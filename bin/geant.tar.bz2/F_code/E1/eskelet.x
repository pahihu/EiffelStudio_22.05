#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif
extern const char *names5[];
static const uint32 types5 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags5 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype5_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype5_1 [] = {0xFF01,1208,0xFF01,1116,0xFFFF};
static const EIF_TYPE_INDEX g_atype5_2 [] = {0xFF01,1208,0xFF01,1116,0xFFFF};
static const EIF_TYPE_INDEX g_atype5_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype5_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype5_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes5 [] = {
g_atype5_0,
g_atype5_1,
g_atype5_2,
g_atype5_3,
g_atype5_4,
g_atype5_5,
};

static const long offsets5 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @LNGOFF(3,2,0,0),
};

extern const char *names8[];
static const uint32 types8 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT64,
SK_UINT64,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags8 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype8_0 [] = {1235,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype8_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype8_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype8_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype8_4 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype8_5 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype8_6 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype8_7 [] = {879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes8 [] = {
g_atype8_0,
g_atype8_1,
g_atype8_2,
g_atype8_3,
g_atype8_4,
g_atype8_5,
g_atype8_6,
g_atype8_7,
};

static const long offsets8 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @I64OFF(1,3,0,0,0,0,0),
+ @I64OFF(1,3,0,0,0,0,1),
+ @I64OFF(1,3,0,0,0,0,2),
+ @I64OFF(1,3,0,0,0,0,3),
};

extern const char *names9[];
static const uint32 types9 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags9 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype9_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_3 [] = {0xFF01,1210,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_4 [] = {0xFF01,1208,0xFF01,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_5 [] = {0xFF01,1208,0xFF01,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_6 [] = {56,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_7 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_8 [] = {0xFF01,1208,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_11 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_12 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_13 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_14 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_15 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_16 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_17 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_18 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_19 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_20 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_21 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_22 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_23 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_24 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_25 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_26 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_27 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_28 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_29 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_30 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_31 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype9_32 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes9 [] = {
g_atype9_0,
g_atype9_1,
g_atype9_2,
g_atype9_3,
g_atype9_4,
g_atype9_5,
g_atype9_6,
g_atype9_7,
g_atype9_8,
g_atype9_9,
g_atype9_10,
g_atype9_11,
g_atype9_12,
g_atype9_13,
g_atype9_14,
g_atype9_15,
g_atype9_16,
g_atype9_17,
g_atype9_18,
g_atype9_19,
g_atype9_20,
g_atype9_21,
g_atype9_22,
g_atype9_23,
g_atype9_24,
g_atype9_25,
g_atype9_26,
g_atype9_27,
g_atype9_28,
g_atype9_29,
g_atype9_30,
g_atype9_31,
g_atype9_32,
};

static const long offsets9 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @CHROFF(9,2),
+ @CHROFF(9,3),
+ @CHROFF(9,4),
+ @CHROFF(9,5),
+ @CHROFF(9,6),
+ @CHROFF(9,7),
+ @CHROFF(9,8),
+ @CHROFF(9,9),
+ @CHROFF(9,10),
+ @CHROFF(9,11),
+ @CHROFF(9,12),
+ @CHROFF(9,13),
+ @CHROFF(9,14),
+ @CHROFF(9,15),
+ @CHROFF(9,16),
+ @CHROFF(9,17),
+ @CHROFF(9,18),
+ @CHROFF(9,19),
+ @CHROFF(9,20),
+ @CHROFF(9,21),
+ @LNGOFF(9,22,0,0),
+ @LNGOFF(9,22,0,1),
};

extern const char *names11[];
static const uint32 types11 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags11 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype11_0 [] = {0xFF01,822,936,0xFF01,948,0xFFFF};
static const EIF_TYPE_INDEX g_atype11_1 [] = {0xFF01,821,0xFF01,948,0xFF01,948,0xFFFF};

static const EIF_TYPE_INDEX *gtypes11 [] = {
g_atype11_0,
g_atype11_1,
};

static const long offsets11 [] =
{
0,
 + @REFACS(1),
};

extern const char *names13[];
static const uint32 types13 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags13 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype13_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype13_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype13_2 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes13 [] = {
g_atype13_0,
g_atype13_1,
g_atype13_2,
};

static const long offsets13 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names15[];
static const uint32 types15 [] =
{
SK_UINT32,
};

static const uint16 attr_flags15 [] =
{1,};

static const EIF_TYPE_INDEX g_atype15_0 [] = {882,0xFFFF};

static const EIF_TYPE_INDEX *gtypes15 [] = {
g_atype15_0,
};

static const long offsets15 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names18[];
static const uint32 types18 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags18 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype18_0 [] = {0xFF01,948,0xFFFF};
static const EIF_TYPE_INDEX g_atype18_1 [] = {0xFF01,1028,0xFFFF};

static const EIF_TYPE_INDEX *gtypes18 [] = {
g_atype18_0,
g_atype18_1,
};

static const long offsets18 [] =
{
0,
 + @REFACS(1),
};

extern const char *names22[];
static const uint32 types22 [] =
{
SK_REF,
};

static const uint16 attr_flags22 [] =
{0,};

static const EIF_TYPE_INDEX g_atype22_0 [] = {950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes22 [] = {
g_atype22_0,
};

static const long offsets22 [] =
{
0,
};

extern const char *names23[];
static const uint32 types23 [] =
{
SK_REF,
};

static const uint16 attr_flags23 [] =
{0,};

static const EIF_TYPE_INDEX g_atype23_0 [] = {950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes23 [] = {
g_atype23_0,
};

static const long offsets23 [] =
{
0,
};

extern const char *names32[];
static const uint32 types32 [] =
{
SK_REF,
};

static const uint16 attr_flags32 [] =
{0,};

static const EIF_TYPE_INDEX g_atype32_0 [] = {0xFF01,1184,0xFF01,133,0xFF01,1031,0xFF01,1275,0xFFFF};

static const EIF_TYPE_INDEX *gtypes32 [] = {
g_atype32_0,
};

static const long offsets32 [] =
{
0,
};

extern const char *names34[];
static const uint32 types34 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags34 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype34_0 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype34_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes34 [] = {
g_atype34_0,
g_atype34_1,
g_atype34_2,
g_atype34_3,
};

static const long offsets34 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
+ @LNGOFF(0,3,0,0),
};

extern const char *names51[];
static const uint32 types51 [] =
{
SK_REF,
};

static const uint16 attr_flags51 [] =
{0,};

static const EIF_TYPE_INDEX g_atype51_0 [] = {699,0xFFFF};

static const EIF_TYPE_INDEX *gtypes51 [] = {
g_atype51_0,
};

static const long offsets51 [] =
{
0,
};

extern const char *names52[];
static const uint32 types52 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags52 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype52_0 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype52_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype52_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype52_3 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes52 [] = {
g_atype52_0,
g_atype52_1,
g_atype52_2,
g_atype52_3,
};

static const long offsets52 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
+ @CHROFF(0,3),
};

extern const char *names57[];
static const uint32 types57 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags57 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype57_0 [] = {0xFF01,737,0xFF01,139,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype57_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes57 [] = {
g_atype57_0,
g_atype57_1,
g_atype57_2,
};

static const long offsets57 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names58[];
static const uint32 types58 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags58 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype58_0 [] = {0xFF01,737,0xFF01,139,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_1 [] = {0xFF01,1221,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype58_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes58 [] = {
g_atype58_0,
g_atype58_1,
g_atype58_2,
g_atype58_3,
};

static const long offsets58 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names68[];
static const uint32 types68 [] =
{
SK_REF,
};

static const uint16 attr_flags68 [] =
{0,};

static const EIF_TYPE_INDEX g_atype68_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes68 [] = {
g_atype68_0,
};

static const long offsets68 [] =
{
0,
};

extern const char *names69[];
static const uint32 types69 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags69 [] =
{0,};

static const EIF_TYPE_INDEX g_atype69_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes69 [] = {
g_atype69_0,
};

static const long offsets69 [] =
{
+ @CHROFF(0,0),
};

extern const char *names70[];
static const uint32 types70 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags70 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype70_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_1 [] = {69,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes70 [] = {
g_atype70_0,
g_atype70_1,
};

static const long offsets70 [] =
{
0,
 + @REFACS(1),
};

extern const char *names71[];
static const uint32 types71 [] =
{
SK_REF,
SK_CHAR8,
};

static const uint16 attr_flags71 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype71_0 [] = {70,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype71_1 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes71 [] = {
g_atype71_0,
g_atype71_1,
};

static const long offsets71 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names75[];
static const uint32 types75 [] =
{
SK_REF,
};

static const uint16 attr_flags75 [] =
{0,};

static const EIF_TYPE_INDEX g_atype75_0 [] = {0xFF01,140,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes75 [] = {
g_atype75_0,
};

static const long offsets75 [] =
{
0,
};

extern const char *names76[];
static const uint32 types76 [] =
{
SK_REF,
};

static const uint16 attr_flags76 [] =
{0,};

static const EIF_TYPE_INDEX g_atype76_0 [] = {0xFF01,141,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes76 [] = {
g_atype76_0,
};

static const long offsets76 [] =
{
0,
};

extern const char *names77[];
static const uint32 types77 [] =
{
SK_REF,
};

static const uint16 attr_flags77 [] =
{0,};

static const EIF_TYPE_INDEX g_atype77_0 [] = {0xFF01,140,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes77 [] = {
g_atype77_0,
};

static const long offsets77 [] =
{
0,
};

extern const char *names78[];
static const uint32 types78 [] =
{
SK_REF,
};

static const uint16 attr_flags78 [] =
{0,};

static const EIF_TYPE_INDEX g_atype78_0 [] = {0xFF01,141,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes78 [] = {
g_atype78_0,
};

static const long offsets78 [] =
{
0,
};

extern const char *names79[];
static const uint32 types79 [] =
{
SK_REF,
};

static const uint16 attr_flags79 [] =
{0,};

static const EIF_TYPE_INDEX g_atype79_0 [] = {0xFF01,140,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes79 [] = {
g_atype79_0,
};

static const long offsets79 [] =
{
0,
};

extern const char *names80[];
static const uint32 types80 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags80 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype80_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_1 [] = {938,0xFF01,0xFFF9,1,864,0xFF01,273,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_2 [] = {938,0xFF01,0xFFF9,2,864,0xFF01,273,0xFF01,273,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_3 [] = {938,0xFF01,0xFFF9,1,864,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_4 [] = {809,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_5 [] = {825,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype80_11 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes80 [] = {
g_atype80_0,
g_atype80_1,
g_atype80_2,
g_atype80_3,
g_atype80_4,
g_atype80_5,
g_atype80_6,
g_atype80_7,
g_atype80_8,
g_atype80_9,
g_atype80_10,
g_atype80_11,
};

static const long offsets80 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names81[];
static const uint32 types81 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags81 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype81_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_1 [] = {938,0xFF01,0xFFF9,1,864,0xFF01,273,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_2 [] = {938,0xFF01,0xFFF9,2,864,0xFF01,273,0xFF01,273,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_3 [] = {938,0xFF01,0xFFF9,1,864,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_4 [] = {809,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_5 [] = {825,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype81_11 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes81 [] = {
g_atype81_0,
g_atype81_1,
g_atype81_2,
g_atype81_3,
g_atype81_4,
g_atype81_5,
g_atype81_6,
g_atype81_7,
g_atype81_8,
g_atype81_9,
g_atype81_10,
g_atype81_11,
};

static const long offsets81 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names95[];
static const uint32 types95 [] =
{
SK_REF,
};

static const uint16 attr_flags95 [] =
{0,};

static const EIF_TYPE_INDEX g_atype95_0 [] = {0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes95 [] = {
g_atype95_0,
};

static const long offsets95 [] =
{
0,
};

extern const char *names108[];
static const uint32 types108 [] =
{
SK_REF,
};

static const uint16 attr_flags108 [] =
{0,};

static const EIF_TYPE_INDEX g_atype108_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes108 [] = {
g_atype108_0,
};

static const long offsets108 [] =
{
0,
};

extern const char *names109[];
static const uint32 types109 [] =
{
SK_INT32,
};

static const uint16 attr_flags109 [] =
{0,};

static const EIF_TYPE_INDEX g_atype109_0 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes109 [] = {
g_atype109_0,
};

static const long offsets109 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names110[];
static const uint32 types110 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags110 [] =
{0,};

static const EIF_TYPE_INDEX g_atype110_0 [] = {897,0xFFFF};

static const EIF_TYPE_INDEX *gtypes110 [] = {
g_atype110_0,
};

static const long offsets110 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names111[];
static const uint32 types111 [] =
{
SK_UINT64,
};

static const uint16 attr_flags111 [] =
{0,};

static const EIF_TYPE_INDEX g_atype111_0 [] = {879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes111 [] = {
g_atype111_0,
};

static const long offsets111 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names112[];
static const uint32 types112 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags112 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype112_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype112_1 [] = {111,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes112 [] = {
g_atype112_0,
g_atype112_1,
};

static const long offsets112 [] =
{
0,
 + @REFACS(1),
};

extern const char *names113[];
static const uint32 types113 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags113 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype113_0 [] = {112,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype113_1 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes113 [] = {
g_atype113_0,
g_atype113_1,
};

static const long offsets113 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names129[];
static const uint32 types129 [] =
{
SK_REF,
};

static const uint16 attr_flags129 [] =
{0,};

static const EIF_TYPE_INDEX g_atype129_0 [] = {0xFF01,122,0xFFFF};

static const EIF_TYPE_INDEX *gtypes129 [] = {
g_atype129_0,
};

static const long offsets129 [] =
{
0,
};

extern const char *names130[];
static const uint32 types130 [] =
{
SK_REF,
};

static const uint16 attr_flags130 [] =
{0,};

static const EIF_TYPE_INDEX g_atype130_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes130 [] = {
g_atype130_0,
};

static const long offsets130 [] =
{
0,
};

extern const char *names131[];
static const uint32 types131 [] =
{
SK_BOOL,
};

static const uint16 attr_flags131 [] =
{0,};

static const EIF_TYPE_INDEX g_atype131_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes131 [] = {
g_atype131_0,
};

static const long offsets131 [] =
{
+ @CHROFF(0,0),
};

extern const char *names132[];
static const uint32 types132 [] =
{
SK_INT32,
};

static const uint16 attr_flags132 [] =
{0,};

static const EIF_TYPE_INDEX g_atype132_0 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes132 [] = {
g_atype132_0,
};

static const long offsets132 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names133[];
static const uint32 types133 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags133 [] =
{0,};

static const EIF_TYPE_INDEX g_atype133_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes133 [] = {
g_atype133_0,
};

static const long offsets133 [] =
{
+ @CHROFF(0,0),
};

extern const char *names134[];
static const uint32 types134 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags134 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype134_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype134_1 [] = {0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes134 [] = {
g_atype134_0,
g_atype134_1,
};

static const long offsets134 [] =
{
0,
 + @REFACS(1),
};

extern const char *names135[];
static const uint32 types135 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags135 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype135_0 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype135_1 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes135 [] = {
g_atype135_0,
g_atype135_1,
};

static const long offsets135 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names136[];
static const uint32 types136 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags136 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype136_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype136_1 [] = {135,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes136 [] = {
g_atype136_0,
g_atype136_1,
};

static const long offsets136 [] =
{
0,
 + @REFACS(1),
};

extern const char *names137[];
static const uint32 types137 [] =
{
SK_REF,
SK_CHAR8,
};

static const uint16 attr_flags137 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype137_0 [] = {136,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype137_1 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes137 [] = {
g_atype137_0,
g_atype137_1,
};

static const long offsets137 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names138[];
static const uint32 types138 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags138 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype138_0 [] = {137,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype138_1 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes138 [] = {
g_atype138_0,
g_atype138_1,
};

static const long offsets138 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names139[];
static const uint32 types139 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags139 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype139_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_1 [] = {138,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype139_2 [] = {138,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes139 [] = {
g_atype139_0,
g_atype139_1,
g_atype139_2,
};

static const long offsets139 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names140[];
static const uint32 types140 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags140 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype140_0 [] = {139,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_1 [] = {139,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype140_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes140 [] = {
g_atype140_0,
g_atype140_1,
g_atype140_2,
};

static const long offsets140 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names144[];
static const uint32 types144 [] =
{
SK_REF,
};

static const uint16 attr_flags144 [] =
{0,};

static const EIF_TYPE_INDEX g_atype144_0 [] = {0xFF01,140,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes144 [] = {
g_atype144_0,
};

static const long offsets144 [] =
{
0,
};

extern const char *names145[];
static const uint32 types145 [] =
{
SK_REF,
};

static const uint16 attr_flags145 [] =
{0,};

static const EIF_TYPE_INDEX g_atype145_0 [] = {0xFF01,141,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes145 [] = {
g_atype145_0,
};

static const long offsets145 [] =
{
0,
};

extern const char *names151[];
static const uint32 types151 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags151 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype151_0 [] = {0xFF01,193,0xFFFF};
static const EIF_TYPE_INDEX g_atype151_1 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes151 [] = {
g_atype151_0,
g_atype151_1,
};

static const long offsets151 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names152[];
static const uint32 types152 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags152 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype152_0 [] = {1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_1 [] = {1281,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_2 [] = {1280,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_3 [] = {1285,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_4 [] = {1279,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_5 [] = {1283,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_6 [] = {1284,0xFFFF};

static const EIF_TYPE_INDEX *gtypes152 [] = {
g_atype152_0,
g_atype152_1,
g_atype152_2,
g_atype152_3,
g_atype152_4,
g_atype152_5,
g_atype152_6,
};

static const long offsets152 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
};

extern const char *names154[];
static const uint32 types154 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags154 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype154_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_2 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes154 [] = {
g_atype154_0,
g_atype154_1,
g_atype154_2,
g_atype154_3,
g_atype154_4,
g_atype154_5,
g_atype154_6,
};

static const long offsets154 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
};

extern const char *names155[];
static const uint32 types155 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags155 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype155_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_3 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_4 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_10 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes155 [] = {
g_atype155_0,
g_atype155_1,
g_atype155_2,
g_atype155_3,
g_atype155_4,
g_atype155_5,
g_atype155_6,
g_atype155_7,
g_atype155_8,
g_atype155_9,
g_atype155_10,
};

static const long offsets155 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @LNGOFF(4,6,0,0),
};

extern const char *names156[];
static const uint32 types156 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags156 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype156_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_3 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_4 [] = {0xFF01,1181,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_5 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_11 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes156 [] = {
g_atype156_0,
g_atype156_1,
g_atype156_2,
g_atype156_3,
g_atype156_4,
g_atype156_5,
g_atype156_6,
g_atype156_7,
g_atype156_8,
g_atype156_9,
g_atype156_10,
g_atype156_11,
};

static const long offsets156 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @LNGOFF(5,6,0,0),
};

extern const char *names157[];
static const uint32 types157 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags157 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype157_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_2 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_7 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes157 [] = {
g_atype157_0,
g_atype157_1,
g_atype157_2,
g_atype157_3,
g_atype157_4,
g_atype157_5,
g_atype157_6,
g_atype157_7,
};

static const long offsets157 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
};

extern const char *names163[];
static const uint32 types163 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags163 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype163_0 [] = {0xFF01,715,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_1 [] = {0xFF01,715,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_2 [] = {0xFF01,715,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype163_3 [] = {0xFF01,715,879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes163 [] = {
g_atype163_0,
g_atype163_1,
g_atype163_2,
g_atype163_3,
};

static const long offsets163 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names164[];
static const uint32 types164 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags164 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype164_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype164_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes164 [] = {
g_atype164_0,
g_atype164_1,
g_atype164_2,
g_atype164_3,
g_atype164_4,
g_atype164_5,
g_atype164_6,
};

static const long offsets164 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
};

extern const char *names165[];
static const uint32 types165 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags165 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype165_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_2 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_9 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype165_10 [] = {879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes165 [] = {
g_atype165_0,
g_atype165_1,
g_atype165_2,
g_atype165_3,
g_atype165_4,
g_atype165_5,
g_atype165_6,
g_atype165_7,
g_atype165_8,
g_atype165_9,
g_atype165_10,
};

static const long offsets165 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @I64OFF(2,4,0,3,0,0,0),
+ @I64OFF(2,4,0,3,0,0,1),
};

extern const char *names166[];
static const uint32 types166 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags166 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype166_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_8 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype166_9 [] = {879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes166 [] = {
g_atype166_0,
g_atype166_1,
g_atype166_2,
g_atype166_3,
g_atype166_4,
g_atype166_5,
g_atype166_6,
g_atype166_7,
g_atype166_8,
g_atype166_9,
};

static const long offsets166 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
+ @LNGOFF(2,3,0,1),
+ @LNGOFF(2,3,0,2),
+ @I64OFF(2,3,0,3,0,0,0),
+ @I64OFF(2,3,0,3,0,0,1),
};

extern const char *names167[];
static const uint32 types167 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
SK_REAL64,
SK_REAL64,
};

static const uint16 attr_flags167 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype167_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_12 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_13 [] = {894,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_14 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes167 [] = {
g_atype167_0,
g_atype167_1,
g_atype167_2,
g_atype167_3,
g_atype167_4,
g_atype167_5,
g_atype167_6,
g_atype167_7,
g_atype167_8,
g_atype167_9,
g_atype167_10,
g_atype167_11,
g_atype167_12,
g_atype167_13,
g_atype167_14,
};

static const long offsets167 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @LNGOFF(2,6,0,0),
+ @LNGOFF(2,6,0,1),
+ @LNGOFF(2,6,0,2),
+ @LNGOFF(2,6,0,3),
+ @R64OFF(2,6,0,4,0,0,0,0),
+ @R64OFF(2,6,0,4,0,0,0,1),
+ @R64OFF(2,6,0,4,0,0,0,2),
};

extern const char *names168[];
static const uint32 types168 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags168 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype168_0 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_1 [] = {712,0xFF01,714,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes168 [] = {
g_atype168_0,
g_atype168_1,
};

static const long offsets168 [] =
{
0,
 + @REFACS(1),
};

extern const char *names169[];
static const uint32 types169 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags169 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype169_0 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype169_1 [] = {712,0xFF01,714,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes169 [] = {
g_atype169_0,
g_atype169_1,
};

static const long offsets169 [] =
{
0,
 + @REFACS(1),
};

extern const char *names170[];
static const uint32 types170 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags170 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype170_0 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype170_1 [] = {712,0xFF01,714,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes170 [] = {
g_atype170_0,
g_atype170_1,
};

static const long offsets170 [] =
{
0,
 + @REFACS(1),
};

extern const char *names175[];
static const uint32 types175 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags175 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype175_0 [] = {0xFF01,191,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_1 [] = {0xFF01,1116,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype175_9 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes175 [] = {
g_atype175_0,
g_atype175_1,
g_atype175_2,
g_atype175_3,
g_atype175_4,
g_atype175_5,
g_atype175_6,
g_atype175_7,
g_atype175_8,
g_atype175_9,
};

static const long offsets175 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
+ @LNGOFF(2,2,0,3),
+ @LNGOFF(2,2,0,4),
+ @LNGOFF(2,2,0,5),
};

extern const char *names178[];
static const uint32 types178 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags178 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype178_0 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_9 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes178 [] = {
g_atype178_0,
g_atype178_1,
g_atype178_2,
g_atype178_3,
g_atype178_4,
g_atype178_5,
g_atype178_6,
g_atype178_7,
g_atype178_8,
g_atype178_9,
};

static const long offsets178 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names179[];
static const uint32 types179 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags179 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype179_0 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_9 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes179 [] = {
g_atype179_0,
g_atype179_1,
g_atype179_2,
g_atype179_3,
g_atype179_4,
g_atype179_5,
g_atype179_6,
g_atype179_7,
g_atype179_8,
g_atype179_9,
};

static const long offsets179 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names180[];
static const uint32 types180 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags180 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype180_0 [] = {0xFF01,302,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_9 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes180 [] = {
g_atype180_0,
g_atype180_1,
g_atype180_2,
g_atype180_3,
g_atype180_4,
g_atype180_5,
g_atype180_6,
g_atype180_7,
g_atype180_8,
g_atype180_9,
};

static const long offsets180 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names181[];
static const uint32 types181 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags181 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype181_0 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_1 [] = {0xFF01,964,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype181_11 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes181 [] = {
g_atype181_0,
g_atype181_1,
g_atype181_2,
g_atype181_3,
g_atype181_4,
g_atype181_5,
g_atype181_6,
g_atype181_7,
g_atype181_8,
g_atype181_9,
g_atype181_10,
g_atype181_11,
};

static const long offsets181 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
};

extern const char *names182[];
static const uint32 types182 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags182 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype182_0 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_1 [] = {0xFF01,964,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_13 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes182 [] = {
g_atype182_0,
g_atype182_1,
g_atype182_2,
g_atype182_3,
g_atype182_4,
g_atype182_5,
g_atype182_6,
g_atype182_7,
g_atype182_8,
g_atype182_9,
g_atype182_10,
g_atype182_11,
g_atype182_12,
g_atype182_13,
};

static const long offsets182 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
+ @LNGOFF(2,4,0,6),
+ @LNGOFF(2,4,0,7),
};

extern const char *names183[];
static const uint32 types183 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags183 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype183_0 [] = {0xFF01,302,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_1 [] = {0xFF01,964,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_14 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes183 [] = {
g_atype183_0,
g_atype183_1,
g_atype183_2,
g_atype183_3,
g_atype183_4,
g_atype183_5,
g_atype183_6,
g_atype183_7,
g_atype183_8,
g_atype183_9,
g_atype183_10,
g_atype183_11,
g_atype183_12,
g_atype183_13,
g_atype183_14,
};

static const long offsets183 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @LNGOFF(2,5,0,0),
+ @LNGOFF(2,5,0,1),
+ @LNGOFF(2,5,0,2),
+ @LNGOFF(2,5,0,3),
+ @LNGOFF(2,5,0,4),
+ @LNGOFF(2,5,0,5),
+ @LNGOFF(2,5,0,6),
+ @LNGOFF(2,5,0,7),
};

extern const char *names190[];
static const uint32 types190 [] =
{
SK_REF,
};

static const uint16 attr_flags190 [] =
{0,};

static const EIF_TYPE_INDEX g_atype190_0 [] = {0xFF01,1237,0xFFFF};

static const EIF_TYPE_INDEX *gtypes190 [] = {
g_atype190_0,
};

static const long offsets190 [] =
{
0,
};

extern const char *names193[];
static const uint32 types193 [] =
{
SK_REF,
};

static const uint16 attr_flags193 [] =
{0,};

static const EIF_TYPE_INDEX g_atype193_0 [] = {0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes193 [] = {
g_atype193_0,
};

static const long offsets193 [] =
{
0,
};

extern const char *names196[];
static const uint32 types196 [] =
{
SK_REF,
};

static const uint16 attr_flags196 [] =
{0,};

static const EIF_TYPE_INDEX g_atype196_0 [] = {0xFF01,193,0xFFFF};

static const EIF_TYPE_INDEX *gtypes196 [] = {
g_atype196_0,
};

static const long offsets196 [] =
{
0,
};

extern const char *names197[];
static const uint32 types197 [] =
{
SK_REF,
};

static const uint16 attr_flags197 [] =
{0,};

static const EIF_TYPE_INDEX g_atype197_0 [] = {0xFF01,193,0xFFFF};

static const EIF_TYPE_INDEX *gtypes197 [] = {
g_atype197_0,
};

static const long offsets197 [] =
{
0,
};

extern const char *names198[];
static const uint32 types198 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags198 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype198_0 [] = {0xFF01,193,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_1 [] = {0xFF01,1285,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_2 [] = {31,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_3 [] = {1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_4 [] = {0xFF01,1220,0xFF01,984,0xFFFF};
static const EIF_TYPE_INDEX g_atype198_5 [] = {1026,0xFFFF};

static const EIF_TYPE_INDEX *gtypes198 [] = {
g_atype198_0,
g_atype198_1,
g_atype198_2,
g_atype198_3,
g_atype198_4,
g_atype198_5,
};

static const long offsets198 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names199[];
static const uint32 types199 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags199 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype199_0 [] = {0xFF01,193,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype199_2 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes199 [] = {
g_atype199_0,
g_atype199_1,
g_atype199_2,
};

static const long offsets199 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names200[];
static const uint32 types200 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags200 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype200_0 [] = {0xFF01,193,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_2 [] = {0xFF01,1026,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_3 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes200 [] = {
g_atype200_0,
g_atype200_1,
g_atype200_2,
g_atype200_3,
};

static const long offsets200 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
};

extern const char *names203[];
static const uint32 types203 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags203 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype203_0 [] = {111,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_2 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes203 [] = {
g_atype203_0,
g_atype203_1,
g_atype203_2,
};

static const long offsets203 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names204[];
static const uint32 types204 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags204 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype204_0 [] = {112,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_2 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes204 [] = {
g_atype204_0,
g_atype204_1,
g_atype204_2,
};

static const long offsets204 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names205[];
static const uint32 types205 [] =
{
SK_INT32,
};

static const uint16 attr_flags205 [] =
{0,};

static const EIF_TYPE_INDEX g_atype205_0 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes205 [] = {
g_atype205_0,
};

static const long offsets205 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names206[];
static const uint32 types206 [] =
{
SK_INT32,
};

static const uint16 attr_flags206 [] =
{0,};

static const EIF_TYPE_INDEX g_atype206_0 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes206 [] = {
g_atype206_0,
};

static const long offsets206 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names211[];
static const uint32 types211 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags211 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype211_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype211_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype211_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype211_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype211_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype211_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype211_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes211 [] = {
g_atype211_0,
g_atype211_1,
g_atype211_2,
g_atype211_3,
g_atype211_4,
g_atype211_5,
g_atype211_6,
};

static const long offsets211 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names212[];
static const uint32 types212 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags212 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype212_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype212_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes212 [] = {
g_atype212_0,
g_atype212_1,
g_atype212_2,
g_atype212_3,
g_atype212_4,
g_atype212_5,
g_atype212_6,
};

static const long offsets212 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names213[];
static const uint32 types213 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags213 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype213_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype213_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes213 [] = {
g_atype213_0,
g_atype213_1,
g_atype213_2,
g_atype213_3,
g_atype213_4,
g_atype213_5,
g_atype213_6,
};

static const long offsets213 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names214[];
static const uint32 types214 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags214 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype214_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype214_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes214 [] = {
g_atype214_0,
g_atype214_1,
g_atype214_2,
g_atype214_3,
g_atype214_4,
g_atype214_5,
g_atype214_6,
};

static const long offsets214 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names215[];
static const uint32 types215 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags215 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype215_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype215_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes215 [] = {
g_atype215_0,
g_atype215_1,
g_atype215_2,
g_atype215_3,
g_atype215_4,
g_atype215_5,
g_atype215_6,
};

static const long offsets215 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names216[];
static const uint32 types216 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags216 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype216_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes216 [] = {
g_atype216_0,
g_atype216_1,
g_atype216_2,
g_atype216_3,
g_atype216_4,
g_atype216_5,
g_atype216_6,
};

static const long offsets216 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names217[];
static const uint32 types217 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags217 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype217_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes217 [] = {
g_atype217_0,
g_atype217_1,
g_atype217_2,
g_atype217_3,
g_atype217_4,
g_atype217_5,
g_atype217_6,
};

static const long offsets217 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names218[];
static const uint32 types218 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags218 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype218_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_7 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes218 [] = {
g_atype218_0,
g_atype218_1,
g_atype218_2,
g_atype218_3,
g_atype218_4,
g_atype218_5,
g_atype218_6,
g_atype218_7,
};

static const long offsets218 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names219[];
static const uint32 types219 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags219 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype219_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_5 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_9 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes219 [] = {
g_atype219_0,
g_atype219_1,
g_atype219_2,
g_atype219_3,
g_atype219_4,
g_atype219_5,
g_atype219_6,
g_atype219_7,
g_atype219_8,
g_atype219_9,
};

static const long offsets219 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
+ @LNGOFF(6,1,0,1),
+ @LNGOFF(6,1,0,2),
};

extern const char *names220[];
static const uint32 types220 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags220 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype220_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_7 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes220 [] = {
g_atype220_0,
g_atype220_1,
g_atype220_2,
g_atype220_3,
g_atype220_4,
g_atype220_5,
g_atype220_6,
g_atype220_7,
};

static const long offsets220 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names221[];
static const uint32 types221 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags221 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype221_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype221_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes221 [] = {
g_atype221_0,
g_atype221_1,
g_atype221_2,
g_atype221_3,
g_atype221_4,
g_atype221_5,
g_atype221_6,
};

static const long offsets221 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names222[];
static const uint32 types222 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags222 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype222_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype222_7 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes222 [] = {
g_atype222_0,
g_atype222_1,
g_atype222_2,
g_atype222_3,
g_atype222_4,
g_atype222_5,
g_atype222_6,
g_atype222_7,
};

static const long offsets222 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names223[];
static const uint32 types223 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags223 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype223_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype223_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes223 [] = {
g_atype223_0,
g_atype223_1,
g_atype223_2,
g_atype223_3,
g_atype223_4,
g_atype223_5,
g_atype223_6,
};

static const long offsets223 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names224[];
static const uint32 types224 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags224 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype224_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype224_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype224_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype224_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype224_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype224_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype224_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes224 [] = {
g_atype224_0,
g_atype224_1,
g_atype224_2,
g_atype224_3,
g_atype224_4,
g_atype224_5,
g_atype224_6,
};

static const long offsets224 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names225[];
static const uint32 types225 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags225 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype225_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes225 [] = {
g_atype225_0,
g_atype225_1,
g_atype225_2,
g_atype225_3,
g_atype225_4,
g_atype225_5,
g_atype225_6,
};

static const long offsets225 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names226[];
static const uint32 types226 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags226 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype226_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes226 [] = {
g_atype226_0,
g_atype226_1,
g_atype226_2,
g_atype226_3,
g_atype226_4,
g_atype226_5,
g_atype226_6,
};

static const long offsets226 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names227[];
static const uint32 types227 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags227 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype227_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype227_7 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes227 [] = {
g_atype227_0,
g_atype227_1,
g_atype227_2,
g_atype227_3,
g_atype227_4,
g_atype227_5,
g_atype227_6,
g_atype227_7,
};

static const long offsets227 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names228[];
static const uint32 types228 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags228 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype228_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype228_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes228 [] = {
g_atype228_0,
g_atype228_1,
g_atype228_2,
g_atype228_3,
g_atype228_4,
g_atype228_5,
g_atype228_6,
};

static const long offsets228 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names229[];
static const uint32 types229 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags229 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype229_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype229_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes229 [] = {
g_atype229_0,
g_atype229_1,
g_atype229_2,
g_atype229_3,
g_atype229_4,
g_atype229_5,
g_atype229_6,
};

static const long offsets229 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names230[];
static const uint32 types230 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags230 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype230_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype230_8 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes230 [] = {
g_atype230_0,
g_atype230_1,
g_atype230_2,
g_atype230_3,
g_atype230_4,
g_atype230_5,
g_atype230_6,
g_atype230_7,
g_atype230_8,
};

static const long offsets230 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
};

extern const char *names231[];
static const uint32 types231 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags231 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype231_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype231_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes231 [] = {
g_atype231_0,
g_atype231_1,
g_atype231_2,
g_atype231_3,
g_atype231_4,
g_atype231_5,
g_atype231_6,
};

static const long offsets231 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names232[];
static const uint32 types232 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags232 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype232_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes232 [] = {
g_atype232_0,
g_atype232_1,
g_atype232_2,
g_atype232_3,
g_atype232_4,
g_atype232_5,
g_atype232_6,
};

static const long offsets232 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names233[];
static const uint32 types233 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags233 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype233_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes233 [] = {
g_atype233_0,
g_atype233_1,
g_atype233_2,
g_atype233_3,
g_atype233_4,
g_atype233_5,
g_atype233_6,
};

static const long offsets233 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names234[];
static const uint32 types234 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags234 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype234_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_5 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_6 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_8 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes234 [] = {
g_atype234_0,
g_atype234_1,
g_atype234_2,
g_atype234_3,
g_atype234_4,
g_atype234_5,
g_atype234_6,
g_atype234_7,
g_atype234_8,
};

static const long offsets234 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names235[];
static const uint32 types235 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags235 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype235_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes235 [] = {
g_atype235_0,
g_atype235_1,
g_atype235_2,
g_atype235_3,
g_atype235_4,
g_atype235_5,
g_atype235_6,
};

static const long offsets235 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names236[];
static const uint32 types236 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags236 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype236_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes236 [] = {
g_atype236_0,
g_atype236_1,
g_atype236_2,
g_atype236_3,
g_atype236_4,
g_atype236_5,
g_atype236_6,
};

static const long offsets236 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names237[];
static const uint32 types237 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags237 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype237_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes237 [] = {
g_atype237_0,
g_atype237_1,
g_atype237_2,
g_atype237_3,
g_atype237_4,
g_atype237_5,
g_atype237_6,
};

static const long offsets237 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names238[];
static const uint32 types238 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags238 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype238_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes238 [] = {
g_atype238_0,
g_atype238_1,
g_atype238_2,
g_atype238_3,
g_atype238_4,
g_atype238_5,
g_atype238_6,
};

static const long offsets238 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names239[];
static const uint32 types239 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags239 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype239_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes239 [] = {
g_atype239_0,
g_atype239_1,
g_atype239_2,
g_atype239_3,
g_atype239_4,
g_atype239_5,
g_atype239_6,
};

static const long offsets239 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names240[];
static const uint32 types240 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags240 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype240_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes240 [] = {
g_atype240_0,
g_atype240_1,
g_atype240_2,
g_atype240_3,
g_atype240_4,
g_atype240_5,
g_atype240_6,
};

static const long offsets240 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names241[];
static const uint32 types241 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags241 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype241_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes241 [] = {
g_atype241_0,
g_atype241_1,
g_atype241_2,
g_atype241_3,
g_atype241_4,
g_atype241_5,
g_atype241_6,
};

static const long offsets241 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names242[];
static const uint32 types242 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags242 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype242_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes242 [] = {
g_atype242_0,
g_atype242_1,
g_atype242_2,
g_atype242_3,
g_atype242_4,
g_atype242_5,
g_atype242_6,
};

static const long offsets242 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names243[];
static const uint32 types243 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags243 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype243_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes243 [] = {
g_atype243_0,
g_atype243_1,
g_atype243_2,
g_atype243_3,
g_atype243_4,
g_atype243_5,
g_atype243_6,
};

static const long offsets243 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names244[];
static const uint32 types244 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags244 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype244_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes244 [] = {
g_atype244_0,
g_atype244_1,
g_atype244_2,
g_atype244_3,
g_atype244_4,
g_atype244_5,
g_atype244_6,
};

static const long offsets244 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names245[];
static const uint32 types245 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags245 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype245_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes245 [] = {
g_atype245_0,
g_atype245_1,
g_atype245_2,
g_atype245_3,
g_atype245_4,
g_atype245_5,
g_atype245_6,
};

static const long offsets245 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names246[];
static const uint32 types246 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags246 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype246_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes246 [] = {
g_atype246_0,
g_atype246_1,
g_atype246_2,
g_atype246_3,
g_atype246_4,
g_atype246_5,
g_atype246_6,
};

static const long offsets246 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names247[];
static const uint32 types247 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags247 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype247_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes247 [] = {
g_atype247_0,
g_atype247_1,
g_atype247_2,
g_atype247_3,
g_atype247_4,
g_atype247_5,
g_atype247_6,
};

static const long offsets247 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names248[];
static const uint32 types248 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags248 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype248_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_7 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes248 [] = {
g_atype248_0,
g_atype248_1,
g_atype248_2,
g_atype248_3,
g_atype248_4,
g_atype248_5,
g_atype248_6,
g_atype248_7,
};

static const long offsets248 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
};

extern const char *names249[];
static const uint32 types249 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags249 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype249_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes249 [] = {
g_atype249_0,
g_atype249_1,
g_atype249_2,
g_atype249_3,
g_atype249_4,
g_atype249_5,
g_atype249_6,
};

static const long offsets249 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names250[];
static const uint32 types250 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags250 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype250_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_2 [] = {210,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_3 [] = {304,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes250 [] = {
g_atype250_0,
g_atype250_1,
g_atype250_2,
g_atype250_3,
g_atype250_4,
g_atype250_5,
g_atype250_6,
};

static const long offsets250 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names254[];
static const uint32 types254 [] =
{
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_UINT64,
};

static const uint16 attr_flags254 [] =
{0,0,1,1,};

static const EIF_TYPE_INDEX g_atype254_0 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype254_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype254_2 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype254_3 [] = {879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes254 [] = {
g_atype254_0,
g_atype254_1,
g_atype254_2,
g_atype254_3,
};

static const long offsets254 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @PTROFF(0,1,0,1,0,0),
+ @I64OFF(0,1,0,1,0,1,0),
};

extern const char *names270[];
static const uint32 types270 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags270 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype270_0 [] = {0xFF01,193,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_1 [] = {0xFF01,1200,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_2 [] = {0xFF01,1200,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes270 [] = {
g_atype270_0,
g_atype270_1,
g_atype270_2,
};

static const long offsets270 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names271[];
static const uint32 types271 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags271 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype271_0 [] = {0xFF01,193,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_1 [] = {0xFF01,1220,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes271 [] = {
g_atype271_0,
g_atype271_1,
};

static const long offsets271 [] =
{
0,
 + @REFACS(1),
};

extern const char *names274[];
static const uint32 types274 [] =
{
SK_INT32,
};

static const uint16 attr_flags274 [] =
{0,};

static const EIF_TYPE_INDEX g_atype274_0 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes274 [] = {
g_atype274_0,
};

static const long offsets274 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names278[];
static const uint32 types278 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags278 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype278_0 [] = {0xFF01,273,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes278 [] = {
g_atype278_0,
g_atype278_1,
g_atype278_2,
g_atype278_3,
};

static const long offsets278 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names279[];
static const uint32 types279 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags279 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype279_0 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes279 [] = {
g_atype279_0,
g_atype279_1,
g_atype279_2,
};

static const long offsets279 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names280[];
static const uint32 types280 [] =
{
SK_REF,
};

static const uint16 attr_flags280 [] =
{0,};

static const EIF_TYPE_INDEX g_atype280_0 [] = {0xFF01,712,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes280 [] = {
g_atype280_0,
};

static const long offsets280 [] =
{
0,
};

extern const char *names281[];
static const uint32 types281 [] =
{
SK_REF,
};

static const uint16 attr_flags281 [] =
{0,};

static const EIF_TYPE_INDEX g_atype281_0 [] = {0xFF01,713,936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes281 [] = {
g_atype281_0,
};

static const long offsets281 [] =
{
0,
};

extern const char *names282[];
static const uint32 types282 [] =
{
SK_REF,
};

static const uint16 attr_flags282 [] =
{0,};

static const EIF_TYPE_INDEX g_atype282_0 [] = {0xFF01,714,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes282 [] = {
g_atype282_0,
};

static const long offsets282 [] =
{
0,
};

extern const char *names283[];
static const uint32 types283 [] =
{
SK_REF,
};

static const uint16 attr_flags283 [] =
{0,};

static const EIF_TYPE_INDEX g_atype283_0 [] = {0xFF01,715,879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes283 [] = {
g_atype283_0,
};

static const long offsets283 [] =
{
0,
};

extern const char *names284[];
static const uint32 types284 [] =
{
SK_REF,
};

static const uint16 attr_flags284 [] =
{0,};

static const EIF_TYPE_INDEX g_atype284_0 [] = {0xFF01,716,900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes284 [] = {
g_atype284_0,
};

static const long offsets284 [] =
{
0,
};

extern const char *names285[];
static const uint32 types285 [] =
{
SK_REF,
};

static const uint16 attr_flags285 [] =
{0,};

static const EIF_TYPE_INDEX g_atype285_0 [] = {0xFF01,717,897,0xFFFF};

static const EIF_TYPE_INDEX *gtypes285 [] = {
g_atype285_0,
};

static const long offsets285 [] =
{
0,
};

extern const char *names286[];
static const uint32 types286 [] =
{
SK_REF,
};

static const uint16 attr_flags286 [] =
{0,};

static const EIF_TYPE_INDEX g_atype286_0 [] = {0xFF01,718,888,0xFFFF};

static const EIF_TYPE_INDEX *gtypes286 [] = {
g_atype286_0,
};

static const long offsets286 [] =
{
0,
};

extern const char *names287[];
static const uint32 types287 [] =
{
SK_REF,
};

static const uint16 attr_flags287 [] =
{0,};

static const EIF_TYPE_INDEX g_atype287_0 [] = {0xFF01,719,885,0xFFFF};

static const EIF_TYPE_INDEX *gtypes287 [] = {
g_atype287_0,
};

static const long offsets287 [] =
{
0,
};

extern const char *names288[];
static const uint32 types288 [] =
{
SK_REF,
};

static const uint16 attr_flags288 [] =
{0,};

static const EIF_TYPE_INDEX g_atype288_0 [] = {0xFF01,720,882,0xFFFF};

static const EIF_TYPE_INDEX *gtypes288 [] = {
g_atype288_0,
};

static const long offsets288 [] =
{
0,
};

extern const char *names289[];
static const uint32 types289 [] =
{
SK_REF,
};

static const uint16 attr_flags289 [] =
{0,};

static const EIF_TYPE_INDEX g_atype289_0 [] = {0xFF01,721,903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes289 [] = {
g_atype289_0,
};

static const long offsets289 [] =
{
0,
};

extern const char *names290[];
static const uint32 types290 [] =
{
SK_REF,
};

static const uint16 attr_flags290 [] =
{0,};

static const EIF_TYPE_INDEX g_atype290_0 [] = {0xFF01,722,891,0xFFFF};

static const EIF_TYPE_INDEX *gtypes290 [] = {
g_atype290_0,
};

static const long offsets290 [] =
{
0,
};

extern const char *names291[];
static const uint32 types291 [] =
{
SK_REF,
};

static const uint16 attr_flags291 [] =
{0,};

static const EIF_TYPE_INDEX g_atype291_0 [] = {0xFF01,723,894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes291 [] = {
g_atype291_0,
};

static const long offsets291 [] =
{
0,
};

extern const char *names294[];
static const uint32 types294 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags294 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype294_0 [] = {0xFF01,253,0xFFFF};
static const EIF_TYPE_INDEX g_atype294_1 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes294 [] = {
g_atype294_0,
g_atype294_1,
};

static const long offsets294 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names295[];
static const uint32 types295 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags295 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype295_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_1 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_2 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_4 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype295_5 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes295 [] = {
g_atype295_0,
g_atype295_1,
g_atype295_2,
g_atype295_3,
g_atype295_4,
g_atype295_5,
};

static const long offsets295 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @PTROFF(3,0,0,1,0,0),
+ @PTROFF(3,0,0,1,0,1),
};

extern const char *names296[];
static const uint32 types296 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags296 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype296_0 [] = {0xFF01,718,888,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_1 [] = {942,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_2 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype296_4 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes296 [] = {
g_atype296_0,
g_atype296_1,
g_atype296_2,
g_atype296_3,
g_atype296_4,
};

static const long offsets296 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names297[];
static const uint32 types297 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags297 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype297_0 [] = {0xFF01,718,888,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_1 [] = {942,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_2 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype297_4 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes297 [] = {
g_atype297_0,
g_atype297_1,
g_atype297_2,
g_atype297_3,
g_atype297_4,
};

static const long offsets297 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names298[];
static const uint32 types298 [] =
{
SK_INT32,
};

static const uint16 attr_flags298 [] =
{0,};

static const EIF_TYPE_INDEX g_atype298_0 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes298 [] = {
g_atype298_0,
};

static const long offsets298 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names300[];
static const uint32 types300 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags300 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype300_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_2 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype300_7 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes300 [] = {
g_atype300_0,
g_atype300_1,
g_atype300_2,
g_atype300_3,
g_atype300_4,
g_atype300_5,
g_atype300_6,
g_atype300_7,
};

static const long offsets300 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
};

extern const char *names303[];
static const uint32 types303 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR32,
};

static const uint16 attr_flags303 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype303_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_1 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_2 [] = {0xFF01,717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_3 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype303_4 [] = {897,0xFFFF};

static const EIF_TYPE_INDEX *gtypes303 [] = {
g_atype303_0,
g_atype303_1,
g_atype303_2,
g_atype303_3,
g_atype303_4,
};

static const long offsets303 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
};

extern const char *names304[];
static const uint32 types304 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags304 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype304_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype304_1 [] = {0xFF01,716,900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes304 [] = {
g_atype304_0,
g_atype304_1,
};

static const long offsets304 [] =
{
0,
 + @REFACS(1),
};

extern const char *names305[];
static const uint32 types305 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags305 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype305_0 [] = {0xFF01,253,0xFFFF};
static const EIF_TYPE_INDEX g_atype305_1 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes305 [] = {
g_atype305_0,
g_atype305_1,
};

static const long offsets305 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names306[];
static const uint32 types306 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags306 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype306_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_1 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_2 [] = {888,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_3 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_4 [] = {885,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_5 [] = {876,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_6 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_9 [] = {891,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_10 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_11 [] = {870,0xFFFF};
static const EIF_TYPE_INDEX g_atype306_12 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes306 [] = {
g_atype306_0,
g_atype306_1,
g_atype306_2,
g_atype306_3,
g_atype306_4,
g_atype306_5,
g_atype306_6,
g_atype306_7,
g_atype306_8,
g_atype306_9,
g_atype306_10,
g_atype306_11,
g_atype306_12,
};

static const long offsets306 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @I16OFF(1,3,0),
+ @I16OFF(1,3,1),
+ @LNGOFF(1,3,2,0),
+ @LNGOFF(1,3,2,1),
+ @LNGOFF(1,3,2,2),
+ @R32OFF(1,3,2,3,0),
+ @I64OFF(1,3,2,3,1,0,0),
+ @I64OFF(1,3,2,3,1,0,1),
+ @R64OFF(1,3,2,3,1,0,2,0),
};

extern const char *names308[];
static const uint32 types308 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags308 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype308_0 [] = {0xFF01,1261,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_2 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_3 [] = {307,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_4 [] = {0xFF01,818,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_5 [] = {809,307,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_6 [] = {809,0xFF01,309,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_7 [] = {0xFF01,0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_11 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype308_14 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes308 [] = {
g_atype308_0,
g_atype308_1,
g_atype308_2,
g_atype308_3,
g_atype308_4,
g_atype308_5,
g_atype308_6,
g_atype308_7,
g_atype308_8,
g_atype308_9,
g_atype308_10,
g_atype308_11,
g_atype308_12,
g_atype308_13,
g_atype308_14,
};

static const long offsets308 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
+ @LNGOFF(8,4,0,0),
+ @LNGOFF(8,4,0,1),
+ @LNGOFF(8,4,0,2),
};

extern const char *names310[];
static const uint32 types310 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags310 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype310_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype310_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes310 [] = {
g_atype310_0,
g_atype310_1,
g_atype310_2,
};

static const long offsets310 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names311[];
static const uint32 types311 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags311 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype311_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype311_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes311 [] = {
g_atype311_0,
g_atype311_1,
g_atype311_2,
g_atype311_3,
g_atype311_4,
};

static const long offsets311 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names312[];
static const uint32 types312 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags312 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype312_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype312_4 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes312 [] = {
g_atype312_0,
g_atype312_1,
g_atype312_2,
g_atype312_3,
g_atype312_4,
};

static const long offsets312 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @PTROFF(2,0,0,2,0,0),
};

extern const char *names313[];
static const uint32 types313 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags313 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype313_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_2 [] = {876,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype313_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes313 [] = {
g_atype313_0,
g_atype313_1,
g_atype313_2,
g_atype313_3,
g_atype313_4,
};

static const long offsets313 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names314[];
static const uint32 types314 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags314 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype314_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype314_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes314 [] = {
g_atype314_0,
g_atype314_1,
g_atype314_2,
g_atype314_3,
g_atype314_4,
};

static const long offsets314 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names315[];
static const uint32 types315 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags315 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype315_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype315_4 [] = {879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes315 [] = {
g_atype315_0,
g_atype315_1,
g_atype315_2,
g_atype315_3,
g_atype315_4,
};

static const long offsets315 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names316[];
static const uint32 types316 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags316 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype316_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_4 [] = {870,0xFFFF};

static const EIF_TYPE_INDEX *gtypes316 [] = {
g_atype316_0,
g_atype316_1,
g_atype316_2,
g_atype316_3,
g_atype316_4,
};

static const long offsets316 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names317[];
static const uint32 types317 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags317 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype317_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_2 [] = {885,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype317_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes317 [] = {
g_atype317_0,
g_atype317_1,
g_atype317_2,
g_atype317_3,
g_atype317_4,
};

static const long offsets317 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names318[];
static const uint32 types318 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags318 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype318_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_4 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes318 [] = {
g_atype318_0,
g_atype318_1,
g_atype318_2,
g_atype318_3,
g_atype318_4,
};

static const long offsets318 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R64OFF(2,0,0,2,0,0,0,0),
};

extern const char *names319[];
static const uint32 types319 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags319 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype319_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype319_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes319 [] = {
g_atype319_0,
g_atype319_1,
g_atype319_2,
g_atype319_3,
g_atype319_4,
};

static const long offsets319 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names320[];
static const uint32 types320 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags320 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype320_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes320 [] = {
g_atype320_0,
g_atype320_1,
g_atype320_2,
g_atype320_3,
g_atype320_4,
};

static const long offsets320 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names321[];
static const uint32 types321 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags321 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype321_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_2 [] = {888,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes321 [] = {
g_atype321_0,
g_atype321_1,
g_atype321_2,
g_atype321_3,
g_atype321_4,
};

static const long offsets321 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names322[];
static const uint32 types322 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags322 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype322_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype322_4 [] = {891,0xFFFF};

static const EIF_TYPE_INDEX *gtypes322 [] = {
g_atype322_0,
g_atype322_1,
g_atype322_2,
g_atype322_3,
g_atype322_4,
};

static const long offsets322 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R32OFF(2,0,0,2,0),
};

extern const char *names323[];
static const uint32 types323 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags323 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype323_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_2 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype323_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes323 [] = {
g_atype323_0,
g_atype323_1,
g_atype323_2,
g_atype323_3,
g_atype323_4,
};

static const long offsets323 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names324[];
static const uint32 types324 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags324 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype324_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_2 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes324 [] = {
g_atype324_0,
g_atype324_1,
g_atype324_2,
g_atype324_3,
g_atype324_4,
};

static const long offsets324 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names325[];
static const uint32 types325 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags325 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype325_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes325 [] = {
g_atype325_0,
g_atype325_1,
g_atype325_2,
g_atype325_3,
g_atype325_4,
};

static const long offsets325 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names326[];
static const uint32 types326 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags326 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype326_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_1 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes326 [] = {
g_atype326_0,
g_atype326_1,
g_atype326_2,
g_atype326_3,
g_atype326_4,
g_atype326_5,
};

static const long offsets326 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names327[];
static const uint32 types327 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags327 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype327_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes327 [] = {
g_atype327_0,
g_atype327_1,
g_atype327_2,
g_atype327_3,
g_atype327_4,
g_atype327_5,
};

static const long offsets327 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names328[];
static const uint32 types328 [] =
{
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags328 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype328_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_1 [] = {885,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype328_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes328 [] = {
g_atype328_0,
g_atype328_1,
g_atype328_2,
g_atype328_3,
g_atype328_4,
g_atype328_5,
};

static const long offsets328 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names329[];
static const uint32 types329 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags329 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype329_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_1 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype329_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes329 [] = {
g_atype329_0,
g_atype329_1,
g_atype329_2,
g_atype329_3,
g_atype329_4,
g_atype329_5,
};

static const long offsets329 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names330[];
static const uint32 types330 [] =
{
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags330 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype330_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_1 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype330_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes330 [] = {
g_atype330_0,
g_atype330_1,
g_atype330_2,
g_atype330_3,
g_atype330_4,
g_atype330_5,
};

static const long offsets330 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names331[];
static const uint32 types331 [] =
{
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags331 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype331_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_1 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes331 [] = {
g_atype331_0,
g_atype331_1,
g_atype331_2,
g_atype331_3,
g_atype331_4,
g_atype331_5,
};

static const long offsets331 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names332[];
static const uint32 types332 [] =
{
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags332 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype332_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_1 [] = {876,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes332 [] = {
g_atype332_0,
g_atype332_1,
g_atype332_2,
g_atype332_3,
g_atype332_4,
g_atype332_5,
};

static const long offsets332 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names333[];
static const uint32 types333 [] =
{
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags333 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype333_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_1 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype333_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes333 [] = {
g_atype333_0,
g_atype333_1,
g_atype333_2,
g_atype333_3,
g_atype333_4,
g_atype333_5,
};

static const long offsets333 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names334[];
static const uint32 types334 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags334 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype334_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_1 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype334_5 [] = {879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes334 [] = {
g_atype334_0,
g_atype334_1,
g_atype334_2,
g_atype334_3,
g_atype334_4,
g_atype334_5,
};

static const long offsets334 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names335[];
static const uint32 types335 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags335 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype335_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_1 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_5 [] = {891,0xFFFF};

static const EIF_TYPE_INDEX *gtypes335 [] = {
g_atype335_0,
g_atype335_1,
g_atype335_2,
g_atype335_3,
g_atype335_4,
g_atype335_5,
};

static const long offsets335 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R32OFF(1,0,0,4,0),
};

extern const char *names336[];
static const uint32 types336 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags336 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype336_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_1 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes336 [] = {
g_atype336_0,
g_atype336_1,
g_atype336_2,
g_atype336_3,
g_atype336_4,
g_atype336_5,
};

static const long offsets336 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names337[];
static const uint32 types337 [] =
{
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags337 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype337_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_1 [] = {888,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes337 [] = {
g_atype337_0,
g_atype337_1,
g_atype337_2,
g_atype337_3,
g_atype337_4,
g_atype337_5,
};

static const long offsets337 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names338[];
static const uint32 types338 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags338 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype338_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_1 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_5 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes338 [] = {
g_atype338_0,
g_atype338_1,
g_atype338_2,
g_atype338_3,
g_atype338_4,
g_atype338_5,
};

static const long offsets338 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R64OFF(1,0,0,4,0,0,0,0),
};

extern const char *names339[];
static const uint32 types339 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags339 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype339_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_1 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_5 [] = {870,0xFFFF};

static const EIF_TYPE_INDEX *gtypes339 [] = {
g_atype339_0,
g_atype339_1,
g_atype339_2,
g_atype339_3,
g_atype339_4,
g_atype339_5,
};

static const long offsets339 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names340[];
static const uint32 types340 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags340 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype340_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_1 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype340_5 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes340 [] = {
g_atype340_0,
g_atype340_1,
g_atype340_2,
g_atype340_3,
g_atype340_4,
g_atype340_5,
};

static const long offsets340 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @PTROFF(1,0,0,4,0,0),
};

extern const char *names341[];
static const uint32 types341 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags341 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype341_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_3 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes341 [] = {
g_atype341_0,
g_atype341_1,
g_atype341_2,
g_atype341_3,
g_atype341_4,
g_atype341_5,
};

static const long offsets341 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names342[];
static const uint32 types342 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags342 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype342_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype342_5 [] = {879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes342 [] = {
g_atype342_0,
g_atype342_1,
g_atype342_2,
g_atype342_3,
g_atype342_4,
g_atype342_5,
};

static const long offsets342 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names343[];
static const uint32 types343 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags343 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype343_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_3 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes343 [] = {
g_atype343_0,
g_atype343_1,
g_atype343_2,
g_atype343_3,
g_atype343_4,
g_atype343_5,
};

static const long offsets343 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names344[];
static const uint32 types344 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags344 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype344_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_3 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes344 [] = {
g_atype344_0,
g_atype344_1,
g_atype344_2,
g_atype344_3,
g_atype344_4,
g_atype344_5,
};

static const long offsets344 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names345[];
static const uint32 types345 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags345 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype345_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_5 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes345 [] = {
g_atype345_0,
g_atype345_1,
g_atype345_2,
g_atype345_3,
g_atype345_4,
g_atype345_5,
};

static const long offsets345 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R64OFF(2,0,0,3,0,0,0,0),
};

extern const char *names346[];
static const uint32 types346 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags346 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype346_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_2 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_3 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes346 [] = {
g_atype346_0,
g_atype346_1,
g_atype346_2,
g_atype346_3,
g_atype346_4,
g_atype346_5,
};

static const long offsets346 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names347[];
static const uint32 types347 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags347 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype347_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_2 [] = {888,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_3 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes347 [] = {
g_atype347_0,
g_atype347_1,
g_atype347_2,
g_atype347_3,
g_atype347_4,
g_atype347_5,
};

static const long offsets347 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names348[];
static const uint32 types348 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags348 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype348_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_5 [] = {891,0xFFFF};

static const EIF_TYPE_INDEX *gtypes348 [] = {
g_atype348_0,
g_atype348_1,
g_atype348_2,
g_atype348_3,
g_atype348_4,
g_atype348_5,
};

static const long offsets348 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R32OFF(2,0,0,3,0),
};

extern const char *names349[];
static const uint32 types349 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags349 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype349_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_2 [] = {885,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_3 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes349 [] = {
g_atype349_0,
g_atype349_1,
g_atype349_2,
g_atype349_3,
g_atype349_4,
g_atype349_5,
};

static const long offsets349 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names350[];
static const uint32 types350 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags350 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype350_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_5 [] = {870,0xFFFF};

static const EIF_TYPE_INDEX *gtypes350 [] = {
g_atype350_0,
g_atype350_1,
g_atype350_2,
g_atype350_3,
g_atype350_4,
g_atype350_5,
};

static const long offsets350 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names351[];
static const uint32 types351 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags351 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype351_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes351 [] = {
g_atype351_0,
g_atype351_1,
g_atype351_2,
g_atype351_3,
g_atype351_4,
g_atype351_5,
};

static const long offsets351 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names352[];
static const uint32 types352 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags352 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype352_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_2 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_3 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes352 [] = {
g_atype352_0,
g_atype352_1,
g_atype352_2,
g_atype352_3,
g_atype352_4,
g_atype352_5,
};

static const long offsets352 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names353[];
static const uint32 types353 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags353 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype353_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_2 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_3 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes353 [] = {
g_atype353_0,
g_atype353_1,
g_atype353_2,
g_atype353_3,
g_atype353_4,
g_atype353_5,
};

static const long offsets353 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names354[];
static const uint32 types354 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags354 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype354_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_2 [] = {876,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_3 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes354 [] = {
g_atype354_0,
g_atype354_1,
g_atype354_2,
g_atype354_3,
g_atype354_4,
g_atype354_5,
};

static const long offsets354 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names355[];
static const uint32 types355 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags355 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype355_0 [] = {0xFFF9,2,864,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_5 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes355 [] = {
g_atype355_0,
g_atype355_1,
g_atype355_2,
g_atype355_3,
g_atype355_4,
g_atype355_5,
};

static const long offsets355 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @PTROFF(2,0,0,3,0,0),
};

extern const char *names369[];
static const uint32 types369 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags369 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype369_0 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_1 [] = {0xFFF5,1,0xFF01,712,0xFFF8,1,3356,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_2 [] = {0xFFF5,1,0xFF01,808,0xFFF8,1,3519,0xFFFF};

static const EIF_TYPE_INDEX *gtypes369 [] = {
g_atype369_0,
g_atype369_1,
g_atype369_2,
};

static const long offsets369 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names370[];
static const uint32 types370 [] =
{
SK_UINT8,
SK_POINTER,
};

static const uint16 attr_flags370 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype370_0 [] = {888,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_1 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes370 [] = {
g_atype370_0,
g_atype370_1,
};

static const long offsets370 [] =
{
+ @CHROFF(0,0),
+ @PTROFF(0,1,0,0,0,0),
};

extern const char *names392[];
static const uint32 types392 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags392 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype392_0 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype392_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes392 [] = {
g_atype392_0,
g_atype392_1,
g_atype392_2,
g_atype392_3,
};

static const long offsets392 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names394[];
static const uint32 types394 [] =
{
SK_REF,
};

static const uint16 attr_flags394 [] =
{0,};

static const EIF_TYPE_INDEX g_atype394_0 [] = {0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes394 [] = {
g_atype394_0,
};

static const long offsets394 [] =
{
0,
};

extern const char *names424[];
static const uint32 types424 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags424 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype424_0 [] = {0xFF01,700,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype424_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes424 [] = {
g_atype424_0,
g_atype424_1,
g_atype424_2,
g_atype424_3,
g_atype424_4,
g_atype424_5,
g_atype424_6,
};

static const long offsets424 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names425[];
static const uint32 types425 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags425 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype425_0 [] = {0xFF01,701,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype425_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes425 [] = {
g_atype425_0,
g_atype425_1,
g_atype425_2,
g_atype425_3,
g_atype425_4,
g_atype425_5,
g_atype425_6,
};

static const long offsets425 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names426[];
static const uint32 types426 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags426 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype426_0 [] = {0xFF01,702,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype426_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype426_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype426_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype426_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype426_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype426_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes426 [] = {
g_atype426_0,
g_atype426_1,
g_atype426_2,
g_atype426_3,
g_atype426_4,
g_atype426_5,
g_atype426_6,
};

static const long offsets426 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names427[];
static const uint32 types427 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags427 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype427_0 [] = {0xFF01,703,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype427_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes427 [] = {
g_atype427_0,
g_atype427_1,
g_atype427_2,
g_atype427_3,
g_atype427_4,
g_atype427_5,
g_atype427_6,
};

static const long offsets427 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names428[];
static const uint32 types428 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags428 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype428_0 [] = {0xFF01,704,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype428_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype428_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype428_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype428_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype428_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype428_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes428 [] = {
g_atype428_0,
g_atype428_1,
g_atype428_2,
g_atype428_3,
g_atype428_4,
g_atype428_5,
g_atype428_6,
};

static const long offsets428 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names429[];
static const uint32 types429 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags429 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype429_0 [] = {0xFF01,705,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype429_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype429_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype429_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype429_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype429_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype429_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes429 [] = {
g_atype429_0,
g_atype429_1,
g_atype429_2,
g_atype429_3,
g_atype429_4,
g_atype429_5,
g_atype429_6,
};

static const long offsets429 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names430[];
static const uint32 types430 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags430 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype430_0 [] = {0xFF01,706,888,0xFFFF};
static const EIF_TYPE_INDEX g_atype430_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype430_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype430_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype430_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype430_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype430_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes430 [] = {
g_atype430_0,
g_atype430_1,
g_atype430_2,
g_atype430_3,
g_atype430_4,
g_atype430_5,
g_atype430_6,
};

static const long offsets430 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names431[];
static const uint32 types431 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags431 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype431_0 [] = {0xFF01,707,885,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype431_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes431 [] = {
g_atype431_0,
g_atype431_1,
g_atype431_2,
g_atype431_3,
g_atype431_4,
g_atype431_5,
g_atype431_6,
};

static const long offsets431 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names432[];
static const uint32 types432 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags432 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype432_0 [] = {0xFF01,708,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype432_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes432 [] = {
g_atype432_0,
g_atype432_1,
g_atype432_2,
g_atype432_3,
g_atype432_4,
g_atype432_5,
g_atype432_6,
};

static const long offsets432 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names433[];
static const uint32 types433 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags433 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype433_0 [] = {0xFF01,709,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype433_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes433 [] = {
g_atype433_0,
g_atype433_1,
g_atype433_2,
g_atype433_3,
g_atype433_4,
g_atype433_5,
g_atype433_6,
};

static const long offsets433 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names434[];
static const uint32 types434 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags434 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype434_0 [] = {0xFF01,710,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype434_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes434 [] = {
g_atype434_0,
g_atype434_1,
g_atype434_2,
g_atype434_3,
g_atype434_4,
g_atype434_5,
g_atype434_6,
};

static const long offsets434 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names435[];
static const uint32 types435 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags435 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype435_0 [] = {0xFF01,711,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype435_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes435 [] = {
g_atype435_0,
g_atype435_1,
g_atype435_2,
g_atype435_3,
g_atype435_4,
g_atype435_5,
g_atype435_6,
};

static const long offsets435 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names436[];
static const uint32 types436 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags436 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype436_0 [] = {0xFF01,803,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_1 [] = {111,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_3 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype436_7 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes436 [] = {
g_atype436_0,
g_atype436_1,
g_atype436_2,
g_atype436_3,
g_atype436_4,
g_atype436_5,
g_atype436_6,
g_atype436_7,
};

static const long offsets436 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names437[];
static const uint32 types437 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags437 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype437_0 [] = {0xFF01,804,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_1 [] = {112,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_3 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype437_7 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes437 [] = {
g_atype437_0,
g_atype437_1,
g_atype437_2,
g_atype437_3,
g_atype437_4,
g_atype437_5,
g_atype437_6,
g_atype437_7,
};

static const long offsets437 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names438[];
static const uint32 types438 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags438 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype438_0 [] = {0xFF01,821,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype438_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes438 [] = {
g_atype438_0,
g_atype438_1,
g_atype438_2,
g_atype438_3,
g_atype438_4,
g_atype438_5,
g_atype438_6,
};

static const long offsets438 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names439[];
static const uint32 types439 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags439 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype439_0 [] = {0xFF01,822,936,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype439_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype439_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype439_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype439_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype439_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype439_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes439 [] = {
g_atype439_0,
g_atype439_1,
g_atype439_2,
g_atype439_3,
g_atype439_4,
g_atype439_5,
g_atype439_6,
};

static const long offsets439 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names440[];
static const uint32 types440 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags440 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype440_0 [] = {0xFF01,823,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype440_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes440 [] = {
g_atype440_0,
g_atype440_1,
g_atype440_2,
g_atype440_3,
g_atype440_4,
g_atype440_5,
g_atype440_6,
};

static const long offsets440 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names441[];
static const uint32 types441 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags441 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype441_0 [] = {0xFF01,824,873,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype441_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype441_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype441_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype441_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype441_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype441_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes441 [] = {
g_atype441_0,
g_atype441_1,
g_atype441_2,
g_atype441_3,
g_atype441_4,
g_atype441_5,
g_atype441_6,
};

static const long offsets441 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names442[];
static const uint32 types442 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags442 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype442_0 [] = {0xFF01,825,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype442_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype442_2 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype442_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype442_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype442_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype442_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes442 [] = {
g_atype442_0,
g_atype442_1,
g_atype442_2,
g_atype442_3,
g_atype442_4,
g_atype442_5,
g_atype442_6,
};

static const long offsets442 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names443[];
static const uint32 types443 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags443 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype443_0 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype443_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype443_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes443 [] = {
g_atype443_0,
g_atype443_1,
g_atype443_2,
};

static const long offsets443 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names444[];
static const uint32 types444 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags444 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype444_0 [] = {0xFF01,713,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype444_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype444_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes444 [] = {
g_atype444_0,
g_atype444_1,
g_atype444_2,
};

static const long offsets444 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names445[];
static const uint32 types445 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags445 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype445_0 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype445_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype445_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes445 [] = {
g_atype445_0,
g_atype445_1,
g_atype445_2,
};

static const long offsets445 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names446[];
static const uint32 types446 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags446 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype446_0 [] = {0xFF01,715,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype446_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype446_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes446 [] = {
g_atype446_0,
g_atype446_1,
g_atype446_2,
};

static const long offsets446 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names447[];
static const uint32 types447 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags447 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype447_0 [] = {0xFF01,716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype447_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype447_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes447 [] = {
g_atype447_0,
g_atype447_1,
g_atype447_2,
};

static const long offsets447 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names448[];
static const uint32 types448 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags448 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype448_0 [] = {0xFF01,717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype448_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes448 [] = {
g_atype448_0,
g_atype448_1,
g_atype448_2,
};

static const long offsets448 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names449[];
static const uint32 types449 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags449 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype449_0 [] = {0xFF01,718,888,0xFFFF};
static const EIF_TYPE_INDEX g_atype449_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype449_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes449 [] = {
g_atype449_0,
g_atype449_1,
g_atype449_2,
};

static const long offsets449 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names450[];
static const uint32 types450 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags450 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype450_0 [] = {0xFF01,719,885,0xFFFF};
static const EIF_TYPE_INDEX g_atype450_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype450_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes450 [] = {
g_atype450_0,
g_atype450_1,
g_atype450_2,
};

static const long offsets450 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names451[];
static const uint32 types451 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags451 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype451_0 [] = {0xFF01,720,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype451_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype451_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes451 [] = {
g_atype451_0,
g_atype451_1,
g_atype451_2,
};

static const long offsets451 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names452[];
static const uint32 types452 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags452 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype452_0 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype452_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype452_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes452 [] = {
g_atype452_0,
g_atype452_1,
g_atype452_2,
};

static const long offsets452 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names453[];
static const uint32 types453 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags453 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype453_0 [] = {0xFF01,722,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype453_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype453_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes453 [] = {
g_atype453_0,
g_atype453_1,
g_atype453_2,
};

static const long offsets453 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names454[];
static const uint32 types454 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags454 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype454_0 [] = {0xFF01,723,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype454_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype454_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes454 [] = {
g_atype454_0,
g_atype454_1,
g_atype454_2,
};

static const long offsets454 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names455[];
static const uint32 types455 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags455 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype455_0 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype455_1 [] = {0xFF01,809,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype455_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype455_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes455 [] = {
g_atype455_0,
g_atype455_1,
g_atype455_2,
g_atype455_3,
};

static const long offsets455 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names456[];
static const uint32 types456 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags456 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype456_0 [] = {0xFF01,713,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype456_1 [] = {0xFF01,810,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype456_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype456_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes456 [] = {
g_atype456_0,
g_atype456_1,
g_atype456_2,
g_atype456_3,
};

static const long offsets456 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names457[];
static const uint32 types457 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags457 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype457_0 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype457_1 [] = {0xFF01,811,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype457_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype457_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes457 [] = {
g_atype457_0,
g_atype457_1,
g_atype457_2,
g_atype457_3,
};

static const long offsets457 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names458[];
static const uint32 types458 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags458 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype458_0 [] = {0xFF01,715,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_1 [] = {0xFF01,812,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes458 [] = {
g_atype458_0,
g_atype458_1,
g_atype458_2,
g_atype458_3,
};

static const long offsets458 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names459[];
static const uint32 types459 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags459 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype459_0 [] = {0xFF01,716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_1 [] = {0xFF01,813,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes459 [] = {
g_atype459_0,
g_atype459_1,
g_atype459_2,
g_atype459_3,
};

static const long offsets459 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names460[];
static const uint32 types460 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags460 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype460_0 [] = {0xFF01,717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_1 [] = {0xFF01,814,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes460 [] = {
g_atype460_0,
g_atype460_1,
g_atype460_2,
g_atype460_3,
};

static const long offsets460 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names461[];
static const uint32 types461 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags461 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype461_0 [] = {0xFF01,718,888,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_1 [] = {0xFF01,815,888,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes461 [] = {
g_atype461_0,
g_atype461_1,
g_atype461_2,
g_atype461_3,
};

static const long offsets461 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names462[];
static const uint32 types462 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags462 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype462_0 [] = {0xFF01,719,885,0xFFFF};
static const EIF_TYPE_INDEX g_atype462_1 [] = {0xFF01,816,885,0xFFFF};
static const EIF_TYPE_INDEX g_atype462_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype462_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes462 [] = {
g_atype462_0,
g_atype462_1,
g_atype462_2,
g_atype462_3,
};

static const long offsets462 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names463[];
static const uint32 types463 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags463 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype463_0 [] = {0xFF01,720,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype463_1 [] = {0xFF01,817,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype463_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype463_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes463 [] = {
g_atype463_0,
g_atype463_1,
g_atype463_2,
g_atype463_3,
};

static const long offsets463 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names464[];
static const uint32 types464 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags464 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype464_0 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype464_1 [] = {0xFF01,818,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype464_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype464_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes464 [] = {
g_atype464_0,
g_atype464_1,
g_atype464_2,
g_atype464_3,
};

static const long offsets464 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names465[];
static const uint32 types465 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags465 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype465_0 [] = {0xFF01,722,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype465_1 [] = {0xFF01,819,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype465_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype465_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes465 [] = {
g_atype465_0,
g_atype465_1,
g_atype465_2,
g_atype465_3,
};

static const long offsets465 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names466[];
static const uint32 types466 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags466 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype466_0 [] = {0xFF01,723,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_1 [] = {0xFF01,820,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes466 [] = {
g_atype466_0,
g_atype466_1,
g_atype466_2,
g_atype466_3,
};

static const long offsets466 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names467[];
static const uint32 types467 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags467 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype467_0 [] = {0xFF01,717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_1 [] = {0xFF01,945,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes467 [] = {
g_atype467_0,
g_atype467_1,
g_atype467_2,
g_atype467_3,
g_atype467_4,
};

static const long offsets467 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names468[];
static const uint32 types468 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags468 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype468_0 [] = {0xFF01,716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype468_1 [] = {0xFF01,948,0xFFFF};
static const EIF_TYPE_INDEX g_atype468_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype468_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype468_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes468 [] = {
g_atype468_0,
g_atype468_1,
g_atype468_2,
g_atype468_3,
g_atype468_4,
};

static const long offsets468 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names469[];
static const uint32 types469 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags469 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype469_0 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype469_1 [] = {0xFF01,737,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype469_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype469_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype469_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes469 [] = {
g_atype469_0,
g_atype469_1,
g_atype469_2,
g_atype469_3,
g_atype469_4,
};

static const long offsets469 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names470[];
static const uint32 types470 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags470 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype470_0 [] = {0xFF01,713,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype470_1 [] = {0xFF01,738,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype470_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype470_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype470_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes470 [] = {
g_atype470_0,
g_atype470_1,
g_atype470_2,
g_atype470_3,
g_atype470_4,
};

static const long offsets470 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names471[];
static const uint32 types471 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags471 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype471_0 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype471_1 [] = {0xFF01,739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype471_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype471_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype471_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes471 [] = {
g_atype471_0,
g_atype471_1,
g_atype471_2,
g_atype471_3,
g_atype471_4,
};

static const long offsets471 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names472[];
static const uint32 types472 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags472 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype472_0 [] = {0xFF01,715,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype472_1 [] = {0xFF01,740,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype472_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype472_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype472_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes472 [] = {
g_atype472_0,
g_atype472_1,
g_atype472_2,
g_atype472_3,
g_atype472_4,
};

static const long offsets472 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names473[];
static const uint32 types473 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags473 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype473_0 [] = {0xFF01,716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype473_1 [] = {0xFF01,741,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype473_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype473_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype473_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes473 [] = {
g_atype473_0,
g_atype473_1,
g_atype473_2,
g_atype473_3,
g_atype473_4,
};

static const long offsets473 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names474[];
static const uint32 types474 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags474 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype474_0 [] = {0xFF01,717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype474_1 [] = {0xFF01,742,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype474_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype474_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype474_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes474 [] = {
g_atype474_0,
g_atype474_1,
g_atype474_2,
g_atype474_3,
g_atype474_4,
};

static const long offsets474 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names475[];
static const uint32 types475 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags475 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype475_0 [] = {0xFF01,718,888,0xFFFF};
static const EIF_TYPE_INDEX g_atype475_1 [] = {0xFF01,743,888,0xFFFF};
static const EIF_TYPE_INDEX g_atype475_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype475_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype475_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes475 [] = {
g_atype475_0,
g_atype475_1,
g_atype475_2,
g_atype475_3,
g_atype475_4,
};

static const long offsets475 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names476[];
static const uint32 types476 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags476 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype476_0 [] = {0xFF01,719,885,0xFFFF};
static const EIF_TYPE_INDEX g_atype476_1 [] = {0xFF01,744,885,0xFFFF};
static const EIF_TYPE_INDEX g_atype476_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype476_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype476_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes476 [] = {
g_atype476_0,
g_atype476_1,
g_atype476_2,
g_atype476_3,
g_atype476_4,
};

static const long offsets476 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names477[];
static const uint32 types477 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags477 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype477_0 [] = {0xFF01,720,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype477_1 [] = {0xFF01,745,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype477_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype477_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype477_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes477 [] = {
g_atype477_0,
g_atype477_1,
g_atype477_2,
g_atype477_3,
g_atype477_4,
};

static const long offsets477 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names478[];
static const uint32 types478 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags478 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype478_0 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype478_1 [] = {0xFF01,746,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype478_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype478_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype478_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes478 [] = {
g_atype478_0,
g_atype478_1,
g_atype478_2,
g_atype478_3,
g_atype478_4,
};

static const long offsets478 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names479[];
static const uint32 types479 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags479 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype479_0 [] = {0xFF01,722,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype479_1 [] = {0xFF01,747,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype479_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype479_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype479_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes479 [] = {
g_atype479_0,
g_atype479_1,
g_atype479_2,
g_atype479_3,
g_atype479_4,
};

static const long offsets479 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names480[];
static const uint32 types480 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags480 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype480_0 [] = {0xFF01,723,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype480_1 [] = {0xFF01,748,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype480_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype480_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype480_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes480 [] = {
g_atype480_0,
g_atype480_1,
g_atype480_2,
g_atype480_3,
g_atype480_4,
};

static const long offsets480 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names481[];
static const uint32 types481 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags481 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype481_0 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype481_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype481_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes481 [] = {
g_atype481_0,
g_atype481_1,
g_atype481_2,
};

static const long offsets481 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names482[];
static const uint32 types482 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags482 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype482_0 [] = {0xFF01,713,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype482_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype482_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes482 [] = {
g_atype482_0,
g_atype482_1,
g_atype482_2,
};

static const long offsets482 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names483[];
static const uint32 types483 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags483 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype483_0 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes483 [] = {
g_atype483_0,
g_atype483_1,
g_atype483_2,
};

static const long offsets483 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names484[];
static const uint32 types484 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags484 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype484_0 [] = {0xFF01,715,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype484_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype484_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes484 [] = {
g_atype484_0,
g_atype484_1,
g_atype484_2,
};

static const long offsets484 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names485[];
static const uint32 types485 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags485 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype485_0 [] = {0xFF01,716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes485 [] = {
g_atype485_0,
g_atype485_1,
g_atype485_2,
};

static const long offsets485 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names486[];
static const uint32 types486 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags486 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype486_0 [] = {0xFF01,717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype486_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype486_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes486 [] = {
g_atype486_0,
g_atype486_1,
g_atype486_2,
};

static const long offsets486 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names487[];
static const uint32 types487 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags487 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype487_0 [] = {0xFF01,718,888,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes487 [] = {
g_atype487_0,
g_atype487_1,
g_atype487_2,
};

static const long offsets487 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names488[];
static const uint32 types488 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags488 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype488_0 [] = {0xFF01,719,885,0xFFFF};
static const EIF_TYPE_INDEX g_atype488_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype488_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes488 [] = {
g_atype488_0,
g_atype488_1,
g_atype488_2,
};

static const long offsets488 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names489[];
static const uint32 types489 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags489 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype489_0 [] = {0xFF01,720,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes489 [] = {
g_atype489_0,
g_atype489_1,
g_atype489_2,
};

static const long offsets489 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names490[];
static const uint32 types490 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags490 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype490_0 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype490_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype490_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes490 [] = {
g_atype490_0,
g_atype490_1,
g_atype490_2,
};

static const long offsets490 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names491[];
static const uint32 types491 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags491 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype491_0 [] = {0xFF01,722,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes491 [] = {
g_atype491_0,
g_atype491_1,
g_atype491_2,
};

static const long offsets491 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names492[];
static const uint32 types492 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags492 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype492_0 [] = {0xFF01,723,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype492_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype492_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes492 [] = {
g_atype492_0,
g_atype492_1,
g_atype492_2,
};

static const long offsets492 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names493[];
static const uint32 types493 [] =
{
SK_BOOL,
};

static const uint16 attr_flags493 [] =
{0,};

static const EIF_TYPE_INDEX g_atype493_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes493 [] = {
g_atype493_0,
};

static const long offsets493 [] =
{
+ @CHROFF(0,0),
};

extern const char *names494[];
static const uint32 types494 [] =
{
SK_BOOL,
};

static const uint16 attr_flags494 [] =
{0,};

static const EIF_TYPE_INDEX g_atype494_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes494 [] = {
g_atype494_0,
};

static const long offsets494 [] =
{
+ @CHROFF(0,0),
};

extern const char *names495[];
static const uint32 types495 [] =
{
SK_BOOL,
};

static const uint16 attr_flags495 [] =
{0,};

static const EIF_TYPE_INDEX g_atype495_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes495 [] = {
g_atype495_0,
};

static const long offsets495 [] =
{
+ @CHROFF(0,0),
};

extern const char *names496[];
static const uint32 types496 [] =
{
SK_BOOL,
};

static const uint16 attr_flags496 [] =
{0,};

static const EIF_TYPE_INDEX g_atype496_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes496 [] = {
g_atype496_0,
};

static const long offsets496 [] =
{
+ @CHROFF(0,0),
};

extern const char *names497[];
static const uint32 types497 [] =
{
SK_BOOL,
};

static const uint16 attr_flags497 [] =
{0,};

static const EIF_TYPE_INDEX g_atype497_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes497 [] = {
g_atype497_0,
};

static const long offsets497 [] =
{
+ @CHROFF(0,0),
};

extern const char *names498[];
static const uint32 types498 [] =
{
SK_BOOL,
};

static const uint16 attr_flags498 [] =
{0,};

static const EIF_TYPE_INDEX g_atype498_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes498 [] = {
g_atype498_0,
};

static const long offsets498 [] =
{
+ @CHROFF(0,0),
};

extern const char *names499[];
static const uint32 types499 [] =
{
SK_BOOL,
};

static const uint16 attr_flags499 [] =
{0,};

static const EIF_TYPE_INDEX g_atype499_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes499 [] = {
g_atype499_0,
};

static const long offsets499 [] =
{
+ @CHROFF(0,0),
};

extern const char *names500[];
static const uint32 types500 [] =
{
SK_BOOL,
};

static const uint16 attr_flags500 [] =
{0,};

static const EIF_TYPE_INDEX g_atype500_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes500 [] = {
g_atype500_0,
};

static const long offsets500 [] =
{
+ @CHROFF(0,0),
};

extern const char *names501[];
static const uint32 types501 [] =
{
SK_BOOL,
};

static const uint16 attr_flags501 [] =
{0,};

static const EIF_TYPE_INDEX g_atype501_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes501 [] = {
g_atype501_0,
};

static const long offsets501 [] =
{
+ @CHROFF(0,0),
};

extern const char *names502[];
static const uint32 types502 [] =
{
SK_BOOL,
};

static const uint16 attr_flags502 [] =
{0,};

static const EIF_TYPE_INDEX g_atype502_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes502 [] = {
g_atype502_0,
};

static const long offsets502 [] =
{
+ @CHROFF(0,0),
};

extern const char *names503[];
static const uint32 types503 [] =
{
SK_BOOL,
};

static const uint16 attr_flags503 [] =
{0,};

static const EIF_TYPE_INDEX g_atype503_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes503 [] = {
g_atype503_0,
};

static const long offsets503 [] =
{
+ @CHROFF(0,0),
};

extern const char *names504[];
static const uint32 types504 [] =
{
SK_BOOL,
};

static const uint16 attr_flags504 [] =
{0,};

static const EIF_TYPE_INDEX g_atype504_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes504 [] = {
g_atype504_0,
};

static const long offsets504 [] =
{
+ @CHROFF(0,0),
};

extern const char *names505[];
static const uint32 types505 [] =
{
SK_BOOL,
};

static const uint16 attr_flags505 [] =
{0,};

static const EIF_TYPE_INDEX g_atype505_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes505 [] = {
g_atype505_0,
};

static const long offsets505 [] =
{
+ @CHROFF(0,0),
};

extern const char *names506[];
static const uint32 types506 [] =
{
SK_BOOL,
};

static const uint16 attr_flags506 [] =
{0,};

static const EIF_TYPE_INDEX g_atype506_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes506 [] = {
g_atype506_0,
};

static const long offsets506 [] =
{
+ @CHROFF(0,0),
};

extern const char *names507[];
static const uint32 types507 [] =
{
SK_BOOL,
};

static const uint16 attr_flags507 [] =
{0,};

static const EIF_TYPE_INDEX g_atype507_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes507 [] = {
g_atype507_0,
};

static const long offsets507 [] =
{
+ @CHROFF(0,0),
};

extern const char *names508[];
static const uint32 types508 [] =
{
SK_BOOL,
};

static const uint16 attr_flags508 [] =
{0,};

static const EIF_TYPE_INDEX g_atype508_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes508 [] = {
g_atype508_0,
};

static const long offsets508 [] =
{
+ @CHROFF(0,0),
};

extern const char *names509[];
static const uint32 types509 [] =
{
SK_BOOL,
};

static const uint16 attr_flags509 [] =
{0,};

static const EIF_TYPE_INDEX g_atype509_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes509 [] = {
g_atype509_0,
};

static const long offsets509 [] =
{
+ @CHROFF(0,0),
};

extern const char *names510[];
static const uint32 types510 [] =
{
SK_BOOL,
};

static const uint16 attr_flags510 [] =
{0,};

static const EIF_TYPE_INDEX g_atype510_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes510 [] = {
g_atype510_0,
};

static const long offsets510 [] =
{
+ @CHROFF(0,0),
};

extern const char *names511[];
static const uint32 types511 [] =
{
SK_BOOL,
};

static const uint16 attr_flags511 [] =
{0,};

static const EIF_TYPE_INDEX g_atype511_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes511 [] = {
g_atype511_0,
};

static const long offsets511 [] =
{
+ @CHROFF(0,0),
};

extern const char *names512[];
static const uint32 types512 [] =
{
SK_BOOL,
};

static const uint16 attr_flags512 [] =
{0,};

static const EIF_TYPE_INDEX g_atype512_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes512 [] = {
g_atype512_0,
};

static const long offsets512 [] =
{
+ @CHROFF(0,0),
};

extern const char *names513[];
static const uint32 types513 [] =
{
SK_BOOL,
};

static const uint16 attr_flags513 [] =
{0,};

static const EIF_TYPE_INDEX g_atype513_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes513 [] = {
g_atype513_0,
};

static const long offsets513 [] =
{
+ @CHROFF(0,0),
};

extern const char *names514[];
static const uint32 types514 [] =
{
SK_BOOL,
};

static const uint16 attr_flags514 [] =
{0,};

static const EIF_TYPE_INDEX g_atype514_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes514 [] = {
g_atype514_0,
};

static const long offsets514 [] =
{
+ @CHROFF(0,0),
};

extern const char *names515[];
static const uint32 types515 [] =
{
SK_BOOL,
};

static const uint16 attr_flags515 [] =
{0,};

static const EIF_TYPE_INDEX g_atype515_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes515 [] = {
g_atype515_0,
};

static const long offsets515 [] =
{
+ @CHROFF(0,0),
};

extern const char *names516[];
static const uint32 types516 [] =
{
SK_BOOL,
};

static const uint16 attr_flags516 [] =
{0,};

static const EIF_TYPE_INDEX g_atype516_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes516 [] = {
g_atype516_0,
};

static const long offsets516 [] =
{
+ @CHROFF(0,0),
};

extern const char *names517[];
static const uint32 types517 [] =
{
SK_BOOL,
};

static const uint16 attr_flags517 [] =
{0,};

static const EIF_TYPE_INDEX g_atype517_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes517 [] = {
g_atype517_0,
};

static const long offsets517 [] =
{
+ @CHROFF(0,0),
};

extern const char *names518[];
static const uint32 types518 [] =
{
SK_BOOL,
};

static const uint16 attr_flags518 [] =
{0,};

static const EIF_TYPE_INDEX g_atype518_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes518 [] = {
g_atype518_0,
};

static const long offsets518 [] =
{
+ @CHROFF(0,0),
};

extern const char *names519[];
static const uint32 types519 [] =
{
SK_BOOL,
};

static const uint16 attr_flags519 [] =
{0,};

static const EIF_TYPE_INDEX g_atype519_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes519 [] = {
g_atype519_0,
};

static const long offsets519 [] =
{
+ @CHROFF(0,0),
};

extern const char *names520[];
static const uint32 types520 [] =
{
SK_BOOL,
};

static const uint16 attr_flags520 [] =
{0,};

static const EIF_TYPE_INDEX g_atype520_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes520 [] = {
g_atype520_0,
};

static const long offsets520 [] =
{
+ @CHROFF(0,0),
};

extern const char *names521[];
static const uint32 types521 [] =
{
SK_BOOL,
};

static const uint16 attr_flags521 [] =
{0,};

static const EIF_TYPE_INDEX g_atype521_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes521 [] = {
g_atype521_0,
};

static const long offsets521 [] =
{
+ @CHROFF(0,0),
};

extern const char *names522[];
static const uint32 types522 [] =
{
SK_BOOL,
};

static const uint16 attr_flags522 [] =
{0,};

static const EIF_TYPE_INDEX g_atype522_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes522 [] = {
g_atype522_0,
};

static const long offsets522 [] =
{
+ @CHROFF(0,0),
};

extern const char *names523[];
static const uint32 types523 [] =
{
SK_BOOL,
};

static const uint16 attr_flags523 [] =
{0,};

static const EIF_TYPE_INDEX g_atype523_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes523 [] = {
g_atype523_0,
};

static const long offsets523 [] =
{
+ @CHROFF(0,0),
};

extern const char *names524[];
static const uint32 types524 [] =
{
SK_BOOL,
};

static const uint16 attr_flags524 [] =
{0,};

static const EIF_TYPE_INDEX g_atype524_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes524 [] = {
g_atype524_0,
};

static const long offsets524 [] =
{
+ @CHROFF(0,0),
};

extern const char *names525[];
static const uint32 types525 [] =
{
SK_BOOL,
};

static const uint16 attr_flags525 [] =
{0,};

static const EIF_TYPE_INDEX g_atype525_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes525 [] = {
g_atype525_0,
};

static const long offsets525 [] =
{
+ @CHROFF(0,0),
};

extern const char *names526[];
static const uint32 types526 [] =
{
SK_BOOL,
};

static const uint16 attr_flags526 [] =
{0,};

static const EIF_TYPE_INDEX g_atype526_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes526 [] = {
g_atype526_0,
};

static const long offsets526 [] =
{
+ @CHROFF(0,0),
};

extern const char *names527[];
static const uint32 types527 [] =
{
SK_BOOL,
};

static const uint16 attr_flags527 [] =
{0,};

static const EIF_TYPE_INDEX g_atype527_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes527 [] = {
g_atype527_0,
};

static const long offsets527 [] =
{
+ @CHROFF(0,0),
};

extern const char *names528[];
static const uint32 types528 [] =
{
SK_BOOL,
};

static const uint16 attr_flags528 [] =
{0,};

static const EIF_TYPE_INDEX g_atype528_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes528 [] = {
g_atype528_0,
};

static const long offsets528 [] =
{
+ @CHROFF(0,0),
};

extern const char *names529[];
static const uint32 types529 [] =
{
SK_BOOL,
};

static const uint16 attr_flags529 [] =
{0,};

static const EIF_TYPE_INDEX g_atype529_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes529 [] = {
g_atype529_0,
};

static const long offsets529 [] =
{
+ @CHROFF(0,0),
};

extern const char *names530[];
static const uint32 types530 [] =
{
SK_BOOL,
};

static const uint16 attr_flags530 [] =
{0,};

static const EIF_TYPE_INDEX g_atype530_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes530 [] = {
g_atype530_0,
};

static const long offsets530 [] =
{
+ @CHROFF(0,0),
};

extern const char *names531[];
static const uint32 types531 [] =
{
SK_BOOL,
};

static const uint16 attr_flags531 [] =
{0,};

static const EIF_TYPE_INDEX g_atype531_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes531 [] = {
g_atype531_0,
};

static const long offsets531 [] =
{
+ @CHROFF(0,0),
};

extern const char *names532[];
static const uint32 types532 [] =
{
SK_BOOL,
};

static const uint16 attr_flags532 [] =
{0,};

static const EIF_TYPE_INDEX g_atype532_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes532 [] = {
g_atype532_0,
};

static const long offsets532 [] =
{
+ @CHROFF(0,0),
};

extern const char *names533[];
static const uint32 types533 [] =
{
SK_BOOL,
};

static const uint16 attr_flags533 [] =
{0,};

static const EIF_TYPE_INDEX g_atype533_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes533 [] = {
g_atype533_0,
};

static const long offsets533 [] =
{
+ @CHROFF(0,0),
};

extern const char *names534[];
static const uint32 types534 [] =
{
SK_BOOL,
};

static const uint16 attr_flags534 [] =
{0,};

static const EIF_TYPE_INDEX g_atype534_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes534 [] = {
g_atype534_0,
};

static const long offsets534 [] =
{
+ @CHROFF(0,0),
};

extern const char *names535[];
static const uint32 types535 [] =
{
SK_BOOL,
};

static const uint16 attr_flags535 [] =
{0,};

static const EIF_TYPE_INDEX g_atype535_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes535 [] = {
g_atype535_0,
};

static const long offsets535 [] =
{
+ @CHROFF(0,0),
};

extern const char *names536[];
static const uint32 types536 [] =
{
SK_BOOL,
};

static const uint16 attr_flags536 [] =
{0,};

static const EIF_TYPE_INDEX g_atype536_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes536 [] = {
g_atype536_0,
};

static const long offsets536 [] =
{
+ @CHROFF(0,0),
};

extern const char *names537[];
static const uint32 types537 [] =
{
SK_BOOL,
};

static const uint16 attr_flags537 [] =
{0,};

static const EIF_TYPE_INDEX g_atype537_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes537 [] = {
g_atype537_0,
};

static const long offsets537 [] =
{
+ @CHROFF(0,0),
};

extern const char *names538[];
static const uint32 types538 [] =
{
SK_BOOL,
};

static const uint16 attr_flags538 [] =
{0,};

static const EIF_TYPE_INDEX g_atype538_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes538 [] = {
g_atype538_0,
};

static const long offsets538 [] =
{
+ @CHROFF(0,0),
};

extern const char *names539[];
static const uint32 types539 [] =
{
SK_BOOL,
};

static const uint16 attr_flags539 [] =
{0,};

static const EIF_TYPE_INDEX g_atype539_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes539 [] = {
g_atype539_0,
};

static const long offsets539 [] =
{
+ @CHROFF(0,0),
};

extern const char *names540[];
static const uint32 types540 [] =
{
SK_BOOL,
};

static const uint16 attr_flags540 [] =
{0,};

static const EIF_TYPE_INDEX g_atype540_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes540 [] = {
g_atype540_0,
};

static const long offsets540 [] =
{
+ @CHROFF(0,0),
};

extern const char *names541[];
static const uint32 types541 [] =
{
SK_BOOL,
};

static const uint16 attr_flags541 [] =
{0,};

static const EIF_TYPE_INDEX g_atype541_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes541 [] = {
g_atype541_0,
};

static const long offsets541 [] =
{
+ @CHROFF(0,0),
};

extern const char *names542[];
static const uint32 types542 [] =
{
SK_BOOL,
};

static const uint16 attr_flags542 [] =
{0,};

static const EIF_TYPE_INDEX g_atype542_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes542 [] = {
g_atype542_0,
};

static const long offsets542 [] =
{
+ @CHROFF(0,0),
};

extern const char *names543[];
static const uint32 types543 [] =
{
SK_BOOL,
};

static const uint16 attr_flags543 [] =
{0,};

static const EIF_TYPE_INDEX g_atype543_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes543 [] = {
g_atype543_0,
};

static const long offsets543 [] =
{
+ @CHROFF(0,0),
};

extern const char *names544[];
static const uint32 types544 [] =
{
SK_BOOL,
};

static const uint16 attr_flags544 [] =
{0,};

static const EIF_TYPE_INDEX g_atype544_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes544 [] = {
g_atype544_0,
};

static const long offsets544 [] =
{
+ @CHROFF(0,0),
};

extern const char *names545[];
static const uint32 types545 [] =
{
SK_BOOL,
};

static const uint16 attr_flags545 [] =
{0,};

static const EIF_TYPE_INDEX g_atype545_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes545 [] = {
g_atype545_0,
};

static const long offsets545 [] =
{
+ @CHROFF(0,0),
};

extern const char *names546[];
static const uint32 types546 [] =
{
SK_BOOL,
};

static const uint16 attr_flags546 [] =
{0,};

static const EIF_TYPE_INDEX g_atype546_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes546 [] = {
g_atype546_0,
};

static const long offsets546 [] =
{
+ @CHROFF(0,0),
};

extern const char *names547[];
static const uint32 types547 [] =
{
SK_BOOL,
};

static const uint16 attr_flags547 [] =
{0,};

static const EIF_TYPE_INDEX g_atype547_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes547 [] = {
g_atype547_0,
};

static const long offsets547 [] =
{
+ @CHROFF(0,0),
};

extern const char *names548[];
static const uint32 types548 [] =
{
SK_BOOL,
};

static const uint16 attr_flags548 [] =
{0,};

static const EIF_TYPE_INDEX g_atype548_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes548 [] = {
g_atype548_0,
};

static const long offsets548 [] =
{
+ @CHROFF(0,0),
};

extern const char *names549[];
static const uint32 types549 [] =
{
SK_BOOL,
};

static const uint16 attr_flags549 [] =
{0,};

static const EIF_TYPE_INDEX g_atype549_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes549 [] = {
g_atype549_0,
};

static const long offsets549 [] =
{
+ @CHROFF(0,0),
};

extern const char *names550[];
static const uint32 types550 [] =
{
SK_BOOL,
};

static const uint16 attr_flags550 [] =
{0,};

static const EIF_TYPE_INDEX g_atype550_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes550 [] = {
g_atype550_0,
};

static const long offsets550 [] =
{
+ @CHROFF(0,0),
};

extern const char *names551[];
static const uint32 types551 [] =
{
SK_BOOL,
};

static const uint16 attr_flags551 [] =
{0,};

static const EIF_TYPE_INDEX g_atype551_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes551 [] = {
g_atype551_0,
};

static const long offsets551 [] =
{
+ @CHROFF(0,0),
};

extern const char *names552[];
static const uint32 types552 [] =
{
SK_BOOL,
};

static const uint16 attr_flags552 [] =
{0,};

static const EIF_TYPE_INDEX g_atype552_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes552 [] = {
g_atype552_0,
};

static const long offsets552 [] =
{
+ @CHROFF(0,0),
};

extern const char *names553[];
static const uint32 types553 [] =
{
SK_BOOL,
};

static const uint16 attr_flags553 [] =
{0,};

static const EIF_TYPE_INDEX g_atype553_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes553 [] = {
g_atype553_0,
};

static const long offsets553 [] =
{
+ @CHROFF(0,0),
};

extern const char *names554[];
static const uint32 types554 [] =
{
SK_BOOL,
};

static const uint16 attr_flags554 [] =
{0,};

static const EIF_TYPE_INDEX g_atype554_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes554 [] = {
g_atype554_0,
};

static const long offsets554 [] =
{
+ @CHROFF(0,0),
};

extern const char *names555[];
static const uint32 types555 [] =
{
SK_BOOL,
};

static const uint16 attr_flags555 [] =
{0,};

static const EIF_TYPE_INDEX g_atype555_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes555 [] = {
g_atype555_0,
};

static const long offsets555 [] =
{
+ @CHROFF(0,0),
};

extern const char *names556[];
static const uint32 types556 [] =
{
SK_BOOL,
};

static const uint16 attr_flags556 [] =
{0,};

static const EIF_TYPE_INDEX g_atype556_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes556 [] = {
g_atype556_0,
};

static const long offsets556 [] =
{
+ @CHROFF(0,0),
};

extern const char *names557[];
static const uint32 types557 [] =
{
SK_BOOL,
};

static const uint16 attr_flags557 [] =
{0,};

static const EIF_TYPE_INDEX g_atype557_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes557 [] = {
g_atype557_0,
};

static const long offsets557 [] =
{
+ @CHROFF(0,0),
};

extern const char *names558[];
static const uint32 types558 [] =
{
SK_BOOL,
};

static const uint16 attr_flags558 [] =
{0,};

static const EIF_TYPE_INDEX g_atype558_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes558 [] = {
g_atype558_0,
};

static const long offsets558 [] =
{
+ @CHROFF(0,0),
};

extern const char *names559[];
static const uint32 types559 [] =
{
SK_BOOL,
};

static const uint16 attr_flags559 [] =
{0,};

static const EIF_TYPE_INDEX g_atype559_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes559 [] = {
g_atype559_0,
};

static const long offsets559 [] =
{
+ @CHROFF(0,0),
};

extern const char *names560[];
static const uint32 types560 [] =
{
SK_BOOL,
};

static const uint16 attr_flags560 [] =
{0,};

static const EIF_TYPE_INDEX g_atype560_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes560 [] = {
g_atype560_0,
};

static const long offsets560 [] =
{
+ @CHROFF(0,0),
};

extern const char *names561[];
static const uint32 types561 [] =
{
SK_BOOL,
};

static const uint16 attr_flags561 [] =
{0,};

static const EIF_TYPE_INDEX g_atype561_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes561 [] = {
g_atype561_0,
};

static const long offsets561 [] =
{
+ @CHROFF(0,0),
};

extern const char *names562[];
static const uint32 types562 [] =
{
SK_BOOL,
};

static const uint16 attr_flags562 [] =
{0,};

static const EIF_TYPE_INDEX g_atype562_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes562 [] = {
g_atype562_0,
};

static const long offsets562 [] =
{
+ @CHROFF(0,0),
};

extern const char *names563[];
static const uint32 types563 [] =
{
SK_BOOL,
};

static const uint16 attr_flags563 [] =
{0,};

static const EIF_TYPE_INDEX g_atype563_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes563 [] = {
g_atype563_0,
};

static const long offsets563 [] =
{
+ @CHROFF(0,0),
};

extern const char *names564[];
static const uint32 types564 [] =
{
SK_BOOL,
};

static const uint16 attr_flags564 [] =
{0,};

static const EIF_TYPE_INDEX g_atype564_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes564 [] = {
g_atype564_0,
};

static const long offsets564 [] =
{
+ @CHROFF(0,0),
};

extern const char *names565[];
static const uint32 types565 [] =
{
SK_BOOL,
};

static const uint16 attr_flags565 [] =
{0,};

static const EIF_TYPE_INDEX g_atype565_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes565 [] = {
g_atype565_0,
};

static const long offsets565 [] =
{
+ @CHROFF(0,0),
};

extern const char *names566[];
static const uint32 types566 [] =
{
SK_BOOL,
};

static const uint16 attr_flags566 [] =
{0,};

static const EIF_TYPE_INDEX g_atype566_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes566 [] = {
g_atype566_0,
};

static const long offsets566 [] =
{
+ @CHROFF(0,0),
};

extern const char *names567[];
static const uint32 types567 [] =
{
SK_BOOL,
};

static const uint16 attr_flags567 [] =
{0,};

static const EIF_TYPE_INDEX g_atype567_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes567 [] = {
g_atype567_0,
};

static const long offsets567 [] =
{
+ @CHROFF(0,0),
};

extern const char *names568[];
static const uint32 types568 [] =
{
SK_BOOL,
};

static const uint16 attr_flags568 [] =
{0,};

static const EIF_TYPE_INDEX g_atype568_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes568 [] = {
g_atype568_0,
};

static const long offsets568 [] =
{
+ @CHROFF(0,0),
};

extern const char *names569[];
static const uint32 types569 [] =
{
SK_BOOL,
};

static const uint16 attr_flags569 [] =
{0,};

static const EIF_TYPE_INDEX g_atype569_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes569 [] = {
g_atype569_0,
};

static const long offsets569 [] =
{
+ @CHROFF(0,0),
};

extern const char *names570[];
static const uint32 types570 [] =
{
SK_BOOL,
};

static const uint16 attr_flags570 [] =
{0,};

static const EIF_TYPE_INDEX g_atype570_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes570 [] = {
g_atype570_0,
};

static const long offsets570 [] =
{
+ @CHROFF(0,0),
};

extern const char *names571[];
static const uint32 types571 [] =
{
SK_BOOL,
};

static const uint16 attr_flags571 [] =
{0,};

static const EIF_TYPE_INDEX g_atype571_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes571 [] = {
g_atype571_0,
};

static const long offsets571 [] =
{
+ @CHROFF(0,0),
};

extern const char *names572[];
static const uint32 types572 [] =
{
SK_BOOL,
};

static const uint16 attr_flags572 [] =
{0,};

static const EIF_TYPE_INDEX g_atype572_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes572 [] = {
g_atype572_0,
};

static const long offsets572 [] =
{
+ @CHROFF(0,0),
};

extern const char *names573[];
static const uint32 types573 [] =
{
SK_BOOL,
};

static const uint16 attr_flags573 [] =
{0,};

static const EIF_TYPE_INDEX g_atype573_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes573 [] = {
g_atype573_0,
};

static const long offsets573 [] =
{
+ @CHROFF(0,0),
};

extern const char *names574[];
static const uint32 types574 [] =
{
SK_BOOL,
};

static const uint16 attr_flags574 [] =
{0,};

static const EIF_TYPE_INDEX g_atype574_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes574 [] = {
g_atype574_0,
};

static const long offsets574 [] =
{
+ @CHROFF(0,0),
};

extern const char *names575[];
static const uint32 types575 [] =
{
SK_BOOL,
};

static const uint16 attr_flags575 [] =
{0,};

static const EIF_TYPE_INDEX g_atype575_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes575 [] = {
g_atype575_0,
};

static const long offsets575 [] =
{
+ @CHROFF(0,0),
};

extern const char *names576[];
static const uint32 types576 [] =
{
SK_BOOL,
};

static const uint16 attr_flags576 [] =
{0,};

static const EIF_TYPE_INDEX g_atype576_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes576 [] = {
g_atype576_0,
};

static const long offsets576 [] =
{
+ @CHROFF(0,0),
};

extern const char *names577[];
static const uint32 types577 [] =
{
SK_BOOL,
};

static const uint16 attr_flags577 [] =
{0,};

static const EIF_TYPE_INDEX g_atype577_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes577 [] = {
g_atype577_0,
};

static const long offsets577 [] =
{
+ @CHROFF(0,0),
};

extern const char *names578[];
static const uint32 types578 [] =
{
SK_BOOL,
};

static const uint16 attr_flags578 [] =
{0,};

static const EIF_TYPE_INDEX g_atype578_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes578 [] = {
g_atype578_0,
};

static const long offsets578 [] =
{
+ @CHROFF(0,0),
};

extern const char *names579[];
static const uint32 types579 [] =
{
SK_BOOL,
};

static const uint16 attr_flags579 [] =
{0,};

static const EIF_TYPE_INDEX g_atype579_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes579 [] = {
g_atype579_0,
};

static const long offsets579 [] =
{
+ @CHROFF(0,0),
};

extern const char *names580[];
static const uint32 types580 [] =
{
SK_BOOL,
};

static const uint16 attr_flags580 [] =
{0,};

static const EIF_TYPE_INDEX g_atype580_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes580 [] = {
g_atype580_0,
};

static const long offsets580 [] =
{
+ @CHROFF(0,0),
};

extern const char *names581[];
static const uint32 types581 [] =
{
SK_BOOL,
};

static const uint16 attr_flags581 [] =
{0,};

static const EIF_TYPE_INDEX g_atype581_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes581 [] = {
g_atype581_0,
};

static const long offsets581 [] =
{
+ @CHROFF(0,0),
};

extern const char *names582[];
static const uint32 types582 [] =
{
SK_BOOL,
};

static const uint16 attr_flags582 [] =
{0,};

static const EIF_TYPE_INDEX g_atype582_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes582 [] = {
g_atype582_0,
};

static const long offsets582 [] =
{
+ @CHROFF(0,0),
};

extern const char *names583[];
static const uint32 types583 [] =
{
SK_BOOL,
};

static const uint16 attr_flags583 [] =
{0,};

static const EIF_TYPE_INDEX g_atype583_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes583 [] = {
g_atype583_0,
};

static const long offsets583 [] =
{
+ @CHROFF(0,0),
};

extern const char *names584[];
static const uint32 types584 [] =
{
SK_BOOL,
};

static const uint16 attr_flags584 [] =
{0,};

static const EIF_TYPE_INDEX g_atype584_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes584 [] = {
g_atype584_0,
};

static const long offsets584 [] =
{
+ @CHROFF(0,0),
};

extern const char *names585[];
static const uint32 types585 [] =
{
SK_BOOL,
};

static const uint16 attr_flags585 [] =
{0,};

static const EIF_TYPE_INDEX g_atype585_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes585 [] = {
g_atype585_0,
};

static const long offsets585 [] =
{
+ @CHROFF(0,0),
};

extern const char *names586[];
static const uint32 types586 [] =
{
SK_BOOL,
};

static const uint16 attr_flags586 [] =
{0,};

static const EIF_TYPE_INDEX g_atype586_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes586 [] = {
g_atype586_0,
};

static const long offsets586 [] =
{
+ @CHROFF(0,0),
};

extern const char *names587[];
static const uint32 types587 [] =
{
SK_BOOL,
};

static const uint16 attr_flags587 [] =
{0,};

static const EIF_TYPE_INDEX g_atype587_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes587 [] = {
g_atype587_0,
};

static const long offsets587 [] =
{
+ @CHROFF(0,0),
};

extern const char *names588[];
static const uint32 types588 [] =
{
SK_BOOL,
};

static const uint16 attr_flags588 [] =
{0,};

static const EIF_TYPE_INDEX g_atype588_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes588 [] = {
g_atype588_0,
};

static const long offsets588 [] =
{
+ @CHROFF(0,0),
};

extern const char *names589[];
static const uint32 types589 [] =
{
SK_BOOL,
};

static const uint16 attr_flags589 [] =
{0,};

static const EIF_TYPE_INDEX g_atype589_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes589 [] = {
g_atype589_0,
};

static const long offsets589 [] =
{
+ @CHROFF(0,0),
};

extern const char *names590[];
static const uint32 types590 [] =
{
SK_BOOL,
};

static const uint16 attr_flags590 [] =
{0,};

static const EIF_TYPE_INDEX g_atype590_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes590 [] = {
g_atype590_0,
};

static const long offsets590 [] =
{
+ @CHROFF(0,0),
};

extern const char *names591[];
static const uint32 types591 [] =
{
SK_BOOL,
};

static const uint16 attr_flags591 [] =
{0,};

static const EIF_TYPE_INDEX g_atype591_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes591 [] = {
g_atype591_0,
};

static const long offsets591 [] =
{
+ @CHROFF(0,0),
};

extern const char *names592[];
static const uint32 types592 [] =
{
SK_BOOL,
};

static const uint16 attr_flags592 [] =
{0,};

static const EIF_TYPE_INDEX g_atype592_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes592 [] = {
g_atype592_0,
};

static const long offsets592 [] =
{
+ @CHROFF(0,0),
};

extern const char *names593[];
static const uint32 types593 [] =
{
SK_BOOL,
};

static const uint16 attr_flags593 [] =
{0,};

static const EIF_TYPE_INDEX g_atype593_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes593 [] = {
g_atype593_0,
};

static const long offsets593 [] =
{
+ @CHROFF(0,0),
};

extern const char *names594[];
static const uint32 types594 [] =
{
SK_BOOL,
};

static const uint16 attr_flags594 [] =
{0,};

static const EIF_TYPE_INDEX g_atype594_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes594 [] = {
g_atype594_0,
};

static const long offsets594 [] =
{
+ @CHROFF(0,0),
};

extern const char *names595[];
static const uint32 types595 [] =
{
SK_BOOL,
};

static const uint16 attr_flags595 [] =
{0,};

static const EIF_TYPE_INDEX g_atype595_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes595 [] = {
g_atype595_0,
};

static const long offsets595 [] =
{
+ @CHROFF(0,0),
};

extern const char *names596[];
static const uint32 types596 [] =
{
SK_BOOL,
};

static const uint16 attr_flags596 [] =
{0,};

static const EIF_TYPE_INDEX g_atype596_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes596 [] = {
g_atype596_0,
};

static const long offsets596 [] =
{
+ @CHROFF(0,0),
};

extern const char *names597[];
static const uint32 types597 [] =
{
SK_BOOL,
};

static const uint16 attr_flags597 [] =
{0,};

static const EIF_TYPE_INDEX g_atype597_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes597 [] = {
g_atype597_0,
};

static const long offsets597 [] =
{
+ @CHROFF(0,0),
};

extern const char *names598[];
static const uint32 types598 [] =
{
SK_BOOL,
};

static const uint16 attr_flags598 [] =
{0,};

static const EIF_TYPE_INDEX g_atype598_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes598 [] = {
g_atype598_0,
};

static const long offsets598 [] =
{
+ @CHROFF(0,0),
};

extern const char *names599[];
static const uint32 types599 [] =
{
SK_BOOL,
};

static const uint16 attr_flags599 [] =
{0,};

static const EIF_TYPE_INDEX g_atype599_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes599 [] = {
g_atype599_0,
};

static const long offsets599 [] =
{
+ @CHROFF(0,0),
};

extern const char *names600[];
static const uint32 types600 [] =
{
SK_BOOL,
};

static const uint16 attr_flags600 [] =
{0,};

static const EIF_TYPE_INDEX g_atype600_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes600 [] = {
g_atype600_0,
};

static const long offsets600 [] =
{
+ @CHROFF(0,0),
};

extern const char *names601[];
static const uint32 types601 [] =
{
SK_BOOL,
};

static const uint16 attr_flags601 [] =
{0,};

static const EIF_TYPE_INDEX g_atype601_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes601 [] = {
g_atype601_0,
};

static const long offsets601 [] =
{
+ @CHROFF(0,0),
};

extern const char *names602[];
static const uint32 types602 [] =
{
SK_BOOL,
};

static const uint16 attr_flags602 [] =
{0,};

static const EIF_TYPE_INDEX g_atype602_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes602 [] = {
g_atype602_0,
};

static const long offsets602 [] =
{
+ @CHROFF(0,0),
};

extern const char *names603[];
static const uint32 types603 [] =
{
SK_BOOL,
};

static const uint16 attr_flags603 [] =
{0,};

static const EIF_TYPE_INDEX g_atype603_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes603 [] = {
g_atype603_0,
};

static const long offsets603 [] =
{
+ @CHROFF(0,0),
};

extern const char *names604[];
static const uint32 types604 [] =
{
SK_BOOL,
};

static const uint16 attr_flags604 [] =
{0,};

static const EIF_TYPE_INDEX g_atype604_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes604 [] = {
g_atype604_0,
};

static const long offsets604 [] =
{
+ @CHROFF(0,0),
};

extern const char *names605[];
static const uint32 types605 [] =
{
SK_BOOL,
};

static const uint16 attr_flags605 [] =
{0,};

static const EIF_TYPE_INDEX g_atype605_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes605 [] = {
g_atype605_0,
};

static const long offsets605 [] =
{
+ @CHROFF(0,0),
};

extern const char *names606[];
static const uint32 types606 [] =
{
SK_BOOL,
};

static const uint16 attr_flags606 [] =
{0,};

static const EIF_TYPE_INDEX g_atype606_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes606 [] = {
g_atype606_0,
};

static const long offsets606 [] =
{
+ @CHROFF(0,0),
};

extern const char *names607[];
static const uint32 types607 [] =
{
SK_BOOL,
};

static const uint16 attr_flags607 [] =
{0,};

static const EIF_TYPE_INDEX g_atype607_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes607 [] = {
g_atype607_0,
};

static const long offsets607 [] =
{
+ @CHROFF(0,0),
};

extern const char *names608[];
static const uint32 types608 [] =
{
SK_BOOL,
};

static const uint16 attr_flags608 [] =
{0,};

static const EIF_TYPE_INDEX g_atype608_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes608 [] = {
g_atype608_0,
};

static const long offsets608 [] =
{
+ @CHROFF(0,0),
};

extern const char *names609[];
static const uint32 types609 [] =
{
SK_BOOL,
};

static const uint16 attr_flags609 [] =
{0,};

static const EIF_TYPE_INDEX g_atype609_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes609 [] = {
g_atype609_0,
};

static const long offsets609 [] =
{
+ @CHROFF(0,0),
};

extern const char *names610[];
static const uint32 types610 [] =
{
SK_BOOL,
};

static const uint16 attr_flags610 [] =
{0,};

static const EIF_TYPE_INDEX g_atype610_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes610 [] = {
g_atype610_0,
};

static const long offsets610 [] =
{
+ @CHROFF(0,0),
};

extern const char *names611[];
static const uint32 types611 [] =
{
SK_BOOL,
};

static const uint16 attr_flags611 [] =
{0,};

static const EIF_TYPE_INDEX g_atype611_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes611 [] = {
g_atype611_0,
};

static const long offsets611 [] =
{
+ @CHROFF(0,0),
};

extern const char *names612[];
static const uint32 types612 [] =
{
SK_BOOL,
};

static const uint16 attr_flags612 [] =
{0,};

static const EIF_TYPE_INDEX g_atype612_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes612 [] = {
g_atype612_0,
};

static const long offsets612 [] =
{
+ @CHROFF(0,0),
};

extern const char *names613[];
static const uint32 types613 [] =
{
SK_BOOL,
};

static const uint16 attr_flags613 [] =
{0,};

static const EIF_TYPE_INDEX g_atype613_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes613 [] = {
g_atype613_0,
};

static const long offsets613 [] =
{
+ @CHROFF(0,0),
};

extern const char *names614[];
static const uint32 types614 [] =
{
SK_BOOL,
};

static const uint16 attr_flags614 [] =
{0,};

static const EIF_TYPE_INDEX g_atype614_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes614 [] = {
g_atype614_0,
};

static const long offsets614 [] =
{
+ @CHROFF(0,0),
};

extern const char *names615[];
static const uint32 types615 [] =
{
SK_BOOL,
};

static const uint16 attr_flags615 [] =
{0,};

static const EIF_TYPE_INDEX g_atype615_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes615 [] = {
g_atype615_0,
};

static const long offsets615 [] =
{
+ @CHROFF(0,0),
};

extern const char *names616[];
static const uint32 types616 [] =
{
SK_BOOL,
};

static const uint16 attr_flags616 [] =
{0,};

static const EIF_TYPE_INDEX g_atype616_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes616 [] = {
g_atype616_0,
};

static const long offsets616 [] =
{
+ @CHROFF(0,0),
};

extern const char *names617[];
static const uint32 types617 [] =
{
SK_BOOL,
};

static const uint16 attr_flags617 [] =
{0,};

static const EIF_TYPE_INDEX g_atype617_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes617 [] = {
g_atype617_0,
};

static const long offsets617 [] =
{
+ @CHROFF(0,0),
};

extern const char *names618[];
static const uint32 types618 [] =
{
SK_BOOL,
};

static const uint16 attr_flags618 [] =
{0,};

static const EIF_TYPE_INDEX g_atype618_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes618 [] = {
g_atype618_0,
};

static const long offsets618 [] =
{
+ @CHROFF(0,0),
};

extern const char *names619[];
static const uint32 types619 [] =
{
SK_BOOL,
};

static const uint16 attr_flags619 [] =
{0,};

static const EIF_TYPE_INDEX g_atype619_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes619 [] = {
g_atype619_0,
};

static const long offsets619 [] =
{
+ @CHROFF(0,0),
};

extern const char *names620[];
static const uint32 types620 [] =
{
SK_BOOL,
};

static const uint16 attr_flags620 [] =
{0,};

static const EIF_TYPE_INDEX g_atype620_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes620 [] = {
g_atype620_0,
};

static const long offsets620 [] =
{
+ @CHROFF(0,0),
};

extern const char *names621[];
static const uint32 types621 [] =
{
SK_BOOL,
};

static const uint16 attr_flags621 [] =
{0,};

static const EIF_TYPE_INDEX g_atype621_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes621 [] = {
g_atype621_0,
};

static const long offsets621 [] =
{
+ @CHROFF(0,0),
};

extern const char *names622[];
static const uint32 types622 [] =
{
SK_BOOL,
};

static const uint16 attr_flags622 [] =
{0,};

static const EIF_TYPE_INDEX g_atype622_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes622 [] = {
g_atype622_0,
};

static const long offsets622 [] =
{
+ @CHROFF(0,0),
};

extern const char *names623[];
static const uint32 types623 [] =
{
SK_BOOL,
};

static const uint16 attr_flags623 [] =
{0,};

static const EIF_TYPE_INDEX g_atype623_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes623 [] = {
g_atype623_0,
};

static const long offsets623 [] =
{
+ @CHROFF(0,0),
};

extern const char *names624[];
static const uint32 types624 [] =
{
SK_BOOL,
};

static const uint16 attr_flags624 [] =
{0,};

static const EIF_TYPE_INDEX g_atype624_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes624 [] = {
g_atype624_0,
};

static const long offsets624 [] =
{
+ @CHROFF(0,0),
};

extern const char *names625[];
static const uint32 types625 [] =
{
SK_BOOL,
};

static const uint16 attr_flags625 [] =
{0,};

static const EIF_TYPE_INDEX g_atype625_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes625 [] = {
g_atype625_0,
};

static const long offsets625 [] =
{
+ @CHROFF(0,0),
};

extern const char *names626[];
static const uint32 types626 [] =
{
SK_BOOL,
};

static const uint16 attr_flags626 [] =
{0,};

static const EIF_TYPE_INDEX g_atype626_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes626 [] = {
g_atype626_0,
};

static const long offsets626 [] =
{
+ @CHROFF(0,0),
};

extern const char *names627[];
static const uint32 types627 [] =
{
SK_BOOL,
};

static const uint16 attr_flags627 [] =
{0,};

static const EIF_TYPE_INDEX g_atype627_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes627 [] = {
g_atype627_0,
};

static const long offsets627 [] =
{
+ @CHROFF(0,0),
};

extern const char *names628[];
static const uint32 types628 [] =
{
SK_BOOL,
};

static const uint16 attr_flags628 [] =
{0,};

static const EIF_TYPE_INDEX g_atype628_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes628 [] = {
g_atype628_0,
};

static const long offsets628 [] =
{
+ @CHROFF(0,0),
};

extern const char *names629[];
static const uint32 types629 [] =
{
SK_BOOL,
};

static const uint16 attr_flags629 [] =
{0,};

static const EIF_TYPE_INDEX g_atype629_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes629 [] = {
g_atype629_0,
};

static const long offsets629 [] =
{
+ @CHROFF(0,0),
};

extern const char *names630[];
static const uint32 types630 [] =
{
SK_BOOL,
};

static const uint16 attr_flags630 [] =
{0,};

static const EIF_TYPE_INDEX g_atype630_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes630 [] = {
g_atype630_0,
};

static const long offsets630 [] =
{
+ @CHROFF(0,0),
};

extern const char *names631[];
static const uint32 types631 [] =
{
SK_BOOL,
};

static const uint16 attr_flags631 [] =
{0,};

static const EIF_TYPE_INDEX g_atype631_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes631 [] = {
g_atype631_0,
};

static const long offsets631 [] =
{
+ @CHROFF(0,0),
};

extern const char *names632[];
static const uint32 types632 [] =
{
SK_BOOL,
};

static const uint16 attr_flags632 [] =
{0,};

static const EIF_TYPE_INDEX g_atype632_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes632 [] = {
g_atype632_0,
};

static const long offsets632 [] =
{
+ @CHROFF(0,0),
};

extern const char *names633[];
static const uint32 types633 [] =
{
SK_BOOL,
};

static const uint16 attr_flags633 [] =
{0,};

static const EIF_TYPE_INDEX g_atype633_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes633 [] = {
g_atype633_0,
};

static const long offsets633 [] =
{
+ @CHROFF(0,0),
};

extern const char *names634[];
static const uint32 types634 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags634 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype634_0 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype634_1 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes634 [] = {
g_atype634_0,
g_atype634_1,
};

static const long offsets634 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names635[];
static const uint32 types635 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags635 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype635_0 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype635_1 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes635 [] = {
g_atype635_0,
g_atype635_1,
};

static const long offsets635 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names636[];
static const uint32 types636 [] =
{
SK_BOOL,
};

static const uint16 attr_flags636 [] =
{0,};

static const EIF_TYPE_INDEX g_atype636_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes636 [] = {
g_atype636_0,
};

static const long offsets636 [] =
{
+ @CHROFF(0,0),
};

extern const char *names637[];
static const uint32 types637 [] =
{
SK_BOOL,
};

static const uint16 attr_flags637 [] =
{0,};

static const EIF_TYPE_INDEX g_atype637_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes637 [] = {
g_atype637_0,
};

static const long offsets637 [] =
{
+ @CHROFF(0,0),
};

extern const char *names638[];
static const uint32 types638 [] =
{
SK_BOOL,
};

static const uint16 attr_flags638 [] =
{0,};

static const EIF_TYPE_INDEX g_atype638_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes638 [] = {
g_atype638_0,
};

static const long offsets638 [] =
{
+ @CHROFF(0,0),
};

extern const char *names639[];
static const uint32 types639 [] =
{
SK_BOOL,
};

static const uint16 attr_flags639 [] =
{0,};

static const EIF_TYPE_INDEX g_atype639_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes639 [] = {
g_atype639_0,
};

static const long offsets639 [] =
{
+ @CHROFF(0,0),
};

extern const char *names640[];
static const uint32 types640 [] =
{
SK_BOOL,
};

static const uint16 attr_flags640 [] =
{0,};

static const EIF_TYPE_INDEX g_atype640_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes640 [] = {
g_atype640_0,
};

static const long offsets640 [] =
{
+ @CHROFF(0,0),
};

extern const char *names641[];
static const uint32 types641 [] =
{
SK_BOOL,
};

static const uint16 attr_flags641 [] =
{0,};

static const EIF_TYPE_INDEX g_atype641_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes641 [] = {
g_atype641_0,
};

static const long offsets641 [] =
{
+ @CHROFF(0,0),
};

extern const char *names642[];
static const uint32 types642 [] =
{
SK_BOOL,
};

static const uint16 attr_flags642 [] =
{0,};

static const EIF_TYPE_INDEX g_atype642_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes642 [] = {
g_atype642_0,
};

static const long offsets642 [] =
{
+ @CHROFF(0,0),
};

extern const char *names643[];
static const uint32 types643 [] =
{
SK_BOOL,
};

static const uint16 attr_flags643 [] =
{0,};

static const EIF_TYPE_INDEX g_atype643_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes643 [] = {
g_atype643_0,
};

static const long offsets643 [] =
{
+ @CHROFF(0,0),
};

extern const char *names644[];
static const uint32 types644 [] =
{
SK_BOOL,
};

static const uint16 attr_flags644 [] =
{0,};

static const EIF_TYPE_INDEX g_atype644_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes644 [] = {
g_atype644_0,
};

static const long offsets644 [] =
{
+ @CHROFF(0,0),
};

extern const char *names645[];
static const uint32 types645 [] =
{
SK_BOOL,
};

static const uint16 attr_flags645 [] =
{0,};

static const EIF_TYPE_INDEX g_atype645_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes645 [] = {
g_atype645_0,
};

static const long offsets645 [] =
{
+ @CHROFF(0,0),
};

extern const char *names646[];
static const uint32 types646 [] =
{
SK_BOOL,
};

static const uint16 attr_flags646 [] =
{0,};

static const EIF_TYPE_INDEX g_atype646_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes646 [] = {
g_atype646_0,
};

static const long offsets646 [] =
{
+ @CHROFF(0,0),
};

extern const char *names647[];
static const uint32 types647 [] =
{
SK_BOOL,
};

static const uint16 attr_flags647 [] =
{0,};

static const EIF_TYPE_INDEX g_atype647_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes647 [] = {
g_atype647_0,
};

static const long offsets647 [] =
{
+ @CHROFF(0,0),
};

extern const char *names648[];
static const uint32 types648 [] =
{
SK_BOOL,
};

static const uint16 attr_flags648 [] =
{0,};

static const EIF_TYPE_INDEX g_atype648_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes648 [] = {
g_atype648_0,
};

static const long offsets648 [] =
{
+ @CHROFF(0,0),
};

extern const char *names649[];
static const uint32 types649 [] =
{
SK_BOOL,
};

static const uint16 attr_flags649 [] =
{0,};

static const EIF_TYPE_INDEX g_atype649_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes649 [] = {
g_atype649_0,
};

static const long offsets649 [] =
{
+ @CHROFF(0,0),
};

extern const char *names650[];
static const uint32 types650 [] =
{
SK_BOOL,
};

static const uint16 attr_flags650 [] =
{0,};

static const EIF_TYPE_INDEX g_atype650_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes650 [] = {
g_atype650_0,
};

static const long offsets650 [] =
{
+ @CHROFF(0,0),
};

extern const char *names651[];
static const uint32 types651 [] =
{
SK_BOOL,
};

static const uint16 attr_flags651 [] =
{0,};

static const EIF_TYPE_INDEX g_atype651_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes651 [] = {
g_atype651_0,
};

static const long offsets651 [] =
{
+ @CHROFF(0,0),
};

extern const char *names652[];
static const uint32 types652 [] =
{
SK_BOOL,
};

static const uint16 attr_flags652 [] =
{0,};

static const EIF_TYPE_INDEX g_atype652_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes652 [] = {
g_atype652_0,
};

static const long offsets652 [] =
{
+ @CHROFF(0,0),
};

extern const char *names653[];
static const uint32 types653 [] =
{
SK_BOOL,
};

static const uint16 attr_flags653 [] =
{0,};

static const EIF_TYPE_INDEX g_atype653_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes653 [] = {
g_atype653_0,
};

static const long offsets653 [] =
{
+ @CHROFF(0,0),
};

extern const char *names654[];
static const uint32 types654 [] =
{
SK_BOOL,
};

static const uint16 attr_flags654 [] =
{0,};

static const EIF_TYPE_INDEX g_atype654_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes654 [] = {
g_atype654_0,
};

static const long offsets654 [] =
{
+ @CHROFF(0,0),
};

extern const char *names655[];
static const uint32 types655 [] =
{
SK_BOOL,
};

static const uint16 attr_flags655 [] =
{0,};

static const EIF_TYPE_INDEX g_atype655_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes655 [] = {
g_atype655_0,
};

static const long offsets655 [] =
{
+ @CHROFF(0,0),
};

extern const char *names656[];
static const uint32 types656 [] =
{
SK_BOOL,
};

static const uint16 attr_flags656 [] =
{0,};

static const EIF_TYPE_INDEX g_atype656_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes656 [] = {
g_atype656_0,
};

static const long offsets656 [] =
{
+ @CHROFF(0,0),
};

extern const char *names657[];
static const uint32 types657 [] =
{
SK_BOOL,
};

static const uint16 attr_flags657 [] =
{0,};

static const EIF_TYPE_INDEX g_atype657_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes657 [] = {
g_atype657_0,
};

static const long offsets657 [] =
{
+ @CHROFF(0,0),
};

extern const char *names658[];
static const uint32 types658 [] =
{
SK_BOOL,
};

static const uint16 attr_flags658 [] =
{0,};

static const EIF_TYPE_INDEX g_atype658_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes658 [] = {
g_atype658_0,
};

static const long offsets658 [] =
{
+ @CHROFF(0,0),
};

extern const char *names659[];
static const uint32 types659 [] =
{
SK_BOOL,
};

static const uint16 attr_flags659 [] =
{0,};

static const EIF_TYPE_INDEX g_atype659_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes659 [] = {
g_atype659_0,
};

static const long offsets659 [] =
{
+ @CHROFF(0,0),
};

extern const char *names660[];
static const uint32 types660 [] =
{
SK_BOOL,
};

static const uint16 attr_flags660 [] =
{0,};

static const EIF_TYPE_INDEX g_atype660_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes660 [] = {
g_atype660_0,
};

static const long offsets660 [] =
{
+ @CHROFF(0,0),
};

extern const char *names661[];
static const uint32 types661 [] =
{
SK_BOOL,
};

static const uint16 attr_flags661 [] =
{0,};

static const EIF_TYPE_INDEX g_atype661_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes661 [] = {
g_atype661_0,
};

static const long offsets661 [] =
{
+ @CHROFF(0,0),
};

extern const char *names662[];
static const uint32 types662 [] =
{
SK_BOOL,
};

static const uint16 attr_flags662 [] =
{0,};

static const EIF_TYPE_INDEX g_atype662_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes662 [] = {
g_atype662_0,
};

static const long offsets662 [] =
{
+ @CHROFF(0,0),
};

extern const char *names663[];
static const uint32 types663 [] =
{
SK_BOOL,
};

static const uint16 attr_flags663 [] =
{0,};

static const EIF_TYPE_INDEX g_atype663_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes663 [] = {
g_atype663_0,
};

static const long offsets663 [] =
{
+ @CHROFF(0,0),
};

extern const char *names664[];
static const uint32 types664 [] =
{
SK_BOOL,
};

static const uint16 attr_flags664 [] =
{0,};

static const EIF_TYPE_INDEX g_atype664_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes664 [] = {
g_atype664_0,
};

static const long offsets664 [] =
{
+ @CHROFF(0,0),
};

extern const char *names665[];
static const uint32 types665 [] =
{
SK_BOOL,
};

static const uint16 attr_flags665 [] =
{0,};

static const EIF_TYPE_INDEX g_atype665_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes665 [] = {
g_atype665_0,
};

static const long offsets665 [] =
{
+ @CHROFF(0,0),
};

extern const char *names666[];
static const uint32 types666 [] =
{
SK_BOOL,
};

static const uint16 attr_flags666 [] =
{0,};

static const EIF_TYPE_INDEX g_atype666_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes666 [] = {
g_atype666_0,
};

static const long offsets666 [] =
{
+ @CHROFF(0,0),
};

extern const char *names667[];
static const uint32 types667 [] =
{
SK_BOOL,
};

static const uint16 attr_flags667 [] =
{0,};

static const EIF_TYPE_INDEX g_atype667_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes667 [] = {
g_atype667_0,
};

static const long offsets667 [] =
{
+ @CHROFF(0,0),
};

extern const char *names668[];
static const uint32 types668 [] =
{
SK_BOOL,
};

static const uint16 attr_flags668 [] =
{0,};

static const EIF_TYPE_INDEX g_atype668_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes668 [] = {
g_atype668_0,
};

static const long offsets668 [] =
{
+ @CHROFF(0,0),
};

extern const char *names669[];
static const uint32 types669 [] =
{
SK_BOOL,
};

static const uint16 attr_flags669 [] =
{0,};

static const EIF_TYPE_INDEX g_atype669_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes669 [] = {
g_atype669_0,
};

static const long offsets669 [] =
{
+ @CHROFF(0,0),
};

extern const char *names670[];
static const uint32 types670 [] =
{
SK_BOOL,
};

static const uint16 attr_flags670 [] =
{0,};

static const EIF_TYPE_INDEX g_atype670_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes670 [] = {
g_atype670_0,
};

static const long offsets670 [] =
{
+ @CHROFF(0,0),
};

extern const char *names671[];
static const uint32 types671 [] =
{
SK_BOOL,
};

static const uint16 attr_flags671 [] =
{0,};

static const EIF_TYPE_INDEX g_atype671_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes671 [] = {
g_atype671_0,
};

static const long offsets671 [] =
{
+ @CHROFF(0,0),
};

extern const char *names672[];
static const uint32 types672 [] =
{
SK_BOOL,
};

static const uint16 attr_flags672 [] =
{0,};

static const EIF_TYPE_INDEX g_atype672_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes672 [] = {
g_atype672_0,
};

static const long offsets672 [] =
{
+ @CHROFF(0,0),
};

extern const char *names673[];
static const uint32 types673 [] =
{
SK_BOOL,
};

static const uint16 attr_flags673 [] =
{0,};

static const EIF_TYPE_INDEX g_atype673_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes673 [] = {
g_atype673_0,
};

static const long offsets673 [] =
{
+ @CHROFF(0,0),
};

extern const char *names674[];
static const uint32 types674 [] =
{
SK_BOOL,
};

static const uint16 attr_flags674 [] =
{0,};

static const EIF_TYPE_INDEX g_atype674_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes674 [] = {
g_atype674_0,
};

static const long offsets674 [] =
{
+ @CHROFF(0,0),
};

extern const char *names675[];
static const uint32 types675 [] =
{
SK_BOOL,
};

static const uint16 attr_flags675 [] =
{0,};

static const EIF_TYPE_INDEX g_atype675_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes675 [] = {
g_atype675_0,
};

static const long offsets675 [] =
{
+ @CHROFF(0,0),
};

extern const char *names676[];
static const uint32 types676 [] =
{
SK_BOOL,
};

static const uint16 attr_flags676 [] =
{0,};

static const EIF_TYPE_INDEX g_atype676_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes676 [] = {
g_atype676_0,
};

static const long offsets676 [] =
{
+ @CHROFF(0,0),
};

extern const char *names677[];
static const uint32 types677 [] =
{
SK_BOOL,
};

static const uint16 attr_flags677 [] =
{0,};

static const EIF_TYPE_INDEX g_atype677_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes677 [] = {
g_atype677_0,
};

static const long offsets677 [] =
{
+ @CHROFF(0,0),
};

extern const char *names678[];
static const uint32 types678 [] =
{
SK_BOOL,
};

static const uint16 attr_flags678 [] =
{0,};

static const EIF_TYPE_INDEX g_atype678_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes678 [] = {
g_atype678_0,
};

static const long offsets678 [] =
{
+ @CHROFF(0,0),
};

extern const char *names679[];
static const uint32 types679 [] =
{
SK_BOOL,
};

static const uint16 attr_flags679 [] =
{0,};

static const EIF_TYPE_INDEX g_atype679_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes679 [] = {
g_atype679_0,
};

static const long offsets679 [] =
{
+ @CHROFF(0,0),
};

extern const char *names680[];
static const uint32 types680 [] =
{
SK_BOOL,
};

static const uint16 attr_flags680 [] =
{0,};

static const EIF_TYPE_INDEX g_atype680_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes680 [] = {
g_atype680_0,
};

static const long offsets680 [] =
{
+ @CHROFF(0,0),
};

extern const char *names681[];
static const uint32 types681 [] =
{
SK_BOOL,
};

static const uint16 attr_flags681 [] =
{0,};

static const EIF_TYPE_INDEX g_atype681_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes681 [] = {
g_atype681_0,
};

static const long offsets681 [] =
{
+ @CHROFF(0,0),
};

extern const char *names682[];
static const uint32 types682 [] =
{
SK_BOOL,
};

static const uint16 attr_flags682 [] =
{0,};

static const EIF_TYPE_INDEX g_atype682_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes682 [] = {
g_atype682_0,
};

static const long offsets682 [] =
{
+ @CHROFF(0,0),
};

extern const char *names683[];
static const uint32 types683 [] =
{
SK_BOOL,
};

static const uint16 attr_flags683 [] =
{0,};

static const EIF_TYPE_INDEX g_atype683_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes683 [] = {
g_atype683_0,
};

static const long offsets683 [] =
{
+ @CHROFF(0,0),
};

extern const char *names684[];
static const uint32 types684 [] =
{
SK_BOOL,
};

static const uint16 attr_flags684 [] =
{0,};

static const EIF_TYPE_INDEX g_atype684_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes684 [] = {
g_atype684_0,
};

static const long offsets684 [] =
{
+ @CHROFF(0,0),
};

extern const char *names685[];
static const uint32 types685 [] =
{
SK_BOOL,
};

static const uint16 attr_flags685 [] =
{0,};

static const EIF_TYPE_INDEX g_atype685_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes685 [] = {
g_atype685_0,
};

static const long offsets685 [] =
{
+ @CHROFF(0,0),
};

extern const char *names686[];
static const uint32 types686 [] =
{
SK_BOOL,
};

static const uint16 attr_flags686 [] =
{0,};

static const EIF_TYPE_INDEX g_atype686_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes686 [] = {
g_atype686_0,
};

static const long offsets686 [] =
{
+ @CHROFF(0,0),
};

extern const char *names687[];
static const uint32 types687 [] =
{
SK_BOOL,
};

static const uint16 attr_flags687 [] =
{0,};

static const EIF_TYPE_INDEX g_atype687_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes687 [] = {
g_atype687_0,
};

static const long offsets687 [] =
{
+ @CHROFF(0,0),
};

extern const char *names688[];
static const uint32 types688 [] =
{
SK_BOOL,
};

static const uint16 attr_flags688 [] =
{0,};

static const EIF_TYPE_INDEX g_atype688_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes688 [] = {
g_atype688_0,
};

static const long offsets688 [] =
{
+ @CHROFF(0,0),
};

extern const char *names689[];
static const uint32 types689 [] =
{
SK_BOOL,
};

static const uint16 attr_flags689 [] =
{0,};

static const EIF_TYPE_INDEX g_atype689_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes689 [] = {
g_atype689_0,
};

static const long offsets689 [] =
{
+ @CHROFF(0,0),
};

extern const char *names690[];
static const uint32 types690 [] =
{
SK_BOOL,
};

static const uint16 attr_flags690 [] =
{0,};

static const EIF_TYPE_INDEX g_atype690_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes690 [] = {
g_atype690_0,
};

static const long offsets690 [] =
{
+ @CHROFF(0,0),
};

extern const char *names691[];
static const uint32 types691 [] =
{
SK_BOOL,
};

static const uint16 attr_flags691 [] =
{0,};

static const EIF_TYPE_INDEX g_atype691_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes691 [] = {
g_atype691_0,
};

static const long offsets691 [] =
{
+ @CHROFF(0,0),
};

extern const char *names692[];
static const uint32 types692 [] =
{
SK_BOOL,
};

static const uint16 attr_flags692 [] =
{0,};

static const EIF_TYPE_INDEX g_atype692_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes692 [] = {
g_atype692_0,
};

static const long offsets692 [] =
{
+ @CHROFF(0,0),
};

extern const char *names693[];
static const uint32 types693 [] =
{
SK_BOOL,
};

static const uint16 attr_flags693 [] =
{0,};

static const EIF_TYPE_INDEX g_atype693_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes693 [] = {
g_atype693_0,
};

static const long offsets693 [] =
{
+ @CHROFF(0,0),
};

extern const char *names694[];
static const uint32 types694 [] =
{
SK_BOOL,
};

static const uint16 attr_flags694 [] =
{0,};

static const EIF_TYPE_INDEX g_atype694_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes694 [] = {
g_atype694_0,
};

static const long offsets694 [] =
{
+ @CHROFF(0,0),
};

extern const char *names695[];
static const uint32 types695 [] =
{
SK_BOOL,
};

static const uint16 attr_flags695 [] =
{0,};

static const EIF_TYPE_INDEX g_atype695_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes695 [] = {
g_atype695_0,
};

static const long offsets695 [] =
{
+ @CHROFF(0,0),
};

extern const char *names696[];
static const uint32 types696 [] =
{
SK_BOOL,
};

static const uint16 attr_flags696 [] =
{0,};

static const EIF_TYPE_INDEX g_atype696_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes696 [] = {
g_atype696_0,
};

static const long offsets696 [] =
{
+ @CHROFF(0,0),
};

extern const char *names697[];
static const uint32 types697 [] =
{
SK_BOOL,
};

static const uint16 attr_flags697 [] =
{0,};

static const EIF_TYPE_INDEX g_atype697_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes697 [] = {
g_atype697_0,
};

static const long offsets697 [] =
{
+ @CHROFF(0,0),
};

extern const char *names698[];
static const uint32 types698 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags698 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype698_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_1 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_2 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_3 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_4 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_7 [] = {888,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_8 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_9 [] = {885,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_10 [] = {876,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_11 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_15 [] = {891,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_16 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_17 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_18 [] = {870,0xFFFF};
static const EIF_TYPE_INDEX g_atype698_19 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes698 [] = {
g_atype698_0,
g_atype698_1,
g_atype698_2,
g_atype698_3,
g_atype698_4,
g_atype698_5,
g_atype698_6,
g_atype698_7,
g_atype698_8,
g_atype698_9,
g_atype698_10,
g_atype698_11,
g_atype698_12,
g_atype698_13,
g_atype698_14,
g_atype698_15,
g_atype698_16,
g_atype698_17,
g_atype698_18,
g_atype698_19,
};

static const long offsets698 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @CHROFF(3,5),
+ @I16OFF(3,6,0),
+ @I16OFF(3,6,1),
+ @LNGOFF(3,6,2,0),
+ @LNGOFF(3,6,2,1),
+ @LNGOFF(3,6,2,2),
+ @LNGOFF(3,6,2,3),
+ @R32OFF(3,6,2,4,0),
+ @PTROFF(3,6,2,4,1,0),
+ @I64OFF(3,6,2,4,1,1,0),
+ @I64OFF(3,6,2,4,1,1,1),
+ @R64OFF(3,6,2,4,1,1,2,0),
};

extern const char *names699[];
static const uint32 types699 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags699 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype699_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_1 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_2 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_3 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_4 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_5 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_8 [] = {888,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_9 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_10 [] = {885,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_11 [] = {876,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_12 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_16 [] = {891,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_17 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_18 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_19 [] = {870,0xFFFF};
static const EIF_TYPE_INDEX g_atype699_20 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes699 [] = {
g_atype699_0,
g_atype699_1,
g_atype699_2,
g_atype699_3,
g_atype699_4,
g_atype699_5,
g_atype699_6,
g_atype699_7,
g_atype699_8,
g_atype699_9,
g_atype699_10,
g_atype699_11,
g_atype699_12,
g_atype699_13,
g_atype699_14,
g_atype699_15,
g_atype699_16,
g_atype699_17,
g_atype699_18,
g_atype699_19,
g_atype699_20,
};

static const long offsets699 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @I16OFF(4,6,0),
+ @I16OFF(4,6,1),
+ @LNGOFF(4,6,2,0),
+ @LNGOFF(4,6,2,1),
+ @LNGOFF(4,6,2,2),
+ @LNGOFF(4,6,2,3),
+ @R32OFF(4,6,2,4,0),
+ @PTROFF(4,6,2,4,1,0),
+ @I64OFF(4,6,2,4,1,1,0),
+ @I64OFF(4,6,2,4,1,1,1),
+ @R64OFF(4,6,2,4,1,1,2,0),
};

extern const char *names700[];
static const uint32 types700 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags700 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype700_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_1 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_2 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_3 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_4 [] = {17,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_5 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_6 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_10 [] = {888,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_11 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_12 [] = {885,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_13 [] = {876,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_14 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_18 [] = {891,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_19 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_20 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_21 [] = {870,0xFFFF};
static const EIF_TYPE_INDEX g_atype700_22 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes700 [] = {
g_atype700_0,
g_atype700_1,
g_atype700_2,
g_atype700_3,
g_atype700_4,
g_atype700_5,
g_atype700_6,
g_atype700_7,
g_atype700_8,
g_atype700_9,
g_atype700_10,
g_atype700_11,
g_atype700_12,
g_atype700_13,
g_atype700_14,
g_atype700_15,
g_atype700_16,
g_atype700_17,
g_atype700_18,
g_atype700_19,
g_atype700_20,
g_atype700_21,
g_atype700_22,
};

static const long offsets700 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names725[];
static const uint32 types725 [] =
{
SK_BOOL,
};

static const uint16 attr_flags725 [] =
{0,};

static const EIF_TYPE_INDEX g_atype725_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes725 [] = {
g_atype725_0,
};

static const long offsets725 [] =
{
+ @CHROFF(0,0),
};

extern const char *names726[];
static const uint32 types726 [] =
{
SK_BOOL,
};

static const uint16 attr_flags726 [] =
{0,};

static const EIF_TYPE_INDEX g_atype726_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes726 [] = {
g_atype726_0,
};

static const long offsets726 [] =
{
+ @CHROFF(0,0),
};

extern const char *names727[];
static const uint32 types727 [] =
{
SK_BOOL,
};

static const uint16 attr_flags727 [] =
{0,};

static const EIF_TYPE_INDEX g_atype727_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes727 [] = {
g_atype727_0,
};

static const long offsets727 [] =
{
+ @CHROFF(0,0),
};

extern const char *names728[];
static const uint32 types728 [] =
{
SK_BOOL,
};

static const uint16 attr_flags728 [] =
{0,};

static const EIF_TYPE_INDEX g_atype728_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes728 [] = {
g_atype728_0,
};

static const long offsets728 [] =
{
+ @CHROFF(0,0),
};

extern const char *names729[];
static const uint32 types729 [] =
{
SK_BOOL,
};

static const uint16 attr_flags729 [] =
{0,};

static const EIF_TYPE_INDEX g_atype729_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes729 [] = {
g_atype729_0,
};

static const long offsets729 [] =
{
+ @CHROFF(0,0),
};

extern const char *names730[];
static const uint32 types730 [] =
{
SK_BOOL,
};

static const uint16 attr_flags730 [] =
{0,};

static const EIF_TYPE_INDEX g_atype730_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes730 [] = {
g_atype730_0,
};

static const long offsets730 [] =
{
+ @CHROFF(0,0),
};

extern const char *names731[];
static const uint32 types731 [] =
{
SK_BOOL,
};

static const uint16 attr_flags731 [] =
{0,};

static const EIF_TYPE_INDEX g_atype731_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes731 [] = {
g_atype731_0,
};

static const long offsets731 [] =
{
+ @CHROFF(0,0),
};

extern const char *names732[];
static const uint32 types732 [] =
{
SK_BOOL,
};

static const uint16 attr_flags732 [] =
{0,};

static const EIF_TYPE_INDEX g_atype732_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes732 [] = {
g_atype732_0,
};

static const long offsets732 [] =
{
+ @CHROFF(0,0),
};

extern const char *names733[];
static const uint32 types733 [] =
{
SK_BOOL,
};

static const uint16 attr_flags733 [] =
{0,};

static const EIF_TYPE_INDEX g_atype733_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes733 [] = {
g_atype733_0,
};

static const long offsets733 [] =
{
+ @CHROFF(0,0),
};

extern const char *names734[];
static const uint32 types734 [] =
{
SK_BOOL,
};

static const uint16 attr_flags734 [] =
{0,};

static const EIF_TYPE_INDEX g_atype734_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes734 [] = {
g_atype734_0,
};

static const long offsets734 [] =
{
+ @CHROFF(0,0),
};

extern const char *names735[];
static const uint32 types735 [] =
{
SK_BOOL,
};

static const uint16 attr_flags735 [] =
{0,};

static const EIF_TYPE_INDEX g_atype735_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes735 [] = {
g_atype735_0,
};

static const long offsets735 [] =
{
+ @CHROFF(0,0),
};

extern const char *names736[];
static const uint32 types736 [] =
{
SK_BOOL,
};

static const uint16 attr_flags736 [] =
{0,};

static const EIF_TYPE_INDEX g_atype736_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes736 [] = {
g_atype736_0,
};

static const long offsets736 [] =
{
+ @CHROFF(0,0),
};

extern const char *names737[];
static const uint32 types737 [] =
{
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags737 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype737_0 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype737_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype737_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes737 [] = {
g_atype737_0,
g_atype737_1,
g_atype737_2,
};

static const long offsets737 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @LNGOFF(0,1,0,1),
};

extern const char *names738[];
static const uint32 types738 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags738 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype738_0 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype738_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype738_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype738_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes738 [] = {
g_atype738_0,
g_atype738_1,
g_atype738_2,
g_atype738_3,
};

static const long offsets738 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names739[];
static const uint32 types739 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags739 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype739_0 [] = {0xFF01,713,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype739_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype739_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype739_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes739 [] = {
g_atype739_0,
g_atype739_1,
g_atype739_2,
g_atype739_3,
};

static const long offsets739 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names740[];
static const uint32 types740 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags740 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype740_0 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype740_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype740_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype740_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes740 [] = {
g_atype740_0,
g_atype740_1,
g_atype740_2,
g_atype740_3,
};

static const long offsets740 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names741[];
static const uint32 types741 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags741 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype741_0 [] = {0xFF01,715,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype741_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype741_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype741_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes741 [] = {
g_atype741_0,
g_atype741_1,
g_atype741_2,
g_atype741_3,
};

static const long offsets741 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names742[];
static const uint32 types742 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags742 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype742_0 [] = {0xFF01,716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype742_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype742_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype742_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes742 [] = {
g_atype742_0,
g_atype742_1,
g_atype742_2,
g_atype742_3,
};

static const long offsets742 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names743[];
static const uint32 types743 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags743 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype743_0 [] = {0xFF01,717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype743_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype743_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype743_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes743 [] = {
g_atype743_0,
g_atype743_1,
g_atype743_2,
g_atype743_3,
};

static const long offsets743 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names744[];
static const uint32 types744 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags744 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype744_0 [] = {0xFF01,718,888,0xFFFF};
static const EIF_TYPE_INDEX g_atype744_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype744_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype744_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes744 [] = {
g_atype744_0,
g_atype744_1,
g_atype744_2,
g_atype744_3,
};

static const long offsets744 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names745[];
static const uint32 types745 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags745 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype745_0 [] = {0xFF01,719,885,0xFFFF};
static const EIF_TYPE_INDEX g_atype745_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype745_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype745_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes745 [] = {
g_atype745_0,
g_atype745_1,
g_atype745_2,
g_atype745_3,
};

static const long offsets745 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names746[];
static const uint32 types746 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags746 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype746_0 [] = {0xFF01,720,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype746_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype746_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype746_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes746 [] = {
g_atype746_0,
g_atype746_1,
g_atype746_2,
g_atype746_3,
};

static const long offsets746 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names747[];
static const uint32 types747 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags747 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype747_0 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype747_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype747_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype747_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes747 [] = {
g_atype747_0,
g_atype747_1,
g_atype747_2,
g_atype747_3,
};

static const long offsets747 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names748[];
static const uint32 types748 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags748 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype748_0 [] = {0xFF01,722,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype748_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes748 [] = {
g_atype748_0,
g_atype748_1,
g_atype748_2,
g_atype748_3,
};

static const long offsets748 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names749[];
static const uint32 types749 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags749 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype749_0 [] = {0xFF01,723,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype749_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes749 [] = {
g_atype749_0,
g_atype749_1,
g_atype749_2,
g_atype749_3,
};

static const long offsets749 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names750[];
static const uint32 types750 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags750 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype750_0 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype750_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype750_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype750_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes750 [] = {
g_atype750_0,
g_atype750_1,
g_atype750_2,
g_atype750_3,
};

static const long offsets750 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names751[];
static const uint32 types751 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags751 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype751_0 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype751_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype751_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype751_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes751 [] = {
g_atype751_0,
g_atype751_1,
g_atype751_2,
g_atype751_3,
};

static const long offsets751 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names752[];
static const uint32 types752 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags752 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype752_0 [] = {0xFF01,716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype752_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype752_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype752_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes752 [] = {
g_atype752_0,
g_atype752_1,
g_atype752_2,
g_atype752_3,
};

static const long offsets752 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names753[];
static const uint32 types753 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags753 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype753_0 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype753_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype753_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype753_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes753 [] = {
g_atype753_0,
g_atype753_1,
g_atype753_2,
g_atype753_3,
};

static const long offsets753 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names754[];
static const uint32 types754 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags754 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype754_0 [] = {0xFF01,715,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype754_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype754_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype754_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes754 [] = {
g_atype754_0,
g_atype754_1,
g_atype754_2,
g_atype754_3,
};

static const long offsets754 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names755[];
static const uint32 types755 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags755 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype755_0 [] = {0xFF01,720,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype755_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype755_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype755_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes755 [] = {
g_atype755_0,
g_atype755_1,
g_atype755_2,
g_atype755_3,
};

static const long offsets755 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names756[];
static const uint32 types756 [] =
{
SK_BOOL,
};

static const uint16 attr_flags756 [] =
{0,};

static const EIF_TYPE_INDEX g_atype756_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes756 [] = {
g_atype756_0,
};

static const long offsets756 [] =
{
+ @CHROFF(0,0),
};

extern const char *names757[];
static const uint32 types757 [] =
{
SK_BOOL,
};

static const uint16 attr_flags757 [] =
{0,};

static const EIF_TYPE_INDEX g_atype757_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes757 [] = {
g_atype757_0,
};

static const long offsets757 [] =
{
+ @CHROFF(0,0),
};

extern const char *names758[];
static const uint32 types758 [] =
{
SK_BOOL,
};

static const uint16 attr_flags758 [] =
{0,};

static const EIF_TYPE_INDEX g_atype758_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes758 [] = {
g_atype758_0,
};

static const long offsets758 [] =
{
+ @CHROFF(0,0),
};

extern const char *names759[];
static const uint32 types759 [] =
{
SK_BOOL,
};

static const uint16 attr_flags759 [] =
{0,};

static const EIF_TYPE_INDEX g_atype759_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes759 [] = {
g_atype759_0,
};

static const long offsets759 [] =
{
+ @CHROFF(0,0),
};

extern const char *names760[];
static const uint32 types760 [] =
{
SK_BOOL,
};

static const uint16 attr_flags760 [] =
{0,};

static const EIF_TYPE_INDEX g_atype760_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes760 [] = {
g_atype760_0,
};

static const long offsets760 [] =
{
+ @CHROFF(0,0),
};

extern const char *names761[];
static const uint32 types761 [] =
{
SK_BOOL,
};

static const uint16 attr_flags761 [] =
{0,};

static const EIF_TYPE_INDEX g_atype761_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes761 [] = {
g_atype761_0,
};

static const long offsets761 [] =
{
+ @CHROFF(0,0),
};

extern const char *names762[];
static const uint32 types762 [] =
{
SK_BOOL,
};

static const uint16 attr_flags762 [] =
{0,};

static const EIF_TYPE_INDEX g_atype762_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes762 [] = {
g_atype762_0,
};

static const long offsets762 [] =
{
+ @CHROFF(0,0),
};

extern const char *names763[];
static const uint32 types763 [] =
{
SK_BOOL,
};

static const uint16 attr_flags763 [] =
{0,};

static const EIF_TYPE_INDEX g_atype763_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes763 [] = {
g_atype763_0,
};

static const long offsets763 [] =
{
+ @CHROFF(0,0),
};

extern const char *names764[];
static const uint32 types764 [] =
{
SK_BOOL,
};

static const uint16 attr_flags764 [] =
{0,};

static const EIF_TYPE_INDEX g_atype764_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes764 [] = {
g_atype764_0,
};

static const long offsets764 [] =
{
+ @CHROFF(0,0),
};

extern const char *names765[];
static const uint32 types765 [] =
{
SK_BOOL,
};

static const uint16 attr_flags765 [] =
{0,};

static const EIF_TYPE_INDEX g_atype765_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes765 [] = {
g_atype765_0,
};

static const long offsets765 [] =
{
+ @CHROFF(0,0),
};

extern const char *names766[];
static const uint32 types766 [] =
{
SK_BOOL,
};

static const uint16 attr_flags766 [] =
{0,};

static const EIF_TYPE_INDEX g_atype766_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes766 [] = {
g_atype766_0,
};

static const long offsets766 [] =
{
+ @CHROFF(0,0),
};

extern const char *names767[];
static const uint32 types767 [] =
{
SK_BOOL,
};

static const uint16 attr_flags767 [] =
{0,};

static const EIF_TYPE_INDEX g_atype767_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes767 [] = {
g_atype767_0,
};

static const long offsets767 [] =
{
+ @CHROFF(0,0),
};

extern const char *names768[];
static const uint32 types768 [] =
{
SK_BOOL,
};

static const uint16 attr_flags768 [] =
{0,};

static const EIF_TYPE_INDEX g_atype768_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes768 [] = {
g_atype768_0,
};

static const long offsets768 [] =
{
+ @CHROFF(0,0),
};

extern const char *names769[];
static const uint32 types769 [] =
{
SK_BOOL,
};

static const uint16 attr_flags769 [] =
{0,};

static const EIF_TYPE_INDEX g_atype769_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes769 [] = {
g_atype769_0,
};

static const long offsets769 [] =
{
+ @CHROFF(0,0),
};

extern const char *names770[];
static const uint32 types770 [] =
{
SK_BOOL,
};

static const uint16 attr_flags770 [] =
{0,};

static const EIF_TYPE_INDEX g_atype770_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes770 [] = {
g_atype770_0,
};

static const long offsets770 [] =
{
+ @CHROFF(0,0),
};

extern const char *names771[];
static const uint32 types771 [] =
{
SK_BOOL,
};

static const uint16 attr_flags771 [] =
{0,};

static const EIF_TYPE_INDEX g_atype771_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes771 [] = {
g_atype771_0,
};

static const long offsets771 [] =
{
+ @CHROFF(0,0),
};

extern const char *names772[];
static const uint32 types772 [] =
{
SK_BOOL,
};

static const uint16 attr_flags772 [] =
{0,};

static const EIF_TYPE_INDEX g_atype772_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes772 [] = {
g_atype772_0,
};

static const long offsets772 [] =
{
+ @CHROFF(0,0),
};

extern const char *names773[];
static const uint32 types773 [] =
{
SK_BOOL,
};

static const uint16 attr_flags773 [] =
{0,};

static const EIF_TYPE_INDEX g_atype773_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes773 [] = {
g_atype773_0,
};

static const long offsets773 [] =
{
+ @CHROFF(0,0),
};

extern const char *names774[];
static const uint32 types774 [] =
{
SK_BOOL,
};

static const uint16 attr_flags774 [] =
{0,};

static const EIF_TYPE_INDEX g_atype774_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes774 [] = {
g_atype774_0,
};

static const long offsets774 [] =
{
+ @CHROFF(0,0),
};

extern const char *names775[];
static const uint32 types775 [] =
{
SK_BOOL,
};

static const uint16 attr_flags775 [] =
{0,};

static const EIF_TYPE_INDEX g_atype775_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes775 [] = {
g_atype775_0,
};

static const long offsets775 [] =
{
+ @CHROFF(0,0),
};

extern const char *names776[];
static const uint32 types776 [] =
{
SK_BOOL,
};

static const uint16 attr_flags776 [] =
{0,};

static const EIF_TYPE_INDEX g_atype776_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes776 [] = {
g_atype776_0,
};

static const long offsets776 [] =
{
+ @CHROFF(0,0),
};

extern const char *names777[];
static const uint32 types777 [] =
{
SK_BOOL,
};

static const uint16 attr_flags777 [] =
{0,};

static const EIF_TYPE_INDEX g_atype777_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes777 [] = {
g_atype777_0,
};

static const long offsets777 [] =
{
+ @CHROFF(0,0),
};

extern const char *names778[];
static const uint32 types778 [] =
{
SK_BOOL,
};

static const uint16 attr_flags778 [] =
{0,};

static const EIF_TYPE_INDEX g_atype778_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes778 [] = {
g_atype778_0,
};

static const long offsets778 [] =
{
+ @CHROFF(0,0),
};

extern const char *names779[];
static const uint32 types779 [] =
{
SK_BOOL,
};

static const uint16 attr_flags779 [] =
{0,};

static const EIF_TYPE_INDEX g_atype779_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes779 [] = {
g_atype779_0,
};

static const long offsets779 [] =
{
+ @CHROFF(0,0),
};

extern const char *names780[];
static const uint32 types780 [] =
{
SK_BOOL,
};

static const uint16 attr_flags780 [] =
{0,};

static const EIF_TYPE_INDEX g_atype780_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes780 [] = {
g_atype780_0,
};

static const long offsets780 [] =
{
+ @CHROFF(0,0),
};

extern const char *names781[];
static const uint32 types781 [] =
{
SK_BOOL,
};

static const uint16 attr_flags781 [] =
{0,};

static const EIF_TYPE_INDEX g_atype781_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes781 [] = {
g_atype781_0,
};

static const long offsets781 [] =
{
+ @CHROFF(0,0),
};

extern const char *names782[];
static const uint32 types782 [] =
{
SK_BOOL,
};

static const uint16 attr_flags782 [] =
{0,};

static const EIF_TYPE_INDEX g_atype782_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes782 [] = {
g_atype782_0,
};

static const long offsets782 [] =
{
+ @CHROFF(0,0),
};

extern const char *names783[];
static const uint32 types783 [] =
{
SK_BOOL,
};

static const uint16 attr_flags783 [] =
{0,};

static const EIF_TYPE_INDEX g_atype783_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes783 [] = {
g_atype783_0,
};

static const long offsets783 [] =
{
+ @CHROFF(0,0),
};

extern const char *names784[];
static const uint32 types784 [] =
{
SK_BOOL,
};

static const uint16 attr_flags784 [] =
{0,};

static const EIF_TYPE_INDEX g_atype784_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes784 [] = {
g_atype784_0,
};

static const long offsets784 [] =
{
+ @CHROFF(0,0),
};

extern const char *names785[];
static const uint32 types785 [] =
{
SK_BOOL,
};

static const uint16 attr_flags785 [] =
{0,};

static const EIF_TYPE_INDEX g_atype785_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes785 [] = {
g_atype785_0,
};

static const long offsets785 [] =
{
+ @CHROFF(0,0),
};

extern const char *names786[];
static const uint32 types786 [] =
{
SK_BOOL,
};

static const uint16 attr_flags786 [] =
{0,};

static const EIF_TYPE_INDEX g_atype786_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes786 [] = {
g_atype786_0,
};

static const long offsets786 [] =
{
+ @CHROFF(0,0),
};

extern const char *names787[];
static const uint32 types787 [] =
{
SK_BOOL,
};

static const uint16 attr_flags787 [] =
{0,};

static const EIF_TYPE_INDEX g_atype787_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes787 [] = {
g_atype787_0,
};

static const long offsets787 [] =
{
+ @CHROFF(0,0),
};

extern const char *names788[];
static const uint32 types788 [] =
{
SK_BOOL,
};

static const uint16 attr_flags788 [] =
{0,};

static const EIF_TYPE_INDEX g_atype788_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes788 [] = {
g_atype788_0,
};

static const long offsets788 [] =
{
+ @CHROFF(0,0),
};

extern const char *names789[];
static const uint32 types789 [] =
{
SK_BOOL,
};

static const uint16 attr_flags789 [] =
{0,};

static const EIF_TYPE_INDEX g_atype789_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes789 [] = {
g_atype789_0,
};

static const long offsets789 [] =
{
+ @CHROFF(0,0),
};

extern const char *names790[];
static const uint32 types790 [] =
{
SK_BOOL,
};

static const uint16 attr_flags790 [] =
{0,};

static const EIF_TYPE_INDEX g_atype790_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes790 [] = {
g_atype790_0,
};

static const long offsets790 [] =
{
+ @CHROFF(0,0),
};

extern const char *names791[];
static const uint32 types791 [] =
{
SK_BOOL,
};

static const uint16 attr_flags791 [] =
{0,};

static const EIF_TYPE_INDEX g_atype791_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes791 [] = {
g_atype791_0,
};

static const long offsets791 [] =
{
+ @CHROFF(0,0),
};

extern const char *names792[];
static const uint32 types792 [] =
{
SK_BOOL,
};

static const uint16 attr_flags792 [] =
{0,};

static const EIF_TYPE_INDEX g_atype792_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes792 [] = {
g_atype792_0,
};

static const long offsets792 [] =
{
+ @CHROFF(0,0),
};

extern const char *names793[];
static const uint32 types793 [] =
{
SK_BOOL,
};

static const uint16 attr_flags793 [] =
{0,};

static const EIF_TYPE_INDEX g_atype793_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes793 [] = {
g_atype793_0,
};

static const long offsets793 [] =
{
+ @CHROFF(0,0),
};

extern const char *names794[];
static const uint32 types794 [] =
{
SK_BOOL,
};

static const uint16 attr_flags794 [] =
{0,};

static const EIF_TYPE_INDEX g_atype794_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes794 [] = {
g_atype794_0,
};

static const long offsets794 [] =
{
+ @CHROFF(0,0),
};

extern const char *names795[];
static const uint32 types795 [] =
{
SK_BOOL,
};

static const uint16 attr_flags795 [] =
{0,};

static const EIF_TYPE_INDEX g_atype795_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes795 [] = {
g_atype795_0,
};

static const long offsets795 [] =
{
+ @CHROFF(0,0),
};

extern const char *names796[];
static const uint32 types796 [] =
{
SK_BOOL,
};

static const uint16 attr_flags796 [] =
{0,};

static const EIF_TYPE_INDEX g_atype796_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes796 [] = {
g_atype796_0,
};

static const long offsets796 [] =
{
+ @CHROFF(0,0),
};

extern const char *names797[];
static const uint32 types797 [] =
{
SK_BOOL,
};

static const uint16 attr_flags797 [] =
{0,};

static const EIF_TYPE_INDEX g_atype797_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes797 [] = {
g_atype797_0,
};

static const long offsets797 [] =
{
+ @CHROFF(0,0),
};

extern const char *names798[];
static const uint32 types798 [] =
{
SK_BOOL,
};

static const uint16 attr_flags798 [] =
{0,};

static const EIF_TYPE_INDEX g_atype798_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes798 [] = {
g_atype798_0,
};

static const long offsets798 [] =
{
+ @CHROFF(0,0),
};

extern const char *names799[];
static const uint32 types799 [] =
{
SK_BOOL,
};

static const uint16 attr_flags799 [] =
{0,};

static const EIF_TYPE_INDEX g_atype799_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes799 [] = {
g_atype799_0,
};

static const long offsets799 [] =
{
+ @CHROFF(0,0),
};

extern const char *names800[];
static const uint32 types800 [] =
{
SK_BOOL,
};

static const uint16 attr_flags800 [] =
{0,};

static const EIF_TYPE_INDEX g_atype800_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes800 [] = {
g_atype800_0,
};

static const long offsets800 [] =
{
+ @CHROFF(0,0),
};

extern const char *names801[];
static const uint32 types801 [] =
{
SK_BOOL,
};

static const uint16 attr_flags801 [] =
{0,};

static const EIF_TYPE_INDEX g_atype801_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes801 [] = {
g_atype801_0,
};

static const long offsets801 [] =
{
+ @CHROFF(0,0),
};

extern const char *names802[];
static const uint32 types802 [] =
{
SK_BOOL,
};

static const uint16 attr_flags802 [] =
{0,};

static const EIF_TYPE_INDEX g_atype802_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes802 [] = {
g_atype802_0,
};

static const long offsets802 [] =
{
+ @CHROFF(0,0),
};

extern const char *names803[];
static const uint32 types803 [] =
{
SK_BOOL,
};

static const uint16 attr_flags803 [] =
{0,};

static const EIF_TYPE_INDEX g_atype803_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes803 [] = {
g_atype803_0,
};

static const long offsets803 [] =
{
+ @CHROFF(0,0),
};

extern const char *names804[];
static const uint32 types804 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags804 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype804_0 [] = {111,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_1 [] = {111,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype804_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes804 [] = {
g_atype804_0,
g_atype804_1,
g_atype804_2,
g_atype804_3,
g_atype804_4,
g_atype804_5,
};

static const long offsets804 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names805[];
static const uint32 types805 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags805 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype805_0 [] = {112,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_1 [] = {112,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype805_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes805 [] = {
g_atype805_0,
g_atype805_1,
g_atype805_2,
g_atype805_3,
g_atype805_4,
g_atype805_5,
};

static const long offsets805 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names809[];
static const uint32 types809 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags809 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype809_0 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype809_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes809 [] = {
g_atype809_0,
g_atype809_1,
g_atype809_2,
g_atype809_3,
};

static const long offsets809 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names810[];
static const uint32 types810 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags810 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype810_0 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype810_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype810_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes810 [] = {
g_atype810_0,
g_atype810_1,
g_atype810_2,
};

static const long offsets810 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names811[];
static const uint32 types811 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags811 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype811_0 [] = {0xFF01,713,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype811_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype811_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes811 [] = {
g_atype811_0,
g_atype811_1,
g_atype811_2,
};

static const long offsets811 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names812[];
static const uint32 types812 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags812 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype812_0 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype812_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype812_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes812 [] = {
g_atype812_0,
g_atype812_1,
g_atype812_2,
};

static const long offsets812 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names813[];
static const uint32 types813 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags813 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype813_0 [] = {0xFF01,715,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype813_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype813_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes813 [] = {
g_atype813_0,
g_atype813_1,
g_atype813_2,
};

static const long offsets813 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names814[];
static const uint32 types814 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags814 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype814_0 [] = {0xFF01,716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype814_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype814_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes814 [] = {
g_atype814_0,
g_atype814_1,
g_atype814_2,
};

static const long offsets814 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names815[];
static const uint32 types815 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags815 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype815_0 [] = {0xFF01,717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype815_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype815_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes815 [] = {
g_atype815_0,
g_atype815_1,
g_atype815_2,
};

static const long offsets815 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names816[];
static const uint32 types816 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags816 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype816_0 [] = {0xFF01,718,888,0xFFFF};
static const EIF_TYPE_INDEX g_atype816_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype816_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes816 [] = {
g_atype816_0,
g_atype816_1,
g_atype816_2,
};

static const long offsets816 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names817[];
static const uint32 types817 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags817 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype817_0 [] = {0xFF01,719,885,0xFFFF};
static const EIF_TYPE_INDEX g_atype817_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype817_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes817 [] = {
g_atype817_0,
g_atype817_1,
g_atype817_2,
};

static const long offsets817 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names818[];
static const uint32 types818 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags818 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype818_0 [] = {0xFF01,720,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype818_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype818_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes818 [] = {
g_atype818_0,
g_atype818_1,
g_atype818_2,
};

static const long offsets818 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names819[];
static const uint32 types819 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags819 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype819_0 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype819_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype819_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes819 [] = {
g_atype819_0,
g_atype819_1,
g_atype819_2,
};

static const long offsets819 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names820[];
static const uint32 types820 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags820 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype820_0 [] = {0xFF01,722,891,0xFFFF};
static const EIF_TYPE_INDEX g_atype820_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype820_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes820 [] = {
g_atype820_0,
g_atype820_1,
g_atype820_2,
};

static const long offsets820 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names821[];
static const uint32 types821 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags821 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype821_0 [] = {0xFF01,723,894,0xFFFF};
static const EIF_TYPE_INDEX g_atype821_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype821_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes821 [] = {
g_atype821_0,
g_atype821_1,
g_atype821_2,
};

static const long offsets821 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names822[];
static const uint32 types822 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags822 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype822_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_1 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_2 [] = {0xFF01,712,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_3 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_4 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_6 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype822_16 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes822 [] = {
g_atype822_0,
g_atype822_1,
g_atype822_2,
g_atype822_3,
g_atype822_4,
g_atype822_5,
g_atype822_6,
g_atype822_7,
g_atype822_8,
g_atype822_9,
g_atype822_10,
g_atype822_11,
g_atype822_12,
g_atype822_13,
g_atype822_14,
g_atype822_15,
g_atype822_16,
};

static const long offsets822 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @LNGOFF(7,3,0,0),
+ @LNGOFF(7,3,0,1),
+ @LNGOFF(7,3,0,2),
+ @LNGOFF(7,3,0,3),
+ @LNGOFF(7,3,0,4),
+ @LNGOFF(7,3,0,5),
+ @LNGOFF(7,3,0,6),
};

extern const char *names823[];
static const uint32 types823 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags823 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype823_0 [] = {0xFF01,713,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_1 [] = {0xFF01,712,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_2 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_3 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_15 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype823_16 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes823 [] = {
g_atype823_0,
g_atype823_1,
g_atype823_2,
g_atype823_3,
g_atype823_4,
g_atype823_5,
g_atype823_6,
g_atype823_7,
g_atype823_8,
g_atype823_9,
g_atype823_10,
g_atype823_11,
g_atype823_12,
g_atype823_13,
g_atype823_14,
g_atype823_15,
g_atype823_16,
};

static const long offsets823 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @PTROFF(5,3,0,7,0,0),
+ @PTROFF(5,3,0,7,0,1),
};

extern const char *names824[];
static const uint32 types824 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags824 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype824_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_1 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_2 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_3 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_4 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype824_16 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes824 [] = {
g_atype824_0,
g_atype824_1,
g_atype824_2,
g_atype824_3,
g_atype824_4,
g_atype824_5,
g_atype824_6,
g_atype824_7,
g_atype824_8,
g_atype824_9,
g_atype824_10,
g_atype824_11,
g_atype824_12,
g_atype824_13,
g_atype824_14,
g_atype824_15,
g_atype824_16,
};

static const long offsets824 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @LNGOFF(6,3,0,0),
+ @LNGOFF(6,3,0,1),
+ @LNGOFF(6,3,0,2),
+ @LNGOFF(6,3,0,3),
+ @LNGOFF(6,3,0,4),
+ @LNGOFF(6,3,0,5),
+ @LNGOFF(6,3,0,6),
+ @LNGOFF(6,3,0,7),
};

extern const char *names825[];
static const uint32 types825 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags825 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype825_0 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_1 [] = {0xFF01,712,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_2 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_3 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype825_16 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes825 [] = {
g_atype825_0,
g_atype825_1,
g_atype825_2,
g_atype825_3,
g_atype825_4,
g_atype825_5,
g_atype825_6,
g_atype825_7,
g_atype825_8,
g_atype825_9,
g_atype825_10,
g_atype825_11,
g_atype825_12,
g_atype825_13,
g_atype825_14,
g_atype825_15,
g_atype825_16,
};

static const long offsets825 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @LNGOFF(5,3,0,7),
+ @LNGOFF(5,3,0,8),
};

extern const char *names826[];
static const uint32 types826 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags826 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype826_0 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_1 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_2 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_3 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype826_16 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes826 [] = {
g_atype826_0,
g_atype826_1,
g_atype826_2,
g_atype826_3,
g_atype826_4,
g_atype826_5,
g_atype826_6,
g_atype826_7,
g_atype826_8,
g_atype826_9,
g_atype826_10,
g_atype826_11,
g_atype826_12,
g_atype826_13,
g_atype826_14,
g_atype826_15,
g_atype826_16,
};

static const long offsets826 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @LNGOFF(4,3,0,3),
+ @LNGOFF(4,3,0,4),
+ @LNGOFF(4,3,0,5),
+ @LNGOFF(4,3,0,6),
+ @LNGOFF(4,3,0,7),
+ @LNGOFF(4,3,0,8),
+ @LNGOFF(4,3,0,9),
};

extern const char *names827[];
static const uint32 types827 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags827 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype827_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_1 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_2 [] = {0xFF01,712,0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_3 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_4 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_6 [] = {942,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype827_17 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes827 [] = {
g_atype827_0,
g_atype827_1,
g_atype827_2,
g_atype827_3,
g_atype827_4,
g_atype827_5,
g_atype827_6,
g_atype827_7,
g_atype827_8,
g_atype827_9,
g_atype827_10,
g_atype827_11,
g_atype827_12,
g_atype827_13,
g_atype827_14,
g_atype827_15,
g_atype827_16,
g_atype827_17,
};

static const long offsets827 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @LNGOFF(7,4,0,0),
+ @LNGOFF(7,4,0,1),
+ @LNGOFF(7,4,0,2),
+ @LNGOFF(7,4,0,3),
+ @LNGOFF(7,4,0,4),
+ @LNGOFF(7,4,0,5),
+ @LNGOFF(7,4,0,6),
};

extern const char *names828[];
static const uint32 types828 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags828 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype828_0 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_1 [] = {0xFF01,712,0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_2 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_3 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_4 [] = {942,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype828_17 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes828 [] = {
g_atype828_0,
g_atype828_1,
g_atype828_2,
g_atype828_3,
g_atype828_4,
g_atype828_5,
g_atype828_6,
g_atype828_7,
g_atype828_8,
g_atype828_9,
g_atype828_10,
g_atype828_11,
g_atype828_12,
g_atype828_13,
g_atype828_14,
g_atype828_15,
g_atype828_16,
g_atype828_17,
};

static const long offsets828 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @LNGOFF(5,4,0,0),
+ @LNGOFF(5,4,0,1),
+ @LNGOFF(5,4,0,2),
+ @LNGOFF(5,4,0,3),
+ @LNGOFF(5,4,0,4),
+ @LNGOFF(5,4,0,5),
+ @LNGOFF(5,4,0,6),
+ @LNGOFF(5,4,0,7),
+ @LNGOFF(5,4,0,8),
};

extern const char *names829[];
static const uint32 types829 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags829 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype829_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_1 [] = {0xFF01,712,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_2 [] = {0xFF01,712,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_3 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_4 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_5 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_6 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_7 [] = {949,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_8 [] = {949,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_11 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype829_18 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes829 [] = {
g_atype829_0,
g_atype829_1,
g_atype829_2,
g_atype829_3,
g_atype829_4,
g_atype829_5,
g_atype829_6,
g_atype829_7,
g_atype829_8,
g_atype829_9,
g_atype829_10,
g_atype829_11,
g_atype829_12,
g_atype829_13,
g_atype829_14,
g_atype829_15,
g_atype829_16,
g_atype829_17,
g_atype829_18,
};

static const long offsets829 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @CHROFF(9,2),
+ @LNGOFF(9,3,0,0),
+ @LNGOFF(9,3,0,1),
+ @LNGOFF(9,3,0,2),
+ @LNGOFF(9,3,0,3),
+ @LNGOFF(9,3,0,4),
+ @LNGOFF(9,3,0,5),
+ @LNGOFF(9,3,0,6),
};

extern const char *names832[];
static const uint32 types832 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags832 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype832_0 [] = {712,715,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype832_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype832_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype832_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype832_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype832_5 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype832_6 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype832_7 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype832_8 [] = {879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes832 [] = {
g_atype832_0,
g_atype832_1,
g_atype832_2,
g_atype832_3,
g_atype832_4,
g_atype832_5,
g_atype832_6,
g_atype832_7,
g_atype832_8,
};

static const long offsets832 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @LNGOFF(1,2,0,0),
+ @LNGOFF(1,2,0,1),
+ @I64OFF(1,2,0,2,0,0,0),
+ @I64OFF(1,2,0,2,0,0,1),
+ @I64OFF(1,2,0,2,0,0,2),
+ @I64OFF(1,2,0,2,0,0,3),
};

extern const char *names833[];
static const uint32 types833 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags833 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype833_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype833_1 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype833_2 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes833 [] = {
g_atype833_0,
g_atype833_1,
g_atype833_2,
};

static const long offsets833 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names834[];
static const uint32 types834 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags834 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype834_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype834_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes834 [] = {
g_atype834_0,
g_atype834_1,
};

static const long offsets834 [] =
{
0,
 + @REFACS(1),
};

extern const char *names835[];
static const uint32 types835 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags835 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype835_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype835_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes835 [] = {
g_atype835_0,
g_atype835_1,
};

static const long offsets835 [] =
{
0,
 + @REFACS(1),
};

extern const char *names836[];
static const uint32 types836 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags836 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype836_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype836_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes836 [] = {
g_atype836_0,
g_atype836_1,
};

static const long offsets836 [] =
{
0,
 + @REFACS(1),
};

extern const char *names837[];
static const uint32 types837 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags837 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype837_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype837_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes837 [] = {
g_atype837_0,
g_atype837_1,
};

static const long offsets837 [] =
{
0,
 + @REFACS(1),
};

extern const char *names838[];
static const uint32 types838 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags838 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype838_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes838 [] = {
g_atype838_0,
g_atype838_1,
};

static const long offsets838 [] =
{
0,
 + @REFACS(1),
};

extern const char *names839[];
static const uint32 types839 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags839 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype839_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype839_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes839 [] = {
g_atype839_0,
g_atype839_1,
};

static const long offsets839 [] =
{
0,
 + @REFACS(1),
};

extern const char *names840[];
static const uint32 types840 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags840 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype840_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype840_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes840 [] = {
g_atype840_0,
g_atype840_1,
};

static const long offsets840 [] =
{
0,
 + @REFACS(1),
};

extern const char *names841[];
static const uint32 types841 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags841 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype841_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype841_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes841 [] = {
g_atype841_0,
g_atype841_1,
};

static const long offsets841 [] =
{
0,
 + @REFACS(1),
};

extern const char *names842[];
static const uint32 types842 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags842 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype842_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype842_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes842 [] = {
g_atype842_0,
g_atype842_1,
};

static const long offsets842 [] =
{
0,
 + @REFACS(1),
};

extern const char *names843[];
static const uint32 types843 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags843 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype843_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype843_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes843 [] = {
g_atype843_0,
g_atype843_1,
};

static const long offsets843 [] =
{
0,
 + @REFACS(1),
};

extern const char *names844[];
static const uint32 types844 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags844 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype844_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype844_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes844 [] = {
g_atype844_0,
g_atype844_1,
};

static const long offsets844 [] =
{
0,
 + @REFACS(1),
};

extern const char *names845[];
static const uint32 types845 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags845 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype845_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype845_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes845 [] = {
g_atype845_0,
g_atype845_1,
};

static const long offsets845 [] =
{
0,
 + @REFACS(1),
};

extern const char *names846[];
static const uint32 types846 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags846 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype846_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype846_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes846 [] = {
g_atype846_0,
g_atype846_1,
};

static const long offsets846 [] =
{
0,
 + @REFACS(1),
};

extern const char *names847[];
static const uint32 types847 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags847 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype847_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype847_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes847 [] = {
g_atype847_0,
g_atype847_1,
};

static const long offsets847 [] =
{
0,
 + @REFACS(1),
};

extern const char *names848[];
static const uint32 types848 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags848 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype848_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype848_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes848 [] = {
g_atype848_0,
g_atype848_1,
};

static const long offsets848 [] =
{
0,
 + @REFACS(1),
};

extern const char *names849[];
static const uint32 types849 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags849 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype849_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype849_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes849 [] = {
g_atype849_0,
g_atype849_1,
};

static const long offsets849 [] =
{
0,
 + @REFACS(1),
};

extern const char *names850[];
static const uint32 types850 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags850 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype850_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype850_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes850 [] = {
g_atype850_0,
g_atype850_1,
};

static const long offsets850 [] =
{
0,
 + @REFACS(1),
};

extern const char *names851[];
static const uint32 types851 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags851 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype851_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype851_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes851 [] = {
g_atype851_0,
g_atype851_1,
};

static const long offsets851 [] =
{
0,
 + @REFACS(1),
};

extern const char *names852[];
static const uint32 types852 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags852 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype852_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes852 [] = {
g_atype852_0,
g_atype852_1,
};

static const long offsets852 [] =
{
0,
 + @REFACS(1),
};

extern const char *names853[];
static const uint32 types853 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags853 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype853_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes853 [] = {
g_atype853_0,
g_atype853_1,
};

static const long offsets853 [] =
{
0,
 + @REFACS(1),
};

extern const char *names854[];
static const uint32 types854 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags854 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype854_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes854 [] = {
g_atype854_0,
g_atype854_1,
};

static const long offsets854 [] =
{
0,
 + @REFACS(1),
};

extern const char *names855[];
static const uint32 types855 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags855 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype855_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes855 [] = {
g_atype855_0,
g_atype855_1,
};

static const long offsets855 [] =
{
0,
 + @REFACS(1),
};

extern const char *names856[];
static const uint32 types856 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags856 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype856_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes856 [] = {
g_atype856_0,
g_atype856_1,
};

static const long offsets856 [] =
{
0,
 + @REFACS(1),
};

extern const char *names857[];
static const uint32 types857 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags857 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype857_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes857 [] = {
g_atype857_0,
g_atype857_1,
};

static const long offsets857 [] =
{
0,
 + @REFACS(1),
};

extern const char *names858[];
static const uint32 types858 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags858 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype858_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes858 [] = {
g_atype858_0,
g_atype858_1,
};

static const long offsets858 [] =
{
0,
 + @REFACS(1),
};

extern const char *names859[];
static const uint32 types859 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags859 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype859_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes859 [] = {
g_atype859_0,
g_atype859_1,
};

static const long offsets859 [] =
{
0,
 + @REFACS(1),
};

extern const char *names860[];
static const uint32 types860 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags860 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype860_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes860 [] = {
g_atype860_0,
g_atype860_1,
};

static const long offsets860 [] =
{
0,
 + @REFACS(1),
};

extern const char *names861[];
static const uint32 types861 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags861 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype861_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes861 [] = {
g_atype861_0,
g_atype861_1,
};

static const long offsets861 [] =
{
0,
 + @REFACS(1),
};

extern const char *names862[];
static const uint32 types862 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags862 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype862_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes862 [] = {
g_atype862_0,
g_atype862_1,
};

static const long offsets862 [] =
{
0,
 + @REFACS(1),
};

extern const char *names863[];
static const uint32 types863 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags863 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype863_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype863_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes863 [] = {
g_atype863_0,
g_atype863_1,
};

static const long offsets863 [] =
{
0,
 + @REFACS(1),
};

extern const char *names864[];
static const uint32 types864 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags864 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype864_0 [] = {946,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_1 [] = {949,0xFFFF};

static const EIF_TYPE_INDEX *gtypes864 [] = {
g_atype864_0,
g_atype864_1,
};

static const long offsets864 [] =
{
0,
 + @REFACS(1),
};

extern const char *names866[];
static const uint32 types866 [] =
{
SK_INT8,
};

static const uint16 attr_flags866 [] =
{0,};

static const EIF_TYPE_INDEX g_atype866_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes866 [] = {
g_atype866_0,
};

static const long offsets866 [] =
{
+ @CHROFF(0,0),
};

extern const char *names867[];
static const uint32 types867 [] =
{
SK_INT8,
};

static const uint16 attr_flags867 [] =
{0,};

static const EIF_TYPE_INDEX g_atype867_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes867 [] = {
g_atype867_0,
};

static const long offsets867 [] =
{
+ @CHROFF(0,0),
};

extern const char *names868[];
static const uint32 types868 [] =
{
SK_INT8,
};

static const uint16 attr_flags868 [] =
{0,};

static const EIF_TYPE_INDEX g_atype868_0 [] = {867,0xFFFF};

static const EIF_TYPE_INDEX *gtypes868 [] = {
g_atype868_0,
};

static const long offsets868 [] =
{
+ @CHROFF(0,0),
};

extern const char *names869[];
static const uint32 types869 [] =
{
SK_INT64,
};

static const uint16 attr_flags869 [] =
{0,};

static const EIF_TYPE_INDEX g_atype869_0 [] = {870,0xFFFF};

static const EIF_TYPE_INDEX *gtypes869 [] = {
g_atype869_0,
};

static const long offsets869 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names870[];
static const uint32 types870 [] =
{
SK_INT64,
};

static const uint16 attr_flags870 [] =
{0,};

static const EIF_TYPE_INDEX g_atype870_0 [] = {870,0xFFFF};

static const EIF_TYPE_INDEX *gtypes870 [] = {
g_atype870_0,
};

static const long offsets870 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names871[];
static const uint32 types871 [] =
{
SK_INT64,
};

static const uint16 attr_flags871 [] =
{0,};

static const EIF_TYPE_INDEX g_atype871_0 [] = {870,0xFFFF};

static const EIF_TYPE_INDEX *gtypes871 [] = {
g_atype871_0,
};

static const long offsets871 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names872[];
static const uint32 types872 [] =
{
SK_INT32,
};

static const uint16 attr_flags872 [] =
{0,};

static const EIF_TYPE_INDEX g_atype872_0 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes872 [] = {
g_atype872_0,
};

static const long offsets872 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names873[];
static const uint32 types873 [] =
{
SK_INT32,
};

static const uint16 attr_flags873 [] =
{0,};

static const EIF_TYPE_INDEX g_atype873_0 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes873 [] = {
g_atype873_0,
};

static const long offsets873 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names874[];
static const uint32 types874 [] =
{
SK_INT32,
};

static const uint16 attr_flags874 [] =
{0,};

static const EIF_TYPE_INDEX g_atype874_0 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes874 [] = {
g_atype874_0,
};

static const long offsets874 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names875[];
static const uint32 types875 [] =
{
SK_INT16,
};

static const uint16 attr_flags875 [] =
{0,};

static const EIF_TYPE_INDEX g_atype875_0 [] = {876,0xFFFF};

static const EIF_TYPE_INDEX *gtypes875 [] = {
g_atype875_0,
};

static const long offsets875 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names876[];
static const uint32 types876 [] =
{
SK_INT16,
};

static const uint16 attr_flags876 [] =
{0,};

static const EIF_TYPE_INDEX g_atype876_0 [] = {876,0xFFFF};

static const EIF_TYPE_INDEX *gtypes876 [] = {
g_atype876_0,
};

static const long offsets876 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names877[];
static const uint32 types877 [] =
{
SK_INT16,
};

static const uint16 attr_flags877 [] =
{0,};

static const EIF_TYPE_INDEX g_atype877_0 [] = {876,0xFFFF};

static const EIF_TYPE_INDEX *gtypes877 [] = {
g_atype877_0,
};

static const long offsets877 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names878[];
static const uint32 types878 [] =
{
SK_UINT64,
};

static const uint16 attr_flags878 [] =
{0,};

static const EIF_TYPE_INDEX g_atype878_0 [] = {879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes878 [] = {
g_atype878_0,
};

static const long offsets878 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names879[];
static const uint32 types879 [] =
{
SK_UINT64,
};

static const uint16 attr_flags879 [] =
{0,};

static const EIF_TYPE_INDEX g_atype879_0 [] = {879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes879 [] = {
g_atype879_0,
};

static const long offsets879 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names880[];
static const uint32 types880 [] =
{
SK_UINT64,
};

static const uint16 attr_flags880 [] =
{0,};

static const EIF_TYPE_INDEX g_atype880_0 [] = {879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes880 [] = {
g_atype880_0,
};

static const long offsets880 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names881[];
static const uint32 types881 [] =
{
SK_UINT32,
};

static const uint16 attr_flags881 [] =
{0,};

static const EIF_TYPE_INDEX g_atype881_0 [] = {882,0xFFFF};

static const EIF_TYPE_INDEX *gtypes881 [] = {
g_atype881_0,
};

static const long offsets881 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names882[];
static const uint32 types882 [] =
{
SK_UINT32,
};

static const uint16 attr_flags882 [] =
{0,};

static const EIF_TYPE_INDEX g_atype882_0 [] = {882,0xFFFF};

static const EIF_TYPE_INDEX *gtypes882 [] = {
g_atype882_0,
};

static const long offsets882 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names883[];
static const uint32 types883 [] =
{
SK_UINT32,
};

static const uint16 attr_flags883 [] =
{0,};

static const EIF_TYPE_INDEX g_atype883_0 [] = {882,0xFFFF};

static const EIF_TYPE_INDEX *gtypes883 [] = {
g_atype883_0,
};

static const long offsets883 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names884[];
static const uint32 types884 [] =
{
SK_UINT16,
};

static const uint16 attr_flags884 [] =
{0,};

static const EIF_TYPE_INDEX g_atype884_0 [] = {885,0xFFFF};

static const EIF_TYPE_INDEX *gtypes884 [] = {
g_atype884_0,
};

static const long offsets884 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names885[];
static const uint32 types885 [] =
{
SK_UINT16,
};

static const uint16 attr_flags885 [] =
{0,};

static const EIF_TYPE_INDEX g_atype885_0 [] = {885,0xFFFF};

static const EIF_TYPE_INDEX *gtypes885 [] = {
g_atype885_0,
};

static const long offsets885 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names886[];
static const uint32 types886 [] =
{
SK_UINT16,
};

static const uint16 attr_flags886 [] =
{0,};

static const EIF_TYPE_INDEX g_atype886_0 [] = {885,0xFFFF};

static const EIF_TYPE_INDEX *gtypes886 [] = {
g_atype886_0,
};

static const long offsets886 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names887[];
static const uint32 types887 [] =
{
SK_UINT8,
};

static const uint16 attr_flags887 [] =
{0,};

static const EIF_TYPE_INDEX g_atype887_0 [] = {888,0xFFFF};

static const EIF_TYPE_INDEX *gtypes887 [] = {
g_atype887_0,
};

static const long offsets887 [] =
{
+ @CHROFF(0,0),
};

extern const char *names888[];
static const uint32 types888 [] =
{
SK_UINT8,
};

static const uint16 attr_flags888 [] =
{0,};

static const EIF_TYPE_INDEX g_atype888_0 [] = {888,0xFFFF};

static const EIF_TYPE_INDEX *gtypes888 [] = {
g_atype888_0,
};

static const long offsets888 [] =
{
+ @CHROFF(0,0),
};

extern const char *names889[];
static const uint32 types889 [] =
{
SK_UINT8,
};

static const uint16 attr_flags889 [] =
{0,};

static const EIF_TYPE_INDEX g_atype889_0 [] = {888,0xFFFF};

static const EIF_TYPE_INDEX *gtypes889 [] = {
g_atype889_0,
};

static const long offsets889 [] =
{
+ @CHROFF(0,0),
};

extern const char *names890[];
static const uint32 types890 [] =
{
SK_REAL32,
};

static const uint16 attr_flags890 [] =
{0,};

static const EIF_TYPE_INDEX g_atype890_0 [] = {891,0xFFFF};

static const EIF_TYPE_INDEX *gtypes890 [] = {
g_atype890_0,
};

static const long offsets890 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names891[];
static const uint32 types891 [] =
{
SK_REAL32,
};

static const uint16 attr_flags891 [] =
{0,};

static const EIF_TYPE_INDEX g_atype891_0 [] = {891,0xFFFF};

static const EIF_TYPE_INDEX *gtypes891 [] = {
g_atype891_0,
};

static const long offsets891 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names892[];
static const uint32 types892 [] =
{
SK_REAL32,
};

static const uint16 attr_flags892 [] =
{0,};

static const EIF_TYPE_INDEX g_atype892_0 [] = {891,0xFFFF};

static const EIF_TYPE_INDEX *gtypes892 [] = {
g_atype892_0,
};

static const long offsets892 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names893[];
static const uint32 types893 [] =
{
SK_REAL64,
};

static const uint16 attr_flags893 [] =
{0,};

static const EIF_TYPE_INDEX g_atype893_0 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes893 [] = {
g_atype893_0,
};

static const long offsets893 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names894[];
static const uint32 types894 [] =
{
SK_REAL64,
};

static const uint16 attr_flags894 [] =
{0,};

static const EIF_TYPE_INDEX g_atype894_0 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes894 [] = {
g_atype894_0,
};

static const long offsets894 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names895[];
static const uint32 types895 [] =
{
SK_REAL64,
};

static const uint16 attr_flags895 [] =
{0,};

static const EIF_TYPE_INDEX g_atype895_0 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes895 [] = {
g_atype895_0,
};

static const long offsets895 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names896[];
static const uint32 types896 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags896 [] =
{0,};

static const EIF_TYPE_INDEX g_atype896_0 [] = {897,0xFFFF};

static const EIF_TYPE_INDEX *gtypes896 [] = {
g_atype896_0,
};

static const long offsets896 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names897[];
static const uint32 types897 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags897 [] =
{0,};

static const EIF_TYPE_INDEX g_atype897_0 [] = {897,0xFFFF};

static const EIF_TYPE_INDEX *gtypes897 [] = {
g_atype897_0,
};

static const long offsets897 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names898[];
static const uint32 types898 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags898 [] =
{0,};

static const EIF_TYPE_INDEX g_atype898_0 [] = {897,0xFFFF};

static const EIF_TYPE_INDEX *gtypes898 [] = {
g_atype898_0,
};

static const long offsets898 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names899[];
static const uint32 types899 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags899 [] =
{0,};

static const EIF_TYPE_INDEX g_atype899_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes899 [] = {
g_atype899_0,
};

static const long offsets899 [] =
{
+ @CHROFF(0,0),
};

extern const char *names900[];
static const uint32 types900 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags900 [] =
{0,};

static const EIF_TYPE_INDEX g_atype900_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes900 [] = {
g_atype900_0,
};

static const long offsets900 [] =
{
+ @CHROFF(0,0),
};

extern const char *names901[];
static const uint32 types901 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags901 [] =
{0,};

static const EIF_TYPE_INDEX g_atype901_0 [] = {900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes901 [] = {
g_atype901_0,
};

static const long offsets901 [] =
{
+ @CHROFF(0,0),
};

extern const char *names902[];
static const uint32 types902 [] =
{
SK_BOOL,
};

static const uint16 attr_flags902 [] =
{0,};

static const EIF_TYPE_INDEX g_atype902_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes902 [] = {
g_atype902_0,
};

static const long offsets902 [] =
{
+ @CHROFF(0,0),
};

extern const char *names903[];
static const uint32 types903 [] =
{
SK_BOOL,
};

static const uint16 attr_flags903 [] =
{0,};

static const EIF_TYPE_INDEX g_atype903_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes903 [] = {
g_atype903_0,
};

static const long offsets903 [] =
{
+ @CHROFF(0,0),
};

extern const char *names904[];
static const uint32 types904 [] =
{
SK_BOOL,
};

static const uint16 attr_flags904 [] =
{0,};

static const EIF_TYPE_INDEX g_atype904_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes904 [] = {
g_atype904_0,
};

static const long offsets904 [] =
{
+ @CHROFF(0,0),
};

extern const char *names905[];
static const uint32 types905 [] =
{
SK_POINTER,
};

static const uint16 attr_flags905 [] =
{0,};

static const EIF_TYPE_INDEX g_atype905_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes905 [] = {
g_atype905_0,
};

static const long offsets905 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names906[];
static const uint32 types906 [] =
{
SK_POINTER,
};

static const uint16 attr_flags906 [] =
{0,};

static const EIF_TYPE_INDEX g_atype906_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes906 [] = {
g_atype906_0,
};

static const long offsets906 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names907[];
static const uint32 types907 [] =
{
SK_POINTER,
};

static const uint16 attr_flags907 [] =
{0,};

static const EIF_TYPE_INDEX g_atype907_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes907 [] = {
g_atype907_0,
};

static const long offsets907 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names908[];
static const uint32 types908 [] =
{
SK_POINTER,
};

static const uint16 attr_flags908 [] =
{0,};

static const EIF_TYPE_INDEX g_atype908_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes908 [] = {
g_atype908_0,
};

static const long offsets908 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names909[];
static const uint32 types909 [] =
{
SK_POINTER,
};

static const uint16 attr_flags909 [] =
{0,};

static const EIF_TYPE_INDEX g_atype909_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes909 [] = {
g_atype909_0,
};

static const long offsets909 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names910[];
static const uint32 types910 [] =
{
SK_POINTER,
};

static const uint16 attr_flags910 [] =
{0,};

static const EIF_TYPE_INDEX g_atype910_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes910 [] = {
g_atype910_0,
};

static const long offsets910 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names911[];
static const uint32 types911 [] =
{
SK_POINTER,
};

static const uint16 attr_flags911 [] =
{0,};

static const EIF_TYPE_INDEX g_atype911_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes911 [] = {
g_atype911_0,
};

static const long offsets911 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names912[];
static const uint32 types912 [] =
{
SK_POINTER,
};

static const uint16 attr_flags912 [] =
{0,};

static const EIF_TYPE_INDEX g_atype912_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes912 [] = {
g_atype912_0,
};

static const long offsets912 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names913[];
static const uint32 types913 [] =
{
SK_POINTER,
};

static const uint16 attr_flags913 [] =
{0,};

static const EIF_TYPE_INDEX g_atype913_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes913 [] = {
g_atype913_0,
};

static const long offsets913 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names914[];
static const uint32 types914 [] =
{
SK_POINTER,
};

static const uint16 attr_flags914 [] =
{0,};

static const EIF_TYPE_INDEX g_atype914_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes914 [] = {
g_atype914_0,
};

static const long offsets914 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names915[];
static const uint32 types915 [] =
{
SK_POINTER,
};

static const uint16 attr_flags915 [] =
{0,};

static const EIF_TYPE_INDEX g_atype915_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes915 [] = {
g_atype915_0,
};

static const long offsets915 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names916[];
static const uint32 types916 [] =
{
SK_POINTER,
};

static const uint16 attr_flags916 [] =
{0,};

static const EIF_TYPE_INDEX g_atype916_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes916 [] = {
g_atype916_0,
};

static const long offsets916 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names917[];
static const uint32 types917 [] =
{
SK_POINTER,
};

static const uint16 attr_flags917 [] =
{0,};

static const EIF_TYPE_INDEX g_atype917_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes917 [] = {
g_atype917_0,
};

static const long offsets917 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names918[];
static const uint32 types918 [] =
{
SK_POINTER,
};

static const uint16 attr_flags918 [] =
{0,};

static const EIF_TYPE_INDEX g_atype918_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes918 [] = {
g_atype918_0,
};

static const long offsets918 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names919[];
static const uint32 types919 [] =
{
SK_POINTER,
};

static const uint16 attr_flags919 [] =
{0,};

static const EIF_TYPE_INDEX g_atype919_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes919 [] = {
g_atype919_0,
};

static const long offsets919 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names920[];
static const uint32 types920 [] =
{
SK_POINTER,
};

static const uint16 attr_flags920 [] =
{0,};

static const EIF_TYPE_INDEX g_atype920_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes920 [] = {
g_atype920_0,
};

static const long offsets920 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names921[];
static const uint32 types921 [] =
{
SK_POINTER,
};

static const uint16 attr_flags921 [] =
{0,};

static const EIF_TYPE_INDEX g_atype921_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes921 [] = {
g_atype921_0,
};

static const long offsets921 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names922[];
static const uint32 types922 [] =
{
SK_POINTER,
};

static const uint16 attr_flags922 [] =
{0,};

static const EIF_TYPE_INDEX g_atype922_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes922 [] = {
g_atype922_0,
};

static const long offsets922 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names923[];
static const uint32 types923 [] =
{
SK_POINTER,
};

static const uint16 attr_flags923 [] =
{0,};

static const EIF_TYPE_INDEX g_atype923_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes923 [] = {
g_atype923_0,
};

static const long offsets923 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names924[];
static const uint32 types924 [] =
{
SK_POINTER,
};

static const uint16 attr_flags924 [] =
{0,};

static const EIF_TYPE_INDEX g_atype924_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes924 [] = {
g_atype924_0,
};

static const long offsets924 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names925[];
static const uint32 types925 [] =
{
SK_POINTER,
};

static const uint16 attr_flags925 [] =
{0,};

static const EIF_TYPE_INDEX g_atype925_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes925 [] = {
g_atype925_0,
};

static const long offsets925 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names926[];
static const uint32 types926 [] =
{
SK_POINTER,
};

static const uint16 attr_flags926 [] =
{0,};

static const EIF_TYPE_INDEX g_atype926_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes926 [] = {
g_atype926_0,
};

static const long offsets926 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names927[];
static const uint32 types927 [] =
{
SK_POINTER,
};

static const uint16 attr_flags927 [] =
{0,};

static const EIF_TYPE_INDEX g_atype927_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes927 [] = {
g_atype927_0,
};

static const long offsets927 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names928[];
static const uint32 types928 [] =
{
SK_POINTER,
};

static const uint16 attr_flags928 [] =
{0,};

static const EIF_TYPE_INDEX g_atype928_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes928 [] = {
g_atype928_0,
};

static const long offsets928 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names929[];
static const uint32 types929 [] =
{
SK_POINTER,
};

static const uint16 attr_flags929 [] =
{0,};

static const EIF_TYPE_INDEX g_atype929_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes929 [] = {
g_atype929_0,
};

static const long offsets929 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names930[];
static const uint32 types930 [] =
{
SK_POINTER,
};

static const uint16 attr_flags930 [] =
{0,};

static const EIF_TYPE_INDEX g_atype930_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes930 [] = {
g_atype930_0,
};

static const long offsets930 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names931[];
static const uint32 types931 [] =
{
SK_POINTER,
};

static const uint16 attr_flags931 [] =
{0,};

static const EIF_TYPE_INDEX g_atype931_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes931 [] = {
g_atype931_0,
};

static const long offsets931 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names932[];
static const uint32 types932 [] =
{
SK_POINTER,
};

static const uint16 attr_flags932 [] =
{0,};

static const EIF_TYPE_INDEX g_atype932_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes932 [] = {
g_atype932_0,
};

static const long offsets932 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names933[];
static const uint32 types933 [] =
{
SK_POINTER,
};

static const uint16 attr_flags933 [] =
{0,};

static const EIF_TYPE_INDEX g_atype933_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes933 [] = {
g_atype933_0,
};

static const long offsets933 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names934[];
static const uint32 types934 [] =
{
SK_POINTER,
};

static const uint16 attr_flags934 [] =
{0,};

static const EIF_TYPE_INDEX g_atype934_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes934 [] = {
g_atype934_0,
};

static const long offsets934 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names935[];
static const uint32 types935 [] =
{
SK_POINTER,
};

static const uint16 attr_flags935 [] =
{0,};

static const EIF_TYPE_INDEX g_atype935_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes935 [] = {
g_atype935_0,
};

static const long offsets935 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names936[];
static const uint32 types936 [] =
{
SK_POINTER,
};

static const uint16 attr_flags936 [] =
{0,};

static const EIF_TYPE_INDEX g_atype936_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes936 [] = {
g_atype936_0,
};

static const long offsets936 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names937[];
static const uint32 types937 [] =
{
SK_POINTER,
};

static const uint16 attr_flags937 [] =
{0,};

static const EIF_TYPE_INDEX g_atype937_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes937 [] = {
g_atype937_0,
};

static const long offsets937 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names938[];
static const uint32 types938 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags938 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype938_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_1 [] = {0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_2 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_3 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_9 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_10 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype938_11 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes938 [] = {
g_atype938_0,
g_atype938_1,
g_atype938_2,
g_atype938_3,
g_atype938_4,
g_atype938_5,
g_atype938_6,
g_atype938_7,
g_atype938_8,
g_atype938_9,
g_atype938_10,
g_atype938_11,
};

static const long offsets938 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names939[];
static const uint32 types939 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags939 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype939_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype939_1 [] = {0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype939_2 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype939_3 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype939_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype939_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype939_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype939_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype939_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype939_9 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype939_10 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype939_11 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes939 [] = {
g_atype939_0,
g_atype939_1,
g_atype939_2,
g_atype939_3,
g_atype939_4,
g_atype939_5,
g_atype939_6,
g_atype939_7,
g_atype939_8,
g_atype939_9,
g_atype939_10,
g_atype939_11,
};

static const long offsets939 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names940[];
static const uint32 types940 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags940 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype940_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_1 [] = {0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_2 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_3 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_10 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_11 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype940_12 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes940 [] = {
g_atype940_0,
g_atype940_1,
g_atype940_2,
g_atype940_3,
g_atype940_4,
g_atype940_5,
g_atype940_6,
g_atype940_7,
g_atype940_8,
g_atype940_9,
g_atype940_10,
g_atype940_11,
g_atype940_12,
};

static const long offsets940 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @PTROFF(5,2,0,3,0,0),
+ @PTROFF(5,2,0,3,0,1),
+ @PTROFF(5,2,0,3,0,2),
};

extern const char *names941[];
static const uint32 types941 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags941 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype941_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_1 [] = {0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_2 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_3 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_10 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_11 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype941_12 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes941 [] = {
g_atype941_0,
g_atype941_1,
g_atype941_2,
g_atype941_3,
g_atype941_4,
g_atype941_5,
g_atype941_6,
g_atype941_7,
g_atype941_8,
g_atype941_9,
g_atype941_10,
g_atype941_11,
g_atype941_12,
};

static const long offsets941 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names942[];
static const uint32 types942 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags942 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype942_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_1 [] = {0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_2 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_3 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_10 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_11 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype942_12 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes942 [] = {
g_atype942_0,
g_atype942_1,
g_atype942_2,
g_atype942_3,
g_atype942_4,
g_atype942_5,
g_atype942_6,
g_atype942_7,
g_atype942_8,
g_atype942_9,
g_atype942_10,
g_atype942_11,
g_atype942_12,
};

static const long offsets942 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names943[];
static const uint32 types943 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags943 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype943_0 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype943_1 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes943 [] = {
g_atype943_0,
g_atype943_1,
};

static const long offsets943 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names944[];
static const uint32 types944 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags944 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype944_0 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype944_1 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes944 [] = {
g_atype944_0,
g_atype944_1,
};

static const long offsets944 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names945[];
static const uint32 types945 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags945 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype945_0 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype945_1 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes945 [] = {
g_atype945_0,
g_atype945_1,
};

static const long offsets945 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names946[];
static const uint32 types946 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags946 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype946_0 [] = {0xFF01,717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype946_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes946 [] = {
g_atype946_0,
g_atype946_1,
g_atype946_2,
g_atype946_3,
};

static const long offsets946 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names947[];
static const uint32 types947 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags947 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype947_0 [] = {0xFF01,717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype947_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes947 [] = {
g_atype947_0,
g_atype947_1,
g_atype947_2,
g_atype947_3,
g_atype947_4,
};

static const long offsets947 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names948[];
static const uint32 types948 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags948 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype948_0 [] = {0xFF01,717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype948_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype948_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype948_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype948_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes948 [] = {
g_atype948_0,
g_atype948_1,
g_atype948_2,
g_atype948_3,
g_atype948_4,
};

static const long offsets948 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names949[];
static const uint32 types949 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags949 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype949_0 [] = {0xFF01,716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype949_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype949_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype949_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes949 [] = {
g_atype949_0,
g_atype949_1,
g_atype949_2,
g_atype949_3,
};

static const long offsets949 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names950[];
static const uint32 types950 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags950 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype950_0 [] = {0xFF01,716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype950_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype950_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype950_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype950_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes950 [] = {
g_atype950_0,
g_atype950_1,
g_atype950_2,
g_atype950_3,
g_atype950_4,
};

static const long offsets950 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names951[];
static const uint32 types951 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags951 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype951_0 [] = {0xFF01,716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype951_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype951_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype951_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype951_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes951 [] = {
g_atype951_0,
g_atype951_1,
g_atype951_2,
g_atype951_3,
g_atype951_4,
};

static const long offsets951 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names952[];
static const uint32 types952 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags952 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype952_0 [] = {0xFF01,716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype952_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype952_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype952_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype952_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes952 [] = {
g_atype952_0,
g_atype952_1,
g_atype952_2,
g_atype952_3,
g_atype952_4,
};

static const long offsets952 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names972[];
static const uint32 types972 [] =
{
SK_INT32,
};

static const uint16 attr_flags972 [] =
{0,};

static const EIF_TYPE_INDEX g_atype972_0 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes972 [] = {
g_atype972_0,
};

static const long offsets972 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names973[];
static const uint32 types973 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags973 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype973_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype973_1 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes973 [] = {
g_atype973_0,
g_atype973_1,
};

static const long offsets973 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names975[];
static const uint32 types975 [] =
{
SK_INT32,
};

static const uint16 attr_flags975 [] =
{0,};

static const EIF_TYPE_INDEX g_atype975_0 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes975 [] = {
g_atype975_0,
};

static const long offsets975 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names976[];
static const uint32 types976 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags976 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype976_0 [] = {0xFF01,193,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_1 [] = {0xFF01,1206,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_2 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes976 [] = {
g_atype976_0,
g_atype976_1,
g_atype976_2,
};

static const long offsets976 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names977[];
static const uint32 types977 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags977 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype977_0 [] = {0xFF01,193,0xFFFF};
static const EIF_TYPE_INDEX g_atype977_1 [] = {950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes977 [] = {
g_atype977_0,
g_atype977_1,
};

static const long offsets977 [] =
{
0,
 + @REFACS(1),
};

extern const char *names978[];
static const uint32 types978 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags978 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype978_0 [] = {0xFF01,193,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_1 [] = {0xFF01,1293,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes978 [] = {
g_atype978_0,
g_atype978_1,
g_atype978_2,
};

static const long offsets978 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names979[];
static const uint32 types979 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags979 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype979_0 [] = {0xFF01,193,0xFFFF};
static const EIF_TYPE_INDEX g_atype979_1 [] = {0xFF01,1294,0xFFFF};
static const EIF_TYPE_INDEX g_atype979_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype979_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype979_4 [] = {0xFF01,1193,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype979_5 [] = {0xFF01,1193,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype979_6 [] = {0xFF01,1193,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype979_7 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes979 [] = {
g_atype979_0,
g_atype979_1,
g_atype979_2,
g_atype979_3,
g_atype979_4,
g_atype979_5,
g_atype979_6,
g_atype979_7,
};

static const long offsets979 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
};

extern const char *names980[];
static const uint32 types980 [] =
{
SK_REF,
};

static const uint16 attr_flags980 [] =
{0,};

static const EIF_TYPE_INDEX g_atype980_0 [] = {0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes980 [] = {
g_atype980_0,
};

static const long offsets980 [] =
{
0,
};

extern const char *names981[];
static const uint32 types981 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags981 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype981_0 [] = {0xFF01,1196,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype981_1 [] = {0xFF01,964,0xFFFF};
static const EIF_TYPE_INDEX g_atype981_2 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype981_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes981 [] = {
g_atype981_0,
g_atype981_1,
g_atype981_2,
g_atype981_3,
};

static const long offsets981 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
};

extern const char *names982[];
static const uint32 types982 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags982 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype982_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype982_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype982_2 [] = {0xFF01,1181,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype982_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype982_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes982 [] = {
g_atype982_0,
g_atype982_1,
g_atype982_2,
g_atype982_3,
g_atype982_4,
};

static const long offsets982 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
};

extern const char *names984[];
static const uint32 types984 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags984 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype984_0 [] = {70,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype984_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype984_2 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype984_3 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes984 [] = {
g_atype984_0,
g_atype984_1,
g_atype984_2,
g_atype984_3,
};

static const long offsets984 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
};

extern const char *names985[];
static const uint32 types985 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags985 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype985_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype985_1 [] = {0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes985 [] = {
g_atype985_0,
g_atype985_1,
};

static const long offsets985 [] =
{
0,
 + @REFACS(1),
};

extern const char *names986[];
static const uint32 types986 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags986 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype986_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype986_1 [] = {950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes986 [] = {
g_atype986_0,
g_atype986_1,
};

static const long offsets986 [] =
{
0,
 + @REFACS(1),
};

extern const char *names988[];
static const uint32 types988 [] =
{
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags988 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype988_0 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype988_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype988_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes988 [] = {
g_atype988_0,
g_atype988_1,
g_atype988_2,
};

static const long offsets988 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
+ @LNGOFF(0,0,0,2),
};

extern const char *names989[];
static const uint32 types989 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags989 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype989_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype989_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype989_2 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype989_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype989_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes989 [] = {
g_atype989_0,
g_atype989_1,
g_atype989_2,
g_atype989_3,
g_atype989_4,
};

static const long offsets989 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
};

extern const char *names991[];
static const uint32 types991 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags991 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype991_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype991_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype991_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype991_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype991_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes991 [] = {
g_atype991_0,
g_atype991_1,
g_atype991_2,
g_atype991_3,
g_atype991_4,
};

static const long offsets991 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names992[];
static const uint32 types992 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags992 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype992_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype992_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype992_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype992_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype992_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes992 [] = {
g_atype992_0,
g_atype992_1,
g_atype992_2,
g_atype992_3,
g_atype992_4,
};

static const long offsets992 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names1001[];
static const uint32 types1001 [] =
{
SK_REF,
};

static const uint16 attr_flags1001 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1001_0 [] = {0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1001 [] = {
g_atype1001_0,
};

static const long offsets1001 [] =
{
0,
};

extern const char *names1004[];
static const uint32 types1004 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1004 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1004_0 [] = {0xFF01,720,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1004_1 [] = {0xFF01,1208,0xFF01,7,0xFFFF};
static const EIF_TYPE_INDEX g_atype1004_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1004_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1004 [] = {
g_atype1004_0,
g_atype1004_1,
g_atype1004_2,
g_atype1004_3,
};

static const long offsets1004 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names1005[];
static const uint32 types1005 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1005 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1005_0 [] = {0xFF01,196,0xFFFF};
static const EIF_TYPE_INDEX g_atype1005_1 [] = {0xFF01,198,0xFFFF};
static const EIF_TYPE_INDEX g_atype1005_2 [] = {0xFF01,197,0xFFFF};
static const EIF_TYPE_INDEX g_atype1005_3 [] = {0xFF01,196,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1005 [] = {
g_atype1005_0,
g_atype1005_1,
g_atype1005_2,
g_atype1005_3,
};

static const long offsets1005 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1012[];
static const uint32 types1012 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1012 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1012_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_1 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_2 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_3 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_4 [] = {17,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_5 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_6 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_10 [] = {888,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_11 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_12 [] = {885,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_13 [] = {876,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_14 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_18 [] = {891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_19 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_20 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_21 [] = {870,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_22 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1012 [] = {
g_atype1012_0,
g_atype1012_1,
g_atype1012_2,
g_atype1012_3,
g_atype1012_4,
g_atype1012_5,
g_atype1012_6,
g_atype1012_7,
g_atype1012_8,
g_atype1012_9,
g_atype1012_10,
g_atype1012_11,
g_atype1012_12,
g_atype1012_13,
g_atype1012_14,
g_atype1012_15,
g_atype1012_16,
g_atype1012_17,
g_atype1012_18,
g_atype1012_19,
g_atype1012_20,
g_atype1012_21,
g_atype1012_22,
};

static const long offsets1012 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names1013[];
static const uint32 types1013 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags1013 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1013_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1013_1 [] = {0xFF01,1221,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1013_2 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1013_3 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1013 [] = {
g_atype1013_0,
g_atype1013_1,
g_atype1013_2,
g_atype1013_3,
};

static const long offsets1013 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
};

extern const char *names1014[];
static const uint32 types1014 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1014 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1014_0 [] = {1427,0xFFFF};
static const EIF_TYPE_INDEX g_atype1014_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1014_2 [] = {0xFF01,1026,0xFFFF};
static const EIF_TYPE_INDEX g_atype1014_3 [] = {0xFF01,1004,0xFFFF};
static const EIF_TYPE_INDEX g_atype1014_4 [] = {0xFF01,1353,0xFFFF};
static const EIF_TYPE_INDEX g_atype1014_5 [] = {0xFF01,51,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1014 [] = {
g_atype1014_0,
g_atype1014_1,
g_atype1014_2,
g_atype1014_3,
g_atype1014_4,
g_atype1014_5,
};

static const long offsets1014 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names1015[];
static const uint32 types1015 [] =
{
SK_REF,
SK_CHAR8,
SK_CHAR32,
SK_INT32,
};

static const uint16 attr_flags1015 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1015_0 [] = {0xFF01,177,0xFFFF};
static const EIF_TYPE_INDEX g_atype1015_1 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1015_2 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1015_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1015 [] = {
g_atype1015_0,
g_atype1015_1,
g_atype1015_2,
g_atype1015_3,
};

static const long offsets1015 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names1016[];
static const uint32 types1016 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1016 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1016_0 [] = {0xFF01,177,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_1 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_2 [] = {716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_3 [] = {717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_5 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_7 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_19 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_20 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_21 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1016 [] = {
g_atype1016_0,
g_atype1016_1,
g_atype1016_2,
g_atype1016_3,
g_atype1016_4,
g_atype1016_5,
g_atype1016_6,
g_atype1016_7,
g_atype1016_8,
g_atype1016_9,
g_atype1016_10,
g_atype1016_11,
g_atype1016_12,
g_atype1016_13,
g_atype1016_14,
g_atype1016_15,
g_atype1016_16,
g_atype1016_17,
g_atype1016_18,
g_atype1016_19,
g_atype1016_20,
g_atype1016_21,
};

static const long offsets1016 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @LNGOFF(5,2,0,3),
+ @LNGOFF(5,2,0,4),
+ @LNGOFF(5,2,0,5),
+ @LNGOFF(5,2,0,6),
+ @LNGOFF(5,2,0,7),
+ @LNGOFF(5,2,0,8),
+ @LNGOFF(5,2,0,9),
+ @LNGOFF(5,2,0,10),
+ @LNGOFF(5,2,0,11),
+ @LNGOFF(5,2,0,12),
+ @LNGOFF(5,2,0,13),
+ @LNGOFF(5,2,0,14),
};

extern const char *names1017[];
static const uint32 types1017 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1017 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1017_0 [] = {0xFF01,177,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_1 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_2 [] = {716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_3 [] = {717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_5 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_6 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_8 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_10 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_19 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_20 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_21 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_22 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_23 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1017_24 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1017 [] = {
g_atype1017_0,
g_atype1017_1,
g_atype1017_2,
g_atype1017_3,
g_atype1017_4,
g_atype1017_5,
g_atype1017_6,
g_atype1017_7,
g_atype1017_8,
g_atype1017_9,
g_atype1017_10,
g_atype1017_11,
g_atype1017_12,
g_atype1017_13,
g_atype1017_14,
g_atype1017_15,
g_atype1017_16,
g_atype1017_17,
g_atype1017_18,
g_atype1017_19,
g_atype1017_20,
g_atype1017_21,
g_atype1017_22,
g_atype1017_23,
g_atype1017_24,
};

static const long offsets1017 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @LNGOFF(8,2,0,0),
+ @LNGOFF(8,2,0,1),
+ @LNGOFF(8,2,0,2),
+ @LNGOFF(8,2,0,3),
+ @LNGOFF(8,2,0,4),
+ @LNGOFF(8,2,0,5),
+ @LNGOFF(8,2,0,6),
+ @LNGOFF(8,2,0,7),
+ @LNGOFF(8,2,0,8),
+ @LNGOFF(8,2,0,9),
+ @LNGOFF(8,2,0,10),
+ @LNGOFF(8,2,0,11),
+ @LNGOFF(8,2,0,12),
+ @LNGOFF(8,2,0,13),
+ @LNGOFF(8,2,0,14),
};

extern const char *names1018[];
static const uint32 types1018 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1018 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1018_0 [] = {0xFF01,177,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_1 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_2 [] = {716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_3 [] = {717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_5 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_8 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_9 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_10 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_11 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_12 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_13 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_14 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_15 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_16 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_17 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_19 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_20 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_21 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_22 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_23 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_24 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_25 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_26 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_27 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_28 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_29 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_30 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_31 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_32 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_33 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_34 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_35 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_36 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_37 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1018 [] = {
g_atype1018_0,
g_atype1018_1,
g_atype1018_2,
g_atype1018_3,
g_atype1018_4,
g_atype1018_5,
g_atype1018_6,
g_atype1018_7,
g_atype1018_8,
g_atype1018_9,
g_atype1018_10,
g_atype1018_11,
g_atype1018_12,
g_atype1018_13,
g_atype1018_14,
g_atype1018_15,
g_atype1018_16,
g_atype1018_17,
g_atype1018_18,
g_atype1018_19,
g_atype1018_20,
g_atype1018_21,
g_atype1018_22,
g_atype1018_23,
g_atype1018_24,
g_atype1018_25,
g_atype1018_26,
g_atype1018_27,
g_atype1018_28,
g_atype1018_29,
g_atype1018_30,
g_atype1018_31,
g_atype1018_32,
g_atype1018_33,
g_atype1018_34,
g_atype1018_35,
g_atype1018_36,
g_atype1018_37,
};

static const long offsets1018 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
+ @CHROFF(14,0),
+ @CHROFF(14,1),
+ @CHROFF(14,2),
+ @LNGOFF(14,3,0,0),
+ @LNGOFF(14,3,0,1),
+ @LNGOFF(14,3,0,2),
+ @LNGOFF(14,3,0,3),
+ @LNGOFF(14,3,0,4),
+ @LNGOFF(14,3,0,5),
+ @LNGOFF(14,3,0,6),
+ @LNGOFF(14,3,0,7),
+ @LNGOFF(14,3,0,8),
+ @LNGOFF(14,3,0,9),
+ @LNGOFF(14,3,0,10),
+ @LNGOFF(14,3,0,11),
+ @LNGOFF(14,3,0,12),
+ @LNGOFF(14,3,0,13),
+ @LNGOFF(14,3,0,14),
+ @LNGOFF(14,3,0,15),
+ @LNGOFF(14,3,0,16),
+ @LNGOFF(14,3,0,17),
+ @LNGOFF(14,3,0,18),
+ @LNGOFF(14,3,0,19),
+ @LNGOFF(14,3,0,20),
};

extern const char *names1019[];
static const uint32 types1019 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1019 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1019_0 [] = {0xFF01,177,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_1 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_2 [] = {716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_3 [] = {717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_5 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_8 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_9 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_10 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_11 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_12 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_13 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_14 [] = {0xFF01,8,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_15 [] = {0xFF01,1273,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_16 [] = {0xFF01,1220,0xFF01,831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_17 [] = {0xFF01,1232,0xFF01,831,0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_18 [] = {0xFF01,1220,0xFF01,831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_19 [] = {0xFF01,1232,0xFF01,831,0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_20 [] = {0xFF01,1232,0xFF01,947,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_21 [] = {0xFF01,1206,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_22 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_23 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_24 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_25 [] = {0xFF01,831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_26 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_27 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_28 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_29 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_30 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_31 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_32 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_33 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_34 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_35 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_36 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_37 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_38 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_39 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_40 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_41 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_42 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_43 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_44 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_45 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_46 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_47 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_48 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_49 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_50 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_51 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_52 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_53 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_54 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_55 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_56 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_57 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1019 [] = {
g_atype1019_0,
g_atype1019_1,
g_atype1019_2,
g_atype1019_3,
g_atype1019_4,
g_atype1019_5,
g_atype1019_6,
g_atype1019_7,
g_atype1019_8,
g_atype1019_9,
g_atype1019_10,
g_atype1019_11,
g_atype1019_12,
g_atype1019_13,
g_atype1019_14,
g_atype1019_15,
g_atype1019_16,
g_atype1019_17,
g_atype1019_18,
g_atype1019_19,
g_atype1019_20,
g_atype1019_21,
g_atype1019_22,
g_atype1019_23,
g_atype1019_24,
g_atype1019_25,
g_atype1019_26,
g_atype1019_27,
g_atype1019_28,
g_atype1019_29,
g_atype1019_30,
g_atype1019_31,
g_atype1019_32,
g_atype1019_33,
g_atype1019_34,
g_atype1019_35,
g_atype1019_36,
g_atype1019_37,
g_atype1019_38,
g_atype1019_39,
g_atype1019_40,
g_atype1019_41,
g_atype1019_42,
g_atype1019_43,
g_atype1019_44,
g_atype1019_45,
g_atype1019_46,
g_atype1019_47,
g_atype1019_48,
g_atype1019_49,
g_atype1019_50,
g_atype1019_51,
g_atype1019_52,
g_atype1019_53,
g_atype1019_54,
g_atype1019_55,
g_atype1019_56,
g_atype1019_57,
};

static const long offsets1019 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
+ @CHROFF(27,0),
+ @CHROFF(27,1),
+ @CHROFF(27,2),
+ @CHROFF(27,3),
+ @LNGOFF(27,4,0,0),
+ @LNGOFF(27,4,0,1),
+ @LNGOFF(27,4,0,2),
+ @LNGOFF(27,4,0,3),
+ @LNGOFF(27,4,0,4),
+ @LNGOFF(27,4,0,5),
+ @LNGOFF(27,4,0,6),
+ @LNGOFF(27,4,0,7),
+ @LNGOFF(27,4,0,8),
+ @LNGOFF(27,4,0,9),
+ @LNGOFF(27,4,0,10),
+ @LNGOFF(27,4,0,11),
+ @LNGOFF(27,4,0,12),
+ @LNGOFF(27,4,0,13),
+ @LNGOFF(27,4,0,14),
+ @LNGOFF(27,4,0,15),
+ @LNGOFF(27,4,0,16),
+ @LNGOFF(27,4,0,17),
+ @LNGOFF(27,4,0,18),
+ @LNGOFF(27,4,0,19),
+ @LNGOFF(27,4,0,20),
+ @LNGOFF(27,4,0,21),
+ @LNGOFF(27,4,0,22),
+ @LNGOFF(27,4,0,23),
+ @LNGOFF(27,4,0,24),
+ @LNGOFF(27,4,0,25),
+ @LNGOFF(27,4,0,26),
};

extern const char *names1026[];
static const uint32 types1026 [] =
{
SK_INT32,
};

static const uint16 attr_flags1026 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1026_0 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1026 [] = {
g_atype1026_0,
};

static const long offsets1026 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1027[];
static const uint32 types1027 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1027 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1027_0 [] = {0xFF01,86,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_1 [] = {0xFF01,86,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1027 [] = {
g_atype1027_0,
g_atype1027_1,
g_atype1027_2,
};

static const long offsets1027 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1028[];
static const uint32 types1028 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1028 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1028_0 [] = {0xFF01,86,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_1 [] = {0xFF01,86,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1028 [] = {
g_atype1028_0,
g_atype1028_1,
g_atype1028_2,
};

static const long offsets1028 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1029[];
static const uint32 types1029 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1029 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1029_0 [] = {942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1029_2 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1029 [] = {
g_atype1029_0,
g_atype1029_1,
g_atype1029_2,
};

static const long offsets1029 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1030[];
static const uint32 types1030 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1030 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1030_0 [] = {942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1030_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1030_2 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1030 [] = {
g_atype1030_0,
g_atype1030_1,
g_atype1030_2,
};

static const long offsets1030 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1031[];
static const uint32 types1031 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1031 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1031_0 [] = {942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1031_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1031_2 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1031 [] = {
g_atype1031_0,
g_atype1031_1,
g_atype1031_2,
};

static const long offsets1031 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1034[];
static const uint32 types1034 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1034 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1034_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1034_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1034_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1034_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1034 [] = {
g_atype1034_0,
g_atype1034_1,
g_atype1034_2,
g_atype1034_3,
};

static const long offsets1034 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1035[];
static const uint32 types1035 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1035 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1035_0 [] = {0xFF01,739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1035_1 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1035_2 [] = {0xFF01,737,0xFF01,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1035_3 [] = {0xFF01,737,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1035_4 [] = {0xFF01,737,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1035_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1035_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1035_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1035_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1035_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1035_10 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1035 [] = {
g_atype1035_0,
g_atype1035_1,
g_atype1035_2,
g_atype1035_3,
g_atype1035_4,
g_atype1035_5,
g_atype1035_6,
g_atype1035_7,
g_atype1035_8,
g_atype1035_9,
g_atype1035_10,
};

static const long offsets1035 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @LNGOFF(5,2,0,3),
};

extern const char *names1036[];
static const uint32 types1036 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1036 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1036_0 [] = {0xFF01,177,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_1 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_2 [] = {716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_3 [] = {717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_5 [] = {0xFF01,739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_6 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_7 [] = {0xFF01,737,0xFF01,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_8 [] = {0xFF01,737,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_9 [] = {0xFF01,737,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_10 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_11 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_12 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_13 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_14 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_19 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_20 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_21 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_22 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_23 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_24 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_25 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_26 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_27 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_28 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_29 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_30 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_31 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1036_32 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1036 [] = {
g_atype1036_0,
g_atype1036_1,
g_atype1036_2,
g_atype1036_3,
g_atype1036_4,
g_atype1036_5,
g_atype1036_6,
g_atype1036_7,
g_atype1036_8,
g_atype1036_9,
g_atype1036_10,
g_atype1036_11,
g_atype1036_12,
g_atype1036_13,
g_atype1036_14,
g_atype1036_15,
g_atype1036_16,
g_atype1036_17,
g_atype1036_18,
g_atype1036_19,
g_atype1036_20,
g_atype1036_21,
g_atype1036_22,
g_atype1036_23,
g_atype1036_24,
g_atype1036_25,
g_atype1036_26,
g_atype1036_27,
g_atype1036_28,
g_atype1036_29,
g_atype1036_30,
g_atype1036_31,
g_atype1036_32,
};

static const long offsets1036 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @CHROFF(10,0),
+ @CHROFF(10,1),
+ @CHROFF(10,2),
+ @CHROFF(10,3),
+ @LNGOFF(10,4,0,0),
+ @LNGOFF(10,4,0,1),
+ @LNGOFF(10,4,0,2),
+ @LNGOFF(10,4,0,3),
+ @LNGOFF(10,4,0,4),
+ @LNGOFF(10,4,0,5),
+ @LNGOFF(10,4,0,6),
+ @LNGOFF(10,4,0,7),
+ @LNGOFF(10,4,0,8),
+ @LNGOFF(10,4,0,9),
+ @LNGOFF(10,4,0,10),
+ @LNGOFF(10,4,0,11),
+ @LNGOFF(10,4,0,12),
+ @LNGOFF(10,4,0,13),
+ @LNGOFF(10,4,0,14),
+ @LNGOFF(10,4,0,15),
+ @LNGOFF(10,4,0,16),
+ @LNGOFF(10,4,0,17),
+ @LNGOFF(10,4,0,18),
};

extern const char *names1037[];
static const uint32 types1037 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1037 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1037_0 [] = {0xFF01,739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1037_1 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1037_2 [] = {0xFF01,737,0xFF01,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1037_3 [] = {0xFF01,737,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1037_4 [] = {0xFF01,737,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1037_5 [] = {0xFF01,739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1037_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1037_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1037_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1037_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1037_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1037_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1037_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1037_13 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1037 [] = {
g_atype1037_0,
g_atype1037_1,
g_atype1037_2,
g_atype1037_3,
g_atype1037_4,
g_atype1037_5,
g_atype1037_6,
g_atype1037_7,
g_atype1037_8,
g_atype1037_9,
g_atype1037_10,
g_atype1037_11,
g_atype1037_12,
g_atype1037_13,
};

static const long offsets1037 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @LNGOFF(6,3,0,0),
+ @LNGOFF(6,3,0,1),
+ @LNGOFF(6,3,0,2),
+ @LNGOFF(6,3,0,3),
+ @LNGOFF(6,3,0,4),
};

extern const char *names1038[];
static const uint32 types1038 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1038 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1038_0 [] = {0xFF01,177,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_1 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_2 [] = {716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_3 [] = {717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_5 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_6 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_8 [] = {0xFF01,739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_9 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_10 [] = {0xFF01,737,0xFF01,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_11 [] = {0xFF01,737,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_12 [] = {0xFF01,737,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_13 [] = {0xFF01,739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_14 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_15 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_16 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_17 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_18 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_19 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_20 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_21 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_22 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_23 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_24 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_25 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_26 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_27 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_28 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_29 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_30 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_31 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_32 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_33 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_34 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_35 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_36 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_37 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1038_38 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1038 [] = {
g_atype1038_0,
g_atype1038_1,
g_atype1038_2,
g_atype1038_3,
g_atype1038_4,
g_atype1038_5,
g_atype1038_6,
g_atype1038_7,
g_atype1038_8,
g_atype1038_9,
g_atype1038_10,
g_atype1038_11,
g_atype1038_12,
g_atype1038_13,
g_atype1038_14,
g_atype1038_15,
g_atype1038_16,
g_atype1038_17,
g_atype1038_18,
g_atype1038_19,
g_atype1038_20,
g_atype1038_21,
g_atype1038_22,
g_atype1038_23,
g_atype1038_24,
g_atype1038_25,
g_atype1038_26,
g_atype1038_27,
g_atype1038_28,
g_atype1038_29,
g_atype1038_30,
g_atype1038_31,
g_atype1038_32,
g_atype1038_33,
g_atype1038_34,
g_atype1038_35,
g_atype1038_36,
g_atype1038_37,
g_atype1038_38,
};

static const long offsets1038 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
+ @CHROFF(14,0),
+ @CHROFF(14,1),
+ @CHROFF(14,2),
+ @CHROFF(14,3),
+ @CHROFF(14,4),
+ @LNGOFF(14,5,0,0),
+ @LNGOFF(14,5,0,1),
+ @LNGOFF(14,5,0,2),
+ @LNGOFF(14,5,0,3),
+ @LNGOFF(14,5,0,4),
+ @LNGOFF(14,5,0,5),
+ @LNGOFF(14,5,0,6),
+ @LNGOFF(14,5,0,7),
+ @LNGOFF(14,5,0,8),
+ @LNGOFF(14,5,0,9),
+ @LNGOFF(14,5,0,10),
+ @LNGOFF(14,5,0,11),
+ @LNGOFF(14,5,0,12),
+ @LNGOFF(14,5,0,13),
+ @LNGOFF(14,5,0,14),
+ @LNGOFF(14,5,0,15),
+ @LNGOFF(14,5,0,16),
+ @LNGOFF(14,5,0,17),
+ @LNGOFF(14,5,0,18),
+ @LNGOFF(14,5,0,19),
};

extern const char *names1039[];
static const uint32 types1039 [] =
{
SK_REF,
};

static const uint16 attr_flags1039 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1039_0 [] = {1038,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1039 [] = {
g_atype1039_0,
};

static const long offsets1039 [] =
{
0,
};

extern const char *names1040[];
static const uint32 types1040 [] =
{
SK_REF,
};

static const uint16 attr_flags1040 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1040_0 [] = {1039,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1040 [] = {
g_atype1040_0,
};

static const long offsets1040 [] =
{
0,
};

extern const char *names1041[];
static const uint32 types1041 [] =
{
SK_REF,
};

static const uint16 attr_flags1041 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1041_0 [] = {1040,900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1041 [] = {
g_atype1041_0,
};

static const long offsets1041 [] =
{
0,
};

extern const char *names1042[];
static const uint32 types1042 [] =
{
SK_REF,
};

static const uint16 attr_flags1042 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1042_0 [] = {1041,903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1042 [] = {
g_atype1042_0,
};

static const long offsets1042 [] =
{
0,
};

extern const char *names1043[];
static const uint32 types1043 [] =
{
SK_REF,
};

static const uint16 attr_flags1043 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1043_0 [] = {1042,879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1043 [] = {
g_atype1043_0,
};

static const long offsets1043 [] =
{
0,
};

extern const char *names1044[];
static const uint32 types1044 [] =
{
SK_REF,
};

static const uint16 attr_flags1044 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1044_0 [] = {1043,882,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1044 [] = {
g_atype1044_0,
};

static const long offsets1044 [] =
{
0,
};

extern const char *names1045[];
static const uint32 types1045 [] =
{
SK_REF,
};

static const uint16 attr_flags1045 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1045_0 [] = {1038,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1045 [] = {
g_atype1045_0,
};

static const long offsets1045 [] =
{
0,
};

extern const char *names1046[];
static const uint32 types1046 [] =
{
SK_REF,
};

static const uint16 attr_flags1046 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1046_0 [] = {1039,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1046 [] = {
g_atype1046_0,
};

static const long offsets1046 [] =
{
0,
};

extern const char *names1047[];
static const uint32 types1047 [] =
{
SK_REF,
};

static const uint16 attr_flags1047 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1047_0 [] = {1040,900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1047 [] = {
g_atype1047_0,
};

static const long offsets1047 [] =
{
0,
};

extern const char *names1048[];
static const uint32 types1048 [] =
{
SK_REF,
};

static const uint16 attr_flags1048 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1048_0 [] = {1038,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1048 [] = {
g_atype1048_0,
};

static const long offsets1048 [] =
{
0,
};

extern const char *names1049[];
static const uint32 types1049 [] =
{
SK_REF,
};

static const uint16 attr_flags1049 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1049_0 [] = {1039,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1049 [] = {
g_atype1049_0,
};

static const long offsets1049 [] =
{
0,
};

extern const char *names1050[];
static const uint32 types1050 [] =
{
SK_REF,
};

static const uint16 attr_flags1050 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1050_0 [] = {1040,900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1050 [] = {
g_atype1050_0,
};

static const long offsets1050 [] =
{
0,
};

extern const char *names1051[];
static const uint32 types1051 [] =
{
SK_REF,
};

static const uint16 attr_flags1051 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1051_0 [] = {1041,903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1051 [] = {
g_atype1051_0,
};

static const long offsets1051 [] =
{
0,
};

extern const char *names1052[];
static const uint32 types1052 [] =
{
SK_REF,
};

static const uint16 attr_flags1052 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1052_0 [] = {1042,879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1052 [] = {
g_atype1052_0,
};

static const long offsets1052 [] =
{
0,
};

extern const char *names1053[];
static const uint32 types1053 [] =
{
SK_REF,
};

static const uint16 attr_flags1053 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1053_0 [] = {1052,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1053 [] = {
g_atype1053_0,
};

static const long offsets1053 [] =
{
0,
};

extern const char *names1054[];
static const uint32 types1054 [] =
{
SK_REF,
};

static const uint16 attr_flags1054 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1054_0 [] = {1053,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1054 [] = {
g_atype1054_0,
};

static const long offsets1054 [] =
{
0,
};

extern const char *names1055[];
static const uint32 types1055 [] =
{
SK_REF,
};

static const uint16 attr_flags1055 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1055_0 [] = {1054,900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1055 [] = {
g_atype1055_0,
};

static const long offsets1055 [] =
{
0,
};

extern const char *names1056[];
static const uint32 types1056 [] =
{
SK_REF,
};

static const uint16 attr_flags1056 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1056_0 [] = {1055,903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1056 [] = {
g_atype1056_0,
};

static const long offsets1056 [] =
{
0,
};

extern const char *names1057[];
static const uint32 types1057 [] =
{
SK_REF,
};

static const uint16 attr_flags1057 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1057_0 [] = {1056,882,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1057 [] = {
g_atype1057_0,
};

static const long offsets1057 [] =
{
0,
};

extern const char *names1058[];
static const uint32 types1058 [] =
{
SK_REF,
};

static const uint16 attr_flags1058 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1058_0 [] = {1057,879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1058 [] = {
g_atype1058_0,
};

static const long offsets1058 [] =
{
0,
};

extern const char *names1059[];
static const uint32 types1059 [] =
{
SK_REF,
};

static const uint16 attr_flags1059 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1059_0 [] = {1058,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1059 [] = {
g_atype1059_0,
};

static const long offsets1059 [] =
{
0,
};

extern const char *names1060[];
static const uint32 types1060 [] =
{
SK_REF,
};

static const uint16 attr_flags1060 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1060_0 [] = {1059,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1060 [] = {
g_atype1060_0,
};

static const long offsets1060 [] =
{
0,
};

extern const char *names1061[];
static const uint32 types1061 [] =
{
SK_REF,
};

static const uint16 attr_flags1061 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1061_0 [] = {1060,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1061 [] = {
g_atype1061_0,
};

static const long offsets1061 [] =
{
0,
};

extern const char *names1062[];
static const uint32 types1062 [] =
{
SK_REF,
};

static const uint16 attr_flags1062 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1062_0 [] = {1061,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1062 [] = {
g_atype1062_0,
};

static const long offsets1062 [] =
{
0,
};

extern const char *names1063[];
static const uint32 types1063 [] =
{
SK_REF,
};

static const uint16 attr_flags1063 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1063_0 [] = {1062,900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1063 [] = {
g_atype1063_0,
};

static const long offsets1063 [] =
{
0,
};

extern const char *names1064[];
static const uint32 types1064 [] =
{
SK_REF,
};

static const uint16 attr_flags1064 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1064_0 [] = {1063,903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1064 [] = {
g_atype1064_0,
};

static const long offsets1064 [] =
{
0,
};

extern const char *names1065[];
static const uint32 types1065 [] =
{
SK_REF,
};

static const uint16 attr_flags1065 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1065_0 [] = {1064,882,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1065 [] = {
g_atype1065_0,
};

static const long offsets1065 [] =
{
0,
};

extern const char *names1066[];
static const uint32 types1066 [] =
{
SK_REF,
};

static const uint16 attr_flags1066 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1066_0 [] = {1065,879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1066 [] = {
g_atype1066_0,
};

static const long offsets1066 [] =
{
0,
};

extern const char *names1067[];
static const uint32 types1067 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1067 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1067_0 [] = {1066,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_1 [] = {0xFFF5,2,0xFF01,1162,0xFFF8,1,0xFFF8,2,6013,5961,0xFFFF};
static const EIF_TYPE_INDEX g_atype1067_2 [] = {0xFF01,1162,0xFFF8,1,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1067 [] = {
g_atype1067_0,
g_atype1067_1,
g_atype1067_2,
};

static const long offsets1067 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1068[];
static const uint32 types1068 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1068 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1068_0 [] = {1067,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_1 [] = {0xFFF5,2,0xFF01,1163,0xFFF8,1,873,6013,5961,0xFFFF};
static const EIF_TYPE_INDEX g_atype1068_2 [] = {0xFF01,1163,0xFFF8,1,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1068 [] = {
g_atype1068_0,
g_atype1068_1,
g_atype1068_2,
};

static const long offsets1068 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1069[];
static const uint32 types1069 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1069 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1069_0 [] = {1068,903,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_1 [] = {0xFFF5,2,0xFF01,1164,903,0xFFF8,2,6013,5961,0xFFFF};
static const EIF_TYPE_INDEX g_atype1069_2 [] = {0xFF01,1164,903,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1069 [] = {
g_atype1069_0,
g_atype1069_1,
g_atype1069_2,
};

static const long offsets1069 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1070[];
static const uint32 types1070 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1070 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1070_0 [] = {1069,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1070_1 [] = {0xFF01,1090,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1070_2 [] = {0xFF01,1165,879,882,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1070 [] = {
g_atype1070_0,
g_atype1070_1,
g_atype1070_2,
};

static const long offsets1070 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1071[];
static const uint32 types1071 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1071 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1071_0 [] = {1070,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1071_1 [] = {0xFF01,1091,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1071_2 [] = {0xFF01,1166,873,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1071 [] = {
g_atype1071_0,
g_atype1071_1,
g_atype1071_2,
};

static const long offsets1071 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1072[];
static const uint32 types1072 [] =
{
SK_REF,
};

static const uint16 attr_flags1072 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1072_0 [] = {1071,0xFFF8,1,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1072 [] = {
g_atype1072_0,
};

static const long offsets1072 [] =
{
0,
};

extern const char *names1073[];
static const uint32 types1073 [] =
{
SK_REF,
};

static const uint16 attr_flags1073 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1073_0 [] = {1072,0xFFF8,1,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1073 [] = {
g_atype1073_0,
};

static const long offsets1073 [] =
{
0,
};

extern const char *names1074[];
static const uint32 types1074 [] =
{
SK_REF,
};

static const uint16 attr_flags1074 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1074_0 [] = {1073,903,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1074 [] = {
g_atype1074_0,
};

static const long offsets1074 [] =
{
0,
};

extern const char *names1075[];
static const uint32 types1075 [] =
{
SK_REF,
};

static const uint16 attr_flags1075 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1075_0 [] = {1074,879,882,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1075 [] = {
g_atype1075_0,
};

static const long offsets1075 [] =
{
0,
};

extern const char *names1076[];
static const uint32 types1076 [] =
{
SK_REF,
};

static const uint16 attr_flags1076 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1076_0 [] = {1075,873,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1076 [] = {
g_atype1076_0,
};

static const long offsets1076 [] =
{
0,
};

extern const char *names1077[];
static const uint32 types1077 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1077 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1077_0 [] = {1076,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_1 [] = {0xFF01,1211,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1077 [] = {
g_atype1077_0,
g_atype1077_1,
g_atype1077_2,
};

static const long offsets1077 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1078[];
static const uint32 types1078 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1078 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1078_0 [] = {1077,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_1 [] = {0xFF01,1212,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1078 [] = {
g_atype1078_0,
g_atype1078_1,
g_atype1078_2,
};

static const long offsets1078 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1079[];
static const uint32 types1079 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1079 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1079_0 [] = {1078,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_1 [] = {0xFF01,1213,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1079 [] = {
g_atype1079_0,
g_atype1079_1,
g_atype1079_2,
};

static const long offsets1079 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1080[];
static const uint32 types1080 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1080 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1080_0 [] = {1079,903,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_1 [] = {0xFF01,1214,903,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1080 [] = {
g_atype1080_0,
g_atype1080_1,
g_atype1080_2,
};

static const long offsets1080 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1081[];
static const uint32 types1081 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1081 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1081_0 [] = {1080,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1081_1 [] = {0xFF01,1215,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1081_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1081 [] = {
g_atype1081_0,
g_atype1081_1,
g_atype1081_2,
};

static const long offsets1081 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1082[];
static const uint32 types1082 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1082 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1082_0 [] = {1081,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_1 [] = {0xFF01,1216,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1082 [] = {
g_atype1082_0,
g_atype1082_1,
g_atype1082_2,
};

static const long offsets1082 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1083[];
static const uint32 types1083 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1083 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1083_0 [] = {1082,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_1 [] = {0xFF01,1217,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1083 [] = {
g_atype1083_0,
g_atype1083_1,
g_atype1083_2,
};

static const long offsets1083 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1084[];
static const uint32 types1084 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1084 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1084_0 [] = {1083,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_1 [] = {0xFF01,1218,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1084 [] = {
g_atype1084_0,
g_atype1084_1,
g_atype1084_2,
};

static const long offsets1084 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1085[];
static const uint32 types1085 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1085 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1085_0 [] = {1084,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_1 [] = {0xFF01,1219,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1085_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1085 [] = {
g_atype1085_0,
g_atype1085_1,
g_atype1085_2,
};

static const long offsets1085 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1086[];
static const uint32 types1086 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1086 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1086_0 [] = {1085,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1086_1 [] = {0xFF01,1220,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1086_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1086 [] = {
g_atype1086_0,
g_atype1086_1,
g_atype1086_2,
};

static const long offsets1086 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1087[];
static const uint32 types1087 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1087 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1087_0 [] = {1086,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_1 [] = {0xFF01,1221,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1087_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1087 [] = {
g_atype1087_0,
g_atype1087_1,
g_atype1087_2,
};

static const long offsets1087 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1088[];
static const uint32 types1088 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1088 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1088_0 [] = {1087,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_1 [] = {0xFF01,1222,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1088_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1088 [] = {
g_atype1088_0,
g_atype1088_1,
g_atype1088_2,
};

static const long offsets1088 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1089[];
static const uint32 types1089 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1089 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1089_0 [] = {1088,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1089_1 [] = {0xFF01,1223,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1089_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1089 [] = {
g_atype1089_0,
g_atype1089_1,
g_atype1089_2,
};

static const long offsets1089 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1090[];
static const uint32 types1090 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1090 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1090_0 [] = {1089,903,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_1 [] = {0xFF01,1224,903,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1090_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1090 [] = {
g_atype1090_0,
g_atype1090_1,
g_atype1090_2,
};

static const long offsets1090 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1091[];
static const uint32 types1091 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1091 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1091_0 [] = {1090,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_1 [] = {0xFF01,1225,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1091_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1091 [] = {
g_atype1091_0,
g_atype1091_1,
g_atype1091_2,
};

static const long offsets1091 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1092[];
static const uint32 types1092 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1092 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1092_0 [] = {1091,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_1 [] = {0xFF01,1226,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1092_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1092 [] = {
g_atype1092_0,
g_atype1092_1,
g_atype1092_2,
};

static const long offsets1092 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1093[];
static const uint32 types1093 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1093 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1093_0 [] = {1092,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_1 [] = {0xFF01,1227,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1093_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1093 [] = {
g_atype1093_0,
g_atype1093_1,
g_atype1093_2,
};

static const long offsets1093 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1094[];
static const uint32 types1094 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1094 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1094_0 [] = {1093,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_1 [] = {0xFF01,1228,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1094_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1094 [] = {
g_atype1094_0,
g_atype1094_1,
g_atype1094_2,
};

static const long offsets1094 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1095[];
static const uint32 types1095 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1095 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1095_0 [] = {1094,903,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_1 [] = {0xFF01,1229,903,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1095_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1095 [] = {
g_atype1095_0,
g_atype1095_1,
g_atype1095_2,
};

static const long offsets1095 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1096[];
static const uint32 types1096 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1096 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1096_0 [] = {1095,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_1 [] = {0xFF01,1230,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1096 [] = {
g_atype1096_0,
g_atype1096_1,
g_atype1096_2,
};

static const long offsets1096 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1097[];
static const uint32 types1097 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1097 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1097_0 [] = {1096,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_1 [] = {0xFF01,1231,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1097 [] = {
g_atype1097_0,
g_atype1097_1,
g_atype1097_2,
};

static const long offsets1097 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1098[];
static const uint32 types1098 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1098 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1098_0 [] = {1097,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_1 [] = {0xFF01,1232,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1098_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1098 [] = {
g_atype1098_0,
g_atype1098_1,
g_atype1098_2,
};

static const long offsets1098 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1099[];
static const uint32 types1099 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1099 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1099_0 [] = {1098,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_1 [] = {0xFF01,1233,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1099_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1099 [] = {
g_atype1099_0,
g_atype1099_1,
g_atype1099_2,
};

static const long offsets1099 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1100[];
static const uint32 types1100 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1100 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1100_0 [] = {1099,903,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_1 [] = {0xFF01,1234,903,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1100_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1100 [] = {
g_atype1100_0,
g_atype1100_1,
g_atype1100_2,
};

static const long offsets1100 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1101[];
static const uint32 types1101 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1101 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1101_0 [] = {1100,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_1 [] = {0xFF01,1235,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1101 [] = {
g_atype1101_0,
g_atype1101_1,
g_atype1101_2,
};

static const long offsets1101 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1102[];
static const uint32 types1102 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1102 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1102_0 [] = {1101,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_1 [] = {0xFF01,1236,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1102 [] = {
g_atype1102_0,
g_atype1102_1,
g_atype1102_2,
};

static const long offsets1102 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1103[];
static const uint32 types1103 [] =
{
SK_REF,
};

static const uint16 attr_flags1103 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1103_0 [] = {1102,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1103 [] = {
g_atype1103_0,
};

static const long offsets1103 [] =
{
0,
};

extern const char *names1104[];
static const uint32 types1104 [] =
{
SK_REF,
};

static const uint16 attr_flags1104 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1104_0 [] = {1103,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1104 [] = {
g_atype1104_0,
};

static const long offsets1104 [] =
{
0,
};

extern const char *names1105[];
static const uint32 types1105 [] =
{
SK_REF,
};

static const uint16 attr_flags1105 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1105_0 [] = {1104,900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1105 [] = {
g_atype1105_0,
};

static const long offsets1105 [] =
{
0,
};

extern const char *names1106[];
static const uint32 types1106 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1106 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1106_0 [] = {1105,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_1 [] = {0xFF01,1208,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1106 [] = {
g_atype1106_0,
g_atype1106_1,
g_atype1106_2,
};

static const long offsets1106 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1107[];
static const uint32 types1107 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1107 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1107_0 [] = {1106,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_1 [] = {0xFF01,1209,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1107_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1107 [] = {
g_atype1107_0,
g_atype1107_1,
g_atype1107_2,
};

static const long offsets1107 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1108[];
static const uint32 types1108 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1108 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1108_0 [] = {1107,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_1 [] = {135,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_2 [] = {0xFF01,1184,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1108_4 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1108 [] = {
g_atype1108_0,
g_atype1108_1,
g_atype1108_2,
g_atype1108_3,
g_atype1108_4,
};

static const long offsets1108 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1109[];
static const uint32 types1109 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1109 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1109_0 [] = {1108,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_1 [] = {136,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_2 [] = {0xFF01,1185,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1109_4 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1109 [] = {
g_atype1109_0,
g_atype1109_1,
g_atype1109_2,
g_atype1109_3,
g_atype1109_4,
};

static const long offsets1109 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1110[];
static const uint32 types1110 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1110 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1110_0 [] = {1109,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1110_1 [] = {138,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1110_2 [] = {0xFF01,1187,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1110_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1110_4 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1110 [] = {
g_atype1110_0,
g_atype1110_1,
g_atype1110_2,
g_atype1110_3,
g_atype1110_4,
};

static const long offsets1110 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1112[];
static const uint32 types1112 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1112 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1112_0 [] = {0xFF01,1233,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1112_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1112 [] = {
g_atype1112_0,
g_atype1112_1,
g_atype1112_2,
g_atype1112_3,
g_atype1112_4,
g_atype1112_5,
};

static const long offsets1112 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names1114[];
static const uint32 types1114 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1114 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1114_0 [] = {1120,0xFF01,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1114_1 [] = {1121,0xFF01,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1114_2 [] = {174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1114_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1114_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1114 [] = {
g_atype1114_0,
g_atype1114_1,
g_atype1114_2,
g_atype1114_3,
g_atype1114_4,
};

static const long offsets1114 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
};

extern const char *names1115[];
static const uint32 types1115 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1115 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1115_0 [] = {0xFF01,1208,0xFF01,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_1 [] = {0xFF01,1208,0xFF01,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_2 [] = {0xFF01,1208,0xFF01,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_3 [] = {0xFF01,1111,0xFF01,1114,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1115_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1115 [] = {
g_atype1115_0,
g_atype1115_1,
g_atype1115_2,
g_atype1115_3,
g_atype1115_4,
g_atype1115_5,
};

static const long offsets1115 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1117[];
static const uint32 types1117 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1117 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1117_0 [] = {0xFF01,1208,0xFF01,1113,0xFFFF};
static const EIF_TYPE_INDEX g_atype1117_1 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1117 [] = {
g_atype1117_0,
g_atype1117_1,
};

static const long offsets1117 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names1118[];
static const uint32 types1118 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1118 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1118_0 [] = {0xFF01,1208,0xFF01,1114,0xFFFF};
static const EIF_TYPE_INDEX g_atype1118_1 [] = {57,0xFFFF};
static const EIF_TYPE_INDEX g_atype1118_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1118_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1118_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1118_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1118 [] = {
g_atype1118_0,
g_atype1118_1,
g_atype1118_2,
g_atype1118_3,
g_atype1118_4,
g_atype1118_5,
};

static const long offsets1118 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names1119[];
static const uint32 types1119 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1119 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1119_0 [] = {0xFF01,739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_1 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_2 [] = {0xFF01,737,0xFF01,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_3 [] = {0xFF01,737,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_4 [] = {0xFF01,737,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_5 [] = {0xFF01,1208,0xFF01,1114,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_6 [] = {57,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_7 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_8 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_9 [] = {0xFF01,1208,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_11 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_12 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_13 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_14 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_15 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_16 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_17 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_18 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_19 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_20 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_21 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_22 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_23 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_24 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_25 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_26 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_27 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_28 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1119_29 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1119 [] = {
g_atype1119_0,
g_atype1119_1,
g_atype1119_2,
g_atype1119_3,
g_atype1119_4,
g_atype1119_5,
g_atype1119_6,
g_atype1119_7,
g_atype1119_8,
g_atype1119_9,
g_atype1119_10,
g_atype1119_11,
g_atype1119_12,
g_atype1119_13,
g_atype1119_14,
g_atype1119_15,
g_atype1119_16,
g_atype1119_17,
g_atype1119_18,
g_atype1119_19,
g_atype1119_20,
g_atype1119_21,
g_atype1119_22,
g_atype1119_23,
g_atype1119_24,
g_atype1119_25,
g_atype1119_26,
g_atype1119_27,
g_atype1119_28,
g_atype1119_29,
};

static const long offsets1119 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @CHROFF(10,0),
+ @CHROFF(10,1),
+ @CHROFF(10,2),
+ @CHROFF(10,3),
+ @CHROFF(10,4),
+ @CHROFF(10,5),
+ @CHROFF(10,6),
+ @CHROFF(10,7),
+ @CHROFF(10,8),
+ @CHROFF(10,9),
+ @CHROFF(10,10),
+ @LNGOFF(10,11,0,0),
+ @LNGOFF(10,11,0,1),
+ @LNGOFF(10,11,0,2),
+ @LNGOFF(10,11,0,3),
+ @LNGOFF(10,11,0,4),
+ @LNGOFF(10,11,0,5),
+ @LNGOFF(10,11,0,6),
+ @LNGOFF(10,11,0,7),
+ @LNGOFF(10,11,0,8),
};

extern const char *names1120[];
static const uint32 types1120 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1120 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1120_0 [] = {0xFF01,739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_1 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_2 [] = {0xFF01,737,0xFF01,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_3 [] = {0xFF01,737,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_4 [] = {0xFF01,737,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_5 [] = {0xFF01,739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_6 [] = {0xFF01,1208,0xFF01,1114,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_7 [] = {57,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_8 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_9 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_10 [] = {0xFF01,1208,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_11 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_12 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_13 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_14 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_15 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_16 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_17 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_18 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_19 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_20 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_21 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_22 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_23 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_24 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_25 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_26 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_27 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_28 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_29 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_30 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_31 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1120_32 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1120 [] = {
g_atype1120_0,
g_atype1120_1,
g_atype1120_2,
g_atype1120_3,
g_atype1120_4,
g_atype1120_5,
g_atype1120_6,
g_atype1120_7,
g_atype1120_8,
g_atype1120_9,
g_atype1120_10,
g_atype1120_11,
g_atype1120_12,
g_atype1120_13,
g_atype1120_14,
g_atype1120_15,
g_atype1120_16,
g_atype1120_17,
g_atype1120_18,
g_atype1120_19,
g_atype1120_20,
g_atype1120_21,
g_atype1120_22,
g_atype1120_23,
g_atype1120_24,
g_atype1120_25,
g_atype1120_26,
g_atype1120_27,
g_atype1120_28,
g_atype1120_29,
g_atype1120_30,
g_atype1120_31,
g_atype1120_32,
};

static const long offsets1120 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @CHROFF(11,1),
+ @CHROFF(11,2),
+ @CHROFF(11,3),
+ @CHROFF(11,4),
+ @CHROFF(11,5),
+ @CHROFF(11,6),
+ @CHROFF(11,7),
+ @CHROFF(11,8),
+ @CHROFF(11,9),
+ @CHROFF(11,10),
+ @CHROFF(11,11),
+ @LNGOFF(11,12,0,0),
+ @LNGOFF(11,12,0,1),
+ @LNGOFF(11,12,0,2),
+ @LNGOFF(11,12,0,3),
+ @LNGOFF(11,12,0,4),
+ @LNGOFF(11,12,0,5),
+ @LNGOFF(11,12,0,6),
+ @LNGOFF(11,12,0,7),
+ @LNGOFF(11,12,0,8),
+ @LNGOFF(11,12,0,9),
};

extern const char *names1121[];
static const uint32 types1121 [] =
{
SK_REF,
};

static const uint16 attr_flags1121 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1121_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1121 [] = {
g_atype1121_0,
};

static const long offsets1121 [] =
{
0,
};

extern const char *names1122[];
static const uint32 types1122 [] =
{
SK_REF,
};

static const uint16 attr_flags1122 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1122_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1122 [] = {
g_atype1122_0,
};

static const long offsets1122 [] =
{
0,
};

extern const char *names1123[];
static const uint32 types1123 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1123 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1123_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1123_1 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1123 [] = {
g_atype1123_0,
g_atype1123_1,
};

static const long offsets1123 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names1124[];
static const uint32 types1124 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1124 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1124_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1124_1 [] = {0xFF01,831,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1124 [] = {
g_atype1124_0,
g_atype1124_1,
};

static const long offsets1124 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1145[];
static const uint32 types1145 [] =
{
SK_REF,
};

static const uint16 attr_flags1145 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1145_0 [] = {254,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1145 [] = {
g_atype1145_0,
};

static const long offsets1145 [] =
{
0,
};

extern const char *names1146[];
static const uint32 types1146 [] =
{
SK_REF,
};

static const uint16 attr_flags1146 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1146_0 [] = {255,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1146 [] = {
g_atype1146_0,
};

static const long offsets1146 [] =
{
0,
};

extern const char *names1147[];
static const uint32 types1147 [] =
{
SK_REF,
};

static const uint16 attr_flags1147 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1147_0 [] = {256,900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1147 [] = {
g_atype1147_0,
};

static const long offsets1147 [] =
{
0,
};

extern const char *names1148[];
static const uint32 types1148 [] =
{
SK_REF,
};

static const uint16 attr_flags1148 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1148_0 [] = {257,903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1148 [] = {
g_atype1148_0,
};

static const long offsets1148 [] =
{
0,
};

extern const char *names1149[];
static const uint32 types1149 [] =
{
SK_REF,
};

static const uint16 attr_flags1149 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1149_0 [] = {258,882,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1149 [] = {
g_atype1149_0,
};

static const long offsets1149 [] =
{
0,
};

extern const char *names1150[];
static const uint32 types1150 [] =
{
SK_REF,
};

static const uint16 attr_flags1150 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1150_0 [] = {259,879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1150 [] = {
g_atype1150_0,
};

static const long offsets1150 [] =
{
0,
};

extern const char *names1151[];
static const uint32 types1151 [] =
{
SK_REF,
};

static const uint16 attr_flags1151 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1151_0 [] = {254,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1151 [] = {
g_atype1151_0,
};

static const long offsets1151 [] =
{
0,
};

extern const char *names1152[];
static const uint32 types1152 [] =
{
SK_REF,
};

static const uint16 attr_flags1152 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1152_0 [] = {255,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1152 [] = {
g_atype1152_0,
};

static const long offsets1152 [] =
{
0,
};

extern const char *names1153[];
static const uint32 types1153 [] =
{
SK_REF,
};

static const uint16 attr_flags1153 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1153_0 [] = {256,900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1153 [] = {
g_atype1153_0,
};

static const long offsets1153 [] =
{
0,
};

extern const char *names1154[];
static const uint32 types1154 [] =
{
SK_REF,
};

static const uint16 attr_flags1154 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1154_0 [] = {257,903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1154 [] = {
g_atype1154_0,
};

static const long offsets1154 [] =
{
0,
};

extern const char *names1155[];
static const uint32 types1155 [] =
{
SK_REF,
};

static const uint16 attr_flags1155 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1155_0 [] = {258,882,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1155 [] = {
g_atype1155_0,
};

static const long offsets1155 [] =
{
0,
};

extern const char *names1156[];
static const uint32 types1156 [] =
{
SK_REF,
};

static const uint16 attr_flags1156 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1156_0 [] = {259,879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1156 [] = {
g_atype1156_0,
};

static const long offsets1156 [] =
{
0,
};

extern const char *names1157[];
static const uint32 types1157 [] =
{
SK_REF,
};

static const uint16 attr_flags1157 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1157_0 [] = {254,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1157 [] = {
g_atype1157_0,
};

static const long offsets1157 [] =
{
0,
};

extern const char *names1158[];
static const uint32 types1158 [] =
{
SK_REF,
};

static const uint16 attr_flags1158 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1158_0 [] = {255,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1158 [] = {
g_atype1158_0,
};

static const long offsets1158 [] =
{
0,
};

extern const char *names1159[];
static const uint32 types1159 [] =
{
SK_REF,
};

static const uint16 attr_flags1159 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1159_0 [] = {256,900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1159 [] = {
g_atype1159_0,
};

static const long offsets1159 [] =
{
0,
};

extern const char *names1160[];
static const uint32 types1160 [] =
{
SK_REF,
};

static const uint16 attr_flags1160 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1160_0 [] = {257,903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1160 [] = {
g_atype1160_0,
};

static const long offsets1160 [] =
{
0,
};

extern const char *names1161[];
static const uint32 types1161 [] =
{
SK_REF,
};

static const uint16 attr_flags1161 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1161_0 [] = {258,882,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1161 [] = {
g_atype1161_0,
};

static const long offsets1161 [] =
{
0,
};

extern const char *names1162[];
static const uint32 types1162 [] =
{
SK_REF,
};

static const uint16 attr_flags1162 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1162_0 [] = {259,879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1162 [] = {
g_atype1162_0,
};

static const long offsets1162 [] =
{
0,
};

extern const char *names1163[];
static const uint32 types1163 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1163 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1163_0 [] = {254,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_1 [] = {0xFF01,1222,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_2 [] = {0xFF01,1066,0xFFF8,1,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1163 [] = {
g_atype1163_0,
g_atype1163_1,
g_atype1163_2,
};

static const long offsets1163 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1164[];
static const uint32 types1164 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1164 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1164_0 [] = {255,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_1 [] = {0xFF01,1223,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1164_2 [] = {0xFF01,1067,0xFFF8,1,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1164 [] = {
g_atype1164_0,
g_atype1164_1,
g_atype1164_2,
};

static const long offsets1164 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1165[];
static const uint32 types1165 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1165 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1165_0 [] = {254,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_1 [] = {0xFF01,1224,903,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1165_2 [] = {0xFF01,1068,903,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1165 [] = {
g_atype1165_0,
g_atype1165_1,
g_atype1165_2,
};

static const long offsets1165 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1166[];
static const uint32 types1166 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1166 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1166_0 [] = {258,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_1 [] = {0xFF01,1225,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_2 [] = {0xFF01,1069,879,882,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1166 [] = {
g_atype1166_0,
g_atype1166_1,
g_atype1166_2,
};

static const long offsets1166 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1167[];
static const uint32 types1167 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1167 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1167_0 [] = {255,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_1 [] = {0xFF01,1226,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_2 [] = {0xFF01,1070,873,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1167 [] = {
g_atype1167_0,
g_atype1167_1,
g_atype1167_2,
};

static const long offsets1167 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1168[];
static const uint32 types1168 [] =
{
SK_REF,
};

static const uint16 attr_flags1168 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1168_0 [] = {254,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1168 [] = {
g_atype1168_0,
};

static const long offsets1168 [] =
{
0,
};

extern const char *names1169[];
static const uint32 types1169 [] =
{
SK_REF,
};

static const uint16 attr_flags1169 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1169_0 [] = {254,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1169 [] = {
g_atype1169_0,
};

static const long offsets1169 [] =
{
0,
};

extern const char *names1170[];
static const uint32 types1170 [] =
{
SK_REF,
};

static const uint16 attr_flags1170 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1170_0 [] = {257,903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1170 [] = {
g_atype1170_0,
};

static const long offsets1170 [] =
{
0,
};

extern const char *names1171[];
static const uint32 types1171 [] =
{
SK_REF,
};

static const uint16 attr_flags1171 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1171_0 [] = {259,879,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1171 [] = {
g_atype1171_0,
};

static const long offsets1171 [] =
{
0,
};

extern const char *names1172[];
static const uint32 types1172 [] =
{
SK_REF,
};

static const uint16 attr_flags1172 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1172_0 [] = {255,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1172 [] = {
g_atype1172_0,
};

static const long offsets1172 [] =
{
0,
};

extern const char *names1173[];
static const uint32 types1173 [] =
{
SK_REF,
};

static const uint16 attr_flags1173 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1173_0 [] = {254,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1173 [] = {
g_atype1173_0,
};

static const long offsets1173 [] =
{
0,
};

extern const char *names1174[];
static const uint32 types1174 [] =
{
SK_REF,
};

static const uint16 attr_flags1174 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1174_0 [] = {255,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1174 [] = {
g_atype1174_0,
};

static const long offsets1174 [] =
{
0,
};

extern const char *names1175[];
static const uint32 types1175 [] =
{
SK_REF,
};

static const uint16 attr_flags1175 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1175_0 [] = {256,900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1175 [] = {
g_atype1175_0,
};

static const long offsets1175 [] =
{
0,
};

extern const char *names1176[];
static const uint32 types1176 [] =
{
SK_REF,
};

static const uint16 attr_flags1176 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1176_0 [] = {257,903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1176 [] = {
g_atype1176_0,
};

static const long offsets1176 [] =
{
0,
};

extern const char *names1177[];
static const uint32 types1177 [] =
{
SK_REF,
};

static const uint16 attr_flags1177 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1177_0 [] = {254,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1177 [] = {
g_atype1177_0,
};

static const long offsets1177 [] =
{
0,
};

extern const char *names1178[];
static const uint32 types1178 [] =
{
SK_REF,
};

static const uint16 attr_flags1178 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1178_0 [] = {255,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1178 [] = {
g_atype1178_0,
};

static const long offsets1178 [] =
{
0,
};

extern const char *names1179[];
static const uint32 types1179 [] =
{
SK_REF,
};

static const uint16 attr_flags1179 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1179_0 [] = {254,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1179 [] = {
g_atype1179_0,
};

static const long offsets1179 [] =
{
0,
};

extern const char *names1180[];
static const uint32 types1180 [] =
{
SK_REF,
};

static const uint16 attr_flags1180 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1180_0 [] = {255,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1180 [] = {
g_atype1180_0,
};

static const long offsets1180 [] =
{
0,
};

extern const char *names1181[];
static const uint32 types1181 [] =
{
SK_REF,
};

static const uint16 attr_flags1181 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1181_0 [] = {256,900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1181 [] = {
g_atype1181_0,
};

static const long offsets1181 [] =
{
0,
};

extern const char *names1182[];
static const uint32 types1182 [] =
{
SK_REF,
};

static const uint16 attr_flags1182 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1182_0 [] = {254,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1182 [] = {
g_atype1182_0,
};

static const long offsets1182 [] =
{
0,
};

extern const char *names1183[];
static const uint32 types1183 [] =
{
SK_REF,
};

static const uint16 attr_flags1183 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1183_0 [] = {255,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1183 [] = {
g_atype1183_0,
};

static const long offsets1183 [] =
{
0,
};

extern const char *names1184[];
static const uint32 types1184 [] =
{
SK_REF,
};

static const uint16 attr_flags1184 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1184_0 [] = {256,900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1184 [] = {
g_atype1184_0,
};

static const long offsets1184 [] =
{
0,
};

extern const char *names1185[];
static const uint32 types1185 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1185 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1185_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1185_1 [] = {135,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1185_2 [] = {135,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1185_3 [] = {0xFF01,1107,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1185_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1185 [] = {
g_atype1185_0,
g_atype1185_1,
g_atype1185_2,
g_atype1185_3,
g_atype1185_4,
};

static const long offsets1185 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1186[];
static const uint32 types1186 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1186 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1186_0 [] = {256,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_1 [] = {136,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_2 [] = {136,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_3 [] = {0xFF01,1108,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1186 [] = {
g_atype1186_0,
g_atype1186_1,
g_atype1186_2,
g_atype1186_3,
g_atype1186_4,
};

static const long offsets1186 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1187[];
static const uint32 types1187 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1187 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1187_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_1 [] = {135,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_2 [] = {135,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_3 [] = {0xFF01,1107,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1187 [] = {
g_atype1187_0,
g_atype1187_1,
g_atype1187_2,
g_atype1187_3,
g_atype1187_4,
};

static const long offsets1187 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1188[];
static const uint32 types1188 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1188 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1188_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_1 [] = {138,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_2 [] = {138,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_3 [] = {0xFF01,1109,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1188 [] = {
g_atype1188_0,
g_atype1188_1,
g_atype1188_2,
g_atype1188_3,
g_atype1188_4,
};

static const long offsets1188 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1189[];
static const uint32 types1189 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1189 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1189_0 [] = {254,0xFF01,153,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_1 [] = {135,0xFF01,153,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_2 [] = {135,0xFF01,153,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_3 [] = {0xFF01,1107,0xFF01,153,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_4 [] = {0xFF01,153,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_5 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1189_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1189 [] = {
g_atype1189_0,
g_atype1189_1,
g_atype1189_2,
g_atype1189_3,
g_atype1189_4,
g_atype1189_5,
g_atype1189_6,
};

static const long offsets1189 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
};

extern const char *names1190[];
static const uint32 types1190 [] =
{
SK_REF,
};

static const uint16 attr_flags1190 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1190_0 [] = {254,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1190 [] = {
g_atype1190_0,
};

static const long offsets1190 [] =
{
0,
};

extern const char *names1191[];
static const uint32 types1191 [] =
{
SK_REF,
};

static const uint16 attr_flags1191 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1191_0 [] = {257,903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1191 [] = {
g_atype1191_0,
};

static const long offsets1191 [] =
{
0,
};

extern const char *names1192[];
static const uint32 types1192 [] =
{
SK_REF,
};

static const uint16 attr_flags1192 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1192_0 [] = {255,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1192 [] = {
g_atype1192_0,
};

static const long offsets1192 [] =
{
0,
};

extern const char *names1193[];
static const uint32 types1193 [] =
{
SK_REF,
};

static const uint16 attr_flags1193 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1193_0 [] = {256,900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1193 [] = {
g_atype1193_0,
};

static const long offsets1193 [] =
{
0,
};

extern const char *names1194[];
static const uint32 types1194 [] =
{
SK_REF,
};

static const uint16 attr_flags1194 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1194_0 [] = {254,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1194 [] = {
g_atype1194_0,
};

static const long offsets1194 [] =
{
0,
};

extern const char *names1195[];
static const uint32 types1195 [] =
{
SK_REF,
};

static const uint16 attr_flags1195 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1195_0 [] = {256,900,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1195 [] = {
g_atype1195_0,
};

static const long offsets1195 [] =
{
0,
};

extern const char *names1196[];
static const uint32 types1196 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1196 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1196_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_1 [] = {135,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_2 [] = {135,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1196_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1196 [] = {
g_atype1196_0,
g_atype1196_1,
g_atype1196_2,
g_atype1196_3,
};

static const long offsets1196 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
};

extern const char *names1197[];
static const uint32 types1197 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1197 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1197_0 [] = {256,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_1 [] = {136,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_2 [] = {136,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1197_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1197 [] = {
g_atype1197_0,
g_atype1197_1,
g_atype1197_2,
g_atype1197_3,
};

static const long offsets1197 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
};

extern const char *names1198[];
static const uint32 types1198 [] =
{
SK_REF,
};

static const uint16 attr_flags1198 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1198_0 [] = {254,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1198 [] = {
g_atype1198_0,
};

static const long offsets1198 [] =
{
0,
};

extern const char *names1199[];
static const uint32 types1199 [] =
{
SK_REF,
};

static const uint16 attr_flags1199 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1199_0 [] = {257,903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1199 [] = {
g_atype1199_0,
};

static const long offsets1199 [] =
{
0,
};

extern const char *names1200[];
static const uint32 types1200 [] =
{
SK_REF,
};

static const uint16 attr_flags1200 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1200_0 [] = {255,873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1200 [] = {
g_atype1200_0,
};

static const long offsets1200 [] =
{
0,
};

extern const char *names1201[];
static const uint32 types1201 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1201 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1201_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_1 [] = {135,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1201_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1201 [] = {
g_atype1201_0,
g_atype1201_1,
g_atype1201_2,
};

static const long offsets1201 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1206[];
static const uint32 types1206 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1206 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1206_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1206_1 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1206_2 [] = {0xFF01,23,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1206_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1206_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1206 [] = {
g_atype1206_0,
g_atype1206_1,
g_atype1206_2,
g_atype1206_3,
g_atype1206_4,
};

static const long offsets1206 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names1207[];
static const uint32 types1207 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1207 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1207_0 [] = {257,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1207_1 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1207_2 [] = {0xFF01,25,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1207_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1207_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1207 [] = {
g_atype1207_0,
g_atype1207_1,
g_atype1207_2,
g_atype1207_3,
g_atype1207_4,
};

static const long offsets1207 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names1208[];
static const uint32 types1208 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1208 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1208_0 [] = {255,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1208_1 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1208_2 [] = {0xFF01,24,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1208_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1208_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1208 [] = {
g_atype1208_0,
g_atype1208_1,
g_atype1208_2,
g_atype1208_3,
g_atype1208_4,
};

static const long offsets1208 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names1209[];
static const uint32 types1209 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1209 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1209_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1209_1 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1209_2 [] = {0xFF01,23,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1209_3 [] = {0xFF01,1105,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1209_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1209_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1209 [] = {
g_atype1209_0,
g_atype1209_1,
g_atype1209_2,
g_atype1209_3,
g_atype1209_4,
g_atype1209_5,
};

static const long offsets1209 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1210[];
static const uint32 types1210 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1210 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1210_0 [] = {255,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1210_1 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1210_2 [] = {0xFF01,24,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1210_3 [] = {0xFF01,1106,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1210_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1210_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1210 [] = {
g_atype1210_0,
g_atype1210_1,
g_atype1210_2,
g_atype1210_3,
g_atype1210_4,
g_atype1210_5,
};

static const long offsets1210 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1211[];
static const uint32 types1211 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1211 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1211_0 [] = {254,0xFF01,4,0xFFFF};
static const EIF_TYPE_INDEX g_atype1211_1 [] = {0xFF01,712,0xFF01,4,0xFFFF};
static const EIF_TYPE_INDEX g_atype1211_2 [] = {0xFF01,23,0xFF01,4,0xFFFF};
static const EIF_TYPE_INDEX g_atype1211_3 [] = {0xFF01,1105,0xFF01,4,0xFFFF};
static const EIF_TYPE_INDEX g_atype1211_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1211_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1211 [] = {
g_atype1211_0,
g_atype1211_1,
g_atype1211_2,
g_atype1211_3,
g_atype1211_4,
g_atype1211_5,
};

static const long offsets1211 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1212[];
static const uint32 types1212 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1212 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1212_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_1 [] = {0xFF01,1076,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1212_10 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1212 [] = {
g_atype1212_0,
g_atype1212_1,
g_atype1212_2,
g_atype1212_3,
g_atype1212_4,
g_atype1212_5,
g_atype1212_6,
g_atype1212_7,
g_atype1212_8,
g_atype1212_9,
g_atype1212_10,
};

static const long offsets1212 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1213[];
static const uint32 types1213 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1213 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1213_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_1 [] = {0xFF01,1077,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1213_10 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1213 [] = {
g_atype1213_0,
g_atype1213_1,
g_atype1213_2,
g_atype1213_3,
g_atype1213_4,
g_atype1213_5,
g_atype1213_6,
g_atype1213_7,
g_atype1213_8,
g_atype1213_9,
g_atype1213_10,
};

static const long offsets1213 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1214[];
static const uint32 types1214 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1214 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1214_0 [] = {255,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_1 [] = {0xFF01,1078,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1214_10 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1214 [] = {
g_atype1214_0,
g_atype1214_1,
g_atype1214_2,
g_atype1214_3,
g_atype1214_4,
g_atype1214_5,
g_atype1214_6,
g_atype1214_7,
g_atype1214_8,
g_atype1214_9,
g_atype1214_10,
};

static const long offsets1214 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1215[];
static const uint32 types1215 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1215 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1215_0 [] = {257,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_1 [] = {0xFF01,1079,903,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1215_10 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1215 [] = {
g_atype1215_0,
g_atype1215_1,
g_atype1215_2,
g_atype1215_3,
g_atype1215_4,
g_atype1215_5,
g_atype1215_6,
g_atype1215_7,
g_atype1215_8,
g_atype1215_9,
g_atype1215_10,
};

static const long offsets1215 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1216[];
static const uint32 types1216 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1216 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1216_0 [] = {259,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_1 [] = {0xFF01,1080,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1216_10 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1216 [] = {
g_atype1216_0,
g_atype1216_1,
g_atype1216_2,
g_atype1216_3,
g_atype1216_4,
g_atype1216_5,
g_atype1216_6,
g_atype1216_7,
g_atype1216_8,
g_atype1216_9,
g_atype1216_10,
};

static const long offsets1216 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1217[];
static const uint32 types1217 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1217 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1217_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_1 [] = {0xFF01,1081,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1217_10 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1217 [] = {
g_atype1217_0,
g_atype1217_1,
g_atype1217_2,
g_atype1217_3,
g_atype1217_4,
g_atype1217_5,
g_atype1217_6,
g_atype1217_7,
g_atype1217_8,
g_atype1217_9,
g_atype1217_10,
};

static const long offsets1217 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1218[];
static const uint32 types1218 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1218 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1218_0 [] = {255,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_1 [] = {0xFF01,1082,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1218_10 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1218 [] = {
g_atype1218_0,
g_atype1218_1,
g_atype1218_2,
g_atype1218_3,
g_atype1218_4,
g_atype1218_5,
g_atype1218_6,
g_atype1218_7,
g_atype1218_8,
g_atype1218_9,
g_atype1218_10,
};

static const long offsets1218 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1219[];
static const uint32 types1219 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1219 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1219_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1219_1 [] = {0xFF01,1083,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1219_2 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1219_3 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1219_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1219_5 [] = {0xFF01,23,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1219_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1219_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1219_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1219_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1219_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1219_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1219_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1219_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1219_14 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1219 [] = {
g_atype1219_0,
g_atype1219_1,
g_atype1219_2,
g_atype1219_3,
g_atype1219_4,
g_atype1219_5,
g_atype1219_6,
g_atype1219_7,
g_atype1219_8,
g_atype1219_9,
g_atype1219_10,
g_atype1219_11,
g_atype1219_12,
g_atype1219_13,
g_atype1219_14,
};

static const long offsets1219 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
+ @LNGOFF(6,0,0,1),
+ @LNGOFF(6,0,0,2),
+ @LNGOFF(6,0,0,3),
+ @LNGOFF(6,0,0,4),
+ @LNGOFF(6,0,0,5),
+ @LNGOFF(6,0,0,6),
+ @LNGOFF(6,0,0,7),
+ @LNGOFF(6,0,0,8),
};

extern const char *names1220[];
static const uint32 types1220 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1220 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1220_0 [] = {255,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_1 [] = {0xFF01,1084,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_2 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_3 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_5 [] = {0xFF01,24,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1220_14 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1220 [] = {
g_atype1220_0,
g_atype1220_1,
g_atype1220_2,
g_atype1220_3,
g_atype1220_4,
g_atype1220_5,
g_atype1220_6,
g_atype1220_7,
g_atype1220_8,
g_atype1220_9,
g_atype1220_10,
g_atype1220_11,
g_atype1220_12,
g_atype1220_13,
g_atype1220_14,
};

static const long offsets1220 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
+ @LNGOFF(6,0,0,1),
+ @LNGOFF(6,0,0,2),
+ @LNGOFF(6,0,0,3),
+ @LNGOFF(6,0,0,4),
+ @LNGOFF(6,0,0,5),
+ @LNGOFF(6,0,0,6),
+ @LNGOFF(6,0,0,7),
+ @LNGOFF(6,0,0,8),
};

extern const char *names1221[];
static const uint32 types1221 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1221 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1221_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1221_1 [] = {0xFF01,1085,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1221_2 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1221_3 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1221_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1221_5 [] = {0xFF01,23,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1221_6 [] = {18,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1221_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1221_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1221_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1221_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1221_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1221_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1221_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1221_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1221_15 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1221 [] = {
g_atype1221_0,
g_atype1221_1,
g_atype1221_2,
g_atype1221_3,
g_atype1221_4,
g_atype1221_5,
g_atype1221_6,
g_atype1221_7,
g_atype1221_8,
g_atype1221_9,
g_atype1221_10,
g_atype1221_11,
g_atype1221_12,
g_atype1221_13,
g_atype1221_14,
g_atype1221_15,
};

static const long offsets1221 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @LNGOFF(7,0,0,0),
+ @LNGOFF(7,0,0,1),
+ @LNGOFF(7,0,0,2),
+ @LNGOFF(7,0,0,3),
+ @LNGOFF(7,0,0,4),
+ @LNGOFF(7,0,0,5),
+ @LNGOFF(7,0,0,6),
+ @LNGOFF(7,0,0,7),
+ @LNGOFF(7,0,0,8),
};

extern const char *names1222[];
static const uint32 types1222 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1222 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1222_0 [] = {255,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_1 [] = {0xFF01,1086,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_2 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_3 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_5 [] = {0xFF01,24,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_6 [] = {19,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1222_15 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1222 [] = {
g_atype1222_0,
g_atype1222_1,
g_atype1222_2,
g_atype1222_3,
g_atype1222_4,
g_atype1222_5,
g_atype1222_6,
g_atype1222_7,
g_atype1222_8,
g_atype1222_9,
g_atype1222_10,
g_atype1222_11,
g_atype1222_12,
g_atype1222_13,
g_atype1222_14,
g_atype1222_15,
};

static const long offsets1222 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @LNGOFF(7,0,0,0),
+ @LNGOFF(7,0,0,1),
+ @LNGOFF(7,0,0,2),
+ @LNGOFF(7,0,0,3),
+ @LNGOFF(7,0,0,4),
+ @LNGOFF(7,0,0,5),
+ @LNGOFF(7,0,0,6),
+ @LNGOFF(7,0,0,7),
+ @LNGOFF(7,0,0,8),
};

extern const char *names1223[];
static const uint32 types1223 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1223 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1223_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_1 [] = {0xFF01,1087,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_2 [] = {1162,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_3 [] = {254,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1223_12 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1223 [] = {
g_atype1223_0,
g_atype1223_1,
g_atype1223_2,
g_atype1223_3,
g_atype1223_4,
g_atype1223_5,
g_atype1223_6,
g_atype1223_7,
g_atype1223_8,
g_atype1223_9,
g_atype1223_10,
g_atype1223_11,
g_atype1223_12,
};

static const long offsets1223 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1224[];
static const uint32 types1224 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1224 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1224_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_1 [] = {0xFF01,1088,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_2 [] = {1163,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_3 [] = {255,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1224_12 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1224 [] = {
g_atype1224_0,
g_atype1224_1,
g_atype1224_2,
g_atype1224_3,
g_atype1224_4,
g_atype1224_5,
g_atype1224_6,
g_atype1224_7,
g_atype1224_8,
g_atype1224_9,
g_atype1224_10,
g_atype1224_11,
g_atype1224_12,
};

static const long offsets1224 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1225[];
static const uint32 types1225 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1225 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1225_0 [] = {257,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_1 [] = {0xFF01,1089,903,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_2 [] = {1164,903,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_3 [] = {254,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1225_12 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1225 [] = {
g_atype1225_0,
g_atype1225_1,
g_atype1225_2,
g_atype1225_3,
g_atype1225_4,
g_atype1225_5,
g_atype1225_6,
g_atype1225_7,
g_atype1225_8,
g_atype1225_9,
g_atype1225_10,
g_atype1225_11,
g_atype1225_12,
};

static const long offsets1225 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1226[];
static const uint32 types1226 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1226 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1226_0 [] = {259,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_1 [] = {0xFF01,1090,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_2 [] = {1165,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_3 [] = {258,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1226_12 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1226 [] = {
g_atype1226_0,
g_atype1226_1,
g_atype1226_2,
g_atype1226_3,
g_atype1226_4,
g_atype1226_5,
g_atype1226_6,
g_atype1226_7,
g_atype1226_8,
g_atype1226_9,
g_atype1226_10,
g_atype1226_11,
g_atype1226_12,
};

static const long offsets1226 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1227[];
static const uint32 types1227 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1227 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1227_0 [] = {255,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_1 [] = {0xFF01,1091,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_2 [] = {1166,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_3 [] = {255,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1227_12 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1227 [] = {
g_atype1227_0,
g_atype1227_1,
g_atype1227_2,
g_atype1227_3,
g_atype1227_4,
g_atype1227_5,
g_atype1227_6,
g_atype1227_7,
g_atype1227_8,
g_atype1227_9,
g_atype1227_10,
g_atype1227_11,
g_atype1227_12,
};

static const long offsets1227 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1228[];
static const uint32 types1228 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1228 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1228_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_1 [] = {0xFF01,1092,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_2 [] = {1162,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_3 [] = {254,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_4 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_5 [] = {0xFF01,712,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_8 [] = {0xFF01,23,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_9 [] = {0xFF01,23,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1228_18 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1228 [] = {
g_atype1228_0,
g_atype1228_1,
g_atype1228_2,
g_atype1228_3,
g_atype1228_4,
g_atype1228_5,
g_atype1228_6,
g_atype1228_7,
g_atype1228_8,
g_atype1228_9,
g_atype1228_10,
g_atype1228_11,
g_atype1228_12,
g_atype1228_13,
g_atype1228_14,
g_atype1228_15,
g_atype1228_16,
g_atype1228_17,
g_atype1228_18,
};

static const long offsets1228 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1229[];
static const uint32 types1229 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1229 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1229_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_1 [] = {0xFF01,1093,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_2 [] = {1163,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_3 [] = {255,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_4 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_5 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_8 [] = {0xFF01,23,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_9 [] = {0xFF01,24,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_18 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1229 [] = {
g_atype1229_0,
g_atype1229_1,
g_atype1229_2,
g_atype1229_3,
g_atype1229_4,
g_atype1229_5,
g_atype1229_6,
g_atype1229_7,
g_atype1229_8,
g_atype1229_9,
g_atype1229_10,
g_atype1229_11,
g_atype1229_12,
g_atype1229_13,
g_atype1229_14,
g_atype1229_15,
g_atype1229_16,
g_atype1229_17,
g_atype1229_18,
};

static const long offsets1229 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1230[];
static const uint32 types1230 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1230 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1230_0 [] = {257,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_1 [] = {0xFF01,1094,903,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_2 [] = {1164,903,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_3 [] = {254,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_4 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_5 [] = {0xFF01,712,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_8 [] = {0xFF01,25,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_9 [] = {0xFF01,23,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_18 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1230 [] = {
g_atype1230_0,
g_atype1230_1,
g_atype1230_2,
g_atype1230_3,
g_atype1230_4,
g_atype1230_5,
g_atype1230_6,
g_atype1230_7,
g_atype1230_8,
g_atype1230_9,
g_atype1230_10,
g_atype1230_11,
g_atype1230_12,
g_atype1230_13,
g_atype1230_14,
g_atype1230_15,
g_atype1230_16,
g_atype1230_17,
g_atype1230_18,
};

static const long offsets1230 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1231[];
static const uint32 types1231 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1231 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1231_0 [] = {259,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_1 [] = {0xFF01,1095,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_2 [] = {1165,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_3 [] = {258,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_4 [] = {0xFF01,715,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_5 [] = {0xFF01,720,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_8 [] = {0xFF01,26,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_9 [] = {0xFF01,27,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_18 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1231 [] = {
g_atype1231_0,
g_atype1231_1,
g_atype1231_2,
g_atype1231_3,
g_atype1231_4,
g_atype1231_5,
g_atype1231_6,
g_atype1231_7,
g_atype1231_8,
g_atype1231_9,
g_atype1231_10,
g_atype1231_11,
g_atype1231_12,
g_atype1231_13,
g_atype1231_14,
g_atype1231_15,
g_atype1231_16,
g_atype1231_17,
g_atype1231_18,
};

static const long offsets1231 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1232[];
static const uint32 types1232 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1232 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1232_0 [] = {255,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_1 [] = {0xFF01,1096,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_2 [] = {1166,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_3 [] = {255,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_5 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_8 [] = {0xFF01,24,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_9 [] = {0xFF01,24,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_18 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1232 [] = {
g_atype1232_0,
g_atype1232_1,
g_atype1232_2,
g_atype1232_3,
g_atype1232_4,
g_atype1232_5,
g_atype1232_6,
g_atype1232_7,
g_atype1232_8,
g_atype1232_9,
g_atype1232_10,
g_atype1232_11,
g_atype1232_12,
g_atype1232_13,
g_atype1232_14,
g_atype1232_15,
g_atype1232_16,
g_atype1232_17,
g_atype1232_18,
};

static const long offsets1232 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1233[];
static const uint32 types1233 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1233 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1233_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_1 [] = {0xFF01,1097,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_2 [] = {1162,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_3 [] = {254,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_4 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_5 [] = {0xFF01,712,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_8 [] = {0xFF01,23,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_9 [] = {0xFF01,23,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_10 [] = {18,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_19 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1233 [] = {
g_atype1233_0,
g_atype1233_1,
g_atype1233_2,
g_atype1233_3,
g_atype1233_4,
g_atype1233_5,
g_atype1233_6,
g_atype1233_7,
g_atype1233_8,
g_atype1233_9,
g_atype1233_10,
g_atype1233_11,
g_atype1233_12,
g_atype1233_13,
g_atype1233_14,
g_atype1233_15,
g_atype1233_16,
g_atype1233_17,
g_atype1233_18,
g_atype1233_19,
};

static const long offsets1233 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1234[];
static const uint32 types1234 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1234 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1234_0 [] = {254,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_1 [] = {0xFF01,1098,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_2 [] = {1163,0xFFF8,1,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_3 [] = {255,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_4 [] = {0xFF01,712,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_5 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_8 [] = {0xFF01,23,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_9 [] = {0xFF01,24,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_10 [] = {19,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1234_19 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1234 [] = {
g_atype1234_0,
g_atype1234_1,
g_atype1234_2,
g_atype1234_3,
g_atype1234_4,
g_atype1234_5,
g_atype1234_6,
g_atype1234_7,
g_atype1234_8,
g_atype1234_9,
g_atype1234_10,
g_atype1234_11,
g_atype1234_12,
g_atype1234_13,
g_atype1234_14,
g_atype1234_15,
g_atype1234_16,
g_atype1234_17,
g_atype1234_18,
g_atype1234_19,
};

static const long offsets1234 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1235[];
static const uint32 types1235 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1235 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1235_0 [] = {257,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_1 [] = {0xFF01,1099,903,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_2 [] = {1164,903,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_3 [] = {254,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_4 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_5 [] = {0xFF01,712,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_8 [] = {0xFF01,25,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_9 [] = {0xFF01,23,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_10 [] = {18,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1235_19 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1235 [] = {
g_atype1235_0,
g_atype1235_1,
g_atype1235_2,
g_atype1235_3,
g_atype1235_4,
g_atype1235_5,
g_atype1235_6,
g_atype1235_7,
g_atype1235_8,
g_atype1235_9,
g_atype1235_10,
g_atype1235_11,
g_atype1235_12,
g_atype1235_13,
g_atype1235_14,
g_atype1235_15,
g_atype1235_16,
g_atype1235_17,
g_atype1235_18,
g_atype1235_19,
};

static const long offsets1235 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1236[];
static const uint32 types1236 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1236 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1236_0 [] = {259,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_1 [] = {0xFF01,1100,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_2 [] = {1165,879,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_3 [] = {258,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_4 [] = {0xFF01,715,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_5 [] = {0xFF01,720,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_8 [] = {0xFF01,26,879,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_9 [] = {0xFF01,27,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_10 [] = {20,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1236_19 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1236 [] = {
g_atype1236_0,
g_atype1236_1,
g_atype1236_2,
g_atype1236_3,
g_atype1236_4,
g_atype1236_5,
g_atype1236_6,
g_atype1236_7,
g_atype1236_8,
g_atype1236_9,
g_atype1236_10,
g_atype1236_11,
g_atype1236_12,
g_atype1236_13,
g_atype1236_14,
g_atype1236_15,
g_atype1236_16,
g_atype1236_17,
g_atype1236_18,
g_atype1236_19,
};

static const long offsets1236 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1237[];
static const uint32 types1237 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1237 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1237_0 [] = {255,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_1 [] = {0xFF01,1101,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_2 [] = {1166,873,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_3 [] = {255,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_5 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_8 [] = {0xFF01,24,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_9 [] = {0xFF01,24,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_10 [] = {19,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1237_19 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1237 [] = {
g_atype1237_0,
g_atype1237_1,
g_atype1237_2,
g_atype1237_3,
g_atype1237_4,
g_atype1237_5,
g_atype1237_6,
g_atype1237_7,
g_atype1237_8,
g_atype1237_9,
g_atype1237_10,
g_atype1237_11,
g_atype1237_12,
g_atype1237_13,
g_atype1237_14,
g_atype1237_15,
g_atype1237_16,
g_atype1237_17,
g_atype1237_18,
g_atype1237_19,
};

static const long offsets1237 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1238[];
static const uint32 types1238 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1238 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1238_0 [] = {254,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_1 [] = {0xFF01,1097,0xFF01,950,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_2 [] = {1162,0xFF01,950,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_3 [] = {254,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_4 [] = {0xFF01,712,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_5 [] = {0xFF01,712,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_8 [] = {0xFF01,23,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_9 [] = {0xFF01,23,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_10 [] = {18,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1238_19 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1238 [] = {
g_atype1238_0,
g_atype1238_1,
g_atype1238_2,
g_atype1238_3,
g_atype1238_4,
g_atype1238_5,
g_atype1238_6,
g_atype1238_7,
g_atype1238_8,
g_atype1238_9,
g_atype1238_10,
g_atype1238_11,
g_atype1238_12,
g_atype1238_13,
g_atype1238_14,
g_atype1238_15,
g_atype1238_16,
g_atype1238_17,
g_atype1238_18,
g_atype1238_19,
};

static const long offsets1238 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1239[];
static const uint32 types1239 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1239 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1239_0 [] = {254,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_1 [] = {0xFF01,1097,0xFF01,950,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_2 [] = {1162,0xFF01,950,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_3 [] = {254,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_4 [] = {0xFF01,712,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_5 [] = {0xFF01,712,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_8 [] = {0xFF01,23,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_9 [] = {0xFF01,23,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_10 [] = {18,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1239_19 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1239 [] = {
g_atype1239_0,
g_atype1239_1,
g_atype1239_2,
g_atype1239_3,
g_atype1239_4,
g_atype1239_5,
g_atype1239_6,
g_atype1239_7,
g_atype1239_8,
g_atype1239_9,
g_atype1239_10,
g_atype1239_11,
g_atype1239_12,
g_atype1239_13,
g_atype1239_14,
g_atype1239_15,
g_atype1239_16,
g_atype1239_17,
g_atype1239_18,
g_atype1239_19,
};

static const long offsets1239 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1241[];
static const uint32 types1241 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1241 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1241_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1241_1 [] = {0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1241 [] = {
g_atype1241_0,
g_atype1241_1,
};

static const long offsets1241 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1242[];
static const uint32 types1242 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1242 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1242_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1242_1 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1242_2 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1242_3 [] = {69,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1242_4 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1242_5 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1242_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1242_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1242_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1242_9 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1242_10 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1242 [] = {
g_atype1242_0,
g_atype1242_1,
g_atype1242_2,
g_atype1242_3,
g_atype1242_4,
g_atype1242_5,
g_atype1242_6,
g_atype1242_7,
g_atype1242_8,
g_atype1242_9,
g_atype1242_10,
};

static const long offsets1242 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
+ @PTROFF(6,2,0,1,0,0),
+ @PTROFF(6,2,0,1,0,1),
};

extern const char *names1243[];
static const uint32 types1243 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1243 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1243_0 [] = {0xFF01,1181,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1243_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1243_2 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1243_3 [] = {0xFF01,1181,0xFF01,153,0xFFFF};
static const EIF_TYPE_INDEX g_atype1243_4 [] = {0xFF01,1181,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1243_5 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1243_6 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1243_7 [] = {1181,0xFF01,153,0xFFFF};
static const EIF_TYPE_INDEX g_atype1243_8 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1243 [] = {
g_atype1243_0,
g_atype1243_1,
g_atype1243_2,
g_atype1243_3,
g_atype1243_4,
g_atype1243_5,
g_atype1243_6,
g_atype1243_7,
g_atype1243_8,
};

static const long offsets1243 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
};

extern const char *names1244[];
static const uint32 types1244 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1244 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1244_0 [] = {0xFF01,1181,0xFF01,1188,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_2 [] = {0xFF01,1274,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_3 [] = {0xFF01,1181,0xFF01,153,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_4 [] = {0xFF01,1181,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_5 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_6 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_7 [] = {1181,0xFF01,153,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_8 [] = {0xFF01,299,0xFFFF};
static const EIF_TYPE_INDEX g_atype1244_9 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1244 [] = {
g_atype1244_0,
g_atype1244_1,
g_atype1244_2,
g_atype1244_3,
g_atype1244_4,
g_atype1244_5,
g_atype1244_6,
g_atype1244_7,
g_atype1244_8,
g_atype1244_9,
};

static const long offsets1244 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
};

extern const char *names1245[];
static const uint32 types1245 [] =
{
SK_REF,
};

static const uint16 attr_flags1245 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1245_0 [] = {0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1245 [] = {
g_atype1245_0,
};

static const long offsets1245 [] =
{
0,
};

extern const char *names1246[];
static const uint32 types1246 [] =
{
SK_REF,
};

static const uint16 attr_flags1246 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1246_0 [] = {0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1246 [] = {
g_atype1246_0,
};

static const long offsets1246 [] =
{
0,
};

extern const char *names1247[];
static const uint32 types1247 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1247 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1247_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_1 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_2 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_3 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_4 [] = {17,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_5 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_6 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_7 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_11 [] = {888,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_12 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_13 [] = {885,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_14 [] = {876,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_15 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_19 [] = {891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_20 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_21 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_22 [] = {870,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_23 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1247 [] = {
g_atype1247_0,
g_atype1247_1,
g_atype1247_2,
g_atype1247_3,
g_atype1247_4,
g_atype1247_5,
g_atype1247_6,
g_atype1247_7,
g_atype1247_8,
g_atype1247_9,
g_atype1247_10,
g_atype1247_11,
g_atype1247_12,
g_atype1247_13,
g_atype1247_14,
g_atype1247_15,
g_atype1247_16,
g_atype1247_17,
g_atype1247_18,
g_atype1247_19,
g_atype1247_20,
g_atype1247_21,
g_atype1247_22,
g_atype1247_23,
};

static const long offsets1247 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1248[];
static const uint32 types1248 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1248 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1248_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_1 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_2 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_3 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_4 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_5 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_6 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_9 [] = {888,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_11 [] = {885,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_12 [] = {876,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_13 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_17 [] = {891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_18 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_19 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_20 [] = {870,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_21 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1248 [] = {
g_atype1248_0,
g_atype1248_1,
g_atype1248_2,
g_atype1248_3,
g_atype1248_4,
g_atype1248_5,
g_atype1248_6,
g_atype1248_7,
g_atype1248_8,
g_atype1248_9,
g_atype1248_10,
g_atype1248_11,
g_atype1248_12,
g_atype1248_13,
g_atype1248_14,
g_atype1248_15,
g_atype1248_16,
g_atype1248_17,
g_atype1248_18,
g_atype1248_19,
g_atype1248_20,
g_atype1248_21,
};

static const long offsets1248 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1249[];
static const uint32 types1249 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1249 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1249_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_1 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_2 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_3 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_4 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_5 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_6 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_9 [] = {888,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_11 [] = {885,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_12 [] = {876,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_13 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_17 [] = {891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_18 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_19 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_20 [] = {870,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_21 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1249 [] = {
g_atype1249_0,
g_atype1249_1,
g_atype1249_2,
g_atype1249_3,
g_atype1249_4,
g_atype1249_5,
g_atype1249_6,
g_atype1249_7,
g_atype1249_8,
g_atype1249_9,
g_atype1249_10,
g_atype1249_11,
g_atype1249_12,
g_atype1249_13,
g_atype1249_14,
g_atype1249_15,
g_atype1249_16,
g_atype1249_17,
g_atype1249_18,
g_atype1249_19,
g_atype1249_20,
g_atype1249_21,
};

static const long offsets1249 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1250[];
static const uint32 types1250 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1250 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1250_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_1 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_2 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_3 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_4 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_5 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_6 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_9 [] = {888,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_10 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_11 [] = {885,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_12 [] = {876,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_13 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_17 [] = {891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_18 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_19 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_20 [] = {870,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_21 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1250 [] = {
g_atype1250_0,
g_atype1250_1,
g_atype1250_2,
g_atype1250_3,
g_atype1250_4,
g_atype1250_5,
g_atype1250_6,
g_atype1250_7,
g_atype1250_8,
g_atype1250_9,
g_atype1250_10,
g_atype1250_11,
g_atype1250_12,
g_atype1250_13,
g_atype1250_14,
g_atype1250_15,
g_atype1250_16,
g_atype1250_17,
g_atype1250_18,
g_atype1250_19,
g_atype1250_20,
g_atype1250_21,
};

static const long offsets1250 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1251[];
static const uint32 types1251 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags1251 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1251_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_1 [] = {70,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_2 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_3 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1251_4 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1251 [] = {
g_atype1251_0,
g_atype1251_1,
g_atype1251_2,
g_atype1251_3,
g_atype1251_4,
};

static const long offsets1251 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1252[];
static const uint32 types1252 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1252 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1252_0 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_1 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_2 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_3 [] = {17,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_4 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_5 [] = {70,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_6 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_7 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_8 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_11 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_12 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_13 [] = {888,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_14 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_15 [] = {885,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_16 [] = {876,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_17 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_19 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_20 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_21 [] = {891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_22 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_23 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_24 [] = {870,0xFFFF};
static const EIF_TYPE_INDEX g_atype1252_25 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1252 [] = {
g_atype1252_0,
g_atype1252_1,
g_atype1252_2,
g_atype1252_3,
g_atype1252_4,
g_atype1252_5,
g_atype1252_6,
g_atype1252_7,
g_atype1252_8,
g_atype1252_9,
g_atype1252_10,
g_atype1252_11,
g_atype1252_12,
g_atype1252_13,
g_atype1252_14,
g_atype1252_15,
g_atype1252_16,
g_atype1252_17,
g_atype1252_18,
g_atype1252_19,
g_atype1252_20,
g_atype1252_21,
g_atype1252_22,
g_atype1252_23,
g_atype1252_24,
g_atype1252_25,
};

static const long offsets1252 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @CHROFF(7,6),
+ @CHROFF(7,7),
+ @I16OFF(7,8,0),
+ @I16OFF(7,8,1),
+ @LNGOFF(7,8,2,0),
+ @LNGOFF(7,8,2,1),
+ @LNGOFF(7,8,2,2),
+ @LNGOFF(7,8,2,3),
+ @R32OFF(7,8,2,4,0),
+ @PTROFF(7,8,2,4,1,0),
+ @I64OFF(7,8,2,4,1,1,0),
+ @I64OFF(7,8,2,4,1,1,1),
+ @R64OFF(7,8,2,4,1,1,2,0),
};

extern const char *names1253[];
static const uint32 types1253 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1253 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1253_0 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_1 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_2 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_3 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_4 [] = {70,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_5 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_6 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_7 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_11 [] = {888,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_12 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_13 [] = {885,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_14 [] = {876,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_15 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_19 [] = {891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_20 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_21 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_22 [] = {870,0xFFFF};
static const EIF_TYPE_INDEX g_atype1253_23 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1253 [] = {
g_atype1253_0,
g_atype1253_1,
g_atype1253_2,
g_atype1253_3,
g_atype1253_4,
g_atype1253_5,
g_atype1253_6,
g_atype1253_7,
g_atype1253_8,
g_atype1253_9,
g_atype1253_10,
g_atype1253_11,
g_atype1253_12,
g_atype1253_13,
g_atype1253_14,
g_atype1253_15,
g_atype1253_16,
g_atype1253_17,
g_atype1253_18,
g_atype1253_19,
g_atype1253_20,
g_atype1253_21,
g_atype1253_22,
g_atype1253_23,
};

static const long offsets1253 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1254[];
static const uint32 types1254 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1254 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1254_0 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_1 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_2 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_3 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_4 [] = {70,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_5 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_6 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_7 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_11 [] = {888,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_12 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_13 [] = {885,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_14 [] = {876,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_15 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_19 [] = {891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_20 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_21 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_22 [] = {870,0xFFFF};
static const EIF_TYPE_INDEX g_atype1254_23 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1254 [] = {
g_atype1254_0,
g_atype1254_1,
g_atype1254_2,
g_atype1254_3,
g_atype1254_4,
g_atype1254_5,
g_atype1254_6,
g_atype1254_7,
g_atype1254_8,
g_atype1254_9,
g_atype1254_10,
g_atype1254_11,
g_atype1254_12,
g_atype1254_13,
g_atype1254_14,
g_atype1254_15,
g_atype1254_16,
g_atype1254_17,
g_atype1254_18,
g_atype1254_19,
g_atype1254_20,
g_atype1254_21,
g_atype1254_22,
g_atype1254_23,
};

static const long offsets1254 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1255[];
static const uint32 types1255 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1255 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1255_0 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_1 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_2 [] = {253,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_3 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_4 [] = {70,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_5 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_6 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_7 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_11 [] = {888,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_12 [] = {867,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_13 [] = {885,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_14 [] = {876,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_15 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_19 [] = {891,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_20 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_21 [] = {879,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_22 [] = {870,0xFFFF};
static const EIF_TYPE_INDEX g_atype1255_23 [] = {894,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1255 [] = {
g_atype1255_0,
g_atype1255_1,
g_atype1255_2,
g_atype1255_3,
g_atype1255_4,
g_atype1255_5,
g_atype1255_6,
g_atype1255_7,
g_atype1255_8,
g_atype1255_9,
g_atype1255_10,
g_atype1255_11,
g_atype1255_12,
g_atype1255_13,
g_atype1255_14,
g_atype1255_15,
g_atype1255_16,
g_atype1255_17,
g_atype1255_18,
g_atype1255_19,
g_atype1255_20,
g_atype1255_21,
g_atype1255_22,
g_atype1255_23,
};

static const long offsets1255 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1257[];
static const uint32 types1257 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1257 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1257_0 [] = {0xFF01,720,882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1257_1 [] = {0xFF01,720,882,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1257 [] = {
g_atype1257_0,
g_atype1257_1,
};

static const long offsets1257 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1258[];
static const uint32 types1258 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1258 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1258_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_4 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_5 [] = {1291,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_6 [] = {1291,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_7 [] = {0xFF01,1176,0xFF01,1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_8 [] = {0xFF01,1176,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_9 [] = {0xFF01,1176,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_11 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1258 [] = {
g_atype1258_0,
g_atype1258_1,
g_atype1258_2,
g_atype1258_3,
g_atype1258_4,
g_atype1258_5,
g_atype1258_6,
g_atype1258_7,
g_atype1258_8,
g_atype1258_9,
g_atype1258_10,
g_atype1258_11,
};

static const long offsets1258 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @CHROFF(10,0),
+ @CHROFF(10,1),
};

extern const char *names1259[];
static const uint32 types1259 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1259 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1259_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_5 [] = {1349,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_6 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_7 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_8 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_9 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_10 [] = {1291,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_11 [] = {1291,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_12 [] = {0xFF01,1176,0xFF01,1240,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_13 [] = {0xFF01,1176,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_14 [] = {0xFF01,1176,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_15 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_16 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1259_17 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1259 [] = {
g_atype1259_0,
g_atype1259_1,
g_atype1259_2,
g_atype1259_3,
g_atype1259_4,
g_atype1259_5,
g_atype1259_6,
g_atype1259_7,
g_atype1259_8,
g_atype1259_9,
g_atype1259_10,
g_atype1259_11,
g_atype1259_12,
g_atype1259_13,
g_atype1259_14,
g_atype1259_15,
g_atype1259_16,
g_atype1259_17,
};

static const long offsets1259 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
+ @CHROFF(15,0),
+ @CHROFF(15,1),
+ @CHROFF(15,2),
};

extern const char *names1260[];
static const uint32 types1260 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1260 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1260_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1260_2 [] = {950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1260 [] = {
g_atype1260_0,
g_atype1260_1,
g_atype1260_2,
};

static const long offsets1260 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1261[];
static const uint32 types1261 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1261 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1261_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_1 [] = {0xFF01,1232,0xFF01,939,0xFF01,0xFFF9,1,864,0xFF01,1286,0xFF01,1373,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1261 [] = {
g_atype1261_0,
g_atype1261_1,
};

static const long offsets1261 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1262[];
static const uint32 types1262 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1262 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1262_0 [] = {307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_1 [] = {307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_2 [] = {307,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_3 [] = {803,0xFF01,0xFFF9,2,864,0xFF01,307,809,0xFF01,0xFFF9,2,864,0xFF01,309,0xFF01,309,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_10 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1262 [] = {
g_atype1262_0,
g_atype1262_1,
g_atype1262_2,
g_atype1262_3,
g_atype1262_4,
g_atype1262_5,
g_atype1262_6,
g_atype1262_7,
g_atype1262_8,
g_atype1262_9,
g_atype1262_10,
};

static const long offsets1262 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @LNGOFF(4,5,0,0),
+ @LNGOFF(4,5,0,1),
};

extern const char *names1264[];
static const uint32 types1264 [] =
{
SK_REF,
};

static const uint16 attr_flags1264 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1264_0 [] = {0xFF01,193,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1264 [] = {
g_atype1264_0,
};

static const long offsets1264 [] =
{
0,
};

extern const char *names1265[];
static const uint32 types1265 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1265 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1265_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1265_1 [] = {994,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1265 [] = {
g_atype1265_0,
g_atype1265_1,
};

static const long offsets1265 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1266[];
static const uint32 types1266 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1266 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1266_0 [] = {0xFF01,193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_2 [] = {994,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1266_5 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1266 [] = {
g_atype1266_0,
g_atype1266_1,
g_atype1266_2,
g_atype1266_3,
g_atype1266_4,
g_atype1266_5,
};

static const long offsets1266 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
};

extern const char *names1267[];
static const uint32 types1267 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1267 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1267_0 [] = {0xFF01,193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_2 [] = {994,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_3 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_4 [] = {0xFF01,1206,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_10 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1267 [] = {
g_atype1267_0,
g_atype1267_1,
g_atype1267_2,
g_atype1267_3,
g_atype1267_4,
g_atype1267_5,
g_atype1267_6,
g_atype1267_7,
g_atype1267_8,
g_atype1267_9,
g_atype1267_10,
};

static const long offsets1267 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
};

extern const char *names1268[];
static const uint32 types1268 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1268 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1268_0 [] = {0xFF01,193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1268_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1268_2 [] = {994,0xFFFF};
static const EIF_TYPE_INDEX g_atype1268_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1268_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1268_5 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1268 [] = {
g_atype1268_0,
g_atype1268_1,
g_atype1268_2,
g_atype1268_3,
g_atype1268_4,
g_atype1268_5,
};

static const long offsets1268 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
};

extern const char *names1274[];
static const uint32 types1274 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1274 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1274_0 [] = {0xFF01,997,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_1 [] = {0xFF01,997,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_2 [] = {0xFF01,997,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1274 [] = {
g_atype1274_0,
g_atype1274_1,
g_atype1274_2,
};

static const long offsets1274 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1275[];
static const uint32 types1275 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1275 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1275_0 [] = {0xFF01,997,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_1 [] = {0xFF01,997,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_2 [] = {0xFF01,997,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_3 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1275 [] = {
g_atype1275_0,
g_atype1275_1,
g_atype1275_2,
g_atype1275_3,
};

static const long offsets1275 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
};

extern const char *names1277[];
static const uint32 types1277 [] =
{
SK_REF,
};

static const uint16 attr_flags1277 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1277_0 [] = {0xFF01,1284,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1277 [] = {
g_atype1277_0,
};

static const long offsets1277 [] =
{
0,
};

extern const char *names1278[];
static const uint32 types1278 [] =
{
SK_REF,
};

static const uint16 attr_flags1278 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1278_0 [] = {0xFF01,1284,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1278 [] = {
g_atype1278_0,
};

static const long offsets1278 [] =
{
0,
};

extern const char *names1279[];
static const uint32 types1279 [] =
{
SK_REF,
};

static const uint16 attr_flags1279 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1279_0 [] = {0xFF01,1284,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1279 [] = {
g_atype1279_0,
};

static const long offsets1279 [] =
{
0,
};

extern const char *names1280[];
static const uint32 types1280 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1280 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1280_0 [] = {0xFF01,1284,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_1 [] = {0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1280 [] = {
g_atype1280_0,
g_atype1280_1,
};

static const long offsets1280 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1281[];
static const uint32 types1281 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1281 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1281_0 [] = {0xFF01,1284,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_2 [] = {0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1281 [] = {
g_atype1281_0,
g_atype1281_1,
g_atype1281_2,
};

static const long offsets1281 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1282[];
static const uint32 types1282 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1282 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1282_0 [] = {0xFF01,1284,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_1 [] = {0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1282 [] = {
g_atype1282_0,
g_atype1282_1,
};

static const long offsets1282 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1283[];
static const uint32 types1283 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1283 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1283_0 [] = {0xFF01,1284,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_2 [] = {0xFF01,984,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1283 [] = {
g_atype1283_0,
g_atype1283_1,
g_atype1283_2,
};

static const long offsets1283 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1284[];
static const uint32 types1284 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1284 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1284_0 [] = {0xFF01,1284,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_2 [] = {0xFF01,984,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_3 [] = {0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1284 [] = {
g_atype1284_0,
g_atype1284_1,
g_atype1284_2,
g_atype1284_3,
};

static const long offsets1284 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1285[];
static const uint32 types1285 [] =
{
SK_REF,
};

static const uint16 attr_flags1285 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1285_0 [] = {0xFF01,1186,0xFF01,1276,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1285 [] = {
g_atype1285_0,
};

static const long offsets1285 [] =
{
0,
};

extern const char *names1286[];
static const uint32 types1286 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1286 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1286_0 [] = {0xFF01,1186,0xFF01,1277,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_1 [] = {0xFF01,1286,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1286 [] = {
g_atype1286_0,
g_atype1286_1,
};

static const long offsets1286 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1287[];
static const uint32 types1287 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1287 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1287_0 [] = {0xFF01,1284,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_2 [] = {0xFF01,984,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_3 [] = {0xFF01,1186,0xFF01,1278,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1287 [] = {
g_atype1287_0,
g_atype1287_1,
g_atype1287_2,
g_atype1287_3,
};

static const long offsets1287 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1288[];
static const uint32 types1288 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1288 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1288_0 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1288 [] = {
g_atype1288_0,
g_atype1288_1,
g_atype1288_2,
g_atype1288_3,
};

static const long offsets1288 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1289[];
static const uint32 types1289 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1289 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1289_0 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_1 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1289 [] = {
g_atype1289_0,
g_atype1289_1,
g_atype1289_2,
g_atype1289_3,
};

static const long offsets1289 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1290[];
static const uint32 types1290 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1290 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1290_0 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_1 [] = {942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1290 [] = {
g_atype1290_0,
g_atype1290_1,
g_atype1290_2,
g_atype1290_3,
g_atype1290_4,
g_atype1290_5,
};

static const long offsets1290 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names1291[];
static const uint32 types1291 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1291 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1291_0 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_1 [] = {942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_2 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_3 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_4 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_13 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1291 [] = {
g_atype1291_0,
g_atype1291_1,
g_atype1291_2,
g_atype1291_3,
g_atype1291_4,
g_atype1291_5,
g_atype1291_6,
g_atype1291_7,
g_atype1291_8,
g_atype1291_9,
g_atype1291_10,
g_atype1291_11,
g_atype1291_12,
g_atype1291_13,
};

static const long offsets1291 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
+ @LNGOFF(5,1,0,3),
+ @LNGOFF(5,1,0,4),
+ @LNGOFF(5,1,0,5),
+ @LNGOFF(5,1,0,6),
+ @LNGOFF(5,1,0,7),
};

extern const char *names1292[];
static const uint32 types1292 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1292 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1292_0 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_1 [] = {942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_2 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1292_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1292 [] = {
g_atype1292_0,
g_atype1292_1,
g_atype1292_2,
g_atype1292_3,
g_atype1292_4,
g_atype1292_5,
};

static const long offsets1292 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names1293[];
static const uint32 types1293 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1293 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1293_0 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_1 [] = {942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_2 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_3 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_4 [] = {739,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_7 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_8 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_9 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_10 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_13 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1293 [] = {
g_atype1293_0,
g_atype1293_1,
g_atype1293_2,
g_atype1293_3,
g_atype1293_4,
g_atype1293_5,
g_atype1293_6,
g_atype1293_7,
g_atype1293_8,
g_atype1293_9,
g_atype1293_10,
g_atype1293_11,
g_atype1293_12,
g_atype1293_13,
};

static const long offsets1293 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
+ @LNGOFF(5,1,0,3),
+ @LNGOFF(5,1,0,4),
+ @LNGOFF(5,1,0,5),
+ @LNGOFF(5,1,0,6),
+ @LNGOFF(5,1,0,7),
};

extern const char *names1294[];
static const uint32 types1294 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1294 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1294_0 [] = {0xFF01,1200,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1294_1 [] = {0xFF01,1187,0xFF01,1232,0xFF01,950,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1294_2 [] = {0xFF01,1220,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1294_3 [] = {950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1294 [] = {
g_atype1294_0,
g_atype1294_1,
g_atype1294_2,
g_atype1294_3,
};

static const long offsets1294 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1295[];
static const uint32 types1295 [] =
{
SK_REF,
};

static const uint16 attr_flags1295 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1295_0 [] = {0xFF01,1187,0xFF01,1232,0xFF01,950,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1295 [] = {
g_atype1295_0,
};

static const long offsets1295 [] =
{
0,
};

extern const char *names1297[];
static const uint32 types1297 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags1297 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1297_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_2 [] = {1181,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_3 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_4 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_5 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1297 [] = {
g_atype1297_0,
g_atype1297_1,
g_atype1297_2,
g_atype1297_3,
g_atype1297_4,
g_atype1297_5,
};

static const long offsets1297 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
};

extern const char *names1298[];
static const uint32 types1298 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1298 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1298_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_1 [] = {188,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1298 [] = {
g_atype1298_0,
g_atype1298_1,
};

static const long offsets1298 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1300[];
static const uint32 types1300 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1300 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1300_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_1 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_2 [] = {0xFF01,831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1300 [] = {
g_atype1300_0,
g_atype1300_1,
g_atype1300_2,
g_atype1300_3,
};

static const long offsets1300 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
};

extern const char *names1301[];
static const uint32 types1301 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1301 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1301_0 [] = {0xFF01,177,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_1 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_2 [] = {716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_3 [] = {717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_5 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_8 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_9 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_10 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_11 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_12 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_13 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_14 [] = {0xFF01,8,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_15 [] = {0xFF01,1273,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_16 [] = {0xFF01,1220,0xFF01,831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_17 [] = {0xFF01,1232,0xFF01,831,0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_18 [] = {0xFF01,1220,0xFF01,831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_19 [] = {0xFF01,1232,0xFF01,831,0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_20 [] = {0xFF01,1232,0xFF01,947,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_21 [] = {0xFF01,1206,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_22 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_23 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_24 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_25 [] = {0xFF01,831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_26 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_27 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_28 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_29 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_30 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_31 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_32 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_33 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_34 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_35 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_36 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_37 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_38 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_39 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_40 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_41 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_42 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_43 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_44 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_45 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_46 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_47 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_48 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_49 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_50 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_51 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_52 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_53 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_54 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_55 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_56 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_57 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_58 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1301 [] = {
g_atype1301_0,
g_atype1301_1,
g_atype1301_2,
g_atype1301_3,
g_atype1301_4,
g_atype1301_5,
g_atype1301_6,
g_atype1301_7,
g_atype1301_8,
g_atype1301_9,
g_atype1301_10,
g_atype1301_11,
g_atype1301_12,
g_atype1301_13,
g_atype1301_14,
g_atype1301_15,
g_atype1301_16,
g_atype1301_17,
g_atype1301_18,
g_atype1301_19,
g_atype1301_20,
g_atype1301_21,
g_atype1301_22,
g_atype1301_23,
g_atype1301_24,
g_atype1301_25,
g_atype1301_26,
g_atype1301_27,
g_atype1301_28,
g_atype1301_29,
g_atype1301_30,
g_atype1301_31,
g_atype1301_32,
g_atype1301_33,
g_atype1301_34,
g_atype1301_35,
g_atype1301_36,
g_atype1301_37,
g_atype1301_38,
g_atype1301_39,
g_atype1301_40,
g_atype1301_41,
g_atype1301_42,
g_atype1301_43,
g_atype1301_44,
g_atype1301_45,
g_atype1301_46,
g_atype1301_47,
g_atype1301_48,
g_atype1301_49,
g_atype1301_50,
g_atype1301_51,
g_atype1301_52,
g_atype1301_53,
g_atype1301_54,
g_atype1301_55,
g_atype1301_56,
g_atype1301_57,
g_atype1301_58,
};

static const long offsets1301 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
+ @CHROFF(28,0),
+ @CHROFF(28,1),
+ @CHROFF(28,2),
+ @CHROFF(28,3),
+ @LNGOFF(28,4,0,0),
+ @LNGOFF(28,4,0,1),
+ @LNGOFF(28,4,0,2),
+ @LNGOFF(28,4,0,3),
+ @LNGOFF(28,4,0,4),
+ @LNGOFF(28,4,0,5),
+ @LNGOFF(28,4,0,6),
+ @LNGOFF(28,4,0,7),
+ @LNGOFF(28,4,0,8),
+ @LNGOFF(28,4,0,9),
+ @LNGOFF(28,4,0,10),
+ @LNGOFF(28,4,0,11),
+ @LNGOFF(28,4,0,12),
+ @LNGOFF(28,4,0,13),
+ @LNGOFF(28,4,0,14),
+ @LNGOFF(28,4,0,15),
+ @LNGOFF(28,4,0,16),
+ @LNGOFF(28,4,0,17),
+ @LNGOFF(28,4,0,18),
+ @LNGOFF(28,4,0,19),
+ @LNGOFF(28,4,0,20),
+ @LNGOFF(28,4,0,21),
+ @LNGOFF(28,4,0,22),
+ @LNGOFF(28,4,0,23),
+ @LNGOFF(28,4,0,24),
+ @LNGOFF(28,4,0,25),
+ @LNGOFF(28,4,0,26),
};

extern const char *names1302[];
static const uint32 types1302 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1302 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1302_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_1 [] = {0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1302 [] = {
g_atype1302_0,
g_atype1302_1,
};

static const long offsets1302 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1303[];
static const uint32 types1303 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1303 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1303_0 [] = {0xFF01,177,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_1 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_2 [] = {716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_3 [] = {717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_5 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_8 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_9 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_10 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_11 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_12 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_13 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_15 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_16 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_17 [] = {86,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_18 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_19 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_20 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_21 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_22 [] = {0xFF01,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_23 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_24 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_25 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_26 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_27 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_28 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_29 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_30 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_31 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_32 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_33 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_34 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_35 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_36 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_37 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_38 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_39 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_40 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_41 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_42 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_43 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_44 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_45 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_46 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1303 [] = {
g_atype1303_0,
g_atype1303_1,
g_atype1303_2,
g_atype1303_3,
g_atype1303_4,
g_atype1303_5,
g_atype1303_6,
g_atype1303_7,
g_atype1303_8,
g_atype1303_9,
g_atype1303_10,
g_atype1303_11,
g_atype1303_12,
g_atype1303_13,
g_atype1303_14,
g_atype1303_15,
g_atype1303_16,
g_atype1303_17,
g_atype1303_18,
g_atype1303_19,
g_atype1303_20,
g_atype1303_21,
g_atype1303_22,
g_atype1303_23,
g_atype1303_24,
g_atype1303_25,
g_atype1303_26,
g_atype1303_27,
g_atype1303_28,
g_atype1303_29,
g_atype1303_30,
g_atype1303_31,
g_atype1303_32,
g_atype1303_33,
g_atype1303_34,
g_atype1303_35,
g_atype1303_36,
g_atype1303_37,
g_atype1303_38,
g_atype1303_39,
g_atype1303_40,
g_atype1303_41,
g_atype1303_42,
g_atype1303_43,
g_atype1303_44,
g_atype1303_45,
g_atype1303_46,
};

static const long offsets1303 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
+ @CHROFF(23,0),
+ @CHROFF(23,1),
+ @CHROFF(23,2),
+ @LNGOFF(23,3,0,0),
+ @LNGOFF(23,3,0,1),
+ @LNGOFF(23,3,0,2),
+ @LNGOFF(23,3,0,3),
+ @LNGOFF(23,3,0,4),
+ @LNGOFF(23,3,0,5),
+ @LNGOFF(23,3,0,6),
+ @LNGOFF(23,3,0,7),
+ @LNGOFF(23,3,0,8),
+ @LNGOFF(23,3,0,9),
+ @LNGOFF(23,3,0,10),
+ @LNGOFF(23,3,0,11),
+ @LNGOFF(23,3,0,12),
+ @LNGOFF(23,3,0,13),
+ @LNGOFF(23,3,0,14),
+ @LNGOFF(23,3,0,15),
+ @LNGOFF(23,3,0,16),
+ @LNGOFF(23,3,0,17),
+ @LNGOFF(23,3,0,18),
+ @LNGOFF(23,3,0,19),
+ @LNGOFF(23,3,0,20),
};

extern const char *names1304[];
static const uint32 types1304 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1304 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1304_0 [] = {0xFF01,177,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_1 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_2 [] = {716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_3 [] = {717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_5 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_8 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_9 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_10 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_11 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_12 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_13 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_15 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_16 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_17 [] = {86,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_18 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_19 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_20 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_21 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_22 [] = {0xFF01,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_23 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_24 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_25 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_26 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_27 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_28 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_29 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_30 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_31 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_32 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_33 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_34 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_35 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_36 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_37 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_38 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_39 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_40 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_41 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_42 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_43 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_44 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_45 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_46 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1304 [] = {
g_atype1304_0,
g_atype1304_1,
g_atype1304_2,
g_atype1304_3,
g_atype1304_4,
g_atype1304_5,
g_atype1304_6,
g_atype1304_7,
g_atype1304_8,
g_atype1304_9,
g_atype1304_10,
g_atype1304_11,
g_atype1304_12,
g_atype1304_13,
g_atype1304_14,
g_atype1304_15,
g_atype1304_16,
g_atype1304_17,
g_atype1304_18,
g_atype1304_19,
g_atype1304_20,
g_atype1304_21,
g_atype1304_22,
g_atype1304_23,
g_atype1304_24,
g_atype1304_25,
g_atype1304_26,
g_atype1304_27,
g_atype1304_28,
g_atype1304_29,
g_atype1304_30,
g_atype1304_31,
g_atype1304_32,
g_atype1304_33,
g_atype1304_34,
g_atype1304_35,
g_atype1304_36,
g_atype1304_37,
g_atype1304_38,
g_atype1304_39,
g_atype1304_40,
g_atype1304_41,
g_atype1304_42,
g_atype1304_43,
g_atype1304_44,
g_atype1304_45,
g_atype1304_46,
};

static const long offsets1304 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
+ @CHROFF(23,0),
+ @CHROFF(23,1),
+ @CHROFF(23,2),
+ @LNGOFF(23,3,0,0),
+ @LNGOFF(23,3,0,1),
+ @LNGOFF(23,3,0,2),
+ @LNGOFF(23,3,0,3),
+ @LNGOFF(23,3,0,4),
+ @LNGOFF(23,3,0,5),
+ @LNGOFF(23,3,0,6),
+ @LNGOFF(23,3,0,7),
+ @LNGOFF(23,3,0,8),
+ @LNGOFF(23,3,0,9),
+ @LNGOFF(23,3,0,10),
+ @LNGOFF(23,3,0,11),
+ @LNGOFF(23,3,0,12),
+ @LNGOFF(23,3,0,13),
+ @LNGOFF(23,3,0,14),
+ @LNGOFF(23,3,0,15),
+ @LNGOFF(23,3,0,16),
+ @LNGOFF(23,3,0,17),
+ @LNGOFF(23,3,0,18),
+ @LNGOFF(23,3,0,19),
+ @LNGOFF(23,3,0,20),
};

extern const char *names1305[];
static const uint32 types1305 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1305 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1305_0 [] = {0xFF01,177,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_1 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_2 [] = {716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_3 [] = {717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_5 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_8 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_9 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_10 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_11 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_12 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_13 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_15 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_16 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_17 [] = {86,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_18 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_19 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_20 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_21 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_22 [] = {0xFF01,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_23 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_24 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_25 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_26 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_27 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_28 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_29 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_30 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_31 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_32 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_33 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_34 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_35 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_36 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_37 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_38 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_39 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_40 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_41 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_42 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_43 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_44 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_45 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_46 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_47 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_48 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1305 [] = {
g_atype1305_0,
g_atype1305_1,
g_atype1305_2,
g_atype1305_3,
g_atype1305_4,
g_atype1305_5,
g_atype1305_6,
g_atype1305_7,
g_atype1305_8,
g_atype1305_9,
g_atype1305_10,
g_atype1305_11,
g_atype1305_12,
g_atype1305_13,
g_atype1305_14,
g_atype1305_15,
g_atype1305_16,
g_atype1305_17,
g_atype1305_18,
g_atype1305_19,
g_atype1305_20,
g_atype1305_21,
g_atype1305_22,
g_atype1305_23,
g_atype1305_24,
g_atype1305_25,
g_atype1305_26,
g_atype1305_27,
g_atype1305_28,
g_atype1305_29,
g_atype1305_30,
g_atype1305_31,
g_atype1305_32,
g_atype1305_33,
g_atype1305_34,
g_atype1305_35,
g_atype1305_36,
g_atype1305_37,
g_atype1305_38,
g_atype1305_39,
g_atype1305_40,
g_atype1305_41,
g_atype1305_42,
g_atype1305_43,
g_atype1305_44,
g_atype1305_45,
g_atype1305_46,
g_atype1305_47,
g_atype1305_48,
};

static const long offsets1305 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
+ @CHROFF(23,0),
+ @CHROFF(23,1),
+ @CHROFF(23,2),
+ @CHROFF(23,3),
+ @CHROFF(23,4),
+ @LNGOFF(23,5,0,0),
+ @LNGOFF(23,5,0,1),
+ @LNGOFF(23,5,0,2),
+ @LNGOFF(23,5,0,3),
+ @LNGOFF(23,5,0,4),
+ @LNGOFF(23,5,0,5),
+ @LNGOFF(23,5,0,6),
+ @LNGOFF(23,5,0,7),
+ @LNGOFF(23,5,0,8),
+ @LNGOFF(23,5,0,9),
+ @LNGOFF(23,5,0,10),
+ @LNGOFF(23,5,0,11),
+ @LNGOFF(23,5,0,12),
+ @LNGOFF(23,5,0,13),
+ @LNGOFF(23,5,0,14),
+ @LNGOFF(23,5,0,15),
+ @LNGOFF(23,5,0,16),
+ @LNGOFF(23,5,0,17),
+ @LNGOFF(23,5,0,18),
+ @LNGOFF(23,5,0,19),
+ @LNGOFF(23,5,0,20),
};

extern const char *names1306[];
static const uint32 types1306 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1306 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1306_0 [] = {0xFF01,177,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_1 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_2 [] = {716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_3 [] = {717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_5 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_8 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_9 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_10 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_11 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_12 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_13 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_15 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_16 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_17 [] = {86,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_18 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_19 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_20 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_21 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_22 [] = {0xFF01,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_23 [] = {0xFF01,86,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_24 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_25 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_26 [] = {1259,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_27 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_28 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_29 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_30 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_31 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_32 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_33 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_34 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_35 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_36 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_37 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_38 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_39 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_40 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_41 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_42 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_43 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_44 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_45 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_46 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_47 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_48 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_49 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_50 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_51 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1306 [] = {
g_atype1306_0,
g_atype1306_1,
g_atype1306_2,
g_atype1306_3,
g_atype1306_4,
g_atype1306_5,
g_atype1306_6,
g_atype1306_7,
g_atype1306_8,
g_atype1306_9,
g_atype1306_10,
g_atype1306_11,
g_atype1306_12,
g_atype1306_13,
g_atype1306_14,
g_atype1306_15,
g_atype1306_16,
g_atype1306_17,
g_atype1306_18,
g_atype1306_19,
g_atype1306_20,
g_atype1306_21,
g_atype1306_22,
g_atype1306_23,
g_atype1306_24,
g_atype1306_25,
g_atype1306_26,
g_atype1306_27,
g_atype1306_28,
g_atype1306_29,
g_atype1306_30,
g_atype1306_31,
g_atype1306_32,
g_atype1306_33,
g_atype1306_34,
g_atype1306_35,
g_atype1306_36,
g_atype1306_37,
g_atype1306_38,
g_atype1306_39,
g_atype1306_40,
g_atype1306_41,
g_atype1306_42,
g_atype1306_43,
g_atype1306_44,
g_atype1306_45,
g_atype1306_46,
g_atype1306_47,
g_atype1306_48,
g_atype1306_49,
g_atype1306_50,
g_atype1306_51,
};

static const long offsets1306 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
+ @CHROFF(27,0),
+ @CHROFF(27,1),
+ @CHROFF(27,2),
+ @CHROFF(27,3),
+ @LNGOFF(27,4,0,0),
+ @LNGOFF(27,4,0,1),
+ @LNGOFF(27,4,0,2),
+ @LNGOFF(27,4,0,3),
+ @LNGOFF(27,4,0,4),
+ @LNGOFF(27,4,0,5),
+ @LNGOFF(27,4,0,6),
+ @LNGOFF(27,4,0,7),
+ @LNGOFF(27,4,0,8),
+ @LNGOFF(27,4,0,9),
+ @LNGOFF(27,4,0,10),
+ @LNGOFF(27,4,0,11),
+ @LNGOFF(27,4,0,12),
+ @LNGOFF(27,4,0,13),
+ @LNGOFF(27,4,0,14),
+ @LNGOFF(27,4,0,15),
+ @LNGOFF(27,4,0,16),
+ @LNGOFF(27,4,0,17),
+ @LNGOFF(27,4,0,18),
+ @LNGOFF(27,4,0,19),
+ @LNGOFF(27,4,0,20),
};

extern const char *names1307[];
static const uint32 types1307 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1307 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1307_0 [] = {0xFF01,177,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_1 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_2 [] = {716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_3 [] = {717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_5 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_8 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_9 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_10 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_11 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_12 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_13 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_15 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_16 [] = {964,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_17 [] = {86,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_18 [] = {980,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_19 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_20 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_21 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_22 [] = {0xFF01,971,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_23 [] = {0xFF01,86,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_24 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_25 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_26 [] = {1259,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_27 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_28 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_29 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_30 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_31 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_32 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_33 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_34 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_35 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_36 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_37 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_38 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_39 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_40 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_41 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_42 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_43 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_44 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_45 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_46 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_47 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_48 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_49 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_50 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_51 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_52 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_53 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1307 [] = {
g_atype1307_0,
g_atype1307_1,
g_atype1307_2,
g_atype1307_3,
g_atype1307_4,
g_atype1307_5,
g_atype1307_6,
g_atype1307_7,
g_atype1307_8,
g_atype1307_9,
g_atype1307_10,
g_atype1307_11,
g_atype1307_12,
g_atype1307_13,
g_atype1307_14,
g_atype1307_15,
g_atype1307_16,
g_atype1307_17,
g_atype1307_18,
g_atype1307_19,
g_atype1307_20,
g_atype1307_21,
g_atype1307_22,
g_atype1307_23,
g_atype1307_24,
g_atype1307_25,
g_atype1307_26,
g_atype1307_27,
g_atype1307_28,
g_atype1307_29,
g_atype1307_30,
g_atype1307_31,
g_atype1307_32,
g_atype1307_33,
g_atype1307_34,
g_atype1307_35,
g_atype1307_36,
g_atype1307_37,
g_atype1307_38,
g_atype1307_39,
g_atype1307_40,
g_atype1307_41,
g_atype1307_42,
g_atype1307_43,
g_atype1307_44,
g_atype1307_45,
g_atype1307_46,
g_atype1307_47,
g_atype1307_48,
g_atype1307_49,
g_atype1307_50,
g_atype1307_51,
g_atype1307_52,
g_atype1307_53,
};

static const long offsets1307 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
+ @CHROFF(27,0),
+ @CHROFF(27,1),
+ @CHROFF(27,2),
+ @CHROFF(27,3),
+ @CHROFF(27,4),
+ @CHROFF(27,5),
+ @LNGOFF(27,6,0,0),
+ @LNGOFF(27,6,0,1),
+ @LNGOFF(27,6,0,2),
+ @LNGOFF(27,6,0,3),
+ @LNGOFF(27,6,0,4),
+ @LNGOFF(27,6,0,5),
+ @LNGOFF(27,6,0,6),
+ @LNGOFF(27,6,0,7),
+ @LNGOFF(27,6,0,8),
+ @LNGOFF(27,6,0,9),
+ @LNGOFF(27,6,0,10),
+ @LNGOFF(27,6,0,11),
+ @LNGOFF(27,6,0,12),
+ @LNGOFF(27,6,0,13),
+ @LNGOFF(27,6,0,14),
+ @LNGOFF(27,6,0,15),
+ @LNGOFF(27,6,0,16),
+ @LNGOFF(27,6,0,17),
+ @LNGOFF(27,6,0,18),
+ @LNGOFF(27,6,0,19),
+ @LNGOFF(27,6,0,20),
};

extern const char *names1308[];
static const uint32 types1308 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1308 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1308_0 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_1 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_2 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_3 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_5 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_8 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_9 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_10 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_11 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_19 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_20 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_21 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1308_22 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1308 [] = {
g_atype1308_0,
g_atype1308_1,
g_atype1308_2,
g_atype1308_3,
g_atype1308_4,
g_atype1308_5,
g_atype1308_6,
g_atype1308_7,
g_atype1308_8,
g_atype1308_9,
g_atype1308_10,
g_atype1308_11,
g_atype1308_12,
g_atype1308_13,
g_atype1308_14,
g_atype1308_15,
g_atype1308_16,
g_atype1308_17,
g_atype1308_18,
g_atype1308_19,
g_atype1308_20,
g_atype1308_21,
g_atype1308_22,
};

static const long offsets1308 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @LNGOFF(11,1,0,0),
+ @LNGOFF(11,1,0,1),
+ @LNGOFF(11,1,0,2),
+ @LNGOFF(11,1,0,3),
+ @LNGOFF(11,1,0,4),
+ @LNGOFF(11,1,0,5),
+ @LNGOFF(11,1,0,6),
+ @LNGOFF(11,1,0,7),
+ @LNGOFF(11,1,0,8),
+ @LNGOFF(11,1,0,9),
+ @LNGOFF(11,1,0,10),
};

extern const char *names1309[];
static const uint32 types1309 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1309 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1309_0 [] = {0xFF01,177,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_1 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_2 [] = {716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_3 [] = {717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_5 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_8 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_9 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_10 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_11 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_12 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_13 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_14 [] = {0xFF01,8,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_15 [] = {0xFF01,1273,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_16 [] = {0xFF01,1220,0xFF01,831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_17 [] = {0xFF01,1232,0xFF01,831,0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_18 [] = {0xFF01,1220,0xFF01,831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_19 [] = {0xFF01,1232,0xFF01,831,0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_20 [] = {0xFF01,1232,0xFF01,947,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_21 [] = {0xFF01,1206,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_22 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_23 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_24 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_25 [] = {0xFF01,831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_26 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_27 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_28 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_29 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_30 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_31 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_32 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_33 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_34 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_35 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_36 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_37 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_38 [] = {0xFF01,1208,0xFF01,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_39 [] = {0xFF01,1210,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_40 [] = {0xFF01,6,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_41 [] = {5,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_42 [] = {174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_43 [] = {0xFF01,1207,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_44 [] = {0xFF01,1207,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_45 [] = {0xFF01,1207,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_46 [] = {0xFF01,1207,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_47 [] = {0xFF01,1207,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_48 [] = {0xFF01,1207,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_49 [] = {0xFF01,1232,0xFF01,1208,0xFF01,1208,0xFF01,831,0xFF01,831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_50 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_51 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_52 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_53 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_54 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_55 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_56 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_57 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_58 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_59 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_60 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_61 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_62 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_63 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_64 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_65 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_66 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_67 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_68 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_69 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_70 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_71 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_72 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_73 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_74 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_75 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_76 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_77 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_78 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_79 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_80 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_81 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_82 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_83 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_84 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_85 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_86 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_87 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_88 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_89 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_90 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_91 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_92 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_93 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_94 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_95 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_96 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_97 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_98 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_99 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_100 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_101 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_102 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_103 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_104 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_105 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_106 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_107 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_108 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_109 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_110 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_111 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1309 [] = {
g_atype1309_0,
g_atype1309_1,
g_atype1309_2,
g_atype1309_3,
g_atype1309_4,
g_atype1309_5,
g_atype1309_6,
g_atype1309_7,
g_atype1309_8,
g_atype1309_9,
g_atype1309_10,
g_atype1309_11,
g_atype1309_12,
g_atype1309_13,
g_atype1309_14,
g_atype1309_15,
g_atype1309_16,
g_atype1309_17,
g_atype1309_18,
g_atype1309_19,
g_atype1309_20,
g_atype1309_21,
g_atype1309_22,
g_atype1309_23,
g_atype1309_24,
g_atype1309_25,
g_atype1309_26,
g_atype1309_27,
g_atype1309_28,
g_atype1309_29,
g_atype1309_30,
g_atype1309_31,
g_atype1309_32,
g_atype1309_33,
g_atype1309_34,
g_atype1309_35,
g_atype1309_36,
g_atype1309_37,
g_atype1309_38,
g_atype1309_39,
g_atype1309_40,
g_atype1309_41,
g_atype1309_42,
g_atype1309_43,
g_atype1309_44,
g_atype1309_45,
g_atype1309_46,
g_atype1309_47,
g_atype1309_48,
g_atype1309_49,
g_atype1309_50,
g_atype1309_51,
g_atype1309_52,
g_atype1309_53,
g_atype1309_54,
g_atype1309_55,
g_atype1309_56,
g_atype1309_57,
g_atype1309_58,
g_atype1309_59,
g_atype1309_60,
g_atype1309_61,
g_atype1309_62,
g_atype1309_63,
g_atype1309_64,
g_atype1309_65,
g_atype1309_66,
g_atype1309_67,
g_atype1309_68,
g_atype1309_69,
g_atype1309_70,
g_atype1309_71,
g_atype1309_72,
g_atype1309_73,
g_atype1309_74,
g_atype1309_75,
g_atype1309_76,
g_atype1309_77,
g_atype1309_78,
g_atype1309_79,
g_atype1309_80,
g_atype1309_81,
g_atype1309_82,
g_atype1309_83,
g_atype1309_84,
g_atype1309_85,
g_atype1309_86,
g_atype1309_87,
g_atype1309_88,
g_atype1309_89,
g_atype1309_90,
g_atype1309_91,
g_atype1309_92,
g_atype1309_93,
g_atype1309_94,
g_atype1309_95,
g_atype1309_96,
g_atype1309_97,
g_atype1309_98,
g_atype1309_99,
g_atype1309_100,
g_atype1309_101,
g_atype1309_102,
g_atype1309_103,
g_atype1309_104,
g_atype1309_105,
g_atype1309_106,
g_atype1309_107,
g_atype1309_108,
g_atype1309_109,
g_atype1309_110,
g_atype1309_111,
};

static const long offsets1309 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
 + @REFACS(35),
 + @REFACS(36),
 + @REFACS(37),
 + @REFACS(38),
 + @REFACS(39),
 + @REFACS(40),
 + @REFACS(41),
 + @REFACS(42),
 + @REFACS(43),
 + @REFACS(44),
 + @REFACS(45),
 + @REFACS(46),
 + @REFACS(47),
 + @REFACS(48),
 + @REFACS(49),
 + @REFACS(50),
+ @CHROFF(51,0),
+ @CHROFF(51,1),
+ @CHROFF(51,2),
+ @CHROFF(51,3),
+ @CHROFF(51,4),
+ @CHROFF(51,5),
+ @CHROFF(51,6),
+ @CHROFF(51,7),
+ @LNGOFF(51,8,0,0),
+ @LNGOFF(51,8,0,1),
+ @LNGOFF(51,8,0,2),
+ @LNGOFF(51,8,0,3),
+ @LNGOFF(51,8,0,4),
+ @LNGOFF(51,8,0,5),
+ @LNGOFF(51,8,0,6),
+ @LNGOFF(51,8,0,7),
+ @LNGOFF(51,8,0,8),
+ @LNGOFF(51,8,0,9),
+ @LNGOFF(51,8,0,10),
+ @LNGOFF(51,8,0,11),
+ @LNGOFF(51,8,0,12),
+ @LNGOFF(51,8,0,13),
+ @LNGOFF(51,8,0,14),
+ @LNGOFF(51,8,0,15),
+ @LNGOFF(51,8,0,16),
+ @LNGOFF(51,8,0,17),
+ @LNGOFF(51,8,0,18),
+ @LNGOFF(51,8,0,19),
+ @LNGOFF(51,8,0,20),
+ @LNGOFF(51,8,0,21),
+ @LNGOFF(51,8,0,22),
+ @LNGOFF(51,8,0,23),
+ @LNGOFF(51,8,0,24),
+ @LNGOFF(51,8,0,25),
+ @LNGOFF(51,8,0,26),
+ @LNGOFF(51,8,0,27),
+ @LNGOFF(51,8,0,28),
+ @LNGOFF(51,8,0,29),
+ @LNGOFF(51,8,0,30),
+ @LNGOFF(51,8,0,31),
+ @LNGOFF(51,8,0,32),
+ @LNGOFF(51,8,0,33),
+ @LNGOFF(51,8,0,34),
+ @LNGOFF(51,8,0,35),
+ @LNGOFF(51,8,0,36),
+ @LNGOFF(51,8,0,37),
+ @LNGOFF(51,8,0,38),
+ @LNGOFF(51,8,0,39),
+ @LNGOFF(51,8,0,40),
+ @LNGOFF(51,8,0,41),
+ @LNGOFF(51,8,0,42),
+ @LNGOFF(51,8,0,43),
+ @LNGOFF(51,8,0,44),
+ @LNGOFF(51,8,0,45),
+ @LNGOFF(51,8,0,46),
+ @LNGOFF(51,8,0,47),
+ @LNGOFF(51,8,0,48),
+ @LNGOFF(51,8,0,49),
+ @LNGOFF(51,8,0,50),
+ @LNGOFF(51,8,0,51),
+ @LNGOFF(51,8,0,52),
};

extern const char *names1310[];
static const uint32 types1310 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1310 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1310_0 [] = {0xFF01,177,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_1 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_2 [] = {716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_3 [] = {717,897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_4 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_5 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_8 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_9 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_10 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_11 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_12 [] = {714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_13 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_14 [] = {0xFF01,8,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_15 [] = {0xFF01,1273,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_16 [] = {0xFF01,1220,0xFF01,831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_17 [] = {0xFF01,1232,0xFF01,831,0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_18 [] = {0xFF01,1220,0xFF01,831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_19 [] = {0xFF01,1232,0xFF01,831,0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_20 [] = {0xFF01,1232,0xFF01,947,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_21 [] = {0xFF01,1206,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_22 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_23 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_24 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_25 [] = {0xFF01,831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_26 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_27 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_28 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_29 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_30 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_31 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_32 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_33 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_34 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_35 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_36 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_37 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_38 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_39 [] = {0xFF01,1208,0xFF01,174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_40 [] = {0xFF01,1210,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_41 [] = {0xFF01,6,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_42 [] = {5,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_43 [] = {174,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_44 [] = {0xFF01,1207,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_45 [] = {0xFF01,1207,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_46 [] = {0xFF01,1207,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_47 [] = {0xFF01,1207,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_48 [] = {0xFF01,1207,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_49 [] = {0xFF01,1207,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_50 [] = {0xFF01,1232,0xFF01,1208,0xFF01,1208,0xFF01,831,0xFF01,831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_51 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_52 [] = {0xFF01,712,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_53 [] = {0xFF01,23,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_54 [] = {0xFF01,712,0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_55 [] = {0xFF01,23,0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_56 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_57 [] = {0xFF01,24,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_58 [] = {0xFF01,712,0xFF01,831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_59 [] = {0xFF01,23,0xFF01,831,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_60 [] = {0xFF01,712,0xFF01,1116,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_61 [] = {0xFF01,23,0xFF01,1116,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_62 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_63 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_64 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_65 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_66 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_67 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_68 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_69 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_70 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_71 [] = {897,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_72 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_73 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_74 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_75 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_76 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_77 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_78 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_79 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_80 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_81 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_82 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_83 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_84 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_85 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_86 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_87 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_88 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_89 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_90 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_91 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_92 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_93 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_94 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_95 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_96 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_97 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_98 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_99 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_100 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_101 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_102 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_103 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_104 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_105 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_106 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_107 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_108 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_109 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_110 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_111 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_112 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_113 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_114 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_115 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_116 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_117 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_118 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_119 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_120 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_121 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_122 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_123 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_124 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_125 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_126 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_127 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_128 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_129 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_130 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_131 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_132 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1310 [] = {
g_atype1310_0,
g_atype1310_1,
g_atype1310_2,
g_atype1310_3,
g_atype1310_4,
g_atype1310_5,
g_atype1310_6,
g_atype1310_7,
g_atype1310_8,
g_atype1310_9,
g_atype1310_10,
g_atype1310_11,
g_atype1310_12,
g_atype1310_13,
g_atype1310_14,
g_atype1310_15,
g_atype1310_16,
g_atype1310_17,
g_atype1310_18,
g_atype1310_19,
g_atype1310_20,
g_atype1310_21,
g_atype1310_22,
g_atype1310_23,
g_atype1310_24,
g_atype1310_25,
g_atype1310_26,
g_atype1310_27,
g_atype1310_28,
g_atype1310_29,
g_atype1310_30,
g_atype1310_31,
g_atype1310_32,
g_atype1310_33,
g_atype1310_34,
g_atype1310_35,
g_atype1310_36,
g_atype1310_37,
g_atype1310_38,
g_atype1310_39,
g_atype1310_40,
g_atype1310_41,
g_atype1310_42,
g_atype1310_43,
g_atype1310_44,
g_atype1310_45,
g_atype1310_46,
g_atype1310_47,
g_atype1310_48,
g_atype1310_49,
g_atype1310_50,
g_atype1310_51,
g_atype1310_52,
g_atype1310_53,
g_atype1310_54,
g_atype1310_55,
g_atype1310_56,
g_atype1310_57,
g_atype1310_58,
g_atype1310_59,
g_atype1310_60,
g_atype1310_61,
g_atype1310_62,
g_atype1310_63,
g_atype1310_64,
g_atype1310_65,
g_atype1310_66,
g_atype1310_67,
g_atype1310_68,
g_atype1310_69,
g_atype1310_70,
g_atype1310_71,
g_atype1310_72,
g_atype1310_73,
g_atype1310_74,
g_atype1310_75,
g_atype1310_76,
g_atype1310_77,
g_atype1310_78,
g_atype1310_79,
g_atype1310_80,
g_atype1310_81,
g_atype1310_82,
g_atype1310_83,
g_atype1310_84,
g_atype1310_85,
g_atype1310_86,
g_atype1310_87,
g_atype1310_88,
g_atype1310_89,
g_atype1310_90,
g_atype1310_91,
g_atype1310_92,
g_atype1310_93,
g_atype1310_94,
g_atype1310_95,
g_atype1310_96,
g_atype1310_97,
g_atype1310_98,
g_atype1310_99,
g_atype1310_100,
g_atype1310_101,
g_atype1310_102,
g_atype1310_103,
g_atype1310_104,
g_atype1310_105,
g_atype1310_106,
g_atype1310_107,
g_atype1310_108,
g_atype1310_109,
g_atype1310_110,
g_atype1310_111,
g_atype1310_112,
g_atype1310_113,
g_atype1310_114,
g_atype1310_115,
g_atype1310_116,
g_atype1310_117,
g_atype1310_118,
g_atype1310_119,
g_atype1310_120,
g_atype1310_121,
g_atype1310_122,
g_atype1310_123,
g_atype1310_124,
g_atype1310_125,
g_atype1310_126,
g_atype1310_127,
g_atype1310_128,
g_atype1310_129,
g_atype1310_130,
g_atype1310_131,
g_atype1310_132,
};

static const long offsets1310 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
 + @REFACS(35),
 + @REFACS(36),
 + @REFACS(37),
 + @REFACS(38),
 + @REFACS(39),
 + @REFACS(40),
 + @REFACS(41),
 + @REFACS(42),
 + @REFACS(43),
 + @REFACS(44),
 + @REFACS(45),
 + @REFACS(46),
 + @REFACS(47),
 + @REFACS(48),
 + @REFACS(49),
 + @REFACS(50),
 + @REFACS(51),
 + @REFACS(52),
 + @REFACS(53),
 + @REFACS(54),
 + @REFACS(55),
 + @REFACS(56),
 + @REFACS(57),
 + @REFACS(58),
 + @REFACS(59),
 + @REFACS(60),
 + @REFACS(61),
+ @CHROFF(62,0),
+ @CHROFF(62,1),
+ @CHROFF(62,2),
+ @CHROFF(62,3),
+ @CHROFF(62,4),
+ @CHROFF(62,5),
+ @CHROFF(62,6),
+ @CHROFF(62,7),
+ @LNGOFF(62,8,0,0),
+ @LNGOFF(62,8,0,1),
+ @LNGOFF(62,8,0,2),
+ @LNGOFF(62,8,0,3),
+ @LNGOFF(62,8,0,4),
+ @LNGOFF(62,8,0,5),
+ @LNGOFF(62,8,0,6),
+ @LNGOFF(62,8,0,7),
+ @LNGOFF(62,8,0,8),
+ @LNGOFF(62,8,0,9),
+ @LNGOFF(62,8,0,10),
+ @LNGOFF(62,8,0,11),
+ @LNGOFF(62,8,0,12),
+ @LNGOFF(62,8,0,13),
+ @LNGOFF(62,8,0,14),
+ @LNGOFF(62,8,0,15),
+ @LNGOFF(62,8,0,16),
+ @LNGOFF(62,8,0,17),
+ @LNGOFF(62,8,0,18),
+ @LNGOFF(62,8,0,19),
+ @LNGOFF(62,8,0,20),
+ @LNGOFF(62,8,0,21),
+ @LNGOFF(62,8,0,22),
+ @LNGOFF(62,8,0,23),
+ @LNGOFF(62,8,0,24),
+ @LNGOFF(62,8,0,25),
+ @LNGOFF(62,8,0,26),
+ @LNGOFF(62,8,0,27),
+ @LNGOFF(62,8,0,28),
+ @LNGOFF(62,8,0,29),
+ @LNGOFF(62,8,0,30),
+ @LNGOFF(62,8,0,31),
+ @LNGOFF(62,8,0,32),
+ @LNGOFF(62,8,0,33),
+ @LNGOFF(62,8,0,34),
+ @LNGOFF(62,8,0,35),
+ @LNGOFF(62,8,0,36),
+ @LNGOFF(62,8,0,37),
+ @LNGOFF(62,8,0,38),
+ @LNGOFF(62,8,0,39),
+ @LNGOFF(62,8,0,40),
+ @LNGOFF(62,8,0,41),
+ @LNGOFF(62,8,0,42),
+ @LNGOFF(62,8,0,43),
+ @LNGOFF(62,8,0,44),
+ @LNGOFF(62,8,0,45),
+ @LNGOFF(62,8,0,46),
+ @LNGOFF(62,8,0,47),
+ @LNGOFF(62,8,0,48),
+ @LNGOFF(62,8,0,49),
+ @LNGOFF(62,8,0,50),
+ @LNGOFF(62,8,0,51),
+ @LNGOFF(62,8,0,52),
+ @LNGOFF(62,8,0,53),
+ @LNGOFF(62,8,0,54),
+ @LNGOFF(62,8,0,55),
+ @LNGOFF(62,8,0,56),
+ @LNGOFF(62,8,0,57),
+ @LNGOFF(62,8,0,58),
+ @LNGOFF(62,8,0,59),
+ @LNGOFF(62,8,0,60),
+ @LNGOFF(62,8,0,61),
+ @LNGOFF(62,8,0,62),
};

extern const char *names1311[];
static const uint32 types1311 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1311 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1311_0 [] = {0xFF01,122,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_1 [] = {0xFF01,193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_2 [] = {0xFF01,86,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_3 [] = {0xFF01,86,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_4 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_5 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_8 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_9 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_10 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_11 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_12 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_13 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_14 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_15 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_16 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_17 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_18 [] = {1181,0xFF01,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_19 [] = {0xFF01,1232,0xFF01,1305,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_20 [] = {0xFF01,1232,0xFF01,1305,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_21 [] = {0xFF01,1303,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_22 [] = {0xFF01,1200,0xFF01,1303,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_23 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_24 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_25 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_26 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_27 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_28 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_29 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_30 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_31 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_32 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_33 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_34 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_35 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_36 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_37 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_38 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1311 [] = {
g_atype1311_0,
g_atype1311_1,
g_atype1311_2,
g_atype1311_3,
g_atype1311_4,
g_atype1311_5,
g_atype1311_6,
g_atype1311_7,
g_atype1311_8,
g_atype1311_9,
g_atype1311_10,
g_atype1311_11,
g_atype1311_12,
g_atype1311_13,
g_atype1311_14,
g_atype1311_15,
g_atype1311_16,
g_atype1311_17,
g_atype1311_18,
g_atype1311_19,
g_atype1311_20,
g_atype1311_21,
g_atype1311_22,
g_atype1311_23,
g_atype1311_24,
g_atype1311_25,
g_atype1311_26,
g_atype1311_27,
g_atype1311_28,
g_atype1311_29,
g_atype1311_30,
g_atype1311_31,
g_atype1311_32,
g_atype1311_33,
g_atype1311_34,
g_atype1311_35,
g_atype1311_36,
g_atype1311_37,
g_atype1311_38,
};

static const long offsets1311 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
+ @CHROFF(23,0),
+ @CHROFF(23,1),
+ @CHROFF(23,2),
+ @LNGOFF(23,3,0,0),
+ @LNGOFF(23,3,0,1),
+ @LNGOFF(23,3,0,2),
+ @LNGOFF(23,3,0,3),
+ @LNGOFF(23,3,0,4),
+ @LNGOFF(23,3,0,5),
+ @LNGOFF(23,3,0,6),
+ @LNGOFF(23,3,0,7),
+ @LNGOFF(23,3,0,8),
+ @LNGOFF(23,3,0,9),
+ @LNGOFF(23,3,0,10),
+ @LNGOFF(23,3,0,11),
+ @LNGOFF(23,3,0,12),
};

extern const char *names1312[];
static const uint32 types1312 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1312 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1312_0 [] = {0xFF01,122,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_1 [] = {0xFF01,193,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_2 [] = {0xFF01,86,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_3 [] = {0xFF01,86,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_4 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_5 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_8 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_9 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_10 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_11 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_12 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_13 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_14 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_15 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_16 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_17 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_18 [] = {1181,0xFF01,1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_19 [] = {0xFF01,1232,0xFF01,1305,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_20 [] = {0xFF01,1232,0xFF01,1305,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_21 [] = {0xFF01,1303,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_22 [] = {0xFF01,1200,0xFF01,1303,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_23 [] = {0xFF01,712,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_24 [] = {0xFF01,23,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_25 [] = {0xFF01,712,0xFF01,981,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_26 [] = {0xFF01,23,0xFF01,981,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_27 [] = {0xFF01,712,0xFF01,1220,0xFF01,981,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_28 [] = {0xFF01,23,0xFF01,1220,0xFF01,981,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_29 [] = {0xFF01,712,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_30 [] = {0xFF01,23,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_31 [] = {0xFF01,712,0xFF01,1259,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_32 [] = {0xFF01,23,0xFF01,1259,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_33 [] = {0xFF01,712,0xFF01,1313,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_34 [] = {0xFF01,23,0xFF01,1313,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_35 [] = {0xFF01,712,0xFF01,1187,0xFF01,1296,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_36 [] = {0xFF01,23,0xFF01,1187,0xFF01,1296,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_37 [] = {0xFF01,712,0xFF01,1296,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_38 [] = {0xFF01,23,0xFF01,1296,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_39 [] = {0xFF01,712,0xFF01,1187,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_40 [] = {0xFF01,23,0xFF01,1187,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_41 [] = {0xFF01,721,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_42 [] = {0xFF01,25,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_43 [] = {0xFF01,712,0xFF01,12,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_44 [] = {0xFF01,23,0xFF01,12,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_45 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_46 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_47 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_48 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_49 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_50 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_51 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_52 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_53 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_54 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_55 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_56 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_57 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_58 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_59 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_60 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_61 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_62 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_63 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_64 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_65 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_66 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_67 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_68 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_69 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_70 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_71 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_72 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_73 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_74 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_75 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_76 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_77 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_78 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_79 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_80 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_81 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1312_82 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1312 [] = {
g_atype1312_0,
g_atype1312_1,
g_atype1312_2,
g_atype1312_3,
g_atype1312_4,
g_atype1312_5,
g_atype1312_6,
g_atype1312_7,
g_atype1312_8,
g_atype1312_9,
g_atype1312_10,
g_atype1312_11,
g_atype1312_12,
g_atype1312_13,
g_atype1312_14,
g_atype1312_15,
g_atype1312_16,
g_atype1312_17,
g_atype1312_18,
g_atype1312_19,
g_atype1312_20,
g_atype1312_21,
g_atype1312_22,
g_atype1312_23,
g_atype1312_24,
g_atype1312_25,
g_atype1312_26,
g_atype1312_27,
g_atype1312_28,
g_atype1312_29,
g_atype1312_30,
g_atype1312_31,
g_atype1312_32,
g_atype1312_33,
g_atype1312_34,
g_atype1312_35,
g_atype1312_36,
g_atype1312_37,
g_atype1312_38,
g_atype1312_39,
g_atype1312_40,
g_atype1312_41,
g_atype1312_42,
g_atype1312_43,
g_atype1312_44,
g_atype1312_45,
g_atype1312_46,
g_atype1312_47,
g_atype1312_48,
g_atype1312_49,
g_atype1312_50,
g_atype1312_51,
g_atype1312_52,
g_atype1312_53,
g_atype1312_54,
g_atype1312_55,
g_atype1312_56,
g_atype1312_57,
g_atype1312_58,
g_atype1312_59,
g_atype1312_60,
g_atype1312_61,
g_atype1312_62,
g_atype1312_63,
g_atype1312_64,
g_atype1312_65,
g_atype1312_66,
g_atype1312_67,
g_atype1312_68,
g_atype1312_69,
g_atype1312_70,
g_atype1312_71,
g_atype1312_72,
g_atype1312_73,
g_atype1312_74,
g_atype1312_75,
g_atype1312_76,
g_atype1312_77,
g_atype1312_78,
g_atype1312_79,
g_atype1312_80,
g_atype1312_81,
g_atype1312_82,
};

static const long offsets1312 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
 + @REFACS(35),
 + @REFACS(36),
 + @REFACS(37),
 + @REFACS(38),
 + @REFACS(39),
 + @REFACS(40),
 + @REFACS(41),
 + @REFACS(42),
 + @REFACS(43),
 + @REFACS(44),
+ @CHROFF(45,0),
+ @CHROFF(45,1),
+ @CHROFF(45,2),
+ @LNGOFF(45,3,0,0),
+ @LNGOFF(45,3,0,1),
+ @LNGOFF(45,3,0,2),
+ @LNGOFF(45,3,0,3),
+ @LNGOFF(45,3,0,4),
+ @LNGOFF(45,3,0,5),
+ @LNGOFF(45,3,0,6),
+ @LNGOFF(45,3,0,7),
+ @LNGOFF(45,3,0,8),
+ @LNGOFF(45,3,0,9),
+ @LNGOFF(45,3,0,10),
+ @LNGOFF(45,3,0,11),
+ @LNGOFF(45,3,0,12),
+ @LNGOFF(45,3,0,13),
+ @LNGOFF(45,3,0,14),
+ @LNGOFF(45,3,0,15),
+ @LNGOFF(45,3,0,16),
+ @LNGOFF(45,3,0,17),
+ @LNGOFF(45,3,0,18),
+ @LNGOFF(45,3,0,19),
+ @LNGOFF(45,3,0,20),
+ @LNGOFF(45,3,0,21),
+ @LNGOFF(45,3,0,22),
+ @LNGOFF(45,3,0,23),
+ @LNGOFF(45,3,0,24),
+ @LNGOFF(45,3,0,25),
+ @LNGOFF(45,3,0,26),
+ @LNGOFF(45,3,0,27),
+ @LNGOFF(45,3,0,28),
+ @LNGOFF(45,3,0,29),
+ @LNGOFF(45,3,0,30),
+ @LNGOFF(45,3,0,31),
+ @LNGOFF(45,3,0,32),
+ @LNGOFF(45,3,0,33),
+ @LNGOFF(45,3,0,34),
};

extern const char *names1314[];
static const uint32 types1314 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags1314 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1314_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_1 [] = {1181,0xFF01,1313,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_2 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_3 [] = {900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1314_4 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1314 [] = {
g_atype1314_0,
g_atype1314_1,
g_atype1314_2,
g_atype1314_3,
g_atype1314_4,
};

static const long offsets1314 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
};

extern const char *names1315[];
static const uint32 types1315 [] =
{
SK_REF,
};

static const uint16 attr_flags1315 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1315_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1315 [] = {
g_atype1315_0,
};

static const long offsets1315 [] =
{
0,
};

extern const char *names1316[];
static const uint32 types1316 [] =
{
SK_REF,
};

static const uint16 attr_flags1316 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1316_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1316 [] = {
g_atype1316_0,
};

static const long offsets1316 [] =
{
0,
};

extern const char *names1317[];
static const uint32 types1317 [] =
{
SK_REF,
};

static const uint16 attr_flags1317 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1317_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1317 [] = {
g_atype1317_0,
};

static const long offsets1317 [] =
{
0,
};

extern const char *names1318[];
static const uint32 types1318 [] =
{
SK_REF,
};

static const uint16 attr_flags1318 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1318_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1318 [] = {
g_atype1318_0,
};

static const long offsets1318 [] =
{
0,
};

extern const char *names1319[];
static const uint32 types1319 [] =
{
SK_REF,
};

static const uint16 attr_flags1319 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1319_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1319 [] = {
g_atype1319_0,
};

static const long offsets1319 [] =
{
0,
};

extern const char *names1320[];
static const uint32 types1320 [] =
{
SK_REF,
};

static const uint16 attr_flags1320 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1320_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1320 [] = {
g_atype1320_0,
};

static const long offsets1320 [] =
{
0,
};

extern const char *names1321[];
static const uint32 types1321 [] =
{
SK_REF,
};

static const uint16 attr_flags1321 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1321_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1321 [] = {
g_atype1321_0,
};

static const long offsets1321 [] =
{
0,
};

extern const char *names1322[];
static const uint32 types1322 [] =
{
SK_REF,
};

static const uint16 attr_flags1322 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1322_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1322 [] = {
g_atype1322_0,
};

static const long offsets1322 [] =
{
0,
};

extern const char *names1323[];
static const uint32 types1323 [] =
{
SK_REF,
};

static const uint16 attr_flags1323 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1323_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1323 [] = {
g_atype1323_0,
};

static const long offsets1323 [] =
{
0,
};

extern const char *names1324[];
static const uint32 types1324 [] =
{
SK_REF,
};

static const uint16 attr_flags1324 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1324_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1324 [] = {
g_atype1324_0,
};

static const long offsets1324 [] =
{
0,
};

extern const char *names1325[];
static const uint32 types1325 [] =
{
SK_REF,
};

static const uint16 attr_flags1325 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1325_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1325 [] = {
g_atype1325_0,
};

static const long offsets1325 [] =
{
0,
};

extern const char *names1326[];
static const uint32 types1326 [] =
{
SK_REF,
};

static const uint16 attr_flags1326 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1326_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1326 [] = {
g_atype1326_0,
};

static const long offsets1326 [] =
{
0,
};

extern const char *names1327[];
static const uint32 types1327 [] =
{
SK_REF,
};

static const uint16 attr_flags1327 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1327_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1327 [] = {
g_atype1327_0,
};

static const long offsets1327 [] =
{
0,
};

extern const char *names1328[];
static const uint32 types1328 [] =
{
SK_REF,
};

static const uint16 attr_flags1328 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1328_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1328 [] = {
g_atype1328_0,
};

static const long offsets1328 [] =
{
0,
};

extern const char *names1329[];
static const uint32 types1329 [] =
{
SK_REF,
};

static const uint16 attr_flags1329 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1329_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1329 [] = {
g_atype1329_0,
};

static const long offsets1329 [] =
{
0,
};

extern const char *names1330[];
static const uint32 types1330 [] =
{
SK_REF,
};

static const uint16 attr_flags1330 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1330_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1330 [] = {
g_atype1330_0,
};

static const long offsets1330 [] =
{
0,
};

extern const char *names1331[];
static const uint32 types1331 [] =
{
SK_REF,
};

static const uint16 attr_flags1331 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1331_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1331 [] = {
g_atype1331_0,
};

static const long offsets1331 [] =
{
0,
};

extern const char *names1332[];
static const uint32 types1332 [] =
{
SK_REF,
};

static const uint16 attr_flags1332 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1332_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1332 [] = {
g_atype1332_0,
};

static const long offsets1332 [] =
{
0,
};

extern const char *names1333[];
static const uint32 types1333 [] =
{
SK_REF,
};

static const uint16 attr_flags1333 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1333_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1333 [] = {
g_atype1333_0,
};

static const long offsets1333 [] =
{
0,
};

extern const char *names1334[];
static const uint32 types1334 [] =
{
SK_REF,
};

static const uint16 attr_flags1334 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1334_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1334 [] = {
g_atype1334_0,
};

static const long offsets1334 [] =
{
0,
};

extern const char *names1335[];
static const uint32 types1335 [] =
{
SK_REF,
};

static const uint16 attr_flags1335 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1335_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1335 [] = {
g_atype1335_0,
};

static const long offsets1335 [] =
{
0,
};

extern const char *names1336[];
static const uint32 types1336 [] =
{
SK_REF,
};

static const uint16 attr_flags1336 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1336_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1336 [] = {
g_atype1336_0,
};

static const long offsets1336 [] =
{
0,
};

extern const char *names1337[];
static const uint32 types1337 [] =
{
SK_REF,
};

static const uint16 attr_flags1337 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1337_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1337 [] = {
g_atype1337_0,
};

static const long offsets1337 [] =
{
0,
};

extern const char *names1338[];
static const uint32 types1338 [] =
{
SK_REF,
};

static const uint16 attr_flags1338 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1338_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1338 [] = {
g_atype1338_0,
};

static const long offsets1338 [] =
{
0,
};

extern const char *names1339[];
static const uint32 types1339 [] =
{
SK_REF,
};

static const uint16 attr_flags1339 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1339_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1339 [] = {
g_atype1339_0,
};

static const long offsets1339 [] =
{
0,
};

extern const char *names1340[];
static const uint32 types1340 [] =
{
SK_REF,
};

static const uint16 attr_flags1340 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1340_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1340 [] = {
g_atype1340_0,
};

static const long offsets1340 [] =
{
0,
};

extern const char *names1341[];
static const uint32 types1341 [] =
{
SK_REF,
};

static const uint16 attr_flags1341 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1341_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1341 [] = {
g_atype1341_0,
};

static const long offsets1341 [] =
{
0,
};

extern const char *names1342[];
static const uint32 types1342 [] =
{
SK_REF,
};

static const uint16 attr_flags1342 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1342_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1342 [] = {
g_atype1342_0,
};

static const long offsets1342 [] =
{
0,
};

extern const char *names1343[];
static const uint32 types1343 [] =
{
SK_REF,
};

static const uint16 attr_flags1343 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1343_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1343 [] = {
g_atype1343_0,
};

static const long offsets1343 [] =
{
0,
};

extern const char *names1344[];
static const uint32 types1344 [] =
{
SK_REF,
};

static const uint16 attr_flags1344 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1344_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1344 [] = {
g_atype1344_0,
};

static const long offsets1344 [] =
{
0,
};

extern const char *names1345[];
static const uint32 types1345 [] =
{
SK_REF,
};

static const uint16 attr_flags1345 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1345_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1345 [] = {
g_atype1345_0,
};

static const long offsets1345 [] =
{
0,
};

extern const char *names1346[];
static const uint32 types1346 [] =
{
SK_REF,
};

static const uint16 attr_flags1346 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1346_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1346 [] = {
g_atype1346_0,
};

static const long offsets1346 [] =
{
0,
};

extern const char *names1347[];
static const uint32 types1347 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1347 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1347_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1347_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1347_2 [] = {0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1347 [] = {
g_atype1347_0,
g_atype1347_1,
g_atype1347_2,
};

static const long offsets1347 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1348[];
static const uint32 types1348 [] =
{
SK_REF,
};

static const uint16 attr_flags1348 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1348_0 [] = {0xFF01,737,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1348 [] = {
g_atype1348_0,
};

static const long offsets1348 [] =
{
0,
};

extern const char *names1350[];
static const uint32 types1350 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1350 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1350_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_4 [] = {1349,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1350 [] = {
g_atype1350_0,
g_atype1350_1,
g_atype1350_2,
g_atype1350_3,
g_atype1350_4,
};

static const long offsets1350 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
};

extern const char *names1351[];
static const uint32 types1351 [] =
{
SK_REF,
};

static const uint16 attr_flags1351 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1351_0 [] = {1237,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1351 [] = {
g_atype1351_0,
};

static const long offsets1351 [] =
{
0,
};

extern const char *names1352[];
static const uint32 types1352 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1352 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1352_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_1 [] = {0xFF01,1208,0xFF01,1352,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1352 [] = {
g_atype1352_0,
g_atype1352_1,
};

static const long offsets1352 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1353[];
static const uint32 types1353 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1353 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1353_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1353_1 [] = {1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1353_2 [] = {0xFF01,1232,0xFF01,985,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1353_3 [] = {0xFF01,1232,0xFF01,22,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1353_4 [] = {0xFF01,1232,0xFF01,21,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1353_5 [] = {0xFF01,1232,0xFF01,1429,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1353_6 [] = {0xFF01,1232,0xFF01,1429,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1353_7 [] = {0xFF01,1232,0xFF01,1429,0xFF01,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1353 [] = {
g_atype1353_0,
g_atype1353_1,
g_atype1353_2,
g_atype1353_3,
g_atype1353_4,
g_atype1353_5,
g_atype1353_6,
g_atype1353_7,
};

static const long offsets1353 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
};

extern const char *names1354[];
static const uint32 types1354 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1354 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1354_0 [] = {254,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_1 [] = {0xFF01,1097,0xFF01,950,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_2 [] = {1162,0xFF01,950,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_3 [] = {254,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_4 [] = {0xFF01,712,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_5 [] = {0xFF01,712,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_6 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_7 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_8 [] = {0xFF01,23,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_9 [] = {0xFF01,23,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_10 [] = {18,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_12 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_13 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_14 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_15 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_16 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_17 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_19 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1354 [] = {
g_atype1354_0,
g_atype1354_1,
g_atype1354_2,
g_atype1354_3,
g_atype1354_4,
g_atype1354_5,
g_atype1354_6,
g_atype1354_7,
g_atype1354_8,
g_atype1354_9,
g_atype1354_10,
g_atype1354_11,
g_atype1354_12,
g_atype1354_13,
g_atype1354_14,
g_atype1354_15,
g_atype1354_16,
g_atype1354_17,
g_atype1354_18,
g_atype1354_19,
};

static const long offsets1354 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1355[];
static const uint32 types1355 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1355 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1355_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_1 [] = {1427,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1355 [] = {
g_atype1355_0,
g_atype1355_1,
};

static const long offsets1355 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1356[];
static const uint32 types1356 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1356 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1356_0 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1356_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1356_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1356_3 [] = {0xFF01,1353,0xFFFF};
static const EIF_TYPE_INDEX g_atype1356_4 [] = {0xFF01,51,0xFFFF};
static const EIF_TYPE_INDEX g_atype1356_5 [] = {1232,0xFF01,1429,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1356_6 [] = {0xFF01,1232,0xFF01,1429,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1356_7 [] = {1351,0xFFFF};
static const EIF_TYPE_INDEX g_atype1356_8 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1356_9 [] = {31,0xFFFF};
static const EIF_TYPE_INDEX g_atype1356_10 [] = {1260,0xFFFF};
static const EIF_TYPE_INDEX g_atype1356_11 [] = {0xFF01,997,0xFFFF};
static const EIF_TYPE_INDEX g_atype1356_12 [] = {0xFF01,1197,0xFF01,1429,0xFFFF};
static const EIF_TYPE_INDEX g_atype1356_13 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1356_14 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1356 [] = {
g_atype1356_0,
g_atype1356_1,
g_atype1356_2,
g_atype1356_3,
g_atype1356_4,
g_atype1356_5,
g_atype1356_6,
g_atype1356_7,
g_atype1356_8,
g_atype1356_9,
g_atype1356_10,
g_atype1356_11,
g_atype1356_12,
g_atype1356_13,
g_atype1356_14,
};

static const long offsets1356 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
+ @CHROFF(13,0),
+ @CHROFF(13,1),
};

extern const char *names1357[];
static const uint32 types1357 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1357 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1357_0 [] = {0xFF01,1273,0xFFFF};
static const EIF_TYPE_INDEX g_atype1357_1 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1357_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1357_3 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1357_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1357_5 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1357_6 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1357 [] = {
g_atype1357_0,
g_atype1357_1,
g_atype1357_2,
g_atype1357_3,
g_atype1357_4,
g_atype1357_5,
g_atype1357_6,
};

static const long offsets1357 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
};

extern const char *names1358[];
static const uint32 types1358 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1358 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1358_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_1 [] = {939,0xFF01,0xFFF9,0,864,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1358 [] = {
g_atype1358_0,
g_atype1358_1,
};

static const long offsets1358 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1359[];
static const uint32 types1359 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1359 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1359_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_1 [] = {939,0xFF01,0xFFF9,0,864,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1359 [] = {
g_atype1359_0,
g_atype1359_1,
};

static const long offsets1359 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1360[];
static const uint32 types1360 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1360 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1360_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1360_1 [] = {939,0xFF01,0xFFF9,0,864,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1360 [] = {
g_atype1360_0,
g_atype1360_1,
};

static const long offsets1360 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1361[];
static const uint32 types1361 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1361 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1361_0 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_1 [] = {939,0xFF01,0xFFF9,0,864,950,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1361 [] = {
g_atype1361_0,
g_atype1361_1,
};

static const long offsets1361 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1362[];
static const uint32 types1362 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1362 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1362_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_1 [] = {1031,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1362 [] = {
g_atype1362_0,
g_atype1362_1,
};

static const long offsets1362 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1363[];
static const uint32 types1363 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1363 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1363_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_1 [] = {1031,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1363 [] = {
g_atype1363_0,
g_atype1363_1,
};

static const long offsets1363 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1364[];
static const uint32 types1364 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1364 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1364_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_1 [] = {1031,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1364 [] = {
g_atype1364_0,
g_atype1364_1,
};

static const long offsets1364 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1365[];
static const uint32 types1365 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1365 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1365_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_1 [] = {1031,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1365 [] = {
g_atype1365_0,
g_atype1365_1,
};

static const long offsets1365 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1366[];
static const uint32 types1366 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1366 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1366_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_1 [] = {1031,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1366 [] = {
g_atype1366_0,
g_atype1366_1,
};

static const long offsets1366 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1367[];
static const uint32 types1367 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1367 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1367_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_2 [] = {0xFF01,1355,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1367 [] = {
g_atype1367_0,
g_atype1367_1,
g_atype1367_2,
};

static const long offsets1367 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1368[];
static const uint32 types1368 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1368 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1368_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_3 [] = {0xFF01,21,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1368 [] = {
g_atype1368_0,
g_atype1368_1,
g_atype1368_2,
g_atype1368_3,
};

static const long offsets1368 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1369[];
static const uint32 types1369 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1369 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1369_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_3 [] = {0xFF01,22,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1369 [] = {
g_atype1369_0,
g_atype1369_1,
g_atype1369_2,
g_atype1369_3,
};

static const long offsets1369 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1370[];
static const uint32 types1370 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1370 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1370_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_3 [] = {0xFF01,985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1370 [] = {
g_atype1370_0,
g_atype1370_1,
g_atype1370_2,
g_atype1370_3,
};

static const long offsets1370 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1371[];
static const uint32 types1371 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1371 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1371_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_3 [] = {0xFF01,1349,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1371 [] = {
g_atype1371_0,
g_atype1371_1,
g_atype1371_2,
g_atype1371_3,
};

static const long offsets1371 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1372[];
static const uint32 types1372 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1372 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1372_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1372_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1372_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1372_3 [] = {0xFF01,1257,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1372 [] = {
g_atype1372_0,
g_atype1372_1,
g_atype1372_2,
g_atype1372_3,
};

static const long offsets1372 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1373[];
static const uint32 types1373 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1373 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1373_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1373_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1373_2 [] = {0xFF01,1355,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1373 [] = {
g_atype1373_0,
g_atype1373_1,
g_atype1373_2,
};

static const long offsets1373 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1374[];
static const uint32 types1374 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1374 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1374_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1374_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1374_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1374_3 [] = {0xFF01,1394,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1374 [] = {
g_atype1374_0,
g_atype1374_1,
g_atype1374_2,
g_atype1374_3,
};

static const long offsets1374 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1375[];
static const uint32 types1375 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1375 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1375_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_3 [] = {0xFF01,1395,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1375 [] = {
g_atype1375_0,
g_atype1375_1,
g_atype1375_2,
g_atype1375_3,
};

static const long offsets1375 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1376[];
static const uint32 types1376 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1376 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1376_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1376_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1376_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1376_3 [] = {0xFF01,1413,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1376 [] = {
g_atype1376_0,
g_atype1376_1,
g_atype1376_2,
g_atype1376_3,
};

static const long offsets1376 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1377[];
static const uint32 types1377 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1377 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1377_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1377_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1377_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1377_3 [] = {0xFF01,1414,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1377 [] = {
g_atype1377_0,
g_atype1377_1,
g_atype1377_2,
g_atype1377_3,
};

static const long offsets1377 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1378[];
static const uint32 types1378 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1378 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1378_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1378_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1378_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1378_3 [] = {0xFF01,1396,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1378 [] = {
g_atype1378_0,
g_atype1378_1,
g_atype1378_2,
g_atype1378_3,
};

static const long offsets1378 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1379[];
static const uint32 types1379 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1379 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1379_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1379_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1379_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1379_3 [] = {0xFF01,1397,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1379 [] = {
g_atype1379_0,
g_atype1379_1,
g_atype1379_2,
g_atype1379_3,
};

static const long offsets1379 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1380[];
static const uint32 types1380 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1380 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1380_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1380_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1380_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1380_3 [] = {0xFF01,1399,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1380 [] = {
g_atype1380_0,
g_atype1380_1,
g_atype1380_2,
g_atype1380_3,
};

static const long offsets1380 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1381[];
static const uint32 types1381 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1381 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1381_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1381_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1381_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1381_3 [] = {0xFF01,1400,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1381 [] = {
g_atype1381_0,
g_atype1381_1,
g_atype1381_2,
g_atype1381_3,
};

static const long offsets1381 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1382[];
static const uint32 types1382 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1382 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1382_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1382_3 [] = {0xFF01,1401,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1382 [] = {
g_atype1382_0,
g_atype1382_1,
g_atype1382_2,
g_atype1382_3,
};

static const long offsets1382 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1383[];
static const uint32 types1383 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1383 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1383_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1383_3 [] = {0xFF01,1402,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1383 [] = {
g_atype1383_0,
g_atype1383_1,
g_atype1383_2,
g_atype1383_3,
};

static const long offsets1383 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1384[];
static const uint32 types1384 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1384 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1384_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1384_3 [] = {0xFF01,1403,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1384 [] = {
g_atype1384_0,
g_atype1384_1,
g_atype1384_2,
g_atype1384_3,
};

static const long offsets1384 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1385[];
static const uint32 types1385 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1385 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1385_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1385_3 [] = {0xFF01,1404,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1385 [] = {
g_atype1385_0,
g_atype1385_1,
g_atype1385_2,
g_atype1385_3,
};

static const long offsets1385 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1386[];
static const uint32 types1386 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1386 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1386_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1386_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1386_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1386_3 [] = {0xFF01,1405,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1386 [] = {
g_atype1386_0,
g_atype1386_1,
g_atype1386_2,
g_atype1386_3,
};

static const long offsets1386 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1387[];
static const uint32 types1387 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1387 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1387_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1387_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1387_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1387_3 [] = {0xFF01,1406,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1387 [] = {
g_atype1387_0,
g_atype1387_1,
g_atype1387_2,
g_atype1387_3,
};

static const long offsets1387 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1388[];
static const uint32 types1388 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1388 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1388_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1388_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1388_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1388_3 [] = {0xFF01,1407,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1388 [] = {
g_atype1388_0,
g_atype1388_1,
g_atype1388_2,
g_atype1388_3,
};

static const long offsets1388 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1389[];
static const uint32 types1389 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1389 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1389_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1389_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1389_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1389_3 [] = {0xFF01,1408,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1389 [] = {
g_atype1389_0,
g_atype1389_1,
g_atype1389_2,
g_atype1389_3,
};

static const long offsets1389 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1390[];
static const uint32 types1390 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1390 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1390_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1390_3 [] = {0xFF01,1415,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1390 [] = {
g_atype1390_0,
g_atype1390_1,
g_atype1390_2,
g_atype1390_3,
};

static const long offsets1390 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1391[];
static const uint32 types1391 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1391 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1391_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1391_3 [] = {0xFF01,1416,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1391 [] = {
g_atype1391_0,
g_atype1391_1,
g_atype1391_2,
g_atype1391_3,
};

static const long offsets1391 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1392[];
static const uint32 types1392 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1392 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1392_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1392_3 [] = {0xFF01,1409,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1392 [] = {
g_atype1392_0,
g_atype1392_1,
g_atype1392_2,
g_atype1392_3,
};

static const long offsets1392 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1393[];
static const uint32 types1393 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1393 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1393_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1393_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1393_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1393_3 [] = {0xFF01,1411,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1393 [] = {
g_atype1393_0,
g_atype1393_1,
g_atype1393_2,
g_atype1393_3,
};

static const long offsets1393 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1394[];
static const uint32 types1394 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1394 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1394_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1394_3 [] = {0xFF01,1419,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1394 [] = {
g_atype1394_0,
g_atype1394_1,
g_atype1394_2,
g_atype1394_3,
};

static const long offsets1394 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1395[];
static const uint32 types1395 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1395 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1395_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1395 [] = {
g_atype1395_0,
g_atype1395_1,
g_atype1395_2,
};

static const long offsets1395 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1396[];
static const uint32 types1396 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1396 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1396_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1396 [] = {
g_atype1396_0,
g_atype1396_1,
g_atype1396_2,
g_atype1396_3,
g_atype1396_4,
};

static const long offsets1396 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1397[];
static const uint32 types1397 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1397 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1397_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_4 [] = {1258,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_5 [] = {1257,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_7 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1397 [] = {
g_atype1397_0,
g_atype1397_1,
g_atype1397_2,
g_atype1397_3,
g_atype1397_4,
g_atype1397_5,
g_atype1397_6,
g_atype1397_7,
};

static const long offsets1397 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
};

extern const char *names1398[];
static const uint32 types1398 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1398 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1398_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_2 [] = {0xFF01,1360,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_3 [] = {0xFF01,129,0xFF01,938,0xFF01,0xFFF9,1,864,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1398_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1398 [] = {
g_atype1398_0,
g_atype1398_1,
g_atype1398_2,
g_atype1398_3,
g_atype1398_4,
};

static const long offsets1398 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1399[];
static const uint32 types1399 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1399 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1399_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1399_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1399_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1399_3 [] = {1258,0xFFFF};
static const EIF_TYPE_INDEX g_atype1399_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1399_5 [] = {0xFF01,1238,0xFFFF};
static const EIF_TYPE_INDEX g_atype1399_6 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1399_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1399_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1399_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1399_10 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1399 [] = {
g_atype1399_0,
g_atype1399_1,
g_atype1399_2,
g_atype1399_3,
g_atype1399_4,
g_atype1399_5,
g_atype1399_6,
g_atype1399_7,
g_atype1399_8,
g_atype1399_9,
g_atype1399_10,
};

static const long offsets1399 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @LNGOFF(7,3,0,0),
};

extern const char *names1400[];
static const uint32 types1400 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1400 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1400_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1400_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1400_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1400_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1400_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1400_5 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1400_6 [] = {0xFF01,1232,0xFF01,950,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1400_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1400_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1400_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1400_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1400_11 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1400_12 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1400_13 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1400 [] = {
g_atype1400_0,
g_atype1400_1,
g_atype1400_2,
g_atype1400_3,
g_atype1400_4,
g_atype1400_5,
g_atype1400_6,
g_atype1400_7,
g_atype1400_8,
g_atype1400_9,
g_atype1400_10,
g_atype1400_11,
g_atype1400_12,
g_atype1400_13,
};

static const long offsets1400 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @LNGOFF(7,6,0,0),
};

extern const char *names1401[];
static const uint32 types1401 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1401 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1401_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1401_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1401_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1401_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1401_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1401_5 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1401_6 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1401_7 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1401_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1401_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1401_10 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1401 [] = {
g_atype1401_0,
g_atype1401_1,
g_atype1401_2,
g_atype1401_3,
g_atype1401_4,
g_atype1401_5,
g_atype1401_6,
g_atype1401_7,
g_atype1401_8,
g_atype1401_9,
g_atype1401_10,
};

static const long offsets1401 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @LNGOFF(8,2,0,0),
};

extern const char *names1402[];
static const uint32 types1402 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1402 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1402_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_4 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_5 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_11 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_12 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_13 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_14 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1402 [] = {
g_atype1402_0,
g_atype1402_1,
g_atype1402_2,
g_atype1402_3,
g_atype1402_4,
g_atype1402_5,
g_atype1402_6,
g_atype1402_7,
g_atype1402_8,
g_atype1402_9,
g_atype1402_10,
g_atype1402_11,
g_atype1402_12,
g_atype1402_13,
g_atype1402_14,
};

static const long offsets1402 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @CHROFF(6,7),
+ @LNGOFF(6,8,0,0),
};

extern const char *names1403[];
static const uint32 types1403 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1403 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1403_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1403_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1403_2 [] = {0xFF01,1360,0xFFFF};
static const EIF_TYPE_INDEX g_atype1403_3 [] = {0xFF01,1360,0xFFFF};
static const EIF_TYPE_INDEX g_atype1403_4 [] = {0xFF01,1359,0xFFFF};
static const EIF_TYPE_INDEX g_atype1403_5 [] = {0xFF01,129,0xFF01,938,0xFF01,0xFFF9,1,864,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1403_6 [] = {0xFF01,129,0xFF01,938,0xFF01,0xFFF9,3,864,0xFF01,950,0xFF01,1246,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1403_7 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1403 [] = {
g_atype1403_0,
g_atype1403_1,
g_atype1403_2,
g_atype1403_3,
g_atype1403_4,
g_atype1403_5,
g_atype1403_6,
g_atype1403_7,
};

static const long offsets1403 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @LNGOFF(7,0,0,0),
};

extern const char *names1404[];
static const uint32 types1404 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1404 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1404_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1404_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1404_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1404_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1404 [] = {
g_atype1404_0,
g_atype1404_1,
g_atype1404_2,
g_atype1404_3,
};

static const long offsets1404 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
};

extern const char *names1405[];
static const uint32 types1405 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1405 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1405_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1405_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1405_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1405_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1405_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1405 [] = {
g_atype1405_0,
g_atype1405_1,
g_atype1405_2,
g_atype1405_3,
g_atype1405_4,
};

static const long offsets1405 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1406[];
static const uint32 types1406 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1406 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1406_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1406_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1406_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1406_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1406_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1406 [] = {
g_atype1406_0,
g_atype1406_1,
g_atype1406_2,
g_atype1406_3,
g_atype1406_4,
};

static const long offsets1406 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1407[];
static const uint32 types1407 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1407 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1407_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_2 [] = {0xFF01,1360,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_3 [] = {0xFF01,1360,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_4 [] = {0xFF01,1359,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_5 [] = {1258,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_7 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1407 [] = {
g_atype1407_0,
g_atype1407_1,
g_atype1407_2,
g_atype1407_3,
g_atype1407_4,
g_atype1407_5,
g_atype1407_6,
g_atype1407_7,
};

static const long offsets1407 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
};

extern const char *names1408[];
static const uint32 types1408 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1408 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1408_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1408_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1408_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1408_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1408_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1408_5 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1408_6 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1408_7 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1408_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1408_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1408_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1408_11 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1408 [] = {
g_atype1408_0,
g_atype1408_1,
g_atype1408_2,
g_atype1408_3,
g_atype1408_4,
g_atype1408_5,
g_atype1408_6,
g_atype1408_7,
g_atype1408_8,
g_atype1408_9,
g_atype1408_10,
g_atype1408_11,
};

static const long offsets1408 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @LNGOFF(8,3,0,0),
};

extern const char *names1409[];
static const uint32 types1409 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1409 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1409_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_5 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_6 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_7 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_8 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_9 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_11 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_12 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_13 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_14 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_15 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_16 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_17 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_18 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_19 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_20 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1409 [] = {
g_atype1409_0,
g_atype1409_1,
g_atype1409_2,
g_atype1409_3,
g_atype1409_4,
g_atype1409_5,
g_atype1409_6,
g_atype1409_7,
g_atype1409_8,
g_atype1409_9,
g_atype1409_10,
g_atype1409_11,
g_atype1409_12,
g_atype1409_13,
g_atype1409_14,
g_atype1409_15,
g_atype1409_16,
g_atype1409_17,
g_atype1409_18,
g_atype1409_19,
g_atype1409_20,
};

static const long offsets1409 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @CHROFF(10,0),
+ @CHROFF(10,1),
+ @CHROFF(10,2),
+ @CHROFF(10,3),
+ @CHROFF(10,4),
+ @CHROFF(10,5),
+ @CHROFF(10,6),
+ @CHROFF(10,7),
+ @LNGOFF(10,8,0,0),
+ @LNGOFF(10,8,0,1),
+ @LNGOFF(10,8,0,2),
};

extern const char *names1410[];
static const uint32 types1410 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1410 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1410_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1410_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1410_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1410_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1410_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1410_5 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1410_6 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1410_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1410_8 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1410 [] = {
g_atype1410_0,
g_atype1410_1,
g_atype1410_2,
g_atype1410_3,
g_atype1410_4,
g_atype1410_5,
g_atype1410_6,
g_atype1410_7,
g_atype1410_8,
};

static const long offsets1410 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names1411[];
static const uint32 types1411 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1411 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1411_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1411_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1411_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1411_3 [] = {0xFF01,1238,0xFFFF};
static const EIF_TYPE_INDEX g_atype1411_4 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1411 [] = {
g_atype1411_0,
g_atype1411_1,
g_atype1411_2,
g_atype1411_3,
g_atype1411_4,
};

static const long offsets1411 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1412[];
static const uint32 types1412 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1412 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1412_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_3 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1412 [] = {
g_atype1412_0,
g_atype1412_1,
g_atype1412_2,
g_atype1412_3,
};

static const long offsets1412 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names1413[];
static const uint32 types1413 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1413 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1413_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_2 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1413 [] = {
g_atype1413_0,
g_atype1413_1,
g_atype1413_2,
};

static const long offsets1413 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1414[];
static const uint32 types1414 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1414 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1414_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1414_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1414_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1414_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1414_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1414_5 [] = {1258,0xFFFF};
static const EIF_TYPE_INDEX g_atype1414_6 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1414 [] = {
g_atype1414_0,
g_atype1414_1,
g_atype1414_2,
g_atype1414_3,
g_atype1414_4,
g_atype1414_5,
g_atype1414_6,
};

static const long offsets1414 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
};

extern const char *names1415[];
static const uint32 types1415 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1415 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1415_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1415_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1415_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1415_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1415_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1415_5 [] = {1258,0xFFFF};
static const EIF_TYPE_INDEX g_atype1415_6 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1415_7 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1415 [] = {
g_atype1415_0,
g_atype1415_1,
g_atype1415_2,
g_atype1415_3,
g_atype1415_4,
g_atype1415_5,
g_atype1415_6,
g_atype1415_7,
};

static const long offsets1415 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
};

extern const char *names1416[];
static const uint32 types1416 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1416 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1416_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1416_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1416_2 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1416_3 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1416_4 [] = {0xFF01,1208,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1416_5 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1416_6 [] = {1258,0xFFFF};
static const EIF_TYPE_INDEX g_atype1416_7 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1416_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1416_9 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1416 [] = {
g_atype1416_0,
g_atype1416_1,
g_atype1416_2,
g_atype1416_3,
g_atype1416_4,
g_atype1416_5,
g_atype1416_6,
g_atype1416_7,
g_atype1416_8,
g_atype1416_9,
};

static const long offsets1416 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @LNGOFF(7,2,0,0),
};

extern const char *names1417[];
static const uint32 types1417 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1417 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1417_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1417_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1417_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1417_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1417_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1417_5 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1417_6 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1417_7 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1417_8 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1417_9 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1417_10 [] = {1258,0xFFFF};
static const EIF_TYPE_INDEX g_atype1417_11 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1417 [] = {
g_atype1417_0,
g_atype1417_1,
g_atype1417_2,
g_atype1417_3,
g_atype1417_4,
g_atype1417_5,
g_atype1417_6,
g_atype1417_7,
g_atype1417_8,
g_atype1417_9,
g_atype1417_10,
g_atype1417_11,
};

static const long offsets1417 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
};

extern const char *names1418[];
static const uint32 types1418 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1418 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1418_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1418_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1418_2 [] = {0xFF01,1360,0xFFFF};
static const EIF_TYPE_INDEX g_atype1418_3 [] = {0xFF01,1360,0xFFFF};
static const EIF_TYPE_INDEX g_atype1418_4 [] = {0xFF01,1360,0xFFFF};
static const EIF_TYPE_INDEX g_atype1418_5 [] = {0xFF01,1360,0xFFFF};
static const EIF_TYPE_INDEX g_atype1418_6 [] = {0xFF01,129,0xFF01,940,0xFF01,0xFFF9,1,864,0xFF01,950,903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1418_7 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1418 [] = {
g_atype1418_0,
g_atype1418_1,
g_atype1418_2,
g_atype1418_3,
g_atype1418_4,
g_atype1418_5,
g_atype1418_6,
g_atype1418_7,
};

static const long offsets1418 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @LNGOFF(7,0,0,0),
};

extern const char *names1419[];
static const uint32 types1419 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1419 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1419_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1419_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1419_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1419_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1419_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1419_5 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1419_6 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1419_7 [] = {1258,0xFFFF};
static const EIF_TYPE_INDEX g_atype1419_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1419_9 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1419 [] = {
g_atype1419_0,
g_atype1419_1,
g_atype1419_2,
g_atype1419_3,
g_atype1419_4,
g_atype1419_5,
g_atype1419_6,
g_atype1419_7,
g_atype1419_8,
g_atype1419_9,
};

static const long offsets1419 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @LNGOFF(8,1,0,0),
};

extern const char *names1420[];
static const uint32 types1420 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1420 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1420_0 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_1 [] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_2 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_3 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_4 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_5 [] = {0xFF01,1208,0xFF01,133,0xFF01,950,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_6 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_7 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_8 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_9 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_11 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_12 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1420 [] = {
g_atype1420_0,
g_atype1420_1,
g_atype1420_2,
g_atype1420_3,
g_atype1420_4,
g_atype1420_5,
g_atype1420_6,
g_atype1420_7,
g_atype1420_8,
g_atype1420_9,
g_atype1420_10,
g_atype1420_11,
g_atype1420_12,
};

static const long offsets1420 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @CHROFF(10,0),
+ @LNGOFF(10,1,0,0),
+ @LNGOFF(10,1,0,1),
};

extern const char *names1421[];
static const uint32 types1421 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1421 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1421_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_3 [] = {0xFF01,1352,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1421 [] = {
g_atype1421_0,
g_atype1421_1,
g_atype1421_2,
g_atype1421_3,
};

static const long offsets1421 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1422[];
static const uint32 types1422 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1422 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1422_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_3 [] = {0xFF01,1258,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1422 [] = {
g_atype1422_0,
g_atype1422_1,
g_atype1422_2,
g_atype1422_3,
};

static const long offsets1422 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1423[];
static const uint32 types1423 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1423 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1423_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1423_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1423_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1423_3 [] = {0xFF01,1351,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1423 [] = {
g_atype1423_0,
g_atype1423_1,
g_atype1423_2,
g_atype1423_3,
};

static const long offsets1423 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1424[];
static const uint32 types1424 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1424 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1424_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1424_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1424_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1424_3 [] = {0xFF01,1398,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1424 [] = {
g_atype1424_0,
g_atype1424_1,
g_atype1424_2,
g_atype1424_3,
};

static const long offsets1424 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1425[];
static const uint32 types1425 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1425 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1425_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1425_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1425_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1425_3 [] = {0xFF01,1417,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1425 [] = {
g_atype1425_0,
g_atype1425_1,
g_atype1425_2,
g_atype1425_3,
};

static const long offsets1425 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1426[];
static const uint32 types1426 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1426 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1426_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1426_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1426_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1426_3 [] = {0xFF01,1410,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1426 [] = {
g_atype1426_0,
g_atype1426_1,
g_atype1426_2,
g_atype1426_3,
};

static const long offsets1426 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1427[];
static const uint32 types1427 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1427 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1427_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1427_3 [] = {0xFF01,1418,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1427 [] = {
g_atype1427_0,
g_atype1427_1,
g_atype1427_2,
g_atype1427_3,
};

static const long offsets1427 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1428[];
static const uint32 types1428 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1428 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1428_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1428_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1428_2 [] = {0xFF01,1355,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1428 [] = {
g_atype1428_0,
g_atype1428_1,
g_atype1428_2,
};

static const long offsets1428 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1429[];
static const uint32 types1429 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1429 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1429_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1429_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1429_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1429_3 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1429_4 [] = {1428,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1429 [] = {
g_atype1429_0,
g_atype1429_1,
g_atype1429_2,
g_atype1429_3,
g_atype1429_4,
};

static const long offsets1429 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
};

extern const char *names1430[];
static const uint32 types1430 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1430 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1430_0 [] = {0xFF01,1286,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_1 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_2 [] = {0xFF01,1355,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_3 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_4 [] = {1428,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_5 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_6 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_7 [] = {0xFF01,1208,0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_8 [] = {1429,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_9 [] = {1429,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_10 [] = {0xFF01,1238,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_11 [] = {0xFF01,1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_12 [] = {0xFF01,1237,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_13 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1430_14 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1430 [] = {
g_atype1430_0,
g_atype1430_1,
g_atype1430_2,
g_atype1430_3,
g_atype1430_4,
g_atype1430_5,
g_atype1430_6,
g_atype1430_7,
g_atype1430_8,
g_atype1430_9,
g_atype1430_10,
g_atype1430_11,
g_atype1430_12,
g_atype1430_13,
g_atype1430_14,
};

static const long offsets1430 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
+ @CHROFF(13,0),
+ @CHROFF(13,1),
};

extern const char *names1432[];
static const uint32 types1432 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1432 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1432_0 [] = {0xFF01,737,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1432_1 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1432_2 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1432_3 [] = {950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1432_4 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1432_5 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1432 [] = {
g_atype1432_0,
g_atype1432_1,
g_atype1432_2,
g_atype1432_3,
g_atype1432_4,
g_atype1432_5,
};

static const long offsets1432 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
};

extern const char *names1433[];
static const uint32 types1433 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
SK_INT64,
};

static const uint16 attr_flags1433 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1433_0 [] = {942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_1 [] = {0xFF01,1003,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_2 [] = {0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_3 [] = {0xFF01,7,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_4 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_5 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_6 [] = {0xFF01,7,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_7 [] = {7,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_8 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_9 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_10 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_11 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_12 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_13 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_14 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_15 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_16 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_17 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_18 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_19 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_20 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_21 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_22 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_23 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_24 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_25 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_26 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_27 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_28 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_29 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_30 [] = {870,0xFFFF};
static const EIF_TYPE_INDEX g_atype1433_31 [] = {870,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1433 [] = {
g_atype1433_0,
g_atype1433_1,
g_atype1433_2,
g_atype1433_3,
g_atype1433_4,
g_atype1433_5,
g_atype1433_6,
g_atype1433_7,
g_atype1433_8,
g_atype1433_9,
g_atype1433_10,
g_atype1433_11,
g_atype1433_12,
g_atype1433_13,
g_atype1433_14,
g_atype1433_15,
g_atype1433_16,
g_atype1433_17,
g_atype1433_18,
g_atype1433_19,
g_atype1433_20,
g_atype1433_21,
g_atype1433_22,
g_atype1433_23,
g_atype1433_24,
g_atype1433_25,
g_atype1433_26,
g_atype1433_27,
g_atype1433_28,
g_atype1433_29,
g_atype1433_30,
g_atype1433_31,
};

static const long offsets1433 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
+ @CHROFF(8,4),
+ @CHROFF(8,5),
+ @CHROFF(8,6),
+ @CHROFF(8,7),
+ @CHROFF(8,8),
+ @CHROFF(8,9),
+ @CHROFF(8,10),
+ @CHROFF(8,11),
+ @CHROFF(8,12),
+ @LNGOFF(8,13,0,0),
+ @LNGOFF(8,13,0,1),
+ @LNGOFF(8,13,0,2),
+ @LNGOFF(8,13,0,3),
+ @LNGOFF(8,13,0,4),
+ @LNGOFF(8,13,0,5),
+ @LNGOFF(8,13,0,6),
+ @LNGOFF(8,13,0,7),
+ @LNGOFF(8,13,0,8),
+ @I64OFF(8,13,0,9,0,0,0),
+ @I64OFF(8,13,0,9,0,0,1),
};

extern const char *names1434[];
static const uint32 types1434 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
SK_INT64,
};

static const uint16 attr_flags1434 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1434_0 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_1 [] = {942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_2 [] = {0xFF01,1003,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_3 [] = {0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_4 [] = {0xFF01,7,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_5 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_6 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_7 [] = {0xFF01,7,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_8 [] = {7,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_9 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_10 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_11 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_12 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_13 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_14 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_15 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_16 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_17 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_18 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_19 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_20 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_21 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_22 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_23 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_24 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_25 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_26 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_27 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_28 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_29 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_30 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_31 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_32 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_33 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_34 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_35 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_36 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_37 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_38 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_39 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_40 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_41 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_42 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_43 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_44 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_45 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_46 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_47 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_48 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_49 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_50 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_51 [] = {870,0xFFFF};
static const EIF_TYPE_INDEX g_atype1434_52 [] = {870,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1434 [] = {
g_atype1434_0,
g_atype1434_1,
g_atype1434_2,
g_atype1434_3,
g_atype1434_4,
g_atype1434_5,
g_atype1434_6,
g_atype1434_7,
g_atype1434_8,
g_atype1434_9,
g_atype1434_10,
g_atype1434_11,
g_atype1434_12,
g_atype1434_13,
g_atype1434_14,
g_atype1434_15,
g_atype1434_16,
g_atype1434_17,
g_atype1434_18,
g_atype1434_19,
g_atype1434_20,
g_atype1434_21,
g_atype1434_22,
g_atype1434_23,
g_atype1434_24,
g_atype1434_25,
g_atype1434_26,
g_atype1434_27,
g_atype1434_28,
g_atype1434_29,
g_atype1434_30,
g_atype1434_31,
g_atype1434_32,
g_atype1434_33,
g_atype1434_34,
g_atype1434_35,
g_atype1434_36,
g_atype1434_37,
g_atype1434_38,
g_atype1434_39,
g_atype1434_40,
g_atype1434_41,
g_atype1434_42,
g_atype1434_43,
g_atype1434_44,
g_atype1434_45,
g_atype1434_46,
g_atype1434_47,
g_atype1434_48,
g_atype1434_49,
g_atype1434_50,
g_atype1434_51,
g_atype1434_52,
};

static const long offsets1434 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @CHROFF(12,0),
+ @CHROFF(12,1),
+ @CHROFF(12,2),
+ @CHROFF(12,3),
+ @CHROFF(12,4),
+ @CHROFF(12,5),
+ @CHROFF(12,6),
+ @CHROFF(12,7),
+ @CHROFF(12,8),
+ @CHROFF(12,9),
+ @CHROFF(12,10),
+ @CHROFF(12,11),
+ @CHROFF(12,12),
+ @CHROFF(12,13),
+ @CHROFF(12,14),
+ @CHROFF(12,15),
+ @LNGOFF(12,16,0,0),
+ @LNGOFF(12,16,0,1),
+ @LNGOFF(12,16,0,2),
+ @LNGOFF(12,16,0,3),
+ @LNGOFF(12,16,0,4),
+ @LNGOFF(12,16,0,5),
+ @LNGOFF(12,16,0,6),
+ @LNGOFF(12,16,0,7),
+ @LNGOFF(12,16,0,8),
+ @LNGOFF(12,16,0,9),
+ @LNGOFF(12,16,0,10),
+ @LNGOFF(12,16,0,11),
+ @LNGOFF(12,16,0,12),
+ @LNGOFF(12,16,0,13),
+ @LNGOFF(12,16,0,14),
+ @LNGOFF(12,16,0,15),
+ @LNGOFF(12,16,0,16),
+ @LNGOFF(12,16,0,17),
+ @LNGOFF(12,16,0,18),
+ @LNGOFF(12,16,0,19),
+ @LNGOFF(12,16,0,20),
+ @LNGOFF(12,16,0,21),
+ @LNGOFF(12,16,0,22),
+ @I64OFF(12,16,0,23,0,0,0),
+ @I64OFF(12,16,0,23,0,0,1),
};

extern const char *names1435[];
static const uint32 types1435 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
SK_INT64,
};

static const uint16 attr_flags1435 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1435_0 [] = {0xFF01,942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_1 [] = {942,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_2 [] = {0xFF01,1003,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_3 [] = {0xFF01,1256,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_4 [] = {0xFF01,7,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_5 [] = {0xFF01,950,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_6 [] = {0xFF01,947,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_7 [] = {0xFF01,7,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_8 [] = {7,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_9 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_10 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_11 [] = {0xFF01,714,873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_12 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_13 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_14 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_15 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_16 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_17 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_18 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_19 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_20 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_21 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_22 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_23 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_24 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_25 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_26 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_27 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_28 [] = {882,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_29 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_30 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_31 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_32 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_33 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_34 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_35 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_36 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_37 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_38 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_39 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_40 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_41 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_42 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_43 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_44 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_45 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_46 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_47 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_48 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_49 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_50 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_51 [] = {870,0xFFFF};
static const EIF_TYPE_INDEX g_atype1435_52 [] = {870,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1435 [] = {
g_atype1435_0,
g_atype1435_1,
g_atype1435_2,
g_atype1435_3,
g_atype1435_4,
g_atype1435_5,
g_atype1435_6,
g_atype1435_7,
g_atype1435_8,
g_atype1435_9,
g_atype1435_10,
g_atype1435_11,
g_atype1435_12,
g_atype1435_13,
g_atype1435_14,
g_atype1435_15,
g_atype1435_16,
g_atype1435_17,
g_atype1435_18,
g_atype1435_19,
g_atype1435_20,
g_atype1435_21,
g_atype1435_22,
g_atype1435_23,
g_atype1435_24,
g_atype1435_25,
g_atype1435_26,
g_atype1435_27,
g_atype1435_28,
g_atype1435_29,
g_atype1435_30,
g_atype1435_31,
g_atype1435_32,
g_atype1435_33,
g_atype1435_34,
g_atype1435_35,
g_atype1435_36,
g_atype1435_37,
g_atype1435_38,
g_atype1435_39,
g_atype1435_40,
g_atype1435_41,
g_atype1435_42,
g_atype1435_43,
g_atype1435_44,
g_atype1435_45,
g_atype1435_46,
g_atype1435_47,
g_atype1435_48,
g_atype1435_49,
g_atype1435_50,
g_atype1435_51,
g_atype1435_52,
};

static const long offsets1435 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @CHROFF(12,0),
+ @CHROFF(12,1),
+ @CHROFF(12,2),
+ @CHROFF(12,3),
+ @CHROFF(12,4),
+ @CHROFF(12,5),
+ @CHROFF(12,6),
+ @CHROFF(12,7),
+ @CHROFF(12,8),
+ @CHROFF(12,9),
+ @CHROFF(12,10),
+ @CHROFF(12,11),
+ @CHROFF(12,12),
+ @CHROFF(12,13),
+ @CHROFF(12,14),
+ @CHROFF(12,15),
+ @LNGOFF(12,16,0,0),
+ @LNGOFF(12,16,0,1),
+ @LNGOFF(12,16,0,2),
+ @LNGOFF(12,16,0,3),
+ @LNGOFF(12,16,0,4),
+ @LNGOFF(12,16,0,5),
+ @LNGOFF(12,16,0,6),
+ @LNGOFF(12,16,0,7),
+ @LNGOFF(12,16,0,8),
+ @LNGOFF(12,16,0,9),
+ @LNGOFF(12,16,0,10),
+ @LNGOFF(12,16,0,11),
+ @LNGOFF(12,16,0,12),
+ @LNGOFF(12,16,0,13),
+ @LNGOFF(12,16,0,14),
+ @LNGOFF(12,16,0,15),
+ @LNGOFF(12,16,0,16),
+ @LNGOFF(12,16,0,17),
+ @LNGOFF(12,16,0,18),
+ @LNGOFF(12,16,0,19),
+ @LNGOFF(12,16,0,20),
+ @LNGOFF(12,16,0,21),
+ @LNGOFF(12,16,0,22),
+ @I64OFF(12,16,0,23,0,0,0),
+ @I64OFF(12,16,0,23,0,0,1),
};

extern const char *names1436[];
static const uint32 types1436 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1436 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1436_0 [] = {0xFF01,716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1436_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1436_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1436_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1436_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1436_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1436_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1436_7 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1436 [] = {
g_atype1436_0,
g_atype1436_1,
g_atype1436_2,
g_atype1436_3,
g_atype1436_4,
g_atype1436_5,
g_atype1436_6,
g_atype1436_7,
};

static const long offsets1436 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

extern const char *names1437[];
static const uint32 types1437 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1437 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1437_0 [] = {0xFF01,716,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1437_1 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1437_2 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1437_3 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1437_4 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1437_5 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1437_6 [] = {873,0xFFFF};
static const EIF_TYPE_INDEX g_atype1437_7 [] = {873,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1437 [] = {
g_atype1437_0,
g_atype1437_1,
g_atype1437_2,
g_atype1437_3,
g_atype1437_4,
g_atype1437_5,
g_atype1437_6,
g_atype1437_7,
};

static const long offsets1437 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

const struct cnode egc_fsystem_init[] = {
{
	(long) 0,
	(long) 0,
	"ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_BOOLEAN_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_ARRAY_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LX_START_CONDITION",
	names5,
	types5,
	attr_flags5,
	gtypes5,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets5,
	NULL
},
{
	(long) 0,
	(long) 0,
	"LX_DESCRIPTION_OVERRIDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"LX_ACTION_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 8,
	(long) 8,
	"RX_CHARACTER_SET",
	names8,
	types8,
	attr_flags8,
	gtypes8,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets8,
	NULL
},
{
	(long) 33,
	(long) 33,
	"LX_DESCRIPTION",
	names9,
	types9,
	attr_flags9,
	gtypes9,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets9,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_BOOLEAN_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DESCRIPTOR_CACHE",
	names11,
	types11,
	attr_flags11,
	gtypes11,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets11,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_EIFFEL_DECLARATION",
	names13,
	types13,
	attr_flags13,
	gtypes13,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets13,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 0,
	"VERSIONABLE",
	names15,
	types15,
	attr_flags15,
	gtypes15,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets15,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_PAGE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ENCODING",
	names18,
	types18,
	attr_flags18,
	gtypes18,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets18,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_HASH_FUNCTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_HASH_FUNCTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_HASH_FUNCTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"GEANT_SELECT",
	names22,
	types22,
	attr_flags22,
	gtypes22,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets22,
	NULL
},
{
	(long) 1,
	(long) 1,
	"GEANT_REDEFINE",
	names23,
	types23,
	attr_flags23,
	gtypes23,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets23,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CHARACTER_PROPERTY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_POSITION_TABLE",
	names32,
	types32,
	attr_flags32,
	gtypes32,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets32,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RT_DBG_EXECUTION_PARAMETERS",
	names34,
	types34,
	attr_flags34,
	gtypes34,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets34,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_RUNTIME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x6000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPERATING_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STD_FILES",
	names51,
	types51,
	attr_flags51,
	gtypes51,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets51,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_PROJECT_OPTIONS",
	names52,
	types52,
	attr_flags52,
	gtypes52,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets52,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_SHARED_CHARACTER_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_OPTION_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_ERROR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_BYTE_CODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LX_EQUIVALENCE_CLASSES",
	names57,
	types57,
	attr_flags57,
	gtypes57,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets57,
	NULL
},
{
	(long) 4,
	(long) 4,
	"LX_SYMBOL_PARTITIONS",
	names58,
	types58,
	attr_flags58,
	gtypes58,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets58,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"YY_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_SHELL_COMMAND",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names68,
	types68,
	attr_flags68,
	gtypes68,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets68,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names69,
	types69,
	attr_flags69,
	gtypes69,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets69,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names70,
	types70,
	attr_flags70,
	gtypes70,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets70,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names71,
	types71,
	attr_flags71,
	gtypes71,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets71,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXABLE_SORTER",
	names75,
	types75,
	attr_flags75,
	gtypes75,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets75,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXABLE_SORTER",
	names76,
	types76,
	attr_flags76,
	gtypes76,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets76,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BUBBLE_SORTER",
	names77,
	types77,
	attr_flags77,
	gtypes77,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets77,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BUBBLE_SORTER",
	names78,
	types78,
	attr_flags78,
	gtypes78,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets78,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_QUICK_SORTER",
	names79,
	types79,
	attr_flags79,
	gtypes79,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets79,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_TRAVERSABLE",
	names80,
	types80,
	attr_flags80,
	gtypes80,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets80,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_BREADTH_FIRST_TRAVERSABLE",
	names81,
	types81,
	attr_flags81,
	gtypes81,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets81,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_I",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_PARSER_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_EXPAT_PARSER_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_CALLBACKS_FILTER_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_ERROR_CODES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_EXTERNAL_RESOLVER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_NULL_EXTERNAL_RESOLVER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_URI_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_DEFAULT_URI_SOURCE",
	names95,
	types95,
	attr_flags95,
	gtypes95,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets95,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OBJECT_GRAPH_MARKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MATH_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DOUBLE_MATH",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFACTORING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_GOBO_VERSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"GEANT_VERSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEP_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names108,
	types108,
	attr_flags108,
	gtypes108,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets108,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names109,
	types109,
	attr_flags109,
	gtypes109,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets109,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names110,
	types110,
	attr_flags110,
	gtypes110,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets110,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names111,
	types111,
	attr_flags111,
	gtypes111,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets111,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names112,
	types112,
	attr_flags112,
	gtypes112,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets112,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names113,
	types113,
	attr_flags113,
	gtypes113,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets113,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_CHARACTER_CODES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_UNICODE_CHARACTERS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_UNICODE_CHARACTERS_1_1",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_UNICODE_CHARACTERS_1_0",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_CHARACTER_32_CODES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM_ENTRY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ENCODING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_IMP",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_DTD_CALLBACKS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_DTD_CALLBACKS_NULL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_EIFFEL_PARSER_ERRORS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_DTD_CALLBACKS_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_FORWARD_DTD_CALLBACKS",
	names129,
	types129,
	attr_flags129,
	gtypes129,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets129,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CELL",
	names130,
	types130,
	attr_flags130,
	gtypes130,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets130,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CELL",
	names131,
	types131,
	attr_flags131,
	gtypes131,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets131,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CELL",
	names132,
	types132,
	attr_flags132,
	gtypes132,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets132,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CELL",
	names133,
	types133,
	attr_flags133,
	gtypes133,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets133,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DS_PAIR",
	names134,
	types134,
	attr_flags134,
	gtypes134,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets134,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DS_PAIR",
	names135,
	types135,
	attr_flags135,
	gtypes135,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets135,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DS_LINKABLE",
	names136,
	types136,
	attr_flags136,
	gtypes136,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets136,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DS_LINKABLE",
	names137,
	types137,
	attr_flags137,
	gtypes137,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets137,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DS_LINKABLE",
	names138,
	types138,
	attr_flags138,
	gtypes138,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets138,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_BILINKABLE",
	names139,
	types139,
	attr_flags139,
	gtypes139,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets139,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_BILINKABLE",
	names140,
	types140,
	attr_flags140,
	gtypes140,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets140,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PART_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PART_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PART_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_REVERSE_PART_COMPARATOR",
	names144,
	types144,
	attr_flags144,
	gtypes144,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets144,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_REVERSE_PART_COMPARATOR",
	names145,
	types145,
	attr_flags145,
	gtypes145,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets145,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"GEANT_ELEMENT_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_NODE_PROCESSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_TREE_TO_EVENTS",
	names151,
	types151,
	attr_flags151,
	gtypes151,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets151,
	NULL
},
{
	(long) 7,
	(long) 7,
	"XM_NODE_TYPER",
	names152,
	types152,
	attr_flags152,
	gtypes152,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets152,
	NULL
},
{
	(long) 0,
	(long) 0,
	"AP_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"AP_OPTION",
	names154,
	types154,
	attr_flags154,
	gtypes154,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets154,
	NULL
},
{
	(long) 11,
	(long) 11,
	"AP_OPTION_WITH_PARAMETER",
	names155,
	types155,
	attr_flags155,
	gtypes155,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets155,
	NULL
},
{
	(long) 12,
	(long) 12,
	"AP_STRING_OPTION",
	names156,
	types156,
	attr_flags156,
	gtypes156,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets156,
	NULL
},
{
	(long) 8,
	(long) 8,
	"AP_FLAG",
	names157,
	types157,
	attr_flags157,
	gtypes157,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets157,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_GENERAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC_INFORMATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"INTEGER_OVERFLOW_CHECKER",
	names163,
	types163,
	attr_flags163,
	gtypes163,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets163,
	NULL
},
{
	(long) 7,
	(long) 7,
	"STRING_TO_NUMERIC_CONVERTOR",
	names164,
	types164,
	attr_flags164,
	gtypes164,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets164,
	NULL
},
{
	(long) 11,
	(long) 11,
	"HEXADECIMAL_STRING_TO_INTEGER_CONVERTER",
	names165,
	types165,
	attr_flags165,
	gtypes165,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets165,
	NULL
},
{
	(long) 10,
	(long) 10,
	"STRING_TO_INTEGER_CONVERTOR",
	names166,
	types166,
	attr_flags166,
	gtypes166,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets166,
	NULL
},
{
	(long) 15,
	(long) 15,
	"STRING_TO_REAL_CONVERTOR",
	names167,
	types167,
	attr_flags167,
	gtypes167,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets167,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_SEARCHER",
	names168,
	types168,
	attr_flags168,
	gtypes168,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets168,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_32_SEARCHER",
	names169,
	types169,
	attr_flags169,
	gtypes169,
	(uint16) 0x6000,
	(void (*)()) 0,
	offsets169,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_8_SEARCHER",
	names170,
	types170,
	attr_flags170,
	gtypes170,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets170,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STREAMS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PART_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 10,
	(long) 10,
	"LX_RULE",
	names175,
	types175,
	attr_flags175,
	gtypes175,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets175,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_BUFFER",
	names178,
	types178,
	attr_flags178,
	gtypes178,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets178,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UTF8_BUFFER",
	names179,
	types179,
	attr_flags179,
	gtypes179,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets179,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UNICODE_BUFFER",
	names180,
	types180,
	attr_flags180,
	gtypes180,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets180,
	NULL
},
{
	(long) 12,
	(long) 12,
	"YY_FILE_BUFFER",
	names181,
	types181,
	attr_flags181,
	gtypes181,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets181,
	NULL
},
{
	(long) 14,
	(long) 14,
	"YY_UTF8_FILE_BUFFER",
	names182,
	types182,
	attr_flags182,
	gtypes182,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets182,
	NULL
},
{
	(long) 15,
	(long) 15,
	"YY_UNICODE_FILE_BUFFER",
	names183,
	types183,
	attr_flags183,
	gtypes183,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets183,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"GEANT_VARIABLE_RESOLVER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"GEANT_VARIABLES_VARIABLE_RESOLVER",
	names190,
	types190,
	attr_flags190,
	gtypes190,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets190,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_CALLBACKS_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DP_COMMAND",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_ACTION",
	names193,
	types193,
	attr_flags193,
	gtypes193,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets193,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_CALLBACKS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_CALLBACKS_NULL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_FORWARD_CALLBACKS",
	names196,
	types196,
	attr_flags196,
	gtypes196,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets196,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_CALLBACKS_FILTER",
	names197,
	types197,
	attr_flags197,
	gtypes197,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets197,
	NULL
},
{
	(long) 6,
	(long) 6,
	"XM_CALLBACKS_TO_TREE_FILTER",
	names198,
	types198,
	attr_flags198,
	gtypes198,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets198,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_STOP_ON_ERROR_FILTER",
	names199,
	types199,
	attr_flags199,
	gtypes199,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets199,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XM_PARSER_STOP_ON_ERROR_FILTER",
	names200,
	types200,
	attr_flags200,
	gtypes200,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets200,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names203,
	types203,
	attr_flags203,
	gtypes203,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets203,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names204,
	types204,
	attr_flags204,
	gtypes204,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets204,
	NULL
},
{
	(long) 1,
	(long) 1,
	"HASH_TABLE_CURSOR",
	names205,
	types205,
	attr_flags205,
	gtypes205,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets205,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ARRAYED_LIST_CURSOR",
	names206,
	types206,
	attr_flags206,
	gtypes206,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets206,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_EXECUTION_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION",
	names211,
	types211,
	attr_flags211,
	gtypes211,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets211,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DEVELOPER_EXCEPTION",
	names212,
	types212,
	attr_flags212,
	gtypes212,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets212,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONVERSION_FAILURE",
	names213,
	types213,
	attr_flags213,
	gtypes213,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets213,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MACHINE_EXCEPTION",
	names214,
	types214,
	attr_flags214,
	gtypes214,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets214,
	NULL
},
{
	(long) 7,
	(long) 7,
	"HARDWARE_EXCEPTION",
	names215,
	types215,
	attr_flags215,
	gtypes215,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets215,
	NULL
},
{
	(long) 7,
	(long) 7,
	"FLOATING_POINT_FAILURE",
	names216,
	types216,
	attr_flags216,
	gtypes216,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets216,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OPERATING_SYSTEM_EXCEPTION",
	names217,
	types217,
	attr_flags217,
	gtypes217,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets217,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_SIGNAL_FAILURE",
	names218,
	types218,
	attr_flags218,
	gtypes218,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets218,
	NULL
},
{
	(long) 10,
	(long) 10,
	"COM_FAILURE",
	names219,
	types219,
	attr_flags219,
	gtypes219,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets219,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_FAILURE",
	names220,
	types220,
	attr_flags220,
	gtypes220,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets220,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SYS_EXCEPTION",
	names221,
	types221,
	attr_flags221,
	gtypes221,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets221,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EIFFEL_RUNTIME_PANIC",
	names222,
	types222,
	attr_flags222,
	gtypes222,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets222,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OLD_VIOLATION",
	names223,
	types223,
	attr_flags223,
	gtypes223,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets223,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIF_EXCEPTION",
	names224,
	types224,
	attr_flags224,
	gtypes224,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets224,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFEL_RUNTIME_EXCEPTION",
	names225,
	types225,
	attr_flags225,
	gtypes225,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets225,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXTERNAL_FAILURE",
	names226,
	types226,
	attr_flags226,
	gtypes226,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets226,
	NULL
},
{
	(long) 8,
	(long) 8,
	"NO_MORE_MEMORY",
	names227,
	types227,
	attr_flags227,
	gtypes227,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets227,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DATA_EXCEPTION",
	names228,
	types228,
	attr_flags228,
	gtypes228,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets228,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MISMATCH_FAILURE",
	names229,
	types229,
	attr_flags229,
	gtypes229,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets229,
	NULL
},
{
	(long) 9,
	(long) 9,
	"IO_FAILURE",
	names230,
	types230,
	attr_flags230,
	gtypes230,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets230,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SERIALIZATION_FAILURE",
	names231,
	types231,
	attr_flags231,
	gtypes231,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets231,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LANGUAGE_EXCEPTION",
	names232,
	types232,
	attr_flags232,
	gtypes232,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets232,
	NULL
},
{
	(long) 7,
	(long) 7,
	"BAD_INSPECT_VALUE",
	names233,
	types233,
	attr_flags233,
	gtypes233,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets233,
	NULL
},
{
	(long) 9,
	(long) 9,
	"ROUTINE_FAILURE",
	names234,
	types234,
	attr_flags234,
	gtypes234,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets234,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_TARGET",
	names235,
	types235,
	attr_flags235,
	gtypes235,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets235,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_ASSIGNED_TO_EXPANDED",
	names236,
	types236,
	attr_flags236,
	gtypes236,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets236,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFELSTUDIO_SPECIFIC_LANGUAGE_EXCEPTION",
	names237,
	types237,
	attr_flags237,
	gtypes237,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets237,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CREATE_ON_DEFERRED",
	names238,
	types238,
	attr_flags238,
	gtypes238,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets238,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ADDRESS_APPLIED_TO_MELTED_FEATURE",
	names239,
	types239,
	attr_flags239,
	gtypes239,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets239,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OBSOLETE_EXCEPTION",
	names240,
	types240,
	attr_flags240,
	gtypes240,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets240,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESUMPTION_FAILURE",
	names241,
	types241,
	attr_flags241,
	gtypes241,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets241,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESCUE_FAILURE",
	names242,
	types242,
	attr_flags242,
	gtypes242,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets242,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION_IN_SIGNAL_HANDLER_FAILURE",
	names243,
	types243,
	attr_flags243,
	gtypes243,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets243,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ASSERTION_VIOLATION",
	names244,
	types244,
	attr_flags244,
	gtypes244,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets244,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LOOP_INVARIANT_VIOLATION",
	names245,
	types245,
	attr_flags245,
	gtypes245,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets245,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VARIANT_VIOLATION",
	names246,
	types246,
	attr_flags246,
	gtypes246,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets246,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CHECK_VIOLATION",
	names247,
	types247,
	attr_flags247,
	gtypes247,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets247,
	NULL
},
{
	(long) 8,
	(long) 8,
	"INVARIANT_VIOLATION",
	names248,
	types248,
	attr_flags248,
	gtypes248,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets248,
	NULL
},
{
	(long) 7,
	(long) 7,
	"POSTCONDITION_VIOLATION",
	names249,
	types249,
	attr_flags249,
	gtypes249,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets249,
	NULL
},
{
	(long) 7,
	(long) 7,
	"PRECONDITION_VIOLATION",
	names250,
	types250,
	attr_flags250,
	gtypes250,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets250,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_IMPORTED_FORMATTERS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DISPOSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 2,
	"MANAGED_POINTER",
	names254,
	types254,
	attr_flags254,
	gtypes254,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets254,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARABLE_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARABLE_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_BOOLEAN_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_UNICODE_STRUCTURE_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_END_TAG_CHECKER",
	names270,
	types270,
	attr_flags270,
	gtypes270,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets270,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_SHARED_STRINGS_FILTER",
	names271,
	types271,
	attr_flags271,
	gtypes271,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets271,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_EIFFEL_UNICODE_STRUCTURE_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REFLECTED_OBJECT",
	names274,
	types274,
	attr_flags274,
	gtypes274,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets274,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"REFLECTED_COPY_SEMANTICS_OBJECT",
	names278,
	types278,
	attr_flags278,
	gtypes278,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets278,
	NULL
},
{
	(long) 3,
	(long) 3,
	"REFLECTED_REFERENCE_OBJECT",
	names279,
	types279,
	attr_flags279,
	gtypes279,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets279,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names280,
	types280,
	attr_flags280,
	gtypes280,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets280,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names281,
	types281,
	attr_flags281,
	gtypes281,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets281,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names282,
	types282,
	attr_flags282,
	gtypes282,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets282,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names283,
	types283,
	attr_flags283,
	gtypes283,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets283,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names284,
	types284,
	attr_flags284,
	gtypes284,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets284,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names285,
	types285,
	attr_flags285,
	gtypes285,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets285,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names286,
	types286,
	attr_flags286,
	gtypes286,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets286,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names287,
	types287,
	attr_flags287,
	gtypes287,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets287,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names288,
	types288,
	attr_flags288,
	gtypes288,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets288,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names289,
	types289,
	attr_flags289,
	gtypes289,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets289,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names290,
	types290,
	attr_flags290,
	gtypes290,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets290,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names291,
	types291,
	attr_flags291,
	gtypes291,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets291,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"NATIVE_STRING",
	names294,
	types294,
	attr_flags294,
	gtypes294,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets294,
	NULL
},
{
	(long) 6,
	(long) 6,
	"DIRECTORY",
	names295,
	types295,
	attr_flags295,
	gtypes295,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets295,
	NULL
},
{
	(long) 5,
	(long) 5,
	"FILE_INFO",
	names296,
	types296,
	attr_flags296,
	gtypes296,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets296,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UNIX_FILE_INFO",
	names297,
	types297,
	attr_flags297,
	gtypes297,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets297,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EXECUTION_ENVIRONMENT",
	names298,
	types298,
	attr_flags298,
	gtypes298,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets298,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 8,
	(long) 8,
	"AP_DISPLAY_HELP_FLAG",
	names300,
	types300,
	attr_flags300,
	gtypes300,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets300,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_UNICODE_CHARACTER_BUFFER",
	names303,
	types303,
	attr_flags303,
	gtypes303,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets303,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_CHARACTER_BUFFER",
	names304,
	types304,
	attr_flags304,
	gtypes304,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets304,
	NULL
},
{
	(long) 2,
	(long) 2,
	"C_STRING",
	names305,
	types305,
	attr_flags305,
	gtypes305,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets305,
	NULL
},
{
	(long) 13,
	(long) 13,
	"IO_MEDIUM",
	names306,
	types306,
	attr_flags306,
	gtypes306,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets306,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DEBUG_OUTPUT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 15,
	(long) 15,
	"RT_DBG_CALL_RECORD",
	names308,
	types308,
	attr_flags308,
	gtypes308,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets308,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSTRACT_SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"RT_DBG_VALUE_RECORD",
	names310,
	types310,
	attr_flags310,
	gtypes310,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets310,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names311,
	types311,
	attr_flags311,
	gtypes311,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets311,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names312,
	types312,
	attr_flags312,
	gtypes312,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets312,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names313,
	types313,
	attr_flags313,
	gtypes313,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets313,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names314,
	types314,
	attr_flags314,
	gtypes314,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets314,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names315,
	types315,
	attr_flags315,
	gtypes315,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets315,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names316,
	types316,
	attr_flags316,
	gtypes316,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets316,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names317,
	types317,
	attr_flags317,
	gtypes317,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets317,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names318,
	types318,
	attr_flags318,
	gtypes318,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets318,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names319,
	types319,
	attr_flags319,
	gtypes319,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets319,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names320,
	types320,
	attr_flags320,
	gtypes320,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets320,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names321,
	types321,
	attr_flags321,
	gtypes321,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets321,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names322,
	types322,
	attr_flags322,
	gtypes322,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets322,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names323,
	types323,
	attr_flags323,
	gtypes323,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets323,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names324,
	types324,
	attr_flags324,
	gtypes324,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets324,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names325,
	types325,
	attr_flags325,
	gtypes325,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets325,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names326,
	types326,
	attr_flags326,
	gtypes326,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets326,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names327,
	types327,
	attr_flags327,
	gtypes327,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets327,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names328,
	types328,
	attr_flags328,
	gtypes328,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets328,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names329,
	types329,
	attr_flags329,
	gtypes329,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets329,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names330,
	types330,
	attr_flags330,
	gtypes330,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets330,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names331,
	types331,
	attr_flags331,
	gtypes331,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets331,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names332,
	types332,
	attr_flags332,
	gtypes332,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets332,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names333,
	types333,
	attr_flags333,
	gtypes333,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets333,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names334,
	types334,
	attr_flags334,
	gtypes334,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets334,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names335,
	types335,
	attr_flags335,
	gtypes335,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets335,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names336,
	types336,
	attr_flags336,
	gtypes336,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets336,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names337,
	types337,
	attr_flags337,
	gtypes337,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets337,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names338,
	types338,
	attr_flags338,
	gtypes338,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets338,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names339,
	types339,
	attr_flags339,
	gtypes339,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets339,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names340,
	types340,
	attr_flags340,
	gtypes340,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets340,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names341,
	types341,
	attr_flags341,
	gtypes341,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets341,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names342,
	types342,
	attr_flags342,
	gtypes342,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets342,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names343,
	types343,
	attr_flags343,
	gtypes343,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets343,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names344,
	types344,
	attr_flags344,
	gtypes344,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets344,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names345,
	types345,
	attr_flags345,
	gtypes345,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets345,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names346,
	types346,
	attr_flags346,
	gtypes346,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets346,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names347,
	types347,
	attr_flags347,
	gtypes347,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets347,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names348,
	types348,
	attr_flags348,
	gtypes348,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets348,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names349,
	types349,
	attr_flags349,
	gtypes349,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets349,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names350,
	types350,
	attr_flags350,
	gtypes350,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets350,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names351,
	types351,
	attr_flags351,
	gtypes351,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets351,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names352,
	types352,
	attr_flags352,
	gtypes352,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets352,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names353,
	types353,
	attr_flags353,
	gtypes353,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets353,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names354,
	types354,
	attr_flags354,
	gtypes354,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets354,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names355,
	types355,
	attr_flags355,
	gtypes355,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets355,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_QUEUE_ITERATION_CURSOR",
	names369,
	types369,
	attr_flags369,
	gtypes369,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets369,
	NULL
},
{
	(long) 2,
	(long) 2,
	"FILE_ITERATION_CURSOR",
	names370,
	types370,
	attr_flags370,
	gtypes370,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets370,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_MARKUP_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS_32",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"STRING_ITERATION_CURSOR",
	names392,
	types392,
	attr_flags392,
	gtypes392,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets392,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_ARGUMENTS",
	names394,
	types394,
	attr_flags394,
	gtypes394,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets394,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names424,
	types424,
	attr_flags424,
	gtypes424,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets424,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names425,
	types425,
	attr_flags425,
	gtypes425,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets425,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names426,
	types426,
	attr_flags426,
	gtypes426,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets426,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names427,
	types427,
	attr_flags427,
	gtypes427,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets427,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names428,
	types428,
	attr_flags428,
	gtypes428,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets428,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names429,
	types429,
	attr_flags429,
	gtypes429,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets429,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names430,
	types430,
	attr_flags430,
	gtypes430,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets430,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names431,
	types431,
	attr_flags431,
	gtypes431,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets431,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names432,
	types432,
	attr_flags432,
	gtypes432,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets432,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names433,
	types433,
	attr_flags433,
	gtypes433,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets433,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names434,
	types434,
	attr_flags434,
	gtypes434,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets434,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names435,
	types435,
	attr_flags435,
	gtypes435,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets435,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names436,
	types436,
	attr_flags436,
	gtypes436,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets436,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names437,
	types437,
	attr_flags437,
	gtypes437,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets437,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names438,
	types438,
	attr_flags438,
	gtypes438,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets438,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names439,
	types439,
	attr_flags439,
	gtypes439,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets439,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names440,
	types440,
	attr_flags440,
	gtypes440,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets440,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names441,
	types441,
	attr_flags441,
	gtypes441,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets441,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names442,
	types442,
	attr_flags442,
	gtypes442,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets442,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names443,
	types443,
	attr_flags443,
	gtypes443,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets443,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names444,
	types444,
	attr_flags444,
	gtypes444,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets444,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names445,
	types445,
	attr_flags445,
	gtypes445,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets445,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names446,
	types446,
	attr_flags446,
	gtypes446,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets446,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names447,
	types447,
	attr_flags447,
	gtypes447,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets447,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names448,
	types448,
	attr_flags448,
	gtypes448,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets448,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names449,
	types449,
	attr_flags449,
	gtypes449,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets449,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names450,
	types450,
	attr_flags450,
	gtypes450,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets450,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names451,
	types451,
	attr_flags451,
	gtypes451,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets451,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names452,
	types452,
	attr_flags452,
	gtypes452,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets452,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names453,
	types453,
	attr_flags453,
	gtypes453,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets453,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names454,
	types454,
	attr_flags454,
	gtypes454,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets454,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names455,
	types455,
	attr_flags455,
	gtypes455,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets455,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names456,
	types456,
	attr_flags456,
	gtypes456,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets456,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names457,
	types457,
	attr_flags457,
	gtypes457,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets457,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names458,
	types458,
	attr_flags458,
	gtypes458,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets458,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names459,
	types459,
	attr_flags459,
	gtypes459,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets459,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names460,
	types460,
	attr_flags460,
	gtypes460,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets460,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names461,
	types461,
	attr_flags461,
	gtypes461,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets461,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names462,
	types462,
	attr_flags462,
	gtypes462,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets462,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names463,
	types463,
	attr_flags463,
	gtypes463,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets463,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names464,
	types464,
	attr_flags464,
	gtypes464,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets464,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names465,
	types465,
	attr_flags465,
	gtypes465,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets465,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names466,
	types466,
	attr_flags466,
	gtypes466,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets466,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32_ITERATION_CURSOR",
	names467,
	types467,
	attr_flags467,
	gtypes467,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets467,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8_ITERATION_CURSOR",
	names468,
	types468,
	attr_flags468,
	gtypes468,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets468,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names469,
	types469,
	attr_flags469,
	gtypes469,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets469,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names470,
	types470,
	attr_flags470,
	gtypes470,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets470,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names471,
	types471,
	attr_flags471,
	gtypes471,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets471,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names472,
	types472,
	attr_flags472,
	gtypes472,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets472,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names473,
	types473,
	attr_flags473,
	gtypes473,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets473,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names474,
	types474,
	attr_flags474,
	gtypes474,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets474,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names475,
	types475,
	attr_flags475,
	gtypes475,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets475,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names476,
	types476,
	attr_flags476,
	gtypes476,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets476,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names477,
	types477,
	attr_flags477,
	gtypes477,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets477,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names478,
	types478,
	attr_flags478,
	gtypes478,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets478,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names479,
	types479,
	attr_flags479,
	gtypes479,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets479,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names480,
	types480,
	attr_flags480,
	gtypes480,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets480,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names481,
	types481,
	attr_flags481,
	gtypes481,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets481,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names482,
	types482,
	attr_flags482,
	gtypes482,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets482,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names483,
	types483,
	attr_flags483,
	gtypes483,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets483,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names484,
	types484,
	attr_flags484,
	gtypes484,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets484,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names485,
	types485,
	attr_flags485,
	gtypes485,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets485,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names486,
	types486,
	attr_flags486,
	gtypes486,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets486,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names487,
	types487,
	attr_flags487,
	gtypes487,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets487,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names488,
	types488,
	attr_flags488,
	gtypes488,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets488,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names489,
	types489,
	attr_flags489,
	gtypes489,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets489,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names490,
	types490,
	attr_flags490,
	gtypes490,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets490,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names491,
	types491,
	attr_flags491,
	gtypes491,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets491,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names492,
	types492,
	attr_flags492,
	gtypes492,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets492,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names493,
	types493,
	attr_flags493,
	gtypes493,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets493,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names494,
	types494,
	attr_flags494,
	gtypes494,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets494,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names495,
	types495,
	attr_flags495,
	gtypes495,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets495,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names496,
	types496,
	attr_flags496,
	gtypes496,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets496,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names497,
	types497,
	attr_flags497,
	gtypes497,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets497,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names498,
	types498,
	attr_flags498,
	gtypes498,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets498,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names499,
	types499,
	attr_flags499,
	gtypes499,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets499,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names500,
	types500,
	attr_flags500,
	gtypes500,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets500,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names501,
	types501,
	attr_flags501,
	gtypes501,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets501,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names502,
	types502,
	attr_flags502,
	gtypes502,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets502,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names503,
	types503,
	attr_flags503,
	gtypes503,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets503,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names504,
	types504,
	attr_flags504,
	gtypes504,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets504,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names505,
	types505,
	attr_flags505,
	gtypes505,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets505,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names506,
	types506,
	attr_flags506,
	gtypes506,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets506,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names507,
	types507,
	attr_flags507,
	gtypes507,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets507,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names508,
	types508,
	attr_flags508,
	gtypes508,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets508,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names509,
	types509,
	attr_flags509,
	gtypes509,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets509,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names510,
	types510,
	attr_flags510,
	gtypes510,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets510,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names511,
	types511,
	attr_flags511,
	gtypes511,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets511,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names512,
	types512,
	attr_flags512,
	gtypes512,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets512,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names513,
	types513,
	attr_flags513,
	gtypes513,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets513,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names514,
	types514,
	attr_flags514,
	gtypes514,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets514,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names515,
	types515,
	attr_flags515,
	gtypes515,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets515,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names516,
	types516,
	attr_flags516,
	gtypes516,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets516,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names517,
	types517,
	attr_flags517,
	gtypes517,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets517,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names518,
	types518,
	attr_flags518,
	gtypes518,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets518,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names519,
	types519,
	attr_flags519,
	gtypes519,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets519,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names520,
	types520,
	attr_flags520,
	gtypes520,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets520,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names521,
	types521,
	attr_flags521,
	gtypes521,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets521,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names522,
	types522,
	attr_flags522,
	gtypes522,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets522,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names523,
	types523,
	attr_flags523,
	gtypes523,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets523,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names524,
	types524,
	attr_flags524,
	gtypes524,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets524,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names525,
	types525,
	attr_flags525,
	gtypes525,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets525,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names526,
	types526,
	attr_flags526,
	gtypes526,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets526,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names527,
	types527,
	attr_flags527,
	gtypes527,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets527,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names528,
	types528,
	attr_flags528,
	gtypes528,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets528,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names529,
	types529,
	attr_flags529,
	gtypes529,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets529,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names530,
	types530,
	attr_flags530,
	gtypes530,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets530,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names531,
	types531,
	attr_flags531,
	gtypes531,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets531,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names532,
	types532,
	attr_flags532,
	gtypes532,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets532,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names533,
	types533,
	attr_flags533,
	gtypes533,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets533,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names534,
	types534,
	attr_flags534,
	gtypes534,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets534,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names535,
	types535,
	attr_flags535,
	gtypes535,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets535,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names536,
	types536,
	attr_flags536,
	gtypes536,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets536,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names537,
	types537,
	attr_flags537,
	gtypes537,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets537,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names538,
	types538,
	attr_flags538,
	gtypes538,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets538,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names539,
	types539,
	attr_flags539,
	gtypes539,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets539,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names540,
	types540,
	attr_flags540,
	gtypes540,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets540,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names541,
	types541,
	attr_flags541,
	gtypes541,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets541,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names542,
	types542,
	attr_flags542,
	gtypes542,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets542,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names543,
	types543,
	attr_flags543,
	gtypes543,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets543,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names544,
	types544,
	attr_flags544,
	gtypes544,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets544,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names545,
	types545,
	attr_flags545,
	gtypes545,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets545,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names546,
	types546,
	attr_flags546,
	gtypes546,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets546,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names547,
	types547,
	attr_flags547,
	gtypes547,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets547,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names548,
	types548,
	attr_flags548,
	gtypes548,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets548,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names549,
	types549,
	attr_flags549,
	gtypes549,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets549,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names550,
	types550,
	attr_flags550,
	gtypes550,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets550,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names551,
	types551,
	attr_flags551,
	gtypes551,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets551,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names552,
	types552,
	attr_flags552,
	gtypes552,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets552,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SET",
	names553,
	types553,
	attr_flags553,
	gtypes553,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets553,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names554,
	types554,
	attr_flags554,
	gtypes554,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets554,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names555,
	types555,
	attr_flags555,
	gtypes555,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets555,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names556,
	types556,
	attr_flags556,
	gtypes556,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets556,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names557,
	types557,
	attr_flags557,
	gtypes557,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets557,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names558,
	types558,
	attr_flags558,
	gtypes558,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets558,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names559,
	types559,
	attr_flags559,
	gtypes559,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets559,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names560,
	types560,
	attr_flags560,
	gtypes560,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets560,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names561,
	types561,
	attr_flags561,
	gtypes561,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets561,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names562,
	types562,
	attr_flags562,
	gtypes562,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets562,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names563,
	types563,
	attr_flags563,
	gtypes563,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets563,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names564,
	types564,
	attr_flags564,
	gtypes564,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets564,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names565,
	types565,
	attr_flags565,
	gtypes565,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets565,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names566,
	types566,
	attr_flags566,
	gtypes566,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets566,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names567,
	types567,
	attr_flags567,
	gtypes567,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets567,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names568,
	types568,
	attr_flags568,
	gtypes568,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets568,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names569,
	types569,
	attr_flags569,
	gtypes569,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets569,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names570,
	types570,
	attr_flags570,
	gtypes570,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets570,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names571,
	types571,
	attr_flags571,
	gtypes571,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets571,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names572,
	types572,
	attr_flags572,
	gtypes572,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets572,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names573,
	types573,
	attr_flags573,
	gtypes573,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets573,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names574,
	types574,
	attr_flags574,
	gtypes574,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets574,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names575,
	types575,
	attr_flags575,
	gtypes575,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets575,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names576,
	types576,
	attr_flags576,
	gtypes576,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets576,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names577,
	types577,
	attr_flags577,
	gtypes577,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets577,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names578,
	types578,
	attr_flags578,
	gtypes578,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets578,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names579,
	types579,
	attr_flags579,
	gtypes579,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets579,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names580,
	types580,
	attr_flags580,
	gtypes580,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets580,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names581,
	types581,
	attr_flags581,
	gtypes581,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets581,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names582,
	types582,
	attr_flags582,
	gtypes582,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets582,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names583,
	types583,
	attr_flags583,
	gtypes583,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets583,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names584,
	types584,
	attr_flags584,
	gtypes584,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets584,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names585,
	types585,
	attr_flags585,
	gtypes585,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets585,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names586,
	types586,
	attr_flags586,
	gtypes586,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets586,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names587,
	types587,
	attr_flags587,
	gtypes587,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets587,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names588,
	types588,
	attr_flags588,
	gtypes588,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets588,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names589,
	types589,
	attr_flags589,
	gtypes589,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets589,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names590,
	types590,
	attr_flags590,
	gtypes590,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets590,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names591,
	types591,
	attr_flags591,
	gtypes591,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets591,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names592,
	types592,
	attr_flags592,
	gtypes592,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets592,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names593,
	types593,
	attr_flags593,
	gtypes593,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets593,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names594,
	types594,
	attr_flags594,
	gtypes594,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets594,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names595,
	types595,
	attr_flags595,
	gtypes595,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets595,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names596,
	types596,
	attr_flags596,
	gtypes596,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets596,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names597,
	types597,
	attr_flags597,
	gtypes597,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets597,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names598,
	types598,
	attr_flags598,
	gtypes598,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets598,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names599,
	types599,
	attr_flags599,
	gtypes599,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets599,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names600,
	types600,
	attr_flags600,
	gtypes600,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets600,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names601,
	types601,
	attr_flags601,
	gtypes601,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets601,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names602,
	types602,
	attr_flags602,
	gtypes602,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets602,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names603,
	types603,
	attr_flags603,
	gtypes603,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets603,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names604,
	types604,
	attr_flags604,
	gtypes604,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets604,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names605,
	types605,
	attr_flags605,
	gtypes605,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets605,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names606,
	types606,
	attr_flags606,
	gtypes606,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets606,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names607,
	types607,
	attr_flags607,
	gtypes607,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets607,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names608,
	types608,
	attr_flags608,
	gtypes608,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets608,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names609,
	types609,
	attr_flags609,
	gtypes609,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets609,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names610,
	types610,
	attr_flags610,
	gtypes610,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets610,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names611,
	types611,
	attr_flags611,
	gtypes611,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets611,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names612,
	types612,
	attr_flags612,
	gtypes612,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets612,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names613,
	types613,
	attr_flags613,
	gtypes613,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets613,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names614,
	types614,
	attr_flags614,
	gtypes614,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets614,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names615,
	types615,
	attr_flags615,
	gtypes615,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets615,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names616,
	types616,
	attr_flags616,
	gtypes616,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets616,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names617,
	types617,
	attr_flags617,
	gtypes617,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets617,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names618,
	types618,
	attr_flags618,
	gtypes618,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets618,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names619,
	types619,
	attr_flags619,
	gtypes619,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets619,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names620,
	types620,
	attr_flags620,
	gtypes620,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets620,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names621,
	types621,
	attr_flags621,
	gtypes621,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets621,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names622,
	types622,
	attr_flags622,
	gtypes622,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets622,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names623,
	types623,
	attr_flags623,
	gtypes623,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets623,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names624,
	types624,
	attr_flags624,
	gtypes624,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets624,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names625,
	types625,
	attr_flags625,
	gtypes625,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets625,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names626,
	types626,
	attr_flags626,
	gtypes626,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets626,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names627,
	types627,
	attr_flags627,
	gtypes627,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets627,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names628,
	types628,
	attr_flags628,
	gtypes628,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets628,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names629,
	types629,
	attr_flags629,
	gtypes629,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets629,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names630,
	types630,
	attr_flags630,
	gtypes630,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets630,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names631,
	types631,
	attr_flags631,
	gtypes631,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets631,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INFINITE",
	names632,
	types632,
	attr_flags632,
	gtypes632,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets632,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COUNTABLE",
	names633,
	types633,
	attr_flags633,
	gtypes633,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets633,
	NULL
},
{
	(long) 2,
	(long) 2,
	"COUNTABLE_SEQUENCE",
	names634,
	types634,
	attr_flags634,
	gtypes634,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets634,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PRIMES",
	names635,
	types635,
	attr_flags635,
	gtypes635,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets635,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names636,
	types636,
	attr_flags636,
	gtypes636,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets636,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names637,
	types637,
	attr_flags637,
	gtypes637,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets637,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names638,
	types638,
	attr_flags638,
	gtypes638,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets638,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names639,
	types639,
	attr_flags639,
	gtypes639,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets639,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names640,
	types640,
	attr_flags640,
	gtypes640,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets640,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names641,
	types641,
	attr_flags641,
	gtypes641,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets641,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names642,
	types642,
	attr_flags642,
	gtypes642,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets642,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names643,
	types643,
	attr_flags643,
	gtypes643,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets643,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names644,
	types644,
	attr_flags644,
	gtypes644,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets644,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names645,
	types645,
	attr_flags645,
	gtypes645,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets645,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names646,
	types646,
	attr_flags646,
	gtypes646,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets646,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names647,
	types647,
	attr_flags647,
	gtypes647,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets647,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DISPENSER",
	names648,
	types648,
	attr_flags648,
	gtypes648,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets648,
	NULL
},
{
	(long) 1,
	(long) 1,
	"QUEUE",
	names649,
	types649,
	attr_flags649,
	gtypes649,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets649,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names650,
	types650,
	attr_flags650,
	gtypes650,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets650,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names651,
	types651,
	attr_flags651,
	gtypes651,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets651,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names652,
	types652,
	attr_flags652,
	gtypes652,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets652,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names653,
	types653,
	attr_flags653,
	gtypes653,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets653,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names654,
	types654,
	attr_flags654,
	gtypes654,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets654,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names655,
	types655,
	attr_flags655,
	gtypes655,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets655,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names656,
	types656,
	attr_flags656,
	gtypes656,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets656,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names657,
	types657,
	attr_flags657,
	gtypes657,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets657,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names658,
	types658,
	attr_flags658,
	gtypes658,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets658,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names659,
	types659,
	attr_flags659,
	gtypes659,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets659,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names660,
	types660,
	attr_flags660,
	gtypes660,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets660,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names661,
	types661,
	attr_flags661,
	gtypes661,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets661,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names662,
	types662,
	attr_flags662,
	gtypes662,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets662,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names663,
	types663,
	attr_flags663,
	gtypes663,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets663,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names664,
	types664,
	attr_flags664,
	gtypes664,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets664,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names665,
	types665,
	attr_flags665,
	gtypes665,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets665,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names666,
	types666,
	attr_flags666,
	gtypes666,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets666,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names667,
	types667,
	attr_flags667,
	gtypes667,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets667,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names668,
	types668,
	attr_flags668,
	gtypes668,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets668,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names669,
	types669,
	attr_flags669,
	gtypes669,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets669,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names670,
	types670,
	attr_flags670,
	gtypes670,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets670,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names671,
	types671,
	attr_flags671,
	gtypes671,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets671,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names672,
	types672,
	attr_flags672,
	gtypes672,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets672,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names673,
	types673,
	attr_flags673,
	gtypes673,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets673,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names674,
	types674,
	attr_flags674,
	gtypes674,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets674,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names675,
	types675,
	attr_flags675,
	gtypes675,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets675,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names676,
	types676,
	attr_flags676,
	gtypes676,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets676,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names677,
	types677,
	attr_flags677,
	gtypes677,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets677,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names678,
	types678,
	attr_flags678,
	gtypes678,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets678,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names679,
	types679,
	attr_flags679,
	gtypes679,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets679,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names680,
	types680,
	attr_flags680,
	gtypes680,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets680,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names681,
	types681,
	attr_flags681,
	gtypes681,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets681,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names682,
	types682,
	attr_flags682,
	gtypes682,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets682,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names683,
	types683,
	attr_flags683,
	gtypes683,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets683,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names684,
	types684,
	attr_flags684,
	gtypes684,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets684,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names685,
	types685,
	attr_flags685,
	gtypes685,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets685,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names686,
	types686,
	attr_flags686,
	gtypes686,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets686,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names687,
	types687,
	attr_flags687,
	gtypes687,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets687,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names688,
	types688,
	attr_flags688,
	gtypes688,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets688,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names689,
	types689,
	attr_flags689,
	gtypes689,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets689,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names690,
	types690,
	attr_flags690,
	gtypes690,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets690,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names691,
	types691,
	attr_flags691,
	gtypes691,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets691,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names692,
	types692,
	attr_flags692,
	gtypes692,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets692,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names693,
	types693,
	attr_flags693,
	gtypes693,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets693,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names694,
	types694,
	attr_flags694,
	gtypes694,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets694,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names695,
	types695,
	attr_flags695,
	gtypes695,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets695,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names696,
	types696,
	attr_flags696,
	gtypes696,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets696,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names697,
	types697,
	attr_flags697,
	gtypes697,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets697,
	NULL
},
{
	(long) 20,
	(long) 19,
	"FILE",
	names698,
	types698,
	attr_flags698,
	gtypes698,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets698,
	NULL
},
{
	(long) 21,
	(long) 20,
	"RAW_FILE",
	names699,
	types699,
	attr_flags699,
	gtypes699,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets699,
	NULL
},
{
	(long) 23,
	(long) 22,
	"PLAIN_TEXT_FILE",
	names700,
	types700,
	attr_flags700,
	gtypes700,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets700,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names725,
	types725,
	attr_flags725,
	gtypes725,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets725,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names726,
	types726,
	attr_flags726,
	gtypes726,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets726,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names727,
	types727,
	attr_flags727,
	gtypes727,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets727,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names728,
	types728,
	attr_flags728,
	gtypes728,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets728,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names729,
	types729,
	attr_flags729,
	gtypes729,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets729,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names730,
	types730,
	attr_flags730,
	gtypes730,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets730,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names731,
	types731,
	attr_flags731,
	gtypes731,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets731,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names732,
	types732,
	attr_flags732,
	gtypes732,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets732,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names733,
	types733,
	attr_flags733,
	gtypes733,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets733,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names734,
	types734,
	attr_flags734,
	gtypes734,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets734,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names735,
	types735,
	attr_flags735,
	gtypes735,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets735,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names736,
	types736,
	attr_flags736,
	gtypes736,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets736,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INTEGER_INTERVAL",
	names737,
	types737,
	attr_flags737,
	gtypes737,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets737,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names738,
	types738,
	attr_flags738,
	gtypes738,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets738,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names739,
	types739,
	attr_flags739,
	gtypes739,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets739,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names740,
	types740,
	attr_flags740,
	gtypes740,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets740,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names741,
	types741,
	attr_flags741,
	gtypes741,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets741,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names742,
	types742,
	attr_flags742,
	gtypes742,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets742,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names743,
	types743,
	attr_flags743,
	gtypes743,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets743,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names744,
	types744,
	attr_flags744,
	gtypes744,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets744,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names745,
	types745,
	attr_flags745,
	gtypes745,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets745,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names746,
	types746,
	attr_flags746,
	gtypes746,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets746,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names747,
	types747,
	attr_flags747,
	gtypes747,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets747,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names748,
	types748,
	attr_flags748,
	gtypes748,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets748,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names749,
	types749,
	attr_flags749,
	gtypes749,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets749,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names750,
	types750,
	attr_flags750,
	gtypes750,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets750,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names751,
	types751,
	attr_flags751,
	gtypes751,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets751,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names752,
	types752,
	attr_flags752,
	gtypes752,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets752,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names753,
	types753,
	attr_flags753,
	gtypes753,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets753,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names754,
	types754,
	attr_flags754,
	gtypes754,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets754,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names755,
	types755,
	attr_flags755,
	gtypes755,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets755,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names756,
	types756,
	attr_flags756,
	gtypes756,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets756,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names757,
	types757,
	attr_flags757,
	gtypes757,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets757,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names758,
	types758,
	attr_flags758,
	gtypes758,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets758,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names759,
	types759,
	attr_flags759,
	gtypes759,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets759,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names760,
	types760,
	attr_flags760,
	gtypes760,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets760,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names761,
	types761,
	attr_flags761,
	gtypes761,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets761,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names762,
	types762,
	attr_flags762,
	gtypes762,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets762,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names763,
	types763,
	attr_flags763,
	gtypes763,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets763,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names764,
	types764,
	attr_flags764,
	gtypes764,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets764,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names765,
	types765,
	attr_flags765,
	gtypes765,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets765,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names766,
	types766,
	attr_flags766,
	gtypes766,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets766,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names767,
	types767,
	attr_flags767,
	gtypes767,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets767,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names768,
	types768,
	attr_flags768,
	gtypes768,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets768,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names769,
	types769,
	attr_flags769,
	gtypes769,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets769,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names770,
	types770,
	attr_flags770,
	gtypes770,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets770,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names771,
	types771,
	attr_flags771,
	gtypes771,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets771,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names772,
	types772,
	attr_flags772,
	gtypes772,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets772,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names773,
	types773,
	attr_flags773,
	gtypes773,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets773,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names774,
	types774,
	attr_flags774,
	gtypes774,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets774,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names775,
	types775,
	attr_flags775,
	gtypes775,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets775,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names776,
	types776,
	attr_flags776,
	gtypes776,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets776,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names777,
	types777,
	attr_flags777,
	gtypes777,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets777,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names778,
	types778,
	attr_flags778,
	gtypes778,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets778,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names779,
	types779,
	attr_flags779,
	gtypes779,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets779,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names780,
	types780,
	attr_flags780,
	gtypes780,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets780,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names781,
	types781,
	attr_flags781,
	gtypes781,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets781,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names782,
	types782,
	attr_flags782,
	gtypes782,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets782,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names783,
	types783,
	attr_flags783,
	gtypes783,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets783,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names784,
	types784,
	attr_flags784,
	gtypes784,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets784,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names785,
	types785,
	attr_flags785,
	gtypes785,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets785,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names786,
	types786,
	attr_flags786,
	gtypes786,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets786,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names787,
	types787,
	attr_flags787,
	gtypes787,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets787,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names788,
	types788,
	attr_flags788,
	gtypes788,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets788,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names789,
	types789,
	attr_flags789,
	gtypes789,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets789,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names790,
	types790,
	attr_flags790,
	gtypes790,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets790,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names791,
	types791,
	attr_flags791,
	gtypes791,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets791,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names792,
	types792,
	attr_flags792,
	gtypes792,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets792,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names793,
	types793,
	attr_flags793,
	gtypes793,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets793,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names794,
	types794,
	attr_flags794,
	gtypes794,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets794,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names795,
	types795,
	attr_flags795,
	gtypes795,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets795,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names796,
	types796,
	attr_flags796,
	gtypes796,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets796,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names797,
	types797,
	attr_flags797,
	gtypes797,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets797,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names798,
	types798,
	attr_flags798,
	gtypes798,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets798,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names799,
	types799,
	attr_flags799,
	gtypes799,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets799,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names800,
	types800,
	attr_flags800,
	gtypes800,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets800,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names801,
	types801,
	attr_flags801,
	gtypes801,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets801,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names802,
	types802,
	attr_flags802,
	gtypes802,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets802,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names803,
	types803,
	attr_flags803,
	gtypes803,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets803,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names804,
	types804,
	attr_flags804,
	gtypes804,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets804,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names805,
	types805,
	attr_flags805,
	gtypes805,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets805,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_DIRECTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MISMATCH_CORRECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_QUEUE",
	names809,
	types809,
	attr_flags809,
	gtypes809,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets809,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names810,
	types810,
	attr_flags810,
	gtypes810,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets810,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names811,
	types811,
	attr_flags811,
	gtypes811,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets811,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names812,
	types812,
	attr_flags812,
	gtypes812,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets812,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names813,
	types813,
	attr_flags813,
	gtypes813,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets813,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names814,
	types814,
	attr_flags814,
	gtypes814,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets814,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names815,
	types815,
	attr_flags815,
	gtypes815,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets815,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names816,
	types816,
	attr_flags816,
	gtypes816,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets816,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names817,
	types817,
	attr_flags817,
	gtypes817,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets817,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names818,
	types818,
	attr_flags818,
	gtypes818,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets818,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names819,
	types819,
	attr_flags819,
	gtypes819,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets819,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names820,
	types820,
	attr_flags820,
	gtypes820,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets820,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names821,
	types821,
	attr_flags821,
	gtypes821,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets821,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names822,
	types822,
	attr_flags822,
	gtypes822,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets822,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names823,
	types823,
	attr_flags823,
	gtypes823,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets823,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names824,
	types824,
	attr_flags824,
	gtypes824,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets824,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names825,
	types825,
	attr_flags825,
	gtypes825,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets825,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names826,
	types826,
	attr_flags826,
	gtypes826,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets826,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names827,
	types827,
	attr_flags827,
	gtypes827,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets827,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names828,
	types828,
	attr_flags828,
	gtypes828,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets828,
	NULL
},
{
	(long) 19,
	(long) 19,
	"MISMATCH_INFORMATION",
	names829,
	types829,
	attr_flags829,
	gtypes829,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets829,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HASHABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 9,
	(long) 9,
	"LX_SYMBOL_CLASS",
	names832,
	types832,
	attr_flags832,
	gtypes832,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets832,
	"20190721"
},
{
	(long) 3,
	(long) 3,
	"PATH",
	names833,
	types833,
	attr_flags833,
	gtypes833,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets833,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names834,
	types834,
	attr_flags834,
	gtypes834,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets834,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names835,
	types835,
	attr_flags835,
	gtypes835,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets835,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names836,
	types836,
	attr_flags836,
	gtypes836,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets836,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names837,
	types837,
	attr_flags837,
	gtypes837,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets837,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names838,
	types838,
	attr_flags838,
	gtypes838,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets838,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names839,
	types839,
	attr_flags839,
	gtypes839,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets839,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names840,
	types840,
	attr_flags840,
	gtypes840,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets840,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names841,
	types841,
	attr_flags841,
	gtypes841,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets841,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names842,
	types842,
	attr_flags842,
	gtypes842,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets842,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names843,
	types843,
	attr_flags843,
	gtypes843,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets843,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names844,
	types844,
	attr_flags844,
	gtypes844,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets844,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names845,
	types845,
	attr_flags845,
	gtypes845,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets845,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names846,
	types846,
	attr_flags846,
	gtypes846,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets846,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names847,
	types847,
	attr_flags847,
	gtypes847,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets847,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names848,
	types848,
	attr_flags848,
	gtypes848,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets848,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names849,
	types849,
	attr_flags849,
	gtypes849,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets849,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names850,
	types850,
	attr_flags850,
	gtypes850,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets850,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names851,
	types851,
	attr_flags851,
	gtypes851,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets851,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names852,
	types852,
	attr_flags852,
	gtypes852,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets852,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names853,
	types853,
	attr_flags853,
	gtypes853,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets853,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names854,
	types854,
	attr_flags854,
	gtypes854,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets854,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names855,
	types855,
	attr_flags855,
	gtypes855,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets855,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names856,
	types856,
	attr_flags856,
	gtypes856,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets856,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names857,
	types857,
	attr_flags857,
	gtypes857,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets857,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names858,
	types858,
	attr_flags858,
	gtypes858,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets858,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names859,
	types859,
	attr_flags859,
	gtypes859,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets859,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names860,
	types860,
	attr_flags860,
	gtypes860,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets860,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names861,
	types861,
	attr_flags861,
	gtypes861,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets861,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names862,
	types862,
	attr_flags862,
	gtypes862,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets862,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names863,
	types863,
	attr_flags863,
	gtypes863,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets863,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names864,
	types864,
	attr_flags864,
	gtypes864,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets864,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TUPLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8_REF",
	names866,
	types866,
	attr_flags866,
	gtypes866,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets866,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names867,
	types867,
	attr_flags867,
	gtypes867,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets867,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names868,
	types868,
	attr_flags868,
	gtypes868,
	(uint16) 0x2306,
	(void (*)()) 0,
	offsets868,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64_REF",
	names869,
	types869,
	attr_flags869,
	gtypes869,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets869,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names870,
	types870,
	attr_flags870,
	gtypes870,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets870,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names871,
	types871,
	attr_flags871,
	gtypes871,
	(uint16) 0x2309,
	(void (*)()) 0,
	offsets871,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32_REF",
	names872,
	types872,
	attr_flags872,
	gtypes872,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets872,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names873,
	types873,
	attr_flags873,
	gtypes873,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets873,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names874,
	types874,
	attr_flags874,
	gtypes874,
	(uint16) 0x2308,
	(void (*)()) 0,
	offsets874,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16_REF",
	names875,
	types875,
	attr_flags875,
	gtypes875,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets875,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names876,
	types876,
	attr_flags876,
	gtypes876,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets876,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names877,
	types877,
	attr_flags877,
	gtypes877,
	(uint16) 0x2307,
	(void (*)()) 0,
	offsets877,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64_REF",
	names878,
	types878,
	attr_flags878,
	gtypes878,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets878,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names879,
	types879,
	attr_flags879,
	gtypes879,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets879,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names880,
	types880,
	attr_flags880,
	gtypes880,
	(uint16) 0x230D,
	(void (*)()) 0,
	offsets880,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32_REF",
	names881,
	types881,
	attr_flags881,
	gtypes881,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets881,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names882,
	types882,
	attr_flags882,
	gtypes882,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets882,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names883,
	types883,
	attr_flags883,
	gtypes883,
	(uint16) 0x230C,
	(void (*)()) 0,
	offsets883,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16_REF",
	names884,
	types884,
	attr_flags884,
	gtypes884,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets884,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names885,
	types885,
	attr_flags885,
	gtypes885,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets885,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names886,
	types886,
	attr_flags886,
	gtypes886,
	(uint16) 0x230B,
	(void (*)()) 0,
	offsets886,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8_REF",
	names887,
	types887,
	attr_flags887,
	gtypes887,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets887,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names888,
	types888,
	attr_flags888,
	gtypes888,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets888,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names889,
	types889,
	attr_flags889,
	gtypes889,
	(uint16) 0x230A,
	(void (*)()) 0,
	offsets889,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32_REF",
	names890,
	types890,
	attr_flags890,
	gtypes890,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets890,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names891,
	types891,
	attr_flags891,
	gtypes891,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets891,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names892,
	types892,
	attr_flags892,
	gtypes892,
	(uint16) 0x2304,
	(void (*)()) 0,
	offsets892,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64_REF",
	names893,
	types893,
	attr_flags893,
	gtypes893,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets893,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names894,
	types894,
	attr_flags894,
	gtypes894,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets894,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names895,
	types895,
	attr_flags895,
	gtypes895,
	(uint16) 0x2303,
	(void (*)()) 0,
	offsets895,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32_REF",
	names896,
	types896,
	attr_flags896,
	gtypes896,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets896,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names897,
	types897,
	attr_flags897,
	gtypes897,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets897,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names898,
	types898,
	attr_flags898,
	gtypes898,
	(uint16) 0x230E,
	(void (*)()) 0,
	offsets898,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8_REF",
	names899,
	types899,
	attr_flags899,
	gtypes899,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets899,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names900,
	types900,
	attr_flags900,
	gtypes900,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets900,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names901,
	types901,
	attr_flags901,
	gtypes901,
	(uint16) 0x2302,
	(void (*)()) 0,
	offsets901,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN_REF",
	names902,
	types902,
	attr_flags902,
	gtypes902,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets902,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names903,
	types903,
	attr_flags903,
	gtypes903,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets903,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names904,
	types904,
	attr_flags904,
	gtypes904,
	(uint16) 0x2301,
	(void (*)()) 0,
	offsets904,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER_REF",
	names905,
	types905,
	attr_flags905,
	gtypes905,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets905,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names906,
	types906,
	attr_flags906,
	gtypes906,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets906,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names907,
	types907,
	attr_flags907,
	gtypes907,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets907,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names908,
	types908,
	attr_flags908,
	gtypes908,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets908,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names909,
	types909,
	attr_flags909,
	gtypes909,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets909,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names910,
	types910,
	attr_flags910,
	gtypes910,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets910,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names911,
	types911,
	attr_flags911,
	gtypes911,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets911,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names912,
	types912,
	attr_flags912,
	gtypes912,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets912,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names913,
	types913,
	attr_flags913,
	gtypes913,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets913,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names914,
	types914,
	attr_flags914,
	gtypes914,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets914,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names915,
	types915,
	attr_flags915,
	gtypes915,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets915,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names916,
	types916,
	attr_flags916,
	gtypes916,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets916,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names917,
	types917,
	attr_flags917,
	gtypes917,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets917,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names918,
	types918,
	attr_flags918,
	gtypes918,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets918,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names919,
	types919,
	attr_flags919,
	gtypes919,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets919,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names920,
	types920,
	attr_flags920,
	gtypes920,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets920,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names921,
	types921,
	attr_flags921,
	gtypes921,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets921,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names922,
	types922,
	attr_flags922,
	gtypes922,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets922,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names923,
	types923,
	attr_flags923,
	gtypes923,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets923,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names924,
	types924,
	attr_flags924,
	gtypes924,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets924,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names925,
	types925,
	attr_flags925,
	gtypes925,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets925,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names926,
	types926,
	attr_flags926,
	gtypes926,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets926,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names927,
	types927,
	attr_flags927,
	gtypes927,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets927,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names928,
	types928,
	attr_flags928,
	gtypes928,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets928,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names929,
	types929,
	attr_flags929,
	gtypes929,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets929,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names930,
	types930,
	attr_flags930,
	gtypes930,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets930,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names931,
	types931,
	attr_flags931,
	gtypes931,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets931,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names932,
	types932,
	attr_flags932,
	gtypes932,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets932,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names933,
	types933,
	attr_flags933,
	gtypes933,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets933,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names934,
	types934,
	attr_flags934,
	gtypes934,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets934,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names935,
	types935,
	attr_flags935,
	gtypes935,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets935,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names936,
	types936,
	attr_flags936,
	gtypes936,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets936,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names937,
	types937,
	attr_flags937,
	gtypes937,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets937,
	NULL
},
{
	(long) 12,
	(long) 12,
	"ROUTINE",
	names938,
	types938,
	attr_flags938,
	gtypes938,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets938,
	NULL
},
{
	(long) 12,
	(long) 12,
	"PROCEDURE",
	names939,
	types939,
	attr_flags939,
	gtypes939,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets939,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names940,
	types940,
	attr_flags940,
	gtypes940,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets940,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names941,
	types941,
	attr_flags941,
	gtypes941,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets941,
	NULL
},
{
	(long) 13,
	(long) 13,
	"PREDICATE",
	names942,
	types942,
	attr_flags942,
	gtypes942,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets942,
	NULL
},
{
	(long) 2,
	(long) 2,
	"READABLE_STRING_GENERAL",
	names943,
	types943,
	attr_flags943,
	gtypes943,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets943,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IMMUTABLE_STRING_GENERAL",
	names944,
	types944,
	attr_flags944,
	gtypes944,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets944,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_GENERAL",
	names945,
	types945,
	attr_flags945,
	gtypes945,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets945,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_32",
	names946,
	types946,
	attr_flags946,
	gtypes946,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets946,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_32",
	names947,
	types947,
	attr_flags947,
	gtypes947,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets947,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32",
	names948,
	types948,
	attr_flags948,
	gtypes948,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets948,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_8",
	names949,
	types949,
	attr_flags949,
	gtypes949,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets949,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_8",
	names950,
	types950,
	attr_flags950,
	gtypes950,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets950,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8",
	names951,
	types951,
	attr_flags951,
	gtypes951,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets951,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING",
	names952,
	types952,
	attr_flags952,
	gtypes952,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets952,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_NATURAL_32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_EIFFEL_CHARACTER_ENTITY",
	names972,
	types972,
	attr_flags972,
	gtypes972,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets972,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ST_COPY_ON_WRITE_STRING",
	names973,
	types973,
	attr_flags973,
	gtypes973,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets973,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UC_CHARACTER",
	names975,
	types975,
	attr_flags975,
	gtypes975,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets975,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_WHITESPACE_NORMALIZER",
	names976,
	types976,
	attr_flags976,
	gtypes976,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets976,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_CONTENT_CONCATENATOR",
	names977,
	types977,
	attr_flags977,
	gtypes977,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets977,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_XMLNS_GENERATOR",
	names978,
	types978,
	attr_flags978,
	gtypes978,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets978,
	NULL
},
{
	(long) 8,
	(long) 8,
	"XM_NAMESPACE_RESOLVER",
	names979,
	types979,
	attr_flags979,
	gtypes979,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets979,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_FILE_SOURCE",
	names980,
	types980,
	attr_flags980,
	gtypes980,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets980,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XM_EIFFEL_INPUT_STREAM",
	names981,
	types981,
	attr_flags981,
	gtypes981,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets981,
	NULL
},
{
	(long) 5,
	(long) 5,
	"XM_EIFFEL_PARSER_NAME",
	names982,
	types982,
	attr_flags982,
	gtypes982,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets982,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CASE_INSENSITIVE_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_STDIN_FILE",
	names984,
	types984,
	attr_flags984,
	gtypes984,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets984,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_NAMESPACE",
	names985,
	types985,
	attr_flags985,
	gtypes985,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets985,
	NULL
},
{
	(long) 2,
	(long) 2,
	"GEANT_RENAME",
	names986,
	types986,
	attr_flags986,
	gtypes986,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets986,
	NULL
},
{
	(long) 0,
	(long) 0,
	"AP_OPTION_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ST_WORD_WRAPPER",
	names988,
	types988,
	attr_flags988,
	gtypes988,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets988,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING_INPUT_STREAM",
	names989,
	types989,
	attr_flags989,
	gtypes989,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets989,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_SHELL_COMMAND",
	names991,
	types991,
	attr_flags991,
	gtypes991,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets991,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DP_SHELL_COMMAND",
	names992,
	types992,
	attr_flags992,
	gtypes992,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets992,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EXECUTION_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDERR_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDOUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_NULL_TEXT_OUTPUT_STREAM",
	names1001,
	types1001,
	attr_flags1001,
	gtypes1001,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1001,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_INTEGER_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RX_BYTE_CODE",
	names1004,
	types1004,
	attr_flags1004,
	gtypes1004,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1004,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XM_TREE_CALLBACKS_PIPE",
	names1005,
	types1005,
	attr_flags1005,
	gtypes1005,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1005,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 23,
	(long) 22,
	"CONSOLE",
	names1012,
	types1012,
	attr_flags1012,
	gtypes1012,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1012,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ST_SPLITTER",
	names1013,
	types1013,
	attr_flags1013,
	gtypes1013,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1013,
	NULL
},
{
	(long) 6,
	(long) 6,
	"GEANT_PROJECT_PARSER",
	names1014,
	types1014,
	attr_flags1014,
	gtypes1014,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1014,
	NULL
},
{
	(long) 4,
	(long) 4,
	"YY_SCANNER",
	names1015,
	types1015,
	attr_flags1015,
	gtypes1015,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1015,
	NULL
},
{
	(long) 22,
	(long) 22,
	"YY_SCANNER_SKELETON",
	names1016,
	types1016,
	attr_flags1016,
	gtypes1016,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1016,
	NULL
},
{
	(long) 25,
	(long) 25,
	"YY_FULL_SCANNER_SKELETON",
	names1017,
	types1017,
	attr_flags1017,
	gtypes1017,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1017,
	NULL
},
{
	(long) 38,
	(long) 38,
	"YY_COMPRESSED_SCANNER_SKELETON",
	names1018,
	types1018,
	attr_flags1018,
	gtypes1018,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1018,
	NULL
},
{
	(long) 58,
	(long) 58,
	"LX_LEX_SCANNER_SKELETON",
	names1019,
	types1019,
	attr_flags1019,
	gtypes1019,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1019,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_TITLECASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_UPPERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_LOWERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_ESCAPE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_STRING_MODE",
	names1026,
	types1026,
	attr_flags1026,
	gtypes1026,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1026,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_PARSER",
	names1027,
	types1027,
	attr_flags1027,
	gtypes1027,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1027,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_NON_INCREMENTAL_PARSER",
	names1028,
	types1028,
	attr_flags1028,
	gtypes1028,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1028,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_I",
	names1029,
	types1029,
	attr_flags1029,
	gtypes1029,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1029,
	NULL
},
{
	(long) 3,
	(long) 3,
	"UNICODE_CONVERSION",
	names1030,
	types1030,
	attr_flags1030,
	gtypes1030,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1030,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_IMP",
	names1031,
	types1031,
	attr_flags1031,
	gtypes1031,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1031,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_POSITION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_STREAM_POSITION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XM_DEFAULT_POSITION",
	names1034,
	types1034,
	attr_flags1034,
	gtypes1034,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1034,
	NULL
},
{
	(long) 11,
	(long) 11,
	"LX_TABLES",
	names1035,
	types1035,
	attr_flags1035,
	gtypes1035,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1035,
	NULL
},
{
	(long) 33,
	(long) 33,
	"LX_SCANNER",
	names1036,
	types1036,
	attr_flags1036,
	gtypes1036,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1036,
	NULL
},
{
	(long) 14,
	(long) 14,
	"LX_FULL_TABLES",
	names1037,
	types1037,
	attr_flags1037,
	gtypes1037,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1037,
	NULL
},
{
	(long) 39,
	(long) 39,
	"LX_FULL_SCANNER",
	names1038,
	types1038,
	attr_flags1038,
	gtypes1038,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1038,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names1039,
	types1039,
	attr_flags1039,
	gtypes1039,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1039,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names1040,
	types1040,
	attr_flags1040,
	gtypes1040,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1040,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names1041,
	types1041,
	attr_flags1041,
	gtypes1041,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1041,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names1042,
	types1042,
	attr_flags1042,
	gtypes1042,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1042,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names1043,
	types1043,
	attr_flags1043,
	gtypes1043,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1043,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names1044,
	types1044,
	attr_flags1044,
	gtypes1044,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1044,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXED_CURSOR",
	names1045,
	types1045,
	attr_flags1045,
	gtypes1045,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1045,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXED_CURSOR",
	names1046,
	types1046,
	attr_flags1046,
	gtypes1046,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1046,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXED_CURSOR",
	names1047,
	types1047,
	attr_flags1047,
	gtypes1047,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1047,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names1048,
	types1048,
	attr_flags1048,
	gtypes1048,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1048,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names1049,
	types1049,
	attr_flags1049,
	gtypes1049,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1049,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names1050,
	types1050,
	attr_flags1050,
	gtypes1050,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1050,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names1051,
	types1051,
	attr_flags1051,
	gtypes1051,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1051,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names1052,
	types1052,
	attr_flags1052,
	gtypes1052,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1052,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names1053,
	types1053,
	attr_flags1053,
	gtypes1053,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1053,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names1054,
	types1054,
	attr_flags1054,
	gtypes1054,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1054,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names1055,
	types1055,
	attr_flags1055,
	gtypes1055,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1055,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names1056,
	types1056,
	attr_flags1056,
	gtypes1056,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1056,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names1057,
	types1057,
	attr_flags1057,
	gtypes1057,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1057,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names1058,
	types1058,
	attr_flags1058,
	gtypes1058,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1058,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SET_CURSOR",
	names1059,
	types1059,
	attr_flags1059,
	gtypes1059,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1059,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SET_CURSOR",
	names1060,
	types1060,
	attr_flags1060,
	gtypes1060,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1060,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names1061,
	types1061,
	attr_flags1061,
	gtypes1061,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1061,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names1062,
	types1062,
	attr_flags1062,
	gtypes1062,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1062,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names1063,
	types1063,
	attr_flags1063,
	gtypes1063,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1063,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names1064,
	types1064,
	attr_flags1064,
	gtypes1064,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1064,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names1065,
	types1065,
	attr_flags1065,
	gtypes1065,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1065,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names1066,
	types1066,
	attr_flags1066,
	gtypes1066,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1066,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names1067,
	types1067,
	attr_flags1067,
	gtypes1067,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1067,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names1068,
	types1068,
	attr_flags1068,
	gtypes1068,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1068,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names1069,
	types1069,
	attr_flags1069,
	gtypes1069,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1069,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names1070,
	types1070,
	attr_flags1070,
	gtypes1070,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1070,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names1071,
	types1071,
	attr_flags1071,
	gtypes1071,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1071,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names1072,
	types1072,
	attr_flags1072,
	gtypes1072,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1072,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names1073,
	types1073,
	attr_flags1073,
	gtypes1073,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1073,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names1074,
	types1074,
	attr_flags1074,
	gtypes1074,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1074,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names1075,
	types1075,
	attr_flags1075,
	gtypes1075,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1075,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names1076,
	types1076,
	attr_flags1076,
	gtypes1076,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1076,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1077,
	types1077,
	attr_flags1077,
	gtypes1077,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1077,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1078,
	types1078,
	attr_flags1078,
	gtypes1078,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1078,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1079,
	types1079,
	attr_flags1079,
	gtypes1079,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1079,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1080,
	types1080,
	attr_flags1080,
	gtypes1080,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1080,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1081,
	types1081,
	attr_flags1081,
	gtypes1081,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1081,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_SET_CURSOR",
	names1082,
	types1082,
	attr_flags1082,
	gtypes1082,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1082,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_SET_CURSOR",
	names1083,
	types1083,
	attr_flags1083,
	gtypes1083,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1083,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_SET_CURSOR",
	names1084,
	types1084,
	attr_flags1084,
	gtypes1084,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1084,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_SET_CURSOR",
	names1085,
	types1085,
	attr_flags1085,
	gtypes1085,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1085,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_SET_CURSOR",
	names1086,
	types1086,
	attr_flags1086,
	gtypes1086,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1086,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_SET_CURSOR",
	names1087,
	types1087,
	attr_flags1087,
	gtypes1087,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1087,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1088,
	types1088,
	attr_flags1088,
	gtypes1088,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1088,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1089,
	types1089,
	attr_flags1089,
	gtypes1089,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1089,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1090,
	types1090,
	attr_flags1090,
	gtypes1090,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1090,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1091,
	types1091,
	attr_flags1091,
	gtypes1091,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1091,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1092,
	types1092,
	attr_flags1092,
	gtypes1092,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1092,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1093,
	types1093,
	attr_flags1093,
	gtypes1093,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1093,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1094,
	types1094,
	attr_flags1094,
	gtypes1094,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1094,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1095,
	types1095,
	attr_flags1095,
	gtypes1095,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1095,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1096,
	types1096,
	attr_flags1096,
	gtypes1096,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1096,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1097,
	types1097,
	attr_flags1097,
	gtypes1097,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1097,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1098,
	types1098,
	attr_flags1098,
	gtypes1098,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1098,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1099,
	types1099,
	attr_flags1099,
	gtypes1099,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1099,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1100,
	types1100,
	attr_flags1100,
	gtypes1100,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1100,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1101,
	types1101,
	attr_flags1101,
	gtypes1101,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1101,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1102,
	types1102,
	attr_flags1102,
	gtypes1102,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1102,
	"20130823"
},
{
	(long) 1,
	(long) 1,
	"DS_LIST_CURSOR",
	names1103,
	types1103,
	attr_flags1103,
	gtypes1103,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1103,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST_CURSOR",
	names1104,
	types1104,
	attr_flags1104,
	gtypes1104,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1104,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST_CURSOR",
	names1105,
	types1105,
	attr_flags1105,
	gtypes1105,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1105,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_LIST_CURSOR",
	names1106,
	types1106,
	attr_flags1106,
	gtypes1106,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1106,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_LIST_CURSOR",
	names1107,
	types1107,
	attr_flags1107,
	gtypes1107,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1107,
	"20130823"
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST_CURSOR",
	names1108,
	types1108,
	attr_flags1108,
	gtypes1108,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1108,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST_CURSOR",
	names1109,
	types1109,
	attr_flags1109,
	gtypes1109,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1109,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_BILINKED_LIST_CURSOR",
	names1110,
	types1110,
	attr_flags1110,
	gtypes1110,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1110,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CLONABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LX_TRANSITION_TABLE",
	names1112,
	types1112,
	attr_flags1112,
	gtypes1112,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1112,
	NULL
},
{
	(long) 0,
	(long) 0,
	"LX_STATE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"LX_NFA_STATE",
	names1114,
	types1114,
	attr_flags1114,
	gtypes1114,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1114,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LX_DFA_STATE",
	names1115,
	types1115,
	attr_flags1115,
	gtypes1115,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1115,
	NULL
},
{
	(long) 0,
	(long) 0,
	"LX_AUTOMATON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LX_NFA",
	names1117,
	types1117,
	attr_flags1117,
	gtypes1117,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1117,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LX_DFA",
	names1118,
	types1118,
	attr_flags1118,
	gtypes1118,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1118,
	NULL
},
{
	(long) 30,
	(long) 30,
	"LX_GENERATABLE_DFA",
	names1119,
	types1119,
	attr_flags1119,
	gtypes1119,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1119,
	NULL
},
{
	(long) 33,
	(long) 33,
	"LX_FULL_DFA",
	names1120,
	types1120,
	attr_flags1120,
	gtypes1120,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1120,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_TRANSITION",
	names1121,
	types1121,
	attr_flags1121,
	gtypes1121,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1121,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_EPSILON_TRANSITION",
	names1122,
	types1122,
	attr_flags1122,
	gtypes1122,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1122,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LX_SYMBOL_TRANSITION",
	names1123,
	types1123,
	attr_flags1123,
	gtypes1123,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1123,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LX_SYMBOL_CLASS_TRANSITION",
	names1124,
	types1124,
	attr_flags1124,
	gtypes1124,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1124,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1145,
	types1145,
	attr_flags1145,
	gtypes1145,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1145,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1146,
	types1146,
	attr_flags1146,
	gtypes1146,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1146,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1147,
	types1147,
	attr_flags1147,
	gtypes1147,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1147,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1148,
	types1148,
	attr_flags1148,
	gtypes1148,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1148,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1149,
	types1149,
	attr_flags1149,
	gtypes1149,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1149,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1150,
	types1150,
	attr_flags1150,
	gtypes1150,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1150,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1151,
	types1151,
	attr_flags1151,
	gtypes1151,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1151,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1152,
	types1152,
	attr_flags1152,
	gtypes1152,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1152,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1153,
	types1153,
	attr_flags1153,
	gtypes1153,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1153,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1154,
	types1154,
	attr_flags1154,
	gtypes1154,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1154,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1155,
	types1155,
	attr_flags1155,
	gtypes1155,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1155,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1156,
	types1156,
	attr_flags1156,
	gtypes1156,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1156,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1157,
	types1157,
	attr_flags1157,
	gtypes1157,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1157,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1158,
	types1158,
	attr_flags1158,
	gtypes1158,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1158,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1159,
	types1159,
	attr_flags1159,
	gtypes1159,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1159,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1160,
	types1160,
	attr_flags1160,
	gtypes1160,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1160,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1161,
	types1161,
	attr_flags1161,
	gtypes1161,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1161,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1162,
	types1162,
	attr_flags1162,
	gtypes1162,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1162,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1163,
	types1163,
	attr_flags1163,
	gtypes1163,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1163,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1164,
	types1164,
	attr_flags1164,
	gtypes1164,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1164,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1165,
	types1165,
	attr_flags1165,
	gtypes1165,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1165,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1166,
	types1166,
	attr_flags1166,
	gtypes1166,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1166,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1167,
	types1167,
	attr_flags1167,
	gtypes1167,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1167,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1168,
	types1168,
	attr_flags1168,
	gtypes1168,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1168,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1169,
	types1169,
	attr_flags1169,
	gtypes1169,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1169,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1170,
	types1170,
	attr_flags1170,
	gtypes1170,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1170,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1171,
	types1171,
	attr_flags1171,
	gtypes1171,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1171,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1172,
	types1172,
	attr_flags1172,
	gtypes1172,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1172,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_EXTENDIBLE",
	names1173,
	types1173,
	attr_flags1173,
	gtypes1173,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1173,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_EXTENDIBLE",
	names1174,
	types1174,
	attr_flags1174,
	gtypes1174,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1174,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_EXTENDIBLE",
	names1175,
	types1175,
	attr_flags1175,
	gtypes1175,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1175,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_EXTENDIBLE",
	names1176,
	types1176,
	attr_flags1176,
	gtypes1176,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1176,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SET",
	names1177,
	types1177,
	attr_flags1177,
	gtypes1177,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1177,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SET",
	names1178,
	types1178,
	attr_flags1178,
	gtypes1178,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1178,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXABLE",
	names1179,
	types1179,
	attr_flags1179,
	gtypes1179,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1179,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXABLE",
	names1180,
	types1180,
	attr_flags1180,
	gtypes1180,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1180,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXABLE",
	names1181,
	types1181,
	attr_flags1181,
	gtypes1181,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1181,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST",
	names1182,
	types1182,
	attr_flags1182,
	gtypes1182,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1182,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST",
	names1183,
	types1183,
	attr_flags1183,
	gtypes1183,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1183,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST",
	names1184,
	types1184,
	attr_flags1184,
	gtypes1184,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1184,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST",
	names1185,
	types1185,
	attr_flags1185,
	gtypes1185,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1185,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST",
	names1186,
	types1186,
	attr_flags1186,
	gtypes1186,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1186,
	NULL
},
{
	(long) 5,
	(long) 5,
	"XM_LINKED_LIST",
	names1187,
	types1187,
	attr_flags1187,
	gtypes1187,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1187,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_BILINKED_LIST",
	names1188,
	types1188,
	attr_flags1188,
	gtypes1188,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1188,
	NULL
},
{
	(long) 7,
	(long) 7,
	"AP_ALTERNATIVE_OPTIONS_LIST",
	names1189,
	types1189,
	attr_flags1189,
	gtypes1189,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1189,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DISPENSER",
	names1190,
	types1190,
	attr_flags1190,
	gtypes1190,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1190,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DISPENSER",
	names1191,
	types1191,
	attr_flags1191,
	gtypes1191,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1191,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DISPENSER",
	names1192,
	types1192,
	attr_flags1192,
	gtypes1192,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1192,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DISPENSER",
	names1193,
	types1193,
	attr_flags1193,
	gtypes1193,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1193,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_QUEUE",
	names1194,
	types1194,
	attr_flags1194,
	gtypes1194,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1194,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_QUEUE",
	names1195,
	types1195,
	attr_flags1195,
	gtypes1195,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1195,
	NULL
},
{
	(long) 4,
	(long) 4,
	"DS_LINKED_QUEUE",
	names1196,
	types1196,
	attr_flags1196,
	gtypes1196,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1196,
	NULL
},
{
	(long) 4,
	(long) 4,
	"DS_LINKED_QUEUE",
	names1197,
	types1197,
	attr_flags1197,
	gtypes1197,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1197,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_STACK",
	names1198,
	types1198,
	attr_flags1198,
	gtypes1198,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1198,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_STACK",
	names1199,
	types1199,
	attr_flags1199,
	gtypes1199,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1199,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_STACK",
	names1200,
	types1200,
	attr_flags1200,
	gtypes1200,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1200,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_LINKED_STACK",
	names1201,
	types1201,
	attr_flags1201,
	gtypes1201,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1201,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_RESIZABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_RESIZABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_RESIZABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_RESIZABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_ARRAYED_STACK",
	names1206,
	types1206,
	attr_flags1206,
	gtypes1206,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1206,
	"20130823"
},
{
	(long) 5,
	(long) 5,
	"DS_ARRAYED_STACK",
	names1207,
	types1207,
	attr_flags1207,
	gtypes1207,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1207,
	"20130823"
},
{
	(long) 5,
	(long) 5,
	"DS_ARRAYED_STACK",
	names1208,
	types1208,
	attr_flags1208,
	gtypes1208,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1208,
	"20130823"
},
{
	(long) 6,
	(long) 6,
	"DS_ARRAYED_LIST",
	names1209,
	types1209,
	attr_flags1209,
	gtypes1209,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1209,
	"20130823"
},
{
	(long) 6,
	(long) 6,
	"DS_ARRAYED_LIST",
	names1210,
	types1210,
	attr_flags1210,
	gtypes1210,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1210,
	"20130823"
},
{
	(long) 6,
	(long) 6,
	"LX_START_CONDITIONS",
	names1211,
	types1211,
	attr_flags1211,
	gtypes1211,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1211,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1212,
	types1212,
	attr_flags1212,
	gtypes1212,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1212,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1213,
	types1213,
	attr_flags1213,
	gtypes1213,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1213,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1214,
	types1214,
	attr_flags1214,
	gtypes1214,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1214,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1215,
	types1215,
	attr_flags1215,
	gtypes1215,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1215,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1216,
	types1216,
	attr_flags1216,
	gtypes1216,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1216,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_SET",
	names1217,
	types1217,
	attr_flags1217,
	gtypes1217,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1217,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_SET",
	names1218,
	types1218,
	attr_flags1218,
	gtypes1218,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1218,
	"20130823"
},
{
	(long) 15,
	(long) 15,
	"DS_ARRAYED_SPARSE_SET",
	names1219,
	types1219,
	attr_flags1219,
	gtypes1219,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1219,
	"20130823"
},
{
	(long) 15,
	(long) 15,
	"DS_ARRAYED_SPARSE_SET",
	names1220,
	types1220,
	attr_flags1220,
	gtypes1220,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1220,
	"20130823"
},
{
	(long) 16,
	(long) 16,
	"DS_HASH_SET",
	names1221,
	types1221,
	attr_flags1221,
	gtypes1221,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1221,
	"20130823"
},
{
	(long) 16,
	(long) 16,
	"DS_HASH_SET",
	names1222,
	types1222,
	attr_flags1222,
	gtypes1222,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1222,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1223,
	types1223,
	attr_flags1223,
	gtypes1223,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1223,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1224,
	types1224,
	attr_flags1224,
	gtypes1224,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1224,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1225,
	types1225,
	attr_flags1225,
	gtypes1225,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1225,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1226,
	types1226,
	attr_flags1226,
	gtypes1226,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1226,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1227,
	types1227,
	attr_flags1227,
	gtypes1227,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1227,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1228,
	types1228,
	attr_flags1228,
	gtypes1228,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1228,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1229,
	types1229,
	attr_flags1229,
	gtypes1229,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1229,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1230,
	types1230,
	attr_flags1230,
	gtypes1230,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1230,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1231,
	types1231,
	attr_flags1231,
	gtypes1231,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1231,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1232,
	types1232,
	attr_flags1232,
	gtypes1232,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1232,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1233,
	types1233,
	attr_flags1233,
	gtypes1233,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1233,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1234,
	types1234,
	attr_flags1234,
	gtypes1234,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1234,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1235,
	types1235,
	attr_flags1235,
	gtypes1235,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1235,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1236,
	types1236,
	attr_flags1236,
	gtypes1236,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1236,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1237,
	types1237,
	attr_flags1237,
	gtypes1237,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1237,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"GEANT_VARIABLES",
	names1238,
	types1238,
	attr_flags1238,
	gtypes1238,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1238,
	NULL
},
{
	(long) 20,
	(long) 20,
	"GEANT_ARGUMENT_VARIABLES",
	names1239,
	types1239,
	attr_flags1239,
	gtypes1239,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1239,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"GEANT_FILESET_ENTRY",
	names1241,
	types1241,
	attr_flags1241,
	gtypes1241,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1241,
	NULL
},
{
	(long) 11,
	(long) 11,
	"KL_DIRECTORY",
	names1242,
	types1242,
	attr_flags1242,
	gtypes1242,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1242,
	NULL
},
{
	(long) 9,
	(long) 9,
	"AP_BASIC_PARSER",
	names1243,
	types1243,
	attr_flags1243,
	gtypes1243,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1243,
	NULL
},
{
	(long) 10,
	(long) 10,
	"AP_PARSER",
	names1244,
	types1244,
	attr_flags1244,
	gtypes1244,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1244,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_FILE",
	names1245,
	types1245,
	attr_flags1245,
	gtypes1245,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1245,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_OUTPUT_FILE",
	names1246,
	types1246,
	attr_flags1246,
	gtypes1246,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1246,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_TEXT_OUTPUT_FILE",
	names1247,
	types1247,
	attr_flags1247,
	gtypes1247,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1247,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_BINARY_OUTPUT_FILE",
	names1248,
	types1248,
	attr_flags1248,
	gtypes1248,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1248,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_WINDOWS_OUTPUT_FILE",
	names1249,
	types1249,
	attr_flags1249,
	gtypes1249,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1249,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_UNIX_OUTPUT_FILE",
	names1250,
	types1250,
	attr_flags1250,
	gtypes1250,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1250,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_INPUT_FILE",
	names1251,
	types1251,
	attr_flags1251,
	gtypes1251,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1251,
	NULL
},
{
	(long) 26,
	(long) 25,
	"KL_TEXT_INPUT_FILE",
	names1252,
	types1252,
	attr_flags1252,
	gtypes1252,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1252,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_BINARY_INPUT_FILE",
	names1253,
	types1253,
	attr_flags1253,
	gtypes1253,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1253,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_WINDOWS_INPUT_FILE",
	names1254,
	types1254,
	attr_flags1254,
	gtypes1254,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1254,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_UNIX_INPUT_FILE",
	names1255,
	types1255,
	attr_flags1255,
	gtypes1255,
	(uint16) 0x4400,
	(void (*)()) 0,
	offsets1255,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_CHARACTER_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"RX_CASE_MAPPING",
	names1257,
	types1257,
	attr_flags1257,
	gtypes1257,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1257,
	NULL
},
{
	(long) 12,
	(long) 12,
	"GEANT_DIRECTORYSET",
	names1258,
	types1258,
	attr_flags1258,
	gtypes1258,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1258,
	NULL
},
{
	(long) 18,
	(long) 18,
	"GEANT_FILESET",
	names1259,
	types1259,
	attr_flags1259,
	gtypes1259,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1259,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_DTD_EXTERNAL_ID",
	names1260,
	types1260,
	attr_flags1260,
	gtypes1260,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1260,
	NULL
},
{
	(long) 2,
	(long) 2,
	"GEANT_TASK_FACTORY",
	names1261,
	types1261,
	attr_flags1261,
	gtypes1261,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1261,
	NULL
},
{
	(long) 11,
	(long) 11,
	"RT_DBG_EXECUTION_RECORDER",
	names1262,
	types1262,
	attr_flags1262,
	gtypes1262,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1262,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_SHARED_UNICODE_CHARACTERS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_UNICODE_VALIDATION_FILTER",
	names1264,
	types1264,
	attr_flags1264,
	gtypes1264,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1264,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_OUTPUT",
	names1265,
	types1265,
	attr_flags1265,
	gtypes1265,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1265,
	NULL
},
{
	(long) 6,
	(long) 6,
	"XM_PRETTY_PRINT_FILTER",
	names1266,
	types1266,
	attr_flags1266,
	gtypes1266,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1266,
	NULL
},
{
	(long) 11,
	(long) 11,
	"XM_INDENT_PRETTY_PRINT_FILTER",
	names1267,
	types1267,
	attr_flags1267,
	gtypes1267,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1267,
	NULL
},
{
	(long) 6,
	(long) 6,
	"XM_CANONICAL_PRETTY_PRINT_FILTER",
	names1268,
	types1268,
	attr_flags1268,
	gtypes1268,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1268,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_UNIX_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM_BACKSLASH_ONLY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"UT_ERROR_HANDLER",
	names1274,
	types1274,
	attr_flags1274,
	gtypes1274,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1274,
	NULL
},
{
	(long) 4,
	(long) 4,
	"AP_ERROR_HANDLER",
	names1275,
	types1275,
	attr_flags1275,
	gtypes1275,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1275,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_NODE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_COMPOSITE_NODE",
	names1277,
	types1277,
	attr_flags1277,
	gtypes1277,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1277,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_DOCUMENT_NODE",
	names1278,
	types1278,
	attr_flags1278,
	gtypes1278,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1278,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_ELEMENT_NODE",
	names1279,
	types1279,
	attr_flags1279,
	gtypes1279,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1279,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_COMMENT",
	names1280,
	types1280,
	attr_flags1280,
	gtypes1280,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1280,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_PROCESSING_INSTRUCTION",
	names1281,
	types1281,
	attr_flags1281,
	gtypes1281,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1281,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_CHARACTER_DATA",
	names1282,
	types1282,
	attr_flags1282,
	gtypes1282,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1282,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_NAMED_NODE",
	names1283,
	types1283,
	attr_flags1283,
	gtypes1283,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1283,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XM_ATTRIBUTE",
	names1284,
	types1284,
	attr_flags1284,
	gtypes1284,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1284,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_COMPOSITE",
	names1285,
	types1285,
	attr_flags1285,
	gtypes1285,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1285,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_DOCUMENT",
	names1286,
	types1286,
	attr_flags1286,
	gtypes1286,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1286,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XM_ELEMENT",
	names1287,
	types1287,
	attr_flags1287,
	gtypes1287,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1287,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RX_PATTERN_MATCHER",
	names1288,
	types1288,
	attr_flags1288,
	gtypes1288,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1288,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RX_REGULAR_EXPRESSION",
	names1289,
	types1289,
	attr_flags1289,
	gtypes1289,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1289,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LX_PATTERN_MATCHER",
	names1290,
	types1290,
	attr_flags1290,
	gtypes1290,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1290,
	NULL
},
{
	(long) 14,
	(long) 14,
	"LX_DFA_PATTERN_MATCHER",
	names1291,
	types1291,
	attr_flags1291,
	gtypes1291,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1291,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LX_WILDCARD",
	names1292,
	types1292,
	attr_flags1292,
	gtypes1292,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1292,
	NULL
},
{
	(long) 14,
	(long) 14,
	"LX_DFA_WILDCARD",
	names1293,
	types1293,
	attr_flags1293,
	gtypes1293,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1293,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XM_XMLNS_GENERATOR_CONTEXT",
	names1294,
	types1294,
	attr_flags1294,
	gtypes1294,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1294,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_NAMESPACE_RESOLVER_CONTEXT",
	names1295,
	types1295,
	attr_flags1295,
	gtypes1295,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1295,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"XM_DTD_ATTRIBUTE_CONTENT",
	names1297,
	types1297,
	attr_flags1297,
	gtypes1297,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1297,
	NULL
},
{
	(long) 2,
	(long) 2,
	"GEANT_STRING_INTERPRETER",
	names1298,
	types1298,
	attr_flags1298,
	gtypes1298,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1298,
	NULL
},
{
	(long) 0,
	(long) 0,
	"YY_PARSER_TOKENS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"LX_WILDCARD_TOKENS",
	names1300,
	types1300,
	attr_flags1300,
	gtypes1300,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1300,
	NULL
},
{
	(long) 59,
	(long) 59,
	"LX_WILDCARD_SCANNER",
	names1301,
	types1301,
	attr_flags1301,
	gtypes1301,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1301,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_EIFFEL_TOKENS",
	names1302,
	types1302,
	attr_flags1302,
	gtypes1302,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1302,
	NULL
},
{
	(long) 47,
	(long) 47,
	"XM_EIFFEL_SCANNER_SKELETON",
	names1303,
	types1303,
	attr_flags1303,
	gtypes1303,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1303,
	NULL
},
{
	(long) 47,
	(long) 47,
	"XM_EIFFEL_SCANNER",
	names1304,
	types1304,
	attr_flags1304,
	gtypes1304,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1304,
	NULL
},
{
	(long) 49,
	(long) 49,
	"XM_EIFFEL_SCANNER_DTD",
	names1305,
	types1305,
	attr_flags1305,
	gtypes1305,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1305,
	NULL
},
{
	(long) 52,
	(long) 52,
	"XM_EIFFEL_ENTITY_DEF",
	names1306,
	types1306,
	attr_flags1306,
	gtypes1306,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1306,
	NULL
},
{
	(long) 54,
	(long) 54,
	"XM_EIFFEL_PE_ENTITY_DEF",
	names1307,
	types1307,
	attr_flags1307,
	gtypes1307,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1307,
	NULL
},
{
	(long) 23,
	(long) 23,
	"YY_PARSER_SKELETON",
	names1308,
	types1308,
	attr_flags1308,
	gtypes1308,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1308,
	NULL
},
{
	(long) 112,
	(long) 112,
	"LX_LEX_PARSER_SKELETON",
	names1309,
	types1309,
	attr_flags1309,
	gtypes1309,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1309,
	NULL
},
{
	(long) 133,
	(long) 133,
	"LX_WILDCARD_PARSER",
	names1310,
	types1310,
	attr_flags1310,
	gtypes1310,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1310,
	NULL
},
{
	(long) 39,
	(long) 39,
	"XM_EIFFEL_PARSER_SKELETON",
	names1311,
	types1311,
	attr_flags1311,
	gtypes1311,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1311,
	NULL
},
{
	(long) 83,
	(long) 83,
	"XM_EIFFEL_PARSER",
	names1312,
	types1312,
	attr_flags1312,
	gtypes1312,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1312,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_STRING_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"XM_DTD_ELEMENT_CONTENT",
	names1314,
	types1314,
	attr_flags1314,
	gtypes1314,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1314,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_ERROR",
	names1315,
	types1315,
	attr_flags1315,
	gtypes1315,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1315,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_UNRECOGNIZED_OPTION_ERROR",
	names1316,
	types1316,
	attr_flags1316,
	gtypes1316,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1316,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_UNRECOGNIZED_DIRECTIVE_ERROR",
	names1317,
	types1317,
	attr_flags1317,
	gtypes1317,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1317,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_UNDEFINED_DEFINITION_ERROR",
	names1318,
	types1318,
	attr_flags1318,
	gtypes1318,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1318,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_START_CONDITION_DECLARED_TWICE_ERROR",
	names1319,
	types1319,
	attr_flags1319,
	gtypes1319,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1319,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_MISSING_QUOTE_ERROR",
	names1320,
	types1320,
	attr_flags1320,
	gtypes1320,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1320,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_MISSING_BRACKET_ERROR",
	names1321,
	types1321,
	attr_flags1321,
	gtypes1321,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1321,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_DIRECTIVE_EXPECTED_ERROR",
	names1322,
	types1322,
	attr_flags1322,
	gtypes1322,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1322,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_INTEGER_TOO_LARGE_ERROR",
	names1323,
	types1323,
	attr_flags1323,
	gtypes1323,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1323,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_CHARACTER_OUT_OF_RANGE_ERROR",
	names1324,
	types1324,
	attr_flags1324,
	gtypes1324,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1324,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_BAD_START_CONDITION_ERROR",
	names1325,
	types1325,
	attr_flags1325,
	gtypes1325,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1325,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_BAD_CHARACTER_IN_BRACKETS_ERROR",
	names1326,
	types1326,
	attr_flags1326,
	gtypes1326,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1326,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_BAD_CHARACTER_CLASS_ERROR",
	names1327,
	types1327,
	attr_flags1327,
	gtypes1327,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1327,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_BAD_CHARACTER_ERROR",
	names1328,
	types1328,
	attr_flags1328,
	gtypes1328,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1328,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_INVALID_UNICODE_CHARACTER_ERROR",
	names1329,
	types1329,
	attr_flags1329,
	gtypes1329,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1329,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_START_CONDITION_EXPECTED_ERROR",
	names1330,
	types1330,
	attr_flags1330,
	gtypes1330,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1330,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_NAME_DEFINED_TWICE_ERROR",
	names1331,
	types1331,
	attr_flags1331,
	gtypes1331,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1331,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_INCOMPLETE_NAME_DEFINITION_ERROR",
	names1332,
	types1332,
	attr_flags1332,
	gtypes1332,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1332,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_UNDECLARED_START_CONDITION_ERROR",
	names1333,
	types1333,
	attr_flags1333,
	gtypes1333,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1333,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_TRAILING_CONTEXT_USED_TWICE_ERROR",
	names1334,
	types1334,
	attr_flags1334,
	gtypes1334,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1334,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_FULL_AND_REJECT_ERROR",
	names1335,
	types1335,
	attr_flags1335,
	gtypes1335,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1335,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_FULL_AND_META_ERROR",
	names1336,
	types1336,
	attr_flags1336,
	gtypes1336,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1336,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_FULL_AND_VARIABLE_TRAILING_CONTEXT_ERROR",
	names1337,
	types1337,
	attr_flags1337,
	gtypes1337,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1337,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_NEGATIVE_RANGE_IN_CHARACTER_CLASS_ERROR",
	names1338,
	types1338,
	attr_flags1338,
	gtypes1338,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1338,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_UNRECOGNIZED_RULE_ERROR",
	names1339,
	types1339,
	attr_flags1339,
	gtypes1339,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1339,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_MULTIPLE_EOF_RULES_ERROR",
	names1340,
	types1340,
	attr_flags1340,
	gtypes1340,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1340,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_ITERATION_NOT_POSITIVE_ERROR",
	names1341,
	types1341,
	attr_flags1341,
	gtypes1341,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1341,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_START_CONDITION_SPECIFIED_TWICE_ERROR",
	names1342,
	types1342,
	attr_flags1342,
	gtypes1342,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1342,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_BAD_ITERATION_VALUES_ERROR",
	names1343,
	types1343,
	attr_flags1343,
	gtypes1343,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1343,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_BAD_START_CONDITION_LIST_ERROR",
	names1344,
	types1344,
	attr_flags1344,
	gtypes1344,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1344,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LX_ALL_START_CONDITIONS_EOF_ERROR",
	names1345,
	types1345,
	attr_flags1345,
	gtypes1345,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1345,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_SYNTAX_ERROR",
	names1346,
	types1346,
	attr_flags1346,
	gtypes1346,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1346,
	NULL
},
{
	(long) 3,
	(long) 3,
	"AP_ERROR",
	names1347,
	types1347,
	attr_flags1347,
	gtypes1347,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1347,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_VERSION_NUMBER",
	names1348,
	types1348,
	attr_flags1348,
	gtypes1348,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1348,
	NULL
},
{
	(long) 0,
	(long) 0,
	"GEANT_SHARED_PROPERTIES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x4000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"GEANT_MAP",
	names1350,
	types1350,
	attr_flags1350,
	gtypes1350,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1350,
	NULL
},
{
	(long) 1,
	(long) 1,
	"GEANT_PROJECT_VARIABLE_RESOLVER",
	names1351,
	types1351,
	attr_flags1351,
	gtypes1351,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1351,
	NULL
},
{
	(long) 2,
	(long) 2,
	"GEANT_INHERIT",
	names1352,
	types1352,
	attr_flags1352,
	gtypes1352,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1352,
	NULL
},
{
	(long) 8,
	(long) 8,
	"GEANT_PARENT",
	names1353,
	types1353,
	attr_flags1353,
	gtypes1353,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1353,
	NULL
},
{
	(long) 20,
	(long) 20,
	"GEANT_PROJECT_VARIABLES",
	names1354,
	types1354,
	attr_flags1354,
	gtypes1354,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1354,
	NULL
},
{
	(long) 2,
	(long) 2,
	"GEANT_PROJECT_LOADER",
	names1355,
	types1355,
	attr_flags1355,
	gtypes1355,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1355,
	NULL
},
{
	(long) 15,
	(long) 15,
	"GEANT_PROJECT",
	names1356,
	types1356,
	attr_flags1356,
	gtypes1356,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1356,
	NULL
},
{
	(long) 7,
	(long) 7,
	"GEANT",
	names1357,
	types1357,
	attr_flags1357,
	gtypes1357,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1357,
	NULL
},
{
	(long) 2,
	(long) 2,
	"GEANT_PROPERTY",
	names1358,
	types1358,
	attr_flags1358,
	gtypes1358,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1358,
	NULL
},
{
	(long) 2,
	(long) 2,
	"GEANT_PROPERTY",
	names1359,
	types1359,
	attr_flags1359,
	gtypes1359,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1359,
	NULL
},
{
	(long) 2,
	(long) 2,
	"GEANT_BOOLEAN_PROPERTY",
	names1360,
	types1360,
	attr_flags1360,
	gtypes1360,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1360,
	NULL
},
{
	(long) 2,
	(long) 2,
	"GEANT_STRING_PROPERTY",
	names1361,
	types1361,
	attr_flags1361,
	gtypes1361,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1361,
	NULL
},
{
	(long) 2,
	(long) 2,
	"GEANT_ELEMENT",
	names1362,
	types1362,
	attr_flags1362,
	gtypes1362,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1362,
	NULL
},
{
	(long) 2,
	(long) 2,
	"GEANT_NAME_VALUE_ELEMENT",
	names1363,
	types1363,
	attr_flags1363,
	gtypes1363,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1363,
	NULL
},
{
	(long) 2,
	(long) 2,
	"GEANT_GLOBAL_ELEMENT",
	names1364,
	types1364,
	attr_flags1364,
	gtypes1364,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1364,
	NULL
},
{
	(long) 2,
	(long) 2,
	"GEANT_LOCAL_ELEMENT",
	names1365,
	types1365,
	attr_flags1365,
	gtypes1365,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1365,
	NULL
},
{
	(long) 2,
	(long) 2,
	"GEANT_ARGUMENT_ELEMENT",
	names1366,
	types1366,
	attr_flags1366,
	gtypes1366,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1366,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GEANT_INTERPRETING_ELEMENT",
	names1367,
	types1367,
	attr_flags1367,
	gtypes1367,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1367,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_SELECT_ELEMENT",
	names1368,
	types1368,
	attr_flags1368,
	gtypes1368,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1368,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_REDEFINE_ELEMENT",
	names1369,
	types1369,
	attr_flags1369,
	gtypes1369,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1369,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_RENAME_ELEMENT",
	names1370,
	types1370,
	attr_flags1370,
	gtypes1370,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1370,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_MAP_ELEMENT",
	names1371,
	types1371,
	attr_flags1371,
	gtypes1371,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1371,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_DIRECTORYSET_ELEMENT",
	names1372,
	types1372,
	attr_flags1372,
	gtypes1372,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1372,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GEANT_DEFINE_ELEMENT",
	names1373,
	types1373,
	attr_flags1373,
	gtypes1373,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1373,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_TASK",
	names1374,
	types1374,
	attr_flags1374,
	gtypes1374,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1374,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_SETENV_TASK",
	names1375,
	types1375,
	attr_flags1375,
	gtypes1375,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1375,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_MOVE_TASK",
	names1376,
	types1376,
	attr_flags1376,
	gtypes1376,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1376,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_COPY_TASK",
	names1377,
	types1377,
	attr_flags1377,
	gtypes1377,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1377,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_DELETE_TASK",
	names1378,
	types1378,
	attr_flags1378,
	gtypes1378,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1378,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_MKDIR_TASK",
	names1379,
	types1379,
	attr_flags1379,
	gtypes1379,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1379,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_GETEST_TASK",
	names1380,
	types1380,
	attr_flags1380,
	gtypes1380,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1380,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_GEYACC_TASK",
	names1381,
	types1381,
	attr_flags1381,
	gtypes1381,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1381,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_GELEX_TASK",
	names1382,
	types1382,
	attr_flags1382,
	gtypes1382,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1382,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_ECHO_TASK",
	names1383,
	types1383,
	attr_flags1383,
	gtypes1383,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1383,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_UNSET_TASK",
	names1384,
	types1384,
	attr_flags1384,
	gtypes1384,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1384,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_SET_TASK",
	names1385,
	types1385,
	attr_flags1385,
	gtypes1385,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1385,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_LCC_TASK",
	names1386,
	types1386,
	attr_flags1386,
	gtypes1386,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1386,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_EXEC_TASK",
	names1387,
	types1387,
	attr_flags1387,
	gtypes1387,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1387,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_ISE_TASK",
	names1388,
	types1388,
	attr_flags1388,
	gtypes1388,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1388,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_GEC_TASK",
	names1389,
	types1389,
	attr_flags1389,
	gtypes1389,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1389,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_GEPP_TASK",
	names1390,
	types1390,
	attr_flags1390,
	gtypes1390,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1390,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_REPLACE_TASK",
	names1391,
	types1391,
	attr_flags1391,
	gtypes1391,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1391,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_INPUT_TASK",
	names1392,
	types1392,
	attr_flags1392,
	gtypes1392,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1392,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_EXIT_TASK",
	names1393,
	types1393,
	attr_flags1393,
	gtypes1393,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1393,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_XSLT_TASK",
	names1394,
	types1394,
	attr_flags1394,
	gtypes1394,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1394,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GEANT_COMMAND",
	names1395,
	types1395,
	attr_flags1395,
	gtypes1395,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1395,
	NULL
},
{
	(long) 5,
	(long) 5,
	"GEANT_SETENV_COMMAND",
	names1396,
	types1396,
	attr_flags1396,
	gtypes1396,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1396,
	NULL
},
{
	(long) 8,
	(long) 8,
	"GEANT_DELETE_COMMAND",
	names1397,
	types1397,
	attr_flags1397,
	gtypes1397,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1397,
	NULL
},
{
	(long) 5,
	(long) 5,
	"GEANT_MKDIR_COMMAND",
	names1398,
	types1398,
	attr_flags1398,
	gtypes1398,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1398,
	NULL
},
{
	(long) 11,
	(long) 11,
	"GEANT_GEANT_COMMAND",
	names1399,
	types1399,
	attr_flags1399,
	gtypes1399,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1399,
	NULL
},
{
	(long) 14,
	(long) 14,
	"GEANT_GETEST_COMMAND",
	names1400,
	types1400,
	attr_flags1400,
	gtypes1400,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1400,
	NULL
},
{
	(long) 11,
	(long) 11,
	"GEANT_GEYACC_COMMAND",
	names1401,
	types1401,
	attr_flags1401,
	gtypes1401,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1401,
	NULL
},
{
	(long) 15,
	(long) 15,
	"GEANT_GELEX_COMMAND",
	names1402,
	types1402,
	attr_flags1402,
	gtypes1402,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1402,
	NULL
},
{
	(long) 8,
	(long) 8,
	"GEANT_ECHO_COMMAND",
	names1403,
	types1403,
	attr_flags1403,
	gtypes1403,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1403,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_UNSET_COMMAND",
	names1404,
	types1404,
	attr_flags1404,
	gtypes1404,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1404,
	NULL
},
{
	(long) 5,
	(long) 5,
	"GEANT_SET_COMMAND",
	names1405,
	types1405,
	attr_flags1405,
	gtypes1405,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1405,
	NULL
},
{
	(long) 5,
	(long) 5,
	"GEANT_LCC_COMMAND",
	names1406,
	types1406,
	attr_flags1406,
	gtypes1406,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1406,
	NULL
},
{
	(long) 8,
	(long) 8,
	"GEANT_EXEC_COMMAND",
	names1407,
	types1407,
	attr_flags1407,
	gtypes1407,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1407,
	NULL
},
{
	(long) 12,
	(long) 12,
	"GEANT_ISE_COMMAND",
	names1408,
	types1408,
	attr_flags1408,
	gtypes1408,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1408,
	NULL
},
{
	(long) 21,
	(long) 21,
	"GEANT_GEC_COMMAND",
	names1409,
	types1409,
	attr_flags1409,
	gtypes1409,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1409,
	NULL
},
{
	(long) 9,
	(long) 9,
	"GEANT_INPUT_COMMAND",
	names1410,
	types1410,
	attr_flags1410,
	gtypes1410,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1410,
	NULL
},
{
	(long) 5,
	(long) 5,
	"GEANT_PRECURSOR_COMMAND",
	names1411,
	types1411,
	attr_flags1411,
	gtypes1411,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1411,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_EXIT_COMMAND",
	names1412,
	types1412,
	attr_flags1412,
	gtypes1412,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1412,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GEANT_FILESYSTEM_COMMAND",
	names1413,
	types1413,
	attr_flags1413,
	gtypes1413,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1413,
	NULL
},
{
	(long) 7,
	(long) 7,
	"GEANT_MOVE_COMMAND",
	names1414,
	types1414,
	attr_flags1414,
	gtypes1414,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1414,
	NULL
},
{
	(long) 8,
	(long) 8,
	"GEANT_COPY_COMMAND",
	names1415,
	types1415,
	attr_flags1415,
	gtypes1415,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1415,
	NULL
},
{
	(long) 10,
	(long) 10,
	"GEANT_GEPP_COMMAND",
	names1416,
	types1416,
	attr_flags1416,
	gtypes1416,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1416,
	NULL
},
{
	(long) 12,
	(long) 12,
	"GEANT_REPLACE_COMMAND",
	names1417,
	types1417,
	attr_flags1417,
	gtypes1417,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1417,
	NULL
},
{
	(long) 8,
	(long) 8,
	"GEANT_AVAILABLE_COMMAND",
	names1418,
	types1418,
	attr_flags1418,
	gtypes1418,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1418,
	NULL
},
{
	(long) 10,
	(long) 10,
	"GEANT_OUTOFDATE_COMMAND",
	names1419,
	types1419,
	attr_flags1419,
	gtypes1419,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1419,
	NULL
},
{
	(long) 13,
	(long) 13,
	"GEANT_XSLT_COMMAND",
	names1420,
	types1420,
	attr_flags1420,
	gtypes1420,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1420,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_PARENT_ELEMENT",
	names1421,
	types1421,
	attr_flags1421,
	gtypes1421,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1421,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_FILESET_ELEMENT",
	names1422,
	types1422,
	attr_flags1422,
	gtypes1422,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1422,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_INHERIT_ELEMENT",
	names1423,
	types1423,
	attr_flags1423,
	gtypes1423,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1423,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_GEANT_TASK",
	names1424,
	types1424,
	attr_flags1424,
	gtypes1424,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1424,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_AVAILABLE_TASK",
	names1425,
	types1425,
	attr_flags1425,
	gtypes1425,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1425,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_PRECURSOR_TASK",
	names1426,
	types1426,
	attr_flags1426,
	gtypes1426,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1426,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GEANT_OUTOFDATE_TASK",
	names1427,
	types1427,
	attr_flags1427,
	gtypes1427,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1427,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GEANT_PROJECT_ELEMENT",
	names1428,
	types1428,
	attr_flags1428,
	gtypes1428,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1428,
	NULL
},
{
	(long) 5,
	(long) 5,
	"GEANT_GROUP",
	names1429,
	types1429,
	attr_flags1429,
	gtypes1429,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1429,
	NULL
},
{
	(long) 15,
	(long) 15,
	"GEANT_TARGET",
	names1430,
	types1430,
	attr_flags1430,
	gtypes1430,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1430,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PATHNAME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"KL_PATHNAME",
	names1432,
	types1432,
	attr_flags1432,
	gtypes1432,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1432,
	NULL
},
{
	(long) 32,
	(long) 32,
	"RX_PCRE_COMPILER",
	names1433,
	types1433,
	attr_flags1433,
	gtypes1433,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1433,
	NULL
},
{
	(long) 53,
	(long) 53,
	"RX_PCRE_MATCHER",
	names1434,
	types1434,
	attr_flags1434,
	gtypes1434,
	(uint16) 0x4000,
	(void (*)()) 0,
	offsets1434,
	NULL
},
{
	(long) 53,
	(long) 53,
	"RX_PCRE_REGULAR_EXPRESSION",
	names1435,
	types1435,
	attr_flags1435,
	gtypes1435,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1435,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_STRING",
	names1436,
	types1436,
	attr_flags1436,
	gtypes1436,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1436,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_UTF8_STRING",
	names1437,
	types1437,
	attr_flags1437,
	gtypes1437,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1437,
	NULL
},};


#ifdef __cplusplus
}
#endif
