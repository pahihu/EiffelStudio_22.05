#include "eif_eiffel.h"
#include "eif_rout_obj.h"
#include "eaddress.h"
#include "eoffsets.h"

#ifdef __cplusplus
extern "C" {
#endif

	/* MISMATCH_INFORMATION wipe_out */
void A240_98 (EIF_REFERENCE Current)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F822_4389)(Current);
}

	/* MISMATCH_INFORMATION internal_put */
void A240_162 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER)) F829_4462)(Current, arg1, arg2);
}

	/* MISMATCH_INFORMATION set_string_versions */
void A240_163 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER)) F829_4463)(Current, arg1, arg2);
}

	/* GEANT_TASK_FACTORY new_gec_task */
EIF_REFERENCE _A406_62_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_gec_task */
EIF_REFERENCE __A406_62_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_ise_task */
EIF_REFERENCE _A406_63_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_ise_task */
EIF_REFERENCE __A406_63_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_exec_task */
EIF_REFERENCE _A406_64_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_exec_task */
EIF_REFERENCE __A406_64_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_lcc_task */
EIF_REFERENCE _A406_65_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_lcc_task */
EIF_REFERENCE __A406_65_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_set_task */
EIF_REFERENCE _A406_66_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_set_task */
EIF_REFERENCE __A406_66_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_unset_task */
EIF_REFERENCE _A406_67_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_unset_task */
EIF_REFERENCE __A406_67_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_gelex_task */
EIF_REFERENCE _A406_68_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_gelex_task */
EIF_REFERENCE __A406_68_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_geyacc_task */
EIF_REFERENCE _A406_69_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_geyacc_task */
EIF_REFERENCE __A406_69_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_gepp_task */
EIF_REFERENCE _A406_70_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_gepp_task */
EIF_REFERENCE __A406_70_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_getest_task */
EIF_REFERENCE _A406_71_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_getest_task */
EIF_REFERENCE __A406_71_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_geant_task */
EIF_REFERENCE _A406_72_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_geant_task */
EIF_REFERENCE __A406_72_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_echo_task */
EIF_REFERENCE _A406_73_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_echo_task */
EIF_REFERENCE __A406_73_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_mkdir_task */
EIF_REFERENCE _A406_74_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_mkdir_task */
EIF_REFERENCE __A406_74_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_delete_task */
EIF_REFERENCE _A406_75_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_delete_task */
EIF_REFERENCE __A406_75_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_copy_task */
EIF_REFERENCE _A406_76_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_copy_task */
EIF_REFERENCE __A406_76_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_move_task */
EIF_REFERENCE _A406_77_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_move_task */
EIF_REFERENCE __A406_77_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_setenv_task */
EIF_REFERENCE _A406_78_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_setenv_task */
EIF_REFERENCE __A406_78_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_xslt_task */
EIF_REFERENCE _A406_79_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_xslt_task */
EIF_REFERENCE __A406_79_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_outofdate_task */
EIF_REFERENCE _A406_80_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_outofdate_task */
EIF_REFERENCE __A406_80_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_exit_task */
EIF_REFERENCE _A406_81_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_exit_task */
EIF_REFERENCE __A406_81_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_precursor_task */
EIF_REFERENCE _A406_82_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_precursor_task */
EIF_REFERENCE __A406_82_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_available_task */
EIF_REFERENCE _A406_83_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_available_task */
EIF_REFERENCE __A406_83_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_input_task */
EIF_REFERENCE _A406_84_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_input_task */
EIF_REFERENCE __A406_84_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_TASK_FACTORY new_replace_task */
EIF_REFERENCE _A406_85_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_TASK_FACTORY new_replace_task */
EIF_REFERENCE __A406_85_2 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_ARRAYED_LIST [G#1] is_empty */
EIF_BOOLEAN _A921_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5930[Dtype(open [1].it_r) - 1184])(open [1].it_r);
}

	/* DS_ARRAYED_LIST [INTEGER_32] is_empty */
EIF_BOOLEAN _A1052_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1126_7674)(open [1].it_r);
}

	/* DS_ARRAYED_LIST [G#1] is_empty */
EIF_BOOLEAN __A921_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5930[Dtype(op_1) - 1184])(op_1);
}

	/* DS_ARRAYED_LIST [INTEGER_32] is_empty */
EIF_BOOLEAN __A1052_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1126_7674)(op_1);
}

	/* DS_ARRAYED_LIST [G#1] has_void */
EIF_BOOLEAN _A921_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* DS_ARRAYED_LIST [INTEGER_32] has_void */
EIF_BOOLEAN _A1052_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* DS_ARRAYED_LIST [G#1] has_void */
EIF_BOOLEAN __A921_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* DS_ARRAYED_LIST [INTEGER_32] has_void */
EIF_BOOLEAN __A1052_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* DS_ARRAYED_LIST [G#1] there_exists */
EIF_BOOLEAN _A921_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* DS_ARRAYED_LIST [INTEGER_32] there_exists */
EIF_BOOLEAN _A1052_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* DS_ARRAYED_LIST [G#1] there_exists */
EIF_BOOLEAN __A921_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* DS_ARRAYED_LIST [INTEGER_32] there_exists */
EIF_BOOLEAN __A1052_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* GEANT_TASK log_validation_messages */
void _A517_93 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* GEANT_TASK log_validation_messages */
void __A517_93 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* GEANT_INTERPRETING_ELEMENT attribute_value */
EIF_REFERENCE _A510_77 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* GEANT_INTERPRETING_ELEMENT attribute_value */
EIF_REFERENCE __A510_77 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* GEANT_INTERPRETING_ELEMENT attribute_or_content_value */
EIF_REFERENCE _A510_65 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* GEANT_INTERPRETING_ELEMENT attribute_or_content_value */
EIF_REFERENCE __A510_65 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* GEANT_INTERPRETING_ELEMENT attribute_value_if_existing */
EIF_REFERENCE _A510_64 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* GEANT_INTERPRETING_ELEMENT attribute_value_if_existing */
EIF_REFERENCE __A510_64 ( EIF_REFERENCE(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* GEANT_MKDIR_COMMAND create_directory */
void _A541_71_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_MKDIR_COMMAND create_directory */
void __A541_71_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_ECHO_COMMAND write_message */
void _A546_74_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_ECHO_COMMAND write_message */
void __A546_74_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* GEANT_ECHO_COMMAND write_message_to_file */
void _A546_75_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r, open [3].it_b);
}

	/* GEANT_ECHO_COMMAND write_message_to_file */
void __A546_75_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3, EIF_BOOLEAN op_4)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4);
}

	/* GEANT_AVAILABLE_COMMAND is_resource_existing */
EIF_BOOLEAN _A561_77_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* GEANT_AVAILABLE_COMMAND is_resource_existing */
EIF_BOOLEAN __A561_77_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN _A296_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F641_3592)(open [1].it_r);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN __A296_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F641_3592)(op_1);
}


#ifdef __cplusplus
}
#endif
