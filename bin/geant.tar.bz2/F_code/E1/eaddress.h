#include "eif_eiffel.h"
#include "eif_rout_obj.h"

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1126_7674(EIF_REFERENCE);
extern void F829_4462(EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER);
extern EIF_BOOLEAN F641_3592(EIF_REFERENCE);
extern void F829_4463(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);
extern void F822_4389(EIF_REFERENCE);
extern char *(*R5930[])();

#ifdef __cplusplus
}
#endif
