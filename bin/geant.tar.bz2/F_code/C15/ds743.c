/*
 * Code for class DS_SPARSE_TABLE [G#1, G#2]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds743.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_TABLE}.make */
void F1223_8386 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y6263,Y6263_gen_type,Dftype(Current),1222).id);
	F1_29(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE)) R6248[Dtype(Current)-1232])(Current, arg1, NULL, *(EIF_REFERENCE *)(Current + _REFACS_3_));
	RTLE;
}

/* {DS_SPARSE_TABLE}.make_map */
void F1223_8389 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE)) R6248[Dtype(Current)-1232])(Current, arg1, NULL, NULL);
}

/* {DS_SPARSE_TABLE}.make_map_equal */
void F1223_8390 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y5980,Y5980_gen_type,Dftype(Current),1144).id);
	F1_29(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE)) R6248[Dtype(Current)-1232])(Current, arg1, *(EIF_REFERENCE *)(Current), NULL);
	RTLE;
}

/* {DS_SPARSE_TABLE}.make_map_default */
void F1223_8391 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6137[dtype-1205])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6245[dtype-1232])(Current, ti4_1);
	RTLE;
}

/* {DS_SPARSE_TABLE}.make_with_equality_testers */
void F1223_8392 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg3;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6174[Dtype(Current)-1220])(Current, arg1);
	RTLE;
}

/* {DS_SPARSE_TABLE}.item */
EIF_REFERENCE F1223_8394 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6189[dtype-1220])(Current, tr1);
	RTLE;
	return (EIF_REFERENCE) (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6183[dtype-1220])(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_));
}

/* {DS_SPARSE_TABLE}.value */
EIF_REFERENCE F1223_8395 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6190[dtype-1220])(Current, tr1);
	if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) -1L))) {
		RTLE;
		return (EIF_REFERENCE) (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6183[dtype-1220])(Current, loc1);
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {DS_SPARSE_TABLE}.key_for_iteration */
EIF_REFERENCE F1223_8398 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	RTLE;
	return (EIF_REFERENCE) (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R6018[Dtype(Current)-1232])(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
}

/* {DS_SPARSE_TABLE}.key_equality_tester */
EIF_REFERENCE F1223_8400 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {DS_SPARSE_TABLE}.has */
EIF_BOOLEAN F1223_8402 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6189[Dtype(Current)-1220])(Current, tr1);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) != ((EIF_INTEGER_32) -1L));
}

/* {DS_SPARSE_TABLE}.search */
void F1223_8405 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6189[Dtype(Current)-1220])(Current, tr1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_6_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_);
	RTLE;
}

/* {DS_SPARSE_TABLE}.is_equal */
EIF_BOOLEAN F1223_8406 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		tr1 = RTOSCF(6290,F953_6290, (Current));
		tb2 = F14_181(RTCW(tr1), Current, arg1);
		if (tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_11_0_0_8_);
			tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) == ti4_1);
		}
		if (tb1) {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L)))) break;
				if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc2) > ((EIF_INTEGER_32) -2L))) {
					loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6185[dtype-1220])(Current, loc2);
					Result = '\0';
					tr1 = RTCCL(loc1);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5943[Dtype(RTCW(arg1))-1232])(arg1, tr1);
					if (tb1) {
						tr1 = RTCCL(loc1);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5940[Dtype(RTCW(arg1))-1232])(arg1, tr1);
						Result = RTCEQ(tr1, (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6183[dtype-1220])(Current, loc2));
					}
				}
				loc2--;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_TABLE}.set_key_equality_tester */
void F1223_8407 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		(RTNA((loc1, arg1)));
	}
	RTLE;
}

/* {DS_SPARSE_TABLE}.replace */
void F1223_8408 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6178[dtype-1220])(Current);
	tr1 = RTCCL(arg2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6189[dtype-1220])(Current, tr1);
	tr1 = RTCCL(arg1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6184[dtype-1220])(Current, tr1, ti4_1);
	RTLE;
}

/* {DS_SPARSE_TABLE}.replace_found_item */
void F1223_8409 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_6_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6184[Dtype(Current)-1220])(Current, tr1, ti4_1);
	RTLE;
}

/* {DS_SPARSE_TABLE}.put */
void F1223_8410 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6178[dtype-1220])(Current);
	tr1 = RTCCL(arg2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6189[dtype-1220])(Current, tr1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		tr1 = RTCCL(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6184[dtype-1220])(Current, tr1, ti4_1);
	} else {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_))++;
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
		} else {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc1);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
		}
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_4_);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6212[dtype-1220])(Current, loc2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6207[dtype-1220])(Current, ti4_1, loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6213[dtype-1220])(Current, loc1, loc2);
		tr1 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6184[dtype-1220])(Current, tr1, loc1);
		tr1 = RTCCL(arg2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6201[dtype-1220])(Current, tr1, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))++;
	}
	RTLE;
}

/* {DS_SPARSE_TABLE}.force */
void F1223_8414 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6178[dtype-1220])(Current);
	tr1 = RTCCL(arg2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6189[dtype-1220])(Current, tr1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		tr1 = RTCCL(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6184[dtype-1220])(Current, tr1, ti4_1);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_))) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6140[dtype-1205])(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) + ((EIF_INTEGER_32) 1L)));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6139[dtype-1205])(Current, ti4_1);
			tr1 = RTCCL(arg2);
			loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6193[dtype-1220])(Current, tr1);
		} else {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_4_);
		}
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_))++;
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
		} else {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc1);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
		}
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6212[dtype-1220])(Current, loc2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6207[dtype-1220])(Current, ti4_1, loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6213[dtype-1220])(Current, loc1, loc2);
		tr1 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6184[dtype-1220])(Current, tr1, loc1);
		tr1 = RTCCL(arg2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6201[dtype-1220])(Current, tr1, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))++;
	}
	RTLE;
}

/* {DS_SPARSE_TABLE}.force_new */
void F1223_8415 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6178[dtype-1220])(Current);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_))) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6140[dtype-1205])(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) + ((EIF_INTEGER_32) 1L)));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6139[dtype-1205])(Current, ti4_1);
	}
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_))++;
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
	} else {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
	}
	tr1 = RTCCL(arg2);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6193[dtype-1220])(Current, tr1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6212[dtype-1220])(Current, loc2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6207[dtype-1220])(Current, ti4_1, loc1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6213[dtype-1220])(Current, loc1, loc2);
	tr1 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6184[dtype-1220])(Current, tr1, loc1);
	tr1 = RTCCL(arg2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6201[dtype-1220])(Current, tr1, loc1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))++;
	RTLE;
}

/* {DS_SPARSE_TABLE}.force_last */
void F1223_8416 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6178[dtype-1220])(Current);
	tr1 = RTCCL(arg2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6189[dtype-1220])(Current, tr1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		tr1 = RTCCL(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6184[dtype-1220])(Current, tr1, ti4_1);
	} else {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
		if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_))) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6140[dtype-1205])(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6139[dtype-1205])(Current, ti4_1);
			tr1 = RTCCL(arg2);
			loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6193[dtype-1220])(Current, tr1);
		} else {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_4_);
		}
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_) = (EIF_INTEGER_32) loc1;
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6212[dtype-1220])(Current, loc2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6207[dtype-1220])(Current, ti4_1, loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6213[dtype-1220])(Current, loc1, loc2);
		tr1 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6184[dtype-1220])(Current, tr1, loc1);
		tr1 = RTCCL(arg2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6201[dtype-1220])(Current, tr1, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))++;
	}
	RTLE;
}

/* {DS_SPARSE_TABLE}.force_last_new */
void F1223_8417 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6178[dtype-1220])(Current);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_))) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6140[dtype-1205])(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6139[dtype-1205])(Current, ti4_1);
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_) = (EIF_INTEGER_32) loc1;
	tr1 = RTCCL(arg2);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6193[dtype-1220])(Current, tr1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6212[dtype-1220])(Current, loc2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6207[dtype-1220])(Current, ti4_1, loc1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6213[dtype-1220])(Current, loc1, loc2);
	tr1 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6184[dtype-1220])(Current, tr1, loc1);
	tr1 = RTCCL(arg2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6201[dtype-1220])(Current, tr1, loc1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))++;
	RTLE;
}

/* {DS_SPARSE_TABLE}.copy */
void F1223_8418 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		F1212_8251(Current, arg1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {DS_SPARSE_TABLE}.internal_set_key_equality_tester */
void F1223_8427 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		(RTNA((loc1, arg1)));
	}
	RTLE;
}

/* {DS_SPARSE_TABLE}.cursor_key */
EIF_REFERENCE F1223_8430 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6185[Dtype(Current)-1220])(Current, ti4_1);
	RTLE;
	return Result;
}

void EIF_Minit743 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
