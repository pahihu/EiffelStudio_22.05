
#ifndef _C15_ds724_
#define _C15_ds724_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1103_7450(EIF_REFERENCE);
extern void F1103_7462(EIF_REFERENCE);
extern void EIF_Minit724(void);
extern char *(*R6100[])();
extern char *(*R6090[])();
extern char *(*R5704[])();

#ifdef __cplusplus
}
#endif

#endif
