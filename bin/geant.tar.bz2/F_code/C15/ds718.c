/*
 * Code for class DS_BILINKED_LIST [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds718.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_BILINKED_LIST}.new_cursor */
EIF_REFERENCE F1188_8015 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1109,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y5938,Y5938_gen_type,Dftype(Current),1124);
			typarr0[2] = l_type.annotations | 0xFF00;
			typarr0[3] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 1109, _OBJSIZ_3_2_0_0_0_0_0_0_);
	}
	F1108_7482(RTCW(tr1), Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {DS_BILINKED_LIST}.remove_last */
void F1188_8020 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) == ((EIF_INTEGER_32) 1L))) {
		F1185_7965(Current);
	} else {
		RTCT0("two_or_more_items", EX_CHECK);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = *(EIF_REFERENCE *)(loc1 + O1524[Dtype(loc1)-138]);
			loc2 = tr1;
			tb1 = EIF_TEST(loc2);
		}
		if (tb1) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1185_7972(Current);
		F1185_7969(Current, loc2);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_))--;
	}
	RTLE;
}

/* {DS_BILINKED_LIST}.remove_at_cursor */
void F1188_8021 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	tb1 = F1053_7392(RTCW(arg1));
	if (tb1) {
		F1185_7951(Current);
	} else {
		tb1 = F1061_7403(RTCW(arg1));
		if (tb1) {
			F1188_8020(Current);
		} else {
			RTCT0("not_off_and_not_last_and_not_first", EX_CHECK);
			tb1 = '\0';
			tb2 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			loc1 = tr1;
			if (EIF_TEST(loc1)) {
				tr1 = *(EIF_REFERENCE *)(loc1 + O1521[Dtype(loc1)-135]);
				loc2 = tr1;
				tb2 = EIF_TEST(loc2);
			}
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(loc1 + O1524[Dtype(loc1)-138]);
				loc3 = tr1;
				tb1 = EIF_TEST(loc3);
			}
			if (tb1) {
				RTCK0;
			} else {
				RTCF0;
			}
			F1185_7973(Current, loc1, loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1522[Dtype(loc3)-135])(loc3, loc2);
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_))--;
		}
	}
	RTLE;
}

/* {DS_BILINKED_LIST}.set_first_cell */
void F1188_8027 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R1526[Dtype(RTCW(arg1))-138])(arg1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {DS_BILINKED_LIST}.cursor_back */
void F1188_8028 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc3 = *(EIF_REFERENCE *)(loc4 + O1524[Dtype(loc4)-138]);
	} else {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	}
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc3 == NULL);
	F1108_7494(RTCW(arg1), loc3, loc2, (EIF_BOOLEAN) 0);
	if (loc2) {
		if ((EIF_BOOLEAN) !loc1) {
			F1139_7718(Current, arg1);
		}
	} else {
		if (loc1) {
			F1139_7717(Current, arg1);
		}
	}
	RTLE;
}

void EIF_Minit718 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
