
#ifndef _C15_to707_
#define _C15_to707_

#ifdef __cplusplus
extern "C" {
#endif

extern void F281_2751(EIF_REFERENCE, EIF_INTEGER_32);
extern void F281_2752(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern void F281_2758(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit707(void);
extern void F714_3970(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2478[];
extern EIF_TYPE_INDEX *Y2478_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
