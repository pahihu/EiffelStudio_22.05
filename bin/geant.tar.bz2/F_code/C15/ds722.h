
#ifndef _C15_ds722_
#define _C15_ds722_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1185_7905(EIF_REFERENCE);
extern EIF_REFERENCE F1185_7911(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1185_7912(EIF_REFERENCE);
extern EIF_REFERENCE F1185_7913(EIF_REFERENCE);
extern EIF_REFERENCE F1185_7914(EIF_REFERENCE);
extern EIF_INTEGER_32 F1185_7915(EIF_REFERENCE);
extern EIF_BOOLEAN F1185_7917(EIF_REFERENCE, EIF_REFERENCE);
extern void F1185_7927(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1185_7928(EIF_REFERENCE, EIF_REFERENCE);
extern void F1185_7930(EIF_REFERENCE, EIF_REFERENCE);
extern void F1185_7931(EIF_REFERENCE, EIF_REFERENCE);
extern void F1185_7932(EIF_REFERENCE, EIF_REFERENCE);
extern void F1185_7933(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F1185_7940(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1185_7951(EIF_REFERENCE);
extern void F1185_7952(EIF_REFERENCE);
extern void F1185_7954(EIF_REFERENCE, EIF_REFERENCE);
extern void F1185_7965(EIF_REFERENCE);
extern void F1185_7968(EIF_REFERENCE, EIF_REFERENCE);
extern void F1185_7969(EIF_REFERENCE, EIF_REFERENCE);
extern void F1185_7970(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1185_7971(EIF_REFERENCE);
extern void F1185_7972(EIF_REFERENCE);
extern void F1185_7973(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1185_7974(EIF_REFERENCE);
extern EIF_REFERENCE F1185_7975(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1185_7976(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1185_7977(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1185_7978(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1185_7979(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1185_7980(EIF_REFERENCE, EIF_REFERENCE);
extern void F1185_7981(EIF_REFERENCE, EIF_REFERENCE);
extern void F1185_7982(EIF_REFERENCE, EIF_REFERENCE);
extern void F1185_7983(EIF_REFERENCE, EIF_REFERENCE);
extern void F1185_7986(EIF_REFERENCE, EIF_REFERENCE);
extern void F1185_7987(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit722(void);
extern EIF_BOOLEAN F14_181(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F953_6290(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,6290)
extern char *(*R5717[])();
extern char *(*R5721[])();
extern char *(*R6108[])();
extern char *(*R6109[])();
extern char *(*R5767[])();
extern char *(*R5769[])();
extern char *(*R5961[])();
extern char *(*R5931[])();
extern char *(*R5964[])();
extern char *(*R6110[])();
extern char *(*R5966[])();
extern char *(*R6112[])();
extern char *(*R5770[])();
extern char *(*R5969[])();
extern char *(*R6111[])();
extern char *(*R5973[])();
extern char *(*R2207[])();
extern char *(*R1512[])();
extern char *(*R5972[])();
extern char *(*R1514[])();
extern char *(*R1515[])();
extern char *(*R5771[])();
extern char *(*R1522[])();
extern char *(*R1523[])();
extern char *(*R6058[])();
extern char *(*R6059[])();
extern char *(*R5772[])();
extern char *(*R5710[])();
extern long O1521[];
extern long O6114[];
extern EIF_TYPE_INDEX Y5938[];
extern EIF_TYPE_INDEX *Y5938_gen_type [];
extern EIF_TYPE_INDEX Y6106[];
extern EIF_TYPE_INDEX *Y6106_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
