
#ifndef _C15_ch700_
#define _C15_ch700_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F757_4124(EIF_REFERENCE);
extern void EIF_Minit700(void);

#ifdef __cplusplus
}
#endif

#endif
