
#ifndef _C15_ds738_
#define _C15_ds738_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1088_7442(EIF_REFERENCE);
extern void EIF_Minit738(void);
extern char *(*R6018[])();

#ifdef __cplusplus
}
#endif

#endif
