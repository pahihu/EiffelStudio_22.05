
#ifndef _C15_ds728_
#define _C15_ds728_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1179_7847(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit728(void);
extern char *(*R6045[])();
extern char *(*R6052[])();

#ifdef __cplusplus
}
#endif

#endif
