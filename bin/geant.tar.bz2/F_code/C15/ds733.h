
#ifndef _C15_ds733_
#define _C15_ds733_

#ifdef __cplusplus
extern "C" {
#endif

extern void F139_1574(EIF_REFERENCE, EIF_REFERENCE);
extern void F139_1575(EIF_REFERENCE, EIF_REFERENCE);
extern void F139_1576(EIF_REFERENCE);
extern void F139_1577(EIF_REFERENCE, EIF_REFERENCE);
extern void F139_1578(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit733(void);
extern char *(*R1527[])();
extern char *(*R1528[])();
extern long O1521[];
extern long O1524[];

#ifdef __cplusplus
}
#endif

#endif
