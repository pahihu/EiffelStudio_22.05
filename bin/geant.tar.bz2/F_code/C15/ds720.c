/*
 * Code for class DS_SORTABLE [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds720.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SORTABLE}.sort */
void F1136_7704 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R975[Dtype(RTCW(arg1))-76])(arg1, Current);
}

void EIF_Minit720 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
