
#ifndef _C15_ds746_
#define _C15_ds746_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1212_8231(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1212_8232(EIF_REFERENCE);
extern EIF_INTEGER_32 F1212_8236(EIF_REFERENCE);
extern EIF_INTEGER_32 F1212_8237(EIF_REFERENCE);
extern EIF_BOOLEAN F1212_8239(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1212_8240(EIF_REFERENCE);
extern void F1212_8250(EIF_REFERENCE);
extern void F1212_8251(EIF_REFERENCE, EIF_REFERENCE);
extern void F1212_8252(EIF_REFERENCE, EIF_REFERENCE);
extern void F1212_8254(EIF_REFERENCE);
extern void F1212_8255(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1212_8264(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1212_8265(EIF_REFERENCE, EIF_REFERENCE);
extern void F1212_8269(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1212_8301(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1212_8302(EIF_REFERENCE);
extern void F1212_8303(EIF_REFERENCE);
extern void F1212_8306(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1212_8307(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1212_8308(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1212_8309(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1212_8310(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1212_8311(EIF_REFERENCE, EIF_REFERENCE);
extern void F1212_8312(EIF_REFERENCE, EIF_REFERENCE);
extern void F1212_8313(EIF_REFERENCE, EIF_REFERENCE);
extern void F1212_8314(EIF_REFERENCE, EIF_REFERENCE);
extern void F1212_8317(EIF_REFERENCE, EIF_REFERENCE);
extern void F1212_8318(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1212_8320(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1212_8321(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit746(void);
extern char *(*R6214[])();
extern char *(*R6215[])();
extern char *(*R6216[])();
extern char *(*R3741[])();
extern char *(*R6183[])();
extern char *(*R6184[])();
extern char *(*R6185[])();
extern char *(*R6186[])();
extern char *(*R5737[])();
extern char *(*R6189[])();
extern char *(*R5973[])();
extern char *(*R6226[])();
extern char *(*R6229[])();
extern char *(*R6191[])();
extern char *(*R5961[])();
extern char *(*R6193[])();
extern char *(*R6194[])();
extern char *(*R6195[])();
extern char *(*R6196[])();
extern char *(*R5966[])();
extern char *(*R6198[])();
extern char *(*R6199[])();
extern char *(*R6230[])();
extern char *(*R5710[])();
extern char *(*R5969[])();
extern char *(*R2207[])();
extern char *(*R5736[])();
extern char *(*R6213[])();
extern char *(*R5738[])();
extern char *(*R5972[])();
extern char *(*R5930[])();
extern char *(*R6192[])();
extern char *(*R6200[])();
extern char *(*R6201[])();
extern char *(*R6202[])();
extern char *(*R6203[])();
extern char *(*R6204[])();
extern char *(*R6197[])();
extern char *(*R6206[])();
extern char *(*R6207[])();
extern char *(*R6208[])();
extern char *(*R6209[])();
extern char *(*R3733[])();
extern char *(*R6205[])();
extern char *(*R6178[])();
extern char *(*R6210[])();
extern char *(*R6211[])();
extern char *(*R6212[])();
extern char *(*R5964[])();
extern long O6217[];
extern long O6218[];
extern long O6219[];
extern long O6182[];
extern long O6220[];
extern long O6221[];
extern long O6222[];
extern long O6232[];
extern long O6233[];
extern EIF_TYPE_INDEX Y5938[];
extern EIF_TYPE_INDEX *Y5938_gen_type [];
extern EIF_TYPE_INDEX Y6234[];
extern EIF_TYPE_INDEX *Y6234_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
