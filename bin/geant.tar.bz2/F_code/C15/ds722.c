/*
 * Code for class DS_LINKED_LIST [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds722.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_LINKED_LIST}.make */
void F1185_7905 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5961[dtype-1184])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5966[dtype-1184])(Current, tr1);
	RTLE;
}

/* {DS_LINKED_LIST}.item */
EIF_REFERENCE F1185_7911 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc2 == arg1)) break;
		RTCT0("valid_index", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1521[Dtype(loc1)-135]);
		loc1 = (EIF_REFERENCE) tr1;
		loc2++;
	}
	RTCT0("valid_index", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1512[Dtype(RTCW(loc1))-129])(loc1);
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.first */
EIF_REFERENCE F1185_7912 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("not_empty", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1512[Dtype(loc1)-129])(loc1);
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.last */
EIF_REFERENCE F1185_7913 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("not_empty", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1512[Dtype(loc1)-129])(loc1);
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.new_cursor */
EIF_REFERENCE F1185_7914 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1107,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y5938,Y5938_gen_type,Dftype(Current),1124);
			typarr0[2] = l_type.annotations | 0xFF00;
			typarr0[3] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 1107, _OBJSIZ_3_2_0_0_0_0_0_0_);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5767[Dtype(RTCW(tr1))-1107])(tr1, Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {DS_LINKED_LIST}.count */
EIF_INTEGER_32 F1185_7915 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O6114[Dtype(Current)-1184]);
}


/* {DS_LINKED_LIST}.has */
EIF_BOOLEAN F1185_7917 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,arg1);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		for (;;) {
			if ((EIF_BOOLEAN)(loc1 == NULL)) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1512[Dtype(RTCW(loc1))-129])(loc1);
			tr2 = RTCCL(tr1);
			tr3 = RTCCL(arg1);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2207[Dtype(loc2)-254])(loc2, tr2, tr3);
			if (tb1) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_REFERENCE) NULL;
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1521[Dtype(loc1)-135]);
				loc1 = (EIF_REFERENCE) tr1;
			}
		}
	} else {
		for (;;) {
			if ((EIF_BOOLEAN)(loc1 == NULL)) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1512[Dtype(RTCW(loc1))-129])(loc1);
			if (RTCEQ(tr1, arg1)) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_REFERENCE) NULL;
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1521[Dtype(loc1)-135]);
				loc1 = (EIF_REFERENCE) tr1;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.copy */
void F1185_7927 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLR(7,loc2);
	RTLIU(8);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		loc4 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6112[dtype-1184])(Current);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5964[dtype-1184])(Current, loc4);
		}
		if (tb1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5966[dtype-1184])(Current, loc4);
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5961[dtype-1184])(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5966[dtype-1184])(Current, tr1);
		}
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			loc3 = RTLNSMART(eif_final_id(Y6106,Y6106_gen_type,dftype,1184).id);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1512[Dtype(RTCW(loc1))-129])(loc1);
			tr2 = RTCCL(tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1515[Dtype(RTCW(loc3))-129])(loc3, tr2);
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc3;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1521[Dtype(loc1)-135]);
			loc1 = (EIF_REFERENCE) tr1;
			for (;;) {
				if ((EIF_BOOLEAN)(loc1 == NULL)) break;
				loc2 = RTLNSMART(eif_final_id(Y6106,Y6106_gen_type,dftype,1184).id);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1512[Dtype(RTCW(loc1))-129])(loc1);
				tr2 = RTCCL(tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1515[Dtype(RTCW(loc2))-129])(loc2, tr2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1522[Dtype(RTCW(loc3))-135])(loc3, loc2);
				loc3 = (EIF_REFERENCE) loc2;
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1521[Dtype(loc1)-135]);
				loc1 = (EIF_REFERENCE) tr1;
			}
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc3;
		}
	}
	RTLE;
}

/* {DS_LINKED_LIST}.is_equal */
EIF_BOOLEAN F1185_7928 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		tr1 = RTOSCF(6290,F953_6290, (Current));
		tb2 = F14_181(RTCW(tr1), Current, arg1);
		if (tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O6114[Dtype(arg1)-1184]);
			tb1 = (EIF_BOOLEAN)(ti4_1 == *(EIF_INTEGER_32 *)(Current + O6114[Dtype(Current)-1184]));
		}
		if (tb1) {
			loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == NULL) || (EIF_BOOLEAN)(loc2 == NULL))) break;
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1512[Dtype(RTCW(loc1))-129])(loc1);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1512[Dtype(RTCW(loc2))-129])(loc2);
				if (!RTCEQ(tr1, tr2)) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc1 = (EIF_REFERENCE) NULL;
				} else {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1521[Dtype(loc1)-135]);
					loc1 = (EIF_REFERENCE) tr1;
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + O1521[Dtype(loc2)-135]);
					loc2 = (EIF_REFERENCE) tr1;
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.force_first */
void F1185_7930 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = RTLNSMART(eif_final_id(Y6106,Y6106_gen_type,dftype,1184).id);
		tr1 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1515[Dtype(RTCW(loc1))-129])(loc1, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1522[Dtype(RTCW(loc1))-135])(loc1, loc2);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
		(*(EIF_INTEGER_32 *)(Current + O6114[dtype-1184]))++;
	} else {
		tr1 = RTLNSMART(eif_final_id(Y6106,Y6106_gen_type,dftype,1184).id);
		tr2 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1515[Dtype(RTCW(tr1))-129])(tr1, tr2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		*(EIF_INTEGER_32 *)(Current + O6114[dtype-1184]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.put_last */
void F1185_7931 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = RTLNSMART(eif_final_id(Y6106,Y6106_gen_type,dftype,1184).id);
		tr1 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1515[Dtype(RTCW(loc1))-129])(loc1, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1522[Dtype(loc2)-135])(loc2, loc1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
		(*(EIF_INTEGER_32 *)(Current + O6114[dtype-1184]))++;
	} else {
		tr1 = RTLNSMART(eif_final_id(Y6106,Y6106_gen_type,dftype,1184).id);
		tr2 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1515[Dtype(RTCW(tr1))-129])(tr1, tr2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		*(EIF_INTEGER_32 *)(Current + O6114[dtype-1184]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.force_last */
void F1185_7932 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = RTLNSMART(eif_final_id(Y6106,Y6106_gen_type,dftype,1184).id);
		tr1 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1515[Dtype(RTCW(loc1))-129])(loc1, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1522[Dtype(loc2)-135])(loc2, loc1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
		(*(EIF_INTEGER_32 *)(Current + O6114[dtype-1184]))++;
	} else {
		tr1 = RTLNSMART(eif_final_id(Y6106,Y6106_gen_type,dftype,1184).id);
		tr2 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1515[Dtype(RTCW(tr1))-129])(tr1, tr2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		*(EIF_INTEGER_32 *)(Current + O6114[dtype-1184]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.replace */
void F1185_7933 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc2 == arg2)) break;
		RTCT0("valid_index", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1521[Dtype(loc1)-135]);
		loc1 = (EIF_REFERENCE) tr1;
		loc2++;
	}
	RTCT0("valid_index", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1514[Dtype(RTCW(loc1))-129])(loc1, tr1);
	RTLE;
}

/* {DS_LINKED_LIST}.swap */
void F1185_7940 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,loc6);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != arg2)) {
		if ((EIF_BOOLEAN) (arg1 < arg2)) {
			loc1 = (EIF_INTEGER_32) arg1;
			loc2 = (EIF_INTEGER_32) arg2;
		} else {
			loc1 = (EIF_INTEGER_32) arg2;
			loc2 = (EIF_INTEGER_32) arg1;
		}
		loc4 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN)(loc3 == loc1)) break;
			RTCT0("valid_i", EX_CHECK);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + O1521[Dtype(loc4)-135]);
			loc4 = (EIF_REFERENCE) tr1;
			loc3++;
		}
		loc5 = (EIF_REFERENCE) loc4;
		for (;;) {
			if ((EIF_BOOLEAN)(loc3 == loc2)) break;
			RTCT0("valid_j", EX_CHECK);
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + O1521[Dtype(loc5)-135]);
			loc5 = (EIF_REFERENCE) tr1;
			loc3++;
		}
		RTCT0("valid_i_and_j", EX_CHECK);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 != NULL) && (EIF_BOOLEAN)(loc5 != NULL))) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1512[Dtype(RTCW(loc4))-129])(loc4);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1512[Dtype(RTCW(loc5))-129])(loc5);
		tr2 = RTCCL(tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1514[Dtype(RTCW(loc4))-129])(loc4, tr2);
		tr1 = RTCCL(loc6);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1514[Dtype(RTCW(loc5))-129])(loc5, tr1);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.remove_first */
void F1185_7951 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O6114[dtype-1184]) == ((EIF_INTEGER_32) 1L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5931[dtype-1184])(Current);
	} else {
		RTCT0("two_or_more_items", EX_CHECK);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = *(EIF_REFERENCE *)(loc1 + O1521[Dtype(loc1)-135]);
			loc2 = tr1;
			tb1 = EIF_TEST(loc2);
		}
		if (tb1) {
			RTCK0;
		} else {
			RTCF0;
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R6111[dtype-1184])(Current, loc1, loc2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6108[dtype-1184])(Current, loc2);
		(*(EIF_INTEGER_32 *)(Current + O6114[dtype-1184]))--;
	}
	RTLE;
}

/* {DS_LINKED_LIST}.remove_last */
void F1185_7952 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O6114[dtype-1184]) == ((EIF_INTEGER_32) 1L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5931[dtype-1184])(Current);
	} else {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6110[dtype-1184])(Current);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = *(EIF_INTEGER_32 *)(Current + O6114[dtype-1184]);
		for (;;) {
			if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 2L))) break;
			RTCT0("two_or_more_items", EX_CHECK);
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1521[Dtype(loc1)-135]);
			loc1 = (EIF_REFERENCE) tr1;
			loc2--;
		}
		RTCT0("two_or_more_items", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6109[dtype-1184])(Current, loc1);
		(*(EIF_INTEGER_32 *)(Current + O6114[dtype-1184]))--;
	}
	RTLE;
}

/* {DS_LINKED_LIST}.remove_at_cursor */
void F1185_7954 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5717[Dtype(RTCW(arg1))-1085])(arg1);
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6058[dtype-1184])(Current);
	} else {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5721[Dtype(RTCW(arg1))-1085])(arg1);
		if (tb1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R6059[dtype-1184])(Current);
		} else {
			RTCT0("not_off_and_not_last", EX_CHECK);
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			loc1 = tr1;
			if (EIF_TEST(loc1)) {
				tr1 = *(EIF_REFERENCE *)(loc1 + O1521[Dtype(loc1)-135]);
				loc2 = tr1;
				tb1 = EIF_TEST(loc2);
			}
			if (tb1) {
				RTCK0;
			} else {
				RTCF0;
			}
			if ((EIF_BOOLEAN)(loc2 == *(EIF_REFERENCE *)(Current + _REFACS_2_))) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6109[dtype-1184])(Current, loc1);
			} else {
				RTCT0("before_second_to_last", EX_CHECK);
				tr1 = *(EIF_REFERENCE *)(loc2 + O1521[Dtype(loc2)-135]);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					RTCK0;
				} else {
					RTCF0;
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1522[Dtype(loc1)-135])(loc1, loc3);
			}
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1512[Dtype(loc2)-129])(loc2);
			tr2 = RTCCL(tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1514[Dtype(loc1)-129])(loc1, tr2);
			(*(EIF_INTEGER_32 *)(Current + O6114[dtype-1184]))--;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R6111[dtype-1184])(Current, loc2, loc1);
		}
	}
	RTLE;
}

/* {DS_LINKED_LIST}.wipe_out */
void F1185_7965 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6112[dtype-1184])(Current);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	*(EIF_INTEGER_32 *)(Current + O6114[dtype-1184]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {DS_LINKED_LIST}.set_first_cell */
void F1185_7968 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {DS_LINKED_LIST}.set_last_cell */
void F1185_7969 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R1523[Dtype(RTCW(arg1))-135])(arg1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {DS_LINKED_LIST}.set_internal_cursor */
void F1185_7970 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {DS_LINKED_LIST}.internal_cursor */
EIF_REFERENCE F1185_7971 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {DS_LINKED_LIST}.move_last_cursors_after */
void F1185_7972 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
	if ((EIF_BOOLEAN)(tr1 == loc4)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5770[Dtype(RTCW(loc1))-1107])(loc1);
	}
	loc3 = (EIF_REFERENCE) loc1;
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
	loc1 = (EIF_REFERENCE) tr1;
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		if ((EIF_BOOLEAN)(tr1 == loc4)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5770[Dtype(RTCW(loc1))-1107])(loc1);
			loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5710[Dtype(RTCW(loc3))-1085])(loc3, loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5710[Dtype(RTCW(loc1))-1085])(loc1, NULL);
			loc1 = (EIF_REFERENCE) loc2;
		} else {
			loc3 = (EIF_REFERENCE) loc1;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			loc1 = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

/* {DS_LINKED_LIST}.move_all_cursors */
void F1185_7973 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		if ((EIF_BOOLEAN)(tr1 == arg1)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5769[Dtype(RTCW(loc1))-1107])(loc1, arg2);
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		loc1 = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {DS_LINKED_LIST}.move_all_cursors_after */
void F1185_7974 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5770[Dtype(RTCW(loc1))-1107])(loc1);
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5710[Dtype(RTCW(loc1))-1085])(loc1, NULL);
		loc1 = (EIF_REFERENCE) loc2;
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_item */
EIF_REFERENCE F1185_7975 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	RTCT0("not_off", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1512[Dtype(loc1)-129])(loc1);
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.cursor_index */
EIF_INTEGER_32 F1185_7976 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_1_);
	if (tb1) {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O6114[Dtype(Current)-1184]) + ((EIF_INTEGER_32) 1L));
	} else {
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_0_);
		if ((EIF_BOOLEAN) !tb1) {
			loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN)(loc1 == loc2)) break;
				RTCT0("valid_cursor", EX_CHECK);
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1521[Dtype(loc1)-135]);
				loc1 = (EIF_REFERENCE) tr1;
				Result++;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.cursor_is_first */
EIF_BOOLEAN F1185_7977 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && (EIF_BOOLEAN)(loc1 == *(EIF_REFERENCE *)(Current + _REFACS_1_)));
}

/* {DS_LINKED_LIST}.cursor_is_last */
EIF_BOOLEAN F1185_7978 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && (EIF_BOOLEAN)(loc1 == *(EIF_REFERENCE *)(Current + _REFACS_2_)));
}

/* {DS_LINKED_LIST}.cursor_same_position */
EIF_BOOLEAN F1185_7979 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
	if ((EIF_BOOLEAN)(tr1 == tr2)) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_0_);
		tb3 = *(EIF_BOOLEAN *)(RTCW(arg2)+ _CHROFF_3_0_);
		tb1 = (EIF_BOOLEAN)(tb2 == tb3);
	}
	if (tb1) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_1_);
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg2)+ _CHROFF_3_1_);
		Result = (EIF_BOOLEAN)(tb1 == tb2);
	}
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.cursor_start */
void F1185_7980 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5969[dtype-1184])(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == NULL);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN)) R5772[Dtype(RTCW(arg1))-1107])(arg1, *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_BOOLEAN) 0, loc2);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc2 && loc1)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5972[dtype-1184])(Current, arg1);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_finish */
void F1185_7981 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5969[dtype-1184])(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == NULL);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN)) R5772[Dtype(RTCW(arg1))-1107])(arg1, *(EIF_REFERENCE *)(Current + _REFACS_2_), loc2, (EIF_BOOLEAN) 0);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc2 && loc1)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5972[dtype-1184])(Current, arg1);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_forth */
void F1185_7982 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc3 = *(EIF_REFERENCE *)(loc4 + O1521[Dtype(loc4)-135]);
	} else {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	}
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc3 == NULL);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN)) R5772[Dtype(RTCW(arg1))-1107])(arg1, loc3, (EIF_BOOLEAN) 0, loc2);
	if (loc2) {
		if ((EIF_BOOLEAN) !loc1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5973[dtype-1184])(Current, arg1);
		}
	} else {
		if (loc1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5972[dtype-1184])(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_back */
void F1185_7983 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc2);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_1_);
	if (tb1) {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	} else {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5717[Dtype(RTCW(arg1))-1085])(arg1);
		if (tb1) {
			loc2 = (EIF_REFERENCE) NULL;
		} else {
			loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			loc2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			for (;;) {
				tb1 = '\01';
				if (!(EIF_BOOLEAN)(loc2 == NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + O1521[Dtype(loc2)-135]);
					tb1 = (EIF_BOOLEAN)(tr1 == loc1);
				}
				if (tb1) break;
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + O1521[Dtype(loc2)-135]);
				loc2 = (EIF_REFERENCE) tr1;
			}
		}
	}
	loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc2 == NULL);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN)) R5772[Dtype(RTCW(arg1))-1107])(arg1, loc2, loc4, (EIF_BOOLEAN) 0);
	if (loc4) {
		if ((EIF_BOOLEAN) !loc3) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5973[dtype-1184])(Current, arg1);
		}
	} else {
		if (loc3) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5972[dtype-1184])(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_go_after */
void F1185_7986 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5969[dtype-1184])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5770[Dtype(RTCW(arg1))-1107])(arg1);
	if ((EIF_BOOLEAN) !loc1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5973[dtype-1184])(Current, arg1);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_go_before */
void F1185_7987 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5969[dtype-1184])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5771[Dtype(RTCW(arg1))-1107])(arg1);
	if ((EIF_BOOLEAN) !loc1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5973[dtype-1184])(Current, arg1);
	}
	RTLE;
}

void EIF_Minit722 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
