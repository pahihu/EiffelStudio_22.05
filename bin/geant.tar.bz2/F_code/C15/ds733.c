/*
 * Code for class DS_BILINKABLE [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds733.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_BILINKABLE}.put_right */
void F139_1574 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O1521[Dtype(Current)-135]) = (EIF_REFERENCE) arg1;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1528[Dtype(RTCW(arg1))-138])(arg1, Current);
	RTLE;
}

/* {DS_BILINKABLE}.put_left */
void F139_1575 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O1524[Dtype(Current)-138]) = (EIF_REFERENCE) arg1;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1527[Dtype(RTCW(arg1))-138])(arg1, Current);
	RTLE;
}

/* {DS_BILINKABLE}.forget_left */
void F139_1576 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_REFERENCE *)(Current + O1524[Dtype(Current)-138]) = (EIF_REFERENCE) NULL;
}

/* {DS_BILINKABLE}.attach_right */
void F139_1577 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O1521[Dtype(Current)-135]) = (EIF_REFERENCE) arg1;
}

/* {DS_BILINKABLE}.attach_left */
void F139_1578 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O1524[Dtype(Current)-138]) = (EIF_REFERENCE) arg1;
}

void EIF_Minit733 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
