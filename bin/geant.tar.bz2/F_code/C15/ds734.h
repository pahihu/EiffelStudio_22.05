
#ifndef _C15_ds734_
#define _C15_ds734_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1098_7448(EIF_REFERENCE);
extern void EIF_Minit734(void);

#ifdef __cplusplus
}
#endif

#endif
