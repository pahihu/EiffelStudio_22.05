
#ifndef _C15_ha713_
#define _C15_ha713_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F439_3435(EIF_REFERENCE);
extern EIF_REFERENCE F439_3436(EIF_REFERENCE);
extern EIF_BOOLEAN F439_3438(EIF_REFERENCE);
extern void F439_3439(EIF_REFERENCE);
extern EIF_REFERENCE F439_3440(EIF_REFERENCE);
extern void EIF_Minit713(void);
extern EIF_INTEGER_32 F823_4380(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F823_4379(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F426_3421(EIF_REFERENCE);
extern char *(*R3355[])();
extern char *(*R2870[])();

#ifdef __cplusplus
}
#endif

#endif
