
#ifndef _C15_ds747_
#define _C15_ds747_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1202_8105(EIF_REFERENCE);
extern EIF_INTEGER_32 F1202_8108(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit747(void);

#ifdef __cplusplus
}
#endif

#endif
