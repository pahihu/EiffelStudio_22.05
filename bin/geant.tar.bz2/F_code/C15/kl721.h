
#ifndef _C15_kl721_
#define _C15_kl721_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F141_1579(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F141_1580(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit721(void);
extern char *(*R1530[])();
extern char *(*R1531[])();

#ifdef __cplusplus
}
#endif

#endif
