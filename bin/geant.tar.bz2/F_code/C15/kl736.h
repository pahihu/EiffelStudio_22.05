
#ifndef _C15_kl736_
#define _C15_kl736_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F24_227(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F24_228(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F24_230(EIF_REFERENCE, EIF_REFERENCE);
extern void F24_232(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F24_235(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F24_236(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit736(void);
extern char *(*R3361[])();
extern char *(*R3371[])();
extern char *(*R2870[])();
extern char *(*R2871[])();
extern char *(*R3375[])();
extern char *(*R3388[])();
extern char *(*R3389[])();

#ifdef __cplusplus
}
#endif

#endif
