/*
 * Code for class DS_LINKABLE [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds731.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_LINKABLE}.put_right */
void F136_1571 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O1521[Dtype(Current)-135]) = (EIF_REFERENCE) arg1;
}

/* {DS_LINKABLE}.forget_right */
void F136_1572 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_REFERENCE *)(Current + O1521[Dtype(Current)-135]) = (EIF_REFERENCE) NULL;
}

void EIF_Minit731 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
