
#ifndef _C15_ds732_
#define _C15_ds732_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1110_7496(EIF_REFERENCE);
extern void EIF_Minit732(void);

#ifdef __cplusplus
}
#endif

#endif
