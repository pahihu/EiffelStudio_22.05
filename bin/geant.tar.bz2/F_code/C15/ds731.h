
#ifndef _C15_ds731_
#define _C15_ds731_

#ifdef __cplusplus
extern "C" {
#endif

extern void F136_1571(EIF_REFERENCE, EIF_REFERENCE);
extern void F136_1572(EIF_REFERENCE);
extern void EIF_Minit731(void);
extern long O1521[];

#ifdef __cplusplus
}
#endif

#endif
