
#ifndef _C15_ds735_
#define _C15_ds735_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1233_8466(EIF_REFERENCE);
extern EIF_INTEGER_32 F1233_8469(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit735(void);
extern char *(*R3640[])();
extern char *(*R5734[])();
extern EIF_TYPE_INDEX Y5938[];
extern EIF_TYPE_INDEX *Y5938_gen_type [];
extern EIF_TYPE_INDEX Y1954[];
extern EIF_TYPE_INDEX *Y1954_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
