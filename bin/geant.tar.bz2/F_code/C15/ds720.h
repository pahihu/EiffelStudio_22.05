
#ifndef _C15_ds720_
#define _C15_ds720_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1136_7704(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit720(void);
extern char *(*R975[])();

#ifdef __cplusplus
}
#endif

#endif
