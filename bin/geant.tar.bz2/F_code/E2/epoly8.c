#include "epoly8.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4552[491])();
void R4552_init () {
	{long i; for (i = 0; i < 2; i++) R4552[i] = (char *(*)()) F946_5989;}
	{long i; for (i = 3; i < 5; i++) R4552[i] = (char *(*)()) F949_6157;}
	{long i; for (i = 489; i < 491; i++) R4552[i] = (char *(*)()) F949_6157;}
}

char *(*R4553[491])();
void R4553_init () {
	R4553[0] = (char *(*)()) F947_6028;
	R4553[1] = (char *(*)()) F637_3592;
	R4553[3] = (char *(*)()) F950_6193;
	R4553[4] = (char *(*)()) F641_3592;
	{long i; for (i = 489; i < 491; i++) R4553[i] = (char *(*)()) F641_3592;}
}

char *(*R4575[491])();
void R4575_init () {
	{long i; for (i = 0; i < 2; i++) R4575[i] = (char *(*)()) F946_5978;}
	{long i; for (i = 3; i < 5; i++) R4575[i] = (char *(*)()) F949_6146;}
	{long i; for (i = 489; i < 491; i++) R4575[i] = (char *(*)()) F1436_11354;}
}

char *(*R4576[491])();
void R4576_init () {
	{long i; for (i = 0; i < 2; i++) R4576[i] = (char *(*)()) F946_5977;}
	{long i; for (i = 3; i < 5; i++) R4576[i] = (char *(*)()) F949_6145;}
	{long i; for (i = 489; i < 491; i++) R4576[i] = (char *(*)()) F1436_11356;}
}

char *(*R4581[491])();
void R4581_init () {
	{long i; for (i = 0; i < 2; i++) R4581[i] = (char *(*)()) F943_5872;}
	{long i; for (i = 3; i < 5; i++) R4581[i] = (char *(*)()) F943_5872;}
	{long i; for (i = 489; i < 491; i++) R4581[i] = (char *(*)()) F1436_11367;}
}

char *(*R4586[488])();
void R4586_init () {
	{long i; for (i = 0; i < 2; i++) R4586[i] = (char *(*)()) F949_6142;}
	{long i; for (i = 486; i < 488; i++) R4586[i] = (char *(*)()) F1436_11342;}
}

char *(*R4616[491])();
void R4616_init () {
	R4616[0] = (char *(*)()) F947_6025;
	R4616[1] = (char *(*)()) F948_6119;
	R4616[3] = (char *(*)()) F950_6191;
	R4616[4] = (char *(*)()) F951_6284;
	{long i; for (i = 489; i < 491; i++) R4616[i] = (char *(*)()) F1436_11340;}
}

char *(*R4631[490])();
void R4631_init () {
	R4631[0] = (char *(*)()) F948_6121;
	R4631[3] = (char *(*)()) F951_6286;
	{long i; for (i = 488; i < 490; i++) R4631[i] = (char *(*)()) F951_6286;}
}

char *(*R4634[490])();
void R4634_init () {
	R4634[0] = (char *(*)()) F948_6060;
	R4634[3] = (char *(*)()) F951_6225;
	{long i; for (i = 488; i < 490; i++) R4634[i] = (char *(*)()) F1436_11453;}
}

char *(*R4635[490])();
void R4635_init () {
	R4635[0] = (char *(*)()) F945_5927;
	R4635[3] = (char *(*)()) F945_5927;
	{long i; for (i = 488; i < 490; i++) R4635[i] = (char *(*)()) F1436_11454;}
}

char *(*R4646[490])();
void R4646_init () {
	R4646[0] = (char *(*)()) F948_6071;
	R4646[3] = (char *(*)()) F951_6236;
	{long i; for (i = 488; i < 490; i++) R4646[i] = (char *(*)()) F1436_11376;}
}

char *(*R4654[487])();
void R4654_init () {
	R4654[0] = (char *(*)()) F951_6219;
	{long i; for (i = 485; i < 487; i++) R4654[i] = (char *(*)()) F1436_11400;}
}

char *(*R4655[487])();
void R4655_init () {
	R4655[0] = (char *(*)()) F951_6220;
	{long i; for (i = 485; i < 487; i++) R4655[i] = (char *(*)()) F1436_11401;}
}

char *(*R4659[487])();
void R4659_init () {
	R4659[0] = (char *(*)()) F951_6258;
	{long i; for (i = 485; i < 487; i++) R4659[i] = (char *(*)()) F1436_11404;}
}

char *(*R4660[487])();
void R4660_init () {
	R4660[0] = (char *(*)()) F951_6259;
	{long i; for (i = 485; i < 487; i++) R4660[i] = (char *(*)()) F1436_11402;}
}

char *(*R4662[487])();
void R4662_init () {
	R4662[0] = (char *(*)()) F951_6261;
	{long i; for (i = 485; i < 487; i++) R4662[i] = (char *(*)()) F1436_11403;}
}

char *(*R4663[490])();
void R4663_init () {
	R4663[0] = (char *(*)()) F948_6101;
	R4663[3] = (char *(*)()) F951_6266;
	{long i; for (i = 488; i < 490; i++) R4663[i] = (char *(*)()) F1436_11447;}
}

char *(*R4664[490])();
void R4664_init () {
	R4664[0] = (char *(*)()) F948_6104;
	R4664[3] = (char *(*)()) F951_6269;
	{long i; for (i = 488; i < 490; i++) R4664[i] = (char *(*)()) F951_6269;}
}

char *(*R4692[2])();
void R4692_init () {
	R4692[0] = (char *(*)()) F947_6031;
	R4692[1] = (char *(*)()) F946_6008;
}

char *(*R4750[487])();
void R4750_init () {
	R4750[0] = (char *(*)()) F951_6207;
	{long i; for (i = 485; i < 487; i++) R4750[i] = (char *(*)()) F1436_11337;}
}

char *(*R4752[488])();
void R4752_init () {
	{long i; for (i = 0; i < 2; i++) R4752[i] = (char *(*)()) F949_6137;}
	{long i; for (i = 486; i < 488; i++) R4752[i] = (char *(*)()) F1436_11348;}
}

char *(*R4754[488])();
void R4754_init () {
	{long i; for (i = 0; i < 2; i++) R4754[i] = (char *(*)()) F949_6140;}
	{long i; for (i = 486; i < 488; i++) R4754[i] = (char *(*)()) F1436_11343;}
}


#ifdef __cplusplus
}
#endif
