#include "epoly2.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R1453[1189])();
void R1453_init () {
	R1453[0] = (char *(*)()) F124_1495;
	R1453[1188] = (char *(*)()) F129_1561;
}

char *(*R1512[11])();
void R1512_init () {
	R1512[0] = (char *(*)()) F130_1562;
	R1512[1] = (char *(*)()) F131_1562_1512_1;
	R1512[2] = (char *(*)()) F132_1562_1512_1;
	R1512[3] = (char *(*)()) F133_1562_1512_1;
	R1512[4] = (char *(*)()) F130_1562;
	R1512[5] = (char *(*)()) F132_1562_1512_1;
	R1512[6] = (char *(*)()) F130_1562;
	R1512[7] = (char *(*)()) F133_1562_1512_1;
	R1512[8] = (char *(*)()) F132_1562_1512_1;
	R1512[9] = (char *(*)()) F130_1562;
	R1512[10] = (char *(*)()) F132_1562_1512_1;
}
static EIF_REFERENCE F131_1562_1512_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F131_1562(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(903, 0x00).id, 903, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F132_1562_1512_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F132_1562(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F133_1562_1512_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F133_1562(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R1514[11])();
void R1514_init () {
	R1514[0] = (char *(*)()) F130_1564;
	R1514[1] = (char *(*)()) F131_1564_1514_4;
	R1514[2] = (char *(*)()) F132_1564_1514_4;
	R1514[3] = (char *(*)()) F133_1564_1514_4;
	R1514[4] = (char *(*)()) F130_1564;
	R1514[5] = (char *(*)()) F132_1564_1514_4;
	R1514[6] = (char *(*)()) F130_1564;
	R1514[7] = (char *(*)()) F133_1564_1514_4;
	R1514[8] = (char *(*)()) F132_1564_1514_4;
	R1514[9] = (char *(*)()) F130_1564;
	R1514[10] = (char *(*)()) F132_1564_1514_4;
}
static void F131_1564_1514_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F131_1564(Current, *(EIF_BOOLEAN *)arg1);
}
static void F132_1564_1514_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F132_1564(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F133_1564_1514_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F133_1564(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R1515[11])();
void R1515_init () {
	R1515[0] = (char *(*)()) F130_1565;
	R1515[1] = (char *(*)()) F131_1565_1515_4;
	R1515[2] = (char *(*)()) F132_1565_1515_4;
	R1515[3] = (char *(*)()) F133_1565_1515_4;
	R1515[4] = (char *(*)()) F130_1565;
	R1515[5] = (char *(*)()) F132_1565_1515_4;
	R1515[6] = (char *(*)()) F130_1565;
	R1515[7] = (char *(*)()) F133_1565_1515_4;
	R1515[8] = (char *(*)()) F132_1565_1515_4;
	R1515[9] = (char *(*)()) F130_1565;
	R1515[10] = (char *(*)()) F132_1565_1515_4;
}
static void F131_1565_1515_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F131_1565(Current, *(EIF_BOOLEAN *)arg1);
}
static void F132_1565_1515_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F132_1565(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F133_1565_1515_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F133_1565(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R1518[2])();
void R1518_init () {
	R1518[0] = (char *(*)()) F134_1567;
	R1518[1] = (char *(*)()) F135_1567_1518_1;
}
static EIF_REFERENCE F135_1567_1518_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F135_1567(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R1522[5])();
void R1522_init () {
	R1522[0] = (char *(*)()) F136_1571;
	R1522[1] = (char *(*)()) F137_1571;
	R1522[2] = (char *(*)()) F138_1571;
	R1522[3] = (char *(*)()) F139_1574;
	R1522[4] = (char *(*)()) F140_1574;
}

char *(*R1523[5])();
void R1523_init () {
	R1523[0] = (char *(*)()) F136_1572;
	R1523[1] = (char *(*)()) F137_1572;
	R1523[2] = (char *(*)()) F138_1572;
	R1523[3] = (char *(*)()) F136_1572;
	R1523[4] = (char *(*)()) F138_1572;
}

char *(*R1526[2])();
void R1526_init () {
	R1526[0] = (char *(*)()) F139_1576;
	R1526[1] = (char *(*)()) F140_1576;
}

char *(*R1527[2])();
void R1527_init () {
	R1527[0] = (char *(*)()) F139_1577;
	R1527[1] = (char *(*)()) F140_1577;
}

char *(*R1528[2])();
void R1528_init () {
	R1528[0] = (char *(*)()) F139_1578;
	R1528[1] = (char *(*)()) F140_1578;
}

char *(*R1529[724])();
void R1529_init () {
	R1529[0] = (char *(*)()) F141_1579;
	R1529[1] = (char *(*)()) F142_1579_1529_3;
	R1529[723] = (char *(*)()) F987_6680;
}
static EIF_BOOLEAN F142_1579_1529_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F142_1579(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R1530[724])();
void R1530_init () {
	R1530[0] = (char *(*)()) F141_1580;
	R1530[1] = (char *(*)()) F142_1580_1530_3;
	R1530[723] = (char *(*)()) F141_1580;
}
static EIF_BOOLEAN F142_1580_1530_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F142_1580(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R1531[724])();
void R1531_init () {
	R1531[0] = (char *(*)()) F264_2467;
	R1531[1] = (char *(*)()) F265_2467_1531_3;
	R1531[723] = (char *(*)()) F987_6681;
}
static EIF_BOOLEAN F265_2467_1531_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F265_2467(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R1539[273])();
void R1539_init () {
	R1539[0] = (char *(*)()) F981_6597;
	R1539[3] = (char *(*)()) F984_6655;
	R1539[8] = (char *(*)()) F989_6701;
	R1539[261] = (char *(*)()) F1242_8508;
	{long i; for (i = 271; i < 273; i++) R1539[i] = (char *(*)()) F1251_8620;}
}

char *(*R1542[273])();
void R1542_init () {
	R1542[0] = (char *(*)()) F147_1592;
	R1542[3] = (char *(*)()) F147_1592;
	R1542[8] = (char *(*)()) F147_1592;
	R1542[261] = (char *(*)()) F119_1448;
	{long i; for (i = 271; i < 273; i++) R1542[i] = (char *(*)()) F119_1448;}
}

char *(*R1545[273])();
void R1545_init () {
	R1545[0] = (char *(*)()) F981_6602;
	R1545[3] = (char *(*)()) F984_6654;
	R1545[8] = (char *(*)()) F989_6695;
	R1545[261] = (char *(*)()) F1242_8493;
	{long i; for (i = 271; i < 273; i++) R1545[i] = (char *(*)()) F966_6449;}
}

char *(*R1547[273])();
void R1547_init () {
	R1547[0] = (char *(*)()) F981_6603;
	R1547[3] = (char *(*)()) F984_6649;
	R1547[8] = (char *(*)()) F989_6697;
	R1547[261] = (char *(*)()) F1242_8488;
	{long i; for (i = 271; i < 273; i++) R1547[i] = (char *(*)()) F1245_8563;}
}

char *(*R1548[273])();
void R1548_init () {
	R1548[0] = (char *(*)()) F981_6604_1548_1;
	R1548[3] = (char *(*)()) F984_6650_1548_1;
	R1548[8] = (char *(*)()) F989_6698_1548_1;
	R1548[261] = (char *(*)()) F1242_8489;
	R1548[271] = (char *(*)()) F1252_8637_1548_1;
	R1548[272] = (char *(*)()) F1253_8643_1548_1;
}
static EIF_REFERENCE F981_6604_1548_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F981_6604(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F984_6650_1548_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F984_6650(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F989_6698_1548_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F989_6698(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1252_8637_1548_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1252_8637(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1253_8643_1548_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1253_8643(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R1549[273])();
void R1549_init () {
	R1549[0] = (char *(*)()) F147_1599;
	R1549[3] = (char *(*)()) F147_1599;
	R1549[8] = (char *(*)()) F147_1599;
	R1549[261] = (char *(*)()) F1242_8498;
	{long i; for (i = 271; i < 273; i++) R1549[i] = (char *(*)()) F1251_8626;}
}

char *(*R1616[145])();
void R1616_init () {
	R1616[0] = (char *(*)()) F155_1710;
	R1616[1] = (char *(*)()) F154_1677;
	R1616[144] = (char *(*)()) F154_1677;
}

char *(*R1621[145])();
void R1621_init () {
	R1621[0] = (char *(*)()) F155_1712;
	R1621[1] = (char *(*)()) F154_1682;
	R1621[144] = (char *(*)()) F154_1682;
}

char *(*R1624[145])();
void R1624_init () {
	R1624[0] = (char *(*)()) F155_1713;
	R1624[1] = (char *(*)()) F154_1685;
	R1624[144] = (char *(*)()) F154_1685;
}

char *(*R1625[145])();
void R1625_init () {
	R1625[0] = (char *(*)()) F155_1717;
	R1625[1] = (char *(*)()) F157_1729;
	R1625[144] = (char *(*)()) F157_1729;
}

char *(*R1632[145])();
void R1632_init () {
	R1632[0] = (char *(*)()) F155_1718;
	R1632[1] = (char *(*)()) F157_1730;
	R1632[144] = (char *(*)()) F157_1730;
}

char *(*R1633[145])();
void R1633_init () {
	R1633[0] = (char *(*)()) F155_1719;
	R1633[1] = (char *(*)()) F157_1731;
	R1633[144] = (char *(*)()) F157_1731;
}

char *(*R1647[145])();
void R1647_init () {
	R1647[0] = (char *(*)()) F156_1728;
	R1647[1] = (char *(*)()) F157_1732;
	R1647[144] = (char *(*)()) F300_2939;
}

char *(*R1648[145])();
void R1648_init () {
	R1648[0] = (char *(*)()) F156_1727;
	R1648[1] = (char *(*)()) F157_1733;
	R1648[144] = (char *(*)()) F157_1733;
}

char *(*R1814[1263])();
void R1814_init () {
	R1814[0] = (char *(*)()) F175_1953;
	R1814[658] = (char *(*)()) F833_4536;
	R1814[692] = (char *(*)()) F867_4797_1814_2;
	R1814[693] = (char *(*)()) F868_4797_1814_2;
	R1814[695] = (char *(*)()) F870_4895_1814_2;
	R1814[696] = (char *(*)()) F871_4895_1814_2;
	R1814[698] = (char *(*)()) F873_4994_1814_2;
	R1814[699] = (char *(*)()) F874_4994_1814_2;
	R1814[701] = (char *(*)()) F876_5093_1814_2;
	R1814[702] = (char *(*)()) F877_5093_1814_2;
	R1814[704] = (char *(*)()) F879_5188_1814_2;
	R1814[705] = (char *(*)()) F880_5188_1814_2;
	R1814[707] = (char *(*)()) F882_5282_1814_2;
	R1814[708] = (char *(*)()) F883_5282_1814_2;
	R1814[710] = (char *(*)()) F885_5377_1814_2;
	R1814[711] = (char *(*)()) F886_5377_1814_2;
	R1814[713] = (char *(*)()) F888_5472_1814_2;
	R1814[714] = (char *(*)()) F889_5472_1814_2;
	R1814[716] = (char *(*)()) F891_5541_1814_2;
	R1814[717] = (char *(*)()) F892_5541_1814_2;
	R1814[719] = (char *(*)()) F894_5607_1814_2;
	R1814[720] = (char *(*)()) F895_5607_1814_2;
	{long i; for (i = 722; i < 724; i++) R1814[i] = (char *(*)()) F896_5638;}
	{long i; for (i = 725; i < 727; i++) R1814[i] = (char *(*)()) F899_5678;}
	{long i; for (i = 772; i < 774; i++) R1814[i] = (char *(*)()) F946_5986;}
	{long i; for (i = 775; i < 777; i++) R1814[i] = (char *(*)()) F949_6154;}
	R1814[939] = (char *(*)()) F1114_7528;
	{long i; for (i = 1261; i < 1263; i++) R1814[i] = (char *(*)()) F1436_11365;}
}
static EIF_BOOLEAN F867_4797_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F867_4797(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F868_4797_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F868_4797(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F870_4895_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F870_4895(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F871_4895_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F871_4895(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F873_4994_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F873_4994(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F874_4994_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F874_4994(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F876_5093_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F876_5093(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F877_5093_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F877_5093(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F879_5188_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F879_5188(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F880_5188_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F880_5188(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F882_5282_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F882_5282(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F883_5282_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F883_5282(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F885_5377_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F885_5377(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F886_5377_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F886_5377(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F888_5472_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F888_5472(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F889_5472_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F889_5472(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F891_5541_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F891_5541(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F892_5541_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F892_5541(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F894_5607_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F894_5607(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F895_5607_1814_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F895_5607(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R1899[4])();
void R1899_init () {
	R1899[0] = (char *(*)()) F178_2027;
	R1899[2] = (char *(*)()) F178_2027;
	R1899[3] = (char *(*)()) F181_2064;
}

char *(*R1915[4])();
void R1915_init () {
	R1915[0] = (char *(*)()) F178_2043;
	R1915[2] = (char *(*)()) F178_2043;
	R1915[3] = (char *(*)()) F181_2071;
}

char *(*R1920[4])();
void R1920_init () {
	R1920[0] = (char *(*)()) F178_2048;
	R1920[2] = (char *(*)()) F180_2060;
	R1920[3] = (char *(*)()) F178_2048;
}

char *(*R1952[1165])();
void R1952_init () {
	R1952[0] = (char *(*)()) F190_2103;
	R1952[804] = (char *(*)()) F994_6717;
	R1952[1043] = (char *(*)()) F1223_8395;
	R1952[1044] = (char *(*)()) F1224_8395_1952_5;
	R1952[1045] = (char *(*)()) F1225_8395_1952_5;
	R1952[1046] = (char *(*)()) F1226_8395_1952_5;
	R1952[1047] = (char *(*)()) F1227_8395_1952_5;
	{long i; for (i = 1048; i < 1050; i++) R1952[i] = (char *(*)()) F1223_8395;}
	R1952[1161] = (char *(*)()) F1351_10234;
	R1952[1164] = (char *(*)()) F1223_8395;
}
static EIF_REFERENCE F1224_8395_1952_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1224_8395(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F1225_8395_1952_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1225_8395(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(903, 0x00).id, 903, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1226_8395_1952_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1226_8395(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(879, 0x00).id, 879, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1227_8395_1952_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1227_8395(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y1954_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype5[] = {0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype6[] = {0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype7[] = {0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype8[] = {0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype32[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype33[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype34[] = {0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype35[] = {0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype36[] = {0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y1954_pgtype37[] = {0xFF01,950,0xFFFF};
EIF_TYPE_INDEX *Y1954_gen_type [1171];
EIF_TYPE_INDEX Y1954 [1171];
void Y1954_init (void)
{
	egc_routines_types [1954] = Y1954;
	egc_routines_gen_types [1954] = Y1954_gen_type;
	egc_routines_offset [1954] = 183;
	Y1954_gen_type [0] = Y1954_pgtype0;
	Y1954_gen_type [1] = Y1954_pgtype1;
	Y1954_gen_type [2] = Y1954_pgtype2;
	Y1954_gen_type [3] = Y1954_pgtype3;
	Y1954_gen_type [4] = Y1954_pgtype4;
	Y1954_gen_type [5] = Y1954_pgtype5;
	Y1954_gen_type [6] = Y1954_pgtype6;
	Y1954_gen_type [809] = Y1954_pgtype7;
	Y1954_gen_type [810] = Y1954_pgtype8;
	Y1954_gen_type [947] = Y1954_pgtype9;
	Y1954_gen_type [948] = Y1954_pgtype10;
	Y1954_gen_type [949] = Y1954_pgtype11;
	Y1954_gen_type [950] = Y1954_pgtype12;
	Y1954_gen_type [951] = Y1954_pgtype13;
	Y1954_gen_type [984] = Y1954_pgtype14;
	Y1954_gen_type [985] = Y1954_pgtype15;
	Y1954_gen_type [986] = Y1954_pgtype16;
	Y1954_gen_type [987] = Y1954_pgtype17;
	Y1954_gen_type [988] = Y1954_pgtype18;
	Y1954_gen_type [1039] = Y1954_pgtype19;
	Y1954_gen_type [1040] = Y1954_pgtype20;
	Y1954_gen_type [1041] = Y1954_pgtype21;
	Y1954_gen_type [1042] = Y1954_pgtype22;
	Y1954_gen_type [1043] = Y1954_pgtype23;
	Y1954_gen_type [1044] = Y1954_pgtype24;
	Y1954_gen_type [1045] = Y1954_pgtype25;
	Y1954_gen_type [1046] = Y1954_pgtype26;
	Y1954_gen_type [1047] = Y1954_pgtype27;
	Y1954_gen_type [1048] = Y1954_pgtype28;
	Y1954_gen_type [1049] = Y1954_pgtype29;
	Y1954_gen_type [1050] = Y1954_pgtype30;
	Y1954_gen_type [1051] = Y1954_pgtype31;
	Y1954_gen_type [1052] = Y1954_pgtype32;
	Y1954_gen_type [1053] = Y1954_pgtype33;
	Y1954_gen_type [1054] = Y1954_pgtype34;
	Y1954_gen_type [1055] = Y1954_pgtype35;
	Y1954_gen_type [1167] = Y1954_pgtype36;
	Y1954_gen_type [1170] = Y1954_pgtype37;
	{long i; for (i = 5; i < 7; i++) Y1954[i] = 950;};
	{long i; for (i = 809; i < 811; i++) Y1954[i] = 950;};
	{long i; for (i = 1054; i < 1056; i++) Y1954[i] = 950;};
	Y1954[1167] = 950;
	Y1954[1170] = 950;
}

char *(*R1955[1162])();
void R1955_init () {
	R1955[0] = (char *(*)()) F190_2105;
	R1955[1161] = (char *(*)()) F1351_10237;
}


#ifdef __cplusplus
}
#endif
