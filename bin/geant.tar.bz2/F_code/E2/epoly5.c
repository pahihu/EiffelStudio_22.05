#include "epoly5.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R1975[1118])();
void R1975_init () {
	R1975[0] = (char *(*)()) F195_2142;
	R1975[3] = (char *(*)()) F196_2155;
	R1975[4] = (char *(*)()) F199_2189;
	R1975[784] = (char *(*)()) F979_6566;
	R1975[1117] = (char *(*)()) F196_2155;
}

char *(*R1976[1118])();
void R1976_init () {
	R1976[0] = (char *(*)()) F195_2143;
	R1976[3] = (char *(*)()) F198_2171;
	R1976[4] = (char *(*)()) F199_2190;
	R1976[784] = (char *(*)()) F979_6567;
	R1976[1117] = (char *(*)()) F196_2156;
}

char *(*R1977[1118])();
void R1977_init () {
	R1977[0] = (char *(*)()) F195_2144;
	R1977[3] = (char *(*)()) F198_2170;
	R1977[4] = (char *(*)()) F199_2191;
	R1977[784] = (char *(*)()) F196_2157;
	R1977[1117] = (char *(*)()) F196_2157;
}

char *(*R2048[40])();
void R2048_init () {
	R2048[0] = (char *(*)()) F211_2243;
	R2048[1] = (char *(*)()) F212_2267;
	R2048[5] = (char *(*)()) F216_2270;
	R2048[7] = (char *(*)()) F218_2272;
	R2048[8] = (char *(*)()) F219_2278;
	R2048[9] = (char *(*)()) F220_2295;
	R2048[11] = (char *(*)()) F222_2299;
	R2048[12] = (char *(*)()) F223_2303;
	R2048[15] = (char *(*)()) F226_2305;
	R2048[16] = (char *(*)()) F227_2307;
	R2048[18] = (char *(*)()) F229_2311;
	R2048[19] = (char *(*)()) F230_2313;
	R2048[20] = (char *(*)()) F231_2319;
	R2048[22] = (char *(*)()) F233_2321;
	R2048[23] = (char *(*)()) F234_2325;
	R2048[24] = (char *(*)()) F235_2329;
	R2048[25] = (char *(*)()) F236_2331;
	R2048[27] = (char *(*)()) F238_2333;
	R2048[28] = (char *(*)()) F239_2335;
	R2048[30] = (char *(*)()) F241_2337;
	R2048[31] = (char *(*)()) F242_2339;
	R2048[32] = (char *(*)()) F243_2341;
	R2048[34] = (char *(*)()) F245_2343;
	R2048[35] = (char *(*)()) F246_2345;
	R2048[36] = (char *(*)()) F247_2347;
	R2048[37] = (char *(*)()) F248_2349;
	R2048[38] = (char *(*)()) F249_2353;
	R2048[39] = (char *(*)()) F250_2355;
}

char *(*R2207[736])();
void R2207_init () {
	R2207[0] = (char *(*)()) F255_2460;
	R2207[1] = (char *(*)()) F256_2460_2207_3;
	R2207[2] = (char *(*)()) F257_2460_2207_3;
	R2207[3] = (char *(*)()) F258_2460_2207_3;
	R2207[4] = (char *(*)()) F259_2460_2207_3;
	R2207[5] = (char *(*)()) F260_2460_2207_3;
	R2207[6] = (char *(*)()) F261_2461;
	R2207[9] = (char *(*)()) F262_2465;
	R2207[10] = (char *(*)()) F263_2465_2207_3;
	R2207[732] = (char *(*)()) F262_2465;
	R2207[735] = (char *(*)()) F990_6708;
}
static EIF_BOOLEAN F256_2460_2207_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F256_2460(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F257_2460_2207_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F257_2460(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_CHARACTER_8 *)arg2);
}
static EIF_BOOLEAN F258_2460_2207_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F258_2460(Current, *(EIF_BOOLEAN *)arg1, *(EIF_BOOLEAN *)arg2);
}
static EIF_BOOLEAN F259_2460_2207_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F259_2460(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static EIF_BOOLEAN F260_2460_2207_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F260_2460(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_NATURAL_64 *)arg2);
}
static EIF_BOOLEAN F263_2465_2207_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F263_2465(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R2209[724])();
void R2209_init () {
	R2209[0] = (char *(*)()) F262_2462;
	R2209[1] = (char *(*)()) F263_2462_2209_3;
	R2209[723] = (char *(*)()) F262_2462;
}
static EIF_BOOLEAN F263_2462_2209_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F263_2462(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R2476[1142])();
void R2476_init () {
	R2476[0] = (char *(*)()) F286_2751;
	R2476[442] = (char *(*)()) F280_2751;
	R2476[443] = (char *(*)()) F281_2751;
	R2476[444] = (char *(*)()) F282_2751;
	R2476[445] = (char *(*)()) F283_2751;
	R2476[446] = (char *(*)()) F284_2751;
	R2476[447] = (char *(*)()) F285_2751;
	R2476[448] = (char *(*)()) F286_2751;
	R2476[449] = (char *(*)()) F287_2751;
	R2476[450] = (char *(*)()) F288_2751;
	R2476[451] = (char *(*)()) F289_2751;
	R2476[452] = (char *(*)()) F290_2751;
	R2476[453] = (char *(*)()) F291_2751;
	R2476[454] = (char *(*)()) F280_2751;
	R2476[455] = (char *(*)()) F282_2751;
	R2476[456] = (char *(*)()) F284_2751;
	R2476[457] = (char *(*)()) F289_2751;
	R2476[458] = (char *(*)()) F283_2751;
	R2476[459] = (char *(*)()) F288_2751;
	R2476[514] = (char *(*)()) F280_2751;
	R2476[515] = (char *(*)()) F281_2751;
	R2476[516] = (char *(*)()) F282_2751;
	R2476[517] = (char *(*)()) F283_2751;
	R2476[518] = (char *(*)()) F284_2751;
	R2476[519] = (char *(*)()) F285_2751;
	R2476[520] = (char *(*)()) F286_2751;
	R2476[521] = (char *(*)()) F287_2751;
	R2476[522] = (char *(*)()) F288_2751;
	R2476[523] = (char *(*)()) F289_2751;
	R2476[524] = (char *(*)()) F290_2751;
	R2476[525] = (char *(*)()) F291_2751;
	R2476[652] = (char *(*)()) F285_2751;
	R2476[655] = (char *(*)()) F284_2751;
	{long i; for (i = 1140; i < 1142; i++) R2476[i] = (char *(*)()) F284_2751;}
}

char *(*R2477[1142])();
void R2477_init () {
	R2477[0] = (char *(*)()) F286_2752_2477_131;
	R2477[442] = (char *(*)()) F280_2752;
	R2477[443] = (char *(*)()) F281_2752_2477_131;
	R2477[444] = (char *(*)()) F282_2752_2477_131;
	R2477[445] = (char *(*)()) F283_2752_2477_131;
	R2477[446] = (char *(*)()) F284_2752_2477_131;
	R2477[447] = (char *(*)()) F285_2752_2477_131;
	R2477[448] = (char *(*)()) F286_2752_2477_131;
	R2477[449] = (char *(*)()) F287_2752_2477_131;
	R2477[450] = (char *(*)()) F288_2752_2477_131;
	R2477[451] = (char *(*)()) F289_2752_2477_131;
	R2477[452] = (char *(*)()) F290_2752_2477_131;
	R2477[453] = (char *(*)()) F291_2752_2477_131;
	R2477[454] = (char *(*)()) F280_2752;
	R2477[455] = (char *(*)()) F282_2752_2477_131;
	R2477[456] = (char *(*)()) F284_2752_2477_131;
	R2477[457] = (char *(*)()) F289_2752_2477_131;
	R2477[458] = (char *(*)()) F283_2752_2477_131;
	R2477[459] = (char *(*)()) F288_2752_2477_131;
	R2477[514] = (char *(*)()) F280_2752;
	R2477[515] = (char *(*)()) F281_2752_2477_131;
	R2477[516] = (char *(*)()) F282_2752_2477_131;
	R2477[517] = (char *(*)()) F283_2752_2477_131;
	R2477[518] = (char *(*)()) F284_2752_2477_131;
	R2477[519] = (char *(*)()) F285_2752_2477_131;
	R2477[520] = (char *(*)()) F286_2752_2477_131;
	R2477[521] = (char *(*)()) F287_2752_2477_131;
	R2477[522] = (char *(*)()) F288_2752_2477_131;
	R2477[523] = (char *(*)()) F289_2752_2477_131;
	R2477[524] = (char *(*)()) F290_2752_2477_131;
	R2477[525] = (char *(*)()) F291_2752_2477_131;
	R2477[652] = (char *(*)()) F285_2752_2477_131;
	R2477[655] = (char *(*)()) F284_2752_2477_131;
	{long i; for (i = 1140; i < 1142; i++) R2477[i] = (char *(*)()) F284_2752_2477_131;}
}
static void F286_2752_2477_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F286_2752(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F281_2752_2477_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F281_2752(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F282_2752_2477_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F282_2752(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F283_2752_2477_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F283_2752(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F284_2752_2477_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F284_2752(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F285_2752_2477_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F285_2752(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F287_2752_2477_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F287_2752(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F288_2752_2477_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F288_2752(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F289_2752_2477_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F289_2752(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F290_2752_2477_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F290_2752(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F291_2752_2477_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F291_2752(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R2483[1142])();
void R2483_init () {
	R2483[0] = (char *(*)()) F286_2758;
	R2483[442] = (char *(*)()) F280_2758;
	R2483[443] = (char *(*)()) F281_2758;
	R2483[444] = (char *(*)()) F282_2758;
	R2483[445] = (char *(*)()) F283_2758;
	R2483[446] = (char *(*)()) F284_2758;
	R2483[447] = (char *(*)()) F285_2758;
	R2483[448] = (char *(*)()) F286_2758;
	R2483[449] = (char *(*)()) F287_2758;
	R2483[450] = (char *(*)()) F288_2758;
	R2483[451] = (char *(*)()) F289_2758;
	R2483[452] = (char *(*)()) F290_2758;
	R2483[453] = (char *(*)()) F291_2758;
	R2483[454] = (char *(*)()) F280_2758;
	R2483[455] = (char *(*)()) F282_2758;
	R2483[456] = (char *(*)()) F284_2758;
	R2483[457] = (char *(*)()) F289_2758;
	R2483[458] = (char *(*)()) F283_2758;
	R2483[459] = (char *(*)()) F288_2758;
	R2483[514] = (char *(*)()) F280_2758;
	R2483[515] = (char *(*)()) F281_2758;
	R2483[516] = (char *(*)()) F282_2758;
	R2483[517] = (char *(*)()) F283_2758;
	R2483[518] = (char *(*)()) F284_2758;
	R2483[519] = (char *(*)()) F285_2758;
	R2483[520] = (char *(*)()) F286_2758;
	R2483[521] = (char *(*)()) F287_2758;
	R2483[522] = (char *(*)()) F288_2758;
	R2483[523] = (char *(*)()) F289_2758;
	R2483[524] = (char *(*)()) F290_2758;
	R2483[525] = (char *(*)()) F291_2758;
	R2483[652] = (char *(*)()) F285_2758;
	R2483[655] = (char *(*)()) F284_2758;
	{long i; for (i = 1140; i < 1142; i++) R2483[i] = (char *(*)()) F284_2758;}
}

static EIF_TYPE_INDEX Y2484_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype12[] = {888,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype13[] = {888,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype44[] = {897,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype45[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype46[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype47[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2484_pgtype48[] = {900,0xFFFF};
EIF_TYPE_INDEX *Y2484_gen_type [1158];
EIF_TYPE_INDEX Y2484 [1158];
void Y2484_init (void)
{
	egc_routines_types [2484] = Y2484;
	egc_routines_gen_types [2484] = Y2484_gen_type;
	egc_routines_offset [2484] = 279;
	Y2484_gen_type [0] = Y2484_pgtype0;
	Y2484_gen_type [1] = Y2484_pgtype1;
	Y2484_gen_type [2] = Y2484_pgtype2;
	Y2484_gen_type [3] = Y2484_pgtype3;
	Y2484_gen_type [4] = Y2484_pgtype4;
	Y2484_gen_type [5] = Y2484_pgtype5;
	Y2484_gen_type [6] = Y2484_pgtype6;
	Y2484_gen_type [7] = Y2484_pgtype7;
	Y2484_gen_type [8] = Y2484_pgtype8;
	Y2484_gen_type [9] = Y2484_pgtype9;
	Y2484_gen_type [10] = Y2484_pgtype10;
	Y2484_gen_type [11] = Y2484_pgtype11;
	Y2484_gen_type [16] = Y2484_pgtype12;
	Y2484_gen_type [17] = Y2484_pgtype13;
	Y2484_gen_type [458] = Y2484_pgtype14;
	Y2484_gen_type [459] = Y2484_pgtype15;
	Y2484_gen_type [460] = Y2484_pgtype16;
	Y2484_gen_type [461] = Y2484_pgtype17;
	Y2484_gen_type [462] = Y2484_pgtype18;
	Y2484_gen_type [463] = Y2484_pgtype19;
	Y2484_gen_type [464] = Y2484_pgtype20;
	Y2484_gen_type [465] = Y2484_pgtype21;
	Y2484_gen_type [466] = Y2484_pgtype22;
	Y2484_gen_type [467] = Y2484_pgtype23;
	Y2484_gen_type [468] = Y2484_pgtype24;
	Y2484_gen_type [469] = Y2484_pgtype25;
	Y2484_gen_type [470] = Y2484_pgtype26;
	Y2484_gen_type [471] = Y2484_pgtype27;
	Y2484_gen_type [472] = Y2484_pgtype28;
	Y2484_gen_type [473] = Y2484_pgtype29;
	Y2484_gen_type [474] = Y2484_pgtype30;
	Y2484_gen_type [475] = Y2484_pgtype31;
	Y2484_gen_type [530] = Y2484_pgtype32;
	Y2484_gen_type [531] = Y2484_pgtype33;
	Y2484_gen_type [532] = Y2484_pgtype34;
	Y2484_gen_type [533] = Y2484_pgtype35;
	Y2484_gen_type [534] = Y2484_pgtype36;
	Y2484_gen_type [535] = Y2484_pgtype37;
	Y2484_gen_type [536] = Y2484_pgtype38;
	Y2484_gen_type [537] = Y2484_pgtype39;
	Y2484_gen_type [538] = Y2484_pgtype40;
	Y2484_gen_type [539] = Y2484_pgtype41;
	Y2484_gen_type [540] = Y2484_pgtype42;
	Y2484_gen_type [541] = Y2484_pgtype43;
	Y2484_gen_type [668] = Y2484_pgtype44;
	Y2484_gen_type [671] = Y2484_pgtype45;
	Y2484_gen_type [672] = Y2484_pgtype46;
	Y2484_gen_type [1156] = Y2484_pgtype47;
	Y2484_gen_type [1157] = Y2484_pgtype48;
	{long i; for (i = 16; i < 18; i++) Y2484[i] = 888;};
	Y2484[668] = 897;
	{long i; for (i = 671; i < 673; i++) Y2484[i] = 900;};
	{long i; for (i = 1156; i < 1158; i++) Y2484[i] = 900;};
}

char *(*R2746[555])();
void R2746_init () {
	R2746[0] = (char *(*)()) F698_3653;
	R2746[313] = (char *(*)()) F1012_6809;
	{long i; for (i = 548; i < 550; i++) R2746[i] = (char *(*)()) F698_3653;}
	{long i; for (i = 553; i < 555; i++) R2746[i] = (char *(*)()) F698_3653;}
}

char *(*R2759[555])();
void R2759_init () {
	R2759[0] = (char *(*)()) F698_3727;
	R2759[313] = (char *(*)()) F1012_6832;
	{long i; for (i = 548; i < 550; i++) R2759[i] = (char *(*)()) F698_3727;}
	{long i; for (i = 553; i < 555; i++) R2759[i] = (char *(*)()) F698_3727;}
}


#ifdef __cplusplus
}
#endif
