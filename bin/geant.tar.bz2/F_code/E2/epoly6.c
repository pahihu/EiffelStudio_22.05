#include "epoly6.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2761[555])();
void R2761_init () {
	R2761[0] = (char *(*)()) F698_3730;
	R2761[313] = (char *(*)()) F1012_6830;
	{long i; for (i = 548; i < 550; i++) R2761[i] = (char *(*)()) F698_3730;}
	{long i; for (i = 553; i < 555; i++) R2761[i] = (char *(*)()) F698_3730;}
}

char *(*R2789[555])();
void R2789_init () {
	R2789[0] = (char *(*)()) F698_3760;
	R2789[313] = (char *(*)()) F1012_6827;
	{long i; for (i = 548; i < 550; i++) R2789[i] = (char *(*)()) F698_3760;}
	{long i; for (i = 553; i < 555; i++) R2789[i] = (char *(*)()) F698_3760;}
}

char *(*R2802[555])();
void R2802_init () {
	R2802[0] = (char *(*)()) F698_3767;
	R2802[313] = (char *(*)()) F1012_6821;
	{long i; for (i = 548; i < 550; i++) R2802[i] = (char *(*)()) F698_3767;}
	{long i; for (i = 553; i < 555; i++) R2802[i] = (char *(*)()) F698_3767;}
}

char *(*R2870[12])();
void R2870_init () {
	R2870[0] = (char *(*)()) F713_3982;
	R2870[1] = (char *(*)()) F714_3982;
	R2870[2] = (char *(*)()) F715_3982;
	R2870[3] = (char *(*)()) F716_3982;
	R2870[4] = (char *(*)()) F717_3982;
	R2870[5] = (char *(*)()) F718_3982;
	R2870[6] = (char *(*)()) F719_3982;
	R2870[7] = (char *(*)()) F720_3982;
	R2870[8] = (char *(*)()) F721_3982;
	R2870[9] = (char *(*)()) F722_3982;
	R2870[10] = (char *(*)()) F723_3982;
	R2870[11] = (char *(*)()) F724_3982;
}

char *(*R2871[12])();
void R2871_init () {
	R2871[0] = (char *(*)()) F713_3983;
	R2871[1] = (char *(*)()) F714_3983;
	R2871[2] = (char *(*)()) F715_3983;
	R2871[3] = (char *(*)()) F716_3983;
	R2871[4] = (char *(*)()) F717_3983;
	R2871[5] = (char *(*)()) F718_3983;
	R2871[6] = (char *(*)()) F719_3983;
	R2871[7] = (char *(*)()) F720_3983;
	R2871[8] = (char *(*)()) F721_3983;
	R2871[9] = (char *(*)()) F722_3983;
	R2871[10] = (char *(*)()) F723_3983;
	R2871[11] = (char *(*)()) F724_3983;
}

char *(*R2920[673])();
void R2920_init () {
	R2920[0] = (char *(*)()) F438_3435;
	R2920[1] = (char *(*)()) F439_3435_2920_1;
	R2920[2] = (char *(*)()) F440_3435;
	R2920[3] = (char *(*)()) F441_3435_2920_1;
	R2920[4] = (char *(*)()) F442_3435_2920_1;
	R2920[648] = (char *(*)()) F1039_7375;
	R2920[649] = (char *(*)()) F1040_7375_2920_1;
	{long i; for (i = 660; i < 662; i++) R2920[i] = (char *(*)()) F1039_7375;}
	R2920[662] = (char *(*)()) F1042_7375_2920_1;
	R2920[663] = (char *(*)()) F1043_7375_2920_1;
	R2920[664] = (char *(*)()) F1040_7375_2920_1;
	R2920[668] = (char *(*)()) F1039_7375;
	R2920[669] = (char *(*)()) F1040_7375_2920_1;
	R2920[670] = (char *(*)()) F1108_7483;
	R2920[671] = (char *(*)()) F1109_7483_2920_1;
	R2920[672] = (char *(*)()) F1108_7483;
}
static EIF_REFERENCE F439_3435_2920_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F439_3435(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F441_3435_2920_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F441_3435(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F442_3435_2920_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F442_3435(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1040_7375_2920_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1040_7375(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1042_7375_2920_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1042_7375(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(903, 0x00).id, 903, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1043_7375_2920_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1043_7375(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(879, 0x00).id, 879, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1109_7483_2920_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1109_7483(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R2921[673])();
void R2921_init () {
	R2921[0] = (char *(*)()) F438_3438;
	R2921[1] = (char *(*)()) F439_3438;
	R2921[2] = (char *(*)()) F440_3438;
	R2921[3] = (char *(*)()) F441_3438;
	R2921[4] = (char *(*)()) F442_3438;
	R2921[197] = (char *(*)()) F634_3564;
	R2921[648] = (char *(*)()) F1077_7423;
	R2921[649] = (char *(*)()) F1079_7423;
	R2921[660] = (char *(*)()) F1077_7423;
	R2921[661] = (char *(*)()) F1078_7423;
	R2921[662] = (char *(*)()) F1080_7423;
	R2921[663] = (char *(*)()) F1081_7423;
	R2921[664] = (char *(*)()) F1079_7423;
	R2921[668] = (char *(*)()) F1106_7470;
	R2921[669] = (char *(*)()) F1107_7470;
	R2921[670] = (char *(*)()) F1108_7485;
	R2921[671] = (char *(*)()) F1109_7485;
	R2921[672] = (char *(*)()) F1108_7485;
}

char *(*R2922[673])();
void R2922_init () {
	R2922[0] = (char *(*)()) F438_3439;
	R2922[1] = (char *(*)()) F439_3439;
	R2922[2] = (char *(*)()) F440_3439;
	R2922[3] = (char *(*)()) F441_3439;
	R2922[4] = (char *(*)()) F442_3439;
	R2922[197] = (char *(*)()) F634_3570;
	R2922[648] = (char *(*)()) F1053_7396;
	R2922[649] = (char *(*)()) F1054_7396;
	{long i; for (i = 660; i < 662; i++) R2922[i] = (char *(*)()) F1053_7396;}
	R2922[662] = (char *(*)()) F1056_7396;
	R2922[663] = (char *(*)()) F1058_7396;
	R2922[664] = (char *(*)()) F1054_7396;
	R2922[668] = (char *(*)()) F1053_7396;
	R2922[669] = (char *(*)()) F1054_7396;
	R2922[670] = (char *(*)()) F1053_7396;
	R2922[671] = (char *(*)()) F1055_7396;
	R2922[672] = (char *(*)()) F1053_7396;
}

char *(*R2933[5])();
void R2933_init () {
	R2933[0] = (char *(*)()) F438_3436;
	R2933[1] = (char *(*)()) F439_3436;
	R2933[2] = (char *(*)()) F440_3436_2933_1;
	R2933[3] = (char *(*)()) F441_3436;
	R2933[4] = (char *(*)()) F442_3436_2933_1;
}
static EIF_REFERENCE F440_3436_2933_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F440_3436(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F442_3436_2933_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F442_3436(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R2981[533])();
void R2981_init () {
	R2981[0] = (char *(*)()) F822_4350;
	R2981[1] = (char *(*)()) F823_4350;
	R2981[2] = (char *(*)()) F824_4350;
	R2981[3] = (char *(*)()) F825_4350;
	R2981[4] = (char *(*)()) F826_4350;
	R2981[7] = (char *(*)()) F822_4350;
	R2981[363] = (char *(*)()) F1151_7729;
	R2981[364] = (char *(*)()) F1153_7729;
	{long i; for (i = 365; i < 368; i++) R2981[i] = (char *(*)()) F1151_7729;}
	R2981[387] = (char *(*)()) F1151_7729;
	R2981[388] = (char *(*)()) F1152_7729;
	R2981[389] = (char *(*)()) F1151_7729;
	R2981[399] = (char *(*)()) F1151_7729;
	R2981[400] = (char *(*)()) F1152_7729;
	{long i; for (i = 411; i < 413; i++) R2981[i] = (char *(*)()) F1151_7729;}
	R2981[413] = (char *(*)()) F1154_7729;
	R2981[414] = (char *(*)()) F1156_7729;
	R2981[415] = (char *(*)()) F1152_7729;
	{long i; for (i = 416; i < 418; i++) R2981[i] = (char *(*)()) F1151_7729;}
	R2981[532] = (char *(*)()) F1151_7729;
}

static EIF_TYPE_INDEX Y2982_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype12[] = {0xFF01,946,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype13[] = {897,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype14[] = {0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype15[] = {0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype88[] = {897,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype89[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype256[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype260[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype261[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype264[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype265[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype274[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype275[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype319[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype320[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype321[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype332[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype333[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype334[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype339[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype340[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype343[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype358[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype362[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype363[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype364[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype365[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype366[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype367[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype368[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype369[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype370[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype371[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype372[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype373[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype374[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype375[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype376[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype377[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype378[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype379[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype380[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype381[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype382[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype383[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype384[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype385[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype386[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype387[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype438[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype446[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype447[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype448[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype449[] = {897,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype450[] = {897,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype451[] = {897,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype452[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype453[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype454[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype455[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype456[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype457[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype458[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype459[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype460[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype461[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype462[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype463[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype464[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype465[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype466[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype467[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype468[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype469[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype470[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype471[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype472[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype473[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype474[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype475[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype476[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype477[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype478[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype479[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype480[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype481[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype482[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype483[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype484[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype485[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype486[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype487[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype488[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype489[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype490[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype491[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype492[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype493[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype494[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype495[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype496[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype497[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype498[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype499[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype500[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype501[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype502[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype503[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype504[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype505[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype506[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype507[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype508[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype509[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype510[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype511[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype512[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype513[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype514[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype515[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype516[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype517[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype518[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype519[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype520[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype521[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype522[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype523[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype524[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype525[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype526[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype527[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype528[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype529[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype530[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype531[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype532[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype533[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype534[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype535[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype536[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype537[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype538[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype539[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype540[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype541[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype542[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype543[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype544[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype545[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype546[] = {0xFF01,153,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype547[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype548[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype549[] = {0xFF01,4,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype550[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype551[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype552[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype553[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype554[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype555[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype556[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype557[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype558[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype559[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype560[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype561[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype562[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype563[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype564[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype565[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype566[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype567[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype568[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype569[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype570[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype571[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype572[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype573[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype574[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype575[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype576[] = {0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype577[] = {0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype578[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype579[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype580[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype581[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype582[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype583[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype584[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype585[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype586[] = {0xFF01,1276,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype587[] = {0xFF01,1276,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype588[] = {0xFF01,1276,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype589[] = {0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype590[] = {900,0xFFFF};
static EIF_TYPE_INDEX Y2982_pgtype591[] = {900,0xFFFF};
EIF_TYPE_INDEX *Y2982_gen_type [1059];
EIF_TYPE_INDEX Y2982 [1059];
void Y2982_init (void)
{
	egc_routines_types [2982] = Y2982;
	egc_routines_gen_types [2982] = Y2982_gen_type;
	egc_routines_offset [2982] = 378;
	Y2982_gen_type [0] = Y2982_pgtype0;
	Y2982_gen_type [1] = Y2982_pgtype1;
	Y2982_gen_type [2] = Y2982_pgtype2;
	Y2982_gen_type [3] = Y2982_pgtype3;
	Y2982_gen_type [4] = Y2982_pgtype4;
	Y2982_gen_type [5] = Y2982_pgtype5;
	Y2982_gen_type [6] = Y2982_pgtype6;
	Y2982_gen_type [7] = Y2982_pgtype7;
	Y2982_gen_type [8] = Y2982_pgtype8;
	Y2982_gen_type [9] = Y2982_pgtype9;
	Y2982_gen_type [10] = Y2982_pgtype10;
	Y2982_gen_type [11] = Y2982_pgtype11;
	Y2982_gen_type [12] = Y2982_pgtype12;
	Y2982_gen_type [13] = Y2982_pgtype13;
	Y2982_gen_type [14] = Y2982_pgtype14;
	Y2982_gen_type [15] = Y2982_pgtype15;
	Y2982_gen_type [16] = Y2982_pgtype16;
	Y2982_gen_type [17] = Y2982_pgtype17;
	Y2982_gen_type [18] = Y2982_pgtype18;
	Y2982_gen_type [19] = Y2982_pgtype19;
	Y2982_gen_type [20] = Y2982_pgtype20;
	Y2982_gen_type [21] = Y2982_pgtype21;
	Y2982_gen_type [22] = Y2982_pgtype22;
	Y2982_gen_type [23] = Y2982_pgtype23;
	Y2982_gen_type [24] = Y2982_pgtype24;
	Y2982_gen_type [25] = Y2982_pgtype25;
	Y2982_gen_type [26] = Y2982_pgtype26;
	Y2982_gen_type [27] = Y2982_pgtype27;
	Y2982_gen_type [28] = Y2982_pgtype28;
	Y2982_gen_type [29] = Y2982_pgtype29;
	Y2982_gen_type [30] = Y2982_pgtype30;
	Y2982_gen_type [31] = Y2982_pgtype31;
	Y2982_gen_type [32] = Y2982_pgtype32;
	Y2982_gen_type [33] = Y2982_pgtype33;
	Y2982_gen_type [34] = Y2982_pgtype34;
	Y2982_gen_type [35] = Y2982_pgtype35;
	Y2982_gen_type [36] = Y2982_pgtype36;
	Y2982_gen_type [37] = Y2982_pgtype37;
	Y2982_gen_type [38] = Y2982_pgtype38;
	Y2982_gen_type [39] = Y2982_pgtype39;
	Y2982_gen_type [40] = Y2982_pgtype40;
	Y2982_gen_type [41] = Y2982_pgtype41;
	Y2982_gen_type [42] = Y2982_pgtype42;
	Y2982_gen_type [43] = Y2982_pgtype43;
	Y2982_gen_type [44] = Y2982_pgtype44;
	Y2982_gen_type [45] = Y2982_pgtype45;
	Y2982_gen_type [46] = Y2982_pgtype46;
	Y2982_gen_type [47] = Y2982_pgtype47;
	Y2982_gen_type [48] = Y2982_pgtype48;
	Y2982_gen_type [49] = Y2982_pgtype49;
	Y2982_gen_type [50] = Y2982_pgtype50;
	Y2982_gen_type [51] = Y2982_pgtype51;
	Y2982_gen_type [52] = Y2982_pgtype52;
	Y2982_gen_type [53] = Y2982_pgtype53;
	Y2982_gen_type [54] = Y2982_pgtype54;
	Y2982_gen_type [55] = Y2982_pgtype55;
	Y2982_gen_type [56] = Y2982_pgtype56;
	Y2982_gen_type [57] = Y2982_pgtype57;
	Y2982_gen_type [58] = Y2982_pgtype58;
	Y2982_gen_type [59] = Y2982_pgtype59;
	Y2982_gen_type [60] = Y2982_pgtype60;
	Y2982_gen_type [61] = Y2982_pgtype61;
	Y2982_gen_type [62] = Y2982_pgtype62;
	Y2982_gen_type [63] = Y2982_pgtype63;
	Y2982_gen_type [64] = Y2982_pgtype64;
	Y2982_gen_type [65] = Y2982_pgtype65;
	Y2982_gen_type [66] = Y2982_pgtype66;
	Y2982_gen_type [67] = Y2982_pgtype67;
	Y2982_gen_type [68] = Y2982_pgtype68;
	Y2982_gen_type [69] = Y2982_pgtype69;
	Y2982_gen_type [70] = Y2982_pgtype70;
	Y2982_gen_type [71] = Y2982_pgtype71;
	Y2982_gen_type [72] = Y2982_pgtype72;
	Y2982_gen_type [73] = Y2982_pgtype73;
	Y2982_gen_type [74] = Y2982_pgtype74;
	Y2982_gen_type [75] = Y2982_pgtype75;
	Y2982_gen_type [76] = Y2982_pgtype76;
	Y2982_gen_type [77] = Y2982_pgtype77;
	Y2982_gen_type [78] = Y2982_pgtype78;
	Y2982_gen_type [79] = Y2982_pgtype79;
	Y2982_gen_type [80] = Y2982_pgtype80;
	Y2982_gen_type [81] = Y2982_pgtype81;
	Y2982_gen_type [82] = Y2982_pgtype82;
	Y2982_gen_type [83] = Y2982_pgtype83;
	Y2982_gen_type [84] = Y2982_pgtype84;
	Y2982_gen_type [85] = Y2982_pgtype85;
	Y2982_gen_type [86] = Y2982_pgtype86;
	Y2982_gen_type [87] = Y2982_pgtype87;
	Y2982_gen_type [88] = Y2982_pgtype88;
	Y2982_gen_type [89] = Y2982_pgtype89;
	Y2982_gen_type [90] = Y2982_pgtype90;
	Y2982_gen_type [91] = Y2982_pgtype91;
	Y2982_gen_type [92] = Y2982_pgtype92;
	Y2982_gen_type [93] = Y2982_pgtype93;
	Y2982_gen_type [94] = Y2982_pgtype94;
	Y2982_gen_type [95] = Y2982_pgtype95;
	Y2982_gen_type [96] = Y2982_pgtype96;
	Y2982_gen_type [97] = Y2982_pgtype97;
	Y2982_gen_type [98] = Y2982_pgtype98;
	Y2982_gen_type [99] = Y2982_pgtype99;
	Y2982_gen_type [100] = Y2982_pgtype100;
	Y2982_gen_type [101] = Y2982_pgtype101;
	Y2982_gen_type [102] = Y2982_pgtype102;
	Y2982_gen_type [103] = Y2982_pgtype103;
	Y2982_gen_type [104] = Y2982_pgtype104;
	Y2982_gen_type [105] = Y2982_pgtype105;
	Y2982_gen_type [106] = Y2982_pgtype106;
	Y2982_gen_type [107] = Y2982_pgtype107;
	Y2982_gen_type [108] = Y2982_pgtype108;
	Y2982_gen_type [109] = Y2982_pgtype109;
	Y2982_gen_type [110] = Y2982_pgtype110;
	Y2982_gen_type [111] = Y2982_pgtype111;
	Y2982_gen_type [112] = Y2982_pgtype112;
	Y2982_gen_type [113] = Y2982_pgtype113;
	Y2982_gen_type [114] = Y2982_pgtype114;
	Y2982_gen_type [115] = Y2982_pgtype115;
	Y2982_gen_type [116] = Y2982_pgtype116;
	Y2982_gen_type [117] = Y2982_pgtype117;
	Y2982_gen_type [118] = Y2982_pgtype118;
	Y2982_gen_type [119] = Y2982_pgtype119;
	Y2982_gen_type [120] = Y2982_pgtype120;
	Y2982_gen_type [121] = Y2982_pgtype121;
	Y2982_gen_type [122] = Y2982_pgtype122;
	Y2982_gen_type [123] = Y2982_pgtype123;
	Y2982_gen_type [124] = Y2982_pgtype124;
	Y2982_gen_type [125] = Y2982_pgtype125;
	Y2982_gen_type [126] = Y2982_pgtype126;
	Y2982_gen_type [127] = Y2982_pgtype127;
	Y2982_gen_type [128] = Y2982_pgtype128;
	Y2982_gen_type [129] = Y2982_pgtype129;
	Y2982_gen_type [130] = Y2982_pgtype130;
	Y2982_gen_type [131] = Y2982_pgtype131;
	Y2982_gen_type [132] = Y2982_pgtype132;
	Y2982_gen_type [133] = Y2982_pgtype133;
	Y2982_gen_type [134] = Y2982_pgtype134;
	Y2982_gen_type [135] = Y2982_pgtype135;
	Y2982_gen_type [136] = Y2982_pgtype136;
	Y2982_gen_type [137] = Y2982_pgtype137;
	Y2982_gen_type [138] = Y2982_pgtype138;
	Y2982_gen_type [139] = Y2982_pgtype139;
	Y2982_gen_type [140] = Y2982_pgtype140;
	Y2982_gen_type [141] = Y2982_pgtype141;
	Y2982_gen_type [142] = Y2982_pgtype142;
	Y2982_gen_type [143] = Y2982_pgtype143;
	Y2982_gen_type [144] = Y2982_pgtype144;
	Y2982_gen_type [145] = Y2982_pgtype145;
	Y2982_gen_type [146] = Y2982_pgtype146;
	Y2982_gen_type [147] = Y2982_pgtype147;
	Y2982_gen_type [148] = Y2982_pgtype148;
	Y2982_gen_type [149] = Y2982_pgtype149;
	Y2982_gen_type [150] = Y2982_pgtype150;
	Y2982_gen_type [151] = Y2982_pgtype151;
	Y2982_gen_type [152] = Y2982_pgtype152;
	Y2982_gen_type [153] = Y2982_pgtype153;
	Y2982_gen_type [154] = Y2982_pgtype154;
	Y2982_gen_type [155] = Y2982_pgtype155;
	Y2982_gen_type [156] = Y2982_pgtype156;
	Y2982_gen_type [157] = Y2982_pgtype157;
	Y2982_gen_type [158] = Y2982_pgtype158;
	Y2982_gen_type [159] = Y2982_pgtype159;
	Y2982_gen_type [160] = Y2982_pgtype160;
	Y2982_gen_type [161] = Y2982_pgtype161;
	Y2982_gen_type [162] = Y2982_pgtype162;
	Y2982_gen_type [163] = Y2982_pgtype163;
	Y2982_gen_type [164] = Y2982_pgtype164;
	Y2982_gen_type [165] = Y2982_pgtype165;
	Y2982_gen_type [166] = Y2982_pgtype166;
	Y2982_gen_type [167] = Y2982_pgtype167;
	Y2982_gen_type [168] = Y2982_pgtype168;
	Y2982_gen_type [169] = Y2982_pgtype169;
	Y2982_gen_type [170] = Y2982_pgtype170;
	Y2982_gen_type [171] = Y2982_pgtype171;
	Y2982_gen_type [172] = Y2982_pgtype172;
	Y2982_gen_type [173] = Y2982_pgtype173;
	Y2982_gen_type [174] = Y2982_pgtype174;
	Y2982_gen_type [175] = Y2982_pgtype175;
	Y2982_gen_type [176] = Y2982_pgtype176;
	Y2982_gen_type [177] = Y2982_pgtype177;
	Y2982_gen_type [178] = Y2982_pgtype178;
	Y2982_gen_type [179] = Y2982_pgtype179;
	Y2982_gen_type [180] = Y2982_pgtype180;
	Y2982_gen_type [181] = Y2982_pgtype181;
	Y2982_gen_type [182] = Y2982_pgtype182;
	Y2982_gen_type [183] = Y2982_pgtype183;
	Y2982_gen_type [184] = Y2982_pgtype184;
	Y2982_gen_type [185] = Y2982_pgtype185;
	Y2982_gen_type [186] = Y2982_pgtype186;
	Y2982_gen_type [187] = Y2982_pgtype187;
	Y2982_gen_type [188] = Y2982_pgtype188;
	Y2982_gen_type [189] = Y2982_pgtype189;
	Y2982_gen_type [190] = Y2982_pgtype190;
	Y2982_gen_type [191] = Y2982_pgtype191;
	Y2982_gen_type [192] = Y2982_pgtype192;
	Y2982_gen_type [193] = Y2982_pgtype193;
	Y2982_gen_type [194] = Y2982_pgtype194;
	Y2982_gen_type [195] = Y2982_pgtype195;
	Y2982_gen_type [196] = Y2982_pgtype196;
	Y2982_gen_type [197] = Y2982_pgtype197;
	Y2982_gen_type [198] = Y2982_pgtype198;
	Y2982_gen_type [199] = Y2982_pgtype199;
	Y2982_gen_type [200] = Y2982_pgtype200;
	Y2982_gen_type [201] = Y2982_pgtype201;
	Y2982_gen_type [202] = Y2982_pgtype202;
	Y2982_gen_type [203] = Y2982_pgtype203;
	Y2982_gen_type [204] = Y2982_pgtype204;
	Y2982_gen_type [205] = Y2982_pgtype205;
	Y2982_gen_type [206] = Y2982_pgtype206;
	Y2982_gen_type [207] = Y2982_pgtype207;
	Y2982_gen_type [208] = Y2982_pgtype208;
	Y2982_gen_type [209] = Y2982_pgtype209;
	Y2982_gen_type [210] = Y2982_pgtype210;
	Y2982_gen_type [211] = Y2982_pgtype211;
	Y2982_gen_type [212] = Y2982_pgtype212;
	Y2982_gen_type [213] = Y2982_pgtype213;
	Y2982_gen_type [214] = Y2982_pgtype214;
	Y2982_gen_type [215] = Y2982_pgtype215;
	Y2982_gen_type [216] = Y2982_pgtype216;
	Y2982_gen_type [217] = Y2982_pgtype217;
	Y2982_gen_type [218] = Y2982_pgtype218;
	Y2982_gen_type [219] = Y2982_pgtype219;
	Y2982_gen_type [220] = Y2982_pgtype220;
	Y2982_gen_type [221] = Y2982_pgtype221;
	Y2982_gen_type [222] = Y2982_pgtype222;
	Y2982_gen_type [223] = Y2982_pgtype223;
	Y2982_gen_type [224] = Y2982_pgtype224;
	Y2982_gen_type [225] = Y2982_pgtype225;
	Y2982_gen_type [226] = Y2982_pgtype226;
	Y2982_gen_type [227] = Y2982_pgtype227;
	Y2982_gen_type [228] = Y2982_pgtype228;
	Y2982_gen_type [229] = Y2982_pgtype229;
	Y2982_gen_type [230] = Y2982_pgtype230;
	Y2982_gen_type [231] = Y2982_pgtype231;
	Y2982_gen_type [232] = Y2982_pgtype232;
	Y2982_gen_type [233] = Y2982_pgtype233;
	Y2982_gen_type [234] = Y2982_pgtype234;
	Y2982_gen_type [235] = Y2982_pgtype235;
	Y2982_gen_type [236] = Y2982_pgtype236;
	Y2982_gen_type [237] = Y2982_pgtype237;
	Y2982_gen_type [238] = Y2982_pgtype238;
	Y2982_gen_type [239] = Y2982_pgtype239;
	Y2982_gen_type [240] = Y2982_pgtype240;
	Y2982_gen_type [241] = Y2982_pgtype241;
	Y2982_gen_type [242] = Y2982_pgtype242;
	Y2982_gen_type [243] = Y2982_pgtype243;
	Y2982_gen_type [244] = Y2982_pgtype244;
	Y2982_gen_type [245] = Y2982_pgtype245;
	Y2982_gen_type [246] = Y2982_pgtype246;
	Y2982_gen_type [247] = Y2982_pgtype247;
	Y2982_gen_type [248] = Y2982_pgtype248;
	Y2982_gen_type [249] = Y2982_pgtype249;
	Y2982_gen_type [250] = Y2982_pgtype250;
	Y2982_gen_type [251] = Y2982_pgtype251;
	Y2982_gen_type [252] = Y2982_pgtype252;
	Y2982_gen_type [253] = Y2982_pgtype253;
	Y2982_gen_type [254] = Y2982_pgtype254;
	Y2982_gen_type [255] = Y2982_pgtype255;
	Y2982_gen_type [256] = Y2982_pgtype256;
	Y2982_gen_type [257] = Y2982_pgtype257;
	Y2982_gen_type [258] = Y2982_pgtype258;
	Y2982_gen_type [259] = Y2982_pgtype259;
	Y2982_gen_type [260] = Y2982_pgtype260;
	Y2982_gen_type [261] = Y2982_pgtype261;
	Y2982_gen_type [262] = Y2982_pgtype262;
	Y2982_gen_type [263] = Y2982_pgtype263;
	Y2982_gen_type [264] = Y2982_pgtype264;
	Y2982_gen_type [265] = Y2982_pgtype265;
	Y2982_gen_type [266] = Y2982_pgtype266;
	Y2982_gen_type [267] = Y2982_pgtype267;
	Y2982_gen_type [268] = Y2982_pgtype268;
	Y2982_gen_type [269] = Y2982_pgtype269;
	Y2982_gen_type [270] = Y2982_pgtype270;
	Y2982_gen_type [271] = Y2982_pgtype271;
	Y2982_gen_type [272] = Y2982_pgtype272;
	Y2982_gen_type [273] = Y2982_pgtype273;
	Y2982_gen_type [274] = Y2982_pgtype274;
	Y2982_gen_type [275] = Y2982_pgtype275;
	Y2982_gen_type [276] = Y2982_pgtype276;
	Y2982_gen_type [277] = Y2982_pgtype277;
	Y2982_gen_type [278] = Y2982_pgtype278;
	Y2982_gen_type [279] = Y2982_pgtype279;
	Y2982_gen_type [280] = Y2982_pgtype280;
	Y2982_gen_type [281] = Y2982_pgtype281;
	Y2982_gen_type [282] = Y2982_pgtype282;
	Y2982_gen_type [283] = Y2982_pgtype283;
	Y2982_gen_type [284] = Y2982_pgtype284;
	Y2982_gen_type [285] = Y2982_pgtype285;
	Y2982_gen_type [286] = Y2982_pgtype286;
	Y2982_gen_type [287] = Y2982_pgtype287;
	Y2982_gen_type [288] = Y2982_pgtype288;
	Y2982_gen_type [289] = Y2982_pgtype289;
	Y2982_gen_type [290] = Y2982_pgtype290;
	Y2982_gen_type [291] = Y2982_pgtype291;
	Y2982_gen_type [292] = Y2982_pgtype292;
	Y2982_gen_type [293] = Y2982_pgtype293;
	Y2982_gen_type [294] = Y2982_pgtype294;
	Y2982_gen_type [295] = Y2982_pgtype295;
	Y2982_gen_type [296] = Y2982_pgtype296;
	Y2982_gen_type [297] = Y2982_pgtype297;
	Y2982_gen_type [298] = Y2982_pgtype298;
	Y2982_gen_type [299] = Y2982_pgtype299;
	Y2982_gen_type [300] = Y2982_pgtype300;
	Y2982_gen_type [301] = Y2982_pgtype301;
	Y2982_gen_type [302] = Y2982_pgtype302;
	Y2982_gen_type [303] = Y2982_pgtype303;
	Y2982_gen_type [304] = Y2982_pgtype304;
	Y2982_gen_type [305] = Y2982_pgtype305;
	Y2982_gen_type [306] = Y2982_pgtype306;
	Y2982_gen_type [307] = Y2982_pgtype307;
	Y2982_gen_type [308] = Y2982_pgtype308;
	Y2982_gen_type [309] = Y2982_pgtype309;
	Y2982_gen_type [310] = Y2982_pgtype310;
	Y2982_gen_type [311] = Y2982_pgtype311;
	Y2982_gen_type [312] = Y2982_pgtype312;
	Y2982_gen_type [313] = Y2982_pgtype313;
	Y2982_gen_type [314] = Y2982_pgtype314;
	Y2982_gen_type [315] = Y2982_pgtype315;
	Y2982_gen_type [316] = Y2982_pgtype316;
	Y2982_gen_type [317] = Y2982_pgtype317;
	Y2982_gen_type [318] = Y2982_pgtype318;
	Y2982_gen_type [319] = Y2982_pgtype319;
	Y2982_gen_type [320] = Y2982_pgtype320;
	Y2982_gen_type [321] = Y2982_pgtype321;
	Y2982_gen_type [322] = Y2982_pgtype322;
	Y2982_gen_type [323] = Y2982_pgtype323;
	Y2982_gen_type [324] = Y2982_pgtype324;
	Y2982_gen_type [325] = Y2982_pgtype325;
	Y2982_gen_type [326] = Y2982_pgtype326;
	Y2982_gen_type [327] = Y2982_pgtype327;
	Y2982_gen_type [328] = Y2982_pgtype328;
	Y2982_gen_type [329] = Y2982_pgtype329;
	Y2982_gen_type [330] = Y2982_pgtype330;
	Y2982_gen_type [331] = Y2982_pgtype331;
	Y2982_gen_type [332] = Y2982_pgtype332;
	Y2982_gen_type [333] = Y2982_pgtype333;
	Y2982_gen_type [334] = Y2982_pgtype334;
	Y2982_gen_type [335] = Y2982_pgtype335;
	Y2982_gen_type [336] = Y2982_pgtype336;
	Y2982_gen_type [337] = Y2982_pgtype337;
	Y2982_gen_type [338] = Y2982_pgtype338;
	Y2982_gen_type [339] = Y2982_pgtype339;
	Y2982_gen_type [340] = Y2982_pgtype340;
	Y2982_gen_type [341] = Y2982_pgtype341;
	Y2982_gen_type [342] = Y2982_pgtype342;
	Y2982_gen_type [343] = Y2982_pgtype343;
	Y2982_gen_type [344] = Y2982_pgtype344;
	Y2982_gen_type [345] = Y2982_pgtype345;
	Y2982_gen_type [346] = Y2982_pgtype346;
	Y2982_gen_type [347] = Y2982_pgtype347;
	Y2982_gen_type [348] = Y2982_pgtype348;
	Y2982_gen_type [349] = Y2982_pgtype349;
	Y2982_gen_type [350] = Y2982_pgtype350;
	Y2982_gen_type [351] = Y2982_pgtype351;
	Y2982_gen_type [352] = Y2982_pgtype352;
	Y2982_gen_type [353] = Y2982_pgtype353;
	Y2982_gen_type [354] = Y2982_pgtype354;
	Y2982_gen_type [355] = Y2982_pgtype355;
	Y2982_gen_type [356] = Y2982_pgtype356;
	Y2982_gen_type [357] = Y2982_pgtype357;
	Y2982_gen_type [358] = Y2982_pgtype358;
	Y2982_gen_type [359] = Y2982_pgtype359;
	Y2982_gen_type [360] = Y2982_pgtype360;
	Y2982_gen_type [361] = Y2982_pgtype361;
	Y2982_gen_type [362] = Y2982_pgtype362;
	Y2982_gen_type [363] = Y2982_pgtype363;
	Y2982_gen_type [364] = Y2982_pgtype364;
	Y2982_gen_type [365] = Y2982_pgtype365;
	Y2982_gen_type [366] = Y2982_pgtype366;
	Y2982_gen_type [367] = Y2982_pgtype367;
	Y2982_gen_type [368] = Y2982_pgtype368;
	Y2982_gen_type [369] = Y2982_pgtype369;
	Y2982_gen_type [370] = Y2982_pgtype370;
	Y2982_gen_type [371] = Y2982_pgtype371;
	Y2982_gen_type [372] = Y2982_pgtype372;
	Y2982_gen_type [373] = Y2982_pgtype373;
	Y2982_gen_type [374] = Y2982_pgtype374;
	Y2982_gen_type [375] = Y2982_pgtype375;
	Y2982_gen_type [376] = Y2982_pgtype376;
	Y2982_gen_type [377] = Y2982_pgtype377;
	Y2982_gen_type [378] = Y2982_pgtype378;
	Y2982_gen_type [379] = Y2982_pgtype379;
	Y2982_gen_type [380] = Y2982_pgtype380;
	Y2982_gen_type [381] = Y2982_pgtype381;
	Y2982_gen_type [382] = Y2982_pgtype382;
	Y2982_gen_type [383] = Y2982_pgtype383;
	Y2982_gen_type [384] = Y2982_pgtype384;
	Y2982_gen_type [385] = Y2982_pgtype385;
	Y2982_gen_type [386] = Y2982_pgtype386;
	Y2982_gen_type [387] = Y2982_pgtype387;
	Y2982_gen_type [388] = Y2982_pgtype388;
	Y2982_gen_type [389] = Y2982_pgtype389;
	Y2982_gen_type [390] = Y2982_pgtype390;
	Y2982_gen_type [391] = Y2982_pgtype391;
	Y2982_gen_type [392] = Y2982_pgtype392;
	Y2982_gen_type [393] = Y2982_pgtype393;
	Y2982_gen_type [394] = Y2982_pgtype394;
	Y2982_gen_type [395] = Y2982_pgtype395;
	Y2982_gen_type [396] = Y2982_pgtype396;
	Y2982_gen_type [397] = Y2982_pgtype397;
	Y2982_gen_type [398] = Y2982_pgtype398;
	Y2982_gen_type [399] = Y2982_pgtype399;
	Y2982_gen_type [400] = Y2982_pgtype400;
	Y2982_gen_type [401] = Y2982_pgtype401;
	Y2982_gen_type [402] = Y2982_pgtype402;
	Y2982_gen_type [403] = Y2982_pgtype403;
	Y2982_gen_type [404] = Y2982_pgtype404;
	Y2982_gen_type [405] = Y2982_pgtype405;
	Y2982_gen_type [406] = Y2982_pgtype406;
	Y2982_gen_type [407] = Y2982_pgtype407;
	Y2982_gen_type [408] = Y2982_pgtype408;
	Y2982_gen_type [409] = Y2982_pgtype409;
	Y2982_gen_type [410] = Y2982_pgtype410;
	Y2982_gen_type [411] = Y2982_pgtype411;
	Y2982_gen_type [412] = Y2982_pgtype412;
	Y2982_gen_type [413] = Y2982_pgtype413;
	Y2982_gen_type [414] = Y2982_pgtype414;
	Y2982_gen_type [415] = Y2982_pgtype415;
	Y2982_gen_type [416] = Y2982_pgtype416;
	Y2982_gen_type [417] = Y2982_pgtype417;
	Y2982_gen_type [418] = Y2982_pgtype418;
	Y2982_gen_type [419] = Y2982_pgtype419;
	Y2982_gen_type [420] = Y2982_pgtype420;
	Y2982_gen_type [421] = Y2982_pgtype421;
	Y2982_gen_type [422] = Y2982_pgtype422;
	Y2982_gen_type [423] = Y2982_pgtype423;
	Y2982_gen_type [424] = Y2982_pgtype424;
	Y2982_gen_type [425] = Y2982_pgtype425;
	Y2982_gen_type [426] = Y2982_pgtype426;
	Y2982_gen_type [430] = Y2982_pgtype427;
	Y2982_gen_type [431] = Y2982_pgtype428;
	Y2982_gen_type [432] = Y2982_pgtype429;
	Y2982_gen_type [433] = Y2982_pgtype430;
	Y2982_gen_type [434] = Y2982_pgtype431;
	Y2982_gen_type [435] = Y2982_pgtype432;
	Y2982_gen_type [436] = Y2982_pgtype433;
	Y2982_gen_type [437] = Y2982_pgtype434;
	Y2982_gen_type [438] = Y2982_pgtype435;
	Y2982_gen_type [439] = Y2982_pgtype436;
	Y2982_gen_type [440] = Y2982_pgtype437;
	Y2982_gen_type [441] = Y2982_pgtype438;
	Y2982_gen_type [442] = Y2982_pgtype439;
	Y2982_gen_type [443] = Y2982_pgtype440;
	Y2982_gen_type [444] = Y2982_pgtype441;
	Y2982_gen_type [445] = Y2982_pgtype442;
	Y2982_gen_type [446] = Y2982_pgtype443;
	Y2982_gen_type [447] = Y2982_pgtype444;
	Y2982_gen_type [448] = Y2982_pgtype445;
	Y2982_gen_type [449] = Y2982_pgtype446;
	Y2982_gen_type [450] = Y2982_pgtype447;
	Y2982_gen_type [486] = Y2982_pgtype448;
	Y2982_gen_type [567] = Y2982_pgtype449;
	Y2982_gen_type [568] = Y2982_pgtype450;
	Y2982_gen_type [569] = Y2982_pgtype451;
	Y2982_gen_type [570] = Y2982_pgtype452;
	Y2982_gen_type [571] = Y2982_pgtype453;
	Y2982_gen_type [572] = Y2982_pgtype454;
	Y2982_gen_type [573] = Y2982_pgtype455;
	Y2982_gen_type [633] = Y2982_pgtype456;
	Y2982_gen_type [674] = Y2982_pgtype457;
	Y2982_gen_type [675] = Y2982_pgtype458;
	Y2982_gen_type [676] = Y2982_pgtype459;
	Y2982_gen_type [677] = Y2982_pgtype460;
	Y2982_gen_type [678] = Y2982_pgtype461;
	Y2982_gen_type [679] = Y2982_pgtype462;
	Y2982_gen_type [680] = Y2982_pgtype463;
	Y2982_gen_type [681] = Y2982_pgtype464;
	Y2982_gen_type [682] = Y2982_pgtype465;
	Y2982_gen_type [683] = Y2982_pgtype466;
	Y2982_gen_type [684] = Y2982_pgtype467;
	Y2982_gen_type [685] = Y2982_pgtype468;
	Y2982_gen_type [686] = Y2982_pgtype469;
	Y2982_gen_type [687] = Y2982_pgtype470;
	Y2982_gen_type [688] = Y2982_pgtype471;
	Y2982_gen_type [689] = Y2982_pgtype472;
	Y2982_gen_type [690] = Y2982_pgtype473;
	Y2982_gen_type [691] = Y2982_pgtype474;
	Y2982_gen_type [692] = Y2982_pgtype475;
	Y2982_gen_type [693] = Y2982_pgtype476;
	Y2982_gen_type [694] = Y2982_pgtype477;
	Y2982_gen_type [695] = Y2982_pgtype478;
	Y2982_gen_type [696] = Y2982_pgtype479;
	Y2982_gen_type [697] = Y2982_pgtype480;
	Y2982_gen_type [698] = Y2982_pgtype481;
	Y2982_gen_type [699] = Y2982_pgtype482;
	Y2982_gen_type [700] = Y2982_pgtype483;
	Y2982_gen_type [701] = Y2982_pgtype484;
	Y2982_gen_type [702] = Y2982_pgtype485;
	Y2982_gen_type [703] = Y2982_pgtype486;
	Y2982_gen_type [704] = Y2982_pgtype487;
	Y2982_gen_type [705] = Y2982_pgtype488;
	Y2982_gen_type [706] = Y2982_pgtype489;
	Y2982_gen_type [707] = Y2982_pgtype490;
	Y2982_gen_type [708] = Y2982_pgtype491;
	Y2982_gen_type [709] = Y2982_pgtype492;
	Y2982_gen_type [710] = Y2982_pgtype493;
	Y2982_gen_type [711] = Y2982_pgtype494;
	Y2982_gen_type [712] = Y2982_pgtype495;
	Y2982_gen_type [713] = Y2982_pgtype496;
	Y2982_gen_type [714] = Y2982_pgtype497;
	Y2982_gen_type [715] = Y2982_pgtype498;
	Y2982_gen_type [716] = Y2982_pgtype499;
	Y2982_gen_type [717] = Y2982_pgtype500;
	Y2982_gen_type [718] = Y2982_pgtype501;
	Y2982_gen_type [719] = Y2982_pgtype502;
	Y2982_gen_type [720] = Y2982_pgtype503;
	Y2982_gen_type [721] = Y2982_pgtype504;
	Y2982_gen_type [722] = Y2982_pgtype505;
	Y2982_gen_type [723] = Y2982_pgtype506;
	Y2982_gen_type [724] = Y2982_pgtype507;
	Y2982_gen_type [725] = Y2982_pgtype508;
	Y2982_gen_type [726] = Y2982_pgtype509;
	Y2982_gen_type [727] = Y2982_pgtype510;
	Y2982_gen_type [728] = Y2982_pgtype511;
	Y2982_gen_type [729] = Y2982_pgtype512;
	Y2982_gen_type [730] = Y2982_pgtype513;
	Y2982_gen_type [731] = Y2982_pgtype514;
	Y2982_gen_type [772] = Y2982_pgtype515;
	Y2982_gen_type [773] = Y2982_pgtype516;
	Y2982_gen_type [774] = Y2982_pgtype517;
	Y2982_gen_type [775] = Y2982_pgtype518;
	Y2982_gen_type [776] = Y2982_pgtype519;
	Y2982_gen_type [777] = Y2982_pgtype520;
	Y2982_gen_type [778] = Y2982_pgtype521;
	Y2982_gen_type [779] = Y2982_pgtype522;
	Y2982_gen_type [780] = Y2982_pgtype523;
	Y2982_gen_type [781] = Y2982_pgtype524;
	Y2982_gen_type [782] = Y2982_pgtype525;
	Y2982_gen_type [783] = Y2982_pgtype526;
	Y2982_gen_type [784] = Y2982_pgtype527;
	Y2982_gen_type [785] = Y2982_pgtype528;
	Y2982_gen_type [786] = Y2982_pgtype529;
	Y2982_gen_type [787] = Y2982_pgtype530;
	Y2982_gen_type [788] = Y2982_pgtype531;
	Y2982_gen_type [789] = Y2982_pgtype532;
	Y2982_gen_type [790] = Y2982_pgtype533;
	Y2982_gen_type [791] = Y2982_pgtype534;
	Y2982_gen_type [792] = Y2982_pgtype535;
	Y2982_gen_type [793] = Y2982_pgtype536;
	Y2982_gen_type [798] = Y2982_pgtype537;
	Y2982_gen_type [799] = Y2982_pgtype538;
	Y2982_gen_type [803] = Y2982_pgtype539;
	Y2982_gen_type [804] = Y2982_pgtype540;
	Y2982_gen_type [805] = Y2982_pgtype541;
	Y2982_gen_type [806] = Y2982_pgtype542;
	Y2982_gen_type [807] = Y2982_pgtype543;
	Y2982_gen_type [808] = Y2982_pgtype544;
	Y2982_gen_type [809] = Y2982_pgtype545;
	Y2982_gen_type [810] = Y2982_pgtype546;
	Y2982_gen_type [830] = Y2982_pgtype547;
	Y2982_gen_type [831] = Y2982_pgtype548;
	Y2982_gen_type [832] = Y2982_pgtype549;
	Y2982_gen_type [833] = Y2982_pgtype550;
	Y2982_gen_type [834] = Y2982_pgtype551;
	Y2982_gen_type [835] = Y2982_pgtype552;
	Y2982_gen_type [836] = Y2982_pgtype553;
	Y2982_gen_type [837] = Y2982_pgtype554;
	Y2982_gen_type [838] = Y2982_pgtype555;
	Y2982_gen_type [839] = Y2982_pgtype556;
	Y2982_gen_type [840] = Y2982_pgtype557;
	Y2982_gen_type [841] = Y2982_pgtype558;
	Y2982_gen_type [842] = Y2982_pgtype559;
	Y2982_gen_type [843] = Y2982_pgtype560;
	Y2982_gen_type [844] = Y2982_pgtype561;
	Y2982_gen_type [845] = Y2982_pgtype562;
	Y2982_gen_type [846] = Y2982_pgtype563;
	Y2982_gen_type [847] = Y2982_pgtype564;
	Y2982_gen_type [848] = Y2982_pgtype565;
	Y2982_gen_type [849] = Y2982_pgtype566;
	Y2982_gen_type [850] = Y2982_pgtype567;
	Y2982_gen_type [851] = Y2982_pgtype568;
	Y2982_gen_type [852] = Y2982_pgtype569;
	Y2982_gen_type [853] = Y2982_pgtype570;
	Y2982_gen_type [854] = Y2982_pgtype571;
	Y2982_gen_type [855] = Y2982_pgtype572;
	Y2982_gen_type [856] = Y2982_pgtype573;
	Y2982_gen_type [857] = Y2982_pgtype574;
	Y2982_gen_type [858] = Y2982_pgtype575;
	Y2982_gen_type [859] = Y2982_pgtype576;
	Y2982_gen_type [860] = Y2982_pgtype577;
	Y2982_gen_type [868] = Y2982_pgtype578;
	Y2982_gen_type [869] = Y2982_pgtype579;
	Y2982_gen_type [870] = Y2982_pgtype580;
	Y2982_gen_type [871] = Y2982_pgtype581;
	Y2982_gen_type [873] = Y2982_pgtype582;
	Y2982_gen_type [874] = Y2982_pgtype583;
	Y2982_gen_type [875] = Y2982_pgtype584;
	Y2982_gen_type [876] = Y2982_pgtype585;
	Y2982_gen_type [906] = Y2982_pgtype586;
	Y2982_gen_type [907] = Y2982_pgtype587;
	Y2982_gen_type [908] = Y2982_pgtype588;
	Y2982_gen_type [975] = Y2982_pgtype589;
	Y2982_gen_type [1057] = Y2982_pgtype590;
	Y2982_gen_type [1058] = Y2982_pgtype591;
	Y2982[12] = 946;
	Y2982[13] = 897;
	{long i; for (i = 14; i < 16; i++) Y2982[i] = 950;};
	Y2982[88] = 897;
	Y2982[89] = 900;
	Y2982[256] = 873;
	{long i; for (i = 319; i < 322; i++) Y2982[i] = 900;};
	Y2982[358] = 873;
	Y2982[450] = 0;
	Y2982[486] = 0;
	{long i; for (i = 567; i < 570; i++) Y2982[i] = 897;};
	{long i; for (i = 570; i < 574; i++) Y2982[i] = 900;};
	Y2982[633] = 900;
	Y2982[810] = 153;
	Y2982[832] = 4;
	{long i; for (i = 859; i < 861; i++) Y2982[i] = 950;};
	{long i; for (i = 868; i < 872; i++) Y2982[i] = 900;};
	{long i; for (i = 873; i < 877; i++) Y2982[i] = 900;};
	{long i; for (i = 906; i < 909; i++) Y2982[i] = 1276;};
	Y2982[975] = 950;
	{long i; for (i = 1057; i < 1059; i++) Y2982[i] = 900;};
}

char *(*R3047[5])();
void R3047_init () {
	R3047[0] = (char *(*)()) F424_3421;
	R3047[1] = (char *(*)()) F426_3421;
	R3047[2] = (char *(*)()) F424_3421;
	{long i; for (i = 3; i < 5; i++) R3047[i] = (char *(*)()) F427_3421;}
}

char *(*R3050[5])();
void R3050_init () {
	R3050[0] = (char *(*)()) F424_3426;
	R3050[1] = (char *(*)()) F426_3426;
	R3050[2] = (char *(*)()) F424_3426;
	{long i; for (i = 3; i < 5; i++) R3050[i] = (char *(*)()) F427_3426;}
}

char *(*R3053[5])();
void R3053_init () {
	R3053[0] = (char *(*)()) F424_3407;
	R3053[1] = (char *(*)()) F426_3407;
	R3053[2] = (char *(*)()) F424_3407;
	{long i; for (i = 3; i < 5; i++) R3053[i] = (char *(*)()) F427_3407;}
}

char *(*R3080[803])();
void R3080_init () {
	R3080[0] = (char *(*)()) F635_3585_3080_2;
	R3080[316] = (char *(*)()) F949_6159_3080_2;
	{long i; for (i = 801; i < 803; i++) R3080[i] = (char *(*)()) F1436_11359_3080_2;}
}
static EIF_BOOLEAN F635_3585_3080_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F635_3585(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F949_6159_3080_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F949_6159(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1436_11359_3080_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1436_11359(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R3085[803])();
void R3085_init () {
	R3085[0] = (char *(*)()) F496_3494;
	R3085[64] = (char *(*)()) F498_3494;
	R3085[103] = (char *(*)()) F493_3494;
	R3085[104] = (char *(*)()) F495_3494;
	R3085[105] = (char *(*)()) F496_3494;
	R3085[106] = (char *(*)()) F497_3494;
	R3085[107] = (char *(*)()) F498_3494;
	R3085[108] = (char *(*)()) F494_3494;
	R3085[109] = (char *(*)()) F499_3494;
	R3085[110] = (char *(*)()) F500_3494;
	R3085[111] = (char *(*)()) F501_3494;
	R3085[112] = (char *(*)()) F502_3494;
	R3085[113] = (char *(*)()) F503_3494;
	R3085[114] = (char *(*)()) F504_3494;
	R3085[115] = (char *(*)()) F493_3494;
	R3085[116] = (char *(*)()) F496_3494;
	R3085[117] = (char *(*)()) F498_3494;
	R3085[118] = (char *(*)()) F502_3494;
	R3085[119] = (char *(*)()) F497_3494;
	R3085[120] = (char *(*)()) F501_3494;
	R3085[175] = (char *(*)()) F493_3494;
	R3085[176] = (char *(*)()) F495_3494;
	R3085[177] = (char *(*)()) F496_3494;
	R3085[178] = (char *(*)()) F497_3494;
	R3085[179] = (char *(*)()) F498_3494;
	R3085[180] = (char *(*)()) F494_3494;
	R3085[181] = (char *(*)()) F499_3494;
	R3085[182] = (char *(*)()) F500_3494;
	R3085[183] = (char *(*)()) F501_3494;
	R3085[184] = (char *(*)()) F502_3494;
	R3085[185] = (char *(*)()) F503_3494;
	R3085[186] = (char *(*)()) F504_3494;
	R3085[187] = (char *(*)()) F493_3494;
	R3085[188] = (char *(*)()) F495_3494;
	R3085[189] = (char *(*)()) F493_3494;
	{long i; for (i = 190; i < 192; i++) R3085[i] = (char *(*)()) F496_3494;}
	R3085[194] = (char *(*)()) F493_3494;
	R3085[313] = (char *(*)()) F494_3494;
	R3085[316] = (char *(*)()) F498_3494;
	R3085[377] = (char *(*)()) F498_3494;
	{long i; for (i = 612; i < 614; i++) R3085[i] = (char *(*)()) F498_3494;}
	{long i; for (i = 617; i < 619; i++) R3085[i] = (char *(*)()) F498_3494;}
	{long i; for (i = 801; i < 803; i++) R3085[i] = (char *(*)()) F498_3494;}
}

char *(*R3117[487])();
void R3117_init () {
	R3117[0] = (char *(*)()) F949_6147_3117_23;
	{long i; for (i = 485; i < 487; i++) R3117[i] = (char *(*)()) F1436_11353_3117_23;}
}
static EIF_INTEGER_32 F949_6147_3117_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F949_6147(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_INTEGER_32 F1436_11353_3117_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1436_11353(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R3118[700])();
void R3118_init () {
	R3118[0] = (char *(*)()) F738_4063_3118_5;
	R3118[1] = (char *(*)()) F739_4063_3118_5;
	R3118[2] = (char *(*)()) F740_4063_3118_5;
	R3118[3] = (char *(*)()) F741_4063_3118_5;
	R3118[4] = (char *(*)()) F742_4063_3118_5;
	R3118[5] = (char *(*)()) F743_4063_3118_5;
	R3118[6] = (char *(*)()) F744_4063_3118_5;
	R3118[7] = (char *(*)()) F745_4063_3118_5;
	R3118[8] = (char *(*)()) F746_4063_3118_5;
	R3118[9] = (char *(*)()) F747_4063_3118_5;
	R3118[10] = (char *(*)()) F748_4063_3118_5;
	R3118[11] = (char *(*)()) F749_4063_3118_5;
	R3118[12] = (char *(*)()) F738_4063_3118_5;
	R3118[13] = (char *(*)()) F740_4063_3118_5;
	R3118[14] = (char *(*)()) F742_4063_3118_5;
	R3118[15] = (char *(*)()) F747_4063_3118_5;
	R3118[16] = (char *(*)()) F741_4063_3118_5;
	R3118[17] = (char *(*)()) F746_4063_3118_5;
	R3118[72] = (char *(*)()) F810_4275_3118_5;
	R3118[73] = (char *(*)()) F811_4275_3118_5;
	R3118[74] = (char *(*)()) F812_4275_3118_5;
	R3118[75] = (char *(*)()) F813_4275_3118_5;
	R3118[76] = (char *(*)()) F814_4275_3118_5;
	R3118[77] = (char *(*)()) F815_4275_3118_5;
	R3118[78] = (char *(*)()) F816_4275_3118_5;
	R3118[79] = (char *(*)()) F817_4275_3118_5;
	R3118[80] = (char *(*)()) F818_4275_3118_5;
	R3118[81] = (char *(*)()) F819_4275_3118_5;
	R3118[82] = (char *(*)()) F820_4275_3118_5;
	R3118[83] = (char *(*)()) F821_4275_3118_5;
	R3118[210] = (char *(*)()) F948_6039_3118_5;
	R3118[213] = (char *(*)()) F951_6203_3118_5;
	{long i; for (i = 698; i < 700; i++) R3118[i] = (char *(*)()) F1436_11338_3118_5;}
}
static EIF_REFERENCE F738_4063_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F738_4063(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F739_4063_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F739_4063(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F740_4063_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F740_4063(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F741_4063_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F741_4063(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(879, 0x00).id, 879, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F742_4063_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F742_4063(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F743_4063_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F743_4063(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(897, 0x00).id, 897, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F744_4063_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F744_4063(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(888, 0x00).id, 888, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F745_4063_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F745_4063(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(885, 0x00).id, 885, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F746_4063_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F746_4063(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(882, 0x00).id, 882, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F747_4063_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F747_4063(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(903, 0x00).id, 903, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F748_4063_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F748_4063(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(891, 0x00).id, 891, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F749_4063_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F749_4063(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(894, 0x00).id, 894, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F810_4275_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F810_4275(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F811_4275_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F811_4275(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F812_4275_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F812_4275(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F813_4275_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F813_4275(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(879, 0x00).id, 879, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F814_4275_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F814_4275(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F815_4275_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F815_4275(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(897, 0x00).id, 897, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F816_4275_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F816_4275(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(888, 0x00).id, 888, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F817_4275_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F817_4275(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(885, 0x00).id, 885, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F818_4275_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F818_4275(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(882, 0x00).id, 882, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F819_4275_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F819_4275(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(903, 0x00).id, 903, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F820_4275_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F820_4275(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(891, 0x00).id, 891, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F821_4275_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F821_4275(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(894, 0x00).id, 894, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F948_6039_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F948_6039(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(897, 0x00).id, 897, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F951_6203_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F951_6203(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1436_11338_3118_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1436_11338(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R3121[700])();
void R3121_init () {
	R3121[0] = (char *(*)()) F738_4082_3121_20;
	R3121[1] = (char *(*)()) F739_4082_3121_20;
	R3121[2] = (char *(*)()) F740_4082_3121_20;
	R3121[3] = (char *(*)()) F741_4082_3121_20;
	R3121[4] = (char *(*)()) F742_4082_3121_20;
	R3121[5] = (char *(*)()) F743_4082_3121_20;
	R3121[6] = (char *(*)()) F744_4082_3121_20;
	R3121[7] = (char *(*)()) F745_4082_3121_20;
	R3121[8] = (char *(*)()) F746_4082_3121_20;
	R3121[9] = (char *(*)()) F747_4082_3121_20;
	R3121[10] = (char *(*)()) F748_4082_3121_20;
	R3121[11] = (char *(*)()) F749_4082_3121_20;
	R3121[12] = (char *(*)()) F738_4082_3121_20;
	R3121[13] = (char *(*)()) F740_4082_3121_20;
	R3121[14] = (char *(*)()) F742_4082_3121_20;
	R3121[15] = (char *(*)()) F747_4082_3121_20;
	R3121[16] = (char *(*)()) F741_4082_3121_20;
	R3121[17] = (char *(*)()) F746_4082_3121_20;
	R3121[84] = (char *(*)()) F822_4381;
	R3121[85] = (char *(*)()) F823_4381_3121_20;
	R3121[86] = (char *(*)()) F824_4381_3121_20;
	R3121[87] = (char *(*)()) F825_4381_3121_20;
	R3121[88] = (char *(*)()) F826_4381_3121_20;
	R3121[91] = (char *(*)()) F822_4381;
	R3121[210] = (char *(*)()) F948_6059_3121_20;
	R3121[213] = (char *(*)()) F951_6224_3121_20;
	{long i; for (i = 698; i < 700; i++) R3121[i] = (char *(*)()) F1436_11373_3121_20;}
}
static void F738_4082_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F738_4082(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F739_4082_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F739_4082(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F740_4082_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F740_4082(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F741_4082_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F741_4082(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F742_4082_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F742_4082(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F743_4082_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F743_4082(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F744_4082_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F744_4082(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F745_4082_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F745_4082(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F746_4082_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F746_4082(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F747_4082_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F747_4082(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F748_4082_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F748_4082(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F749_4082_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F749_4082(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F823_4381_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F823_4381(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F824_4381_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F824_4381(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F825_4381_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F825_4381(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F826_4381_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F826_4381(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F948_6059_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F948_6059(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F951_6224_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F951_6224(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1436_11373_3121_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1436_11373(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y3123_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype30[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype31[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype32[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype33[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype34[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype35[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype36[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype37[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype38[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype39[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype40[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype41[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype42[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype43[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype44[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype45[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype46[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype47[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype48[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype49[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype50[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype51[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype52[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype53[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype54[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype55[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype56[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype57[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype58[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype59[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype60[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype61[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype62[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype63[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype64[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype65[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype66[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype67[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype68[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype69[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype70[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype71[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype72[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype73[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype74[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype75[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype76[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype77[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype78[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype79[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype80[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype81[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype82[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype83[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype84[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype85[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype86[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype87[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype88[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype89[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype90[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype91[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype92[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype93[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype94[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype95[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype96[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype97[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype98[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype99[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype100[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype101[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype102[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype103[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype104[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype105[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype106[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype107[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype108[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype109[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype110[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype111[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype112[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype113[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype114[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype115[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype116[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype117[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype118[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype119[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype120[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype121[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype122[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype123[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype124[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype125[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype126[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype127[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype128[] = {0xFF01,942,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype129[] = {0xFF01,942,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype130[] = {0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype131[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype132[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype133[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype134[] = {873,0xFFFF};
static EIF_TYPE_INDEX Y3123_pgtype135[] = {873,0xFFFF};
EIF_TYPE_INDEX *Y3123_gen_type [872];
EIF_TYPE_INDEX Y3123 [872];
void Y3123_init (void)
{
	egc_routines_types [3123] = Y3123;
	egc_routines_gen_types [3123] = Y3123_gen_type;
	egc_routines_offset [3123] = 565;
	Y3123_gen_type [0] = Y3123_pgtype0;
	Y3123_gen_type [1] = Y3123_pgtype1;
	Y3123_gen_type [2] = Y3123_pgtype2;
	Y3123_gen_type [3] = Y3123_pgtype3;
	Y3123_gen_type [4] = Y3123_pgtype4;
	Y3123_gen_type [5] = Y3123_pgtype5;
	Y3123_gen_type [6] = Y3123_pgtype6;
	Y3123_gen_type [7] = Y3123_pgtype7;
	Y3123_gen_type [8] = Y3123_pgtype8;
	Y3123_gen_type [9] = Y3123_pgtype9;
	Y3123_gen_type [10] = Y3123_pgtype10;
	Y3123_gen_type [11] = Y3123_pgtype11;
	Y3123_gen_type [12] = Y3123_pgtype12;
	Y3123_gen_type [13] = Y3123_pgtype13;
	Y3123_gen_type [14] = Y3123_pgtype14;
	Y3123_gen_type [15] = Y3123_pgtype15;
	Y3123_gen_type [16] = Y3123_pgtype16;
	Y3123_gen_type [17] = Y3123_pgtype17;
	Y3123_gen_type [18] = Y3123_pgtype18;
	Y3123_gen_type [19] = Y3123_pgtype19;
	Y3123_gen_type [20] = Y3123_pgtype20;
	Y3123_gen_type [21] = Y3123_pgtype21;
	Y3123_gen_type [22] = Y3123_pgtype22;
	Y3123_gen_type [23] = Y3123_pgtype23;
	Y3123_gen_type [24] = Y3123_pgtype24;
	Y3123_gen_type [25] = Y3123_pgtype25;
	Y3123_gen_type [26] = Y3123_pgtype26;
	Y3123_gen_type [27] = Y3123_pgtype27;
	Y3123_gen_type [28] = Y3123_pgtype28;
	Y3123_gen_type [29] = Y3123_pgtype29;
	Y3123_gen_type [159] = Y3123_pgtype30;
	Y3123_gen_type [160] = Y3123_pgtype31;
	Y3123_gen_type [161] = Y3123_pgtype32;
	Y3123_gen_type [162] = Y3123_pgtype33;
	Y3123_gen_type [163] = Y3123_pgtype34;
	Y3123_gen_type [164] = Y3123_pgtype35;
	Y3123_gen_type [165] = Y3123_pgtype36;
	Y3123_gen_type [166] = Y3123_pgtype37;
	Y3123_gen_type [167] = Y3123_pgtype38;
	Y3123_gen_type [168] = Y3123_pgtype39;
	Y3123_gen_type [169] = Y3123_pgtype40;
	Y3123_gen_type [170] = Y3123_pgtype41;
	Y3123_gen_type [171] = Y3123_pgtype42;
	Y3123_gen_type [172] = Y3123_pgtype43;
	Y3123_gen_type [173] = Y3123_pgtype44;
	Y3123_gen_type [174] = Y3123_pgtype45;
	Y3123_gen_type [175] = Y3123_pgtype46;
	Y3123_gen_type [176] = Y3123_pgtype47;
	Y3123_gen_type [177] = Y3123_pgtype48;
	Y3123_gen_type [178] = Y3123_pgtype49;
	Y3123_gen_type [179] = Y3123_pgtype50;
	Y3123_gen_type [180] = Y3123_pgtype51;
	Y3123_gen_type [181] = Y3123_pgtype52;
	Y3123_gen_type [182] = Y3123_pgtype53;
	Y3123_gen_type [183] = Y3123_pgtype54;
	Y3123_gen_type [184] = Y3123_pgtype55;
	Y3123_gen_type [185] = Y3123_pgtype56;
	Y3123_gen_type [186] = Y3123_pgtype57;
	Y3123_gen_type [187] = Y3123_pgtype58;
	Y3123_gen_type [188] = Y3123_pgtype59;
	Y3123_gen_type [189] = Y3123_pgtype60;
	Y3123_gen_type [190] = Y3123_pgtype61;
	Y3123_gen_type [191] = Y3123_pgtype62;
	Y3123_gen_type [192] = Y3123_pgtype63;
	Y3123_gen_type [193] = Y3123_pgtype64;
	Y3123_gen_type [194] = Y3123_pgtype65;
	Y3123_gen_type [195] = Y3123_pgtype66;
	Y3123_gen_type [196] = Y3123_pgtype67;
	Y3123_gen_type [197] = Y3123_pgtype68;
	Y3123_gen_type [198] = Y3123_pgtype69;
	Y3123_gen_type [199] = Y3123_pgtype70;
	Y3123_gen_type [200] = Y3123_pgtype71;
	Y3123_gen_type [201] = Y3123_pgtype72;
	Y3123_gen_type [202] = Y3123_pgtype73;
	Y3123_gen_type [203] = Y3123_pgtype74;
	Y3123_gen_type [204] = Y3123_pgtype75;
	Y3123_gen_type [205] = Y3123_pgtype76;
	Y3123_gen_type [206] = Y3123_pgtype77;
	Y3123_gen_type [207] = Y3123_pgtype78;
	Y3123_gen_type [208] = Y3123_pgtype79;
	Y3123_gen_type [209] = Y3123_pgtype80;
	Y3123_gen_type [210] = Y3123_pgtype81;
	Y3123_gen_type [211] = Y3123_pgtype82;
	Y3123_gen_type [212] = Y3123_pgtype83;
	Y3123_gen_type [213] = Y3123_pgtype84;
	Y3123_gen_type [214] = Y3123_pgtype85;
	Y3123_gen_type [215] = Y3123_pgtype86;
	Y3123_gen_type [216] = Y3123_pgtype87;
	Y3123_gen_type [217] = Y3123_pgtype88;
	Y3123_gen_type [218] = Y3123_pgtype89;
	Y3123_gen_type [219] = Y3123_pgtype90;
	Y3123_gen_type [220] = Y3123_pgtype91;
	Y3123_gen_type [221] = Y3123_pgtype92;
	Y3123_gen_type [222] = Y3123_pgtype93;
	Y3123_gen_type [223] = Y3123_pgtype94;
	Y3123_gen_type [224] = Y3123_pgtype95;
	Y3123_gen_type [225] = Y3123_pgtype96;
	Y3123_gen_type [226] = Y3123_pgtype97;
	Y3123_gen_type [227] = Y3123_pgtype98;
	Y3123_gen_type [228] = Y3123_pgtype99;
	Y3123_gen_type [229] = Y3123_pgtype100;
	Y3123_gen_type [230] = Y3123_pgtype101;
	Y3123_gen_type [231] = Y3123_pgtype102;
	Y3123_gen_type [232] = Y3123_pgtype103;
	Y3123_gen_type [233] = Y3123_pgtype104;
	Y3123_gen_type [234] = Y3123_pgtype105;
	Y3123_gen_type [235] = Y3123_pgtype106;
	Y3123_gen_type [236] = Y3123_pgtype107;
	Y3123_gen_type [237] = Y3123_pgtype108;
	Y3123_gen_type [238] = Y3123_pgtype109;
	Y3123_gen_type [239] = Y3123_pgtype110;
	Y3123_gen_type [244] = Y3123_pgtype111;
	Y3123_gen_type [245] = Y3123_pgtype112;
	Y3123_gen_type [246] = Y3123_pgtype113;
	Y3123_gen_type [247] = Y3123_pgtype114;
	Y3123_gen_type [248] = Y3123_pgtype115;
	Y3123_gen_type [249] = Y3123_pgtype116;
	Y3123_gen_type [250] = Y3123_pgtype117;
	Y3123_gen_type [251] = Y3123_pgtype118;
	Y3123_gen_type [252] = Y3123_pgtype119;
	Y3123_gen_type [253] = Y3123_pgtype120;
	Y3123_gen_type [254] = Y3123_pgtype121;
	Y3123_gen_type [255] = Y3123_pgtype122;
	Y3123_gen_type [256] = Y3123_pgtype123;
	Y3123_gen_type [257] = Y3123_pgtype124;
	Y3123_gen_type [258] = Y3123_pgtype125;
	Y3123_gen_type [259] = Y3123_pgtype126;
	Y3123_gen_type [260] = Y3123_pgtype127;
	Y3123_gen_type [261] = Y3123_pgtype128;
	Y3123_gen_type [262] = Y3123_pgtype129;
	Y3123_gen_type [263] = Y3123_pgtype130;
	Y3123_gen_type [382] = Y3123_pgtype131;
	Y3123_gen_type [385] = Y3123_pgtype132;
	Y3123_gen_type [386] = Y3123_pgtype133;
	Y3123_gen_type [870] = Y3123_pgtype134;
	Y3123_gen_type [871] = Y3123_pgtype135;
	{long i; for (i = 159; i < 240; i++) Y3123[i] = 873;};
	{long i; for (i = 244; i < 256; i++) Y3123[i] = 873;};
	{long i; for (i = 261; i < 263; i++) Y3123[i] = 942;};
	Y3123[263] = 950;
	Y3123[382] = 873;
	{long i; for (i = 385; i < 387; i++) Y3123[i] = 873;};
	{long i; for (i = 870; i < 872; i++) Y3123[i] = 873;};
}

char *(*R3145[739])();
void R3145_init () {
	R3145[0] = (char *(*)()) F698_3648;
	R3145[39] = (char *(*)()) F738_4070;
	R3145[40] = (char *(*)()) F739_4070;
	R3145[41] = (char *(*)()) F740_4070;
	R3145[42] = (char *(*)()) F741_4070;
	R3145[43] = (char *(*)()) F742_4070;
	R3145[44] = (char *(*)()) F743_4070;
	R3145[45] = (char *(*)()) F744_4070;
	R3145[46] = (char *(*)()) F745_4070;
	R3145[47] = (char *(*)()) F746_4070;
	R3145[48] = (char *(*)()) F747_4070;
	R3145[49] = (char *(*)()) F748_4070;
	R3145[50] = (char *(*)()) F749_4070;
	R3145[51] = (char *(*)()) F738_4070;
	R3145[52] = (char *(*)()) F740_4070;
	R3145[53] = (char *(*)()) F742_4070;
	R3145[54] = (char *(*)()) F747_4070;
	R3145[55] = (char *(*)()) F741_4070;
	R3145[56] = (char *(*)()) F746_4070;
	R3145[111] = (char *(*)()) F810_4290;
	R3145[112] = (char *(*)()) F811_4290;
	R3145[113] = (char *(*)()) F812_4290;
	R3145[114] = (char *(*)()) F813_4290;
	R3145[115] = (char *(*)()) F814_4290;
	R3145[116] = (char *(*)()) F815_4290;
	R3145[117] = (char *(*)()) F816_4290;
	R3145[118] = (char *(*)()) F817_4290;
	R3145[119] = (char *(*)()) F818_4290;
	R3145[120] = (char *(*)()) F819_4290;
	R3145[121] = (char *(*)()) F820_4290;
	R3145[122] = (char *(*)()) F821_4290;
	R3145[123] = (char *(*)()) F822_4353;
	R3145[124] = (char *(*)()) F823_4353;
	R3145[125] = (char *(*)()) F824_4353;
	R3145[126] = (char *(*)()) F825_4353;
	R3145[127] = (char *(*)()) F826_4353;
	R3145[130] = (char *(*)()) F822_4353;
	R3145[249] = (char *(*)()) F946_5978;
	R3145[252] = (char *(*)()) F949_6146;
	R3145[313] = (char *(*)()) F1012_6810;
	{long i; for (i = 548; i < 550; i++) R3145[i] = (char *(*)()) F698_3648;}
	{long i; for (i = 553; i < 555; i++) R3145[i] = (char *(*)()) F698_3648;}
	{long i; for (i = 737; i < 739; i++) R3145[i] = (char *(*)()) F1436_11354;}
}


#ifdef __cplusplus
}
#endif
