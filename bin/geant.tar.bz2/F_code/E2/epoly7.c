#include "epoly7.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R3148[700])();
void R3148_init () {
	R3148[0] = (char *(*)()) F738_4071;
	R3148[1] = (char *(*)()) F739_4071;
	R3148[2] = (char *(*)()) F740_4071;
	R3148[3] = (char *(*)()) F741_4071;
	R3148[4] = (char *(*)()) F742_4071;
	R3148[5] = (char *(*)()) F743_4071;
	R3148[6] = (char *(*)()) F744_4071;
	R3148[7] = (char *(*)()) F745_4071;
	R3148[8] = (char *(*)()) F746_4071;
	R3148[9] = (char *(*)()) F747_4071;
	R3148[10] = (char *(*)()) F748_4071;
	R3148[11] = (char *(*)()) F749_4071;
	R3148[12] = (char *(*)()) F738_4071;
	R3148[13] = (char *(*)()) F740_4071;
	R3148[14] = (char *(*)()) F742_4071;
	R3148[15] = (char *(*)()) F747_4071;
	R3148[16] = (char *(*)()) F741_4071;
	R3148[17] = (char *(*)()) F746_4071;
	R3148[72] = (char *(*)()) F810_4291;
	R3148[73] = (char *(*)()) F811_4291;
	R3148[74] = (char *(*)()) F812_4291;
	R3148[75] = (char *(*)()) F813_4291;
	R3148[76] = (char *(*)()) F814_4291;
	R3148[77] = (char *(*)()) F815_4291;
	R3148[78] = (char *(*)()) F816_4291;
	R3148[79] = (char *(*)()) F817_4291;
	R3148[80] = (char *(*)()) F818_4291;
	R3148[81] = (char *(*)()) F819_4291;
	R3148[82] = (char *(*)()) F820_4291;
	R3148[83] = (char *(*)()) F821_4291;
	R3148[210] = (char *(*)()) F946_5977;
	R3148[213] = (char *(*)()) F949_6145;
	{long i; for (i = 698; i < 700; i++) R3148[i] = (char *(*)()) F1436_11356;}
}

char *(*R3152[700])();
void R3152_init () {
	R3152[0] = (char *(*)()) F662_3605;
	R3152[1] = (char *(*)()) F663_3605;
	R3152[2] = (char *(*)()) F664_3605;
	R3152[3] = (char *(*)()) F665_3605;
	R3152[4] = (char *(*)()) F666_3605;
	R3152[5] = (char *(*)()) F667_3605;
	R3152[6] = (char *(*)()) F668_3605;
	R3152[7] = (char *(*)()) F669_3605;
	R3152[8] = (char *(*)()) F670_3605;
	R3152[9] = (char *(*)()) F671_3605;
	R3152[10] = (char *(*)()) F672_3605;
	R3152[11] = (char *(*)()) F673_3605;
	R3152[12] = (char *(*)()) F662_3605;
	R3152[13] = (char *(*)()) F664_3605;
	R3152[14] = (char *(*)()) F666_3605;
	R3152[15] = (char *(*)()) F671_3605;
	R3152[16] = (char *(*)()) F665_3605;
	R3152[17] = (char *(*)()) F670_3605;
	R3152[72] = (char *(*)()) F662_3605;
	R3152[73] = (char *(*)()) F663_3605;
	R3152[74] = (char *(*)()) F664_3605;
	R3152[75] = (char *(*)()) F665_3605;
	R3152[76] = (char *(*)()) F666_3605;
	R3152[77] = (char *(*)()) F667_3605;
	R3152[78] = (char *(*)()) F668_3605;
	R3152[79] = (char *(*)()) F669_3605;
	R3152[80] = (char *(*)()) F670_3605;
	R3152[81] = (char *(*)()) F671_3605;
	R3152[82] = (char *(*)()) F672_3605;
	R3152[83] = (char *(*)()) F673_3605;
	R3152[210] = (char *(*)()) F667_3605;
	R3152[213] = (char *(*)()) F666_3605;
	{long i; for (i = 698; i < 700; i++) R3152[i] = (char *(*)()) F666_3605;}
}

char *(*R3159[555])();
void R3159_init () {
	R3159[0] = (char *(*)()) F698_3618;
	R3159[313] = (char *(*)()) F700_3899;
	R3159[548] = (char *(*)()) F700_3899;
	R3159[549] = (char *(*)()) F698_3618;
	R3159[553] = (char *(*)()) F700_3899;
	R3159[554] = (char *(*)()) F698_3618;
}

char *(*R3184[555])();
void R3184_init () {
	R3184[0] = (char *(*)()) F698_3652;
	R3184[313] = (char *(*)()) F1012_6808;
	{long i; for (i = 548; i < 550; i++) R3184[i] = (char *(*)()) F698_3652;}
	{long i; for (i = 553; i < 555; i++) R3184[i] = (char *(*)()) F698_3652;}
}

char *(*R3253[555])();
void R3253_init () {
	R3253[0] = (char *(*)()) F699_3893;
	R3253[313] = (char *(*)()) F698_3776;
	R3253[548] = (char *(*)()) F698_3776;
	R3253[549] = (char *(*)()) F699_3893;
	R3253[553] = (char *(*)()) F698_3776;
	R3253[554] = (char *(*)()) F699_3893;
}

char *(*R3254[555])();
void R3254_init () {
	R3254[0] = (char *(*)()) F698_3777;
	R3254[313] = (char *(*)()) F1012_6864;
	{long i; for (i = 548; i < 550; i++) R3254[i] = (char *(*)()) F698_3777;}
	{long i; for (i = 553; i < 555; i++) R3254[i] = (char *(*)()) F698_3777;}
}

char *(*R3355[725])();
void R3355_init () {
	R3355[0] = (char *(*)()) F713_3972;
	R3355[1] = (char *(*)()) F714_3972_3355_26;
	R3355[2] = (char *(*)()) F715_3972_3355_26;
	R3355[3] = (char *(*)()) F716_3972_3355_26;
	R3355[4] = (char *(*)()) F717_3972_3355_26;
	R3355[5] = (char *(*)()) F718_3972_3355_26;
	R3355[6] = (char *(*)()) F719_3972_3355_26;
	R3355[7] = (char *(*)()) F720_3972_3355_26;
	R3355[8] = (char *(*)()) F721_3972_3355_26;
	R3355[9] = (char *(*)()) F722_3972_3355_26;
	R3355[10] = (char *(*)()) F723_3972_3355_26;
	R3355[11] = (char *(*)()) F724_3972_3355_26;
	R3355[25] = (char *(*)()) F738_4063;
	R3355[26] = (char *(*)()) F739_4063_3355_26;
	R3355[27] = (char *(*)()) F740_4063_3355_26;
	R3355[28] = (char *(*)()) F741_4063_3355_26;
	R3355[29] = (char *(*)()) F742_4063_3355_26;
	R3355[30] = (char *(*)()) F743_4063_3355_26;
	R3355[31] = (char *(*)()) F744_4063_3355_26;
	R3355[32] = (char *(*)()) F745_4063_3355_26;
	R3355[33] = (char *(*)()) F746_4063_3355_26;
	R3355[34] = (char *(*)()) F747_4063_3355_26;
	R3355[35] = (char *(*)()) F748_4063_3355_26;
	R3355[36] = (char *(*)()) F749_4063_3355_26;
	R3355[37] = (char *(*)()) F738_4063;
	R3355[38] = (char *(*)()) F740_4063_3355_26;
	R3355[39] = (char *(*)()) F742_4063_3355_26;
	R3355[40] = (char *(*)()) F747_4063_3355_26;
	R3355[41] = (char *(*)()) F741_4063_3355_26;
	R3355[42] = (char *(*)()) F746_4063_3355_26;
	R3355[97] = (char *(*)()) F810_4275;
	R3355[98] = (char *(*)()) F811_4275_3355_26;
	R3355[99] = (char *(*)()) F812_4275_3355_26;
	R3355[100] = (char *(*)()) F813_4275_3355_26;
	R3355[101] = (char *(*)()) F814_4275_3355_26;
	R3355[102] = (char *(*)()) F815_4275_3355_26;
	R3355[103] = (char *(*)()) F816_4275_3355_26;
	R3355[104] = (char *(*)()) F817_4275_3355_26;
	R3355[105] = (char *(*)()) F818_4275_3355_26;
	R3355[106] = (char *(*)()) F819_4275_3355_26;
	R3355[107] = (char *(*)()) F820_4275_3355_26;
	R3355[108] = (char *(*)()) F821_4275_3355_26;
	R3355[152] = (char *(*)()) F865_4594;
	R3355[234] = (char *(*)()) F947_6016_3355_26;
	R3355[235] = (char *(*)()) F948_6039_3355_26;
	R3355[237] = (char *(*)()) F950_6181_3355_26;
	R3355[238] = (char *(*)()) F951_6203_3355_26;
	{long i; for (i = 723; i < 725; i++) R3355[i] = (char *(*)()) F1436_11338_3355_26;}
}
static EIF_REFERENCE F714_3972_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F714_3972(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F715_3972_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F715_3972(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F716_3972_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F716_3972(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(879, 0x00).id, 879, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F717_3972_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F717_3972(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F718_3972_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F718_3972(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(897, 0x00).id, 897, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F719_3972_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F719_3972(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(888, 0x00).id, 888, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F720_3972_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F720_3972(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(885, 0x00).id, 885, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F721_3972_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F721_3972(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(882, 0x00).id, 882, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F722_3972_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F722_3972(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(903, 0x00).id, 903, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F723_3972_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F723_3972(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(891, 0x00).id, 891, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F724_3972_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F724_3972(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(894, 0x00).id, 894, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F739_4063_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F739_4063(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F740_4063_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F740_4063(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F741_4063_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F741_4063(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(879, 0x00).id, 879, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F742_4063_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F742_4063(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F743_4063_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F743_4063(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(897, 0x00).id, 897, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F744_4063_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F744_4063(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(888, 0x00).id, 888, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F745_4063_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F745_4063(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(885, 0x00).id, 885, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F746_4063_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F746_4063(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(882, 0x00).id, 882, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F747_4063_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F747_4063(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(903, 0x00).id, 903, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F748_4063_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F748_4063(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(891, 0x00).id, 891, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F749_4063_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F749_4063(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(894, 0x00).id, 894, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F811_4275_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F811_4275(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F812_4275_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F812_4275(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F813_4275_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F813_4275(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(879, 0x00).id, 879, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F814_4275_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F814_4275(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F815_4275_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F815_4275(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(897, 0x00).id, 897, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F816_4275_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F816_4275(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(888, 0x00).id, 888, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F817_4275_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F817_4275(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(885, 0x00).id, 885, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F818_4275_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F818_4275(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(882, 0x00).id, 882, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F819_4275_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F819_4275(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(903, 0x00).id, 903, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F820_4275_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F820_4275(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(891, 0x00).id, 891, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F821_4275_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F821_4275(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(894, 0x00).id, 894, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F947_6016_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F947_6016(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(897, 0x00).id, 897, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F948_6039_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F948_6039(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(897, 0x00).id, 897, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F950_6181_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F950_6181(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F951_6203_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F951_6203(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1436_11338_3355_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1436_11338(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R3356[725])();
void R3356_init () {
	R3356[0] = (char *(*)()) F713_3980;
	R3356[1] = (char *(*)()) F714_3980;
	R3356[2] = (char *(*)()) F715_3980;
	R3356[3] = (char *(*)()) F716_3980;
	R3356[4] = (char *(*)()) F717_3980;
	R3356[5] = (char *(*)()) F718_3980;
	R3356[6] = (char *(*)()) F719_3980;
	R3356[7] = (char *(*)()) F720_3980;
	R3356[8] = (char *(*)()) F721_3980;
	R3356[9] = (char *(*)()) F722_3980;
	R3356[10] = (char *(*)()) F723_3980;
	R3356[11] = (char *(*)()) F724_3980;
	R3356[25] = (char *(*)()) F738_4068;
	R3356[26] = (char *(*)()) F739_4068;
	R3356[27] = (char *(*)()) F740_4068;
	R3356[28] = (char *(*)()) F741_4068;
	R3356[29] = (char *(*)()) F742_4068;
	R3356[30] = (char *(*)()) F743_4068;
	R3356[31] = (char *(*)()) F744_4068;
	R3356[32] = (char *(*)()) F745_4068;
	R3356[33] = (char *(*)()) F746_4068;
	R3356[34] = (char *(*)()) F747_4068;
	R3356[35] = (char *(*)()) F748_4068;
	R3356[36] = (char *(*)()) F749_4068;
	R3356[37] = (char *(*)()) F738_4068;
	R3356[38] = (char *(*)()) F740_4068;
	R3356[39] = (char *(*)()) F742_4068;
	R3356[40] = (char *(*)()) F747_4068;
	R3356[41] = (char *(*)()) F741_4068;
	R3356[42] = (char *(*)()) F746_4068;
	R3356[97] = (char *(*)()) F756_4124;
	R3356[98] = (char *(*)()) F757_4124;
	R3356[99] = (char *(*)()) F758_4124;
	R3356[100] = (char *(*)()) F759_4124;
	R3356[101] = (char *(*)()) F760_4124;
	R3356[102] = (char *(*)()) F761_4124;
	R3356[103] = (char *(*)()) F762_4124;
	R3356[104] = (char *(*)()) F763_4124;
	R3356[105] = (char *(*)()) F764_4124;
	R3356[106] = (char *(*)()) F765_4124;
	R3356[107] = (char *(*)()) F766_4124;
	R3356[108] = (char *(*)()) F767_4124;
	R3356[109] = (char *(*)()) F822_4356;
	R3356[110] = (char *(*)()) F823_4356;
	R3356[111] = (char *(*)()) F824_4356;
	R3356[112] = (char *(*)()) F825_4356;
	R3356[113] = (char *(*)()) F826_4356;
	R3356[116] = (char *(*)()) F822_4356;
	R3356[152] = (char *(*)()) F865_4624;
	{long i; for (i = 234; i < 236; i++) R3356[i] = (char *(*)()) F946_5980;}
	{long i; for (i = 237; i < 239; i++) R3356[i] = (char *(*)()) F949_6148;}
	{long i; for (i = 723; i < 725; i++) R3356[i] = (char *(*)()) F949_6148;}
}

EIF_TYPE_INDEX *Y3356_gen_type [737];
EIF_TYPE_INDEX Y3356 [737];
void Y3356_init (void)
{
	egc_routines_types [3356] = Y3356;
	egc_routines_gen_types [3356] = Y3356_gen_type;
	egc_routines_offset [3356] = 700;
	{long i; for (i = 0; i < 105; i++) Y3356[i] = 873;};
	{long i; for (i = 109; i < 129; i++) Y3356[i] = 873;};
	Y3356[164] = 873;
	{long i; for (i = 245; i < 252; i++) Y3356[i] = 873;};
	{long i; for (i = 735; i < 737; i++) Y3356[i] = 873;};
}

char *(*R3357[725])();
void R3357_init () {
	R3357[0] = (char *(*)()) F713_3981;
	R3357[1] = (char *(*)()) F714_3981;
	R3357[2] = (char *(*)()) F715_3981;
	R3357[3] = (char *(*)()) F716_3981;
	R3357[4] = (char *(*)()) F717_3981;
	R3357[5] = (char *(*)()) F718_3981;
	R3357[6] = (char *(*)()) F719_3981;
	R3357[7] = (char *(*)()) F720_3981;
	R3357[8] = (char *(*)()) F721_3981;
	R3357[9] = (char *(*)()) F722_3981;
	R3357[10] = (char *(*)()) F723_3981;
	R3357[11] = (char *(*)()) F724_3981;
	R3357[25] = (char *(*)()) F738_4069;
	R3357[26] = (char *(*)()) F739_4069;
	R3357[27] = (char *(*)()) F740_4069;
	R3357[28] = (char *(*)()) F741_4069;
	R3357[29] = (char *(*)()) F742_4069;
	R3357[30] = (char *(*)()) F743_4069;
	R3357[31] = (char *(*)()) F744_4069;
	R3357[32] = (char *(*)()) F745_4069;
	R3357[33] = (char *(*)()) F746_4069;
	R3357[34] = (char *(*)()) F747_4069;
	R3357[35] = (char *(*)()) F748_4069;
	R3357[36] = (char *(*)()) F749_4069;
	R3357[37] = (char *(*)()) F738_4069;
	R3357[38] = (char *(*)()) F740_4069;
	R3357[39] = (char *(*)()) F742_4069;
	R3357[40] = (char *(*)()) F747_4069;
	R3357[41] = (char *(*)()) F741_4069;
	R3357[42] = (char *(*)()) F746_4069;
	R3357[97] = (char *(*)()) F810_4290;
	R3357[98] = (char *(*)()) F811_4290;
	R3357[99] = (char *(*)()) F812_4290;
	R3357[100] = (char *(*)()) F813_4290;
	R3357[101] = (char *(*)()) F814_4290;
	R3357[102] = (char *(*)()) F815_4290;
	R3357[103] = (char *(*)()) F816_4290;
	R3357[104] = (char *(*)()) F817_4290;
	R3357[105] = (char *(*)()) F818_4290;
	R3357[106] = (char *(*)()) F819_4290;
	R3357[107] = (char *(*)()) F820_4290;
	R3357[108] = (char *(*)()) F821_4290;
	R3357[109] = (char *(*)()) F822_4357;
	R3357[110] = (char *(*)()) F823_4357;
	R3357[111] = (char *(*)()) F824_4357;
	R3357[112] = (char *(*)()) F825_4357;
	R3357[113] = (char *(*)()) F826_4357;
	R3357[116] = (char *(*)()) F822_4357;
	R3357[152] = (char *(*)()) F865_4623;
	{long i; for (i = 234; i < 236; i++) R3357[i] = (char *(*)()) F946_5978;}
	{long i; for (i = 237; i < 239; i++) R3357[i] = (char *(*)()) F949_6146;}
	{long i; for (i = 723; i < 725; i++) R3357[i] = (char *(*)()) F1436_11354;}
}

char *(*R3360[12])();
void R3360_init () {
	R3360[0] = (char *(*)()) F713_3969;
	R3360[1] = (char *(*)()) F714_3969;
	R3360[2] = (char *(*)()) F715_3969;
	R3360[3] = (char *(*)()) F716_3969;
	R3360[4] = (char *(*)()) F717_3969;
	R3360[5] = (char *(*)()) F718_3969;
	R3360[6] = (char *(*)()) F719_3969;
	R3360[7] = (char *(*)()) F720_3969;
	R3360[8] = (char *(*)()) F721_3969;
	R3360[9] = (char *(*)()) F722_3969;
	R3360[10] = (char *(*)()) F723_3969;
	R3360[11] = (char *(*)()) F724_3969;
}

char *(*R3361[12])();
void R3361_init () {
	R3361[0] = (char *(*)()) F713_3970;
	R3361[1] = (char *(*)()) F714_3970_3361_131;
	R3361[2] = (char *(*)()) F715_3970_3361_131;
	R3361[3] = (char *(*)()) F716_3970_3361_131;
	R3361[4] = (char *(*)()) F717_3970_3361_131;
	R3361[5] = (char *(*)()) F718_3970_3361_131;
	R3361[6] = (char *(*)()) F719_3970_3361_131;
	R3361[7] = (char *(*)()) F720_3970_3361_131;
	R3361[8] = (char *(*)()) F721_3970_3361_131;
	R3361[9] = (char *(*)()) F722_3970_3361_131;
	R3361[10] = (char *(*)()) F723_3970_3361_131;
	R3361[11] = (char *(*)()) F724_3970_3361_131;
}
static void F714_3970_3361_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F714_3970(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F715_3970_3361_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F715_3970(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F716_3970_3361_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F716_3970(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F717_3970_3361_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F717_3970(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F718_3970_3361_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F718_3970(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F719_3970_3361_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F719_3970(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F720_3970_3361_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F720_3970(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F721_3970_3361_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F721_3970(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F722_3970_3361_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F722_3970(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F723_3970_3361_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F723_3970(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F724_3970_3361_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F724_3970(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3370[12])();
void R3370_init () {
	R3370[0] = (char *(*)()) F713_3985;
	R3370[1] = (char *(*)()) F714_3985;
	R3370[2] = (char *(*)()) F715_3985;
	R3370[3] = (char *(*)()) F716_3985;
	R3370[4] = (char *(*)()) F717_3985;
	R3370[5] = (char *(*)()) F718_3985;
	R3370[6] = (char *(*)()) F719_3985;
	R3370[7] = (char *(*)()) F720_3985;
	R3370[8] = (char *(*)()) F721_3985;
	R3370[9] = (char *(*)()) F722_3985;
	R3370[10] = (char *(*)()) F723_3985;
	R3370[11] = (char *(*)()) F724_3985;
}

char *(*R3371[12])();
void R3371_init () {
	R3371[0] = (char *(*)()) F713_3987;
	R3371[1] = (char *(*)()) F714_3987_3371_131;
	R3371[2] = (char *(*)()) F715_3987_3371_131;
	R3371[3] = (char *(*)()) F716_3987_3371_131;
	R3371[4] = (char *(*)()) F717_3987_3371_131;
	R3371[5] = (char *(*)()) F718_3987_3371_131;
	R3371[6] = (char *(*)()) F719_3987_3371_131;
	R3371[7] = (char *(*)()) F720_3987_3371_131;
	R3371[8] = (char *(*)()) F721_3987_3371_131;
	R3371[9] = (char *(*)()) F722_3987_3371_131;
	R3371[10] = (char *(*)()) F723_3987_3371_131;
	R3371[11] = (char *(*)()) F724_3987_3371_131;
}
static void F714_3987_3371_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F714_3987(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F715_3987_3371_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F715_3987(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F716_3987_3371_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F716_3987(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F717_3987_3371_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F717_3987(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F718_3987_3371_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F718_3987(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F719_3987_3371_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F719_3987(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F720_3987_3371_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F720_3987(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F721_3987_3371_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F721_3987(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F722_3987_3371_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F722_3987(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F723_3987_3371_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F723_3987(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F724_3987_3371_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F724_3987(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3372[12])();
void R3372_init () {
	R3372[0] = (char *(*)()) F713_3988;
	R3372[1] = (char *(*)()) F714_3988_3372_131;
	R3372[2] = (char *(*)()) F715_3988_3372_131;
	R3372[3] = (char *(*)()) F716_3988_3372_131;
	R3372[4] = (char *(*)()) F717_3988_3372_131;
	R3372[5] = (char *(*)()) F718_3988_3372_131;
	R3372[6] = (char *(*)()) F719_3988_3372_131;
	R3372[7] = (char *(*)()) F720_3988_3372_131;
	R3372[8] = (char *(*)()) F721_3988_3372_131;
	R3372[9] = (char *(*)()) F722_3988_3372_131;
	R3372[10] = (char *(*)()) F723_3988_3372_131;
	R3372[11] = (char *(*)()) F724_3988_3372_131;
}
static void F714_3988_3372_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F714_3988(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F715_3988_3372_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F715_3988(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F716_3988_3372_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F716_3988(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F717_3988_3372_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F717_3988(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F718_3988_3372_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F718_3988(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F719_3988_3372_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F719_3988(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F720_3988_3372_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F720_3988(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F721_3988_3372_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F721_3988(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F722_3988_3372_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F722_3988(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F723_3988_3372_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F723_3988(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F724_3988_3372_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F724_3988(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3373[12])();
void R3373_init () {
	R3373[0] = (char *(*)()) F713_3989;
	R3373[1] = (char *(*)()) F714_3989_3373_4;
	R3373[2] = (char *(*)()) F715_3989_3373_4;
	R3373[3] = (char *(*)()) F716_3989_3373_4;
	R3373[4] = (char *(*)()) F717_3989_3373_4;
	R3373[5] = (char *(*)()) F718_3989_3373_4;
	R3373[6] = (char *(*)()) F719_3989_3373_4;
	R3373[7] = (char *(*)()) F720_3989_3373_4;
	R3373[8] = (char *(*)()) F721_3989_3373_4;
	R3373[9] = (char *(*)()) F722_3989_3373_4;
	R3373[10] = (char *(*)()) F723_3989_3373_4;
	R3373[11] = (char *(*)()) F724_3989_3373_4;
}
static void F714_3989_3373_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F714_3989(Current, *(EIF_POINTER *)arg1);
}
static void F715_3989_3373_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F715_3989(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F716_3989_3373_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F716_3989(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F717_3989_3373_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F717_3989(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F718_3989_3373_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F718_3989(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F719_3989_3373_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F719_3989(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F720_3989_3373_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F720_3989(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F721_3989_3373_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F721_3989(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F722_3989_3373_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F722_3989(Current, *(EIF_BOOLEAN *)arg1);
}
static void F723_3989_3373_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F723_3989(Current, *(EIF_REAL_32 *)arg1);
}
static void F724_3989_3373_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F724_3989(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R3375[12])();
void R3375_init () {
	R3375[0] = (char *(*)()) F713_3991;
	R3375[1] = (char *(*)()) F714_3991_3375_39;
	R3375[2] = (char *(*)()) F715_3991_3375_39;
	R3375[3] = (char *(*)()) F716_3991_3375_39;
	R3375[4] = (char *(*)()) F717_3991_3375_39;
	R3375[5] = (char *(*)()) F718_3991_3375_39;
	R3375[6] = (char *(*)()) F719_3991_3375_39;
	R3375[7] = (char *(*)()) F720_3991_3375_39;
	R3375[8] = (char *(*)()) F721_3991_3375_39;
	R3375[9] = (char *(*)()) F722_3991_3375_39;
	R3375[10] = (char *(*)()) F723_3991_3375_39;
	R3375[11] = (char *(*)()) F724_3991_3375_39;
}
static void F714_3991_3375_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F714_3991(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F715_3991_3375_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F715_3991(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F716_3991_3375_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F716_3991(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F717_3991_3375_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F717_3991(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F718_3991_3375_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F718_3991(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F719_3991_3375_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F719_3991(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F720_3991_3375_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F720_3991(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F721_3991_3375_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F721_3991(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F722_3991_3375_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F722_3991(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F723_3991_3375_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F723_3991(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F724_3991_3375_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F724_3991(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R3378[12])();
void R3378_init () {
	R3378[0] = (char *(*)()) F713_3994;
	R3378[1] = (char *(*)()) F714_3994;
	R3378[2] = (char *(*)()) F715_3994;
	R3378[3] = (char *(*)()) F716_3994;
	R3378[4] = (char *(*)()) F717_3994;
	R3378[5] = (char *(*)()) F718_3994;
	R3378[6] = (char *(*)()) F719_3994;
	R3378[7] = (char *(*)()) F720_3994;
	R3378[8] = (char *(*)()) F721_3994;
	R3378[9] = (char *(*)()) F722_3994;
	R3378[10] = (char *(*)()) F723_3994;
	R3378[11] = (char *(*)()) F724_3994;
}

char *(*R3379[12])();
void R3379_init () {
	R3379[0] = (char *(*)()) F713_3995;
	R3379[1] = (char *(*)()) F714_3995;
	R3379[2] = (char *(*)()) F715_3995;
	R3379[3] = (char *(*)()) F716_3995;
	R3379[4] = (char *(*)()) F717_3995;
	R3379[5] = (char *(*)()) F718_3995;
	R3379[6] = (char *(*)()) F719_3995;
	R3379[7] = (char *(*)()) F720_3995;
	R3379[8] = (char *(*)()) F721_3995;
	R3379[9] = (char *(*)()) F722_3995;
	R3379[10] = (char *(*)()) F723_3995;
	R3379[11] = (char *(*)()) F724_3995;
}

char *(*R3380[12])();
void R3380_init () {
	R3380[0] = (char *(*)()) F713_3996;
	R3380[1] = (char *(*)()) F714_3996;
	R3380[2] = (char *(*)()) F715_3996;
	R3380[3] = (char *(*)()) F716_3996;
	R3380[4] = (char *(*)()) F717_3996;
	R3380[5] = (char *(*)()) F718_3996;
	R3380[6] = (char *(*)()) F719_3996;
	R3380[7] = (char *(*)()) F720_3996;
	R3380[8] = (char *(*)()) F721_3996;
	R3380[9] = (char *(*)()) F722_3996;
	R3380[10] = (char *(*)()) F723_3996;
	R3380[11] = (char *(*)()) F724_3996;
}

char *(*R3381[12])();
void R3381_init () {
	R3381[0] = (char *(*)()) F713_3997;
	R3381[1] = (char *(*)()) F714_3997;
	R3381[2] = (char *(*)()) F715_3997;
	R3381[3] = (char *(*)()) F716_3997;
	R3381[4] = (char *(*)()) F717_3997;
	R3381[5] = (char *(*)()) F718_3997;
	R3381[6] = (char *(*)()) F719_3997;
	R3381[7] = (char *(*)()) F720_3997;
	R3381[8] = (char *(*)()) F721_3997;
	R3381[9] = (char *(*)()) F722_3997;
	R3381[10] = (char *(*)()) F723_3997;
	R3381[11] = (char *(*)()) F724_3997;
}

char *(*R3382[12])();
void R3382_init () {
	R3382[0] = (char *(*)()) F713_3998;
	R3382[1] = (char *(*)()) F714_3998;
	R3382[2] = (char *(*)()) F715_3998;
	R3382[3] = (char *(*)()) F716_3998;
	R3382[4] = (char *(*)()) F717_3998;
	R3382[5] = (char *(*)()) F718_3998;
	R3382[6] = (char *(*)()) F719_3998;
	R3382[7] = (char *(*)()) F720_3998;
	R3382[8] = (char *(*)()) F721_3998;
	R3382[9] = (char *(*)()) F722_3998;
	R3382[10] = (char *(*)()) F723_3998;
	R3382[11] = (char *(*)()) F724_3998;
}

char *(*R3386[12])();
void R3386_init () {
	R3386[0] = (char *(*)()) F713_4002;
	R3386[1] = (char *(*)()) F714_4002;
	R3386[2] = (char *(*)()) F715_4002;
	R3386[3] = (char *(*)()) F716_4002;
	R3386[4] = (char *(*)()) F717_4002;
	R3386[5] = (char *(*)()) F718_4002;
	R3386[6] = (char *(*)()) F719_4002;
	R3386[7] = (char *(*)()) F720_4002;
	R3386[8] = (char *(*)()) F721_4002;
	R3386[9] = (char *(*)()) F722_4002;
	R3386[10] = (char *(*)()) F723_4002;
	R3386[11] = (char *(*)()) F724_4002;
}

char *(*R3388[12])();
void R3388_init () {
	R3388[0] = (char *(*)()) F713_4004;
	R3388[1] = (char *(*)()) F714_4004;
	R3388[2] = (char *(*)()) F715_4004;
	R3388[3] = (char *(*)()) F716_4004;
	R3388[4] = (char *(*)()) F717_4004;
	R3388[5] = (char *(*)()) F718_4004;
	R3388[6] = (char *(*)()) F719_4004;
	R3388[7] = (char *(*)()) F720_4004;
	R3388[8] = (char *(*)()) F721_4004;
	R3388[9] = (char *(*)()) F722_4004;
	R3388[10] = (char *(*)()) F723_4004;
	R3388[11] = (char *(*)()) F724_4004;
}

char *(*R3389[12])();
void R3389_init () {
	R3389[0] = (char *(*)()) F713_4005;
	R3389[1] = (char *(*)()) F714_4005_3389_27;
	R3389[2] = (char *(*)()) F715_4005_3389_27;
	R3389[3] = (char *(*)()) F716_4005_3389_27;
	R3389[4] = (char *(*)()) F717_4005_3389_27;
	R3389[5] = (char *(*)()) F718_4005_3389_27;
	R3389[6] = (char *(*)()) F719_4005_3389_27;
	R3389[7] = (char *(*)()) F720_4005_3389_27;
	R3389[8] = (char *(*)()) F721_4005_3389_27;
	R3389[9] = (char *(*)()) F722_4005_3389_27;
	R3389[10] = (char *(*)()) F723_4005_3389_27;
	R3389[11] = (char *(*)()) F724_4005_3389_27;
}
static EIF_REFERENCE F714_4005_3389_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F714_4005(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F715_4005_3389_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F715_4005(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F716_4005_3389_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F716_4005(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F717_4005_3389_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F717_4005(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F718_4005_3389_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F718_4005(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F719_4005_3389_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F719_4005(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F720_4005_3389_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F720_4005(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F721_4005_3389_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F721_4005(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F722_4005_3389_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F722_4005(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F723_4005_3389_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F723_4005(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F724_4005_3389_27 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F724_4005(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3391[12])();
void R3391_init () {
	R3391[0] = (char *(*)()) F713_4007;
	R3391[1] = (char *(*)()) F714_4007;
	R3391[2] = (char *(*)()) F715_4007;
	R3391[3] = (char *(*)()) F716_4007;
	R3391[4] = (char *(*)()) F717_4007;
	R3391[5] = (char *(*)()) F718_4007;
	R3391[6] = (char *(*)()) F719_4007;
	R3391[7] = (char *(*)()) F720_4007;
	R3391[8] = (char *(*)()) F721_4007;
	R3391[9] = (char *(*)()) F722_4007;
	R3391[10] = (char *(*)()) F723_4007;
	R3391[11] = (char *(*)()) F724_4007;
}

char *(*R3400[12])();
void R3400_init () {
	R3400[0] = (char *(*)()) F713_4017;
	R3400[1] = (char *(*)()) F714_4017;
	R3400[2] = (char *(*)()) F715_4017;
	R3400[3] = (char *(*)()) F716_4017;
	R3400[4] = (char *(*)()) F717_4017;
	R3400[5] = (char *(*)()) F718_4017;
	R3400[6] = (char *(*)()) F719_4017;
	R3400[7] = (char *(*)()) F720_4017;
	R3400[8] = (char *(*)()) F721_4017;
	R3400[9] = (char *(*)()) F722_4017;
	R3400[10] = (char *(*)()) F723_4017;
	R3400[11] = (char *(*)()) F724_4017;
}

char *(*R3420[18])();
void R3420_init () {
	R3420[0] = (char *(*)()) F738_4057;
	R3420[1] = (char *(*)()) F739_4057;
	R3420[2] = (char *(*)()) F740_4057;
	R3420[3] = (char *(*)()) F741_4057;
	R3420[4] = (char *(*)()) F742_4057;
	R3420[5] = (char *(*)()) F743_4057;
	R3420[6] = (char *(*)()) F744_4057;
	R3420[7] = (char *(*)()) F745_4057;
	R3420[8] = (char *(*)()) F746_4057;
	R3420[9] = (char *(*)()) F747_4057;
	R3420[10] = (char *(*)()) F748_4057;
	R3420[11] = (char *(*)()) F749_4057;
	R3420[12] = (char *(*)()) F738_4057;
	R3420[13] = (char *(*)()) F740_4057;
	R3420[14] = (char *(*)()) F742_4057;
	R3420[15] = (char *(*)()) F747_4057;
	R3420[16] = (char *(*)()) F741_4057;
	R3420[17] = (char *(*)()) F746_4057;
}

char *(*R3421[18])();
void R3421_init () {
	R3421[0] = (char *(*)()) F738_4058;
	R3421[1] = (char *(*)()) F739_4058_3421_39;
	R3421[2] = (char *(*)()) F740_4058_3421_39;
	R3421[3] = (char *(*)()) F741_4058_3421_39;
	R3421[4] = (char *(*)()) F742_4058_3421_39;
	R3421[5] = (char *(*)()) F743_4058_3421_39;
	R3421[6] = (char *(*)()) F744_4058_3421_39;
	R3421[7] = (char *(*)()) F745_4058_3421_39;
	R3421[8] = (char *(*)()) F746_4058_3421_39;
	R3421[9] = (char *(*)()) F747_4058_3421_39;
	R3421[10] = (char *(*)()) F748_4058_3421_39;
	R3421[11] = (char *(*)()) F749_4058_3421_39;
	R3421[12] = (char *(*)()) F738_4058;
	R3421[13] = (char *(*)()) F740_4058_3421_39;
	R3421[14] = (char *(*)()) F742_4058_3421_39;
	R3421[15] = (char *(*)()) F747_4058_3421_39;
	R3421[16] = (char *(*)()) F741_4058_3421_39;
	R3421[17] = (char *(*)()) F746_4058_3421_39;
}
static void F739_4058_3421_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F739_4058(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F740_4058_3421_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F740_4058(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F741_4058_3421_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F741_4058(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F742_4058_3421_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F742_4058(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F743_4058_3421_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F743_4058(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F744_4058_3421_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F744_4058(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F745_4058_3421_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F745_4058(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F746_4058_3421_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F746_4058(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F747_4058_3421_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F747_4058(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F748_4058_3421_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F748_4058(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F749_4058_3421_39 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F749_4058(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R3423[18])();
void R3423_init () {
	R3423[0] = (char *(*)()) F738_4060;
	R3423[1] = (char *(*)()) F739_4060;
	R3423[2] = (char *(*)()) F740_4060;
	R3423[3] = (char *(*)()) F741_4060;
	R3423[4] = (char *(*)()) F742_4060;
	R3423[5] = (char *(*)()) F743_4060;
	R3423[6] = (char *(*)()) F744_4060;
	R3423[7] = (char *(*)()) F745_4060;
	R3423[8] = (char *(*)()) F746_4060;
	R3423[9] = (char *(*)()) F747_4060;
	R3423[10] = (char *(*)()) F748_4060;
	R3423[11] = (char *(*)()) F749_4060;
	R3423[12] = (char *(*)()) F738_4060;
	R3423[13] = (char *(*)()) F740_4060;
	R3423[14] = (char *(*)()) F742_4060;
	R3423[15] = (char *(*)()) F747_4060;
	R3423[16] = (char *(*)()) F741_4060;
	R3423[17] = (char *(*)()) F746_4060;
}

char *(*R3424[18])();
void R3424_init () {
	R3424[0] = (char *(*)()) F738_4061;
	R3424[1] = (char *(*)()) F739_4061;
	R3424[2] = (char *(*)()) F740_4061;
	R3424[3] = (char *(*)()) F741_4061;
	R3424[4] = (char *(*)()) F742_4061;
	R3424[5] = (char *(*)()) F743_4061;
	R3424[6] = (char *(*)()) F744_4061;
	R3424[7] = (char *(*)()) F745_4061;
	R3424[8] = (char *(*)()) F746_4061;
	R3424[9] = (char *(*)()) F747_4061;
	R3424[10] = (char *(*)()) F748_4061;
	R3424[11] = (char *(*)()) F749_4061;
	R3424[12] = (char *(*)()) F738_4061;
	R3424[13] = (char *(*)()) F740_4061;
	R3424[14] = (char *(*)()) F742_4061;
	R3424[15] = (char *(*)()) F747_4061;
	R3424[16] = (char *(*)()) F741_4061;
	R3424[17] = (char *(*)()) F746_4061;
}

char *(*R3434[18])();
void R3434_init () {
	R3434[0] = (char *(*)()) F738_4087;
	R3434[1] = (char *(*)()) F739_4087;
	R3434[2] = (char *(*)()) F740_4087;
	R3434[3] = (char *(*)()) F741_4087;
	R3434[4] = (char *(*)()) F742_4087;
	R3434[5] = (char *(*)()) F743_4087;
	R3434[6] = (char *(*)()) F744_4087;
	R3434[7] = (char *(*)()) F745_4087;
	R3434[8] = (char *(*)()) F746_4087;
	R3434[9] = (char *(*)()) F747_4087;
	R3434[10] = (char *(*)()) F748_4087;
	R3434[11] = (char *(*)()) F749_4087;
	R3434[12] = (char *(*)()) F738_4087;
	R3434[13] = (char *(*)()) F740_4087;
	R3434[14] = (char *(*)()) F742_4087;
	R3434[15] = (char *(*)()) F747_4087;
	R3434[16] = (char *(*)()) F741_4087;
	R3434[17] = (char *(*)()) F746_4087;
}

char *(*R3455[18])();
void R3455_init () {
	R3455[0] = (char *(*)()) F738_4115;
	R3455[1] = (char *(*)()) F739_4115;
	R3455[2] = (char *(*)()) F740_4115;
	R3455[3] = (char *(*)()) F741_4115;
	R3455[4] = (char *(*)()) F742_4115;
	R3455[5] = (char *(*)()) F743_4115;
	R3455[6] = (char *(*)()) F744_4115;
	R3455[7] = (char *(*)()) F745_4115;
	R3455[8] = (char *(*)()) F746_4115;
	R3455[9] = (char *(*)()) F747_4115;
	R3455[10] = (char *(*)()) F748_4115;
	R3455[11] = (char *(*)()) F749_4115;
	R3455[12] = (char *(*)()) F738_4115;
	R3455[13] = (char *(*)()) F740_4115;
	R3455[14] = (char *(*)()) F742_4115;
	R3455[15] = (char *(*)()) F747_4115;
	R3455[16] = (char *(*)()) F741_4115;
	R3455[17] = (char *(*)()) F746_4115;
}

char *(*R3458[6])();
void R3458_init () {
	R3458[0] = (char *(*)()) F750_4116;
	R3458[1] = (char *(*)()) F751_4116;
	R3458[2] = (char *(*)()) F752_4116;
	R3458[3] = (char *(*)()) F753_4116;
	R3458[4] = (char *(*)()) F754_4116;
	R3458[5] = (char *(*)()) F755_4116;
}

char *(*R3508[628])();
void R3508_init () {
	R3508[0] = (char *(*)()) F810_4330;
	R3508[1] = (char *(*)()) F811_4330;
	R3508[2] = (char *(*)()) F812_4330;
	R3508[3] = (char *(*)()) F813_4330;
	R3508[4] = (char *(*)()) F814_4330;
	R3508[5] = (char *(*)()) F815_4330;
	R3508[6] = (char *(*)()) F816_4330;
	R3508[7] = (char *(*)()) F817_4330;
	R3508[8] = (char *(*)()) F818_4330;
	R3508[9] = (char *(*)()) F819_4330;
	R3508[10] = (char *(*)()) F820_4330;
	R3508[11] = (char *(*)()) F821_4330;
	R3508[12] = (char *(*)()) F822_4394;
	R3508[13] = (char *(*)()) F823_4394;
	R3508[14] = (char *(*)()) F824_4394;
	R3508[15] = (char *(*)()) F825_4394;
	R3508[16] = (char *(*)()) F826_4394;
	R3508[19] = (char *(*)()) F822_4394;
	R3508[55] = (char *(*)()) F865_4702;
	{long i; for (i = 129; i < 133; i++) R3508[i] = (char *(*)()) F938_5793;}
	R3508[137] = (char *(*)()) F947_6032;
	R3508[138] = (char *(*)()) F948_6123;
	R3508[141] = (char *(*)()) F951_6287;
	R3508[276] = (char *(*)()) F1077_7434;
	R3508[277] = (char *(*)()) F1079_7434;
	R3508[288] = (char *(*)()) F1077_7434;
	R3508[289] = (char *(*)()) F1078_7434;
	R3508[290] = (char *(*)()) F1080_7434;
	R3508[291] = (char *(*)()) F1081_7434;
	R3508[292] = (char *(*)()) F1079_7434;
	R3508[296] = (char *(*)()) F1106_7480;
	R3508[297] = (char *(*)()) F1107_7480;
	R3508[396] = (char *(*)()) F1206_8139;
	R3508[397] = (char *(*)()) F1207_8139;
	R3508[398] = (char *(*)()) F1208_8139;
	R3508[399] = (char *(*)()) F1209_8220;
	R3508[400] = (char *(*)()) F1210_8220;
	R3508[401] = (char *(*)()) F1209_8220;
	R3508[411] = (char *(*)()) F1219_8380;
	R3508[412] = (char *(*)()) F1220_8380;
	R3508[423] = (char *(*)()) F1228_8464;
	R3508[424] = (char *(*)()) F1229_8464;
	R3508[425] = (char *(*)()) F1230_8464;
	R3508[426] = (char *(*)()) F1231_8464;
	R3508[427] = (char *(*)()) F1232_8464;
	{long i; for (i = 428; i < 430; i++) R3508[i] = (char *(*)()) F1228_8464;}
	R3508[544] = (char *(*)()) F1228_8464;
	{long i; for (i = 626; i < 628; i++) R3508[i] = (char *(*)()) F951_6287;}
}

char *(*R3528[12])();
void R3528_init () {
	R3528[0] = (char *(*)()) F810_4292;
	R3528[1] = (char *(*)()) F811_4292;
	R3528[2] = (char *(*)()) F812_4292;
	R3528[3] = (char *(*)()) F813_4292;
	R3528[4] = (char *(*)()) F814_4292;
	R3528[5] = (char *(*)()) F815_4292;
	R3528[6] = (char *(*)()) F816_4292;
	R3528[7] = (char *(*)()) F817_4292;
	R3528[8] = (char *(*)()) F818_4292;
	R3528[9] = (char *(*)()) F819_4292;
	R3528[10] = (char *(*)()) F820_4292;
	R3528[11] = (char *(*)()) F821_4292;
}

char *(*R3535[8])();
void R3535_init () {
	R3535[0] = (char *(*)()) F822_4335;
	R3535[1] = (char *(*)()) F823_4335;
	R3535[2] = (char *(*)()) F824_4335;
	R3535[3] = (char *(*)()) F825_4335;
	R3535[4] = (char *(*)()) F826_4335;
	R3535[7] = (char *(*)()) F822_4335;
}

char *(*R3538[8])();
void R3538_init () {
	R3538[0] = (char *(*)()) F822_4338;
	R3538[1] = (char *(*)()) F823_4338;
	R3538[2] = (char *(*)()) F824_4338;
	R3538[3] = (char *(*)()) F825_4338;
	R3538[4] = (char *(*)()) F826_4338;
	R3538[7] = (char *(*)()) F822_4338;
}

char *(*R3539[8])();
void R3539_init () {
	R3539[0] = (char *(*)()) F822_4339;
	R3539[1] = (char *(*)()) F823_4339_3539_1;
	R3539[2] = (char *(*)()) F824_4339;
	R3539[3] = (char *(*)()) F825_4339_3539_1;
	R3539[4] = (char *(*)()) F826_4339_3539_1;
	R3539[7] = (char *(*)()) F822_4339;
}
static EIF_REFERENCE F823_4339_3539_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F823_4339(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F825_4339_3539_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F825_4339(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F826_4339_3539_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F826_4339(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R3547[8])();
void R3547_init () {
	R3547[0] = (char *(*)()) F822_4352;
	R3547[1] = (char *(*)()) F823_4352;
	R3547[2] = (char *(*)()) F824_4352_3547_23;
	R3547[3] = (char *(*)()) F825_4352;
	R3547[4] = (char *(*)()) F826_4352_3547_23;
	R3547[7] = (char *(*)()) F822_4352;
}
static EIF_INTEGER_32 F824_4352_3547_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F824_4352(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F826_4352_3547_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F826_4352(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3549[8])();
void R3549_init () {
	R3549[0] = (char *(*)()) F822_4359;
	R3549[1] = (char *(*)()) F823_4359;
	R3549[2] = (char *(*)()) F824_4359_3549_3;
	R3549[3] = (char *(*)()) F825_4359;
	R3549[4] = (char *(*)()) F826_4359_3549_3;
	R3549[7] = (char *(*)()) F822_4359;
}
static EIF_BOOLEAN F824_4359_3549_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F824_4359(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F826_4359_3549_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F826_4359(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R3555[8])();
void R3555_init () {
	R3555[0] = (char *(*)()) F822_4367;
	R3555[1] = (char *(*)()) F823_4367;
	R3555[2] = (char *(*)()) F824_4367;
	R3555[3] = (char *(*)()) F825_4367;
	R3555[4] = (char *(*)()) F826_4367;
	R3555[7] = (char *(*)()) F822_4367;
}

char *(*R3556[8])();
void R3556_init () {
	R3556[0] = (char *(*)()) F822_4368;
	R3556[1] = (char *(*)()) F823_4368;
	R3556[2] = (char *(*)()) F824_4368;
	R3556[3] = (char *(*)()) F825_4368;
	R3556[4] = (char *(*)()) F826_4368;
	R3556[7] = (char *(*)()) F822_4368;
}

char *(*R3564[8])();
void R3564_init () {
	R3564[0] = (char *(*)()) F822_4377;
	R3564[1] = (char *(*)()) F823_4377;
	R3564[2] = (char *(*)()) F824_4377_3564_4;
	R3564[3] = (char *(*)()) F825_4377;
	R3564[4] = (char *(*)()) F826_4377_3564_4;
	R3564[7] = (char *(*)()) F822_4377;
}
static void F824_4377_3564_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F824_4377(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F826_4377_3564_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F826_4377(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3566[8])();
void R3566_init () {
	R3566[0] = (char *(*)()) F822_4379;
	R3566[1] = (char *(*)()) F823_4379;
	R3566[2] = (char *(*)()) F824_4379;
	R3566[3] = (char *(*)()) F825_4379;
	R3566[4] = (char *(*)()) F826_4379;
	R3566[7] = (char *(*)()) F822_4379;
}

char *(*R3567[8])();
void R3567_init () {
	R3567[0] = (char *(*)()) F822_4380;
	R3567[1] = (char *(*)()) F823_4380;
	R3567[2] = (char *(*)()) F824_4380;
	R3567[3] = (char *(*)()) F825_4380;
	R3567[4] = (char *(*)()) F826_4380;
	R3567[7] = (char *(*)()) F822_4380;
}

char *(*R3573[8])();
void R3573_init () {
	R3573[0] = (char *(*)()) F822_4393;
	R3573[1] = (char *(*)()) F823_4393;
	R3573[2] = (char *(*)()) F824_4393;
	R3573[3] = (char *(*)()) F825_4393;
	R3573[4] = (char *(*)()) F826_4393;
	R3573[7] = (char *(*)()) F822_4393;
}

char *(*R3582[8])();
void R3582_init () {
	R3582[0] = (char *(*)()) F822_4403;
	R3582[1] = (char *(*)()) F823_4403;
	R3582[2] = (char *(*)()) F824_4403;
	R3582[3] = (char *(*)()) F825_4403;
	R3582[4] = (char *(*)()) F826_4403;
	R3582[7] = (char *(*)()) F822_4403;
}

char *(*R3583[8])();
void R3583_init () {
	R3583[0] = (char *(*)()) F822_4404;
	R3583[1] = (char *(*)()) F823_4404;
	R3583[2] = (char *(*)()) F824_4404;
	R3583[3] = (char *(*)()) F825_4404;
	R3583[4] = (char *(*)()) F826_4404;
	R3583[7] = (char *(*)()) F822_4404;
}

char *(*R3590[8])();
void R3590_init () {
	R3590[0] = (char *(*)()) F822_4411;
	R3590[1] = (char *(*)()) F823_4411_3590_1;
	R3590[2] = (char *(*)()) F824_4411;
	R3590[3] = (char *(*)()) F825_4411_3590_1;
	R3590[4] = (char *(*)()) F826_4411_3590_1;
	R3590[7] = (char *(*)()) F822_4411;
}
static EIF_REFERENCE F823_4411_3590_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F823_4411(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F825_4411_3590_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F825_4411(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F826_4411_3590_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F826_4411(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R3591[8])();
void R3591_init () {
	R3591[0] = (char *(*)()) F822_4412;
	R3591[1] = (char *(*)()) F823_4412;
	R3591[2] = (char *(*)()) F824_4412_3591_1;
	R3591[3] = (char *(*)()) F825_4412;
	R3591[4] = (char *(*)()) F826_4412_3591_1;
	R3591[7] = (char *(*)()) F822_4412;
}
static EIF_REFERENCE F824_4412_3591_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F824_4412(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F826_4412_3591_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F826_4412(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R3592[8])();
void R3592_init () {
	R3592[0] = (char *(*)()) F822_4413;
	R3592[1] = (char *(*)()) F823_4413;
	R3592[2] = (char *(*)()) F824_4413;
	R3592[3] = (char *(*)()) F825_4413;
	R3592[4] = (char *(*)()) F826_4413;
	R3592[7] = (char *(*)()) F822_4413;
}

char *(*R3593[8])();
void R3593_init () {
	R3593[0] = (char *(*)()) F822_4414;
	R3593[1] = (char *(*)()) F823_4414;
	R3593[2] = (char *(*)()) F824_4414;
	R3593[3] = (char *(*)()) F825_4414;
	R3593[4] = (char *(*)()) F826_4414;
	R3593[7] = (char *(*)()) F822_4414;
}

char *(*R3596[8])();
void R3596_init () {
	R3596[0] = (char *(*)()) F822_4417;
	R3596[1] = (char *(*)()) F823_4417;
	R3596[2] = (char *(*)()) F824_4417;
	R3596[3] = (char *(*)()) F825_4417;
	R3596[4] = (char *(*)()) F826_4417;
	R3596[7] = (char *(*)()) F822_4417;
}

char *(*R3598[8])();
void R3598_init () {
	R3598[0] = (char *(*)()) F822_4419;
	R3598[1] = (char *(*)()) F823_4419;
	R3598[2] = (char *(*)()) F824_4419;
	R3598[3] = (char *(*)()) F825_4419;
	R3598[4] = (char *(*)()) F826_4419;
	R3598[7] = (char *(*)()) F822_4419;
}

char *(*R3599[8])();
void R3599_init () {
	R3599[0] = (char *(*)()) F822_4420;
	R3599[1] = (char *(*)()) F823_4420;
	R3599[2] = (char *(*)()) F824_4420;
	R3599[3] = (char *(*)()) F825_4420;
	R3599[4] = (char *(*)()) F826_4420;
	R3599[7] = (char *(*)()) F822_4420;
}

char *(*R3600[8])();
void R3600_init () {
	R3600[0] = (char *(*)()) F822_4421;
	R3600[1] = (char *(*)()) F823_4421;
	R3600[2] = (char *(*)()) F824_4421;
	R3600[3] = (char *(*)()) F825_4421;
	R3600[4] = (char *(*)()) F826_4421;
	R3600[7] = (char *(*)()) F822_4421;
}

char *(*R3604[8])();
void R3604_init () {
	R3604[0] = (char *(*)()) F822_4425;
	R3604[1] = (char *(*)()) F823_4425;
	R3604[2] = (char *(*)()) F824_4425_3604_4;
	R3604[3] = (char *(*)()) F825_4425;
	R3604[4] = (char *(*)()) F826_4425_3604_4;
	R3604[7] = (char *(*)()) F822_4425;
}
static void F824_4425_3604_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F824_4425(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F826_4425_3604_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F826_4425(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3610[8])();
void R3610_init () {
	R3610[0] = (char *(*)()) F822_4431;
	R3610[1] = (char *(*)()) F823_4431;
	R3610[2] = (char *(*)()) F824_4431;
	R3610[3] = (char *(*)()) F825_4431;
	R3610[4] = (char *(*)()) F826_4431;
	R3610[7] = (char *(*)()) F822_4431;
}

char *(*R3623[8])();
void R3623_init () {
	R3623[0] = (char *(*)()) F822_4444;
	R3623[1] = (char *(*)()) F823_4444;
	R3623[2] = (char *(*)()) F824_4444;
	R3623[3] = (char *(*)()) F825_4444;
	R3623[4] = (char *(*)()) F826_4444;
	R3623[7] = (char *(*)()) F822_4444;
}

char *(*R3640[606])();
void R3640_init () {
	R3640[0] = (char *(*)()) F832_4472;
	R3640[1] = (char *(*)()) F833_4526;
	R3640[2] = (char *(*)()) F834_4568;
	R3640[3] = (char *(*)()) F835_4568;
	R3640[4] = (char *(*)()) F836_4568;
	R3640[5] = (char *(*)()) F837_4568;
	R3640[6] = (char *(*)()) F838_4568;
	R3640[7] = (char *(*)()) F839_4568;
	R3640[8] = (char *(*)()) F840_4568;
	R3640[9] = (char *(*)()) F841_4568;
	R3640[10] = (char *(*)()) F842_4568;
	R3640[11] = (char *(*)()) F843_4568;
	R3640[12] = (char *(*)()) F844_4568;
	R3640[13] = (char *(*)()) F845_4568;
	R3640[14] = (char *(*)()) F846_4568;
	R3640[15] = (char *(*)()) F847_4568;
	R3640[16] = (char *(*)()) F848_4568;
	R3640[17] = (char *(*)()) F849_4568;
	R3640[18] = (char *(*)()) F850_4568;
	R3640[19] = (char *(*)()) F851_4568;
	R3640[20] = (char *(*)()) F852_4568;
	R3640[21] = (char *(*)()) F853_4568;
	R3640[22] = (char *(*)()) F854_4568;
	R3640[23] = (char *(*)()) F855_4568;
	R3640[24] = (char *(*)()) F856_4568;
	R3640[25] = (char *(*)()) F857_4568;
	R3640[26] = (char *(*)()) F858_4568;
	R3640[27] = (char *(*)()) F859_4568;
	R3640[28] = (char *(*)()) F860_4568;
	R3640[29] = (char *(*)()) F861_4568;
	R3640[30] = (char *(*)()) F862_4568;
	R3640[31] = (char *(*)()) F863_4568;
	R3640[32] = (char *(*)()) F864_4568;
	R3640[33] = (char *(*)()) F865_4620;
	{long i; for (i = 35; i < 37; i++) R3640[i] = (char *(*)()) F866_4727;}
	{long i; for (i = 38; i < 40; i++) R3640[i] = (char *(*)()) F869_4826;}
	{long i; for (i = 41; i < 43; i++) R3640[i] = (char *(*)()) F872_4924;}
	{long i; for (i = 44; i < 46; i++) R3640[i] = (char *(*)()) F875_5023;}
	{long i; for (i = 47; i < 49; i++) R3640[i] = (char *(*)()) F878_5122;}
	{long i; for (i = 50; i < 52; i++) R3640[i] = (char *(*)()) F881_5216;}
	{long i; for (i = 53; i < 55; i++) R3640[i] = (char *(*)()) F884_5310;}
	{long i; for (i = 56; i < 58; i++) R3640[i] = (char *(*)()) F887_5405;}
	{long i; for (i = 59; i < 61; i++) R3640[i] = (char *(*)()) F890_5500;}
	{long i; for (i = 62; i < 64; i++) R3640[i] = (char *(*)()) F893_5566;}
	{long i; for (i = 65; i < 67; i++) R3640[i] = (char *(*)()) F896_5633;}
	{long i; for (i = 68; i < 70; i++) R3640[i] = (char *(*)()) F899_5674;}
	{long i; for (i = 71; i < 73; i++) R3640[i] = (char *(*)()) F902_5722;}
	{long i; for (i = 74; i < 104; i++) R3640[i] = (char *(*)()) F905_5743;}
	R3640[104] = (char *(*)()) F936_5769;
	R3640[105] = (char *(*)()) F937_5769;
	{long i; for (i = 107; i < 111; i++) R3640[i] = (char *(*)()) F938_5777;}
	{long i; for (i = 115; i < 117; i++) R3640[i] = (char *(*)()) F943_5836;}
	{long i; for (i = 118; i < 120; i++) R3640[i] = (char *(*)()) F943_5836;}
	R3640[150] = (char *(*)()) F982_6638;
	R3640[153] = (char *(*)()) F985_6670;
	R3640[409] = (char *(*)()) F1241_8483;
	R3640[428] = (char *(*)()) F1260_8758;
	{long i; for (i = 474; i < 476; i++) R3640[i] = (char *(*)()) F1306_9630;}
	{long i; for (i = 604; i < 606; i++) R3640[i] = (char *(*)()) F1436_11349;}
}

char *(*R3728[31])();
void R3728_init () {
	R3728[0] = (char *(*)()) F834_4564;
	R3728[1] = (char *(*)()) F835_4564;
	R3728[2] = (char *(*)()) F836_4564;
	R3728[3] = (char *(*)()) F837_4564;
	R3728[4] = (char *(*)()) F838_4564;
	R3728[5] = (char *(*)()) F839_4564;
	R3728[6] = (char *(*)()) F840_4564;
	R3728[7] = (char *(*)()) F841_4564;
	R3728[8] = (char *(*)()) F842_4564;
	R3728[9] = (char *(*)()) F843_4564;
	R3728[10] = (char *(*)()) F844_4564;
	R3728[11] = (char *(*)()) F845_4564;
	R3728[12] = (char *(*)()) F846_4564;
	R3728[13] = (char *(*)()) F847_4564;
	R3728[14] = (char *(*)()) F848_4564;
	R3728[15] = (char *(*)()) F849_4564;
	R3728[16] = (char *(*)()) F850_4564;
	R3728[17] = (char *(*)()) F851_4564;
	R3728[18] = (char *(*)()) F852_4564;
	R3728[19] = (char *(*)()) F853_4564;
	R3728[20] = (char *(*)()) F854_4564;
	R3728[21] = (char *(*)()) F855_4564;
	R3728[22] = (char *(*)()) F856_4564;
	R3728[23] = (char *(*)()) F857_4564;
	R3728[24] = (char *(*)()) F858_4564;
	R3728[25] = (char *(*)()) F859_4564;
	R3728[26] = (char *(*)()) F860_4564;
	R3728[27] = (char *(*)()) F861_4564;
	R3728[28] = (char *(*)()) F862_4564;
	R3728[29] = (char *(*)()) F863_4564;
	R3728[30] = (char *(*)()) F864_4564;
}

char *(*R3731[31])();
void R3731_init () {
	R3731[0] = (char *(*)()) F834_4567;
	R3731[1] = (char *(*)()) F835_4567;
	R3731[2] = (char *(*)()) F836_4567;
	R3731[3] = (char *(*)()) F837_4567;
	R3731[4] = (char *(*)()) F838_4567;
	R3731[5] = (char *(*)()) F839_4567;
	R3731[6] = (char *(*)()) F840_4567;
	R3731[7] = (char *(*)()) F841_4567;
	R3731[8] = (char *(*)()) F842_4567;
	R3731[9] = (char *(*)()) F843_4567;
	R3731[10] = (char *(*)()) F844_4567;
	R3731[11] = (char *(*)()) F845_4567;
	R3731[12] = (char *(*)()) F846_4567;
	R3731[13] = (char *(*)()) F847_4567;
	R3731[14] = (char *(*)()) F848_4567;
	R3731[15] = (char *(*)()) F849_4567;
	R3731[16] = (char *(*)()) F850_4567;
	R3731[17] = (char *(*)()) F851_4567;
	R3731[18] = (char *(*)()) F852_4567;
	R3731[19] = (char *(*)()) F853_4567;
	R3731[20] = (char *(*)()) F854_4567;
	R3731[21] = (char *(*)()) F855_4567;
	R3731[22] = (char *(*)()) F856_4567;
	R3731[23] = (char *(*)()) F857_4567;
	R3731[24] = (char *(*)()) F858_4567;
	R3731[25] = (char *(*)()) F859_4567;
	R3731[26] = (char *(*)()) F860_4567;
	R3731[27] = (char *(*)()) F861_4567;
	R3731[28] = (char *(*)()) F862_4567;
	R3731[29] = (char *(*)()) F863_4567;
	R3731[30] = (char *(*)()) F864_4567;
}

char *(*R3733[31])();
void R3733_init () {
	R3733[0] = (char *(*)()) F834_4570;
	R3733[1] = (char *(*)()) F835_4570;
	R3733[2] = (char *(*)()) F836_4570;
	R3733[3] = (char *(*)()) F837_4570;
	R3733[4] = (char *(*)()) F838_4570;
	R3733[5] = (char *(*)()) F839_4570;
	R3733[6] = (char *(*)()) F840_4570;
	R3733[7] = (char *(*)()) F841_4570;
	R3733[8] = (char *(*)()) F842_4570;
	R3733[9] = (char *(*)()) F843_4570;
	R3733[10] = (char *(*)()) F844_4570;
	R3733[11] = (char *(*)()) F845_4570;
	R3733[12] = (char *(*)()) F846_4570;
	R3733[13] = (char *(*)()) F847_4570;
	R3733[14] = (char *(*)()) F848_4570;
	R3733[15] = (char *(*)()) F849_4570;
	R3733[16] = (char *(*)()) F850_4570;
	R3733[17] = (char *(*)()) F851_4570;
	R3733[18] = (char *(*)()) F852_4570;
	R3733[19] = (char *(*)()) F853_4570;
	R3733[20] = (char *(*)()) F854_4570;
	R3733[21] = (char *(*)()) F855_4570;
	R3733[22] = (char *(*)()) F856_4570;
	R3733[23] = (char *(*)()) F857_4570;
	R3733[24] = (char *(*)()) F858_4570;
	R3733[25] = (char *(*)()) F859_4570;
	R3733[26] = (char *(*)()) F860_4570;
	R3733[27] = (char *(*)()) F861_4570;
	R3733[28] = (char *(*)()) F862_4570;
	R3733[29] = (char *(*)()) F863_4570;
	R3733[30] = (char *(*)()) F864_4570;
}

char *(*R3736[31])();
void R3736_init () {
	R3736[0] = (char *(*)()) F834_4573;
	R3736[1] = (char *(*)()) F835_4573;
	R3736[2] = (char *(*)()) F836_4573;
	R3736[3] = (char *(*)()) F837_4573;
	R3736[4] = (char *(*)()) F838_4573;
	R3736[5] = (char *(*)()) F839_4573;
	R3736[6] = (char *(*)()) F840_4573;
	R3736[7] = (char *(*)()) F841_4573;
	R3736[8] = (char *(*)()) F842_4573;
	R3736[9] = (char *(*)()) F843_4573;
	R3736[10] = (char *(*)()) F844_4573;
	R3736[11] = (char *(*)()) F845_4573;
	R3736[12] = (char *(*)()) F846_4573;
	R3736[13] = (char *(*)()) F847_4573;
	R3736[14] = (char *(*)()) F848_4573;
	R3736[15] = (char *(*)()) F849_4573;
	R3736[16] = (char *(*)()) F850_4573;
	R3736[17] = (char *(*)()) F851_4573;
	R3736[18] = (char *(*)()) F852_4573;
	R3736[19] = (char *(*)()) F853_4573;
	R3736[20] = (char *(*)()) F854_4573;
	R3736[21] = (char *(*)()) F855_4573;
	R3736[22] = (char *(*)()) F856_4573;
	R3736[23] = (char *(*)()) F857_4573;
	R3736[24] = (char *(*)()) F858_4573;
	R3736[25] = (char *(*)()) F859_4573;
	R3736[26] = (char *(*)()) F860_4573;
	R3736[27] = (char *(*)()) F861_4573;
	R3736[28] = (char *(*)()) F862_4573;
	R3736[29] = (char *(*)()) F863_4573;
	R3736[30] = (char *(*)()) F864_4573;
}

char *(*R3741[31])();
void R3741_init () {
	R3741[0] = (char *(*)()) F834_4581;
	R3741[1] = (char *(*)()) F835_4581_3741_1;
	R3741[2] = (char *(*)()) F836_4581_3741_1;
	R3741[3] = (char *(*)()) F837_4581_3741_1;
	R3741[4] = (char *(*)()) F838_4581_3741_1;
	R3741[5] = (char *(*)()) F839_4581_3741_1;
	R3741[6] = (char *(*)()) F840_4581_3741_1;
	R3741[7] = (char *(*)()) F841_4581_3741_1;
	R3741[8] = (char *(*)()) F842_4581_3741_1;
	R3741[9] = (char *(*)()) F843_4581_3741_1;
	R3741[10] = (char *(*)()) F844_4581_3741_1;
	R3741[11] = (char *(*)()) F845_4581_3741_1;
	R3741[12] = (char *(*)()) F846_4581_3741_1;
	R3741[13] = (char *(*)()) F847_4581_3741_1;
	R3741[14] = (char *(*)()) F848_4581_3741_1;
	R3741[15] = (char *(*)()) F849_4581_3741_1;
	R3741[16] = (char *(*)()) F850_4581_3741_1;
	R3741[17] = (char *(*)()) F851_4581_3741_1;
	R3741[18] = (char *(*)()) F852_4581_3741_1;
	R3741[19] = (char *(*)()) F853_4581_3741_1;
	R3741[20] = (char *(*)()) F854_4581_3741_1;
	R3741[21] = (char *(*)()) F855_4581_3741_1;
	R3741[22] = (char *(*)()) F856_4581;
	R3741[23] = (char *(*)()) F857_4581_3741_1;
	R3741[24] = (char *(*)()) F858_4581_3741_1;
	R3741[25] = (char *(*)()) F859_4581_3741_1;
	R3741[26] = (char *(*)()) F860_4581_3741_1;
	R3741[27] = (char *(*)()) F861_4581_3741_1;
	R3741[28] = (char *(*)()) F862_4581_3741_1;
	R3741[29] = (char *(*)()) F863_4581_3741_1;
	R3741[30] = (char *(*)()) F864_4581_3741_1;
}
static EIF_REFERENCE F835_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F835_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F836_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F836_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {906,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 906, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F837_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F837_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(894, 0x00).id, 894, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F838_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F838_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(891, 0x00).id, 891, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F839_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F839_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(888, 0x00).id, 888, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F840_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F840_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(885, 0x00).id, 885, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F841_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F841_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(882, 0x00).id, 882, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F842_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F842_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(879, 0x00).id, 879, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F843_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F843_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(867, 0x00).id, 867, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F844_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F844_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(876, 0x00).id, 876, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F845_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F845_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F846_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F846_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(870, 0x00).id, 870, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F847_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F847_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F848_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F848_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(903, 0x00).id, 903, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F849_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F849_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(897, 0x00).id, 897, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F850_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F850_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {908,936,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 908, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F851_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F851_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {910,903,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 910, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F852_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F852_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {912,879,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 912, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F853_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F853_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {914,882,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 914, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F854_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F854_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {916,876,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 916, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F855_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F855_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {918,867,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 918, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F857_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {920,891,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 920, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F858_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {922,885,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 922, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F859_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {924,900,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 924, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F860_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F860_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {926,897,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 926, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F861_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F861_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {928,894,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 928, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F862_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F862_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {930,873,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 930, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F863_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F863_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {932,870,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 932, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F864_4581_3741_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F864_4581(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {934,888,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 934, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}

char *(*R3751[31])();
void R3751_init () {
	R3751[0] = (char *(*)()) F834_4593;
	R3751[1] = (char *(*)()) F835_4593;
	R3751[2] = (char *(*)()) F836_4593;
	R3751[3] = (char *(*)()) F837_4593;
	R3751[4] = (char *(*)()) F838_4593;
	R3751[5] = (char *(*)()) F839_4593;
	R3751[6] = (char *(*)()) F840_4593;
	R3751[7] = (char *(*)()) F841_4593;
	R3751[8] = (char *(*)()) F842_4593;
	R3751[9] = (char *(*)()) F843_4593;
	R3751[10] = (char *(*)()) F844_4593;
	R3751[11] = (char *(*)()) F845_4593;
	R3751[12] = (char *(*)()) F846_4593;
	R3751[13] = (char *(*)()) F847_4593;
	R3751[14] = (char *(*)()) F848_4593;
	R3751[15] = (char *(*)()) F849_4593;
	R3751[16] = (char *(*)()) F850_4593;
	R3751[17] = (char *(*)()) F851_4593;
	R3751[18] = (char *(*)()) F852_4593;
	R3751[19] = (char *(*)()) F853_4593;
	R3751[20] = (char *(*)()) F854_4593;
	R3751[21] = (char *(*)()) F855_4593;
	R3751[22] = (char *(*)()) F856_4593;
	R3751[23] = (char *(*)()) F857_4593;
	R3751[24] = (char *(*)()) F858_4593;
	R3751[25] = (char *(*)()) F859_4593;
	R3751[26] = (char *(*)()) F860_4593;
	R3751[27] = (char *(*)()) F861_4593;
	R3751[28] = (char *(*)()) F862_4593;
	R3751[29] = (char *(*)()) F863_4593;
	R3751[30] = (char *(*)()) F864_4593;
}

char *(*R3895[2])();
void R3895_init () {
	R3895[0] = (char *(*)()) F867_4807;
	R3895[1] = (char *(*)()) F868_4807;
}

char *(*R3898[2])();
void R3898_init () {
	R3898[0] = (char *(*)()) F867_4810;
	R3898[1] = (char *(*)()) F868_4810;
}

char *(*R3901[2])();
void R3901_init () {
	R3901[0] = (char *(*)()) F867_4813;
	R3901[1] = (char *(*)()) F868_4813;
}

char *(*R3952[2])();
void R3952_init () {
	R3952[0] = (char *(*)()) F870_4907;
	R3952[1] = (char *(*)()) F871_4907;
}

char *(*R3953[2])();
void R3953_init () {
	R3953[0] = (char *(*)()) F870_4908;
	R3953[1] = (char *(*)()) F871_4908;
}

char *(*R3956[2])();
void R3956_init () {
	R3956[0] = (char *(*)()) F870_4911;
	R3956[1] = (char *(*)()) F871_4911;
}

char *(*R4008[2])();
void R4008_init () {
	R4008[0] = (char *(*)()) F873_5006;
	R4008[1] = (char *(*)()) F874_5006;
}

char *(*R4009[2])();
void R4009_init () {
	R4009[0] = (char *(*)()) F873_5007;
	R4009[1] = (char *(*)()) F874_5007;
}

char *(*R4013[2])();
void R4013_init () {
	R4013[0] = (char *(*)()) F873_5011;
	R4013[1] = (char *(*)()) F874_5011;
}

char *(*R4065[2])();
void R4065_init () {
	R4065[0] = (char *(*)()) F876_5106;
	R4065[1] = (char *(*)()) F877_5106;
}

char *(*R4068[2])();
void R4068_init () {
	R4068[0] = (char *(*)()) F876_5109;
	R4068[1] = (char *(*)()) F877_5109;
}

char *(*R4122[2])();
void R4122_init () {
	R4122[0] = (char *(*)()) F879_5203;
	R4122[1] = (char *(*)()) F880_5203;
}

char *(*R4168[2])();
void R4168_init () {
	R4168[0] = (char *(*)()) F882_5291;
	R4168[1] = (char *(*)()) F883_5291;
}

char *(*R4169[2])();
void R4169_init () {
	R4169[0] = (char *(*)()) F882_5292;
	R4169[1] = (char *(*)()) F883_5292;
}

char *(*R4171[2])();
void R4171_init () {
	R4171[0] = (char *(*)()) F882_5294;
	R4171[1] = (char *(*)()) F883_5294;
}

char *(*R4174[2])();
void R4174_init () {
	R4174[0] = (char *(*)()) F882_5297;
	R4174[1] = (char *(*)()) F883_5297;
}

char *(*R4175[2])();
void R4175_init () {
	R4175[0] = (char *(*)()) F882_5298;
	R4175[1] = (char *(*)()) F883_5298;
}

char *(*R4223[2])();
void R4223_init () {
	R4223[0] = (char *(*)()) F885_5388;
	R4223[1] = (char *(*)()) F886_5388;
}

char *(*R4224[2])();
void R4224_init () {
	R4224[0] = (char *(*)()) F885_5389;
	R4224[1] = (char *(*)()) F886_5389;
}

char *(*R4227[2])();
void R4227_init () {
	R4227[0] = (char *(*)()) F885_5392;
	R4227[1] = (char *(*)()) F886_5392;
}

char *(*R4275[2])();
void R4275_init () {
	R4275[0] = (char *(*)()) F888_5482;
	R4275[1] = (char *(*)()) F889_5482;
}

char *(*R4276[2])();
void R4276_init () {
	R4276[0] = (char *(*)()) F888_5483;
	R4276[1] = (char *(*)()) F889_5483;
}

char *(*R4277[2])();
void R4277_init () {
	R4277[0] = (char *(*)()) F888_5484;
	R4277[1] = (char *(*)()) F889_5484;
}

char *(*R4278[2])();
void R4278_init () {
	R4278[0] = (char *(*)()) F888_5485;
	R4278[1] = (char *(*)()) F889_5485;
}

char *(*R4280[2])();
void R4280_init () {
	R4280[0] = (char *(*)()) F888_5487;
	R4280[1] = (char *(*)()) F889_5487;
}

char *(*R4326[2])();
void R4326_init () {
	R4326[0] = (char *(*)()) F891_5545;
	R4326[1] = (char *(*)()) F892_5545;
}

char *(*R4360[2])();
void R4360_init () {
	R4360[0] = (char *(*)()) F894_5611;
	R4360[1] = (char *(*)()) F895_5611;
}

char *(*R4381[2])();
void R4381_init () {
	R4381[0] = (char *(*)()) F897_5669;
	R4381[1] = (char *(*)()) F898_5669;
}

char *(*R4529[3])();
void R4529_init () {
	R4529[0] = (char *(*)()) F940_5816;
	{long i; for (i = 1; i < 3; i++) R4529[i] = (char *(*)()) F941_5816_4529_1;}
}
static EIF_REFERENCE F941_5816_4529_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F941_5816(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(903, 0x00).id, 903, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R4534[3])();
void R4534_init () {
	R4534[0] = (char *(*)()) F940_5825;
	{long i; for (i = 1; i < 3; i++) R4534[i] = (char *(*)()) F941_5825_4534_472;}
}
static EIF_REFERENCE F941_5825_4534_472 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F941_5825(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(903, 0x00).id, 903, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y4535_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4535_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4535_pgtype2[] = {903,0xFFFF};
EIF_TYPE_INDEX *Y4535_gen_type [3];
EIF_TYPE_INDEX Y4535 [3];
void Y4535_init (void)
{
	egc_routines_types [4535] = Y4535;
	egc_routines_gen_types [4535] = Y4535_gen_type;
	egc_routines_offset [4535] = 939;
	Y4535_gen_type [0] = Y4535_pgtype0;
	Y4535_gen_type [1] = Y4535_pgtype1;
	Y4535_gen_type [2] = Y4535_pgtype2;
	Y4535[2] = 903;
}

char *(*R4536[491])();
void R4536_init () {
	{long i; for (i = 0; i < 2; i++) R4536[i] = (char *(*)()) F946_5957;}
	{long i; for (i = 3; i < 5; i++) R4536[i] = (char *(*)()) F949_6124;}
	{long i; for (i = 489; i < 491; i++) R4536[i] = (char *(*)()) F1436_11323;}
}

char *(*R4538[491])();
void R4538_init () {
	R4538[0] = (char *(*)()) F947_6018;
	R4538[1] = (char *(*)()) F948_6041;
	R4538[3] = (char *(*)()) F950_6184;
	R4538[4] = (char *(*)()) F951_6206;
	{long i; for (i = 489; i < 491; i++) R4538[i] = (char *(*)()) F1436_11451;}
}

char *(*R4539[491])();
void R4539_init () {
	R4539[0] = (char *(*)()) F947_6016;
	R4539[1] = (char *(*)()) F948_6039;
	R4539[3] = (char *(*)()) F950_6183;
	R4539[4] = (char *(*)()) F951_6205;
	{long i; for (i = 489; i < 491; i++) R4539[i] = (char *(*)()) F951_6205;}
}


#ifdef __cplusplus
}
#endif
