#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O5398[295];
void O5398_init () {
	O5398[0] = + _LNGOFF_5_2_0_11_;
	O5398[1] = + _LNGOFF_8_2_0_11_;
	O5398[2] = + _LNGOFF_14_3_0_11_;
	O5398[3] = + _LNGOFF_27_4_0_12_;
	O5398[20] = + _LNGOFF_10_4_0_11_;
	O5398[22] = + _LNGOFF_14_5_0_11_;
	O5398[285] = + _LNGOFF_28_4_0_12_;
	{long i; for (i = 287; i < 289; i++) O5398[i] = + _LNGOFF_23_3_0_11_;}
	O5398[289] = + _LNGOFF_23_5_0_11_;
	O5398[290] = + _LNGOFF_27_4_0_11_;
	O5398[291] = + _LNGOFF_27_6_0_11_;
	O5398[293] = + _LNGOFF_51_8_0_12_;
	O5398[294] = + _LNGOFF_62_8_0_12_;
}

long O5399[295];
void O5399_init () {
	O5399[0] = + _LNGOFF_5_2_0_12_;
	O5399[1] = + _LNGOFF_8_2_0_12_;
	O5399[2] = + _LNGOFF_14_3_0_12_;
	O5399[3] = + _LNGOFF_27_4_0_13_;
	O5399[20] = + _LNGOFF_10_4_0_12_;
	O5399[22] = + _LNGOFF_14_5_0_12_;
	O5399[285] = + _LNGOFF_28_4_0_13_;
	{long i; for (i = 287; i < 289; i++) O5399[i] = + _LNGOFF_23_3_0_12_;}
	O5399[289] = + _LNGOFF_23_5_0_12_;
	O5399[290] = + _LNGOFF_27_4_0_12_;
	O5399[291] = + _LNGOFF_27_6_0_12_;
	O5399[293] = + _LNGOFF_51_8_0_13_;
	O5399[294] = + _LNGOFF_62_8_0_13_;
}

long O5400[295];
void O5400_init () {
	O5400[0] = + _LNGOFF_5_2_0_13_;
	O5400[1] = + _LNGOFF_8_2_0_13_;
	O5400[2] = + _LNGOFF_14_3_0_13_;
	O5400[3] = + _LNGOFF_27_4_0_14_;
	O5400[20] = + _LNGOFF_10_4_0_13_;
	O5400[22] = + _LNGOFF_14_5_0_13_;
	O5400[285] = + _LNGOFF_28_4_0_14_;
	{long i; for (i = 287; i < 289; i++) O5400[i] = + _LNGOFF_23_3_0_13_;}
	O5400[289] = + _LNGOFF_23_5_0_13_;
	O5400[290] = + _LNGOFF_27_4_0_13_;
	O5400[291] = + _LNGOFF_27_6_0_13_;
	O5400[293] = + _LNGOFF_51_8_0_14_;
	O5400[294] = + _LNGOFF_62_8_0_14_;
}

long O5401[295];
void O5401_init () {
	O5401[0] = + _LNGOFF_5_2_0_14_;
	O5401[1] = + _LNGOFF_8_2_0_14_;
	O5401[2] = + _LNGOFF_14_3_0_14_;
	O5401[3] = + _LNGOFF_27_4_0_15_;
	O5401[20] = + _LNGOFF_10_4_0_14_;
	O5401[22] = + _LNGOFF_14_5_0_14_;
	O5401[285] = + _LNGOFF_28_4_0_15_;
	{long i; for (i = 287; i < 289; i++) O5401[i] = + _LNGOFF_23_3_0_14_;}
	O5401[289] = + _LNGOFF_23_5_0_14_;
	O5401[290] = + _LNGOFF_27_4_0_14_;
	O5401[291] = + _LNGOFF_27_6_0_14_;
	O5401[293] = + _LNGOFF_51_8_0_15_;
	O5401[294] = + _LNGOFF_62_8_0_15_;
}

long O5420[293];
void O5420_init () {
	O5420[0] = + _CHROFF_14_2_;
	O5420[1] = + _CHROFF_27_2_;
	O5420[283] = + _CHROFF_28_2_;
	{long i; for (i = 285; i < 288; i++) O5420[i] = + _CHROFF_23_2_;}
	{long i; for (i = 288; i < 290; i++) O5420[i] = + _CHROFF_27_2_;}
	O5420[291] = + _CHROFF_51_2_;
	O5420[292] = + _CHROFF_62_2_;
}

long O5422[293];
void O5422_init () {
	O5422[0] = + _LNGOFF_14_3_0_15_;
	O5422[1] = + _LNGOFF_27_4_0_16_;
	O5422[283] = + _LNGOFF_28_4_0_16_;
	{long i; for (i = 285; i < 287; i++) O5422[i] = + _LNGOFF_23_3_0_15_;}
	O5422[287] = + _LNGOFF_23_5_0_15_;
	O5422[288] = + _LNGOFF_27_4_0_15_;
	O5422[289] = + _LNGOFF_27_6_0_15_;
	O5422[291] = + _LNGOFF_51_8_0_16_;
	O5422[292] = + _LNGOFF_62_8_0_16_;
}

long O5423[293];
void O5423_init () {
	O5423[0] = + _LNGOFF_14_3_0_16_;
	O5423[1] = + _LNGOFF_27_4_0_17_;
	O5423[283] = + _LNGOFF_28_4_0_17_;
	{long i; for (i = 285; i < 287; i++) O5423[i] = + _LNGOFF_23_3_0_16_;}
	O5423[287] = + _LNGOFF_23_5_0_16_;
	O5423[288] = + _LNGOFF_27_4_0_16_;
	O5423[289] = + _LNGOFF_27_6_0_16_;
	O5423[291] = + _LNGOFF_51_8_0_17_;
	O5423[292] = + _LNGOFF_62_8_0_17_;
}

long O5424[293];
void O5424_init () {
	O5424[0] = + _LNGOFF_14_3_0_17_;
	O5424[1] = + _LNGOFF_27_4_0_18_;
	O5424[283] = + _LNGOFF_28_4_0_18_;
	{long i; for (i = 285; i < 287; i++) O5424[i] = + _LNGOFF_23_3_0_17_;}
	O5424[287] = + _LNGOFF_23_5_0_17_;
	O5424[288] = + _LNGOFF_27_4_0_17_;
	O5424[289] = + _LNGOFF_27_6_0_17_;
	O5424[291] = + _LNGOFF_51_8_0_18_;
	O5424[292] = + _LNGOFF_62_8_0_18_;
}

long O5425[293];
void O5425_init () {
	O5425[0] = + _LNGOFF_14_3_0_18_;
	O5425[1] = + _LNGOFF_27_4_0_19_;
	O5425[283] = + _LNGOFF_28_4_0_19_;
	{long i; for (i = 285; i < 287; i++) O5425[i] = + _LNGOFF_23_3_0_18_;}
	O5425[287] = + _LNGOFF_23_5_0_18_;
	O5425[288] = + _LNGOFF_27_4_0_18_;
	O5425[289] = + _LNGOFF_27_6_0_18_;
	O5425[291] = + _LNGOFF_51_8_0_19_;
	O5425[292] = + _LNGOFF_62_8_0_19_;
}

long O5426[293];
void O5426_init () {
	O5426[0] = + _LNGOFF_14_3_0_19_;
	O5426[1] = + _LNGOFF_27_4_0_20_;
	O5426[283] = + _LNGOFF_28_4_0_20_;
	{long i; for (i = 285; i < 287; i++) O5426[i] = + _LNGOFF_23_3_0_19_;}
	O5426[287] = + _LNGOFF_23_5_0_19_;
	O5426[288] = + _LNGOFF_27_4_0_19_;
	O5426[289] = + _LNGOFF_27_6_0_19_;
	O5426[291] = + _LNGOFF_51_8_0_20_;
	O5426[292] = + _LNGOFF_62_8_0_20_;
}

long O5427[293];
void O5427_init () {
	O5427[0] = + _LNGOFF_14_3_0_20_;
	O5427[1] = + _LNGOFF_27_4_0_21_;
	O5427[283] = + _LNGOFF_28_4_0_21_;
	{long i; for (i = 285; i < 287; i++) O5427[i] = + _LNGOFF_23_3_0_20_;}
	O5427[287] = + _LNGOFF_23_5_0_20_;
	O5427[288] = + _LNGOFF_27_4_0_20_;
	O5427[289] = + _LNGOFF_27_6_0_20_;
	O5427[291] = + _LNGOFF_51_8_0_21_;
	O5427[292] = + _LNGOFF_62_8_0_21_;
}

static EIF_TYPE_INDEX Y5980_pgtype0[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype1[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype2[] = {256,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype3[] = {257,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype4[] = {258,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype5[] = {259,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype6[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype7[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype8[] = {256,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype9[] = {257,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype10[] = {258,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype11[] = {259,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype12[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype13[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype14[] = {256,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype15[] = {257,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype16[] = {258,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype17[] = {259,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype18[] = {254,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype19[] = {255,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype20[] = {254,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype21[] = {258,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype22[] = {255,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype23[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype24[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype25[] = {257,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype26[] = {259,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype27[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype28[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype29[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype30[] = {256,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype31[] = {257,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype32[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype33[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype34[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype35[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype36[] = {256,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype37[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype38[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype39[] = {256,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype40[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype41[] = {256,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype42[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype43[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype44[] = {254,0xFF01,153,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype45[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype46[] = {257,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype47[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype48[] = {256,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype49[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype50[] = {256,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype51[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype52[] = {256,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype53[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype54[] = {257,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype55[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype56[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype57[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype58[] = {257,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype59[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype60[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype61[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype62[] = {254,0xFF01,4,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype63[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype64[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype65[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype66[] = {257,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype67[] = {259,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype68[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype69[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype70[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype71[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype72[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype73[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype74[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype75[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype76[] = {257,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype77[] = {259,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype78[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype79[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype80[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype81[] = {257,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype82[] = {259,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype83[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype84[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype85[] = {254,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype86[] = {257,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype87[] = {259,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype88[] = {255,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype89[] = {254,0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype90[] = {254,0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y5980_pgtype91[] = {254,0xFF01,950,0xFFFF};
EIF_TYPE_INDEX *Y5980_gen_type [210];
EIF_TYPE_INDEX Y5980 [210];
void Y5980_init (void)
{
	egc_routines_types [5980] = Y5980;
	egc_routines_gen_types [5980] = Y5980_gen_type;
	egc_routines_offset [5980] = 1144;
	Y5980_gen_type [0] = Y5980_pgtype0;
	Y5980_gen_type [1] = Y5980_pgtype1;
	Y5980_gen_type [2] = Y5980_pgtype2;
	Y5980_gen_type [3] = Y5980_pgtype3;
	Y5980_gen_type [4] = Y5980_pgtype4;
	Y5980_gen_type [5] = Y5980_pgtype5;
	Y5980_gen_type [6] = Y5980_pgtype6;
	Y5980_gen_type [7] = Y5980_pgtype7;
	Y5980_gen_type [8] = Y5980_pgtype8;
	Y5980_gen_type [9] = Y5980_pgtype9;
	Y5980_gen_type [10] = Y5980_pgtype10;
	Y5980_gen_type [11] = Y5980_pgtype11;
	Y5980_gen_type [12] = Y5980_pgtype12;
	Y5980_gen_type [13] = Y5980_pgtype13;
	Y5980_gen_type [14] = Y5980_pgtype14;
	Y5980_gen_type [15] = Y5980_pgtype15;
	Y5980_gen_type [16] = Y5980_pgtype16;
	Y5980_gen_type [17] = Y5980_pgtype17;
	Y5980_gen_type [18] = Y5980_pgtype18;
	Y5980_gen_type [19] = Y5980_pgtype19;
	Y5980_gen_type [20] = Y5980_pgtype20;
	Y5980_gen_type [21] = Y5980_pgtype21;
	Y5980_gen_type [22] = Y5980_pgtype22;
	Y5980_gen_type [23] = Y5980_pgtype23;
	Y5980_gen_type [24] = Y5980_pgtype24;
	Y5980_gen_type [25] = Y5980_pgtype25;
	Y5980_gen_type [26] = Y5980_pgtype26;
	Y5980_gen_type [27] = Y5980_pgtype27;
	Y5980_gen_type [28] = Y5980_pgtype28;
	Y5980_gen_type [29] = Y5980_pgtype29;
	Y5980_gen_type [30] = Y5980_pgtype30;
	Y5980_gen_type [31] = Y5980_pgtype31;
	Y5980_gen_type [32] = Y5980_pgtype32;
	Y5980_gen_type [33] = Y5980_pgtype33;
	Y5980_gen_type [34] = Y5980_pgtype34;
	Y5980_gen_type [35] = Y5980_pgtype35;
	Y5980_gen_type [36] = Y5980_pgtype36;
	Y5980_gen_type [37] = Y5980_pgtype37;
	Y5980_gen_type [38] = Y5980_pgtype38;
	Y5980_gen_type [39] = Y5980_pgtype39;
	Y5980_gen_type [40] = Y5980_pgtype40;
	Y5980_gen_type [41] = Y5980_pgtype41;
	Y5980_gen_type [42] = Y5980_pgtype42;
	Y5980_gen_type [43] = Y5980_pgtype43;
	Y5980_gen_type [44] = Y5980_pgtype44;
	Y5980_gen_type [45] = Y5980_pgtype45;
	Y5980_gen_type [46] = Y5980_pgtype46;
	Y5980_gen_type [47] = Y5980_pgtype47;
	Y5980_gen_type [48] = Y5980_pgtype48;
	Y5980_gen_type [49] = Y5980_pgtype49;
	Y5980_gen_type [50] = Y5980_pgtype50;
	Y5980_gen_type [51] = Y5980_pgtype51;
	Y5980_gen_type [52] = Y5980_pgtype52;
	Y5980_gen_type [53] = Y5980_pgtype53;
	Y5980_gen_type [54] = Y5980_pgtype54;
	Y5980_gen_type [55] = Y5980_pgtype55;
	Y5980_gen_type [56] = Y5980_pgtype56;
	Y5980_gen_type [61] = Y5980_pgtype57;
	Y5980_gen_type [62] = Y5980_pgtype58;
	Y5980_gen_type [63] = Y5980_pgtype59;
	Y5980_gen_type [64] = Y5980_pgtype60;
	Y5980_gen_type [65] = Y5980_pgtype61;
	Y5980_gen_type [66] = Y5980_pgtype62;
	Y5980_gen_type [67] = Y5980_pgtype63;
	Y5980_gen_type [68] = Y5980_pgtype64;
	Y5980_gen_type [69] = Y5980_pgtype65;
	Y5980_gen_type [70] = Y5980_pgtype66;
	Y5980_gen_type [71] = Y5980_pgtype67;
	Y5980_gen_type [72] = Y5980_pgtype68;
	Y5980_gen_type [73] = Y5980_pgtype69;
	Y5980_gen_type [74] = Y5980_pgtype70;
	Y5980_gen_type [75] = Y5980_pgtype71;
	Y5980_gen_type [76] = Y5980_pgtype72;
	Y5980_gen_type [77] = Y5980_pgtype73;
	Y5980_gen_type [78] = Y5980_pgtype74;
	Y5980_gen_type [79] = Y5980_pgtype75;
	Y5980_gen_type [80] = Y5980_pgtype76;
	Y5980_gen_type [81] = Y5980_pgtype77;
	Y5980_gen_type [82] = Y5980_pgtype78;
	Y5980_gen_type [83] = Y5980_pgtype79;
	Y5980_gen_type [84] = Y5980_pgtype80;
	Y5980_gen_type [85] = Y5980_pgtype81;
	Y5980_gen_type [86] = Y5980_pgtype82;
	Y5980_gen_type [87] = Y5980_pgtype83;
	Y5980_gen_type [88] = Y5980_pgtype84;
	Y5980_gen_type [89] = Y5980_pgtype85;
	Y5980_gen_type [90] = Y5980_pgtype86;
	Y5980_gen_type [91] = Y5980_pgtype87;
	Y5980_gen_type [92] = Y5980_pgtype88;
	Y5980_gen_type [93] = Y5980_pgtype89;
	Y5980_gen_type [94] = Y5980_pgtype90;
	Y5980_gen_type [209] = Y5980_pgtype91;
	Y5980[0] = 254;
	Y5980[1] = 255;
	Y5980[2] = 256;
	Y5980[3] = 257;
	Y5980[4] = 258;
	Y5980[5] = 259;
	Y5980[6] = 254;
	Y5980[7] = 255;
	Y5980[8] = 256;
	Y5980[9] = 257;
	Y5980[10] = 258;
	Y5980[11] = 259;
	Y5980[12] = 254;
	Y5980[13] = 255;
	Y5980[14] = 256;
	Y5980[15] = 257;
	Y5980[16] = 258;
	Y5980[17] = 259;
	Y5980[18] = 254;
	Y5980[19] = 255;
	Y5980[20] = 254;
	Y5980[21] = 258;
	Y5980[22] = 255;
	{long i; for (i = 23; i < 25; i++) Y5980[i] = 254;};
	Y5980[25] = 257;
	Y5980[26] = 259;
	Y5980[27] = 255;
	Y5980[28] = 254;
	Y5980[29] = 255;
	Y5980[30] = 256;
	Y5980[31] = 257;
	Y5980[32] = 254;
	Y5980[33] = 255;
	Y5980[34] = 254;
	Y5980[35] = 255;
	Y5980[36] = 256;
	Y5980[37] = 254;
	Y5980[38] = 255;
	Y5980[39] = 256;
	Y5980[40] = 254;
	Y5980[41] = 256;
	{long i; for (i = 42; i < 46; i++) Y5980[i] = 254;};
	Y5980[46] = 257;
	Y5980[47] = 255;
	Y5980[48] = 256;
	Y5980[49] = 254;
	Y5980[50] = 256;
	Y5980[51] = 254;
	Y5980[52] = 256;
	Y5980[53] = 254;
	Y5980[54] = 257;
	Y5980[55] = 255;
	Y5980[56] = 254;
	Y5980[61] = 254;
	Y5980[62] = 257;
	Y5980[63] = 255;
	Y5980[64] = 254;
	Y5980[65] = 255;
	{long i; for (i = 66; i < 69; i++) Y5980[i] = 254;};
	Y5980[69] = 255;
	Y5980[70] = 257;
	Y5980[71] = 259;
	Y5980[72] = 254;
	Y5980[73] = 255;
	Y5980[74] = 254;
	Y5980[75] = 255;
	Y5980[76] = 254;
	Y5980[77] = 255;
	{long i; for (i = 78; i < 80; i++) Y5980[i] = 254;};
	Y5980[80] = 257;
	Y5980[81] = 259;
	Y5980[82] = 255;
	{long i; for (i = 83; i < 85; i++) Y5980[i] = 254;};
	Y5980[85] = 257;
	Y5980[86] = 259;
	Y5980[87] = 255;
	{long i; for (i = 88; i < 90; i++) Y5980[i] = 254;};
	Y5980[90] = 257;
	Y5980[91] = 259;
	Y5980[92] = 255;
	{long i; for (i = 93; i < 95; i++) Y5980[i] = 254;};
	Y5980[209] = 254;
}

static EIF_TYPE_INDEX Y6013_pgtype0[] = {0xFF01,1222,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6013_pgtype1[] = {0xFF01,1223,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6013_pgtype2[] = {0xFF01,1224,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6013_pgtype3[] = {0xFF01,1225,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6013_pgtype4[] = {0xFF01,1226,0xFFF8,1,0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y6013_gen_type [5];
EIF_TYPE_INDEX Y6013 [5];
void Y6013_init (void)
{
	egc_routines_types [6013] = Y6013;
	egc_routines_gen_types [6013] = Y6013_gen_type;
	egc_routines_offset [6013] = 1162;
	Y6013_gen_type [0] = Y6013_pgtype0;
	Y6013_gen_type [1] = Y6013_pgtype1;
	Y6013_gen_type [2] = Y6013_pgtype2;
	Y6013_gen_type [3] = Y6013_pgtype3;
	Y6013_gen_type [4] = Y6013_pgtype4;
	Y6013[0] = 1222;
	Y6013[1] = 1223;
	Y6013[2] = 1224;
	Y6013[3] = 1225;
	Y6013[4] = 1226;
}

static EIF_TYPE_INDEX Y6106_pgtype0[] = {135,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6106_pgtype1[] = {136,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6106_pgtype2[] = {135,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6106_pgtype3[] = {138,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6106_pgtype4[] = {135,0xFF01,153,0xFFFF};
EIF_TYPE_INDEX *Y6106_gen_type [5];
EIF_TYPE_INDEX Y6106 [5];
void Y6106_init (void)
{
	egc_routines_types [6106] = Y6106;
	egc_routines_gen_types [6106] = Y6106_gen_type;
	egc_routines_offset [6106] = 1184;
	Y6106_gen_type [0] = Y6106_pgtype0;
	Y6106_gen_type [1] = Y6106_pgtype1;
	Y6106_gen_type [2] = Y6106_pgtype2;
	Y6106_gen_type [3] = Y6106_pgtype3;
	Y6106_gen_type [4] = Y6106_pgtype4;
	Y6106[0] = 135;
	Y6106[1] = 136;
	Y6106[2] = 135;
	Y6106[3] = 138;
	Y6106[4] = 135;
}

long O6114[5];
void O6114_init () {
	{long i; for (i = 0; i < 4; i++) O6114[i] = + _LNGOFF_4_0_0_0_;}
	O6114[4] = + _LNGOFF_6_0_0_0_;
}

static EIF_TYPE_INDEX Y6156_pgtype0[] = {0xFF01,23,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6156_pgtype1[] = {0xFF01,24,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6156_pgtype2[] = {0xFF01,23,0xFF01,4,0xFFFF};
EIF_TYPE_INDEX *Y6156_gen_type [3];
EIF_TYPE_INDEX Y6156 [3];
void Y6156_init (void)
{
	egc_routines_types [6156] = Y6156;
	egc_routines_gen_types [6156] = Y6156_gen_type;
	egc_routines_offset [6156] = 1208;
	Y6156_gen_type [0] = Y6156_pgtype0;
	Y6156_gen_type [1] = Y6156_pgtype1;
	Y6156_gen_type [2] = Y6156_pgtype2;
	Y6156[0] = 23;
	Y6156[1] = 24;
	Y6156[2] = 23;
}

long O6182[143];
void O6182_init () {
	{long i; for (i = 0; i < 7; i++) O6182[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 7; i < 9; i++) O6182[i] = + _LNGOFF_6_0_0_0_;}
	{long i; for (i = 9; i < 11; i++) O6182[i] = + _LNGOFF_7_0_0_0_;}
	{long i; for (i = 11; i < 16; i++) O6182[i] = + _LNGOFF_4_0_0_0_;}
	{long i; for (i = 16; i < 21; i++) O6182[i] = + _LNGOFF_10_0_0_0_;}
	{long i; for (i = 21; i < 28; i++) O6182[i] = + _LNGOFF_11_0_0_0_;}
	O6182[142] = + _LNGOFF_11_0_0_0_;
}

long O6217[143];
void O6217_init () {
	{long i; for (i = 0; i < 7; i++) O6217[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 7; i < 9; i++) O6217[i] = + _LNGOFF_6_0_0_1_;}
	{long i; for (i = 9; i < 11; i++) O6217[i] = + _LNGOFF_7_0_0_1_;}
	{long i; for (i = 11; i < 16; i++) O6217[i] = + _LNGOFF_4_0_0_1_;}
	{long i; for (i = 16; i < 21; i++) O6217[i] = + _LNGOFF_10_0_0_1_;}
	{long i; for (i = 21; i < 28; i++) O6217[i] = + _LNGOFF_11_0_0_1_;}
	O6217[142] = + _LNGOFF_11_0_0_1_;
}

long O6218[143];
void O6218_init () {
	{long i; for (i = 0; i < 7; i++) O6218[i] = + _LNGOFF_2_0_0_2_;}
	{long i; for (i = 7; i < 9; i++) O6218[i] = + _LNGOFF_6_0_0_2_;}
	{long i; for (i = 9; i < 11; i++) O6218[i] = + _LNGOFF_7_0_0_2_;}
	{long i; for (i = 11; i < 16; i++) O6218[i] = + _LNGOFF_4_0_0_2_;}
	{long i; for (i = 16; i < 21; i++) O6218[i] = + _LNGOFF_10_0_0_2_;}
	{long i; for (i = 21; i < 28; i++) O6218[i] = + _LNGOFF_11_0_0_2_;}
	O6218[142] = + _LNGOFF_11_0_0_2_;
}

long O6219[143];
void O6219_init () {
	{long i; for (i = 0; i < 7; i++) O6219[i] = + _LNGOFF_2_0_0_3_;}
	{long i; for (i = 7; i < 9; i++) O6219[i] = + _LNGOFF_6_0_0_3_;}
	{long i; for (i = 9; i < 11; i++) O6219[i] = + _LNGOFF_7_0_0_3_;}
	{long i; for (i = 11; i < 16; i++) O6219[i] = + _LNGOFF_4_0_0_3_;}
	{long i; for (i = 16; i < 21; i++) O6219[i] = + _LNGOFF_10_0_0_3_;}
	{long i; for (i = 21; i < 28; i++) O6219[i] = + _LNGOFF_11_0_0_3_;}
	O6219[142] = + _LNGOFF_11_0_0_3_;
}

long O6220[143];
void O6220_init () {
	{long i; for (i = 0; i < 7; i++) O6220[i] = + _LNGOFF_2_0_0_4_;}
	{long i; for (i = 7; i < 9; i++) O6220[i] = + _LNGOFF_6_0_0_4_;}
	{long i; for (i = 9; i < 11; i++) O6220[i] = + _LNGOFF_7_0_0_4_;}
	{long i; for (i = 11; i < 16; i++) O6220[i] = + _LNGOFF_4_0_0_4_;}
	{long i; for (i = 16; i < 21; i++) O6220[i] = + _LNGOFF_10_0_0_4_;}
	{long i; for (i = 21; i < 28; i++) O6220[i] = + _LNGOFF_11_0_0_4_;}
	O6220[142] = + _LNGOFF_11_0_0_4_;
}

long O6221[143];
void O6221_init () {
	{long i; for (i = 0; i < 7; i++) O6221[i] = + _LNGOFF_2_0_0_5_;}
	{long i; for (i = 7; i < 9; i++) O6221[i] = + _LNGOFF_6_0_0_5_;}
	{long i; for (i = 9; i < 11; i++) O6221[i] = + _LNGOFF_7_0_0_5_;}
	{long i; for (i = 11; i < 16; i++) O6221[i] = + _LNGOFF_4_0_0_5_;}
	{long i; for (i = 16; i < 21; i++) O6221[i] = + _LNGOFF_10_0_0_5_;}
	{long i; for (i = 21; i < 28; i++) O6221[i] = + _LNGOFF_11_0_0_5_;}
	O6221[142] = + _LNGOFF_11_0_0_5_;
}

long O6222[143];
void O6222_init () {
	{long i; for (i = 0; i < 7; i++) O6222[i] = + _LNGOFF_2_0_0_6_;}
	{long i; for (i = 7; i < 9; i++) O6222[i] = + _LNGOFF_6_0_0_6_;}
	{long i; for (i = 9; i < 11; i++) O6222[i] = + _LNGOFF_7_0_0_6_;}
	{long i; for (i = 11; i < 16; i++) O6222[i] = + _LNGOFF_4_0_0_6_;}
	{long i; for (i = 16; i < 21; i++) O6222[i] = + _LNGOFF_10_0_0_6_;}
	{long i; for (i = 21; i < 28; i++) O6222[i] = + _LNGOFF_11_0_0_6_;}
	O6222[142] = + _LNGOFF_11_0_0_6_;
}

long O6232[143];
void O6232_init () {
	{long i; for (i = 0; i < 7; i++) O6232[i] = + _LNGOFF_2_0_0_7_;}
	{long i; for (i = 7; i < 9; i++) O6232[i] = + _LNGOFF_6_0_0_7_;}
	{long i; for (i = 9; i < 11; i++) O6232[i] = + _LNGOFF_7_0_0_7_;}
	{long i; for (i = 11; i < 16; i++) O6232[i] = + _LNGOFF_4_0_0_7_;}
	{long i; for (i = 16; i < 21; i++) O6232[i] = + _LNGOFF_10_0_0_7_;}
	{long i; for (i = 21; i < 28; i++) O6232[i] = + _LNGOFF_11_0_0_7_;}
	O6232[142] = + _LNGOFF_11_0_0_7_;
}

long O6233[143];
void O6233_init () {
	{long i; for (i = 0; i < 7; i++) O6233[i] = + _LNGOFF_2_0_0_8_;}
	{long i; for (i = 7; i < 9; i++) O6233[i] = + _LNGOFF_6_0_0_8_;}
	{long i; for (i = 9; i < 11; i++) O6233[i] = + _LNGOFF_7_0_0_8_;}
	{long i; for (i = 11; i < 16; i++) O6233[i] = + _LNGOFF_4_0_0_8_;}
	{long i; for (i = 16; i < 21; i++) O6233[i] = + _LNGOFF_10_0_0_8_;}
	{long i; for (i = 21; i < 28; i++) O6233[i] = + _LNGOFF_11_0_0_8_;}
	O6233[142] = + _LNGOFF_11_0_0_8_;
}

static EIF_TYPE_INDEX Y6239_pgtype0[] = {0xFF01,23,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6239_pgtype1[] = {0xFF01,24,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6239_pgtype2[] = {0xFF01,23,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6239_pgtype3[] = {0xFF01,24,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y6239_gen_type [4];
EIF_TYPE_INDEX Y6239 [4];
void Y6239_init (void)
{
	egc_routines_types [6239] = Y6239;
	egc_routines_gen_types [6239] = Y6239_gen_type;
	egc_routines_offset [6239] = 1218;
	Y6239_gen_type [0] = Y6239_pgtype0;
	Y6239_gen_type [1] = Y6239_pgtype1;
	Y6239_gen_type [2] = Y6239_pgtype2;
	Y6239_gen_type [3] = Y6239_pgtype3;
	Y6239[0] = 23;
	Y6239[1] = 24;
	Y6239[2] = 23;
	Y6239[3] = 24;
}

static EIF_TYPE_INDEX Y6263_pgtype0[] = {254,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6263_pgtype1[] = {255,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6263_pgtype2[] = {254,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6263_pgtype3[] = {258,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6263_pgtype4[] = {255,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6263_pgtype5[] = {254,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6263_pgtype6[] = {255,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6263_pgtype7[] = {254,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6263_pgtype8[] = {258,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6263_pgtype9[] = {255,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6263_pgtype10[] = {254,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6263_pgtype11[] = {255,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6263_pgtype12[] = {254,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6263_pgtype13[] = {258,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6263_pgtype14[] = {255,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6263_pgtype15[] = {254,0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y6263_pgtype16[] = {254,0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y6263_pgtype17[] = {254,0xFF01,950,0xFFFF};
EIF_TYPE_INDEX *Y6263_gen_type [132];
EIF_TYPE_INDEX Y6263 [132];
void Y6263_init (void)
{
	egc_routines_types [6263] = Y6263;
	egc_routines_gen_types [6263] = Y6263_gen_type;
	egc_routines_offset [6263] = 1222;
	Y6263_gen_type [0] = Y6263_pgtype0;
	Y6263_gen_type [1] = Y6263_pgtype1;
	Y6263_gen_type [2] = Y6263_pgtype2;
	Y6263_gen_type [3] = Y6263_pgtype3;
	Y6263_gen_type [4] = Y6263_pgtype4;
	Y6263_gen_type [5] = Y6263_pgtype5;
	Y6263_gen_type [6] = Y6263_pgtype6;
	Y6263_gen_type [7] = Y6263_pgtype7;
	Y6263_gen_type [8] = Y6263_pgtype8;
	Y6263_gen_type [9] = Y6263_pgtype9;
	Y6263_gen_type [10] = Y6263_pgtype10;
	Y6263_gen_type [11] = Y6263_pgtype11;
	Y6263_gen_type [12] = Y6263_pgtype12;
	Y6263_gen_type [13] = Y6263_pgtype13;
	Y6263_gen_type [14] = Y6263_pgtype14;
	Y6263_gen_type [15] = Y6263_pgtype15;
	Y6263_gen_type [16] = Y6263_pgtype16;
	Y6263_gen_type [131] = Y6263_pgtype17;
	Y6263[0] = 254;
	Y6263[1] = 255;
	Y6263[2] = 254;
	Y6263[3] = 258;
	Y6263[4] = 255;
	Y6263[5] = 254;
	Y6263[6] = 255;
	Y6263[7] = 254;
	Y6263[8] = 258;
	Y6263[9] = 255;
	Y6263[10] = 254;
	Y6263[11] = 255;
	Y6263[12] = 254;
	Y6263[13] = 258;
	Y6263[14] = 255;
	{long i; for (i = 15; i < 17; i++) Y6263[i] = 254;};
	Y6263[131] = 254;
}

static EIF_TYPE_INDEX Y6268_pgtype0[] = {0xFF01,23,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6268_pgtype1[] = {0xFF01,23,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6268_pgtype2[] = {0xFF01,25,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6268_pgtype3[] = {0xFF01,26,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6268_pgtype4[] = {0xFF01,24,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6268_pgtype5[] = {0xFF01,23,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6268_pgtype6[] = {0xFF01,23,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6268_pgtype7[] = {0xFF01,25,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6268_pgtype8[] = {0xFF01,26,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6268_pgtype9[] = {0xFF01,24,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6268_pgtype10[] = {0xFF01,23,0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y6268_pgtype11[] = {0xFF01,23,0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y6268_pgtype12[] = {0xFF01,23,0xFF01,950,0xFFFF};
EIF_TYPE_INDEX *Y6268_gen_type [127];
EIF_TYPE_INDEX Y6268 [127];
void Y6268_init (void)
{
	egc_routines_types [6268] = Y6268;
	egc_routines_gen_types [6268] = Y6268_gen_type;
	egc_routines_offset [6268] = 1227;
	Y6268_gen_type [0] = Y6268_pgtype0;
	Y6268_gen_type [1] = Y6268_pgtype1;
	Y6268_gen_type [2] = Y6268_pgtype2;
	Y6268_gen_type [3] = Y6268_pgtype3;
	Y6268_gen_type [4] = Y6268_pgtype4;
	Y6268_gen_type [5] = Y6268_pgtype5;
	Y6268_gen_type [6] = Y6268_pgtype6;
	Y6268_gen_type [7] = Y6268_pgtype7;
	Y6268_gen_type [8] = Y6268_pgtype8;
	Y6268_gen_type [9] = Y6268_pgtype9;
	Y6268_gen_type [10] = Y6268_pgtype10;
	Y6268_gen_type [11] = Y6268_pgtype11;
	Y6268_gen_type [126] = Y6268_pgtype12;
	{long i; for (i = 0; i < 2; i++) Y6268[i] = 23;};
	Y6268[2] = 25;
	Y6268[3] = 26;
	Y6268[4] = 24;
	{long i; for (i = 5; i < 7; i++) Y6268[i] = 23;};
	Y6268[7] = 25;
	Y6268[8] = 26;
	Y6268[9] = 24;
	{long i; for (i = 10; i < 12; i++) Y6268[i] = 23;};
	Y6268[126] = 23;
}

static EIF_TYPE_INDEX Y6269_pgtype0[] = {0xFF01,23,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6269_pgtype1[] = {0xFF01,24,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6269_pgtype2[] = {0xFF01,23,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6269_pgtype3[] = {0xFF01,27,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6269_pgtype4[] = {0xFF01,24,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6269_pgtype5[] = {0xFF01,23,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6269_pgtype6[] = {0xFF01,24,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6269_pgtype7[] = {0xFF01,23,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6269_pgtype8[] = {0xFF01,27,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6269_pgtype9[] = {0xFF01,24,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6269_pgtype10[] = {0xFF01,23,0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y6269_pgtype11[] = {0xFF01,23,0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y6269_pgtype12[] = {0xFF01,23,0xFF01,950,0xFFFF};
EIF_TYPE_INDEX *Y6269_gen_type [127];
EIF_TYPE_INDEX Y6269 [127];
void Y6269_init (void)
{
	egc_routines_types [6269] = Y6269;
	egc_routines_gen_types [6269] = Y6269_gen_type;
	egc_routines_offset [6269] = 1227;
	Y6269_gen_type [0] = Y6269_pgtype0;
	Y6269_gen_type [1] = Y6269_pgtype1;
	Y6269_gen_type [2] = Y6269_pgtype2;
	Y6269_gen_type [3] = Y6269_pgtype3;
	Y6269_gen_type [4] = Y6269_pgtype4;
	Y6269_gen_type [5] = Y6269_pgtype5;
	Y6269_gen_type [6] = Y6269_pgtype6;
	Y6269_gen_type [7] = Y6269_pgtype7;
	Y6269_gen_type [8] = Y6269_pgtype8;
	Y6269_gen_type [9] = Y6269_pgtype9;
	Y6269_gen_type [10] = Y6269_pgtype10;
	Y6269_gen_type [11] = Y6269_pgtype11;
	Y6269_gen_type [126] = Y6269_pgtype12;
	Y6269[0] = 23;
	Y6269[1] = 24;
	Y6269[2] = 23;
	Y6269[3] = 27;
	Y6269[4] = 24;
	Y6269[5] = 23;
	Y6269[6] = 24;
	Y6269[7] = 23;
	Y6269[8] = 27;
	Y6269[9] = 24;
	{long i; for (i = 10; i < 12; i++) Y6269[i] = 23;};
	Y6269[126] = 23;
}

long O6358[11];
void O6358_init () {
	{long i; for (i = 0; i < 2; i++) O6358[i] = 0;}
	O6358[2] =  + _REFACS_5_;
	{long i; for (i = 3; i < 6; i++) O6358[i] =  + _REFACS_4_;}
	O6358[6] = 0;
	O6358[7] =  + _REFACS_4_;
	{long i; for (i = 8; i < 11; i++) O6358[i] =  + _REFACS_3_;}
}

long O6367[5];
void O6367_init () {
	O6367[0] =  + _REFACS_1_;
	O6367[1] =  + _REFACS_5_;
	{long i; for (i = 2; i < 5; i++) O6367[i] =  + _REFACS_4_;}
}

long O6377[5];
void O6377_init () {
	O6377[0] = + _CHROFF_3_1_;
	O6377[1] = + _CHROFF_7_5_;
	{long i; for (i = 2; i < 5; i++) O6377[i] = + _CHROFF_6_4_;}
}

long O6378[5];
void O6378_init () {
	O6378[0] =  + _REFACS_2_;
	O6378[1] =  + _REFACS_6_;
	{long i; for (i = 2; i < 5; i++) O6378[i] =  + _REFACS_5_;}
}

long O6379[5];
void O6379_init () {
	O6379[0] = + _CHROFF_3_0_;
	O6379[1] = + _CHROFF_7_1_;
	{long i; for (i = 2; i < 5; i++) O6379[i] = + _CHROFF_6_1_;}
}

long O6778[3];
void O6778_init () {
	{long i; for (i = 0; i < 2; i++) O6778[i] = 0;}
	O6778[2] =  + _REFACS_3_;
}

static EIF_TYPE_INDEX Y6778_pgtype0[] = {0xFF01,1186,0xFF01,1276,0xFFFF};
static EIF_TYPE_INDEX Y6778_pgtype1[] = {0xFF01,1186,0xFF01,1277,0xFFFF};
static EIF_TYPE_INDEX Y6778_pgtype2[] = {0xFF01,1186,0xFF01,1278,0xFFFF};
EIF_TYPE_INDEX *Y6778_gen_type [3];
EIF_TYPE_INDEX Y6778 [3];
void Y6778_init (void)
{
	egc_routines_types [6778] = Y6778;
	egc_routines_gen_types [6778] = Y6778_gen_type;
	egc_routines_offset [6778] = 1284;
	Y6778_gen_type [0] = Y6778_pgtype0;
	Y6778_gen_type [1] = Y6778_pgtype1;
	Y6778_gen_type [2] = Y6778_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y6778[i] = 1186;};
}

long O6817[148];
void O6817_init () {
	{long i; for (i = 0; i < 2; i++) O6817[i] = + _LNGOFF_1_0_0_0_;}
	O6817[2] = + _LNGOFF_2_1_0_0_;
	O6817[3] = + _LNGOFF_5_1_0_0_;
	O6817[4] = + _LNGOFF_2_1_0_0_;
	O6817[5] = + _LNGOFF_5_1_0_0_;
	{long i; for (i = 146; i < 148; i++) O6817[i] = + _LNGOFF_12_16_0_1_;}
}

long O6818[148];
void O6818_init () {
	{long i; for (i = 0; i < 2; i++) O6818[i] = + _LNGOFF_1_0_0_1_;}
	O6818[2] = + _LNGOFF_2_1_0_1_;
	O6818[3] = + _LNGOFF_5_1_0_1_;
	O6818[4] = + _LNGOFF_2_1_0_1_;
	O6818[5] = + _LNGOFF_5_1_0_1_;
	{long i; for (i = 146; i < 148; i++) O6818[i] = + _LNGOFF_12_16_0_2_;}
}

long O6819[148];
void O6819_init () {
	{long i; for (i = 0; i < 2; i++) O6819[i] = + _LNGOFF_1_0_0_2_;}
	O6819[2] = + _LNGOFF_2_1_0_2_;
	O6819[3] = + _LNGOFF_5_1_0_2_;
	O6819[4] = + _LNGOFF_2_1_0_2_;
	O6819[5] = + _LNGOFF_5_1_0_2_;
	{long i; for (i = 146; i < 148; i++) O6819[i] = + _LNGOFF_12_16_0_3_;}
}

long O7189[5];
void O7189_init () {
	O7189[0] = 0;
	O7189[1] =  + _REFACS_27_;
	O7189[2] =  + _REFACS_28_;
	{long i; for (i = 3; i < 5; i++) O7189[i] =  + _REFACS_6_;}
}

long O7190[5];
void O7190_init () {
	O7190[0] =  + _REFACS_1_;
	O7190[1] =  + _REFACS_28_;
	O7190[2] =  + _REFACS_29_;
	{long i; for (i = 3; i < 5; i++) O7190[i] =  + _REFACS_7_;}
}

long O7191[5];
void O7191_init () {
	O7191[0] =  + _REFACS_2_;
	O7191[1] =  + _REFACS_29_;
	O7191[2] =  + _REFACS_30_;
	{long i; for (i = 3; i < 5; i++) O7191[i] =  + _REFACS_8_;}
}

long O7192[5];
void O7192_init () {
	O7192[0] =  + _REFACS_3_;
	O7192[1] =  + _REFACS_30_;
	O7192[2] =  + _REFACS_31_;
	{long i; for (i = 3; i < 5; i++) O7192[i] =  + _REFACS_9_;}
}

long O7193[5];
void O7193_init () {
	O7193[0] =  + _REFACS_4_;
	O7193[1] =  + _REFACS_31_;
	O7193[2] =  + _REFACS_32_;
	{long i; for (i = 3; i < 5; i++) O7193[i] =  + _REFACS_10_;}
}

long O7194[5];
void O7194_init () {
	O7194[0] =  + _REFACS_5_;
	O7194[1] =  + _REFACS_32_;
	O7194[2] =  + _REFACS_33_;
	{long i; for (i = 3; i < 5; i++) O7194[i] =  + _REFACS_11_;}
}

long O7195[5];
void O7195_init () {
	O7195[0] =  + _REFACS_6_;
	O7195[1] =  + _REFACS_33_;
	O7195[2] =  + _REFACS_34_;
	{long i; for (i = 3; i < 5; i++) O7195[i] =  + _REFACS_12_;}
}

long O7196[5];
void O7196_init () {
	O7196[0] =  + _REFACS_7_;
	O7196[1] =  + _REFACS_34_;
	O7196[2] =  + _REFACS_35_;
	{long i; for (i = 3; i < 5; i++) O7196[i] =  + _REFACS_13_;}
}

long O7199[5];
void O7199_init () {
	O7199[0] = + _LNGOFF_11_1_0_0_;
	O7199[1] = + _LNGOFF_51_8_0_27_;
	O7199[2] = + _LNGOFF_62_8_0_27_;
	O7199[3] = + _LNGOFF_23_3_0_1_;
	O7199[4] = + _LNGOFF_45_3_0_1_;
}

long O7200[5];
void O7200_init () {
	O7200[0] = + _LNGOFF_11_1_0_1_;
	O7200[1] = + _LNGOFF_51_8_0_28_;
	O7200[2] = + _LNGOFF_62_8_0_28_;
	O7200[3] = + _LNGOFF_23_3_0_2_;
	O7200[4] = + _LNGOFF_45_3_0_2_;
}

long O7201[5];
void O7201_init () {
	O7201[0] = + _LNGOFF_11_1_0_2_;
	O7201[1] = + _LNGOFF_51_8_0_29_;
	O7201[2] = + _LNGOFF_62_8_0_29_;
	O7201[3] = + _LNGOFF_23_3_0_3_;
	O7201[4] = + _LNGOFF_45_3_0_3_;
}

long O7202[5];
void O7202_init () {
	O7202[0] = + _LNGOFF_11_1_0_3_;
	O7202[1] = + _LNGOFF_51_8_0_30_;
	O7202[2] = + _LNGOFF_62_8_0_30_;
	O7202[3] = + _LNGOFF_23_3_0_4_;
	O7202[4] = + _LNGOFF_45_3_0_4_;
}

long O7203[5];
void O7203_init () {
	O7203[0] = + _LNGOFF_11_1_0_4_;
	O7203[1] = + _LNGOFF_51_8_0_31_;
	O7203[2] = + _LNGOFF_62_8_0_31_;
	O7203[3] = + _LNGOFF_23_3_0_5_;
	O7203[4] = + _LNGOFF_45_3_0_5_;
}

long O7204[5];
void O7204_init () {
	O7204[0] = + _LNGOFF_11_1_0_5_;
	O7204[1] = + _LNGOFF_51_8_0_32_;
	O7204[2] = + _LNGOFF_62_8_0_32_;
	O7204[3] = + _LNGOFF_23_3_0_6_;
	O7204[4] = + _LNGOFF_45_3_0_6_;
}

long O7205[5];
void O7205_init () {
	O7205[0] = + _LNGOFF_11_1_0_6_;
	O7205[1] = + _LNGOFF_51_8_0_33_;
	O7205[2] = + _LNGOFF_62_8_0_33_;
	O7205[3] = + _LNGOFF_23_3_0_7_;
	O7205[4] = + _LNGOFF_45_3_0_7_;
}

long O7217[5];
void O7217_init () {
	O7217[0] =  + _REFACS_10_;
	O7217[1] =  + _REFACS_37_;
	O7217[2] =  + _REFACS_38_;
	{long i; for (i = 3; i < 5; i++) O7217[i] =  + _REFACS_16_;}
}

long O7218[5];
void O7218_init () {
	O7218[0] = + _LNGOFF_11_1_0_7_;
	O7218[1] = + _LNGOFF_51_8_0_34_;
	O7218[2] = + _LNGOFF_62_8_0_34_;
	O7218[3] = + _LNGOFF_23_3_0_8_;
	O7218[4] = + _LNGOFF_45_3_0_8_;
}

long O7219[5];
void O7219_init () {
	O7219[0] = + _CHROFF_11_0_;
	O7219[1] = + _CHROFF_51_4_;
	O7219[2] = + _CHROFF_62_4_;
	O7219[3] = + _CHROFF_23_0_;
	O7219[4] = + _CHROFF_45_0_;
}

long O7220[5];
void O7220_init () {
	O7220[0] = + _LNGOFF_11_1_0_8_;
	O7220[1] = + _LNGOFF_51_8_0_35_;
	O7220[2] = + _LNGOFF_62_8_0_35_;
	O7220[3] = + _LNGOFF_23_3_0_9_;
	O7220[4] = + _LNGOFF_45_3_0_9_;
}

long O7221[5];
void O7221_init () {
	O7221[0] = + _LNGOFF_11_1_0_9_;
	O7221[1] = + _LNGOFF_51_8_0_36_;
	O7221[2] = + _LNGOFF_62_8_0_36_;
	O7221[3] = + _LNGOFF_23_3_0_10_;
	O7221[4] = + _LNGOFF_45_3_0_10_;
}

long O7246[5];
void O7246_init () {
	O7246[0] = + _LNGOFF_11_1_0_10_;
	O7246[1] = + _LNGOFF_51_8_0_37_;
	O7246[2] = + _LNGOFF_62_8_0_37_;
	O7246[3] = + _LNGOFF_23_3_0_11_;
	O7246[4] = + _LNGOFF_45_3_0_11_;
}

static EIF_TYPE_INDEX Y7829_pgtype0[] = {0xFF01,1394,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype1[] = {0xFF01,1395,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype2[] = {0xFF01,1413,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype3[] = {0xFF01,1414,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype4[] = {0xFF01,1396,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype5[] = {0xFF01,1397,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype6[] = {0xFF01,1399,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype7[] = {0xFF01,1400,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype8[] = {0xFF01,1401,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype9[] = {0xFF01,1402,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype10[] = {0xFF01,1403,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype11[] = {0xFF01,1404,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype12[] = {0xFF01,1405,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype13[] = {0xFF01,1406,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype14[] = {0xFF01,1407,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype15[] = {0xFF01,1408,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype16[] = {0xFF01,1415,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype17[] = {0xFF01,1416,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype18[] = {0xFF01,1409,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype19[] = {0xFF01,1411,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype20[] = {0xFF01,1419,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype21[] = {0xFF01,1398,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype22[] = {0xFF01,1417,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype23[] = {0xFF01,1410,0xFFFF};
static EIF_TYPE_INDEX Y7829_pgtype24[] = {0xFF01,1418,0xFFFF};
EIF_TYPE_INDEX *Y7829_gen_type [54];
EIF_TYPE_INDEX Y7829 [54];
void Y7829_init (void)
{
	egc_routines_types [7829] = Y7829;
	egc_routines_gen_types [7829] = Y7829_gen_type;
	egc_routines_offset [7829] = 1373;
	Y7829_gen_type [0] = Y7829_pgtype0;
	Y7829_gen_type [1] = Y7829_pgtype1;
	Y7829_gen_type [2] = Y7829_pgtype2;
	Y7829_gen_type [3] = Y7829_pgtype3;
	Y7829_gen_type [4] = Y7829_pgtype4;
	Y7829_gen_type [5] = Y7829_pgtype5;
	Y7829_gen_type [6] = Y7829_pgtype6;
	Y7829_gen_type [7] = Y7829_pgtype7;
	Y7829_gen_type [8] = Y7829_pgtype8;
	Y7829_gen_type [9] = Y7829_pgtype9;
	Y7829_gen_type [10] = Y7829_pgtype10;
	Y7829_gen_type [11] = Y7829_pgtype11;
	Y7829_gen_type [12] = Y7829_pgtype12;
	Y7829_gen_type [13] = Y7829_pgtype13;
	Y7829_gen_type [14] = Y7829_pgtype14;
	Y7829_gen_type [15] = Y7829_pgtype15;
	Y7829_gen_type [16] = Y7829_pgtype16;
	Y7829_gen_type [17] = Y7829_pgtype17;
	Y7829_gen_type [18] = Y7829_pgtype18;
	Y7829_gen_type [19] = Y7829_pgtype19;
	Y7829_gen_type [20] = Y7829_pgtype20;
	Y7829_gen_type [50] = Y7829_pgtype21;
	Y7829_gen_type [51] = Y7829_pgtype22;
	Y7829_gen_type [52] = Y7829_pgtype23;
	Y7829_gen_type [53] = Y7829_pgtype24;
	Y7829[0] = 1394;
	Y7829[1] = 1395;
	Y7829[2] = 1413;
	Y7829[3] = 1414;
	Y7829[4] = 1396;
	Y7829[5] = 1397;
	Y7829[6] = 1399;
	Y7829[7] = 1400;
	Y7829[8] = 1401;
	Y7829[9] = 1402;
	Y7829[10] = 1403;
	Y7829[11] = 1404;
	Y7829[12] = 1405;
	Y7829[13] = 1406;
	Y7829[14] = 1407;
	Y7829[15] = 1408;
	Y7829[16] = 1415;
	Y7829[17] = 1416;
	Y7829[18] = 1409;
	Y7829[19] = 1411;
	Y7829[20] = 1419;
	Y7829[50] = 1398;
	Y7829[51] = 1417;
	Y7829[52] = 1410;
	Y7829[53] = 1418;
}

long O7961[26];
void O7961_init () {
	O7961[0] = + _LNGOFF_2_0_0_0_;
	O7961[1] = + _LNGOFF_4_0_0_0_;
	O7961[2] = + _LNGOFF_6_1_0_0_;
	O7961[3] = + _LNGOFF_4_0_0_0_;
	O7961[4] = + _LNGOFF_7_3_0_0_;
	O7961[5] = + _LNGOFF_7_6_0_0_;
	O7961[6] = + _LNGOFF_8_2_0_0_;
	O7961[7] = + _LNGOFF_6_8_0_0_;
	O7961[8] = + _LNGOFF_7_0_0_0_;
	O7961[9] = + _LNGOFF_3_0_0_0_;
	{long i; for (i = 10; i < 12; i++) O7961[i] = + _LNGOFF_4_0_0_0_;}
	O7961[12] = + _LNGOFF_6_1_0_0_;
	O7961[13] = + _LNGOFF_8_3_0_0_;
	O7961[14] = + _LNGOFF_10_8_0_0_;
	O7961[15] = + _LNGOFF_7_1_0_0_;
	O7961[16] = + _LNGOFF_4_0_0_0_;
	{long i; for (i = 17; i < 19; i++) O7961[i] = + _LNGOFF_2_0_0_0_;}
	O7961[19] = + _LNGOFF_6_0_0_0_;
	O7961[20] = + _LNGOFF_6_1_0_0_;
	O7961[21] = + _LNGOFF_7_2_0_0_;
	O7961[22] = + _LNGOFF_11_0_0_0_;
	O7961[23] = + _LNGOFF_7_0_0_0_;
	O7961[24] = + _LNGOFF_8_1_0_0_;
	O7961[25] = + _LNGOFF_10_1_0_0_;
}


#ifdef __cplusplus
}
#endif
