#include "epoly10.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4759[488])();
void R4759_init () {
	{long i; for (i = 0; i < 2; i++) R4759[i] = (char *(*)()) F949_6152;}
	{long i; for (i = 486; i < 488; i++) R4759[i] = (char *(*)()) F1436_11366;}
}

char *(*R4764[487])();
void R4764_init () {
	R4764[0] = (char *(*)()) F951_6256;
	{long i; for (i = 485; i < 487; i++) R4764[i] = (char *(*)()) F1436_11344;}
}

char *(*R4772[488])();
void R4772_init () {
	R4772[0] = (char *(*)()) F950_6197;
	R4772[1] = (char *(*)()) F949_6176;
	{long i; for (i = 486; i < 488; i++) R4772[i] = (char *(*)()) F949_6176;}
}

char *(*R4798[487])();
void R4798_init () {
	R4798[0] = (char *(*)()) F951_6237;
	{long i; for (i = 485; i < 487; i++) R4798[i] = (char *(*)()) F1436_11382;}
}

char *(*R4800[487])();
void R4800_init () {
	R4800[0] = (char *(*)()) F951_6239;
	{long i; for (i = 485; i < 487; i++) R4800[i] = (char *(*)()) F1436_11380;}
}

char *(*R4802[487])();
void R4802_init () {
	R4802[0] = (char *(*)()) F951_6250;
	{long i; for (i = 485; i < 487; i++) R4802[i] = (char *(*)()) F1436_11379;}
}

char *(*R4966[6])();
void R4966_init () {
	R4966[0] = (char *(*)()) F959_6436;
	R4966[1] = (char *(*)()) F960_6436;
	R4966[2] = (char *(*)()) F961_6436;
	R4966[3] = (char *(*)()) F962_6436;
	R4966[4] = (char *(*)()) F963_6436;
	R4966[5] = (char *(*)()) F964_6436;
}

char *(*R4976[273])();
void R4976_init () {
	R4976[0] = (char *(*)()) F981_6599;
	R4976[3] = (char *(*)()) F984_6660;
	R4976[8] = (char *(*)()) F965_6445;
	{long i; for (i = 271; i < 273; i++) R4976[i] = (char *(*)()) F1251_8623;}
}

char *(*R5171[439])();
void R5171_init () {
	R5171[0] = (char *(*)()) F999_6748;
	R5171[1] = (char *(*)()) F1000_6756;
	R5171[2] = (char *(*)()) F1001_6761;
	{long i; for (i = 248; i < 250; i++) R5171[i] = (char *(*)()) F1246_8594;}
	{long i; for (i = 437; i < 439; i++) R5171[i] = (char *(*)()) F1436_11381;}
}

char *(*R5183[439])();
void R5183_init () {
	R5183[0] = (char *(*)()) F999_6749;
	R5183[1] = (char *(*)()) F1000_6757;
	R5183[2] = (char *(*)()) F1001_6765;
	{long i; for (i = 248; i < 250; i++) R5183[i] = (char *(*)()) F1246_8599;}
	{long i; for (i = 437; i < 439; i++) R5183[i] = (char *(*)()) F1436_11424;}
}

char *(*R5191[439])();
void R5191_init () {
	R5191[0] = (char *(*)()) F999_6745;
	R5191[1] = (char *(*)()) F1000_6753;
	R5191[2] = (char *(*)()) F1001_6764;
	R5191[248] = (char *(*)()) F1247_8608;
	{long i; for (i = 437; i < 439; i++) R5191[i] = (char *(*)()) F1436_11422;}
}

char *(*R5286[7])();
void R5286_init () {
	{long i; for (i = 0; i < 2; i++) R5286[i] = (char *(*)()) F1303_9493;}
	R5286[2] = (char *(*)()) F1306_9636;
	R5286[3] = (char *(*)()) F1307_9638;
	R5286[6] = (char *(*)()) F1018_7056;
}

char *(*R5313[7])();
void R5313_init () {
	R5313[0] = (char *(*)()) F1018_7057;
	R5313[1] = (char *(*)()) F1305_9620;
	R5313[2] = (char *(*)()) F1306_9635;
	R5313[3] = (char *(*)()) F1307_9637;
	R5313[6] = (char *(*)()) F1018_7057;
}

char *(*R5346[7])();
void R5346_init () {
	{long i; for (i = 0; i < 4; i++) R5346[i] = (char *(*)()) F1303_9510;}
	R5346[6] = (char *(*)()) F1015_6956;
}

char *(*R5347[7])();
void R5347_init () {
	{long i; for (i = 0; i < 4; i++) R5347[i] = (char *(*)()) F1303_9511;}
	R5347[6] = (char *(*)()) F1019_7131;
}

char *(*R5357[7])();
void R5357_init () {
	{long i; for (i = 0; i < 4; i++) R5357[i] = (char *(*)()) F1304_9523;}
	R5357[6] = (char *(*)()) F1301_9361;
}

char *(*R5360[7])();
void R5360_init () {
	{long i; for (i = 0; i < 4; i++) R5360[i] = (char *(*)()) F1304_9524;}
	R5360[6] = (char *(*)()) F1301_9362;
}

char *(*R5361[7])();
void R5361_init () {
	{long i; for (i = 0; i < 4; i++) R5361[i] = (char *(*)()) F1304_9525;}
	R5361[6] = (char *(*)()) F1301_9363;
}

char *(*R5391[7])();
void R5391_init () {
	{long i; for (i = 0; i < 4; i++) R5391[i] = (char *(*)()) F1304_9596;}
	R5391[6] = (char *(*)()) F1301_9387;
}

char *(*R5393[7])();
void R5393_init () {
	{long i; for (i = 0; i < 4; i++) R5393[i] = (char *(*)()) F1304_9597;}
	R5393[6] = (char *(*)()) F1301_9388;
}

char *(*R5394[7])();
void R5394_init () {
	{long i; for (i = 0; i < 4; i++) R5394[i] = (char *(*)()) F1304_9598;}
	R5394[6] = (char *(*)()) F1301_9389;
}

char *(*R5395[7])();
void R5395_init () {
	{long i; for (i = 0; i < 4; i++) R5395[i] = (char *(*)()) F1304_9590;}
	R5395[6] = (char *(*)()) F1301_9381;
}

char *(*R5396[7])();
void R5396_init () {
	{long i; for (i = 0; i < 4; i++) R5396[i] = (char *(*)()) F1304_9591;}
	R5396[6] = (char *(*)()) F1301_9382;
}

char *(*R5429[7])();
void R5429_init () {
	{long i; for (i = 0; i < 4; i++) R5429[i] = (char *(*)()) F1304_9588;}
	R5429[6] = (char *(*)()) F1301_9379;
}

char *(*R5430[7])();
void R5430_init () {
	{long i; for (i = 0; i < 4; i++) R5430[i] = (char *(*)()) F1304_9589;}
	R5430[6] = (char *(*)()) F1301_9380;
}

char *(*R5431[7])();
void R5431_init () {
	{long i; for (i = 0; i < 4; i++) R5431[i] = (char *(*)()) F1304_9592;}
	R5431[6] = (char *(*)()) F1301_9383;
}

char *(*R5432[7])();
void R5432_init () {
	{long i; for (i = 0; i < 4; i++) R5432[i] = (char *(*)()) F1304_9593;}
	R5432[6] = (char *(*)()) F1301_9384;
}

char *(*R5433[7])();
void R5433_init () {
	{long i; for (i = 0; i < 4; i++) R5433[i] = (char *(*)()) F1304_9594;}
	R5433[6] = (char *(*)()) F1301_9385;
}

char *(*R5434[7])();
void R5434_init () {
	{long i; for (i = 0; i < 4; i++) R5434[i] = (char *(*)()) F1304_9595;}
	R5434[6] = (char *(*)()) F1301_9386;
}

char *(*R5704[25])();
void R5704_init () {
	R5704[0] = (char *(*)()) F1086_7440;
	R5704[1] = (char *(*)()) F1087_7440;
	R5704[12] = (char *(*)()) F1098_7448;
	R5704[13] = (char *(*)()) F1099_7448;
	R5704[14] = (char *(*)()) F1100_7448;
	R5704[15] = (char *(*)()) F1101_7448;
	R5704[16] = (char *(*)()) F1102_7448;
	R5704[20] = (char *(*)()) F1106_7469;
	R5704[21] = (char *(*)()) F1107_7469;
	R5704[22] = (char *(*)()) F1108_7484;
	R5704[23] = (char *(*)()) F1109_7484;
	R5704[24] = (char *(*)()) F1110_7496;
}

char *(*R5705[25])();
void R5705_init () {
	R5705[0] = (char *(*)()) F1077_7425;
	R5705[1] = (char *(*)()) F1079_7425;
	R5705[12] = (char *(*)()) F1077_7425;
	R5705[13] = (char *(*)()) F1078_7425;
	R5705[14] = (char *(*)()) F1080_7425;
	R5705[15] = (char *(*)()) F1081_7425;
	R5705[16] = (char *(*)()) F1079_7425;
	R5705[20] = (char *(*)()) F1061_7405;
	R5705[21] = (char *(*)()) F1062_7405;
	R5705[22] = (char *(*)()) F1108_7487;
	R5705[23] = (char *(*)()) F1109_7487;
	R5705[24] = (char *(*)()) F1108_7487;
}

char *(*R5706[25])();
void R5706_init () {
	R5706[0] = (char *(*)()) F1039_7378;
	R5706[1] = (char *(*)()) F1040_7378;
	{long i; for (i = 12; i < 14; i++) R5706[i] = (char *(*)()) F1039_7378;}
	R5706[14] = (char *(*)()) F1042_7378;
	R5706[15] = (char *(*)()) F1043_7378;
	R5706[16] = (char *(*)()) F1040_7378;
	R5706[20] = (char *(*)()) F1039_7378;
	R5706[21] = (char *(*)()) F1040_7378;
	R5706[22] = (char *(*)()) F1108_7488;
	R5706[23] = (char *(*)()) F1109_7488;
	R5706[24] = (char *(*)()) F1108_7488;
}

char *(*R5710[25])();
void R5710_init () {
	R5710[0] = (char *(*)()) F1039_7384;
	R5710[1] = (char *(*)()) F1040_7384;
	{long i; for (i = 12; i < 14; i++) R5710[i] = (char *(*)()) F1039_7384;}
	R5710[14] = (char *(*)()) F1042_7384;
	R5710[15] = (char *(*)()) F1043_7384;
	R5710[16] = (char *(*)()) F1040_7384;
	R5710[20] = (char *(*)()) F1039_7384;
	R5710[21] = (char *(*)()) F1040_7384;
	R5710[22] = (char *(*)()) F1039_7384;
	R5710[23] = (char *(*)()) F1041_7384;
	R5710[24] = (char *(*)()) F1039_7384;
}

char *(*R5712[5])();
void R5712_init () {
	R5712[0] = (char *(*)()) F1103_7450;
	R5712[1] = (char *(*)()) F1104_7450;
	R5712[2] = (char *(*)()) F1103_7450;
	R5712[3] = (char *(*)()) F1105_7450;
	R5712[4] = (char *(*)()) F1103_7450;
}

char *(*R5717[25])();
void R5717_init () {
	R5717[0] = (char *(*)()) F1053_7392;
	R5717[1] = (char *(*)()) F1054_7392;
	{long i; for (i = 12; i < 14; i++) R5717[i] = (char *(*)()) F1053_7392;}
	R5717[14] = (char *(*)()) F1056_7392;
	R5717[15] = (char *(*)()) F1058_7392;
	R5717[16] = (char *(*)()) F1054_7392;
	R5717[20] = (char *(*)()) F1053_7392;
	R5717[21] = (char *(*)()) F1054_7392;
	R5717[22] = (char *(*)()) F1053_7392;
	R5717[23] = (char *(*)()) F1055_7392;
	R5717[24] = (char *(*)()) F1053_7392;
}

char *(*R5718[25])();
void R5718_init () {
	R5718[0] = (char *(*)()) F1053_7395;
	R5718[1] = (char *(*)()) F1054_7395;
	{long i; for (i = 12; i < 14; i++) R5718[i] = (char *(*)()) F1053_7395;}
	R5718[14] = (char *(*)()) F1056_7395;
	R5718[15] = (char *(*)()) F1058_7395;
	R5718[16] = (char *(*)()) F1054_7395;
	R5718[20] = (char *(*)()) F1053_7395;
	R5718[21] = (char *(*)()) F1054_7395;
	R5718[22] = (char *(*)()) F1053_7395;
	R5718[23] = (char *(*)()) F1055_7395;
	R5718[24] = (char *(*)()) F1053_7395;
}

char *(*R5721[25])();
void R5721_init () {
	R5721[0] = (char *(*)()) F1061_7403;
	R5721[1] = (char *(*)()) F1062_7403;
	{long i; for (i = 12; i < 14; i++) R5721[i] = (char *(*)()) F1061_7403;}
	R5721[14] = (char *(*)()) F1064_7403;
	R5721[15] = (char *(*)()) F1066_7403;
	R5721[16] = (char *(*)()) F1062_7403;
	R5721[20] = (char *(*)()) F1061_7403;
	R5721[21] = (char *(*)()) F1062_7403;
	R5721[22] = (char *(*)()) F1061_7403;
	R5721[23] = (char *(*)()) F1063_7403;
	R5721[24] = (char *(*)()) F1061_7403;
}

char *(*R5722[25])();
void R5722_init () {
	R5722[0] = (char *(*)()) F1077_7424;
	R5722[1] = (char *(*)()) F1079_7424;
	R5722[12] = (char *(*)()) F1077_7424;
	R5722[13] = (char *(*)()) F1078_7424;
	R5722[14] = (char *(*)()) F1080_7424;
	R5722[15] = (char *(*)()) F1081_7424;
	R5722[16] = (char *(*)()) F1079_7424;
	R5722[20] = (char *(*)()) F1106_7471;
	R5722[21] = (char *(*)()) F1107_7471;
	R5722[22] = (char *(*)()) F1108_7486;
	R5722[23] = (char *(*)()) F1109_7486;
	R5722[24] = (char *(*)()) F1108_7486;
}

char *(*R5734[17])();
void R5734_init () {
	R5734[0] = (char *(*)()) F1077_7421;
	R5734[1] = (char *(*)()) F1079_7421;
	R5734[12] = (char *(*)()) F1077_7421;
	R5734[13] = (char *(*)()) F1078_7421;
	R5734[14] = (char *(*)()) F1080_7421;
	R5734[15] = (char *(*)()) F1081_7421;
	R5734[16] = (char *(*)()) F1079_7421;
}

char *(*R5736[17])();
void R5736_init () {
	R5736[0] = (char *(*)()) F1077_7427;
	R5736[1] = (char *(*)()) F1079_7427;
	R5736[12] = (char *(*)()) F1077_7427;
	R5736[13] = (char *(*)()) F1078_7427;
	R5736[14] = (char *(*)()) F1080_7427;
	R5736[15] = (char *(*)()) F1081_7427;
	R5736[16] = (char *(*)()) F1079_7427;
}

char *(*R5737[17])();
void R5737_init () {
	R5737[0] = (char *(*)()) F1077_7428;
	R5737[1] = (char *(*)()) F1079_7428;
	R5737[12] = (char *(*)()) F1077_7428;
	R5737[13] = (char *(*)()) F1078_7428;
	R5737[14] = (char *(*)()) F1080_7428;
	R5737[15] = (char *(*)()) F1081_7428;
	R5737[16] = (char *(*)()) F1079_7428;
}

char *(*R5738[17])();
void R5738_init () {
	R5738[0] = (char *(*)()) F1077_7429;
	R5738[1] = (char *(*)()) F1079_7429;
	R5738[12] = (char *(*)()) F1077_7429;
	R5738[13] = (char *(*)()) F1078_7429;
	R5738[14] = (char *(*)()) F1080_7429;
	R5738[15] = (char *(*)()) F1081_7429;
	R5738[16] = (char *(*)()) F1079_7429;
}

char *(*R5742[17])();
void R5742_init () {
	R5742[0] = (char *(*)()) F1077_7435;
	R5742[1] = (char *(*)()) F1079_7435;
	R5742[12] = (char *(*)()) F1077_7435;
	R5742[13] = (char *(*)()) F1078_7435;
	R5742[14] = (char *(*)()) F1080_7435;
	R5742[15] = (char *(*)()) F1081_7435;
	R5742[16] = (char *(*)()) F1079_7435;
}

char *(*R5758[2])();
void R5758_init () {
	R5758[0] = (char *(*)()) F1106_7468;
	R5758[1] = (char *(*)()) F1107_7468;
}

char *(*R5760[2])();
void R5760_init () {
	R5760[0] = (char *(*)()) F1106_7474;
	R5760[1] = (char *(*)()) F1107_7474;
}

char *(*R5761[2])();
void R5761_init () {
	R5761[0] = (char *(*)()) F1106_7475;
	R5761[1] = (char *(*)()) F1107_7475;
}

char *(*R5765[2])();
void R5765_init () {
	R5765[0] = (char *(*)()) F1106_7481;
	R5765[1] = (char *(*)()) F1107_7481;
}

char *(*R5767[3])();
void R5767_init () {
	R5767[0] = (char *(*)()) F1108_7482;
	R5767[1] = (char *(*)()) F1109_7482;
	R5767[2] = (char *(*)()) F1108_7482;
}

char *(*R5769[3])();
void R5769_init () {
	R5769[0] = (char *(*)()) F1108_7491;
	R5769[1] = (char *(*)()) F1109_7491;
	R5769[2] = (char *(*)()) F1108_7491;
}

char *(*R5770[3])();
void R5770_init () {
	R5770[0] = (char *(*)()) F1108_7492;
	R5770[1] = (char *(*)()) F1109_7492;
	R5770[2] = (char *(*)()) F1108_7492;
}

char *(*R5771[3])();
void R5771_init () {
	R5771[0] = (char *(*)()) F1108_7493;
	R5771[1] = (char *(*)()) F1109_7493;
	R5771[2] = (char *(*)()) F1108_7493;
}

char *(*R5772[3])();
void R5772_init () {
	R5772[0] = (char *(*)()) F1108_7494;
	R5772[1] = (char *(*)()) F1109_7494;
	R5772[2] = (char *(*)()) F1108_7494;
}

static EIF_TYPE_INDEX Y5824_pgtype0[] = {0xFF01,1112,0xFFFF};
static EIF_TYPE_INDEX Y5824_pgtype1[] = {0xFF01,1113,0xFFFF};
static EIF_TYPE_INDEX Y5824_pgtype2[] = {0xFF01,1114,0xFFFF};
static EIF_TYPE_INDEX Y5824_pgtype3[] = {0xFF01,1114,0xFFFF};
static EIF_TYPE_INDEX Y5824_pgtype4[] = {0xFF01,1114,0xFFFF};
EIF_TYPE_INDEX *Y5824_gen_type [5];
EIF_TYPE_INDEX Y5824 [5];
void Y5824_init (void)
{
	egc_routines_types [5824] = Y5824;
	egc_routines_gen_types [5824] = Y5824_gen_type;
	egc_routines_offset [5824] = 1115;
	Y5824_gen_type [0] = Y5824_pgtype0;
	Y5824_gen_type [1] = Y5824_pgtype1;
	Y5824_gen_type [2] = Y5824_pgtype2;
	Y5824_gen_type [3] = Y5824_pgtype3;
	Y5824_gen_type [4] = Y5824_pgtype4;
	Y5824[0] = 1112;
	Y5824[1] = 1113;
	{long i; for (i = 2; i < 5; i++) Y5824[i] = 1114;};
}

char *(*R5918[3])();
void R5918_init () {
	R5918[0] = (char *(*)()) F1121_7657;
	R5918[1] = (char *(*)()) F1123_7663;
	R5918[2] = (char *(*)()) F1124_7669;
}

char *(*R5919[3])();
void R5919_init () {
	R5919[0] = (char *(*)()) F1121_7658;
	R5919[1] = (char *(*)()) F1123_7664;
	R5919[2] = (char *(*)()) F1124_7670;
}

char *(*R5929[170])();
void R5929_init () {
	R5929[0] = (char *(*)()) F1185_7915;
	R5929[1] = (char *(*)()) F1186_7915;
	{long i; for (i = 2; i < 5; i++) R5929[i] = (char *(*)()) F1185_7915;}
	R5929[11] = (char *(*)()) F1196_8054;
	R5929[12] = (char *(*)()) F1197_8054;
	R5929[16] = (char *(*)()) F1201_8083;
	R5929[21] = (char *(*)()) F1206_8116;
	R5929[22] = (char *(*)()) F1207_8116;
	R5929[23] = (char *(*)()) F1208_8116;
	R5929[24] = (char *(*)()) F1209_8151;
	R5929[25] = (char *(*)()) F1210_8151;
	R5929[26] = (char *(*)()) F1209_8151;
	R5929[36] = (char *(*)()) F1212_8236;
	R5929[37] = (char *(*)()) F1214_8236;
	R5929[48] = (char *(*)()) F1212_8236;
	R5929[49] = (char *(*)()) F1213_8236;
	R5929[50] = (char *(*)()) F1215_8236;
	R5929[51] = (char *(*)()) F1216_8236;
	R5929[52] = (char *(*)()) F1214_8236;
	{long i; for (i = 53; i < 55; i++) R5929[i] = (char *(*)()) F1212_8236;}
	R5929[169] = (char *(*)()) F1212_8236;
}

char *(*R5930[170])();
void R5930_init () {
	R5930[0] = (char *(*)()) F1125_7674;
	R5930[1] = (char *(*)()) F1127_7674;
	{long i; for (i = 2; i < 5; i++) R5930[i] = (char *(*)()) F1125_7674;}
	R5930[11] = (char *(*)()) F1125_7674;
	R5930[12] = (char *(*)()) F1127_7674;
	R5930[16] = (char *(*)()) F1125_7674;
	R5930[21] = (char *(*)()) F1125_7674;
	R5930[22] = (char *(*)()) F1128_7674;
	R5930[23] = (char *(*)()) F1126_7674;
	R5930[24] = (char *(*)()) F1125_7674;
	R5930[25] = (char *(*)()) F1126_7674;
	R5930[26] = (char *(*)()) F1125_7674;
	R5930[36] = (char *(*)()) F1125_7674;
	R5930[37] = (char *(*)()) F1126_7674;
	{long i; for (i = 48; i < 50; i++) R5930[i] = (char *(*)()) F1125_7674;}
	R5930[50] = (char *(*)()) F1128_7674;
	R5930[51] = (char *(*)()) F1129_7674;
	R5930[52] = (char *(*)()) F1126_7674;
	{long i; for (i = 53; i < 55; i++) R5930[i] = (char *(*)()) F1125_7674;}
	R5930[169] = (char *(*)()) F1125_7674;
}

char *(*R5931[170])();
void R5931_init () {
	R5931[0] = (char *(*)()) F1185_7965;
	R5931[1] = (char *(*)()) F1186_7965;
	{long i; for (i = 2; i < 5; i++) R5931[i] = (char *(*)()) F1185_7965;}
	R5931[11] = (char *(*)()) F1196_8065;
	R5931[12] = (char *(*)()) F1197_8065;
	R5931[24] = (char *(*)()) F1209_8193;
	R5931[25] = (char *(*)()) F1210_8193;
	R5931[26] = (char *(*)()) F1209_8193;
	R5931[36] = (char *(*)()) F1212_8254;
	R5931[37] = (char *(*)()) F1214_8254;
	R5931[48] = (char *(*)()) F1212_8254;
	R5931[49] = (char *(*)()) F1213_8254;
	R5931[50] = (char *(*)()) F1215_8254;
	R5931[51] = (char *(*)()) F1216_8254;
	R5931[52] = (char *(*)()) F1214_8254;
	{long i; for (i = 53; i < 55; i++) R5931[i] = (char *(*)()) F1212_8254;}
	R5931[169] = (char *(*)()) F1212_8254;
}

static EIF_TYPE_INDEX Y5938_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype38[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype39[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype40[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype41[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype42[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype64[] = {0xFF01,153,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype86[] = {0xFF01,4,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype113[] = {0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype114[] = {0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y5938_pgtype115[] = {0xFF01,950,0xFFFF};
EIF_TYPE_INDEX *Y5938_gen_type [230];
EIF_TYPE_INDEX Y5938 [230];
void Y5938_init (void)
{
	egc_routines_types [5938] = Y5938;
	egc_routines_gen_types [5938] = Y5938_gen_type;
	egc_routines_offset [5938] = 1124;
	Y5938_gen_type [0] = Y5938_pgtype0;
	Y5938_gen_type [1] = Y5938_pgtype1;
	Y5938_gen_type [2] = Y5938_pgtype2;
	Y5938_gen_type [3] = Y5938_pgtype3;
	Y5938_gen_type [4] = Y5938_pgtype4;
	Y5938_gen_type [5] = Y5938_pgtype5;
	Y5938_gen_type [6] = Y5938_pgtype6;
	Y5938_gen_type [7] = Y5938_pgtype7;
	Y5938_gen_type [8] = Y5938_pgtype8;
	Y5938_gen_type [9] = Y5938_pgtype9;
	Y5938_gen_type [10] = Y5938_pgtype10;
	Y5938_gen_type [11] = Y5938_pgtype11;
	Y5938_gen_type [12] = Y5938_pgtype12;
	Y5938_gen_type [13] = Y5938_pgtype13;
	Y5938_gen_type [14] = Y5938_pgtype14;
	Y5938_gen_type [15] = Y5938_pgtype15;
	Y5938_gen_type [16] = Y5938_pgtype16;
	Y5938_gen_type [17] = Y5938_pgtype17;
	Y5938_gen_type [18] = Y5938_pgtype18;
	Y5938_gen_type [19] = Y5938_pgtype19;
	Y5938_gen_type [20] = Y5938_pgtype20;
	Y5938_gen_type [21] = Y5938_pgtype21;
	Y5938_gen_type [22] = Y5938_pgtype22;
	Y5938_gen_type [23] = Y5938_pgtype23;
	Y5938_gen_type [24] = Y5938_pgtype24;
	Y5938_gen_type [25] = Y5938_pgtype25;
	Y5938_gen_type [26] = Y5938_pgtype26;
	Y5938_gen_type [27] = Y5938_pgtype27;
	Y5938_gen_type [28] = Y5938_pgtype28;
	Y5938_gen_type [29] = Y5938_pgtype29;
	Y5938_gen_type [30] = Y5938_pgtype30;
	Y5938_gen_type [31] = Y5938_pgtype31;
	Y5938_gen_type [32] = Y5938_pgtype32;
	Y5938_gen_type [33] = Y5938_pgtype33;
	Y5938_gen_type [34] = Y5938_pgtype34;
	Y5938_gen_type [35] = Y5938_pgtype35;
	Y5938_gen_type [36] = Y5938_pgtype36;
	Y5938_gen_type [37] = Y5938_pgtype37;
	Y5938_gen_type [38] = Y5938_pgtype38;
	Y5938_gen_type [39] = Y5938_pgtype39;
	Y5938_gen_type [40] = Y5938_pgtype40;
	Y5938_gen_type [41] = Y5938_pgtype41;
	Y5938_gen_type [42] = Y5938_pgtype42;
	Y5938_gen_type [43] = Y5938_pgtype43;
	Y5938_gen_type [44] = Y5938_pgtype44;
	Y5938_gen_type [45] = Y5938_pgtype45;
	Y5938_gen_type [46] = Y5938_pgtype46;
	Y5938_gen_type [47] = Y5938_pgtype47;
	Y5938_gen_type [48] = Y5938_pgtype48;
	Y5938_gen_type [49] = Y5938_pgtype49;
	Y5938_gen_type [50] = Y5938_pgtype50;
	Y5938_gen_type [51] = Y5938_pgtype51;
	Y5938_gen_type [52] = Y5938_pgtype52;
	Y5938_gen_type [53] = Y5938_pgtype53;
	Y5938_gen_type [54] = Y5938_pgtype54;
	Y5938_gen_type [55] = Y5938_pgtype55;
	Y5938_gen_type [56] = Y5938_pgtype56;
	Y5938_gen_type [57] = Y5938_pgtype57;
	Y5938_gen_type [58] = Y5938_pgtype58;
	Y5938_gen_type [59] = Y5938_pgtype59;
	Y5938_gen_type [60] = Y5938_pgtype60;
	Y5938_gen_type [61] = Y5938_pgtype61;
	Y5938_gen_type [62] = Y5938_pgtype62;
	Y5938_gen_type [63] = Y5938_pgtype63;
	Y5938_gen_type [64] = Y5938_pgtype64;
	Y5938_gen_type [65] = Y5938_pgtype65;
	Y5938_gen_type [66] = Y5938_pgtype66;
	Y5938_gen_type [67] = Y5938_pgtype67;
	Y5938_gen_type [68] = Y5938_pgtype68;
	Y5938_gen_type [69] = Y5938_pgtype69;
	Y5938_gen_type [70] = Y5938_pgtype70;
	Y5938_gen_type [71] = Y5938_pgtype71;
	Y5938_gen_type [72] = Y5938_pgtype72;
	Y5938_gen_type [73] = Y5938_pgtype73;
	Y5938_gen_type [74] = Y5938_pgtype74;
	Y5938_gen_type [75] = Y5938_pgtype75;
	Y5938_gen_type [76] = Y5938_pgtype76;
	Y5938_gen_type [77] = Y5938_pgtype77;
	Y5938_gen_type [78] = Y5938_pgtype78;
	Y5938_gen_type [79] = Y5938_pgtype79;
	Y5938_gen_type [80] = Y5938_pgtype80;
	Y5938_gen_type [81] = Y5938_pgtype81;
	Y5938_gen_type [82] = Y5938_pgtype82;
	Y5938_gen_type [83] = Y5938_pgtype83;
	Y5938_gen_type [84] = Y5938_pgtype84;
	Y5938_gen_type [85] = Y5938_pgtype85;
	Y5938_gen_type [86] = Y5938_pgtype86;
	Y5938_gen_type [87] = Y5938_pgtype87;
	Y5938_gen_type [88] = Y5938_pgtype88;
	Y5938_gen_type [89] = Y5938_pgtype89;
	Y5938_gen_type [90] = Y5938_pgtype90;
	Y5938_gen_type [91] = Y5938_pgtype91;
	Y5938_gen_type [92] = Y5938_pgtype92;
	Y5938_gen_type [93] = Y5938_pgtype93;
	Y5938_gen_type [94] = Y5938_pgtype94;
	Y5938_gen_type [95] = Y5938_pgtype95;
	Y5938_gen_type [96] = Y5938_pgtype96;
	Y5938_gen_type [97] = Y5938_pgtype97;
	Y5938_gen_type [98] = Y5938_pgtype98;
	Y5938_gen_type [99] = Y5938_pgtype99;
	Y5938_gen_type [100] = Y5938_pgtype100;
	Y5938_gen_type [101] = Y5938_pgtype101;
	Y5938_gen_type [102] = Y5938_pgtype102;
	Y5938_gen_type [103] = Y5938_pgtype103;
	Y5938_gen_type [104] = Y5938_pgtype104;
	Y5938_gen_type [105] = Y5938_pgtype105;
	Y5938_gen_type [106] = Y5938_pgtype106;
	Y5938_gen_type [107] = Y5938_pgtype107;
	Y5938_gen_type [108] = Y5938_pgtype108;
	Y5938_gen_type [109] = Y5938_pgtype109;
	Y5938_gen_type [110] = Y5938_pgtype110;
	Y5938_gen_type [111] = Y5938_pgtype111;
	Y5938_gen_type [112] = Y5938_pgtype112;
	Y5938_gen_type [113] = Y5938_pgtype113;
	Y5938_gen_type [114] = Y5938_pgtype114;
	Y5938_gen_type [229] = Y5938_pgtype115;
	Y5938[64] = 153;
	Y5938[86] = 4;
	{long i; for (i = 113; i < 115; i++) Y5938[i] = 950;};
	Y5938[229] = 950;
}

char *(*R5940[122])();
void R5940_init () {
	R5940[0] = (char *(*)()) F1223_8394;
	R5940[1] = (char *(*)()) F1224_8394_5940_5;
	R5940[2] = (char *(*)()) F1225_8394_5940_5;
	R5940[3] = (char *(*)()) F1226_8394_5940_5;
	R5940[4] = (char *(*)()) F1227_8394_5940_5;
	{long i; for (i = 5; i < 7; i++) R5940[i] = (char *(*)()) F1223_8394;}
	R5940[121] = (char *(*)()) F1223_8394;
}
static EIF_REFERENCE F1224_8394_5940_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1224_8394(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F1225_8394_5940_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1225_8394(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(903, 0x00).id, 903, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1226_8394_5940_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1226_8394(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(879, 0x00).id, 879, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1227_8394_5940_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1227_8394(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5943[122])();
void R5943_init () {
	R5943[0] = (char *(*)()) F1223_8402;
	R5943[1] = (char *(*)()) F1224_8402_5943_2;
	R5943[2] = (char *(*)()) F1225_8402;
	R5943[3] = (char *(*)()) F1226_8402_5943_2;
	R5943[4] = (char *(*)()) F1227_8402_5943_2;
	{long i; for (i = 5; i < 7; i++) R5943[i] = (char *(*)()) F1223_8402;}
	R5943[121] = (char *(*)()) F1223_8402;
}
static EIF_BOOLEAN F1224_8402_5943_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1224_8402(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1226_8402_5943_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1226_8402(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1227_8402_5943_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1227_8402(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5947[122])();
void R5947_init () {
	R5947[0] = (char *(*)()) F1223_8415;
	R5947[1] = (char *(*)()) F1224_8415_5947_20;
	R5947[2] = (char *(*)()) F1225_8415_5947_20;
	R5947[3] = (char *(*)()) F1226_8415_5947_20;
	R5947[4] = (char *(*)()) F1227_8415_5947_20;
	{long i; for (i = 5; i < 7; i++) R5947[i] = (char *(*)()) F1223_8415;}
	R5947[121] = (char *(*)()) F1223_8415;
}
static void F1224_8415_5947_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1224_8415(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1225_8415_5947_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1225_8415(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1226_8415_5947_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1226_8415(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static void F1227_8415_5947_20 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1227_8415(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R5961[170])();
void R5961_init () {
	R5961[0] = (char *(*)()) F1185_7914;
	R5961[1] = (char *(*)()) F1186_7914;
	R5961[2] = (char *(*)()) F1185_7914;
	R5961[3] = (char *(*)()) F1188_8015;
	R5961[4] = (char *(*)()) F1185_7914;
	R5961[24] = (char *(*)()) F1209_8150;
	R5961[25] = (char *(*)()) F1210_8150;
	R5961[26] = (char *(*)()) F1209_8150;
	R5961[36] = (char *(*)()) F1221_8382;
	R5961[37] = (char *(*)()) F1222_8382;
	R5961[48] = (char *(*)()) F1233_8466;
	R5961[49] = (char *(*)()) F1234_8466;
	R5961[50] = (char *(*)()) F1235_8466;
	R5961[51] = (char *(*)()) F1236_8466;
	R5961[52] = (char *(*)()) F1237_8466;
	{long i; for (i = 53; i < 55; i++) R5961[i] = (char *(*)()) F1233_8466;}
	R5961[169] = (char *(*)()) F1233_8466;
}

static EIF_TYPE_INDEX Y5961_pgtype0[] = {0xFF01,1038,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype1[] = {0xFF01,1039,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype2[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype3[] = {0xFF01,1041,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype4[] = {0xFF01,1042,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype5[] = {0xFF01,1043,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype6[] = {0xFF01,1052,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype7[] = {0xFF01,1053,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype8[] = {0xFF01,1054,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype9[] = {0xFF01,1055,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype10[] = {0xFF01,1056,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype11[] = {0xFF01,1057,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype12[] = {0xFF01,1060,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype13[] = {0xFF01,1061,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype14[] = {0xFF01,1062,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype15[] = {0xFF01,1063,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype16[] = {0xFF01,1064,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype17[] = {0xFF01,1065,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype18[] = {0xFF01,1066,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype19[] = {0xFF01,1067,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype20[] = {0xFF01,1068,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype21[] = {0xFF01,1069,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype22[] = {0xFF01,1070,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype23[] = {0xFF01,1071,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype24[] = {0xFF01,1072,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype25[] = {0xFF01,1073,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype26[] = {0xFF01,1074,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype27[] = {0xFF01,1075,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype28[] = {0xFF01,1058,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype29[] = {0xFF01,1059,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype30[] = {0xFF01,1102,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype31[] = {0xFF01,1103,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype32[] = {0xFF01,1104,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype33[] = {0xFF01,1107,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype34[] = {0xFF01,1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype35[] = {0xFF01,1107,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype36[] = {0xFF01,1109,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype37[] = {0xFF01,1107,0xFF01,153,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype38[] = {0xFF01,1105,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype39[] = {0xFF01,1106,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype40[] = {0xFF01,1105,0xFF01,4,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype41[] = {0xFF01,1076,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype42[] = {0xFF01,1077,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype43[] = {0xFF01,1078,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype44[] = {0xFF01,1079,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype45[] = {0xFF01,1080,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype46[] = {0xFF01,1081,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype47[] = {0xFF01,1082,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype48[] = {0xFF01,1083,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype49[] = {0xFF01,1084,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype50[] = {0xFF01,1085,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype51[] = {0xFF01,1086,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype52[] = {0xFF01,1087,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype53[] = {0xFF01,1088,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype54[] = {0xFF01,1089,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype55[] = {0xFF01,1090,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype56[] = {0xFF01,1091,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype57[] = {0xFF01,1092,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype58[] = {0xFF01,1093,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype59[] = {0xFF01,1094,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype60[] = {0xFF01,1095,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype61[] = {0xFF01,1096,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype62[] = {0xFF01,1097,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype63[] = {0xFF01,1098,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype64[] = {0xFF01,1099,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype65[] = {0xFF01,1100,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype66[] = {0xFF01,1101,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype67[] = {0xFF01,1097,0xFF01,950,0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype68[] = {0xFF01,1097,0xFF01,950,0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y5961_pgtype69[] = {0xFF01,1097,0xFF01,950,0xFF01,950,0xFFFF};
EIF_TYPE_INDEX *Y5961_gen_type [216];
EIF_TYPE_INDEX Y5961 [216];
void Y5961_init (void)
{
	egc_routines_types [5961] = Y5961;
	egc_routines_gen_types [5961] = Y5961_gen_type;
	egc_routines_offset [5961] = 1138;
	Y5961_gen_type [0] = Y5961_pgtype0;
	Y5961_gen_type [1] = Y5961_pgtype1;
	Y5961_gen_type [2] = Y5961_pgtype2;
	Y5961_gen_type [3] = Y5961_pgtype3;
	Y5961_gen_type [4] = Y5961_pgtype4;
	Y5961_gen_type [5] = Y5961_pgtype5;
	Y5961_gen_type [12] = Y5961_pgtype6;
	Y5961_gen_type [13] = Y5961_pgtype7;
	Y5961_gen_type [14] = Y5961_pgtype8;
	Y5961_gen_type [15] = Y5961_pgtype9;
	Y5961_gen_type [16] = Y5961_pgtype10;
	Y5961_gen_type [17] = Y5961_pgtype11;
	Y5961_gen_type [18] = Y5961_pgtype12;
	Y5961_gen_type [19] = Y5961_pgtype13;
	Y5961_gen_type [20] = Y5961_pgtype14;
	Y5961_gen_type [21] = Y5961_pgtype15;
	Y5961_gen_type [22] = Y5961_pgtype16;
	Y5961_gen_type [23] = Y5961_pgtype17;
	Y5961_gen_type [24] = Y5961_pgtype18;
	Y5961_gen_type [25] = Y5961_pgtype19;
	Y5961_gen_type [26] = Y5961_pgtype20;
	Y5961_gen_type [27] = Y5961_pgtype21;
	Y5961_gen_type [28] = Y5961_pgtype22;
	Y5961_gen_type [29] = Y5961_pgtype23;
	Y5961_gen_type [30] = Y5961_pgtype24;
	Y5961_gen_type [31] = Y5961_pgtype25;
	Y5961_gen_type [32] = Y5961_pgtype26;
	Y5961_gen_type [33] = Y5961_pgtype27;
	Y5961_gen_type [38] = Y5961_pgtype28;
	Y5961_gen_type [39] = Y5961_pgtype29;
	Y5961_gen_type [43] = Y5961_pgtype30;
	Y5961_gen_type [44] = Y5961_pgtype31;
	Y5961_gen_type [45] = Y5961_pgtype32;
	Y5961_gen_type [46] = Y5961_pgtype33;
	Y5961_gen_type [47] = Y5961_pgtype34;
	Y5961_gen_type [48] = Y5961_pgtype35;
	Y5961_gen_type [49] = Y5961_pgtype36;
	Y5961_gen_type [50] = Y5961_pgtype37;
	Y5961_gen_type [70] = Y5961_pgtype38;
	Y5961_gen_type [71] = Y5961_pgtype39;
	Y5961_gen_type [72] = Y5961_pgtype40;
	Y5961_gen_type [73] = Y5961_pgtype41;
	Y5961_gen_type [74] = Y5961_pgtype42;
	Y5961_gen_type [75] = Y5961_pgtype43;
	Y5961_gen_type [76] = Y5961_pgtype44;
	Y5961_gen_type [77] = Y5961_pgtype45;
	Y5961_gen_type [78] = Y5961_pgtype46;
	Y5961_gen_type [79] = Y5961_pgtype47;
	Y5961_gen_type [80] = Y5961_pgtype48;
	Y5961_gen_type [81] = Y5961_pgtype49;
	Y5961_gen_type [82] = Y5961_pgtype50;
	Y5961_gen_type [83] = Y5961_pgtype51;
	Y5961_gen_type [84] = Y5961_pgtype52;
	Y5961_gen_type [85] = Y5961_pgtype53;
	Y5961_gen_type [86] = Y5961_pgtype54;
	Y5961_gen_type [87] = Y5961_pgtype55;
	Y5961_gen_type [88] = Y5961_pgtype56;
	Y5961_gen_type [89] = Y5961_pgtype57;
	Y5961_gen_type [90] = Y5961_pgtype58;
	Y5961_gen_type [91] = Y5961_pgtype59;
	Y5961_gen_type [92] = Y5961_pgtype60;
	Y5961_gen_type [93] = Y5961_pgtype61;
	Y5961_gen_type [94] = Y5961_pgtype62;
	Y5961_gen_type [95] = Y5961_pgtype63;
	Y5961_gen_type [96] = Y5961_pgtype64;
	Y5961_gen_type [97] = Y5961_pgtype65;
	Y5961_gen_type [98] = Y5961_pgtype66;
	Y5961_gen_type [99] = Y5961_pgtype67;
	Y5961_gen_type [100] = Y5961_pgtype68;
	Y5961_gen_type [215] = Y5961_pgtype69;
	Y5961[0] = 1038;
	Y5961[1] = 1039;
	Y5961[2] = 1040;
	Y5961[3] = 1041;
	Y5961[4] = 1042;
	Y5961[5] = 1043;
	Y5961[12] = 1052;
	Y5961[13] = 1053;
	Y5961[14] = 1054;
	Y5961[15] = 1055;
	Y5961[16] = 1056;
	Y5961[17] = 1057;
	Y5961[18] = 1060;
	Y5961[19] = 1061;
	Y5961[20] = 1062;
	Y5961[21] = 1063;
	Y5961[22] = 1064;
	Y5961[23] = 1065;
	Y5961[24] = 1066;
	Y5961[25] = 1067;
	Y5961[26] = 1068;
	Y5961[27] = 1069;
	Y5961[28] = 1070;
	Y5961[29] = 1071;
	Y5961[30] = 1072;
	Y5961[31] = 1073;
	Y5961[32] = 1074;
	Y5961[33] = 1075;
	Y5961[38] = 1058;
	Y5961[39] = 1059;
	Y5961[43] = 1102;
	Y5961[44] = 1103;
	Y5961[45] = 1104;
	Y5961[46] = 1107;
	Y5961[47] = 1108;
	Y5961[48] = 1107;
	Y5961[49] = 1109;
	Y5961[50] = 1107;
	Y5961[70] = 1105;
	Y5961[71] = 1106;
	Y5961[72] = 1105;
	Y5961[73] = 1076;
	Y5961[74] = 1077;
	Y5961[75] = 1078;
	Y5961[76] = 1079;
	Y5961[77] = 1080;
	Y5961[78] = 1081;
	Y5961[79] = 1082;
	Y5961[80] = 1083;
	Y5961[81] = 1084;
	Y5961[82] = 1085;
	Y5961[83] = 1086;
	Y5961[84] = 1087;
	Y5961[85] = 1088;
	Y5961[86] = 1089;
	Y5961[87] = 1090;
	Y5961[88] = 1091;
	Y5961[89] = 1092;
	Y5961[90] = 1093;
	Y5961[91] = 1094;
	Y5961[92] = 1095;
	Y5961[93] = 1096;
	Y5961[94] = 1097;
	Y5961[95] = 1098;
	Y5961[96] = 1099;
	Y5961[97] = 1100;
	Y5961[98] = 1101;
	{long i; for (i = 99; i < 101; i++) Y5961[i] = 1097;};
	Y5961[215] = 1097;
}

char *(*R5964[170])();
void R5964_init () {
	R5964[0] = (char *(*)()) F1139_7709;
	R5964[1] = (char *(*)()) F1141_7709;
	{long i; for (i = 2; i < 5; i++) R5964[i] = (char *(*)()) F1139_7709;}
	R5964[24] = (char *(*)()) F1139_7709;
	R5964[25] = (char *(*)()) F1140_7709;
	R5964[26] = (char *(*)()) F1139_7709;
	R5964[36] = (char *(*)()) F1139_7709;
	R5964[37] = (char *(*)()) F1140_7709;
	{long i; for (i = 48; i < 50; i++) R5964[i] = (char *(*)()) F1139_7709;}
	R5964[50] = (char *(*)()) F1142_7709;
	R5964[51] = (char *(*)()) F1143_7709;
	R5964[52] = (char *(*)()) F1140_7709;
	{long i; for (i = 53; i < 55; i++) R5964[i] = (char *(*)()) F1139_7709;}
	R5964[169] = (char *(*)()) F1139_7709;
}

char *(*R5966[170])();
void R5966_init () {
	R5966[0] = (char *(*)()) F1185_7970;
	R5966[1] = (char *(*)()) F1186_7970;
	{long i; for (i = 2; i < 5; i++) R5966[i] = (char *(*)()) F1185_7970;}
	R5966[24] = (char *(*)()) F1209_8199;
	R5966[25] = (char *(*)()) F1210_8199;
	R5966[26] = (char *(*)()) F1209_8199;
	R5966[36] = (char *(*)()) F1212_8301;
	R5966[37] = (char *(*)()) F1214_8301;
	R5966[48] = (char *(*)()) F1212_8301;
	R5966[49] = (char *(*)()) F1213_8301;
	R5966[50] = (char *(*)()) F1215_8301;
	R5966[51] = (char *(*)()) F1216_8301;
	R5966[52] = (char *(*)()) F1214_8301;
	{long i; for (i = 53; i < 55; i++) R5966[i] = (char *(*)()) F1212_8301;}
	R5966[169] = (char *(*)()) F1212_8301;
}

char *(*R5967[170])();
void R5967_init () {
	R5967[0] = (char *(*)()) F1185_7971;
	R5967[1] = (char *(*)()) F1186_7971;
	{long i; for (i = 2; i < 5; i++) R5967[i] = (char *(*)()) F1185_7971;}
	R5967[24] = (char *(*)()) F1209_8200;
	R5967[25] = (char *(*)()) F1210_8200;
	R5967[26] = (char *(*)()) F1209_8200;
	R5967[36] = (char *(*)()) F1212_8302;
	R5967[37] = (char *(*)()) F1214_8302;
	R5967[48] = (char *(*)()) F1212_8302;
	R5967[49] = (char *(*)()) F1213_8302;
	R5967[50] = (char *(*)()) F1215_8302;
	R5967[51] = (char *(*)()) F1216_8302;
	R5967[52] = (char *(*)()) F1214_8302;
	{long i; for (i = 53; i < 55; i++) R5967[i] = (char *(*)()) F1212_8302;}
	R5967[169] = (char *(*)()) F1212_8302;
}

char *(*R5968[170])();
void R5968_init () {
	R5968[0] = (char *(*)()) F1185_7975;
	R5968[1] = (char *(*)()) F1186_7975_5968_5;
	{long i; for (i = 2; i < 5; i++) R5968[i] = (char *(*)()) F1185_7975;}
	R5968[24] = (char *(*)()) F1209_8205;
	R5968[25] = (char *(*)()) F1210_8205_5968_5;
	R5968[26] = (char *(*)()) F1209_8205;
	R5968[36] = (char *(*)()) F1212_8307;
	R5968[37] = (char *(*)()) F1214_8307_5968_5;
	R5968[48] = (char *(*)()) F1212_8307;
	R5968[49] = (char *(*)()) F1213_8307;
	R5968[50] = (char *(*)()) F1215_8307_5968_5;
	R5968[51] = (char *(*)()) F1216_8307_5968_5;
	R5968[52] = (char *(*)()) F1214_8307_5968_5;
	{long i; for (i = 53; i < 55; i++) R5968[i] = (char *(*)()) F1212_8307;}
	R5968[169] = (char *(*)()) F1212_8307;
}
static EIF_REFERENCE F1186_7975_5968_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1186_7975(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1210_8205_5968_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1210_8205(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1214_8307_5968_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1214_8307(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1215_8307_5968_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1215_8307(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(903, 0x00).id, 903, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1216_8307_5968_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1216_8307(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(879, 0x00).id, 879, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5969[170])();
void R5969_init () {
	R5969[0] = (char *(*)()) F1139_7714;
	R5969[1] = (char *(*)()) F1141_7714;
	{long i; for (i = 2; i < 5; i++) R5969[i] = (char *(*)()) F1139_7714;}
	R5969[24] = (char *(*)()) F1139_7714;
	R5969[25] = (char *(*)()) F1140_7714;
	R5969[26] = (char *(*)()) F1139_7714;
	R5969[36] = (char *(*)()) F1139_7714;
	R5969[37] = (char *(*)()) F1140_7714;
	{long i; for (i = 48; i < 50; i++) R5969[i] = (char *(*)()) F1139_7714;}
	R5969[50] = (char *(*)()) F1142_7714;
	R5969[51] = (char *(*)()) F1143_7714;
	R5969[52] = (char *(*)()) F1140_7714;
	{long i; for (i = 53; i < 55; i++) R5969[i] = (char *(*)()) F1139_7714;}
	R5969[169] = (char *(*)()) F1139_7714;
}

char *(*R5970[170])();
void R5970_init () {
	R5970[0] = (char *(*)()) F1185_7979;
	R5970[1] = (char *(*)()) F1186_7979;
	{long i; for (i = 2; i < 5; i++) R5970[i] = (char *(*)()) F1185_7979;}
	R5970[24] = (char *(*)()) F1209_8209;
	R5970[25] = (char *(*)()) F1210_8209;
	R5970[26] = (char *(*)()) F1209_8209;
	R5970[36] = (char *(*)()) F1212_8310;
	R5970[37] = (char *(*)()) F1214_8310;
	R5970[48] = (char *(*)()) F1212_8310;
	R5970[49] = (char *(*)()) F1213_8310;
	R5970[50] = (char *(*)()) F1215_8310;
	R5970[51] = (char *(*)()) F1216_8310;
	R5970[52] = (char *(*)()) F1214_8310;
	{long i; for (i = 53; i < 55; i++) R5970[i] = (char *(*)()) F1212_8310;}
	R5970[169] = (char *(*)()) F1212_8310;
}

char *(*R5972[170])();
void R5972_init () {
	R5972[0] = (char *(*)()) F1139_7717;
	R5972[1] = (char *(*)()) F1141_7717;
	{long i; for (i = 2; i < 5; i++) R5972[i] = (char *(*)()) F1139_7717;}
	R5972[24] = (char *(*)()) F1139_7717;
	R5972[25] = (char *(*)()) F1140_7717;
	R5972[26] = (char *(*)()) F1139_7717;
	R5972[36] = (char *(*)()) F1139_7717;
	R5972[37] = (char *(*)()) F1140_7717;
	{long i; for (i = 48; i < 50; i++) R5972[i] = (char *(*)()) F1139_7717;}
	R5972[50] = (char *(*)()) F1142_7717;
	R5972[51] = (char *(*)()) F1143_7717;
	R5972[52] = (char *(*)()) F1140_7717;
	{long i; for (i = 53; i < 55; i++) R5972[i] = (char *(*)()) F1139_7717;}
	R5972[169] = (char *(*)()) F1139_7717;
}

char *(*R5973[170])();
void R5973_init () {
	R5973[0] = (char *(*)()) F1139_7718;
	R5973[1] = (char *(*)()) F1141_7718;
	{long i; for (i = 2; i < 5; i++) R5973[i] = (char *(*)()) F1139_7718;}
	R5973[24] = (char *(*)()) F1139_7718;
	R5973[25] = (char *(*)()) F1140_7718;
	R5973[26] = (char *(*)()) F1139_7718;
	R5973[36] = (char *(*)()) F1139_7718;
	R5973[37] = (char *(*)()) F1140_7718;
	{long i; for (i = 48; i < 50; i++) R5973[i] = (char *(*)()) F1139_7718;}
	R5973[50] = (char *(*)()) F1142_7718;
	R5973[51] = (char *(*)()) F1143_7718;
	R5973[52] = (char *(*)()) F1140_7718;
	{long i; for (i = 53; i < 55; i++) R5973[i] = (char *(*)()) F1139_7718;}
	R5973[169] = (char *(*)()) F1139_7718;
}

char *(*R5974[170])();
void R5974_init () {
	R5974[0] = (char *(*)()) F1185_7917;
	R5974[1] = (char *(*)()) F1186_7917_5974_2;
	{long i; for (i = 2; i < 5; i++) R5974[i] = (char *(*)()) F1185_7917;}
	R5974[24] = (char *(*)()) F1209_8154;
	R5974[25] = (char *(*)()) F1210_8154_5974_2;
	R5974[26] = (char *(*)()) F1209_8154;
	R5974[36] = (char *(*)()) F1217_8327;
	R5974[37] = (char *(*)()) F1218_8327_5974_2;
	R5974[48] = (char *(*)()) F1212_8239;
	R5974[49] = (char *(*)()) F1213_8239;
	R5974[50] = (char *(*)()) F1215_8239_5974_2;
	R5974[51] = (char *(*)()) F1216_8239_5974_2;
	R5974[52] = (char *(*)()) F1214_8239_5974_2;
	{long i; for (i = 53; i < 55; i++) R5974[i] = (char *(*)()) F1212_8239;}
	R5974[169] = (char *(*)()) F1212_8239;
}
static EIF_BOOLEAN F1186_7917_5974_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1186_7917(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1210_8154_5974_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1210_8154(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1218_8327_5974_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1218_8327(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1215_8239_5974_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1215_8239(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F1216_8239_5974_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1216_8239(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F1214_8239_5974_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1214_8239(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5977[170])();
void R5977_init () {
	R5977[0] = (char *(*)()) F1145_7722;
	R5977[1] = (char *(*)()) F1147_7722;
	{long i; for (i = 2; i < 5; i++) R5977[i] = (char *(*)()) F1145_7722;}
	R5977[11] = (char *(*)()) F1145_7722;
	R5977[12] = (char *(*)()) F1147_7722;
	R5977[16] = (char *(*)()) F1145_7722;
	R5977[21] = (char *(*)()) F1145_7722;
	R5977[22] = (char *(*)()) F1148_7722;
	R5977[23] = (char *(*)()) F1146_7722;
	R5977[24] = (char *(*)()) F1145_7722;
	R5977[25] = (char *(*)()) F1146_7722;
	R5977[26] = (char *(*)()) F1145_7722;
	R5977[36] = (char *(*)()) F1145_7722;
	R5977[37] = (char *(*)()) F1146_7722;
	{long i; for (i = 48; i < 50; i++) R5977[i] = (char *(*)()) F1145_7722;}
	R5977[50] = (char *(*)()) F1148_7722;
	R5977[51] = (char *(*)()) F1150_7722;
	R5977[52] = (char *(*)()) F1146_7722;
	{long i; for (i = 53; i < 55; i++) R5977[i] = (char *(*)()) F1145_7722;}
	R5977[169] = (char *(*)()) F1145_7722;
}

char *(*R5982[27])();
void R5982_init () {
	R5982[0] = (char *(*)()) F1185_7912;
	R5982[1] = (char *(*)()) F1186_7912_5982_1;
	{long i; for (i = 2; i < 5; i++) R5982[i] = (char *(*)()) F1185_7912;}
	R5982[24] = (char *(*)()) F1209_8148;
	R5982[25] = (char *(*)()) F1210_8148_5982_1;
	R5982[26] = (char *(*)()) F1209_8148;
}
static EIF_REFERENCE F1186_7912_5982_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1186_7912(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1210_8148_5982_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1210_8148(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5992[170])();
void R5992_init () {
	R5992[0] = (char *(*)()) F1185_7977;
	R5992[1] = (char *(*)()) F1186_7977;
	{long i; for (i = 2; i < 5; i++) R5992[i] = (char *(*)()) F1185_7977;}
	R5992[24] = (char *(*)()) F1209_8207;
	R5992[25] = (char *(*)()) F1210_8207;
	R5992[26] = (char *(*)()) F1209_8207;
	R5992[36] = (char *(*)()) F1212_8308;
	R5992[37] = (char *(*)()) F1214_8308;
	R5992[48] = (char *(*)()) F1212_8308;
	R5992[49] = (char *(*)()) F1213_8308;
	R5992[50] = (char *(*)()) F1215_8308;
	R5992[51] = (char *(*)()) F1216_8308;
	R5992[52] = (char *(*)()) F1214_8308;
	{long i; for (i = 53; i < 55; i++) R5992[i] = (char *(*)()) F1212_8308;}
	R5992[169] = (char *(*)()) F1212_8308;
}

char *(*R5993[170])();
void R5993_init () {
	R5993[0] = (char *(*)()) F1151_7746;
	R5993[1] = (char *(*)()) F1153_7746;
	{long i; for (i = 2; i < 5; i++) R5993[i] = (char *(*)()) F1151_7746;}
	R5993[24] = (char *(*)()) F1151_7746;
	R5993[25] = (char *(*)()) F1152_7746;
	R5993[26] = (char *(*)()) F1151_7746;
	R5993[36] = (char *(*)()) F1151_7746;
	R5993[37] = (char *(*)()) F1152_7746;
	{long i; for (i = 48; i < 50; i++) R5993[i] = (char *(*)()) F1151_7746;}
	R5993[50] = (char *(*)()) F1154_7746;
	R5993[51] = (char *(*)()) F1156_7746;
	R5993[52] = (char *(*)()) F1152_7746;
	{long i; for (i = 53; i < 55; i++) R5993[i] = (char *(*)()) F1151_7746;}
	R5993[169] = (char *(*)()) F1151_7746;
}

char *(*R5994[170])();
void R5994_init () {
	R5994[0] = (char *(*)()) F1185_7980;
	R5994[1] = (char *(*)()) F1186_7980;
	{long i; for (i = 2; i < 5; i++) R5994[i] = (char *(*)()) F1185_7980;}
	R5994[24] = (char *(*)()) F1209_8210;
	R5994[25] = (char *(*)()) F1210_8210;
	R5994[26] = (char *(*)()) F1209_8210;
	R5994[36] = (char *(*)()) F1212_8311;
	R5994[37] = (char *(*)()) F1214_8311;
	R5994[48] = (char *(*)()) F1212_8311;
	R5994[49] = (char *(*)()) F1213_8311;
	R5994[50] = (char *(*)()) F1215_8311;
	R5994[51] = (char *(*)()) F1216_8311;
	R5994[52] = (char *(*)()) F1214_8311;
	{long i; for (i = 53; i < 55; i++) R5994[i] = (char *(*)()) F1212_8311;}
	R5994[169] = (char *(*)()) F1212_8311;
}

char *(*R5995[170])();
void R5995_init () {
	R5995[0] = (char *(*)()) F1185_7982;
	R5995[1] = (char *(*)()) F1186_7982;
	{long i; for (i = 2; i < 5; i++) R5995[i] = (char *(*)()) F1185_7982;}
	R5995[24] = (char *(*)()) F1209_8212;
	R5995[25] = (char *(*)()) F1210_8212;
	R5995[26] = (char *(*)()) F1209_8212;
	R5995[36] = (char *(*)()) F1212_8313;
	R5995[37] = (char *(*)()) F1214_8313;
	R5995[48] = (char *(*)()) F1212_8313;
	R5995[49] = (char *(*)()) F1213_8313;
	R5995[50] = (char *(*)()) F1215_8313;
	R5995[51] = (char *(*)()) F1216_8313;
	R5995[52] = (char *(*)()) F1214_8313;
	{long i; for (i = 53; i < 55; i++) R5995[i] = (char *(*)()) F1212_8313;}
	R5995[169] = (char *(*)()) F1212_8313;
}

char *(*R5997[170])();
void R5997_init () {
	R5997[0] = (char *(*)()) F1185_7986;
	R5997[1] = (char *(*)()) F1186_7986;
	{long i; for (i = 2; i < 5; i++) R5997[i] = (char *(*)()) F1185_7986;}
	R5997[24] = (char *(*)()) F1209_8216;
	R5997[25] = (char *(*)()) F1210_8216;
	R5997[26] = (char *(*)()) F1209_8216;
	R5997[36] = (char *(*)()) F1212_8317;
	R5997[37] = (char *(*)()) F1214_8317;
	R5997[48] = (char *(*)()) F1212_8317;
	R5997[49] = (char *(*)()) F1213_8317;
	R5997[50] = (char *(*)()) F1215_8317;
	R5997[51] = (char *(*)()) F1216_8317;
	R5997[52] = (char *(*)()) F1214_8317;
	{long i; for (i = 53; i < 55; i++) R5997[i] = (char *(*)()) F1212_8317;}
	R5997[169] = (char *(*)()) F1212_8317;
}

char *(*R5998[27])();
void R5998_init () {
	R5998[0] = (char *(*)()) F1185_7913;
	R5998[1] = (char *(*)()) F1186_7913_5998_1;
	{long i; for (i = 2; i < 5; i++) R5998[i] = (char *(*)()) F1185_7913;}
	R5998[24] = (char *(*)()) F1209_8149;
	R5998[25] = (char *(*)()) F1210_8149_5998_1;
	R5998[26] = (char *(*)()) F1209_8149;
}
static EIF_REFERENCE F1186_7913_5998_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1186_7913(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1210_8149_5998_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1210_8149(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6005[170])();
void R6005_init () {
	R6005[0] = (char *(*)()) F1185_7978;
	R6005[1] = (char *(*)()) F1186_7978;
	{long i; for (i = 2; i < 5; i++) R6005[i] = (char *(*)()) F1185_7978;}
	R6005[24] = (char *(*)()) F1209_8208;
	R6005[25] = (char *(*)()) F1210_8208;
	R6005[26] = (char *(*)()) F1209_8208;
	R6005[36] = (char *(*)()) F1212_8309;
	R6005[37] = (char *(*)()) F1214_8309;
	R6005[48] = (char *(*)()) F1212_8309;
	R6005[49] = (char *(*)()) F1213_8309;
	R6005[50] = (char *(*)()) F1215_8309;
	R6005[51] = (char *(*)()) F1216_8309;
	R6005[52] = (char *(*)()) F1214_8309;
	{long i; for (i = 53; i < 55; i++) R6005[i] = (char *(*)()) F1212_8309;}
	R6005[169] = (char *(*)()) F1212_8309;
}

char *(*R6007[170])();
void R6007_init () {
	R6007[0] = (char *(*)()) F1185_7981;
	R6007[1] = (char *(*)()) F1186_7981;
	{long i; for (i = 2; i < 5; i++) R6007[i] = (char *(*)()) F1185_7981;}
	R6007[24] = (char *(*)()) F1209_8211;
	R6007[25] = (char *(*)()) F1210_8211;
	R6007[26] = (char *(*)()) F1209_8211;
	R6007[36] = (char *(*)()) F1212_8312;
	R6007[37] = (char *(*)()) F1214_8312;
	R6007[48] = (char *(*)()) F1212_8312;
	R6007[49] = (char *(*)()) F1213_8312;
	R6007[50] = (char *(*)()) F1215_8312;
	R6007[51] = (char *(*)()) F1216_8312;
	R6007[52] = (char *(*)()) F1214_8312;
	{long i; for (i = 53; i < 55; i++) R6007[i] = (char *(*)()) F1212_8312;}
	R6007[169] = (char *(*)()) F1212_8312;
}

char *(*R6008[170])();
void R6008_init () {
	R6008[0] = (char *(*)()) F1185_7983;
	R6008[1] = (char *(*)()) F1186_7983;
	R6008[2] = (char *(*)()) F1185_7983;
	R6008[3] = (char *(*)()) F1188_8028;
	R6008[4] = (char *(*)()) F1185_7983;
	R6008[24] = (char *(*)()) F1209_8213;
	R6008[25] = (char *(*)()) F1210_8213;
	R6008[26] = (char *(*)()) F1209_8213;
	R6008[36] = (char *(*)()) F1212_8314;
	R6008[37] = (char *(*)()) F1214_8314;
	R6008[48] = (char *(*)()) F1212_8314;
	R6008[49] = (char *(*)()) F1213_8314;
	R6008[50] = (char *(*)()) F1215_8314;
	R6008[51] = (char *(*)()) F1216_8314;
	R6008[52] = (char *(*)()) F1214_8314;
	{long i; for (i = 53; i < 55; i++) R6008[i] = (char *(*)()) F1212_8314;}
	R6008[169] = (char *(*)()) F1212_8314;
}

char *(*R6010[170])();
void R6010_init () {
	R6010[0] = (char *(*)()) F1185_7987;
	R6010[1] = (char *(*)()) F1186_7987;
	{long i; for (i = 2; i < 5; i++) R6010[i] = (char *(*)()) F1185_7987;}
	R6010[24] = (char *(*)()) F1209_8217;
	R6010[25] = (char *(*)()) F1210_8217;
	R6010[26] = (char *(*)()) F1209_8217;
	R6010[36] = (char *(*)()) F1212_8318;
	R6010[37] = (char *(*)()) F1214_8318;
	R6010[48] = (char *(*)()) F1212_8318;
	R6010[49] = (char *(*)()) F1213_8318;
	R6010[50] = (char *(*)()) F1215_8318;
	R6010[51] = (char *(*)()) F1216_8318;
	R6010[52] = (char *(*)()) F1214_8318;
	{long i; for (i = 53; i < 55; i++) R6010[i] = (char *(*)()) F1212_8318;}
	R6010[169] = (char *(*)()) F1212_8318;
}

char *(*R6018[122])();
void R6018_init () {
	R6018[0] = (char *(*)()) F1223_8430;
	R6018[1] = (char *(*)()) F1224_8430_6018_5;
	R6018[2] = (char *(*)()) F1225_8430;
	R6018[3] = (char *(*)()) F1226_8430_6018_5;
	R6018[4] = (char *(*)()) F1227_8430_6018_5;
	{long i; for (i = 5; i < 7; i++) R6018[i] = (char *(*)()) F1223_8430;}
	R6018[121] = (char *(*)()) F1223_8430;
}
static EIF_REFERENCE F1224_8430_6018_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1224_8430(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1226_8430_6018_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1226_8430(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(882, 0x00).id, 882, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1227_8430_6018_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1227_8430(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6019[6])();
void R6019_init () {
	R6019[0] = (char *(*)()) F1206_8113;
	R6019[1] = (char *(*)()) F1207_8113;
	R6019[2] = (char *(*)()) F1208_8113;
	R6019[3] = (char *(*)()) F1209_8155;
	R6019[4] = (char *(*)()) F1210_8155;
	R6019[5] = (char *(*)()) F1209_8155;
}

char *(*R6020[27])();
void R6020_init () {
	R6020[0] = (char *(*)()) F1185_7931;
	R6020[1] = (char *(*)()) F1186_7931_6020_4;
	R6020[2] = (char *(*)()) F1187_8009;
	{long i; for (i = 3; i < 5; i++) R6020[i] = (char *(*)()) F1185_7931;}
	R6020[24] = (char *(*)()) F1209_8160;
	R6020[25] = (char *(*)()) F1210_8160_6020_4;
	R6020[26] = (char *(*)()) F1209_8160;
}
static void F1186_7931_6020_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1186_7931(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1210_8160_6020_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1210_8160(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R6021[38])();
void R6021_init () {
	R6021[0] = (char *(*)()) F1185_7932;
	R6021[1] = (char *(*)()) F1186_7932_6021_4;
	R6021[2] = (char *(*)()) F1187_8004;
	{long i; for (i = 3; i < 5; i++) R6021[i] = (char *(*)()) F1185_7932;}
	R6021[11] = (char *(*)()) F1196_8059;
	R6021[12] = (char *(*)()) F1197_8059_6021_4;
	R6021[16] = (char *(*)()) F1201_8088;
	R6021[21] = (char *(*)()) F1206_8122;
	R6021[22] = (char *(*)()) F1207_8122_6021_4;
	R6021[23] = (char *(*)()) F1208_8122_6021_4;
	R6021[24] = (char *(*)()) F1209_8165;
	R6021[25] = (char *(*)()) F1210_8165_6021_4;
	R6021[26] = (char *(*)()) F1209_8165;
	R6021[36] = (char *(*)()) F1217_8338;
	R6021[37] = (char *(*)()) F1218_8338_6021_4;
}
static void F1186_7932_6021_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1186_7932(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1197_8059_6021_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1197_8059(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1207_8122_6021_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1207_8122(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1208_8122_6021_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1208_8122(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1210_8165_6021_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1210_8165(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1218_8338_6021_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1218_8338(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R6022[3])();
void R6022_init () {
	R6022[0] = (char *(*)()) F1209_8170;
	R6022[1] = (char *(*)()) F1210_8170;
	R6022[2] = (char *(*)()) F1209_8170;
}

char *(*R6045[27])();
void R6045_init () {
	R6045[0] = (char *(*)()) F1185_7911;
	R6045[1] = (char *(*)()) F1186_7911_6045_26;
	{long i; for (i = 2; i < 5; i++) R6045[i] = (char *(*)()) F1185_7911;}
	R6045[24] = (char *(*)()) F1209_8147;
	R6045[25] = (char *(*)()) F1210_8147_6045_26;
	R6045[26] = (char *(*)()) F1209_8147;
}
static EIF_REFERENCE F1186_7911_6045_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1186_7911(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1210_8147_6045_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1210_8147(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6049[3])();
void R6049_init () {
	R6049[0] = (char *(*)()) F1209_8161;
	R6049[1] = (char *(*)()) F1210_8161_6049_131;
	R6049[2] = (char *(*)()) F1209_8161;
}
static void F1210_8161_6049_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1210_8161(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R6050[27])();
void R6050_init () {
	R6050[0] = (char *(*)()) F1185_7930;
	R6050[1] = (char *(*)()) F1186_7930_6050_4;
	R6050[2] = (char *(*)()) F1187_8003;
	{long i; for (i = 3; i < 5; i++) R6050[i] = (char *(*)()) F1185_7930;}
	R6050[24] = (char *(*)()) F1209_8164;
	R6050[25] = (char *(*)()) F1210_8164_6050_4;
	R6050[26] = (char *(*)()) F1209_8164;
}
static void F1186_7930_6050_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1186_7930(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1210_8164_6050_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1210_8164(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R6052[27])();
void R6052_init () {
	R6052[0] = (char *(*)()) F1185_7933;
	R6052[1] = (char *(*)()) F1186_7933_6052_131;
	R6052[2] = (char *(*)()) F1187_8012;
	{long i; for (i = 3; i < 5; i++) R6052[i] = (char *(*)()) F1185_7933;}
	R6052[24] = (char *(*)()) F1209_8158;
	R6052[25] = (char *(*)()) F1210_8158_6052_131;
	R6052[26] = (char *(*)()) F1209_8158;
}
static void F1186_7933_6052_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1186_7933(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1210_8158_6052_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1210_8158(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}


#ifdef __cplusplus
}
#endif
