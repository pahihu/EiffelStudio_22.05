#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O2743[950];
void O2743_init () {
	O2743[0] = + _R64OFF_1_3_2_3_1_0_2_0_;
	O2743[392] = + _R64OFF_3_6_2_4_1_1_2_0_;
	O2743[393] = + _R64OFF_4_6_2_4_1_1_2_0_;
	O2743[394] = + _R64OFF_5_7_2_4_1_1_2_0_;
	O2743[706] = + _R64OFF_5_7_2_4_1_1_2_0_;
	O2743[941] = + _R64OFF_6_7_2_4_1_1_2_0_;
	{long i; for (i = 942; i < 945; i++) O2743[i] = + _R64OFF_5_6_2_4_1_1_2_0_;}
	O2743[946] = + _R64OFF_7_8_2_4_1_1_2_0_;
	{long i; for (i = 947; i < 950; i++) O2743[i] = + _R64OFF_6_7_2_4_1_1_2_0_;}
}

long O3083[945];
void O3083_init () {
	{long i; for (i = 0; i < 205; i++) O3083[i] = + _CHROFF_0_0_;}
	O3083[205] = + _CHROFF_3_2_;
	O3083[206] = + _CHROFF_4_2_;
	O3083[207] = + _CHROFF_5_2_;
	{long i; for (i = 232; i < 245; i++) O3083[i] = + _CHROFF_0_0_;}
	{long i; for (i = 245; i < 263; i++) O3083[i] = + _CHROFF_1_0_;}
	{long i; for (i = 263; i < 311; i++) O3083[i] = + _CHROFF_0_0_;}
	{long i; for (i = 311; i < 313; i++) O3083[i] = + _CHROFF_2_0_;}
	{long i; for (i = 316; i < 329; i++) O3083[i] = + _CHROFF_1_0_;}
	O3083[329] = + _CHROFF_7_0_;
	O3083[330] = + _CHROFF_5_0_;
	O3083[331] = + _CHROFF_6_0_;
	O3083[332] = + _CHROFF_5_0_;
	O3083[333] = + _CHROFF_4_0_;
	O3083[334] = + _CHROFF_7_0_;
	O3083[335] = + _CHROFF_5_0_;
	O3083[336] = + _CHROFF_9_0_;
	O3083[455] = + _CHROFF_1_0_;
	{long i; for (i = 458; i < 460; i++) O3083[i] = + _CHROFF_1_0_;}
	O3083[519] = + _CHROFF_5_2_;
	O3083[754] = + _CHROFF_6_2_;
	{long i; for (i = 755; i < 758; i++) O3083[i] = + _CHROFF_5_2_;}
	O3083[759] = + _CHROFF_7_2_;
	{long i; for (i = 760; i < 763; i++) O3083[i] = + _CHROFF_6_2_;}
	{long i; for (i = 943; i < 945; i++) O3083[i] = + _CHROFF_1_0_;}
}

long O3172[558];
void O3172_init () {
	O3172[0] = + _PTROFF_3_6_2_4_1_0_;
	O3172[1] = + _PTROFF_4_6_2_4_1_0_;
	O3172[2] = + _PTROFF_5_7_2_4_1_0_;
	O3172[314] = + _PTROFF_5_7_2_4_1_0_;
	O3172[549] = + _PTROFF_6_7_2_4_1_0_;
	{long i; for (i = 550; i < 553; i++) O3172[i] = + _PTROFF_5_6_2_4_1_0_;}
	O3172[554] = + _PTROFF_7_8_2_4_1_0_;
	{long i; for (i = 555; i < 558; i++) O3172[i] = + _PTROFF_6_7_2_4_1_0_;}
}

long O3255[558];
void O3255_init () {
	{long i; for (i = 0; i < 3; i++) O3255[i] =  + _REFACS_1_;}
	O3255[314] =  + _REFACS_1_;
	{long i; for (i = 549; i < 553; i++) O3255[i] =  + _REFACS_1_;}
	{long i; for (i = 554; i < 558; i++) O3255[i] = 0;}
}

long O3257[558];
void O3257_init () {
	{long i; for (i = 0; i < 3; i++) O3257[i] =  + _REFACS_2_;}
	O3257[314] =  + _REFACS_2_;
	{long i; for (i = 549; i < 553; i++) O3257[i] =  + _REFACS_2_;}
	{long i; for (i = 554; i < 558; i++) O3257[i] =  + _REFACS_1_;}
}

long O3311[558];
void O3311_init () {
	O3311[0] = + _LNGOFF_3_6_2_3_;
	O3311[1] = + _LNGOFF_4_6_2_3_;
	O3311[2] = + _LNGOFF_5_7_2_3_;
	O3311[314] = + _LNGOFF_5_7_2_3_;
	O3311[549] = + _LNGOFF_6_7_2_3_;
	{long i; for (i = 550; i < 553; i++) O3311[i] = + _LNGOFF_5_6_2_3_;}
	O3311[554] = + _LNGOFF_7_8_2_3_;
	{long i; for (i = 555; i < 558; i++) O3311[i] = + _LNGOFF_6_7_2_3_;}
}

long O3320[558];
void O3320_init () {
	O3320[0] = + _CHROFF_3_3_;
	O3320[1] = + _CHROFF_4_3_;
	O3320[2] = + _CHROFF_5_3_;
	O3320[314] = + _CHROFF_5_3_;
	O3320[549] = + _CHROFF_6_3_;
	{long i; for (i = 550; i < 553; i++) O3320[i] = + _CHROFF_5_3_;}
	O3320[554] = + _CHROFF_7_3_;
	{long i; for (i = 555; i < 558; i++) O3320[i] = + _CHROFF_6_3_;}
}

long O3334[553];
void O3334_init () {
	O3334[0] =  + _REFACS_3_;
	O3334[312] =  + _REFACS_3_;
	O3334[547] =  + _REFACS_3_;
	O3334[552] =  + _REFACS_2_;
}

EIF_TYPE_INDEX *Y3519_gen_type [1];
EIF_TYPE_INDEX Y3519 [1];
void Y3519_init (void)
{
	egc_routines_types [3519] = Y3519;
	egc_routines_gen_types [3519] = Y3519_gen_type;
	egc_routines_offset [3519] = 808;
	Y3519[0] = 873;
}

long O3539[8];
void O3539_init () {
	O3539[0] = 0;
	O3539[1] = + _PTROFF_5_3_0_7_0_0_;
	O3539[2] = 0;
	O3539[3] = + _LNGOFF_5_3_0_0_;
	O3539[4] = + _LNGOFF_4_3_0_0_;
	O3539[5] = 0;
	O3539[6] = + _LNGOFF_5_4_0_0_;
	O3539[7] = 0;
}

long O3548[8];
void O3548_init () {
	O3548[0] = + _LNGOFF_7_3_0_0_;
	O3548[1] = + _LNGOFF_5_3_0_0_;
	O3548[2] = + _LNGOFF_6_3_0_0_;
	O3548[3] = + _LNGOFF_5_3_0_1_;
	O3548[4] = + _LNGOFF_4_3_0_1_;
	O3548[5] = + _LNGOFF_7_4_0_0_;
	O3548[6] = + _LNGOFF_5_4_0_1_;
	O3548[7] = + _LNGOFF_9_3_0_0_;
}

long O3575[8];
void O3575_init () {
	O3575[0] =  + _REFACS_1_;
	O3575[1] = 0;
	O3575[2] =  + _REFACS_1_;
	{long i; for (i = 3; i < 5; i++) O3575[i] = 0;}
	O3575[5] =  + _REFACS_1_;
	O3575[6] = 0;
	O3575[7] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y3575_pgtype0[] = {0xFF01,712,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3575_pgtype1[] = {0xFF01,713,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3575_pgtype2[] = {0xFF01,712,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3575_pgtype3[] = {0xFF01,714,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3575_pgtype4[] = {0xFF01,714,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3575_pgtype5[] = {0xFF01,712,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3575_pgtype6[] = {0xFF01,714,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3575_pgtype7[] = {0xFF01,712,0,0xFFFF};
EIF_TYPE_INDEX *Y3575_gen_type [8];
EIF_TYPE_INDEX Y3575 [8];
void Y3575_init (void)
{
	egc_routines_types [3575] = Y3575;
	egc_routines_gen_types [3575] = Y3575_gen_type;
	egc_routines_offset [3575] = 821;
	Y3575_gen_type [0] = Y3575_pgtype0;
	Y3575_gen_type [1] = Y3575_pgtype1;
	Y3575_gen_type [2] = Y3575_pgtype2;
	Y3575_gen_type [3] = Y3575_pgtype3;
	Y3575_gen_type [4] = Y3575_pgtype4;
	Y3575_gen_type [5] = Y3575_pgtype5;
	Y3575_gen_type [6] = Y3575_pgtype6;
	Y3575_gen_type [7] = Y3575_pgtype7;
	Y3575[0] = 712;
	Y3575[1] = 713;
	Y3575[2] = 712;
	{long i; for (i = 3; i < 5; i++) Y3575[i] = 714;};
	Y3575[5] = 712;
	Y3575[6] = 714;
	Y3575[7] = 712;
}

long O3576[8];
void O3576_init () {
	O3576[0] =  + _REFACS_2_;
	O3576[1] =  + _REFACS_1_;
	O3576[2] =  + _REFACS_2_;
	{long i; for (i = 3; i < 5; i++) O3576[i] =  + _REFACS_1_;}
	O3576[5] =  + _REFACS_2_;
	O3576[6] =  + _REFACS_1_;
	O3576[7] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y3576_pgtype0[] = {0xFF01,712,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3576_pgtype1[] = {0xFF01,712,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3576_pgtype2[] = {0xFF01,714,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3576_pgtype3[] = {0xFF01,712,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3576_pgtype4[] = {0xFF01,714,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3576_pgtype5[] = {0xFF01,712,0xFF01,942,0xFFFF};
static EIF_TYPE_INDEX Y3576_pgtype6[] = {0xFF01,712,0xFF01,942,0xFFFF};
static EIF_TYPE_INDEX Y3576_pgtype7[] = {0xFF01,712,0xFF01,950,0xFFFF};
EIF_TYPE_INDEX *Y3576_gen_type [8];
EIF_TYPE_INDEX Y3576 [8];
void Y3576_init (void)
{
	egc_routines_types [3576] = Y3576;
	egc_routines_gen_types [3576] = Y3576_gen_type;
	egc_routines_offset [3576] = 821;
	Y3576_gen_type [0] = Y3576_pgtype0;
	Y3576_gen_type [1] = Y3576_pgtype1;
	Y3576_gen_type [2] = Y3576_pgtype2;
	Y3576_gen_type [3] = Y3576_pgtype3;
	Y3576_gen_type [4] = Y3576_pgtype4;
	Y3576_gen_type [5] = Y3576_pgtype5;
	Y3576_gen_type [6] = Y3576_pgtype6;
	Y3576_gen_type [7] = Y3576_pgtype7;
	{long i; for (i = 0; i < 2; i++) Y3576[i] = 712;};
	Y3576[2] = 714;
	Y3576[3] = 712;
	Y3576[4] = 714;
	{long i; for (i = 5; i < 8; i++) Y3576[i] = 712;};
}

long O3577[8];
void O3577_init () {
	O3577[0] =  + _REFACS_3_;
	O3577[1] =  + _REFACS_2_;
	O3577[2] =  + _REFACS_3_;
	{long i; for (i = 3; i < 5; i++) O3577[i] =  + _REFACS_2_;}
	O3577[5] =  + _REFACS_3_;
	O3577[6] =  + _REFACS_2_;
	O3577[7] =  + _REFACS_3_;
}

long O3578[8];
void O3578_init () {
	O3578[0] =  + _REFACS_4_;
	O3578[1] =  + _REFACS_3_;
	O3578[2] =  + _REFACS_4_;
	{long i; for (i = 3; i < 5; i++) O3578[i] =  + _REFACS_3_;}
	O3578[5] =  + _REFACS_4_;
	O3578[6] =  + _REFACS_3_;
	O3578[7] =  + _REFACS_4_;
}

long O3579[8];
void O3579_init () {
	O3579[0] = + _LNGOFF_7_3_0_1_;
	O3579[1] = + _LNGOFF_5_3_0_1_;
	O3579[2] = + _LNGOFF_6_3_0_1_;
	O3579[3] = + _LNGOFF_5_3_0_2_;
	O3579[4] = + _LNGOFF_4_3_0_2_;
	O3579[5] = + _LNGOFF_7_4_0_1_;
	O3579[6] = + _LNGOFF_5_4_0_2_;
	O3579[7] = + _LNGOFF_9_3_0_1_;
}

long O3580[8];
void O3580_init () {
	O3580[0] = + _CHROFF_7_2_;
	O3580[1] = + _CHROFF_5_2_;
	O3580[2] = + _CHROFF_6_2_;
	O3580[3] = + _CHROFF_5_2_;
	O3580[4] = + _CHROFF_4_2_;
	O3580[5] = + _CHROFF_7_2_;
	O3580[6] = + _CHROFF_5_2_;
	O3580[7] = + _CHROFF_9_2_;
}

long O3581[8];
void O3581_init () {
	O3581[0] = + _LNGOFF_7_3_0_2_;
	O3581[1] = + _LNGOFF_5_3_0_2_;
	O3581[2] = + _LNGOFF_6_3_0_2_;
	O3581[3] = + _LNGOFF_5_3_0_3_;
	O3581[4] = + _LNGOFF_4_3_0_3_;
	O3581[5] = + _LNGOFF_7_4_0_2_;
	O3581[6] = + _LNGOFF_5_4_0_3_;
	O3581[7] = + _LNGOFF_9_3_0_2_;
}

long O3584[8];
void O3584_init () {
	O3584[0] = + _LNGOFF_7_3_0_3_;
	O3584[1] = + _LNGOFF_5_3_0_3_;
	O3584[2] = + _LNGOFF_6_3_0_3_;
	O3584[3] = + _LNGOFF_5_3_0_4_;
	O3584[4] = + _LNGOFF_4_3_0_4_;
	O3584[5] = + _LNGOFF_7_4_0_3_;
	O3584[6] = + _LNGOFF_5_4_0_4_;
	O3584[7] = + _LNGOFF_9_3_0_3_;
}

long O3585[8];
void O3585_init () {
	O3585[0] = + _LNGOFF_7_3_0_4_;
	O3585[1] = + _LNGOFF_5_3_0_4_;
	O3585[2] = + _LNGOFF_6_3_0_4_;
	O3585[3] = + _LNGOFF_5_3_0_5_;
	O3585[4] = + _LNGOFF_4_3_0_5_;
	O3585[5] = + _LNGOFF_7_4_0_4_;
	O3585[6] = + _LNGOFF_5_4_0_5_;
	O3585[7] = + _LNGOFF_9_3_0_4_;
}

long O3589[8];
void O3589_init () {
	O3589[0] = + _LNGOFF_7_3_0_5_;
	O3589[1] = + _LNGOFF_5_3_0_5_;
	O3589[2] = + _LNGOFF_6_3_0_5_;
	O3589[3] = + _LNGOFF_5_3_0_6_;
	O3589[4] = + _LNGOFF_4_3_0_6_;
	O3589[5] = + _LNGOFF_7_4_0_5_;
	O3589[6] = + _LNGOFF_5_4_0_6_;
	O3589[7] = + _LNGOFF_9_3_0_5_;
}

long O3590[8];
void O3590_init () {
	O3590[0] =  + _REFACS_5_;
	O3590[1] = + _PTROFF_5_3_0_7_0_1_;
	O3590[2] =  + _REFACS_5_;
	O3590[3] = + _LNGOFF_5_3_0_7_;
	O3590[4] = + _LNGOFF_4_3_0_7_;
	O3590[5] =  + _REFACS_5_;
	O3590[6] = + _LNGOFF_5_4_0_7_;
	O3590[7] =  + _REFACS_5_;
}

long O3591[8];
void O3591_init () {
	O3591[0] =  + _REFACS_6_;
	O3591[1] =  + _REFACS_4_;
	O3591[2] = + _LNGOFF_6_3_0_6_;
	O3591[3] =  + _REFACS_4_;
	O3591[4] = + _LNGOFF_4_3_0_8_;
	O3591[5] =  + _REFACS_6_;
	O3591[6] =  + _REFACS_4_;
	O3591[7] =  + _REFACS_6_;
}

long O3625[8];
void O3625_init () {
	O3625[0] = + _LNGOFF_7_3_0_6_;
	O3625[1] = + _LNGOFF_5_3_0_6_;
	O3625[2] = + _LNGOFF_6_3_0_7_;
	O3625[3] = + _LNGOFF_5_3_0_8_;
	O3625[4] = + _LNGOFF_4_3_0_9_;
	O3625[5] = + _LNGOFF_7_4_0_6_;
	O3625[6] = + _LNGOFF_5_4_0_8_;
	O3625[7] = + _LNGOFF_9_3_0_6_;
}

long O4501[5];
void O4501_init () {
	{long i; for (i = 0; i < 2; i++) O4501[i] = + _CHROFF_4_0_;}
	O4501[2] = + _CHROFF_5_0_;
	{long i; for (i = 3; i < 5; i++) O4501[i] = + _CHROFF_4_0_;}
}

long O4502[5];
void O4502_init () {
	{long i; for (i = 0; i < 2; i++) O4502[i] = + _LNGOFF_4_2_0_0_;}
	O4502[2] = + _LNGOFF_5_2_0_0_;
	{long i; for (i = 3; i < 5; i++) O4502[i] = + _LNGOFF_4_3_0_0_;}
}

long O4510[5];
void O4510_init () {
	{long i; for (i = 0; i < 2; i++) O4510[i] = + _PTROFF_4_2_0_3_0_0_;}
	O4510[2] = + _PTROFF_5_2_0_3_0_0_;
	{long i; for (i = 3; i < 5; i++) O4510[i] = + _PTROFF_4_3_0_3_0_0_;}
}

long O4511[5];
void O4511_init () {
	{long i; for (i = 0; i < 2; i++) O4511[i] = + _PTROFF_4_2_0_3_0_1_;}
	O4511[2] = + _PTROFF_5_2_0_3_0_1_;
	{long i; for (i = 3; i < 5; i++) O4511[i] = + _PTROFF_4_3_0_3_0_1_;}
}

long O4513[5];
void O4513_init () {
	{long i; for (i = 0; i < 2; i++) O4513[i] = + _PTROFF_4_2_0_3_0_2_;}
	O4513[2] = + _PTROFF_5_2_0_3_0_2_;
	{long i; for (i = 3; i < 5; i++) O4513[i] = + _PTROFF_4_3_0_3_0_2_;}
}

long O4514[5];
void O4514_init () {
	{long i; for (i = 0; i < 2; i++) O4514[i] = + _LNGOFF_4_2_0_1_;}
	O4514[2] = + _LNGOFF_5_2_0_1_;
	{long i; for (i = 3; i < 5; i++) O4514[i] = + _LNGOFF_4_3_0_1_;}
}

long O4515[5];
void O4515_init () {
	{long i; for (i = 0; i < 2; i++) O4515[i] = + _CHROFF_4_1_;}
	O4515[2] = + _CHROFF_5_1_;
	{long i; for (i = 3; i < 5; i++) O4515[i] = + _CHROFF_4_1_;}
}

long O4516[5];
void O4516_init () {
	{long i; for (i = 0; i < 2; i++) O4516[i] = + _LNGOFF_4_2_0_2_;}
	O4516[2] = + _LNGOFF_5_2_0_2_;
	{long i; for (i = 3; i < 5; i++) O4516[i] = + _LNGOFF_4_3_0_2_;}
}

long O4529[3];
void O4529_init () {
	O4529[0] =  + _REFACS_4_;
	{long i; for (i = 1; i < 3; i++) O4529[i] = + _CHROFF_4_2_;}
}

long O4628[495];
void O4628_init () {
	{long i; for (i = 0; i < 3; i++) O4628[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O4628[i] = + _LNGOFF_1_0_0_0_;}
	O4628[5] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 6; i < 8; i++) O4628[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 8; i < 10; i++) O4628[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 493; i < 495; i++) O4628[i] = + _LNGOFF_1_1_0_0_;}
}

long O4629[495];
void O4629_init () {
	{long i; for (i = 0; i < 3; i++) O4629[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O4629[i] = + _LNGOFF_1_0_0_1_;}
	O4629[5] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 6; i < 8; i++) O4629[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 8; i < 10; i++) O4629[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 493; i < 495; i++) O4629[i] = + _LNGOFF_1_1_0_1_;}
}

long O4694[3];
void O4694_init () {
	{long i; for (i = 0; i < 2; i++) O4694[i] = + _LNGOFF_1_0_0_2_;}
	O4694[2] = + _LNGOFF_1_1_0_2_;
}

long O4774[489];
void O4774_init () {
	{long i; for (i = 0; i < 2; i++) O4774[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 4; i++) O4774[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 487; i < 489; i++) O4774[i] = + _LNGOFF_1_1_0_2_;}
}

long O5290[296];
void O5290_init () {
	O5290[0] = + _LNGOFF_1_1_0_1_;
	O5290[1] = + _LNGOFF_5_2_0_1_;
	O5290[2] = + _LNGOFF_8_2_0_1_;
	O5290[3] = + _LNGOFF_14_3_0_1_;
	O5290[4] = + _LNGOFF_27_4_0_2_;
	O5290[21] = + _LNGOFF_10_4_0_1_;
	O5290[23] = + _LNGOFF_14_5_0_1_;
	O5290[286] = + _LNGOFF_28_4_0_2_;
	{long i; for (i = 288; i < 290; i++) O5290[i] = + _LNGOFF_23_3_0_1_;}
	O5290[290] = + _LNGOFF_23_5_0_1_;
	O5290[291] = + _LNGOFF_27_4_0_1_;
	O5290[292] = + _LNGOFF_27_6_0_1_;
	O5290[294] = + _LNGOFF_51_8_0_2_;
	O5290[295] = + _LNGOFF_62_8_0_2_;
}

long O5369[295];
void O5369_init () {
	O5369[0] = + _LNGOFF_5_2_0_2_;
	O5369[1] = + _LNGOFF_8_2_0_2_;
	O5369[2] = + _LNGOFF_14_3_0_2_;
	O5369[3] = + _LNGOFF_27_4_0_3_;
	O5369[20] = + _LNGOFF_10_4_0_2_;
	O5369[22] = + _LNGOFF_14_5_0_2_;
	O5369[285] = + _LNGOFF_28_4_0_3_;
	{long i; for (i = 287; i < 289; i++) O5369[i] = + _LNGOFF_23_3_0_2_;}
	O5369[289] = + _LNGOFF_23_5_0_2_;
	O5369[290] = + _LNGOFF_27_4_0_2_;
	O5369[291] = + _LNGOFF_27_6_0_2_;
	O5369[293] = + _LNGOFF_51_8_0_3_;
	O5369[294] = + _LNGOFF_62_8_0_3_;
}

long O5373[295];
void O5373_init () {
	O5373[0] = + _LNGOFF_5_2_0_3_;
	O5373[1] = + _LNGOFF_8_2_0_3_;
	O5373[2] = + _LNGOFF_14_3_0_3_;
	O5373[3] = + _LNGOFF_27_4_0_4_;
	O5373[20] = + _LNGOFF_10_4_0_3_;
	O5373[22] = + _LNGOFF_14_5_0_3_;
	O5373[285] = + _LNGOFF_28_4_0_4_;
	{long i; for (i = 287; i < 289; i++) O5373[i] = + _LNGOFF_23_3_0_3_;}
	O5373[289] = + _LNGOFF_23_5_0_3_;
	O5373[290] = + _LNGOFF_27_4_0_3_;
	O5373[291] = + _LNGOFF_27_6_0_3_;
	O5373[293] = + _LNGOFF_51_8_0_4_;
	O5373[294] = + _LNGOFF_62_8_0_4_;
}

long O5374[295];
void O5374_init () {
	O5374[0] = + _LNGOFF_5_2_0_4_;
	O5374[1] = + _LNGOFF_8_2_0_4_;
	O5374[2] = + _LNGOFF_14_3_0_4_;
	O5374[3] = + _LNGOFF_27_4_0_5_;
	O5374[20] = + _LNGOFF_10_4_0_4_;
	O5374[22] = + _LNGOFF_14_5_0_4_;
	O5374[285] = + _LNGOFF_28_4_0_5_;
	{long i; for (i = 287; i < 289; i++) O5374[i] = + _LNGOFF_23_3_0_4_;}
	O5374[289] = + _LNGOFF_23_5_0_4_;
	O5374[290] = + _LNGOFF_27_4_0_4_;
	O5374[291] = + _LNGOFF_27_6_0_4_;
	O5374[293] = + _LNGOFF_51_8_0_5_;
	O5374[294] = + _LNGOFF_62_8_0_5_;
}

long O5375[295];
void O5375_init () {
	O5375[0] = + _LNGOFF_5_2_0_5_;
	O5375[1] = + _LNGOFF_8_2_0_5_;
	O5375[2] = + _LNGOFF_14_3_0_5_;
	O5375[3] = + _LNGOFF_27_4_0_6_;
	O5375[20] = + _LNGOFF_10_4_0_5_;
	O5375[22] = + _LNGOFF_14_5_0_5_;
	O5375[285] = + _LNGOFF_28_4_0_6_;
	{long i; for (i = 287; i < 289; i++) O5375[i] = + _LNGOFF_23_3_0_5_;}
	O5375[289] = + _LNGOFF_23_5_0_5_;
	O5375[290] = + _LNGOFF_27_4_0_5_;
	O5375[291] = + _LNGOFF_27_6_0_5_;
	O5375[293] = + _LNGOFF_51_8_0_6_;
	O5375[294] = + _LNGOFF_62_8_0_6_;
}

long O5376[295];
void O5376_init () {
	O5376[0] = + _LNGOFF_5_2_0_6_;
	O5376[1] = + _LNGOFF_8_2_0_6_;
	O5376[2] = + _LNGOFF_14_3_0_6_;
	O5376[3] = + _LNGOFF_27_4_0_7_;
	O5376[20] = + _LNGOFF_10_4_0_6_;
	O5376[22] = + _LNGOFF_14_5_0_6_;
	O5376[285] = + _LNGOFF_28_4_0_7_;
	{long i; for (i = 287; i < 289; i++) O5376[i] = + _LNGOFF_23_3_0_6_;}
	O5376[289] = + _LNGOFF_23_5_0_6_;
	O5376[290] = + _LNGOFF_27_4_0_6_;
	O5376[291] = + _LNGOFF_27_6_0_6_;
	O5376[293] = + _LNGOFF_51_8_0_7_;
	O5376[294] = + _LNGOFF_62_8_0_7_;
}

long O5377[295];
void O5377_init () {
	O5377[0] = + _LNGOFF_5_2_0_7_;
	O5377[1] = + _LNGOFF_8_2_0_7_;
	O5377[2] = + _LNGOFF_14_3_0_7_;
	O5377[3] = + _LNGOFF_27_4_0_8_;
	O5377[20] = + _LNGOFF_10_4_0_7_;
	O5377[22] = + _LNGOFF_14_5_0_7_;
	O5377[285] = + _LNGOFF_28_4_0_8_;
	{long i; for (i = 287; i < 289; i++) O5377[i] = + _LNGOFF_23_3_0_7_;}
	O5377[289] = + _LNGOFF_23_5_0_7_;
	O5377[290] = + _LNGOFF_27_4_0_7_;
	O5377[291] = + _LNGOFF_27_6_0_7_;
	O5377[293] = + _LNGOFF_51_8_0_8_;
	O5377[294] = + _LNGOFF_62_8_0_8_;
}

long O5378[295];
void O5378_init () {
	O5378[0] = + _CHROFF_5_1_;
	O5378[1] = + _CHROFF_8_1_;
	O5378[2] = + _CHROFF_14_1_;
	O5378[3] = + _CHROFF_27_1_;
	O5378[20] = + _CHROFF_10_1_;
	O5378[22] = + _CHROFF_14_1_;
	O5378[285] = + _CHROFF_28_1_;
	{long i; for (i = 287; i < 290; i++) O5378[i] = + _CHROFF_23_1_;}
	{long i; for (i = 290; i < 292; i++) O5378[i] = + _CHROFF_27_1_;}
	O5378[293] = + _CHROFF_51_1_;
	O5378[294] = + _CHROFF_62_1_;
}

long O5379[295];
void O5379_init () {
	O5379[0] = + _LNGOFF_5_2_0_8_;
	O5379[1] = + _LNGOFF_8_2_0_8_;
	O5379[2] = + _LNGOFF_14_3_0_8_;
	O5379[3] = + _LNGOFF_27_4_0_9_;
	O5379[20] = + _LNGOFF_10_4_0_8_;
	O5379[22] = + _LNGOFF_14_5_0_8_;
	O5379[285] = + _LNGOFF_28_4_0_9_;
	{long i; for (i = 287; i < 289; i++) O5379[i] = + _LNGOFF_23_3_0_8_;}
	O5379[289] = + _LNGOFF_23_5_0_8_;
	O5379[290] = + _LNGOFF_27_4_0_8_;
	O5379[291] = + _LNGOFF_27_6_0_8_;
	O5379[293] = + _LNGOFF_51_8_0_9_;
	O5379[294] = + _LNGOFF_62_8_0_9_;
}

long O5380[295];
void O5380_init () {
	O5380[0] = + _LNGOFF_5_2_0_9_;
	O5380[1] = + _LNGOFF_8_2_0_9_;
	O5380[2] = + _LNGOFF_14_3_0_9_;
	O5380[3] = + _LNGOFF_27_4_0_10_;
	O5380[20] = + _LNGOFF_10_4_0_9_;
	O5380[22] = + _LNGOFF_14_5_0_9_;
	O5380[285] = + _LNGOFF_28_4_0_10_;
	{long i; for (i = 287; i < 289; i++) O5380[i] = + _LNGOFF_23_3_0_9_;}
	O5380[289] = + _LNGOFF_23_5_0_9_;
	O5380[290] = + _LNGOFF_27_4_0_9_;
	O5380[291] = + _LNGOFF_27_6_0_9_;
	O5380[293] = + _LNGOFF_51_8_0_10_;
	O5380[294] = + _LNGOFF_62_8_0_10_;
}

long O5381[295];
void O5381_init () {
	O5381[0] = + _LNGOFF_5_2_0_10_;
	O5381[1] = + _LNGOFF_8_2_0_10_;
	O5381[2] = + _LNGOFF_14_3_0_10_;
	O5381[3] = + _LNGOFF_27_4_0_11_;
	O5381[20] = + _LNGOFF_10_4_0_10_;
	O5381[22] = + _LNGOFF_14_5_0_10_;
	O5381[285] = + _LNGOFF_28_4_0_11_;
	{long i; for (i = 287; i < 289; i++) O5381[i] = + _LNGOFF_23_3_0_10_;}
	O5381[289] = + _LNGOFF_23_5_0_10_;
	O5381[290] = + _LNGOFF_27_4_0_10_;
	O5381[291] = + _LNGOFF_27_6_0_10_;
	O5381[293] = + _LNGOFF_51_8_0_11_;
	O5381[294] = + _LNGOFF_62_8_0_11_;
}


#ifdef __cplusplus
}
#endif
