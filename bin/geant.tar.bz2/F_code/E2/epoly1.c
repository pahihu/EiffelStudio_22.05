#include "epoly1.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R11[1433])();
void R11_init () {
	R11[0] = (char *(*)()) F1_8;
	{long i; for (i = 2; i < 6; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 7; i < 10; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 17; i < 25; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 26; i < 28; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 30; i < 33; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 45; i < 48; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 52; i < 54; i++) R11[i] = (char *(*)()) F1_8;}
	R11[61] = (char *(*)()) F1_8;
	{long i; for (i = 65; i < 67; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 72; i < 75; i++) R11[i] = (char *(*)()) F1_8;}
	R11[79] = (char *(*)()) F1_8;
	R11[83] = (char *(*)()) F1_8;
	{long i; for (i = 94; i < 96; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 101; i < 107; i++) R11[i] = (char *(*)()) F1_8;}
	R11[119] = (char *(*)()) F1_8;
	{long i; for (i = 125; i < 136; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 151; i < 153; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 157; i < 159; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 160; i < 162; i++) R11[i] = (char *(*)()) F1_8;}
	R11[165] = (char *(*)()) F1_8;
	R11[170] = (char *(*)()) F173_1926;
	{long i; for (i = 171; i < 174; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 175; i < 177; i++) R11[i] = (char *(*)()) F1_8;}
	R11[185] = (char *(*)()) F1_8;
	R11[188] = (char *(*)()) F1_8;
	R11[190] = (char *(*)()) F1_8;
	{long i; for (i = 193; i < 195; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 204; i < 208; i++) R11[i] = (char *(*)()) F1_8;}
	R11[211] = (char *(*)()) F1_8;
	{long i; for (i = 213; i < 216; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 217; i < 219; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 221; i < 223; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 224; i < 227; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 228; i < 232; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 233; i < 235; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 236; i < 239; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 240; i < 246; i++) R11[i] = (char *(*)()) F1_8;}
	R11[249] = (char *(*)()) F254_2374;
	{long i; for (i = 250; i < 257; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 259; i < 261; i++) R11[i] = (char *(*)()) F1_8;}
	R11[270] = (char *(*)()) F1_8;
	R11[289] = (char *(*)()) F294_2776;
	R11[290] = (char *(*)()) F1_8;
	R11[291] = (char *(*)()) F296_2884;
	R11[293] = (char *(*)()) F1_8;
	R11[295] = (char *(*)()) F1_8;
	{long i; for (i = 298; i < 301; i++) R11[i] = (char *(*)()) F1_8;}
	R11[386] = (char *(*)()) F1_8;
	R11[389] = (char *(*)()) F1_8;
	{long i; for (i = 433; i < 438; i++) R11[i] = (char *(*)()) F1_8;}
	R11[630] = (char *(*)()) F1_8;
	R11[694] = (char *(*)()) F1_8;
	{long i; for (i = 708; i < 720; i++) R11[i] = (char *(*)()) F1_8;}
	R11[733] = (char *(*)()) F738_4073;
	R11[734] = (char *(*)()) F739_4073;
	R11[735] = (char *(*)()) F740_4073;
	R11[736] = (char *(*)()) F741_4073;
	R11[737] = (char *(*)()) F742_4073;
	R11[738] = (char *(*)()) F743_4073;
	R11[739] = (char *(*)()) F744_4073;
	R11[740] = (char *(*)()) F745_4073;
	R11[741] = (char *(*)()) F746_4073;
	R11[742] = (char *(*)()) F747_4073;
	R11[743] = (char *(*)()) F748_4073;
	R11[744] = (char *(*)()) F749_4073;
	R11[745] = (char *(*)()) F738_4073;
	R11[746] = (char *(*)()) F740_4073;
	R11[747] = (char *(*)()) F742_4073;
	R11[748] = (char *(*)()) F747_4073;
	R11[749] = (char *(*)()) F741_4073;
	R11[750] = (char *(*)()) F746_4073;
	R11[805] = (char *(*)()) F810_4293;
	R11[806] = (char *(*)()) F811_4293;
	R11[807] = (char *(*)()) F812_4293;
	R11[808] = (char *(*)()) F813_4293;
	R11[809] = (char *(*)()) F814_4293;
	R11[810] = (char *(*)()) F815_4293;
	R11[811] = (char *(*)()) F816_4293;
	R11[812] = (char *(*)()) F817_4293;
	R11[813] = (char *(*)()) F818_4293;
	R11[814] = (char *(*)()) F819_4293;
	R11[815] = (char *(*)()) F820_4293;
	R11[816] = (char *(*)()) F821_4293;
	R11[817] = (char *(*)()) F822_4358;
	R11[818] = (char *(*)()) F823_4358;
	R11[819] = (char *(*)()) F824_4358;
	R11[820] = (char *(*)()) F825_4358;
	R11[821] = (char *(*)()) F826_4358;
	R11[824] = (char *(*)()) F822_4358;
	R11[827] = (char *(*)()) F832_4479;
	R11[828] = (char *(*)()) F833_4537;
	R11[829] = (char *(*)()) F834_4574;
	R11[830] = (char *(*)()) F835_4574;
	R11[831] = (char *(*)()) F836_4574;
	R11[832] = (char *(*)()) F837_4574;
	R11[833] = (char *(*)()) F838_4574;
	R11[834] = (char *(*)()) F839_4574;
	R11[835] = (char *(*)()) F840_4574;
	R11[836] = (char *(*)()) F841_4574;
	R11[837] = (char *(*)()) F842_4574;
	R11[838] = (char *(*)()) F843_4574;
	R11[839] = (char *(*)()) F844_4574;
	R11[840] = (char *(*)()) F845_4574;
	R11[841] = (char *(*)()) F846_4574;
	R11[842] = (char *(*)()) F847_4574;
	R11[843] = (char *(*)()) F848_4574;
	R11[844] = (char *(*)()) F849_4574;
	R11[845] = (char *(*)()) F850_4574;
	R11[846] = (char *(*)()) F851_4574;
	R11[847] = (char *(*)()) F852_4574;
	R11[848] = (char *(*)()) F853_4574;
	R11[849] = (char *(*)()) F854_4574;
	R11[850] = (char *(*)()) F855_4574;
	R11[851] = (char *(*)()) F856_4574;
	R11[852] = (char *(*)()) F857_4574;
	R11[853] = (char *(*)()) F858_4574;
	R11[854] = (char *(*)()) F859_4574;
	R11[855] = (char *(*)()) F860_4574;
	R11[856] = (char *(*)()) F861_4574;
	R11[857] = (char *(*)()) F862_4574;
	R11[858] = (char *(*)()) F863_4574;
	R11[859] = (char *(*)()) F864_4574;
	R11[860] = (char *(*)()) F865_4617;
	{long i; for (i = 862; i < 864; i++) R11[i] = (char *(*)()) F866_4735;}
	{long i; for (i = 865; i < 867; i++) R11[i] = (char *(*)()) F869_4834;}
	{long i; for (i = 868; i < 870; i++) R11[i] = (char *(*)()) F872_4932;}
	{long i; for (i = 871; i < 873; i++) R11[i] = (char *(*)()) F875_5031;}
	{long i; for (i = 874; i < 876; i++) R11[i] = (char *(*)()) F878_5130;}
	{long i; for (i = 877; i < 879; i++) R11[i] = (char *(*)()) F881_5224;}
	{long i; for (i = 880; i < 882; i++) R11[i] = (char *(*)()) F884_5318;}
	{long i; for (i = 883; i < 885; i++) R11[i] = (char *(*)()) F887_5413;}
	{long i; for (i = 886; i < 888; i++) R11[i] = (char *(*)()) F890_5512;}
	{long i; for (i = 889; i < 891; i++) R11[i] = (char *(*)()) F893_5578;}
	{long i; for (i = 892; i < 894; i++) R11[i] = (char *(*)()) F896_5639;}
	{long i; for (i = 895; i < 897; i++) R11[i] = (char *(*)()) F899_5679;}
	{long i; for (i = 898; i < 900; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 901; i < 933; i++) R11[i] = (char *(*)()) F905_5745;}
	R11[934] = (char *(*)()) F938_5782;
	R11[935] = (char *(*)()) F940_5820;
	{long i; for (i = 936; i < 938; i++) R11[i] = (char *(*)()) F941_5820;}
	{long i; for (i = 942; i < 944; i++) R11[i] = (char *(*)()) F946_5981;}
	{long i; for (i = 945; i < 947; i++) R11[i] = (char *(*)()) F949_6149;}
	R11[949] = (char *(*)()) F1_8;
	{long i; for (i = 951; i < 960; i++) R11[i] = (char *(*)()) F1_8;}
	R11[967] = (char *(*)()) F1_8;
	R11[969] = (char *(*)()) F1_8;
	R11[974] = (char *(*)()) F1_8;
	R11[976] = (char *(*)()) F1_8;
	R11[977] = (char *(*)()) F982_6643;
	R11[979] = (char *(*)()) F1_8;
	R11[980] = (char *(*)()) F985_6669;
	{long i; for (i = 981; i < 986; i++) R11[i] = (char *(*)()) F1_8;}
	R11[987] = (char *(*)()) F1_8;
	R11[989] = (char *(*)()) F1_8;
	{long i; for (i = 994; i < 997; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 999; i < 1010; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1029] = (char *(*)()) F1_8;
	R11[1081] = (char *(*)()) F1039_7382;
	R11[1082] = (char *(*)()) F1040_7382;
	{long i; for (i = 1093; i < 1095; i++) R11[i] = (char *(*)()) F1039_7382;}
	R11[1095] = (char *(*)()) F1042_7382;
	R11[1096] = (char *(*)()) F1043_7382;
	R11[1097] = (char *(*)()) F1040_7382;
	R11[1101] = (char *(*)()) F1039_7382;
	R11[1102] = (char *(*)()) F1040_7382;
	R11[1103] = (char *(*)()) F1039_7382;
	R11[1104] = (char *(*)()) F1041_7382;
	R11[1105] = (char *(*)()) F1039_7382;
	R11[1107] = (char *(*)()) F1112_7515;
	R11[1109] = (char *(*)()) F1114_7527;
	R11[1110] = (char *(*)()) F1115_7547;
	R11[1112] = (char *(*)()) F1117_7564;
	R11[1115] = (char *(*)()) F1_8;
	{long i; for (i = 1117; i < 1120; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1180] = (char *(*)()) F1185_7928;
	R11[1181] = (char *(*)()) F1186_7928;
	{long i; for (i = 1182; i < 1185; i++) R11[i] = (char *(*)()) F1185_7928;}
	R11[1191] = (char *(*)()) F1196_8057;
	R11[1192] = (char *(*)()) F1197_8057;
	R11[1196] = (char *(*)()) F1201_8086;
	R11[1201] = (char *(*)()) F1206_8120;
	R11[1202] = (char *(*)()) F1207_8120;
	R11[1203] = (char *(*)()) F1208_8120;
	R11[1204] = (char *(*)()) F1209_8157;
	R11[1205] = (char *(*)()) F1210_8157;
	R11[1206] = (char *(*)()) F1209_8157;
	R11[1216] = (char *(*)()) F1217_8332;
	R11[1217] = (char *(*)()) F1218_8332;
	R11[1228] = (char *(*)()) F1223_8406;
	R11[1229] = (char *(*)()) F1224_8406;
	R11[1230] = (char *(*)()) F1225_8406;
	R11[1231] = (char *(*)()) F1226_8406;
	R11[1232] = (char *(*)()) F1227_8406;
	{long i; for (i = 1233; i < 1235; i++) R11[i] = (char *(*)()) F1223_8406;}
	R11[1236] = (char *(*)()) F1241_8484;
	R11[1237] = (char *(*)()) F1_8;
	R11[1239] = (char *(*)()) F1_8;
	{long i; for (i = 1242; i < 1244; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1247; i < 1249; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1252; i < 1257; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1266; i < 1268; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1269; i < 1271; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1275; i < 1278; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1279] = (char *(*)()) F1_8;
	{long i; for (i = 1281; i < 1283; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1288] = (char *(*)()) F1_8;
	{long i; for (i = 1290; i < 1294; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1299; i < 1303; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1305] = (char *(*)()) F1_8;
	{long i; for (i = 1307; i < 1310; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1315] = (char *(*)()) F1_8;
	R11[1319] = (char *(*)()) F1_8;
	{long i; for (i = 1322; i < 1325; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1330; i < 1335; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1341; i < 1344; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1345; i < 1349; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1349] = (char *(*)()) F1223_8406;
	{long i; for (i = 1350; i < 1353; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1355; i < 1357; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1358; i < 1369; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1370; i < 1390; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1391; i < 1408; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1409; i < 1426; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1427] = (char *(*)()) F1431_11167;
	R11[1430] = (char *(*)()) F1_8;
	{long i; for (i = 1431; i < 1433; i++) R11[i] = (char *(*)()) F1436_11364;}
}

char *(*R28[565])();
void R28_init () {
	{long i; for (i = 0; i < 2; i++) R28[i] = (char *(*)()) F872_4992;}
	{long i; for (i = 9; i < 11; i++) R28[i] = (char *(*)()) F881_5281;}
	{long i; for (i = 27; i < 29; i++) R28[i] = (char *(*)()) F899_5686;}
	{long i; for (i = 30; i < 32; i++) R28[i] = (char *(*)()) F902_5734;}
	{long i; for (i = 77; i < 79; i++) R28[i] = (char *(*)()) F949_6169;}
	{long i; for (i = 563; i < 565; i++) R28[i] = (char *(*)()) F1436_11409;}
}

char *(*R231[6])();
void R231_init () {
	R231[0] = (char *(*)()) F24_227;
	R231[1] = (char *(*)()) F25_227;
	R231[2] = (char *(*)()) F26_227;
	R231[3] = (char *(*)()) F27_227;
	R231[4] = (char *(*)()) F28_227;
	R231[5] = (char *(*)()) F29_227;
}

char *(*R236[6])();
void R236_init () {
	R236[0] = (char *(*)()) F24_232;
	R236[1] = (char *(*)()) F25_232_236_38;
	R236[2] = (char *(*)()) F26_232_236_38;
	R236[3] = (char *(*)()) F27_232_236_38;
	R236[4] = (char *(*)()) F28_232_236_38;
	R236[5] = (char *(*)()) F29_232_236_38;
}
static void F25_232_236_38 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F25_232(Current, arg1, *(EIF_INTEGER_32 *)arg2, arg3);
}
static void F26_232_236_38 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F26_232(Current, arg1, *(EIF_BOOLEAN *)arg2, arg3);
}
static void F27_232_236_38 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F27_232(Current, arg1, *(EIF_NATURAL_64 *)arg2, arg3);
}
static void F28_232_236_38 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F28_232(Current, arg1, *(EIF_NATURAL_32 *)arg2, arg3);
}
static void F29_232_236_38 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F29_232(Current, arg1, *(EIF_CHARACTER_8 *)arg2, arg3);
}

char *(*R239[6])();
void R239_init () {
	R239[0] = (char *(*)()) F24_235;
	R239[1] = (char *(*)()) F25_235;
	R239[2] = (char *(*)()) F26_235;
	R239[3] = (char *(*)()) F27_235;
	R239[4] = (char *(*)()) F28_235;
	R239[5] = (char *(*)()) F29_235;
}

char *(*R826[2])();
void R826_init () {
	R826[0] = (char *(*)()) F57_820;
	R826[1] = (char *(*)()) F58_840;
}

char *(*R840[2])();
void R840_init () {
	R840[0] = (char *(*)()) F57_834;
	R840[1] = (char *(*)()) F58_843;
}

char *(*R841[2])();
void R841_init () {
	R841[0] = (char *(*)()) F57_835;
	R841[1] = (char *(*)()) F58_844;
}

char *(*R880[3])();
void R880_init () {
	R880[0] = (char *(*)()) F1309_9800;
	R880[2] = (char *(*)()) F1311_9900;
}

char *(*R883[3])();
void R883_init () {
	R883[0] = (char *(*)()) F1018_7057;
	R883[2] = (char *(*)()) F1311_9931;
}

char *(*R884[3])();
void R884_init () {
	R884[0] = (char *(*)()) F1015_6900;
	R884[2] = (char *(*)()) F1311_9930;
}

char *(*R965[2])();
void R965_init () {
	R965[0] = (char *(*)()) F68_963;
	R965[1] = (char *(*)()) F69_963_965_1;
}
static EIF_REFERENCE F69_963_965_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F69_963(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R975[3])();
void R975_init () {
	R975[0] = (char *(*)()) F75_983;
	R975[1] = (char *(*)()) F76_983;
	R975[2] = (char *(*)()) F75_983;
}

char *(*R977[3])();
void R977_init () {
	R977[0] = (char *(*)()) F75_985;
	R977[1] = (char *(*)()) F76_985;
	R977[2] = (char *(*)()) F75_985;
}

char *(*R986[3])();
void R986_init () {
	R986[0] = (char *(*)()) F77_989;
	R986[1] = (char *(*)()) F78_989;
	R986[2] = (char *(*)()) F79_990;
}

char *(*R1043[2])();
void R1043_init () {
	R1043[0] = (char *(*)()) F303_2953_1043_26;
	R1043[1] = (char *(*)()) F304_2982_1043_26;
}
static EIF_REFERENCE F303_2953_1043_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F303_2953(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F304_2982_1043_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F304_2982(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R1044[2])();
void R1044_init () {
	R1044[0] = (char *(*)()) F303_2961;
	R1044[1] = (char *(*)()) F304_2986;
}

char *(*R1045[2])();
void R1045_init () {
	R1045[0] = (char *(*)()) F303_2965_1045_131;
	R1045[1] = (char *(*)()) F304_2988_1045_131;
}
static void F303_2965_1045_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F303_2965(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F304_2988_1045_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F304_2988(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}

char *(*R1046[2])();
void R1046_init () {
	R1046[0] = (char *(*)()) F303_2974;
	R1046[1] = (char *(*)()) F304_2993;
}

char *(*R1047[2])();
void R1047_init () {
	R1047[0] = (char *(*)()) F303_2976;
	R1047[1] = (char *(*)()) F304_2994;
}

char *(*R1049[2])();
void R1049_init () {
	R1049[0] = (char *(*)()) F303_2978;
	R1049[1] = (char *(*)()) F304_2996;
}

char *(*R1053[2])();
void R1053_init () {
	R1053[0] = (char *(*)()) F303_2954;
	R1053[1] = (char *(*)()) F91_1063;
}

char *(*R1054[2])();
void R1054_init () {
	R1054[0] = (char *(*)()) F303_2955;
	R1054[1] = (char *(*)()) F91_1064;
}

char *(*R1055[2])();
void R1055_init () {
	R1055[0] = (char *(*)()) F303_2956;
	R1055[1] = (char *(*)()) F304_2983;
}

char *(*R1056[2])();
void R1056_init () {
	R1056[0] = (char *(*)()) F303_2957;
	R1056[1] = (char *(*)()) F304_2984;
}

char *(*R1060[2])();
void R1060_init () {
	R1060[0] = (char *(*)()) F91_1070;
	R1060[1] = (char *(*)()) F304_2987;
}

char *(*R1061[2])();
void R1061_init () {
	R1061[0] = (char *(*)()) F303_2962;
	R1061[1] = (char *(*)()) F91_1071;
}

char *(*R1066[2])();
void R1066_init () {
	R1066[0] = (char *(*)()) F303_2972;
	R1066[1] = (char *(*)()) F304_2992;
}

char *(*R1077[439])();
void R1077_init () {
	R1077[0] = (char *(*)()) F999_6747;
	R1077[1] = (char *(*)()) F1000_6755;
	R1077[2] = (char *(*)()) F1001_6760;
	{long i; for (i = 248; i < 250; i++) R1077[i] = (char *(*)()) F1246_8593;}
	{long i; for (i = 437; i < 439; i++) R1077[i] = (char *(*)()) F1436_11379;}
}

char *(*R1188[4])();
void R1188_init () {
	R1188[0] = (char *(*)()) F108_1210;
	R1188[1] = (char *(*)()) F109_1210_1188_1;
	R1188[2] = (char *(*)()) F110_1210_1188_1;
	R1188[3] = (char *(*)()) F111_1210_1188_1;
}
static EIF_REFERENCE F109_1210_1188_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F109_1210(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F110_1210_1188_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F110_1210(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(897, 0x00).id, 897, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F111_1210_1188_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F111_1210(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(879, 0x00).id, 879, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}

char *(*R1412[12])();
void R1412_init () {
	R1412[0] = (char *(*)()) F1242_8487;
	{long i; for (i = 5; i < 7; i++) R1412[i] = (char *(*)()) F1245_8562;}
	{long i; for (i = 10; i < 12; i++) R1412[i] = (char *(*)()) F1251_8615;}
}

char *(*R1415[12])();
void R1415_init () {
	R1415[0] = (char *(*)()) F1242_8492;
	{long i; for (i = 5; i < 7; i++) R1415[i] = (char *(*)()) F1246_8592;}
	{long i; for (i = 10; i < 12; i++) R1415[i] = (char *(*)()) F1251_8618;}
}

char *(*R1446[1189])();
void R1446_init () {
	R1446[0] = (char *(*)()) F124_1488;
	R1446[1188] = (char *(*)()) F129_1554;
}

char *(*R1447[1189])();
void R1447_init () {
	R1447[0] = (char *(*)()) F124_1489;
	R1447[1188] = (char *(*)()) F129_1555;
}

char *(*R1448[1189])();
void R1448_init () {
	R1448[0] = (char *(*)()) F124_1490;
	R1448[1188] = (char *(*)()) F129_1556;
}

char *(*R1449[1189])();
void R1449_init () {
	R1449[0] = (char *(*)()) F124_1491;
	R1449[1188] = (char *(*)()) F129_1557;
}

char *(*R1450[1189])();
void R1450_init () {
	R1450[0] = (char *(*)()) F124_1492;
	R1450[1188] = (char *(*)()) F129_1558;
}

char *(*R1451[1189])();
void R1451_init () {
	R1451[0] = (char *(*)()) F124_1493;
	R1451[1188] = (char *(*)()) F129_1559;
}

char *(*R1452[1189])();
void R1452_init () {
	R1452[0] = (char *(*)()) F124_1494;
	R1452[1188] = (char *(*)()) F129_1560;
}


#ifdef __cplusplus
}
#endif
