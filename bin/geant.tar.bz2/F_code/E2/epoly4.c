#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O834[2];
void O834_init () {
	O834[0] = + _LNGOFF_1_0_0_1_;
	O834[1] = + _LNGOFF_2_0_0_1_;
}

long O965[4];
void O965_init () {
	O965[0] = 0;
	O965[1] = + _CHROFF_0_0_;
	O965[2] = 0;
	O965[3] = + _CHROFF_1_0_;
}

long O969[2];
void O969_init () {
	O969[0] =  + _REFACS_1_;
	O969[1] = 0;
}

long O1188[6];
void O1188_init () {
	O1188[0] = 0;
	{long i; for (i = 1; i < 3; i++) O1188[i] = + _LNGOFF_0_0_0_0_;}
	O1188[3] = + _I64OFF_0_0_0_0_0_0_0_;
	O1188[4] = 0;
	O1188[5] = + _LNGOFF_1_0_0_0_;
}

long O1512[11];
void O1512_init () {
	O1512[0] = 0;
	O1512[1] = + _CHROFF_0_0_;
	O1512[2] = + _LNGOFF_0_0_0_0_;
	O1512[3] = + _CHROFF_0_0_;
	O1512[4] = 0;
	O1512[5] = + _LNGOFF_0_0_0_0_;
	O1512[6] = 0;
	O1512[7] = + _CHROFF_1_0_;
	O1512[8] = + _LNGOFF_1_0_0_0_;
	O1512[9] = 0;
	O1512[10] = + _LNGOFF_2_0_0_0_;
}

long O1518[2];
void O1518_init () {
	O1518[0] =  + _REFACS_1_;
	O1518[1] = + _LNGOFF_0_0_0_1_;
}

long O1521[5];
void O1521_init () {
	O1521[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O1521[i] = 0;}
	O1521[3] =  + _REFACS_1_;
	O1521[4] = 0;
}

long O1524[2];
void O1524_init () {
	O1524[0] =  + _REFACS_2_;
	O1524[1] =  + _REFACS_1_;
}

long O1626[147];
void O1626_init () {
	O1626[0] = + _LNGOFF_2_4_0_0_;
	O1626[1] = + _LNGOFF_4_6_0_0_;
	O1626[2] = + _LNGOFF_5_6_0_0_;
	O1626[3] = + _LNGOFF_2_4_0_0_;
	O1626[146] = + _LNGOFF_2_4_0_0_;
}

long O1627[147];
void O1627_init () {
	O1627[0] = + _CHROFF_2_0_;
	O1627[1] = + _CHROFF_4_0_;
	O1627[2] = + _CHROFF_5_0_;
	O1627[3] = + _CHROFF_2_0_;
	O1627[146] = + _CHROFF_2_0_;
}

long O1629[147];
void O1629_init () {
	O1629[0] = + _CHROFF_2_1_;
	O1629[1] = + _CHROFF_4_1_;
	O1629[2] = + _CHROFF_5_1_;
	O1629[3] = + _CHROFF_2_1_;
	O1629[146] = + _CHROFF_2_1_;
}

long O1630[147];
void O1630_init () {
	O1630[0] = + _CHROFF_2_2_;
	O1630[1] = + _CHROFF_4_2_;
	O1630[2] = + _CHROFF_5_2_;
	O1630[3] = + _CHROFF_2_2_;
	O1630[146] = + _CHROFF_2_2_;
}

long O1631[147];
void O1631_init () {
	O1631[0] = + _CHROFF_2_3_;
	O1631[1] = + _CHROFF_4_3_;
	O1631[2] = + _CHROFF_5_3_;
	O1631[3] = + _CHROFF_2_3_;
	O1631[146] = + _CHROFF_2_3_;
}

long O1731[4];
void O1731_init () {
	O1731[0] = + _CHROFF_2_0_;
	O1731[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O1731[i] = + _CHROFF_2_0_;}
}

long O1732[4];
void O1732_init () {
	O1732[0] = + _CHROFF_2_1_;
	O1732[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O1732[i] = + _CHROFF_2_1_;}
}

static EIF_TYPE_INDEX Y1900_pgtype0[] = {0xFF01,90,0xFFFF};
static EIF_TYPE_INDEX Y1900_pgtype1[] = {0xFF01,90,0xFFFF};
static EIF_TYPE_INDEX Y1900_pgtype2[] = {0xFF01,302,0xFFFF};
static EIF_TYPE_INDEX Y1900_pgtype3[] = {0xFF01,90,0xFFFF};
static EIF_TYPE_INDEX Y1900_pgtype4[] = {0xFF01,90,0xFFFF};
static EIF_TYPE_INDEX Y1900_pgtype5[] = {0xFF01,302,0xFFFF};
EIF_TYPE_INDEX *Y1900_gen_type [6];
EIF_TYPE_INDEX Y1900 [6];
void Y1900_init (void)
{
	egc_routines_types [1900] = Y1900;
	egc_routines_gen_types [1900] = Y1900_gen_type;
	egc_routines_offset [1900] = 177;
	Y1900_gen_type [0] = Y1900_pgtype0;
	Y1900_gen_type [1] = Y1900_pgtype1;
	Y1900_gen_type [2] = Y1900_pgtype2;
	Y1900_gen_type [3] = Y1900_pgtype3;
	Y1900_gen_type [4] = Y1900_pgtype4;
	Y1900_gen_type [5] = Y1900_pgtype5;
	{long i; for (i = 0; i < 2; i++) Y1900[i] = 90;};
	Y1900[2] = 302;
	{long i; for (i = 3; i < 5; i++) Y1900[i] = 90;};
	Y1900[5] = 302;
}

long O1901[6];
void O1901_init () {
	{long i; for (i = 0; i < 3; i++) O1901[i] = + _LNGOFF_1_3_0_0_;}
	{long i; for (i = 3; i < 5; i++) O1901[i] = + _LNGOFF_2_4_0_0_;}
	O1901[5] = + _LNGOFF_2_5_0_0_;
}

long O1902[6];
void O1902_init () {
	{long i; for (i = 0; i < 3; i++) O1902[i] = + _LNGOFF_1_3_0_1_;}
	{long i; for (i = 3; i < 5; i++) O1902[i] = + _LNGOFF_2_4_0_1_;}
	O1902[5] = + _LNGOFF_2_5_0_1_;
}

long O1903[6];
void O1903_init () {
	{long i; for (i = 0; i < 3; i++) O1903[i] = + _LNGOFF_1_3_0_2_;}
	{long i; for (i = 3; i < 5; i++) O1903[i] = + _LNGOFF_2_4_0_2_;}
	O1903[5] = + _LNGOFF_2_5_0_2_;
}

long O1904[6];
void O1904_init () {
	{long i; for (i = 0; i < 3; i++) O1904[i] = + _LNGOFF_1_3_0_3_;}
	{long i; for (i = 3; i < 5; i++) O1904[i] = + _LNGOFF_2_4_0_3_;}
	O1904[5] = + _LNGOFF_2_5_0_3_;
}

long O1905[6];
void O1905_init () {
	{long i; for (i = 0; i < 3; i++) O1905[i] = + _LNGOFF_1_3_0_4_;}
	{long i; for (i = 3; i < 5; i++) O1905[i] = + _LNGOFF_2_4_0_4_;}
	O1905[5] = + _LNGOFF_2_5_0_4_;
}

long O1906[6];
void O1906_init () {
	{long i; for (i = 0; i < 3; i++) O1906[i] = + _LNGOFF_1_3_0_5_;}
	{long i; for (i = 3; i < 5; i++) O1906[i] = + _LNGOFF_2_4_0_5_;}
	O1906[5] = + _LNGOFF_2_5_0_5_;
}

long O1907[6];
void O1907_init () {
	{long i; for (i = 0; i < 3; i++) O1907[i] = + _CHROFF_1_0_;}
	{long i; for (i = 3; i < 6; i++) O1907[i] = + _CHROFF_2_0_;}
}

long O1912[6];
void O1912_init () {
	{long i; for (i = 0; i < 3; i++) O1912[i] = + _CHROFF_1_1_;}
	{long i; for (i = 3; i < 6; i++) O1912[i] = + _CHROFF_2_1_;}
}

long O1983[1117];
void O1983_init () {
	{long i; for (i = 0; i < 5; i++) O1983[i] = 0;}
	{long i; for (i = 74; i < 76; i++) O1983[i] = 0;}
	{long i; for (i = 780; i < 784; i++) O1983[i] = 0;}
	O1983[1068] = 0;
	{long i; for (i = 1070; i < 1073; i++) O1983[i] = 0;}
	{long i; for (i = 1115; i < 1117; i++) O1983[i] =  + _REFACS_1_;}
}

static EIF_TYPE_INDEX Y2478_pgtype0[] = {0xFF01,712,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype1[] = {0xFF01,713,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype2[] = {0xFF01,714,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype3[] = {0xFF01,715,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype4[] = {0xFF01,716,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype5[] = {0xFF01,717,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype6[] = {0xFF01,718,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype7[] = {0xFF01,719,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype8[] = {0xFF01,720,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype9[] = {0xFF01,721,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype10[] = {0xFF01,722,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype11[] = {0xFF01,723,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype12[] = {0xFF01,718,888,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype13[] = {0xFF01,718,888,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype14[] = {0xFF01,712,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype15[] = {0xFF01,713,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype16[] = {0xFF01,714,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype17[] = {0xFF01,715,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype18[] = {0xFF01,716,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype19[] = {0xFF01,717,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype20[] = {0xFF01,718,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype21[] = {0xFF01,719,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype22[] = {0xFF01,720,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype23[] = {0xFF01,721,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype24[] = {0xFF01,722,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype25[] = {0xFF01,723,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype26[] = {0xFF01,712,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype27[] = {0xFF01,714,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype28[] = {0xFF01,716,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype29[] = {0xFF01,721,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype30[] = {0xFF01,715,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype31[] = {0xFF01,720,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype32[] = {0xFF01,712,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype33[] = {0xFF01,713,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype34[] = {0xFF01,714,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype35[] = {0xFF01,715,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype36[] = {0xFF01,716,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype37[] = {0xFF01,717,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype38[] = {0xFF01,718,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype39[] = {0xFF01,719,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype40[] = {0xFF01,720,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype41[] = {0xFF01,721,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype42[] = {0xFF01,722,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype43[] = {0xFF01,723,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype44[] = {0xFF01,717,897,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype45[] = {0xFF01,716,900,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype46[] = {0xFF01,716,900,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype47[] = {0xFF01,716,900,0xFFFF};
static EIF_TYPE_INDEX Y2478_pgtype48[] = {0xFF01,716,900,0xFFFF};
EIF_TYPE_INDEX *Y2478_gen_type [1158];
EIF_TYPE_INDEX Y2478 [1158];
void Y2478_init (void)
{
	egc_routines_types [2478] = Y2478;
	egc_routines_gen_types [2478] = Y2478_gen_type;
	egc_routines_offset [2478] = 279;
	Y2478_gen_type [0] = Y2478_pgtype0;
	Y2478_gen_type [1] = Y2478_pgtype1;
	Y2478_gen_type [2] = Y2478_pgtype2;
	Y2478_gen_type [3] = Y2478_pgtype3;
	Y2478_gen_type [4] = Y2478_pgtype4;
	Y2478_gen_type [5] = Y2478_pgtype5;
	Y2478_gen_type [6] = Y2478_pgtype6;
	Y2478_gen_type [7] = Y2478_pgtype7;
	Y2478_gen_type [8] = Y2478_pgtype8;
	Y2478_gen_type [9] = Y2478_pgtype9;
	Y2478_gen_type [10] = Y2478_pgtype10;
	Y2478_gen_type [11] = Y2478_pgtype11;
	Y2478_gen_type [16] = Y2478_pgtype12;
	Y2478_gen_type [17] = Y2478_pgtype13;
	Y2478_gen_type [458] = Y2478_pgtype14;
	Y2478_gen_type [459] = Y2478_pgtype15;
	Y2478_gen_type [460] = Y2478_pgtype16;
	Y2478_gen_type [461] = Y2478_pgtype17;
	Y2478_gen_type [462] = Y2478_pgtype18;
	Y2478_gen_type [463] = Y2478_pgtype19;
	Y2478_gen_type [464] = Y2478_pgtype20;
	Y2478_gen_type [465] = Y2478_pgtype21;
	Y2478_gen_type [466] = Y2478_pgtype22;
	Y2478_gen_type [467] = Y2478_pgtype23;
	Y2478_gen_type [468] = Y2478_pgtype24;
	Y2478_gen_type [469] = Y2478_pgtype25;
	Y2478_gen_type [470] = Y2478_pgtype26;
	Y2478_gen_type [471] = Y2478_pgtype27;
	Y2478_gen_type [472] = Y2478_pgtype28;
	Y2478_gen_type [473] = Y2478_pgtype29;
	Y2478_gen_type [474] = Y2478_pgtype30;
	Y2478_gen_type [475] = Y2478_pgtype31;
	Y2478_gen_type [530] = Y2478_pgtype32;
	Y2478_gen_type [531] = Y2478_pgtype33;
	Y2478_gen_type [532] = Y2478_pgtype34;
	Y2478_gen_type [533] = Y2478_pgtype35;
	Y2478_gen_type [534] = Y2478_pgtype36;
	Y2478_gen_type [535] = Y2478_pgtype37;
	Y2478_gen_type [536] = Y2478_pgtype38;
	Y2478_gen_type [537] = Y2478_pgtype39;
	Y2478_gen_type [538] = Y2478_pgtype40;
	Y2478_gen_type [539] = Y2478_pgtype41;
	Y2478_gen_type [540] = Y2478_pgtype42;
	Y2478_gen_type [541] = Y2478_pgtype43;
	Y2478_gen_type [668] = Y2478_pgtype44;
	Y2478_gen_type [671] = Y2478_pgtype45;
	Y2478_gen_type [672] = Y2478_pgtype46;
	Y2478_gen_type [1156] = Y2478_pgtype47;
	Y2478_gen_type [1157] = Y2478_pgtype48;
	Y2478[0] = 712;
	Y2478[1] = 713;
	Y2478[2] = 714;
	Y2478[3] = 715;
	Y2478[4] = 716;
	Y2478[5] = 717;
	Y2478[6] = 718;
	Y2478[7] = 719;
	Y2478[8] = 720;
	Y2478[9] = 721;
	Y2478[10] = 722;
	Y2478[11] = 723;
	{long i; for (i = 16; i < 18; i++) Y2478[i] = 718;};
	Y2478[458] = 712;
	Y2478[459] = 713;
	Y2478[460] = 714;
	Y2478[461] = 715;
	Y2478[462] = 716;
	Y2478[463] = 717;
	Y2478[464] = 718;
	Y2478[465] = 719;
	Y2478[466] = 720;
	Y2478[467] = 721;
	Y2478[468] = 722;
	Y2478[469] = 723;
	Y2478[470] = 712;
	Y2478[471] = 714;
	Y2478[472] = 716;
	Y2478[473] = 721;
	Y2478[474] = 715;
	Y2478[475] = 720;
	Y2478[530] = 712;
	Y2478[531] = 713;
	Y2478[532] = 714;
	Y2478[533] = 715;
	Y2478[534] = 716;
	Y2478[535] = 717;
	Y2478[536] = 718;
	Y2478[537] = 719;
	Y2478[538] = 720;
	Y2478[539] = 721;
	Y2478[540] = 722;
	Y2478[541] = 723;
	Y2478[668] = 717;
	{long i; for (i = 671; i < 673; i++) Y2478[i] = 716;};
	{long i; for (i = 1156; i < 1158; i++) Y2478[i] = 716;};
}

long O2542[948];
void O2542_init () {
	O2542[0] = + _PTROFF_3_0_0_1_0_0_;
	O2542[947] = + _PTROFF_6_2_0_1_0_0_;
}

long O2543[948];
void O2543_init () {
	O2543[0] = + _PTROFF_3_0_0_1_0_1_;
	O2543[947] = + _PTROFF_6_2_0_1_0_1_;
}

long O2548[948];
void O2548_init () {
	O2548[0] = + _LNGOFF_3_0_0_0_;
	O2548[947] = + _LNGOFF_6_2_0_0_;
}

long O2639[695];
void O2639_init () {
	O2639[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 693; i < 695; i++) O2639[i] = + _LNGOFF_2_1_0_0_;}
}

long O2729[950];
void O2729_init () {
	O2729[0] = + _CHROFF_1_0_;
	O2729[392] = + _CHROFF_3_0_;
	O2729[393] = + _CHROFF_4_0_;
	O2729[394] = + _CHROFF_5_0_;
	O2729[706] = + _CHROFF_5_0_;
	O2729[941] = + _CHROFF_6_0_;
	{long i; for (i = 942; i < 945; i++) O2729[i] = + _CHROFF_5_0_;}
	O2729[946] = + _CHROFF_7_1_;
	{long i; for (i = 947; i < 950; i++) O2729[i] = + _CHROFF_6_1_;}
}

long O2730[950];
void O2730_init () {
	O2730[0] = 0;
	{long i; for (i = 392; i < 395; i++) O2730[i] = 0;}
	O2730[706] = 0;
	{long i; for (i = 941; i < 945; i++) O2730[i] = 0;}
	O2730[946] =  + _REFACS_6_;
	{long i; for (i = 947; i < 950; i++) O2730[i] =  + _REFACS_5_;}
}

long O2731[950];
void O2731_init () {
	O2731[0] = + _LNGOFF_1_3_2_1_;
	O2731[392] = + _LNGOFF_3_6_2_1_;
	O2731[393] = + _LNGOFF_4_6_2_1_;
	O2731[394] = + _LNGOFF_5_7_2_1_;
	O2731[706] = + _LNGOFF_5_7_2_1_;
	O2731[941] = + _LNGOFF_6_7_2_1_;
	{long i; for (i = 942; i < 945; i++) O2731[i] = + _LNGOFF_5_6_2_1_;}
	O2731[946] = + _LNGOFF_7_8_2_1_;
	{long i; for (i = 947; i < 950; i++) O2731[i] = + _LNGOFF_6_7_2_1_;}
}

long O2741[950];
void O2741_init () {
	O2741[0] = + _R32OFF_1_3_2_3_0_;
	O2741[392] = + _R32OFF_3_6_2_4_0_;
	O2741[393] = + _R32OFF_4_6_2_4_0_;
	O2741[394] = + _R32OFF_5_7_2_4_0_;
	O2741[706] = + _R32OFF_5_7_2_4_0_;
	O2741[941] = + _R32OFF_6_7_2_4_0_;
	{long i; for (i = 942; i < 945; i++) O2741[i] = + _R32OFF_5_6_2_4_0_;}
	O2741[946] = + _R32OFF_7_8_2_4_0_;
	{long i; for (i = 947; i < 950; i++) O2741[i] = + _R32OFF_6_7_2_4_0_;}
}


#ifdef __cplusplus
}
#endif
