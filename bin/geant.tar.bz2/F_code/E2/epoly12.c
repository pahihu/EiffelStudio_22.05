#include "epoly12.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R6053[27])();
void R6053_init () {
	R6053[0] = (char *(*)()) F1185_7940;
	R6053[1] = (char *(*)()) F1186_7940;
	{long i; for (i = 2; i < 5; i++) R6053[i] = (char *(*)()) F1185_7940;}
	R6053[24] = (char *(*)()) F1179_7847;
	R6053[25] = (char *(*)()) F1180_7847;
	R6053[26] = (char *(*)()) F1179_7847;
}

char *(*R6058[5])();
void R6058_init () {
	R6058[0] = (char *(*)()) F1185_7951;
	R6058[1] = (char *(*)()) F1186_7951;
	{long i; for (i = 2; i < 5; i++) R6058[i] = (char *(*)()) F1185_7951;}
}

char *(*R6059[27])();
void R6059_init () {
	R6059[0] = (char *(*)()) F1185_7952;
	R6059[1] = (char *(*)()) F1186_7952;
	R6059[2] = (char *(*)()) F1185_7952;
	R6059[3] = (char *(*)()) F1188_8020;
	R6059[4] = (char *(*)()) F1185_7952;
	R6059[24] = (char *(*)()) F1209_8180;
	R6059[25] = (char *(*)()) F1210_8180;
	R6059[26] = (char *(*)()) F1209_8180;
}

char *(*R6060[3])();
void R6060_init () {
	R6060[0] = (char *(*)()) F1209_8181;
	R6060[1] = (char *(*)()) F1210_8181;
	R6060[2] = (char *(*)()) F1209_8181;
}

char *(*R6090[27])();
void R6090_init () {
	R6090[0] = (char *(*)()) F1185_7954;
	R6090[1] = (char *(*)()) F1186_7954;
	R6090[2] = (char *(*)()) F1185_7954;
	R6090[3] = (char *(*)()) F1188_8021;
	R6090[4] = (char *(*)()) F1185_7954;
	R6090[24] = (char *(*)()) F1209_8182;
	R6090[25] = (char *(*)()) F1210_8182;
	R6090[26] = (char *(*)()) F1209_8182;
}

char *(*R6100[27])();
void R6100_init () {
	R6100[0] = (char *(*)()) F1185_7976;
	R6100[1] = (char *(*)()) F1186_7976;
	{long i; for (i = 2; i < 5; i++) R6100[i] = (char *(*)()) F1185_7976;}
	R6100[24] = (char *(*)()) F1209_8206;
	R6100[25] = (char *(*)()) F1210_8206;
	R6100[26] = (char *(*)()) F1209_8206;
}

char *(*R6108[5])();
void R6108_init () {
	R6108[0] = (char *(*)()) F1185_7968;
	R6108[1] = (char *(*)()) F1186_7968;
	R6108[2] = (char *(*)()) F1185_7968;
	R6108[3] = (char *(*)()) F1188_8027;
	R6108[4] = (char *(*)()) F1185_7968;
}

char *(*R6109[5])();
void R6109_init () {
	R6109[0] = (char *(*)()) F1185_7969;
	R6109[1] = (char *(*)()) F1186_7969;
	{long i; for (i = 2; i < 5; i++) R6109[i] = (char *(*)()) F1185_7969;}
}

char *(*R6110[5])();
void R6110_init () {
	R6110[0] = (char *(*)()) F1185_7972;
	R6110[1] = (char *(*)()) F1186_7972;
	{long i; for (i = 2; i < 5; i++) R6110[i] = (char *(*)()) F1185_7972;}
}

char *(*R6111[5])();
void R6111_init () {
	R6111[0] = (char *(*)()) F1185_7973;
	R6111[1] = (char *(*)()) F1186_7973;
	{long i; for (i = 2; i < 5; i++) R6111[i] = (char *(*)()) F1185_7973;}
}

char *(*R6112[5])();
void R6112_init () {
	R6112[0] = (char *(*)()) F1185_7974;
	R6112[1] = (char *(*)()) F1186_7974;
	{long i; for (i = 2; i < 5; i++) R6112[i] = (char *(*)()) F1185_7974;}
}

char *(*R6122[13])();
void R6122_init () {
	R6122[0] = (char *(*)()) F1196_8053;
	R6122[1] = (char *(*)()) F1197_8053_6122_1;
	R6122[5] = (char *(*)()) F1201_8082;
	R6122[10] = (char *(*)()) F1206_8114;
	R6122[11] = (char *(*)()) F1207_8114_6122_1;
	R6122[12] = (char *(*)()) F1208_8114_6122_1;
}
static EIF_REFERENCE F1197_8053_6122_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1197_8053(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1207_8114_6122_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1207_8114(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(903, 0x00).id, 903, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1208_8114_6122_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1208_8114(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6123[13])();
void R6123_init () {
	R6123[0] = (char *(*)()) F1196_8062;
	R6123[1] = (char *(*)()) F1197_8062;
	R6123[5] = (char *(*)()) F1201_8092;
	R6123[10] = (char *(*)()) F1206_8126;
	R6123[11] = (char *(*)()) F1207_8126;
	R6123[12] = (char *(*)()) F1208_8126;
}

char *(*R6137[149])();
void R6137_init () {
	R6137[0] = (char *(*)()) F1202_8105;
	R6137[1] = (char *(*)()) F1204_8105;
	R6137[2] = (char *(*)()) F1203_8105;
	R6137[3] = (char *(*)()) F1202_8105;
	R6137[4] = (char *(*)()) F1203_8105;
	R6137[5] = (char *(*)()) F1202_8105;
	R6137[15] = (char *(*)()) F1202_8105;
	R6137[16] = (char *(*)()) F1203_8105;
	{long i; for (i = 27; i < 29; i++) R6137[i] = (char *(*)()) F1202_8105;}
	R6137[29] = (char *(*)()) F1204_8105;
	R6137[30] = (char *(*)()) F1205_8105;
	R6137[31] = (char *(*)()) F1203_8105;
	{long i; for (i = 32; i < 34; i++) R6137[i] = (char *(*)()) F1202_8105;}
	R6137[148] = (char *(*)()) F1202_8105;
}

char *(*R6139[149])();
void R6139_init () {
	R6139[0] = (char *(*)()) F1206_8130;
	R6139[1] = (char *(*)()) F1207_8130;
	R6139[2] = (char *(*)()) F1208_8130;
	R6139[3] = (char *(*)()) F1209_8194;
	R6139[4] = (char *(*)()) F1210_8194;
	R6139[5] = (char *(*)()) F1209_8194;
	R6139[15] = (char *(*)()) F1212_8255;
	R6139[16] = (char *(*)()) F1214_8255;
	R6139[27] = (char *(*)()) F1212_8255;
	R6139[28] = (char *(*)()) F1213_8255;
	R6139[29] = (char *(*)()) F1215_8255;
	R6139[30] = (char *(*)()) F1216_8255;
	R6139[31] = (char *(*)()) F1214_8255;
	{long i; for (i = 32; i < 34; i++) R6139[i] = (char *(*)()) F1212_8255;}
	R6139[148] = (char *(*)()) F1212_8255;
}

char *(*R6140[149])();
void R6140_init () {
	R6140[0] = (char *(*)()) F1202_8108;
	R6140[1] = (char *(*)()) F1204_8108;
	R6140[2] = (char *(*)()) F1203_8108;
	R6140[3] = (char *(*)()) F1202_8108;
	R6140[4] = (char *(*)()) F1203_8108;
	R6140[5] = (char *(*)()) F1202_8108;
	R6140[15] = (char *(*)()) F1212_8320;
	R6140[16] = (char *(*)()) F1214_8320;
	R6140[27] = (char *(*)()) F1212_8320;
	R6140[28] = (char *(*)()) F1213_8320;
	R6140[29] = (char *(*)()) F1215_8320;
	R6140[30] = (char *(*)()) F1216_8320;
	R6140[31] = (char *(*)()) F1214_8320;
	{long i; for (i = 32; i < 34; i++) R6140[i] = (char *(*)()) F1212_8320;}
	R6140[148] = (char *(*)()) F1212_8320;
}

char *(*R6146[3])();
void R6146_init () {
	R6146[0] = (char *(*)()) F1206_8140;
	R6146[1] = (char *(*)()) F1207_8140;
	R6146[2] = (char *(*)()) F1208_8140;
}

char *(*R6154[3])();
void R6154_init () {
	R6154[0] = (char *(*)()) F1209_8196;
	R6154[1] = (char *(*)()) F1210_8196;
	R6154[2] = (char *(*)()) F1209_8196;
}

char *(*R6155[3])();
void R6155_init () {
	R6155[0] = (char *(*)()) F1209_8197;
	R6155[1] = (char *(*)()) F1210_8197;
	R6155[2] = (char *(*)()) F1209_8197;
}

char *(*R6157[3])();
void R6157_init () {
	R6157[0] = (char *(*)()) F1209_8201;
	R6157[1] = (char *(*)()) F1210_8201;
	R6157[2] = (char *(*)()) F1209_8201;
}

char *(*R6158[3])();
void R6158_init () {
	R6158[0] = (char *(*)()) F1209_8202;
	R6158[1] = (char *(*)()) F1210_8202;
	R6158[2] = (char *(*)()) F1209_8202;
}

char *(*R6159[3])();
void R6159_init () {
	R6159[0] = (char *(*)()) F1209_8203;
	R6159[1] = (char *(*)()) F1210_8203;
	R6159[2] = (char *(*)()) F1209_8203;
}

char *(*R6160[3])();
void R6160_init () {
	R6160[0] = (char *(*)()) F1209_8204;
	R6160[1] = (char *(*)()) F1210_8204;
	R6160[2] = (char *(*)()) F1209_8204;
}

char *(*R6161[3])();
void R6161_init () {
	R6161[0] = (char *(*)()) F1209_8221;
	R6161[1] = (char *(*)()) F1210_8221;
	R6161[2] = (char *(*)()) F1209_8221;
}

char *(*R6174[134])();
void R6174_init () {
	R6174[0] = (char *(*)()) F1212_8231;
	R6174[1] = (char *(*)()) F1214_8231;
	R6174[12] = (char *(*)()) F1212_8231;
	R6174[13] = (char *(*)()) F1213_8231;
	R6174[14] = (char *(*)()) F1215_8231;
	R6174[15] = (char *(*)()) F1216_8231;
	R6174[16] = (char *(*)()) F1214_8231;
	{long i; for (i = 17; i < 19; i++) R6174[i] = (char *(*)()) F1212_8231;}
	R6174[133] = (char *(*)()) F1212_8231;
}

char *(*R6176[134])();
void R6176_init () {
	R6176[0] = (char *(*)()) F1212_8240;
	R6176[1] = (char *(*)()) F1214_8240;
	R6176[12] = (char *(*)()) F1212_8240;
	R6176[13] = (char *(*)()) F1213_8240;
	R6176[14] = (char *(*)()) F1215_8240;
	R6176[15] = (char *(*)()) F1216_8240;
	R6176[16] = (char *(*)()) F1214_8240;
	{long i; for (i = 17; i < 19; i++) R6176[i] = (char *(*)()) F1212_8240;}
	R6176[133] = (char *(*)()) F1212_8240;
}

char *(*R6177[134])();
void R6177_init () {
	R6177[0] = (char *(*)()) F1217_8331;
	R6177[1] = (char *(*)()) F1218_8331_6177_4;
	R6177[12] = (char *(*)()) F1223_8405;
	R6177[13] = (char *(*)()) F1224_8405_6177_4;
	R6177[14] = (char *(*)()) F1225_8405;
	R6177[15] = (char *(*)()) F1226_8405_6177_4;
	R6177[16] = (char *(*)()) F1227_8405_6177_4;
	{long i; for (i = 17; i < 19; i++) R6177[i] = (char *(*)()) F1223_8405;}
	R6177[133] = (char *(*)()) F1223_8405;
}
static void F1218_8331_6177_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1218_8331(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1224_8405_6177_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1224_8405(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1226_8405_6177_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1226_8405(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F1227_8405_6177_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1227_8405(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R6178[134])();
void R6178_init () {
	R6178[0] = (char *(*)()) F1212_8250;
	R6178[1] = (char *(*)()) F1214_8250;
	R6178[12] = (char *(*)()) F1212_8250;
	R6178[13] = (char *(*)()) F1213_8250;
	R6178[14] = (char *(*)()) F1215_8250;
	R6178[15] = (char *(*)()) F1216_8250;
	R6178[16] = (char *(*)()) F1214_8250;
	{long i; for (i = 17; i < 19; i++) R6178[i] = (char *(*)()) F1212_8250;}
	R6178[133] = (char *(*)()) F1212_8250;
}

char *(*R6183[134])();
void R6183_init () {
	R6183[0] = (char *(*)()) F1219_8357;
	R6183[1] = (char *(*)()) F1220_8357_6183_26;
	R6183[12] = (char *(*)()) F1228_8432;
	R6183[13] = (char *(*)()) F1229_8432;
	R6183[14] = (char *(*)()) F1230_8432_6183_26;
	R6183[15] = (char *(*)()) F1231_8432_6183_26;
	R6183[16] = (char *(*)()) F1232_8432_6183_26;
	{long i; for (i = 17; i < 19; i++) R6183[i] = (char *(*)()) F1228_8432;}
	R6183[133] = (char *(*)()) F1228_8432;
}
static EIF_REFERENCE F1220_8357_6183_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1220_8357(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1230_8432_6183_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1230_8432(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(903, 0x00).id, 903, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1231_8432_6183_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1231_8432(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(879, 0x00).id, 879, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1232_8432_6183_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1232_8432(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6184[134])();
void R6184_init () {
	R6184[0] = (char *(*)()) F1219_8361;
	R6184[1] = (char *(*)()) F1220_8361_6184_131;
	R6184[12] = (char *(*)()) F1228_8433;
	R6184[13] = (char *(*)()) F1229_8433;
	R6184[14] = (char *(*)()) F1230_8433_6184_131;
	R6184[15] = (char *(*)()) F1231_8433_6184_131;
	R6184[16] = (char *(*)()) F1232_8433_6184_131;
	{long i; for (i = 17; i < 19; i++) R6184[i] = (char *(*)()) F1228_8433;}
	R6184[133] = (char *(*)()) F1228_8433;
}
static void F1220_8361_6184_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1220_8361(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1230_8433_6184_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1230_8433(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1231_8433_6184_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1231_8433(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1232_8433_6184_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1232_8433(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R6185[134])();
void R6185_init () {
	R6185[0] = (char *(*)()) F1217_8347;
	R6185[1] = (char *(*)()) F1218_8347_6185_26;
	R6185[12] = (char *(*)()) F1228_8434;
	R6185[13] = (char *(*)()) F1229_8434_6185_26;
	R6185[14] = (char *(*)()) F1230_8434;
	R6185[15] = (char *(*)()) F1231_8434_6185_26;
	R6185[16] = (char *(*)()) F1232_8434_6185_26;
	{long i; for (i = 17; i < 19; i++) R6185[i] = (char *(*)()) F1228_8434;}
	R6185[133] = (char *(*)()) F1228_8434;
}
static EIF_REFERENCE F1218_8347_6185_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1218_8347(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1229_8434_6185_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1229_8434(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1231_8434_6185_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1231_8434(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(882, 0x00).id, 882, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1232_8434_6185_26 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1232_8434(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(873, 0x00).id, 873, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6186[134])();
void R6186_init () {
	R6186[0] = (char *(*)()) F1219_8358;
	R6186[1] = (char *(*)()) F1220_8358;
	R6186[12] = (char *(*)()) F1228_8435;
	R6186[13] = (char *(*)()) F1229_8435;
	R6186[14] = (char *(*)()) F1230_8435;
	R6186[15] = (char *(*)()) F1231_8435;
	R6186[16] = (char *(*)()) F1232_8435;
	{long i; for (i = 17; i < 19; i++) R6186[i] = (char *(*)()) F1228_8435;}
	R6186[133] = (char *(*)()) F1228_8435;
}

char *(*R6189[134])();
void R6189_init () {
	R6189[0] = (char *(*)()) F1212_8264;
	R6189[1] = (char *(*)()) F1214_8264_6189_4;
	R6189[12] = (char *(*)()) F1212_8264;
	R6189[13] = (char *(*)()) F1213_8264_6189_4;
	R6189[14] = (char *(*)()) F1215_8264;
	R6189[15] = (char *(*)()) F1216_8264_6189_4;
	R6189[16] = (char *(*)()) F1214_8264_6189_4;
	{long i; for (i = 17; i < 19; i++) R6189[i] = (char *(*)()) F1212_8264;}
	R6189[133] = (char *(*)()) F1212_8264;
}
static void F1214_8264_6189_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1214_8264(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1213_8264_6189_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1213_8264(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1216_8264_6189_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1216_8264(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R6190[134])();
void R6190_init () {
	R6190[0] = (char *(*)()) F1212_8265;
	R6190[1] = (char *(*)()) F1214_8265_6190_23;
	R6190[12] = (char *(*)()) F1212_8265;
	R6190[13] = (char *(*)()) F1213_8265_6190_23;
	R6190[14] = (char *(*)()) F1215_8265;
	R6190[15] = (char *(*)()) F1216_8265_6190_23;
	R6190[16] = (char *(*)()) F1214_8265_6190_23;
	{long i; for (i = 17; i < 19; i++) R6190[i] = (char *(*)()) F1212_8265;}
	R6190[133] = (char *(*)()) F1212_8265;
}
static EIF_INTEGER_32 F1214_8265_6190_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1214_8265(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F1213_8265_6190_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1213_8265(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F1216_8265_6190_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1216_8265(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R6191[134])();
void R6191_init () {
	R6191[0] = (char *(*)()) F1217_8348;
	R6191[1] = (char *(*)()) F1218_8348;
	R6191[12] = (char *(*)()) F1223_8400;
	R6191[13] = (char *(*)()) F1224_8400;
	R6191[14] = (char *(*)()) F1225_8400;
	R6191[15] = (char *(*)()) F1226_8400;
	R6191[16] = (char *(*)()) F1227_8400;
	{long i; for (i = 17; i < 19; i++) R6191[i] = (char *(*)()) F1223_8400;}
	R6191[133] = (char *(*)()) F1223_8400;
}

char *(*R6192[134])();
void R6192_init () {
	R6192[0] = (char *(*)()) F1217_8349;
	R6192[1] = (char *(*)()) F1218_8349;
	R6192[12] = (char *(*)()) F1223_8427;
	R6192[13] = (char *(*)()) F1224_8427;
	R6192[14] = (char *(*)()) F1225_8427;
	R6192[15] = (char *(*)()) F1226_8427;
	R6192[16] = (char *(*)()) F1227_8427;
	{long i; for (i = 17; i < 19; i++) R6192[i] = (char *(*)()) F1223_8427;}
	R6192[133] = (char *(*)()) F1223_8427;
}

char *(*R6193[134])();
void R6193_init () {
	R6193[0] = (char *(*)()) F1221_8385;
	R6193[1] = (char *(*)()) F1222_8385_6193_23;
	R6193[12] = (char *(*)()) F1233_8469;
	R6193[13] = (char *(*)()) F1234_8469_6193_23;
	R6193[14] = (char *(*)()) F1235_8469;
	R6193[15] = (char *(*)()) F1236_8469_6193_23;
	R6193[16] = (char *(*)()) F1237_8469_6193_23;
	{long i; for (i = 17; i < 19; i++) R6193[i] = (char *(*)()) F1233_8469;}
	R6193[133] = (char *(*)()) F1233_8469;
}
static EIF_INTEGER_32 F1222_8385_6193_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1222_8385(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F1234_8469_6193_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1234_8469(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F1236_8469_6193_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1236_8469(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_INTEGER_32 F1237_8469_6193_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1237_8469(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R6194[134])();
void R6194_init () {
	R6194[0] = (char *(*)()) F1212_8269;
	R6194[1] = (char *(*)()) F1214_8269;
	R6194[12] = (char *(*)()) F1212_8269;
	R6194[13] = (char *(*)()) F1213_8269;
	R6194[14] = (char *(*)()) F1215_8269;
	R6194[15] = (char *(*)()) F1216_8269;
	R6194[16] = (char *(*)()) F1214_8269;
	{long i; for (i = 17; i < 19; i++) R6194[i] = (char *(*)()) F1212_8269;}
	R6194[133] = (char *(*)()) F1212_8269;
}

char *(*R6195[134])();
void R6195_init () {
	R6195[0] = (char *(*)()) F1219_8360;
	R6195[1] = (char *(*)()) F1220_8360;
	R6195[12] = (char *(*)()) F1228_8437;
	R6195[13] = (char *(*)()) F1229_8437;
	R6195[14] = (char *(*)()) F1230_8437;
	R6195[15] = (char *(*)()) F1231_8437;
	R6195[16] = (char *(*)()) F1232_8437;
	{long i; for (i = 17; i < 19; i++) R6195[i] = (char *(*)()) F1228_8437;}
	R6195[133] = (char *(*)()) F1228_8437;
}

char *(*R6196[134])();
void R6196_init () {
	R6196[0] = (char *(*)()) F1219_8362;
	R6196[1] = (char *(*)()) F1220_8362;
	R6196[12] = (char *(*)()) F1228_8438;
	R6196[13] = (char *(*)()) F1229_8438;
	R6196[14] = (char *(*)()) F1230_8438;
	R6196[15] = (char *(*)()) F1231_8438;
	R6196[16] = (char *(*)()) F1232_8438;
	{long i; for (i = 17; i < 19; i++) R6196[i] = (char *(*)()) F1228_8438;}
	R6196[133] = (char *(*)()) F1228_8438;
}

char *(*R6197[134])();
void R6197_init () {
	R6197[0] = (char *(*)()) F1219_8363;
	R6197[1] = (char *(*)()) F1220_8363;
	R6197[12] = (char *(*)()) F1228_8439;
	R6197[13] = (char *(*)()) F1229_8439;
	R6197[14] = (char *(*)()) F1230_8439;
	R6197[15] = (char *(*)()) F1231_8439;
	R6197[16] = (char *(*)()) F1232_8439;
	{long i; for (i = 17; i < 19; i++) R6197[i] = (char *(*)()) F1228_8439;}
	R6197[133] = (char *(*)()) F1228_8439;
}

char *(*R6198[134])();
void R6198_init () {
	R6198[0] = (char *(*)()) F1219_8364;
	R6198[1] = (char *(*)()) F1220_8364;
	R6198[12] = (char *(*)()) F1228_8440;
	R6198[13] = (char *(*)()) F1229_8440;
	R6198[14] = (char *(*)()) F1230_8440;
	R6198[15] = (char *(*)()) F1231_8440;
	R6198[16] = (char *(*)()) F1232_8440;
	{long i; for (i = 17; i < 19; i++) R6198[i] = (char *(*)()) F1228_8440;}
	R6198[133] = (char *(*)()) F1228_8440;
}

char *(*R6199[134])();
void R6199_init () {
	R6199[0] = (char *(*)()) F1219_8365;
	R6199[1] = (char *(*)()) F1220_8365;
	R6199[12] = (char *(*)()) F1228_8441;
	R6199[13] = (char *(*)()) F1229_8441;
	R6199[14] = (char *(*)()) F1230_8441;
	R6199[15] = (char *(*)()) F1231_8441;
	R6199[16] = (char *(*)()) F1232_8441;
	{long i; for (i = 17; i < 19; i++) R6199[i] = (char *(*)()) F1228_8441;}
	R6199[133] = (char *(*)()) F1228_8441;
}

char *(*R6200[134])();
void R6200_init () {
	R6200[0] = (char *(*)()) F1217_8350;
	R6200[1] = (char *(*)()) F1218_8350;
	R6200[12] = (char *(*)()) F1228_8443;
	R6200[13] = (char *(*)()) F1229_8443;
	R6200[14] = (char *(*)()) F1230_8443;
	R6200[15] = (char *(*)()) F1231_8443;
	R6200[16] = (char *(*)()) F1232_8443;
	{long i; for (i = 17; i < 19; i++) R6200[i] = (char *(*)()) F1228_8443;}
	R6200[133] = (char *(*)()) F1228_8443;
}

char *(*R6201[134])();
void R6201_init () {
	R6201[0] = (char *(*)()) F1217_8351;
	R6201[1] = (char *(*)()) F1218_8351_6201_131;
	R6201[12] = (char *(*)()) F1228_8444;
	R6201[13] = (char *(*)()) F1229_8444_6201_131;
	R6201[14] = (char *(*)()) F1230_8444;
	R6201[15] = (char *(*)()) F1231_8444_6201_131;
	R6201[16] = (char *(*)()) F1232_8444_6201_131;
	{long i; for (i = 17; i < 19; i++) R6201[i] = (char *(*)()) F1228_8444;}
	R6201[133] = (char *(*)()) F1228_8444;
}
static void F1218_8351_6201_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1218_8351(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1229_8444_6201_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1229_8444(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1231_8444_6201_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1231_8444(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1232_8444_6201_131 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1232_8444(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R6202[134])();
void R6202_init () {
	R6202[0] = (char *(*)()) F1217_8352;
	R6202[1] = (char *(*)()) F1218_8352;
	R6202[12] = (char *(*)()) F1228_8445;
	R6202[13] = (char *(*)()) F1229_8445;
	R6202[14] = (char *(*)()) F1230_8445;
	R6202[15] = (char *(*)()) F1231_8445;
	R6202[16] = (char *(*)()) F1232_8445;
	{long i; for (i = 17; i < 19; i++) R6202[i] = (char *(*)()) F1228_8445;}
	R6202[133] = (char *(*)()) F1228_8445;
}

char *(*R6203[134])();
void R6203_init () {
	R6203[0] = (char *(*)()) F1217_8353;
	R6203[1] = (char *(*)()) F1218_8353;
	R6203[12] = (char *(*)()) F1228_8446;
	R6203[13] = (char *(*)()) F1229_8446;
	R6203[14] = (char *(*)()) F1230_8446;
	R6203[15] = (char *(*)()) F1231_8446;
	R6203[16] = (char *(*)()) F1232_8446;
	{long i; for (i = 17; i < 19; i++) R6203[i] = (char *(*)()) F1228_8446;}
	R6203[133] = (char *(*)()) F1228_8446;
}

char *(*R6204[134])();
void R6204_init () {
	R6204[0] = (char *(*)()) F1217_8354;
	R6204[1] = (char *(*)()) F1218_8354;
	R6204[12] = (char *(*)()) F1228_8447;
	R6204[13] = (char *(*)()) F1229_8447;
	R6204[14] = (char *(*)()) F1230_8447;
	R6204[15] = (char *(*)()) F1231_8447;
	R6204[16] = (char *(*)()) F1232_8447;
	{long i; for (i = 17; i < 19; i++) R6204[i] = (char *(*)()) F1228_8447;}
	R6204[133] = (char *(*)()) F1228_8447;
}

char *(*R6205[134])();
void R6205_init () {
	R6205[0] = (char *(*)()) F1217_8355;
	R6205[1] = (char *(*)()) F1218_8355;
	R6205[12] = (char *(*)()) F1228_8448;
	R6205[13] = (char *(*)()) F1229_8448;
	R6205[14] = (char *(*)()) F1230_8448;
	R6205[15] = (char *(*)()) F1231_8448;
	R6205[16] = (char *(*)()) F1232_8448;
	{long i; for (i = 17; i < 19; i++) R6205[i] = (char *(*)()) F1228_8448;}
	R6205[133] = (char *(*)()) F1228_8448;
}

char *(*R6206[134])();
void R6206_init () {
	R6206[0] = (char *(*)()) F1219_8367;
	R6206[1] = (char *(*)()) F1220_8367;
	R6206[12] = (char *(*)()) F1228_8450;
	R6206[13] = (char *(*)()) F1229_8450;
	R6206[14] = (char *(*)()) F1230_8450;
	R6206[15] = (char *(*)()) F1231_8450;
	R6206[16] = (char *(*)()) F1232_8450;
	{long i; for (i = 17; i < 19; i++) R6206[i] = (char *(*)()) F1228_8450;}
	R6206[133] = (char *(*)()) F1228_8450;
}

char *(*R6207[134])();
void R6207_init () {
	R6207[0] = (char *(*)()) F1219_8368;
	R6207[1] = (char *(*)()) F1220_8368;
	R6207[12] = (char *(*)()) F1228_8451;
	R6207[13] = (char *(*)()) F1229_8451;
	R6207[14] = (char *(*)()) F1230_8451;
	R6207[15] = (char *(*)()) F1231_8451;
	R6207[16] = (char *(*)()) F1232_8451;
	{long i; for (i = 17; i < 19; i++) R6207[i] = (char *(*)()) F1228_8451;}
	R6207[133] = (char *(*)()) F1228_8451;
}

char *(*R6208[134])();
void R6208_init () {
	R6208[0] = (char *(*)()) F1219_8369;
	R6208[1] = (char *(*)()) F1220_8369;
	R6208[12] = (char *(*)()) F1228_8452;
	R6208[13] = (char *(*)()) F1229_8452;
	R6208[14] = (char *(*)()) F1230_8452;
	R6208[15] = (char *(*)()) F1231_8452;
	R6208[16] = (char *(*)()) F1232_8452;
	{long i; for (i = 17; i < 19; i++) R6208[i] = (char *(*)()) F1228_8452;}
	R6208[133] = (char *(*)()) F1228_8452;
}

char *(*R6209[134])();
void R6209_init () {
	R6209[0] = (char *(*)()) F1219_8370;
	R6209[1] = (char *(*)()) F1220_8370;
	R6209[12] = (char *(*)()) F1228_8453;
	R6209[13] = (char *(*)()) F1229_8453;
	R6209[14] = (char *(*)()) F1230_8453;
	R6209[15] = (char *(*)()) F1231_8453;
	R6209[16] = (char *(*)()) F1232_8453;
	{long i; for (i = 17; i < 19; i++) R6209[i] = (char *(*)()) F1228_8453;}
	R6209[133] = (char *(*)()) F1228_8453;
}

char *(*R6210[134])();
void R6210_init () {
	R6210[0] = (char *(*)()) F1219_8371;
	R6210[1] = (char *(*)()) F1220_8371;
	R6210[12] = (char *(*)()) F1228_8454;
	R6210[13] = (char *(*)()) F1229_8454;
	R6210[14] = (char *(*)()) F1230_8454;
	R6210[15] = (char *(*)()) F1231_8454;
	R6210[16] = (char *(*)()) F1232_8454;
	{long i; for (i = 17; i < 19; i++) R6210[i] = (char *(*)()) F1228_8454;}
	R6210[133] = (char *(*)()) F1228_8454;
}

char *(*R6211[134])();
void R6211_init () {
	R6211[0] = (char *(*)()) F1219_8373;
	R6211[1] = (char *(*)()) F1220_8373;
	R6211[12] = (char *(*)()) F1228_8456;
	R6211[13] = (char *(*)()) F1229_8456;
	R6211[14] = (char *(*)()) F1230_8456;
	R6211[15] = (char *(*)()) F1231_8456;
	R6211[16] = (char *(*)()) F1232_8456;
	{long i; for (i = 17; i < 19; i++) R6211[i] = (char *(*)()) F1228_8456;}
	R6211[133] = (char *(*)()) F1228_8456;
}

char *(*R6212[134])();
void R6212_init () {
	R6212[0] = (char *(*)()) F1219_8374;
	R6212[1] = (char *(*)()) F1220_8374;
	R6212[12] = (char *(*)()) F1228_8457;
	R6212[13] = (char *(*)()) F1229_8457;
	R6212[14] = (char *(*)()) F1230_8457;
	R6212[15] = (char *(*)()) F1231_8457;
	R6212[16] = (char *(*)()) F1232_8457;
	{long i; for (i = 17; i < 19; i++) R6212[i] = (char *(*)()) F1228_8457;}
	R6212[133] = (char *(*)()) F1228_8457;
}

char *(*R6213[134])();
void R6213_init () {
	R6213[0] = (char *(*)()) F1219_8375;
	R6213[1] = (char *(*)()) F1220_8375;
	R6213[12] = (char *(*)()) F1228_8458;
	R6213[13] = (char *(*)()) F1229_8458;
	R6213[14] = (char *(*)()) F1230_8458;
	R6213[15] = (char *(*)()) F1231_8458;
	R6213[16] = (char *(*)()) F1232_8458;
	{long i; for (i = 17; i < 19; i++) R6213[i] = (char *(*)()) F1228_8458;}
	R6213[133] = (char *(*)()) F1228_8458;
}

char *(*R6214[134])();
void R6214_init () {
	R6214[0] = (char *(*)()) F1219_8376;
	R6214[1] = (char *(*)()) F1220_8376;
	R6214[12] = (char *(*)()) F1228_8459;
	R6214[13] = (char *(*)()) F1229_8459;
	R6214[14] = (char *(*)()) F1230_8459;
	R6214[15] = (char *(*)()) F1231_8459;
	R6214[16] = (char *(*)()) F1232_8459;
	{long i; for (i = 17; i < 19; i++) R6214[i] = (char *(*)()) F1228_8459;}
	R6214[133] = (char *(*)()) F1228_8459;
}

char *(*R6215[134])();
void R6215_init () {
	R6215[0] = (char *(*)()) F1219_8377;
	R6215[1] = (char *(*)()) F1220_8377;
	R6215[12] = (char *(*)()) F1228_8460;
	R6215[13] = (char *(*)()) F1229_8460;
	R6215[14] = (char *(*)()) F1230_8460;
	R6215[15] = (char *(*)()) F1231_8460;
	R6215[16] = (char *(*)()) F1232_8460;
	{long i; for (i = 17; i < 19; i++) R6215[i] = (char *(*)()) F1228_8460;}
	R6215[133] = (char *(*)()) F1228_8460;
}

char *(*R6216[134])();
void R6216_init () {
	R6216[0] = (char *(*)()) F1219_8378;
	R6216[1] = (char *(*)()) F1220_8378;
	R6216[12] = (char *(*)()) F1228_8461;
	R6216[13] = (char *(*)()) F1229_8461;
	R6216[14] = (char *(*)()) F1230_8461;
	R6216[15] = (char *(*)()) F1231_8461;
	R6216[16] = (char *(*)()) F1232_8461;
	{long i; for (i = 17; i < 19; i++) R6216[i] = (char *(*)()) F1228_8461;}
	R6216[133] = (char *(*)()) F1228_8461;
}

char *(*R6226[134])();
void R6226_init () {
	R6226[0] = (char *(*)()) F1212_8303;
	R6226[1] = (char *(*)()) F1214_8303;
	R6226[12] = (char *(*)()) F1212_8303;
	R6226[13] = (char *(*)()) F1213_8303;
	R6226[14] = (char *(*)()) F1215_8303;
	R6226[15] = (char *(*)()) F1216_8303;
	R6226[16] = (char *(*)()) F1214_8303;
	{long i; for (i = 17; i < 19; i++) R6226[i] = (char *(*)()) F1212_8303;}
	R6226[133] = (char *(*)()) F1212_8303;
}

char *(*R6229[134])();
void R6229_init () {
	R6229[0] = (char *(*)()) F1212_8306;
	R6229[1] = (char *(*)()) F1214_8306;
	R6229[12] = (char *(*)()) F1212_8306;
	R6229[13] = (char *(*)()) F1213_8306;
	R6229[14] = (char *(*)()) F1215_8306;
	R6229[15] = (char *(*)()) F1216_8306;
	R6229[16] = (char *(*)()) F1214_8306;
	{long i; for (i = 17; i < 19; i++) R6229[i] = (char *(*)()) F1212_8306;}
	R6229[133] = (char *(*)()) F1212_8306;
}

char *(*R6230[134])();
void R6230_init () {
	R6230[0] = (char *(*)()) F1212_8321;
	R6230[1] = (char *(*)()) F1214_8321;
	R6230[12] = (char *(*)()) F1212_8321;
	R6230[13] = (char *(*)()) F1213_8321;
	R6230[14] = (char *(*)()) F1215_8321;
	R6230[15] = (char *(*)()) F1216_8321;
	R6230[16] = (char *(*)()) F1214_8321;
	{long i; for (i = 17; i < 19; i++) R6230[i] = (char *(*)()) F1212_8321;}
	R6230[133] = (char *(*)()) F1212_8321;
}

static EIF_TYPE_INDEX Y6234_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype26[] = {0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype27[] = {0xFF01,950,0xFFFF};
static EIF_TYPE_INDEX Y6234_pgtype28[] = {0xFF01,950,0xFFFF};
EIF_TYPE_INDEX *Y6234_gen_type [143];
EIF_TYPE_INDEX Y6234 [143];
void Y6234_init (void)
{
	egc_routines_types [6234] = Y6234;
	egc_routines_gen_types [6234] = Y6234_gen_type;
	egc_routines_offset [6234] = 1211;
	Y6234_gen_type [0] = Y6234_pgtype0;
	Y6234_gen_type [1] = Y6234_pgtype1;
	Y6234_gen_type [2] = Y6234_pgtype2;
	Y6234_gen_type [3] = Y6234_pgtype3;
	Y6234_gen_type [4] = Y6234_pgtype4;
	Y6234_gen_type [5] = Y6234_pgtype5;
	Y6234_gen_type [6] = Y6234_pgtype6;
	Y6234_gen_type [7] = Y6234_pgtype7;
	Y6234_gen_type [8] = Y6234_pgtype8;
	Y6234_gen_type [9] = Y6234_pgtype9;
	Y6234_gen_type [10] = Y6234_pgtype10;
	Y6234_gen_type [11] = Y6234_pgtype11;
	Y6234_gen_type [12] = Y6234_pgtype12;
	Y6234_gen_type [13] = Y6234_pgtype13;
	Y6234_gen_type [14] = Y6234_pgtype14;
	Y6234_gen_type [15] = Y6234_pgtype15;
	Y6234_gen_type [16] = Y6234_pgtype16;
	Y6234_gen_type [17] = Y6234_pgtype17;
	Y6234_gen_type [18] = Y6234_pgtype18;
	Y6234_gen_type [19] = Y6234_pgtype19;
	Y6234_gen_type [20] = Y6234_pgtype20;
	Y6234_gen_type [21] = Y6234_pgtype21;
	Y6234_gen_type [22] = Y6234_pgtype22;
	Y6234_gen_type [23] = Y6234_pgtype23;
	Y6234_gen_type [24] = Y6234_pgtype24;
	Y6234_gen_type [25] = Y6234_pgtype25;
	Y6234_gen_type [26] = Y6234_pgtype26;
	Y6234_gen_type [27] = Y6234_pgtype27;
	Y6234_gen_type [142] = Y6234_pgtype28;
	{long i; for (i = 26; i < 28; i++) Y6234[i] = 950;};
	Y6234[142] = 950;
}

char *(*R6240[2])();
void R6240_init () {
	R6240[0] = (char *(*)()) F1219_8381;
	R6240[1] = (char *(*)()) F1220_8381;
}

char *(*R6245[122])();
void R6245_init () {
	R6245[0] = (char *(*)()) F1223_8389;
	R6245[1] = (char *(*)()) F1224_8389;
	R6245[2] = (char *(*)()) F1225_8389;
	R6245[3] = (char *(*)()) F1226_8389;
	R6245[4] = (char *(*)()) F1227_8389;
	{long i; for (i = 5; i < 7; i++) R6245[i] = (char *(*)()) F1223_8389;}
	R6245[121] = (char *(*)()) F1223_8389;
}

char *(*R6248[122])();
void R6248_init () {
	R6248[0] = (char *(*)()) F1223_8392;
	R6248[1] = (char *(*)()) F1224_8392;
	R6248[2] = (char *(*)()) F1225_8392;
	R6248[3] = (char *(*)()) F1226_8392;
	R6248[4] = (char *(*)()) F1227_8392;
	{long i; for (i = 5; i < 7; i++) R6248[i] = (char *(*)()) F1223_8392;}
	R6248[121] = (char *(*)()) F1223_8392;
}

char *(*R6254[122])();
void R6254_init () {
	R6254[0] = (char *(*)()) F1223_8409;
	R6254[1] = (char *(*)()) F1224_8409;
	R6254[2] = (char *(*)()) F1225_8409_6254_4;
	R6254[3] = (char *(*)()) F1226_8409_6254_4;
	R6254[4] = (char *(*)()) F1227_8409_6254_4;
	{long i; for (i = 5; i < 7; i++) R6254[i] = (char *(*)()) F1223_8409;}
	R6254[121] = (char *(*)()) F1223_8409;
}
static void F1225_8409_6254_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1225_8409(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1226_8409_6254_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1226_8409(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F1227_8409_6254_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1227_8409(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R6270[122])();
void R6270_init () {
	R6270[0] = (char *(*)()) F1228_8465;
	R6270[1] = (char *(*)()) F1229_8465;
	R6270[2] = (char *(*)()) F1230_8465;
	R6270[3] = (char *(*)()) F1231_8465;
	R6270[4] = (char *(*)()) F1232_8465;
	{long i; for (i = 5; i < 7; i++) R6270[i] = (char *(*)()) F1228_8465;}
	R6270[121] = (char *(*)()) F1228_8465;
}

char *(*R6364[2])();
void R6364_init () {
	R6364[0] = (char *(*)()) F1247_8609;
	R6364[1] = (char *(*)()) F1248_8611;
}

char *(*R6365[2])();
void R6365_init () {
	R6365[0] = (char *(*)()) F1247_8610;
	R6365[1] = (char *(*)()) F1248_8612;
}

char *(*R6369[2])();
void R6369_init () {
	R6369[0] = (char *(*)()) F700_3941;
	R6369[1] = (char *(*)()) F699_3886;
}

char *(*R6376[2])();
void R6376_init () {
	R6376[0] = (char *(*)()) F1252_8642;
	R6376[1] = (char *(*)()) F1253_8645;
}

char *(*R6634[2])();
void R6634_init () {
	R6634[0] = (char *(*)()) F1271_8987;
	R6634[1] = (char *(*)()) F1272_9015;
}

char *(*R6642[2])();
void R6642_init () {
	R6642[0] = (char *(*)()) F1271_8993;
	R6642[1] = (char *(*)()) F1272_9021;
}

char *(*R6643[2])();
void R6643_init () {
	R6643[0] = (char *(*)()) F1271_8994;
	R6643[1] = (char *(*)()) F1272_9022;
}

char *(*R6644[2])();
void R6644_init () {
	R6644[0] = (char *(*)()) F1271_8995;
	R6644[1] = (char *(*)()) F1272_9023;
}

char *(*R6648[2])();
void R6648_init () {
	R6648[0] = (char *(*)()) F1271_8998;
	R6648[1] = (char *(*)()) F1272_9026;
}

char *(*R6649[2])();
void R6649_init () {
	R6649[0] = (char *(*)()) F1271_8999;
	R6649[1] = (char *(*)()) F1272_9027;
}

char *(*R6651[2])();
void R6651_init () {
	R6651[0] = (char *(*)()) F1271_9001;
	R6651[1] = (char *(*)()) F1272_9029;
}

char *(*R6654[2])();
void R6654_init () {
	R6654[0] = (char *(*)()) F1271_9004;
	R6654[1] = (char *(*)()) F1272_9032;
}

char *(*R6655[2])();
void R6655_init () {
	R6655[0] = (char *(*)()) F1271_9005;
	R6655[1] = (char *(*)()) F1272_9033;
}

char *(*R6659[2])();
void R6659_init () {
	R6659[0] = (char *(*)()) F1271_9008;
	R6659[1] = (char *(*)()) F1272_9036;
}

char *(*R6674[2])();
void R6674_init () {
	R6674[0] = (char *(*)()) F1274_9047;
	R6674[1] = (char *(*)()) F1275_9066;
}

char *(*R6693[8])();
void R6693_init () {
	{long i; for (i = 0; i < 3; i++) R6693[i] = (char *(*)()) F1277_9078;}
	R6693[4] = (char *(*)()) F1277_9078;
	R6693[6] = (char *(*)()) F1276_9067;
	R6693[7] = (char *(*)()) F1277_9078;
}

char *(*R6749[2])();
void R6749_init () {
	R6749[0] = (char *(*)()) F1286_9163;
	R6749[1] = (char *(*)()) F1287_9187;
}

char *(*R6820[143])();
void R6820_init () {
	R6820[0] = (char *(*)()) F1291_9250;
	R6820[142] = (char *(*)()) F1434_11283;
}

char *(*R6821[143])();
void R6821_init () {
	R6821[0] = (char *(*)()) F1291_9251;
	R6821[142] = (char *(*)()) F1434_11284;
}

char *(*R6827[143])();
void R6827_init () {
	R6827[0] = (char *(*)()) F1291_9252;
	R6827[142] = (char *(*)()) F1434_11285;
}

char *(*R7087[4])();
void R7087_init () {
	{long i; for (i = 0; i < 2; i++) R7087[i] = (char *(*)()) F1303_9518;}
	{long i; for (i = 2; i < 4; i++) R7087[i] = (char *(*)()) F1306_9632;}
}

char *(*R7088[4])();
void R7088_init () {
	{long i; for (i = 0; i < 2; i++) R7088[i] = (char *(*)()) F1303_9519;}
	{long i; for (i = 2; i < 4; i++) R7088[i] = (char *(*)()) F1306_9633;}
}

char *(*R7206[3])();
void R7206_init () {
	R7206[0] = (char *(*)()) F1310_9826;
	R7206[2] = (char *(*)()) F1312_9950;
}

char *(*R7207[3])();
void R7207_init () {
	R7207[0] = (char *(*)()) F1310_9827;
	R7207[2] = (char *(*)()) F1312_9951;
}

char *(*R7208[3])();
void R7208_init () {
	R7208[0] = (char *(*)()) F1310_9818;
	R7208[2] = (char *(*)()) F1312_9942;
}

char *(*R7209[3])();
void R7209_init () {
	R7209[0] = (char *(*)()) F1310_9819;
	R7209[2] = (char *(*)()) F1312_9943;
}

char *(*R7210[3])();
void R7210_init () {
	R7210[0] = (char *(*)()) F1310_9820;
	R7210[2] = (char *(*)()) F1312_9944;
}

char *(*R7211[3])();
void R7211_init () {
	R7211[0] = (char *(*)()) F1310_9821;
	R7211[2] = (char *(*)()) F1312_9945;
}

char *(*R7212[3])();
void R7212_init () {
	R7212[0] = (char *(*)()) F1310_9822;
	R7212[2] = (char *(*)()) F1312_9946;
}

char *(*R7213[3])();
void R7213_init () {
	R7213[0] = (char *(*)()) F1310_9823;
	R7213[2] = (char *(*)()) F1312_9947;
}

char *(*R7214[3])();
void R7214_init () {
	R7214[0] = (char *(*)()) F1310_9824;
	R7214[2] = (char *(*)()) F1312_9948;
}

char *(*R7237[3])();
void R7237_init () {
	R7237[0] = (char *(*)()) F1310_9860;
	R7237[2] = (char *(*)()) F1312_10027;
}

char *(*R7238[3])();
void R7238_init () {
	R7238[0] = (char *(*)()) F1310_9861;
	R7238[2] = (char *(*)()) F1312_10028;
}

char *(*R7239[3])();
void R7239_init () {
	R7239[0] = (char *(*)()) F1310_9862;
	R7239[2] = (char *(*)()) F1312_10029;
}

char *(*R7240[3])();
void R7240_init () {
	R7240[0] = (char *(*)()) F1310_9863;
	R7240[2] = (char *(*)()) F1312_10030;
}

char *(*R7241[3])();
void R7241_init () {
	R7241[0] = (char *(*)()) F1310_9864;
	R7241[2] = (char *(*)()) F1312_10031;
}

char *(*R7242[3])();
void R7242_init () {
	R7242[0] = (char *(*)()) F1310_9865;
	R7242[2] = (char *(*)()) F1312_10032;
}

char *(*R7558[29])();
void R7558_init () {
	R7558[0] = (char *(*)()) F1320_10096;
	R7558[4] = (char *(*)()) F1324_10108;
	R7558[7] = (char *(*)()) F1327_10117;
	R7558[8] = (char *(*)()) F1328_10120;
	R7558[9] = (char *(*)()) F1329_10123;
	R7558[15] = (char *(*)()) F1335_10141;
	R7558[16] = (char *(*)()) F1336_10144;
	R7558[17] = (char *(*)()) F1337_10147;
	R7558[18] = (char *(*)()) F1338_10150;
	R7558[19] = (char *(*)()) F1339_10153;
	R7558[26] = (char *(*)()) F1346_10174;
	R7558[27] = (char *(*)()) F1347_10182;
	R7558[28] = (char *(*)()) F1348_10197;
}

char *(*R7760[2])();
void R7760_init () {
	R7760[0] = (char *(*)()) F1359_10349;
	R7760[1] = (char *(*)()) F1358_10349;
}

char *(*R7761[2])();
void R7761_init () {
	R7761[0] = (char *(*)()) F1360_10357_7761_1;
	R7761[1] = (char *(*)()) F1361_10361;
}
static EIF_REFERENCE F1360_10357_7761_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1360_10357(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(903, 0x00).id, 903, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R7764[2])();
void R7764_init () {
	R7764[0] = (char *(*)()) F1359_10353;
	R7764[1] = (char *(*)()) F1358_10353;
}

char *(*R7780[68])();
void R7780_init () {
	{long i; for (i = 0; i < 4; i++) R7780[i] = (char *(*)()) F1362_10370;}
	{long i; for (i = 4; i < 11; i++) R7780[i] = (char *(*)()) F1367_10390;}
	{long i; for (i = 12; i < 32; i++) R7780[i] = (char *(*)()) F1367_10390;}
	{long i; for (i = 58; i < 65; i++) R7780[i] = (char *(*)()) F1367_10390;}
	R7780[65] = (char *(*)()) F1362_10370;
	{long i; for (i = 66; i < 68; i++) R7780[i] = (char *(*)()) F1367_10390;}
}

char *(*R7782[68])();
void R7782_init () {
	{long i; for (i = 0; i < 4; i++) R7782[i] = (char *(*)()) F1362_10372;}
	{long i; for (i = 4; i < 11; i++) R7782[i] = (char *(*)()) F1367_10392;}
	{long i; for (i = 12; i < 32; i++) R7782[i] = (char *(*)()) F1367_10392;}
	{long i; for (i = 58; i < 65; i++) R7782[i] = (char *(*)()) F1367_10392;}
	R7782[65] = (char *(*)()) F1362_10372;
	{long i; for (i = 66; i < 68; i++) R7782[i] = (char *(*)()) F1367_10392;}
}

char *(*R7825[53])();
void R7825_init () {
	R7825[0] = (char *(*)()) F1375_10431;
	R7825[1] = (char *(*)()) F1376_10436;
	R7825[2] = (char *(*)()) F1377_10443;
	R7825[3] = (char *(*)()) F1378_10451;
	R7825[4] = (char *(*)()) F1374_10420;
	R7825[5] = (char *(*)()) F1380_10462;
	R7825[6] = (char *(*)()) F1381_10478;
	R7825[7] = (char *(*)()) F1382_10489;
	R7825[8] = (char *(*)()) F1374_10420;
	R7825[9] = (char *(*)()) F1384_10508;
	R7825[10] = (char *(*)()) F1385_10512;
	R7825[11] = (char *(*)()) F1386_10517;
	R7825[12] = (char *(*)()) F1374_10420;
	R7825[13] = (char *(*)()) F1388_10526;
	R7825[14] = (char *(*)()) F1389_10540;
	R7825[15] = (char *(*)()) F1390_10562;
	R7825[16] = (char *(*)()) F1391_10572;
	R7825[17] = (char *(*)()) F1392_10584;
	R7825[18] = (char *(*)()) F1393_10593;
	R7825[19] = (char *(*)()) F1394_10597;
	R7825[49] = (char *(*)()) F1424_11046;
	R7825[50] = (char *(*)()) F1374_10420;
	R7825[51] = (char *(*)()) F1426_11060;
	R7825[52] = (char *(*)()) F1427_11066;
}

char *(*R7828[53])();
void R7828_init () {
	R7828[0] = (char *(*)()) F1375_10432;
	R7828[1] = (char *(*)()) F1376_10437;
	R7828[2] = (char *(*)()) F1377_10444;
	R7828[3] = (char *(*)()) F1378_10452;
	R7828[4] = (char *(*)()) F1379_10460;
	R7828[5] = (char *(*)()) F1380_10463;
	R7828[6] = (char *(*)()) F1381_10479;
	R7828[7] = (char *(*)()) F1382_10490;
	R7828[8] = (char *(*)()) F1383_10506;
	R7828[9] = (char *(*)()) F1384_10509;
	R7828[10] = (char *(*)()) F1385_10513;
	R7828[11] = (char *(*)()) F1386_10518;
	R7828[12] = (char *(*)()) F1387_10523;
	R7828[13] = (char *(*)()) F1388_10527;
	R7828[14] = (char *(*)()) F1389_10541;
	R7828[15] = (char *(*)()) F1390_10563;
	R7828[16] = (char *(*)()) F1391_10573;
	R7828[17] = (char *(*)()) F1392_10585;
	R7828[18] = (char *(*)()) F1393_10594;
	R7828[19] = (char *(*)()) F1394_10598;
	R7828[49] = (char *(*)()) F1424_11047;
	R7828[50] = (char *(*)()) F1425_11058;
	R7828[51] = (char *(*)()) F1426_11061;
	R7828[52] = (char *(*)()) F1427_11067;
}

char *(*R7962[25])();
void R7962_init () {
	{long i; for (i = 0; i < 16; i++) R7962[i] = (char *(*)()) F1395_10617;}
	R7962[16] = (char *(*)()) F1412_10871;
	{long i; for (i = 18; i < 25; i++) R7962[i] = (char *(*)()) F1395_10617;}
}

char *(*R8355[2])();
void R8355_init () {
	R8355[0] = (char *(*)()) F1429_11087;
	R8355[1] = (char *(*)()) F1430_11103;
}

char *(*R8359[2])();
void R8359_init () {
	R8359[0] = (char *(*)()) F1429_11091;
	R8359[1] = (char *(*)()) F1430_11110;
}

char *(*R8362[2])();
void R8362_init () {
	R8362[0] = (char *(*)()) F1429_11094;
	R8362[1] = (char *(*)()) F1430_11139;
}

char *(*R8363[2])();
void R8363_init () {
	R8363[0] = (char *(*)()) F1429_11095;
	R8363[1] = (char *(*)()) F1430_11140;
}

char *(*R8366[2])();
void R8366_init () {
	R8366[0] = (char *(*)()) F1429_11098;
	R8366[1] = (char *(*)()) F1430_11141;
}
char *(*R2[1437])();
void R2_init () {}
char *(*R6[1437])();
void R6_init () {}

char *(*R3[1437])();
void R3_init () {
	R3[253] = (char *(*)()) F254_2456;
	R3[294] = (char *(*)()) F295_2817;
	R3[698] = (char *(*)()) F306_3068;
	R3[1011] = (char *(*)()) F1012_6811;
	R3[1241] = (char *(*)()) F295_2817;
	{long i; for (i = 1246; i < 1248; i++) R3[i] = (char *(*)()) F306_3068;}
	{long i; for (i = 1251; i < 1253; i++) R3[i] = (char *(*)()) F306_3068;}
}

char *(*R4[1437])();
void R4_init () {
	R4[4] = (char *(*)()) F1_15;
	{long i; for (i = 6; i < 10; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 11; i < 14; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 21; i < 29; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 30; i < 32; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 34; i < 37; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 49; i < 52; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 56; i < 58; i++) R4[i] = (char *(*)()) F1_15;}
	R4[65] = (char *(*)()) F1_15;
	{long i; for (i = 69; i < 71; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 76; i < 79; i++) R4[i] = (char *(*)()) F1_15;}
	R4[83] = (char *(*)()) F1_15;
	R4[87] = (char *(*)()) F1_15;
	{long i; for (i = 98; i < 100; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 105; i < 111; i++) R4[i] = (char *(*)()) F1_15;}
	R4[123] = (char *(*)()) F1_15;
	{long i; for (i = 129; i < 140; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 155; i < 157; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 161; i < 163; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 164; i < 166; i++) R4[i] = (char *(*)()) F1_15;}
	R4[169] = (char *(*)()) F1_15;
	{long i; for (i = 174; i < 178; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 179; i < 181; i++) R4[i] = (char *(*)()) F1_15;}
	R4[189] = (char *(*)()) F1_15;
	R4[192] = (char *(*)()) F1_15;
	R4[194] = (char *(*)()) F1_15;
	{long i; for (i = 197; i < 199; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 208; i < 212; i++) R4[i] = (char *(*)()) F1_15;}
	R4[215] = (char *(*)()) F1_15;
	{long i; for (i = 217; i < 220; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 221; i < 223; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 225; i < 227; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 228; i < 231; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 232; i < 236; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 237; i < 239; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 240; i < 243; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 244; i < 250; i++) R4[i] = (char *(*)()) F1_15;}
	R4[253] = (char *(*)()) F254_2375;
	{long i; for (i = 254; i < 261; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 263; i < 265; i++) R4[i] = (char *(*)()) F1_15;}
	R4[274] = (char *(*)()) F1_15;
	{long i; for (i = 293; i < 295; i++) R4[i] = (char *(*)()) F1_15;}
	R4[295] = (char *(*)()) F296_2885;
	R4[297] = (char *(*)()) F1_15;
	R4[299] = (char *(*)()) F1_15;
	{long i; for (i = 302; i < 305; i++) R4[i] = (char *(*)()) F1_15;}
	R4[390] = (char *(*)()) F1_15;
	R4[393] = (char *(*)()) F1_15;
	{long i; for (i = 437; i < 442; i++) R4[i] = (char *(*)()) F1_15;}
	R4[634] = (char *(*)()) F1_15;
	R4[698] = (char *(*)()) F1_15;
	{long i; for (i = 712; i < 724; i++) R4[i] = (char *(*)()) F1_15;}
	R4[737] = (char *(*)()) F738_4111;
	R4[738] = (char *(*)()) F739_4111;
	R4[739] = (char *(*)()) F740_4111;
	R4[740] = (char *(*)()) F741_4111;
	R4[741] = (char *(*)()) F742_4111;
	R4[742] = (char *(*)()) F743_4111;
	R4[743] = (char *(*)()) F744_4111;
	R4[744] = (char *(*)()) F745_4111;
	R4[745] = (char *(*)()) F746_4111;
	R4[746] = (char *(*)()) F747_4111;
	R4[747] = (char *(*)()) F748_4111;
	R4[748] = (char *(*)()) F749_4111;
	R4[749] = (char *(*)()) F738_4111;
	R4[750] = (char *(*)()) F740_4111;
	R4[751] = (char *(*)()) F742_4111;
	R4[752] = (char *(*)()) F747_4111;
	R4[753] = (char *(*)()) F741_4111;
	R4[754] = (char *(*)()) F746_4111;
	R4[809] = (char *(*)()) F810_4320;
	R4[810] = (char *(*)()) F811_4320;
	R4[811] = (char *(*)()) F812_4320;
	R4[812] = (char *(*)()) F813_4320;
	R4[813] = (char *(*)()) F814_4320;
	R4[814] = (char *(*)()) F815_4320;
	R4[815] = (char *(*)()) F816_4320;
	R4[816] = (char *(*)()) F817_4320;
	R4[817] = (char *(*)()) F818_4320;
	R4[818] = (char *(*)()) F819_4320;
	R4[819] = (char *(*)()) F820_4320;
	R4[820] = (char *(*)()) F821_4320;
	R4[821] = (char *(*)()) F822_4392;
	R4[822] = (char *(*)()) F823_4392;
	R4[823] = (char *(*)()) F824_4392;
	R4[824] = (char *(*)()) F825_4392;
	R4[825] = (char *(*)()) F826_4392;
	R4[828] = (char *(*)()) F822_4392;
	R4[831] = (char *(*)()) F832_4487;
	R4[832] = (char *(*)()) F833_4540;
	{long i; for (i = 833; i < 865; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 866; i < 868; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 869; i < 871; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 872; i < 874; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 875; i < 877; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 878; i < 880; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 881; i < 883; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 884; i < 886; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 887; i < 889; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 890; i < 892; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 893; i < 895; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 896; i < 898; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 899; i < 901; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 902; i < 904; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 905; i < 937; i++) R4[i] = (char *(*)()) F1_15;}
	R4[938] = (char *(*)()) F938_5789;
	R4[939] = (char *(*)()) F940_5821;
	{long i; for (i = 940; i < 942; i++) R4[i] = (char *(*)()) F941_5821;}
	R4[946] = (char *(*)()) F947_6015;
	R4[947] = (char *(*)()) F946_5996;
	R4[949] = (char *(*)()) F950_6180;
	R4[950] = (char *(*)()) F949_6164;
	R4[953] = (char *(*)()) F1_15;
	{long i; for (i = 955; i < 964; i++) R4[i] = (char *(*)()) F1_15;}
	R4[971] = (char *(*)()) F1_15;
	R4[973] = (char *(*)()) F1_15;
	R4[978] = (char *(*)()) F1_15;
	{long i; for (i = 980; i < 982; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 983; i < 990; i++) R4[i] = (char *(*)()) F1_15;}
	R4[991] = (char *(*)()) F1_15;
	R4[993] = (char *(*)()) F1_15;
	{long i; for (i = 998; i < 1001; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1003; i < 1014; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1033] = (char *(*)()) F1_15;
	R4[1085] = (char *(*)()) F1039_7381;
	R4[1086] = (char *(*)()) F1040_7381;
	{long i; for (i = 1097; i < 1099; i++) R4[i] = (char *(*)()) F1039_7381;}
	R4[1099] = (char *(*)()) F1042_7381;
	R4[1100] = (char *(*)()) F1043_7381;
	R4[1101] = (char *(*)()) F1040_7381;
	R4[1105] = (char *(*)()) F1039_7381;
	R4[1106] = (char *(*)()) F1040_7381;
	R4[1107] = (char *(*)()) F1039_7381;
	R4[1108] = (char *(*)()) F1041_7381;
	R4[1109] = (char *(*)()) F1039_7381;
	R4[1111] = (char *(*)()) F1112_7514;
	{long i; for (i = 1113; i < 1115; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1116] = (char *(*)()) F1117_7563;
	R4[1119] = (char *(*)()) F1_15;
	{long i; for (i = 1121; i < 1124; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1184] = (char *(*)()) F1185_7927;
	R4[1185] = (char *(*)()) F1186_7927;
	{long i; for (i = 1186; i < 1189; i++) R4[i] = (char *(*)()) F1185_7927;}
	R4[1195] = (char *(*)()) F1196_8056;
	R4[1196] = (char *(*)()) F1197_8056;
	R4[1200] = (char *(*)()) F1201_8085;
	R4[1205] = (char *(*)()) F1206_8119;
	R4[1206] = (char *(*)()) F1207_8119;
	R4[1207] = (char *(*)()) F1208_8119;
	R4[1208] = (char *(*)()) F1209_8156;
	R4[1209] = (char *(*)()) F1210_8156;
	R4[1210] = (char *(*)()) F1209_8156;
	R4[1220] = (char *(*)()) F1212_8251;
	R4[1221] = (char *(*)()) F1214_8251;
	R4[1232] = (char *(*)()) F1223_8418;
	R4[1233] = (char *(*)()) F1224_8418;
	R4[1234] = (char *(*)()) F1225_8418;
	R4[1235] = (char *(*)()) F1226_8418;
	R4[1236] = (char *(*)()) F1227_8418;
	{long i; for (i = 1237; i < 1239; i++) R4[i] = (char *(*)()) F1223_8418;}
	{long i; for (i = 1240; i < 1242; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1243] = (char *(*)()) F1_15;
	{long i; for (i = 1246; i < 1248; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1251; i < 1253; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1256; i < 1261; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1270; i < 1272; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1273; i < 1275; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1279; i < 1282; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1283] = (char *(*)()) F1_15;
	{long i; for (i = 1285; i < 1287; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1292] = (char *(*)()) F1_15;
	{long i; for (i = 1294; i < 1298; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1303; i < 1307; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1309] = (char *(*)()) F1_15;
	{long i; for (i = 1311; i < 1314; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1319] = (char *(*)()) F1_15;
	R4[1323] = (char *(*)()) F1_15;
	{long i; for (i = 1326; i < 1329; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1334; i < 1339; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1345; i < 1348; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1349; i < 1353; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1353] = (char *(*)()) F1223_8418;
	{long i; for (i = 1354; i < 1357; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1359; i < 1361; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1362; i < 1373; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1374; i < 1394; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1395; i < 1412; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1413; i < 1430; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1431] = (char *(*)()) F1432_11186;
	R4[1434] = (char *(*)()) F1_15;
	{long i; for (i = 1435; i < 1437; i++) R4[i] = (char *(*)()) F1436_11407;}
}

char *(*R5[1437])();
void R5_init () {
	R5[4] = (char *(*)()) F1_8;
	{long i; for (i = 6; i < 10; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 11; i < 14; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 21; i < 29; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 30; i < 32; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 34; i < 37; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 49; i < 52; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 56; i < 58; i++) R5[i] = (char *(*)()) F1_8;}
	R5[65] = (char *(*)()) F1_8;
	{long i; for (i = 69; i < 71; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 76; i < 79; i++) R5[i] = (char *(*)()) F1_8;}
	R5[83] = (char *(*)()) F1_8;
	R5[87] = (char *(*)()) F1_8;
	{long i; for (i = 98; i < 100; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 105; i < 111; i++) R5[i] = (char *(*)()) F1_8;}
	R5[123] = (char *(*)()) F1_8;
	{long i; for (i = 129; i < 140; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 155; i < 157; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 161; i < 163; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 164; i < 166; i++) R5[i] = (char *(*)()) F1_8;}
	R5[169] = (char *(*)()) F1_8;
	R5[174] = (char *(*)()) F173_1926;
	{long i; for (i = 175; i < 178; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 179; i < 181; i++) R5[i] = (char *(*)()) F1_8;}
	R5[189] = (char *(*)()) F1_8;
	R5[192] = (char *(*)()) F1_8;
	R5[194] = (char *(*)()) F1_8;
	{long i; for (i = 197; i < 199; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 208; i < 212; i++) R5[i] = (char *(*)()) F1_8;}
	R5[215] = (char *(*)()) F1_8;
	{long i; for (i = 217; i < 220; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 221; i < 223; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 225; i < 227; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 228; i < 231; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 232; i < 236; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 237; i < 239; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 240; i < 243; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 244; i < 250; i++) R5[i] = (char *(*)()) F1_8;}
	R5[253] = (char *(*)()) F254_2374;
	{long i; for (i = 254; i < 261; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 263; i < 265; i++) R5[i] = (char *(*)()) F1_8;}
	R5[274] = (char *(*)()) F1_8;
	R5[293] = (char *(*)()) F294_2776;
	R5[294] = (char *(*)()) F1_8;
	R5[295] = (char *(*)()) F296_2884;
	R5[297] = (char *(*)()) F1_8;
	R5[299] = (char *(*)()) F1_8;
	{long i; for (i = 302; i < 305; i++) R5[i] = (char *(*)()) F1_8;}
	R5[390] = (char *(*)()) F1_8;
	R5[393] = (char *(*)()) F1_8;
	{long i; for (i = 437; i < 442; i++) R5[i] = (char *(*)()) F1_8;}
	R5[634] = (char *(*)()) F1_8;
	R5[698] = (char *(*)()) F1_8;
	{long i; for (i = 712; i < 724; i++) R5[i] = (char *(*)()) F1_8;}
	R5[737] = (char *(*)()) F738_4073;
	R5[738] = (char *(*)()) F739_4073;
	R5[739] = (char *(*)()) F740_4073;
	R5[740] = (char *(*)()) F741_4073;
	R5[741] = (char *(*)()) F742_4073;
	R5[742] = (char *(*)()) F743_4073;
	R5[743] = (char *(*)()) F744_4073;
	R5[744] = (char *(*)()) F745_4073;
	R5[745] = (char *(*)()) F746_4073;
	R5[746] = (char *(*)()) F747_4073;
	R5[747] = (char *(*)()) F748_4073;
	R5[748] = (char *(*)()) F749_4073;
	R5[749] = (char *(*)()) F738_4073;
	R5[750] = (char *(*)()) F740_4073;
	R5[751] = (char *(*)()) F742_4073;
	R5[752] = (char *(*)()) F747_4073;
	R5[753] = (char *(*)()) F741_4073;
	R5[754] = (char *(*)()) F746_4073;
	R5[809] = (char *(*)()) F810_4293;
	R5[810] = (char *(*)()) F811_4293;
	R5[811] = (char *(*)()) F812_4293;
	R5[812] = (char *(*)()) F813_4293;
	R5[813] = (char *(*)()) F814_4293;
	R5[814] = (char *(*)()) F815_4293;
	R5[815] = (char *(*)()) F816_4293;
	R5[816] = (char *(*)()) F817_4293;
	R5[817] = (char *(*)()) F818_4293;
	R5[818] = (char *(*)()) F819_4293;
	R5[819] = (char *(*)()) F820_4293;
	R5[820] = (char *(*)()) F821_4293;
	R5[821] = (char *(*)()) F822_4358;
	R5[822] = (char *(*)()) F823_4358;
	R5[823] = (char *(*)()) F824_4358;
	R5[824] = (char *(*)()) F825_4358;
	R5[825] = (char *(*)()) F826_4358;
	R5[828] = (char *(*)()) F822_4358;
	R5[831] = (char *(*)()) F832_4479;
	R5[832] = (char *(*)()) F833_4537;
	R5[833] = (char *(*)()) F834_4574;
	R5[834] = (char *(*)()) F835_4574;
	R5[835] = (char *(*)()) F836_4574;
	R5[836] = (char *(*)()) F837_4574;
	R5[837] = (char *(*)()) F838_4574;
	R5[838] = (char *(*)()) F839_4574;
	R5[839] = (char *(*)()) F840_4574;
	R5[840] = (char *(*)()) F841_4574;
	R5[841] = (char *(*)()) F842_4574;
	R5[842] = (char *(*)()) F843_4574;
	R5[843] = (char *(*)()) F844_4574;
	R5[844] = (char *(*)()) F845_4574;
	R5[845] = (char *(*)()) F846_4574;
	R5[846] = (char *(*)()) F847_4574;
	R5[847] = (char *(*)()) F848_4574;
	R5[848] = (char *(*)()) F849_4574;
	R5[849] = (char *(*)()) F850_4574;
	R5[850] = (char *(*)()) F851_4574;
	R5[851] = (char *(*)()) F852_4574;
	R5[852] = (char *(*)()) F853_4574;
	R5[853] = (char *(*)()) F854_4574;
	R5[854] = (char *(*)()) F855_4574;
	R5[855] = (char *(*)()) F856_4574;
	R5[856] = (char *(*)()) F857_4574;
	R5[857] = (char *(*)()) F858_4574;
	R5[858] = (char *(*)()) F859_4574;
	R5[859] = (char *(*)()) F860_4574;
	R5[860] = (char *(*)()) F861_4574;
	R5[861] = (char *(*)()) F862_4574;
	R5[862] = (char *(*)()) F863_4574;
	R5[863] = (char *(*)()) F864_4574;
	R5[864] = (char *(*)()) F865_4617;
	{long i; for (i = 866; i < 868; i++) R5[i] = (char *(*)()) F866_4735;}
	{long i; for (i = 869; i < 871; i++) R5[i] = (char *(*)()) F869_4834;}
	{long i; for (i = 872; i < 874; i++) R5[i] = (char *(*)()) F872_4932;}
	{long i; for (i = 875; i < 877; i++) R5[i] = (char *(*)()) F875_5031;}
	{long i; for (i = 878; i < 880; i++) R5[i] = (char *(*)()) F878_5130;}
	{long i; for (i = 881; i < 883; i++) R5[i] = (char *(*)()) F881_5224;}
	{long i; for (i = 884; i < 886; i++) R5[i] = (char *(*)()) F884_5318;}
	{long i; for (i = 887; i < 889; i++) R5[i] = (char *(*)()) F887_5413;}
	{long i; for (i = 890; i < 892; i++) R5[i] = (char *(*)()) F890_5512;}
	{long i; for (i = 893; i < 895; i++) R5[i] = (char *(*)()) F893_5578;}
	{long i; for (i = 896; i < 898; i++) R5[i] = (char *(*)()) F896_5639;}
	{long i; for (i = 899; i < 901; i++) R5[i] = (char *(*)()) F899_5679;}
	{long i; for (i = 902; i < 904; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 905; i < 937; i++) R5[i] = (char *(*)()) F905_5745;}
	R5[938] = (char *(*)()) F938_5782;
	R5[939] = (char *(*)()) F940_5820;
	{long i; for (i = 940; i < 942; i++) R5[i] = (char *(*)()) F941_5820;}
	{long i; for (i = 946; i < 948; i++) R5[i] = (char *(*)()) F946_5981;}
	{long i; for (i = 949; i < 951; i++) R5[i] = (char *(*)()) F949_6149;}
	R5[953] = (char *(*)()) F1_8;
	{long i; for (i = 955; i < 964; i++) R5[i] = (char *(*)()) F1_8;}
	R5[971] = (char *(*)()) F1_8;
	R5[973] = (char *(*)()) F1_8;
	R5[978] = (char *(*)()) F1_8;
	R5[980] = (char *(*)()) F1_8;
	R5[981] = (char *(*)()) F982_6643;
	R5[983] = (char *(*)()) F1_8;
	R5[984] = (char *(*)()) F985_6669;
	{long i; for (i = 985; i < 990; i++) R5[i] = (char *(*)()) F1_8;}
	R5[991] = (char *(*)()) F1_8;
	R5[993] = (char *(*)()) F1_8;
	{long i; for (i = 998; i < 1001; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1003; i < 1014; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1033] = (char *(*)()) F1_8;
	R5[1085] = (char *(*)()) F1039_7382;
	R5[1086] = (char *(*)()) F1040_7382;
	{long i; for (i = 1097; i < 1099; i++) R5[i] = (char *(*)()) F1039_7382;}
	R5[1099] = (char *(*)()) F1042_7382;
	R5[1100] = (char *(*)()) F1043_7382;
	R5[1101] = (char *(*)()) F1040_7382;
	R5[1105] = (char *(*)()) F1039_7382;
	R5[1106] = (char *(*)()) F1040_7382;
	R5[1107] = (char *(*)()) F1039_7382;
	R5[1108] = (char *(*)()) F1041_7382;
	R5[1109] = (char *(*)()) F1039_7382;
	R5[1111] = (char *(*)()) F1112_7515;
	R5[1113] = (char *(*)()) F1114_7527;
	R5[1114] = (char *(*)()) F1115_7547;
	R5[1116] = (char *(*)()) F1117_7564;
	R5[1119] = (char *(*)()) F1_8;
	{long i; for (i = 1121; i < 1124; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1184] = (char *(*)()) F1185_7928;
	R5[1185] = (char *(*)()) F1186_7928;
	{long i; for (i = 1186; i < 1189; i++) R5[i] = (char *(*)()) F1185_7928;}
	R5[1195] = (char *(*)()) F1196_8057;
	R5[1196] = (char *(*)()) F1197_8057;
	R5[1200] = (char *(*)()) F1201_8086;
	R5[1205] = (char *(*)()) F1206_8120;
	R5[1206] = (char *(*)()) F1207_8120;
	R5[1207] = (char *(*)()) F1208_8120;
	R5[1208] = (char *(*)()) F1209_8157;
	R5[1209] = (char *(*)()) F1210_8157;
	R5[1210] = (char *(*)()) F1209_8157;
	R5[1220] = (char *(*)()) F1217_8332;
	R5[1221] = (char *(*)()) F1218_8332;
	R5[1232] = (char *(*)()) F1223_8406;
	R5[1233] = (char *(*)()) F1224_8406;
	R5[1234] = (char *(*)()) F1225_8406;
	R5[1235] = (char *(*)()) F1226_8406;
	R5[1236] = (char *(*)()) F1227_8406;
	{long i; for (i = 1237; i < 1239; i++) R5[i] = (char *(*)()) F1223_8406;}
	R5[1240] = (char *(*)()) F1241_8484;
	R5[1241] = (char *(*)()) F1_8;
	R5[1243] = (char *(*)()) F1_8;
	{long i; for (i = 1246; i < 1248; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1251; i < 1253; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1256; i < 1261; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1270; i < 1272; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1273; i < 1275; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1279; i < 1282; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1283] = (char *(*)()) F1_8;
	{long i; for (i = 1285; i < 1287; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1292] = (char *(*)()) F1_8;
	{long i; for (i = 1294; i < 1298; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1303; i < 1307; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1309] = (char *(*)()) F1_8;
	{long i; for (i = 1311; i < 1314; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1319] = (char *(*)()) F1_8;
	R5[1323] = (char *(*)()) F1_8;
	{long i; for (i = 1326; i < 1329; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1334; i < 1339; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1345; i < 1348; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1349; i < 1353; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1353] = (char *(*)()) F1223_8406;
	{long i; for (i = 1354; i < 1357; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1359; i < 1361; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1362; i < 1373; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1374; i < 1394; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1395; i < 1412; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1413; i < 1430; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1431] = (char *(*)()) F1431_11167;
	R5[1434] = (char *(*)()) F1_8;
	{long i; for (i = 1435; i < 1437; i++) R5[i] = (char *(*)()) F1436_11364;}
}


#ifdef __cplusplus
}
#endif
