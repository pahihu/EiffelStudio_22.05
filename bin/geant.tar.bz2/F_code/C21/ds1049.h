
#ifndef _C21_ds1049_
#define _C21_ds1049_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1137_7704(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1049(void);
extern void F76_983(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
