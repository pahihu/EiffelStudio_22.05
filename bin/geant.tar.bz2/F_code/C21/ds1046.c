/*
 * Code for class DS_INDEXABLE_SORTER [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1046.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_INDEXABLE_SORTER}.make */
void F76_975 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {DS_INDEXABLE_SORTER}.sort */
void F76_983 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F76_985(Current, arg1, *(EIF_REFERENCE *)(Current));
}

/* {DS_INDEXABLE_SORTER}.sort_with_comparator */
void F76_985 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tb1 = F1126_7674(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_1_);
		F78_989(Current, arg1, arg2, ((EIF_INTEGER_32) 1L), ti4_1);
	}
	RTLE;
}

void EIF_Minit1046 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
