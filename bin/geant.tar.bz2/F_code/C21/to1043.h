
#ifndef _C21_to1043_
#define _C21_to1043_

#ifdef __cplusplus
extern "C" {
#endif

extern void F286_2751(EIF_REFERENCE, EIF_INTEGER_32);
extern void F286_2752(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern void F286_2758(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1043(void);
extern void F719_3970(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2478[];
extern EIF_TYPE_INDEX *Y2478_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
