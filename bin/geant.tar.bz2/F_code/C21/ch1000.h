
#ifndef _C21_ch1000_
#define _C21_ch1000_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F761_4124(EIF_REFERENCE);
extern void EIF_Minit1000(void);

#ifdef __cplusplus
}
#endif

#endif
