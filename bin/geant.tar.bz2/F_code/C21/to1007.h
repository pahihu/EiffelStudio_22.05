
#ifndef _C21_to1007_
#define _C21_to1007_

#ifdef __cplusplus
extern "C" {
#endif

extern void F285_2751(EIF_REFERENCE, EIF_INTEGER_32);
extern void F285_2752(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F285_2758(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1007(void);
extern void F718_3970(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2478[];
extern EIF_TYPE_INDEX *Y2478_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
