
#ifndef _C21_re1029_
#define _C21_re1029_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F668_3605(EIF_REFERENCE);
extern void EIF_Minit1029(void);
extern char *(*R3148[])();

#ifdef __cplusplus
}
#endif

#endif
