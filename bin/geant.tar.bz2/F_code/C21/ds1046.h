
#ifndef _C21_ds1046_
#define _C21_ds1046_

#ifdef __cplusplus
extern "C" {
#endif

extern void F76_975(EIF_REFERENCE, EIF_REFERENCE);
extern void F76_983(EIF_REFERENCE, EIF_REFERENCE);
extern void F76_985(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1046(void);
extern EIF_BOOLEAN F1126_7674(EIF_REFERENCE);
extern void F78_989(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
