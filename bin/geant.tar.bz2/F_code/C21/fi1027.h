
#ifndef _C21_fi1027_
#define _C21_fi1027_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F642_3592(EIF_REFERENCE);
extern void EIF_Minit1027(void);
extern char *(*R3145[])();

#ifdef __cplusplus
}
#endif

#endif
