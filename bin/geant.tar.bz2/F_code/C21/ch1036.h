
#ifndef _C21_ch1036_
#define _C21_ch1036_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F762_4124(EIF_REFERENCE);
extern void EIF_Minit1036(void);

#ifdef __cplusplus
}
#endif

#endif
