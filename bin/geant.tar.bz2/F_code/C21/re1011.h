
#ifndef _C21_re1011_
#define _C21_re1011_

#ifdef __cplusplus
extern "C" {
#endif

extern void F430_3407(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F430_3409(EIF_REFERENCE);
extern EIF_INTEGER_32 F430_3410(EIF_REFERENCE);
extern EIF_INTEGER_32 F430_3411(EIF_REFERENCE);
extern EIF_INTEGER_32 F430_3412(EIF_REFERENCE);
extern EIF_BOOLEAN F430_3420(EIF_REFERENCE);
extern EIF_BOOLEAN F430_3421(EIF_REFERENCE);
extern void F430_3426(EIF_REFERENCE);
extern void EIF_Minit1011(void);
extern char *(*R3356[])();
extern char *(*R3357[])();

#ifdef __cplusplus
}
#endif

#endif
