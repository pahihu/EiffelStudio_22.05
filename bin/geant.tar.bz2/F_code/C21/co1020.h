
#ifndef _C21_co1020_
#define _C21_co1020_

#ifdef __cplusplus
extern "C" {
#endif

extern void F499_3494(EIF_REFERENCE);
extern void EIF_Minit1020(void);
extern long O3083[];

#ifdef __cplusplus
}
#endif

#endif
