
#ifndef _C21_ds1047_
#define _C21_ds1047_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1180_7847(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit1047(void);
extern EIF_INTEGER_32 F1210_8147(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1210_8158(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
