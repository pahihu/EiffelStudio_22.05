/*
 * Code for class GEANT_SET_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge528.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_SET_TASK}.make */
void F1385_10512 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	F1374_10420(Current, arg1, arg2);
	tr1 = RTOSCF(10515,F1385_10515, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10515,F1385_10515, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1405_10765(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10516,F1385_10516, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10516,F1385_10516, (Current));
		loc1 = F1367_10390(Current, tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1405_10766(RTCW(tr1), loc1);
	}
	RTLE;
}

/* {GEANT_SET_TASK}.build_command */
void F1385_10513 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7829,Y7829_gen_type,Dftype(Current),1373).id);
	F1395_10615(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_SET_TASK}.name_attribute_name */
static EIF_REFERENCE F1385_10515_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10515);
#define Result RTOSR(10515)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("name",4,1851878757);
	RTOSE (10515);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1385_10515 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10515,F1385_10515_body,(Current));
}

/* {GEANT_SET_TASK}.value_attribute_name */
static EIF_REFERENCE F1385_10516_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10516);
#define Result RTOSR(10516)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("value",5,1635404133);
	RTOSE (10516);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1385_10516 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10516,F1385_10516_body,(Current));
}

void EIF_Minit528 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
