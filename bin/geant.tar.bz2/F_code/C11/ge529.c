/*
 * Code for class GEANT_LCC_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge529.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_LCC_TASK}.make */
void F1386_10517 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	F1374_10420(Current, arg1, arg2);
	tr1 = RTOSCF(10520,F1386_10520, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10520,F1386_10520, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1406_10771(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10521,F1386_10521, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10521,F1386_10521, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1406_10772(RTCW(tr1), loc1);
		}
	}
	RTLE;
}

/* {GEANT_LCC_TASK}.build_command */
void F1386_10518 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7829,Y7829_gen_type,Dftype(Current),1373).id);
	F1395_10615(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_LCC_TASK}.executable_attribute_name */
static EIF_REFERENCE F1386_10520_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10520);
#define Result RTOSR(10520)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("executable",10,1150568293);
	RTOSE (10520);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1386_10520 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10520,F1386_10520_body,(Current));
}

/* {GEANT_LCC_TASK}.source_filename_attribute_name */
static EIF_REFERENCE F1386_10521_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10521);
#define Result RTOSR(10521)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("sourcefilename",14,927409509);
	RTOSE (10521);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1386_10521 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10521,F1386_10521_body,(Current));
}

void EIF_Minit529 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
