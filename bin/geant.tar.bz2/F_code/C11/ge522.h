
#ifndef _C11_ge522_
#define _C11_ge522_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1379_10459(EIF_REFERENCE, EIF_REFERENCE);
extern void F1379_10460(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit522(void);
extern EIF_REFERENCE __A510_77();
extern void F1374_10421(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE _A510_77();
extern void F1398_10647(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1367_10390(EIF_REFERENCE, EIF_REFERENCE);
extern void F1358_10354(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_TYPE_INDEX Y7829[];
extern EIF_TYPE_INDEX *Y7829_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
