/*
 * Code for class GEANT_GEC_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge532.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_GEC_TASK}.make */
void F1389_10540 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	F1374_10420(Current, arg1, arg2);
	tr1 = RTOSCF(10543,F1389_10543, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10543,F1389_10543, (Current));
		tr2 = RTMS_EX_H("",0,0);
		loc1 = F1367_10391(Current, tr1, tr2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1409_10830(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10544,F1389_10544, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10544,F1389_10544, (Current));
		tr2 = RTMS_EX_H("",0,0);
		loc1 = F1367_10391(Current, tr1, tr2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1409_10830(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10548,F1389_10548, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10548,F1389_10548, (Current));
		tr2 = RTMS_EX_H("",0,0);
		loc1 = F1367_10391(Current, tr1, tr2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1409_10846(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10545,F1389_10545, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10545,F1389_10545, (Current));
		tr2 = RTMS_EX_H("",0,0);
		loc1 = F1367_10391(Current, tr1, tr2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1409_10831(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10546,F1389_10546, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10546,F1389_10546, (Current));
		loc1 = F1367_10390(Current, tr1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb2 = F641_3592(RTCW(loc1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1409_10832(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10550,F1389_10550, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10550,F1389_10550, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1409_10833(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10552,F1389_10552, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10552,F1389_10552, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1409_10834(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10547,F1389_10547, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10547,F1389_10547, (Current));
		loc1 = F1367_10390(Current, tr1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb2 = F641_3592(RTCW(loc1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1409_10835(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10553,F1389_10553, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10553,F1389_10553, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1409_10836(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10554,F1389_10554, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10554,F1389_10554, (Current));
		loc1 = F1367_10390(Current, tr1);
		tb1 = F943_5858(RTCW(loc1));
		if (tb1) {
			loc2 = F943_5892(RTCW(loc1));
			if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				F1409_10837(RTCW(tr1), loc2);
			}
		}
	}
	tr1 = RTOSCF(10551,F1389_10551, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10551,F1389_10551, (Current));
		loc1 = F1367_10390(Current, tr1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb2 = F641_3592(RTCW(loc1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1409_10838(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10555,F1389_10555, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10555,F1389_10555, (Current));
		loc1 = F1367_10390(Current, tr1);
		tb1 = F943_5858(RTCW(loc1));
		if (tb1) {
			loc2 = F943_5892(RTCW(loc1));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			ti4_1 = F943_5892(RTCW(loc1));
			F1409_10839(RTCW(tr1), ti4_1);
		}
	}
	tr1 = RTOSCF(10556,F1389_10556, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10556,F1389_10556, (Current));
		loc1 = F1367_10390(Current, tr1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb2 = F641_3592(RTCW(loc1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1409_10840(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10557,F1389_10557, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10557,F1389_10557, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1409_10841(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10558,F1389_10558, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10558,F1389_10558, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1409_10842(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10559,F1389_10559, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10559,F1389_10559, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1409_10843(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10560,F1389_10560, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10560,F1389_10560, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1409_10844(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10561,F1389_10561, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10561,F1389_10561, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1409_10845(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10549,F1389_10549, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10549,F1389_10549, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1409_10847(RTCW(tr1), loc1);
		}
	}
	RTLE;
}

/* {GEANT_GEC_TASK}.build_command */
void F1389_10541 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7829,Y7829_gen_type,Dftype(Current),1373).id);
	F1409_10808(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_GEC_TASK}.ace_attribute_name */
static EIF_REFERENCE F1389_10543_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10543);
#define Result RTOSR(10543)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("ace",3,6382437);
	RTOSE (10543);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10543 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10543,F1389_10543_body,(Current));
}

/* {GEANT_GEC_TASK}.ecf_attribute_name */
static EIF_REFERENCE F1389_10544_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10544);
#define Result RTOSR(10544)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("ecf",3,6644582);
	RTOSE (10544);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10544 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10544,F1389_10544_body,(Current));
}

/* {GEANT_GEC_TASK}.target_attribute_name */
static EIF_REFERENCE F1389_10545_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10545);
#define Result RTOSR(10545)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("target",6,709236);
	RTOSE (10545);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10545 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10545,F1389_10545_body,(Current));
}

/* {GEANT_GEC_TASK}.c_compile_attribute_name */
static EIF_REFERENCE F1389_10546_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10546);
#define Result RTOSR(10546)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("c_compile",9,1960031333);
	RTOSE (10546);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10546 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10546,F1389_10546_body,(Current));
}

/* {GEANT_GEC_TASK}.catcall_attribute_name */
static EIF_REFERENCE F1389_10547_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10547);
#define Result RTOSR(10547)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("catcall",7,147745900);
	RTOSE (10547);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10547 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10547,F1389_10547_body,(Current));
}

/* {GEANT_GEC_TASK}.clean_attribute_name */
static EIF_REFERENCE F1389_10548_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10548);
#define Result RTOSR(10548)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("clean",5,1819343726);
	RTOSE (10548);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10548 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10548,F1389_10548_body,(Current));
}

/* {GEANT_GEC_TASK}.exit_code_variable_attribute_name */
static EIF_REFERENCE F1389_10549_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10549);
#define Result RTOSR(10549)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("exit_code_variable",18,2096751205);
	RTOSE (10549);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10549 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10549,F1389_10549_body,(Current));
}

/* {GEANT_GEC_TASK}.finalize_attribute_name */
static EIF_REFERENCE F1389_10550_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10550);
#define Result RTOSR(10550)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("finalize",8,1220601701);
	RTOSE (10550);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10550 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10550,F1389_10550_body,(Current));
}

/* {GEANT_GEC_TASK}.gc_attribute_name */
static EIF_REFERENCE F1389_10551_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10551);
#define Result RTOSR(10551)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("gc",2,26467);
	RTOSE (10551);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10551 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10551,F1389_10551_body,(Current));
}

/* {GEANT_GEC_TASK}.gelint_attribute_name */
static EIF_REFERENCE F1389_10552_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10552);
#define Result RTOSR(10552)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("gelint",6,2022130804);
	RTOSE (10552);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10552 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10552,F1389_10552_body,(Current));
}

/* {GEANT_GEC_TASK}.split_attribute_name */
static EIF_REFERENCE F1389_10553_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10553);
#define Result RTOSR(10553)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("split",5,1887036276);
	RTOSE (10553);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10553 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10553,F1389_10553_body,(Current));
}

/* {GEANT_GEC_TASK}.split_size_attribute_name */
static EIF_REFERENCE F1389_10554_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10554);
#define Result RTOSR(10554)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("split_size",10,645486437);
	RTOSE (10554);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10554 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10554,F1389_10554_body,(Current));
}

/* {GEANT_GEC_TASK}.thread_attribute_name */
static EIF_REFERENCE F1389_10555_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10555);
#define Result RTOSR(10555)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("thread",6,630884);
	RTOSE (10555);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10555 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10555,F1389_10555_body,(Current));
}

/* {GEANT_GEC_TASK}.new_instance_types_attribute_name */
static EIF_REFERENCE F1389_10556_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10556);
#define Result RTOSR(10556)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("new_instance_types",18,2082470259);
	RTOSE (10556);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10556 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10556,F1389_10556_body,(Current));
}

/* {GEANT_GEC_TASK}.silent_attribute_name */
static EIF_REFERENCE F1389_10557_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10557);
#define Result RTOSR(10557)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("silent",6,2045492340);
	RTOSE (10557);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10557 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10557,F1389_10557_body,(Current));
}

/* {GEANT_GEC_TASK}.verbose_attribute_name */
static EIF_REFERENCE F1389_10558_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10558);
#define Result RTOSR(10558)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("verbose",7,1112830821);
	RTOSE (10558);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10558 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10558,F1389_10558_body,(Current));
}

/* {GEANT_GEC_TASK}.no_benchmark_attribute_name */
static EIF_REFERENCE F1389_10559_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10559);
#define Result RTOSR(10559)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("no_benchmark",12,845933163);
	RTOSE (10559);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10559 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10559,F1389_10559_body,(Current));
}

/* {GEANT_GEC_TASK}.nested_benchmark_attribute_name */
static EIF_REFERENCE F1389_10560_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10560);
#define Result RTOSR(10560)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("nested_benchmark",16,1037433451);
	RTOSE (10560);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10560 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10560,F1389_10560_body,(Current));
}

/* {GEANT_GEC_TASK}.metrics_attribute_name */
static EIF_REFERENCE F1389_10561_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10561);
#define Result RTOSR(10561)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("metrics",7,1145995635);
	RTOSE (10561);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1389_10561 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10561,F1389_10561_body,(Current));
}

void EIF_Minit532 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
