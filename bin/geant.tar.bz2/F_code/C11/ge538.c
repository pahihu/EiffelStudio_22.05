/*
 * Code for class GEANT_COMMAND
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge538.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_COMMAND}.make */
void F1395_10615 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1395_10620(Current, arg1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,129,938,0xFF01,0xFFF9,0,864,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F130_1565(RTCW(tr1), NULL);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_COMMAND}.is_exit_command */
EIF_BOOLEAN F1395_10617 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {GEANT_COMMAND}.set_project */
void F1395_10620 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {GEANT_COMMAND}.validate_condition */
void F1395_10622 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg3)+ _CHROFF_0_0_);
	if (tb1) {
		if ((EIF_BOOLEAN) !arg1) {
			F131_1564(RTCW(arg3), (EIF_BOOLEAN) 0);
			tr1 = RTOSCF(10207,F1349_10207, (Current));
			F1209_8165(RTCW(tr1), arg2);
		}
	}
	RTLE;
}

/* {GEANT_COMMAND}.execute_shell */
void F1395_10623 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_2_);
	if ((EIF_BOOLEAN) !tb1) {
		loc1 = RTLNS(eif_new_type(991, 0x01).id, 991, _OBJSIZ_2_1_0_2_0_0_0_0_);
		F991_6709(RTCW(loc1), arg1);
		F991_6713(RTCW(loc1));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_1_0_1_);
		*(EIF_INTEGER_32 *)(Current + O7961[Dtype(Current)-1394]) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

void EIF_Minit538 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
