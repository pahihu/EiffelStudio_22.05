/*
 * Code for class GEANT_PROJECT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge501.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_PROJECT}.make */
void F1356_10285 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg3;
	tr1 = RTOSCF(1120,F100_1120, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	F1356_10310(Current, arg1);
	F1356_10311(Current, arg2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1232,0xFF01,1429,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1223_8389(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	loc1 = RTLNS(eif_new_type(989, 0x01).id, 989, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1223_8407(RTCW(tr1), loc1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1205,0xFF01,1429,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 1205, _OBJSIZ_3_0_0_2_0_0_0_0_);
	}
	F1206_8109(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1260, 0).id);
	F1261_8763(RTCW(tr1), Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {GEANT_PROJECT}.aggregated_variables_array */
EIF_REFERENCE F1356_10290 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,1237,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 3L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTOSCF(10208,F1349_10208, (Current));
	tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6122[Dtype(RTCW(tr3))-1195])(tr3);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTOSCF(10209,F1349_10209, (Current));
	tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6122[Dtype(RTCW(tr3))-1195])(tr3);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

/* {GEANT_PROJECT}.preferred_start_target */
EIF_REFERENCE F1356_10294 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tb1 = F1223_8402(loc2, loc1);
			if (tb1) {
				tr1 = F1223_8394(loc2, loc1);
				RTLE;
				return (EIF_REFERENCE) tr1;
			}
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {GEANT_PROJECT}.default_target */
EIF_REFERENCE F1356_10295 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tb1 = F1223_8402(loc2, loc1);
			if (tb1) {
				tr1 = F1223_8394(loc2, loc1);
				RTLE;
				return (EIF_REFERENCE) tr1;
			}
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {GEANT_PROJECT}.start_target */
EIF_REFERENCE F1356_10296 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	Result = F1356_10295(Current);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		tr1 = F1356_10294(Current);
		loc2 = tr1;
		if ((EIF_BOOLEAN) !EIF_TEST(loc2)) {
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr2) = 2L;
				memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
			}
			tr3 = RTMS_EX_H("Cannot determine start target `",31,695422560);
			*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = RTMS_EX_H("\'",1,39);
			tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4764[Dtype(loc1)-950])(loc1, tr3);
			*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
			F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
		} else {
			Result = (EIF_REFERENCE) loc2;
		}
	}
	if ((EIF_BOOLEAN)(Result == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr2) = 1L;
			memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
		}
		tr3 = RTMS_EX_H("Cannot determine start target.",30,2032756014);
		*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
		RTAR(tr2,tr3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
		F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
		RTCT0("exited", EX_CHECK);
			RTCF0;
	}
	RTLE;
	return Result;
}

/* {GEANT_PROJECT}.target_name */
EIF_REFERENCE F1356_10300 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc1);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	RTCT0("precondition", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = RTMS_EX_H("",0,0);
	loc1 = F1233_8466(loc3);
	F1053_7395(RTCW(loc1));
	for (;;) {
		tb1 = F1077_7423(RTCW(loc1));
		if (tb1) break;
		tr1 = F1039_7375(RTCW(loc1));
		if ((EIF_BOOLEAN)(arg1 == tr1)) {
			Result = F1088_7442(RTCW(loc1));
			F1053_7398(RTCW(loc1));
		} else {
			F1053_7396(RTCW(loc1));
		}
	}
	RTLE;
	return Result;
}

/* {GEANT_PROJECT}.has_parent_with_name */
EIF_BOOLEAN F1356_10303 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		loc4 = *(EIF_REFERENCE *)(loc5 + _REFACS_1_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_4_0_0_1_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = F1209_8147(RTCW(loc4), loc1);
			loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				tr1 = RTOSCF(6466,F971_6466, (Current));
				tr2 = *(EIF_REFERENCE *)(RTCW(loc3));
				tb1 = F958_6409(RTCW(tr1), tr2, arg1);
				if (tb1) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				} else {
					tb1 = F1356_10303(RTCW(loc3), arg1);
					if (tb1) {
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					}
				}
			}
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {GEANT_PROJECT}.set_description */
void F1356_10305 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_PROJECT}.set_start_target_name */
void F1356_10307 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_PROJECT}.set_default_target_name */
void F1356_10308 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_PROJECT}.set_targets */
void F1356_10309 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_PROJECT}.set_variables */
void F1356_10310 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_PROJECT}.set_options */
void F1356_10311 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_PROJECT}.set_inherit_clause */
void F1356_10312 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_PROJECT}.set_old_inherit */
void F1356_10313 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_1_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT_PROJECT}.set_position_table */
void F1356_10314 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_PROJECT}.new_task */
EIF_REFERENCE F1356_10315 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1261_8765(loc1, arg1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {GEANT_PROJECT}.merge_in_parent_projects */
void F1356_10317 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,loc6);
	RTLR(6,loc4);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,loc3);
	RTLIU(10);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		tr1 = *(EIF_REFERENCE *)(loc5 + _REFACS_1_);
		loc2 = F1209_8150(RTCW(tr1));
		F1053_7395(RTCW(loc2));
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2921[Dtype(RTCW(loc2))-437])(loc2);
			if (tb1) break;
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2920[Dtype(RTCW(loc2))-437])(loc2);
			F1353_10267(RTCW(loc1));
			F1053_7396(RTCW(loc2));
		}
		tr1 = *(EIF_REFERENCE *)(loc5 + _REFACS_1_);
		loc2 = F1209_8150(RTCW(tr1));
		F1053_7395(RTCW(loc2));
		for (;;) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2921[Dtype(RTCW(loc2))-437])(loc2);
			if (tb2) break;
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2920[Dtype(RTCW(loc2))-437])(loc2);
			F1352_10249(loc5, loc1);
			F1053_7396(RTCW(loc2));
		}
		F1352_10245(loc5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			loc4 = F1233_8466(loc6);
			F1053_7395(RTCW(loc4));
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr2) = 3L;
				memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
			}
			tr3 = RTMS_EX_H("Project \'",9,213807399);
			*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = *(EIF_REFERENCE *)(Current);
			*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = RTMS_EX_H("\': target list:",15,6029370);
			*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
			F1356_10325(Current, tr1);
			for (;;) {
				tb3 = F1077_7423(RTCW(loc4));
				if (tb3) break;
				loc3 = F1039_7375(RTCW(loc4));
				{
					static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
					RT_SPECIAL_COUNT(tr2) = 5L;
					memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
				}
				tr3 = RTMS_EX_H("  target `",10,1124243808);
				*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = F1088_7442(RTCW(loc4));
				*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = RTMS_EX_H("\' (",3,2564136);
				*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = F1430_11111(RTCW(loc3));
				*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = RTMS_EX_H(")",1,41);
				*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
				F1356_10325(Current, tr1);
				F1430_11138(RTCW(loc3));
				F1053_7396(RTCW(loc4));
			}
		}
	}
	RTLE;
}

/* {GEANT_PROJECT}.calculate_depend_order */
void F1356_10318 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	loc1 = F1206_8114(RTCW(arg1));
	{
		static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 2L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS_EX_H("pushing target: ",16,1463922976);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_5_);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
	F1356_10325(Current, tr1);
	loc2 = F1430_11142(RTCW(loc1));
	for (;;) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_3_0_0_1_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) break;
		tr1 = F1206_8114(RTCW(loc2));
		F1206_8122(RTCW(arg1), tr1);
		F1206_8126(RTCW(loc2));
		F1356_10318(Current, arg1);
	}
	RTLE;
}

/* {GEANT_PROJECT}.build */
void F1356_10319 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,loc1);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 1L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS_EX_H("Building Project",16,591143540);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
	F1356_10323(Current, tr1);
	loc1 = F1356_10296(Current);
	F1356_10321(Current, loc1, arg1);
	RTLE;
}

/* {GEANT_PROJECT}.show_target_info */
void F1356_10320 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLR(6,loc4);
	RTLR(7,tr3);
	RTLIU(8);
	
	RTGC;
	RTCT0("precondition", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc1 = F1233_8466(loc3);
	F1053_7395(RTCW(loc1));
	for (;;) {
		tb1 = F1077_7423(RTCW(loc1));
		if (tb1) break;
		loc2 = F1039_7375(RTCW(loc1));
		tb2 = F1430_11123(RTCW(loc2));
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
			tr2 = F1430_11111(RTCW(loc2));
			F998_6740(RTCW(tr1), tr2);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_6_);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
				tr2 = RTMS_EX_H("  obsolete. ",12,1435847712);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4764[Dtype(tr2)-950])(tr2, loc4);
				F998_6740(RTCW(tr1), tr2);
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
			tr2 = RTMS_EX_H("  ",2,8224);
			tr3 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_3_);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4764[Dtype(tr2)-950])(tr2, tr3);
			F998_6740(RTCW(tr1), tr2);
		}
		F1053_7396(RTCW(loc1));
	}
	RTLE;
}

/* {GEANT_PROJECT}.build_target */
void F1356_10321 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(10208,F1349_10208, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(tr1))-1184])(tr1, arg2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1205,0xFF01,1429,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 1205, _OBJSIZ_3_0_0_2_0_0_0_0_);
	}
	F1206_8109(RTCW(loc1), ((EIF_INTEGER_32) 10L));
	F1206_8122(RTCW(loc1), arg1);
	F1356_10318(Current, loc1);
	loc2 = RTLNS(eif_new_type(1238, 0x01).id, 1238, _OBJSIZ_11_0_0_9_0_0_0_0_);
	F1238_8470(RTCW(loc2));
	tr1 = RTOSCF(10208,F1349_10208, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(tr1))-1184])(tr1, loc2);
	for (;;) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_3_0_0_1_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) break;
		tr1 = F1206_8114(RTCW(loc1));
		F1356_10322(Current, tr1, loc2, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 1);
		F1206_8126(RTCW(loc1));
	}
	tr1 = RTOSCF(10208,F1349_10208, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6123[Dtype(RTCW(tr1))-1195])(tr1);
	F1356_10322(Current, arg1, arg2, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 1);
	tr1 = RTOSCF(10208,F1349_10208, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6123[Dtype(RTCW(tr1))-1195])(tr1);
	RTLE;
}

/* {GEANT_PROJECT}.execute_target */
void F1356_10322 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLR(7,arg2);
	RTLIU(8);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 5L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = RTMS_EX_H("project \'",9,2101244199);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = *(EIF_REFERENCE *)(Current);
	*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("\': executing target `",21,1756461408);
	*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = F1430_11111(RTCW(arg1));
	*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr3 = RTMS_EX_H("\'",1,39);
	*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
	F1356_10325(Current, tr1);
	loc1 = F1356_10332(Current);
	tb1 = '\01';
	if (!arg3) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_13_0_);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		if (arg4) {
			loc2 = F1430_11115(RTCW(arg1));
		} else {
			loc2 = (EIF_REFERENCE) arg1;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(tr1))-1184])(tr1, loc2);
		tr1 = RTOSCF(10209,F1349_10209, (Current));
		tr2 = RTLNS(eif_new_type(1237, 0x01).id, 1237, _OBJSIZ_11_0_0_9_0_0_0_0_);
		F1238_8470(RTCW(tr2));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(tr1))-1184])(tr1, tr2);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_2_);
		if ((EIF_BOOLEAN)(tr1 != Current)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_2_);
			F1356_10322(RTCW(tr1), loc2, arg2, arg3, arg4);
		} else {
			tr1 = RTOSCF(10208,F1349_10208, (Current));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(tr1))-1184])(tr1, arg2);
			F1430_11139(RTCW(loc2));
			tr1 = RTOSCF(10208,F1349_10208, (Current));
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R6123[Dtype(RTCW(tr1))-1195])(tr1);
		}
		tr1 = RTOSCF(10209,F1349_10209, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6123[Dtype(RTCW(tr1))-1195])(tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6123[Dtype(RTCW(tr1))-1195])(tr1);
	}
	RTLE;
}

/* {GEANT_PROJECT}.trace */
void F1356_10323 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_0_);
	if (tb1) {
		loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_1_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_0_);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
			tr2 = F738_4063(RTCW(arg1), loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5171[Dtype(RTCW(tr1))-998])(tr1, tr2);
			loc1++;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		F998_6741(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5183[Dtype(RTCW(tr1))-998])(tr1);
	}
	RTLE;
}

/* {GEANT_PROJECT}.log */
void F1356_10324 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_1_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_0_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		tr2 = F738_4063(RTCW(arg1), loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5171[Dtype(RTCW(tr1))-998])(tr1, tr2);
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	F998_6741(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5183[Dtype(RTCW(tr1))-998])(tr1);
	RTLE;
}

/* {GEANT_PROJECT}.trace_debug */
void F1356_10325 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_1_);
	if (tb1) {
		loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_1_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_0_);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
			tr2 = F738_4063(RTCW(arg1), loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5171[Dtype(RTCW(tr1))-998])(tr1, tr2);
			loc1++;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		F998_6741(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5183[Dtype(RTCW(tr1))-998])(tr1);
	}
	RTLE;
}

/* {GEANT_PROJECT}.set_variable_value */
void F1356_10328 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	if (F1356_10330(Current, arg1)) {
		tr1 = RTOSCF(10209,F1349_10209, (Current));
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6122[Dtype(RTCW(tr1))-1195])(tr1);
	} else {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	}
	F1238_8472(RTCW(loc1), arg1, arg2);
	RTLE;
}

/* {GEANT_PROJECT}.unset_variable */
void F1356_10329 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if (F1356_10330(Current, arg1)) {
		tr1 = RTOSCF(10209,F1349_10209, (Current));
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6122[Dtype(RTCW(tr1))-1195])(tr1);
		tb1 = F1223_8402(RTCW(loc1), arg1);
		if (tb1) {
			tr1 = RTLNS(eif_new_type(950, 0x01).id, 950, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F943_5827(RTCW(tr1));
			F1223_8408(RTCW(loc1), tr1, arg1);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1212_8252(RTCW(tr1), arg1);
	}
	RTLE;
}

/* {GEANT_PROJECT}.is_local_variable */
EIF_BOOLEAN F1356_10330 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = F1356_10332(Current);
	loc1 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_3_);
	} else {
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_11_);
		tb1 = F1223_8402(RTCW(tr1), arg1);
		if (tb1) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_12_);
			tb1 = F1223_8402(RTCW(tr1), arg1);
			if (tb1) {
				RTLE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_3_);
			}
		}
	}
	RTLE;
	return Result;
}

/* {GEANT_PROJECT}.current_target */
EIF_REFERENCE F1356_10332 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	tb1 = F1125_7674(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6122[Dtype(RTCW(tr1))-1195])(tr1);
	}
	RTLE;
	return Result;
}

void EIF_Minit501 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
