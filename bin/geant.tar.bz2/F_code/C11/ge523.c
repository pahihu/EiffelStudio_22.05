/*
 * Code for class GEANT_GETEST_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge523.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_GETEST_TASK}.make */
void F1380_10462 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	RTLD;
	
	RTLI(12);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,loc7);
	RTLR(7,loc3);
	RTLR(8,loc6);
	RTLR(9,loc1);
	RTLR(10,loc5);
	RTLR(11,loc4);
	RTLIU(12);
	
	RTGC;
	F1374_10420(Current, arg1, arg2);
	tr1 = RTOSCF(10465,F1380_10465, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10465,F1380_10465, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1400_10691(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10466,F1380_10466, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10466,F1380_10466, (Current));
		loc2 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1400_10692(RTCW(tr1), loc2);
		}
	}
	tr1 = RTOSCF(10467,F1380_10467, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10467,F1380_10467, (Current));
		loc2 = F1367_10390(Current, tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1400_10693(RTCW(tr1), loc2);
	}
	tr1 = RTOSCF(10468,F1380_10468, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10468,F1380_10468, (Current));
		loc2 = F1367_10390(Current, tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1400_10694(RTCW(tr1), loc2);
	}
	tr1 = RTOSCF(10469,F1380_10469, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10469,F1380_10469, (Current));
		loc2 = F1367_10390(Current, tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1400_10695(RTCW(tr1), loc2);
	}
	tr1 = RTOSCF(10470,F1380_10470, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10470,F1380_10470, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1400_10696(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10471,F1380_10471, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10471,F1380_10471, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1400_10697(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10472,F1380_10472, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10472,F1380_10472, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1400_10698(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10473,F1380_10473, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10473,F1380_10473, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1400_10699(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10474,F1380_10474, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10474,F1380_10474, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1400_10700(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10475,F1380_10475, (Current));
	loc7 = F1362_10365(Current, tr1);
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5961[Dtype(RTCW(loc7))-1184])(loc7);
	F1053_7395(RTCW(loc3));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
		if (tb1) break;
		loc6 = RTLNS(eif_new_type(1372, 0x01).id, 1372, _OBJSIZ_3_0_0_0_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = F1108_7483(RTCW(loc3));
		F1367_10386(RTCW(loc6), tr1, tr2);
		tb2 = '\0';
		tb3 = '\0';
		tb4 = F1367_10388(RTCW(loc6));
		if (tb4) {
			tb4 = F1363_10382(RTCW(loc6));
			tb3 = tb4;
		}
		if (tb3) {
			tb3 = F1363_10383(RTCW(loc6));
			tb2 = tb3;
		}
		if (tb2) {
			loc1 = F1363_10380(RTCW(loc6));
			loc2 = F1363_10381(RTCW(loc6));
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = RTOSCF(10468,F1380_10468, (Current));
			tb2 = F958_6409(RTCW(tr1), loc1, tr2);
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				F1400_10694(RTCW(tr1), loc2);
			} else {
				tr1 = RTOSCF(6466,F971_6466, (Current));
				tr2 = RTOSCF(10469,F1380_10469, (Current));
				tb2 = F958_6409(RTCW(tr1), loc1, tr2);
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					F1400_10695(RTCW(tr1), loc2);
				} else {
					tr1 = RTOSCF(6466,F971_6466, (Current));
					tr2 = RTOSCF(10470,F1380_10470, (Current));
					tb2 = F958_6409(RTCW(tr1), loc1, tr2);
					if (tb2) {
						tr1 = RTOSCF(6466,F971_6466, (Current));
						tr2 = RTOSCF(10378,F1362_10378, (Current));
						tb2 = F958_6409(RTCW(tr1), tr2, loc2);
						if (tb2) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
							F1400_10696(RTCW(tr1), (EIF_BOOLEAN) 1);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
							F1400_10696(RTCW(tr1), (EIF_BOOLEAN) 0);
						}
					}
				}
			}
		}
		F1053_7396(RTCW(loc3));
	}
	tr1 = RTOSCF(10476,F1380_10476, (Current));
	loc5 = F1362_10365(Current, tr1);
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5961[Dtype(RTCW(loc5))-1184])(loc5);
	F1053_7395(RTCW(loc3));
	for (;;) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
		if (tb2) break;
		loc4 = RTLNS(eif_new_type(1372, 0x01).id, 1372, _OBJSIZ_3_0_0_0_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = F1108_7483(RTCW(loc3));
		F1367_10386(RTCW(loc4), tr1, tr2);
		tb3 = '\0';
		tb4 = '\0';
		tb5 = F1367_10388(RTCW(loc4));
		if (tb5) {
			tb5 = F1363_10382(RTCW(loc4));
			tb4 = tb5;
		}
		if (tb4) {
			tb4 = F1363_10383(RTCW(loc4));
			tb3 = tb4;
		}
		if (tb3) {
			loc1 = F1363_10380(RTCW(loc4));
			loc2 = F1363_10381(RTCW(loc4));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_6_);
				F1223_8414(RTCW(tr1), loc2, loc1);
			}
		}
		F1053_7396(RTCW(loc3));
	}
	RTLE;
}

/* {GEANT_GETEST_TASK}.build_command */
void F1380_10463 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7829,Y7829_gen_type,Dftype(Current),1373).id);
	F1400_10678(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_GETEST_TASK}.verbose_attribute_name */
static EIF_REFERENCE F1380_10465_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10465);
#define Result RTOSR(10465)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("verbose",7,1112830821);
	RTOSE (10465);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1380_10465 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10465,F1380_10465_body,(Current));
}

/* {GEANT_GETEST_TASK}.config_filename_attribute_name */
static EIF_REFERENCE F1380_10466_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10466);
#define Result RTOSR(10466)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("config",6,2047699815);
	RTOSE (10466);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1380_10466 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10466,F1380_10466_body,(Current));
}

/* {GEANT_GETEST_TASK}.compile_attribute_name */
static EIF_REFERENCE F1380_10467_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10467);
#define Result RTOSR(10467)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("compile",7,393845349);
	RTOSE (10467);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1380_10467 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10467,F1380_10467_body,(Current));
}

/* {GEANT_GETEST_TASK}.class_attribute_name */
static EIF_REFERENCE F1380_10468_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10468);
#define Result RTOSR(10468)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("class",5,1819086195);
	RTOSE (10468);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1380_10468 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10468,F1380_10468_body,(Current));
}

/* {GEANT_GETEST_TASK}.feature_attribute_name */
static EIF_REFERENCE F1380_10469_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10469);
#define Result RTOSR(10469)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("feature",7,1951938661);
	RTOSE (10469);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1380_10469 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10469,F1380_10469_body,(Current));
}

/* {GEANT_GETEST_TASK}.default_test_attribute_name */
static EIF_REFERENCE F1380_10470_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10470);
#define Result RTOSR(10470)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("default_test",12,1968489844);
	RTOSE (10470);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1380_10470 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10470,F1380_10470_body,(Current));
}

/* {GEANT_GETEST_TASK}.generation_attribute_name */
static EIF_REFERENCE F1380_10471_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10471);
#define Result RTOSR(10471)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("generation",10,1486063214);
	RTOSE (10471);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1380_10471 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10471,F1380_10471_body,(Current));
}

/* {GEANT_GETEST_TASK}.compilation_attribute_name */
static EIF_REFERENCE F1380_10472_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10472);
#define Result RTOSR(10472)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("compilation",11,886266990);
	RTOSE (10472);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1380_10472 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10472,F1380_10472_body,(Current));
}

/* {GEANT_GETEST_TASK}.execution_attribute_name */
static EIF_REFERENCE F1380_10473_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10473);
#define Result RTOSR(10473)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("execution",9,986487406);
	RTOSE (10473);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1380_10473 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10473,F1380_10473_body,(Current));
}

/* {GEANT_GETEST_TASK}.abort_attribute_name */
static EIF_REFERENCE F1380_10474_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10474);
#define Result RTOSR(10474)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("abort",5,1652215924);
	RTOSE (10474);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1380_10474 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10474,F1380_10474_body,(Current));
}

/* {GEANT_GETEST_TASK}.attribute_element_name */
static EIF_REFERENCE F1380_10475_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10475);
#define Result RTOSR(10475)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("attribute",9,1585140837);
	RTOSE (10475);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1380_10475 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10475,F1380_10475_body,(Current));
}

/* {GEANT_GETEST_TASK}.define_element_name */
static EIF_REFERENCE F1380_10476_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10476);
#define Result RTOSR(10476)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("define",6,1915569253);
	RTOSE (10476);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1380_10476 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10476,F1380_10476_body,(Current));
}

void EIF_Minit523 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
