/*
 * Code for class GEANT_ELEMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge505.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_ELEMENT}.make */
void F1362_10362 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1362_10367(Current, arg1);
}

/* {GEANT_ELEMENT}.elements_by_name */
EIF_REFERENCE F1362_10365 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1184,0xFF01,1286,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1184, _OBJSIZ_4_0_0_1_0_0_0_0_);
	}
	F1185_7905(RTCW(Result));
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = F1285_9135(RTCW(tr1));
	F1053_7395(RTCW(loc1));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_3_1_);
		if (tb1) break;
		tb2 = '\0';
		tr1 = F1108_7483(RTCW(loc1));
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(1286, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = *(EIF_REFERENCE *)(loc2 + _REFACS_1_);
			tb3 = F958_6409(RTCW(tr1), tr2, arg1);
			tb2 = tb3;
		}
		if (tb2) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(Result))-1184])(Result, loc2);
		}
		F1053_7396(RTCW(loc1));
	}
	RTLE;
	return Result;
}

/* {GEANT_ELEMENT}.set_xml_element */
void F1362_10367 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {GEANT_ELEMENT}.attribute_value */
EIF_REFERENCE F1362_10370 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	RTCT0("precondition", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F1287_9188(RTCW(tr1), arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = *(EIF_REFERENCE *)(loc1 + _REFACS_3_);
	RTLE;
	return Result;
}

/* {GEANT_ELEMENT}.attribute_value_if_existing */
EIF_REFERENCE F1362_10371 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if (F1362_10376(Current, arg1)) {
		RTLE;
		return (EIF_REFERENCE) (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7780[Dtype(Current)-1362])(Current, arg1);
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {GEANT_ELEMENT}.content */
EIF_REFERENCE F1362_10372 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1285_9137(RTCW(tr1));
	RTLE;
	return Result;
}

/* {GEANT_ELEMENT}.attribute_or_content_value */
EIF_REFERENCE F1362_10373 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,loc4);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,loc5);
	RTLR(8,Result);
	RTLIU(9);
	
	RTGC;
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7782[dtype-1362])(Current);
	loc2 = '\0';
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		tb1 = F641_3592(RTCW(loc3));
		loc2 = (EIF_BOOLEAN) !tb1;
	}
	loc1 = F1362_10376(Current, arg1);
	if ((EIF_BOOLEAN) (loc2 && loc1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 9L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr2) = 9L;
				memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
			}
			tr3 = RTMS_EX_H("  [",3,2105435);
			*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = *(EIF_REFERENCE *)(Current);
			tr3 = *(EIF_REFERENCE *)(RTCW(tr3) + _REFACS_1_);
			*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = RTMS_EX_H("] ERROR (",9,912087336);
			*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = *(EIF_REFERENCE *)(loc4);
			*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = RTMS_EX_H(", ",2,11296);
			*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_1_0_0_0_);
			tr3 = eif_out__i4_s1(ti4_1);
			*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = RTMS_EX_H(":",1,58);
			*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_1_0_0_1_);
			tr3 = eif_out__i4_s1(ti4_1);
			*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = RTMS_EX_H("):",2,10554);
			*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
			F1349_10215(Current, tr1);
		} else {
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr2) = 4L;
				memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
			}
			tr3 = RTMS_EX_H("  [",3,2105435);
			*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = *(EIF_REFERENCE *)(Current);
			tr3 = *(EIF_REFERENCE *)(RTCW(tr3) + _REFACS_1_);
			*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = RTMS_EX_H("]",1,93);
			*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = RTMS_EX_H(" ERROR:",7,443508282);
			*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
			F1349_10215(Current, tr1);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr2) = 5L;
			memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
		}
		tr3 = RTMS_EX_H("  Usage of both, attribute \'",28,1460132647);
		*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
		RTAR(tr2,tr3);
		*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) arg1;
		RTAR(tr2,arg1);
		tr3 = RTMS_EX_H("\' and text content within element \'",35,1660440871);
		*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
		RTAR(tr2,tr3);
		tr3 = *(EIF_REFERENCE *)(Current);
		tr3 = *(EIF_REFERENCE *)(RTCW(tr3) + _REFACS_1_);
		*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
		RTAR(tr2,tr3);
		tr3 = RTMS_EX_H("\' is not allowed.",17,1788971822);
		*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
		RTAR(tr2,tr3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
		F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc2 && (EIF_BOOLEAN) !loc1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 9L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr2) = 9L;
				memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
			}
			tr3 = RTMS_EX_H("  [",3,2105435);
			*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = *(EIF_REFERENCE *)(Current);
			tr3 = *(EIF_REFERENCE *)(RTCW(tr3) + _REFACS_1_);
			*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = RTMS_EX_H("] ERROR (",9,912087336);
			*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = *(EIF_REFERENCE *)(loc5);
			*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = RTMS_EX_H(", ",2,11296);
			*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_0_0_0_);
			tr3 = eif_out__i4_s1(ti4_1);
			*((EIF_REFERENCE *)tr2+5) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = RTMS_EX_H(":",1,58);
			*((EIF_REFERENCE *)tr2+6) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_0_0_1_);
			tr3 = eif_out__i4_s1(ti4_1);
			*((EIF_REFERENCE *)tr2+7) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = RTMS_EX_H("):",2,10554);
			*((EIF_REFERENCE *)tr2+8) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
			F1349_10215(Current, tr1);
		} else {
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr2) = 4L;
				memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
			}
			tr3 = RTMS_EX_H("  [",3,2105435);
			*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = *(EIF_REFERENCE *)(Current);
			tr3 = *(EIF_REFERENCE *)(RTCW(tr3) + _REFACS_1_);
			*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = RTMS_EX_H("]",1,93);
			*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr3 = RTMS_EX_H(" ERROR:",7,443508282);
			*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
			F1349_10215(Current, tr1);
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr2) = 5L;
			memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
		}
		tr3 = RTMS_EX_H("  You have to specify either attribute \'",40,1937270567);
		*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
		RTAR(tr2,tr3);
		*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) arg1;
		RTAR(tr2,arg1);
		tr3 = RTMS_EX_H("\' or text content within the element \'",38,1027119143);
		*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
		RTAR(tr2,tr3);
		tr3 = *(EIF_REFERENCE *)(Current);
		tr3 = *(EIF_REFERENCE *)(RTCW(tr3) + _REFACS_1_);
		*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
		RTAR(tr2,tr3);
		tr3 = RTMS_EX_H("\'.",2,10030);
		*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
		RTAR(tr2,tr3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
		F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
	}
	if (loc1) {
		RTLE;
		return (EIF_REFERENCE) (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7780[dtype-1362])(Current, arg1);
	} else {
		RTCT0("has_context_text", EX_CHECK);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		Result = (EIF_REFERENCE) loc3;
	}
	RTLE;
	return Result;
}

/* {GEANT_ELEMENT}.boolean_value */
EIF_BOOLEAN F1362_10375 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7780[Dtype(Current)-1362])(Current, arg1);
	tr1 = RTOSCF(6466,F971_6466, (Current));
	tr2 = RTOSCF(10378,F1362_10378, (Current));
	tb1 = F958_6409(RTCW(tr1), tr2, loc1);
	if (tb1) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = RTOSCF(10379,F1362_10379, (Current));
		tb1 = F958_6409(RTCW(tr1), tr2, loc1);
		if (tb1) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
			tr2 = RTMS_EX_H("WARNING: wrong value \'",22,251118375);
			F999_6748(RTCW(tr1), tr2);
			tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
			F999_6748(RTCW(tr1), loc1);
			tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
			tr2 = RTMS_EX_H("\' for attribute \'",17,972711719);
			F999_6748(RTCW(tr1), tr2);
			tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
			F999_6748(RTCW(tr1), arg1);
			tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
			tr2 = RTMS_EX_H("\'. Valid values are \'true\' and \'false\'. Using \'false\'.",54,685460014);
			F998_6740(RTCW(tr1), tr2);
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
	}/* NOTREACHED */
	
}

/* {GEANT_ELEMENT}.has_attribute */
EIF_BOOLEAN F1362_10376 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1287_9180(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {GEANT_ELEMENT}.description_element_name */
static EIF_REFERENCE F1362_10377_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10377);
#define Result RTOSR(10377)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("description",11,801826414);
	RTOSE (10377);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1362_10377 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10377,F1362_10377_body,(Current));
}

/* {GEANT_ELEMENT}.true_attribute_value */
static EIF_REFERENCE F1362_10378_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10378);
#define Result RTOSR(10378)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("true",4,1953658213);
	RTOSE (10378);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1362_10378 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10378,F1362_10378_body,(Current));
}

/* {GEANT_ELEMENT}.false_attribute_value */
static EIF_REFERENCE F1362_10379_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10379);
#define Result RTOSR(10379)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("false",5,1635280741);
	RTOSE (10379);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1362_10379 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10379,F1362_10379_body,(Current));
}

void EIF_Minit505 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
