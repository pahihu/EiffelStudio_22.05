/*
 * Code for class GEANT_INPUT_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge535.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_INPUT_TASK}.make */
void F1392_10584 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	F1374_10420(Current, arg1, arg2);
	tr1 = RTOSCF(10587,F1392_10587, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10587,F1392_10587, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1410_10857(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10588,F1392_10588, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10588,F1392_10588, (Current));
		loc1 = F1367_10390(Current, tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1410_10858(RTCW(tr1), loc1);
	}
	tr1 = RTOSCF(10589,F1392_10589, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10589,F1392_10589, (Current));
		loc1 = F1367_10390(Current, tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1410_10859(RTCW(tr1), loc1);
	}
	tr1 = RTOSCF(10590,F1392_10590, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10590,F1392_10590, (Current));
		loc1 = F1367_10390(Current, tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1410_10861(RTCW(tr1), loc1);
	}
	tr1 = RTOSCF(10591,F1392_10591, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10591,F1392_10591, (Current));
		loc1 = F1367_10390(Current, tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1410_10862(RTCW(tr1), loc1);
	}
	tr1 = RTOSCF(10592,F1392_10592, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10592,F1392_10592, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1410_10860(RTCW(tr1), tb1);
	}
	RTLE;
}

/* {GEANT_INPUT_TASK}.build_command */
void F1392_10585 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7829,Y7829_gen_type,Dftype(Current),1373).id);
	F1395_10615(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_INPUT_TASK}.variable_attribute_name */
static EIF_REFERENCE F1392_10587_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10587);
#define Result RTOSR(10587)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("variable",8,1315629925);
	RTOSE (10587);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1392_10587 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10587,F1392_10587_body,(Current));
}

/* {GEANT_INPUT_TASK}.message_attribute_name */
static EIF_REFERENCE F1392_10588_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10588);
#define Result RTOSR(10588)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("message",7,1162241893);
	RTOSE (10588);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1392_10588 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10588,F1392_10588_body,(Current));
}

/* {GEANT_INPUT_TASK}.defaultvalue_attribute_name */
static EIF_REFERENCE F1392_10589_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10589);
#define Result RTOSR(10589)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("defaultvalue",12,1650358629);
	RTOSE (10589);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1392_10589 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10589,F1392_10589_body,(Current));
}

/* {GEANT_INPUT_TASK}.validargs_attribute_name */
static EIF_REFERENCE F1392_10590_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10590);
#define Result RTOSR(10590)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("validargs",9,905631347);
	RTOSE (10590);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1392_10590 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10590,F1392_10590_body,(Current));
}

/* {GEANT_INPUT_TASK}.validregexp_attribute_name */
static EIF_REFERENCE F1392_10591_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10591);
#define Result RTOSR(10591)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("validregexp",11,1588940144);
	RTOSE (10591);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1392_10591 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10591,F1392_10591_body,(Current));
}

/* {GEANT_INPUT_TASK}.answer_required_attribute_name */
static EIF_REFERENCE F1392_10592_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10592);
#define Result RTOSR(10592)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("answer_required",15,882827876);
	RTOSE (10592);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1392_10592 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10592,F1392_10592_body,(Current));
}

void EIF_Minit535 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
