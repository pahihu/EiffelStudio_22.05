/*
 * Code for class GEANT_ECHO_COMMAND
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge546.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_ECHO_COMMAND}.make */
void F1403_10748 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	F1395_10615(Current, arg1);
	tr1 = RTLNSMART(eif_new_type(1360, 1).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1360, 1).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1359, 1).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,129,0xFF01,938,0xFF01,0xFFF9,1,864,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,864,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,938,0xFF01,0xFFF9,1,864,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A546_74_2, (EIF_POINTER) _A546_74_2, (EIF_POINTER)(F1403_10756),tr2, 1, 1);
	}
	F130_1565(RTCW(tr1), tr5);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,129,0xFF01,938,0xFF01,0xFFF9,3,864,0xFF01,950,0xFF01,1246,903,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,864,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,938,0xFF01,0xFFF9,3,864,0xFF01,950,0xFF01,1246,903,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A546_75_2_3_4, (EIF_POINTER) _A546_75_2_3_4, (EIF_POINTER)(F1403_10757),tr2, 1, 3);
	}
	F130_1565(RTCW(tr1), tr5);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_ECHO_COMMAND}.is_executable */
EIF_BOOLEAN F1403_10749 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,130,903,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 130, _OBJSIZ_0_1_0_0_0_0_0_0_);
	}
	F131_1565(RTCW(loc1), (EIF_BOOLEAN) 1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1358_10353(RTCW(tr1));
	tr1 = RTMS_EX_H("  [echo] error: \'message\' is not defined",40,1430542436);
	F1395_10622(Current, tb1, tr1, loc1);
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_0_0_);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tb1 = F1358_10353(RTCW(tr1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr1 = F1361_10361(RTCW(tr1));
			tb1 = F641_3592(RTCW(tr1));
			tr1 = RTMS_EX_H("  [echo] error: \'to_file\' may not be empty",42,1344766329);
			F1395_10622(Current, (EIF_BOOLEAN) !tb1, tr1, loc1);
		}
	}
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_0_0_);
	RTLE;
	return (EIF_BOOLEAN) tb1;
}

/* {GEANT_ECHO_COMMAND}.execute */
void F1403_10755 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc4);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,tr4);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = F1361_10361(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tb1 = F1358_10353(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc2 = F1361_10361(RTCW(tr1));
		loc4 = RTLNS(eif_new_type(1246, 0x01).id, 1246, _OBJSIZ_6_7_2_4_1_1_2_1_);
		F1245_8562(RTCW(loc4), loc2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc3 = F1359_10352(RTCW(tr1), (EIF_BOOLEAN) 0);
		if (loc3) {
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr3) = 5L;
				memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
			}
			tr4 = RTMS_EX_H("  [echo] Appending \'",20,303329831);
			*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
			RTAR(tr3,loc1);
			tr4 = RTMS_EX_H("\' to file \'",11,1641727527);
			*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) loc2;
			RTAR(tr3,loc2);
			tr4 = RTMS_EX_H("\'",1,39);
			*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
			F1356_10323(RTCW(tr1), tr2);
			F1246_8596(RTCW(loc4));
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr3) = 5L;
				memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
			}
			tr4 = RTMS_EX_H("  [echo] Writing \'",18,216344103);
			*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
			RTAR(tr3,loc1);
			tr4 = RTMS_EX_H("\' to file \'",11,1641727527);
			*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) loc2;
			RTAR(tr3,loc2);
			tr4 = RTMS_EX_H("\'",1,39);
			*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
			F1356_10323(RTCW(tr1), tr2);
			F1246_8595(RTCW(loc4));
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_), loc1, loc4, loc3);
		tb1 = F1246_8592(RTCW(loc4));
		if (tb1) {
			F1245_8570(RTCW(loc4));
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_), loc1);
	}
	RTLE;
}

/* {GEANT_ECHO_COMMAND}.write_message */
void F1403_10756 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr3) = 1L;
		memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
	}
	tr4 = RTMS_EX_H("  [echo]",8,781139293);
	*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
	F1356_10323(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr3) = 1L;
		memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
	}
	*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) arg1;
	RTAR(tr3,arg1);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
	F1356_10324(RTCW(tr1), tr2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {GEANT_ECHO_COMMAND}.write_message_to_file */
void F1403_10757 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTGC;
	tb1 = F1246_8592(RTCW(arg2));
	if (tb1) {
		F998_6740(RTCW(arg2), arg1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H("  [echo] error: cannot write to file \'",38,963065383);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_5_);
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = RTMS_EX_H("\'",1,39);
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10324(RTCW(tr1), tr2);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

void EIF_Minit546 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
