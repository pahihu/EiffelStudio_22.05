/*
 * Code for class GEANT_MOVE_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge519.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_MOVE_TASK}.make */
void F1376_10436 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,loc3);
	RTLIU(8);
	
	RTGC;
	F1374_10420(Current, arg1, arg2);
	tr1 = RTOSCF(10439,F1376_10439, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10439,F1376_10439, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1414_10886(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10440,F1376_10440, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10440,F1376_10440, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1414_10887(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10441,F1376_10441, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10441,F1376_10441, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1414_10888(RTCW(tr1), loc1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTOSCF(10442,F1376_10442, (Current));
	loc2 = F1287_9185(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		loc3 = RTLNS(eif_new_type(1421, 0x01).id, 1421, _OBJSIZ_4_0_0_0_0_0_0_0_);
		F1422_11027(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_2_), loc2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_3_);
		F1414_10889(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {GEANT_MOVE_TASK}.build_command */
void F1376_10437 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7829,Y7829_gen_type,Dftype(Current),1373).id);
	F1395_10615(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_MOVE_TASK}.file_attribute_name */
static EIF_REFERENCE F1376_10439_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10439);
#define Result RTOSR(10439)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("file",4,1718185061);
	RTOSE (10439);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1376_10439 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10439,F1376_10439_body,(Current));
}

/* {GEANT_MOVE_TASK}.to_file_attribute_name */
static EIF_REFERENCE F1376_10440_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10440);
#define Result RTOSR(10440)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("to_file",7,192426597);
	RTOSE (10440);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1376_10440 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10440,F1376_10440_body,(Current));
}

/* {GEANT_MOVE_TASK}.to_directory_attribute_name */
static EIF_REFERENCE F1376_10441_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10441);
#define Result RTOSR(10441)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("to_directory",12,832290425);
	RTOSE (10441);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1376_10441 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10441,F1376_10441_body,(Current));
}

/* {GEANT_MOVE_TASK}.fileset_element_name */
static EIF_REFERENCE F1376_10442_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10442);
#define Result RTOSR(10442)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("fileset",7,1708094836);
	RTOSE (10442);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1376_10442 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10442,F1376_10442_body,(Current));
}

void EIF_Minit519 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
