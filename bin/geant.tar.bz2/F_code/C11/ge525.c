/*
 * Code for class GEANT_GELEX_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge525.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_GELEX_TASK}.make */
void F1382_10489 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	F1374_10420(Current, arg1, arg2);
	tr1 = RTOSCF(10492,F1382_10492, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10492,F1382_10492, (Current));
		loc1 = F1367_10390(Current, tr1);
		tb1 = F943_5858(RTCW(loc1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1402_10735(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10493,F1382_10493, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10493,F1382_10493, (Current));
		loc1 = F1367_10390(Current, tr1);
		tb1 = F943_5858(RTCW(loc1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1402_10735(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10495,F1382_10495, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10495,F1382_10495, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1402_10736(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10496,F1382_10496, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10496,F1382_10496, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1402_10737(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10497,F1382_10497, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10497,F1382_10497, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1402_10738(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10498,F1382_10498, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10498,F1382_10498, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1402_10739(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10499,F1382_10499, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10499,F1382_10499, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1402_10740(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10500,F1382_10500, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10500,F1382_10500, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1402_10741(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10501,F1382_10501, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10501,F1382_10501, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1402_10742(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10502,F1382_10502, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10502,F1382_10502, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1402_10743(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10494,F1382_10494, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10494,F1382_10494, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1402_10744(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10503,F1382_10503, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10503,F1382_10503, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1402_10745(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10504,F1382_10504, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10504,F1382_10504, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1402_10746(RTCW(tr1), loc1);
		}
	}
	RTLE;
}

/* {GEANT_GELEX_TASK}.build_command */
void F1382_10490 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7829,Y7829_gen_type,Dftype(Current),1373).id);
	F1402_10721(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_GELEX_TASK}.size_attribute_name */
static EIF_REFERENCE F1382_10492_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10492);
#define Result RTOSR(10492)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("size",4,1936292453);
	RTOSE (10492);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1382_10492 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10492,F1382_10492_body,(Current));
}

/* {GEANT_GELEX_TASK}.array_size_attribute_name */
static EIF_REFERENCE F1382_10493_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10493);
#define Result RTOSR(10493)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("array_size",10,1982128229);
	RTOSE (10493);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1382_10493 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10493,F1382_10493_body,(Current));
}

/* {GEANT_GELEX_TASK}.inspect_actions_attribute_name */
static EIF_REFERENCE F1382_10494_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10494);
#define Result RTOSR(10494)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("inspect_actions",15,1187384179);
	RTOSE (10494);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1382_10494 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10494,F1382_10494_body,(Current));
}

/* {GEANT_GELEX_TASK}.backup_attribute_name */
static EIF_REFERENCE F1382_10495_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10495);
#define Result RTOSR(10495)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("backup",6,1861407600);
	RTOSE (10495);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1382_10495 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10495,F1382_10495_body,(Current));
}

/* {GEANT_GELEX_TASK}.ecs_attribute_name */
static EIF_REFERENCE F1382_10496_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10496);
#define Result RTOSR(10496)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("ecs",3,6644595);
	RTOSE (10496);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1382_10496 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10496,F1382_10496_body,(Current));
}

/* {GEANT_GELEX_TASK}.full_attribute_name */
static EIF_REFERENCE F1382_10497_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10497);
#define Result RTOSR(10497)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("full",4,1718971500);
	RTOSE (10497);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1382_10497 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10497,F1382_10497_body,(Current));
}

/* {GEANT_GELEX_TASK}.case_insensitive_attribute_name */
static EIF_REFERENCE F1382_10498_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10498);
#define Result RTOSR(10498)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("case_insensitive",16,249136997);
	RTOSE (10498);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1382_10498 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10498,F1382_10498_body,(Current));
}

/* {GEANT_GELEX_TASK}.meta_ecs_attribute_name */
static EIF_REFERENCE F1382_10499_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10499);
#define Result RTOSR(10499)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("meta_ecs",8,1149853043);
	RTOSE (10499);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1382_10499 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10499,F1382_10499_body,(Current));
}

/* {GEANT_GELEX_TASK}.no_default_attribute_name */
static EIF_REFERENCE F1382_10500_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10500);
#define Result RTOSR(10500)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("no_default",10,1695562868);
	RTOSE (10500);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1382_10500 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10500,F1382_10500_body,(Current));
}

/* {GEANT_GELEX_TASK}.no_warn_attribute_name */
static EIF_REFERENCE F1382_10501_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10501);
#define Result RTOSR(10501)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("no_warn",7,1752177262);
	RTOSE (10501);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1382_10501 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10501,F1382_10501_body,(Current));
}

/* {GEANT_GELEX_TASK}.separate_actions_attribute_name */
static EIF_REFERENCE F1382_10502_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10502);
#define Result RTOSR(10502)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("separate_actions",16,897573491);
	RTOSE (10502);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1382_10502 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10502,F1382_10502_body,(Current));
}

/* {GEANT_GELEX_TASK}.output_filename_attribute_name */
static EIF_REFERENCE F1382_10503_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10503);
#define Result RTOSR(10503)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("output",6,25180788);
	RTOSE (10503);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1382_10503 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10503,F1382_10503_body,(Current));
}

/* {GEANT_GELEX_TASK}.input_filename_attribute_name */
static EIF_REFERENCE F1382_10504_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10504);
#define Result RTOSR(10504)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("input",5,1853670260);
	RTOSE (10504);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1382_10504 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10504,F1382_10504_body,(Current));
}

void EIF_Minit525 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
