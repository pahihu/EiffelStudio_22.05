/*
 * Code for class GEANT_PROJECT_LOADER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge500.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_PROJECT_LOADER}.make */
void F1355_10281 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc1);
	RTLR(8,tr3);
	RTLR(9,tr4);
	RTLIU(10);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	tr1 = RTOSCF(8474,F1240_8474, (Current));
	tb1 = F1270_8956(RTCW(tr1), *(EIF_REFERENCE *)(Current));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(2207,F207_2207, (Current));
		tr2 = RTMS_EX_H("${GOBO}/misc/",13,1710060335);
		loc2 = F993_6715(RTCW(tr1), tr2);
		tb1 = F949_6160(RTCW(arg1), loc2);
		if (tb1) {
			tr1 = RTOSCF(2207,F207_2207, (Current));
			tr2 = RTMS_EX_H("${GOBO}/library/common/config/",30,1333294639);
			loc3 = F993_6715(RTCW(tr1), tr2);
			loc4 = F1_14(arg1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4660[Dtype(RTCW(loc4))-950])(loc4, ti4_1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4764[Dtype(RTCW(loc3))-950])(loc3, loc4);
			loc4 = (EIF_REFERENCE) tr1;
			tr1 = RTOSCF(8474,F1240_8474, (Current));
			tb1 = F1270_8956(RTCW(tr1), loc4);
			if (tb1) {
				RTAR(Current, loc4);
				*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc4;
			}
		}
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) == arg1)) {
			tr1 = RTOSCF(8474,F1240_8474, (Current));
			tr2 = RTOSCF(8474,F1240_8474, (Current));
			tr3 = *(EIF_REFERENCE *)(Current);
			tr4 = RTOSCF(8477,F1240_8477, (Current));
			tr2 = F1269_8951(RTCW(tr2), tr3, tr4);
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R6651[Dtype(RTCW(tr1))-1270])(tr1, tr2);
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr2) = 3L;
				memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
			}
			tr3 = RTMS_EX_H("cannot read build file \'",24,1294273319);
			*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) loc1;
			RTAR(tr2,loc1);
			tr3 = RTMS_EX_H("\'",1,39);
			*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
			F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
		}
	}
	RTLE;
}

/* {GEANT_PROJECT_LOADER}.load */
void F1355_10284 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLR(6,tr2);
	RTLR(7,loc3);
	RTLR(8,tr3);
	RTLR(9,tr4);
	RTLIU(10);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	loc1 = RTLNS(eif_new_type(1251, 0x01).id, 1251, _OBJSIZ_7_8_2_4_1_1_2_1_);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R28[Dtype(RTCW(tr1))-872])(tr1);
	F1251_8615(RTCW(loc1), tr1);
	F1251_8625(RTCW(loc1));
	tb1 = F1251_8618(RTCW(loc1));
	if (tb1) {
		loc2 = RTLNS(eif_new_type(1013, 0x01).id, 1013, _OBJSIZ_6_0_0_0_0_0_0_0_);
		F1014_6884(RTCW(loc2), arg1, arg2, *(EIF_REFERENCE *)(Current));
		F1014_6887(RTCW(loc2), loc1);
		F1251_8626(RTCW(loc1));
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
		tr2 = RTMS_EX_H("cannot read file: \'",19,1071348775);
		F999_6748(RTCW(tr1), tr2);
		tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
		F999_6748(RTCW(tr1), *(EIF_REFERENCE *)(Current));
		tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
		F999_6747(RTCW(tr1), (EIF_CHARACTER_8) '\'');
		tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
		F998_6741(RTCW(tr1));
	}
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) == NULL)) {
		tr1 = RTOSCF(8474,F1240_8474, (Current));
		tr2 = RTOSCF(8474,F1240_8474, (Current));
		tr3 = *(EIF_REFERENCE *)(Current);
		tr4 = RTOSCF(8477,F1240_8477, (Current));
		tr2 = F1269_8951(RTCW(tr2), tr3, tr4);
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R6651[Dtype(RTCW(tr1))-1270])(tr1, tr2);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr2) = 3L;
			memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
		}
		tr3 = RTMS_EX_H("Parsing error in file \'",23,224427047);
		*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
		RTAR(tr2,tr3);
		*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) loc3;
		RTAR(tr2,loc3);
		tr3 = RTMS_EX_H("\'",1,39);
		*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
		RTAR(tr2,tr3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
		F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
	}
	RTLE;
}

void EIF_Minit500 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
