/*
 * Code for class GEANT_EXIT_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge536.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_EXIT_TASK}.make */
void F1393_10593 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	F1374_10420(Current, arg1, arg2);
	tr1 = RTOSCF(10596,F1393_10596, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10596,F1393_10596, (Current));
		loc1 = F1367_10390(Current, tr1);
		tb1 = F943_5858(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr2) = 3L;
				memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
			}
			tr3 = RTMS_EX_H("  [exit] warning: code \'",24,1889281063);
			*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) loc1;
			RTAR(tr2,loc1);
			tr3 = RTMS_EX_H("\' is not a valid integer value. Using value \'1\' instead.",56,666020398);
			*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
			F1356_10324(RTCW(arg1), tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1412_10873(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			ti4_1 = F943_5892(RTCW(loc1));
			F1412_10873(RTCW(tr1), ti4_1);
		}
	}
	RTLE;
}

/* {GEANT_EXIT_TASK}.build_command */
void F1393_10594 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7829,Y7829_gen_type,Dftype(Current),1373).id);
	F1395_10615(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_EXIT_TASK}.code_attribute_name */
static EIF_REFERENCE F1393_10596_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10596);
#define Result RTOSR(10596)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("code",4,1668244581);
	RTOSE (10596);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1393_10596 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10596,F1393_10596_body,(Current));
}

void EIF_Minit536 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
