/*
 * Code for class GEANT_STRING_PROPERTY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge504.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_STRING_PROPERTY}.value */
EIF_REFERENCE F1361_10361 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1358_10349(Current);
}

void EIF_Minit504 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
