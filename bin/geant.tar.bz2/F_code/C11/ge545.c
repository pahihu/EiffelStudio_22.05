/*
 * Code for class GEANT_GELEX_COMMAND
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge545.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_GELEX_COMMAND}.make */
void F1402_10721 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1395_10615(Current, arg1);
	tr1 = RTMS_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {GEANT_GELEX_COMMAND}.is_executable */
EIF_BOOLEAN F1402_10722 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		Result = (!(*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) || ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_6_4_)));
	}
	RTLE;
	return Result;
}

/* {GEANT_GELEX_COMMAND}.set_array_size */
void F1402_10735 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_GELEX_COMMAND}.set_backup */
void F1402_10736 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT_GELEX_COMMAND}.set_ecs */
void F1402_10737 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT_GELEX_COMMAND}.set_full */
void F1402_10738 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT_GELEX_COMMAND}.set_case_insensitive */
void F1402_10739 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_3_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT_GELEX_COMMAND}.set_meta_ecs */
void F1402_10740 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_4_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT_GELEX_COMMAND}.set_no_default */
void F1402_10741 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_5_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT_GELEX_COMMAND}.set_no_warn */
void F1402_10742 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_6_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT_GELEX_COMMAND}.set_separate_actions */
void F1402_10743 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_7_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT_GELEX_COMMAND}.set_inspect_actions */
void F1402_10744 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_GELEX_COMMAND}.set_output_filename */
void F1402_10745 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_GELEX_COMMAND}.set_input_filename */
void F1402_10746 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_GELEX_COMMAND}.execute */
void F1402_10747 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,loc3);
	RTLR(3,Current);
	RTLR(4,tr2);
	RTLR(5,loc4);
	RTLR(6,loc2);
	RTLR(7,tr3);
	RTLR(8,tr4);
	RTLIU(9);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(950, 0x01).id, 950, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F949_6124(RTCW(loc1), ((EIF_INTEGER_32) 128L));
	tr1 = RTMS_EX_H("gelex ",6,2021871136);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		tr1 = RTMS_EX_H("--array-size=",13,1129877565);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R28[Dtype(loc3)-872])(loc3);
		tr1 = F958_6417(RTCW(tr1), loc1, tr2);
		loc1 = (EIF_REFERENCE) tr1;
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_)) {
		tr1 = RTMS_EX_H("-b ",3,2974240);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_2_)) {
		tr1 = RTMS_EX_H("-f ",3,2975264);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_) || (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_6_4_))) {
			tr1 = RTMS_EX_H("-c ",3,2974496);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
		}
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_1_)) {
		tr1 = RTMS_EX_H("-e ",3,2975008);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_4_)) {
		tr1 = RTMS_EX_H("-m ",3,2977056);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_3_)) {
		tr1 = RTMS_EX_H("-i ",3,2976032);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_5_)) {
		tr1 = RTMS_EX_H("-s ",3,2978592);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_6_)) {
		tr1 = RTMS_EX_H("-w ",3,2979616);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_6_7_)) {
		tr1 = RTMS_EX_H("-x ",3,2979872);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
	}
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		tb2 = F641_3592(loc4);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = RTMS_EX_H("--inspect-actions=",18,1205008957);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, loc4);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(loc1))-950])(loc1, (EIF_CHARACTER_8) ' ');
	}
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		tr1 = RTMS_EX_H("-o ",3,2977568);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
		tr1 = RTOSCF(8474,F1240_8474, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr3 = RTOSCF(8477,F1240_8477, (Current));
		loc2 = F1269_8951(RTCW(tr1), tr2, tr3);
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr1 = F958_6417(RTCW(tr1), loc1, loc2);
		loc1 = (EIF_REFERENCE) tr1;
		tr1 = RTMS_EX_H(" ",1,32);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
	}
	tr1 = RTOSCF(8474,F1240_8474, (Current));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr3 = RTOSCF(8477,F1240_8477, (Current));
	loc2 = F1269_8951(RTCW(tr1), tr2, tr3);
	tr1 = RTOSCF(6466,F971_6466, (Current));
	tr1 = F958_6417(RTCW(tr1), loc1, loc2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr3) = 2L;
		memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
	}
	tr4 = RTMS_EX_H("  [gelex] ",10,1965659936);
	*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
	RTAR(tr3,loc1);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
	F1356_10323(RTCW(tr1), tr2);
	F1395_10623(Current, loc1);
	RTLE;
}

void EIF_Minit545 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
