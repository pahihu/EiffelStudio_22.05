/*
 * Code for class GEANT_GEANT_COMMAND
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge542.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_GEANT_COMMAND}.make */
void F1399_10653 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1395_10615(Current, arg1);
	tr1 = RTLNSMART(eif_new_type(1238, 1).id);
	F1238_8470(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_GEANT_COMMAND}.is_filename_executable */
EIF_BOOLEAN F1399_10660 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
		Result = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	RTLE;
	return Result;
}

/* {GEANT_GEANT_COMMAND}.is_target_executable */
EIF_BOOLEAN F1399_10661 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
		Result = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	RTLE;
	return Result;
}

/* {GEANT_GEANT_COMMAND}.is_fileset_executable */
EIF_BOOLEAN F1399_10662 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) != NULL);
}

/* {GEANT_GEANT_COMMAND}.is_executable */
EIF_BOOLEAN F1399_10663 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	if (!F1399_10660(Current)) {
		Result = F1399_10661(Current);
	}
	RTLE;
	return Result;
}

/* {GEANT_GEANT_COMMAND}.set_filename */
void F1399_10665 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_GEANT_COMMAND}.set_fileset */
void F1399_10666 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_GEANT_COMMAND}.set_reuse_variables */
void F1399_10667 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT_GEANT_COMMAND}.set_fork */
void F1399_10668 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_) = (EIF_BOOLEAN) arg1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {GEANT_GEANT_COMMAND}.set_start_target_name */
void F1399_10669 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_GEANT_COMMAND}.set_exit_code_variable_name */
void F1399_10670 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_GEANT_COMMAND}.execute */
void F1399_10671 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLIU(7);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tb1 = '\0';
	if (F1399_10660(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc3 = tr1;
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_)) {
			loc2 = *(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_);
		} else {
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		tr1 = RTOSCF(8474,F1240_8474, (Current));
		tr2 = RTOSCF(8477,F1240_8477, (Current));
		loc1 = F1269_8951(RTCW(tr1), loc3, tr2);
		if (loc2) {
			F1399_10672(Current, loc1, *(EIF_REFERENCE *)(Current + _REFACS_4_));
		} else {
			F1399_10674(Current, loc1);
		}
	} else {
		RTCT0("target_executable", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			RTCK0;
		} else {
			RTCF0;
		}
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_)) {
			loc2 = *(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_);
		} else {
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		if (loc2) {
			F1399_10673(Current, loc4);
		} else {
			F1399_10675(Current, loc4);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_);
		tr2 = eif_out__i4_s1(ti4_1);
		F1356_10328(RTCW(tr1), loc5, tr2);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	RTLE;
}

/* {GEANT_GEANT_COMMAND}.execute_forked_with_filename_and_target */
void F1399_10672 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc2);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,arg1);
	RTLR(8,loc3);
	RTLR(9,loc1);
	RTLIU(10);
	
	RTGC;
	loc2 = RTMS_EX_H("",0,0);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 5L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H("  [*geant] execute_forked_with_filename_and_target: \'",53,451852327);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) arg1;
		RTAR(tr3,arg1);
		tr4 = RTMS_EX_H("\', \'",4,657203239);
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) arg2;
		RTAR(tr3,arg2);
		tr4 = RTMS_EX_H("\'",1,39);
		*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10325(RTCW(tr1), tr2);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H("  [*geant] execute_forked_with_filename_and_target: \'",53,451852327);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) arg1;
		RTAR(tr3,arg1);
		tr4 = RTMS_EX_H("\'",1,39);
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10325(RTCW(tr1), tr2);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_1_);
	if (tb1) {
		tb1 = '\0';
		tr1 = RTOSCF(10206,F1349_10206, (Current));
		tr2 = RTMS_EX_H("geant.geant.level",17,888452460);
		tb2 = F1351_10237(RTCW(tr1), tr2);
		if (tb2) {
			tr1 = RTOSCF(10206,F1349_10206, (Current));
			tr2 = RTMS_EX_H("geant.geant.level",17,888452460);
			tr1 = F1351_10234(RTCW(tr1), tr2);
			loc3 = tr1;
			tb1 = EIF_TEST(loc3);
		}
		if (tb1) {
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = RTMS_EX_H("#",1,35);
			loc2 = F958_6407(RTCW(tr1), loc3, tr2);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr3) = 1L;
				memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
			}
			tr4 = RTMS_EX_H("  [*geant] no variable \'geant.geant.level\' found",48,1897141348);
			*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
			F1356_10325(RTCW(tr1), tr2);
			loc2 = RTMS_EX_H("#",1,35);
		}
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H("  [geant] geant.geant.level=",28,649077053);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc2;
		RTAR(tr3,loc2);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10323(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		tr2 = RTMS_EX_H("geant.geant.level",17,888452460);
		F1223_8410(RTCW(tr1), loc2, tr2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 25L))) {
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr2) = 1L;
				memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
			}
			tr3 = RTMS_EX_H("TOO MANY RECURSIVE FORKED GEANT CALLS",37,1239529555);
			*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
			F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
		}
	}
	loc1 = RTLNS(eif_new_type(950, 0x01).id, 950, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F949_6124(RTCW(loc1), ((EIF_INTEGER_32) 256L));
	tr1 = RTMS_EX_H("geant",5,1701675124);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
	tr1 = RTOSCF(6466,F971_6466, (Current));
	tr2 = F1399_10676(Current);
	tr1 = F958_6417(RTCW(tr1), loc1, tr2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_1_);
	if (tb1) {
		tr1 = RTMS_EX_H(" -Dgeant.geant.level=",21,2145372989);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr1 = F958_6417(RTCW(tr1), loc1, loc2);
		loc1 = (EIF_REFERENCE) tr1;
	}
	tr1 = RTMS_EX_H(" -b ",4,539845152);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
	tr1 = RTOSCF(6466,F971_6466, (Current));
	tr1 = F958_6417(RTCW(tr1), loc1, arg1);
	loc1 = (EIF_REFERENCE) tr1;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		tr1 = RTMS_EX_H(" ",1,32);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr1 = F958_6417(RTCW(tr1), loc1, arg2);
		loc1 = (EIF_REFERENCE) tr1;
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr3) = 2L;
		memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
	}
	tr4 = RTMS_EX_H("  [geant] ",10,2116308256);
	*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
	RTAR(tr3,loc1);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
	F1356_10323(RTCW(tr1), tr2);
	F1395_10623(Current, loc1);
	RTLE;
}

/* {GEANT_GEANT_COMMAND}.execute_forked_with_target */
void F1399_10673 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,arg1);
	RTLR(6,loc2);
	RTLR(7,loc1);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr3) = 3L;
		memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
	}
	tr4 = RTMS_EX_H("  [*geant] execute_forked_with_target: \'",40,652143911);
	*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) arg1;
	RTAR(tr3,arg1);
	tr4 = RTMS_EX_H("\'",1,39);
	*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
	F1356_10325(RTCW(tr1), tr2);
	if (F1399_10662(Current)) {
	} else {
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = *(EIF_REFERENCE *)(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2));
		tr3 = RTMS_EX_H(".filename",9,1815437669);
		loc2 = F958_6407(RTCW(tr1), tr2, tr3);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		loc1 = F1223_8394(RTCW(tr1), loc2);
		tr1 = RTOSCF(8474,F1240_8474, (Current));
		tr2 = RTOSCF(8477,F1240_8477, (Current));
		tr1 = F1269_8951(RTCW(tr1), loc1, tr2);
		loc1 = (EIF_REFERENCE) tr1;
		F1399_10672(Current, loc1, arg1);
	}
	RTLE;
}

/* {GEANT_GEANT_COMMAND}.execute_with_filename */
void F1399_10674 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,loc5);
	RTLR(6,loc2);
	RTLR(7,loc6);
	RTLR(8,loc7);
	RTLR(9,tr2);
	RTLR(10,tr3);
	RTLR(11,loc3);
	RTLR(12,loc8);
	RTLR(13,tr4);
	RTLIU(14);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	} else {
		loc4 = RTLNS(eif_new_type(1353, 0x01).id, 1353, _OBJSIZ_11_0_0_9_0_0_0_0_);
		F1354_10273(RTCW(loc4));
	}
	loc1 = RTLNS(eif_new_type(1354, 0x01).id, 1354, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1355_10281(RTCW(loc1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	F1355_10284(RTCW(loc1), loc4, tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		loc2 = *(EIF_REFERENCE *)(loc5 + _REFACS_2_);
		F1356_10317(RTCW(loc2));
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			ti4_1 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_1_1_0_2_);
			tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
		}
		if (tb1) {
			tb1 = '\01';
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_5_);
			loc7 = tr1;
			if (!((EIF_BOOLEAN) !EIF_TEST(loc7))) {
				tb2 = F1223_8402(loc7, loc6);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				{
					static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
					RT_SPECIAL_COUNT(tr2) = 4L;
					memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
				}
				tr3 = RTMS_EX_H("Project \'",9,213807399);
				*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = *(EIF_REFERENCE *)(RTCW(loc2));
				*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = RTMS_EX_H("\' does not contain a target named `",35,2111554912);
				*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = RTMS_EX_H("\'",1,39);
				tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4764[Dtype(loc6)-950])(loc6, tr3);
				*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
				F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
			} else {
				loc3 = F1223_8394(loc7, loc6);
				tb1 = '\01';
				tb2 = F1430_11123(RTCW(loc3));
				if (!tb2) {
					tb2 = F1430_11124(RTCW(loc3), *(EIF_REFERENCE *)(Current));
					tb1 = tb2;
				}
				if ((EIF_BOOLEAN) !tb1) {
					{
						static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 5L),sizeof(EIF_REFERENCE), EIF_FALSE);
						RT_SPECIAL_COUNT(tr2) = 5L;
						memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
					}
					tr3 = RTMS_EX_H("target: `",9,1971240032);
					*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = F1430_11111(RTCW(loc3));
					*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("\' is not exported to project \'",30,1013440039);
					*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = *(EIF_REFERENCE *)(Current);
					tr3 = *(EIF_REFERENCE *)(RTCW(tr3));
					*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("\'",1,39);
					*((EIF_REFERENCE *)tr2+4) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
					F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
				}
				F1356_10307(RTCW(loc2), loc6);
			}
		}
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) == ((EIF_INTEGER_32) 0L))) {
			tb1 = '\0';
			if (F1399_10662(Current)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				loc8 = tr1;
				tb1 = EIF_TEST(loc8);
			}
			if (tb1) {
				tb1 = F1259_8717(loc8);
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = *(EIF_REFERENCE *)(Current);
					{
						static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
						RT_SPECIAL_COUNT(tr3) = 1L;
						memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
					}
					tr4 = RTMS_EX_H("  [geant] error: fileset definition wrong",41,288502375);
					*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
					F1356_10324(RTCW(tr1), tr2);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				}
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) == ((EIF_INTEGER_32) 0L))) {
					F1259_8743(loc8);
					F1259_8740(loc8);
					for (;;) {
						tb1 = '\01';
						tb2 = F1259_8722(loc8);
						if (!tb2) {
							tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) != ((EIF_INTEGER_32) 0L));
						}
						if (tb1) break;
						loc3 = F1356_10296(RTCW(loc2));
						F1356_10319(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_5_));
						tb2 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_13_0_);
						if ((EIF_BOOLEAN) !tb2) {
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						}
						F1259_8741(loc8);
					}
				}
			} else {
				loc3 = F1356_10296(RTCW(loc2));
				F1356_10319(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_5_));
				tb2 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_13_0_);
				if ((EIF_BOOLEAN) !tb2) {
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				}
			}
		}
	} else {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {GEANT_GEANT_COMMAND}.execute_with_target */
void F1399_10675 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,tr4);
	RTLR(8,loc1);
	RTLIU(9);
	
	RTGC;
	RTCT0("precondition", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		tb2 = F1223_8402(loc3, loc2);
		tb1 = tb2;
	}
	if (tb1) {
		tb1 = '\0';
		if (F1399_10662(Current)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			loc4 = tr1;
			tb1 = EIF_TEST(loc4);
		}
		if (tb1) {
			tb1 = F1259_8717(loc4);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = *(EIF_REFERENCE *)(Current);
				{
					static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
					RT_SPECIAL_COUNT(tr3) = 1L;
					memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
				}
				tr4 = RTMS_EX_H("  [geant] error: fileset definition wrong",41,288502375);
				*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
				RTAR(tr3,tr4);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
				F1356_10324(RTCW(tr1), tr2);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			}
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) == ((EIF_INTEGER_32) 0L))) {
				F1259_8743(loc4);
				loc1 = F1223_8394(loc3, loc2);
				tr1 = F1430_11115(RTCW(loc1));
				loc1 = (EIF_REFERENCE) tr1;
				F1259_8740(loc4);
				for (;;) {
					tb1 = '\01';
					tb2 = F1259_8722(loc4);
					if (!tb2) {
						tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) != ((EIF_INTEGER_32) 0L));
					}
					if (tb1) break;
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
					F1356_10321(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + _REFACS_5_));
					F1259_8741(loc4);
				}
			}
		} else {
			loc1 = F1223_8394(loc3, loc2);
			tr1 = F1430_11115(RTCW(loc1));
			loc1 = (EIF_REFERENCE) tr1;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
			F1356_10321(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + _REFACS_5_));
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H("  [geant] error: unknown target: `",34,610669152);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc2;
		RTAR(tr3,loc2);
		tr4 = RTMS_EX_H("\'",1,39);
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10324(RTCW(tr1), tr2);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_3_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {GEANT_GEANT_COMMAND}.options_and_arguments_for_cmdline */
EIF_REFERENCE F1399_10676 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTGC;
	Result = RTLNS(eif_new_type(950, 0x01).id, 950, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F949_6124(RTCW(Result), ((EIF_INTEGER_32) 128L));
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_0_);
	if (tb1) {
		tr1 = RTMS_EX_H(" -v",3,2108790);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(Result))-950])(Result, tr1);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_1_);
	if (tb1) {
		tr1 = RTMS_EX_H(" -d",3,2108772);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(Result))-950])(Result, tr1);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_2_);
	if (tb1) {
		tr1 = RTMS_EX_H(" -n",3,2108782);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(Result))-950])(Result, tr1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = F1233_8466(RTCW(tr1));
	F1053_7395(RTCW(loc1));
	for (;;) {
		tb1 = F1077_7423(RTCW(loc1));
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H("    [*geant] variable: ",23,271186464);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1088_7442(RTCW(loc1));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = RTMS_EX_H("=",1,61);
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1039_7375(RTCW(loc1));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10325(RTCW(tr1), tr2);
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = RTMS_EX_H(" -A\"",4,539836706);
		tr1 = F958_6417(RTCW(tr1), Result, tr2);
		Result = (EIF_REFERENCE) tr1;
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = F1088_7442(RTCW(loc1));
		tr1 = F958_6417(RTCW(tr1), Result, tr2);
		Result = (EIF_REFERENCE) tr1;
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = RTMS_EX_H("=",1,61);
		tr1 = F958_6417(RTCW(tr1), Result, tr2);
		Result = (EIF_REFERENCE) tr1;
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = F1039_7375(RTCW(loc1));
		tr1 = F958_6417(RTCW(tr1), Result, tr2);
		Result = (EIF_REFERENCE) tr1;
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = RTMS_EX_H("\"",1,34);
		tr1 = F958_6417(RTCW(tr1), Result, tr2);
		Result = (EIF_REFERENCE) tr1;
		F1053_7396(RTCW(loc1));
	}
	RTLE;
	return Result;
}

void EIF_Minit542 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
