/*
 * Code for class GEANT_DELETE_COMMAND
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge540.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_DELETE_COMMAND}.make */
void F1397_10630 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1395_10615(Current, arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {GEANT_DELETE_COMMAND}.is_file_executable */
EIF_BOOLEAN F1397_10631 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
		Result = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	RTLE;
	return Result;
}

/* {GEANT_DELETE_COMMAND}.is_directory_executable */
EIF_BOOLEAN F1397_10632 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
		Result = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	RTLE;
	return Result;
}

/* {GEANT_DELETE_COMMAND}.is_fileset_executable */
EIF_BOOLEAN F1397_10633 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL);
}

/* {GEANT_DELETE_COMMAND}.is_directoryset_executable */
EIF_BOOLEAN F1397_10634 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) != NULL);
}

/* {GEANT_DELETE_COMMAND}.is_executable */
EIF_BOOLEAN F1397_10635 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(2469,F267_2469, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {721,903,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 3L),sizeof(EIF_BOOLEAN), EIF_TRUE);
		RT_SPECIAL_COUNT(tr3) = 3L;
	}
	tb1 = F1397_10631(Current);
	*((EIF_BOOLEAN *)tr3+0) = (EIF_BOOLEAN) tb1;
	tb1 = F1397_10632(Current);
	*((EIF_BOOLEAN *)tr3+1) = (EIF_BOOLEAN) tb1;
	tb1 = '\01';
	if (!F1397_10633(Current)) {
		tb1 = F1397_10634(Current);
	}
	*((EIF_BOOLEAN *)tr3+2) = (EIF_BOOLEAN) tb1;
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F722_3978)(tr3);
	Result = F10_152(RTCW(tr1), tr2);
	RTLE;
	return Result;
}

/* {GEANT_DELETE_COMMAND}.set_directory */
void F1397_10641 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_DELETE_COMMAND}.set_file */
void F1397_10642 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_DELETE_COMMAND}.set_fileset */
void F1397_10643 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_DELETE_COMMAND}.set_directoryset */
void F1397_10644 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_DELETE_COMMAND}.set_fail_on_error */
void F1397_10645 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT_DELETE_COMMAND}.execute */
void F1397_10646 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	EIF_BOOLEAN tb7;
	RTCFDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLR(9,loc6);
	RTLIU(10);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tb1 = '\0';
	if (F1397_10632(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc3 = tr1;
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		tr1 = RTOSCF(8474,F1240_8474, (Current));
		tr2 = RTOSCF(8477,F1240_8477, (Current));
		loc1 = F1269_8951(RTCW(tr1), loc3, tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H("  [delete] ",11,631408416);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
		RTAR(tr3,loc1);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10323(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_2_);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = RTOSCF(8474,F1240_8474, (Current));
			F1270_8973(RTCW(tr1), loc1);
			tr1 = RTOSCF(8474,F1240_8474, (Current));
			tb1 = F1270_8968(RTCW(tr1), loc1);
			if (tb1) {
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				tr1 = RTOSCF(2207,F207_2207, (Current));
				F994_6719(RTCW(tr1), (EIF_INTEGER_64) ((EIF_INTEGER_32) 500000000L));
				tr1 = RTOSCF(8474,F1240_8474, (Current));
				F1270_8973(RTCW(tr1), loc1);
				for (;;) {
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 20L))) {
						tr1 = RTOSCF(8474,F1240_8474, (Current));
						tb2 = F1270_8968(RTCW(tr1), loc1);
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) break;
					tr1 = RTOSCF(2207,F207_2207, (Current));
					F994_6719(RTCW(tr1), (EIF_INTEGER_64) ((EIF_INTEGER_32) 500000000L));
					tr1 = RTOSCF(8474,F1240_8474, (Current));
					F1270_8973(RTCW(tr1), loc1);
					loc2++;
				}
				tr1 = RTOSCF(8474,F1240_8474, (Current));
				tb2 = F1270_8968(RTCW(tr1), loc1);
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current);
					{
						static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
						RT_SPECIAL_COUNT(tr3) = 3L;
						memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
					}
					tr4 = RTMS_EX_H("  [delete] error: cannot delete directory \'",43,76579879);
					*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
					RTAR(tr3,loc1);
					tr4 = RTMS_EX_H("\'",1,39);
					*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
					F1356_10324(RTCW(tr1), tr2);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				}
			}
		}
	} else {
		tb2 = '\0';
		if (F1397_10631(Current)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			loc4 = tr1;
			tb2 = EIF_TEST(loc4);
		}
		if (tb2) {
			tr1 = RTOSCF(8474,F1240_8474, (Current));
			tr2 = RTOSCF(8477,F1240_8477, (Current));
			loc1 = F1269_8951(RTCW(tr1), loc4, tr2);
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr3) = 2L;
				memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
			}
			tr4 = RTMS_EX_H("  [delete] ",11,631408416);
			*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
			RTAR(tr3,loc1);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
			F1356_10323(RTCW(tr1), tr2);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
			tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_2_);
			if ((EIF_BOOLEAN) !tb2) {
				tr1 = RTOSCF(8474,F1240_8474, (Current));
				F1270_8966(RTCW(tr1), loc1);
				tr1 = RTOSCF(8474,F1240_8474, (Current));
				tb2 = F1270_8957(RTCW(tr1), loc1);
				if (tb2) {
					loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					tr1 = RTOSCF(2207,F207_2207, (Current));
					F994_6719(RTCW(tr1), (EIF_INTEGER_64) ((EIF_INTEGER_32) 500000000L));
					tr1 = RTOSCF(8474,F1240_8474, (Current));
					F1270_8966(RTCW(tr1), loc1);
					for (;;) {
						tb2 = '\01';
						if (!(EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 20L))) {
							tr1 = RTOSCF(8474,F1240_8474, (Current));
							tb3 = F1270_8957(RTCW(tr1), loc1);
							tb2 = (EIF_BOOLEAN) !tb3;
						}
						if (tb2) break;
						tr1 = RTOSCF(2207,F207_2207, (Current));
						F994_6719(RTCW(tr1), (EIF_INTEGER_64) ((EIF_INTEGER_32) 500000000L));
						tr1 = RTOSCF(8474,F1240_8474, (Current));
						F1270_8966(RTCW(tr1), loc1);
						loc2++;
					}
					tr1 = RTOSCF(8474,F1240_8474, (Current));
					tb3 = F1270_8957(RTCW(tr1), loc1);
					if (tb3) {
						tr1 = *(EIF_REFERENCE *)(Current);
						{
							static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
							RT_SPECIAL_COUNT(tr3) = 3L;
							memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
						}
						tr4 = RTMS_EX_H("geant error: cannot delete file \'",33,546054183);
						*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
						RTAR(tr3,loc1);
						tr4 = RTMS_EX_H("\'",1,39);
						*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
						F1356_10324(RTCW(tr1), tr2);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					}
				}
			}
		} else {
			tb3 = '\0';
			if (F1397_10633(Current)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				loc5 = tr1;
				tb3 = EIF_TEST(loc5);
			}
			if (tb3) {
				tb3 = F1259_8717(loc5);
				if ((EIF_BOOLEAN) !tb3) {
					tr1 = *(EIF_REFERENCE *)(Current);
					{
						static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
						RT_SPECIAL_COUNT(tr3) = 1L;
						memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
					}
					tr4 = RTMS_EX_H("  [delete] error: fileset definition wrong",42,628456551);
					*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
					F1356_10324(RTCW(tr1), tr2);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				}
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_0_) == ((EIF_INTEGER_32) 0L))) {
					F1259_8730(loc5, (EIF_BOOLEAN) 1);
					F1259_8743(loc5);
					F1259_8740(loc5);
					for (;;) {
						tb3 = '\01';
						tb4 = F1259_8722(loc5);
						if (!tb4) {
							tb3 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_0_) != ((EIF_INTEGER_32) 0L));
						}
						if (tb3) break;
						tr1 = RTOSCF(8474,F1240_8474, (Current));
						tr2 = F1259_8716(loc5);
						tr3 = RTOSCF(8477,F1240_8477, (Current));
						loc1 = F1269_8951(RTCW(tr1), tr2, tr3);
						tr1 = *(EIF_REFERENCE *)(Current);
						{
							static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
							RT_SPECIAL_COUNT(tr3) = 2L;
							memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
						}
						tr4 = RTMS_EX_H("  [delete] ",11,631408416);
						*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
						RTAR(tr3,loc1);
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
						F1356_10323(RTCW(tr1), tr2);
						tr1 = *(EIF_REFERENCE *)(Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
						tb4 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_2_);
						if ((EIF_BOOLEAN) !tb4) {
							tr1 = RTOSCF(8474,F1240_8474, (Current));
							F1270_8966(RTCW(tr1), loc1);
							tr1 = RTOSCF(8474,F1240_8474, (Current));
							tb4 = F1270_8957(RTCW(tr1), loc1);
							if (tb4) {
								loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								tr1 = RTOSCF(2207,F207_2207, (Current));
								F994_6719(RTCW(tr1), (EIF_INTEGER_64) ((EIF_INTEGER_32) 500000000L));
								tr1 = RTOSCF(8474,F1240_8474, (Current));
								F1270_8966(RTCW(tr1), loc1);
								for (;;) {
									tb4 = '\01';
									if (!(EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 20L))) {
										tr1 = RTOSCF(8474,F1240_8474, (Current));
										tb5 = F1270_8957(RTCW(tr1), loc1);
										tb4 = (EIF_BOOLEAN) !tb5;
									}
									if (tb4) break;
									tr1 = RTOSCF(2207,F207_2207, (Current));
									F994_6719(RTCW(tr1), (EIF_INTEGER_64) ((EIF_INTEGER_32) 500000000L));
									tr1 = RTOSCF(8474,F1240_8474, (Current));
									F1270_8966(RTCW(tr1), loc1);
									loc2++;
								}
								tr1 = RTOSCF(8474,F1240_8474, (Current));
								tb5 = F1270_8957(RTCW(tr1), loc1);
								if (tb5) {
									tr1 = *(EIF_REFERENCE *)(Current);
									{
										static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
										EIF_TYPE typres0;
										static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
										
										typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
										tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
										RT_SPECIAL_COUNT(tr3) = 3L;
										memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
									}
									tr4 = RTMS_EX_H("geant error: cannot delete file \'",33,546054183);
									*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
									RTAR(tr3,loc1);
									tr4 = RTMS_EX_H("\'",1,39);
									*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
									F1356_10324(RTCW(tr1), tr2);
									*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								}
							}
						}
						F1259_8741(loc5);
					}
				}
			}
			tb5 = '\0';
			if (F1397_10634(Current)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				loc6 = tr1;
				tb5 = EIF_TEST(loc6);
			}
			if (tb5) {
				tb5 = F1258_8669(loc6);
				if ((EIF_BOOLEAN) !tb5) {
					tr1 = *(EIF_REFERENCE *)(Current);
					{
						static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
						RT_SPECIAL_COUNT(tr3) = 1L;
						memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
					}
					tr4 = RTMS_EX_H("  [delete] error: directoryset definition wrong",47,260171879);
					*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
					RTAR(tr3,tr4);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
					F1356_10324(RTCW(tr1), tr2);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				}
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_0_) == ((EIF_INTEGER_32) 0L))) {
					F1258_8692(loc6);
					F1258_8690(loc6);
					for (;;) {
						tb5 = '\01';
						tb6 = F1258_8677(loc6);
						if (!tb6) {
							tb5 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_0_) != ((EIF_INTEGER_32) 0L));
						}
						if (tb5) break;
						tr1 = RTOSCF(8474,F1240_8474, (Current));
						tr2 = F1258_8678(loc6);
						tr3 = RTOSCF(8477,F1240_8477, (Current));
						loc1 = F1269_8951(RTCW(tr1), tr2, tr3);
						tr1 = *(EIF_REFERENCE *)(Current);
						{
							static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
							RT_SPECIAL_COUNT(tr3) = 2L;
							memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
						}
						tr4 = RTMS_EX_H("  [delete] ",11,631408416);
						*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
						RTAR(tr3,loc1);
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
						F1356_10323(RTCW(tr1), tr2);
						tr1 = *(EIF_REFERENCE *)(Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
						tb6 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_2_);
						if ((EIF_BOOLEAN) !tb6) {
							tr1 = RTOSCF(8474,F1240_8474, (Current));
							F1270_8973(RTCW(tr1), loc1);
							tr1 = RTOSCF(8474,F1240_8474, (Current));
							tb6 = F1270_8968(RTCW(tr1), loc1);
							if (tb6) {
								loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								tr1 = RTOSCF(2207,F207_2207, (Current));
								F994_6719(RTCW(tr1), (EIF_INTEGER_64) ((EIF_INTEGER_32) 500000000L));
								tr1 = RTOSCF(8474,F1240_8474, (Current));
								F1270_8973(RTCW(tr1), loc1);
								for (;;) {
									tb6 = '\01';
									if (!(EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 20L))) {
										tr1 = RTOSCF(8474,F1240_8474, (Current));
										tb7 = F1270_8968(RTCW(tr1), loc1);
										tb6 = (EIF_BOOLEAN) !tb7;
									}
									if (tb6) break;
									tr1 = RTOSCF(2207,F207_2207, (Current));
									F994_6719(RTCW(tr1), (EIF_INTEGER_64) ((EIF_INTEGER_32) 500000000L));
									tr1 = RTOSCF(8474,F1240_8474, (Current));
									F1270_8973(RTCW(tr1), loc1);
									loc2++;
								}
								tr1 = RTOSCF(8474,F1240_8474, (Current));
								tb7 = F1270_8968(RTCW(tr1), loc1);
								if (tb7) {
									tr1 = *(EIF_REFERENCE *)(Current);
									{
										static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
										EIF_TYPE typres0;
										static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
										
										typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
										tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
										RT_SPECIAL_COUNT(tr3) = 3L;
										memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
									}
									tr4 = RTMS_EX_H("  [delete] error: cannot delete directory \'",43,76579879);
									*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
									RTAR(tr3,loc1);
									tr4 = RTMS_EX_H("\'",1,39);
									*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
									F1356_10324(RTCW(tr1), tr2);
									*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								}
							}
						}
						F1258_8691(loc6);
					}
				}
			}
		}
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_6_0_)) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	RTLE;
}

void EIF_Minit540 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
