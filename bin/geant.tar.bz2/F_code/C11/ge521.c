/*
 * Code for class GEANT_DELETE_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge521.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_DELETE_TASK}.make */
void F1378_10451 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLR(6,loc2);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLIU(9);
	
	RTGC;
	F1374_10420(Current, arg1, arg2);
	tr1 = RTOSCF(10454,F1378_10454, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10454,F1378_10454, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1397_10641(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10455,F1378_10455, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10455,F1378_10455, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1397_10642(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10458,F1378_10458, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10458,F1378_10458, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1397_10645(RTCW(tr1), tb1);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTOSCF(10456,F1378_10456, (Current));
	loc2 = F1287_9185(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		loc3 = RTLNS(eif_new_type(1421, 0x01).id, 1421, _OBJSIZ_4_0_0_0_0_0_0_0_);
		F1422_11027(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_2_), loc2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_3_);
		F1397_10643(RTCW(tr1), tr2);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTOSCF(10457,F1378_10457, (Current));
	loc2 = F1287_9185(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		loc4 = RTLNS(eif_new_type(1371, 0x01).id, 1371, _OBJSIZ_4_0_0_0_0_0_0_0_);
		F1372_10412(RTCW(loc4), *(EIF_REFERENCE *)(Current + _REFACS_2_), loc2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_3_);
		F1397_10644(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {GEANT_DELETE_TASK}.build_command */
void F1378_10452 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7829,Y7829_gen_type,Dftype(Current),1373).id);
	F1397_10630(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_DELETE_TASK}.directory_attribute_name */
static EIF_REFERENCE F1378_10454_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10454);
#define Result RTOSR(10454)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("directory",9,1028911737);
	RTOSE (10454);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1378_10454 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10454,F1378_10454_body,(Current));
}

/* {GEANT_DELETE_TASK}.file_attribute_name */
static EIF_REFERENCE F1378_10455_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10455);
#define Result RTOSR(10455)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("file",4,1718185061);
	RTOSE (10455);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1378_10455 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10455,F1378_10455_body,(Current));
}

/* {GEANT_DELETE_TASK}.fileset_element_name */
static EIF_REFERENCE F1378_10456_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10456);
#define Result RTOSR(10456)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("fileset",7,1708094836);
	RTOSE (10456);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1378_10456 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10456,F1378_10456_body,(Current));
}

/* {GEANT_DELETE_TASK}.directoryset_element_name */
static EIF_REFERENCE F1378_10457_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10457);
#define Result RTOSR(10457)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("directoryset",12,692757108);
	RTOSE (10457);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1378_10457 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10457,F1378_10457_body,(Current));
}

/* {GEANT_DELETE_TASK}.fail_on_error_attribute_name */
static EIF_REFERENCE F1378_10458_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10458);
#define Result RTOSR(10458)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("fail_on_error",13,1476151666);
	RTOSE (10458);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1378_10458 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10458,F1378_10458_body,(Current));
}

void EIF_Minit521 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
