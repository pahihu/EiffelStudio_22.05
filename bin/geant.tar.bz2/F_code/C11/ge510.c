/*
 * Code for class GEANT_INTERPRETING_ELEMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge510.h"
#include "eif_plug.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_INTERPRETING_ELEMENT}.make */
void F1367_10386 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,tr4);
	RTLIU(8);
	
	RTGC;
	F1362_10362(Current, arg2);
	F1367_10389(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_9_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = F32_378(loc1, *(EIF_REFERENCE *)(Current));
		if (tb1) {
			tr1 = F32_379(loc1, *(EIF_REFERENCE *)(Current));
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr3) = 3L;
				memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
			}
			tr4 = RTMS_EX_H("  [*GEANT_INTERPRETING_ELEMENT] position Void for element \'",59,605258279);
			*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = *(EIF_REFERENCE *)(Current);
			tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + _REFACS_1_);
			*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr4 = RTMS_EX_H("\'",1,39);
			*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
			F1356_10325(RTCW(tr1), tr2);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H("  [*GEANT_INTERPRETING_ELEMENT] project.position_table is Void",62,1609227620);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10325(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {GEANT_INTERPRETING_ELEMENT}.is_enabled */
EIF_BOOLEAN F1367_10388 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc4);
	RTLR(4,loc3);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,loc5);
	RTLIU(8);
	
	RTGC;
	tr1 = RTOSCF(10206,F1349_10206, (Current));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_3_);
	F1351_10238(RTCW(tr1), tr2);
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTOSCF(10394,F1367_10394, (Current));
	tr1 = F1287_9188(RTCW(tr1), tr2);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc3 = *(EIF_REFERENCE *)(loc4 + _REFACS_3_);
		tr1 = RTOSCF(10206,F1349_10206, (Current));
		loc1 = F1351_10235(RTCW(tr1), loc3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H(" if: \'",6,1778806311);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc3;
		RTAR(tr3,loc3);
		tr4 = RTMS_EX_H("\': ",3,2570784);
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = (loc1 ? makestr ("True", 4) : makestr ("False", 5));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10325(RTCW(tr1), tr2);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTOSCF(10395,F1367_10395, (Current));
	tr1 = F1287_9188(RTCW(tr1), tr2);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		loc3 = *(EIF_REFERENCE *)(loc5 + _REFACS_3_);
		tr1 = RTOSCF(10206,F1349_10206, (Current));
		loc2 = F1351_10235(RTCW(tr1), loc3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H(" unless: \'",10,1141060647);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc3;
		RTAR(tr3,loc3);
		tr4 = RTMS_EX_H("\'=",2,10045);
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = (loc2 ? makestr ("True", 4) : makestr ("False", 5));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10325(RTCW(tr1), tr2);
	}
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (loc1 && (EIF_BOOLEAN) !loc2);
}

/* {GEANT_INTERPRETING_ELEMENT}.set_project */
void F1367_10389 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_INTERPRETING_ELEMENT}.attribute_value */
EIF_REFERENCE F1367_10390 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLR(5,loc1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = F1287_9188(RTCW(tr1), arg1);
	RTCT0("precondition", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_3_);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(Result != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		loc1 = RTLNS(eif_new_type(1297, 0x01).id, 1297, _OBJSIZ_2_0_0_0_0_0_0_0_);
		tr1 = RTOSCF(10206,F1349_10206, (Current));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_3_);
		F1351_10238(RTCW(tr1), tr2);
		tr1 = RTOSCF(10206,F1349_10206, (Current));
		F1298_9342(RTCW(loc1), tr1);
		tr1 = F1298_9340(RTCW(loc1), Result);
		Result = (EIF_REFERENCE) tr1;
	}
	RTLE;
	return Result;
}

/* {GEANT_INTERPRETING_ELEMENT}.attribute_value_or_default */
EIF_REFERENCE F1367_10391 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = F1287_9180(RTCW(tr1), arg1);
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) F1367_10390(Current, arg1);
	} else {
		RTLE;
		return (EIF_REFERENCE) arg2;
	}/* NOTREACHED */
	
}

/* {GEANT_INTERPRETING_ELEMENT}.content */
EIF_REFERENCE F1367_10392 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1285_9137(RTCW(tr1));
	if ((EIF_BOOLEAN)(Result != NULL)) {
		tb1 = F641_3592(RTCW(Result));
		if ((EIF_BOOLEAN) !tb1) {
			loc1 = RTLNS(eif_new_type(1297, 0x01).id, 1297, _OBJSIZ_2_0_0_0_0_0_0_0_);
			tr1 = RTOSCF(10206,F1349_10206, (Current));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_3_);
			F1351_10238(RTCW(tr1), tr2);
			tr1 = RTOSCF(10206,F1349_10206, (Current));
			F1298_9342(RTCW(loc1), tr1);
			tr1 = F1298_9340(RTCW(loc1), Result);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
	return Result;
}

/* {GEANT_INTERPRETING_ELEMENT}.dir_attribute_name */
static EIF_REFERENCE F1367_10393_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10393);
#define Result RTOSR(10393)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("dir",3,6580594);
	RTOSE (10393);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1367_10393 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10393,F1367_10393_body,(Current));
}

/* {GEANT_INTERPRETING_ELEMENT}.if_attribute_name */
static EIF_REFERENCE F1367_10394_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10394);
#define Result RTOSR(10394)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("if",2,26982);
	RTOSE (10394);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1367_10394 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10394,F1367_10394_body,(Current));
}

/* {GEANT_INTERPRETING_ELEMENT}.unless_attribute_name */
static EIF_REFERENCE F1367_10395_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10395);
#define Result RTOSR(10395)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("unless",6,2049464179);
	RTOSE (10395);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1367_10395 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10395,F1367_10395_body,(Current));
}

void EIF_Minit510 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
