/*
 * Code for class GEANT_SETENV_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge518.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_SETENV_TASK}.make */
void F1375_10431 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	F1374_10420(Current, arg1, arg2);
	tr1 = RTOSCF(10434,F1375_10434, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10434,F1375_10434, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1396_10627(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10435,F1375_10435, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10435,F1375_10435, (Current));
		loc1 = F1367_10390(Current, tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1396_10628(RTCW(tr1), loc1);
	}
	RTLE;
}

/* {GEANT_SETENV_TASK}.build_command */
void F1375_10432 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7829,Y7829_gen_type,Dftype(Current),1373).id);
	F1395_10615(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_SETENV_TASK}.name_attribute_name */
static EIF_REFERENCE F1375_10434_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10434);
#define Result RTOSR(10434)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("name",4,1851878757);
	RTOSE (10434);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1375_10434 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10434,F1375_10434_body,(Current));
}

/* {GEANT_SETENV_TASK}.value_attribute_name */
static EIF_REFERENCE F1375_10435_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10435);
#define Result RTOSR(10435)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("value",5,1635404133);
	RTOSE (10435);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1375_10435 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10435,F1375_10435_body,(Current));
}

void EIF_Minit518 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
