/*
 * Code for class GEANT_RENAME_ELEMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge513.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_RENAME_ELEMENT}.make */
void F1370_10402 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	F1367_10386(Current, arg1, arg2);
	tr1 = RTLNSMART(eif_new_type(985, 1).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(10404,F1370_10404, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10404,F1370_10404, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F986_6678(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10405,F1370_10405, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10405,F1370_10405, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F986_6679(RTCW(tr1), loc1);
		}
	}
	RTLE;
}

/* {GEANT_RENAME_ELEMENT}.target_attribute_name */
static EIF_REFERENCE F1370_10404_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10404);
#define Result RTOSR(10404)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("target",6,709236);
	RTOSE (10404);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1370_10404 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10404,F1370_10404_body,(Current));
}

/* {GEANT_RENAME_ELEMENT}.as_attribute_name */
static EIF_REFERENCE F1370_10405_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10405);
#define Result RTOSR(10405)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("as",2,24947);
	RTOSE (10405);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1370_10405 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10405,F1370_10405_body,(Current));
}

void EIF_Minit513 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
