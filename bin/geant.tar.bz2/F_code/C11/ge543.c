/*
 * Code for class GEANT_GETEST_COMMAND
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge543.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_GETEST_COMMAND}.make */
void F1400_10678 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	F1395_10615(Current, arg1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1232,0xFF01,950,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1223_8389(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	loc1 = RTLNS(eif_new_type(989, 0x01).id, 989, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1223_8407(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {GEANT_GETEST_COMMAND}.is_executable */
EIF_BOOLEAN F1400_10679 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
		Result = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	RTLE;
	return Result;
}

/* {GEANT_GETEST_COMMAND}.set_verbose */
void F1400_10691 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT_GETEST_COMMAND}.set_config_filename */
void F1400_10692 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_GETEST_COMMAND}.set_compile */
void F1400_10693 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_GETEST_COMMAND}.set_class_regexp */
void F1400_10694 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_GETEST_COMMAND}.set_feature_regexp */
void F1400_10695 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_GETEST_COMMAND}.set_default_test_included */
void F1400_10696 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT_GETEST_COMMAND}.set_generation */
void F1400_10697 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT_GETEST_COMMAND}.set_compilation */
void F1400_10698 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_3_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT_GETEST_COMMAND}.set_execution */
void F1400_10699 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_4_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT_GETEST_COMMAND}.set_abort */
void F1400_10700 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_7_5_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT_GETEST_COMMAND}.execute */
void F1400_10701 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,loc1);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLR(9,loc6);
	RTLR(10,loc7);
	RTLR(11,loc2);
	RTLIU(12);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_7_3_)) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_7_4_))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H("  [getest] ",11,632034080);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = RTMS_EX_H("no generation, no compilation, no execution",43,1395823214);
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10323(RTCW(tr1), tr2);
	} else {
		loc1 = RTLNS(eif_new_type(950, 0x01).id, 950, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F949_6124(RTCW(loc1), ((EIF_INTEGER_32) 128L));
		tr1 = RTMS_EX_H("getest ",7,56132384);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_)) {
			tr1 = RTMS_EX_H("--verbose ",10,650232608);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
		}
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_7_2_)) {
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_7_3_)) {
				tr1 = RTMS_EX_H("-e ",3,2975008);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
			} else {
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_7_4_)) {
					tr1 = RTMS_EX_H("-c ",3,2974496);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
				} else {
					tr1 = RTMS_EX_H("-c -e ",6,629079840);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
				}
			}
		} else {
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_7_3_)) {
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_7_4_)) {
					tr1 = RTMS_EX_H("-g ",3,2975520);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
				} else {
					tr1 = RTMS_EX_H("-g -e ",6,629110560);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
				}
			} else {
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_7_4_)) {
					tr1 = RTMS_EX_H("-g -c ",6,629110048);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
				}
			}
		}
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_5_)) {
			tr1 = RTMS_EX_H("-a ",3,2973984);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_11_0_0_8_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			loc3 = F1233_8466(RTCW(tr1));
			F1053_7395(RTCW(loc3));
			for (;;) {
				tb1 = F1077_7423(RTCW(loc3));
				if (tb1) break;
				tr1 = RTMS_EX_H("--define=\"",10,604841250);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
				tr1 = RTOSCF(6466,F971_6466, (Current));
				tr2 = F1088_7442(RTCW(loc3));
				tr1 = F958_6417(RTCW(tr1), loc1, tr2);
				loc1 = (EIF_REFERENCE) tr1;
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(loc1))-950])(loc1, (EIF_CHARACTER_8) '=');
				tr1 = RTOSCF(6466,F971_6466, (Current));
				tr2 = F1039_7375(RTCW(loc3));
				tr1 = F958_6417(RTCW(tr1), loc1, tr2);
				loc1 = (EIF_REFERENCE) tr1;
				tr1 = RTMS_EX_H("\" ",2,8736);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
				F1053_7396(RTCW(loc3));
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			tr1 = RTMS_EX_H("--compile=\"",11,1673664034);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr1 = F958_6417(RTCW(tr1), loc1, loc4);
			loc1 = (EIF_REFERENCE) tr1;
			tr1 = RTMS_EX_H("\" ",2,8736);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			tr1 = RTMS_EX_H("--class=\"",9,955926050);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr1 = F958_6417(RTCW(tr1), loc1, loc5);
			loc1 = (EIF_REFERENCE) tr1;
			tr1 = RTMS_EX_H("\" ",2,8736);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			tr1 = RTMS_EX_H("--feature=\"",11,212088866);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr1 = F958_6417(RTCW(tr1), loc1, loc6);
			loc1 = (EIF_REFERENCE) tr1;
			tr1 = RTMS_EX_H("\" ",2,8736);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
		}
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_1_)) {
			tr1 = RTMS_EX_H("--default_test ",15,806579488);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
		}
		RTCT0("is_executable", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = RTOSCF(8474,F1240_8474, (Current));
		tr2 = RTOSCF(8477,F1240_8477, (Current));
		loc2 = F1269_8951(RTCW(tr1), loc7, tr2);
		tr1 = RTOSCF(8474,F1240_8474, (Current));
		tr2 = RTOSCF(8477,F1240_8477, (Current));
		loc2 = F1269_8951(RTCW(tr1), loc7, tr2);
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr1 = F958_6417(RTCW(tr1), loc1, loc2);
		loc1 = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H("  [getest] ",11,632034080);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
		RTAR(tr3,loc1);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10323(RTCW(tr1), tr2);
		F1395_10623(Current, loc1);
	}
	RTLE;
}

void EIF_Minit543 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
