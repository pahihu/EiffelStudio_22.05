/*
 * Code for class GEANT_MKDIR_COMMAND
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge541.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_MKDIR_COMMAND}.make */
void F1398_10647 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	F1395_10615(Current, arg1);
	tr1 = RTLNSMART(eif_new_type(1360, 1).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,129,0xFF01,938,0xFF01,0xFFF9,1,864,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,864,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,938,0xFF01,0xFFF9,1,864,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A541_71_2, (EIF_POINTER) _A541_71_2, (EIF_POINTER)(F1398_10652),tr2, 1, 1);
	}
	F130_1565(RTCW(tr1), tr5);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_MKDIR_COMMAND}.is_executable */
EIF_BOOLEAN F1398_10648 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,130,903,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 130, _OBJSIZ_0_1_0_0_0_0_0_0_);
	}
	F131_1565(RTCW(loc1), (EIF_BOOLEAN) 1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1358_10353(RTCW(tr1));
	tr1 = RTMS_EX_H("  [mkdir] error: \'directory\' is not defined",43,1152448868);
	F1395_10622(Current, tb1, tr1, loc1);
	tb1 = '\0';
	tb2 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_0_0_);
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = F1361_10361(RTCW(tr1));
		tb2 = F641_3592(RTCW(tr1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	tr1 = RTMS_EX_H("  [mkdir] error: \'directory\' is empty",37,854196601);
	F1395_10622(Current, tb1, tr1, loc1);
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_0_0_);
	RTLE;
	return (EIF_BOOLEAN) tb1;
}

/* {GEANT_MKDIR_COMMAND}.execute */
void F1398_10651 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = F1361_10361(RTCW(tr2));
	(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_3_0_0_))(
		*(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_3_0_1_),
		*(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_), tr2);
	RTLE;
}

/* {GEANT_MKDIR_COMMAND}.create_directory */
void F1398_10652 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = RTOSCF(8474,F1240_8474, (Current));
	tr2 = RTOSCF(8477,F1240_8477, (Current));
	loc1 = F1269_8951(RTCW(tr1), arg1, tr2);
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr3) = 2L;
		memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
	}
	tr4 = RTMS_EX_H("  [mkdir] ",10,769049888);
	*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
	RTAR(tr3,loc1);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
	F1356_10323(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_2_);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(8474,F1240_8474, (Current));
		F1270_8971(RTCW(tr1), loc1);
		tr1 = RTOSCF(8474,F1240_8474, (Current));
		tb1 = F1270_8968(RTCW(tr1), loc1);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr3) = 3L;
				memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
			}
			tr4 = RTMS_EX_H("  [mkdir] error: cannot create directory \'",42,1581807143);
			*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
			RTAR(tr3,loc1);
			tr4 = RTMS_EX_H("\'",1,39);
			*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
			F1356_10324(RTCW(tr1), tr2);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
	}
	RTLE;
}

void EIF_Minit541 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
