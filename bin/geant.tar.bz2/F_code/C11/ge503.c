/*
 * Code for class GEANT_BOOLEAN_PROPERTY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge503.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_BOOLEAN_PROPERTY}.value */
EIF_BOOLEAN F1360_10357 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1359_10349(Current);
	Result = F1360_10358(Current, tr1);
	RTLE;
	return Result;
}

/* {GEANT_BOOLEAN_PROPERTY}.boolean_value */
EIF_BOOLEAN F1360_10358 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(6466,F971_6466, (Current));
	tr2 = RTOSCF(10359,F1360_10359, (Current));
	tb1 = F958_6410(RTCW(tr1), tr2, arg1);
	if (tb1) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = RTOSCF(10360,F1360_10360, (Current));
		tb1 = F958_6410(RTCW(tr1), tr2, arg1);
		if (tb1) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
	}/* NOTREACHED */
	
}

/* {GEANT_BOOLEAN_PROPERTY}.true_attribute_value */
static EIF_REFERENCE F1360_10359_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10359);
#define Result RTOSR(10359)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("true",4,1953658213);
	RTOSE (10359);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1360_10359 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10359,F1360_10359_body,(Current));
}

/* {GEANT_BOOLEAN_PROPERTY}.false_attribute_value */
static EIF_REFERENCE F1360_10360_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10360);
#define Result RTOSR(10360)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("false",5,1635280741);
	RTOSE (10360);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1360_10360 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10360,F1360_10360_body,(Current));
}

void EIF_Minit503 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
