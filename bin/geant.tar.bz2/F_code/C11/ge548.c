/*
 * Code for class GEANT_SET_COMMAND
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge548.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_SET_COMMAND}.is_executable */
EIF_BOOLEAN F1405_10762 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		Result = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) != NULL);
	}
	RTLE;
	return Result;
}

/* {GEANT_SET_COMMAND}.set_name */
void F1405_10765 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_SET_COMMAND}.set_value */
void F1405_10766 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_SET_COMMAND}.execute */
void F1405_10767 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLIU(7);
	
	RTGC;
	RTCT0("is_executable", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = tr1;
	if ((EIF_BOOLEAN) (EIF_TEST(loc1) && EIF_TEST(loc2))) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = RTOSCF(10203,F1349_10203, (Current));
	tb1 = F1223_8402(RTCW(tr1), loc1);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTMS_EX_H("  [set] ",8,815583008);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = RTMS_EX_H("warning: you are using the name of the builtin variable \'",57,1256023591);
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) loc1;
		RTAR(tr3,loc1);
		tr4 = RTMS_EX_H("\' in a <set> task",17,1552060779);
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
		F1356_10324(RTCW(tr1), tr2);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_0_0_);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tb1 = F1356_10330(RTCW(tr1), loc1);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr3) = 4L;
				memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
			}
			tr4 = RTMS_EX_H("  [set local] ",14,2097201184);
			*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
			RTAR(tr3,loc1);
			tr4 = RTMS_EX_H("=",1,61);
			*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) loc2;
			RTAR(tr3,loc2);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
			F1356_10323(RTCW(tr1), tr2);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr3) = 4L;
				memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
			}
			tr4 = RTMS_EX_H("  [set global] ",15,489979424);
			*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
			RTAR(tr3,loc1);
			tr4 = RTMS_EX_H("=",1,61);
			*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
			RTAR(tr3,tr4);
			*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) loc2;
			RTAR(tr3,loc2);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
			F1356_10323(RTCW(tr1), tr2);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	F1356_10328(RTCW(tr1), loc1, loc2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

void EIF_Minit548 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
