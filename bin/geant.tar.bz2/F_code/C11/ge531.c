/*
 * Code for class GEANT_ISE_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge531.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_ISE_TASK}.make */
void F1388_10526 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	F1374_10420(Current, arg1, arg2);
	tr1 = RTOSCF(10529,F1388_10529, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10529,F1388_10529, (Current));
		tr2 = RTMS_EX_H("",0,0);
		loc1 = F1367_10391(Current, tr1, tr2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1408_10796(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10530,F1388_10530, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10530,F1388_10530, (Current));
		tr2 = RTMS_EX_H("",0,0);
		loc1 = F1367_10391(Current, tr1, tr2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1408_10796(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10531,F1388_10531, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10531,F1388_10531, (Current));
		tr2 = RTMS_EX_H("",0,0);
		loc1 = F1367_10391(Current, tr1, tr2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1408_10797(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10532,F1388_10532, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10532,F1388_10532, (Current));
		tr2 = RTMS_EX_H("",0,0);
		loc1 = F1367_10391(Current, tr1, tr2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1408_10798(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10536,F1388_10536, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10536,F1388_10536, (Current));
		tr2 = RTMS_EX_H("",0,0);
		loc1 = F1367_10391(Current, tr1, tr2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1408_10802(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10533,F1388_10533, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10533,F1388_10533, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1408_10799(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10534,F1388_10534, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10534,F1388_10534, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1408_10800(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10535,F1388_10535, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10535,F1388_10535, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1408_10801(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10537,F1388_10537, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10537,F1388_10537, (Current));
		tr2 = RTMS_EX_H("",0,0);
		loc1 = F1367_10391(Current, tr1, tr2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1408_10804(RTCW(tr1), loc1);
		}
	} else {
		tr1 = RTOSCF(10538,F1388_10538, (Current));
		if (F1362_10376(Current, tr1)) {
			tr1 = RTOSCF(10538,F1388_10538, (Current));
			tr2 = RTMS_EX_H("",0,0);
			loc1 = F1367_10391(Current, tr1, tr2);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				F1408_10804(RTCW(tr1), loc1);
			}
		}
	}
	tr1 = RTOSCF(10539,F1388_10539, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10539,F1388_10539, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1408_10803(RTCW(tr1), loc1);
		}
	}
	RTLE;
}

/* {GEANT_ISE_TASK}.build_command */
void F1388_10527 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7829,Y7829_gen_type,Dftype(Current),1373).id);
	F1395_10615(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_ISE_TASK}.ace_attribute_name */
static EIF_REFERENCE F1388_10529_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10529);
#define Result RTOSR(10529)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("ace",3,6382437);
	RTOSE (10529);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1388_10529 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10529,F1388_10529_body,(Current));
}

/* {GEANT_ISE_TASK}.ecf_attribute_name */
static EIF_REFERENCE F1388_10530_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10530);
#define Result RTOSR(10530)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("ecf",3,6644582);
	RTOSE (10530);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1388_10530 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10530,F1388_10530_body,(Current));
}

/* {GEANT_ISE_TASK}.target_attribute_name */
static EIF_REFERENCE F1388_10531_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10531);
#define Result RTOSR(10531)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("target",6,709236);
	RTOSE (10531);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1388_10531 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10531,F1388_10531_body,(Current));
}

/* {GEANT_ISE_TASK}.system_attribute_name */
static EIF_REFERENCE F1388_10532_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10532);
#define Result RTOSR(10532)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("system",6,16556653);
	RTOSE (10532);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1388_10532 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10532,F1388_10532_body,(Current));
}

/* {GEANT_ISE_TASK}.compatible_attribute_name */
static EIF_REFERENCE F1388_10533_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10533);
#define Result RTOSR(10533)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("compatible",10,682869349);
	RTOSE (10533);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1388_10533 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10533,F1388_10533_body,(Current));
}

/* {GEANT_ISE_TASK}.finalize_attribute_name */
static EIF_REFERENCE F1388_10534_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10534);
#define Result RTOSR(10534)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("finalize",8,1220601701);
	RTOSE (10534);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1388_10534 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10534,F1388_10534_body,(Current));
}

/* {GEANT_ISE_TASK}.finish_freezing_attribute_name */
static EIF_REFERENCE F1388_10535_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10535);
#define Result RTOSR(10535)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("finish_freezing",15,427748711);
	RTOSE (10535);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1388_10535 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10535,F1388_10535_body,(Current));
}

/* {GEANT_ISE_TASK}.clean_attribute_name */
static EIF_REFERENCE F1388_10536_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10536);
#define Result RTOSR(10536)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("clean",5,1819343726);
	RTOSE (10536);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1388_10536 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10536,F1388_10536_body,(Current));
}

/* {GEANT_ISE_TASK}.project_path_attribute_name */
static EIF_REFERENCE F1388_10537_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10537);
#define Result RTOSR(10537)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("project_path",12,498849384);
	RTOSE (10537);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1388_10537 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10537,F1388_10537_body,(Current));
}

/* {GEANT_ISE_TASK}.old_project_path_attribute_name */
static EIF_REFERENCE F1388_10538_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10538);
#define Result RTOSR(10538)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("project-path",12,498465384);
	RTOSE (10538);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1388_10538 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10538,F1388_10538_body,(Current));
}

/* {GEANT_ISE_TASK}.exit_code_variable_attribute_name */
static EIF_REFERENCE F1388_10539_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10539);
#define Result RTOSR(10539)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("exit_code_variable",18,2096751205);
	RTOSE (10539);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1388_10539 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10539,F1388_10539_body,(Current));
}

void EIF_Minit531 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
