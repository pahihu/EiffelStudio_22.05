/*
 * Code for class GEANT_UNSET_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge527.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_UNSET_TASK}.make */
void F1384_10508 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	F1374_10420(Current, arg1, arg2);
	tr1 = RTOSCF(10511,F1384_10511, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10511,F1384_10511, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1404_10760(RTCW(tr1), loc1);
		}
	}
	RTLE;
}

/* {GEANT_UNSET_TASK}.build_command */
void F1384_10509 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7829,Y7829_gen_type,Dftype(Current),1373).id);
	F1395_10615(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_UNSET_TASK}.name_attribute_name */
static EIF_REFERENCE F1384_10511_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10511);
#define Result RTOSR(10511)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("name",4,1851878757);
	RTOSE (10511);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1384_10511 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10511,F1384_10511_body,(Current));
}

void EIF_Minit527 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
