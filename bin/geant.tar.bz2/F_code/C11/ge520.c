/*
 * Code for class GEANT_COPY_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge520.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_COPY_TASK}.make */
void F1377_10443 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLR(6,loc2);
	RTLR(7,loc3);
	RTLIU(8);
	
	RTGC;
	F1374_10420(Current, arg1, arg2);
	tr1 = RTOSCF(10446,F1377_10446, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10446,F1377_10446, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1415_10901(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10447,F1377_10447, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10447,F1377_10447, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1415_10902(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10448,F1377_10448, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10448,F1377_10448, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1415_10903(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10449,F1377_10449, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10449,F1377_10449, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1415_10905(RTCW(tr1), tb1);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTOSCF(10450,F1377_10450, (Current));
	loc2 = F1287_9185(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		loc3 = RTLNS(eif_new_type(1421, 0x01).id, 1421, _OBJSIZ_4_0_0_0_0_0_0_0_);
		F1422_11027(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_2_), loc2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_3_);
		F1415_10904(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {GEANT_COPY_TASK}.build_command */
void F1377_10444 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7829,Y7829_gen_type,Dftype(Current),1373).id);
	F1395_10615(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_COPY_TASK}.file_attribute_name */
static EIF_REFERENCE F1377_10446_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10446);
#define Result RTOSR(10446)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("file",4,1718185061);
	RTOSE (10446);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1377_10446 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10446,F1377_10446_body,(Current));
}

/* {GEANT_COPY_TASK}.to_file_attribute_name */
static EIF_REFERENCE F1377_10447_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10447);
#define Result RTOSR(10447)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("to_file",7,192426597);
	RTOSE (10447);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1377_10447 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10447,F1377_10447_body,(Current));
}

/* {GEANT_COPY_TASK}.to_directory_attribute_name */
static EIF_REFERENCE F1377_10448_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10448);
#define Result RTOSR(10448)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("to_directory",12,832290425);
	RTOSE (10448);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1377_10448 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10448,F1377_10448_body,(Current));
}

/* {GEANT_COPY_TASK}.force_attribute_name */
static EIF_REFERENCE F1377_10449_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10449);
#define Result RTOSR(10449)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("force",5,1870550885);
	RTOSE (10449);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1377_10449 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10449,F1377_10449_body,(Current));
}

/* {GEANT_COPY_TASK}.fileset_element_name */
static EIF_REFERENCE F1377_10450_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10450);
#define Result RTOSR(10450)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("fileset",7,1708094836);
	RTOSE (10450);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1377_10450 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10450,F1377_10450_body,(Current));
}

void EIF_Minit520 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
