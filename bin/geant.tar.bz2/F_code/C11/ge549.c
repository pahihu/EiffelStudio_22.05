/*
 * Code for class GEANT_LCC_COMMAND
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge549.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_LCC_COMMAND}.is_executable */
EIF_BOOLEAN F1406_10768 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_1_1_0_2_);
			tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {GEANT_LCC_COMMAND}.set_executable */
void F1406_10771 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_LCC_COMMAND}.set_source_filename */
void F1406_10772 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {GEANT_LCC_COMMAND}.execute */
void F1406_10773 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,tr4);
	RTLIU(9);
	
	RTGC;
	RTCT0("is_executable", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc3 = tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc4 = tr1;
	if ((EIF_BOOLEAN) (EIF_TEST(loc3) && EIF_TEST(loc4))) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc1 = RTLNS(eif_new_type(950, 0x01).id, 950, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F949_6124(RTCW(loc1), ((EIF_INTEGER_32) 128L));
	tr1 = RTMS_EX_H("lcc",3,7103331);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
	tr1 = RTMS_EX_H(" -Fo",4,539838063);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
	tr1 = RTOSCF(8474,F1240_8474, (Current));
	tr2 = RTOSCF(8477,F1240_8477, (Current));
	loc2 = F1269_8951(RTCW(tr1), loc3, tr2);
	tr1 = RTOSCF(6466,F971_6466, (Current));
	tr1 = F958_6417(RTCW(tr1), loc1, loc2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H(" ",1,32);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(loc1))-950])(loc1, tr1);
	tr1 = RTOSCF(8474,F1240_8474, (Current));
	tr2 = RTOSCF(8477,F1240_8477, (Current));
	loc2 = F1269_8951(RTCW(tr1), loc4, tr2);
	tr1 = RTOSCF(6466,F971_6466, (Current));
	tr1 = F958_6417(RTCW(tr1), loc1, loc2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr3) = 2L;
		memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
	}
	tr4 = RTMS_EX_H("  [lcc] ",8,780860704);
	*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
	RTAR(tr3,tr4);
	*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) loc1;
	RTAR(tr3,loc1);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr3);
	F1356_10323(RTCW(tr1), tr2);
	F1395_10623(Current, loc1);
	RTLE;
}

void EIF_Minit549 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
