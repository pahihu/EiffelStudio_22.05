/*
 * Code for class GEANT_GEYACC_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge524.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_GEYACC_TASK}.make */
void F1381_10478 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	F1374_10420(Current, arg1, arg2);
	tr1 = RTOSCF(10481,F1381_10481, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10481,F1381_10481, (Current));
		loc1 = F1367_10390(Current, tr1);
		tb1 = F943_5858(RTCW(loc1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1401_10712(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10482,F1381_10482, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10482,F1381_10482, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1401_10714(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10483,F1381_10483, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10483,F1381_10483, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1401_10715(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10484,F1381_10484, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10484,F1381_10484, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1401_10713(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10485,F1381_10485, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10485,F1381_10485, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1401_10716(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10486,F1381_10486, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10486,F1381_10486, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1401_10717(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10487,F1381_10487, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10487,F1381_10487, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1401_10718(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10488,F1381_10488, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10488,F1381_10488, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1401_10719(RTCW(tr1), loc1);
		}
	}
	RTLE;
}

/* {GEANT_GEYACC_TASK}.build_command */
void F1381_10479 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7829,Y7829_gen_type,Dftype(Current),1373).id);
	F1401_10702(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_GEYACC_TASK}.array_size_attribute_name */
static EIF_REFERENCE F1381_10481_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10481);
#define Result RTOSR(10481)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("array_size",10,1982128229);
	RTOSE (10481);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1381_10481 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10481,F1381_10481_body,(Current));
}

/* {GEANT_GEYACC_TASK}.rescue_on_abort_attribute_name */
static EIF_REFERENCE F1381_10482_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10482);
#define Result RTOSR(10482)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("rescue_on_abort",15,2089833076);
	RTOSE (10482);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1381_10482 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10482,F1381_10482_body,(Current));
}

/* {GEANT_GEYACC_TASK}.separate_actions_attribute_name */
static EIF_REFERENCE F1381_10483_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10483);
#define Result RTOSR(10483)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("separate_actions",16,897573491);
	RTOSE (10483);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1381_10483 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10483,F1381_10483_body,(Current));
}

/* {GEANT_GEYACC_TASK}.verbose_filename_attribute_name */
static EIF_REFERENCE F1381_10484_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10484);
#define Result RTOSR(10484)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("verbose",7,1112830821);
	RTOSE (10484);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1381_10484 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10484,F1381_10484_body,(Current));
}

/* {GEANT_GEYACC_TASK}.tokens_classname_attribute_name */
static EIF_REFERENCE F1381_10485_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10485);
#define Result RTOSR(10485)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("tokens",6,2030727283);
	RTOSE (10485);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1381_10485 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10485,F1381_10485_body,(Current));
}

/* {GEANT_GEYACC_TASK}.tokens_filename_attribute_name */
static EIF_REFERENCE F1381_10486_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10486);
#define Result RTOSR(10486)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("tokens_file",11,1031239781);
	RTOSE (10486);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1381_10486 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10486,F1381_10486_body,(Current));
}

/* {GEANT_GEYACC_TASK}.output_filename_attribute_name */
static EIF_REFERENCE F1381_10487_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10487);
#define Result RTOSR(10487)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("output",6,25180788);
	RTOSE (10487);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1381_10487 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10487,F1381_10487_body,(Current));
}

/* {GEANT_GEYACC_TASK}.input_filename_attribute_name */
static EIF_REFERENCE F1381_10488_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10488);
#define Result RTOSR(10488)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("input",5,1853670260);
	RTOSE (10488);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1381_10488 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10488,F1381_10488_body,(Current));
}

void EIF_Minit524 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
