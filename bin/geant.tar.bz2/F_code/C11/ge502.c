/*
 * Code for class GEANT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge502.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT}.make */
void F1357_10333 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,loc4);
	RTLR(5,loc3);
	RTLR(6,loc6);
	RTLR(7,loc7);
	RTLR(8,loc2);
	RTLR(9,loc8);
	RTLR(10,loc1);
	RTLR(11,loc9);
	RTLR(12,loc10);
	RTLR(13,loc5);
	RTLIU(14);
	
	RTGC;
	tr1 = RTOSCF(2468,F266_2468, (Current));
	tr2 = RTMS_EX_H("geant",5,1701675124);
	F394_3383(RTCW(tr1), tr2);
	tr1 = RTLNSMART(eif_new_type(1273, 1).id);
	F1274_9042(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(10347,F1357_10347, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F1357_10341(Current);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_)) {
		tr1 = RTOSCF(10203,F1349_10203, (Current));
		tr2 = RTMS_EX_H("verbose",7,1112830821);
		tr3 = RTMS_EX_H("true",4,1953658213);
		F1238_8472(RTCW(tr1), tr2, tr3);
	}
	loc4 = RTLNS(eif_new_type(1353, 0x01).id, 1353, _OBJSIZ_11_0_0_9_0_0_0_0_);
	F1354_10273(RTCW(loc4));
	loc3 = RTLNS(eif_new_type(51, 0x01).id, 51, _OBJSIZ_0_4_0_0_0_0_0_0_);
	F52_666(RTCW(loc3), *(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_));
	F52_667(RTCW(loc3), *(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_));
	F52_668(RTCW(loc3), *(EIF_BOOLEAN *)(Current+ _CHROFF_3_3_));
	tr1 = RTOSCF(8474,F1240_8474, (Current));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr3 = RTOSCF(8477,F1240_8477, (Current));
	loc6 = F1269_8951(RTCW(tr1), tr2, tr3);
	tr1 = RTOSCF(8474,F1240_8474, (Current));
	tr2 = RTOSCF(8474,F1240_8474, (Current));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R6651[Dtype(RTCW(tr2))-1270])(tr2, loc6);
	loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R6643[Dtype(RTCW(tr1))-1270])(tr1, tr2);
	tr1 = RTMS_EX_H("current.absdir",14,1190523250);
	F1238_8472(RTCW(loc4), tr1, loc7);
	tr1 = RTOSCF(8474,F1240_8474, (Current));
	loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R6643[Dtype(RTCW(tr1))-1270])(tr1, loc6);
	tr1 = RTMS_EX_H("current.dir",11,548011890);
	F1238_8472(RTCW(loc4), tr1, loc7);
	tr1 = RTOSCF(8474,F1240_8474, (Current));
	loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R6642[Dtype(RTCW(tr1))-1270])(tr1, loc6);
	tr1 = RTMS_EX_H("current.filename",16,1341260389);
	F1238_8472(RTCW(loc4), tr1, loc7);
	loc2 = RTLNS(eif_new_type(1354, 0x01).id, 1354, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1355_10281(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	F1355_10284(RTCW(loc2), loc4, loc3);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_1_);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		loc1 = *(EIF_REFERENCE *)(loc8 + _REFACS_2_);
		F1356_10317(RTCW(loc1));
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc9 = tr1;
		if (EIF_TEST(loc9)) {
			ti4_1 = *(EIF_INTEGER_32 *)(loc9+ _LNGOFF_1_1_0_2_);
			tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
		}
		if (tb1) {
			tb1 = '\01';
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_5_);
			loc10 = tr1;
			if (!((EIF_BOOLEAN) !EIF_TEST(loc10))) {
				tb2 = F1223_8402(loc10, loc9);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				{
					static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
					RT_SPECIAL_COUNT(tr2) = 4L;
					memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
				}
				tr3 = RTMS_EX_H("Project \'",9,213807399);
				*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = *(EIF_REFERENCE *)(RTCW(loc1));
				*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = RTMS_EX_H("\' does not contain a target named `",35,2111554912);
				*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr3 = RTMS_EX_H("\'",1,39);
				tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4764[Dtype(loc9)-950])(loc9, tr3);
				*((EIF_REFERENCE *)tr2+3) = (EIF_REFERENCE) tr3;
				RTAR(tr2,tr3);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
				F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
			} else {
				loc5 = F1223_8394(loc10, loc9);
				tb1 = F1430_11123(RTCW(loc5));
				if ((EIF_BOOLEAN) !tb1) {
					{
						static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
						RT_SPECIAL_COUNT(tr2) = 3L;
						memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
					}
					tr3 = RTMS_EX_H("target: `",9,1971240032);
					*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = F1430_11111(RTCW(loc5));
					*((EIF_REFERENCE *)tr2+1) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr3 = RTMS_EX_H("\' is not exported.",18,919767086);
					*((EIF_REFERENCE *)tr2+2) = (EIF_REFERENCE) tr3;
					RTAR(tr2,tr3);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
					F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
				}
				F1356_10307(RTCW(loc1), loc9);
			}
		}
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_)) {
			F1356_10320(RTCW(loc1));
		} else {
			loc5 = F1356_10296(RTCW(loc1));
			tr1 = RTOSCF(10200,F1349_10200, (Current));
			F1356_10319(RTCW(loc1), tr1);
		}
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_13_0_);
		if ((EIF_BOOLEAN) !tb1) {
			F1349_10210(Current, ((EIF_INTEGER_32) 1L), NULL);
		}
	} else {
		F1349_10210(Current, ((EIF_INTEGER_32) 1L), NULL);
	}
	RTLE;
}

/* {GEANT}.read_command_line */
void F1357_10341 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(21);
	RTLR(0,loc10);
	RTLR(1,tr1);
	RTLR(2,loc9);
	RTLR(3,loc6);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLR(9,loc7);
	RTLR(10,loc8);
	RTLR(11,Current);
	RTLR(12,loc16);
	RTLR(13,loc11);
	RTLR(14,loc17);
	RTLR(15,loc13);
	RTLR(16,loc14);
	RTLR(17,loc15);
	RTLR(18,loc18);
	RTLR(19,tr2);
	RTLR(20,tr3);
	RTLIU(21);
	
	RTGC;
	loc10 = RTLNS(eif_new_type(1243, 0x01).id, 1243, _OBJSIZ_9_1_0_0_0_0_0_0_);
	F1244_8560(RTCW(loc10));
	tr1 = RTMS_EX_H("Geant is a general software build tool comparable to \'make\' or \'ant\'. In addition to its general purpose build capabilities, it has built-in support for the Eiffel programming language which makes it especially useful as a build tool for Eiffel projects.",254,573607470);
	F1243_8528(RTCW(loc10), tr1);
	tr1 = RTMS_EX_H("[starttarget]",13,1584860509);
	F1243_8530(RTCW(loc10), tr1);
	loc9 = RTLNS(eif_new_type(155, 0x01).id, 155, _OBJSIZ_5_6_0_1_0_0_0_0_);
	F154_1679(RTCW(loc9), (EIF_CHARACTER_8) 'A');
	tr1 = RTMS_EX_H("Define argument named \'variable\' with value \'value\' for \'starttarget\'.",70,1484818990);
	F154_1698(RTCW(loc9), tr1);
	tr1 = RTMS_EX_H("<variable>=<value>",18,1816608062);
	F155_1721(RTCW(loc9), tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc10) + _REFACS_3_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(tr1))-1184])(tr1, loc9);
	loc6 = RTLNS(eif_new_type(155, 0x01).id, 155, _OBJSIZ_5_6_0_1_0_0_0_0_);
	F154_1679(RTCW(loc6), (EIF_CHARACTER_8) 'D');
	tr1 = RTMS_EX_H("Define variable named \'variable\' with value \'value\'. If no value is supplied, True is assumed as value.",103,324171054);
	F154_1698(RTCW(loc6), tr1);
	tr1 = RTMS_EX_H("<variable>[=<value>]",20,1234125405);
	F155_1721(RTCW(loc6), tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc10) + _REFACS_3_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(tr1))-1184])(tr1, loc6);
	loc1 = RTLNS(eif_new_type(156, 0x01).id, 156, _OBJSIZ_2_4_0_2_0_0_0_0_);
	tr1 = RTMS_EX_H("version",7,1397649262);
	F154_1680(RTCW(loc1), tr1);
	tr1 = RTMS_EX_H("Show version",12,252553838);
	F154_1698(RTCW(loc1), tr1);
	loc2 = RTLNS(eif_new_type(1188, 0x01).id, 1188, _OBJSIZ_6_0_0_1_0_0_0_0_);
	F1189_8031(RTCW(loc2), loc1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc10));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(tr1))-1184])(tr1, loc2);
	loc3 = RTLNS(eif_new_type(156, 0x01).id, 156, _OBJSIZ_2_4_0_2_0_0_0_0_);
	tr1 = RTMS_EX_H("verbose",7,1112830821);
	F154_1678(RTCW(loc3), (EIF_CHARACTER_8) 'v', tr1);
	tr1 = RTMS_EX_H("Turn on verbose output",22,766109812);
	F154_1698(RTCW(loc3), tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc10) + _REFACS_3_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(tr1))-1184])(tr1, loc3);
	loc4 = RTLNS(eif_new_type(155, 0x01).id, 155, _OBJSIZ_5_6_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("buildfilename",13,773136229);
	F154_1678(RTCW(loc4), (EIF_CHARACTER_8) 'b', tr1);
	tr1 = RTMS_EX_H("Specify buildfile (default: \'build.eant\')",41,1693826857);
	F154_1698(RTCW(loc4), tr1);
	tr1 = RTMS_EX_H("<file>",6,1887459646);
	F155_1721(RTCW(loc4), tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc10) + _REFACS_3_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(tr1))-1184])(tr1, loc4);
	loc5 = RTLNS(eif_new_type(156, 0x01).id, 156, _OBJSIZ_2_4_0_2_0_0_0_0_);
	tr1 = RTMS_EX_H("noexec",6,1919510371);
	F154_1678(RTCW(loc5), (EIF_CHARACTER_8) 'n', tr1);
	tr1 = RTMS_EX_H("Do not execute tasks, just show what they would do",50,592011631);
	F154_1698(RTCW(loc5), tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc10) + _REFACS_3_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(tr1))-1184])(tr1, loc5);
	loc7 = RTLNS(eif_new_type(156, 0x01).id, 156, _OBJSIZ_2_4_0_2_0_0_0_0_);
	tr1 = RTMS_EX_H("debug",5,1701719399);
	F154_1678(RTCW(loc7), (EIF_CHARACTER_8) 'd', tr1);
	tr1 = RTMS_EX_H("Show internal messages",22,229120371);
	F154_1698(RTCW(loc7), tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc10) + _REFACS_3_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(tr1))-1184])(tr1, loc7);
	loc8 = RTLNS(eif_new_type(156, 0x01).id, 156, _OBJSIZ_2_4_0_2_0_0_0_0_);
	tr1 = RTMS_EX_H("targets",7,181564531);
	F154_1678(RTCW(loc8), (EIF_CHARACTER_8) 't', tr1);
	tr1 = RTMS_EX_H("List all targets",16,1917401715);
	F154_1698(RTCW(loc8), tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc10) + _REFACS_3_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(tr1))-1184])(tr1, loc8);
	F1243_8533(RTCW(loc10));
	tb1 = F154_1697(RTCW(loc1));
	if (tb1) {
		F1357_10346(Current);
	}
	tb1 = F154_1697(RTCW(loc3));
	F1357_10342(Current, tb1);
	tb1 = F154_1697(RTCW(loc5));
	F1357_10345(Current, tb1);
	tb1 = F154_1697(RTCW(loc7));
	F1357_10343(Current, tb1);
	tb1 = '\0';
	tb2 = F154_1697(RTCW(loc4));
	if (tb2) {
		tr1 = F155_1715(RTCW(loc4));
		loc16 = tr1;
		tb1 = EIF_TEST(loc16);
	}
	if (tb1) {
		RTAR(Current, loc16);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc16;
	}
	tb1 = F154_1697(RTCW(loc8));
	F1357_10344(Current, tb1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc9) + _REFACS_4_);
	loc11 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5961[Dtype(RTCW(tr1))-1184])(tr1);
	F1053_7395(RTCW(loc11));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2921[Dtype(RTCW(loc11))-437])(loc11);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2920[Dtype(RTCW(loc11))-437])(loc11);
		loc17 = tr1;
		if (EIF_TEST(loc17)) {
			loc12 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R4752[Dtype(loc17)-949])(loc17, (EIF_CHARACTER_8) '=', ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN) (loc12 > ((EIF_INTEGER_32) 0L))) {
				loc13 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4616[Dtype(loc17)-946])(loc17, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc12 - ((EIF_INTEGER_32) 1L)));
				ti4_1 = *(EIF_INTEGER_32 *)(loc17+ _LNGOFF_1_1_0_2_);
				loc14 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4616[Dtype(loc17)-946])(loc17, (EIF_INTEGER_32) (loc12 + ((EIF_INTEGER_32) 1L)), ti4_1);
				tr1 = RTOSCF(10200,F1349_10200, (Current));
				F1223_8414(RTCW(tr1), loc14, loc13);
			} else {
				loc15 = RTLNS(eif_new_type(1346, 0x01).id, 1346, _OBJSIZ_3_0_0_0_0_0_0_0_);
				F1347_10176(RTCW(loc15), loc9, loc17);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc10) + _REFACS_2_);
				F1274_9044(RTCW(tr1), loc15);
				F1243_8536(RTCW(loc10));
			}
		}
		F1053_7396(RTCW(loc11));
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(loc6) + _REFACS_4_);
	loc11 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5961[Dtype(RTCW(tr1))-1184])(tr1);
	F1053_7395(RTCW(loc11));
	for (;;) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2921[Dtype(RTCW(loc11))-437])(loc11);
		if (tb2) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2920[Dtype(RTCW(loc11))-437])(loc11);
		loc18 = tr1;
		if (EIF_TEST(loc18)) {
			loc12 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R4752[Dtype(loc18)-949])(loc18, (EIF_CHARACTER_8) '=', ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN) (loc12 > ((EIF_INTEGER_32) 0L))) {
				loc13 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4616[Dtype(loc18)-946])(loc18, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc12 - ((EIF_INTEGER_32) 1L)));
				ti4_1 = *(EIF_INTEGER_32 *)(loc18+ _LNGOFF_1_1_0_2_);
				loc14 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4616[Dtype(loc18)-946])(loc18, (EIF_INTEGER_32) (loc12 + ((EIF_INTEGER_32) 1L)), ti4_1);
				tr1 = RTOSCF(10199,F1349_10199, (Current));
				F1223_8414(RTCW(tr1), loc14, loc13);
			} else {
				tr1 = RTOSCF(10199,F1349_10199, (Current));
				tr2 = RTMS_EX_H("true",4,1953658213);
				F1223_8414(RTCW(tr1), tr2, loc18);
			}
		}
		F1053_7396(RTCW(loc11));
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(loc10) + _REFACS_4_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5929[Dtype(RTCW(tr1))-1184])(tr1);
	switch (ti4_1) {
		case 0L:
			break;
		case 1L:
			tr1 = *(EIF_REFERENCE *)(RTCW(loc10) + _REFACS_4_);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5982[Dtype(RTCW(tr1))-1184])(tr1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
			break;
		default:
			{
				static EIF_TYPE_INDEX typarr0[] = {712,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
				RT_SPECIAL_COUNT(tr2) = 1L;
				memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
			}
			tr3 = RTMS_EX_H("Too many targets.",17,442328110);
			*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
			RTAR(tr2,tr3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F713_3978)(tr2);
			F1349_10210(Current, ((EIF_INTEGER_32) 1L), tr1);
			break;
	}
	RTLE;
}

/* {GEANT}.set_verbose */
void F1357_10342 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT}.set_debug_mode */
void F1357_10343 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT}.set_show_target_info */
void F1357_10344 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT}.set_no_exec */
void F1357_10345 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_3_) = (EIF_BOOLEAN) arg1;
}

/* {GEANT}.report_version_number */
void F1357_10346 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1347, 0x01).id, 1347, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(1138,F103_1138, (Current));
	F1348_10196(RTCW(loc1), tr1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1274_9046(RTCW(tr1), loc1);
	F1349_10210(Current, ((EIF_INTEGER_32) 0L), NULL);
	RTLE;
}

/* {GEANT}.default_build_filename */
static EIF_REFERENCE F1357_10347_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10347);
#define Result RTOSR(10347)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("build.eant",10,1041107060);
	RTOSE (10347);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1357_10347 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10347,F1357_10347_body,(Current));
}

void EIF_Minit502 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
