
#ifndef _C11_ge504_
#define _C11_ge504_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1361_10361(EIF_REFERENCE);
extern void EIF_Minit504(void);
extern EIF_REFERENCE F1358_10349(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
