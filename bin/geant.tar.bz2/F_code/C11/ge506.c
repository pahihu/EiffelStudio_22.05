/*
 * Code for class GEANT_NAME_VALUE_ELEMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge506.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_NAME_VALUE_ELEMENT}.name */
EIF_REFERENCE F1363_10380 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(10384,F1363_10384, (Current));
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7780[Dtype(Current)-1362])(Current, tr1);
	RTLE;
	return Result;
}

/* {GEANT_NAME_VALUE_ELEMENT}.value */
EIF_REFERENCE F1363_10381 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(10385,F1363_10385, (Current));
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7780[Dtype(Current)-1362])(Current, tr1);
	RTLE;
	return Result;
}

/* {GEANT_NAME_VALUE_ELEMENT}.has_name */
EIF_BOOLEAN F1363_10382 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(10384,F1363_10384, (Current));
	Result = F1362_10376(Current, tr1);
	RTLE;
	return Result;
}

/* {GEANT_NAME_VALUE_ELEMENT}.has_value */
EIF_BOOLEAN F1363_10383 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(10385,F1363_10385, (Current));
	Result = F1362_10376(Current, tr1);
	RTLE;
	return Result;
}

/* {GEANT_NAME_VALUE_ELEMENT}.name_attribute_name */
static EIF_REFERENCE F1363_10384_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10384);
#define Result RTOSR(10384)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("name",4,1851878757);
	RTOSE (10384);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1363_10384 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10384,F1363_10384_body,(Current));
}

/* {GEANT_NAME_VALUE_ELEMENT}.value_attribute_name */
static EIF_REFERENCE F1363_10385_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10385);
#define Result RTOSR(10385)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("value",5,1635404133);
	RTOSE (10385);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1363_10385 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10385,F1363_10385_body,(Current));
}

void EIF_Minit506 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
