/*
 * Code for class GEANT_XSLT_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge537.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_XSLT_TASK}.make */
void F1394_10597 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(11);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLR(9,loc1);
	RTLR(10,loc6);
	RTLIU(11);
	
	RTGC;
	F1374_10420(Current, arg1, arg2);
	tr1 = RTOSCF(10604,F1394_10604, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10604,F1394_10604, (Current));
		loc2 = F1367_10390(Current, tr1);
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = RTOSCF(10605,F1394_10605, (Current));
		tb1 = F958_6409(RTCW(tr1), loc2, tr2);
		if (tb1) {
			loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1420_11001(RTCW(tr1));
		} else {
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = RTOSCF(10606,F1394_10606, (Current));
			tb1 = F958_6409(RTCW(tr1), loc2, tr2);
			if (tb1) {
				loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				F1420_11000(RTCW(tr1));
			} else {
				tr1 = RTOSCF(6466,F971_6466, (Current));
				tr2 = RTOSCF(10607,F1394_10607, (Current));
				tb1 = F958_6409(RTCW(tr1), loc2, tr2);
				if (tb1) {
					loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					F1420_11002(RTCW(tr1));
				} else {
					tr1 = RTOSCF(6466,F971_6466, (Current));
					tr2 = RTOSCF(10608,F1394_10608, (Current));
					tb1 = F958_6409(RTCW(tr1), loc2, tr2);
					if (tb1) {
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
						F1420_11003(RTCW(tr1));
					}
				}
			}
		}
	}
	tr1 = RTOSCF(10600,F1394_10600, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10600,F1394_10600, (Current));
		loc2 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1420_10997(RTCW(tr1), loc2);
		}
	}
	tr1 = RTOSCF(10601,F1394_10601, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10601,F1394_10601, (Current));
		loc2 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1420_10998(RTCW(tr1), loc2);
		}
	}
	tr1 = RTOSCF(10602,F1394_10602, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10602,F1394_10602, (Current));
		loc2 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1420_10999(RTCW(tr1), loc2);
		}
	}
	tr1 = RTOSCF(10603,F1394_10603, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10603,F1394_10603, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1420_11008(RTCW(tr1), tb1);
	}
	if ((EIF_BOOLEAN) (loc8 || loc7)) {
		tr1 = RTOSCF(10610,F1394_10610, (Current));
		if (F1362_10376(Current, tr1)) {
			tr1 = RTOSCF(10610,F1394_10610, (Current));
			loc2 = F1367_10390(Current, tr1);
			tb1 = F943_5858(RTCW(loc2));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				F1420_11005(RTCW(tr1), loc2);
			}
		}
	}
	tr1 = RTOSCF(10613,F1394_10613, (Current));
	loc3 = F1362_10365(Current, tr1);
	loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5961[Dtype(RTCW(loc3))-1184])(loc3);
	F1053_7395(RTCW(loc4));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc4)+ _CHROFF_3_1_);
		if (tb1) break;
		loc5 = RTLNS(eif_new_type(1372, 0x01).id, 1372, _OBJSIZ_3_0_0_0_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = F1108_7483(RTCW(loc4));
		F1367_10386(RTCW(loc5), tr1, tr2);
		tb2 = '\0';
		tb3 = '\0';
		tb4 = F1367_10388(RTCW(loc5));
		if (tb4) {
			tb4 = F1363_10382(RTCW(loc5));
			tb3 = tb4;
		}
		if (tb3) {
			tb3 = F1363_10383(RTCW(loc5));
			tb2 = tb3;
		}
		if (tb2) {
			loc1 = F1363_10380(RTCW(loc5));
			loc2 = F1363_10381(RTCW(loc5));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,133,0xFF01,950,0xFF01,950,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				loc6 = RTLNS(typres0.id, 133, _OBJSIZ_2_0_0_0_0_0_0_0_);
			}
			F134_1566(RTCW(loc6), loc1, loc2);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
			F1209_8165(RTCW(tr1), loc6);
		}
		F1053_7396(RTCW(loc4));
	}
	if (loc8) {
		tr1 = RTOSCF(10609,F1394_10609, (Current));
		if (F1362_10376(Current, tr1)) {
			tr1 = RTOSCF(10609,F1394_10609, (Current));
			loc2 = F1367_10390(Current, tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				F1420_11004(RTCW(tr1), loc2);
			}
		}
		tr1 = RTOSCF(10611,F1394_10611, (Current));
		if (F1362_10376(Current, tr1)) {
			tr1 = RTOSCF(10611,F1394_10611, (Current));
			loc2 = F1367_10390(Current, tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				F1420_11006(RTCW(tr1), loc2);
			}
		}
		tr1 = RTOSCF(10612,F1394_10612, (Current));
		if (F1362_10376(Current, tr1)) {
			tr1 = RTOSCF(10612,F1394_10612, (Current));
			loc2 = F1367_10390(Current, tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				F1420_11007(RTCW(tr1), loc2);
			}
		}
	}
	RTLE;
}

/* {GEANT_XSLT_TASK}.build_command */
void F1394_10598 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7829,Y7829_gen_type,Dftype(Current),1373).id);
	F1420_10985(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_XSLT_TASK}.input_filename_attribute_name */
static EIF_REFERENCE F1394_10600_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10600);
#define Result RTOSR(10600)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("input",5,1853670260);
	RTOSE (10600);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1394_10600 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10600,F1394_10600_body,(Current));
}

/* {GEANT_XSLT_TASK}.output_filename_attribute_name */
static EIF_REFERENCE F1394_10601_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10601);
#define Result RTOSR(10601)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("output",6,25180788);
	RTOSE (10601);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1394_10601 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10601,F1394_10601_body,(Current));
}

/* {GEANT_XSLT_TASK}.stylesheet_filename_attribute_name */
static EIF_REFERENCE F1394_10602_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10602);
#define Result RTOSR(10602)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("stylesheet",10,32726388);
	RTOSE (10602);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1394_10602 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10602,F1394_10602_body,(Current));
}

/* {GEANT_XSLT_TASK}.force_attribute_name */
static EIF_REFERENCE F1394_10603_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10603);
#define Result RTOSR(10603)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("force",5,1870550885);
	RTOSE (10603);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1394_10603 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10603,F1394_10603_body,(Current));
}

/* {GEANT_XSLT_TASK}.processor_attribute_name */
static EIF_REFERENCE F1394_10604_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10604);
#define Result RTOSR(10604)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("processor",9,208392050);
	RTOSE (10604);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1394_10604 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10604,F1394_10604_body,(Current));
}

/* {GEANT_XSLT_TASK}.processor_attribute_value_xalan_cpp */
static EIF_REFERENCE F1394_10605_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10605);
#define Result RTOSR(10605)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("xalan_cpp",9,973409136);
	RTOSE (10605);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1394_10605 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10605,F1394_10605_body,(Current));
}

/* {GEANT_XSLT_TASK}.processor_attribute_value_xalan_java */
static EIF_REFERENCE F1394_10606_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10606);
#define Result RTOSR(10606)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("xalan_java",10,201540193);
	RTOSE (10606);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1394_10606 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10606,F1394_10606_body,(Current));
}

/* {GEANT_XSLT_TASK}.processor_attribute_value_xsltproc */
static EIF_REFERENCE F1394_10607_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10607);
#define Result RTOSR(10607)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("xsltproc",8,2026863715);
	RTOSE (10607);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1394_10607 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10607,F1394_10607_body,(Current));
}

/* {GEANT_XSLT_TASK}.processor_attribute_value_gexslt */
static EIF_REFERENCE F1394_10608_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10608);
#define Result RTOSR(10608)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("gexslt",6,76632436);
	RTOSE (10608);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1394_10608 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10608,F1394_10608_body,(Current));
}

/* {GEANT_XSLT_TASK}.format_attribute_name */
static EIF_REFERENCE F1394_10609_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10609);
#define Result RTOSR(10609)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("format",6,2121163636);
	RTOSE (10609);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1394_10609 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10609,F1394_10609_body,(Current));
}

/* {GEANT_XSLT_TASK}.indent_attribute_name */
static EIF_REFERENCE F1394_10610_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10610);
#define Result RTOSR(10610)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("indent",6,1891652212);
	RTOSE (10610);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1394_10610 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10610,F1394_10610_body,(Current));
}

/* {GEANT_XSLT_TASK}.extdirs_attribute_name */
static EIF_REFERENCE F1394_10611_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10611);
#define Result RTOSR(10611)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("extdirs",7,1216901747);
	RTOSE (10611);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1394_10611 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10611,F1394_10611_body,(Current));
}

/* {GEANT_XSLT_TASK}.classpath_attribute_name */
static EIF_REFERENCE F1394_10612_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10612);
#define Result RTOSR(10612)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("classpath",9,963781736);
	RTOSE (10612);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1394_10612 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10612,F1394_10612_body,(Current));
}

/* {GEANT_XSLT_TASK}.parameter_element_name */
static EIF_REFERENCE F1394_10613_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10613);
#define Result RTOSR(10613)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("parameter",9,1475735922);
	RTOSE (10613);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1394_10613 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10613,F1394_10613_body,(Current));
}

void EIF_Minit537 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
