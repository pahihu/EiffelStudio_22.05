/*
 * Code for class GEANT_MAP_ELEMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge514.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_MAP_ELEMENT}.make */
void F1371_10406 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,loc3);
	RTLIU(8);
	
	RTGC;
	F1367_10386(Current, arg1, arg2);
	tr1 = RTLNSMART(eif_new_type(1349, 1).id);
	F1350_10216(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(10408,F1371_10408, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10408,F1371_10408, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1350_10224(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10409,F1371_10409, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10409,F1371_10409, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1350_10225(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10410,F1371_10410, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10410,F1371_10410, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1350_10226(RTCW(tr1), loc1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTOSCF(10411,F1371_10411, (Current));
	loc2 = F1287_9185(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		loc3 = RTLNS(eif_new_type(1370, 0x01).id, 1370, _OBJSIZ_4_0_0_0_0_0_0_0_);
		F1371_10406(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_2_), loc2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_3_);
		F1350_10227(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {GEANT_MAP_ELEMENT}.type_attribute_name */
static EIF_REFERENCE F1371_10408_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10408);
#define Result RTOSR(10408)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("type",4,1954115685);
	RTOSE (10408);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1371_10408 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10408,F1371_10408_body,(Current));
}

/* {GEANT_MAP_ELEMENT}.from_attribute_name */
static EIF_REFERENCE F1371_10409_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10409);
#define Result RTOSR(10409)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("from",4,1718775661);
	RTOSE (10409);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1371_10409 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10409,F1371_10409_body,(Current));
}

/* {GEANT_MAP_ELEMENT}.to_attribute_name */
static EIF_REFERENCE F1371_10410_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10410);
#define Result RTOSR(10410)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("to",2,29807);
	RTOSE (10410);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1371_10410 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10410,F1371_10410_body,(Current));
}

/* {GEANT_MAP_ELEMENT}.map_element_name */
static EIF_REFERENCE F1371_10411_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10411);
#define Result RTOSR(10411)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("map",3,7168368);
	RTOSE (10411);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1371_10411 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10411,F1371_10411_body,(Current));
}

void EIF_Minit514 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
