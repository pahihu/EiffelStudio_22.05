/*
 * Code for class GEANT_GEPP_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge533.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_GEPP_TASK}.make */
void F1390_10562 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(11);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,tr2);
	RTLR(9,loc6);
	RTLR(10,loc7);
	RTLIU(11);
	
	RTGC;
	F1374_10420(Current, arg1, arg2);
	tr1 = RTOSCF(10565,F1390_10565, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10565,F1390_10565, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1416_10919(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10566,F1390_10566, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10566,F1390_10566, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1416_10920(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10567,F1390_10567, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10567,F1390_10567, (Current));
		loc2 = F1362_10375(Current, tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1416_10921(RTCW(tr1), loc2);
	}
	tr1 = RTOSCF(10568,F1390_10568, (Current));
	loc3 = F1362_10365(Current, tr1);
	loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5961[Dtype(RTCW(loc3))-1184])(loc3);
	F1053_7395(RTCW(loc4));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc4)+ _CHROFF_3_1_);
		if (tb1) break;
		loc5 = RTLNS(eif_new_type(1372, 0x01).id, 1372, _OBJSIZ_3_0_0_0_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = F1108_7483(RTCW(loc4));
		F1367_10386(RTCW(loc5), tr1, tr2);
		tb2 = '\0';
		tb3 = '\0';
		tb4 = F1367_10388(RTCW(loc5));
		if (tb4) {
			tb4 = F1363_10382(RTCW(loc5));
			tb3 = tb4;
		}
		if (tb3) {
			tr1 = F1363_10380(RTCW(loc5));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
			tb2 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
			tr2 = F1363_10380(RTCW(loc5));
			F1209_8165(RTCW(tr1), tr2);
		}
		F1053_7396(RTCW(loc4));
	}
	tr1 = RTOSCF(10569,F1390_10569, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10569,F1390_10569, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1416_10922(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10570,F1390_10570, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10570,F1390_10570, (Current));
		tb2 = F1362_10375(Current, tr2);
		F1416_10924(RTCW(tr1), tb2);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTOSCF(10571,F1390_10571, (Current));
	loc6 = F1287_9185(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN)(loc6 != NULL)) {
		loc7 = RTLNS(eif_new_type(1421, 0x01).id, 1421, _OBJSIZ_4_0_0_0_0_0_0_0_);
		F1422_11027(RTCW(loc7), *(EIF_REFERENCE *)(Current + _REFACS_2_), loc6);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_3_);
		F1416_10923(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {GEANT_GEPP_TASK}.build_command */
void F1390_10563 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7829,Y7829_gen_type,Dftype(Current),1373).id);
	F1416_10908(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_GEPP_TASK}.input_filename_attribute_name */
static EIF_REFERENCE F1390_10565_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10565);
#define Result RTOSR(10565)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("input",5,1853670260);
	RTOSE (10565);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1390_10565 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10565,F1390_10565_body,(Current));
}

/* {GEANT_GEPP_TASK}.output_filename_attribute_name */
static EIF_REFERENCE F1390_10566_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10566);
#define Result RTOSR(10566)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("output",6,25180788);
	RTOSE (10566);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1390_10566 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10566,F1390_10566_body,(Current));
}

/* {GEANT_GEPP_TASK}.lines_attribute_name */
static EIF_REFERENCE F1390_10567_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10567);
#define Result RTOSR(10567)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("lines",5,1769672051);
	RTOSE (10567);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1390_10567 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10567,F1390_10567_body,(Current));
}

/* {GEANT_GEPP_TASK}.define_element_name */
static EIF_REFERENCE F1390_10568_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10568);
#define Result RTOSR(10568)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("define",6,1915569253);
	RTOSE (10568);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1390_10568 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10568,F1390_10568_body,(Current));
}

/* {GEANT_GEPP_TASK}.to_directory_attribute_name */
static EIF_REFERENCE F1390_10569_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10569);
#define Result RTOSR(10569)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("to_directory",12,832290425);
	RTOSE (10569);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1390_10569 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10569,F1390_10569_body,(Current));
}

/* {GEANT_GEPP_TASK}.force_attribute_name */
static EIF_REFERENCE F1390_10570_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10570);
#define Result RTOSR(10570)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("force",5,1870550885);
	RTOSE (10570);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1390_10570 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10570,F1390_10570_body,(Current));
}

/* {GEANT_GEPP_TASK}.fileset_element_name */
static EIF_REFERENCE F1390_10571_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10571);
#define Result RTOSR(10571)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("fileset",7,1708094836);
	RTOSE (10571);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1390_10571 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10571,F1390_10571_body,(Current));
}

void EIF_Minit533 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
