/*
 * Code for class GEANT_DIRECTORYSET_ELEMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge515.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_DIRECTORYSET_ELEMENT}.make */
void F1372_10412 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLR(6,loc2);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLIU(9);
	
	RTGC;
	F1367_10386(Current, arg1, arg2);
	tr1 = RTLNSMART(eif_new_type(1257, 1).id);
	F1258_8667(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(10414,F1372_10414, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10414,F1372_10414, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1258_8680(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10415,F1372_10415, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10415,F1372_10415, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1258_8681(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10416,F1372_10416, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10416,F1372_10416, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1258_8682(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10417,F1372_10417, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = RTOSCF(10417,F1372_10417, (Current));
		tb1 = F1362_10375(Current, tr2);
		F1258_8684(RTCW(tr1), tb1);
	}
	tr1 = RTOSCF(10418,F1372_10418, (Current));
	loc2 = F1362_10365(Current, tr1);
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5961[Dtype(RTCW(loc2))-1184])(loc2);
	F1053_7395(RTCW(loc3));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
		if (tb1) break;
		loc4 = RTLNS(eif_new_type(1372, 0x01).id, 1372, _OBJSIZ_3_0_0_0_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = F1108_7483(RTCW(loc3));
		F1367_10386(RTCW(loc4), tr1, tr2);
		tb2 = '\0';
		tb3 = '\0';
		tb4 = F1367_10388(RTCW(loc4));
		if (tb4) {
			tb4 = F1363_10382(RTCW(loc4));
			tb3 = tb4;
		}
		if (tb3) {
			tr1 = F1363_10380(RTCW(loc4));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
			tb2 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr2 = F1363_10380(RTCW(loc4));
			F1258_8688(RTCW(tr1), tr2);
		}
		F1053_7396(RTCW(loc3));
	}
	tr1 = RTOSCF(10419,F1372_10419, (Current));
	loc2 = F1362_10365(Current, tr1);
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5961[Dtype(RTCW(loc2))-1184])(loc2);
	F1053_7395(RTCW(loc3));
	for (;;) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
		if (tb2) break;
		loc4 = RTLNS(eif_new_type(1372, 0x01).id, 1372, _OBJSIZ_3_0_0_0_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = F1108_7483(RTCW(loc3));
		F1367_10386(RTCW(loc4), tr1, tr2);
		tb3 = '\0';
		tb4 = '\0';
		tb5 = F1367_10388(RTCW(loc4));
		if (tb5) {
			tb5 = F1363_10382(RTCW(loc4));
			tb4 = tb5;
		}
		if (tb4) {
			tr1 = F1363_10380(RTCW(loc4));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
			tb3 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
		}
		if (tb3) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr2 = F1363_10380(RTCW(loc4));
			F1258_8689(RTCW(tr1), tr2);
		}
		F1053_7396(RTCW(loc3));
	}
	RTLE;
}

/* {GEANT_DIRECTORYSET_ELEMENT}.directory_attribute_name */
static EIF_REFERENCE F1372_10414_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10414);
#define Result RTOSR(10414)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("directory",9,1028911737);
	RTOSE (10414);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1372_10414 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10414,F1372_10414_body,(Current));
}

/* {GEANT_DIRECTORYSET_ELEMENT}.include_attribute_name */
static EIF_REFERENCE F1372_10415_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10415);
#define Result RTOSR(10415)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("include",7,1197897061);
	RTOSE (10415);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1372_10415 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10415,F1372_10415_body,(Current));
}

/* {GEANT_DIRECTORYSET_ELEMENT}.exclude_attribute_name */
static EIF_REFERENCE F1372_10416_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10416);
#define Result RTOSR(10416)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("exclude",7,1351771749);
	RTOSE (10416);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1372_10416 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10416,F1372_10416_body,(Current));
}

/* {GEANT_DIRECTORYSET_ELEMENT}.concat_attribute_name */
static EIF_REFERENCE F1372_10417_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10417);
#define Result RTOSR(10417)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("concat",6,2047501172);
	RTOSE (10417);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1372_10417 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10417,F1372_10417_body,(Current));
}

/* {GEANT_DIRECTORYSET_ELEMENT}.include_element_name */
static EIF_REFERENCE F1372_10418_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10418);
#define Result RTOSR(10418)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("include",7,1197897061);
	RTOSE (10418);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1372_10418 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10418,F1372_10418_body,(Current));
}

/* {GEANT_DIRECTORYSET_ELEMENT}.exclude_element_name */
static EIF_REFERENCE F1372_10419_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10419);
#define Result RTOSR(10419)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("exclude",7,1351771749);
	RTOSE (10419);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1372_10419 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10419,F1372_10419_body,(Current));
}

void EIF_Minit515 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
