/*
 * Code for class GEANT_REPLACE_TASK
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge534.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_REPLACE_TASK}.make */
void F1391_10572 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLR(7,loc2);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	F1374_10420(Current, arg1, arg2);
	tr1 = RTOSCF(10575,F1391_10575, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10575,F1391_10575, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1417_10939(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10576,F1391_10576, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10576,F1391_10576, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1417_10940(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10577,F1391_10577, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10577,F1391_10577, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1417_10941(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10578,F1391_10578, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10578,F1391_10578, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1417_10944(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10579,F1391_10579, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10579,F1391_10579, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1417_10942(RTCW(tr1), loc1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTOSCF(10580,F1391_10580, (Current));
	tr1 = F1287_9188(RTCW(tr1), tr2);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc1 = *(EIF_REFERENCE *)(loc4 + _REFACS_3_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1417_10943(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10581,F1391_10581, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10581,F1391_10581, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1417_10945(RTCW(tr1), loc1);
		}
	}
	tr1 = RTOSCF(10582,F1391_10582, (Current));
	if (F1362_10376(Current, tr1)) {
		tr1 = RTOSCF(10582,F1391_10582, (Current));
		loc1 = F1367_10390(Current, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1417_10946(RTCW(tr1), loc1);
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTOSCF(10583,F1391_10583, (Current));
	loc2 = F1287_9185(RTCW(tr1), tr2);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		loc3 = RTLNS(eif_new_type(1421, 0x01).id, 1421, _OBJSIZ_4_0_0_0_0_0_0_0_);
		F1422_11027(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_2_), loc2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_3_);
		F1417_10947(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {GEANT_REPLACE_TASK}.build_command */
void F1391_10573 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7829,Y7829_gen_type,Dftype(Current),1373).id);
	F1395_10615(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {GEANT_REPLACE_TASK}.file_attribute_name */
static EIF_REFERENCE F1391_10575_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10575);
#define Result RTOSR(10575)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("file",4,1718185061);
	RTOSE (10575);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1391_10575 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10575,F1391_10575_body,(Current));
}

/* {GEANT_REPLACE_TASK}.to_file_attribute_name */
static EIF_REFERENCE F1391_10576_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10576);
#define Result RTOSR(10576)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("to_file",7,192426597);
	RTOSE (10576);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1391_10576 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10576,F1391_10576_body,(Current));
}

/* {GEANT_REPLACE_TASK}.to_directory_attribute_name */
static EIF_REFERENCE F1391_10577_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10577);
#define Result RTOSR(10577)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("to_directory",12,832290425);
	RTOSE (10577);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1391_10577 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10577,F1391_10577_body,(Current));
}

/* {GEANT_REPLACE_TASK}.match_attribute_name */
static EIF_REFERENCE F1391_10578_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10578);
#define Result RTOSR(10578)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("match",5,1635854696);
	RTOSE (10578);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1391_10578 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10578,F1391_10578_body,(Current));
}

/* {GEANT_REPLACE_TASK}.token_attribute_name */
static EIF_REFERENCE F1391_10579_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10579);
#define Result RTOSR(10579)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("token",5,1870200174);
	RTOSE (10579);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1391_10579 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10579,F1391_10579_body,(Current));
}

/* {GEANT_REPLACE_TASK}.variable_pattern_attribute_name */
static EIF_REFERENCE F1391_10580_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10580);
#define Result RTOSR(10580)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("variable_pattern",16,2127889518);
	RTOSE (10580);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1391_10580 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10580,F1391_10580_body,(Current));
}

/* {GEANT_REPLACE_TASK}.replace_attribute_name */
static EIF_REFERENCE F1391_10581_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10581);
#define Result RTOSR(10581)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("replace",7,1413879909);
	RTOSE (10581);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1391_10581 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10581,F1391_10581_body,(Current));
}

/* {GEANT_REPLACE_TASK}.flags_attribute_name */
static EIF_REFERENCE F1391_10582_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10582);
#define Result RTOSR(10582)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("flags",5,1819106163);
	RTOSE (10582);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1391_10582 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10582,F1391_10582_body,(Current));
}

/* {GEANT_REPLACE_TASK}.fileset_element_name */
static EIF_REFERENCE F1391_10583_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10583);
#define Result RTOSR(10583)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("fileset",7,1708094836);
	RTOSE (10583);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1391_10583 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10583,F1391_10583_body,(Current));
}

void EIF_Minit534 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
