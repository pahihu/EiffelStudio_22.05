
#ifndef _C17_ds812_
#define _C17_ds812_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1234_8466(EIF_REFERENCE);
extern EIF_INTEGER_32 F1234_8469(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit812(void);
extern char *(*R5734[])();
extern EIF_TYPE_INDEX Y5938[];
extern EIF_TYPE_INDEX *Y5938_gen_type [];
extern EIF_TYPE_INDEX Y1954[];
extern EIF_TYPE_INDEX *Y1954_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
