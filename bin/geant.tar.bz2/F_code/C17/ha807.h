
#ifndef _C17_ha807_
#define _C17_ha807_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F438_3435(EIF_REFERENCE);
extern EIF_REFERENCE F438_3436(EIF_REFERENCE);
extern EIF_BOOLEAN F438_3438(EIF_REFERENCE);
extern void F438_3439(EIF_REFERENCE);
extern EIF_REFERENCE F438_3440(EIF_REFERENCE);
extern void EIF_Minit807(void);
extern char *(*R3355[])();
extern char *(*R3047[])();
extern char *(*R3566[])();
extern char *(*R3567[])();
extern char *(*R2870[])();
extern long O3575[];
extern long O3576[];

#ifdef __cplusplus
}
#endif

#endif
