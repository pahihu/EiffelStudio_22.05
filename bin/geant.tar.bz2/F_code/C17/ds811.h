
#ifndef _C17_ds811_
#define _C17_ds811_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1099_7448(EIF_REFERENCE);
extern void EIF_Minit811(void);

#ifdef __cplusplus
}
#endif

#endif
