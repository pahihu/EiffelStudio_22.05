
#ifndef _C17_ds828_
#define _C17_ds828_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1089_7442(EIF_REFERENCE);
extern void EIF_Minit828(void);
extern char *(*R6018[])();

#ifdef __cplusplus
}
#endif

#endif
