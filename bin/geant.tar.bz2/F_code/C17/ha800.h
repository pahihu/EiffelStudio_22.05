
#ifndef _C17_ha800_
#define _C17_ha800_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F440_3435(EIF_REFERENCE);
extern EIF_INTEGER_32 F440_3436(EIF_REFERENCE);
extern EIF_BOOLEAN F440_3438(EIF_REFERENCE);
extern void F440_3439(EIF_REFERENCE);
extern EIF_REFERENCE F440_3440(EIF_REFERENCE);
extern void EIF_Minit800(void);
extern char *(*R3355[])();
extern char *(*R3047[])();
extern char *(*R3566[])();
extern char *(*R3567[])();
extern long O3575[];
extern long O3576[];

#ifdef __cplusplus
}
#endif

#endif
