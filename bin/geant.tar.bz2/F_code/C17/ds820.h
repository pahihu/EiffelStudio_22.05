
#ifndef _C17_ds820_
#define _C17_ds820_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1054_7392(EIF_REFERENCE);
extern void F1054_7395(EIF_REFERENCE);
extern void F1054_7396(EIF_REFERENCE);
extern void F1054_7398(EIF_REFERENCE);
extern void EIF_Minit820(void);
extern char *(*R5992[])();
extern char *(*R5994[])();
extern char *(*R5995[])();
extern char *(*R5997[])();
extern char *(*R5704[])();

#ifdef __cplusplus
}
#endif

#endif
