
#ifndef _C17_ki809_
#define _C17_ki809_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F147_1592(EIF_REFERENCE);
extern void F147_1599(EIF_REFERENCE);
extern void EIF_Minit809(void);

#ifdef __cplusplus
}
#endif

#endif
