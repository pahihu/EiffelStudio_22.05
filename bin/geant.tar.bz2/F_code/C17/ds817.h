
#ifndef _C17_ds817_
#define _C17_ds817_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1152_7729(EIF_REFERENCE);
extern EIF_BOOLEAN F1152_7731(EIF_REFERENCE);
extern void F1152_7734(EIF_REFERENCE);
extern void F1152_7735(EIF_REFERENCE);
extern void F1152_7737(EIF_REFERENCE);
extern EIF_REFERENCE F1152_7744(EIF_REFERENCE);
extern EIF_BOOLEAN F1152_7746(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit817(void);
extern void F740_4082(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F740_4058(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F960_6436(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1040_7375(EIF_REFERENCE);
extern EIF_BOOLEAN F1126_7674(EIF_REFERENCE);
extern void F1054_7396(EIF_REFERENCE);
extern void F1_29(EIF_REFERENCE);
extern void F1054_7395(EIF_REFERENCE);
extern char *(*R5994[])();
extern char *(*R5995[])();
extern char *(*R5997[])();
extern char *(*R5961[])();
extern char *(*R5967[])();
extern char *(*R5929[])();
extern char *(*R2921[])();
extern EIF_TYPE_INDEX Y5938[];
extern EIF_TYPE_INDEX *Y5938_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
