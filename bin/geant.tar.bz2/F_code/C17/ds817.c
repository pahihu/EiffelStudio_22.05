/*
 * Code for class DS_LINEAR [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds817.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_LINEAR}.new_iterator */
EIF_REFERENCE F1152_7729 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5961[Dtype(Current)-1184])(Current);
	F1054_7395(RTCW(Result));
	RTLE;
	return Result;
}

/* {DS_LINEAR}.after */
EIF_BOOLEAN F1152_7731 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5967[Dtype(Current)-1184])(Current);
	Result = F1152_7746(Current, tr1);
	RTLE;
	return Result;
}

/* {DS_LINEAR}.start */
void F1152_7734 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5967[dtype-1184])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5994[dtype-1184])(Current, tr1);
	RTLE;
}

/* {DS_LINEAR}.forth */
void F1152_7735 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5967[dtype-1184])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5995[dtype-1184])(Current, tr1);
	RTLE;
}

/* {DS_LINEAR}.go_after */
void F1152_7737 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5967[dtype-1184])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5997[dtype-1184])(Current, tr1);
	RTLE;
}

/* {DS_LINEAR}.to_array */
EIF_REFERENCE F1152_7744 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	if (F1126_7674(Current)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,959,0,0,0xFFFF};
			EIF_TYPE typres0;
			{
				EIF_TYPE l_type;
				l_type = eif_final_id(Y5938,Y5938_gen_type,dftype,1124);
				typarr0[2] = l_type.annotations | 0xFF00;
				typarr0[3] = l_type.id;
			}
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr1 = RTLNS(typres0.id, 959, _OBJSIZ_0_0_0_0_0_0_0_0_);
		}
		F1_29(RTCW(tr1));
		Result = F960_6436(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	} else {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5961[dtype-1184])(Current);
		F1054_7395(RTCW(loc1));
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,739,0,0,0xFFFF};
			EIF_TYPE typres0;
			{
				EIF_TYPE l_type;
				l_type = eif_final_id(Y5938,Y5938_gen_type,dftype,1124);
				typarr0[2] = l_type.annotations | 0xFF00;
				typarr0[3] = l_type.id;
			}
			
			typres0 = eif_compound_id(dftype, typarr0);
			Result = RTLNS(typres0.id, 739, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		ti4_1 = F1040_7375(RTCW(loc1));
		ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5929[dtype-1184])(Current);
		F740_4058(RTCW(Result), ti4_1, ((EIF_INTEGER_32) 1L), ti4_2);
		F1054_7396(RTCW(loc1));
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2921[Dtype(RTCW(loc1))-437])(loc1);
			if (tb1) break;
			loc2++;
			ti4_1 = F1040_7375(RTCW(loc1));
			F740_4082(RTCW(Result), ti4_1, loc2);
			F1054_7396(RTCW(loc1));
		}
	}
	RTLE;
	return Result;
}

/* {DS_LINEAR}.cursor_after */
EIF_BOOLEAN F1152_7746 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	
	
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2921[Dtype(RTCW(arg1))-437])(arg1);
	return (EIF_BOOLEAN) tb1;
}

void EIF_Minit817 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
