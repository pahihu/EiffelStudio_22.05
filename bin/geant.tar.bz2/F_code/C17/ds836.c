/*
 * Code for class DS_SPARSE_CONTAINER [G#1, INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds836.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_CONTAINER}.make */
void F1213_8231 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O6232[dtype-1211]) = (EIF_INTEGER_32) arg1;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6195[dtype-1220])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6200[dtype-1220])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6206[dtype-1220])(Current, arg1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6230[dtype-1220])(Current, arg1);
	*(EIF_INTEGER_32 *)(Current + O6217[dtype-1211]) = (EIF_INTEGER_32) ti4_1;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6211[dtype-1220])(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O6217[dtype-1211]) + ((EIF_INTEGER_32) 1L)));
	*(EIF_INTEGER_32 *)(Current + O6182[dtype-1211]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current + O6218[dtype-1211]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6178[dtype-1220])(Current);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5961[dtype-1184])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5966[dtype-1184])(Current, tr1);
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.found_item */
EIF_REFERENCE F1213_8232 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	RTLE;
	return (EIF_REFERENCE) (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6183[dtype-1220])(Current, *(EIF_INTEGER_32 *)(Current + O6222[dtype-1211]));
}

/* {DS_SPARSE_CONTAINER}.count */
EIF_INTEGER_32 F1213_8236 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O6233[Dtype(Current)-1211]);
}


/* {DS_SPARSE_CONTAINER}.capacity */
EIF_INTEGER_32 F1213_8237 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O6232[Dtype(Current)-1211]);
}


/* {DS_SPARSE_CONTAINER}.has */
EIF_BOOLEAN F1213_8239 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg1);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O6182[dtype-1211]);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
			tb1 = '\0';
			if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc1) > ((EIF_INTEGER_32) -2L))) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6183[dtype-1220])(Current, loc1);
				tr2 = RTCCL(tr1);
				tr3 = RTCCL(arg1);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2207[Dtype(loc2)-254])(loc2, tr2, tr3);
				tb1 = tb2;
			}
			if (tb1) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			} else {
				loc1--;
			}
		}
	} else {
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
			tb1 = '\0';
			if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc1) > ((EIF_INTEGER_32) -2L))) {
				tb1 = RTCEQ((FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6183[dtype-1220])(Current, loc1), arg1);
			}
			if (tb1) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			} else {
				loc1--;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.found */
EIF_BOOLEAN F1213_8240 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O6222[Dtype(Current)-1211]) != ((EIF_INTEGER_32) -1L));
}

/* {DS_SPARSE_CONTAINER}.unset_found_item */
void F1213_8250 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O6222[Dtype(Current)-1211]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
}

/* {DS_SPARSE_CONTAINER}.copy */
void F1213_8251 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6226[dtype-1220])(Current);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5964[dtype-1184])(Current, loc1);
		}
		if (tb1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5966[dtype-1184])(Current, loc1);
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5961[dtype-1184])(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5966[dtype-1184])(Current, tr1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6178[dtype-1220])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6196[dtype-1220])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6202[dtype-1220])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6214[dtype-1220])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6208[dtype-1220])(Current);
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.remove */
void F1213_8252 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6178[dtype-1220])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6189[dtype-1220])(Current, (EIF_REFERENCE) &arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]) != ((EIF_INTEGER_32) -1L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6194[dtype-1220])(Current, *(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]));
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.wipe_out */
void F1213_8254 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6226[dtype-1220])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6178[dtype-1220])(Current);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O6233[dtype-1211]) > ((EIF_INTEGER_32) 0L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6198[dtype-1220])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6204[dtype-1220])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6210[dtype-1220])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6216[dtype-1220])(Current);
		*(EIF_INTEGER_32 *)(Current + O6182[dtype-1211]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		*(EIF_INTEGER_32 *)(Current + O6218[dtype-1211]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		*(EIF_INTEGER_32 *)(Current + O6233[dtype-1211]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	*(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.resize */
void F1213_8255 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6178[dtype-1220])(Current);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6230[dtype-1220])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6215[dtype-1220])(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
	loc2 = *(EIF_INTEGER_32 *)(Current + O6217[dtype-1211]);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) break;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6213[dtype-1220])(Current, ((EIF_INTEGER_32) -1L), loc2);
		loc2--;
	}
	*(EIF_INTEGER_32 *)(Current + O6217[dtype-1211]) = (EIF_INTEGER_32) loc1;
	loc2 = *(EIF_INTEGER_32 *)(Current + O6182[dtype-1211]);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) break;
		if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc2) > ((EIF_INTEGER_32) -2L))) {
			ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6185[dtype-1220])(Current, loc2));
			loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6193[dtype-1220])(Current, (EIF_REFERENCE) &ti4_1);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6212[dtype-1220])(Current, loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6207[dtype-1220])(Current, ti4_1, loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6213[dtype-1220])(Current, loc2, loc3);
		}
		loc2--;
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6197[dtype-1220])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6203[dtype-1220])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6209[dtype-1220])(Current, arg1);
	*(EIF_INTEGER_32 *)(Current + O6232[dtype-1211]) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.search_position */
void F1213_8264 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (EIF_FALSE) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6212[dtype-1220])(Current, *(EIF_INTEGER_32 *)(Current + O6217[dtype-1211]));
		*(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]) = (EIF_INTEGER_32) ti4_1;
		*(EIF_INTEGER_32 *)(Current + O6220[dtype-1211]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O6217[dtype-1211]);
		*(EIF_INTEGER_32 *)(Current + O6221[dtype-1211]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	} else {
		loc3 = *(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6191[dtype-1220])(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			loc4 = *(EIF_INTEGER_32 *)(Current + O6220[dtype-1211]);
			loc2 = *(EIF_INTEGER_32 *)(Current + O6221[dtype-1211]);
			tb1 = '\01';
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
				tb2 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc3) <= ((EIF_INTEGER_32) -2L));
			}
			if (!tb2) {
				ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6185[dtype-1220])(Current, loc3));
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2207[Dtype(loc5)-254])(loc5, (EIF_REFERENCE) &arg1, (EIF_REFERENCE) &ti4_1);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6193[dtype-1220])(Current, (EIF_REFERENCE) &arg1);
				loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6212[dtype-1220])(Current, loc4);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				for (;;) {
					if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
					ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6185[dtype-1220])(Current, loc1));
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2207[Dtype(loc5)-254])(loc5, (EIF_REFERENCE) &arg1, (EIF_REFERENCE) &ti4_1);
					if (tb1) {
						loc3 = (EIF_INTEGER_32) loc1;
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2 = (EIF_INTEGER_32) loc1;
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc1);
						loc1 = (EIF_INTEGER_32) ti4_1;
					}
				}
			}
			*(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]) = (EIF_INTEGER_32) loc3;
			*(EIF_INTEGER_32 *)(Current + O6220[dtype-1211]) = (EIF_INTEGER_32) loc4;
			*(EIF_INTEGER_32 *)(Current + O6221[dtype-1211]) = (EIF_INTEGER_32) loc2;
		} else {
			tb1 = '\01';
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
				tb2 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc3) <= ((EIF_INTEGER_32) -2L));
			}
			if (!tb2) {
				tb1 = (EIF_BOOLEAN)(arg1 != (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6185[dtype-1220])(Current, loc3)));
			}
			if (tb1) {
				loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6193[dtype-1220])(Current, (EIF_REFERENCE) &arg1);
				loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6212[dtype-1220])(Current, loc4);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				for (;;) {
					if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
					if ((EIF_BOOLEAN)(arg1 == (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6185[dtype-1220])(Current, loc1)))) {
						loc3 = (EIF_INTEGER_32) loc1;
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2 = (EIF_INTEGER_32) loc1;
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc1);
						loc1 = (EIF_INTEGER_32) ti4_1;
					}
				}
				*(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]) = (EIF_INTEGER_32) loc3;
				*(EIF_INTEGER_32 *)(Current + O6220[dtype-1211]) = (EIF_INTEGER_32) loc4;
				*(EIF_INTEGER_32 *)(Current + O6221[dtype-1211]) = (EIF_INTEGER_32) loc2;
			}
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.position_of_key */
EIF_INTEGER_32 F1213_8265 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (EIF_FALSE) {
		RTLE;
		return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6212[dtype-1220])(Current, *(EIF_INTEGER_32 *)(Current + O6217[dtype-1211]));
	} else {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6191[dtype-1220])(Current);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6193[dtype-1220])(Current, (EIF_REFERENCE) &arg1);
			loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6212[dtype-1220])(Current, loc3);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			for (;;) {
				if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
				ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6185[dtype-1220])(Current, loc1));
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2207[Dtype(loc4)-254])(loc4, (EIF_REFERENCE) &arg1, (EIF_REFERENCE) &ti4_1);
				if (tb1) {
					loc2 = (EIF_INTEGER_32) loc1;
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				} else {
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc1);
					loc1 = (EIF_INTEGER_32) ti4_1;
				}
			}
		} else {
			loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6193[dtype-1220])(Current, (EIF_REFERENCE) &arg1);
			loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6212[dtype-1220])(Current, loc3);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			for (;;) {
				if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
				if ((EIF_BOOLEAN)(arg1 == (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6185[dtype-1220])(Current, loc1)))) {
					loc2 = (EIF_INTEGER_32) loc1;
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				} else {
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc1);
					loc1 = (EIF_INTEGER_32) ti4_1;
				}
			}
		}
		RTLE;
		return (EIF_INTEGER_32) loc2;
	}/* NOTREACHED */
	
}

/* {DS_SPARSE_CONTAINER}.remove_position */
void F1213_8269 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != *(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]))) {
		loc1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6185[dtype-1220])(Current, arg1));
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6193[dtype-1220])(Current, (EIF_REFERENCE) &loc1);
		if ((EIF_BOOLEAN)((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6212[dtype-1220])(Current, loc2) == arg1)) {
			*(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]) = (EIF_INTEGER_32) arg1;
			*(EIF_INTEGER_32 *)(Current + O6220[dtype-1211]) = (EIF_INTEGER_32) loc2;
			*(EIF_INTEGER_32 *)(Current + O6221[dtype-1211]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		} else {
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6191[dtype-1220])(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6192[dtype-1220])(Current, NULL);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6189[dtype-1220])(Current, (EIF_REFERENCE) &loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6192[dtype-1220])(Current, loc3);
		}
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6229[dtype-1220])(Current, *(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]));
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O6221[dtype-1211]) == ((EIF_INTEGER_32) -1L))) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, *(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]));
		ti4_2 = *(EIF_INTEGER_32 *)(Current + O6220[dtype-1211]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6213[dtype-1220])(Current, ti4_1, ti4_2);
	} else {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, *(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]));
		ti4_2 = *(EIF_INTEGER_32 *)(Current + O6221[dtype-1211]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6207[dtype-1220])(Current, ti4_1, ti4_2);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O6218[dtype-1211]) == ((EIF_INTEGER_32) -1L)) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]) == *(EIF_INTEGER_32 *)(Current + O6182[dtype-1211])))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6199[dtype-1220])(Current, *(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6205[dtype-1220])(Current, *(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6207[dtype-1220])(Current, ((EIF_INTEGER_32) -1L), *(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]));
		*(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		(*(EIF_INTEGER_32 *)(Current + O6182[dtype-1211]))--;
	} else {
		tr1 = RTLNTY2(eif_final_id(Y5938,Y5938_gen_type,dftype,1124), 0x00);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3733[Dtype(tr1)-833])(tr1);
		if (tb1) {
			tr1 = RTLNTY2(eif_final_id(Y5938,Y5938_gen_type,dftype,1124), 0x00);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3741[Dtype(tr1)-833])(tr1);
			tr2 = RTCCL(tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6184[dtype-1220])(Current, tr2, ti4_1);
		}
		tr1 = RTLNTY2(eif_final_id(Y6234,Y6234_gen_type,dftype,1211), 0x00);
		tb1 = (EIF_BOOLEAN) eif_builtin_TYPE_has_default__b (tr1);
		if (tb1) {
			tr1 = RTLNTY2(eif_final_id(Y6234,Y6234_gen_type,dftype,1211), 0x00);
			ti4_1 = F845_4581(tr1);
			ti4_2 = *(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6201[dtype-1220])(Current, (EIF_REFERENCE) &ti4_1, ti4_2);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6207[dtype-1220])(Current, (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - *(EIF_INTEGER_32 *)(Current + O6218[dtype-1211])), *(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]));
		*(EIF_INTEGER_32 *)(Current + O6218[dtype-1211]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O6219[dtype-1211]);
	}
	(*(EIF_INTEGER_32 *)(Current + O6233[dtype-1211]))--;
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.set_internal_cursor */
void F1213_8301 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {DS_SPARSE_CONTAINER}.internal_cursor */
EIF_REFERENCE F1213_8302 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {DS_SPARSE_CONTAINER}.move_all_cursors_after */
void F1213_8303 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5737[Dtype(RTCW(loc1))-1085])(loc1);
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5710[Dtype(RTCW(loc1))-1085])(loc1, NULL);
		loc1 = (EIF_REFERENCE) loc2;
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.move_cursors_forth */
void F1213_8306 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == arg1)) {
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
				loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
				loc5 = *(EIF_INTEGER_32 *)(Current + O6182[dtype-1211]);
				for (;;) {
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (loc4 > loc5)) {
						tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc4) > ((EIF_INTEGER_32) -2L));
					}
					if (tb1) break;
					loc4++;
				}
			}
			if ((EIF_BOOLEAN) (loc4 > loc5)) {
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R5737[Dtype(RTCW(loc1))-1085])(loc1);
				if ((EIF_BOOLEAN)(loc3 == NULL)) {
					loc3 = (EIF_REFERENCE) loc1;
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
					loc1 = (EIF_REFERENCE) tr1;
				} else {
					loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5710[Dtype(RTCW(loc3))-1085])(loc3, loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5710[Dtype(RTCW(loc1))-1085])(loc1, NULL);
					loc1 = (EIF_REFERENCE) loc2;
				}
			} else {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5736[Dtype(RTCW(loc1))-1085])(loc1, loc4);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
				loc1 = (EIF_REFERENCE) tr1;
			}
		} else {
			loc3 = (EIF_REFERENCE) loc1;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			loc1 = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_item */
EIF_REFERENCE F1213_8307 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6183[Dtype(Current)-1220])(Current, ti4_1);
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_is_first */
EIF_BOOLEAN F1213_8308 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5930[dtype-1184])(Current)) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc1) > ((EIF_INTEGER_32) -2L))) break;
			loc1++;
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == loc1);
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_is_last */
EIF_BOOLEAN F1213_8309 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5930[dtype-1184])(Current)) {
		loc1 = *(EIF_INTEGER_32 *)(Current + O6182[dtype-1211]);
		for (;;) {
			if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc1) > ((EIF_INTEGER_32) -2L))) break;
			loc1--;
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == loc1);
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_same_position */
EIF_BOOLEAN F1213_8310 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_0_0_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_start */
void F1213_8311 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5930[dtype-1184])(Current)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5737[Dtype(RTCW(arg1))-1085])(arg1);
	} else {
		loc3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5969[dtype-1184])(Current, arg1);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		loc2 = *(EIF_INTEGER_32 *)(Current + O6182[dtype-1211]);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 > loc2)) {
				tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc1) > ((EIF_INTEGER_32) -2L));
			}
			if (tb1) break;
			loc1++;
		}
		if ((EIF_BOOLEAN) (loc1 > loc2)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5737[Dtype(RTCW(arg1))-1085])(arg1);
			if ((EIF_BOOLEAN) !loc3) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5973[dtype-1184])(Current, arg1);
			}
		} else {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5736[Dtype(RTCW(arg1))-1085])(arg1, loc1);
			if (loc3) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5972[dtype-1184])(Current, arg1);
			}
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_finish */
void F1213_8312 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5930[dtype-1184])(Current)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5738[Dtype(RTCW(arg1))-1085])(arg1);
	} else {
		loc2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5969[dtype-1184])(Current, arg1);
		loc1 = *(EIF_INTEGER_32 *)(Current + O6182[dtype-1211]);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
				tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc1) > ((EIF_INTEGER_32) -2L));
			}
			if (tb1) break;
			loc1--;
		}
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5738[Dtype(RTCW(arg1))-1085])(arg1);
			if ((EIF_BOOLEAN) !loc2) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5973[dtype-1184])(Current, arg1);
			}
		} else {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5736[Dtype(RTCW(arg1))-1085])(arg1, loc1);
			if (loc2) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5972[dtype-1184])(Current, arg1);
			}
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_forth */
void F1213_8313 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_1 = ((EIF_INTEGER_32) -2L);
	if ((EIF_BOOLEAN)(loc4 == ti4_1)) {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
	}
	loc2 = *(EIF_INTEGER_32 *)(Current + O6182[dtype-1211]);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 > loc2)) {
			tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc1) > ((EIF_INTEGER_32) -2L));
		}
		if (tb1) break;
		loc1++;
	}
	if ((EIF_BOOLEAN) (loc1 > loc2)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5737[Dtype(RTCW(arg1))-1085])(arg1);
		if ((EIF_BOOLEAN) !loc3) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5973[dtype-1184])(Current, arg1);
		}
	} else {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5736[Dtype(RTCW(arg1))-1085])(arg1, loc1);
		if (loc3) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5972[dtype-1184])(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_back */
void F1213_8314 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_1 = ((EIF_INTEGER_32) -3L);
	if ((EIF_BOOLEAN)(loc3 == ti4_1)) {
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc1 = *(EIF_INTEGER_32 *)(Current + O6182[dtype-1211]);
	} else {
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
	}
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
			tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6186[dtype-1220])(Current, loc1) > ((EIF_INTEGER_32) -2L));
		}
		if (tb1) break;
		loc1--;
	}
	if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5738[Dtype(RTCW(arg1))-1085])(arg1);
		if ((EIF_BOOLEAN) !loc2) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5973[dtype-1184])(Current, arg1);
		}
	} else {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5736[Dtype(RTCW(arg1))-1085])(arg1, loc1);
		if (loc2) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5972[dtype-1184])(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_go_after */
void F1213_8317 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5969[dtype-1184])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5737[Dtype(RTCW(arg1))-1085])(arg1);
	if ((EIF_BOOLEAN) !loc1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5973[dtype-1184])(Current, arg1);
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_go_before */
void F1213_8318 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5969[dtype-1184])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5738[Dtype(RTCW(arg1))-1085])(arg1);
	if ((EIF_BOOLEAN) !loc1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5973[dtype-1184])(Current, arg1);
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.new_capacity */
EIF_INTEGER_32 F1213_8320 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * arg1);
}

/* {DS_SPARSE_CONTAINER}.new_modulus */
EIF_INTEGER_32 F1213_8321 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)) * ((EIF_INTEGER_32) 3L)) / ((EIF_INTEGER_32) 2L));
}

void EIF_Minit836 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
