
#ifndef _C17_ds824_
#define _C17_ds824_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1062_7403(EIF_REFERENCE);
extern EIF_BOOLEAN F1062_7405(EIF_REFERENCE);
extern void F1062_7406(EIF_REFERENCE);
extern void F1062_7407(EIF_REFERENCE);
extern void F1062_7409(EIF_REFERENCE);
extern void EIF_Minit824(void);
extern char *(*R5722[])();
extern char *(*R6005[])();
extern char *(*R6007[])();
extern char *(*R6008[])();
extern char *(*R5704[])();
extern char *(*R6010[])();
extern char *(*R2921[])();

#ifdef __cplusplus
}
#endif

#endif
