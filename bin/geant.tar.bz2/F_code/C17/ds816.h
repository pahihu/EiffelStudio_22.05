
#ifndef _C17_ds816_
#define _C17_ds816_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1126_7674(EIF_REFERENCE);
extern void EIF_Minit816(void);
extern char *(*R5929[])();

#ifdef __cplusplus
}
#endif

#endif
