/*
 * Code for class DS_ARRAYED_SPARSE_TABLE [G#1, INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds826.h"
#include "eif_built_in.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_ARRAYED_SPARSE_TABLE}.item_storage_item */
EIF_REFERENCE F1229_8432 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(tr1))-712])(tr1, arg1);
	RTLE;
	return Result;
}

/* {DS_ARRAYED_SPARSE_TABLE}.item_storage_put */
void F1229_8433 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr3 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R236[Dtype(RTCW(tr1))-23])(tr1, tr2, tr3, arg2);
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.key_storage_item */
EIF_INTEGER_32 F1229_8434 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (arg1));
	/* END INLINED CODE */
	Result = ti4_2;
	RTLE;
	return Result;
}

/* {DS_ARRAYED_SPARSE_TABLE}.clashes_item */
EIF_INTEGER_32 F1229_8435 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (arg1));
	/* END INLINED CODE */
	Result = ti4_2;
	RTLE;
	return Result;
}

/* {DS_ARRAYED_SPARSE_TABLE}.make_item_storage */
void F1229_8437 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y6268,Y6268_gen_type,Dftype(Current),1227).id);
	F1_29(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R231[Dtype(RTCW(tr1))-23])(tr1, arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.clone_item_storage */
void F1229_8438 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2871[Dtype(RTCW(tr2))-712])(tr2);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3386[Dtype(RTCW(tr1))-712])(tr1, ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.item_storage_resize */
void F1229_8439 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R239[Dtype(RTCW(tr1))-23])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_4_), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.item_storage_wipe_out */
void F1229_8440 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R3382[Dtype(RTCW(tr1))-712])(tr1, ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.item_storage_keep_head */
void F1229_8441 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R3382[Dtype(RTCW(tr1))-712])(tr1, arg1);
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.make_key_storage */
void F1229_8443 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y6269,Y6269_gen_type,Dftype(Current),1227).id);
	F1_29(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tr1 = F25_227(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.key_storage_put */
void F1229_8444 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	F25_232(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_5_), arg1, arg2);
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.clone_key_storage */
void F1229_8445 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (tr2);
	tr1 = F715_4002(RTCW(tr1), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.key_storage_resize */
void F1229_8446 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tr1 = F25_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_5_), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.key_storage_wipe_out */
void F1229_8447 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F715_3998(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.key_storage_keep_head */
void F1229_8448 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F715_3998(RTCW(tr1), arg1);
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.make_clashes */
void F1229_8450 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSP2(typres0.id,0,arg1,sizeof(EIF_INTEGER_32), EIF_TRUE);
	}
	F715_3970(RTCW(tr1), ((EIF_INTEGER_32) -1L), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.clashes_put */
void F1229_8451 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_INTEGER_32 *)RTCW(tr1) + (arg2)) = arg1;
	/* END INLINED CODE */
	;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.clone_clashes */
void F1229_8452 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (tr2);
	tr1 = F715_4002(RTCW(tr1), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.clashes_resize */
void F1229_8453 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(2947,F301_2947, (Current));
	tr1 = F25_236(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_6_), ((EIF_INTEGER_32) -1L), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.clashes_wipe_out */
void F1229_8454 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + (loc1)) = ((EIF_INTEGER_32) -1L);
		/* END INLINED CODE */
		;
		loc1--;
	}
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.make_slots */
void F1229_8456 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,714,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSP2(typres0.id,0,arg1,sizeof(EIF_INTEGER_32), EIF_TRUE);
	}
	F715_3970(RTCW(tr1), ((EIF_INTEGER_32) -1L), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.slots_item */
EIF_INTEGER_32 F1229_8457 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (arg1));
	/* END INLINED CODE */
	Result = ti4_2;
	RTLE;
	return Result;
}

/* {DS_ARRAYED_SPARSE_TABLE}.slots_put */
void F1229_8458 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_INTEGER_32 *)RTCW(tr1) + (arg2)) = arg1;
	/* END INLINED CODE */
	;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.clone_slots */
void F1229_8459 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (tr2);
	tr1 = F715_4002(RTCW(tr1), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.slots_resize */
void F1229_8460 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(2947,F301_2947, (Current));
	tr1 = F25_236(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_7_), ((EIF_INTEGER_32) -1L), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.slots_wipe_out */
void F1229_8461 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + (loc1)) = ((EIF_INTEGER_32) -1L);
		/* END INLINED CODE */
		;
		loc1--;
	}
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.correct_mismatch */
void F1229_8464 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(4236,F808_4236, (Current))) + _REFACS_7_);
	loc2 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc2))) {
		tb2 = F950_6193(loc2);
		tb1 = tb2;
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6270[dtype-1232])(Current);
	} else {
		tb1 = F943_5858(loc2);
		if (tb1) {
			loc1 = F943_5892(loc2);
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 20130823L))) {
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R6270[dtype-1232])(Current);
			} else {
				F808_4235(Current);
			}
		} else {
			F808_4235(Current);
		}
	}
	RTLE;
}

/* {DS_ARRAYED_SPARSE_TABLE}.correct_mismatch_20130823 */
void F1229_8465 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R3379[Dtype(RTCW(tr1))-712])(tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 0L), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R3382[Dtype(RTCW(tr1))-712])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	/* INLINED CODE (SPECIAL.overlapping_move) */
	memmove((EIF_INTEGER_32 *)RTCW(tr1) + (((EIF_INTEGER_32) 0L)),(EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) 1L), (rt_uint_ptr)sizeof(EIF_INTEGER_32) * (rt_uint_ptr)*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_));
	RT_SPECIAL_COUNT(tr1) = eif_max_int32(RT_SPECIAL_COUNT(tr1), ((EIF_INTEGER_32) 0L) + *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_));
	/* END INLINED CODE */
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F715_3998(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc2 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		/* INLINED CODE (SPECIAL.item) */
		ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr2) + (loc1));
		/* END INLINED CODE */
		ti4_1 = ti4_2;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)))) = (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L));
		/* END INLINED CODE */
		;
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr2);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)))) = ((EIF_INTEGER_32) -1L);
	/* END INLINED CODE */
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		/* INLINED CODE (SPECIAL.item) */
		ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr2) + (loc1));
		/* END INLINED CODE */
		ti4_1 = ti4_2;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + (loc1)) = (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L));
		/* END INLINED CODE */
		;
		loc1--;
	}
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_5_))--;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_6_))--;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_))--;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_))--;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_))--;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2871[Dtype(RTCW(tr1))-712])(tr1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

void EIF_Minit826 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
