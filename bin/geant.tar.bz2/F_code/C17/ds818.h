
#ifndef _C17_ds818_
#define _C17_ds818_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1140_7705(EIF_REFERENCE);
extern EIF_BOOLEAN F1140_7707(EIF_REFERENCE);
extern EIF_BOOLEAN F1140_7709(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1140_7714(EIF_REFERENCE, EIF_REFERENCE);
extern void F1140_7717(EIF_REFERENCE, EIF_REFERENCE);
extern void F1140_7718(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit818(void);
extern void F1040_7384(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5967[])();
extern char *(*R5968[])();
extern char *(*R5704[])();
extern char *(*R5705[])();

#ifdef __cplusplus
}
#endif

#endif
