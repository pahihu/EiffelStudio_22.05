
#ifndef _C17_ha802_
#define _C17_ha802_

#ifdef __cplusplus
extern "C" {
#endif

extern void F822_4335(EIF_REFERENCE, EIF_INTEGER_32);
extern void F822_4338(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F822_4339(EIF_REFERENCE);
extern EIF_REFERENCE F822_4341(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F822_4343(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F822_4350(EIF_REFERENCE);
extern EIF_INTEGER_32 F822_4352(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F822_4353(EIF_REFERENCE);
extern EIF_INTEGER_32 F822_4356(EIF_REFERENCE);
extern EIF_INTEGER_32 F822_4357(EIF_REFERENCE);
extern EIF_BOOLEAN F822_4358(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F822_4359(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F822_4367(EIF_REFERENCE);
extern EIF_BOOLEAN F822_4368(EIF_REFERENCE);
extern void F822_4377(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F822_4379(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F822_4380(EIF_REFERENCE, EIF_INTEGER_32);
extern void F822_4381(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F822_4382(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F822_4389(EIF_REFERENCE);
extern void F822_4392(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F822_4393(EIF_REFERENCE, EIF_INTEGER_32);
extern void F822_4394(EIF_REFERENCE);
extern EIF_INTEGER_32 F822_4403(EIF_REFERENCE);
extern EIF_BOOLEAN F822_4404(EIF_REFERENCE);
extern EIF_REFERENCE F822_4411(EIF_REFERENCE);
extern EIF_REFERENCE F822_4412(EIF_REFERENCE);
extern EIF_INTEGER_32 F822_4413(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F822_4414(EIF_REFERENCE, EIF_INTEGER_32);
extern void F822_4417(EIF_REFERENCE, EIF_REFERENCE);
extern void F822_4419(EIF_REFERENCE, EIF_REFERENCE);
extern void F822_4420(EIF_REFERENCE, EIF_REFERENCE);
extern void F822_4421(EIF_REFERENCE, EIF_REFERENCE);
extern void F822_4425(EIF_REFERENCE, EIF_REFERENCE);
extern void F822_4431(EIF_REFERENCE);
extern void F822_4444(EIF_REFERENCE);
extern void EIF_Minit802(void);
extern void F722_3970(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F715_3991(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F722_3988(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern EIF_INTEGER_32 F635_3582(EIF_REFERENCE, EIF_INTEGER_32);
extern void F715_3970(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F808_4236(EIF_REFERENCE);
extern void F722_3991(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F808_4235(EIF_REFERENCE);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern EIF_INTEGER_32 F722_3981(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,4236)
extern char *(*R3547[])();
extern char *(*R3549[])();
extern char *(*R3623[])();
extern char *(*R3355[])();
extern char *(*R3085[])();
extern char *(*R3592[])();
extern char *(*R3593[])();
extern char *(*R3121[])();
extern char *(*R3596[])();
extern char *(*R3598[])();
extern char *(*R3599[])();
extern char *(*R3583[])();
extern char *(*R3610[])();
extern char *(*R3567[])();
extern char *(*R3050[])();
extern char *(*R3053[])();
extern char *(*R3372[])();
extern char *(*R2933[])();
extern char *(*R3564[])();
extern char *(*R3566[])();
extern char *(*R3640[])();
extern char *(*R2870[])();
extern char *(*R3582[])();
extern char *(*R3604[])();
extern char *(*R2871[])();
extern char *(*R3573[])();
extern char *(*R3555[])();
extern char *(*R3535[])();
extern char *(*R3556[])();
extern char *(*R3600[])();
extern char *(*R3538[])();
extern char *(*R3539[])();
extern char *(*R2920[])();
extern char *(*R2921[])();
extern char *(*R2922[])();
extern char *(*R2981[])();
extern char *(*R3391[])();
extern long O3575[];
extern long O3576[];
extern long O3577[];
extern long O3578[];
extern long O3579[];
extern long O3539[];
extern long O3580[];
extern long O3581[];
extern long O3584[];
extern long O3585[];
extern long O3083[];
extern long O3589[];
extern long O3548[];
extern long O3625[];
extern long O3590[];
extern long O3591[];
extern EIF_TYPE_INDEX Y3575[];
extern EIF_TYPE_INDEX *Y3575_gen_type [];
extern EIF_TYPE_INDEX Y3576[];
extern EIF_TYPE_INDEX *Y3576_gen_type [];
extern EIF_TYPE_INDEX Y3123[];
extern EIF_TYPE_INDEX *Y3123_gen_type [];
extern EIF_TYPE_INDEX Y2982[];
extern EIF_TYPE_INDEX *Y2982_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
