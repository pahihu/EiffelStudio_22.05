
#ifndef _C17_kl823_
#define _C17_kl823_

#ifdef __cplusplus
extern "C" {
#endif

extern void F751_4116(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit823(void);

#ifdef __cplusplus
}
#endif

#endif
