
#ifndef _C17_lx810_
#define _C17_lx810_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1112_7500(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F1112_7503(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1112_7512(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F1112_7514(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1112_7515(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit810(void);
extern EIF_REFERENCE F953_6290(EIF_REFERENCE);
extern EIF_BOOLEAN F14_181(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,6290)
extern char *(*R11[])();
extern char *(*R6245[])();
extern char *(*R1952[])();
extern char *(*R6176[])();
extern char *(*R6177[])();
extern char *(*R5947[])();
extern char *(*R6254[])();

#ifdef __cplusplus
}
#endif

#endif
