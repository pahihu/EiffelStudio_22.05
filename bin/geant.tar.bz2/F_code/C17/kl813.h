
#ifndef _C17_kl813_
#define _C17_kl813_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F256_2460(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit813(void);

#ifdef __cplusplus
}
#endif

#endif
