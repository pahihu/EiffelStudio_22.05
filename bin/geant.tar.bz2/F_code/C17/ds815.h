
#ifndef _C17_ds815_
#define _C17_ds815_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1146_7722(EIF_REFERENCE, EIF_REFERENCE);
extern void F1146_7726(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit815(void);

#ifdef __cplusplus
}
#endif

#endif
