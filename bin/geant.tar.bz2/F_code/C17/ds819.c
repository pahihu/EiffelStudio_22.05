/*
 * Code for class DS_CURSOR [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds819.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_CURSOR}.item */
EIF_INTEGER_32 F1040_7375 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5704[Dtype(Current)-1085])(Current);
	Result = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5968[Dtype(RTCW(tr1))-1184])(tr1, Current));
	RTLE;
	return Result;
}

/* {DS_CURSOR}.same_position */
EIF_BOOLEAN F1040_7378 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5704[Dtype(Current)-1085])(Current);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5970[Dtype(RTCW(tr1))-1184])(tr1, Current, arg1);
	RTLE;
	return Result;
}

/* {DS_CURSOR}.copy */
void F1040_7381 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)((FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5704[dtype-1085])(Current) != NULL)) {
		tb1 = (EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5705[dtype-1085])(Current);
	}
	if (tb1) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5704[dtype-1085])(Current);
		F1140_7718(RTCW(tr1), Current);
	}
	eif_builtin_ANY_standard_copy__o_ (Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5705[dtype-1085])(Current)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5704[dtype-1085])(Current);
		F1140_7717(RTCW(tr1), Current);
	}
	RTLE;
}

/* {DS_CURSOR}.is_equal */
EIF_BOOLEAN F1040_7382 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(6290,F953_6290, (Current));
	tb1 = F14_181(RTCW(tr1), Current, arg1);
	if (tb1) {
		RTLE;
		return (EIF_BOOLEAN) F1040_7378(Current, arg1);
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {DS_CURSOR}.set_next_cursor */
void F1040_7384 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

void EIF_Minit819 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
