/*
 * Code for class KL_SHARED_STRING_EQUALITY_TESTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl135.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SHARED_STRING_EQUALITY_TESTER}.string_equality_tester */
static EIF_REFERENCE F201_2196_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2196);
#define Result RTOSR(2196)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(260, 0x01).id, 260, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2196);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F201_2196 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2196,F201_2196_body,(Current));
}

/* {KL_SHARED_STRING_EQUALITY_TESTER}.string_32_equality_tester */
static EIF_REFERENCE F201_2198_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2198);
#define Result RTOSR(2198)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,254,0xFF01,947,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 254, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2198);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F201_2198 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2198,F201_2198_body,(Current));
}

void EIF_Minit135 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
