
#ifndef _C3_xm131_
#define _C3_xm131_

#ifdef __cplusplus
extern "C" {
#endif

extern void F197_2158(EIF_REFERENCE, EIF_REFERENCE);
extern void F197_2159(EIF_REFERENCE);
extern void F197_2160(EIF_REFERENCE);
extern void EIF_Minit131(void);
extern void F196_2146(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F191_2108(EIF_REFERENCE);
extern char *(*R1966[])();

#ifdef __cplusplus
}
#endif

#endif
