/*
 * Code for class KL_SHARED_EXECUTION_ENVIRONMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl139.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SHARED_EXECUTION_ENVIRONMENT}.execution_environment */
static EIF_REFERENCE F207_2207_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2207);
#define Result RTOSR(2207)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(993, 0x01).id, 993, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2207);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F207_2207 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2207,F207_2207_body,(Current));
}

void EIF_Minit139 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
