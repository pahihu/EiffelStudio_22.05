
#ifndef _C3_kl139_
#define _C3_kl139_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2207)
static EIF_REFERENCE F207_2207_body(EIF_REFERENCE);
extern EIF_REFERENCE F207_2207(EIF_REFERENCE);
extern void EIF_Minit139(void);

#ifdef __cplusplus
}
#endif

#endif
