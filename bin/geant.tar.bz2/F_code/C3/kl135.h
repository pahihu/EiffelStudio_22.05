
#ifndef _C3_kl135_
#define _C3_kl135_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2196)
static EIF_REFERENCE F201_2196_body(EIF_REFERENCE);
extern EIF_REFERENCE F201_2196(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,2198)
static EIF_REFERENCE F201_2198_body(EIF_REFERENCE);
extern EIF_REFERENCE F201_2198(EIF_REFERENCE);
extern void EIF_Minit135(void);

#ifdef __cplusplus
}
#endif

#endif
