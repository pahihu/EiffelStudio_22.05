
#ifndef _C3_ex140_
#define _C3_ex140_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2208)
static EIF_REFERENCE F208_2208_body(EIF_REFERENCE);
extern EIF_REFERENCE F208_2208(EIF_REFERENCE);
extern void EIF_Minit140(void);

#ifdef __cplusplus
}
#endif

#endif
