
#ifndef _C3_yy120_
#define _C3_yy120_

#ifdef __cplusplus
extern "C" {
#endif

extern void F181_2061(EIF_REFERENCE, EIF_REFERENCE);
extern void F181_2062(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F181_2063(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F181_2064(EIF_REFERENCE);
extern void F181_2067(EIF_REFERENCE, EIF_REFERENCE);
extern void F181_2068(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F181_2071(EIF_REFERENCE);
extern void EIF_Minit120(void);
extern EIF_INTEGER_32 F178_2050(EIF_REFERENCE);
extern EIF_REFERENCE F178_2048(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F171_1916(EIF_REFERENCE);
extern void F178_2025(EIF_REFERENCE, EIF_REFERENCE);
extern void F178_2046(EIF_REFERENCE);
extern void F178_2044(EIF_REFERENCE);
RTOSHF(EIF_INTEGER_32,2050)
RTOSHF(EIF_REFERENCE,1916)
extern char *(*R1539[])();
extern char *(*R1545[])();
extern char *(*R1547[])();
extern char *(*R1548[])();
extern char *(*R1045[])();
extern char *(*R1046[])();
extern char *(*R1049[])();

#ifdef __cplusplus
}
#endif

#endif
