
#ifndef _C3_kl142_
#define _C3_kl142_

#ifdef __cplusplus
extern "C" {
#endif

extern void F210_2234(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit142(void);

#ifdef __cplusplus
}
#endif

#endif
