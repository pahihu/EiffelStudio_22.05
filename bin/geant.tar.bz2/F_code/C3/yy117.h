
#ifndef _C3_yy117_
#define _C3_yy117_

#ifdef __cplusplus
extern "C" {
#endif

extern void F178_2025(EIF_REFERENCE, EIF_REFERENCE);
extern void F178_2026(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F178_2027(EIF_REFERENCE);
extern void F178_2037(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F178_2038(EIF_REFERENCE, EIF_INTEGER_32);
extern void F178_2043(EIF_REFERENCE);
extern void F178_2044(EIF_REFERENCE);
extern void F178_2046(EIF_REFERENCE);
extern EIF_REFERENCE F178_2048(EIF_REFERENCE, EIF_INTEGER_32);
extern void F178_2049(EIF_REFERENCE);
RTOSHF (EIF_INTEGER_32,2050)
static EIF_INTEGER_32 F178_2050_body(EIF_REFERENCE);
extern EIF_INTEGER_32 F178_2050(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 2052)


extern EIF_REFERENCE F178_2052(EIF_REFERENCE);
extern void EIF_Minit117(void);
extern void F304_2981(EIF_REFERENCE, EIF_INTEGER_32);
extern void F91_1075(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R1920[])();
extern char *(*R1044[])();
extern char *(*R1045[])();
extern char *(*R1047[])();
extern char *(*R1049[])();
extern long O1905[];
extern long O1906[];
extern long O1907[];
extern long O1912[];
extern long O1901[];
extern long O1902[];
extern long O1903[];
extern long O1904[];

#ifdef __cplusplus
}
#endif

#endif
