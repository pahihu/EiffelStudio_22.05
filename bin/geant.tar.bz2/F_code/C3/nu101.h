
#ifndef _C3_nu101_
#define _C3_nu101_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F162_1775(EIF_REFERENCE);
extern void EIF_Minit101(void);

#ifdef __cplusplus
}
#endif

#endif
