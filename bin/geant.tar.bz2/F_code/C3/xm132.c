/*
 * Code for class XM_CALLBACKS_TO_TREE_FILTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm132.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_CALLBACKS_TO_TREE_FILTER}.initialize */
void F198_2161 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1285, 1).id);
	F1286_9160(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1220,0xFF01,984,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1217_8322(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_CALLBACKS_TO_TREE_FILTER}.enable_position_table */
void F198_2165 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	tr1 = RTLNSMART(eif_new_type(31, 0).id);
	F32_377(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_CALLBACKS_TO_TREE_FILTER}.on_start */
void F198_2167 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F198_2161(Current);
}

/* {XM_CALLBACKS_TO_TREE_FILTER}.on_start_tag */
void F198_2168 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc1);
	RTLR(6,arg3);
	RTLR(7,arg2);
	RTLR(8,tr2);
	RTLIU(9);
	
	RTGC;
	RTCT0("has_resolved_namespaces", EX_CHECK);
	loc2 = arg1;
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		loc1 = RTLNS(eif_new_type(1286, 0x01).id, 1286, _OBJSIZ_4_0_0_0_0_0_0_0_);
		tr1 = F198_2175(Current, loc2, arg2);
		F1287_9176(RTCW(loc1), loc3, arg3, tr1);
	} else {
		loc1 = RTLNS(eif_new_type(1286, 0x01).id, 1286, _OBJSIZ_4_0_0_0_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = F198_2175(Current, loc2, arg2);
		F1287_9177(RTCW(loc1), tr1, arg3, tr2);
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) loc1;
	F198_2177(Current, loc1);
	RTLE;
}

/* {XM_CALLBACKS_TO_TREE_FILTER}.on_attribute */
void F198_2169 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc1);
	RTLR(6,arg3);
	RTLR(7,arg2);
	RTLR(8,arg4);
	RTLIU(9);
	
	RTGC;
	RTCT0("has_resolved_namespaces", EX_CHECK);
	loc2 = arg1;
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTCT0("element_not_void", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc1 = RTLNS(eif_new_type(1283, 0x01).id, 1283, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr1 = F198_2175(Current, loc2, arg2);
	F1284_9113(RTCW(loc1), arg3, tr1, arg4, loc3);
	F198_2177(Current, loc1);
	RTLE;
}

/* {XM_CALLBACKS_TO_TREE_FILTER}.on_content */
void F198_2170 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	RTCT0("not_finished", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc1 = RTLNS(eif_new_type(1281, 0x01).id, 1281, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1282_9096(RTCW(loc1), loc2, arg1);
	F198_2177(Current, loc1);
	RTLE;
}

/* {XM_CALLBACKS_TO_TREE_FILTER}.on_end_tag */
void F198_2171 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	RTCT0("open_composite_exists", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(loc1);
	loc2 = tr1;
	if (!((EIF_BOOLEAN) !(EIF_TRUE))) {
		tb2 = F1276_9071(loc2);
		tb1 = tb2;
	}
	if (tb1) {
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	} else {
		tr1 = F1276_9068(loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {XM_CALLBACKS_TO_TREE_FILTER}.on_processing_instruction */
void F198_2172 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = RTLNS(eif_new_type(1280, 0x01).id, 1280, _OBJSIZ_3_0_0_0_0_0_0_0_);
		F1281_9088(RTCW(loc1), loc2, arg1, arg2);
	} else {
		loc1 = RTLNS(eif_new_type(1280, 0x01).id, 1280, _OBJSIZ_3_0_0_0_0_0_0_0_);
		F1281_9089(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_1_), arg1, arg2);
	}
	F198_2177(Current, loc1);
	RTLE;
}

/* {XM_CALLBACKS_TO_TREE_FILTER}.on_comment */
void F198_2173 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = RTLNS(eif_new_type(1279, 0x01).id, 1279, _OBJSIZ_2_0_0_0_0_0_0_0_);
		F1280_9082(RTCW(loc1), loc2, arg1);
	} else {
		loc1 = RTLNS(eif_new_type(1279, 0x01).id, 1279, _OBJSIZ_2_0_0_0_0_0_0_0_);
		F1280_9083(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_1_), arg1);
	}
	F198_2177(Current, loc1);
	RTLE;
}

/* {XM_CALLBACKS_TO_TREE_FILTER}.new_namespace */
EIF_REFERENCE F198_2175 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,Result);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	Result = RTLNS(eif_new_type(984, 0x01).id, 984, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F985_6665(RTCW(Result), arg2, arg1);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tb2 = F1217_8327(RTCW(tr1), Result);
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr1 = F1217_8325(RTCW(tr1), Result);
		tb2 = F985_6672(RTCW(tr1), Result);
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr1 = F1217_8325(RTCW(tr1), Result);
		Result = (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1217_8338(RTCW(tr1), Result);
	}
	RTLE;
	return Result;
}

/* {XM_CALLBACKS_TO_TREE_FILTER}.handle_position */
void F198_2177 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc2 = tr1;
	if ((EIF_BOOLEAN) (EIF_TEST(loc1) && EIF_TEST(loc2))) {
		tr1 = F1311_9891(loc2);
		F32_380(loc1, tr1, arg1);
	}
	RTLE;
}

void EIF_Minit132 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
