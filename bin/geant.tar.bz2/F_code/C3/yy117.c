/*
 * Code for class YY_BUFFER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy117.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_BUFFER}.make */
void F178_2025 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R1920[Dtype(Current)-177])(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
	F91_1075(RTCW(loc1), arg1, ((EIF_INTEGER_32) 1L));
	tc1 = (EIF_CHARACTER_8) '\000';
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1045[Dtype(RTCW(loc1))-302])(loc1, (EIF_REFERENCE) &tc1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
	tc1 = (EIF_CHARACTER_8) '\000';
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1045[Dtype(RTCW(loc1))-302])(loc1, (EIF_REFERENCE) &tc1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
	F178_2026(Current, loc1);
	RTLE;
}

/* {YY_BUFFER}.make_from_buffer */
void F178_2026 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1044[Dtype(RTCW(arg1))-302])(arg1);
	*(EIF_INTEGER_32 *)(Current + O1902[dtype-177]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L));
	*(EIF_INTEGER_32 *)(Current + O1901[dtype-177]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O1902[dtype-177]);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	*(EIF_INTEGER_32 *)(Current + O1906[dtype-177]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O1904[dtype-177]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O1905[dtype-177]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O1903[dtype-177]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_BOOLEAN *)(Current + O1907[dtype-177]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {YY_BUFFER}.name */
EIF_REFERENCE F178_2027 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) RTOSCF(2052,F178_2052, (Current));
}

/* {YY_BUFFER}.set_position */
void F178_2037 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O1903[dtype-177]) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current + O1904[dtype-177]) = (EIF_INTEGER_32) arg2;
	*(EIF_INTEGER_32 *)(Current + O1905[dtype-177]) = (EIF_INTEGER_32) arg3;
	RTLE;
}

/* {YY_BUFFER}.set_index */
void F178_2038 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O1906[Dtype(Current)-177]) = (EIF_INTEGER_32) arg1;
}

/* {YY_BUFFER}.fill */
void F178_2043 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O1912[Dtype(Current)-177]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {YY_BUFFER}.flush */
void F178_2044 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tc1 = (EIF_CHARACTER_8) '\000';
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1045[Dtype(RTCW(tr1))-302])(tr1, (EIF_REFERENCE) &tc1, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current);
	tc1 = (EIF_CHARACTER_8) '\000';
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1045[Dtype(RTCW(tr1))-302])(tr1, (EIF_REFERENCE) &tc1, ((EIF_INTEGER_32) 2L));
	*(EIF_INTEGER_32 *)(Current + O1901[dtype-177]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current + O1906[dtype-177]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O1904[dtype-177]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O1905[dtype-177]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O1903[dtype-177]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_BOOLEAN *)(Current + O1907[dtype-177]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O1912[dtype-177]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {YY_BUFFER}.compact_left */
void F178_2046 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O1901[dtype-177]);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O1906[dtype-177]);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ti4_1) + ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current + O1902[dtype-177]))) {
		F178_2049(Current);
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O1906[dtype-177]) != ((EIF_INTEGER_32) 1L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R1047[Dtype(RTCW(tr1))-302])(tr1, *(EIF_INTEGER_32 *)(Current + O1906[dtype-177]), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
		*(EIF_INTEGER_32 *)(Current + O1906[dtype-177]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		*(EIF_INTEGER_32 *)(Current + O1901[dtype-177]) = (EIF_INTEGER_32) loc1;
	}
	RTLE;
}

/* {YY_BUFFER}.new_default_buffer */
EIF_REFERENCE F178_2048 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(303, 0x01).id, 303, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F304_2981(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {YY_BUFFER}.resize */
void F178_2049 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O1902[dtype-177]) == ((EIF_INTEGER_32) 0L))) {
		ti4_1 = RTOSCF(2050,F178_2050, (Current));
		*(EIF_INTEGER_32 *)(Current + O1902[dtype-177]) = (EIF_INTEGER_32) ti4_1;
	} else {
		(*(EIF_INTEGER_32 *)(Current + O1902[dtype-177])) *= ((EIF_INTEGER_32) 2L);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1044[Dtype(RTCW(tr1))-302])(tr1);
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O1902[dtype-177]) + ((EIF_INTEGER_32) 2L)) > ti4_1)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R1049[Dtype(RTCW(tr1))-302])(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O1902[dtype-177]) + ((EIF_INTEGER_32) 2L)));
	}
	RTLE;
}

/* {YY_BUFFER}.default_capacity */
static EIF_INTEGER_32 F178_2050_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (2050);
#define Result RTOSR(2050)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16384L);
	RTOSE (2050);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F178_2050 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2050,F178_2050_body,(Current));
}

/* {YY_BUFFER}.name_constant */

EIF_REFERENCE F178_2052 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2052,RTMS_EX_H("<string>",8,1911048254));
}

void EIF_Minit117 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
