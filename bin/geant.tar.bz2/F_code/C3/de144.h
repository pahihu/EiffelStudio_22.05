
#ifndef _C3_de144_
#define _C3_de144_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F212_2267(EIF_REFERENCE);
extern void EIF_Minit144(void);

#ifdef __cplusplus
}
#endif

#endif
