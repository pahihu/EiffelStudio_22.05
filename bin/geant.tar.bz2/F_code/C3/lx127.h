
#ifndef _C3_lx127_
#define _C3_lx127_

#ifdef __cplusplus
extern "C" {
#endif

extern void F193_2111(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit127(void);

#ifdef __cplusplus
}
#endif

#endif
