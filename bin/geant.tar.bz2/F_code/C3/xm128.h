
#ifndef _C3_xm128_
#define _C3_xm128_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F194_2128(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit128(void);

#ifdef __cplusplus
}
#endif

#endif
