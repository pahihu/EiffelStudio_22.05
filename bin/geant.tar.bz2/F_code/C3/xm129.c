/*
 * Code for class XM_CALLBACKS_NULL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm129.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_CALLBACKS_NULL}.make */
void F195_2132 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {XM_CALLBACKS_NULL}.on_start */
void F195_2134 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {XM_CALLBACKS_NULL}.on_finish */
void F195_2135 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {XM_CALLBACKS_NULL}.on_xml_declaration */
void F195_2136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	
	
	RTGC;
}

/* {XM_CALLBACKS_NULL}.on_error */
void F195_2137 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {XM_CALLBACKS_NULL}.on_processing_instruction */
void F195_2138 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {XM_CALLBACKS_NULL}.on_comment */
void F195_2139 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {XM_CALLBACKS_NULL}.on_start_tag */
void F195_2140 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {XM_CALLBACKS_NULL}.on_attribute */
void F195_2141 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	
	
	RTGC;
}

/* {XM_CALLBACKS_NULL}.on_start_tag_finish */
void F195_2142 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {XM_CALLBACKS_NULL}.on_end_tag */
void F195_2143 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {XM_CALLBACKS_NULL}.on_content */
void F195_2144 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

void EIF_Minit129 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
