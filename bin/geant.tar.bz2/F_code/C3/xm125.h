
#ifndef _C3_xm125_
#define _C3_xm125_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F191_2108(EIF_REFERENCE);
extern void EIF_Minit125(void);

#ifdef __cplusplus
}
#endif

#endif
