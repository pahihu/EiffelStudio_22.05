
#ifndef _C3_ex141_
#define _C3_ex141_

#ifdef __cplusplus
extern "C" {
#endif

extern void F209_2227(EIF_REFERENCE, EIF_REFERENCE);
extern void F209_2228(EIF_REFERENCE, EIF_REFERENCE);
extern void F209_2229(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit141(void);
extern EIF_REFERENCE F208_2208(EIF_REFERENCE);
extern void F211_2251(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F106_1160(EIF_REFERENCE, EIF_INTEGER_32);
extern void F211_2236(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,2208)

#ifdef __cplusplus
}
#endif

#endif
