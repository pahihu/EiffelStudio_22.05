
#ifndef _C3_in102_
#define _C3_in102_

#ifdef __cplusplus
extern "C" {
#endif

extern void F163_1797(EIF_REFERENCE);
extern EIF_BOOLEAN F163_1798(EIF_REFERENCE, EIF_NATURAL_64, EIF_NATURAL_64, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit102(void);
extern void F716_3989(EIF_REFERENCE, EIF_NATURAL_64);

#ifdef __cplusplus
}
#endif

#endif
