
#ifndef _C3_yy119_
#define _C3_yy119_

#ifdef __cplusplus
extern "C" {
#endif

extern void F180_2055(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F180_2060(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit119(void);
extern void F303_2950(EIF_REFERENCE, EIF_INTEGER_32);
extern void F303_2970(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F303_2965(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern void F178_2026(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4575[])();
extern EIF_TYPE_INDEX Y1900[];
extern EIF_TYPE_INDEX *Y1900_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
