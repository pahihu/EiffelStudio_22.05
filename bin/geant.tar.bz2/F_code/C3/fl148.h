
#ifndef _C3_fl148_
#define _C3_fl148_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F216_2270(EIF_REFERENCE);
extern void EIF_Minit148(void);

#ifdef __cplusplus
}
#endif

#endif
