
#ifndef _C3_pl115_
#define _C3_pl115_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F176_1959(EIF_REFERENCE);
extern void EIF_Minit115(void);

#ifdef __cplusplus
}
#endif

#endif
