/*
 * Code for class KL_SHARED_STREAMS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl110.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SHARED_STREAMS}.null_input_stream */
static EIF_REFERENCE F171_1916_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1916);
#define Result RTOSR(1916)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(988, 0x01).id, 988, _OBJSIZ_2_2_0_1_0_0_0_0_);
	tr2 = RTMS_EX_H("",0,0);
	F989_6693(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1916);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F171_1916 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1916,F171_1916_body,(Current));
}

/* {KL_SHARED_STREAMS}.null_output_stream */
static EIF_REFERENCE F171_1917_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1917);
#define Result RTOSR(1917)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1000, 0x01).id, 1000, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("null",4,1853189228);
	F1001_6759(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1917);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F171_1917 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1917,F171_1917_body,(Current));
}

void EIF_Minit110 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
