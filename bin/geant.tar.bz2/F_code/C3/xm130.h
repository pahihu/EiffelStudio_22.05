
#ifndef _C3_xm130_
#define _C3_xm130_

#ifdef __cplusplus
extern "C" {
#endif

extern void F196_2146(EIF_REFERENCE, EIF_REFERENCE);
extern void F196_2147(EIF_REFERENCE);
extern void F196_2148(EIF_REFERENCE);
extern void F196_2149(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void F196_2150(EIF_REFERENCE, EIF_REFERENCE);
extern void F196_2151(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F196_2152(EIF_REFERENCE, EIF_REFERENCE);
extern void F196_2153(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F196_2154(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F196_2155(EIF_REFERENCE);
extern void F196_2156(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F196_2157(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit130(void);
extern char *(*R1967[])();
extern char *(*R1968[])();
extern char *(*R1969[])();
extern char *(*R1970[])();
extern char *(*R1971[])();
extern char *(*R1972[])();
extern char *(*R1973[])();
extern char *(*R1974[])();
extern char *(*R1975[])();
extern char *(*R1976[])();
extern char *(*R1977[])();
extern long O1983[];

#ifdef __cplusplus
}
#endif

#endif
