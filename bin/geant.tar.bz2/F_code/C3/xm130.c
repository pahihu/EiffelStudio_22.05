/*
 * Code for class XM_FORWARD_CALLBACKS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm130.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_FORWARD_CALLBACKS}.set_callbacks */
void F196_2146 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O1983[Dtype(Current)-195]) = (EIF_REFERENCE) arg1;
}

/* {XM_FORWARD_CALLBACKS}.on_start */
void F196_2147 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O1983[Dtype(Current)-195]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R1967[Dtype(RTCW(tr1))-194])(tr1);
	RTLE;
}

/* {XM_FORWARD_CALLBACKS}.on_finish */
void F196_2148 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O1983[Dtype(Current)-195]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R1968[Dtype(RTCW(tr1))-194])(tr1);
	RTLE;
}

/* {XM_FORWARD_CALLBACKS}.on_xml_declaration */
void F196_2149 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O1983[Dtype(Current)-195]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R1969[Dtype(RTCW(tr1))-194])(tr1, arg1, arg2, arg3);
	RTLE;
}

/* {XM_FORWARD_CALLBACKS}.on_error */
void F196_2150 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O1983[Dtype(Current)-195]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1970[Dtype(RTCW(tr1))-194])(tr1, arg1);
	RTLE;
}

/* {XM_FORWARD_CALLBACKS}.on_processing_instruction */
void F196_2151 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O1983[Dtype(Current)-195]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1971[Dtype(RTCW(tr1))-194])(tr1, arg1, arg2);
	RTLE;
}

/* {XM_FORWARD_CALLBACKS}.on_comment */
void F196_2152 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O1983[Dtype(Current)-195]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1972[Dtype(RTCW(tr1))-194])(tr1, arg1);
	RTLE;
}

/* {XM_FORWARD_CALLBACKS}.on_start_tag */
void F196_2153 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O1983[Dtype(Current)-195]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1973[Dtype(RTCW(tr1))-194])(tr1, arg1, arg2, arg3);
	RTLE;
}

/* {XM_FORWARD_CALLBACKS}.on_attribute */
void F196_2154 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLR(5,arg4);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O1983[Dtype(Current)-195]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1974[Dtype(RTCW(tr1))-194])(tr1, arg1, arg2, arg3, arg4);
	RTLE;
}

/* {XM_FORWARD_CALLBACKS}.on_start_tag_finish */
void F196_2155 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O1983[Dtype(Current)-195]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R1975[Dtype(RTCW(tr1))-194])(tr1);
	RTLE;
}

/* {XM_FORWARD_CALLBACKS}.on_end_tag */
void F196_2156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O1983[Dtype(Current)-195]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1976[Dtype(RTCW(tr1))-194])(tr1, arg1, arg2, arg3);
	RTLE;
}

/* {XM_FORWARD_CALLBACKS}.on_content */
void F196_2157 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O1983[Dtype(Current)-195]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1977[Dtype(RTCW(tr1))-194])(tr1, arg1);
	RTLE;
}

void EIF_Minit130 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
