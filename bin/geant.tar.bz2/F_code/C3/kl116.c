/*
 * Code for class KL_PLATFORM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl116.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_PLATFORM}.minimum_character_code */
static EIF_INTEGER_32 F177_2019_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (2019);
#define Result RTOSR(2019)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTOSE (2019);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F177_2019 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2019,F177_2019_body,(Current));
}

/* {KL_PLATFORM}.maximum_character_code */
static EIF_INTEGER_32 F177_2020_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (2020);
#define Result RTOSR(2020)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 255L);
	RTOSE (2020);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F177_2020 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2020,F177_2020_body,(Current));
}

/* {KL_PLATFORM}.maximum_integer */
static EIF_INTEGER_32 F177_2022_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (2022);
#define Result RTOSR(2022)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	RTOSE (2022);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F177_2022 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2022,F177_2022_body,(Current));
}

void EIF_Minit116 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
