
#ifndef _C3_ge124_
#define _C3_ge124_

#ifdef __cplusplus
extern "C" {
#endif

extern void F190_2102(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F190_2103(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F190_2105(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit124(void);
extern EIF_REFERENCE F1223_8394(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1223_8402(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
