
#ifndef _C3_kl110_
#define _C3_kl110_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,1916)
static EIF_REFERENCE F171_1916_body(EIF_REFERENCE);
extern EIF_REFERENCE F171_1916(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,1917)
static EIF_REFERENCE F171_1917_body(EIF_REFERENCE);
extern EIF_REFERENCE F171_1917(EIF_REFERENCE);
extern void EIF_Minit110(void);
extern void F1001_6759(EIF_REFERENCE, EIF_REFERENCE);
extern void F989_6693(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
