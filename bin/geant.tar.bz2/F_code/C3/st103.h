
#ifndef _C3_st103_
#define _C3_st103_

#ifdef __cplusplus
extern "C" {
#endif

extern void F164_1814(EIF_REFERENCE, EIF_BOOLEAN);
extern void F164_1815(EIF_REFERENCE, EIF_BOOLEAN);
extern void F164_1816(EIF_REFERENCE, EIF_REFERENCE);
extern void F164_1817(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit103(void);
extern void F949_6126(EIF_REFERENCE, EIF_REFERENCE);
extern long O1731[];
extern long O1732[];

#ifdef __cplusplus
}
#endif

#endif
