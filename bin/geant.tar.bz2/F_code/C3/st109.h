
#ifndef _C3_st109_
#define _C3_st109_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F170_1913(EIF_REFERENCE);
extern EIF_INTEGER_32 F170_1914(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit109(void);
extern char *(*R4575[])();
extern char *(*R4538[])();
extern char *(*R4772[])();

#ifdef __cplusplus
}
#endif

#endif
