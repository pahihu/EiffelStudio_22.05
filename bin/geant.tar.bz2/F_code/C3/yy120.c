/*
 * Code for class YY_FILE_BUFFER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy120.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_FILE_BUFFER}.make */
void F181_2061 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = RTOSCF(2050,F178_2050, (Current));
	F181_2062(Current, arg1, ti4_1);
	RTLE;
}

/* {YY_FILE_BUFFER}.make_with_size */
void F181_2062 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_) = (EIF_INTEGER_32) arg2;
	tr1 = F178_2048(Current, (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 2L)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	F181_2067(Current, arg1);
	RTLE;
}

/* {YY_FILE_BUFFER}.make_from_string */
void F181_2063 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = RTOSCF(1916,F171_1916, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F178_2025(Current, arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {YY_FILE_BUFFER}.name */
EIF_REFERENCE F181_2064 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1547[Dtype(RTCW(tr1))-980])(tr1);
	RTLE;
	return Result;
}

/* {YY_FILE_BUFFER}.set_file */
void F181_2067 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F181_2068(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_));
}

/* {YY_FILE_BUFFER}.set_file_with_size */
void F181_2068 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1545[Dtype(RTCW(arg1))-980])(arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_) = (EIF_BOOLEAN) tb1;
	F178_2044(Current);
	if ((EIF_BOOLEAN) (arg2 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_))) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_) = (EIF_INTEGER_32) arg2;
		tr1 = *(EIF_REFERENCE *)(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R1049[Dtype(RTCW(tr1))-302])(tr1, (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 2L)));
	}
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {YY_FILE_BUFFER}.fill */
void F181_2071 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_))) {
		F178_2046(Current);
		loc3 = *(EIF_REFERENCE *)(Current);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R1539[Dtype(RTCW(tr1))-980])(tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1545[Dtype(RTCW(tr1))-980])(tr1);
			if ((EIF_BOOLEAN) !tb1) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_))++;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1548[Dtype(RTCW(tr1))-980])(tr1));
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1045[Dtype(RTCW(loc3))-302])(loc3, (EIF_REFERENCE) &tc1, ti4_1);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		} else {
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_);
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
			loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R1046[Dtype(RTCW(loc3))-302])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
			if ((EIF_BOOLEAN) (loc2 < loc1)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1545[Dtype(RTCW(tr1))-980])(tr1);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_) = (EIF_BOOLEAN) tb1;
			}
			if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_)) += loc2;
		}
		tc1 = (EIF_CHARACTER_8) '\000';
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1045[Dtype(RTCW(loc3))-302])(loc3, (EIF_REFERENCE) &tc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		tc1 = (EIF_CHARACTER_8) '\000';
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1045[Dtype(RTCW(loc3))-302])(loc3, (EIF_REFERENCE) &tc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
	} else {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

void EIF_Minit120 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
