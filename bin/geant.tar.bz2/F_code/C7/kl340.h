
#ifndef _C7_kl340_
#define _C7_kl340_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1001_6759(EIF_REFERENCE, EIF_REFERENCE);
extern void F1001_6760(EIF_REFERENCE, EIF_CHARACTER_8);
extern void F1001_6761(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1001_6763(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 6764)


extern EIF_REFERENCE F1001_6764(EIF_REFERENCE);
extern void F1001_6765(EIF_REFERENCE);
extern void EIF_Minit340(void);

#ifdef __cplusplus
}
#endif

#endif
