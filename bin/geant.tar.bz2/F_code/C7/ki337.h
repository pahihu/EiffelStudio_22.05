
#ifndef _C7_ki337_
#define _C7_ki337_

#ifdef __cplusplus
extern "C" {
#endif

extern void F998_6740(EIF_REFERENCE, EIF_REFERENCE);
extern void F998_6741(EIF_REFERENCE);
extern void EIF_Minit337(void);
extern char *(*R5171[])();
extern char *(*R5191[])();

#ifdef __cplusplus
}
#endif

#endif
