/*
 * Code for class KL_STDERR_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl338.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STDERR_FILE}.make */
void F999_6743 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {KL_STDERR_FILE}.eol */

EIF_REFERENCE F999_6745 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6745,RTMS_EX_H("\012",1,10));
}

/* {KL_STDERR_FILE}.put_character */
void F999_6747 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(6750,F999_6750, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R2761[Dtype(RTCW(tr1))-698])(tr1, arg1);
	RTLE;
}

/* {KL_STDERR_FILE}.put_string */
void F999_6748 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(6466,F971_6466, (Current));
	loc1 = F958_6423(RTCW(tr1), arg1);
	tr1 = RTOSCF(6750,F999_6750, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2759[Dtype(RTCW(tr1))-698])(tr1, loc1);
	RTLE;
}

/* {KL_STDERR_FILE}.flush */
void F999_6749 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F698_3716(RTCV(RTOSCF(6750,F999_6750, (Current))));
	RTLE;
}

/* {KL_STDERR_FILE}.console */
static EIF_REFERENCE F999_6750_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6750);
#define Result RTOSR(6750)
	RTOC_NEW(Result);
	Result = RTOSCF(583,F51_583, (RTCV(RTOSCF(24,F1_24, (Current)))));
	RTOSE (6750);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F999_6750 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6750,F999_6750_body,(Current));
}

void EIF_Minit338 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
