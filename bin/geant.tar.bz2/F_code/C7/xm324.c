/*
 * Code for class XM_NAMESPACE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm324.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_NAMESPACE}.make */
void F985_6665 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {XM_NAMESPACE}.make_default */
void F985_6666 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("",0,0);
	tr2 = RTMS_EX_H("",0,0);
	F985_6665(Current, tr1, tr2);
	RTLE;
}

/* {XM_NAMESPACE}.is_equal */
EIF_BOOLEAN F985_6669 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	if (!(EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) == tr1)) {
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		tb1 = F958_6409(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), tr2);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {XM_NAMESPACE}.hash_code */
EIF_INTEGER_32 F985_6670 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R3640[Dtype(RTCW(tr1))-831])(tr1);
	RTLE;
	return Result;
}

/* {XM_NAMESPACE}.same_prefix */
EIF_BOOLEAN F985_6672 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	Result = '\0';
	if (F985_6669(Current, arg1)) {
		tb1 = '\01';
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		if (!(EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) == tr1)) {
			tb2 = '\0';
			tb3 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current);
			loc1 = tr1;
			if (EIF_TEST(loc1)) {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
				loc2 = tr1;
				tb3 = EIF_TEST(loc2);
			}
			if (tb3) {
				tr1 = RTOSCF(6466,F971_6466, (Current));
				tb3 = F958_6409(RTCW(tr1), loc1, loc2);
				tb2 = tb3;
			}
			tb1 = tb2;
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

void EIF_Minit324 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
