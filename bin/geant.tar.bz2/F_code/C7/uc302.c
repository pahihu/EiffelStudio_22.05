/*
 * Code for class UC_UTF8_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uc302.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UC_UTF8_ROUTINES}.valid_utf8 */
EIF_BOOLEAN F957_6333 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	Result = F957_6334(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.valid_utf8_substring */
EIF_BOOLEAN F957_6334 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc6 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc7 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc1 = (EIF_INTEGER_32) arg2;
	loc2 = (EIF_INTEGER_32) arg3;
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc7 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(arg1))-712])(arg1, loc1));
		if (F957_6337(Current, loc7)) {
			loc4 = F957_6352(Current, loc7);
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 1L))) {
				loc1++;
			} else {
				loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc4) - ((EIF_INTEGER_32) 1L));
				if ((EIF_BOOLEAN) (loc3 > loc2)) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				} else {
					loc5 = F957_6346(Current, loc7);
					loc1++;
					loc6 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(arg1))-712])(arg1, loc1));
					if ((EIF_BOOLEAN) !F957_6339(Current, loc6, loc7)) {
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					} else {
						ti4_1 = F957_6347(Current, loc6);
						loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 * ((EIF_INTEGER_32) 64L)) + ti4_1);
						switch (loc4) {
							case 2L:
								if ((EIF_BOOLEAN) (loc5 <= ((EIF_INTEGER_32) 127L))) {
									Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								}
								break;
							case 3L:
								if ((EIF_BOOLEAN) (loc5 <= ((EIF_INTEGER_32) 31L))) {
									Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								}
								break;
							case 4L:
								if ((EIF_BOOLEAN) (loc5 <= ((EIF_INTEGER_32) 15L))) {
									Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								}
								break;
							default:
								RTEC(EN_WHEN);
						}
						if (Result) {
							loc1++;
							for (;;) {
								if ((EIF_BOOLEAN) (loc1 > loc3)) break;
								tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(arg1))-712])(arg1, loc1));
								if (F957_6338(Current, tc1)) {
									loc1++;
								} else {
									Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
								}
							}
						}
					}
				}
			}
		} else {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		}
	}
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.is_encoded_first_byte */
EIF_BOOLEAN F957_6337 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '') || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_CHARACTER_8) '\302' <= arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\364')));
}

/* {UC_UTF8_ROUTINES}.is_encoded_next_byte */
EIF_BOOLEAN F957_6338 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_CHARACTER_8) '' < arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\277'));
}

/* {UC_UTF8_ROUTINES}.is_encoded_second_byte */
EIF_BOOLEAN F957_6339 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 == (EIF_CHARACTER_8) '\340')) {
		return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_CHARACTER_8) '\237' < arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\277'));
	} else {
		if ((EIF_BOOLEAN)(arg2 == (EIF_CHARACTER_8) '\355')) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_CHARACTER_8) '' < arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\237'));
		} else {
			if ((EIF_BOOLEAN)(arg2 == (EIF_CHARACTER_8) '\360')) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_CHARACTER_8) '\217' < arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\277'));
			} else {
				if ((EIF_BOOLEAN)(arg2 == (EIF_CHARACTER_8) '\364')) {
					return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_CHARACTER_8) '' < arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\217'));
				} else {
					return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_CHARACTER_8) '' < arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\277'));
				}
			}
		}
	}
	return Result;
}

/* {UC_UTF8_ROUTINES}.is_endian_detection_character */
EIF_BOOLEAN F957_6340 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_CHARACTER_8 arg2, EIF_CHARACTER_8 arg3)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	if (F957_6341(Current, arg1, arg2)) {
		Result = (EIF_BOOLEAN)(arg3 == (EIF_CHARACTER_8) '\277');
	}
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.is_endian_detection_character_start */
EIF_BOOLEAN F957_6341 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) '\357') && (EIF_BOOLEAN)(arg2 == (EIF_CHARACTER_8) '\273'));
}

/* {UC_UTF8_ROUTINES}.encoded_first_value */
EIF_INTEGER_32 F957_6346 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	Result = (EIF_INTEGER_32) (arg1);
	if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '')) {
	} else {
		if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\337')) {
			Result %= ((EIF_INTEGER_32) 32L);
		} else {
			if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\357')) {
				Result %= ((EIF_INTEGER_32) 16L);
			} else {
				if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\364')) {
					return (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 8L));
				}
			}
		}
	}
	return Result;
}

/* {UC_UTF8_ROUTINES}.encoded_next_value */
EIF_INTEGER_32 F957_6347 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	Result = (EIF_INTEGER_32) (arg1);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 64L));
	return Result;
}

/* {UC_UTF8_ROUTINES}.encoded_byte_count */
EIF_INTEGER_32 F957_6352 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '')) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\337')) {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		} else {
			if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\357')) {
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			} else {
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
			}
		}
	}
	return Result;
}

/* {UC_UTF8_ROUTINES}.substring_byte_count */
EIF_INTEGER_32 F957_6354 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg2 <= arg3)) {
		tb1 = '\0';
		tr1 = RTOSCF(6290,F953_6290, (Current));
		tr2 = RTOSCF(6391,F957_6391, (Current));
		tb2 = F14_181(RTCW(tr1), arg1, tr2);
		if (tb2) {
			loc4 = arg1;
			loc4 = RTRV(eif_new_type(950, 0x01),loc4);
			tb1 = EIF_TEST(loc4);
		}
		if (tb1) {
			loc3 = (EIF_INTEGER_32) arg2;
			for (;;) {
				if ((EIF_BOOLEAN) (loc3 > arg3)) break;
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(loc4)-712])(loc4, loc3));
				Result += F957_6356(Current, tc1);
				loc3++;
			}
		} else {
			tb1 = '\0';
			tr1 = RTOSCF(6290,F953_6290, (Current));
			tr2 = RTOSCF(6392,F957_6392, (Current));
			tb2 = F14_181(RTCW(tr1), arg1, tr2);
			if (tb2) {
				loc5 = arg1;
				loc5 = RTRV(eif_new_type(1435, 0x01),loc5);
				tb1 = EIF_TEST(loc5);
			}
			if (tb1) {
				tb1 = '\0';
				if ((EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 1L))) {
					ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
					tb1 = (EIF_BOOLEAN)(arg3 == ti4_1);
				}
				if (tb1) {
					Result = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_3_);
				} else {
					loc1 = F1436_11429(loc5, arg2);
					ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN)(arg3 == ti4_1)) {
						Result = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_3_);
						Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result - loc1) + ((EIF_INTEGER_32) 1L));
					} else {
						loc2 = F1436_11428(loc5, loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L)));
						Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - loc1);
					}
				}
			} else {
				loc6 = arg1;
				loc6 = RTRV(eif_new_type(1436, 0x01),loc6);
				if (EIF_TEST(loc6)) {
					tb1 = '\0';
					if ((EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 1L))) {
						ti4_1 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_1_1_0_2_);
						tb1 = (EIF_BOOLEAN)(arg3 == ti4_1);
					}
					if (tb1) {
						Result = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_1_1_0_3_);
						RTLE;
						return (EIF_INTEGER_32) Result;
					} else {
						loc1 = F1436_11429(loc6, arg2);
						ti4_1 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_1_1_0_2_);
						if ((EIF_BOOLEAN)(arg3 == ti4_1)) {
							Result = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_1_1_0_3_);
							Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result - loc1) + ((EIF_INTEGER_32) 1L));
						} else {
							loc2 = F1436_11428(loc6, loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L)));
							RTLE;
							return (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - loc1);
						}
					}
				} else {
					loc3 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN) (loc3 > arg3)) break;
						tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4539[Dtype(RTCW(arg1))-946])(arg1, loc3);
						Result += F957_6357(Current, tw1);
						loc3++;
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.character_byte_count */
EIF_INTEGER_32 F957_6355 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F957_6356(Current, arg1);
}

/* {UC_UTF8_ROUTINES}.character_8_byte_count */
EIF_INTEGER_32 F957_6356 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '')) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	}/* NOTREACHED */
	
}

/* {UC_UTF8_ROUTINES}.character_32_byte_count */
EIF_INTEGER_32 F957_6357 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = (EIF_NATURAL_32) arg1;
	Result = F957_6359(Current, tu4_1);
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.code_byte_count */
EIF_INTEGER_32 F957_6358 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 1114111L))) {
		tu4_1 = (EIF_NATURAL_32) arg1;
		Result = F957_6359(Current, tu4_1);
	} else {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.natural_32_code_byte_count */
EIF_INTEGER_32 F957_6359 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 128U))) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		if ((EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 2048U))) {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		} else {
			if ((EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 55296U))) {
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			} else {
				if ((EIF_BOOLEAN) (arg1 <= ((EIF_NATURAL_32) 57343U))) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				} else {
					if ((EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 65536U))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
					} else {
						if ((EIF_BOOLEAN) (arg1 <= ((EIF_NATURAL_32) 1114111U))) {
							return (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
						} else {
							return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						}
					}
				}
			}
		}
	}
	return Result;
}

/* {UC_UTF8_ROUTINES}.string_to_utf8 */
EIF_REFERENCE F957_6362 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4575[Dtype(RTCW(arg1))-946])(arg1);
	Result = F957_6363(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.substring_to_utf8 */
EIF_REFERENCE F957_6363 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(950, 0x01).id, 950, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = F957_6354(Current, arg1, arg2, arg3);
	F949_6124(RTCW(Result), ti4_1);
	F957_6366(Current, Result, arg1, arg2, arg3);
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.to_utf8 */
EIF_REFERENCE F957_6364 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	loc3 = arg1;
	loc3 = RTRV(eif_new_type(1435, 0x01),loc3);
	if (EIF_TEST(loc3)) {
		tr1 = F1436_11415(loc3);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		Result = RTLNS(eif_new_type(950, 0x01).id, 950, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F949_6124(RTCW(Result), loc2);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(arg1))-950])(arg1, loc1);
			F957_6367(Current, Result, ti4_1);
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.append_substring_to_utf8 */
void F957_6366 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg3 <= arg4)) {
		loc1 = (EIF_INTEGER_32) arg3;
		loc2 = (EIF_INTEGER_32) arg4;
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4538[Dtype(RTCW(arg2))-946])(arg2, loc1);
			F957_6368(Current, arg1, tu4_1);
			loc1++;
		}
	}
	RTLE;
}

/* {UC_UTF8_ROUTINES}.append_code_to_utf8 */
void F957_6367 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tu4_1 = (EIF_NATURAL_32) arg2;
	F957_6368(Current, arg1, tu4_1);
	RTLE;
}

/* {UC_UTF8_ROUTINES}.append_natural_32_code_to_utf8 */
void F957_6368 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_32 arg2)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg2 < ((EIF_NATURAL_32) 128U))) {
		tc1 = (EIF_CHARACTER_8) arg2;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(arg1))-950])(arg1, tc1);
	} else {
		if ((EIF_BOOLEAN) (arg2 < ((EIF_NATURAL_32) 2048U))) {
			loc4 = (EIF_NATURAL_32) arg2;
			loc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
			loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
			tc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) (loc4 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 192L)));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(arg1))-950])(arg1, tc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(arg1))-950])(arg1, loc1);
		} else {
			if ((EIF_BOOLEAN) (arg2 < ((EIF_NATURAL_32) 65536U))) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg2 >= ((EIF_NATURAL_32) 55296U)) && (EIF_BOOLEAN) (arg2 <= ((EIF_NATURAL_32) 57343U)))) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(arg1))-950])(arg1, (EIF_CHARACTER_8) '\377');
				} else {
					loc4 = (EIF_NATURAL_32) arg2;
					loc2 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					loc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					tc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) (loc4 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 224L)));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(arg1))-950])(arg1, tc1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(arg1))-950])(arg1, loc1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(arg1))-950])(arg1, loc2);
				}
			} else {
				if ((EIF_BOOLEAN) (arg2 <= ((EIF_NATURAL_32) 1114111U))) {
					loc4 = (EIF_NATURAL_32) arg2;
					loc3 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					loc2 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					loc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					tc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) (loc4 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 240L)));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(arg1))-950])(arg1, tc1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(arg1))-950])(arg1, loc1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(arg1))-950])(arg1, loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(arg1))-950])(arg1, loc3);
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(arg1))-950])(arg1, (EIF_CHARACTER_8) '\377');
				}
			}
		}
	}
	RTLE;
}

/* {UC_UTF8_ROUTINES}.dummy_string */

EIF_REFERENCE F957_6391 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6391,RTMS_EX_H("",0,0));
}

/* {UC_UTF8_ROUTINES}.dummy_uc_string */
static EIF_REFERENCE F957_6392_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6392);
#define Result RTOSR(6392)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1435, 0x01).id, 1435, _OBJSIZ_1_1_0_6_0_0_0_0_);
	F1436_11325(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6392);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F957_6392 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6392,F957_6392_body,(Current));
}

void EIF_Minit302 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
