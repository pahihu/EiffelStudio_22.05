/*
 * Code for class YY_SCANNER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy348.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_SCANNER}.last_token */
EIF_INTEGER_32 F1015_6900 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O5290[Dtype(Current)-1014]);
}


/* {YY_SCANNER}.end_of_file */
EIF_BOOLEAN F1015_6915 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5290[Dtype(Current)-1014]) == ((EIF_INTEGER_32) 0L));
}

/* {YY_SCANNER}.set_last_token */
void F1015_6918 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O5290[Dtype(Current)-1014]) = (EIF_INTEGER_32) arg1;
}

/* {YY_SCANNER}.terminate */
void F1015_6930 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O5290[Dtype(Current)-1014]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
}

/* {YY_SCANNER}.wrap */
EIF_BOOLEAN F1015_6931 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {YY_SCANNER}.new_file_buffer */
EIF_REFERENCE F1015_6942 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(180, 0x01).id, 180, _OBJSIZ_2_4_0_6_0_0_0_0_);
	F181_2061(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {YY_SCANNER}.new_unicode_string_buffer */
EIF_REFERENCE F1015_6946 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(179, 0x01).id, 179, _OBJSIZ_1_3_0_6_0_0_0_0_);
	F180_2055(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {YY_SCANNER}.empty_buffer */
static EIF_REFERENCE F1015_6948_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (6948);
#define Result RTOSR(6948)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(177, 0x01).id, 177, _OBJSIZ_1_3_0_6_0_0_0_0_);
	tr2 = RTMS_EX_H("",0,0);
	F178_2025(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6948);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1015_6948 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6948,F1015_6948_body,(Current));
}

/* {YY_SCANNER}.fatal_error */
void F1015_6956 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
	F999_6748(RTCW(tr1), arg1);
	tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
	F999_6747(RTCW(tr1), (EIF_CHARACTER_8) '\012');
	RTLE;
}

void EIF_Minit348 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
