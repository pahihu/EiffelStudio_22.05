/*
 * Code for class KL_STDOUT_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl339.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STDOUT_FILE}.make */
void F1000_6751 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {KL_STDOUT_FILE}.eol */

EIF_REFERENCE F1000_6753 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6753,RTMS_EX_H("\012",1,10));
}

/* {KL_STDOUT_FILE}.put_character */
void F1000_6755 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(6758,F1000_6758, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R2761[Dtype(RTCW(tr1))-698])(tr1, arg1);
	RTLE;
}

/* {KL_STDOUT_FILE}.put_string */
void F1000_6756 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(6466,F971_6466, (Current));
	loc1 = F958_6423(RTCW(tr1), arg1);
	tr1 = RTOSCF(6758,F1000_6758, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2759[Dtype(RTCW(tr1))-698])(tr1, loc1);
	RTLE;
}

/* {KL_STDOUT_FILE}.flush */
void F1000_6757 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F698_3716(RTCV(RTOSCF(6758,F1000_6758, (Current))));
	RTLE;
}

/* {KL_STDOUT_FILE}.console */
static EIF_REFERENCE F1000_6758_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6758);
#define Result RTOSR(6758)
	RTOC_NEW(Result);
	Result = RTOSCF(582,F51_582, (RTCV(RTOSCF(24,F1_24, (Current)))));
	RTOSE (6758);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1000_6758 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6758,F1000_6758_body,(Current));
}

void EIF_Minit339 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
