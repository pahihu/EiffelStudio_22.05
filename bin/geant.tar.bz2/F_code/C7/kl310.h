
#ifndef _C7_kl310_
#define _C7_kl310_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,6466)
static EIF_REFERENCE F971_6466_body(EIF_REFERENCE);
extern EIF_REFERENCE F971_6466(EIF_REFERENCE);
extern void EIF_Minit310(void);

#ifdef __cplusplus
}
#endif

#endif
