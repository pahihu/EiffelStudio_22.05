/*
 * Code for class KL_STRING_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl303.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STRING_ROUTINES}.new_empty_string */
EIF_REFERENCE F958_6400 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(6290,F953_6290, (Current));
	tr2 = RTOSCF(6431,F958_6431, (Current));
	tb1 = F14_181(RTCW(tr1), arg1, tr2);
	if (tb1) {
		tr1 = RTLNS(eif_new_type(950, 0x01).id, 950, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F949_6124(RTCW(tr1), arg2);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		loc1 = arg1;
		loc1 = RTRV(eif_new_type(1435, 0x01),loc1);
		if (EIF_TEST(loc1)) {
			tr1 = F1436_11350(loc1, arg2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			Result = F958_6416(Current, arg1);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R4663[Dtype(RTCW(Result))-947])(Result);
		}
	}
	RTLE;
	return Result;
}

/* {KL_STRING_ROUTINES}.substring_index */
EIF_INTEGER_32 F958_6405 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc10);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 == arg1)) {
		if ((EIF_BOOLEAN)(arg3 == ((EIF_INTEGER_32) 1L))) {
			RTLE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
	} else {
		loc9 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN)(loc9 == ((EIF_INTEGER_32) 0L))) {
			RTLE;
			return (EIF_INTEGER_32) arg3;
		} else {
			loc6 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 - loc9) + ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN) (arg3 <= loc6)) {
				tr1 = RTOSCF(6290,F953_6290, (Current));
				tr2 = RTOSCF(6431,F958_6431, (Current));
				tb1 = F14_181(RTCW(tr1), arg1, tr2);
				if (tb1) {
					tr1 = RTOSCF(6290,F953_6290, (Current));
					tr2 = RTOSCF(6431,F958_6431, (Current));
					tb1 = F14_181(RTCW(tr1), arg2, tr2);
					if (tb1) {
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R4586[Dtype(RTCW(arg1))-949])(arg1, arg2, arg3);
						RTLE;
						return (EIF_INTEGER_32) ti4_1;
					} else {
						loc10 = arg2;
						loc10 = RTRV(eif_new_type(1435, 0x01),loc10);
						if (EIF_TEST(loc10)) {
							loc3 = *(EIF_INTEGER_32 *)(loc10+ _LNGOFF_1_1_0_3_);
							loc8 = RTOSCF(2020,F177_2020, (RTCV(RTOSCF(894,F64_894, (Current)))));
							loc5 = (EIF_INTEGER_32) arg3;
							for (;;) {
								if ((EIF_BOOLEAN) (loc5 > loc6)) break;
								loc2 = (EIF_INTEGER_32) loc5;
								loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								for (;;) {
									if ((EIF_BOOLEAN) (loc1 > loc3)) break;
									loc4 = F1436_11425(loc10, loc1);
									if ((EIF_BOOLEAN) (loc4 > loc8)) {
										loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
									}
									ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(arg1))-950])(arg1, loc2);
									if ((EIF_BOOLEAN)(ti4_1 != loc4)) {
										loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
										loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
									} else {
										loc2++;
										ti4_1 = F1436_11427(loc10, loc1);
										loc1 = (EIF_INTEGER_32) ti4_1;
									}
								}
								if (loc7) {
									Result = (EIF_INTEGER_32) loc5;
									loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L));
								} else {
									loc5++;
								}
							}
						} else {
							loc3 = (EIF_INTEGER_32) loc9;
							loc5 = (EIF_INTEGER_32) arg3;
							for (;;) {
								if ((EIF_BOOLEAN) (loc5 > loc6)) break;
								loc2 = (EIF_INTEGER_32) loc5;
								loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								for (;;) {
									if ((EIF_BOOLEAN) (loc1 > loc3)) break;
									tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(arg1))-712])(arg1, loc2));
									tc2 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(arg2))-712])(arg2, loc1));
									if ((EIF_BOOLEAN)(tc1 != tc2)) {
										loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
										loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
									} else {
										loc2++;
										loc1++;
									}
								}
								if (loc7) {
									Result = (EIF_INTEGER_32) loc5;
									loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L));
								} else {
									loc5++;
								}
							}
						}
					}
				} else {
					Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R4586[Dtype(RTCW(arg1))-949])(arg1, arg2, arg3);
					RTLE;
					return (EIF_INTEGER_32) Result;
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {KL_STRING_ROUTINES}.concat */
EIF_REFERENCE F958_6407 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1435, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = F1436_11344(loc1, arg2);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		loc2 = arg2;
		loc2 = RTRV(eif_new_type(1435, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			tr1 = F1436_11345(loc2, arg1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4764[Dtype(RTCW(arg1))-950])(arg1, arg2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}/* NOTREACHED */
	
}

/* {KL_STRING_ROUTINES}.elks_same_string */
EIF_BOOLEAN F958_6408 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
			tr1 = RTOSCF(6290,F953_6290, (Current));
			tr2 = RTOSCF(6431,F958_6431, (Current));
			tb1 = F14_181(RTCW(tr1), arg2, tr2);
			if (tb1) {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4759[Dtype(RTCW(arg1))-949])(arg1, arg2);
				RTLE;
				return (EIF_BOOLEAN) tb1;
			} else {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R4759[Dtype(RTCW(arg2))-949])(arg2, arg1);
				RTLE;
				return (EIF_BOOLEAN) tb1;
			}
		}
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {KL_STRING_ROUTINES}.same_string */
EIF_BOOLEAN F958_6409 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,loc4);
	RTLR(4,Current);
	RTLR(5,tr1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
			loc3 = arg1;
			loc3 = RTRV(eif_new_type(1435, 0x01),loc3);
			if (EIF_TEST(loc3)) {
				tb1 = F1436_11368(loc3, arg2);
				RTLE;
				return (EIF_BOOLEAN) tb1;
			} else {
				loc4 = arg2;
				loc4 = RTRV(eif_new_type(1435, 0x01),loc4);
				if (EIF_TEST(loc4)) {
					Result = F1436_11368(loc4, arg1);
				} else {
					tb1 = '\0';
					tr1 = RTOSCF(6290,F953_6290, (Current));
					tr2 = RTOSCF(6431,F958_6431, (Current));
					tb2 = F14_181(RTCW(tr1), arg1, tr2);
					if (tb2) {
						tr1 = RTOSCF(6290,F953_6290, (Current));
						tr2 = RTOSCF(6431,F958_6431, (Current));
						tb2 = F14_181(RTCW(tr1), arg2, tr2);
						tb1 = tb2;
					}
					if (tb1) {
						Result = F958_6408(Current, arg1, arg2);
						RTLE;
						return (EIF_BOOLEAN) Result;
					} else {
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 > loc2)) break;
							ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(arg1))-950])(arg1, loc1);
							ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(arg2))-950])(arg2, loc1);
							if ((EIF_BOOLEAN)(ti4_1 != ti4_2)) {
								Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
							} else {
								loc1++;
							}
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {KL_STRING_ROUTINES}.same_case_insensitive */
EIF_BOOLEAN F958_6410 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == arg2)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
			loc6 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tb1 = '\0';
			tr1 = RTOSCF(6290,F953_6290, (Current));
			tr2 = RTOSCF(6431,F958_6431, (Current));
			tb2 = F14_181(RTCW(tr1), arg1, tr2);
			if (tb2) {
				tr1 = RTOSCF(6290,F953_6290, (Current));
				tr2 = RTOSCF(6431,F958_6431, (Current));
				tb2 = F14_181(RTCW(tr1), arg2, tr2);
				tb1 = tb2;
			}
			if ((EIF_BOOLEAN) !tb1) {
				loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc5 > loc6)) break;
					loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(arg1))-950])(arg1, loc5);
					loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(arg2))-950])(arg2, loc5);
					if ((EIF_BOOLEAN)(loc3 == loc4)) {
						loc5++;
					} else {
						tr1 = RTOSCF(3278,F376_3278, (Current));
						ti4_1 = F1023_7227(RTCW(tr1), loc3);
						tr1 = RTOSCF(3278,F376_3278, (Current));
						ti4_2 = F1023_7227(RTCW(tr1), loc4);
						if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
							loc5++;
						} else {
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L));
						}
					}
				}
			} else {
				loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc5 > loc6)) break;
					loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(arg1))-712])(arg1, loc5));
					loc2 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(arg2))-712])(arg2, loc5));
					if ((EIF_BOOLEAN)(loc1 == loc2)) {
						loc5++;
					} else {
						tc1 = eif_builtin_CHARACTER_8_as_lower__c1_c1(loc1);
						tc2 = eif_builtin_CHARACTER_8_as_lower__c1_c1(loc2);
						if ((EIF_BOOLEAN)(tc1 == tc2)) {
							loc5++;
						} else {
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L));
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {KL_STRING_ROUTINES}.three_way_comparison */
EIF_INTEGER_32 F958_6412 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc5 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc6 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc10);
	RTLR(6,loc11);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 == arg1)) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		tb1 = '\0';
		tr1 = RTOSCF(6290,F953_6290, (Current));
		tr2 = RTOSCF(6431,F958_6431, (Current));
		tb2 = F14_181(RTCW(tr1), arg1, tr2);
		if (tb2) {
			tr1 = RTOSCF(6290,F953_6290, (Current));
			tr2 = RTOSCF(6431,F958_6431, (Current));
			tb2 = F14_181(RTCW(tr1), arg2, tr2);
			tb1 = tb2;
		}
		if (tb1) {
			loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			loc4 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (loc3 < loc4)) {
				loc2 = (EIF_INTEGER_32) loc3;
			} else {
				loc2 = (EIF_INTEGER_32) loc4;
			}
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(arg1))-712])(arg1, loc1));
				loc6 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(arg2))-712])(arg2, loc1));
				if ((EIF_BOOLEAN)(loc5 == loc6)) {
					loc1++;
				} else {
					if ((EIF_BOOLEAN) (loc5 < loc6)) {
						loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					} else {
						loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					}
				}
			}
			if ((EIF_BOOLEAN) !loc9) {
				if ((EIF_BOOLEAN) (loc3 < loc4)) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				} else {
					if ((EIF_BOOLEAN)(loc3 != loc4)) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					}
				}
			}
		} else {
			loc10 = arg1;
			loc10 = RTRV(eif_new_type(1435, 0x01),loc10);
			if (EIF_TEST(loc10)) {
				Result = F1436_11370(loc10, arg2);
			} else {
				loc11 = arg2;
				loc11 = RTRV(eif_new_type(1435, 0x01),loc11);
				if (EIF_TEST(loc11)) {
					Result = F1436_11370(loc11, arg1);
					Result = (EIF_INTEGER_32) (EIF_INTEGER_32) -Result;
				} else {
					loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
					loc4 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN) (loc3 < loc4)) {
						loc2 = (EIF_INTEGER_32) loc3;
					} else {
						loc2 = (EIF_INTEGER_32) loc4;
					}
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > loc2)) break;
						loc7 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(arg1))-950])(arg1, loc1);
						loc8 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(arg2))-950])(arg2, loc1);
						if ((EIF_BOOLEAN)(loc7 == loc8)) {
							loc1++;
						} else {
							if ((EIF_BOOLEAN) (loc7 < loc8)) {
								loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
							} else {
								loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
							}
						}
					}
					if ((EIF_BOOLEAN) !loc9) {
						if ((EIF_BOOLEAN) (loc3 < loc4)) {
							RTLE;
							return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						} else {
							if ((EIF_BOOLEAN)(loc3 != loc4)) {
								RTLE;
								return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							}
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {KL_STRING_ROUTINES}.cloned_string */
EIF_REFERENCE F958_6416 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	
	
	tr1 = F1_14(arg1);
	return (EIF_REFERENCE) tr1;
}

/* {KL_STRING_ROUTINES}.appended_string */
EIF_REFERENCE F958_6417 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1435, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		F1436_11380(loc1, arg2);
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		loc2 = arg2;
		loc2 = RTRV(eif_new_type(1435, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			RTLE;
			return (EIF_REFERENCE) F958_6407(Current, arg1, arg2);
		} else {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4800[Dtype(RTCW(arg1))-950])(arg1, arg2);
			RTLE;
			return (EIF_REFERENCE) arg1;
		}
	}/* NOTREACHED */
	
}

/* {KL_STRING_ROUTINES}.appended_substring */
EIF_REFERENCE F958_6418 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,loc4);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	loc3 = arg1;
	loc3 = RTRV(eif_new_type(1435, 0x01),loc3);
	if (EIF_TEST(loc3)) {
		F1436_11383(loc3, arg2, arg3, arg4);
		RTLE;
		return (EIF_REFERENCE) loc3;
	} else {
		loc4 = arg2;
		loc4 = RTRV(eif_new_type(1435, 0x01),loc4);
		if (EIF_TEST(loc4)) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			loc1 = F1436_11350(loc4, (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + arg4) - arg3) + ((EIF_INTEGER_32) 1L)));
			F1436_11380(RTCW(loc1), arg1);
			F1436_11383(RTCW(loc1), arg2, arg3, arg4);
			RTLE;
			return (EIF_REFERENCE) loc1;
		} else {
			loc2 = (EIF_INTEGER_32) arg3;
			for (;;) {
				if ((EIF_BOOLEAN) (loc2 > arg4)) break;
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(arg2))-712])(arg2, loc2));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(arg1))-950])(arg1, tc1);
				loc2++;
			}
			RTLE;
			return (EIF_REFERENCE) arg1;
		}
	}/* NOTREACHED */
	
}

/* {KL_STRING_ROUTINES}.append_substring_to_string */
void F958_6420 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	loc3 = arg1;
	loc3 = RTRV(eif_new_type(1435, 0x01),loc3);
	loc4 = arg2;
	loc4 = RTRV(eif_new_type(950, 0x01),loc4);
	if ((EIF_BOOLEAN) (EIF_TEST(loc3) && EIF_TEST(loc4))) {
		F1436_11383(loc3, loc4, arg3, arg4);
	} else {
		loc1 = (EIF_INTEGER_32) arg3;
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > arg4)) break;
			tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4538[Dtype(RTCW(arg2))-946])(arg2, loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R4635[Dtype(RTCW(arg1))-947])(arg1, tu4_1);
			loc1++;
		}
	}
	RTLE;
}

/* {KL_STRING_ROUTINES}.replaced_all_substrings */
EIF_REFERENCE F958_6421 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLR(4,tr1);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc4 = F958_6405(Current, arg1, arg2, loc3);
	if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 0L))) {
		loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
		Result = F958_6400(Current, arg1, loc1);
		for (;;) {
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) break;
			tr1 = F958_6418(Current, Result, arg1, loc3, (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L)));
			Result = (EIF_REFERENCE) tr1;
			tr1 = F958_6417(Current, Result, arg3);
			Result = (EIF_REFERENCE) tr1;
			loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + loc2);
			if ((EIF_BOOLEAN) (loc3 > loc1)) {
				loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			} else {
				loc4 = F958_6405(Current, arg1, arg2, loc3);
			}
		}
		RTLE;
		return (EIF_REFERENCE) F958_6418(Current, Result, arg1, loc3, loc1);
	} else {
		RTLE;
		return (EIF_REFERENCE) arg1;
	}/* NOTREACHED */
	
}

/* {KL_STRING_ROUTINES}.replaced_first_substring */
EIF_REFERENCE F958_6422 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,arg3);
	RTLR(4,Result);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	loc3 = F958_6405(Current, arg1, arg2, ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
		loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg3)+ _LNGOFF_1_1_0_2_);
		Result = F958_6400(Current, arg1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - loc2) + ti4_1));
		tr1 = F958_6418(Current, Result, arg1, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
		Result = (EIF_REFERENCE) tr1;
		tr1 = F958_6417(Current, Result, arg3);
		Result = (EIF_REFERENCE) tr1;
		RTLE;
		return (EIF_REFERENCE) F958_6418(Current, Result, arg1, (EIF_INTEGER_32) (loc3 + loc2), loc1);
	} else {
		RTLE;
		return (EIF_REFERENCE) arg1;
	}/* NOTREACHED */
	
}

/* {KL_STRING_ROUTINES}.as_string */
EIF_REFERENCE F958_6423 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(950, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = RTOSCF(6290,F953_6290, (Current));
		tr2 = RTOSCF(6431,F958_6431, (Current));
		tb2 = F14_181(RTCW(tr1), arg1, tr2);
		tb1 = tb2;
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		loc2 = arg1;
		loc2 = RTRV(eif_new_type(1435, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			tr1 = F1436_11420(loc2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4754[Dtype(RTCW(arg1))-949])(arg1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}/* NOTREACHED */
	
}

/* {KL_STRING_ROUTINES}.hexadecimal_to_integer */
EIF_INTEGER_32 F958_6424 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		Result *= ((EIF_INTEGER_32) 16L);
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(arg1))-712])(arg1, loc1));
		switch (tc1) {
			case (EIF_CHARACTER_8) '0':
				break;
			case (EIF_CHARACTER_8) '1':
				Result++;
				break;
			case (EIF_CHARACTER_8) '2':
				Result += ((EIF_INTEGER_32) 2L);
				break;
			case (EIF_CHARACTER_8) '3':
				Result += ((EIF_INTEGER_32) 3L);
				break;
			case (EIF_CHARACTER_8) '4':
				Result += ((EIF_INTEGER_32) 4L);
				break;
			case (EIF_CHARACTER_8) '5':
				Result += ((EIF_INTEGER_32) 5L);
				break;
			case (EIF_CHARACTER_8) '6':
				Result += ((EIF_INTEGER_32) 6L);
				break;
			case (EIF_CHARACTER_8) '7':
				Result += ((EIF_INTEGER_32) 7L);
				break;
			case (EIF_CHARACTER_8) '8':
				Result += ((EIF_INTEGER_32) 8L);
				break;
			case (EIF_CHARACTER_8) '9':
				Result += ((EIF_INTEGER_32) 9L);
				break;
			case (EIF_CHARACTER_8) 'A':
			case (EIF_CHARACTER_8) 'a':
				Result += ((EIF_INTEGER_32) 10L);
				break;
			case (EIF_CHARACTER_8) 'B':
			case (EIF_CHARACTER_8) 'b':
				Result += ((EIF_INTEGER_32) 11L);
				break;
			case (EIF_CHARACTER_8) 'C':
			case (EIF_CHARACTER_8) 'c':
				Result += ((EIF_INTEGER_32) 12L);
				break;
			case (EIF_CHARACTER_8) 'D':
			case (EIF_CHARACTER_8) 'd':
				Result += ((EIF_INTEGER_32) 13L);
				break;
			case (EIF_CHARACTER_8) 'E':
			case (EIF_CHARACTER_8) 'e':
				Result += ((EIF_INTEGER_32) 14L);
				break;
			case (EIF_CHARACTER_8) 'F':
			case (EIF_CHARACTER_8) 'f':
				Result += ((EIF_INTEGER_32) 15L);
				break;
			default:
				RTEC(EN_WHEN);
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {KL_STRING_ROUTINES}.wipe_out */
void F958_6427 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4654[Dtype(RTCW(arg1))-950])(arg1, ((EIF_INTEGER_32) 0L));
}

/* {KL_STRING_ROUTINES}.dummy_string */

EIF_REFERENCE F958_6431 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6431,RTMS_EX_H("",0,0));
}

void EIF_Minit303 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
