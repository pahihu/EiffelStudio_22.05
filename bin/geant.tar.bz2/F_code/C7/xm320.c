/*
 * Code for class XM_EIFFEL_INPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm320.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_EIFFEL_INPUT_STREAM}.make_from_stream */
void F981_6589 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1196,900,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(950, 1).id);
	F943_5827(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.is_valid_encoding */
EIF_BOOLEAN F981_6590 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		Result = '\01';
		tb1 = '\01';
		tb2 = '\01';
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = RTOSCF(6594,F981_6594, (Current));
		tb3 = F958_6410(RTCW(tr1), arg1, tr2);
		if (!tb3) {
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = RTOSCF(6593,F981_6593, (Current));
			tb3 = F958_6410(RTCW(tr1), arg1, tr2);
			tb2 = tb3;
		}
		if (!tb2) {
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = RTOSCF(6595,F981_6595, (Current));
			tb2 = F958_6410(RTCW(tr1), arg1, tr2);
			tb1 = tb2;
		}
		if (!tb1) {
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = RTOSCF(6596,F981_6596, (Current));
			tb1 = F958_6410(RTCW(tr1), arg1, tr2);
			Result = tb1;
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.is_applicable_encoding */
EIF_BOOLEAN F981_6591 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 6L))) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\01';
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = RTOSCF(6594,F981_6594, (Current));
		tb2 = F958_6410(RTCW(tr1), arg1, tr2);
		if (!tb2) {
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = RTOSCF(6593,F981_6593, (Current));
			tb2 = F958_6410(RTCW(tr1), arg1, tr2);
			tb1 = tb2;
		}
		if (tb1) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 2L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 1L))) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 3L)));
		} else {
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = RTOSCF(6595,F981_6595, (Current));
			tb1 = F958_6410(RTCW(tr1), arg1, tr2);
			if (tb1) {
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_);
				ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L)) || (EIF_BOOLEAN)(ti4_2 == ((EIF_INTEGER_32) 1L)));
			} else {
				tr1 = RTOSCF(6466,F971_6466, (Current));
				tr2 = RTOSCF(6596,F981_6596, (Current));
				tb1 = F958_6410(RTCW(tr1), arg1, tr2);
				if (tb1) {
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_);
					ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_);
					RTLE;
					return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 4L)) || (EIF_BOOLEAN)(ti4_2 == ((EIF_INTEGER_32) 5L)));
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.set_encoding */
void F981_6592 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(6466,F971_6466, (Current));
	tr2 = RTOSCF(6594,F981_6594, (Current));
	tb1 = F958_6410(RTCW(tr1), arg1, tr2);
	if (tb1) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	} else {
		tr1 = RTOSCF(6466,F971_6466, (Current));
		tr2 = RTOSCF(6596,F981_6596, (Current));
		tb1 = F958_6410(RTCW(tr1), arg1, tr2);
		if (tb1) {
		} else {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.encoding_us_ascii */

EIF_REFERENCE F981_6593 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6593,RTMS_EX_H("us-ascii",8,1951510633));
}

/* {XM_EIFFEL_INPUT_STREAM}.encoding_latin_1 */

EIF_REFERENCE F981_6594 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6594,RTMS_EX_H("iso-8859-1",10,1003358513));
}

/* {XM_EIFFEL_INPUT_STREAM}.encoding_utf_8 */

EIF_REFERENCE F981_6595 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6595,RTMS_EX_H("utf-8",5,1953751864));
}

/* {XM_EIFFEL_INPUT_STREAM}.encoding_utf_16 */

EIF_REFERENCE F981_6596 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6596,RTMS_EX_H("utf-16",6,1945159990));
}

/* {XM_EIFFEL_INPUT_STREAM}.read_character */
void F981_6597 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 6L))) {
		F981_6616(Current);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1545[Dtype(RTCW(tr1))-980])(tr1);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			F981_6615(Current);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current);
			F1197_8062(RTCW(tr1));
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1545[Dtype(RTCW(tr1))-980])(tr1);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				F981_6615(Current);
			}
		} else {
			F981_6615(Current);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.read_string */
void F981_6598 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(6466,F971_6466, (Current));
	F958_6427(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	F981_6597(Current);
	loc1 = (EIF_INTEGER_32) arg1;
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
			tb1 = F981_6602(Current);
		}
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tc1 = F981_6604(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(tr1))-950])(tr1, tc1);
		F981_6597(Current);
		loc1--;
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.read_to_string */
EIF_INTEGER_32 F981_6599 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\01';
	if (!(EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 6L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 2L)))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		F981_6597(Current);
		if ((EIF_BOOLEAN) !F981_6602(Current)) {
			tc1 = F981_6604(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3121[Dtype(RTCW(arg1))-737])(arg1, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &arg2);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 1L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4976[Dtype(RTCW(tr1))-980])(tr1, arg1, arg2, arg3);
		} else {
			Result = F965_6445(Current, arg1, arg2, arg3);
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.end_of_input */
EIF_BOOLEAN F981_6602 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1545[Dtype(RTCW(tr1))-980])(tr1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.name */
EIF_REFERENCE F981_6603 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1547[Dtype(RTCW(tr1))-980])(tr1);
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.last_character */
EIF_CHARACTER_8 F981_6604 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = F1197_8053(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1548[Dtype(RTCW(tr1))-980])(tr1));
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.last_string */
EIF_REFERENCE F981_6605 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_2_);
}


/* {XM_EIFFEL_INPUT_STREAM}.noqueue_read_character */
void F981_6615 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 1L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 2L)))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R1539[Dtype(RTCW(tr1))-980])(tr1);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 3L))) {
			F981_6618(Current);
		} else {
			F981_6617(Current);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.utf16_detect_read_character */
void F981_6616 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R1539[Dtype(RTCW(tr1))-980])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1545[Dtype(RTCW(tr1))-980])(tr1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1548[Dtype(RTCW(tr1))-980])(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R1539[Dtype(RTCW(tr1))-980])(tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1545[Dtype(RTCW(tr1))-980])(tr1);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc2 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1548[Dtype(RTCW(tr1))-980])(tr1));
			tr1 = RTOSCF(2362,F252_2362, (Current));
			ti4_1 = (EIF_INTEGER_32) (loc1);
			ti4_2 = (EIF_INTEGER_32) (loc2);
			tb1 = F956_6310(RTCW(tr1), ti4_1, ti4_2);
			if (tb1) {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
			} else {
				tr1 = RTOSCF(2362,F252_2362, (Current));
				ti4_1 = (EIF_INTEGER_32) (loc1);
				ti4_2 = (EIF_INTEGER_32) (loc2);
				tb1 = F956_6311(RTCW(tr1), ti4_1, ti4_2);
				if (tb1) {
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
				} else {
					tb1 = '\0';
					ti4_1 = (EIF_INTEGER_32) (loc1);
					if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
						tb1 = (EIF_BOOLEAN)(loc2 == (EIF_CHARACTER_8) '<');
					}
					if (tb1) {
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
						tr1 = *(EIF_REFERENCE *)(Current);
						F1197_8059(RTCW(tr1), (EIF_CHARACTER_8) '<');
					} else {
						tb1 = '\0';
						if ((EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_8) '<')) {
							ti4_1 = (EIF_INTEGER_32) (loc2);
							tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
						}
						if (tb1) {
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
							tr1 = *(EIF_REFERENCE *)(Current);
							F1197_8059(RTCW(tr1), (EIF_CHARACTER_8) '<');
						} else {
							tr1 = RTOSCF(2759,F292_2759, (Current));
							tb1 = F957_6341(RTCW(tr1), loc1, loc2);
							if (tb1) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								(FUNCTION_CAST(void, (EIF_REFERENCE)) R1539[Dtype(RTCW(tr1))-980])(tr1);
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1545[Dtype(RTCW(tr1))-980])(tr1);
								if ((EIF_BOOLEAN) !tb1) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1548[Dtype(RTCW(tr1))-980])(tr1));
									tr1 = RTOSCF(2759,F292_2759, (Current));
									tb1 = F957_6340(RTCW(tr1), loc1, loc2, loc3);
									if (tb1) {
									} else {
										tr1 = *(EIF_REFERENCE *)(Current);
										F1197_8059(RTCW(tr1), loc1);
										tr1 = *(EIF_REFERENCE *)(Current);
										F1197_8059(RTCW(tr1), loc2);
										tr1 = *(EIF_REFERENCE *)(Current);
										F1197_8059(RTCW(tr1), loc3);
									}
								} else {
									tr1 = *(EIF_REFERENCE *)(Current);
									F1197_8059(RTCW(tr1), loc1);
									tr1 = *(EIF_REFERENCE *)(Current);
									F1197_8059(RTCW(tr1), loc2);
								}
							} else {
								tr1 = *(EIF_REFERENCE *)(Current);
								F1197_8059(RTCW(tr1), loc1);
								tr1 = *(EIF_REFERENCE *)(Current);
								F1197_8059(RTCW(tr1), loc2);
							}
						}
					}
				}
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			F1197_8059(RTCW(tr1), loc1);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.utf16_read_character */
void F981_6617 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R1539[Dtype(RTCW(tr1))-980])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1545[Dtype(RTCW(tr1))-980])(tr1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1548[Dtype(RTCW(tr1))-980])(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R1539[Dtype(RTCW(tr1))-980])(tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1545[Dtype(RTCW(tr1))-980])(tr1);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc2 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1548[Dtype(RTCW(tr1))-980])(tr1));
			loc3 = F981_6620(Current, loc1, loc2);
			loc4 = F981_6621(Current, loc1, loc2);
			tr1 = RTOSCF(2362,F252_2362, (Current));
			tb1 = F956_6313(RTCW(tr1), loc3);
			if (tb1) {
				tr1 = RTOSCF(2362,F252_2362, (Current));
				tb1 = F956_6314(RTCW(tr1), loc3);
				if (tb1) {
					tr1 = RTOSCF(2362,F252_2362, (Current));
					loc5 = F956_6316(RTCW(tr1), loc3, loc4);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R1539[Dtype(RTCW(tr1))-980])(tr1);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1545[Dtype(RTCW(tr1))-980])(tr1);
					if ((EIF_BOOLEAN) !tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1548[Dtype(RTCW(tr1))-980])(tr1));
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R1539[Dtype(RTCW(tr1))-980])(tr1);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1545[Dtype(RTCW(tr1))-980])(tr1);
						if ((EIF_BOOLEAN) !tb1) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							loc2 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1548[Dtype(RTCW(tr1))-980])(tr1));
							loc3 = F981_6620(Current, loc1, loc2);
							loc4 = F981_6621(Current, loc1, loc2);
							tr1 = RTOSCF(2362,F252_2362, (Current));
							tb1 = F956_6315(RTCW(tr1), loc3);
							if (tb1) {
								tr1 = RTOSCF(2362,F252_2362, (Current));
								tr2 = RTOSCF(2362,F252_2362, (Current));
								ti4_1 = F956_6316(RTCW(tr2), loc3, loc4);
								ti4_1 = F956_6317(RTCW(tr1), loc5, ti4_1);
								F981_6619(Current, ti4_1);
							}
						}
					}
				}
			} else {
				F981_6619(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 * ((EIF_INTEGER_32) 256L)) + loc4));
			}
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.latin1_read_character */
void F981_6618 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R1539[Dtype(RTCW(tr1))-980])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1545[Dtype(RTCW(tr1))-980])(tr1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1548[Dtype(RTCW(tr1))-980])(tr1));
		ti4_1 = (EIF_INTEGER_32) (tc1);
		if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 128L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1548[Dtype(RTCW(tr1))-980])(tr1));
			ti4_1 = (EIF_INTEGER_32) (tc1);
			F981_6619(Current, ti4_1);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.append_character */
void F981_6619 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc3 = RTOSCF(6623,F981_6623, (Current));
	tr1 = RTOSCF(6466,F971_6466, (Current));
	F958_6427(RTCW(tr1), loc3);
	tr1 = RTOSCF(2759,F292_2759, (Current));
	F957_6367(RTCW(tr1), loc3, arg1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(loc3))-712])(loc3, loc1));
		F1197_8059(RTCW(tr1), tc1);
		loc1++;
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.most_significant */
EIF_INTEGER_32 F981_6620 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 4L))) {
		ti4_1 = (EIF_INTEGER_32) (arg1);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		ti4_1 = (EIF_INTEGER_32) (arg2);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}/* NOTREACHED */
	
}

/* {XM_EIFFEL_INPUT_STREAM}.least_significant */
EIF_INTEGER_32 F981_6621 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 4L))) {
		ti4_1 = (EIF_INTEGER_32) (arg2);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		ti4_1 = (EIF_INTEGER_32) (arg1);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}/* NOTREACHED */
	
}

/* {XM_EIFFEL_INPUT_STREAM}.utf8_buffer */
static EIF_REFERENCE F981_6623_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6623);
#define Result RTOSR(6623)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(950, 0x01).id, 950, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F949_6124(RTCW(tr1), ((EIF_INTEGER_32) 6L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6623);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F981_6623 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6623,F981_6623_body,(Current));
}

void EIF_Minit320 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
