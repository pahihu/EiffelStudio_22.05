/*
 * Code for class KL_NULL_TEXT_OUTPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl340.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_NULL_TEXT_OUTPUT_STREAM}.make */
void F1001_6759 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {KL_NULL_TEXT_OUTPUT_STREAM}.put_character */
void F1001_6760 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	RTGC;
}

/* {KL_NULL_TEXT_OUTPUT_STREAM}.put_string */
void F1001_6761 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {KL_NULL_TEXT_OUTPUT_STREAM}.name */
EIF_REFERENCE F1001_6763 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current);
}


/* {KL_NULL_TEXT_OUTPUT_STREAM}.eol */

EIF_REFERENCE F1001_6764 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6764,RTMS_EX_H("\012",1,10));
}

/* {KL_NULL_TEXT_OUTPUT_STREAM}.flush */
void F1001_6765 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

void EIF_Minit340 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
