/*
 * Code for class UC_UTF16_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uc301.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UC_UTF16_ROUTINES}.is_endian_detection_character_most_first */
EIF_BOOLEAN F956_6310 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 254L)) && (EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 255L)));
}

/* {UC_UTF16_ROUTINES}.is_endian_detection_character_least_first */
EIF_BOOLEAN F956_6311 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 255L)) && (EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 254L)));
}

/* {UC_UTF16_ROUTINES}.is_surrogate */
EIF_BOOLEAN F956_6313 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 216L)) && (EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 224L)));
}

/* {UC_UTF16_ROUTINES}.is_high_surrogate */
EIF_BOOLEAN F956_6314 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 216L)) && (EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 220L)));
}

/* {UC_UTF16_ROUTINES}.is_low_surrogate */
EIF_BOOLEAN F956_6315 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 220L)) && (EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 224L)));
}

/* {UC_UTF16_ROUTINES}.least_10_bits */
EIF_INTEGER_32 F956_6316 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 4L)) * ((EIF_INTEGER_32) 256L)) + arg2);
}

/* {UC_UTF16_ROUTINES}.surrogate */
EIF_INTEGER_32 F956_6317 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 65536L) + (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 * ((EIF_INTEGER_32) 1024L)) + arg2));
}

void EIF_Minit301 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
