
#ifndef _C7_st327_
#define _C7_st327_

#ifdef __cplusplus
extern "C" {
#endif

extern void F988_6682(EIF_REFERENCE);
extern void F988_6688(EIF_REFERENCE, EIF_INTEGER_32);
extern void F988_6689(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F988_6690(EIF_REFERENCE, EIF_REFERENCE);
extern void F988_6691(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F988_6692(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit327(void);
extern void F949_6125(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern void F949_6124(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F958_6416(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F971_6466(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,6466)
extern char *(*R3355[])();
extern char *(*R3121[])();
extern char *(*R4800[])();
extern char *(*R4802[])();
extern char *(*R4616[])();

#ifdef __cplusplus
}
#endif

#endif
