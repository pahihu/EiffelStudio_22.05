
#ifndef _C7_ge325_
#define _C7_ge325_

#ifdef __cplusplus
extern "C" {
#endif

extern void F986_6674(EIF_REFERENCE);
extern EIF_BOOLEAN F986_6675(EIF_REFERENCE);
extern void F986_6678(EIF_REFERENCE, EIF_REFERENCE);
extern void F986_6679(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit325(void);
extern EIF_BOOLEAN F958_6409(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F971_6466(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,6466)

#ifdef __cplusplus
}
#endif

#endif
