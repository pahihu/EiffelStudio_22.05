
#ifndef _C7_ki305_
#define _C7_ki305_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F966_6449(EIF_REFERENCE);
extern void EIF_Minit305(void);
extern long O6377[];

#ifdef __cplusplus
}
#endif

#endif
