
#ifndef _C7_ki334_
#define _C7_ki334_

#ifdef __cplusplus
extern "C" {
#endif

extern void F995_6723(EIF_REFERENCE, EIF_INTEGER_32);
extern void F995_6727(EIF_REFERENCE, EIF_INTEGER_64);
extern void F995_6730(EIF_REFERENCE, EIF_NATURAL_32);
extern void F995_6731(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit334(void);
extern char *(*R1077[])();

#ifdef __cplusplus
}
#endif

#endif
