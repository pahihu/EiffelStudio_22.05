
#ifndef _C7_uc329_
#define _C7_uc329_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F990_6708(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit329(void);
extern EIF_REFERENCE F971_6466(EIF_REFERENCE);
extern EIF_BOOLEAN F958_6409(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,6466)

#ifdef __cplusplus
}
#endif

#endif
