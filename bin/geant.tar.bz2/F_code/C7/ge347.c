/*
 * Code for class GEANT_PROJECT_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ge347.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GEANT_PROJECT_PARSER}.make */
void F1014_6884 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,loc1);
	RTLR(5,tr1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg3;
	loc1 = RTLNS(eif_new_type(83, 0x01).id, 83, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tb1 = F84_1025(RTCW(loc1));
	if (tb1) {
		tr1 = F84_1026(RTCW(loc1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTLNS(eif_new_type(1311, 0x01).id, 1311, _OBJSIZ_45_3_0_35_0_0_0_0_);
		F1311_9871(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1026_7249(RTCW(tr1));
	tr1 = RTLNSMART(eif_new_type(1004, 1).id);
	F1005_6794(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = *(EIF_REFERENCE *)(RTCW(tr2));
	F196_2146(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	F198_2165(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTLE;
}

/* {GEANT_PROJECT_PARSER}.parse_file */
void F1014_6887 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1311_9875(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1311_9884(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_2_0_);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			loc1 = F1005_6799(RTCW(tr1));
			loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
			loc3 = RTLNSMART(eif_new_type(1427, 0).id);
			F1428_11075(RTCW(loc3), loc2, *(EIF_REFERENCE *)(Current + _REFACS_4_), *(EIF_REFERENCE *)(Current + _REFACS_5_), *(EIF_REFERENCE *)(Current + _REFACS_1_));
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_2_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_2_);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_2_);
			F1356_10314(RTCW(tr1), tr2);
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc3;
		} else {
			tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr2 = F1005_6800(RTCW(tr2));
			F999_6748(RTCW(tr1), tr2);
			tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
			F999_6749(RTCW(tr1));
		}
	} else {
		tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = F1027_7278(RTCW(tr2));
		F999_6748(RTCW(tr1), tr2);
		tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
		F999_6749(RTCW(tr1));
	}
	RTLE;
}

void EIF_Minit347 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
