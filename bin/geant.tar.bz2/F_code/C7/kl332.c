/*
 * Code for class KL_STRING_VALUES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl332.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STRING_VALUES}.interpreted_string */
EIF_REFERENCE F993_6715 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F993_6716(Current, arg1, (EIF_BOOLEAN) 1);
}

/* {KL_STRING_VALUES}.expanded_string */
EIF_REFERENCE F993_6716 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc5 = (EIF_CHARACTER_8) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	tr1 = RTOSCF(6466,F971_6466, (Current));
	Result = F958_6400(RTCW(tr1), arg1, loc4);
	for (;;) {
		if ((EIF_BOOLEAN) (loc3 > loc4)) break;
		loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(arg1))-712])(arg1, loc3));
		loc3++;
		if ((EIF_BOOLEAN)(loc5 != (EIF_CHARACTER_8) '$')) {
			if ((EIF_BOOLEAN)(loc5 != (EIF_CHARACTER_8) '\000')) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(Result))-950])(Result, loc5);
			} else {
				tr1 = RTOSCF(6466,F971_6466, (Current));
				tr1 = F958_6418(RTCW(tr1), Result, arg1, (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L)));
				Result = (EIF_REFERENCE) tr1;
			}
		} else {
			if ((EIF_BOOLEAN) (loc3 > loc4)) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(Result))-950])(Result, (EIF_CHARACTER_8) '$');
			} else {
				loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(arg1))-712])(arg1, loc3));
				if ((EIF_BOOLEAN)(loc5 == (EIF_CHARACTER_8) '$')) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(Result))-950])(Result, (EIF_CHARACTER_8) '$');
					loc3++;
				} else {
					tr1 = RTOSCF(6466,F971_6466, (Current));
					loc1 = F958_6400(RTCW(tr1), arg1, ((EIF_INTEGER_32) 5L));
					if ((EIF_BOOLEAN)(loc5 == (EIF_CHARACTER_8) '{')) {
						loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						loc3++;
						loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						for (;;) {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 > loc4) || loc7)) break;
							loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(arg1))-712])(arg1, loc3));
							if ((EIF_BOOLEAN)(loc5 == (EIF_CHARACTER_8) '}')) {
								loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								if ((EIF_BOOLEAN)(loc5 != (EIF_CHARACTER_8) '\000')) {
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(loc1))-950])(loc1, loc5);
								} else {
									tr1 = RTOSCF(6466,F971_6466, (Current));
									F958_6420(RTCW(tr1), loc1, arg1, loc3, loc3);
								}
							}
							loc3++;
						}
					} else {
						loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						for (;;) {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 > loc4) || loc7)) break;
							loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(arg1))-712])(arg1, loc3));
							switch (loc5) {
								case (EIF_CHARACTER_8) '0':
								case (EIF_CHARACTER_8) '1':
								case (EIF_CHARACTER_8) '2':
								case (EIF_CHARACTER_8) '3':
								case (EIF_CHARACTER_8) '4':
								case (EIF_CHARACTER_8) '5':
								case (EIF_CHARACTER_8) '6':
								case (EIF_CHARACTER_8) '7':
								case (EIF_CHARACTER_8) '8':
								case (EIF_CHARACTER_8) '9':
								case (EIF_CHARACTER_8) 'A':
								case (EIF_CHARACTER_8) 'B':
								case (EIF_CHARACTER_8) 'C':
								case (EIF_CHARACTER_8) 'D':
								case (EIF_CHARACTER_8) 'E':
								case (EIF_CHARACTER_8) 'F':
								case (EIF_CHARACTER_8) 'G':
								case (EIF_CHARACTER_8) 'H':
								case (EIF_CHARACTER_8) 'I':
								case (EIF_CHARACTER_8) 'J':
								case (EIF_CHARACTER_8) 'K':
								case (EIF_CHARACTER_8) 'L':
								case (EIF_CHARACTER_8) 'M':
								case (EIF_CHARACTER_8) 'N':
								case (EIF_CHARACTER_8) 'O':
								case (EIF_CHARACTER_8) 'P':
								case (EIF_CHARACTER_8) 'Q':
								case (EIF_CHARACTER_8) 'R':
								case (EIF_CHARACTER_8) 'S':
								case (EIF_CHARACTER_8) 'T':
								case (EIF_CHARACTER_8) 'U':
								case (EIF_CHARACTER_8) 'V':
								case (EIF_CHARACTER_8) 'W':
								case (EIF_CHARACTER_8) 'X':
								case (EIF_CHARACTER_8) 'Y':
								case (EIF_CHARACTER_8) 'Z':
								case (EIF_CHARACTER_8) '_':
								case (EIF_CHARACTER_8) 'a':
								case (EIF_CHARACTER_8) 'b':
								case (EIF_CHARACTER_8) 'c':
								case (EIF_CHARACTER_8) 'd':
								case (EIF_CHARACTER_8) 'e':
								case (EIF_CHARACTER_8) 'f':
								case (EIF_CHARACTER_8) 'g':
								case (EIF_CHARACTER_8) 'h':
								case (EIF_CHARACTER_8) 'i':
								case (EIF_CHARACTER_8) 'j':
								case (EIF_CHARACTER_8) 'k':
								case (EIF_CHARACTER_8) 'l':
								case (EIF_CHARACTER_8) 'm':
								case (EIF_CHARACTER_8) 'n':
								case (EIF_CHARACTER_8) 'o':
								case (EIF_CHARACTER_8) 'p':
								case (EIF_CHARACTER_8) 'q':
								case (EIF_CHARACTER_8) 'r':
								case (EIF_CHARACTER_8) 's':
								case (EIF_CHARACTER_8) 't':
								case (EIF_CHARACTER_8) 'u':
								case (EIF_CHARACTER_8) 'v':
								case (EIF_CHARACTER_8) 'w':
								case (EIF_CHARACTER_8) 'x':
								case (EIF_CHARACTER_8) 'y':
								case (EIF_CHARACTER_8) 'z':
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(loc1))-950])(loc1, loc5);
									loc3++;
									break;
								default:
									loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									break;
							}
						}
					}
					loc2 = F994_6717(Current, loc1);
					if ((EIF_BOOLEAN)(loc2 != NULL)) {
						tr1 = RTOSCF(6466,F971_6466, (Current));
						tr1 = F958_6417(RTCW(tr1), Result, loc2);
						Result = (EIF_REFERENCE) tr1;
					} else {
						if ((EIF_BOOLEAN) !arg2) {
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(Result))-950])(Result, (EIF_CHARACTER_8) '$');
							if (loc6) {
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(Result))-950])(Result, (EIF_CHARACTER_8) '{');
							}
							tr1 = RTOSCF(6466,F971_6466, (Current));
							tr1 = F958_6417(RTCW(tr1), Result, loc1);
							Result = (EIF_REFERENCE) tr1;
							if (loc6) {
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(Result))-950])(Result, (EIF_CHARACTER_8) '}');
							}
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit332 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
