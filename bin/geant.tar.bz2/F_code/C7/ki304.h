
#ifndef _C7_ki304_
#define _C7_ki304_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F965_6445(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit304(void);
extern char *(*R1539[])();
extern char *(*R3121[])();
extern char *(*R1545[])();
extern char *(*R1548[])();

#ifdef __cplusplus
}
#endif

#endif
