
#ifndef _C7_kl328_
#define _C7_kl328_

#ifdef __cplusplus
extern "C" {
#endif

extern void F989_6693(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F989_6695(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,6697)
static EIF_REFERENCE F989_6697_body(EIF_REFERENCE);
extern EIF_REFERENCE F989_6697(EIF_REFERENCE);
extern EIF_CHARACTER_8 F989_6698(EIF_REFERENCE);
extern EIF_REFERENCE F989_6699(EIF_REFERENCE);
extern void F989_6701(EIF_REFERENCE);
extern void EIF_Minit328(void);
extern void F943_5827(EIF_REFERENCE);
extern char *(*R3355[])();

#ifdef __cplusplus
}
#endif

#endif
