/*
 * Code for class ST_SPLITTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st346.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ST_SPLITTER}.make */
void F1013_6865 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(6870,F1013_6870, (Current));
	F1013_6871(Current, tr1);
	RTLE;
}

/* {ST_SPLITTER}.make_with_separators */
void F1013_6866 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1013_6871(Current, arg1);
}

/* {ST_SPLITTER}.default_separators */

EIF_REFERENCE F1013_6870 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6870,RTMS_EX_H(" \011\015\012",4,537464074));
}

/* {ST_SPLITTER}.set_separators */
void F1013_6871 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1221,873,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1214_8231(RTCW(tr1), loc2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(arg1))-950])(arg1, loc1);
		F1218_8333(RTCW(tr1), ti4_1);
		loc1++;
	}
	RTLE;
}

/* {ST_SPLITTER}.split */
EIF_REFERENCE F1013_6875 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1013_6881(Current, arg1, (EIF_BOOLEAN) 0);
}

/* {ST_SPLITTER}.split_greedy */
EIF_REFERENCE F1013_6876 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1013_6881(Current, arg1, (EIF_BOOLEAN) 1);
}

/* {ST_SPLITTER}.do_split */
EIF_REFERENCE F1013_6881 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLR(3,loc7);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1184,0xFF01,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1184, _OBJSIZ_4_0_0_1_0_0_0_0_);
	}
	F1185_7905(RTCW(Result));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
			loc5 = (EIF_INTEGER_32) (tc1);
		}
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc6 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4750[Dtype(RTCW(arg1))-950])(arg1, loc1);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) && (EIF_BOOLEAN)(loc6 == loc5)) && (EIF_BOOLEAN) (loc1 < loc2))) {
				if ((EIF_BOOLEAN)(loc7 == NULL)) {
					loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4616[Dtype(RTCW(arg1))-946])(arg1, loc4, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
				} else {
					tr1 = RTOSCF(6466,F971_6466, (Current));
					tr1 = F958_6418(RTCW(tr1), loc7, arg1, loc4, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
					loc7 = (EIF_REFERENCE) tr1;
				}
				loc1++;
				loc4 = (EIF_INTEGER_32) loc1;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tb1 = F1218_8327(RTCW(tr1), loc6);
				if (tb1) {
					if ((EIF_BOOLEAN)(loc3 == (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)))) {
						if (arg2) {
							tr1 = RTMS_EX_H("",0,0);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(Result))-1184])(Result, tr1);
						}
					} else {
						if ((EIF_BOOLEAN)(loc7 == NULL)) {
							loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4616[Dtype(RTCW(arg1))-946])(arg1, loc4, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
						} else {
							tr1 = RTOSCF(6466,F971_6466, (Current));
							tr1 = F958_6418(RTCW(tr1), loc7, arg1, loc4, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
							loc7 = (EIF_REFERENCE) tr1;
						}
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(Result))-1184])(Result, loc7);
					}
					loc7 = (EIF_REFERENCE) NULL;
					loc3 = (EIF_INTEGER_32) loc1;
					loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
				}
			}
			loc1++;
		}
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
			if ((EIF_BOOLEAN)(loc7 == NULL)) {
				loc7 = (EIF_REFERENCE) arg1;
			} else {
				tr1 = RTOSCF(6466,F971_6466, (Current));
				tr1 = F958_6418(RTCW(tr1), loc7, arg1, loc4, loc2);
				loc7 = (EIF_REFERENCE) tr1;
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(Result))-1184])(Result, loc7);
		} else {
			if ((EIF_BOOLEAN) (loc3 < loc2)) {
				if ((EIF_BOOLEAN)(loc7 == NULL)) {
					loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4616[Dtype(RTCW(arg1))-946])(arg1, loc4, loc2);
				} else {
					tr1 = RTOSCF(6466,F971_6466, (Current));
					tr1 = F958_6418(RTCW(tr1), loc7, arg1, loc4, loc2);
					loc7 = (EIF_REFERENCE) tr1;
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(Result))-1184])(Result, loc7);
			} else {
				if (arg2) {
					tr1 = RTMS_EX_H("",0,0);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6021[Dtype(RTCW(Result))-1184])(Result, tr1);
				}
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit346 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
