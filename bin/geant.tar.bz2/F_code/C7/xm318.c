/*
 * Code for class XM_NAMESPACE_RESOLVER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm318.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_NAMESPACE_RESOLVER}.initialize */
void F979_6559 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1294, 1).id);
	F1295_9281(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F979_6575(Current);
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.on_finish */
void F979_6560 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R1968[Dtype(RTCW(tr1))-194])(tr1);
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.on_start */
void F979_6561 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F979_6559(Current);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R1967[Dtype(RTCW(tr1))-194])(tr1);
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.on_start_tag */
void F979_6564 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1295_9289(RTCW(tr1));
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg3;
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.on_attribute */
void F979_6565 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,arg3);
	RTLR(3,tr1);
	RTLR(4,arg4);
	RTLIU(5);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN) !F194_2128(Current, arg2)) {
		tb1 = F979_6570(Current, arg3);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F1295_9282(RTCW(tr1), arg4);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_)) {
			F979_6576(Current, arg2, arg3, arg4);
		}
	} else {
		tb1 = '\0';
		if ((EIF_BOOLEAN)(arg2 != NULL)) {
			tb1 = F979_6570(Current, arg2);
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tb1 = F1295_9285(RTCW(tr1), arg2);
			if (tb1) {
				tr1 = RTOSCF(6583,F979_6583, (Current));
				F196_2150(Current, tr1);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F1295_9283(RTCW(tr1), arg4, arg3);
			}
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_)) {
				F979_6576(Current, arg2, arg3, arg4);
			}
		} else {
			F979_6576(Current, arg2, arg3, arg4);
		}
	}
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.on_start_tag_finish */
void F979_6566 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,tr2);
	RTLR(5,loc1);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	RTCT0("attached element_local_part as l_element_local_part", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		tb1 = F194_2128(Current, loc3);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = F1295_9286(RTCW(tr1), loc3);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr2 = F1295_9288(RTCW(tr2), loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1973[Dtype(RTCW(tr1))-194])(tr1, tr2, loc3, loc2);
			F979_6568(Current);
		} else {
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = RTOSCF(6582,F979_6582, (Current));
			loc1 = F958_6416(RTCW(tr1), tr2);
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = RTMS_EX_H(" in tag <",9,992440636);
			tr1 = F958_6417(RTCW(tr1), loc1, tr2);
			loc1 = (EIF_REFERENCE) tr1;
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr1 = F958_6417(RTCW(tr1), loc1, loc3);
			loc1 = (EIF_REFERENCE) tr1;
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = RTMS_EX_H(":",1,58);
			tr1 = F958_6417(RTCW(tr1), loc1, tr2);
			loc1 = (EIF_REFERENCE) tr1;
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr1 = F958_6417(RTCW(tr1), loc1, loc2);
			loc1 = (EIF_REFERENCE) tr1;
			tr1 = RTOSCF(6466,F971_6466, (Current));
			tr2 = RTMS_EX_H(">",1,62);
			tr1 = F958_6417(RTCW(tr1), loc1, tr2);
			loc1 = (EIF_REFERENCE) tr1;
			F196_2150(Current, loc1);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = F1295_9287(RTCW(tr2));
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1973[Dtype(RTCW(tr1))-194])(tr1, tr2, tr3, loc2);
		F979_6568(Current);
	}
	F196_2155(Current);
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.on_end_tag */
void F979_6567 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		tb1 = F194_2128(Current, arg2);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F1295_9288(RTCW(tr1), arg2);
		F196_2156(Current, tr1, arg2, arg3);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F1295_9287(RTCW(tr1));
		F196_2156(Current, tr1, arg2, arg3);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1295_9290(RTCW(tr1));
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.on_delayed_attributes */
void F979_6568 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTGC;
	for (;;) {
		if (F979_6578(Current)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc1 = F1196_8053(RTCW(tr1));
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb1 = F194_2128(Current, loc1);
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tb1 = F1295_9286(RTCW(tr1), loc1);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr2 = F1295_9288(RTCW(tr2), loc1);
				tr3 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				tr3 = F1196_8053(RTCW(tr3));
				tr4 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				tr4 = F1196_8053(RTCW(tr4));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1974[Dtype(RTCW(tr1))-194])(tr1, tr2, loc1, tr3, tr4);
			} else {
				if (F979_6571(Current, loc1)) {
					tr1 = *(EIF_REFERENCE *)(Current);
					tr2 = RTOSCF(3315,F377_3315, (Current));
					tr3 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					tr3 = F1196_8053(RTCW(tr3));
					tr4 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					tr4 = F1196_8053(RTCW(tr4));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1974[Dtype(RTCW(tr1))-194])(tr1, tr2, loc1, tr3, tr4);
				} else {
					if (F979_6570(Current, loc1)) {
						tr1 = *(EIF_REFERENCE *)(Current);
						tr2 = RTOSCF(3316,F377_3316, (Current));
						tr3 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
						tr3 = F1196_8053(RTCW(tr3));
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						tr4 = F1196_8053(RTCW(tr4));
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1974[Dtype(RTCW(tr1))-194])(tr1, tr2, loc1, tr3, tr4);
					} else {
						tr1 = RTOSCF(6582,F979_6582, (Current));
						F196_2150(Current, tr1);
					}
				}
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = F979_6572(Current);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			tr3 = F1196_8053(RTCW(tr3));
			tr4 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tr4 = F1196_8053(RTCW(tr4));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1974[Dtype(RTCW(tr1))-194])(tr1, tr2, loc1, tr3, tr4);
		}
		F979_6577(Current);
	}
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.is_xmlns */
EIF_BOOLEAN F979_6570 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = RTOSCF(3309,F377_3309, (Current));
		Result = F269_2471(Current, tr1, arg1);
	}
	RTLE;
	return Result;
}

/* {XM_NAMESPACE_RESOLVER}.is_xml */
EIF_BOOLEAN F979_6571 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = RTOSCF(3310,F377_3310, (Current));
		Result = F269_2471(Current, tr1, arg1);
	}
	RTLE;
	return Result;
}

/* {XM_NAMESPACE_RESOLVER}.unprefixed_attribute_namespace */
EIF_REFERENCE F979_6572 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) RTOSCF(3308,F377_3308, (Current));
}

/* {XM_NAMESPACE_RESOLVER}.attributes_make */
void F979_6575 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F269_2477(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = F269_2476(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = F269_2476(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.attributes_force */
void F979_6576 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1196_8059(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1196_8059(RTCW(tr1), arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1196_8059(RTCW(tr1), arg3);
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.attributes_remove */
void F979_6577 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1196_8062(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1196_8062(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1196_8062(RTCW(tr1));
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.attributes_is_empty */
EIF_BOOLEAN F979_6578 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	Result = F1125_7674(RTCW(tr1));
	RTLE;
	return Result;
}

/* {XM_NAMESPACE_RESOLVER}.undeclared_namespace_error */

EIF_REFERENCE F979_6582 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6582,RTMS_EX_H("Undeclared namespace error",26,1792447602));
}

/* {XM_NAMESPACE_RESOLVER}.duplicate_namespace_declaration_error */

EIF_REFERENCE F979_6583 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6583,RTMS_EX_H("Namespace declared twice",24,1284969317));
}

void EIF_Minit318 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
