/*
 * Code for class KL_EXECUTION_ENVIRONMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl333.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_EXECUTION_ENVIRONMENT}.variable_value */
EIF_REFERENCE F994_6717 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(6720,F994_6720, (Current));
	tr2 = RTOSCF(6466,F971_6466, (Current));
	tr2 = F958_6423(RTCW(tr2), arg1);
	tr1 = F298_2907(RTCW(tr1), tr2);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = F946_5989(loc1);
		if (tb1) {
			tr1 = F943_5880(loc1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			tr1 = RTLNS(eif_new_type(956, 0x01).id, 956, _OBJSIZ_0_0_0_0_0_0_0_0_);
			Result = F957_6362(RTCW(tr1), loc1);
		}
	}
	RTLE;
	return Result;
}

/* {KL_EXECUTION_ENVIRONMENT}.set_variable_value */
void F994_6718 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg2);
	RTLR(4,tr3);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(6720,F994_6720, (Current));
	tr2 = RTOSCF(6466,F971_6466, (Current));
	tr2 = F958_6423(RTCW(tr2), arg2);
	tr3 = RTOSCF(6466,F971_6466, (Current));
	tr3 = F958_6423(RTCW(tr3), arg1);
	F298_2920(RTCW(tr1), tr2, tr3);
	RTLE;
}

/* {KL_EXECUTION_ENVIRONMENT}.sleep */
void F994_6719 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(6720,F994_6720, (Current));
	F298_2923(RTCW(tr1), arg1);
	RTLE;
}

/* {KL_EXECUTION_ENVIRONMENT}.environment_impl */
static EIF_REFERENCE F994_6720_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6720);
#define Result RTOSR(6720)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(297, 0x01).id, 297, _OBJSIZ_0_0_0_1_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6720);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F994_6720 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6720,F994_6720_body,(Current));
}

void EIF_Minit333 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
