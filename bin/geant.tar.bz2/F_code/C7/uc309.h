
#ifndef _C7_uc309_
#define _C7_uc309_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F970_6457(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F970_6460(EIF_REFERENCE);
extern void EIF_Minit309(void);
extern void F1436_11325(EIF_REFERENCE);
extern void F1436_11332(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
