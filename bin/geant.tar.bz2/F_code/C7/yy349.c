/*
 * Code for class YY_SCANNER_SKELETON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy349.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_SCANNER_SKELETON}.make_with_buffer */
void F1016_6963 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(2947,F301_2947, (Current));
	tr1 = F25_227(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	F1018_7055(Current);
	F1016_6998(Current);
	RTLE;
}

/* {YY_SCANNER_SKELETON}.yy_initialize */
void F1016_6964 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5357[dtype-1303])(Current);
	*(EIF_INTEGER_32 *)(Current + O5369[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O5375[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O5376[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O5377[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O5373[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O5401[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O5400[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O5399[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {YY_SCANNER_SKELETON}.reset */
void F1016_6965 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O5398[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current + O5369[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O5375[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O5376[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O5377[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O5373[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O5401[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O5400[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O5399[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_BOOLEAN *)(Current + O5378[dtype-1015]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_INTEGER_32 *)(Current + O5379[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current + O5380[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current + O5381[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {YY_SCANNER_SKELETON}.text */
EIF_REFERENCE F1016_6967 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]) < *(EIF_INTEGER_32 *)(Current + O5373[dtype-1015]))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R1055[Dtype(RTCW(tr1))-302])(tr1, *(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5373[dtype-1015]) - ((EIF_INTEGER_32) 1L)));
	} else {
		Result = RTLNS(eif_new_type(950, 0x01).id, 950, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F949_6124(RTCW(Result), ((EIF_INTEGER_32) 0L));
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {YY_SCANNER_SKELETON}.unicode_text */
EIF_REFERENCE F1016_6968 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]) < *(EIF_INTEGER_32 *)(Current + O5373[dtype-1015]))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R1056[Dtype(RTCW(tr1))-302])(tr1, *(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5373[dtype-1015]) - ((EIF_INTEGER_32) 1L)));
	} else {
		Result = RTLNS(eif_new_type(947, 0x01).id, 947, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F946_5957(RTCW(Result), ((EIF_INTEGER_32) 0L));
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {YY_SCANNER_SKELETON}.text_item */
EIF_CHARACTER_8 F1016_6970 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		/* INLINED CODE (SPECIAL.item) */
		tc2 = *((EIF_CHARACTER_8 *)RTCW(loc1) + ((EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]) + arg1) - ((EIF_INTEGER_32) 1L))));
		/* END INLINED CODE */
		tc1 = tc2;
		RTLE;
		return (EIF_CHARACTER_8) tc1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R1043[Dtype(RTCW(tr1))-302])(tr1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]) + arg1) - ((EIF_INTEGER_32) 1L))));
	}
	RTLE;
	return Result;
}

/* {YY_SCANNER_SKELETON}.unicode_text_item */
EIF_CHARACTER_32 F1016_6971 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		/* INLINED CODE (SPECIAL.item) */
		tw2 = *((EIF_CHARACTER_32 *)RTCW(loc1) + ((EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]) + arg1) - ((EIF_INTEGER_32) 1L))));
		/* END INLINED CODE */
		tw1 = tw2;
		RTLE;
		return (EIF_CHARACTER_32) tw1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R1053[Dtype(RTCW(tr1))-302])(tr1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]) + arg1) - ((EIF_INTEGER_32) 1L)));
	}
	RTLE;
	return Result;
}

/* {YY_SCANNER_SKELETON}.text_substring */
EIF_REFERENCE F1016_6972 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg2 < arg1)) {
		tr1 = RTLNS(eif_new_type(950, 0x01).id, 950, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F949_6124(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R1055[Dtype(RTCW(tr1))-302])(tr1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]) + arg1) - ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]) + arg2) - ((EIF_INTEGER_32) 1L)));
	}
	RTLE;
	return Result;
}

/* {YY_SCANNER_SKELETON}.start_condition */
EIF_INTEGER_32 F1016_6975 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5369[Dtype(Current)-1015]) - ((EIF_INTEGER_32) 1L)) / ((EIF_INTEGER_32) 2L));
}

/* {YY_SCANNER_SKELETON}.text_count */
EIF_INTEGER_32 F1016_6976 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5373[dtype-1015]) - *(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]));
}

/* {YY_SCANNER_SKELETON}.line */
EIF_INTEGER_32 F1016_6977 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O5401[Dtype(Current)-1015]);
}


/* {YY_SCANNER_SKELETON}.column */
EIF_INTEGER_32 F1016_6978 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O5400[Dtype(Current)-1015]);
}


/* {YY_SCANNER_SKELETON}.position */
EIF_INTEGER_32 F1016_6979 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O5399[Dtype(Current)-1015]);
}


/* {YY_SCANNER_SKELETON}.pushed_start_condition_count */
EIF_INTEGER_32 F1016_6980 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O5398[Dtype(Current)-1015]);
}


/* {YY_SCANNER_SKELETON}.set_start_condition */
void F1016_6981 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O5369[Dtype(Current)-1015]) = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * arg1) + ((EIF_INTEGER_32) 1L));
}

/* {YY_SCANNER_SKELETON}.push_start_condition */
void F1016_6982 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (tr1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O5398[dtype-1015]) >= ti4_1)) {
		tr1 = RTOSCF(2947,F301_2947, (Current));
		tr1 = F25_235(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_4_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5398[dtype-1015]) + ((EIF_INTEGER_32) 10L)));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	}
	tr1 = RTOSCF(2947,F301_2947, (Current));
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	ti4_1 = F1016_6975(Current);
	ti4_2 = *(EIF_INTEGER_32 *)(Current + O5398[dtype-1015]);
	F25_232(RTCW(tr1), tr2, ti4_1, ti4_2);
	(*(EIF_INTEGER_32 *)(Current + O5398[dtype-1015]))++;
	F1016_6981(Current, arg1);
	RTLE;
}

/* {YY_SCANNER_SKELETON}.pop_start_condition */
void F1016_6983 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current + O5398[dtype-1015]))--;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current + O5398[dtype-1015])));
	/* END INLINED CODE */
	ti4_1 = ti4_3;
	F1016_6981(Current, ti4_1);
	RTLE;
}

/* {YY_SCANNER_SKELETON}.less */
void F1016_6991 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5393[dtype-1303])(Current)) {
		loc2 = *(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + arg1);
		loc1 = *(EIF_INTEGER_32 *)(Current + O5373[dtype-1015]);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - loc2);
		*(EIF_INTEGER_32 *)(Current + O5373[dtype-1015]) = (EIF_INTEGER_32) loc2;
		if ((EIF_BOOLEAN) (loc1 < *(EIF_INTEGER_32 *)(Current + O5376[dtype-1015]))) {
			(*(EIF_INTEGER_32 *)(Current + O5376[dtype-1015])) -= loc1;
		} else {
			loc3 = *(EIF_INTEGER_32 *)(Current + O5379[dtype-1015]);
			*(EIF_INTEGER_32 *)(Current + O5379[dtype-1015]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			*(EIF_INTEGER_32 *)(Current + O5375[dtype-1015]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O5401[dtype-1015]);
			*(EIF_INTEGER_32 *)(Current + O5376[dtype-1015]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O5400[dtype-1015]);
			F1016_7010(Current);
			*(EIF_INTEGER_32 *)(Current + O5379[dtype-1015]) = (EIF_INTEGER_32) loc3;
		}
	} else {
		*(EIF_INTEGER_32 *)(Current + O5373[dtype-1015]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]) + arg1);
	}
	*(EIF_INTEGER_32 *)(Current + O5377[dtype-1015]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5399[dtype-1015]) + arg1);
	RTLE;
}

/* {YY_SCANNER_SKELETON}.set_input_buffer */
void F1016_6995 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != *(EIF_REFERENCE *)(Current))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		F178_2038(RTCW(tr1), *(EIF_INTEGER_32 *)(Current + O5373[dtype-1015]));
		tr1 = *(EIF_REFERENCE *)(Current);
		F178_2037(RTCW(tr1), *(EIF_INTEGER_32 *)(Current + O5377[dtype-1015]), *(EIF_INTEGER_32 *)(Current + O5375[dtype-1015]), *(EIF_INTEGER_32 *)(Current + O5376[dtype-1015]));
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
		F1016_6998(Current);
	}
	RTLE;
}

/* {YY_SCANNER_SKELETON}.print_last_token */
void F1016_6997 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
	tr2 = RTMS_EX_H("Last token code: ",17,1619278880);
	F999_6748(RTCW(tr1), tr2);
	tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
	F995_6723(RTCW(tr1), *(EIF_INTEGER_32 *)(Current + O5290[dtype-1014]));
	tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
	F999_6747(RTCW(tr1), (EIF_CHARACTER_8) '\012');
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5393[dtype-1303])(Current)) {
		tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
		tr2 = RTMS_EX_H("Last token line: ",17,1804699680);
		F999_6748(RTCW(tr1), tr2);
		tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
		F995_6723(RTCW(tr1), *(EIF_INTEGER_32 *)(Current + O5401[dtype-1015]));
		tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
		tr2 = RTMS_EX_H("\012Last token column: ",20,7670816);
		F999_6748(RTCW(tr1), tr2);
		tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
		F995_6723(RTCW(tr1), *(EIF_INTEGER_32 *)(Current + O5400[dtype-1015]));
		tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
		F999_6747(RTCW(tr1), (EIF_CHARACTER_8) '\012');
	}
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5394[dtype-1303])(Current)) {
		tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
		tr2 = RTMS_EX_H("Last token position: ",21,584845344);
		F999_6748(RTCW(tr1), tr2);
		tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
		F995_6723(RTCW(tr1), *(EIF_INTEGER_32 *)(Current + O5399[dtype-1015]));
		tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
		F999_6747(RTCW(tr1), (EIF_CHARACTER_8) '\012');
	}
	tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
	tr2 = RTMS_EX_H("Last token text: ",17,1989152800);
	F999_6748(RTCW(tr1), tr2);
	switch (*(EIF_INTEGER_32 *)(Current + O5290[dtype-1014])) {
		case 0L:
			tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
			tr2 = RTMS_EX_H("EOF token\012",10,1675200778);
			F999_6748(RTCW(tr1), tr2);
			break;
		case -1L:
			tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
			tr2 = RTMS_EX_H("Error token\012",12,626631178);
			F999_6748(RTCW(tr1), tr2);
			break;
		case -2L:
			tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
			tr2 = RTMS_EX_H("Unknown token\012",14,192392202);
			F999_6748(RTCW(tr1), tr2);
			break;
		default:
			tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
			F999_6747(RTCW(tr1), (EIF_CHARACTER_8) '\"');
			tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
			tr2 = F1016_6967(Current);
			F999_6748(RTCW(tr1), tr2);
			tr1 = RTOSCF(1121,F100_1121, (RTCV(RTOSCF(3323,F378_3323, (Current)))));
			tr2 = RTMS_EX_H("\"\012",2,8714);
			F999_6748(RTCW(tr1), tr2);
			break;
	}
	RTLE;
}

/* {YY_SCANNER_SKELETON}.yy_load_input_buffer */
void F1016_6998 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
	F1018_7067(Current, tr1);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O1906[Dtype(tr1)-177]);
	*(EIF_INTEGER_32 *)(Current + O5373[dtype-1015]) = (EIF_INTEGER_32) ti4_1;
	*(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O5373[dtype-1015]);
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O1904[Dtype(tr1)-177]);
	*(EIF_INTEGER_32 *)(Current + O5375[dtype-1015]) = (EIF_INTEGER_32) ti4_1;
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O1905[Dtype(tr1)-177]);
	*(EIF_INTEGER_32 *)(Current + O5376[dtype-1015]) = (EIF_INTEGER_32) ti4_1;
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O1903[Dtype(tr1)-177]);
	*(EIF_INTEGER_32 *)(Current + O5377[dtype-1015]) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {YY_SCANNER_SKELETON}.yy_refill_input_buffer */
void F1016_6999 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F178_2038(RTCW(tr1), *(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]));
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R1915[Dtype(RTCW(tr1))-177])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
	F1018_7067(Current, tr1);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O1906[Dtype(tr1)-177]);
	*(EIF_INTEGER_32 *)(Current + O5373[dtype-1015]) = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5373[dtype-1015]) - *(EIF_INTEGER_32 *)(Current + O5374[dtype-1015])) + loc1);
	*(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]) = (EIF_INTEGER_32) loc1;
	RTLE;
}

/* {YY_SCANNER_SKELETON}.yy_fixed_array */
EIF_REFERENCE F1016_7002 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(2947,F301_2947, (Current));
	Result = F25_230(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {YY_SCANNER_SKELETON}.yy_array_subcopy */
void F1016_7003 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(4214,F806_4214, (Current));
	F960_6441(RTCW(tr1), arg1, arg2, arg3, arg4, arg5);
	RTLE;
}

/* {YY_SCANNER_SKELETON}.yy_at_beginning_of_line */
EIF_INTEGER_32 F1016_7006 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O1907[Dtype(tr1)-177]);
	if (tb1) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {YY_SCANNER_SKELETON}.yy_set_line_column */
void F1016_7010 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc6 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,loc8);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc7 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc8 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = *(EIF_INTEGER_32 *)(Current + O5373[dtype-1015]);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
	loc2 = *(EIF_INTEGER_32 *)(Current + O5374[dtype-1015]);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O5379[dtype-1015]);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ti4_1);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 < loc2) || loc5)) break;
		if ((EIF_BOOLEAN)(loc7 != NULL)) {
			/* INLINED CODE (SPECIAL.item) */
			tc2 = *((EIF_CHARACTER_8 *)RTCW(loc7) + (loc1));
			/* END INLINED CODE */
			tc1 = tc2;
			loc6 = (EIF_CHARACTER_32) tc1;
		} else {
			if ((EIF_BOOLEAN)(loc8 != NULL)) {
				/* INLINED CODE (SPECIAL.item) */
				tw2 = *((EIF_CHARACTER_32 *)RTCW(loc8) + (loc1));
				/* END INLINED CODE */
				loc6 = tw2;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc6 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R1053[Dtype(RTCW(tr1))-302])(tr1, loc1);
			}
		}
		if ((EIF_BOOLEAN)(loc6 == (EIF_CHARACTER_32) 10U)) {
			loc3++;
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			loc4++;
		}
		loc1--;
	}
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < loc2)) break;
		if ((EIF_BOOLEAN)(loc7 != NULL)) {
			/* INLINED CODE (SPECIAL.item) */
			tc2 = *((EIF_CHARACTER_8 *)RTCW(loc7) + (loc1));
			/* END INLINED CODE */
			tc1 = tc2;
			loc6 = (EIF_CHARACTER_32) tc1;
		} else {
			if ((EIF_BOOLEAN)(loc8 != NULL)) {
				/* INLINED CODE (SPECIAL.item) */
				tw2 = *((EIF_CHARACTER_32 *)RTCW(loc8) + (loc1));
				/* END INLINED CODE */
				loc6 = tw2;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc6 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R1053[Dtype(RTCW(tr1))-302])(tr1, loc1);
			}
		}
		if ((EIF_BOOLEAN)(loc6 == (EIF_CHARACTER_32) 10U)) {
			loc3++;
		}
		loc1--;
	}
	if (loc5) {
		(*(EIF_INTEGER_32 *)(Current + O5375[dtype-1015])) += loc3;
		*(EIF_INTEGER_32 *)(Current + O5376[dtype-1015]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
	} else {
		(*(EIF_INTEGER_32 *)(Current + O5376[dtype-1015])) += loc4;
	}
	RTLE;
}

void EIF_Minit349 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
