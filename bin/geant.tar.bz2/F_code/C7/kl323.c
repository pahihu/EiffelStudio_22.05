/*
 * Code for class KL_STDIN_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl323.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STDIN_FILE}.make */
void F984_6648 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(950, 1).id);
	F943_5827(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {KL_STDIN_FILE}.name */

EIF_REFERENCE F984_6649 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6649,RTMS_EX_H("stdin",5,1953620846));
}

/* {KL_STDIN_FILE}.last_character */
EIF_CHARACTER_8 F984_6650 (EIF_REFERENCE Current)
{
	return *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
}


/* {KL_STDIN_FILE}.last_string */
EIF_REFERENCE F984_6651 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {KL_STDIN_FILE}.end_of_file */
EIF_BOOLEAN F984_6654 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
}


/* {KL_STDIN_FILE}.read_character */
void F984_6655 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tc1 = *(EIF_CHARACTER_8 *)(RTCW(loc1)+ _CHROFF_1_0_);
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTOSCF(6664,F984_6664, (Current));
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3184[Dtype(RTCW(tr1))-698])(tr1);
		if (tb1) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			tr1 = RTOSCF(6664,F984_6664, (Current));
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R2789[Dtype(RTCW(tr1))-698])(tr1);
			tr1 = RTOSCF(6664,F984_6664, (Current));
			tc1 = *(EIF_CHARACTER_8 *)(RTCW(tr1) + O2729[Dtype(tr1)-305]);
			*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
			tr1 = RTOSCF(6664,F984_6664, (Current));
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3184[Dtype(RTCW(tr1))-698])(tr1);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) tb1;
		}
	}
	RTLE;
}

/* {KL_STDIN_FILE}.unread_character */
void F984_6656 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {70,900,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNSMART(typres0.id);
	}
	F69_965(RTCW(loc1), arg1);
	loc2 = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		F71_967(RTCW(loc1), loc2);
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) arg1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {KL_STDIN_FILE}.read_line */
void F984_6658 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(6466,F971_6466, (Current));
	F958_6427(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	for (;;) {
		if (loc1) break;
		F984_6655(Current);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_)) {
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc2 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
			switch (loc2) {
				case (EIF_CHARACTER_8) '\012':
					loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					break;
				case (EIF_CHARACTER_8) '\015':
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					break;
				default:
					if (loc4) {
						F984_6656(Current, loc2);
						loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4802[Dtype(RTCW(tr1))-950])(tr1, loc2);
					}
					break;
			}
		}
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) loc3;
	RTLE;
}

/* {KL_STDIN_FILE}.read_to_string */
EIF_INTEGER_32 F984_6660 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLIU(7);
	
	RTGC;
	loc2 = (EIF_INTEGER_32) arg2;
	loc7 = *(EIF_REFERENCE *)(Current);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == arg3) || (EIF_BOOLEAN)(loc7 == NULL))) break;
		loc1++;
		tc1 = *(EIF_CHARACTER_8 *)(RTCW(loc7)+ _CHROFF_1_0_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3121[Dtype(RTCW(arg1))-737])(arg1, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &loc2);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc7));
		loc7 = (EIF_REFERENCE) tr1;
		loc2++;
	}
	RTAR(Current, loc7);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc7;
	if ((EIF_BOOLEAN) (loc1 < arg3)) {
		tr1 = RTOSCF(6664,F984_6664, (Current));
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3184[Dtype(RTCW(tr1))-698])(tr1);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = RTOSCF(6290,F953_6290, (Current));
			tr2 = RTOSCF(6663,F984_6663, (Current));
			tb1 = F14_181(RTCW(tr1), arg1, tr2);
			if (tb1) {
				tr1 = RTOSCF(6664,F984_6664, (Current));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R2802[Dtype(RTCW(tr1))-698])(tr1, (EIF_INTEGER_32) (arg3 - loc1));
				tr1 = RTOSCF(6664,F984_6664, (Current));
				loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + O2730[Dtype(tr1)-305]);
				tb1 = F641_3592(RTCW(loc5));
				if ((EIF_BOOLEAN) !tb1) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
					F951_6212(RTCW(arg1), loc5, ((EIF_INTEGER_32) 1L), ti4_1, loc2);
					F945_5925(RTCW(arg1));
				}
				Result = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
				Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + Result);
			} else {
				loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg3 - loc1);
				loc6 = RTLNS(eif_new_type(950, 0x01).id, 950, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F949_6124(RTCW(loc6), loc4);
				F951_6286(RTCW(loc6), loc4);
				tr1 = RTOSCF(6664,F984_6664, (Current));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R2802[Dtype(RTCW(tr1))-698])(tr1, loc4);
				tr1 = RTOSCF(6664,F984_6664, (Current));
				loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + O2730[Dtype(tr1)-305]);
				tb1 = F641_3592(RTCW(loc5));
				if ((EIF_BOOLEAN) !tb1) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
					F951_6212(RTCW(loc6), loc5, ((EIF_INTEGER_32) 1L), ti4_1, ((EIF_INTEGER_32) 1L));
					F945_5925(RTCW(loc6));
				}
				loc4 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc3 > loc4)) break;
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3355[Dtype(RTCW(loc6))-712])(loc6, loc3));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3121[Dtype(RTCW(arg1))-737])(arg1, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &loc2);
					loc2++;
					loc3++;
				}
				Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + loc4);
			}
		} else {
			Result = (EIF_INTEGER_32) loc1;
		}
		tr1 = RTOSCF(6664,F984_6664, (Current));
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3184[Dtype(RTCW(tr1))-698])(tr1);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) tb1;
	} else {
		RTLE;
		return (EIF_INTEGER_32) loc1;
	}
	RTLE;
	return Result;
}

/* {KL_STDIN_FILE}.dummy_string */

EIF_REFERENCE F984_6663 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6663,RTMS_EX_H("",0,0));
}

/* {KL_STDIN_FILE}.console */
static EIF_REFERENCE F984_6664_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6664);
#define Result RTOSR(6664)
	RTOC_NEW(Result);
	Result = RTOSCF(581,F51_581, (RTCV(RTOSCF(24,F1_24, (Current)))));
	RTOSE (6664);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F984_6664 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6664,F984_6664_body,(Current));
}

void EIF_Minit323 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
