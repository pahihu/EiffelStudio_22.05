
#ifndef _C21_ar1036_
#define _C21_ar1036_

#ifdef __cplusplus
extern "C" {
#endif

extern void F509_4000(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F509_4001(EIF_REFERENCE);
extern EIF_REFERENCE F509_4002(EIF_REFERENCE);
extern EIF_REFERENCE F509_4004(EIF_REFERENCE);
extern EIF_INTEGER_32 F509_4005(EIF_REFERENCE);
extern void EIF_Minit1036(void);
extern EIF_TYPE_INDEX Y3323[];
extern EIF_TYPE_INDEX *Y3323_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
