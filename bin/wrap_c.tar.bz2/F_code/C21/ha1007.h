
#ifndef _C21_ha1007_
#define _C21_ha1007_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F473_3956(EIF_REFERENCE);
extern EIF_REFERENCE F473_3957(EIF_REFERENCE);
extern EIF_BOOLEAN F473_3959(EIF_REFERENCE);
extern void F473_3960(EIF_REFERENCE);
extern EIF_REFERENCE F473_3961(EIF_REFERENCE);
extern void EIF_Minit1007(void);
extern EIF_BOOLEAN F459_3942(EIF_REFERENCE);
extern char *(*R3966[])();
extern char *(*R3967[])();
extern char *(*R3772[])();
extern char *(*R3270[])();

#ifdef __cplusplus
}
#endif

#endif
