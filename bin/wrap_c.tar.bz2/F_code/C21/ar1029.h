
#ifndef _C21_ar1029_
#define _C21_ar1029_

#ifdef __cplusplus
extern "C" {
#endif

extern void F494_3982(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F494_3983(EIF_REFERENCE);
extern EIF_REFERENCE F494_3984(EIF_REFERENCE);
extern EIF_REFERENCE F494_3986(EIF_REFERENCE);
extern EIF_INTEGER_32 F494_3987(EIF_REFERENCE);
extern void EIF_Minit1029(void);
extern EIF_INTEGER_32 F848_4792(EIF_REFERENCE);
extern EIF_REFERENCE F848_4773(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y3323[];
extern EIF_TYPE_INDEX *Y3323_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
