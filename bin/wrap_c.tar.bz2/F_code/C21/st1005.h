
#ifndef _C21_st1005_
#define _C21_st1005_

#ifdef __cplusplus
extern "C" {
#endif

extern void F860_4947(EIF_REFERENCE, EIF_INTEGER_32);
extern void F860_4948(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F860_4949(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F860_4951(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F860_4952(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F860_4953(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1005(void);
extern EIF_BOOLEAN F855_4858(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F979_6357(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F979_6325(EIF_REFERENCE);
extern char *(*R3935[])();
extern char *(*R3936[])();
extern char *(*R4026[])();
extern char *(*R4966[])();
extern char *(*R4044[])();
extern char *(*R3502[])();
extern long O3500[];
extern long O4028[];

#ifdef __cplusplus
}
#endif

#endif
