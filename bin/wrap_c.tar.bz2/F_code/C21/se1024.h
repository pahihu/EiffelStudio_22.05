
#ifndef _C21_se1024_
#define _C21_se1024_

#ifdef __cplusplus
extern "C" {
#endif

extern void F713_4133(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit1024(void);
extern void F848_4810(EIF_REFERENCE, EIF_CHARACTER_32);

#ifdef __cplusplus
}
#endif

#endif
