
#ifndef _C21_to1049_
#define _C21_to1049_

#ifdef __cplusplus
extern "C" {
#endif

extern void F297_2870(EIF_REFERENCE, EIF_INTEGER_32);
extern void F297_2871(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern void F297_2877(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1049(void);
extern void F754_4491(EIF_REFERENCE, EIF_NATURAL_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2614[];
extern EIF_TYPE_INDEX *Y2614_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
