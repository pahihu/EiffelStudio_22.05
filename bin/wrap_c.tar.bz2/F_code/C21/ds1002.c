/*
 * Code for class DS_ARRAYED_SPARSE_TABLE_CURSOR [NATURAL_64, NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1002.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_ARRAYED_SPARSE_TABLE_CURSOR}.container */
EIF_REFERENCE F1156_8339 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


void EIF_Minit1002 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
