
#ifndef _C21_ge1017_
#define _C21_ge1017_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F482_3962(EIF_REFERENCE);
extern EIF_INTEGER_32 F482_3964(EIF_REFERENCE);
extern EIF_BOOLEAN F482_3971(EIF_REFERENCE);
extern void F482_3976(EIF_REFERENCE);
extern void F482_3977(EIF_REFERENCE);
extern EIF_REFERENCE F482_3978(EIF_REFERENCE);
extern void EIF_Minit1017(void);
extern char *(*R3483[])();
extern char *(*R3456[])();
extern long O3482[];
extern long O3484[];

#ifdef __cplusplus
}
#endif

#endif
