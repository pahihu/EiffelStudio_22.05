
#ifndef _C21_li1047_
#define _C21_li1047_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F820_4676(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F820_4677(EIF_REFERENCE);
extern void EIF_Minit1047(void);
extern void F849_4805(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F849_4790(EIF_REFERENCE);
extern EIF_REFERENCE F849_4780(EIF_REFERENCE);
extern void F849_4802(EIF_REFERENCE);
extern EIF_BOOLEAN F673_4113(EIF_REFERENCE);
extern void F849_4800(EIF_REFERENCE);
extern EIF_CHARACTER_8 F849_4774(EIF_REFERENCE);
extern long O3500[];

#ifdef __cplusplus
}
#endif

#endif
