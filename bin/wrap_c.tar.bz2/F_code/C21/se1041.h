
#ifndef _C21_se1041_
#define _C21_se1041_

#ifdef __cplusplus
extern "C" {
#endif

extern void F714_4133(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit1041(void);
extern char *(*R3528[])();

#ifdef __cplusplus
}
#endif

#endif
