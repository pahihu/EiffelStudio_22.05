
#ifndef _C21_ge1034_
#define _C21_ge1034_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F483_3962(EIF_REFERENCE);
extern EIF_INTEGER_32 F483_3964(EIF_REFERENCE);
extern EIF_BOOLEAN F483_3971(EIF_REFERENCE);
extern void F483_3976(EIF_REFERENCE);
extern void F483_3977(EIF_REFERENCE);
extern EIF_REFERENCE F483_3978(EIF_REFERENCE);
extern void EIF_Minit1034(void);
extern char *(*R3483[])();
extern char *(*R3456[])();
extern long O3482[];
extern long O3484[];

#ifdef __cplusplus
}
#endif

#endif
