
#ifndef _C21_sp1016_
#define _C21_sp1016_

#ifdef __cplusplus
extern "C" {
#endif

extern void F520_4006(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F520_4007(EIF_REFERENCE);
extern EIF_REFERENCE F520_4008(EIF_REFERENCE);
extern EIF_INTEGER_32 F520_4009(EIF_REFERENCE);
extern void EIF_Minit1016(void);
extern EIF_INTEGER_32 F752_4502(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y3323[];
extern EIF_TYPE_INDEX *Y3323_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
