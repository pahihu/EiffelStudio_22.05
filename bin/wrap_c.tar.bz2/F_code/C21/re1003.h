
#ifndef _C21_re1003_
#define _C21_re1003_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F702_4126(EIF_REFERENCE);
extern void F702_4128(EIF_REFERENCE);
extern void EIF_Minit1003(void);
extern char *(*R3565[])();
extern char *(*R3571[])();

#ifdef __cplusplus
}
#endif

#endif
