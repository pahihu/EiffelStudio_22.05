
#ifndef _C21_sp1033_
#define _C21_sp1033_

#ifdef __cplusplus
extern "C" {
#endif

extern void F521_4006(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F521_4007(EIF_REFERENCE);
extern EIF_REFERENCE F521_4008(EIF_REFERENCE);
extern EIF_INTEGER_32 F521_4009(EIF_REFERENCE);
extern void EIF_Minit1033(void);
extern EIF_INTEGER_32 F753_4502(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y3323[];
extern EIF_TYPE_INDEX *Y3323_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
