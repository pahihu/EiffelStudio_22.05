
#ifndef _C21_to1030_
#define _C21_to1030_

#ifdef __cplusplus
extern "C" {
#endif

extern void F296_2870(EIF_REFERENCE, EIF_INTEGER_32);
extern void F296_2871(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern void F296_2877(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1030(void);
extern void F753_4491(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2614[];
extern EIF_TYPE_INDEX *Y2614_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
