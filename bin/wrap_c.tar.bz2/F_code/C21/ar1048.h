
#ifndef _C21_ar1048_
#define _C21_ar1048_

#ifdef __cplusplus
extern "C" {
#endif

extern void F495_3982(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F495_3983(EIF_REFERENCE);
extern EIF_REFERENCE F495_3984(EIF_REFERENCE);
extern EIF_REFERENCE F495_3986(EIF_REFERENCE);
extern EIF_INTEGER_32 F495_3987(EIF_REFERENCE);
extern void EIF_Minit1048(void);
extern EIF_INTEGER_32 F849_4792(EIF_REFERENCE);
extern EIF_REFERENCE F849_4773(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y3323[];
extern EIF_TYPE_INDEX *Y3323_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
