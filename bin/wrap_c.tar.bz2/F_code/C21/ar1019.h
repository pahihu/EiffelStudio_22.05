
#ifndef _C21_ar1019_
#define _C21_ar1019_

#ifdef __cplusplus
extern "C" {
#endif

extern void F508_4000(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F508_4001(EIF_REFERENCE);
extern EIF_REFERENCE F508_4002(EIF_REFERENCE);
extern EIF_REFERENCE F508_4004(EIF_REFERENCE);
extern EIF_INTEGER_32 F508_4005(EIF_REFERENCE);
extern void EIF_Minit1019(void);
extern EIF_TYPE_INDEX Y3323[];
extern EIF_TYPE_INDEX *Y3323_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
