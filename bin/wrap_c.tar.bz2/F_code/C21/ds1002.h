
#ifndef _C21_ds1002_
#define _C21_ds1002_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1156_8339(EIF_REFERENCE);
extern void EIF_Minit1002(void);

#ifdef __cplusplus
}
#endif

#endif
