
#ifndef _C21_to1013_
#define _C21_to1013_

#ifdef __cplusplus
extern "C" {
#endif

extern void F295_2870(EIF_REFERENCE, EIF_INTEGER_32);
extern void F295_2871(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F295_2877(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1013(void);
extern void F752_4491(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2614[];
extern EIF_TYPE_INDEX *Y2614_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
