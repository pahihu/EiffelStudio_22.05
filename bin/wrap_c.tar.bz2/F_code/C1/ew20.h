
#ifndef _C1_ew20_
#define _C1_ew20_

#ifdef __cplusplus
extern "C" {
#endif

extern void F27_228(EIF_REFERENCE);
extern void F27_229(EIF_REFERENCE);
extern void F27_230(EIF_REFERENCE);
extern void F27_231(EIF_REFERENCE);
extern void F27_232(EIF_REFERENCE);
extern void F27_233(EIF_REFERENCE);
extern void F27_234(EIF_REFERENCE);
extern void F27_236(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F27_243(EIF_REFERENCE);
extern void EIF_Minit20(void);
extern char *(*R5149[])();

#ifdef __cplusplus
}
#endif

#endif
