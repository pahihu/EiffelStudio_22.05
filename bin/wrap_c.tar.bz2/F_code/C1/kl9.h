
#ifndef _C1_kl9_
#define _C1_kl9_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F13_114(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit9(void);

#ifdef __cplusplus
}
#endif

#endif
