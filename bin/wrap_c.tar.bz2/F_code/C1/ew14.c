/*
 * Code for class EWG_C_PHASE_1_ARRAY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew14.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EWG_C_PHASE_1_ARRAY}.make */
void F18_144 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EWG_C_PHASE_1_ARRAY}.make_with_size */
void F18_145 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {EWG_C_PHASE_1_ARRAY}.is_size_defined */
EIF_BOOLEAN F18_147 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL);
}

void EIF_Minit14 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
