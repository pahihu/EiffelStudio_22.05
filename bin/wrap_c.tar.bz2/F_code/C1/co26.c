/*
 * Code for class CODE_PAGE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co26.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CODE_PAGE_CONSTANTS}.utf7 */

EIF_REFERENCE F39_287 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (287,RTMS_EX_H("UTF-7",5,1414538039));
}

/* {CODE_PAGE_CONSTANTS}.utf8 */

EIF_REFERENCE F39_288 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (288,RTMS_EX_H("UTF-8",5,1414538040));
}

/* {CODE_PAGE_CONSTANTS}.utf16 */

EIF_REFERENCE F39_289 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (289,RTMS_EX_H("UTF-16",6,1345128758));
}

/* {CODE_PAGE_CONSTANTS}.utf32 */

EIF_REFERENCE F39_290 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (290,RTMS_EX_H("UTF-32",6,1345129266));
}

/* {CODE_PAGE_CONSTANTS}.utf16_le */

EIF_REFERENCE F39_291 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (291,RTMS_EX_H("UTF-16LE",8,312185413));
}

/* {CODE_PAGE_CONSTANTS}.utf32_le */

EIF_REFERENCE F39_292 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (292,RTMS_EX_H("UTF-32LE",8,345477701));
}

/* {CODE_PAGE_CONSTANTS}.utf16_be */

EIF_REFERENCE F39_293 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (293,RTMS_EX_H("UTF-16BE",8,312182853));
}

/* {CODE_PAGE_CONSTANTS}.utf32_be */

EIF_REFERENCE F39_294 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (294,RTMS_EX_H("UTF-32BE",8,345475141));
}

void EIF_Minit26 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
