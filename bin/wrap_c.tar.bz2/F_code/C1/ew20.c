/*
 * Code for class EWG_C_PHASE_1_STORAGE_CLASS_SPECIFIERS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew20.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EWG_C_PHASE_1_STORAGE_CLASS_SPECIFIERS}.make */
void F27_228 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EWG_C_PHASE_1_STORAGE_CLASS_SPECIFIERS}.set_typedef */
void F27_229 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_0_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EWG_C_PHASE_1_STORAGE_CLASS_SPECIFIERS}.set_extern */
void F27_230 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_0_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EWG_C_PHASE_1_STORAGE_CLASS_SPECIFIERS}.set_static */
void F27_231 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_0_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EWG_C_PHASE_1_STORAGE_CLASS_SPECIFIERS}.set_auto */
void F27_232 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_0_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EWG_C_PHASE_1_STORAGE_CLASS_SPECIFIERS}.set_register */
void F27_233 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_0_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EWG_C_PHASE_1_STORAGE_CLASS_SPECIFIERS}.set_inline */
void F27_234 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_0_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EWG_C_PHASE_1_STORAGE_CLASS_SPECIFIERS}.merge */
void F27_236 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_0_0_);
	if (tb1) {
		F27_229(Current);
	}
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_0_1_);
	if (tb1) {
		F27_230(Current);
	}
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_0_2_);
	if (tb1) {
		F27_231(Current);
	}
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_0_3_);
	if (tb1) {
		F27_232(Current);
	}
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_0_4_);
	if (tb1) {
		F27_233(Current);
	}
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_0_5_);
	if (tb1) {
		F27_234(Current);
	}
	RTLE;
}

/* {EWG_C_PHASE_1_STORAGE_CLASS_SPECIFIERS}.out */
EIF_REFERENCE F27_243 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = RTMS_EX_H("",0,0);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_0_0_)) {
		tr1 = RTMS_EX_H("typedef ",8,556449568);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5149[Dtype(RTCW(Result))-985])(Result, tr1);
		Result = (EIF_REFERENCE) tr1;
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_0_1_)) {
		tr1 = RTMS_EX_H("extern ",7,1234267680);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5149[Dtype(RTCW(Result))-985])(Result, tr1);
		Result = (EIF_REFERENCE) tr1;
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_0_2_)) {
		tr1 = RTMS_EX_H("static ",7,2081314336);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5149[Dtype(RTCW(Result))-985])(Result, tr1);
		Result = (EIF_REFERENCE) tr1;
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_0_3_)) {
		tr1 = RTMS_EX_H("auto ",5,1971309856);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5149[Dtype(RTCW(Result))-985])(Result, tr1);
		Result = (EIF_REFERENCE) tr1;
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_0_4_)) {
		tr1 = RTMS_EX_H("register ",9,619553824);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5149[Dtype(RTCW(Result))-985])(Result, tr1);
		Result = (EIF_REFERENCE) tr1;
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_0_5_)) {
		tr1 = RTMS_EX_H("inline ",7,1147175968);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5149[Dtype(RTCW(Result))-985])(Result, tr1);
		Result = (EIF_REFERENCE) tr1;
	}
	RTLE;
	return Result;
}

void EIF_Minit20 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
