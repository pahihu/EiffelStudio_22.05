/*
 * Code for class EWG_C_PHASE_1_DECLARATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew21.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EWG_C_PHASE_1_DECLARATION}.make */
void F28_244 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg3;
	F28_255(Current, arg1);
	RTLE;
}

/* {EWG_C_PHASE_1_DECLARATION}.make_with_one_declarator */
void F28_245 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1246,0xFF01,1075,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1247_8688(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6627[Dtype(RTCW(tr1))-1246])(tr1, arg2);
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg3;
	F28_255(Current, arg1);
	RTLE;
}

/* {EWG_C_PHASE_1_DECLARATION}.make_without_declarator */
void F28_246 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1246,0xFF01,1075,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1247_8688(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg2;
	F28_255(Current, arg1);
	RTLE;
}

/* {EWG_C_PHASE_1_DECLARATION}.merge_specifiers */
void F28_255 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,loc4);
	RTLR(4,loc1);
	RTLR(5,arg1);
	RTLR(6,loc5);
	RTLR(7,tr1);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLIU(10);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc4 = *(EIF_REFERENCE *)(Current);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6568[Dtype(RTCW(arg1))-1228])(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6395[Dtype(RTCW(loc1))-1130])(loc1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6382[Dtype(RTCW(loc1))-1130])(loc1);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3320[Dtype(RTCW(loc1))-401])(loc1);
		loc5 = RTCCL(tr1);
		loc5 = RTRV(eif_new_type(1074, 0x01),loc5);
		if (EIF_TEST(loc5)) {
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				loc2 = (EIF_REFERENCE) loc5;
			} else {
				F1075_7622(RTCW(loc2), loc5);
			}
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3320[Dtype(RTCW(loc1))-401])(loc1);
		loc6 = RTCCL(tr1);
		loc6 = RTRV(eif_new_type(26, 0x01),loc6);
		if (EIF_TEST(loc6)) {
			if ((EIF_BOOLEAN)(loc4 == NULL)) {
				loc4 = (EIF_REFERENCE) loc6;
			} else {
				F27_236(RTCW(loc4), loc6);
			}
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3320[Dtype(RTCW(loc1))-401])(loc1);
		loc7 = RTCCL(tr1);
		loc7 = RTRV(eif_new_type(1076, 0x01),loc7);
		if (EIF_TEST(loc7)) {
			if ((EIF_BOOLEAN)(loc3 == NULL)) {
				loc3 = (EIF_REFERENCE) loc7;
			} else {
				F1077_7651(RTCW(loc3), loc7);
			}
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R3322[Dtype(RTCW(loc1))-401])(loc1);
	}
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		loc2 = RTLNSMART(eif_new_type(1074, 0).id);
		tr1 = RTMS_EX_H("int",3,6909556);
		F1075_7618(RTCW(loc2), tr1);
	}
	if ((EIF_BOOLEAN)(loc3 == NULL)) {
		loc3 = RTLNSMART(eif_new_type(1076, 0).id);
	}
	if ((EIF_BOOLEAN)(loc4 == NULL)) {
		loc4 = RTLNSMART(eif_new_type(26, 0).id);
	}
	RTAR(Current, loc2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc2;
	RTAR(Current, loc3);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc3;
	RTAR(Current, loc4);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc4;
	RTLE;
}

void EIF_Minit21 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
