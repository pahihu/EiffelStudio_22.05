
#ifndef _C1_ew22_
#define _C1_ew22_

#ifdef __cplusplus
extern "C" {
#endif

extern void F35_266(EIF_REFERENCE, EIF_REFERENCE);
extern void F35_267(EIF_REFERENCE, EIF_REFERENCE);
extern void F35_268(EIF_REFERENCE);
extern void F35_271(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit22(void);
extern void F1247_8688(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
