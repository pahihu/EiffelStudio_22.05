
#ifndef _C1_rt40_
#define _C1_rt40_

#ifdef __cplusplus
extern "C" {
#endif

extern void F65_757(EIF_REFERENCE);
extern void F65_758(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F65_759(EIF_REFERENCE);
extern void EIF_Minit40(void);

#ifdef __cplusplus
}
#endif

#endif
