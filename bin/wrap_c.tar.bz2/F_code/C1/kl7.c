/*
 * Code for class KL_STANDARD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl7.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STANDARD_FILES}.input */
static EIF_REFERENCE F11_92_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (92);
#define Result RTOSR(92)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1009, 0x01).id, 1009, _OBJSIZ_2_2_0_0_0_0_0_0_);
	F1010_6965(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (92);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F11_92 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(92,F11_92_body,(Current));
}

/* {KL_STANDARD_FILES}.output */
static EIF_REFERENCE F11_93_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (93);
#define Result RTOSR(93)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1036, 0x01).id, 1036, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (93);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F11_93 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(93,F11_93_body,(Current));
}

/* {KL_STANDARD_FILES}.error */
static EIF_REFERENCE F11_94_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (94);
#define Result RTOSR(94)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1035, 0x01).id, 1035, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (94);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F11_94 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(94,F11_94_body,(Current));
}

void EIF_Minit7 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
