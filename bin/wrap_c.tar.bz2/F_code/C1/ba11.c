/*
 * Code for class BASE_PROCESS_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ba11.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BASE_PROCESS_FACTORY}.process_launcher_with_command_line */
EIF_REFERENCE F15_130 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(331, 0x01).id, 331, _OBJSIZ_13_16_0_5_0_0_0_0_);
	F332_3336(RTCW(tr1), arg1, arg2);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit11 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
