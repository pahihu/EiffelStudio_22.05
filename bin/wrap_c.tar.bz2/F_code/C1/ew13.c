/*
 * Code for class EWG_C_PHASE_1_MACRO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew13.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EWG_C_PHASE_1_MACRO}.out */
EIF_REFERENCE F17_143 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTMS_EX_H("macro: ",7,1138383392);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5149[Dtype(tr1)-985])(tr1, *(EIF_REFERENCE *)(Current));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = RTMS_EX_H("(",1,40);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5149[Dtype(RTCW(Result))-985])(Result, tr1);
		Result = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6568[Dtype(RTCW(tr1))-1228])(tr1);
		F1119_8288(RTCW(loc1));
		for (;;) {
			tb1 = F1167_8380(RTCW(loc1));
			if (tb1) break;
			tr1 = F1167_8376(RTCW(loc1));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5149[Dtype(RTCW(Result))-985])(Result, tr1);
			Result = (EIF_REFERENCE) tr1;
			tb2 = F1126_8296(RTCW(loc1));
			if ((EIF_BOOLEAN) !tb2) {
				tr1 = RTMS_EX_H(", ",2,11296);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5149[Dtype(RTCW(Result))-985])(Result, tr1);
				Result = (EIF_REFERENCE) tr1;
			}
			F1119_8289(RTCW(loc1));
		}
		tr1 = RTMS_EX_H(")",1,41);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5149[Dtype(RTCW(Result))-985])(Result, tr1);
		Result = (EIF_REFERENCE) tr1;
	}
	tr1 = RTMS_EX_H(" -> ",4,539835936);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5149[Dtype(RTCW(Result))-985])(Result, tr1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5149[Dtype(RTCW(tr1))-985])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

void EIF_Minit13 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
