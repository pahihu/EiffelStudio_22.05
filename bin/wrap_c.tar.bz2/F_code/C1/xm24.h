
#ifndef _C1_xm24_
#define _C1_xm24_

#ifdef __cplusplus
extern "C" {
#endif

extern void F37_275(EIF_REFERENCE);
extern EIF_REFERENCE F37_277(EIF_REFERENCE, EIF_REFERENCE);
extern void F37_278(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit24(void);
extern void F1119_8291(EIF_REFERENCE);
extern EIF_REFERENCE F1167_8376(EIF_REFERENCE);
extern void F152_1715(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1247_8688(EIF_REFERENCE);
extern void F1119_8289(EIF_REFERENCE);
extern void F1119_8288(EIF_REFERENCE);
extern char *(*R6627[])();
extern char *(*R6568[])();

#ifdef __cplusplus
}
#endif

#endif
