
#ifndef _C1_ew31_
#define _C1_ew31_

#ifdef __cplusplus
extern "C" {
#endif

extern void F44_476(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit31(void);

#ifdef __cplusplus
}
#endif

#endif
