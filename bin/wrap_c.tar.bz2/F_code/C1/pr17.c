/*
 * Code for class PROCESS_MISC
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "pr17.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {PROCESS_MISC}.output_of_command */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_REFERENCE F24_165 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_BOOLEAN  EIF_VOLATILE tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	RTXD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,loc6);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,loc1);
	RTLR(5,arg2);
	RTLR(6,loc4);
	RTLR(7,loc2);
	RTLR(8,arg1);
	RTLR(9,loc8);
	RTLR(10,loc7);
	RTLR(11,Result);
	RTLR(12,saved_except);
	RTLIU(13);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc3) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		tr1 = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F985_6612(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		loc6 = (EIF_REFERENCE) tr1;
		tr1 = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F985_6612(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		loc5 = (EIF_REFERENCE) tr1;
		loc1 = RTLNS(eif_new_type(14, 0x01).id, 14, _OBJSIZ_0_0_0_0_0_0_0_0_);
		if ((EIF_BOOLEAN)(arg2 != NULL)) {
			loc4 = F867_5016(RTCW(arg2));
		}
		loc2 = F15_130(RTCW(loc1), arg1, loc4);
		F73_958(RTCW(loc2), (EIF_BOOLEAN) 1);
		F73_959(RTCW(loc2), (EIF_BOOLEAN) 0);
		F73_929(RTCW(loc2));
		F73_932(RTCW(loc2));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,753,924,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 1024L),sizeof(EIF_NATURAL_8), EIF_TRUE);
		}
		F754_4491(RTCW(tr1), (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1024L));
		loc8 = (EIF_REFERENCE) tr1;
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,753,924,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 1024L),sizeof(EIF_NATURAL_8), EIF_TRUE);
		}
		F754_4491(RTCW(tr1), (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1024L));
		loc7 = (EIF_REFERENCE) tr1;
		F73_938(RTCW(loc2));
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_13_6_);
		if (tb1) {
			for (;;) {
				tb1 = '\01';
				tb2 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_13_2_);
				if (!tb2) {
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_13_1_);
					tb1 = tb2;
				}
				if (tb1) break;
				F332_3344(RTCW(loc2), loc8);
				F24_166(Current, loc8, loc6);
			}
			for (;;) {
				tb2 = '\01';
				tb3 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_13_4_);
				if (!tb3) {
					tb3 = *(EIF_BOOLEAN *)(RTCW(loc2)+ _CHROFF_13_3_);
					tb2 = tb3;
				}
				if (tb2) break;
				F332_3345(RTCW(loc2), loc7);
				F24_166(Current, loc7, loc5);
			}
			F332_3339(RTCW(loc2));
			tr1 = RTLNS(eif_new_type(15, 0x01).id, 15, _OBJSIZ_2_0_0_1_0_0_0_0_);
			ti4_1 = F332_3346(RTCW(loc2));
			F16_132(RTCW(tr1), ti4_1, loc6, loc5);
			Result = (EIF_REFERENCE) tr1;
		} else {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
	} else {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTE_E
	RTXSC;
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {PROCESS_MISC}.append_special_of_natural_8_to_string_8 */
void F24_166 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 tu1_2;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	loc1 = ((EIF_INTEGER_32) 0L);
	loc2 = F754_4502(RTCW(arg1));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		/* INLINED CODE (SPECIAL.item) */
		tu1_2 = *((EIF_NATURAL_8 *)RTCW(arg1) + (loc1));
		/* END INLINED CODE */
		tu1_1 = tu1_2;
		tu4_1 = (EIF_NATURAL_32) tu1_1;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R5020[Dtype(RTCW(arg2))-983])(arg2, tu4_1);
		loc1++;
	}
	RTLE;
}

void EIF_Minit17 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
