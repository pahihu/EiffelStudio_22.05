/*
 * Code for class STD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st37.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STD_FILES}.input */
static EIF_REFERENCE F62_671_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (671);
#define Result RTOSR(671)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1078, 0x01).id, 1078, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stdin",5,1953620846);
	F1079_7663(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (671);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F62_671 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(671,F62_671_body,(Current));
}

/* {STD_FILES}.output */
static EIF_REFERENCE F62_672_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (672);
#define Result RTOSR(672)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1078, 0x01).id, 1078, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stdout",6,1912016244);
	F1079_7664(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (672);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F62_672 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(672,F62_672_body,(Current));
}

/* {STD_FILES}.error */
static EIF_REFERENCE F62_673_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (673);
#define Result RTOSR(673)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1078, 0x01).id, 1078, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stderr",6,1911360114);
	F1079_7665(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (673);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F62_673 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(673,F62_673_body,(Current));
}

/* {STD_FILES}.standard_default */
EIF_REFERENCE F62_675 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN)(Result == NULL)) {
		Result = RTOSCF(672,F62_672, (Current));
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {STD_FILES}.set_output_default */
void F62_699 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(672,F62_672, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {STD_FILES}.put_string */
void F62_702 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = F62_675(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3141[Dtype(RTCW(tr1))-732])(tr1, arg1);
	RTLE;
}

/* {STD_FILES}.put_string_32 */
void F62_704 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = F62_675(Current);
	F734_4443(RTCW(tr1), arg1);
	RTLE;
}

void EIF_Minit37 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
