
#ifndef _C1_ba11_
#define _C1_ba11_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F15_130(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit11(void);
extern void F332_3336(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
