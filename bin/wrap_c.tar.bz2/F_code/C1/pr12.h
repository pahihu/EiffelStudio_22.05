
#ifndef _C1_pr12_
#define _C1_pr12_

#ifdef __cplusplus
extern "C" {
#endif

extern void F16_132(EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit12(void);

#ifdef __cplusplus
}
#endif

#endif
