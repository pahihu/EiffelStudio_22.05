
#ifndef _C1_is36_
#define _C1_is36_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F49_562(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F49_567(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F49_569(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F49_577(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit36(void);

#ifdef __cplusplus
}
#endif

#endif
