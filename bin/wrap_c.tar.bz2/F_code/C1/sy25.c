/*
 * Code for class SYSTEM_ENCODINGS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sy25.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SYSTEM_ENCODINGS}.console_encoding */
static EIF_REFERENCE F38_281_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (281);
#define Result RTOSR(281)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(39, 0x01).id, 39, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = F159_1741(RTCV(RTOSCF(286,F38_286, (Current))));
	F40_295(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (281);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F38_281 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(281,F38_281_body,(Current));
}

/* {SYSTEM_ENCODINGS}.utf8 */
static EIF_REFERENCE F38_282_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (282);
#define Result RTOSR(282)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(39, 0x01).id, 39, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(288,F39_288, (Current));
	F40_295(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (282);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F38_282 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(282,F38_282_body,(Current));
}

/* {SYSTEM_ENCODINGS}.utf32 */
static EIF_REFERENCE F38_284_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (284);
#define Result RTOSR(284)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(39, 0x01).id, 39, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(290,F39_290, (Current));
	F40_295(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (284);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F38_284 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(284,F38_284_body,(Current));
}

/* {SYSTEM_ENCODINGS}.system_encodings_i */
static EIF_REFERENCE F38_286_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (286);
#define Result RTOSR(286)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(158, 0x01).id, 158, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (286);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F38_286 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(286,F38_286_body,(Current));
}

void EIF_Minit25 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
