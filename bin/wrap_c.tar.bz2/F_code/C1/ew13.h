
#ifndef _C1_ew13_
#define _C1_ew13_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F17_143(EIF_REFERENCE);
extern void EIF_Minit13(void);
extern EIF_BOOLEAN F1126_8296(EIF_REFERENCE);
extern EIF_REFERENCE F1167_8376(EIF_REFERENCE);
extern EIF_BOOLEAN F1167_8380(EIF_REFERENCE);
extern void F1119_8289(EIF_REFERENCE);
extern void F1119_8288(EIF_REFERENCE);
extern char *(*R5149[])();
extern char *(*R6568[])();

#ifdef __cplusplus
}
#endif

#endif
