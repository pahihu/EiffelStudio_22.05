
#ifndef _C1_ew14_
#define _C1_ew14_

#ifdef __cplusplus
extern "C" {
#endif

extern void F18_144(EIF_REFERENCE);
extern void F18_145(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F18_147(EIF_REFERENCE);
extern void EIF_Minit14(void);

#ifdef __cplusplus
}
#endif

#endif
