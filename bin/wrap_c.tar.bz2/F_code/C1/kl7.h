
#ifndef _C1_kl7_
#define _C1_kl7_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,92)
static EIF_REFERENCE F11_92_body(EIF_REFERENCE);
extern EIF_REFERENCE F11_92(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,93)
static EIF_REFERENCE F11_93_body(EIF_REFERENCE);
extern EIF_REFERENCE F11_93(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,94)
static EIF_REFERENCE F11_94_body(EIF_REFERENCE);
extern EIF_REFERENCE F11_94(EIF_REFERENCE);
extern void EIF_Minit7(void);
extern void F1010_6965(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
