/*
 * Code for class WRAPC_MACRO_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wr30.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WRAPC_MACRO_PARSER}.make */
void F43_450 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	tr1 = RTLNSMART(eif_new_type(986, 1).id);
	F979_6315(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(986, 1).id);
	F979_6315(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,859,0xFF01,813,0xFF01,0xFFF9,3,898,0xFF01,986,0xFF01,986,0xFF01,986,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F860_4948(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {WRAPC_MACRO_PARSER}.parse_macro */
void F43_453 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F43_454(Current);
	tb1 = '\0';
	if ((EIF_BOOLEAN) !F43_474(Current)) {
		tb1 = F43_469(Current);
	}
	if (tb1) {
		F43_470(Current);
		for (;;) {
			tb1 = '\01';
			if (!F43_474(Current)) {
				tb1 = F43_468(Current);
			}
			if (tb1) break;
			F43_456(Current);
			if (F43_469(Current)) {
				F43_470(Current);
			}
		}
	}
	F43_455(Current);
	RTLE;
}

/* {WRAPC_MACRO_PARSER}.initialize */
void F43_454 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(733, 0x01).id, 733, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F734_4421(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	tb1 = '\0';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3128[Dtype(RTCW(loc1))-732])(loc1);
	if (tb2) {
		tb2 = F732_4177(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R3626[Dtype(RTCW(loc1))-732])(loc1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) loc1;
	} else {
		tr1 = RTLNSMART(eif_new_type(986, 0).id);
		tr2 = RTMS_EX_H("File is not readable or does not exist at path: ",48,484263200);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr3 = F867_5014(RTCW(tr3));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5149[Dtype(tr2)-985])(tr2, tr3);
		F985_6614(RTCW(tr1), tr2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {WRAPC_MACRO_PARSER}.finalize */
void F43_455 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F732_4226(loc1);
	}
	RTLE;
}

/* {WRAPC_MACRO_PARSER}.parse_line */
void F43_456 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F673_4113(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		F43_457(Current);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_));
		if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '#')) {
			F43_466(Current);
			if (F43_460(Current)) {
				if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
					F43_466(Current);
					F43_466(Current);
					F43_466(Current);
					F43_466(Current);
				}
				F43_457(Current);
				F43_459(Current);
				F43_457(Current);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_));
				if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\"')) {
					tr1 = RTLNSMART(eif_new_type(986, 1).id);
					F979_6315(RTCW(tr1));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
					F43_458(Current);
					tb1 = '\0';
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tb2 = F673_4113(RTCW(tr1));
					if ((EIF_BOOLEAN) !tb2) {
						tr1 = *(EIF_REFERENCE *)(Current);
						tb2 = F855_4844(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) {
						loc1 = RTLNS(eif_new_type(25, 0x01).id, 25, _OBJSIZ_14_2_0_1_0_0_0_0_);
						tr1 = RTLNS(eif_new_type(866, 0x01).id, 866, _OBJSIZ_2_1_0_0_0_0_0_0_);
						F867_4977(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
						F26_175(RTCW(loc1), tr1);
						F26_178(RTCW(loc1));
						tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
						tb1 = F670_4113(RTCW(tr1));
						if ((EIF_BOOLEAN) !tb1) {
							tr1 = *(EIF_REFERENCE *)(Current);
							tr2 = *(EIF_REFERENCE *)(RTCW(loc1));
							F855_4882(RTCW(tr1), tr2, *(EIF_REFERENCE *)(Current + _REFACS_2_));
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {WRAPC_MACRO_PARSER}.skip_white_spaces */
void F43_457 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	for (;;) {
		tb1 = '\01';
		tb2 = '\0';
		tb3 = '\0';
		tb4 = '\0';
		tb5 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_));
		if ((EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) ' ')) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_));
			tb5 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '\012');
		}
		if (tb5) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_));
			tb4 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '\015');
		}
		if (tb4) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_));
			tb3 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '\000');
		}
		if (tb3) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_));
			tb2 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '\011');
		}
		if (!tb2) {
			tb1 = (EIF_BOOLEAN) !F43_467(Current);
		}
		if (tb1) break;
		F43_466(Current);
	}
	RTLE;
}

/* {WRAPC_MACRO_PARSER}.parse_file_path */
void F43_458 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	F43_466(Current);
	for (;;) {
		tb1 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_));
		if (!(EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\"')) {
			tb1 = (EIF_BOOLEAN) !F43_467(Current);
		}
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr2))-986])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(tr1))-986])(tr1, tc1);
		F43_466(Current);
	}
	RTLE;
}

/* {WRAPC_MACRO_PARSER}.skip_values */
void F43_459 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	for (;;) {
		tb1 = '\01';
		tb2 = '\01';
		tb3 = '\01';
		tb4 = '\01';
		tb5 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_));
		if (!(EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) ' ')) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_));
			tb5 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\012');
		}
		if (!tb5) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_));
			tb4 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\015');
		}
		if (!tb4) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_));
			tb3 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\000');
		}
		if (!tb3) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_));
			tb2 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\011');
		}
		if (!tb2) {
			tb1 = (EIF_BOOLEAN) !F43_467(Current);
		}
		if (tb1) break;
		F43_466(Current);
	}
	RTLE;
}

/* {WRAPC_MACRO_PARSER}.is_line */
EIF_BOOLEAN F43_460 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = RTOSCF(475,F43_475, (Current));
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_);
		Result = F979_6361(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 4L), ti4_1);
	} else {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return Result;
}

/* {WRAPC_MACRO_PARSER}.next */
void F43_466 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_) < ti4_1)) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_))++;
	}
	RTLE;
}

/* {WRAPC_MACRO_PARSER}.has_next */
EIF_BOOLEAN F43_467 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 < ti4_2);
	RTLE;
	return Result;
}

/* {WRAPC_MACRO_PARSER}.end_of_file */
EIF_BOOLEAN F43_468 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN) !F43_474(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc1 = tr1;
		tb1 = EIF_TEST(loc1);
	}
	if (tb1) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3601[Dtype(loc1)-732])(loc1);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}/* NOTREACHED */
	
}

/* {WRAPC_MACRO_PARSER}.has_next_line */
EIF_BOOLEAN F43_469 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F43_468(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {WRAPC_MACRO_PARSER}.next_line */
void F43_470 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R3187[Dtype(loc1)-732])(loc1);
		tr1 = *(EIF_REFERENCE *)(loc1 + O3112[Dtype(loc1)-337]);
		tr1 = F1_14(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		tr1 = RTMS_EX_H("",0,0);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {WRAPC_MACRO_PARSER}.has_error */
EIF_BOOLEAN F43_474 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) != NULL);
}

/* {WRAPC_MACRO_PARSER}.line_id */

EIF_REFERENCE F43_475 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (475,RTMS_EX_H("line",4,1818848869));
}

void EIF_Minit30 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
