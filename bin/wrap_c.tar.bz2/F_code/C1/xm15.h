
#ifndef _C1_xm15_
#define _C1_xm15_

#ifdef __cplusplus
extern "C" {
#endif

extern void F22_149(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 150)


extern EIF_REFERENCE F22_150(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 151)


extern EIF_REFERENCE F22_151(EIF_REFERENCE);
extern void F22_156(EIF_REFERENCE, EIF_REFERENCE);
extern void F22_157(EIF_REFERENCE, EIF_REFERENCE);
extern void F22_158(EIF_REFERENCE, EIF_BOOLEAN);
extern void F22_159(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit15(void);
extern char *(*R2182[])();

#ifdef __cplusplus
}
#endif

#endif
