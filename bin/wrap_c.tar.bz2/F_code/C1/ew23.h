
#ifndef _C1_ew23_
#define _C1_ew23_

#ifdef __cplusplus
extern "C" {
#endif

extern void F36_272(EIF_REFERENCE);
extern void F36_273(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit23(void);
extern EIF_REFERENCE F1167_8376(EIF_REFERENCE);
extern void F1077_7651(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1167_8380(EIF_REFERENCE);
extern void F1119_8289(EIF_REFERENCE);
extern void F1119_8288(EIF_REFERENCE);
extern char *(*R6568[])();

#ifdef __cplusplus
}
#endif

#endif
