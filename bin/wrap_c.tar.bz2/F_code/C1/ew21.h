
#ifndef _C1_ew21_
#define _C1_ew21_

#ifdef __cplusplus
extern "C" {
#endif

extern void F28_244(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F28_245(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F28_246(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F28_255(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit21(void);
extern void F27_236(EIF_REFERENCE, EIF_REFERENCE);
extern void F1075_7618(EIF_REFERENCE, EIF_REFERENCE);
extern void F1077_7651(EIF_REFERENCE, EIF_REFERENCE);
extern void F1247_8688(EIF_REFERENCE);
extern void F1075_7622(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R6382[])();
extern char *(*R3320[])();
extern char *(*R3322[])();
extern char *(*R6395[])();
extern char *(*R6627[])();
extern char *(*R6568[])();

#ifdef __cplusplus
}
#endif

#endif
