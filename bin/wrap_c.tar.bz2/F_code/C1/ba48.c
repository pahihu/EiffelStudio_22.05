/*
 * Code for class BASE_PROCESS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ba48.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {BASE_PROCESS}.cancel_input_redirection */
void F73_928 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = RTLNSMART(eif_new_type(982, 0).id);
	F979_6315(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {BASE_PROCESS}.redirect_output_to_stream */
void F73_929 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {BASE_PROCESS}.cancel_output_redirection */
void F73_931 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = RTLNSMART(eif_new_type(982, 0).id);
	F979_6315(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {BASE_PROCESS}.redirect_error_to_stream */
void F73_932 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {BASE_PROCESS}.cancel_error_redirection */
void F73_935 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_13_16_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = RTLNSMART(eif_new_type(982, 0).id);
	F979_6315(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {BASE_PROCESS}.launch */
void F73_938 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F73_972(Current);
	F332_3341(Current);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_13_6_)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_13_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		*(EIF_BOOLEAN *)(Current+ _CHROFF_13_9_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		*(EIF_BOOLEAN *)(Current+ _CHROFF_13_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		*(EIF_BOOLEAN *)(Current+ _CHROFF_13_7_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		{
			/* INLINED CODE (BASE_PROCESS.initialize_after_launch) */
			/* END INLINED CODE */
		}
		;
		F73_976(Current);
	} else {
		F73_975(Current);
	}
	RTLE;
}

/* {BASE_PROCESS}.check_exit */
void F73_954 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_13_7_)) {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_13_5_)) {
			F332_3347(Current);
		}
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_13_5_)) {
			F332_3348(Current);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_13_7_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_13_9_)) {
				F73_973(Current);
			} else {
				F73_974(Current);
			}
		}
	}
	RTLE;
}

/* {BASE_PROCESS}.set_hidden */
void F73_958 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_11_) = (EIF_BOOLEAN) arg1;
}

/* {BASE_PROCESS}.set_separate_console */
void F73_959 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_12_) = (EIF_BOOLEAN) arg1;
}

/* {BASE_PROCESS}.on_start */
void F73_972 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,0,898,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4890[Dtype(loc1)-974])(loc1, tr1);
	}
	RTLE;
}

/* {BASE_PROCESS}.on_terminate */
void F73_973 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,0,898,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4890[Dtype(loc1)-974])(loc1, tr1);
	}
	RTLE;
}

/* {BASE_PROCESS}.on_exit */
void F73_974 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,0,898,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4890[Dtype(loc1)-974])(loc1, tr1);
	}
	RTLE;
}

/* {BASE_PROCESS}.on_launch_failed */
void F73_975 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,0,898,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4890[Dtype(loc1)-974])(loc1, tr1);
	}
	RTLE;
}

/* {BASE_PROCESS}.on_launch_successed */
void F73_976 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,0,898,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 1, 1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4890[Dtype(loc1)-974])(loc1, tr1);
	}
	RTLE;
}

/* {BASE_PROCESS}.platform */
static EIF_REFERENCE F73_979_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (979);
#define Result RTOSR(979)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(192, 0x01).id, 192, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (979);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F73_979 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(979,F73_979_body,(Current));
}

/* {BASE_PROCESS}.initialize_working_directory */
void F73_1010 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = RTLNSMART(eif_new_type(982, 0).id);
		F983_6498(RTCW(tr1), arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	} else {
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {BASE_PROCESS}.initialize_parameter */
void F73_1011 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F73_928(Current);
	F73_931(Current);
	F73_935(Current);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_12_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_9_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_13_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {BASE_PROCESS}.is_separator */
EIF_BOOLEAN F73_1013 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTGC;
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ' ';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(arg1 == tw1);
	return Result;
}

/* {BASE_PROCESS}.separated_words */
EIF_REFERENCE F73_1014 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc9 = (EIF_CHARACTER_32) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,arg1);
	RTLR(3,loc5);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,842,0xFF01,983,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 842, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F843_4769(RTCW(Result), ((EIF_INTEGER_32) 1L));
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4938[Dtype(RTCW(arg1))-982])(arg1);
	if ((EIF_BOOLEAN) !tb1) {
		loc5 = RTLNS(eif_new_type(983, 0x01).id, 983, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F982_6445(RTCW(loc5), ((EIF_INTEGER_32) 128L));
		loc8 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4960[Dtype(RTCW(arg1))-982])(arg1);
		loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc9 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4924[Dtype(RTCW(arg1))-982])(arg1, loc7);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc7 > loc8)) {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\000';
				tb1 = (EIF_BOOLEAN)(loc9 == tw1);
			}
			if (tb1) break;
			loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			if (loc1) {
				if (loc4) {
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\\';
					if ((EIF_BOOLEAN)(loc9 == tw1)) {
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					} else {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\'';
						if ((EIF_BOOLEAN)(loc9 == tw1)) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
							F984_6547(RTCW(loc5), loc9, ti4_1);
							loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
					}
				}
				tb2 = '\0';
				if (loc10) {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\'';
					tb2 = (EIF_BOOLEAN)(loc9 == tw1);
				}
				if (tb2) {
					loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				}
			} else {
				if (loc2) {
					if (loc4) {
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
						F984_6547(RTCW(loc5), loc9, ti4_1);
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					}
					tb2 = '\0';
					if (loc10) {
						tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\"';
						tb2 = (EIF_BOOLEAN)(loc9 == tw1);
					}
					if (tb2) {
						loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					}
				}
			}
			if (loc10) {
				switch (loc9) {
					case (EIF_CHARACTER_8) '\\':
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						F984_6573(RTCW(loc5), loc9);
						loc6++;
						loc9 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4924[Dtype(RTCW(arg1))-982])(arg1, loc6);
						break;
					case (EIF_CHARACTER_8) '\'':
						loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						break;
					case (EIF_CHARACTER_8) '\"':
						if ((EIF_BOOLEAN) !loc1) {
							loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							tb2 = (EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b;
							if (tb2) {
								if ((EIF_BOOLEAN) !loc2) {
									F984_6573(RTCW(loc5), loc9);
									loc6++;
								} else {
									loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								}
							} else {
								F984_6573(RTCW(loc5), loc9);
								loc6++;
							}
						}
						break;
					default:
						if ((EIF_BOOLEAN) (loc1 || loc2)) {
							F984_6573(RTCW(loc5), loc9);
							loc6++;
						} else {
							if (F73_1013(Current, loc9)) {
								if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc6 > ((EIF_INTEGER_32) 1L)) || loc3)) {
									tr1 = F1_14(loc5);
									F843_4810(RTCW(Result), tr1);
									F984_6589(RTCW(loc5));
									loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
									loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								}
							} else {
								F984_6573(RTCW(loc5), loc9);
								loc6++;
							}
						}
						break;
				}
			}
			if (loc10) {
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			loc7++;
			if ((EIF_BOOLEAN) (loc7 <= loc8)) {
				loc9 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4924[Dtype(RTCW(arg1))-982])(arg1, loc7);
			}
		}
		if ((EIF_BOOLEAN) (loc6 > ((EIF_INTEGER_32) 1L))) {
			F843_4810(RTCW(Result), loc5);
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit48 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
