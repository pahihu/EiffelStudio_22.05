/*
 * Code for class WRAPC_MACRO_HEADER_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "wr19.h"
#include <ctype.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WRAPC_MACRO_HEADER_PARSER}.make */
void F26_175 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
	tr1 = RTLNSMART(eif_new_type(986, 1).id);
	F979_6315(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(986, 1).id);
	F979_6315(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(986, 1).id);
	F979_6315(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(986, 1).id);
	F979_6315(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,842,0xFF01,0xFFF9,3,898,0xFF01,986,0xFF01,986,0xFF01,986,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 842, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F843_4769(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	F26_210(Current);
	F26_211(Current);
	F26_212(Current);
	F26_213(Current);
	F26_214(Current);
	F26_215(Current);
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.parse_macro */
void F26_178 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F26_179(Current);
	tb1 = '\0';
	if ((EIF_BOOLEAN) !F26_202(Current)) {
		tb1 = F26_197(Current);
	}
	if (tb1) {
		F26_198(Current);
		for (;;) {
			tb1 = '\01';
			if (!F26_202(Current)) {
				tb1 = F26_196(Current);
			}
			if (tb1) break;
			F26_181(Current);
			if (F26_197(Current)) {
				F26_198(Current);
			}
		}
	}
	F26_180(Current);
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.initialize */
void F26_179 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(733, 0x01).id, 733, _OBJSIZ_5_7_2_4_1_1_2_1_);
	F734_4421(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
	tb1 = '\0';
	tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3128[Dtype(RTCW(loc1))-732])(loc1);
	if (tb2) {
		tb2 = F732_4177(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R3626[Dtype(RTCW(loc1))-732])(loc1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc1;
	} else {
		tr1 = RTLNSMART(eif_new_type(986, 0).id);
		tr2 = RTMS_EX_H("File is not readable or does not exist at path: ",48,484263200);
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tr3 = F867_5014(RTCW(tr3));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5149[Dtype(tr2)-985])(tr2, tr3);
		F985_6614(RTCW(tr1), tr2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.finalize */
void F26_180 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F732_4226(loc1);
	}
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.parse_line */
void F26_181 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F673_4113(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		F26_182(Current);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
		if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '#')) {
			F26_194(Current);
			if (F26_183(Current)) {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_14_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				F26_194(Current);
				F26_194(Current);
				F26_194(Current);
				F26_194(Current);
				F26_194(Current);
				F26_194(Current);
				F26_182(Current);
				tr1 = RTLNSMART(eif_new_type(986, 1).id);
				F979_6315(RTCW(tr1));
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
				F26_184(Current);
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_14_1_)) {
					F26_182(Current);
					*(EIF_BOOLEAN *)(Current+ _CHROFF_14_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					F26_185(Current);
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_14_0_)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						F981_6438(RTCW(tr1));
						tr1 = *(EIF_REFERENCE *)(Current);
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,3,898,0xFF01,986,0xFF01,986,0xFF01,986,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
							tr2 = RTLNTS(typres0.id, 4, 0);
						}
						tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
						RTAR(tr2,tr3);
						tr3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
						tr3 = F1_14(tr3);
						((EIF_TYPED_VALUE *)tr2+2)->it_r = tr3;
						RTAR(tr2,tr3);
						tr3 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
						tr3 = F1_14(tr3);
						((EIF_TYPED_VALUE *)tr2+3)->it_r = tr3;
						RTAR(tr2,tr3);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R3573[Dtype(RTCW(tr1))-732])(tr1, tr2);
					}
				}
			}
		}
	}
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.skip_white_spaces */
void F26_182 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	for (;;) {
		tb1 = '\01';
		tb2 = '\0';
		tb3 = '\0';
		tb4 = '\0';
		tb5 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
		if ((EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) ' ')) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
			tb5 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '\012');
		}
		if (tb5) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
			tb4 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '\015');
		}
		if (tb4) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
			tb3 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '\000');
		}
		if (tb3) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
			tb2 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '\011');
		}
		if (!tb2) {
			tb1 = (EIF_BOOLEAN) !F26_195(Current);
		}
		if (tb1) break;
		F26_194(Current);
	}
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.is_define */
EIF_BOOLEAN F26_183 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = RTOSCF(203,F26_203, (Current));
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_);
	Result = F979_6361(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 6L), ti4_1);
	RTLE;
	return Result;
}

/* {WRAPC_MACRO_HEADER_PARSER}.parse_constant_name */
void F26_184 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F979_6315(RTCW(loc1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(loc1))-986])(loc1, tc1);
	F26_194(Current);
	for (;;) {
		tb1 = '\01';
		tb2 = '\01';
		tb3 = '\01';
		tb4 = '\01';
		tb5 = '\01';
		tb6 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
		if (!(EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) ' ')) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
			tb6 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\012');
		}
		if (!tb6) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
			tb5 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\015');
		}
		if (!tb5) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
			tb4 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\000');
		}
		if (!tb4) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
			tb3 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\011');
		}
		if (!tb3) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
			tb2 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '(');
		}
		if (!tb2) {
			tb1 = (EIF_BOOLEAN) !F26_195(Current);
		}
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(loc1))-986])(loc1, tc1);
		F26_194(Current);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
	if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '(')) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_14_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5183[Dtype(RTCW(tr1))-986])(tr1, loc1);
	} else {
		tb2 = '\01';
		tb3 = '\01';
		tb4 = '\01';
		tb5 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
		if (!(EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) ' ')) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
			tb5 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '\012');
		}
		if (!tb5) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
			tb4 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '\015');
		}
		if (!tb4) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
			tb3 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '\000');
		}
		if (!tb3) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
			tb2 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '\011');
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(loc1))-986])(loc1, tc1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5185[Dtype(RTCW(tr1))-986])(tr1, loc1);
	}
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.parse_value */
void F26_185 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5048[Dtype(RTCW(tr1))-983])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5048[Dtype(RTCW(tr1))-983])(tr1);
	tb1 = '\01';
	tb2 = '\01';
	tb3 = '\01';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
	if (!(EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '(')) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
		tb4 = EIF_TEST(isdigit(tc1));
		tb3 = tb4;
	}
	if (!tb3) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
		tb2 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\"');
	}
	if (!tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
		tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\'');
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
		if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\"')) {
			tr1 = RTMS_EX_H("STRING",6,1544365639);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
		if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\'')) {
			tr1 = RTMS_EX_H("CHARACTER_32",12,329034290);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
		}
		F26_186(Current);
		F26_208(Current);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tb1 = F673_4113(RTCW(tr1));
		if (tb1) {
			if (F26_204(Current, *(EIF_REFERENCE *)(Current + _REFACS_4_))) {
				tr1 = RTMS_EX_H("INTEGER_64",10,674744372);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
			} else {
				if (F26_205(Current, *(EIF_REFERENCE *)(Current + _REFACS_4_))) {
					tr1 = RTMS_EX_H("REAL_64",7,1887301940);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
				} else {
					if (F26_206(Current, *(EIF_REFERENCE *)(Current + _REFACS_4_))) {
						tr1 = RTMS_EX_H("INTEGER",7,1551244370);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
					} else {
						if (F26_207(Current, *(EIF_REFERENCE *)(Current + _REFACS_4_))) {
							tr1 = RTMS_EX_H("INTEGER_64",10,674744372);
							RTAR(Current, tr1);
							*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
							(FUNCTION_CAST(void, (EIF_REFERENCE)) R5048[Dtype(RTCW(tr1))-983])(tr1);
						} else {
							if (F26_209(Current, *(EIF_REFERENCE *)(Current + _REFACS_4_))) {
								tr1 = RTMS_EX_H("REAL_64",7,1887301940);
								RTAR(Current, tr1);
								*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
								(FUNCTION_CAST(void, (EIF_REFERENCE)) R5048[Dtype(RTCW(tr1))-983])(tr1);
							} else {
								tr1 = RTMS_EX_H("UNKOWN",6,1431206734);
								RTAR(Current, tr1);
								*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
							}
						}
					}
				}
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr2 = RTMS_EX_H("CHARACTER_32",12,329034290);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(tr1))-0])(tr1, tr2);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				tr2 = RTMS_EX_H("\'",1,39);
				tr3 = RTMS_EX_H("",0,0);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5172[Dtype(RTCW(tr1))-986])(tr1, tr2, tr3);
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr2 = RTMS_EX_H("STRING",6,1544365639);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(tr1))-0])(tr1, tr2);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				tr2 = RTMS_EX_H("\"",1,34);
				tr3 = RTMS_EX_H("",0,0);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5172[Dtype(RTCW(tr1))-986])(tr1, tr2, tr3);
			}
		}
	} else {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_14_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.skip_value */
void F26_186 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	if (F26_195(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr2))-986])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(tr1))-986])(tr1, tc1);
		F26_194(Current);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
		if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\\')) {
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		for (;;) {
			if ((EIF_BOOLEAN) !F26_195(Current)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr2))-986])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(tr1))-986])(tr1, tc1);
			F26_194(Current);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
		if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\\')) {
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		tb1 = '\0';
		if (loc1) {
			tb1 = F26_197(Current);
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr2 = RTMS_EX_H("\012",1,10);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5185[Dtype(RTCW(tr1))-986])(tr1, tr2);
			F26_198(Current);
			F26_186(Current);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr2))-986])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(tr1))-986])(tr1, tc1);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr1))-986])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
		tb1 = EIF_TEST(isdigit(tc1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (FUNCTION_CAST(EIF_CHARACTER_8, (EIF_REFERENCE, EIF_INTEGER_32)) R5134[Dtype(RTCW(tr2))-986])(tr2, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(tr1))-986])(tr1, tc1);
		}
	}
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.next */
void F26_194 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_) < ti4_1)) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_))++;
	}
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.has_next */
EIF_BOOLEAN F26_195 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 < ti4_2);
	RTLE;
	return Result;
}

/* {WRAPC_MACRO_HEADER_PARSER}.end_of_file */
EIF_BOOLEAN F26_196 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN) !F26_202(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc1 = tr1;
		tb1 = EIF_TEST(loc1);
	}
	if (tb1) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3601[Dtype(loc1)-732])(loc1);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}/* NOTREACHED */
	
}

/* {WRAPC_MACRO_HEADER_PARSER}.has_next_line */
EIF_BOOLEAN F26_197 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F26_196(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {WRAPC_MACRO_HEADER_PARSER}.next_line */
void F26_198 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R3187[Dtype(loc1)-732])(loc1);
		tr1 = *(EIF_REFERENCE *)(loc1 + O3112[Dtype(loc1)-337]);
		tr1 = F1_14(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		tr1 = RTMS_EX_H("",0,0);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_14_2_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.has_error */
EIF_BOOLEAN F26_202 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) != NULL);
}

/* {WRAPC_MACRO_HEADER_PARSER}.define_id */

EIF_REFERENCE F26_203 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (203,RTMS_EX_H("define",6,1915569253));
}

/* {WRAPC_MACRO_HEADER_PARSER}.is_valid_integer */
EIF_BOOLEAN F26_204 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F985_6614(RTCW(loc1), arg1);
	F987_6751(RTCW(loc1), (EIF_CHARACTER_8) ' ');
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	Result = F1325_9796(RTCW(tr1), loc1);
	RTLE;
	return Result;
}

/* {WRAPC_MACRO_HEADER_PARSER}.is_valid_double */
EIF_BOOLEAN F26_205 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F985_6614(RTCW(loc1), arg1);
	F987_6751(RTCW(loc1), (EIF_CHARACTER_8) ' ');
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	Result = F1325_9796(RTCW(tr1), loc1);
	RTLE;
	return Result;
}

/* {WRAPC_MACRO_HEADER_PARSER}.is_valid_hexa */
EIF_BOOLEAN F26_206 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F985_6614(RTCW(loc1), arg1);
	F987_6751(RTCW(loc1), (EIF_CHARACTER_8) ' ');
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	Result = F1325_9796(RTCW(tr1), loc1);
	RTLE;
	return Result;
}

/* {WRAPC_MACRO_HEADER_PARSER}.is_valid_integer_expression */
EIF_BOOLEAN F26_207 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F985_6614(RTCW(loc1), arg1);
	F987_6751(RTCW(loc1), (EIF_CHARACTER_8) ' ');
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	Result = F1325_9796(RTCW(tr1), loc1);
	RTLE;
	return Result;
}

/* {WRAPC_MACRO_HEADER_PARSER}.clean_comments */
void F26_208 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F985_6614(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
	F1421_11734(RTCW(tr1), loc1, ((EIF_INTEGER_32) 1L), ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_12_16_0_3_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		ti4_1 = F1421_11733(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		ti4_2 = F1421_11732(RTCW(tr2), ((EIF_INTEGER_32) 1L));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5047[Dtype(RTCW(tr1))-986])(tr1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - ti4_2) + ((EIF_INTEGER_32) 1L)));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F981_6438(RTCW(tr1));
	}
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.is_valid_double_expression */
EIF_BOOLEAN F26_209 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F985_6614(RTCW(loc1), arg1);
	F987_6751(RTCW(loc1), (EIF_CHARACTER_8) ' ');
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	Result = F1325_9796(RTCW(tr1), loc1);
	RTLE;
	return Result;
}

/* {WRAPC_MACRO_HEADER_PARSER}.compile_integer_regex */
void F26_210 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1421, 1).id);
	F1421_11728(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOSCF(222,F26_222, (Current));
	F1421_11731(RTCW(tr1), tr2);
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.compile_double_regex */
void F26_211 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1421, 1).id);
	F1421_11728(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tr2 = RTOSCF(223,F26_223, (Current));
	F1421_11731(RTCW(tr1), tr2);
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.compile_hexa_regex */
void F26_212 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1421, 1).id);
	F1421_11728(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tr2 = RTOSCF(224,F26_224, (Current));
	F1421_11731(RTCW(tr1), tr2);
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.compile_integer_expression */
void F26_213 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1421, 1).id);
	F1421_11728(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr2 = RTOSCF(225,F26_225, (Current));
	F1421_11731(RTCW(tr1), tr2);
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.compile_double_expression */
void F26_214 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1421, 1).id);
	F1421_11728(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	tr2 = RTOSCF(226,F26_226, (Current));
	F1421_11731(RTCW(tr1), tr2);
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.compile_comments_expression */
void F26_215 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1421, 1).id);
	F1421_11728(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	tr2 = RTOSCF(227,F26_227, (Current));
	F1421_11731(RTCW(tr1), tr2);
	RTLE;
}

/* {WRAPC_MACRO_HEADER_PARSER}.integer_pattern */

EIF_REFERENCE F26_222 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (222,RTMS_EX_H("\\d+",3,6054955));
}

/* {WRAPC_MACRO_HEADER_PARSER}.double_pattern */

EIF_REFERENCE F26_223 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (223,RTMS_EX_H("\\d*\\.\\d+",8,1821898027));
}

/* {WRAPC_MACRO_HEADER_PARSER}.hexadecimal_pattern */

EIF_REFERENCE F26_224 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (224,RTMS_EX_H("0([xX]{1})\?[A-Fa-f0-9]+",23,1175984683));
}

/* {WRAPC_MACRO_HEADER_PARSER}.integer_expressions_pattern */

EIF_REFERENCE F26_225 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (225,RTMS_EX_H("[-+(]*[\\d]+[)]*[>]*[<]*([-+*/][-+(]*[\\d]+[)]*)*",47,149278762));
}

/* {WRAPC_MACRO_HEADER_PARSER}.double_expressions_pattern */

EIF_REFERENCE F26_226 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (226,RTMS_EX_H("[-+(]*[\\d|\\d*\\.\\d*]+[)]*[>]*[<]*([-+*/][-+(]*[\\d]+[)]*)*",56,1851675690));
}

/* {WRAPC_MACRO_HEADER_PARSER}.comments_expressions_pattern */

EIF_REFERENCE F26_227 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (227,RTMS_EX_H("(\\/\\*.*\?\\*\\/)|(\\/\\/.*)",22,307317033));
}

void EIF_Minit19 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
