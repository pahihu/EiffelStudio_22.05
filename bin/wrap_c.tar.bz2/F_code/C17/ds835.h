
#ifndef _C17_ds835_
#define _C17_ds835_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1146_8329(EIF_REFERENCE);
extern void EIF_Minit835(void);

#ifdef __cplusplus
}
#endif

#endif
