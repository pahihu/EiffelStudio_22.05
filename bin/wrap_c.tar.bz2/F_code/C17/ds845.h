
#ifndef _C17_ds845_
#define _C17_ds845_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1229_8575(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1229_8578(EIF_REFERENCE);
extern EIF_INTEGER_32 F1229_8579(EIF_REFERENCE);
extern EIF_BOOLEAN F1229_8589(EIF_REFERENCE, EIF_REFERENCE);
extern void F1229_8590(EIF_REFERENCE, EIF_REFERENCE);
extern void F1229_8592(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1229_8593(EIF_REFERENCE);
extern EIF_REFERENCE F1229_8594(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1229_8595(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1229_8596(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1229_8597(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1229_8598(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1229_8599(EIF_REFERENCE, EIF_REFERENCE);
extern void F1229_8600(EIF_REFERENCE, EIF_REFERENCE);
extern void F1229_8601(EIF_REFERENCE, EIF_REFERENCE);
extern void F1229_8602(EIF_REFERENCE, EIF_REFERENCE);
extern void F1229_8605(EIF_REFERENCE, EIF_REFERENCE);
extern void F1229_8606(EIF_REFERENCE, EIF_REFERENCE);
extern void F1229_8609(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit845(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R11[])();
extern char *(*R6573[])();
extern char *(*R18[])();
extern char *(*R6383[])();
extern char *(*R3322[])();
extern char *(*R6618[])();
extern char *(*R6619[])();
extern char *(*R6855[])();
extern char *(*R6409[])();
extern char *(*R6394[])();
extern char *(*R6395[])();
extern char *(*R6397[])();
extern char *(*R6398[])();
extern char *(*R6400[])();
extern char *(*R6401[])();
extern char *(*R6403[])();
extern char *(*R6404[])();
extern char *(*R6405[])();
extern char *(*R6568[])();
extern EIF_TYPE_INDEX Y6545[];
extern EIF_TYPE_INDEX *Y6545_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
