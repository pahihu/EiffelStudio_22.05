
#ifndef _C17_xm843_
#define _C17_xm843_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1249_8773(EIF_REFERENCE, EIF_REFERENCE);
extern void F1249_8774(EIF_REFERENCE, EIF_REFERENCE);
extern void F1249_8782(EIF_REFERENCE, EIF_REFERENCE);
extern void F1249_8786(EIF_REFERENCE, EIF_REFERENCE);
extern void F1249_8787(EIF_REFERENCE, EIF_REFERENCE);
extern void F1249_8791(EIF_REFERENCE, EIF_REFERENCE);
extern void F1249_8792(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit843(void);
extern void F1247_8714(EIF_REFERENCE, EIF_REFERENCE);
extern void F1247_8726(EIF_REFERENCE, EIF_REFERENCE);
extern void F1247_8712(EIF_REFERENCE, EIF_REFERENCE);
extern void F1247_8715(EIF_REFERENCE, EIF_REFERENCE);
extern void F1247_8713(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R3320[])();
extern char *(*R3321[])();
extern char *(*R3322[])();
extern char *(*R6395[])();
extern char *(*R6568[])();

#ifdef __cplusplus
}
#endif

#endif
