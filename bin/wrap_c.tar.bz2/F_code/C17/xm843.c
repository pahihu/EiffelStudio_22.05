/*
 * Code for class XM_LINKED_LIST [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm843.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_LINKED_LIST}.before_addition */
void F1249_8773 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {XM_LINKED_LIST}.before_addition_list */
void F1249_8774 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6568[Dtype(RTCW(arg1))-1228])(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6395[Dtype(RTCW(loc1))-1130])(loc1);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3321[Dtype(RTCW(loc1))-401])(loc1);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3320[Dtype(RTCW(loc1))-401])(loc1);
		tr2 = RTCCL(tr1);
		{
			/* INLINED CODE (XM_LINKED_LIST.before_addition) */
			/* END INLINED CODE */
		}
		;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R3322[Dtype(RTCW(loc1))-401])(loc1);
	}
	RTLE;
}

/* {XM_LINKED_LIST}.extend_last */
void F1249_8782 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1249_8774(Current, arg1);
	F1247_8726(Current, arg1);
	RTLE;
}

/* {XM_LINKED_LIST}.force_first */
void F1249_8786 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	{
		/* INLINED CODE (XM_LINKED_LIST.before_addition) */
		/* END INLINED CODE */
	}
	;
	tr1 = RTCCL(arg1);
	F1247_8713(Current, tr1);
	RTLE;
}

/* {XM_LINKED_LIST}.force_last */
void F1249_8787 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	{
		/* INLINED CODE (XM_LINKED_LIST.before_addition) */
		/* END INLINED CODE */
	}
	;
	tr1 = RTCCL(arg1);
	F1247_8715(Current, tr1);
	RTLE;
}

/* {XM_LINKED_LIST}.put_first */
void F1249_8791 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	{
		/* INLINED CODE (XM_LINKED_LIST.before_addition) */
		/* END INLINED CODE */
	}
	;
	tr1 = RTCCL(arg1);
	F1247_8712(Current, tr1);
	RTLE;
}

/* {XM_LINKED_LIST}.put_last */
void F1249_8792 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	{
		/* INLINED CODE (XM_LINKED_LIST.before_addition) */
		/* END INLINED CODE */
	}
	;
	tr1 = RTCCL(arg1);
	F1247_8714(Current, tr1);
	RTLE;
}

void EIF_Minit843 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
