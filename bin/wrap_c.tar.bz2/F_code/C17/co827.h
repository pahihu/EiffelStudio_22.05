
#ifndef _C17_co827_
#define _C17_co827_

#ifdef __cplusplus
extern "C" {
#endif

extern void F530_4015(EIF_REFERENCE);
extern void EIF_Minit827(void);
extern long O3500[];

#ifdef __cplusplus
}
#endif

#endif
