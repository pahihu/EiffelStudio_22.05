/*
 * Code for class TYPE [UTF_CONVERTER]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ty802.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {TYPE}.name_32 */
EIF_REFERENCE F884_5037 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		Result = RTLNS(eif_new_type(982, 0x01).id, 982, _OBJSIZ_1_0_0_4_0_0_0_0_);
		tr1 = F884_5066(Current);
		F983_6498(RTCW(Result), tr1);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {TYPE}.name */
EIF_REFERENCE F884_5038 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		loc1 = F884_5066(Current);
		Result = RTLNS(eif_new_type(985, 0x01).id, 985, _OBJSIZ_1_0_0_4_0_0_0_0_);
		loc2 = loc1;
		if ((EIF_TRUE)) {
			tr1 = loc2;
		} else {
			tr2 = RTLNS(eif_new_type(47, 0x00).id, 47, _OBJSIZ_0_0_0_0_0_0_0_0_);
			tr1 = F48_500(RTCW(tr2), loc1);
		}
		F985_6614(RTCW(Result), tr1);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {TYPE}.generic_parameter_type */
EIF_REFERENCE F884_5039 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("generic_parameter_type", 883, Current, 0, 1, 10336);
	Result = (EIF_REFERENCE) eif_builtin_TYPE_generic_parameter_type__i4_t (Current, arg1);
	if (!Result) {RTEC(EN_FAIL);}
	RTLE;
	RTEE;
	return Result;
}

/* {TYPE}.type_id */
EIF_INTEGER_32 F884_5040 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (Current);
	return Result;
}

/* {TYPE}.hash_code */
EIF_INTEGER_32 F884_5041 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (Current);
}

/* {TYPE}.has_default */
EIF_BOOLEAN F884_5043 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = (EIF_BOOLEAN) eif_builtin_TYPE_has_default__b (Current);
	return Result;
}

/* {TYPE}.is_attached */
EIF_BOOLEAN F884_5046 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = (EIF_BOOLEAN) eif_builtin_TYPE_is_attached__b (Current);
	return Result;
}

/* {TYPE}.is_equal */
EIF_BOOLEAN F884_5047 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (Current);
	ti4_2 = (EIF_INTEGER_32) eif_builtin_TYPE_type_id__i4 (arg1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTLE;
	return Result;
}

/* {TYPE}.default */
EIF_REFERENCE F884_5054 (EIF_REFERENCE Current)
{
	GTCX
	struct eif_ex_33 sloc1;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) sloc1.data;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	memset (&sloc1.overhead, 0, OVERHEAD + _OBJSIZ_0_0_0_0_0_0_0_0_);
	sloc1.overhead.ov_flags = EO_EXP | EO_STACK;
	RT_DFS(&sloc1.overhead, eif_gen_param(Dftype(Current), 1).id);
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result= RTLN(eif_gen_param(Dftype(Current), 1).id);
	RTLE;
	return Result;
}

/* {TYPE}.out */
EIF_REFERENCE F884_5055 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = F884_5037(Current);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(984, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F985_6614(RTCW(tr1), loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = F884_5038(Current);
		loc2 = tr1;
		if ((EIF_TRUE)) {
			tr1 = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F985_6614(RTCW(tr1), loc2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			RTCT0("known_string_type", EX_CHECK);
				RTCF0;
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {TYPE}.runtime_name */
EIF_REFERENCE F884_5066 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEAA("runtime_name", 883, Current, 0, 0, 10333);
	Result = (EIF_REFERENCE) eif_builtin_TYPE_runtime_name__s1 (Current);
	if (!Result) {RTEC(EN_FAIL);}
	RTLE;
	RTEE;
	return Result;
}

void EIF_Minit802 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
