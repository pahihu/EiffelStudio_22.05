
#ifndef _C17_ha818_
#define _C17_ha818_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F472_3956(EIF_REFERENCE);
extern EIF_REFERENCE F472_3957(EIF_REFERENCE);
extern EIF_BOOLEAN F472_3959(EIF_REFERENCE);
extern void F472_3960(EIF_REFERENCE);
extern EIF_REFERENCE F472_3961(EIF_REFERENCE);
extern void EIF_Minit818(void);
extern char *(*R3966[])();
extern char *(*R3967[])();
extern char *(*R3772[])();
extern char *(*R3464[])();
extern char *(*R3270[])();
extern long O3975[];
extern long O3976[];

#ifdef __cplusplus
}
#endif

#endif
