
#ifndef _C17_re821_
#define _C17_re821_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F699_4126(EIF_REFERENCE);
extern void F699_4128(EIF_REFERENCE);
extern void EIF_Minit821(void);
extern char *(*R3565[])();
extern char *(*R3571[])();

#ifdef __cplusplus
}
#endif

#endif
