/*
 * Code for class DS_HASH_SET [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds832.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_HASH_SET}.new_cursor */
EIF_REFERENCE F1276_9178 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1147,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y6545,Y6545_gen_type,Dftype(Current),1192);
			typarr0[2] = l_type.annotations | 0xFF00;
			typarr0[3] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 1147, _OBJSIZ_2_0_0_1_0_0_0_0_);
	}
	F1141_8314(RTCW(tr1), Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {DS_HASH_SET}.hash_position */
EIF_INTEGER_32 F1276_9181 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = RTCCL(arg1);
			Result = (RTNA((loc1, tr1)), ((EIF_INTEGER_32) 0));
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_1_);
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ti4_1);
		} else {
			Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4044[Dtype(RTCW(arg1))-866])(arg1);
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_1_);
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ti4_1);
		}
	} else {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_1_);
		RTLE;
		return (EIF_INTEGER_32) Result;
	}
	RTLE;
	return Result;
}

void EIF_Minit832 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
