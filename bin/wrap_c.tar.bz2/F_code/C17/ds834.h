
#ifndef _C17_ds834_
#define _C17_ds834_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1147_8331(EIF_REFERENCE);
extern void EIF_Minit834(void);

#ifdef __cplusplus
}
#endif

#endif
