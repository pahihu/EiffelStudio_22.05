
#ifndef _C17_ds839_
#define _C17_ds839_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1269_9027(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1269_9028(EIF_REFERENCE);
extern EIF_INTEGER_32 F1269_9032(EIF_REFERENCE);
extern EIF_INTEGER_32 F1269_9033(EIF_REFERENCE);
extern EIF_BOOLEAN F1269_9036(EIF_REFERENCE);
extern void F1269_9046(EIF_REFERENCE);
extern void F1269_9047(EIF_REFERENCE, EIF_REFERENCE);
extern void F1269_9048(EIF_REFERENCE, EIF_REFERENCE);
extern void F1269_9050(EIF_REFERENCE);
extern void F1269_9051(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1269_9052(EIF_REFERENCE);
extern void F1269_9060(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1269_9061(EIF_REFERENCE, EIF_REFERENCE);
extern void F1269_9065(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1269_9097(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1269_9098(EIF_REFERENCE);
extern void F1269_9099(EIF_REFERENCE);
extern void F1269_9100(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1269_9102(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1269_9103(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1269_9104(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1269_9105(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1269_9106(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1269_9107(EIF_REFERENCE, EIF_REFERENCE);
extern void F1269_9108(EIF_REFERENCE, EIF_REFERENCE);
extern void F1269_9109(EIF_REFERENCE, EIF_REFERENCE);
extern void F1269_9110(EIF_REFERENCE, EIF_REFERENCE);
extern void F1269_9113(EIF_REFERENCE, EIF_REFERENCE);
extern void F1269_9114(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1269_9116(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1269_9117(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit839(void);
extern char *(*R6571[])();
extern char *(*R6800[])();
extern char *(*R6573[])();
extern char *(*R6802[])();
extern char *(*R6803[])();
extern char *(*R6804[])();
extern char *(*R6805[])();
extern char *(*R6806[])();
extern char *(*R6807[])();
extern char *(*R6808[])();
extern char *(*R6809[])();
extern char *(*R6771[])();
extern char *(*R6537[])();
extern char *(*R6415[])();
extern char *(*R6387[])();
extern char *(*R6776[])();
extern char *(*R6777[])();
extern char *(*R6801[])();
extern char *(*R6779[])();
extern char *(*R4107[])();
extern char *(*R6778[])();
extern char *(*R6576[])();
extern char *(*R6819[])();
extern char *(*R2621[])();
extern char *(*R6782[])();
extern char *(*R6784[])();
extern char *(*R6785[])();
extern char *(*R6786[])();
extern char *(*R6787[])();
extern char *(*R6788[])();
extern char *(*R6789[])();
extern char *(*R6820[])();
extern char *(*R6822[])();
extern char *(*R6823[])();
extern char *(*R6790[])();
extern char *(*R6791[])();
extern char *(*R6792[])();
extern char *(*R6793[])();
extern char *(*R6794[])();
extern char *(*R6795[])();
extern char *(*R6796[])();
extern char *(*R6797[])();
extern char *(*R6798[])();
extern char *(*R6799[])();
extern char *(*R6579[])();
extern char *(*R6413[])();
extern char *(*R4115[])();
extern char *(*R6414[])();
extern char *(*R6568[])();
extern char *(*R6580[])();
extern long O6825[];
extern long O6826[];
extern long O6775[];
extern long O6810[];
extern long O6811[];
extern long O6812[];
extern long O6813[];
extern long O6814[];
extern long O6815[];
extern EIF_TYPE_INDEX Y6827[];
extern EIF_TYPE_INDEX *Y6827_gen_type [];
extern EIF_TYPE_INDEX Y6545[];
extern EIF_TYPE_INDEX *Y6545_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
