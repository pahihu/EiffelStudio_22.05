
#ifndef _C17_re809_
#define _C17_re809_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F739_4485(EIF_REFERENCE);
extern void EIF_Minit809(void);
extern void F462_3928(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R3467[])();
extern EIF_TYPE_INDEX Y3399[];
extern EIF_TYPE_INDEX *Y3399_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
