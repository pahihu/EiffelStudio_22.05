
#ifndef _C17_ds846_
#define _C17_ds846_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1149_8335(EIF_REFERENCE);
extern EIF_REFERENCE F1149_8336(EIF_REFERENCE);
extern void F1149_8337(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit846(void);
extern char *(*R6777[])();
extern char *(*R6625[])();

#ifdef __cplusplus
}
#endif

#endif
