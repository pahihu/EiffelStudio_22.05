
#ifndef _C17_fi828_
#define _C17_fi828_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F673_4113(EIF_REFERENCE);
extern void EIF_Minit828(void);
extern char *(*R3562[])();

#ifdef __cplusplus
}
#endif

#endif
