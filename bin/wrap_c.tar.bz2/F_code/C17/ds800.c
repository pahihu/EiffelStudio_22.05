/*
 * Code for class DS_ARRAYED_SPARSE_TABLE_CURSOR [BOOLEAN, G#2]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds800.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_ARRAYED_SPARSE_TABLE_CURSOR}.container */
EIF_REFERENCE F1155_8339 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


void EIF_Minit800 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
