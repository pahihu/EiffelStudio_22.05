
#ifndef _C17_ha815_
#define _C17_ha815_

#ifdef __cplusplus
extern "C" {
#endif

extern void F855_4835(EIF_REFERENCE, EIF_INTEGER_32);
extern void F855_4836(EIF_REFERENCE, EIF_INTEGER_32);
extern void F855_4838(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F855_4839(EIF_REFERENCE);
extern EIF_REFERENCE F855_4841(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F855_4843(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F855_4844(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F855_4847(EIF_REFERENCE);
extern EIF_REFERENCE F855_4848(EIF_REFERENCE);
extern EIF_REFERENCE F855_4850(EIF_REFERENCE);
extern EIF_REFERENCE F855_4851(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F855_4852(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F855_4853(EIF_REFERENCE);
extern EIF_INTEGER_32 F855_4856(EIF_REFERENCE);
extern EIF_INTEGER_32 F855_4857(EIF_REFERENCE);
extern EIF_BOOLEAN F855_4858(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F855_4859(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F855_4867(EIF_REFERENCE);
extern EIF_BOOLEAN F855_4868(EIF_REFERENCE);
extern EIF_BOOLEAN F855_4869(EIF_REFERENCE);
extern EIF_BOOLEAN F855_4873(EIF_REFERENCE, EIF_INTEGER_32);
extern void F855_4874(EIF_REFERENCE);
extern void F855_4875(EIF_REFERENCE);
extern void F855_4877(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F855_4879(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F855_4880(EIF_REFERENCE, EIF_INTEGER_32);
extern void F855_4881(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F855_4882(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F855_4889(EIF_REFERENCE);
extern void F855_4892(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F855_4893(EIF_REFERENCE, EIF_INTEGER_32);
extern void F855_4894(EIF_REFERENCE);
extern EIF_INTEGER_32 F855_4903(EIF_REFERENCE);
extern EIF_BOOLEAN F855_4904(EIF_REFERENCE);
extern EIF_REFERENCE F855_4911(EIF_REFERENCE);
extern EIF_REFERENCE F855_4912(EIF_REFERENCE);
extern EIF_INTEGER_32 F855_4913(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F855_4914(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F855_4915(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F855_4916(EIF_REFERENCE, EIF_INTEGER_32);
extern void F855_4917(EIF_REFERENCE, EIF_REFERENCE);
extern void F855_4919(EIF_REFERENCE, EIF_REFERENCE);
extern void F855_4920(EIF_REFERENCE, EIF_REFERENCE);
extern void F855_4921(EIF_REFERENCE, EIF_REFERENCE);
extern void F855_4925(EIF_REFERENCE, EIF_REFERENCE);
extern void F855_4931(EIF_REFERENCE);
extern void F855_4944(EIF_REFERENCE);
extern void EIF_Minit815(void);
extern EIF_INTEGER_32 F669_4103(EIF_REFERENCE, EIF_INTEGER_32);
extern void F748_4512(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F749_4502(EIF_REFERENCE);
extern void F749_4512(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F749_4491(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F749_4509(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F748_4491(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F841_4736(EIF_REFERENCE);
extern void F841_4735(EIF_REFERENCE);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,4736)
extern char *(*R3935[])();
extern char *(*R3938[])();
extern char *(*R3470[])();
extern char *(*R3398[])();
extern char *(*R3789[])();
extern char *(*R4010[])();
extern char *(*R3982[])();
extern char *(*R3983[])();
extern char *(*R3808[])();
extern char *(*R3947[])();
extern char *(*R3320[])();
extern char *(*R3949[])();
extern char *(*R3322[])();
extern char *(*R3271[])();
extern char *(*R3992[])();
extern char *(*R3993[])();
extern char *(*R4000[])();
extern char *(*R3995[])();
extern char *(*R3996[])();
extern char *(*R3998[])();
extern char *(*R3999[])();
extern char *(*R4004[])();
extern char *(*R3333[])();
extern char *(*R4023[])();
extern char *(*R3321[])();
extern char *(*R3964[])();
extern char *(*R3966[])();
extern char *(*R3967[])();
extern char *(*R3538[])();
extern char *(*R3772[])();
extern char *(*R3955[])();
extern char *(*R3956[])();
extern char *(*R3939[])();
extern char *(*R3994[])();
extern char *(*R3467[])();
extern char *(*R3270[])();
extern char *(*R4044[])();
extern char *(*R3973[])();
extern char *(*R3502[])();
extern long O3500[];
extern long O3975[];
extern long O3976[];
extern long O3977[];
extern long O3978[];
extern long O3979[];
extern long O3939[];
extern long O3980[];
extern long O3981[];
extern long O3984[];
extern long O3985[];
extern long O3989[];
extern long O3948[];
extern long O3990[];
extern long O3991[];
extern long O4025[];
extern EIF_TYPE_INDEX Y3540[];
extern EIF_TYPE_INDEX *Y3540_gen_type [];
extern EIF_TYPE_INDEX Y3975[];
extern EIF_TYPE_INDEX *Y3975_gen_type [];
extern EIF_TYPE_INDEX Y3976[];
extern EIF_TYPE_INDEX *Y3976_gen_type [];
extern EIF_TYPE_INDEX Y3399[];
extern EIF_TYPE_INDEX *Y3399_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
