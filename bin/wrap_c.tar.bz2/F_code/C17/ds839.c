/*
 * Code for class DS_SPARSE_CONTAINER [G#1, G#2]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds839.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_CONTAINER}.make */
void F1269_9027 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O6825[dtype-1268]) = (EIF_INTEGER_32) arg1;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6788[dtype-1275])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6793[dtype-1275])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6799[dtype-1275])(Current, arg1);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6823[dtype-1275])(Current, arg1);
	*(EIF_INTEGER_32 *)(Current + O6810[dtype-1268]) = (EIF_INTEGER_32) ti4_1;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6804[dtype-1275])(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O6810[dtype-1268]) + ((EIF_INTEGER_32) 1L)));
	*(EIF_INTEGER_32 *)(Current + O6775[dtype-1268]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current + O6811[dtype-1268]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6771[dtype-1275])(Current);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6568[dtype-1228])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6573[dtype-1228])(Current, tr1);
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.found_item */
EIF_REFERENCE F1269_9028 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	RTLE;
	return (EIF_REFERENCE) (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6776[dtype-1275])(Current, *(EIF_INTEGER_32 *)(Current + O6815[dtype-1268]));
}

/* {DS_SPARSE_CONTAINER}.count */
EIF_INTEGER_32 F1269_9032 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O6826[Dtype(Current)-1268]);
}


/* {DS_SPARSE_CONTAINER}.capacity */
EIF_INTEGER_32 F1269_9033 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O6825[Dtype(Current)-1268]);
}


/* {DS_SPARSE_CONTAINER}.found */
EIF_BOOLEAN F1269_9036 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O6815[Dtype(Current)-1268]) != ((EIF_INTEGER_32) -1L));
}

/* {DS_SPARSE_CONTAINER}.unset_found_item */
void F1269_9046 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O6815[Dtype(Current)-1268]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
}

/* {DS_SPARSE_CONTAINER}.copy */
void F1269_9047 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6819[dtype-1275])(Current);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6571[dtype-1228])(Current, loc1);
		}
		if (tb1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6573[dtype-1228])(Current, loc1);
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6568[dtype-1228])(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6573[dtype-1228])(Current, tr1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6771[dtype-1275])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6789[dtype-1275])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6795[dtype-1275])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6807[dtype-1275])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6801[dtype-1275])(Current);
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.remove */
void F1269_9048 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6771[dtype-1275])(Current);
	tr1 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6782[dtype-1275])(Current, tr1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]) != ((EIF_INTEGER_32) -1L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6787[dtype-1275])(Current, *(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]));
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.wipe_out */
void F1269_9050 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6819[dtype-1275])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6771[dtype-1275])(Current);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O6826[dtype-1268]) > ((EIF_INTEGER_32) 0L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6791[dtype-1275])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6797[dtype-1275])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6803[dtype-1275])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6809[dtype-1275])(Current);
		*(EIF_INTEGER_32 *)(Current + O6775[dtype-1268]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		*(EIF_INTEGER_32 *)(Current + O6811[dtype-1268]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		*(EIF_INTEGER_32 *)(Current + O6826[dtype-1268]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	*(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.resize */
void F1269_9051 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6771[dtype-1275])(Current);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6823[dtype-1275])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6808[dtype-1275])(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
	loc2 = *(EIF_INTEGER_32 *)(Current + O6810[dtype-1268]);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) break;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6806[dtype-1275])(Current, ((EIF_INTEGER_32) -1L), loc2);
		loc2--;
	}
	*(EIF_INTEGER_32 *)(Current + O6810[dtype-1268]) = (EIF_INTEGER_32) loc1;
	loc2 = *(EIF_INTEGER_32 *)(Current + O6775[dtype-1268]);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L))) break;
		if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6779[dtype-1275])(Current, loc2) > ((EIF_INTEGER_32) -2L))) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6778[dtype-1275])(Current, loc2);
			tr2 = RTCCL(tr1);
			loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6786[dtype-1275])(Current, tr2);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6805[dtype-1275])(Current, loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6800[dtype-1275])(Current, ti4_1, loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6806[dtype-1275])(Current, loc2, loc3);
		}
		loc2--;
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6790[dtype-1275])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6796[dtype-1275])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6802[dtype-1275])(Current, arg1);
	*(EIF_INTEGER_32 *)(Current + O6825[dtype-1268]) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.compress */
void F1269_9052 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O6775[dtype-1268]) != (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O6826[dtype-1268]) - ((EIF_INTEGER_32) 1L)))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6771[dtype-1275])(Current);
		loc3 = *(EIF_INTEGER_32 *)(Current + O6775[dtype-1268]);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6779[dtype-1275])(Current, loc1) > ((EIF_INTEGER_32) -2L))) {
				if ((EIF_BOOLEAN)(loc2 != loc1)) {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6776[dtype-1275])(Current, loc1);
					tr2 = RTCCL(tr1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6777[dtype-1275])(Current, tr2, loc2);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6778[dtype-1275])(Current, loc1);
					tr2 = RTCCL(tr1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6794[dtype-1275])(Current, tr2, loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6800[dtype-1275])(Current, ((EIF_INTEGER_32) -1L), loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6820[dtype-1275])(Current, loc1, loc2);
				}
				loc2++;
			}
			loc1++;
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6792[dtype-1275])(Current, *(EIF_INTEGER_32 *)(Current + O6826[dtype-1268]));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6798[dtype-1275])(Current, *(EIF_INTEGER_32 *)(Current + O6826[dtype-1268]));
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6803[dtype-1275])(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6809[dtype-1275])(Current);
		loc3 = *(EIF_INTEGER_32 *)(Current + O6826[dtype-1268]);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6778[dtype-1275])(Current, loc1);
			tr2 = RTCCL(tr1);
			loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6786[dtype-1275])(Current, tr2);
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6805[dtype-1275])(Current, loc4);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6800[dtype-1275])(Current, ti4_1, loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6806[dtype-1275])(Current, loc1, loc4);
			loc1++;
		}
		*(EIF_INTEGER_32 *)(Current + O6775[dtype-1268]) = (EIF_INTEGER_32) loc3;
		*(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.search_position */
void F1269_9060 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6805[dtype-1275])(Current, *(EIF_INTEGER_32 *)(Current + O6810[dtype-1268]));
		*(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]) = (EIF_INTEGER_32) ti4_1;
		*(EIF_INTEGER_32 *)(Current + O6813[dtype-1268]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O6810[dtype-1268]);
		*(EIF_INTEGER_32 *)(Current + O6814[dtype-1268]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	} else {
		loc3 = *(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6784[dtype-1275])(Current);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			loc4 = *(EIF_INTEGER_32 *)(Current + O6813[dtype-1268]);
			loc2 = *(EIF_INTEGER_32 *)(Current + O6814[dtype-1268]);
			tb1 = '\01';
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
				tb2 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6779[dtype-1275])(Current, loc3) <= ((EIF_INTEGER_32) -2L));
			}
			if (!tb2) {
				tr1 = RTCCL(arg1);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6778[dtype-1275])(Current, loc3);
				tr3 = RTCCL(tr2);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2621[Dtype(loc5)-301])(loc5, tr1, tr3);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				tr1 = RTCCL(arg1);
				loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6786[dtype-1275])(Current, tr1);
				loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6805[dtype-1275])(Current, loc4);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				for (;;) {
					if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
					tr1 = RTCCL(arg1);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6778[dtype-1275])(Current, loc1);
					tr3 = RTCCL(tr2);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2621[Dtype(loc5)-301])(loc5, tr1, tr3);
					if (tb1) {
						loc3 = (EIF_INTEGER_32) loc1;
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2 = (EIF_INTEGER_32) loc1;
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6779[dtype-1275])(Current, loc1);
						loc1 = (EIF_INTEGER_32) ti4_1;
					}
				}
			}
			*(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]) = (EIF_INTEGER_32) loc3;
			*(EIF_INTEGER_32 *)(Current + O6813[dtype-1268]) = (EIF_INTEGER_32) loc4;
			*(EIF_INTEGER_32 *)(Current + O6814[dtype-1268]) = (EIF_INTEGER_32) loc2;
		} else {
			tb1 = '\01';
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) -1L))) {
				tb2 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6779[dtype-1275])(Current, loc3) <= ((EIF_INTEGER_32) -2L));
			}
			if (!tb2) {
				tb1 = !RTCEQ(arg1, (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6778[dtype-1275])(Current, loc3));
			}
			if (tb1) {
				tr1 = RTCCL(arg1);
				loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6786[dtype-1275])(Current, tr1);
				loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6805[dtype-1275])(Current, loc4);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				for (;;) {
					if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
					if (RTCEQ(arg1, (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6778[dtype-1275])(Current, loc1))) {
						loc3 = (EIF_INTEGER_32) loc1;
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					} else {
						loc2 = (EIF_INTEGER_32) loc1;
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6779[dtype-1275])(Current, loc1);
						loc1 = (EIF_INTEGER_32) ti4_1;
					}
				}
				*(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]) = (EIF_INTEGER_32) loc3;
				*(EIF_INTEGER_32 *)(Current + O6813[dtype-1268]) = (EIF_INTEGER_32) loc4;
				*(EIF_INTEGER_32 *)(Current + O6814[dtype-1268]) = (EIF_INTEGER_32) loc2;
			}
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.position_of_key */
EIF_INTEGER_32 F1269_9061 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTLE;
		return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6805[dtype-1275])(Current, *(EIF_INTEGER_32 *)(Current + O6810[dtype-1268]));
	} else {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6784[dtype-1275])(Current);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			tr1 = RTCCL(arg1);
			loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6786[dtype-1275])(Current, tr1);
			loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6805[dtype-1275])(Current, loc3);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			for (;;) {
				if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
				tr1 = RTCCL(arg1);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6778[dtype-1275])(Current, loc1);
				tr3 = RTCCL(tr2);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2621[Dtype(loc4)-301])(loc4, tr1, tr3);
				if (tb1) {
					loc2 = (EIF_INTEGER_32) loc1;
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				} else {
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6779[dtype-1275])(Current, loc1);
					loc1 = (EIF_INTEGER_32) ti4_1;
				}
			}
		} else {
			tr1 = RTCCL(arg1);
			loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6786[dtype-1275])(Current, tr1);
			loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6805[dtype-1275])(Current, loc3);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			for (;;) {
				if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) break;
				if (RTCEQ(arg1, (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6778[dtype-1275])(Current, loc1))) {
					loc2 = (EIF_INTEGER_32) loc1;
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				} else {
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6779[dtype-1275])(Current, loc1);
					loc1 = (EIF_INTEGER_32) ti4_1;
				}
			}
		}
		RTLE;
		return (EIF_INTEGER_32) loc2;
	}/* NOTREACHED */
	
}

/* {DS_SPARSE_CONTAINER}.remove_position */
void F1269_9065 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != *(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]))) {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6778[dtype-1275])(Current, arg1);
		tr1 = RTCCL(loc1);
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R6786[dtype-1275])(Current, tr1);
		if ((EIF_BOOLEAN)((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6805[dtype-1275])(Current, loc2) == arg1)) {
			*(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]) = (EIF_INTEGER_32) arg1;
			*(EIF_INTEGER_32 *)(Current + O6813[dtype-1268]) = (EIF_INTEGER_32) loc2;
			*(EIF_INTEGER_32 *)(Current + O6814[dtype-1268]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		} else {
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6784[dtype-1275])(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6785[dtype-1275])(Current, NULL);
			tr1 = RTCCL(loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6782[dtype-1275])(Current, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6785[dtype-1275])(Current, loc3);
		}
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6822[dtype-1275])(Current, *(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]));
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O6814[dtype-1268]) == ((EIF_INTEGER_32) -1L))) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6779[dtype-1275])(Current, *(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]));
		ti4_2 = *(EIF_INTEGER_32 *)(Current + O6813[dtype-1268]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6806[dtype-1275])(Current, ti4_1, ti4_2);
	} else {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6779[dtype-1275])(Current, *(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]));
		ti4_2 = *(EIF_INTEGER_32 *)(Current + O6814[dtype-1268]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6800[dtype-1275])(Current, ti4_1, ti4_2);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O6811[dtype-1268]) == ((EIF_INTEGER_32) -1L)) && (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]) == *(EIF_INTEGER_32 *)(Current + O6775[dtype-1268])))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6792[dtype-1275])(Current, *(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6798[dtype-1275])(Current, *(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6800[dtype-1275])(Current, ((EIF_INTEGER_32) -1L), *(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]));
		*(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		(*(EIF_INTEGER_32 *)(Current + O6775[dtype-1268]))--;
	} else {
		tr1 = RTLNTY2(eif_final_id(Y6545,Y6545_gen_type,dftype,1192), 0x00);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4107[Dtype(tr1)-867])(tr1);
		if (tb1) {
			tr1 = RTLNTY2(eif_final_id(Y6545,Y6545_gen_type,dftype,1192), 0x00);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4115[Dtype(tr1)-867])(tr1);
			tr2 = RTCCL(tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6777[dtype-1275])(Current, tr2, ti4_1);
		}
		tr1 = RTLNTY2(eif_final_id(Y6827,Y6827_gen_type,dftype,1268), 0x00);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4107[Dtype(tr1)-867])(tr1);
		if (tb1) {
			tr1 = RTLNTY2(eif_final_id(Y6827,Y6827_gen_type,dftype,1268), 0x00);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4115[Dtype(tr1)-867])(tr1);
			tr2 = RTCCL(tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R6794[dtype-1275])(Current, tr2, ti4_1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R6800[dtype-1275])(Current, (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - *(EIF_INTEGER_32 *)(Current + O6811[dtype-1268])), *(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]));
		*(EIF_INTEGER_32 *)(Current + O6811[dtype-1268]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O6812[dtype-1268]);
	}
	(*(EIF_INTEGER_32 *)(Current + O6826[dtype-1268]))--;
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.set_internal_cursor */
void F1269_9097 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {DS_SPARSE_CONTAINER}.internal_cursor */
EIF_REFERENCE F1269_9098 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {DS_SPARSE_CONTAINER}.move_all_cursors_after */
void F1269_9099 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6414[Dtype(RTCW(loc1))-1140])(loc1);
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6387[Dtype(RTCW(loc1))-1130])(loc1, NULL);
		loc1 = (EIF_REFERENCE) loc2;
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.move_all_cursors */
void F1269_9100 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == arg1)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6413[Dtype(RTCW(loc1))-1140])(loc1, arg2);
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		loc1 = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.move_cursors_forth */
void F1269_9102 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == arg1)) {
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
				loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
				loc5 = *(EIF_INTEGER_32 *)(Current + O6775[dtype-1268]);
				for (;;) {
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (loc4 > loc5)) {
						tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6779[dtype-1275])(Current, loc4) > ((EIF_INTEGER_32) -2L));
					}
					if (tb1) break;
					loc4++;
				}
			}
			if ((EIF_BOOLEAN) (loc4 > loc5)) {
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R6414[Dtype(RTCW(loc1))-1140])(loc1);
				if ((EIF_BOOLEAN)(loc3 == NULL)) {
					loc3 = (EIF_REFERENCE) loc1;
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
					loc1 = (EIF_REFERENCE) tr1;
				} else {
					loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6387[Dtype(RTCW(loc3))-1130])(loc3, loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6387[Dtype(RTCW(loc1))-1130])(loc1, NULL);
					loc1 = (EIF_REFERENCE) loc2;
				}
			} else {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6413[Dtype(RTCW(loc1))-1140])(loc1, loc4);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
				loc1 = (EIF_REFERENCE) tr1;
			}
		} else {
			loc3 = (EIF_REFERENCE) loc1;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			loc1 = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_item */
EIF_REFERENCE F1269_9103 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6776[Dtype(Current)-1275])(Current, ti4_1);
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_is_first */
EIF_BOOLEAN F1269_9104 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6537[dtype-1228])(Current)) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6779[dtype-1275])(Current, loc1) > ((EIF_INTEGER_32) -2L))) break;
			loc1++;
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == loc1);
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_is_last */
EIF_BOOLEAN F1269_9105 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6537[dtype-1228])(Current)) {
		loc1 = *(EIF_INTEGER_32 *)(Current + O6775[dtype-1268]);
		for (;;) {
			if ((EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6779[dtype-1275])(Current, loc1) > ((EIF_INTEGER_32) -2L))) break;
			loc1--;
		}
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == loc1);
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_same_position */
EIF_BOOLEAN F1269_9106 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_0_0_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTLE;
	return Result;
}

/* {DS_SPARSE_CONTAINER}.cursor_start */
void F1269_9107 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6537[dtype-1228])(Current)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6414[Dtype(RTCW(arg1))-1140])(arg1);
	} else {
		loc3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6576[dtype-1228])(Current, arg1);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		loc2 = *(EIF_INTEGER_32 *)(Current + O6775[dtype-1268]);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 > loc2)) {
				tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6779[dtype-1275])(Current, loc1) > ((EIF_INTEGER_32) -2L));
			}
			if (tb1) break;
			loc1++;
		}
		if ((EIF_BOOLEAN) (loc1 > loc2)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R6414[Dtype(RTCW(arg1))-1140])(arg1);
			if ((EIF_BOOLEAN) !loc3) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6580[dtype-1228])(Current, arg1);
			}
		} else {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6413[Dtype(RTCW(arg1))-1140])(arg1, loc1);
			if (loc3) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6579[dtype-1228])(Current, arg1);
			}
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_finish */
void F1269_9108 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6537[dtype-1228])(Current)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6415[Dtype(RTCW(arg1))-1140])(arg1);
	} else {
		loc2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6576[dtype-1228])(Current, arg1);
		loc1 = *(EIF_INTEGER_32 *)(Current + O6775[dtype-1268]);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
				tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6779[dtype-1275])(Current, loc1) > ((EIF_INTEGER_32) -2L));
			}
			if (tb1) break;
			loc1--;
		}
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R6415[Dtype(RTCW(arg1))-1140])(arg1);
			if ((EIF_BOOLEAN) !loc2) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6580[dtype-1228])(Current, arg1);
			}
		} else {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6413[Dtype(RTCW(arg1))-1140])(arg1, loc1);
			if (loc2) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6579[dtype-1228])(Current, arg1);
			}
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_forth */
void F1269_9109 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_1 = ((EIF_INTEGER_32) -2L);
	if ((EIF_BOOLEAN)(loc4 == ti4_1)) {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
	}
	loc2 = *(EIF_INTEGER_32 *)(Current + O6775[dtype-1268]);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 > loc2)) {
			tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6779[dtype-1275])(Current, loc1) > ((EIF_INTEGER_32) -2L));
		}
		if (tb1) break;
		loc1++;
	}
	if ((EIF_BOOLEAN) (loc1 > loc2)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6414[Dtype(RTCW(arg1))-1140])(arg1);
		if ((EIF_BOOLEAN) !loc3) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6580[dtype-1228])(Current, arg1);
		}
	} else {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6413[Dtype(RTCW(arg1))-1140])(arg1, loc1);
		if (loc3) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6579[dtype-1228])(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_back */
void F1269_9110 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_1 = ((EIF_INTEGER_32) -3L);
	if ((EIF_BOOLEAN)(loc3 == ti4_1)) {
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc1 = *(EIF_INTEGER_32 *)(Current + O6775[dtype-1268]);
	} else {
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
	}
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
			tb1 = (EIF_BOOLEAN) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6779[dtype-1275])(Current, loc1) > ((EIF_INTEGER_32) -2L));
		}
		if (tb1) break;
		loc1--;
	}
	if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6415[Dtype(RTCW(arg1))-1140])(arg1);
		if ((EIF_BOOLEAN) !loc2) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6580[dtype-1228])(Current, arg1);
		}
	} else {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R6413[Dtype(RTCW(arg1))-1140])(arg1, loc1);
		if (loc2) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6579[dtype-1228])(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_go_after */
void F1269_9113 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6576[dtype-1228])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6414[Dtype(RTCW(arg1))-1140])(arg1);
	if ((EIF_BOOLEAN) !loc1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6580[dtype-1228])(Current, arg1);
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.cursor_go_before */
void F1269_9114 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R6576[dtype-1228])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6415[Dtype(RTCW(arg1))-1140])(arg1);
	if ((EIF_BOOLEAN) !loc1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6580[dtype-1228])(Current, arg1);
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER}.new_capacity */
EIF_INTEGER_32 F1269_9116 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * arg1);
}

/* {DS_SPARSE_CONTAINER}.new_modulus */
EIF_INTEGER_32 F1269_9117 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)) * ((EIF_INTEGER_32) 3L)) / ((EIF_INTEGER_32) 2L));
}

void EIF_Minit839 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
