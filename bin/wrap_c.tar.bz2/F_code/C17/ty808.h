
#ifndef _C17_ty808_
#define _C17_ty808_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F449_3922(EIF_REFERENCE);
extern void EIF_Minit808(void);
extern char *(*R3455[])();
extern char *(*R3772[])();
extern char *(*R3468[])();

#ifdef __cplusplus
}
#endif

#endif
