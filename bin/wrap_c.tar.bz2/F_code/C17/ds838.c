/*
 * Code for class DS_SPARSE_SET [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds838.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_SET}.make_equal */
void F1274_9118 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1269_9027(Current, arg1);
	tr1 = RTLNSMART(eif_final_id(Y6587,Y6587_gen_type,Dftype(Current),1211).id);
	F1_29(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_SPARSE_SET}.make_default */
void F1274_9119 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F1263_8910(Current);
	F1269_9027(Current, ti4_1);
	RTLE;
}

/* {DS_SPARSE_SET}.item */
EIF_REFERENCE F1274_9121 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	F1269_9060(Current, tr1);
	RTLE;
	return (EIF_REFERENCE) F1275_9153(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_));
}

/* {DS_SPARSE_SET}.has */
EIF_BOOLEAN F1274_9123 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	F1269_9060(Current, tr1);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_) != ((EIF_INTEGER_32) -1L));
}

/* {DS_SPARSE_SET}.extendible */
EIF_BOOLEAN F1274_9124 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_7_) >= (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) + arg1));
}

/* {DS_SPARSE_SET}.search */
void F1274_9127 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg1);
	F1269_9060(Current, tr1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_6_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_);
	RTLE;
}

/* {DS_SPARSE_SET}.is_equal */
EIF_BOOLEAN F1274_9128 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		tb2 = '\0';
		tr1 = RTOSCF(6778,F989_6778, (Current));
		tb3 = F13_114(RTCW(tr1), Current, arg1);
		if (tb3) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_7_0_0_8_);
			tb2 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) == ti4_1);
		}
		if (tb2) {
			tb1 = F1212_8532(Current, arg1);
		}
		if (tb1) {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L)))) break;
				if ((EIF_BOOLEAN) (F1275_9154(Current, loc2) > ((EIF_INTEGER_32) -2L))) {
					loc1 = F1275_9153(Current, loc2);
					tr1 = RTCCL(loc1);
					Result = F1274_9123(RTCW(arg1), tr1);
				}
				loc2--;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_SET}.put */
void F1274_9129 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1269_9046(Current);
	tr1 = RTCCL(arg1);
	F1269_9060(Current, tr1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		tr1 = RTCCL(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_);
		F1275_9157(Current, tr1, ti4_1);
	} else {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_))++;
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
		} else {
			ti4_1 = F1275_9154(Current, loc1);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
		}
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_4_);
		ti4_1 = F1275_9170(Current, loc2);
		F1275_9164(Current, ti4_1, loc1);
		F1275_9171(Current, loc1, loc2);
		tr1 = RTCCL(arg1);
		F1275_9157(Current, tr1, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_))++;
	}
	RTLE;
}

/* {DS_SPARSE_SET}.put_new */
void F1274_9130 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1269_9046(Current);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_))++;
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
	} else {
		ti4_1 = F1275_9154(Current, loc1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
	}
	tr1 = RTCCL(arg1);
	loc2 = F1276_9181(Current, tr1);
	ti4_1 = F1275_9170(Current, loc2);
	F1275_9164(Current, ti4_1, loc1);
	F1275_9171(Current, loc1, loc2);
	tr1 = RTCCL(arg1);
	F1275_9157(Current, tr1, loc1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_))++;
	RTLE;
}

/* {DS_SPARSE_SET}.put_last */
void F1274_9131 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1269_9046(Current);
	tr1 = RTCCL(arg1);
	F1269_9060(Current, tr1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		tr1 = RTCCL(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_);
		F1275_9157(Current, tr1, ti4_1);
	} else {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
		if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_7_))) {
			F1269_9052(Current);
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
		}
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_) = (EIF_INTEGER_32) loc1;
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_4_);
		ti4_1 = F1275_9170(Current, loc2);
		F1275_9164(Current, ti4_1, loc1);
		F1275_9171(Current, loc1, loc2);
		tr1 = RTCCL(arg1);
		F1275_9157(Current, tr1, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_))++;
	}
	RTLE;
}

/* {DS_SPARSE_SET}.force */
void F1274_9132 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1269_9046(Current);
	tr1 = RTCCL(arg1);
	F1269_9060(Current, tr1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		tr1 = RTCCL(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_);
		F1275_9157(Current, tr1, ti4_1);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_7_))) {
			ti4_1 = F1269_9116(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) + ((EIF_INTEGER_32) 1L)));
			F1269_9051(Current, ti4_1);
			tr1 = RTCCL(arg1);
			loc2 = F1276_9181(Current, tr1);
		} else {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_4_);
		}
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_))++;
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
		} else {
			ti4_1 = F1275_9154(Current, loc1);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
		}
		ti4_1 = F1275_9170(Current, loc2);
		F1275_9164(Current, ti4_1, loc1);
		F1275_9171(Current, loc1, loc2);
		tr1 = RTCCL(arg1);
		F1275_9157(Current, tr1, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_))++;
	}
	RTLE;
}

/* {DS_SPARSE_SET}.force_new */
void F1274_9133 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1269_9046(Current);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_7_))) {
		ti4_1 = F1269_9116(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) + ((EIF_INTEGER_32) 1L)));
		F1269_9051(Current, ti4_1);
	}
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_))++;
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
	} else {
		ti4_1 = F1275_9154(Current, loc1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
	}
	tr1 = RTCCL(arg1);
	loc2 = F1276_9181(Current, tr1);
	ti4_1 = F1275_9170(Current, loc2);
	F1275_9164(Current, ti4_1, loc1);
	F1275_9171(Current, loc1, loc2);
	tr1 = RTCCL(arg1);
	F1275_9157(Current, tr1, loc1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_))++;
	RTLE;
}

/* {DS_SPARSE_SET}.force_last */
void F1274_9134 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1269_9046(Current);
	tr1 = RTCCL(arg1);
	F1269_9060(Current, tr1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		tr1 = RTCCL(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_);
		F1275_9157(Current, tr1, ti4_1);
	} else {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
		if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_7_))) {
			ti4_1 = F1269_9116(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			F1269_9051(Current, ti4_1);
			tr1 = RTCCL(arg1);
			loc2 = F1276_9181(Current, tr1);
		} else {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_4_);
		}
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_) = (EIF_INTEGER_32) loc1;
		ti4_1 = F1275_9170(Current, loc2);
		F1275_9164(Current, ti4_1, loc1);
		F1275_9171(Current, loc1, loc2);
		tr1 = RTCCL(arg1);
		F1275_9157(Current, tr1, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_))++;
	}
	RTLE;
}

/* {DS_SPARSE_SET}.extend_last */
void F1274_9136 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6568[Dtype(RTCW(arg1))-1228])(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R6395[Dtype(RTCW(loc1))-1130])(loc1);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3321[Dtype(RTCW(loc1))-401])(loc1);
			if (tb1) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3320[Dtype(RTCW(loc1))-401])(loc1);
			tr2 = RTCCL(tr1);
			F1274_9131(Current, tr2);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R3322[Dtype(RTCW(loc1))-401])(loc1);
		}
	}
	RTLE;
}

/* {DS_SPARSE_SET}.append_last */
void F1274_9138 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6536[Dtype(RTCW(arg1))-1228])(arg1);
	if ((EIF_BOOLEAN) !F1274_9124(Current, loc1)) {
		ti4_1 = F1269_9116(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) + loc1));
		F1269_9051(Current, ti4_1);
	}
	F1274_9136(Current, arg1);
	RTLE;
}

/* {DS_SPARSE_SET}.key_storage_item */
EIF_REFERENCE F1274_9143 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	RTLE;
	return (EIF_REFERENCE) F1275_9153(Current, arg1);
}

/* {DS_SPARSE_SET}.key_equality_tester */
EIF_REFERENCE F1274_9144 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current);
}

/* {DS_SPARSE_SET}.internal_set_key_equality_tester */
void F1274_9145 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {DS_SPARSE_SET}.make_key_storage */
void F1274_9146 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
}

/* {DS_SPARSE_SET}.key_storage_put */
void F1274_9147 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	RTGC;
}

/* {DS_SPARSE_SET}.clone_key_storage */
void F1274_9148 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {DS_SPARSE_SET}.key_storage_resize */
void F1274_9149 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
}

/* {DS_SPARSE_SET}.key_storage_wipe_out */
void F1274_9150 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {DS_SPARSE_SET}.key_storage_keep_head */
void F1274_9151 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
}

void EIF_Minit838 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
