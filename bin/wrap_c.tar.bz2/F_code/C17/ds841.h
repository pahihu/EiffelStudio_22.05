
#ifndef _C17_ds841_
#define _C17_ds841_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1263_8910(EIF_REFERENCE);
extern EIF_INTEGER_32 F1263_8913(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit841(void);

#ifdef __cplusplus
}
#endif

#endif
