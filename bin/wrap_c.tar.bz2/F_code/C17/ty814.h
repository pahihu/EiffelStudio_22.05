
#ifndef _C17_ty814_
#define _C17_ty814_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F450_3922(EIF_REFERENCE);
extern void EIF_Minit814(void);
extern char *(*R3455[])();
extern char *(*R3772[])();
extern char *(*R3468[])();

#ifdef __cplusplus
}
#endif

#endif
