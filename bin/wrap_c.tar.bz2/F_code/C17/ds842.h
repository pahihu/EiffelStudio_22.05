
#ifndef _C17_ds842_
#define _C17_ds842_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1148_8333(EIF_REFERENCE);
extern void EIF_Minit842(void);

#ifdef __cplusplus
}
#endif

#endif
