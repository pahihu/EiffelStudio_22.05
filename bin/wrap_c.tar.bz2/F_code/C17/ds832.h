
#ifndef _C17_ds832_
#define _C17_ds832_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1276_9178(EIF_REFERENCE);
extern EIF_INTEGER_32 F1276_9181(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit832(void);
extern void F1141_8314(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4044[])();
extern EIF_TYPE_INDEX Y6545[];
extern EIF_TYPE_INDEX *Y6545_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
