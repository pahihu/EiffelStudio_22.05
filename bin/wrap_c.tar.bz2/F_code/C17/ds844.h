
#ifndef _C17_ds844_
#define _C17_ds844_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1287_9262(EIF_REFERENCE);
extern EIF_INTEGER_32 F1287_9265(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit844(void);
extern char *(*R6411[])();
extern char *(*R4044[])();
extern EIF_TYPE_INDEX Y1616[];
extern EIF_TYPE_INDEX *Y1616_gen_type [];
extern EIF_TYPE_INDEX Y6545[];
extern EIF_TYPE_INDEX *Y6545_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
