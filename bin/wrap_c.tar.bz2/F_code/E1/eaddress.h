#include "eif_eiffel.h"
#include "eif_rout_obj.h"

#ifdef __cplusplus
extern "C" {
#endif

extern void F855_4889(EIF_REFERENCE);
extern void F862_4962(EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER);
extern EIF_BOOLEAN F673_4113(EIF_REFERENCE);
extern void F862_4963(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);

#ifdef __cplusplus
}
#endif
