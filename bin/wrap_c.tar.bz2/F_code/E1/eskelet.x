#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif
extern const char *names6[];
static const uint32 types6 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags6 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype6_0 [] = {0xFF01,319,0xFFFF};
static const EIF_TYPE_INDEX g_atype6_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype6_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes6 [] = {
g_atype6_0,
g_atype6_1,
g_atype6_2,
};

static const long offsets6 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names12[];
static const uint32 types12 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT64,
SK_UINT64,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags12 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype12_0 [] = {1288,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype12_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype12_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype12_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype12_4 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype12_5 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype12_6 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype12_7 [] = {915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes12 [] = {
g_atype12_0,
g_atype12_1,
g_atype12_2,
g_atype12_3,
g_atype12_4,
g_atype12_5,
g_atype12_6,
g_atype12_7,
};

static const long offsets12 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @I64OFF(1,3,0,0,0,0,0),
+ @I64OFF(1,3,0,0,0,0,1),
+ @I64OFF(1,3,0,0,0,0,2),
+ @I64OFF(1,3,0,0,0,0,3),
};

extern const char *names14[];
static const uint32 types14 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags14 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype14_0 [] = {0xFF01,858,972,0xFF01,984,0xFFFF};
static const EIF_TYPE_INDEX g_atype14_1 [] = {0xFF01,854,0xFF01,984,0xFF01,984,0xFFFF};

static const EIF_TYPE_INDEX *gtypes14 [] = {
g_atype14_0,
g_atype14_1,
};

static const long offsets14 [] =
{
0,
 + @REFACS(1),
};

extern const char *names16[];
static const uint32 types16 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags16 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype16_0 [] = {0xFF01,984,0xFFFF};
static const EIF_TYPE_INDEX g_atype16_1 [] = {0xFF01,984,0xFFFF};
static const EIF_TYPE_INDEX g_atype16_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes16 [] = {
g_atype16_0,
g_atype16_1,
g_atype16_2,
};

static const long offsets16 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names17[];
static const uint32 types17 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags17 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype17_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype17_1 [] = {0xFF01,1246,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype17_2 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes17 [] = {
g_atype17_0,
g_atype17_1,
g_atype17_2,
};

static const long offsets17 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names18[];
static const uint32 types18 [] =
{
SK_REF,
};

static const uint16 attr_flags18 [] =
{0,};

static const EIF_TYPE_INDEX g_atype18_0 [] = {986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes18 [] = {
g_atype18_0,
};

static const long offsets18 [] =
{
0,
};

extern const char *names22[];
static const uint32 types22 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags22 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype22_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype22_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype22_2 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes22 [] = {
g_atype22_0,
g_atype22_1,
g_atype22_2,
};

static const long offsets22 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names23[];
static const uint32 types23 [] =
{
SK_UINT32,
};

static const uint16 attr_flags23 [] =
{1,};

static const EIF_TYPE_INDEX g_atype23_0 [] = {918,0xFFFF};

static const EIF_TYPE_INDEX *gtypes23 [] = {
g_atype23_0,
};

static const long offsets23 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names24[];
static const uint32 types24 [] =
{
SK_INT32,
};

static const uint16 attr_flags24 [] =
{0,};

static const EIF_TYPE_INDEX g_atype24_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes24 [] = {
g_atype24_0,
};

static const long offsets24 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names26[];
static const uint32 types26 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags26 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype26_0 [] = {0xFF01,813,0xFF01,0xFFF9,3,898,0xFF01,986,0xFF01,986,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_3 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_4 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_5 [] = {0xFF01,866,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_6 [] = {731,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_7 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_8 [] = {0xFF01,1421,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_9 [] = {0xFF01,1421,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_10 [] = {0xFF01,1421,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_11 [] = {0xFF01,1421,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_12 [] = {0xFF01,1421,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_13 [] = {0xFF01,1421,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_14 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_15 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype26_16 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes26 [] = {
g_atype26_0,
g_atype26_1,
g_atype26_2,
g_atype26_3,
g_atype26_4,
g_atype26_5,
g_atype26_6,
g_atype26_7,
g_atype26_8,
g_atype26_9,
g_atype26_10,
g_atype26_11,
g_atype26_12,
g_atype26_13,
g_atype26_14,
g_atype26_15,
g_atype26_16,
};

static const long offsets26 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
+ @CHROFF(14,0),
+ @CHROFF(14,1),
+ @LNGOFF(14,2,0,0),
};

extern const char *names27[];
static const uint32 types27 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags27 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype27_0 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype27_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype27_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype27_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype27_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype27_5 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes27 [] = {
g_atype27_0,
g_atype27_1,
g_atype27_2,
g_atype27_3,
g_atype27_4,
g_atype27_5,
};

static const long offsets27 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
+ @CHROFF(0,3),
+ @CHROFF(0,4),
+ @CHROFF(0,5),
};

extern const char *names28[];
static const uint32 types28 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags28 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype28_0 [] = {26,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_1 [] = {1076,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_2 [] = {1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_3 [] = {0xFF01,1246,0xFF01,1075,0xFFFF};
static const EIF_TYPE_INDEX g_atype28_4 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes28 [] = {
g_atype28_0,
g_atype28_1,
g_atype28_2,
g_atype28_3,
g_atype28_4,
};

static const long offsets28 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
};

extern const char *names35[];
static const uint32 types35 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags35 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype35_0 [] = {0xFF01,1246,0xFF01,27,0xFFFF};
static const EIF_TYPE_INDEX g_atype35_1 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes35 [] = {
g_atype35_0,
g_atype35_1,
};

static const long offsets35 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names36[];
static const uint32 types36 [] =
{
SK_REF,
};

static const uint16 attr_flags36 [] =
{0,};

static const EIF_TYPE_INDEX g_atype36_0 [] = {0xFF01,1076,0xFFFF};

static const EIF_TYPE_INDEX *gtypes36 [] = {
g_atype36_0,
};

static const long offsets36 [] =
{
0,
};

extern const char *names37[];
static const uint32 types37 [] =
{
SK_REF,
};

static const uint16 attr_flags37 [] =
{0,};

static const EIF_TYPE_INDEX g_atype37_0 [] = {0xFF01,1246,0xFF01,151,0xFF01,1103,0xFF01,1326,0xFFFF};

static const EIF_TYPE_INDEX *gtypes37 [] = {
g_atype37_0,
};

static const long offsets37 [] =
{
0,
};

extern const char *names40[];
static const uint32 types40 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags40 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype40_0 [] = {0xFF01,984,0xFFFF};
static const EIF_TYPE_INDEX g_atype40_1 [] = {0xFF01,1100,0xFFFF};

static const EIF_TYPE_INDEX *gtypes40 [] = {
g_atype40_0,
g_atype40_1,
};

static const long offsets40 [] =
{
0,
 + @REFACS(1),
};

extern const char *names43[];
static const uint32 types43 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags43 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype43_0 [] = {0xFF01,859,0xFF01,813,0xFF01,0xFFF9,3,898,0xFF01,986,0xFF01,986,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_3 [] = {0xFF01,866,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_4 [] = {731,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_5 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype43_8 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes43 [] = {
g_atype43_0,
g_atype43_1,
g_atype43_2,
g_atype43_3,
g_atype43_4,
g_atype43_5,
g_atype43_6,
g_atype43_7,
g_atype43_8,
};

static const long offsets43 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
};

extern const char *names44[];
static const uint32 types44 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags44 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype44_0 [] = {0xFF01,1027,0xFFFF};
static const EIF_TYPE_INDEX g_atype44_1 [] = {0xFF01,314,0xFFFF};

static const EIF_TYPE_INDEX *gtypes44 [] = {
g_atype44_0,
g_atype44_1,
};

static const long offsets44 [] =
{
0,
 + @REFACS(1),
};

extern const char *names46[];
static const uint32 types46 [] =
{
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags46 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype46_0 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype46_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes46 [] = {
g_atype46_0,
g_atype46_1,
g_atype46_2,
g_atype46_3,
};

static const long offsets46 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
+ @CHROFF(0,2),
+ @LNGOFF(0,3,0,0),
};

extern const char *names62[];
static const uint32 types62 [] =
{
SK_REF,
};

static const uint16 attr_flags62 [] =
{0,};

static const EIF_TYPE_INDEX g_atype62_0 [] = {733,0xFFFF};

static const EIF_TYPE_INDEX *gtypes62 [] = {
g_atype62_0,
};

static const long offsets62 [] =
{
0,
};

extern const char *names70[];
static const uint32 types70 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags70 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype70_0 [] = {5,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_1 [] = {5,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype70_8 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes70 [] = {
g_atype70_0,
g_atype70_1,
g_atype70_2,
g_atype70_3,
g_atype70_4,
g_atype70_5,
g_atype70_6,
g_atype70_7,
g_atype70_8,
};

static const long offsets70 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
};

extern const char *names73[];
static const uint32 types73 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags73 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype73_0 [] = {0xFF01,982,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_1 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_2 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_3 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_4 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_5 [] = {854,0xFF01,978,0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_6 [] = {973,0xFF01,0xFFF9,0,898,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_7 [] = {973,0xFF01,0xFFF9,0,898,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_8 [] = {973,0xFF01,0xFFF9,0,898,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_9 [] = {973,0xFF01,0xFFF9,0,898,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_10 [] = {973,0xFF01,0xFFF9,0,898,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_11 [] = {813,0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_12 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_13 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_14 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_15 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_16 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_17 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_18 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_19 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_20 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_21 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_22 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_23 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_24 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_25 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_26 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_27 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_28 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_29 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_30 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype73_31 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes73 [] = {
g_atype73_0,
g_atype73_1,
g_atype73_2,
g_atype73_3,
g_atype73_4,
g_atype73_5,
g_atype73_6,
g_atype73_7,
g_atype73_8,
g_atype73_9,
g_atype73_10,
g_atype73_11,
g_atype73_12,
g_atype73_13,
g_atype73_14,
g_atype73_15,
g_atype73_16,
g_atype73_17,
g_atype73_18,
g_atype73_19,
g_atype73_20,
g_atype73_21,
g_atype73_22,
g_atype73_23,
g_atype73_24,
g_atype73_25,
g_atype73_26,
g_atype73_27,
g_atype73_28,
g_atype73_29,
g_atype73_30,
g_atype73_31,
};

static const long offsets73 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @CHROFF(12,0),
+ @CHROFF(12,1),
+ @CHROFF(12,2),
+ @CHROFF(12,3),
+ @CHROFF(12,4),
+ @CHROFF(12,5),
+ @CHROFF(12,6),
+ @CHROFF(12,7),
+ @CHROFF(12,8),
+ @CHROFF(12,9),
+ @CHROFF(12,10),
+ @CHROFF(12,11),
+ @CHROFF(12,12),
+ @CHROFF(12,13),
+ @CHROFF(12,14),
+ @CHROFF(12,15),
+ @LNGOFF(12,16,0,0),
+ @LNGOFF(12,16,0,1),
+ @LNGOFF(12,16,0,2),
+ @LNGOFF(12,16,0,3),
};

extern const char *names84[];
static const uint32 types84 [] =
{
SK_REF,
};

static const uint16 attr_flags84 [] =
{0,};

static const EIF_TYPE_INDEX g_atype84_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes84 [] = {
g_atype84_0,
};

static const long offsets84 [] =
{
0,
};

extern const char *names85[];
static const uint32 types85 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags85 [] =
{0,};

static const EIF_TYPE_INDEX g_atype85_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes85 [] = {
g_atype85_0,
};

static const long offsets85 [] =
{
+ @CHROFF(0,0),
};

extern const char *names86[];
static const uint32 types86 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags86 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype86_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype86_1 [] = {85,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes86 [] = {
g_atype86_0,
g_atype86_1,
};

static const long offsets86 [] =
{
0,
 + @REFACS(1),
};

extern const char *names87[];
static const uint32 types87 [] =
{
SK_REF,
SK_CHAR8,
};

static const uint16 attr_flags87 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype87_0 [] = {86,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype87_1 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes87 [] = {
g_atype87_0,
g_atype87_1,
};

static const long offsets87 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names89[];
static const uint32 types89 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags89 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype89_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_1 [] = {974,0xFF01,0xFFF9,1,898,0xFF01,283,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_2 [] = {974,0xFF01,0xFFF9,2,898,0xFF01,283,0xFF01,283,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_3 [] = {974,0xFF01,0xFFF9,1,898,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_4 [] = {842,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_5 [] = {857,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_9 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_10 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype89_11 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes89 [] = {
g_atype89_0,
g_atype89_1,
g_atype89_2,
g_atype89_3,
g_atype89_4,
g_atype89_5,
g_atype89_6,
g_atype89_7,
g_atype89_8,
g_atype89_9,
g_atype89_10,
g_atype89_11,
};

static const long offsets89 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names90[];
static const uint32 types90 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags90 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype90_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_1 [] = {974,0xFF01,0xFFF9,1,898,0xFF01,283,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_2 [] = {974,0xFF01,0xFFF9,2,898,0xFF01,283,0xFF01,283,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_3 [] = {974,0xFF01,0xFFF9,1,898,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_4 [] = {842,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_5 [] = {857,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_9 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_10 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype90_11 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes90 [] = {
g_atype90_0,
g_atype90_1,
g_atype90_2,
g_atype90_3,
g_atype90_4,
g_atype90_5,
g_atype90_6,
g_atype90_7,
g_atype90_8,
g_atype90_9,
g_atype90_10,
g_atype90_11,
};

static const long offsets90 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
};

extern const char *names104[];
static const uint32 types104 [] =
{
SK_REF,
};

static const uint16 attr_flags104 [] =
{0,};

static const EIF_TYPE_INDEX g_atype104_0 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes104 [] = {
g_atype104_0,
};

static const long offsets104 [] =
{
0,
};

extern const char *names123[];
static const uint32 types123 [] =
{
SK_REF,
};

static const uint16 attr_flags123 [] =
{0,};

static const EIF_TYPE_INDEX g_atype123_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes123 [] = {
g_atype123_0,
};

static const long offsets123 [] =
{
0,
};

extern const char *names124[];
static const uint32 types124 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags124 [] =
{0,};

static const EIF_TYPE_INDEX g_atype124_0 [] = {933,0xFFFF};

static const EIF_TYPE_INDEX *gtypes124 [] = {
g_atype124_0,
};

static const long offsets124 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names125[];
static const uint32 types125 [] =
{
SK_UINT64,
};

static const uint16 attr_flags125 [] =
{0,};

static const EIF_TYPE_INDEX g_atype125_0 [] = {915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes125 [] = {
g_atype125_0,
};

static const long offsets125 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names126[];
static const uint32 types126 [] =
{
SK_INT32,
};

static const uint16 attr_flags126 [] =
{0,};

static const EIF_TYPE_INDEX g_atype126_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes126 [] = {
g_atype126_0,
};

static const long offsets126 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names127[];
static const uint32 types127 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags127 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype127_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype127_1 [] = {126,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes127 [] = {
g_atype127_0,
g_atype127_1,
};

static const long offsets127 [] =
{
0,
 + @REFACS(1),
};

extern const char *names128[];
static const uint32 types128 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags128 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype128_0 [] = {127,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype128_1 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes128 [] = {
g_atype128_0,
g_atype128_1,
};

static const long offsets128 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names130[];
static const uint32 types130 [] =
{
SK_REF,
SK_BOOL,
SK_POINTER,
};

static const uint16 attr_flags130 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype130_0 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype130_2 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes130 [] = {
g_atype130_0,
g_atype130_1,
g_atype130_2,
};

static const long offsets130 [] =
{
0,
+ @CHROFF(1,0),
+ @PTROFF(1,1,0,0,0,0),
};

extern const char *names148[];
static const uint32 types148 [] =
{
SK_REF,
};

static const uint16 attr_flags148 [] =
{0,};

static const EIF_TYPE_INDEX g_atype148_0 [] = {0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes148 [] = {
g_atype148_0,
};

static const long offsets148 [] =
{
0,
};

extern const char *names149[];
static const uint32 types149 [] =
{
SK_BOOL,
};

static const uint16 attr_flags149 [] =
{0,};

static const EIF_TYPE_INDEX g_atype149_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes149 [] = {
g_atype149_0,
};

static const long offsets149 [] =
{
+ @CHROFF(0,0),
};

extern const char *names150[];
static const uint32 types150 [] =
{
SK_INT32,
};

static const uint16 attr_flags150 [] =
{0,};

static const EIF_TYPE_INDEX g_atype150_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes150 [] = {
g_atype150_0,
};

static const long offsets150 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names151[];
static const uint32 types151 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags151 [] =
{0,};

static const EIF_TYPE_INDEX g_atype151_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes151 [] = {
g_atype151_0,
};

static const long offsets151 [] =
{
+ @CHROFF(0,0),
};

extern const char *names152[];
static const uint32 types152 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags152 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype152_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype152_1 [] = {0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes152 [] = {
g_atype152_0,
g_atype152_1,
};

static const long offsets152 [] =
{
0,
 + @REFACS(1),
};

extern const char *names153[];
static const uint32 types153 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags153 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype153_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype153_1 [] = {152,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes153 [] = {
g_atype153_0,
g_atype153_1,
};

static const long offsets153 [] =
{
0,
 + @REFACS(1),
};

extern const char *names154[];
static const uint32 types154 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags154 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype154_0 [] = {153,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype154_1 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes154 [] = {
g_atype154_0,
g_atype154_1,
};

static const long offsets154 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names155[];
static const uint32 types155 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags155 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype155_0 [] = {154,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype155_1 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes155 [] = {
g_atype155_0,
g_atype155_1,
};

static const long offsets155 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names156[];
static const uint32 types156 [] =
{
SK_REF,
SK_CHAR8,
};

static const uint16 attr_flags156 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype156_0 [] = {155,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype156_1 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes156 [] = {
g_atype156_0,
g_atype156_1,
};

static const long offsets156 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names157[];
static const uint32 types157 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags157 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype157_0 [] = {0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_1 [] = {156,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype157_2 [] = {156,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes157 [] = {
g_atype157_0,
g_atype157_1,
g_atype157_2,
};

static const long offsets157 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names165[];
static const uint32 types165 [] =
{
SK_REF,
};

static const uint16 attr_flags165 [] =
{0,};

static const EIF_TYPE_INDEX g_atype165_0 [] = {0xFF01,144,0xFFFF};

static const EIF_TYPE_INDEX *gtypes165 [] = {
g_atype165_0,
};

static const long offsets165 [] =
{
0,
};

extern const char *names167[];
static const uint32 types167 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags167 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype167_0 [] = {1336,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_1 [] = {1332,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_2 [] = {1330,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_3 [] = {1337,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_4 [] = {1331,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_5 [] = {1334,0xFFFF};
static const EIF_TYPE_INDEX g_atype167_6 [] = {1335,0xFFFF};

static const EIF_TYPE_INDEX *gtypes167 [] = {
g_atype167_0,
g_atype167_1,
g_atype167_2,
g_atype167_3,
g_atype167_4,
g_atype167_5,
g_atype167_6,
};

static const long offsets167 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
};

extern const char *names168[];
static const uint32 types168 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags168 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype168_0 [] = {0xFF01,211,0xFFFF};
static const EIF_TYPE_INDEX g_atype168_1 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes168 [] = {
g_atype168_0,
g_atype168_1,
};

static const long offsets168 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names172[];
static const uint32 types172 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags172 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype172_0 [] = {899,0xFFFF};
static const EIF_TYPE_INDEX g_atype172_1 [] = {0xFF01,1275,0xFF01,899,0xFFFF};

static const EIF_TYPE_INDEX *gtypes172 [] = {
g_atype172_0,
g_atype172_1,
};

static const long offsets172 [] =
{
0,
 + @REFACS(1),
};

extern const char *names178[];
static const uint32 types178 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags178 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype178_0 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype178_1 [] = {746,0xFF01,747,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes178 [] = {
g_atype178_0,
g_atype178_1,
};

static const long offsets178 [] =
{
0,
 + @REFACS(1),
};

extern const char *names179[];
static const uint32 types179 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags179 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype179_0 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype179_1 [] = {746,0xFF01,747,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes179 [] = {
g_atype179_0,
g_atype179_1,
};

static const long offsets179 [] =
{
0,
 + @REFACS(1),
};

extern const char *names180[];
static const uint32 types180 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags180 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype180_0 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype180_1 [] = {746,0xFF01,747,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes180 [] = {
g_atype180_0,
g_atype180_1,
};

static const long offsets180 [] =
{
0,
 + @REFACS(1),
};

extern const char *names182[];
static const uint32 types182 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags182 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype182_0 [] = {0xFF01,749,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_1 [] = {0xFF01,749,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_2 [] = {0xFF01,749,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype182_3 [] = {0xFF01,749,915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes182 [] = {
g_atype182_0,
g_atype182_1,
g_atype182_2,
g_atype182_3,
};

static const long offsets182 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names183[];
static const uint32 types183 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags183 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype183_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype183_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes183 [] = {
g_atype183_0,
g_atype183_1,
g_atype183_2,
g_atype183_3,
g_atype183_4,
g_atype183_5,
g_atype183_6,
};

static const long offsets183 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
+ @LNGOFF(2,2,0,1),
+ @LNGOFF(2,2,0,2),
};

extern const char *names184[];
static const uint32 types184 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags184 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype184_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_2 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_9 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype184_10 [] = {915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes184 [] = {
g_atype184_0,
g_atype184_1,
g_atype184_2,
g_atype184_3,
g_atype184_4,
g_atype184_5,
g_atype184_6,
g_atype184_7,
g_atype184_8,
g_atype184_9,
g_atype184_10,
};

static const long offsets184 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @I64OFF(2,4,0,3,0,0,0),
+ @I64OFF(2,4,0,3,0,0,1),
};

extern const char *names185[];
static const uint32 types185 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
SK_REAL64,
SK_REAL64,
};

static const uint16 attr_flags185 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype185_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_12 [] = {930,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_13 [] = {930,0xFFFF};
static const EIF_TYPE_INDEX g_atype185_14 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes185 [] = {
g_atype185_0,
g_atype185_1,
g_atype185_2,
g_atype185_3,
g_atype185_4,
g_atype185_5,
g_atype185_6,
g_atype185_7,
g_atype185_8,
g_atype185_9,
g_atype185_10,
g_atype185_11,
g_atype185_12,
g_atype185_13,
g_atype185_14,
};

static const long offsets185 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @LNGOFF(2,6,0,0),
+ @LNGOFF(2,6,0,1),
+ @LNGOFF(2,6,0,2),
+ @LNGOFF(2,6,0,3),
+ @R64OFF(2,6,0,4,0,0,0,0),
+ @R64OFF(2,6,0,4,0,0,0,1),
+ @R64OFF(2,6,0,4,0,0,0,2),
};

extern const char *names186[];
static const uint32 types186 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
SK_UINT64,
};

static const uint16 attr_flags186 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype186_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_8 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype186_9 [] = {915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes186 [] = {
g_atype186_0,
g_atype186_1,
g_atype186_2,
g_atype186_3,
g_atype186_4,
g_atype186_5,
g_atype186_6,
g_atype186_7,
g_atype186_8,
g_atype186_9,
};

static const long offsets186 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
+ @LNGOFF(2,3,0,1),
+ @LNGOFF(2,3,0,2),
+ @I64OFF(2,3,0,3,0,0,0),
+ @I64OFF(2,3,0,3,0,0,1),
};

extern const char *names200[];
static const uint32 types200 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags200 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype200_0 [] = {0xFF01,97,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype200_9 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes200 [] = {
g_atype200_0,
g_atype200_1,
g_atype200_2,
g_atype200_3,
g_atype200_4,
g_atype200_5,
g_atype200_6,
g_atype200_7,
g_atype200_8,
g_atype200_9,
};

static const long offsets200 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names201[];
static const uint32 types201 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags201 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype201_0 [] = {0xFF01,97,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype201_9 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes201 [] = {
g_atype201_0,
g_atype201_1,
g_atype201_2,
g_atype201_3,
g_atype201_4,
g_atype201_5,
g_atype201_6,
g_atype201_7,
g_atype201_8,
g_atype201_9,
};

static const long offsets201 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names202[];
static const uint32 types202 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags202 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype202_0 [] = {0xFF01,334,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype202_9 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes202 [] = {
g_atype202_0,
g_atype202_1,
g_atype202_2,
g_atype202_3,
g_atype202_4,
g_atype202_5,
g_atype202_6,
g_atype202_7,
g_atype202_8,
g_atype202_9,
};

static const long offsets202 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @LNGOFF(1,3,0,0),
+ @LNGOFF(1,3,0,1),
+ @LNGOFF(1,3,0,2),
+ @LNGOFF(1,3,0,3),
+ @LNGOFF(1,3,0,4),
+ @LNGOFF(1,3,0,5),
};

extern const char *names203[];
static const uint32 types203 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags203 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype203_0 [] = {0xFF01,97,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_1 [] = {0xFF01,1000,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype203_11 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes203 [] = {
g_atype203_0,
g_atype203_1,
g_atype203_2,
g_atype203_3,
g_atype203_4,
g_atype203_5,
g_atype203_6,
g_atype203_7,
g_atype203_8,
g_atype203_9,
g_atype203_10,
g_atype203_11,
};

static const long offsets203 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
};

extern const char *names204[];
static const uint32 types204 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags204 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype204_0 [] = {0xFF01,97,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_1 [] = {0xFF01,1000,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype204_13 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes204 [] = {
g_atype204_0,
g_atype204_1,
g_atype204_2,
g_atype204_3,
g_atype204_4,
g_atype204_5,
g_atype204_6,
g_atype204_7,
g_atype204_8,
g_atype204_9,
g_atype204_10,
g_atype204_11,
g_atype204_12,
g_atype204_13,
};

static const long offsets204 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @LNGOFF(2,4,0,0),
+ @LNGOFF(2,4,0,1),
+ @LNGOFF(2,4,0,2),
+ @LNGOFF(2,4,0,3),
+ @LNGOFF(2,4,0,4),
+ @LNGOFF(2,4,0,5),
+ @LNGOFF(2,4,0,6),
+ @LNGOFF(2,4,0,7),
};

extern const char *names205[];
static const uint32 types205 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags205 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype205_0 [] = {0xFF01,334,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_1 [] = {0xFF01,1000,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype205_14 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes205 [] = {
g_atype205_0,
g_atype205_1,
g_atype205_2,
g_atype205_3,
g_atype205_4,
g_atype205_5,
g_atype205_6,
g_atype205_7,
g_atype205_8,
g_atype205_9,
g_atype205_10,
g_atype205_11,
g_atype205_12,
g_atype205_13,
g_atype205_14,
};

static const long offsets205 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @LNGOFF(2,5,0,0),
+ @LNGOFF(2,5,0,1),
+ @LNGOFF(2,5,0,2),
+ @LNGOFF(2,5,0,3),
+ @LNGOFF(2,5,0,4),
+ @LNGOFF(2,5,0,5),
+ @LNGOFF(2,5,0,6),
+ @LNGOFF(2,5,0,7),
};

extern const char *names214[];
static const uint32 types214 [] =
{
SK_REF,
};

static const uint16 attr_flags214 [] =
{0,};

static const EIF_TYPE_INDEX g_atype214_0 [] = {0xFF01,211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes214 [] = {
g_atype214_0,
};

static const long offsets214 [] =
{
0,
};

extern const char *names215[];
static const uint32 types215 [] =
{
SK_REF,
};

static const uint16 attr_flags215 [] =
{0,};

static const EIF_TYPE_INDEX g_atype215_0 [] = {0xFF01,211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes215 [] = {
g_atype215_0,
};

static const long offsets215 [] =
{
0,
};

extern const char *names216[];
static const uint32 types216 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags216 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype216_0 [] = {0xFF01,211,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_1 [] = {0xFF01,1260,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype216_2 [] = {0xFF01,1260,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes216 [] = {
g_atype216_0,
g_atype216_1,
g_atype216_2,
};

static const long offsets216 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names217[];
static const uint32 types217 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags217 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype217_0 [] = {0xFF01,211,0xFFFF};
static const EIF_TYPE_INDEX g_atype217_1 [] = {0xFF01,1275,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes217 [] = {
g_atype217_0,
g_atype217_1,
};

static const long offsets217 [] =
{
0,
 + @REFACS(1),
};

extern const char *names218[];
static const uint32 types218 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags218 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype218_0 [] = {0xFF01,211,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_1 [] = {0xFF01,1337,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_2 [] = {36,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_3 [] = {1336,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_4 [] = {0xFF01,1275,0xFF01,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype218_5 [] = {1095,0xFFFF};

static const EIF_TYPE_INDEX *gtypes218 [] = {
g_atype218_0,
g_atype218_1,
g_atype218_2,
g_atype218_3,
g_atype218_4,
g_atype218_5,
};

static const long offsets218 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names219[];
static const uint32 types219 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags219 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype219_0 [] = {0xFF01,211,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype219_2 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes219 [] = {
g_atype219_0,
g_atype219_1,
g_atype219_2,
};

static const long offsets219 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names220[];
static const uint32 types220 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags220 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype220_0 [] = {0xFF01,211,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_2 [] = {0xFF01,1095,0xFFFF};
static const EIF_TYPE_INDEX g_atype220_3 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes220 [] = {
g_atype220_0,
g_atype220_1,
g_atype220_2,
g_atype220_3,
};

static const long offsets220 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
};

extern const char *names222[];
static const uint32 types222 [] =
{
SK_INT32,
};

static const uint16 attr_flags222 [] =
{0,};

static const EIF_TYPE_INDEX g_atype222_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes222 [] = {
g_atype222_0,
};

static const long offsets222 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names225[];
static const uint32 types225 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags225 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype225_0 [] = {126,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype225_2 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes225 [] = {
g_atype225_0,
g_atype225_1,
g_atype225_2,
};

static const long offsets225 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names226[];
static const uint32 types226 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags226 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype226_0 [] = {127,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype226_2 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes226 [] = {
g_atype226_0,
g_atype226_1,
g_atype226_2,
};

static const long offsets226 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names227[];
static const uint32 types227 [] =
{
SK_INT32,
};

static const uint16 attr_flags227 [] =
{0,};

static const EIF_TYPE_INDEX g_atype227_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes227 [] = {
g_atype227_0,
};

static const long offsets227 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names228[];
static const uint32 types228 [] =
{
SK_INT32,
};

static const uint16 attr_flags228 [] =
{0,};

static const EIF_TYPE_INDEX g_atype228_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes228 [] = {
g_atype228_0,
};

static const long offsets228 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names232[];
static const uint32 types232 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags232 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype232_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype232_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes232 [] = {
g_atype232_0,
g_atype232_1,
g_atype232_2,
g_atype232_3,
g_atype232_4,
g_atype232_5,
g_atype232_6,
};

static const long offsets232 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names233[];
static const uint32 types233 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags233 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype233_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype233_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes233 [] = {
g_atype233_0,
g_atype233_1,
g_atype233_2,
g_atype233_3,
g_atype233_4,
g_atype233_5,
g_atype233_6,
};

static const long offsets233 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names234[];
static const uint32 types234 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags234 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype234_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype234_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes234 [] = {
g_atype234_0,
g_atype234_1,
g_atype234_2,
g_atype234_3,
g_atype234_4,
g_atype234_5,
g_atype234_6,
};

static const long offsets234 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names235[];
static const uint32 types235 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags235 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype235_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype235_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes235 [] = {
g_atype235_0,
g_atype235_1,
g_atype235_2,
g_atype235_3,
g_atype235_4,
g_atype235_5,
g_atype235_6,
};

static const long offsets235 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names236[];
static const uint32 types236 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags236 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype236_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype236_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes236 [] = {
g_atype236_0,
g_atype236_1,
g_atype236_2,
g_atype236_3,
g_atype236_4,
g_atype236_5,
g_atype236_6,
};

static const long offsets236 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names237[];
static const uint32 types237 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags237 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype237_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype237_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes237 [] = {
g_atype237_0,
g_atype237_1,
g_atype237_2,
g_atype237_3,
g_atype237_4,
g_atype237_5,
g_atype237_6,
};

static const long offsets237 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names238[];
static const uint32 types238 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags238 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype238_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype238_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes238 [] = {
g_atype238_0,
g_atype238_1,
g_atype238_2,
g_atype238_3,
g_atype238_4,
g_atype238_5,
g_atype238_6,
};

static const long offsets238 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names239[];
static const uint32 types239 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags239 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype239_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype239_7 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes239 [] = {
g_atype239_0,
g_atype239_1,
g_atype239_2,
g_atype239_3,
g_atype239_4,
g_atype239_5,
g_atype239_6,
g_atype239_7,
};

static const long offsets239 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names240[];
static const uint32 types240 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags240 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype240_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_5 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype240_9 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes240 [] = {
g_atype240_0,
g_atype240_1,
g_atype240_2,
g_atype240_3,
g_atype240_4,
g_atype240_5,
g_atype240_6,
g_atype240_7,
g_atype240_8,
g_atype240_9,
};

static const long offsets240 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @LNGOFF(6,1,0,0),
+ @LNGOFF(6,1,0,1),
+ @LNGOFF(6,1,0,2),
};

extern const char *names241[];
static const uint32 types241 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags241 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype241_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype241_7 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes241 [] = {
g_atype241_0,
g_atype241_1,
g_atype241_2,
g_atype241_3,
g_atype241_4,
g_atype241_5,
g_atype241_6,
g_atype241_7,
};

static const long offsets241 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names242[];
static const uint32 types242 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags242 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype242_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype242_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes242 [] = {
g_atype242_0,
g_atype242_1,
g_atype242_2,
g_atype242_3,
g_atype242_4,
g_atype242_5,
g_atype242_6,
};

static const long offsets242 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names243[];
static const uint32 types243 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags243 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype243_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype243_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes243 [] = {
g_atype243_0,
g_atype243_1,
g_atype243_2,
g_atype243_3,
g_atype243_4,
g_atype243_5,
g_atype243_6,
};

static const long offsets243 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names244[];
static const uint32 types244 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags244 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype244_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype244_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes244 [] = {
g_atype244_0,
g_atype244_1,
g_atype244_2,
g_atype244_3,
g_atype244_4,
g_atype244_5,
g_atype244_6,
};

static const long offsets244 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names245[];
static const uint32 types245 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags245 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype245_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype245_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes245 [] = {
g_atype245_0,
g_atype245_1,
g_atype245_2,
g_atype245_3,
g_atype245_4,
g_atype245_5,
g_atype245_6,
};

static const long offsets245 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names246[];
static const uint32 types246 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags246 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype246_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype246_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes246 [] = {
g_atype246_0,
g_atype246_1,
g_atype246_2,
g_atype246_3,
g_atype246_4,
g_atype246_5,
g_atype246_6,
};

static const long offsets246 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names247[];
static const uint32 types247 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags247 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype247_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype247_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes247 [] = {
g_atype247_0,
g_atype247_1,
g_atype247_2,
g_atype247_3,
g_atype247_4,
g_atype247_5,
g_atype247_6,
};

static const long offsets247 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names248[];
static const uint32 types248 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags248 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype248_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype248_7 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes248 [] = {
g_atype248_0,
g_atype248_1,
g_atype248_2,
g_atype248_3,
g_atype248_4,
g_atype248_5,
g_atype248_6,
g_atype248_7,
};

static const long offsets248 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names249[];
static const uint32 types249 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags249 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype249_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype249_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes249 [] = {
g_atype249_0,
g_atype249_1,
g_atype249_2,
g_atype249_3,
g_atype249_4,
g_atype249_5,
g_atype249_6,
};

static const long offsets249 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names250[];
static const uint32 types250 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags250 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype250_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype250_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes250 [] = {
g_atype250_0,
g_atype250_1,
g_atype250_2,
g_atype250_3,
g_atype250_4,
g_atype250_5,
g_atype250_6,
};

static const long offsets250 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names251[];
static const uint32 types251 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags251 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype251_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype251_7 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes251 [] = {
g_atype251_0,
g_atype251_1,
g_atype251_2,
g_atype251_3,
g_atype251_4,
g_atype251_5,
g_atype251_6,
g_atype251_7,
};

static const long offsets251 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names252[];
static const uint32 types252 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags252 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype252_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype252_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes252 [] = {
g_atype252_0,
g_atype252_1,
g_atype252_2,
g_atype252_3,
g_atype252_4,
g_atype252_5,
g_atype252_6,
};

static const long offsets252 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names253[];
static const uint32 types253 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags253 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype253_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype253_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes253 [] = {
g_atype253_0,
g_atype253_1,
g_atype253_2,
g_atype253_3,
g_atype253_4,
g_atype253_5,
g_atype253_6,
};

static const long offsets253 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names254[];
static const uint32 types254 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags254 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype254_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype254_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype254_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype254_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype254_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype254_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype254_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes254 [] = {
g_atype254_0,
g_atype254_1,
g_atype254_2,
g_atype254_3,
g_atype254_4,
g_atype254_5,
g_atype254_6,
};

static const long offsets254 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names255[];
static const uint32 types255 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags255 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype255_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype255_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes255 [] = {
g_atype255_0,
g_atype255_1,
g_atype255_2,
g_atype255_3,
g_atype255_4,
g_atype255_5,
g_atype255_6,
};

static const long offsets255 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names256[];
static const uint32 types256 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags256 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype256_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype256_8 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes256 [] = {
g_atype256_0,
g_atype256_1,
g_atype256_2,
g_atype256_3,
g_atype256_4,
g_atype256_5,
g_atype256_6,
g_atype256_7,
g_atype256_8,
};

static const long offsets256 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
+ @LNGOFF(5,1,0,2),
};

extern const char *names257[];
static const uint32 types257 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags257 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype257_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype257_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes257 [] = {
g_atype257_0,
g_atype257_1,
g_atype257_2,
g_atype257_3,
g_atype257_4,
g_atype257_5,
g_atype257_6,
};

static const long offsets257 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names258[];
static const uint32 types258 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags258 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype258_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype258_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes258 [] = {
g_atype258_0,
g_atype258_1,
g_atype258_2,
g_atype258_3,
g_atype258_4,
g_atype258_5,
g_atype258_6,
};

static const long offsets258 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names259[];
static const uint32 types259 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags259 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype259_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_5 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_6 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype259_8 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes259 [] = {
g_atype259_0,
g_atype259_1,
g_atype259_2,
g_atype259_3,
g_atype259_4,
g_atype259_5,
g_atype259_6,
g_atype259_7,
g_atype259_8,
};

static const long offsets259 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @LNGOFF(7,1,0,0),
};

extern const char *names260[];
static const uint32 types260 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags260 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype260_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype260_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes260 [] = {
g_atype260_0,
g_atype260_1,
g_atype260_2,
g_atype260_3,
g_atype260_4,
g_atype260_5,
g_atype260_6,
};

static const long offsets260 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names261[];
static const uint32 types261 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags261 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype261_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype261_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes261 [] = {
g_atype261_0,
g_atype261_1,
g_atype261_2,
g_atype261_3,
g_atype261_4,
g_atype261_5,
g_atype261_6,
};

static const long offsets261 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names262[];
static const uint32 types262 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags262 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype262_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype262_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes262 [] = {
g_atype262_0,
g_atype262_1,
g_atype262_2,
g_atype262_3,
g_atype262_4,
g_atype262_5,
g_atype262_6,
};

static const long offsets262 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names263[];
static const uint32 types263 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags263 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype263_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype263_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes263 [] = {
g_atype263_0,
g_atype263_1,
g_atype263_2,
g_atype263_3,
g_atype263_4,
g_atype263_5,
g_atype263_6,
};

static const long offsets263 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names264[];
static const uint32 types264 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags264 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype264_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype264_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes264 [] = {
g_atype264_0,
g_atype264_1,
g_atype264_2,
g_atype264_3,
g_atype264_4,
g_atype264_5,
g_atype264_6,
};

static const long offsets264 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names265[];
static const uint32 types265 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags265 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype265_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype265_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes265 [] = {
g_atype265_0,
g_atype265_1,
g_atype265_2,
g_atype265_3,
g_atype265_4,
g_atype265_5,
g_atype265_6,
};

static const long offsets265 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names266[];
static const uint32 types266 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags266 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype266_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype266_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes266 [] = {
g_atype266_0,
g_atype266_1,
g_atype266_2,
g_atype266_3,
g_atype266_4,
g_atype266_5,
g_atype266_6,
};

static const long offsets266 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names267[];
static const uint32 types267 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags267 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype267_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype267_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes267 [] = {
g_atype267_0,
g_atype267_1,
g_atype267_2,
g_atype267_3,
g_atype267_4,
g_atype267_5,
g_atype267_6,
};

static const long offsets267 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names268[];
static const uint32 types268 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags268 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype268_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype268_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes268 [] = {
g_atype268_0,
g_atype268_1,
g_atype268_2,
g_atype268_3,
g_atype268_4,
g_atype268_5,
g_atype268_6,
};

static const long offsets268 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names269[];
static const uint32 types269 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags269 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype269_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype269_7 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes269 [] = {
g_atype269_0,
g_atype269_1,
g_atype269_2,
g_atype269_3,
g_atype269_4,
g_atype269_5,
g_atype269_6,
g_atype269_7,
};

static const long offsets269 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
};

extern const char *names270[];
static const uint32 types270 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags270 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype270_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype270_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes270 [] = {
g_atype270_0,
g_atype270_1,
g_atype270_2,
g_atype270_3,
g_atype270_4,
g_atype270_5,
g_atype270_6,
};

static const long offsets270 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names271[];
static const uint32 types271 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags271 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype271_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_2 [] = {231,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_3 [] = {336,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype271_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes271 [] = {
g_atype271_0,
g_atype271_1,
g_atype271_2,
g_atype271_3,
g_atype271_4,
g_atype271_5,
g_atype271_6,
};

static const long offsets271 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
};

extern const char *names272[];
static const uint32 types272 [] =
{
SK_REF,
};

static const uint16 attr_flags272 [] =
{0,};

static const EIF_TYPE_INDEX g_atype272_0 [] = {0xFF01,1034,0xFFFF};

static const EIF_TYPE_INDEX *gtypes272 [] = {
g_atype272_0,
};

static const long offsets272 [] =
{
0,
};

extern const char *names273[];
static const uint32 types273 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags273 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype273_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype273_1 [] = {0xFF01,221,0xFFFF};

static const EIF_TYPE_INDEX *gtypes273 [] = {
g_atype273_0,
g_atype273_1,
};

static const long offsets273 [] =
{
0,
 + @REFACS(1),
};

extern const char *names274[];
static const uint32 types274 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags274 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype274_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_1 [] = {0xFF01,221,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_2 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype274_3 [] = {0xFF01,1293,0xFFFF};

static const EIF_TYPE_INDEX *gtypes274 [] = {
g_atype274_0,
g_atype274_1,
g_atype274_2,
g_atype274_3,
};

static const long offsets274 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names275[];
static const uint32 types275 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags275 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype275_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_1 [] = {0xFF01,221,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_2 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype275_3 [] = {0xFF01,1293,0xFFFF};

static const EIF_TYPE_INDEX *gtypes275 [] = {
g_atype275_0,
g_atype275_1,
g_atype275_2,
g_atype275_3,
};

static const long offsets275 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names276[];
static const uint32 types276 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags276 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype276_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_1 [] = {0xFF01,221,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_2 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype276_3 [] = {0xFF01,1293,0xFFFF};

static const EIF_TYPE_INDEX *gtypes276 [] = {
g_atype276_0,
g_atype276_1,
g_atype276_2,
g_atype276_3,
};

static const long offsets276 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names277[];
static const uint32 types277 [] =
{
SK_REF,
};

static const uint16 attr_flags277 [] =
{0,};

static const EIF_TYPE_INDEX g_atype277_0 [] = {0xFF01,1034,0xFFFF};

static const EIF_TYPE_INDEX *gtypes277 [] = {
g_atype277_0,
};

static const long offsets277 [] =
{
0,
};

extern const char *names278[];
static const uint32 types278 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags278 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype278_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype278_1 [] = {0xFF01,221,0xFFFF};

static const EIF_TYPE_INDEX *gtypes278 [] = {
g_atype278_0,
g_atype278_1,
};

static const long offsets278 [] =
{
0,
 + @REFACS(1),
};

extern const char *names279[];
static const uint32 types279 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags279 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype279_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype279_1 [] = {0xFF01,1244,0xFF01,276,0xFFFF};

static const EIF_TYPE_INDEX *gtypes279 [] = {
g_atype279_0,
g_atype279_1,
};

static const long offsets279 [] =
{
0,
 + @REFACS(1),
};

extern const char *names280[];
static const uint32 types280 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags280 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype280_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype280_1 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes280 [] = {
g_atype280_0,
g_atype280_1,
};

static const long offsets280 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names284[];
static const uint32 types284 [] =
{
SK_INT32,
};

static const uint16 attr_flags284 [] =
{0,};

static const EIF_TYPE_INDEX g_atype284_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes284 [] = {
g_atype284_0,
};

static const long offsets284 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names288[];
static const uint32 types288 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags288 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype288_0 [] = {0xFF01,283,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype288_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes288 [] = {
g_atype288_0,
g_atype288_1,
g_atype288_2,
g_atype288_3,
};

static const long offsets288 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names289[];
static const uint32 types289 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags289 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype289_0 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype289_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes289 [] = {
g_atype289_0,
g_atype289_1,
g_atype289_2,
};

static const long offsets289 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names290[];
static const uint32 types290 [] =
{
SK_REF,
};

static const uint16 attr_flags290 [] =
{0,};

static const EIF_TYPE_INDEX g_atype290_0 [] = {0xFF01,746,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes290 [] = {
g_atype290_0,
};

static const long offsets290 [] =
{
0,
};

extern const char *names291[];
static const uint32 types291 [] =
{
SK_REF,
};

static const uint16 attr_flags291 [] =
{0,};

static const EIF_TYPE_INDEX g_atype291_0 [] = {0xFF01,747,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes291 [] = {
g_atype291_0,
};

static const long offsets291 [] =
{
0,
};

extern const char *names292[];
static const uint32 types292 [] =
{
SK_REF,
};

static const uint16 attr_flags292 [] =
{0,};

static const EIF_TYPE_INDEX g_atype292_0 [] = {0xFF01,748,939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes292 [] = {
g_atype292_0,
};

static const long offsets292 [] =
{
0,
};

extern const char *names293[];
static const uint32 types293 [] =
{
SK_REF,
};

static const uint16 attr_flags293 [] =
{0,};

static const EIF_TYPE_INDEX g_atype293_0 [] = {0xFF01,749,915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes293 [] = {
g_atype293_0,
};

static const long offsets293 [] =
{
0,
};

extern const char *names294[];
static const uint32 types294 [] =
{
SK_REF,
};

static const uint16 attr_flags294 [] =
{0,};

static const EIF_TYPE_INDEX g_atype294_0 [] = {0xFF01,750,918,0xFFFF};

static const EIF_TYPE_INDEX *gtypes294 [] = {
g_atype294_0,
};

static const long offsets294 [] =
{
0,
};

extern const char *names295[];
static const uint32 types295 [] =
{
SK_REF,
};

static const uint16 attr_flags295 [] =
{0,};

static const EIF_TYPE_INDEX g_atype295_0 [] = {0xFF01,751,933,0xFFFF};

static const EIF_TYPE_INDEX *gtypes295 [] = {
g_atype295_0,
};

static const long offsets295 [] =
{
0,
};

extern const char *names296[];
static const uint32 types296 [] =
{
SK_REF,
};

static const uint16 attr_flags296 [] =
{0,};

static const EIF_TYPE_INDEX g_atype296_0 [] = {0xFF01,752,936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes296 [] = {
g_atype296_0,
};

static const long offsets296 [] =
{
0,
};

extern const char *names297[];
static const uint32 types297 [] =
{
SK_REF,
};

static const uint16 attr_flags297 [] =
{0,};

static const EIF_TYPE_INDEX g_atype297_0 [] = {0xFF01,753,924,0xFFFF};

static const EIF_TYPE_INDEX *gtypes297 [] = {
g_atype297_0,
};

static const long offsets297 [] =
{
0,
};

extern const char *names298[];
static const uint32 types298 [] =
{
SK_REF,
};

static const uint16 attr_flags298 [] =
{0,};

static const EIF_TYPE_INDEX g_atype298_0 [] = {0xFF01,754,921,0xFFFF};

static const EIF_TYPE_INDEX *gtypes298 [] = {
g_atype298_0,
};

static const long offsets298 [] =
{
0,
};

extern const char *names299[];
static const uint32 types299 [] =
{
SK_REF,
};

static const uint16 attr_flags299 [] =
{0,};

static const EIF_TYPE_INDEX g_atype299_0 [] = {0xFF01,755,972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes299 [] = {
g_atype299_0,
};

static const long offsets299 [] =
{
0,
};

extern const char *names300[];
static const uint32 types300 [] =
{
SK_REF,
};

static const uint16 attr_flags300 [] =
{0,};

static const EIF_TYPE_INDEX g_atype300_0 [] = {0xFF01,756,927,0xFFFF};

static const EIF_TYPE_INDEX *gtypes300 [] = {
g_atype300_0,
};

static const long offsets300 [] =
{
0,
};

extern const char *names301[];
static const uint32 types301 [] =
{
SK_REF,
};

static const uint16 attr_flags301 [] =
{0,};

static const EIF_TYPE_INDEX g_atype301_0 [] = {0xFF01,757,930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes301 [] = {
g_atype301_0,
};

static const long offsets301 [] =
{
0,
};

extern const char *names315[];
static const uint32 types315 [] =
{
SK_REF,
};

static const uint16 attr_flags315 [] =
{0,};

static const EIF_TYPE_INDEX g_atype315_0 [] = {986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes315 [] = {
g_atype315_0,
};

static const long offsets315 [] =
{
0,
};

extern const char *names316[];
static const uint32 types316 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags316 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype316_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype316_1 [] = {986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes316 [] = {
g_atype316_0,
g_atype316_1,
};

static const long offsets316 [] =
{
0,
 + @REFACS(1),
};

extern const char *names317[];
static const uint32 types317 [] =
{
SK_REF,
};

static const uint16 attr_flags317 [] =
{0,};

static const EIF_TYPE_INDEX g_atype317_0 [] = {986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes317 [] = {
g_atype317_0,
};

static const long offsets317 [] =
{
0,
};

extern const char *names318[];
static const uint32 types318 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags318 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype318_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_1 [] = {0xFF01,1417,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_2 [] = {0xFF01,1415,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_3 [] = {0xFF01,1416,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_4 [] = {0xFF01,1408,0xFFFF};
static const EIF_TYPE_INDEX g_atype318_5 [] = {0xFF01,1409,0xFFFF};

static const EIF_TYPE_INDEX *gtypes318 [] = {
g_atype318_0,
g_atype318_1,
g_atype318_2,
g_atype318_3,
g_atype318_4,
g_atype318_5,
};

static const long offsets318 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names320[];
static const uint32 types320 [] =
{
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_UINT64,
};

static const uint16 attr_flags320 [] =
{0,0,1,1,};

static const EIF_TYPE_INDEX g_atype320_0 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_2 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype320_3 [] = {915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes320 [] = {
g_atype320_0,
g_atype320_1,
g_atype320_2,
g_atype320_3,
};

static const long offsets320 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @PTROFF(0,1,0,1,0,0),
+ @I64OFF(0,1,0,1,0,1,0),
};

extern const char *names321[];
static const uint32 types321 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags321 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype321_0 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype321_1 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes321 [] = {
g_atype321_0,
g_atype321_1,
};

static const long offsets321 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names324[];
static const uint32 types324 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags324 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype324_0 [] = {0xFF01,319,0xFFFF};
static const EIF_TYPE_INDEX g_atype324_1 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes324 [] = {
g_atype324_0,
g_atype324_1,
};

static const long offsets324 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names325[];
static const uint32 types325 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags325 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype325_0 [] = {0xFF01,753,924,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_1 [] = {978,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_2 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype325_4 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes325 [] = {
g_atype325_0,
g_atype325_1,
g_atype325_2,
g_atype325_3,
g_atype325_4,
};

static const long offsets325 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names326[];
static const uint32 types326 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags326 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype326_0 [] = {0xFF01,753,924,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_1 [] = {978,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_2 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype326_4 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes326 [] = {
g_atype326_0,
g_atype326_1,
g_atype326_2,
g_atype326_3,
g_atype326_4,
};

static const long offsets326 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names327[];
static const uint32 types327 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags327 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype327_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_1 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_2 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_4 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype327_5 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes327 [] = {
g_atype327_0,
g_atype327_1,
g_atype327_2,
g_atype327_3,
g_atype327_4,
g_atype327_5,
};

static const long offsets327 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @PTROFF(3,0,0,1,0,0),
+ @PTROFF(3,0,0,1,0,1),
};

extern const char *names328[];
static const uint32 types328 [] =
{
SK_INT32,
};

static const uint16 attr_flags328 [] =
{0,};

static const EIF_TYPE_INDEX g_atype328_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes328 [] = {
g_atype328_0,
};

static const long offsets328 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names329[];
static const uint32 types329 [] =
{
SK_INT32,
};

static const uint16 attr_flags329 [] =
{0,};

static const EIF_TYPE_INDEX g_atype329_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes329 [] = {
g_atype329_0,
};

static const long offsets329 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names330[];
static const uint32 types330 [] =
{
SK_INT32,
};

static const uint16 attr_flags330 [] =
{0,};

static const EIF_TYPE_INDEX g_atype330_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes330 [] = {
g_atype330_0,
};

static const long offsets330 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names331[];
static const uint32 types331 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags331 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype331_0 [] = {866,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_1 [] = {771,0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_2 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_3 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_4 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_5 [] = {842,0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_6 [] = {978,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_7 [] = {978,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_8 [] = {978,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_9 [] = {732,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_10 [] = {732,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_11 [] = {732,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_12 [] = {338,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_13 [] = {338,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_14 [] = {338,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_15 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_16 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_17 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_18 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_19 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_20 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_21 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_22 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_23 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_24 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_25 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_26 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_27 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype331_28 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes331 [] = {
g_atype331_0,
g_atype331_1,
g_atype331_2,
g_atype331_3,
g_atype331_4,
g_atype331_5,
g_atype331_6,
g_atype331_7,
g_atype331_8,
g_atype331_9,
g_atype331_10,
g_atype331_11,
g_atype331_12,
g_atype331_13,
g_atype331_14,
g_atype331_15,
g_atype331_16,
g_atype331_17,
g_atype331_18,
g_atype331_19,
g_atype331_20,
g_atype331_21,
g_atype331_22,
g_atype331_23,
g_atype331_24,
g_atype331_25,
g_atype331_26,
g_atype331_27,
g_atype331_28,
};

static const long offsets331 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
+ @CHROFF(15,0),
+ @CHROFF(15,1),
+ @CHROFF(15,2),
+ @CHROFF(15,3),
+ @CHROFF(15,4),
+ @CHROFF(15,5),
+ @CHROFF(15,6),
+ @CHROFF(15,7),
+ @CHROFF(15,8),
+ @CHROFF(15,9),
+ @CHROFF(15,10),
+ @LNGOFF(15,11,0,0),
+ @LNGOFF(15,11,0,1),
+ @LNGOFF(15,11,0,2),
};

extern const char *names332[];
static const uint32 types332 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags332 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype332_0 [] = {0xFF01,982,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_1 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_2 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_3 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_4 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_5 [] = {854,0xFF01,978,0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_6 [] = {973,0xFF01,0xFFF9,0,898,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_7 [] = {973,0xFF01,0xFFF9,0,898,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_8 [] = {973,0xFF01,0xFFF9,0,898,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_9 [] = {973,0xFF01,0xFFF9,0,898,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_10 [] = {973,0xFF01,0xFFF9,0,898,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_11 [] = {813,0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_12 [] = {0xFF01,330,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_13 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_14 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_15 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_16 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_17 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_18 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_19 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_20 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_21 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_22 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_23 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_24 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_25 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_26 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_27 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_28 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_29 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_30 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_31 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_32 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype332_33 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes332 [] = {
g_atype332_0,
g_atype332_1,
g_atype332_2,
g_atype332_3,
g_atype332_4,
g_atype332_5,
g_atype332_6,
g_atype332_7,
g_atype332_8,
g_atype332_9,
g_atype332_10,
g_atype332_11,
g_atype332_12,
g_atype332_13,
g_atype332_14,
g_atype332_15,
g_atype332_16,
g_atype332_17,
g_atype332_18,
g_atype332_19,
g_atype332_20,
g_atype332_21,
g_atype332_22,
g_atype332_23,
g_atype332_24,
g_atype332_25,
g_atype332_26,
g_atype332_27,
g_atype332_28,
g_atype332_29,
g_atype332_30,
g_atype332_31,
g_atype332_32,
g_atype332_33,
};

static const long offsets332 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
+ @CHROFF(13,0),
+ @CHROFF(13,1),
+ @CHROFF(13,2),
+ @CHROFF(13,3),
+ @CHROFF(13,4),
+ @CHROFF(13,5),
+ @CHROFF(13,6),
+ @CHROFF(13,7),
+ @CHROFF(13,8),
+ @CHROFF(13,9),
+ @CHROFF(13,10),
+ @CHROFF(13,11),
+ @CHROFF(13,12),
+ @CHROFF(13,13),
+ @CHROFF(13,14),
+ @CHROFF(13,15),
+ @LNGOFF(13,16,0,0),
+ @LNGOFF(13,16,0,1),
+ @LNGOFF(13,16,0,2),
+ @LNGOFF(13,16,0,3),
+ @LNGOFF(13,16,0,4),
};

extern const char *names335[];
static const uint32 types335 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR32,
};

static const uint16 attr_flags335 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype335_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_1 [] = {0xFF01,983,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_2 [] = {0xFF01,751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_3 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype335_4 [] = {933,0xFFFF};

static const EIF_TYPE_INDEX *gtypes335 [] = {
g_atype335_0,
g_atype335_1,
g_atype335_2,
g_atype335_3,
g_atype335_4,
};

static const long offsets335 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
};

extern const char *names336[];
static const uint32 types336 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags336 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype336_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype336_1 [] = {0xFF01,752,936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes336 [] = {
g_atype336_0,
g_atype336_1,
};

static const long offsets336 [] =
{
0,
 + @REFACS(1),
};

extern const char *names337[];
static const uint32 types337 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags337 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype337_0 [] = {0xFF01,319,0xFFFF};
static const EIF_TYPE_INDEX g_atype337_1 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes337 [] = {
g_atype337_0,
g_atype337_1,
};

static const long offsets337 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names338[];
static const uint32 types338 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags338 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype338_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_1 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_2 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_3 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_4 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_5 [] = {909,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_6 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_9 [] = {927,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_10 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_11 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype338_12 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes338 [] = {
g_atype338_0,
g_atype338_1,
g_atype338_2,
g_atype338_3,
g_atype338_4,
g_atype338_5,
g_atype338_6,
g_atype338_7,
g_atype338_8,
g_atype338_9,
g_atype338_10,
g_atype338_11,
g_atype338_12,
};

static const long offsets338 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
+ @CHROFF(1,2),
+ @I16OFF(1,3,0),
+ @I16OFF(1,3,1),
+ @LNGOFF(1,3,2,0),
+ @LNGOFF(1,3,2,1),
+ @LNGOFF(1,3,2,2),
+ @R32OFF(1,3,2,3,0),
+ @I64OFF(1,3,2,3,1,0,0),
+ @I64OFF(1,3,2,3,1,0,1),
+ @R64OFF(1,3,2,3,1,0,2,0),
};

extern const char *names339[];
static const uint32 types339 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags339 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype339_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_1 [] = {0xFF01,319,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_2 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_7 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_8 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_9 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_10 [] = {909,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_11 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_16 [] = {927,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_17 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_18 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype339_19 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes339 [] = {
g_atype339_0,
g_atype339_1,
g_atype339_2,
g_atype339_3,
g_atype339_4,
g_atype339_5,
g_atype339_6,
g_atype339_7,
g_atype339_8,
g_atype339_9,
g_atype339_10,
g_atype339_11,
g_atype339_12,
g_atype339_13,
g_atype339_14,
g_atype339_15,
g_atype339_16,
g_atype339_17,
g_atype339_18,
g_atype339_19,
};

static const long offsets339 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @CHROFF(2,3),
+ @CHROFF(2,4),
+ @CHROFF(2,5),
+ @CHROFF(2,6),
+ @I16OFF(2,7,0),
+ @I16OFF(2,7,1),
+ @LNGOFF(2,7,2,0),
+ @LNGOFF(2,7,2,1),
+ @LNGOFF(2,7,2,2),
+ @LNGOFF(2,7,2,3),
+ @LNGOFF(2,7,2,4),
+ @R32OFF(2,7,2,5,0),
+ @I64OFF(2,7,2,5,1,0,0),
+ @I64OFF(2,7,2,5,1,0,1),
+ @R64OFF(2,7,2,5,1,0,2,0),
};

extern const char *names341[];
static const uint32 types341 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags341 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype341_0 [] = {0xFF01,1310,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_1 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_2 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_3 [] = {340,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_4 [] = {0xFF01,844,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_5 [] = {842,340,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_6 [] = {842,0xFF01,342,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_7 [] = {0xFF01,0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_9 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_10 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_11 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype341_14 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes341 [] = {
g_atype341_0,
g_atype341_1,
g_atype341_2,
g_atype341_3,
g_atype341_4,
g_atype341_5,
g_atype341_6,
g_atype341_7,
g_atype341_8,
g_atype341_9,
g_atype341_10,
g_atype341_11,
g_atype341_12,
g_atype341_13,
g_atype341_14,
};

static const long offsets341 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
+ @LNGOFF(8,4,0,0),
+ @LNGOFF(8,4,0,1),
+ @LNGOFF(8,4,0,2),
};

extern const char *names343[];
static const uint32 types343 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags343 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype343_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype343_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes343 [] = {
g_atype343_0,
g_atype343_1,
g_atype343_2,
};

static const long offsets343 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names344[];
static const uint32 types344 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags344 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype344_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_1 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype344_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes344 [] = {
g_atype344_0,
g_atype344_1,
g_atype344_2,
g_atype344_3,
g_atype344_4,
g_atype344_5,
};

static const long offsets344 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names345[];
static const uint32 types345 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags345 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype345_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_1 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype345_5 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes345 [] = {
g_atype345_0,
g_atype345_1,
g_atype345_2,
g_atype345_3,
g_atype345_4,
g_atype345_5,
};

static const long offsets345 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @PTROFF(1,0,0,4,0,0),
};

extern const char *names346[];
static const uint32 types346 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags346 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype346_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_1 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype346_5 [] = {915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes346 [] = {
g_atype346_0,
g_atype346_1,
g_atype346_2,
g_atype346_3,
g_atype346_4,
g_atype346_5,
};

static const long offsets346 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names347[];
static const uint32 types347 [] =
{
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags347 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype347_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_1 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype347_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes347 [] = {
g_atype347_0,
g_atype347_1,
g_atype347_2,
g_atype347_3,
g_atype347_4,
g_atype347_5,
};

static const long offsets347 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names348[];
static const uint32 types348 [] =
{
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags348 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype348_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_1 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype348_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes348 [] = {
g_atype348_0,
g_atype348_1,
g_atype348_2,
g_atype348_3,
g_atype348_4,
g_atype348_5,
};

static const long offsets348 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names349[];
static const uint32 types349 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags349 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype349_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_1 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype349_5 [] = {927,0xFFFF};

static const EIF_TYPE_INDEX *gtypes349 [] = {
g_atype349_0,
g_atype349_1,
g_atype349_2,
g_atype349_3,
g_atype349_4,
g_atype349_5,
};

static const long offsets349 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R32OFF(1,0,0,4,0),
};

extern const char *names350[];
static const uint32 types350 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags350 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype350_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_1 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype350_5 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes350 [] = {
g_atype350_0,
g_atype350_1,
g_atype350_2,
g_atype350_3,
g_atype350_4,
g_atype350_5,
};

static const long offsets350 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @R64OFF(1,0,0,4,0,0,0,0),
};

extern const char *names351[];
static const uint32 types351 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags351 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype351_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype351_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes351 [] = {
g_atype351_0,
g_atype351_1,
g_atype351_2,
g_atype351_3,
g_atype351_4,
g_atype351_5,
};

static const long offsets351 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names352[];
static const uint32 types352 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags352 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype352_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_1 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype352_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes352 [] = {
g_atype352_0,
g_atype352_1,
g_atype352_2,
g_atype352_3,
g_atype352_4,
g_atype352_5,
};

static const long offsets352 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names353[];
static const uint32 types353 [] =
{
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags353 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype353_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_1 [] = {933,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype353_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes353 [] = {
g_atype353_0,
g_atype353_1,
g_atype353_2,
g_atype353_3,
g_atype353_4,
g_atype353_5,
};

static const long offsets353 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @LNGOFF(1,0,0,4),
};

extern const char *names354[];
static const uint32 types354 [] =
{
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags354 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype354_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_1 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype354_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes354 [] = {
g_atype354_0,
g_atype354_1,
g_atype354_2,
g_atype354_3,
g_atype354_4,
g_atype354_5,
};

static const long offsets354 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names355[];
static const uint32 types355 [] =
{
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags355 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype355_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_1 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype355_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes355 [] = {
g_atype355_0,
g_atype355_1,
g_atype355_2,
g_atype355_3,
g_atype355_4,
g_atype355_5,
};

static const long offsets355 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
};

extern const char *names356[];
static const uint32 types356 [] =
{
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags356 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype356_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype356_1 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype356_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype356_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype356_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype356_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes356 [] = {
g_atype356_0,
g_atype356_1,
g_atype356_2,
g_atype356_3,
g_atype356_4,
g_atype356_5,
};

static const long offsets356 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names357[];
static const uint32 types357 [] =
{
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags357 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype357_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_1 [] = {909,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype357_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes357 [] = {
g_atype357_0,
g_atype357_1,
g_atype357_2,
g_atype357_3,
g_atype357_4,
g_atype357_5,
};

static const long offsets357 [] =
{
0,
+ @I16OFF(1,0,0),
+ @LNGOFF(1,0,1,0),
+ @LNGOFF(1,0,1,1),
+ @LNGOFF(1,0,1,2),
+ @LNGOFF(1,0,1,3),
};

extern const char *names358[];
static const uint32 types358 [] =
{
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags358 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype358_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_1 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype358_5 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes358 [] = {
g_atype358_0,
g_atype358_1,
g_atype358_2,
g_atype358_3,
g_atype358_4,
g_atype358_5,
};

static const long offsets358 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
+ @I64OFF(1,0,0,4,0,0,0),
};

extern const char *names359[];
static const uint32 types359 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags359 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype359_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_3 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype359_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes359 [] = {
g_atype359_0,
g_atype359_1,
g_atype359_2,
g_atype359_3,
g_atype359_4,
g_atype359_5,
};

static const long offsets359 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
+ @LNGOFF(3,0,0,2),
};

extern const char *names360[];
static const uint32 types360 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags360 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype360_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype360_5 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes360 [] = {
g_atype360_0,
g_atype360_1,
g_atype360_2,
g_atype360_3,
g_atype360_4,
g_atype360_5,
};

static const long offsets360 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @PTROFF(2,0,0,3,0,0),
};

extern const char *names361[];
static const uint32 types361 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags361 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype361_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_3 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype361_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes361 [] = {
g_atype361_0,
g_atype361_1,
g_atype361_2,
g_atype361_3,
g_atype361_4,
g_atype361_5,
};

static const long offsets361 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names362[];
static const uint32 types362 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags362 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype362_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_2 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_3 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype362_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes362 [] = {
g_atype362_0,
g_atype362_1,
g_atype362_2,
g_atype362_3,
g_atype362_4,
g_atype362_5,
};

static const long offsets362 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names363[];
static const uint32 types363 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags363 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype363_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype363_5 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes363 [] = {
g_atype363_0,
g_atype363_1,
g_atype363_2,
g_atype363_3,
g_atype363_4,
g_atype363_5,
};

static const long offsets363 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R64OFF(2,0,0,3,0,0,0,0),
};

extern const char *names364[];
static const uint32 types364 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags364 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype364_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype364_5 [] = {927,0xFFFF};

static const EIF_TYPE_INDEX *gtypes364 [] = {
g_atype364_0,
g_atype364_1,
g_atype364_2,
g_atype364_3,
g_atype364_4,
g_atype364_5,
};

static const long offsets364 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @R32OFF(2,0,0,3,0),
};

extern const char *names365[];
static const uint32 types365 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags365 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype365_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_2 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_3 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype365_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes365 [] = {
g_atype365_0,
g_atype365_1,
g_atype365_2,
g_atype365_3,
g_atype365_4,
g_atype365_5,
};

static const long offsets365 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names366[];
static const uint32 types366 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags366 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype366_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_2 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_3 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype366_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes366 [] = {
g_atype366_0,
g_atype366_1,
g_atype366_2,
g_atype366_3,
g_atype366_4,
g_atype366_5,
};

static const long offsets366 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names367[];
static const uint32 types367 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags367 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype367_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_3 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype367_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes367 [] = {
g_atype367_0,
g_atype367_1,
g_atype367_2,
g_atype367_3,
g_atype367_4,
g_atype367_5,
};

static const long offsets367 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names368[];
static const uint32 types368 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags368 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype368_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype368_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes368 [] = {
g_atype368_0,
g_atype368_1,
g_atype368_2,
g_atype368_3,
g_atype368_4,
g_atype368_5,
};

static const long offsets368 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names369[];
static const uint32 types369 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags369 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype369_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype369_5 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes369 [] = {
g_atype369_0,
g_atype369_1,
g_atype369_2,
g_atype369_3,
g_atype369_4,
g_atype369_5,
};

static const long offsets369 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names370[];
static const uint32 types370 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags370 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype370_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_2 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_3 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype370_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes370 [] = {
g_atype370_0,
g_atype370_1,
g_atype370_2,
g_atype370_3,
g_atype370_4,
g_atype370_5,
};

static const long offsets370 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
};

extern const char *names371[];
static const uint32 types371 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags371 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype371_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype371_5 [] = {915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes371 [] = {
g_atype371_0,
g_atype371_1,
g_atype371_2,
g_atype371_3,
g_atype371_4,
g_atype371_5,
};

static const long offsets371 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @I64OFF(2,0,0,3,0,0,0),
};

extern const char *names372[];
static const uint32 types372 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags372 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype372_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_2 [] = {909,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_3 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype372_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes372 [] = {
g_atype372_0,
g_atype372_1,
g_atype372_2,
g_atype372_3,
g_atype372_4,
g_atype372_5,
};

static const long offsets372 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
+ @LNGOFF(2,0,1,2),
};

extern const char *names373[];
static const uint32 types373 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags373 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype373_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_2 [] = {933,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_3 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype373_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes373 [] = {
g_atype373_0,
g_atype373_1,
g_atype373_2,
g_atype373_3,
g_atype373_4,
g_atype373_5,
};

static const long offsets373 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
};

extern const char *names374[];
static const uint32 types374 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags374 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype374_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_2 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype374_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes374 [] = {
g_atype374_0,
g_atype374_1,
g_atype374_2,
g_atype374_3,
g_atype374_4,
};

static const long offsets374 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names375[];
static const uint32 types375 [] =
{
SK_REF,
SK_REF,
SK_INT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags375 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype375_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_2 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype375_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes375 [] = {
g_atype375_0,
g_atype375_1,
g_atype375_2,
g_atype375_3,
g_atype375_4,
};

static const long offsets375 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names376[];
static const uint32 types376 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags376 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype376_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype376_4 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes376 [] = {
g_atype376_0,
g_atype376_1,
g_atype376_2,
g_atype376_3,
g_atype376_4,
};

static const long offsets376 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @PTROFF(2,0,0,2,0,0),
};

extern const char *names377[];
static const uint32 types377 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL64,
};

static const uint16 attr_flags377 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype377_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype377_4 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes377 [] = {
g_atype377_0,
g_atype377_1,
g_atype377_2,
g_atype377_3,
g_atype377_4,
};

static const long offsets377 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R64OFF(2,0,0,2,0,0,0,0),
};

extern const char *names378[];
static const uint32 types378 [] =
{
SK_REF,
SK_REF,
SK_UINT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags378 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype378_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype378_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes378 [] = {
g_atype378_0,
g_atype378_1,
g_atype378_2,
g_atype378_3,
g_atype378_4,
};

static const long offsets378 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names379[];
static const uint32 types379 [] =
{
SK_REF,
SK_REF,
SK_UINT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags379 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype379_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_2 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype379_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes379 [] = {
g_atype379_0,
g_atype379_1,
g_atype379_2,
g_atype379_3,
g_atype379_4,
};

static const long offsets379 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names380[];
static const uint32 types380 [] =
{
SK_REF,
SK_REF,
SK_UINT8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags380 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype380_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_2 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype380_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes380 [] = {
g_atype380_0,
g_atype380_1,
g_atype380_2,
g_atype380_3,
g_atype380_4,
};

static const long offsets380 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names381[];
static const uint32 types381 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_REAL32,
};

static const uint16 attr_flags381 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype381_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype381_4 [] = {927,0xFFFF};

static const EIF_TYPE_INDEX *gtypes381 [] = {
g_atype381_0,
g_atype381_1,
g_atype381_2,
g_atype381_3,
g_atype381_4,
};

static const long offsets381 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @R32OFF(2,0,0,2,0),
};

extern const char *names382[];
static const uint32 types382 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags382 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype382_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype382_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes382 [] = {
g_atype382_0,
g_atype382_1,
g_atype382_2,
g_atype382_3,
g_atype382_4,
};

static const long offsets382 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names383[];
static const uint32 types383 [] =
{
SK_REF,
SK_REF,
SK_INT16,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags383 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype383_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_2 [] = {909,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype383_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes383 [] = {
g_atype383_0,
g_atype383_1,
g_atype383_2,
g_atype383_3,
g_atype383_4,
};

static const long offsets383 [] =
{
0,
 + @REFACS(1),
+ @I16OFF(2,0,0),
+ @LNGOFF(2,0,1,0),
+ @LNGOFF(2,0,1,1),
};

extern const char *names384[];
static const uint32 types384 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_UINT64,
};

static const uint16 attr_flags384 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype384_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype384_4 [] = {915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes384 [] = {
g_atype384_0,
g_atype384_1,
g_atype384_2,
g_atype384_3,
g_atype384_4,
};

static const long offsets384 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names385[];
static const uint32 types385 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags385 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype385_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype385_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes385 [] = {
g_atype385_0,
g_atype385_1,
g_atype385_2,
g_atype385_3,
g_atype385_4,
};

static const long offsets385 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names386[];
static const uint32 types386 [] =
{
SK_REF,
SK_REF,
SK_CHAR32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags386 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype386_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_2 [] = {933,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype386_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes386 [] = {
g_atype386_0,
g_atype386_1,
g_atype386_2,
g_atype386_3,
g_atype386_4,
};

static const long offsets386 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names387[];
static const uint32 types387 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags387 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype387_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype387_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype387_2 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype387_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype387_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes387 [] = {
g_atype387_0,
g_atype387_1,
g_atype387_2,
g_atype387_3,
g_atype387_4,
};

static const long offsets387 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
};

extern const char *names388[];
static const uint32 types388 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT64,
};

static const uint16 attr_flags388 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype388_0 [] = {0xFFF9,2,898,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_1 [] = {0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype388_4 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes388 [] = {
g_atype388_0,
g_atype388_1,
g_atype388_2,
g_atype388_3,
g_atype388_4,
};

static const long offsets388 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @I64OFF(2,0,0,2,0,0,0),
};

extern const char *names402[];
static const uint32 types402 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags402 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype402_0 [] = {0xFF01,746,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype402_1 [] = {0xFFF5,1,0xFF01,746,0xFFF8,1,3773,0xFFFF};
static const EIF_TYPE_INDEX g_atype402_2 [] = {0xFFF5,1,0xFF01,841,0xFFF8,1,3919,0xFFFF};

static const EIF_TYPE_INDEX *gtypes402 [] = {
g_atype402_0,
g_atype402_1,
g_atype402_2,
};

static const long offsets402 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names403[];
static const uint32 types403 [] =
{
SK_UINT8,
SK_POINTER,
};

static const uint16 attr_flags403 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype403_0 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype403_1 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes403 [] = {
g_atype403_0,
g_atype403_1,
};

static const long offsets403 [] =
{
+ @CHROFF(0,0),
+ @PTROFF(0,1,0,0,0,0),
};

extern const char *names426[];
static const uint32 types426 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags426 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype426_0 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype426_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype426_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype426_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes426 [] = {
g_atype426_0,
g_atype426_1,
g_atype426_2,
g_atype426_3,
};

static const long offsets426 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names428[];
static const uint32 types428 [] =
{
SK_REF,
};

static const uint16 attr_flags428 [] =
{0,};

static const EIF_TYPE_INDEX g_atype428_0 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes428 [] = {
g_atype428_0,
};

static const long offsets428 [] =
{
0,
};

extern const char *names458[];
static const uint32 types458 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags458 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype458_0 [] = {0xFF01,734,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype458_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes458 [] = {
g_atype458_0,
g_atype458_1,
g_atype458_2,
g_atype458_3,
g_atype458_4,
g_atype458_5,
g_atype458_6,
};

static const long offsets458 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names459[];
static const uint32 types459 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags459 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype459_0 [] = {0xFF01,735,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype459_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes459 [] = {
g_atype459_0,
g_atype459_1,
g_atype459_2,
g_atype459_3,
g_atype459_4,
g_atype459_5,
g_atype459_6,
};

static const long offsets459 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names460[];
static const uint32 types460 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags460 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype460_0 [] = {0xFF01,736,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype460_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes460 [] = {
g_atype460_0,
g_atype460_1,
g_atype460_2,
g_atype460_3,
g_atype460_4,
g_atype460_5,
g_atype460_6,
};

static const long offsets460 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names461[];
static const uint32 types461 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags461 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype461_0 [] = {0xFF01,737,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype461_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes461 [] = {
g_atype461_0,
g_atype461_1,
g_atype461_2,
g_atype461_3,
g_atype461_4,
g_atype461_5,
g_atype461_6,
};

static const long offsets461 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names462[];
static const uint32 types462 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags462 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype462_0 [] = {0xFF01,738,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype462_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype462_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype462_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype462_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype462_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype462_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes462 [] = {
g_atype462_0,
g_atype462_1,
g_atype462_2,
g_atype462_3,
g_atype462_4,
g_atype462_5,
g_atype462_6,
};

static const long offsets462 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names463[];
static const uint32 types463 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags463 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype463_0 [] = {0xFF01,739,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype463_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype463_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype463_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype463_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype463_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype463_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes463 [] = {
g_atype463_0,
g_atype463_1,
g_atype463_2,
g_atype463_3,
g_atype463_4,
g_atype463_5,
g_atype463_6,
};

static const long offsets463 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names464[];
static const uint32 types464 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags464 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype464_0 [] = {0xFF01,740,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype464_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype464_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype464_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype464_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype464_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype464_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes464 [] = {
g_atype464_0,
g_atype464_1,
g_atype464_2,
g_atype464_3,
g_atype464_4,
g_atype464_5,
g_atype464_6,
};

static const long offsets464 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names465[];
static const uint32 types465 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags465 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype465_0 [] = {0xFF01,741,924,0xFFFF};
static const EIF_TYPE_INDEX g_atype465_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype465_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype465_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype465_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype465_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype465_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes465 [] = {
g_atype465_0,
g_atype465_1,
g_atype465_2,
g_atype465_3,
g_atype465_4,
g_atype465_5,
g_atype465_6,
};

static const long offsets465 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names466[];
static const uint32 types466 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags466 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype466_0 [] = {0xFF01,742,921,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype466_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes466 [] = {
g_atype466_0,
g_atype466_1,
g_atype466_2,
g_atype466_3,
g_atype466_4,
g_atype466_5,
g_atype466_6,
};

static const long offsets466 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names467[];
static const uint32 types467 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags467 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype467_0 [] = {0xFF01,743,972,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype467_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes467 [] = {
g_atype467_0,
g_atype467_1,
g_atype467_2,
g_atype467_3,
g_atype467_4,
g_atype467_5,
g_atype467_6,
};

static const long offsets467 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names468[];
static const uint32 types468 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags468 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype468_0 [] = {0xFF01,744,927,0xFFFF};
static const EIF_TYPE_INDEX g_atype468_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype468_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype468_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype468_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype468_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype468_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes468 [] = {
g_atype468_0,
g_atype468_1,
g_atype468_2,
g_atype468_3,
g_atype468_4,
g_atype468_5,
g_atype468_6,
};

static const long offsets468 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names469[];
static const uint32 types469 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags469 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype469_0 [] = {0xFF01,745,930,0xFFFF};
static const EIF_TYPE_INDEX g_atype469_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype469_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype469_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype469_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype469_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype469_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes469 [] = {
g_atype469_0,
g_atype469_1,
g_atype469_2,
g_atype469_3,
g_atype469_4,
g_atype469_5,
g_atype469_6,
};

static const long offsets469 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names470[];
static const uint32 types470 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags470 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype470_0 [] = {0xFF01,837,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype470_1 [] = {126,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype470_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype470_3 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype470_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype470_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype470_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype470_7 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes470 [] = {
g_atype470_0,
g_atype470_1,
g_atype470_2,
g_atype470_3,
g_atype470_4,
g_atype470_5,
g_atype470_6,
g_atype470_7,
};

static const long offsets470 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names471[];
static const uint32 types471 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags471 [] =
{0,0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype471_0 [] = {0xFF01,838,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype471_1 [] = {127,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype471_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype471_3 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype471_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype471_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype471_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype471_7 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes471 [] = {
g_atype471_0,
g_atype471_1,
g_atype471_2,
g_atype471_3,
g_atype471_4,
g_atype471_5,
g_atype471_6,
g_atype471_7,
};

static const long offsets471 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @LNGOFF(2,1,0,0),
+ @LNGOFF(2,1,0,1),
+ @LNGOFF(2,1,0,2),
+ @LNGOFF(2,1,0,3),
+ @LNGOFF(2,1,0,4),
};

extern const char *names472[];
static const uint32 types472 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags472 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype472_0 [] = {0xFF01,854,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype472_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype472_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype472_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype472_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype472_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype472_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes472 [] = {
g_atype472_0,
g_atype472_1,
g_atype472_2,
g_atype472_3,
g_atype472_4,
g_atype472_5,
g_atype472_6,
};

static const long offsets472 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names473[];
static const uint32 types473 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags473 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype473_0 [] = {0xFF01,855,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype473_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype473_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype473_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype473_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype473_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype473_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes473 [] = {
g_atype473_0,
g_atype473_1,
g_atype473_2,
g_atype473_3,
g_atype473_4,
g_atype473_5,
g_atype473_6,
};

static const long offsets473 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names474[];
static const uint32 types474 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags474 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype474_0 [] = {0xFF01,856,0xFFF8,1,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype474_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype474_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype474_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype474_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype474_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype474_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes474 [] = {
g_atype474_0,
g_atype474_1,
g_atype474_2,
g_atype474_3,
g_atype474_4,
g_atype474_5,
g_atype474_6,
};

static const long offsets474 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names475[];
static const uint32 types475 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags475 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype475_0 [] = {0xFF01,857,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype475_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype475_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype475_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype475_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype475_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype475_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes475 [] = {
g_atype475_0,
g_atype475_1,
g_atype475_2,
g_atype475_3,
g_atype475_4,
g_atype475_5,
g_atype475_6,
};

static const long offsets475 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names476[];
static const uint32 types476 [] =
{
SK_REF,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags476 [] =
{0,0,1,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype476_0 [] = {0xFF01,858,972,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype476_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype476_2 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype476_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype476_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype476_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype476_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes476 [] = {
g_atype476_0,
g_atype476_1,
g_atype476_2,
g_atype476_3,
g_atype476_4,
g_atype476_5,
g_atype476_6,
};

static const long offsets476 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
};

extern const char *names477[];
static const uint32 types477 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags477 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype477_0 [] = {0xFF01,746,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype477_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype477_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes477 [] = {
g_atype477_0,
g_atype477_1,
g_atype477_2,
};

static const long offsets477 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names478[];
static const uint32 types478 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags478 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype478_0 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype478_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype478_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes478 [] = {
g_atype478_0,
g_atype478_1,
g_atype478_2,
};

static const long offsets478 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names479[];
static const uint32 types479 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags479 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype479_0 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype479_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype479_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes479 [] = {
g_atype479_0,
g_atype479_1,
g_atype479_2,
};

static const long offsets479 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names480[];
static const uint32 types480 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags480 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype480_0 [] = {0xFF01,749,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype480_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype480_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes480 [] = {
g_atype480_0,
g_atype480_1,
g_atype480_2,
};

static const long offsets480 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names481[];
static const uint32 types481 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags481 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype481_0 [] = {0xFF01,750,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype481_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype481_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes481 [] = {
g_atype481_0,
g_atype481_1,
g_atype481_2,
};

static const long offsets481 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names482[];
static const uint32 types482 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags482 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype482_0 [] = {0xFF01,751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype482_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype482_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes482 [] = {
g_atype482_0,
g_atype482_1,
g_atype482_2,
};

static const long offsets482 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names483[];
static const uint32 types483 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags483 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype483_0 [] = {0xFF01,752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype483_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes483 [] = {
g_atype483_0,
g_atype483_1,
g_atype483_2,
};

static const long offsets483 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names484[];
static const uint32 types484 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags484 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype484_0 [] = {0xFF01,753,924,0xFFFF};
static const EIF_TYPE_INDEX g_atype484_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype484_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes484 [] = {
g_atype484_0,
g_atype484_1,
g_atype484_2,
};

static const long offsets484 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names485[];
static const uint32 types485 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags485 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype485_0 [] = {0xFF01,754,921,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype485_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes485 [] = {
g_atype485_0,
g_atype485_1,
g_atype485_2,
};

static const long offsets485 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names486[];
static const uint32 types486 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags486 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype486_0 [] = {0xFF01,755,972,0xFFFF};
static const EIF_TYPE_INDEX g_atype486_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype486_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes486 [] = {
g_atype486_0,
g_atype486_1,
g_atype486_2,
};

static const long offsets486 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names487[];
static const uint32 types487 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags487 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype487_0 [] = {0xFF01,756,927,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype487_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes487 [] = {
g_atype487_0,
g_atype487_1,
g_atype487_2,
};

static const long offsets487 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names488[];
static const uint32 types488 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags488 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype488_0 [] = {0xFF01,757,930,0xFFFF};
static const EIF_TYPE_INDEX g_atype488_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype488_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes488 [] = {
g_atype488_0,
g_atype488_1,
g_atype488_2,
};

static const long offsets488 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names489[];
static const uint32 types489 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags489 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype489_0 [] = {0xFF01,746,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_1 [] = {0xFF01,842,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype489_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes489 [] = {
g_atype489_0,
g_atype489_1,
g_atype489_2,
g_atype489_3,
};

static const long offsets489 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names490[];
static const uint32 types490 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags490 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype490_0 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype490_1 [] = {0xFF01,843,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype490_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype490_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes490 [] = {
g_atype490_0,
g_atype490_1,
g_atype490_2,
g_atype490_3,
};

static const long offsets490 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names491[];
static const uint32 types491 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags491 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype491_0 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_1 [] = {0xFF01,844,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype491_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes491 [] = {
g_atype491_0,
g_atype491_1,
g_atype491_2,
g_atype491_3,
};

static const long offsets491 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names492[];
static const uint32 types492 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags492 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype492_0 [] = {0xFF01,749,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype492_1 [] = {0xFF01,845,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype492_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype492_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes492 [] = {
g_atype492_0,
g_atype492_1,
g_atype492_2,
g_atype492_3,
};

static const long offsets492 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names493[];
static const uint32 types493 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags493 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype493_0 [] = {0xFF01,750,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_1 [] = {0xFF01,846,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype493_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes493 [] = {
g_atype493_0,
g_atype493_1,
g_atype493_2,
g_atype493_3,
};

static const long offsets493 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names494[];
static const uint32 types494 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags494 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype494_0 [] = {0xFF01,751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype494_1 [] = {0xFF01,847,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype494_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype494_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes494 [] = {
g_atype494_0,
g_atype494_1,
g_atype494_2,
g_atype494_3,
};

static const long offsets494 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names495[];
static const uint32 types495 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags495 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype495_0 [] = {0xFF01,752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_1 [] = {0xFF01,848,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype495_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes495 [] = {
g_atype495_0,
g_atype495_1,
g_atype495_2,
g_atype495_3,
};

static const long offsets495 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names496[];
static const uint32 types496 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags496 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype496_0 [] = {0xFF01,753,924,0xFFFF};
static const EIF_TYPE_INDEX g_atype496_1 [] = {0xFF01,849,924,0xFFFF};
static const EIF_TYPE_INDEX g_atype496_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype496_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes496 [] = {
g_atype496_0,
g_atype496_1,
g_atype496_2,
g_atype496_3,
};

static const long offsets496 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names497[];
static const uint32 types497 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags497 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype497_0 [] = {0xFF01,754,921,0xFFFF};
static const EIF_TYPE_INDEX g_atype497_1 [] = {0xFF01,850,921,0xFFFF};
static const EIF_TYPE_INDEX g_atype497_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype497_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes497 [] = {
g_atype497_0,
g_atype497_1,
g_atype497_2,
g_atype497_3,
};

static const long offsets497 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names498[];
static const uint32 types498 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags498 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype498_0 [] = {0xFF01,755,972,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_1 [] = {0xFF01,851,972,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype498_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes498 [] = {
g_atype498_0,
g_atype498_1,
g_atype498_2,
g_atype498_3,
};

static const long offsets498 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names499[];
static const uint32 types499 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags499 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype499_0 [] = {0xFF01,756,927,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_1 [] = {0xFF01,852,927,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype499_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes499 [] = {
g_atype499_0,
g_atype499_1,
g_atype499_2,
g_atype499_3,
};

static const long offsets499 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names500[];
static const uint32 types500 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags500 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype500_0 [] = {0xFF01,757,930,0xFFFF};
static const EIF_TYPE_INDEX g_atype500_1 [] = {0xFF01,853,930,0xFFFF};
static const EIF_TYPE_INDEX g_atype500_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype500_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes500 [] = {
g_atype500_0,
g_atype500_1,
g_atype500_2,
g_atype500_3,
};

static const long offsets500 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names501[];
static const uint32 types501 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags501 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype501_0 [] = {0xFF01,751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype501_1 [] = {0xFF01,981,0xFFFF};
static const EIF_TYPE_INDEX g_atype501_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype501_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype501_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes501 [] = {
g_atype501_0,
g_atype501_1,
g_atype501_2,
g_atype501_3,
g_atype501_4,
};

static const long offsets501 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names502[];
static const uint32 types502 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags502 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype502_0 [] = {0xFF01,752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype502_1 [] = {0xFF01,984,0xFFFF};
static const EIF_TYPE_INDEX g_atype502_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype502_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype502_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes502 [] = {
g_atype502_0,
g_atype502_1,
g_atype502_2,
g_atype502_3,
g_atype502_4,
};

static const long offsets502 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names503[];
static const uint32 types503 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags503 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype503_0 [] = {0xFF01,746,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype503_1 [] = {0xFF01,771,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype503_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype503_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype503_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes503 [] = {
g_atype503_0,
g_atype503_1,
g_atype503_2,
g_atype503_3,
g_atype503_4,
};

static const long offsets503 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names504[];
static const uint32 types504 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags504 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype504_0 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype504_1 [] = {0xFF01,772,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype504_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype504_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype504_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes504 [] = {
g_atype504_0,
g_atype504_1,
g_atype504_2,
g_atype504_3,
g_atype504_4,
};

static const long offsets504 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names505[];
static const uint32 types505 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags505 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype505_0 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype505_1 [] = {0xFF01,773,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype505_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype505_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype505_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes505 [] = {
g_atype505_0,
g_atype505_1,
g_atype505_2,
g_atype505_3,
g_atype505_4,
};

static const long offsets505 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names506[];
static const uint32 types506 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags506 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype506_0 [] = {0xFF01,749,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype506_1 [] = {0xFF01,774,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype506_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype506_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype506_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes506 [] = {
g_atype506_0,
g_atype506_1,
g_atype506_2,
g_atype506_3,
g_atype506_4,
};

static const long offsets506 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names507[];
static const uint32 types507 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags507 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype507_0 [] = {0xFF01,750,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype507_1 [] = {0xFF01,775,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype507_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype507_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype507_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes507 [] = {
g_atype507_0,
g_atype507_1,
g_atype507_2,
g_atype507_3,
g_atype507_4,
};

static const long offsets507 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names508[];
static const uint32 types508 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags508 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype508_0 [] = {0xFF01,751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype508_1 [] = {0xFF01,776,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype508_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype508_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype508_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes508 [] = {
g_atype508_0,
g_atype508_1,
g_atype508_2,
g_atype508_3,
g_atype508_4,
};

static const long offsets508 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names509[];
static const uint32 types509 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags509 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype509_0 [] = {0xFF01,752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype509_1 [] = {0xFF01,777,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype509_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype509_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype509_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes509 [] = {
g_atype509_0,
g_atype509_1,
g_atype509_2,
g_atype509_3,
g_atype509_4,
};

static const long offsets509 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names510[];
static const uint32 types510 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags510 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype510_0 [] = {0xFF01,753,924,0xFFFF};
static const EIF_TYPE_INDEX g_atype510_1 [] = {0xFF01,778,924,0xFFFF};
static const EIF_TYPE_INDEX g_atype510_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype510_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype510_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes510 [] = {
g_atype510_0,
g_atype510_1,
g_atype510_2,
g_atype510_3,
g_atype510_4,
};

static const long offsets510 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names511[];
static const uint32 types511 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags511 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype511_0 [] = {0xFF01,754,921,0xFFFF};
static const EIF_TYPE_INDEX g_atype511_1 [] = {0xFF01,779,921,0xFFFF};
static const EIF_TYPE_INDEX g_atype511_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype511_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype511_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes511 [] = {
g_atype511_0,
g_atype511_1,
g_atype511_2,
g_atype511_3,
g_atype511_4,
};

static const long offsets511 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names512[];
static const uint32 types512 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags512 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype512_0 [] = {0xFF01,755,972,0xFFFF};
static const EIF_TYPE_INDEX g_atype512_1 [] = {0xFF01,780,972,0xFFFF};
static const EIF_TYPE_INDEX g_atype512_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype512_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype512_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes512 [] = {
g_atype512_0,
g_atype512_1,
g_atype512_2,
g_atype512_3,
g_atype512_4,
};

static const long offsets512 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names513[];
static const uint32 types513 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags513 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype513_0 [] = {0xFF01,756,927,0xFFFF};
static const EIF_TYPE_INDEX g_atype513_1 [] = {0xFF01,781,927,0xFFFF};
static const EIF_TYPE_INDEX g_atype513_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype513_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype513_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes513 [] = {
g_atype513_0,
g_atype513_1,
g_atype513_2,
g_atype513_3,
g_atype513_4,
};

static const long offsets513 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names514[];
static const uint32 types514 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags514 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype514_0 [] = {0xFF01,757,930,0xFFFF};
static const EIF_TYPE_INDEX g_atype514_1 [] = {0xFF01,782,930,0xFFFF};
static const EIF_TYPE_INDEX g_atype514_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype514_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype514_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes514 [] = {
g_atype514_0,
g_atype514_1,
g_atype514_2,
g_atype514_3,
g_atype514_4,
};

static const long offsets514 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
};

extern const char *names515[];
static const uint32 types515 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags515 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype515_0 [] = {0xFF01,746,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype515_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype515_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes515 [] = {
g_atype515_0,
g_atype515_1,
g_atype515_2,
};

static const long offsets515 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names516[];
static const uint32 types516 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags516 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype516_0 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype516_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype516_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes516 [] = {
g_atype516_0,
g_atype516_1,
g_atype516_2,
};

static const long offsets516 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names517[];
static const uint32 types517 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags517 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype517_0 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype517_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype517_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes517 [] = {
g_atype517_0,
g_atype517_1,
g_atype517_2,
};

static const long offsets517 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names518[];
static const uint32 types518 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags518 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype518_0 [] = {0xFF01,749,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype518_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype518_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes518 [] = {
g_atype518_0,
g_atype518_1,
g_atype518_2,
};

static const long offsets518 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names519[];
static const uint32 types519 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags519 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype519_0 [] = {0xFF01,750,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype519_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype519_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes519 [] = {
g_atype519_0,
g_atype519_1,
g_atype519_2,
};

static const long offsets519 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names520[];
static const uint32 types520 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags520 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype520_0 [] = {0xFF01,751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype520_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype520_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes520 [] = {
g_atype520_0,
g_atype520_1,
g_atype520_2,
};

static const long offsets520 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names521[];
static const uint32 types521 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags521 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype521_0 [] = {0xFF01,752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype521_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype521_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes521 [] = {
g_atype521_0,
g_atype521_1,
g_atype521_2,
};

static const long offsets521 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names522[];
static const uint32 types522 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags522 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype522_0 [] = {0xFF01,753,924,0xFFFF};
static const EIF_TYPE_INDEX g_atype522_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype522_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes522 [] = {
g_atype522_0,
g_atype522_1,
g_atype522_2,
};

static const long offsets522 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names523[];
static const uint32 types523 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags523 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype523_0 [] = {0xFF01,754,921,0xFFFF};
static const EIF_TYPE_INDEX g_atype523_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype523_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes523 [] = {
g_atype523_0,
g_atype523_1,
g_atype523_2,
};

static const long offsets523 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names524[];
static const uint32 types524 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags524 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype524_0 [] = {0xFF01,755,972,0xFFFF};
static const EIF_TYPE_INDEX g_atype524_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype524_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes524 [] = {
g_atype524_0,
g_atype524_1,
g_atype524_2,
};

static const long offsets524 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names525[];
static const uint32 types525 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags525 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype525_0 [] = {0xFF01,756,927,0xFFFF};
static const EIF_TYPE_INDEX g_atype525_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype525_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes525 [] = {
g_atype525_0,
g_atype525_1,
g_atype525_2,
};

static const long offsets525 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names526[];
static const uint32 types526 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags526 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype526_0 [] = {0xFF01,757,930,0xFFFF};
static const EIF_TYPE_INDEX g_atype526_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype526_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes526 [] = {
g_atype526_0,
g_atype526_1,
g_atype526_2,
};

static const long offsets526 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
};

extern const char *names527[];
static const uint32 types527 [] =
{
SK_BOOL,
};

static const uint16 attr_flags527 [] =
{0,};

static const EIF_TYPE_INDEX g_atype527_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes527 [] = {
g_atype527_0,
};

static const long offsets527 [] =
{
+ @CHROFF(0,0),
};

extern const char *names528[];
static const uint32 types528 [] =
{
SK_BOOL,
};

static const uint16 attr_flags528 [] =
{0,};

static const EIF_TYPE_INDEX g_atype528_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes528 [] = {
g_atype528_0,
};

static const long offsets528 [] =
{
+ @CHROFF(0,0),
};

extern const char *names529[];
static const uint32 types529 [] =
{
SK_BOOL,
};

static const uint16 attr_flags529 [] =
{0,};

static const EIF_TYPE_INDEX g_atype529_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes529 [] = {
g_atype529_0,
};

static const long offsets529 [] =
{
+ @CHROFF(0,0),
};

extern const char *names530[];
static const uint32 types530 [] =
{
SK_BOOL,
};

static const uint16 attr_flags530 [] =
{0,};

static const EIF_TYPE_INDEX g_atype530_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes530 [] = {
g_atype530_0,
};

static const long offsets530 [] =
{
+ @CHROFF(0,0),
};

extern const char *names531[];
static const uint32 types531 [] =
{
SK_BOOL,
};

static const uint16 attr_flags531 [] =
{0,};

static const EIF_TYPE_INDEX g_atype531_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes531 [] = {
g_atype531_0,
};

static const long offsets531 [] =
{
+ @CHROFF(0,0),
};

extern const char *names532[];
static const uint32 types532 [] =
{
SK_BOOL,
};

static const uint16 attr_flags532 [] =
{0,};

static const EIF_TYPE_INDEX g_atype532_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes532 [] = {
g_atype532_0,
};

static const long offsets532 [] =
{
+ @CHROFF(0,0),
};

extern const char *names533[];
static const uint32 types533 [] =
{
SK_BOOL,
};

static const uint16 attr_flags533 [] =
{0,};

static const EIF_TYPE_INDEX g_atype533_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes533 [] = {
g_atype533_0,
};

static const long offsets533 [] =
{
+ @CHROFF(0,0),
};

extern const char *names534[];
static const uint32 types534 [] =
{
SK_BOOL,
};

static const uint16 attr_flags534 [] =
{0,};

static const EIF_TYPE_INDEX g_atype534_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes534 [] = {
g_atype534_0,
};

static const long offsets534 [] =
{
+ @CHROFF(0,0),
};

extern const char *names535[];
static const uint32 types535 [] =
{
SK_BOOL,
};

static const uint16 attr_flags535 [] =
{0,};

static const EIF_TYPE_INDEX g_atype535_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes535 [] = {
g_atype535_0,
};

static const long offsets535 [] =
{
+ @CHROFF(0,0),
};

extern const char *names536[];
static const uint32 types536 [] =
{
SK_BOOL,
};

static const uint16 attr_flags536 [] =
{0,};

static const EIF_TYPE_INDEX g_atype536_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes536 [] = {
g_atype536_0,
};

static const long offsets536 [] =
{
+ @CHROFF(0,0),
};

extern const char *names537[];
static const uint32 types537 [] =
{
SK_BOOL,
};

static const uint16 attr_flags537 [] =
{0,};

static const EIF_TYPE_INDEX g_atype537_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes537 [] = {
g_atype537_0,
};

static const long offsets537 [] =
{
+ @CHROFF(0,0),
};

extern const char *names538[];
static const uint32 types538 [] =
{
SK_BOOL,
};

static const uint16 attr_flags538 [] =
{0,};

static const EIF_TYPE_INDEX g_atype538_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes538 [] = {
g_atype538_0,
};

static const long offsets538 [] =
{
+ @CHROFF(0,0),
};

extern const char *names539[];
static const uint32 types539 [] =
{
SK_BOOL,
};

static const uint16 attr_flags539 [] =
{0,};

static const EIF_TYPE_INDEX g_atype539_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes539 [] = {
g_atype539_0,
};

static const long offsets539 [] =
{
+ @CHROFF(0,0),
};

extern const char *names540[];
static const uint32 types540 [] =
{
SK_BOOL,
};

static const uint16 attr_flags540 [] =
{0,};

static const EIF_TYPE_INDEX g_atype540_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes540 [] = {
g_atype540_0,
};

static const long offsets540 [] =
{
+ @CHROFF(0,0),
};

extern const char *names541[];
static const uint32 types541 [] =
{
SK_BOOL,
};

static const uint16 attr_flags541 [] =
{0,};

static const EIF_TYPE_INDEX g_atype541_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes541 [] = {
g_atype541_0,
};

static const long offsets541 [] =
{
+ @CHROFF(0,0),
};

extern const char *names542[];
static const uint32 types542 [] =
{
SK_BOOL,
};

static const uint16 attr_flags542 [] =
{0,};

static const EIF_TYPE_INDEX g_atype542_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes542 [] = {
g_atype542_0,
};

static const long offsets542 [] =
{
+ @CHROFF(0,0),
};

extern const char *names543[];
static const uint32 types543 [] =
{
SK_BOOL,
};

static const uint16 attr_flags543 [] =
{0,};

static const EIF_TYPE_INDEX g_atype543_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes543 [] = {
g_atype543_0,
};

static const long offsets543 [] =
{
+ @CHROFF(0,0),
};

extern const char *names544[];
static const uint32 types544 [] =
{
SK_BOOL,
};

static const uint16 attr_flags544 [] =
{0,};

static const EIF_TYPE_INDEX g_atype544_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes544 [] = {
g_atype544_0,
};

static const long offsets544 [] =
{
+ @CHROFF(0,0),
};

extern const char *names545[];
static const uint32 types545 [] =
{
SK_BOOL,
};

static const uint16 attr_flags545 [] =
{0,};

static const EIF_TYPE_INDEX g_atype545_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes545 [] = {
g_atype545_0,
};

static const long offsets545 [] =
{
+ @CHROFF(0,0),
};

extern const char *names546[];
static const uint32 types546 [] =
{
SK_BOOL,
};

static const uint16 attr_flags546 [] =
{0,};

static const EIF_TYPE_INDEX g_atype546_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes546 [] = {
g_atype546_0,
};

static const long offsets546 [] =
{
+ @CHROFF(0,0),
};

extern const char *names547[];
static const uint32 types547 [] =
{
SK_BOOL,
};

static const uint16 attr_flags547 [] =
{0,};

static const EIF_TYPE_INDEX g_atype547_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes547 [] = {
g_atype547_0,
};

static const long offsets547 [] =
{
+ @CHROFF(0,0),
};

extern const char *names548[];
static const uint32 types548 [] =
{
SK_BOOL,
};

static const uint16 attr_flags548 [] =
{0,};

static const EIF_TYPE_INDEX g_atype548_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes548 [] = {
g_atype548_0,
};

static const long offsets548 [] =
{
+ @CHROFF(0,0),
};

extern const char *names549[];
static const uint32 types549 [] =
{
SK_BOOL,
};

static const uint16 attr_flags549 [] =
{0,};

static const EIF_TYPE_INDEX g_atype549_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes549 [] = {
g_atype549_0,
};

static const long offsets549 [] =
{
+ @CHROFF(0,0),
};

extern const char *names550[];
static const uint32 types550 [] =
{
SK_BOOL,
};

static const uint16 attr_flags550 [] =
{0,};

static const EIF_TYPE_INDEX g_atype550_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes550 [] = {
g_atype550_0,
};

static const long offsets550 [] =
{
+ @CHROFF(0,0),
};

extern const char *names551[];
static const uint32 types551 [] =
{
SK_BOOL,
};

static const uint16 attr_flags551 [] =
{0,};

static const EIF_TYPE_INDEX g_atype551_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes551 [] = {
g_atype551_0,
};

static const long offsets551 [] =
{
+ @CHROFF(0,0),
};

extern const char *names552[];
static const uint32 types552 [] =
{
SK_BOOL,
};

static const uint16 attr_flags552 [] =
{0,};

static const EIF_TYPE_INDEX g_atype552_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes552 [] = {
g_atype552_0,
};

static const long offsets552 [] =
{
+ @CHROFF(0,0),
};

extern const char *names553[];
static const uint32 types553 [] =
{
SK_BOOL,
};

static const uint16 attr_flags553 [] =
{0,};

static const EIF_TYPE_INDEX g_atype553_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes553 [] = {
g_atype553_0,
};

static const long offsets553 [] =
{
+ @CHROFF(0,0),
};

extern const char *names554[];
static const uint32 types554 [] =
{
SK_BOOL,
};

static const uint16 attr_flags554 [] =
{0,};

static const EIF_TYPE_INDEX g_atype554_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes554 [] = {
g_atype554_0,
};

static const long offsets554 [] =
{
+ @CHROFF(0,0),
};

extern const char *names555[];
static const uint32 types555 [] =
{
SK_BOOL,
};

static const uint16 attr_flags555 [] =
{0,};

static const EIF_TYPE_INDEX g_atype555_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes555 [] = {
g_atype555_0,
};

static const long offsets555 [] =
{
+ @CHROFF(0,0),
};

extern const char *names556[];
static const uint32 types556 [] =
{
SK_BOOL,
};

static const uint16 attr_flags556 [] =
{0,};

static const EIF_TYPE_INDEX g_atype556_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes556 [] = {
g_atype556_0,
};

static const long offsets556 [] =
{
+ @CHROFF(0,0),
};

extern const char *names557[];
static const uint32 types557 [] =
{
SK_BOOL,
};

static const uint16 attr_flags557 [] =
{0,};

static const EIF_TYPE_INDEX g_atype557_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes557 [] = {
g_atype557_0,
};

static const long offsets557 [] =
{
+ @CHROFF(0,0),
};

extern const char *names558[];
static const uint32 types558 [] =
{
SK_BOOL,
};

static const uint16 attr_flags558 [] =
{0,};

static const EIF_TYPE_INDEX g_atype558_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes558 [] = {
g_atype558_0,
};

static const long offsets558 [] =
{
+ @CHROFF(0,0),
};

extern const char *names559[];
static const uint32 types559 [] =
{
SK_BOOL,
};

static const uint16 attr_flags559 [] =
{0,};

static const EIF_TYPE_INDEX g_atype559_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes559 [] = {
g_atype559_0,
};

static const long offsets559 [] =
{
+ @CHROFF(0,0),
};

extern const char *names560[];
static const uint32 types560 [] =
{
SK_BOOL,
};

static const uint16 attr_flags560 [] =
{0,};

static const EIF_TYPE_INDEX g_atype560_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes560 [] = {
g_atype560_0,
};

static const long offsets560 [] =
{
+ @CHROFF(0,0),
};

extern const char *names561[];
static const uint32 types561 [] =
{
SK_BOOL,
};

static const uint16 attr_flags561 [] =
{0,};

static const EIF_TYPE_INDEX g_atype561_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes561 [] = {
g_atype561_0,
};

static const long offsets561 [] =
{
+ @CHROFF(0,0),
};

extern const char *names562[];
static const uint32 types562 [] =
{
SK_BOOL,
};

static const uint16 attr_flags562 [] =
{0,};

static const EIF_TYPE_INDEX g_atype562_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes562 [] = {
g_atype562_0,
};

static const long offsets562 [] =
{
+ @CHROFF(0,0),
};

extern const char *names563[];
static const uint32 types563 [] =
{
SK_BOOL,
};

static const uint16 attr_flags563 [] =
{0,};

static const EIF_TYPE_INDEX g_atype563_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes563 [] = {
g_atype563_0,
};

static const long offsets563 [] =
{
+ @CHROFF(0,0),
};

extern const char *names564[];
static const uint32 types564 [] =
{
SK_BOOL,
};

static const uint16 attr_flags564 [] =
{0,};

static const EIF_TYPE_INDEX g_atype564_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes564 [] = {
g_atype564_0,
};

static const long offsets564 [] =
{
+ @CHROFF(0,0),
};

extern const char *names565[];
static const uint32 types565 [] =
{
SK_BOOL,
};

static const uint16 attr_flags565 [] =
{0,};

static const EIF_TYPE_INDEX g_atype565_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes565 [] = {
g_atype565_0,
};

static const long offsets565 [] =
{
+ @CHROFF(0,0),
};

extern const char *names566[];
static const uint32 types566 [] =
{
SK_BOOL,
};

static const uint16 attr_flags566 [] =
{0,};

static const EIF_TYPE_INDEX g_atype566_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes566 [] = {
g_atype566_0,
};

static const long offsets566 [] =
{
+ @CHROFF(0,0),
};

extern const char *names567[];
static const uint32 types567 [] =
{
SK_BOOL,
};

static const uint16 attr_flags567 [] =
{0,};

static const EIF_TYPE_INDEX g_atype567_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes567 [] = {
g_atype567_0,
};

static const long offsets567 [] =
{
+ @CHROFF(0,0),
};

extern const char *names568[];
static const uint32 types568 [] =
{
SK_BOOL,
};

static const uint16 attr_flags568 [] =
{0,};

static const EIF_TYPE_INDEX g_atype568_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes568 [] = {
g_atype568_0,
};

static const long offsets568 [] =
{
+ @CHROFF(0,0),
};

extern const char *names569[];
static const uint32 types569 [] =
{
SK_BOOL,
};

static const uint16 attr_flags569 [] =
{0,};

static const EIF_TYPE_INDEX g_atype569_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes569 [] = {
g_atype569_0,
};

static const long offsets569 [] =
{
+ @CHROFF(0,0),
};

extern const char *names570[];
static const uint32 types570 [] =
{
SK_BOOL,
};

static const uint16 attr_flags570 [] =
{0,};

static const EIF_TYPE_INDEX g_atype570_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes570 [] = {
g_atype570_0,
};

static const long offsets570 [] =
{
+ @CHROFF(0,0),
};

extern const char *names571[];
static const uint32 types571 [] =
{
SK_BOOL,
};

static const uint16 attr_flags571 [] =
{0,};

static const EIF_TYPE_INDEX g_atype571_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes571 [] = {
g_atype571_0,
};

static const long offsets571 [] =
{
+ @CHROFF(0,0),
};

extern const char *names572[];
static const uint32 types572 [] =
{
SK_BOOL,
};

static const uint16 attr_flags572 [] =
{0,};

static const EIF_TYPE_INDEX g_atype572_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes572 [] = {
g_atype572_0,
};

static const long offsets572 [] =
{
+ @CHROFF(0,0),
};

extern const char *names573[];
static const uint32 types573 [] =
{
SK_BOOL,
};

static const uint16 attr_flags573 [] =
{0,};

static const EIF_TYPE_INDEX g_atype573_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes573 [] = {
g_atype573_0,
};

static const long offsets573 [] =
{
+ @CHROFF(0,0),
};

extern const char *names574[];
static const uint32 types574 [] =
{
SK_BOOL,
};

static const uint16 attr_flags574 [] =
{0,};

static const EIF_TYPE_INDEX g_atype574_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes574 [] = {
g_atype574_0,
};

static const long offsets574 [] =
{
+ @CHROFF(0,0),
};

extern const char *names575[];
static const uint32 types575 [] =
{
SK_BOOL,
};

static const uint16 attr_flags575 [] =
{0,};

static const EIF_TYPE_INDEX g_atype575_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes575 [] = {
g_atype575_0,
};

static const long offsets575 [] =
{
+ @CHROFF(0,0),
};

extern const char *names576[];
static const uint32 types576 [] =
{
SK_BOOL,
};

static const uint16 attr_flags576 [] =
{0,};

static const EIF_TYPE_INDEX g_atype576_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes576 [] = {
g_atype576_0,
};

static const long offsets576 [] =
{
+ @CHROFF(0,0),
};

extern const char *names577[];
static const uint32 types577 [] =
{
SK_BOOL,
};

static const uint16 attr_flags577 [] =
{0,};

static const EIF_TYPE_INDEX g_atype577_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes577 [] = {
g_atype577_0,
};

static const long offsets577 [] =
{
+ @CHROFF(0,0),
};

extern const char *names578[];
static const uint32 types578 [] =
{
SK_BOOL,
};

static const uint16 attr_flags578 [] =
{0,};

static const EIF_TYPE_INDEX g_atype578_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes578 [] = {
g_atype578_0,
};

static const long offsets578 [] =
{
+ @CHROFF(0,0),
};

extern const char *names579[];
static const uint32 types579 [] =
{
SK_BOOL,
};

static const uint16 attr_flags579 [] =
{0,};

static const EIF_TYPE_INDEX g_atype579_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes579 [] = {
g_atype579_0,
};

static const long offsets579 [] =
{
+ @CHROFF(0,0),
};

extern const char *names580[];
static const uint32 types580 [] =
{
SK_BOOL,
};

static const uint16 attr_flags580 [] =
{0,};

static const EIF_TYPE_INDEX g_atype580_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes580 [] = {
g_atype580_0,
};

static const long offsets580 [] =
{
+ @CHROFF(0,0),
};

extern const char *names581[];
static const uint32 types581 [] =
{
SK_BOOL,
};

static const uint16 attr_flags581 [] =
{0,};

static const EIF_TYPE_INDEX g_atype581_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes581 [] = {
g_atype581_0,
};

static const long offsets581 [] =
{
+ @CHROFF(0,0),
};

extern const char *names582[];
static const uint32 types582 [] =
{
SK_BOOL,
};

static const uint16 attr_flags582 [] =
{0,};

static const EIF_TYPE_INDEX g_atype582_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes582 [] = {
g_atype582_0,
};

static const long offsets582 [] =
{
+ @CHROFF(0,0),
};

extern const char *names583[];
static const uint32 types583 [] =
{
SK_BOOL,
};

static const uint16 attr_flags583 [] =
{0,};

static const EIF_TYPE_INDEX g_atype583_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes583 [] = {
g_atype583_0,
};

static const long offsets583 [] =
{
+ @CHROFF(0,0),
};

extern const char *names584[];
static const uint32 types584 [] =
{
SK_BOOL,
};

static const uint16 attr_flags584 [] =
{0,};

static const EIF_TYPE_INDEX g_atype584_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes584 [] = {
g_atype584_0,
};

static const long offsets584 [] =
{
+ @CHROFF(0,0),
};

extern const char *names585[];
static const uint32 types585 [] =
{
SK_BOOL,
};

static const uint16 attr_flags585 [] =
{0,};

static const EIF_TYPE_INDEX g_atype585_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes585 [] = {
g_atype585_0,
};

static const long offsets585 [] =
{
+ @CHROFF(0,0),
};

extern const char *names586[];
static const uint32 types586 [] =
{
SK_BOOL,
};

static const uint16 attr_flags586 [] =
{0,};

static const EIF_TYPE_INDEX g_atype586_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes586 [] = {
g_atype586_0,
};

static const long offsets586 [] =
{
+ @CHROFF(0,0),
};

extern const char *names587[];
static const uint32 types587 [] =
{
SK_BOOL,
};

static const uint16 attr_flags587 [] =
{0,};

static const EIF_TYPE_INDEX g_atype587_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes587 [] = {
g_atype587_0,
};

static const long offsets587 [] =
{
+ @CHROFF(0,0),
};

extern const char *names588[];
static const uint32 types588 [] =
{
SK_BOOL,
};

static const uint16 attr_flags588 [] =
{0,};

static const EIF_TYPE_INDEX g_atype588_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes588 [] = {
g_atype588_0,
};

static const long offsets588 [] =
{
+ @CHROFF(0,0),
};

extern const char *names589[];
static const uint32 types589 [] =
{
SK_BOOL,
};

static const uint16 attr_flags589 [] =
{0,};

static const EIF_TYPE_INDEX g_atype589_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes589 [] = {
g_atype589_0,
};

static const long offsets589 [] =
{
+ @CHROFF(0,0),
};

extern const char *names590[];
static const uint32 types590 [] =
{
SK_BOOL,
};

static const uint16 attr_flags590 [] =
{0,};

static const EIF_TYPE_INDEX g_atype590_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes590 [] = {
g_atype590_0,
};

static const long offsets590 [] =
{
+ @CHROFF(0,0),
};

extern const char *names591[];
static const uint32 types591 [] =
{
SK_BOOL,
};

static const uint16 attr_flags591 [] =
{0,};

static const EIF_TYPE_INDEX g_atype591_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes591 [] = {
g_atype591_0,
};

static const long offsets591 [] =
{
+ @CHROFF(0,0),
};

extern const char *names592[];
static const uint32 types592 [] =
{
SK_BOOL,
};

static const uint16 attr_flags592 [] =
{0,};

static const EIF_TYPE_INDEX g_atype592_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes592 [] = {
g_atype592_0,
};

static const long offsets592 [] =
{
+ @CHROFF(0,0),
};

extern const char *names593[];
static const uint32 types593 [] =
{
SK_BOOL,
};

static const uint16 attr_flags593 [] =
{0,};

static const EIF_TYPE_INDEX g_atype593_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes593 [] = {
g_atype593_0,
};

static const long offsets593 [] =
{
+ @CHROFF(0,0),
};

extern const char *names594[];
static const uint32 types594 [] =
{
SK_BOOL,
};

static const uint16 attr_flags594 [] =
{0,};

static const EIF_TYPE_INDEX g_atype594_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes594 [] = {
g_atype594_0,
};

static const long offsets594 [] =
{
+ @CHROFF(0,0),
};

extern const char *names595[];
static const uint32 types595 [] =
{
SK_BOOL,
};

static const uint16 attr_flags595 [] =
{0,};

static const EIF_TYPE_INDEX g_atype595_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes595 [] = {
g_atype595_0,
};

static const long offsets595 [] =
{
+ @CHROFF(0,0),
};

extern const char *names596[];
static const uint32 types596 [] =
{
SK_BOOL,
};

static const uint16 attr_flags596 [] =
{0,};

static const EIF_TYPE_INDEX g_atype596_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes596 [] = {
g_atype596_0,
};

static const long offsets596 [] =
{
+ @CHROFF(0,0),
};

extern const char *names597[];
static const uint32 types597 [] =
{
SK_BOOL,
};

static const uint16 attr_flags597 [] =
{0,};

static const EIF_TYPE_INDEX g_atype597_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes597 [] = {
g_atype597_0,
};

static const long offsets597 [] =
{
+ @CHROFF(0,0),
};

extern const char *names598[];
static const uint32 types598 [] =
{
SK_BOOL,
};

static const uint16 attr_flags598 [] =
{0,};

static const EIF_TYPE_INDEX g_atype598_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes598 [] = {
g_atype598_0,
};

static const long offsets598 [] =
{
+ @CHROFF(0,0),
};

extern const char *names599[];
static const uint32 types599 [] =
{
SK_BOOL,
};

static const uint16 attr_flags599 [] =
{0,};

static const EIF_TYPE_INDEX g_atype599_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes599 [] = {
g_atype599_0,
};

static const long offsets599 [] =
{
+ @CHROFF(0,0),
};

extern const char *names600[];
static const uint32 types600 [] =
{
SK_BOOL,
};

static const uint16 attr_flags600 [] =
{0,};

static const EIF_TYPE_INDEX g_atype600_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes600 [] = {
g_atype600_0,
};

static const long offsets600 [] =
{
+ @CHROFF(0,0),
};

extern const char *names601[];
static const uint32 types601 [] =
{
SK_BOOL,
};

static const uint16 attr_flags601 [] =
{0,};

static const EIF_TYPE_INDEX g_atype601_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes601 [] = {
g_atype601_0,
};

static const long offsets601 [] =
{
+ @CHROFF(0,0),
};

extern const char *names602[];
static const uint32 types602 [] =
{
SK_BOOL,
};

static const uint16 attr_flags602 [] =
{0,};

static const EIF_TYPE_INDEX g_atype602_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes602 [] = {
g_atype602_0,
};

static const long offsets602 [] =
{
+ @CHROFF(0,0),
};

extern const char *names603[];
static const uint32 types603 [] =
{
SK_BOOL,
};

static const uint16 attr_flags603 [] =
{0,};

static const EIF_TYPE_INDEX g_atype603_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes603 [] = {
g_atype603_0,
};

static const long offsets603 [] =
{
+ @CHROFF(0,0),
};

extern const char *names604[];
static const uint32 types604 [] =
{
SK_BOOL,
};

static const uint16 attr_flags604 [] =
{0,};

static const EIF_TYPE_INDEX g_atype604_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes604 [] = {
g_atype604_0,
};

static const long offsets604 [] =
{
+ @CHROFF(0,0),
};

extern const char *names605[];
static const uint32 types605 [] =
{
SK_BOOL,
};

static const uint16 attr_flags605 [] =
{0,};

static const EIF_TYPE_INDEX g_atype605_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes605 [] = {
g_atype605_0,
};

static const long offsets605 [] =
{
+ @CHROFF(0,0),
};

extern const char *names606[];
static const uint32 types606 [] =
{
SK_BOOL,
};

static const uint16 attr_flags606 [] =
{0,};

static const EIF_TYPE_INDEX g_atype606_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes606 [] = {
g_atype606_0,
};

static const long offsets606 [] =
{
+ @CHROFF(0,0),
};

extern const char *names607[];
static const uint32 types607 [] =
{
SK_BOOL,
};

static const uint16 attr_flags607 [] =
{0,};

static const EIF_TYPE_INDEX g_atype607_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes607 [] = {
g_atype607_0,
};

static const long offsets607 [] =
{
+ @CHROFF(0,0),
};

extern const char *names608[];
static const uint32 types608 [] =
{
SK_BOOL,
};

static const uint16 attr_flags608 [] =
{0,};

static const EIF_TYPE_INDEX g_atype608_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes608 [] = {
g_atype608_0,
};

static const long offsets608 [] =
{
+ @CHROFF(0,0),
};

extern const char *names609[];
static const uint32 types609 [] =
{
SK_BOOL,
};

static const uint16 attr_flags609 [] =
{0,};

static const EIF_TYPE_INDEX g_atype609_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes609 [] = {
g_atype609_0,
};

static const long offsets609 [] =
{
+ @CHROFF(0,0),
};

extern const char *names610[];
static const uint32 types610 [] =
{
SK_BOOL,
};

static const uint16 attr_flags610 [] =
{0,};

static const EIF_TYPE_INDEX g_atype610_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes610 [] = {
g_atype610_0,
};

static const long offsets610 [] =
{
+ @CHROFF(0,0),
};

extern const char *names611[];
static const uint32 types611 [] =
{
SK_BOOL,
};

static const uint16 attr_flags611 [] =
{0,};

static const EIF_TYPE_INDEX g_atype611_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes611 [] = {
g_atype611_0,
};

static const long offsets611 [] =
{
+ @CHROFF(0,0),
};

extern const char *names612[];
static const uint32 types612 [] =
{
SK_BOOL,
};

static const uint16 attr_flags612 [] =
{0,};

static const EIF_TYPE_INDEX g_atype612_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes612 [] = {
g_atype612_0,
};

static const long offsets612 [] =
{
+ @CHROFF(0,0),
};

extern const char *names613[];
static const uint32 types613 [] =
{
SK_BOOL,
};

static const uint16 attr_flags613 [] =
{0,};

static const EIF_TYPE_INDEX g_atype613_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes613 [] = {
g_atype613_0,
};

static const long offsets613 [] =
{
+ @CHROFF(0,0),
};

extern const char *names614[];
static const uint32 types614 [] =
{
SK_BOOL,
};

static const uint16 attr_flags614 [] =
{0,};

static const EIF_TYPE_INDEX g_atype614_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes614 [] = {
g_atype614_0,
};

static const long offsets614 [] =
{
+ @CHROFF(0,0),
};

extern const char *names615[];
static const uint32 types615 [] =
{
SK_BOOL,
};

static const uint16 attr_flags615 [] =
{0,};

static const EIF_TYPE_INDEX g_atype615_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes615 [] = {
g_atype615_0,
};

static const long offsets615 [] =
{
+ @CHROFF(0,0),
};

extern const char *names616[];
static const uint32 types616 [] =
{
SK_BOOL,
};

static const uint16 attr_flags616 [] =
{0,};

static const EIF_TYPE_INDEX g_atype616_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes616 [] = {
g_atype616_0,
};

static const long offsets616 [] =
{
+ @CHROFF(0,0),
};

extern const char *names617[];
static const uint32 types617 [] =
{
SK_BOOL,
};

static const uint16 attr_flags617 [] =
{0,};

static const EIF_TYPE_INDEX g_atype617_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes617 [] = {
g_atype617_0,
};

static const long offsets617 [] =
{
+ @CHROFF(0,0),
};

extern const char *names618[];
static const uint32 types618 [] =
{
SK_BOOL,
};

static const uint16 attr_flags618 [] =
{0,};

static const EIF_TYPE_INDEX g_atype618_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes618 [] = {
g_atype618_0,
};

static const long offsets618 [] =
{
+ @CHROFF(0,0),
};

extern const char *names619[];
static const uint32 types619 [] =
{
SK_BOOL,
};

static const uint16 attr_flags619 [] =
{0,};

static const EIF_TYPE_INDEX g_atype619_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes619 [] = {
g_atype619_0,
};

static const long offsets619 [] =
{
+ @CHROFF(0,0),
};

extern const char *names620[];
static const uint32 types620 [] =
{
SK_BOOL,
};

static const uint16 attr_flags620 [] =
{0,};

static const EIF_TYPE_INDEX g_atype620_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes620 [] = {
g_atype620_0,
};

static const long offsets620 [] =
{
+ @CHROFF(0,0),
};

extern const char *names621[];
static const uint32 types621 [] =
{
SK_BOOL,
};

static const uint16 attr_flags621 [] =
{0,};

static const EIF_TYPE_INDEX g_atype621_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes621 [] = {
g_atype621_0,
};

static const long offsets621 [] =
{
+ @CHROFF(0,0),
};

extern const char *names622[];
static const uint32 types622 [] =
{
SK_BOOL,
};

static const uint16 attr_flags622 [] =
{0,};

static const EIF_TYPE_INDEX g_atype622_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes622 [] = {
g_atype622_0,
};

static const long offsets622 [] =
{
+ @CHROFF(0,0),
};

extern const char *names623[];
static const uint32 types623 [] =
{
SK_BOOL,
};

static const uint16 attr_flags623 [] =
{0,};

static const EIF_TYPE_INDEX g_atype623_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes623 [] = {
g_atype623_0,
};

static const long offsets623 [] =
{
+ @CHROFF(0,0),
};

extern const char *names624[];
static const uint32 types624 [] =
{
SK_BOOL,
};

static const uint16 attr_flags624 [] =
{0,};

static const EIF_TYPE_INDEX g_atype624_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes624 [] = {
g_atype624_0,
};

static const long offsets624 [] =
{
+ @CHROFF(0,0),
};

extern const char *names625[];
static const uint32 types625 [] =
{
SK_BOOL,
};

static const uint16 attr_flags625 [] =
{0,};

static const EIF_TYPE_INDEX g_atype625_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes625 [] = {
g_atype625_0,
};

static const long offsets625 [] =
{
+ @CHROFF(0,0),
};

extern const char *names626[];
static const uint32 types626 [] =
{
SK_BOOL,
};

static const uint16 attr_flags626 [] =
{0,};

static const EIF_TYPE_INDEX g_atype626_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes626 [] = {
g_atype626_0,
};

static const long offsets626 [] =
{
+ @CHROFF(0,0),
};

extern const char *names627[];
static const uint32 types627 [] =
{
SK_BOOL,
};

static const uint16 attr_flags627 [] =
{0,};

static const EIF_TYPE_INDEX g_atype627_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes627 [] = {
g_atype627_0,
};

static const long offsets627 [] =
{
+ @CHROFF(0,0),
};

extern const char *names628[];
static const uint32 types628 [] =
{
SK_BOOL,
};

static const uint16 attr_flags628 [] =
{0,};

static const EIF_TYPE_INDEX g_atype628_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes628 [] = {
g_atype628_0,
};

static const long offsets628 [] =
{
+ @CHROFF(0,0),
};

extern const char *names629[];
static const uint32 types629 [] =
{
SK_BOOL,
};

static const uint16 attr_flags629 [] =
{0,};

static const EIF_TYPE_INDEX g_atype629_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes629 [] = {
g_atype629_0,
};

static const long offsets629 [] =
{
+ @CHROFF(0,0),
};

extern const char *names630[];
static const uint32 types630 [] =
{
SK_BOOL,
};

static const uint16 attr_flags630 [] =
{0,};

static const EIF_TYPE_INDEX g_atype630_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes630 [] = {
g_atype630_0,
};

static const long offsets630 [] =
{
+ @CHROFF(0,0),
};

extern const char *names631[];
static const uint32 types631 [] =
{
SK_BOOL,
};

static const uint16 attr_flags631 [] =
{0,};

static const EIF_TYPE_INDEX g_atype631_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes631 [] = {
g_atype631_0,
};

static const long offsets631 [] =
{
+ @CHROFF(0,0),
};

extern const char *names632[];
static const uint32 types632 [] =
{
SK_BOOL,
};

static const uint16 attr_flags632 [] =
{0,};

static const EIF_TYPE_INDEX g_atype632_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes632 [] = {
g_atype632_0,
};

static const long offsets632 [] =
{
+ @CHROFF(0,0),
};

extern const char *names633[];
static const uint32 types633 [] =
{
SK_BOOL,
};

static const uint16 attr_flags633 [] =
{0,};

static const EIF_TYPE_INDEX g_atype633_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes633 [] = {
g_atype633_0,
};

static const long offsets633 [] =
{
+ @CHROFF(0,0),
};

extern const char *names634[];
static const uint32 types634 [] =
{
SK_BOOL,
};

static const uint16 attr_flags634 [] =
{0,};

static const EIF_TYPE_INDEX g_atype634_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes634 [] = {
g_atype634_0,
};

static const long offsets634 [] =
{
+ @CHROFF(0,0),
};

extern const char *names635[];
static const uint32 types635 [] =
{
SK_BOOL,
};

static const uint16 attr_flags635 [] =
{0,};

static const EIF_TYPE_INDEX g_atype635_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes635 [] = {
g_atype635_0,
};

static const long offsets635 [] =
{
+ @CHROFF(0,0),
};

extern const char *names636[];
static const uint32 types636 [] =
{
SK_BOOL,
};

static const uint16 attr_flags636 [] =
{0,};

static const EIF_TYPE_INDEX g_atype636_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes636 [] = {
g_atype636_0,
};

static const long offsets636 [] =
{
+ @CHROFF(0,0),
};

extern const char *names637[];
static const uint32 types637 [] =
{
SK_BOOL,
};

static const uint16 attr_flags637 [] =
{0,};

static const EIF_TYPE_INDEX g_atype637_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes637 [] = {
g_atype637_0,
};

static const long offsets637 [] =
{
+ @CHROFF(0,0),
};

extern const char *names638[];
static const uint32 types638 [] =
{
SK_BOOL,
};

static const uint16 attr_flags638 [] =
{0,};

static const EIF_TYPE_INDEX g_atype638_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes638 [] = {
g_atype638_0,
};

static const long offsets638 [] =
{
+ @CHROFF(0,0),
};

extern const char *names639[];
static const uint32 types639 [] =
{
SK_BOOL,
};

static const uint16 attr_flags639 [] =
{0,};

static const EIF_TYPE_INDEX g_atype639_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes639 [] = {
g_atype639_0,
};

static const long offsets639 [] =
{
+ @CHROFF(0,0),
};

extern const char *names640[];
static const uint32 types640 [] =
{
SK_BOOL,
};

static const uint16 attr_flags640 [] =
{0,};

static const EIF_TYPE_INDEX g_atype640_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes640 [] = {
g_atype640_0,
};

static const long offsets640 [] =
{
+ @CHROFF(0,0),
};

extern const char *names641[];
static const uint32 types641 [] =
{
SK_BOOL,
};

static const uint16 attr_flags641 [] =
{0,};

static const EIF_TYPE_INDEX g_atype641_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes641 [] = {
g_atype641_0,
};

static const long offsets641 [] =
{
+ @CHROFF(0,0),
};

extern const char *names642[];
static const uint32 types642 [] =
{
SK_BOOL,
};

static const uint16 attr_flags642 [] =
{0,};

static const EIF_TYPE_INDEX g_atype642_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes642 [] = {
g_atype642_0,
};

static const long offsets642 [] =
{
+ @CHROFF(0,0),
};

extern const char *names643[];
static const uint32 types643 [] =
{
SK_BOOL,
};

static const uint16 attr_flags643 [] =
{0,};

static const EIF_TYPE_INDEX g_atype643_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes643 [] = {
g_atype643_0,
};

static const long offsets643 [] =
{
+ @CHROFF(0,0),
};

extern const char *names644[];
static const uint32 types644 [] =
{
SK_BOOL,
};

static const uint16 attr_flags644 [] =
{0,};

static const EIF_TYPE_INDEX g_atype644_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes644 [] = {
g_atype644_0,
};

static const long offsets644 [] =
{
+ @CHROFF(0,0),
};

extern const char *names645[];
static const uint32 types645 [] =
{
SK_BOOL,
};

static const uint16 attr_flags645 [] =
{0,};

static const EIF_TYPE_INDEX g_atype645_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes645 [] = {
g_atype645_0,
};

static const long offsets645 [] =
{
+ @CHROFF(0,0),
};

extern const char *names646[];
static const uint32 types646 [] =
{
SK_BOOL,
};

static const uint16 attr_flags646 [] =
{0,};

static const EIF_TYPE_INDEX g_atype646_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes646 [] = {
g_atype646_0,
};

static const long offsets646 [] =
{
+ @CHROFF(0,0),
};

extern const char *names647[];
static const uint32 types647 [] =
{
SK_BOOL,
};

static const uint16 attr_flags647 [] =
{0,};

static const EIF_TYPE_INDEX g_atype647_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes647 [] = {
g_atype647_0,
};

static const long offsets647 [] =
{
+ @CHROFF(0,0),
};

extern const char *names648[];
static const uint32 types648 [] =
{
SK_BOOL,
};

static const uint16 attr_flags648 [] =
{0,};

static const EIF_TYPE_INDEX g_atype648_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes648 [] = {
g_atype648_0,
};

static const long offsets648 [] =
{
+ @CHROFF(0,0),
};

extern const char *names649[];
static const uint32 types649 [] =
{
SK_BOOL,
};

static const uint16 attr_flags649 [] =
{0,};

static const EIF_TYPE_INDEX g_atype649_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes649 [] = {
g_atype649_0,
};

static const long offsets649 [] =
{
+ @CHROFF(0,0),
};

extern const char *names650[];
static const uint32 types650 [] =
{
SK_BOOL,
};

static const uint16 attr_flags650 [] =
{0,};

static const EIF_TYPE_INDEX g_atype650_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes650 [] = {
g_atype650_0,
};

static const long offsets650 [] =
{
+ @CHROFF(0,0),
};

extern const char *names651[];
static const uint32 types651 [] =
{
SK_BOOL,
};

static const uint16 attr_flags651 [] =
{0,};

static const EIF_TYPE_INDEX g_atype651_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes651 [] = {
g_atype651_0,
};

static const long offsets651 [] =
{
+ @CHROFF(0,0),
};

extern const char *names652[];
static const uint32 types652 [] =
{
SK_BOOL,
};

static const uint16 attr_flags652 [] =
{0,};

static const EIF_TYPE_INDEX g_atype652_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes652 [] = {
g_atype652_0,
};

static const long offsets652 [] =
{
+ @CHROFF(0,0),
};

extern const char *names653[];
static const uint32 types653 [] =
{
SK_BOOL,
};

static const uint16 attr_flags653 [] =
{0,};

static const EIF_TYPE_INDEX g_atype653_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes653 [] = {
g_atype653_0,
};

static const long offsets653 [] =
{
+ @CHROFF(0,0),
};

extern const char *names654[];
static const uint32 types654 [] =
{
SK_BOOL,
};

static const uint16 attr_flags654 [] =
{0,};

static const EIF_TYPE_INDEX g_atype654_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes654 [] = {
g_atype654_0,
};

static const long offsets654 [] =
{
+ @CHROFF(0,0),
};

extern const char *names655[];
static const uint32 types655 [] =
{
SK_BOOL,
};

static const uint16 attr_flags655 [] =
{0,};

static const EIF_TYPE_INDEX g_atype655_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes655 [] = {
g_atype655_0,
};

static const long offsets655 [] =
{
+ @CHROFF(0,0),
};

extern const char *names656[];
static const uint32 types656 [] =
{
SK_BOOL,
};

static const uint16 attr_flags656 [] =
{0,};

static const EIF_TYPE_INDEX g_atype656_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes656 [] = {
g_atype656_0,
};

static const long offsets656 [] =
{
+ @CHROFF(0,0),
};

extern const char *names657[];
static const uint32 types657 [] =
{
SK_BOOL,
};

static const uint16 attr_flags657 [] =
{0,};

static const EIF_TYPE_INDEX g_atype657_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes657 [] = {
g_atype657_0,
};

static const long offsets657 [] =
{
+ @CHROFF(0,0),
};

extern const char *names658[];
static const uint32 types658 [] =
{
SK_BOOL,
};

static const uint16 attr_flags658 [] =
{0,};

static const EIF_TYPE_INDEX g_atype658_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes658 [] = {
g_atype658_0,
};

static const long offsets658 [] =
{
+ @CHROFF(0,0),
};

extern const char *names659[];
static const uint32 types659 [] =
{
SK_BOOL,
};

static const uint16 attr_flags659 [] =
{0,};

static const EIF_TYPE_INDEX g_atype659_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes659 [] = {
g_atype659_0,
};

static const long offsets659 [] =
{
+ @CHROFF(0,0),
};

extern const char *names660[];
static const uint32 types660 [] =
{
SK_BOOL,
};

static const uint16 attr_flags660 [] =
{0,};

static const EIF_TYPE_INDEX g_atype660_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes660 [] = {
g_atype660_0,
};

static const long offsets660 [] =
{
+ @CHROFF(0,0),
};

extern const char *names661[];
static const uint32 types661 [] =
{
SK_BOOL,
};

static const uint16 attr_flags661 [] =
{0,};

static const EIF_TYPE_INDEX g_atype661_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes661 [] = {
g_atype661_0,
};

static const long offsets661 [] =
{
+ @CHROFF(0,0),
};

extern const char *names662[];
static const uint32 types662 [] =
{
SK_BOOL,
};

static const uint16 attr_flags662 [] =
{0,};

static const EIF_TYPE_INDEX g_atype662_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes662 [] = {
g_atype662_0,
};

static const long offsets662 [] =
{
+ @CHROFF(0,0),
};

extern const char *names663[];
static const uint32 types663 [] =
{
SK_BOOL,
};

static const uint16 attr_flags663 [] =
{0,};

static const EIF_TYPE_INDEX g_atype663_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes663 [] = {
g_atype663_0,
};

static const long offsets663 [] =
{
+ @CHROFF(0,0),
};

extern const char *names664[];
static const uint32 types664 [] =
{
SK_BOOL,
};

static const uint16 attr_flags664 [] =
{0,};

static const EIF_TYPE_INDEX g_atype664_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes664 [] = {
g_atype664_0,
};

static const long offsets664 [] =
{
+ @CHROFF(0,0),
};

extern const char *names665[];
static const uint32 types665 [] =
{
SK_BOOL,
};

static const uint16 attr_flags665 [] =
{0,};

static const EIF_TYPE_INDEX g_atype665_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes665 [] = {
g_atype665_0,
};

static const long offsets665 [] =
{
+ @CHROFF(0,0),
};

extern const char *names666[];
static const uint32 types666 [] =
{
SK_BOOL,
};

static const uint16 attr_flags666 [] =
{0,};

static const EIF_TYPE_INDEX g_atype666_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes666 [] = {
g_atype666_0,
};

static const long offsets666 [] =
{
+ @CHROFF(0,0),
};

extern const char *names667[];
static const uint32 types667 [] =
{
SK_BOOL,
};

static const uint16 attr_flags667 [] =
{0,};

static const EIF_TYPE_INDEX g_atype667_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes667 [] = {
g_atype667_0,
};

static const long offsets667 [] =
{
+ @CHROFF(0,0),
};

extern const char *names668[];
static const uint32 types668 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags668 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype668_0 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype668_1 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes668 [] = {
g_atype668_0,
g_atype668_1,
};

static const long offsets668 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names669[];
static const uint32 types669 [] =
{
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags669 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype669_0 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype669_1 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes669 [] = {
g_atype669_0,
g_atype669_1,
};

static const long offsets669 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
};

extern const char *names670[];
static const uint32 types670 [] =
{
SK_BOOL,
};

static const uint16 attr_flags670 [] =
{0,};

static const EIF_TYPE_INDEX g_atype670_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes670 [] = {
g_atype670_0,
};

static const long offsets670 [] =
{
+ @CHROFF(0,0),
};

extern const char *names671[];
static const uint32 types671 [] =
{
SK_BOOL,
};

static const uint16 attr_flags671 [] =
{0,};

static const EIF_TYPE_INDEX g_atype671_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes671 [] = {
g_atype671_0,
};

static const long offsets671 [] =
{
+ @CHROFF(0,0),
};

extern const char *names672[];
static const uint32 types672 [] =
{
SK_BOOL,
};

static const uint16 attr_flags672 [] =
{0,};

static const EIF_TYPE_INDEX g_atype672_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes672 [] = {
g_atype672_0,
};

static const long offsets672 [] =
{
+ @CHROFF(0,0),
};

extern const char *names673[];
static const uint32 types673 [] =
{
SK_BOOL,
};

static const uint16 attr_flags673 [] =
{0,};

static const EIF_TYPE_INDEX g_atype673_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes673 [] = {
g_atype673_0,
};

static const long offsets673 [] =
{
+ @CHROFF(0,0),
};

extern const char *names674[];
static const uint32 types674 [] =
{
SK_BOOL,
};

static const uint16 attr_flags674 [] =
{0,};

static const EIF_TYPE_INDEX g_atype674_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes674 [] = {
g_atype674_0,
};

static const long offsets674 [] =
{
+ @CHROFF(0,0),
};

extern const char *names675[];
static const uint32 types675 [] =
{
SK_BOOL,
};

static const uint16 attr_flags675 [] =
{0,};

static const EIF_TYPE_INDEX g_atype675_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes675 [] = {
g_atype675_0,
};

static const long offsets675 [] =
{
+ @CHROFF(0,0),
};

extern const char *names676[];
static const uint32 types676 [] =
{
SK_BOOL,
};

static const uint16 attr_flags676 [] =
{0,};

static const EIF_TYPE_INDEX g_atype676_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes676 [] = {
g_atype676_0,
};

static const long offsets676 [] =
{
+ @CHROFF(0,0),
};

extern const char *names677[];
static const uint32 types677 [] =
{
SK_BOOL,
};

static const uint16 attr_flags677 [] =
{0,};

static const EIF_TYPE_INDEX g_atype677_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes677 [] = {
g_atype677_0,
};

static const long offsets677 [] =
{
+ @CHROFF(0,0),
};

extern const char *names678[];
static const uint32 types678 [] =
{
SK_BOOL,
};

static const uint16 attr_flags678 [] =
{0,};

static const EIF_TYPE_INDEX g_atype678_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes678 [] = {
g_atype678_0,
};

static const long offsets678 [] =
{
+ @CHROFF(0,0),
};

extern const char *names679[];
static const uint32 types679 [] =
{
SK_BOOL,
};

static const uint16 attr_flags679 [] =
{0,};

static const EIF_TYPE_INDEX g_atype679_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes679 [] = {
g_atype679_0,
};

static const long offsets679 [] =
{
+ @CHROFF(0,0),
};

extern const char *names680[];
static const uint32 types680 [] =
{
SK_BOOL,
};

static const uint16 attr_flags680 [] =
{0,};

static const EIF_TYPE_INDEX g_atype680_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes680 [] = {
g_atype680_0,
};

static const long offsets680 [] =
{
+ @CHROFF(0,0),
};

extern const char *names681[];
static const uint32 types681 [] =
{
SK_BOOL,
};

static const uint16 attr_flags681 [] =
{0,};

static const EIF_TYPE_INDEX g_atype681_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes681 [] = {
g_atype681_0,
};

static const long offsets681 [] =
{
+ @CHROFF(0,0),
};

extern const char *names682[];
static const uint32 types682 [] =
{
SK_BOOL,
};

static const uint16 attr_flags682 [] =
{0,};

static const EIF_TYPE_INDEX g_atype682_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes682 [] = {
g_atype682_0,
};

static const long offsets682 [] =
{
+ @CHROFF(0,0),
};

extern const char *names683[];
static const uint32 types683 [] =
{
SK_BOOL,
};

static const uint16 attr_flags683 [] =
{0,};

static const EIF_TYPE_INDEX g_atype683_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes683 [] = {
g_atype683_0,
};

static const long offsets683 [] =
{
+ @CHROFF(0,0),
};

extern const char *names684[];
static const uint32 types684 [] =
{
SK_BOOL,
};

static const uint16 attr_flags684 [] =
{0,};

static const EIF_TYPE_INDEX g_atype684_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes684 [] = {
g_atype684_0,
};

static const long offsets684 [] =
{
+ @CHROFF(0,0),
};

extern const char *names685[];
static const uint32 types685 [] =
{
SK_BOOL,
};

static const uint16 attr_flags685 [] =
{0,};

static const EIF_TYPE_INDEX g_atype685_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes685 [] = {
g_atype685_0,
};

static const long offsets685 [] =
{
+ @CHROFF(0,0),
};

extern const char *names686[];
static const uint32 types686 [] =
{
SK_BOOL,
};

static const uint16 attr_flags686 [] =
{0,};

static const EIF_TYPE_INDEX g_atype686_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes686 [] = {
g_atype686_0,
};

static const long offsets686 [] =
{
+ @CHROFF(0,0),
};

extern const char *names687[];
static const uint32 types687 [] =
{
SK_BOOL,
};

static const uint16 attr_flags687 [] =
{0,};

static const EIF_TYPE_INDEX g_atype687_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes687 [] = {
g_atype687_0,
};

static const long offsets687 [] =
{
+ @CHROFF(0,0),
};

extern const char *names688[];
static const uint32 types688 [] =
{
SK_BOOL,
};

static const uint16 attr_flags688 [] =
{0,};

static const EIF_TYPE_INDEX g_atype688_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes688 [] = {
g_atype688_0,
};

static const long offsets688 [] =
{
+ @CHROFF(0,0),
};

extern const char *names689[];
static const uint32 types689 [] =
{
SK_BOOL,
};

static const uint16 attr_flags689 [] =
{0,};

static const EIF_TYPE_INDEX g_atype689_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes689 [] = {
g_atype689_0,
};

static const long offsets689 [] =
{
+ @CHROFF(0,0),
};

extern const char *names690[];
static const uint32 types690 [] =
{
SK_BOOL,
};

static const uint16 attr_flags690 [] =
{0,};

static const EIF_TYPE_INDEX g_atype690_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes690 [] = {
g_atype690_0,
};

static const long offsets690 [] =
{
+ @CHROFF(0,0),
};

extern const char *names691[];
static const uint32 types691 [] =
{
SK_BOOL,
};

static const uint16 attr_flags691 [] =
{0,};

static const EIF_TYPE_INDEX g_atype691_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes691 [] = {
g_atype691_0,
};

static const long offsets691 [] =
{
+ @CHROFF(0,0),
};

extern const char *names692[];
static const uint32 types692 [] =
{
SK_BOOL,
};

static const uint16 attr_flags692 [] =
{0,};

static const EIF_TYPE_INDEX g_atype692_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes692 [] = {
g_atype692_0,
};

static const long offsets692 [] =
{
+ @CHROFF(0,0),
};

extern const char *names693[];
static const uint32 types693 [] =
{
SK_BOOL,
};

static const uint16 attr_flags693 [] =
{0,};

static const EIF_TYPE_INDEX g_atype693_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes693 [] = {
g_atype693_0,
};

static const long offsets693 [] =
{
+ @CHROFF(0,0),
};

extern const char *names694[];
static const uint32 types694 [] =
{
SK_BOOL,
};

static const uint16 attr_flags694 [] =
{0,};

static const EIF_TYPE_INDEX g_atype694_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes694 [] = {
g_atype694_0,
};

static const long offsets694 [] =
{
+ @CHROFF(0,0),
};

extern const char *names695[];
static const uint32 types695 [] =
{
SK_BOOL,
};

static const uint16 attr_flags695 [] =
{0,};

static const EIF_TYPE_INDEX g_atype695_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes695 [] = {
g_atype695_0,
};

static const long offsets695 [] =
{
+ @CHROFF(0,0),
};

extern const char *names696[];
static const uint32 types696 [] =
{
SK_BOOL,
};

static const uint16 attr_flags696 [] =
{0,};

static const EIF_TYPE_INDEX g_atype696_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes696 [] = {
g_atype696_0,
};

static const long offsets696 [] =
{
+ @CHROFF(0,0),
};

extern const char *names697[];
static const uint32 types697 [] =
{
SK_BOOL,
};

static const uint16 attr_flags697 [] =
{0,};

static const EIF_TYPE_INDEX g_atype697_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes697 [] = {
g_atype697_0,
};

static const long offsets697 [] =
{
+ @CHROFF(0,0),
};

extern const char *names698[];
static const uint32 types698 [] =
{
SK_BOOL,
};

static const uint16 attr_flags698 [] =
{0,};

static const EIF_TYPE_INDEX g_atype698_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes698 [] = {
g_atype698_0,
};

static const long offsets698 [] =
{
+ @CHROFF(0,0),
};

extern const char *names699[];
static const uint32 types699 [] =
{
SK_BOOL,
};

static const uint16 attr_flags699 [] =
{0,};

static const EIF_TYPE_INDEX g_atype699_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes699 [] = {
g_atype699_0,
};

static const long offsets699 [] =
{
+ @CHROFF(0,0),
};

extern const char *names700[];
static const uint32 types700 [] =
{
SK_BOOL,
};

static const uint16 attr_flags700 [] =
{0,};

static const EIF_TYPE_INDEX g_atype700_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes700 [] = {
g_atype700_0,
};

static const long offsets700 [] =
{
+ @CHROFF(0,0),
};

extern const char *names701[];
static const uint32 types701 [] =
{
SK_BOOL,
};

static const uint16 attr_flags701 [] =
{0,};

static const EIF_TYPE_INDEX g_atype701_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes701 [] = {
g_atype701_0,
};

static const long offsets701 [] =
{
+ @CHROFF(0,0),
};

extern const char *names702[];
static const uint32 types702 [] =
{
SK_BOOL,
};

static const uint16 attr_flags702 [] =
{0,};

static const EIF_TYPE_INDEX g_atype702_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes702 [] = {
g_atype702_0,
};

static const long offsets702 [] =
{
+ @CHROFF(0,0),
};

extern const char *names703[];
static const uint32 types703 [] =
{
SK_BOOL,
};

static const uint16 attr_flags703 [] =
{0,};

static const EIF_TYPE_INDEX g_atype703_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes703 [] = {
g_atype703_0,
};

static const long offsets703 [] =
{
+ @CHROFF(0,0),
};

extern const char *names704[];
static const uint32 types704 [] =
{
SK_BOOL,
};

static const uint16 attr_flags704 [] =
{0,};

static const EIF_TYPE_INDEX g_atype704_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes704 [] = {
g_atype704_0,
};

static const long offsets704 [] =
{
+ @CHROFF(0,0),
};

extern const char *names705[];
static const uint32 types705 [] =
{
SK_BOOL,
};

static const uint16 attr_flags705 [] =
{0,};

static const EIF_TYPE_INDEX g_atype705_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes705 [] = {
g_atype705_0,
};

static const long offsets705 [] =
{
+ @CHROFF(0,0),
};

extern const char *names706[];
static const uint32 types706 [] =
{
SK_BOOL,
};

static const uint16 attr_flags706 [] =
{0,};

static const EIF_TYPE_INDEX g_atype706_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes706 [] = {
g_atype706_0,
};

static const long offsets706 [] =
{
+ @CHROFF(0,0),
};

extern const char *names707[];
static const uint32 types707 [] =
{
SK_BOOL,
};

static const uint16 attr_flags707 [] =
{0,};

static const EIF_TYPE_INDEX g_atype707_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes707 [] = {
g_atype707_0,
};

static const long offsets707 [] =
{
+ @CHROFF(0,0),
};

extern const char *names708[];
static const uint32 types708 [] =
{
SK_BOOL,
};

static const uint16 attr_flags708 [] =
{0,};

static const EIF_TYPE_INDEX g_atype708_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes708 [] = {
g_atype708_0,
};

static const long offsets708 [] =
{
+ @CHROFF(0,0),
};

extern const char *names709[];
static const uint32 types709 [] =
{
SK_BOOL,
};

static const uint16 attr_flags709 [] =
{0,};

static const EIF_TYPE_INDEX g_atype709_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes709 [] = {
g_atype709_0,
};

static const long offsets709 [] =
{
+ @CHROFF(0,0),
};

extern const char *names710[];
static const uint32 types710 [] =
{
SK_BOOL,
};

static const uint16 attr_flags710 [] =
{0,};

static const EIF_TYPE_INDEX g_atype710_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes710 [] = {
g_atype710_0,
};

static const long offsets710 [] =
{
+ @CHROFF(0,0),
};

extern const char *names711[];
static const uint32 types711 [] =
{
SK_BOOL,
};

static const uint16 attr_flags711 [] =
{0,};

static const EIF_TYPE_INDEX g_atype711_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes711 [] = {
g_atype711_0,
};

static const long offsets711 [] =
{
+ @CHROFF(0,0),
};

extern const char *names712[];
static const uint32 types712 [] =
{
SK_BOOL,
};

static const uint16 attr_flags712 [] =
{0,};

static const EIF_TYPE_INDEX g_atype712_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes712 [] = {
g_atype712_0,
};

static const long offsets712 [] =
{
+ @CHROFF(0,0),
};

extern const char *names713[];
static const uint32 types713 [] =
{
SK_BOOL,
};

static const uint16 attr_flags713 [] =
{0,};

static const EIF_TYPE_INDEX g_atype713_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes713 [] = {
g_atype713_0,
};

static const long offsets713 [] =
{
+ @CHROFF(0,0),
};

extern const char *names714[];
static const uint32 types714 [] =
{
SK_BOOL,
};

static const uint16 attr_flags714 [] =
{0,};

static const EIF_TYPE_INDEX g_atype714_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes714 [] = {
g_atype714_0,
};

static const long offsets714 [] =
{
+ @CHROFF(0,0),
};

extern const char *names715[];
static const uint32 types715 [] =
{
SK_BOOL,
};

static const uint16 attr_flags715 [] =
{0,};

static const EIF_TYPE_INDEX g_atype715_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes715 [] = {
g_atype715_0,
};

static const long offsets715 [] =
{
+ @CHROFF(0,0),
};

extern const char *names716[];
static const uint32 types716 [] =
{
SK_BOOL,
};

static const uint16 attr_flags716 [] =
{0,};

static const EIF_TYPE_INDEX g_atype716_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes716 [] = {
g_atype716_0,
};

static const long offsets716 [] =
{
+ @CHROFF(0,0),
};

extern const char *names717[];
static const uint32 types717 [] =
{
SK_BOOL,
};

static const uint16 attr_flags717 [] =
{0,};

static const EIF_TYPE_INDEX g_atype717_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes717 [] = {
g_atype717_0,
};

static const long offsets717 [] =
{
+ @CHROFF(0,0),
};

extern const char *names718[];
static const uint32 types718 [] =
{
SK_BOOL,
};

static const uint16 attr_flags718 [] =
{0,};

static const EIF_TYPE_INDEX g_atype718_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes718 [] = {
g_atype718_0,
};

static const long offsets718 [] =
{
+ @CHROFF(0,0),
};

extern const char *names719[];
static const uint32 types719 [] =
{
SK_BOOL,
};

static const uint16 attr_flags719 [] =
{0,};

static const EIF_TYPE_INDEX g_atype719_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes719 [] = {
g_atype719_0,
};

static const long offsets719 [] =
{
+ @CHROFF(0,0),
};

extern const char *names720[];
static const uint32 types720 [] =
{
SK_BOOL,
};

static const uint16 attr_flags720 [] =
{0,};

static const EIF_TYPE_INDEX g_atype720_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes720 [] = {
g_atype720_0,
};

static const long offsets720 [] =
{
+ @CHROFF(0,0),
};

extern const char *names721[];
static const uint32 types721 [] =
{
SK_BOOL,
};

static const uint16 attr_flags721 [] =
{0,};

static const EIF_TYPE_INDEX g_atype721_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes721 [] = {
g_atype721_0,
};

static const long offsets721 [] =
{
+ @CHROFF(0,0),
};

extern const char *names722[];
static const uint32 types722 [] =
{
SK_BOOL,
};

static const uint16 attr_flags722 [] =
{0,};

static const EIF_TYPE_INDEX g_atype722_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes722 [] = {
g_atype722_0,
};

static const long offsets722 [] =
{
+ @CHROFF(0,0),
};

extern const char *names723[];
static const uint32 types723 [] =
{
SK_BOOL,
};

static const uint16 attr_flags723 [] =
{0,};

static const EIF_TYPE_INDEX g_atype723_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes723 [] = {
g_atype723_0,
};

static const long offsets723 [] =
{
+ @CHROFF(0,0),
};

extern const char *names724[];
static const uint32 types724 [] =
{
SK_BOOL,
};

static const uint16 attr_flags724 [] =
{0,};

static const EIF_TYPE_INDEX g_atype724_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes724 [] = {
g_atype724_0,
};

static const long offsets724 [] =
{
+ @CHROFF(0,0),
};

extern const char *names725[];
static const uint32 types725 [] =
{
SK_BOOL,
};

static const uint16 attr_flags725 [] =
{0,};

static const EIF_TYPE_INDEX g_atype725_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes725 [] = {
g_atype725_0,
};

static const long offsets725 [] =
{
+ @CHROFF(0,0),
};

extern const char *names726[];
static const uint32 types726 [] =
{
SK_BOOL,
};

static const uint16 attr_flags726 [] =
{0,};

static const EIF_TYPE_INDEX g_atype726_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes726 [] = {
g_atype726_0,
};

static const long offsets726 [] =
{
+ @CHROFF(0,0),
};

extern const char *names727[];
static const uint32 types727 [] =
{
SK_BOOL,
};

static const uint16 attr_flags727 [] =
{0,};

static const EIF_TYPE_INDEX g_atype727_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes727 [] = {
g_atype727_0,
};

static const long offsets727 [] =
{
+ @CHROFF(0,0),
};

extern const char *names728[];
static const uint32 types728 [] =
{
SK_BOOL,
};

static const uint16 attr_flags728 [] =
{0,};

static const EIF_TYPE_INDEX g_atype728_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes728 [] = {
g_atype728_0,
};

static const long offsets728 [] =
{
+ @CHROFF(0,0),
};

extern const char *names729[];
static const uint32 types729 [] =
{
SK_BOOL,
};

static const uint16 attr_flags729 [] =
{0,};

static const EIF_TYPE_INDEX g_atype729_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes729 [] = {
g_atype729_0,
};

static const long offsets729 [] =
{
+ @CHROFF(0,0),
};

extern const char *names730[];
static const uint32 types730 [] =
{
SK_BOOL,
};

static const uint16 attr_flags730 [] =
{0,};

static const EIF_TYPE_INDEX g_atype730_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes730 [] = {
g_atype730_0,
};

static const long offsets730 [] =
{
+ @CHROFF(0,0),
};

extern const char *names731[];
static const uint32 types731 [] =
{
SK_BOOL,
};

static const uint16 attr_flags731 [] =
{0,};

static const EIF_TYPE_INDEX g_atype731_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes731 [] = {
g_atype731_0,
};

static const long offsets731 [] =
{
+ @CHROFF(0,0),
};

extern const char *names732[];
static const uint32 types732 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags732 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype732_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_1 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_2 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_3 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_4 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_7 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_8 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_9 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_10 [] = {909,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_11 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_15 [] = {927,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_16 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_17 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_18 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype732_19 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes732 [] = {
g_atype732_0,
g_atype732_1,
g_atype732_2,
g_atype732_3,
g_atype732_4,
g_atype732_5,
g_atype732_6,
g_atype732_7,
g_atype732_8,
g_atype732_9,
g_atype732_10,
g_atype732_11,
g_atype732_12,
g_atype732_13,
g_atype732_14,
g_atype732_15,
g_atype732_16,
g_atype732_17,
g_atype732_18,
g_atype732_19,
};

static const long offsets732 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
+ @CHROFF(3,3),
+ @CHROFF(3,4),
+ @CHROFF(3,5),
+ @I16OFF(3,6,0),
+ @I16OFF(3,6,1),
+ @LNGOFF(3,6,2,0),
+ @LNGOFF(3,6,2,1),
+ @LNGOFF(3,6,2,2),
+ @LNGOFF(3,6,2,3),
+ @R32OFF(3,6,2,4,0),
+ @PTROFF(3,6,2,4,1,0),
+ @I64OFF(3,6,2,4,1,1,0),
+ @I64OFF(3,6,2,4,1,1,1),
+ @R64OFF(3,6,2,4,1,1,2,0),
};

extern const char *names733[];
static const uint32 types733 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags733 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype733_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_1 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_2 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_3 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_4 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_5 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_8 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_9 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_10 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_11 [] = {909,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_12 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_16 [] = {927,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_17 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_18 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_19 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype733_20 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes733 [] = {
g_atype733_0,
g_atype733_1,
g_atype733_2,
g_atype733_3,
g_atype733_4,
g_atype733_5,
g_atype733_6,
g_atype733_7,
g_atype733_8,
g_atype733_9,
g_atype733_10,
g_atype733_11,
g_atype733_12,
g_atype733_13,
g_atype733_14,
g_atype733_15,
g_atype733_16,
g_atype733_17,
g_atype733_18,
g_atype733_19,
g_atype733_20,
};

static const long offsets733 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @CHROFF(4,5),
+ @I16OFF(4,6,0),
+ @I16OFF(4,6,1),
+ @LNGOFF(4,6,2,0),
+ @LNGOFF(4,6,2,1),
+ @LNGOFF(4,6,2,2),
+ @LNGOFF(4,6,2,3),
+ @R32OFF(4,6,2,4,0),
+ @PTROFF(4,6,2,4,1,0),
+ @I64OFF(4,6,2,4,1,1,0),
+ @I64OFF(4,6,2,4,1,1,1),
+ @R64OFF(4,6,2,4,1,1,2,0),
};

extern const char *names734[];
static const uint32 types734 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags734 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype734_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_1 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_2 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_3 [] = {0xFF01,983,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_4 [] = {39,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_5 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_6 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_9 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_10 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_11 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_12 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_13 [] = {909,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_14 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_18 [] = {927,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_19 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_20 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_21 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype734_22 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes734 [] = {
g_atype734_0,
g_atype734_1,
g_atype734_2,
g_atype734_3,
g_atype734_4,
g_atype734_5,
g_atype734_6,
g_atype734_7,
g_atype734_8,
g_atype734_9,
g_atype734_10,
g_atype734_11,
g_atype734_12,
g_atype734_13,
g_atype734_14,
g_atype734_15,
g_atype734_16,
g_atype734_17,
g_atype734_18,
g_atype734_19,
g_atype734_20,
g_atype734_21,
g_atype734_22,
};

static const long offsets734 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names759[];
static const uint32 types759 [] =
{
SK_BOOL,
};

static const uint16 attr_flags759 [] =
{0,};

static const EIF_TYPE_INDEX g_atype759_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes759 [] = {
g_atype759_0,
};

static const long offsets759 [] =
{
+ @CHROFF(0,0),
};

extern const char *names760[];
static const uint32 types760 [] =
{
SK_BOOL,
};

static const uint16 attr_flags760 [] =
{0,};

static const EIF_TYPE_INDEX g_atype760_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes760 [] = {
g_atype760_0,
};

static const long offsets760 [] =
{
+ @CHROFF(0,0),
};

extern const char *names761[];
static const uint32 types761 [] =
{
SK_BOOL,
};

static const uint16 attr_flags761 [] =
{0,};

static const EIF_TYPE_INDEX g_atype761_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes761 [] = {
g_atype761_0,
};

static const long offsets761 [] =
{
+ @CHROFF(0,0),
};

extern const char *names762[];
static const uint32 types762 [] =
{
SK_BOOL,
};

static const uint16 attr_flags762 [] =
{0,};

static const EIF_TYPE_INDEX g_atype762_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes762 [] = {
g_atype762_0,
};

static const long offsets762 [] =
{
+ @CHROFF(0,0),
};

extern const char *names763[];
static const uint32 types763 [] =
{
SK_BOOL,
};

static const uint16 attr_flags763 [] =
{0,};

static const EIF_TYPE_INDEX g_atype763_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes763 [] = {
g_atype763_0,
};

static const long offsets763 [] =
{
+ @CHROFF(0,0),
};

extern const char *names764[];
static const uint32 types764 [] =
{
SK_BOOL,
};

static const uint16 attr_flags764 [] =
{0,};

static const EIF_TYPE_INDEX g_atype764_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes764 [] = {
g_atype764_0,
};

static const long offsets764 [] =
{
+ @CHROFF(0,0),
};

extern const char *names765[];
static const uint32 types765 [] =
{
SK_BOOL,
};

static const uint16 attr_flags765 [] =
{0,};

static const EIF_TYPE_INDEX g_atype765_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes765 [] = {
g_atype765_0,
};

static const long offsets765 [] =
{
+ @CHROFF(0,0),
};

extern const char *names766[];
static const uint32 types766 [] =
{
SK_BOOL,
};

static const uint16 attr_flags766 [] =
{0,};

static const EIF_TYPE_INDEX g_atype766_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes766 [] = {
g_atype766_0,
};

static const long offsets766 [] =
{
+ @CHROFF(0,0),
};

extern const char *names767[];
static const uint32 types767 [] =
{
SK_BOOL,
};

static const uint16 attr_flags767 [] =
{0,};

static const EIF_TYPE_INDEX g_atype767_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes767 [] = {
g_atype767_0,
};

static const long offsets767 [] =
{
+ @CHROFF(0,0),
};

extern const char *names768[];
static const uint32 types768 [] =
{
SK_BOOL,
};

static const uint16 attr_flags768 [] =
{0,};

static const EIF_TYPE_INDEX g_atype768_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes768 [] = {
g_atype768_0,
};

static const long offsets768 [] =
{
+ @CHROFF(0,0),
};

extern const char *names769[];
static const uint32 types769 [] =
{
SK_BOOL,
};

static const uint16 attr_flags769 [] =
{0,};

static const EIF_TYPE_INDEX g_atype769_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes769 [] = {
g_atype769_0,
};

static const long offsets769 [] =
{
+ @CHROFF(0,0),
};

extern const char *names770[];
static const uint32 types770 [] =
{
SK_BOOL,
};

static const uint16 attr_flags770 [] =
{0,};

static const EIF_TYPE_INDEX g_atype770_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes770 [] = {
g_atype770_0,
};

static const long offsets770 [] =
{
+ @CHROFF(0,0),
};

extern const char *names771[];
static const uint32 types771 [] =
{
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags771 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype771_0 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype771_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes771 [] = {
g_atype771_0,
g_atype771_1,
g_atype771_2,
};

static const long offsets771 [] =
{
+ @CHROFF(0,0),
+ @LNGOFF(0,1,0,0),
+ @LNGOFF(0,1,0,1),
};

extern const char *names772[];
static const uint32 types772 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags772 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype772_0 [] = {0xFF01,746,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype772_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes772 [] = {
g_atype772_0,
g_atype772_1,
g_atype772_2,
g_atype772_3,
};

static const long offsets772 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names773[];
static const uint32 types773 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags773 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype773_0 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype773_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes773 [] = {
g_atype773_0,
g_atype773_1,
g_atype773_2,
g_atype773_3,
};

static const long offsets773 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names774[];
static const uint32 types774 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags774 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype774_0 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype774_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes774 [] = {
g_atype774_0,
g_atype774_1,
g_atype774_2,
g_atype774_3,
};

static const long offsets774 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names775[];
static const uint32 types775 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags775 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype775_0 [] = {0xFF01,749,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype775_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes775 [] = {
g_atype775_0,
g_atype775_1,
g_atype775_2,
g_atype775_3,
};

static const long offsets775 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names776[];
static const uint32 types776 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags776 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype776_0 [] = {0xFF01,750,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype776_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes776 [] = {
g_atype776_0,
g_atype776_1,
g_atype776_2,
g_atype776_3,
};

static const long offsets776 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names777[];
static const uint32 types777 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags777 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype777_0 [] = {0xFF01,751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype777_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes777 [] = {
g_atype777_0,
g_atype777_1,
g_atype777_2,
g_atype777_3,
};

static const long offsets777 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names778[];
static const uint32 types778 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags778 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype778_0 [] = {0xFF01,752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype778_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes778 [] = {
g_atype778_0,
g_atype778_1,
g_atype778_2,
g_atype778_3,
};

static const long offsets778 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names779[];
static const uint32 types779 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags779 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype779_0 [] = {0xFF01,753,924,0xFFFF};
static const EIF_TYPE_INDEX g_atype779_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype779_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype779_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes779 [] = {
g_atype779_0,
g_atype779_1,
g_atype779_2,
g_atype779_3,
};

static const long offsets779 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names780[];
static const uint32 types780 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags780 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype780_0 [] = {0xFF01,754,921,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype780_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes780 [] = {
g_atype780_0,
g_atype780_1,
g_atype780_2,
g_atype780_3,
};

static const long offsets780 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names781[];
static const uint32 types781 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags781 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype781_0 [] = {0xFF01,755,972,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype781_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes781 [] = {
g_atype781_0,
g_atype781_1,
g_atype781_2,
g_atype781_3,
};

static const long offsets781 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names782[];
static const uint32 types782 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags782 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype782_0 [] = {0xFF01,756,927,0xFFFF};
static const EIF_TYPE_INDEX g_atype782_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype782_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype782_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes782 [] = {
g_atype782_0,
g_atype782_1,
g_atype782_2,
g_atype782_3,
};

static const long offsets782 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names783[];
static const uint32 types783 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags783 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype783_0 [] = {0xFF01,757,930,0xFFFF};
static const EIF_TYPE_INDEX g_atype783_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype783_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype783_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes783 [] = {
g_atype783_0,
g_atype783_1,
g_atype783_2,
g_atype783_3,
};

static const long offsets783 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names784[];
static const uint32 types784 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags784 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype784_0 [] = {0xFF01,746,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype784_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes784 [] = {
g_atype784_0,
g_atype784_1,
g_atype784_2,
g_atype784_3,
};

static const long offsets784 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names785[];
static const uint32 types785 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags785 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype785_0 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype785_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes785 [] = {
g_atype785_0,
g_atype785_1,
g_atype785_2,
g_atype785_3,
};

static const long offsets785 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names786[];
static const uint32 types786 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags786 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype786_0 [] = {0xFF01,750,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype786_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes786 [] = {
g_atype786_0,
g_atype786_1,
g_atype786_2,
g_atype786_3,
};

static const long offsets786 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names787[];
static const uint32 types787 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags787 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype787_0 [] = {0xFF01,749,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype787_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes787 [] = {
g_atype787_0,
g_atype787_1,
g_atype787_2,
g_atype787_3,
};

static const long offsets787 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names788[];
static const uint32 types788 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags788 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype788_0 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype788_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes788 [] = {
g_atype788_0,
g_atype788_1,
g_atype788_2,
g_atype788_3,
};

static const long offsets788 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names789[];
static const uint32 types789 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags789 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype789_0 [] = {0xFF01,752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype789_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes789 [] = {
g_atype789_0,
g_atype789_1,
g_atype789_2,
g_atype789_3,
};

static const long offsets789 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names790[];
static const uint32 types790 [] =
{
SK_BOOL,
};

static const uint16 attr_flags790 [] =
{0,};

static const EIF_TYPE_INDEX g_atype790_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes790 [] = {
g_atype790_0,
};

static const long offsets790 [] =
{
+ @CHROFF(0,0),
};

extern const char *names791[];
static const uint32 types791 [] =
{
SK_BOOL,
};

static const uint16 attr_flags791 [] =
{0,};

static const EIF_TYPE_INDEX g_atype791_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes791 [] = {
g_atype791_0,
};

static const long offsets791 [] =
{
+ @CHROFF(0,0),
};

extern const char *names792[];
static const uint32 types792 [] =
{
SK_BOOL,
};

static const uint16 attr_flags792 [] =
{0,};

static const EIF_TYPE_INDEX g_atype792_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes792 [] = {
g_atype792_0,
};

static const long offsets792 [] =
{
+ @CHROFF(0,0),
};

extern const char *names793[];
static const uint32 types793 [] =
{
SK_BOOL,
};

static const uint16 attr_flags793 [] =
{0,};

static const EIF_TYPE_INDEX g_atype793_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes793 [] = {
g_atype793_0,
};

static const long offsets793 [] =
{
+ @CHROFF(0,0),
};

extern const char *names794[];
static const uint32 types794 [] =
{
SK_BOOL,
};

static const uint16 attr_flags794 [] =
{0,};

static const EIF_TYPE_INDEX g_atype794_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes794 [] = {
g_atype794_0,
};

static const long offsets794 [] =
{
+ @CHROFF(0,0),
};

extern const char *names795[];
static const uint32 types795 [] =
{
SK_BOOL,
};

static const uint16 attr_flags795 [] =
{0,};

static const EIF_TYPE_INDEX g_atype795_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes795 [] = {
g_atype795_0,
};

static const long offsets795 [] =
{
+ @CHROFF(0,0),
};

extern const char *names796[];
static const uint32 types796 [] =
{
SK_BOOL,
};

static const uint16 attr_flags796 [] =
{0,};

static const EIF_TYPE_INDEX g_atype796_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes796 [] = {
g_atype796_0,
};

static const long offsets796 [] =
{
+ @CHROFF(0,0),
};

extern const char *names797[];
static const uint32 types797 [] =
{
SK_BOOL,
};

static const uint16 attr_flags797 [] =
{0,};

static const EIF_TYPE_INDEX g_atype797_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes797 [] = {
g_atype797_0,
};

static const long offsets797 [] =
{
+ @CHROFF(0,0),
};

extern const char *names798[];
static const uint32 types798 [] =
{
SK_BOOL,
};

static const uint16 attr_flags798 [] =
{0,};

static const EIF_TYPE_INDEX g_atype798_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes798 [] = {
g_atype798_0,
};

static const long offsets798 [] =
{
+ @CHROFF(0,0),
};

extern const char *names799[];
static const uint32 types799 [] =
{
SK_BOOL,
};

static const uint16 attr_flags799 [] =
{0,};

static const EIF_TYPE_INDEX g_atype799_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes799 [] = {
g_atype799_0,
};

static const long offsets799 [] =
{
+ @CHROFF(0,0),
};

extern const char *names800[];
static const uint32 types800 [] =
{
SK_BOOL,
};

static const uint16 attr_flags800 [] =
{0,};

static const EIF_TYPE_INDEX g_atype800_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes800 [] = {
g_atype800_0,
};

static const long offsets800 [] =
{
+ @CHROFF(0,0),
};

extern const char *names801[];
static const uint32 types801 [] =
{
SK_BOOL,
};

static const uint16 attr_flags801 [] =
{0,};

static const EIF_TYPE_INDEX g_atype801_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes801 [] = {
g_atype801_0,
};

static const long offsets801 [] =
{
+ @CHROFF(0,0),
};

extern const char *names802[];
static const uint32 types802 [] =
{
SK_BOOL,
};

static const uint16 attr_flags802 [] =
{0,};

static const EIF_TYPE_INDEX g_atype802_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes802 [] = {
g_atype802_0,
};

static const long offsets802 [] =
{
+ @CHROFF(0,0),
};

extern const char *names803[];
static const uint32 types803 [] =
{
SK_BOOL,
};

static const uint16 attr_flags803 [] =
{0,};

static const EIF_TYPE_INDEX g_atype803_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes803 [] = {
g_atype803_0,
};

static const long offsets803 [] =
{
+ @CHROFF(0,0),
};

extern const char *names804[];
static const uint32 types804 [] =
{
SK_BOOL,
};

static const uint16 attr_flags804 [] =
{0,};

static const EIF_TYPE_INDEX g_atype804_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes804 [] = {
g_atype804_0,
};

static const long offsets804 [] =
{
+ @CHROFF(0,0),
};

extern const char *names805[];
static const uint32 types805 [] =
{
SK_BOOL,
};

static const uint16 attr_flags805 [] =
{0,};

static const EIF_TYPE_INDEX g_atype805_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes805 [] = {
g_atype805_0,
};

static const long offsets805 [] =
{
+ @CHROFF(0,0),
};

extern const char *names806[];
static const uint32 types806 [] =
{
SK_BOOL,
};

static const uint16 attr_flags806 [] =
{0,};

static const EIF_TYPE_INDEX g_atype806_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes806 [] = {
g_atype806_0,
};

static const long offsets806 [] =
{
+ @CHROFF(0,0),
};

extern const char *names807[];
static const uint32 types807 [] =
{
SK_BOOL,
};

static const uint16 attr_flags807 [] =
{0,};

static const EIF_TYPE_INDEX g_atype807_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes807 [] = {
g_atype807_0,
};

static const long offsets807 [] =
{
+ @CHROFF(0,0),
};

extern const char *names808[];
static const uint32 types808 [] =
{
SK_BOOL,
};

static const uint16 attr_flags808 [] =
{0,};

static const EIF_TYPE_INDEX g_atype808_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes808 [] = {
g_atype808_0,
};

static const long offsets808 [] =
{
+ @CHROFF(0,0),
};

extern const char *names809[];
static const uint32 types809 [] =
{
SK_BOOL,
};

static const uint16 attr_flags809 [] =
{0,};

static const EIF_TYPE_INDEX g_atype809_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes809 [] = {
g_atype809_0,
};

static const long offsets809 [] =
{
+ @CHROFF(0,0),
};

extern const char *names810[];
static const uint32 types810 [] =
{
SK_BOOL,
};

static const uint16 attr_flags810 [] =
{0,};

static const EIF_TYPE_INDEX g_atype810_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes810 [] = {
g_atype810_0,
};

static const long offsets810 [] =
{
+ @CHROFF(0,0),
};

extern const char *names811[];
static const uint32 types811 [] =
{
SK_BOOL,
};

static const uint16 attr_flags811 [] =
{0,};

static const EIF_TYPE_INDEX g_atype811_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes811 [] = {
g_atype811_0,
};

static const long offsets811 [] =
{
+ @CHROFF(0,0),
};

extern const char *names812[];
static const uint32 types812 [] =
{
SK_BOOL,
};

static const uint16 attr_flags812 [] =
{0,};

static const EIF_TYPE_INDEX g_atype812_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes812 [] = {
g_atype812_0,
};

static const long offsets812 [] =
{
+ @CHROFF(0,0),
};

extern const char *names813[];
static const uint32 types813 [] =
{
SK_BOOL,
};

static const uint16 attr_flags813 [] =
{0,};

static const EIF_TYPE_INDEX g_atype813_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes813 [] = {
g_atype813_0,
};

static const long offsets813 [] =
{
+ @CHROFF(0,0),
};

extern const char *names814[];
static const uint32 types814 [] =
{
SK_BOOL,
};

static const uint16 attr_flags814 [] =
{0,};

static const EIF_TYPE_INDEX g_atype814_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes814 [] = {
g_atype814_0,
};

static const long offsets814 [] =
{
+ @CHROFF(0,0),
};

extern const char *names815[];
static const uint32 types815 [] =
{
SK_BOOL,
};

static const uint16 attr_flags815 [] =
{0,};

static const EIF_TYPE_INDEX g_atype815_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes815 [] = {
g_atype815_0,
};

static const long offsets815 [] =
{
+ @CHROFF(0,0),
};

extern const char *names816[];
static const uint32 types816 [] =
{
SK_BOOL,
};

static const uint16 attr_flags816 [] =
{0,};

static const EIF_TYPE_INDEX g_atype816_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes816 [] = {
g_atype816_0,
};

static const long offsets816 [] =
{
+ @CHROFF(0,0),
};

extern const char *names817[];
static const uint32 types817 [] =
{
SK_BOOL,
};

static const uint16 attr_flags817 [] =
{0,};

static const EIF_TYPE_INDEX g_atype817_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes817 [] = {
g_atype817_0,
};

static const long offsets817 [] =
{
+ @CHROFF(0,0),
};

extern const char *names818[];
static const uint32 types818 [] =
{
SK_BOOL,
};

static const uint16 attr_flags818 [] =
{0,};

static const EIF_TYPE_INDEX g_atype818_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes818 [] = {
g_atype818_0,
};

static const long offsets818 [] =
{
+ @CHROFF(0,0),
};

extern const char *names819[];
static const uint32 types819 [] =
{
SK_BOOL,
};

static const uint16 attr_flags819 [] =
{0,};

static const EIF_TYPE_INDEX g_atype819_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes819 [] = {
g_atype819_0,
};

static const long offsets819 [] =
{
+ @CHROFF(0,0),
};

extern const char *names820[];
static const uint32 types820 [] =
{
SK_BOOL,
};

static const uint16 attr_flags820 [] =
{0,};

static const EIF_TYPE_INDEX g_atype820_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes820 [] = {
g_atype820_0,
};

static const long offsets820 [] =
{
+ @CHROFF(0,0),
};

extern const char *names821[];
static const uint32 types821 [] =
{
SK_BOOL,
};

static const uint16 attr_flags821 [] =
{0,};

static const EIF_TYPE_INDEX g_atype821_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes821 [] = {
g_atype821_0,
};

static const long offsets821 [] =
{
+ @CHROFF(0,0),
};

extern const char *names822[];
static const uint32 types822 [] =
{
SK_BOOL,
};

static const uint16 attr_flags822 [] =
{0,};

static const EIF_TYPE_INDEX g_atype822_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes822 [] = {
g_atype822_0,
};

static const long offsets822 [] =
{
+ @CHROFF(0,0),
};

extern const char *names823[];
static const uint32 types823 [] =
{
SK_BOOL,
};

static const uint16 attr_flags823 [] =
{0,};

static const EIF_TYPE_INDEX g_atype823_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes823 [] = {
g_atype823_0,
};

static const long offsets823 [] =
{
+ @CHROFF(0,0),
};

extern const char *names824[];
static const uint32 types824 [] =
{
SK_BOOL,
};

static const uint16 attr_flags824 [] =
{0,};

static const EIF_TYPE_INDEX g_atype824_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes824 [] = {
g_atype824_0,
};

static const long offsets824 [] =
{
+ @CHROFF(0,0),
};

extern const char *names825[];
static const uint32 types825 [] =
{
SK_BOOL,
};

static const uint16 attr_flags825 [] =
{0,};

static const EIF_TYPE_INDEX g_atype825_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes825 [] = {
g_atype825_0,
};

static const long offsets825 [] =
{
+ @CHROFF(0,0),
};

extern const char *names826[];
static const uint32 types826 [] =
{
SK_BOOL,
};

static const uint16 attr_flags826 [] =
{0,};

static const EIF_TYPE_INDEX g_atype826_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes826 [] = {
g_atype826_0,
};

static const long offsets826 [] =
{
+ @CHROFF(0,0),
};

extern const char *names827[];
static const uint32 types827 [] =
{
SK_BOOL,
};

static const uint16 attr_flags827 [] =
{0,};

static const EIF_TYPE_INDEX g_atype827_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes827 [] = {
g_atype827_0,
};

static const long offsets827 [] =
{
+ @CHROFF(0,0),
};

extern const char *names828[];
static const uint32 types828 [] =
{
SK_BOOL,
};

static const uint16 attr_flags828 [] =
{0,};

static const EIF_TYPE_INDEX g_atype828_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes828 [] = {
g_atype828_0,
};

static const long offsets828 [] =
{
+ @CHROFF(0,0),
};

extern const char *names829[];
static const uint32 types829 [] =
{
SK_BOOL,
};

static const uint16 attr_flags829 [] =
{0,};

static const EIF_TYPE_INDEX g_atype829_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes829 [] = {
g_atype829_0,
};

static const long offsets829 [] =
{
+ @CHROFF(0,0),
};

extern const char *names830[];
static const uint32 types830 [] =
{
SK_BOOL,
};

static const uint16 attr_flags830 [] =
{0,};

static const EIF_TYPE_INDEX g_atype830_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes830 [] = {
g_atype830_0,
};

static const long offsets830 [] =
{
+ @CHROFF(0,0),
};

extern const char *names831[];
static const uint32 types831 [] =
{
SK_BOOL,
};

static const uint16 attr_flags831 [] =
{0,};

static const EIF_TYPE_INDEX g_atype831_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes831 [] = {
g_atype831_0,
};

static const long offsets831 [] =
{
+ @CHROFF(0,0),
};

extern const char *names832[];
static const uint32 types832 [] =
{
SK_BOOL,
};

static const uint16 attr_flags832 [] =
{0,};

static const EIF_TYPE_INDEX g_atype832_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes832 [] = {
g_atype832_0,
};

static const long offsets832 [] =
{
+ @CHROFF(0,0),
};

extern const char *names833[];
static const uint32 types833 [] =
{
SK_BOOL,
};

static const uint16 attr_flags833 [] =
{0,};

static const EIF_TYPE_INDEX g_atype833_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes833 [] = {
g_atype833_0,
};

static const long offsets833 [] =
{
+ @CHROFF(0,0),
};

extern const char *names834[];
static const uint32 types834 [] =
{
SK_BOOL,
};

static const uint16 attr_flags834 [] =
{0,};

static const EIF_TYPE_INDEX g_atype834_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes834 [] = {
g_atype834_0,
};

static const long offsets834 [] =
{
+ @CHROFF(0,0),
};

extern const char *names835[];
static const uint32 types835 [] =
{
SK_BOOL,
};

static const uint16 attr_flags835 [] =
{0,};

static const EIF_TYPE_INDEX g_atype835_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes835 [] = {
g_atype835_0,
};

static const long offsets835 [] =
{
+ @CHROFF(0,0),
};

extern const char *names836[];
static const uint32 types836 [] =
{
SK_BOOL,
};

static const uint16 attr_flags836 [] =
{0,};

static const EIF_TYPE_INDEX g_atype836_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes836 [] = {
g_atype836_0,
};

static const long offsets836 [] =
{
+ @CHROFF(0,0),
};

extern const char *names837[];
static const uint32 types837 [] =
{
SK_BOOL,
};

static const uint16 attr_flags837 [] =
{0,};

static const EIF_TYPE_INDEX g_atype837_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes837 [] = {
g_atype837_0,
};

static const long offsets837 [] =
{
+ @CHROFF(0,0),
};

extern const char *names838[];
static const uint32 types838 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags838 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype838_0 [] = {126,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_1 [] = {126,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype838_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes838 [] = {
g_atype838_0,
g_atype838_1,
g_atype838_2,
g_atype838_3,
g_atype838_4,
g_atype838_5,
};

static const long offsets838 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names839[];
static const uint32 types839 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags839 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype839_0 [] = {127,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype839_1 [] = {127,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype839_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype839_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype839_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype839_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes839 [] = {
g_atype839_0,
g_atype839_1,
g_atype839_2,
g_atype839_3,
g_atype839_4,
g_atype839_5,
};

static const long offsets839 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
+ @LNGOFF(2,3,0,0),
};

extern const char *names842[];
static const uint32 types842 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags842 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype842_0 [] = {0xFF01,746,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype842_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype842_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype842_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes842 [] = {
g_atype842_0,
g_atype842_1,
g_atype842_2,
g_atype842_3,
};

static const long offsets842 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names843[];
static const uint32 types843 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags843 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype843_0 [] = {0xFF01,746,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype843_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype843_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes843 [] = {
g_atype843_0,
g_atype843_1,
g_atype843_2,
};

static const long offsets843 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names844[];
static const uint32 types844 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags844 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype844_0 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype844_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype844_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes844 [] = {
g_atype844_0,
g_atype844_1,
g_atype844_2,
};

static const long offsets844 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names845[];
static const uint32 types845 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags845 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype845_0 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype845_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype845_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes845 [] = {
g_atype845_0,
g_atype845_1,
g_atype845_2,
};

static const long offsets845 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names846[];
static const uint32 types846 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags846 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype846_0 [] = {0xFF01,749,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype846_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype846_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes846 [] = {
g_atype846_0,
g_atype846_1,
g_atype846_2,
};

static const long offsets846 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names847[];
static const uint32 types847 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags847 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype847_0 [] = {0xFF01,750,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype847_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype847_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes847 [] = {
g_atype847_0,
g_atype847_1,
g_atype847_2,
};

static const long offsets847 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names848[];
static const uint32 types848 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags848 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype848_0 [] = {0xFF01,751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype848_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype848_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes848 [] = {
g_atype848_0,
g_atype848_1,
g_atype848_2,
};

static const long offsets848 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names849[];
static const uint32 types849 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags849 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype849_0 [] = {0xFF01,752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype849_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype849_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes849 [] = {
g_atype849_0,
g_atype849_1,
g_atype849_2,
};

static const long offsets849 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names850[];
static const uint32 types850 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags850 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype850_0 [] = {0xFF01,753,924,0xFFFF};
static const EIF_TYPE_INDEX g_atype850_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype850_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes850 [] = {
g_atype850_0,
g_atype850_1,
g_atype850_2,
};

static const long offsets850 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names851[];
static const uint32 types851 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags851 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype851_0 [] = {0xFF01,754,921,0xFFFF};
static const EIF_TYPE_INDEX g_atype851_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype851_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes851 [] = {
g_atype851_0,
g_atype851_1,
g_atype851_2,
};

static const long offsets851 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names852[];
static const uint32 types852 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags852 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype852_0 [] = {0xFF01,755,972,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype852_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes852 [] = {
g_atype852_0,
g_atype852_1,
g_atype852_2,
};

static const long offsets852 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names853[];
static const uint32 types853 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags853 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype853_0 [] = {0xFF01,756,927,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype853_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes853 [] = {
g_atype853_0,
g_atype853_1,
g_atype853_2,
};

static const long offsets853 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names854[];
static const uint32 types854 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags854 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype854_0 [] = {0xFF01,757,930,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype854_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes854 [] = {
g_atype854_0,
g_atype854_1,
g_atype854_2,
};

static const long offsets854 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
};

extern const char *names855[];
static const uint32 types855 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags855 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype855_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_1 [] = {0xFF01,746,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_2 [] = {0xFF01,746,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_3 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_4 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_6 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_9 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype855_16 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes855 [] = {
g_atype855_0,
g_atype855_1,
g_atype855_2,
g_atype855_3,
g_atype855_4,
g_atype855_5,
g_atype855_6,
g_atype855_7,
g_atype855_8,
g_atype855_9,
g_atype855_10,
g_atype855_11,
g_atype855_12,
g_atype855_13,
g_atype855_14,
g_atype855_15,
g_atype855_16,
};

static const long offsets855 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @LNGOFF(7,3,0,0),
+ @LNGOFF(7,3,0,1),
+ @LNGOFF(7,3,0,2),
+ @LNGOFF(7,3,0,3),
+ @LNGOFF(7,3,0,4),
+ @LNGOFF(7,3,0,5),
+ @LNGOFF(7,3,0,6),
};

extern const char *names856[];
static const uint32 types856 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags856 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype856_0 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_1 [] = {0xFF01,746,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_2 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_3 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype856_16 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes856 [] = {
g_atype856_0,
g_atype856_1,
g_atype856_2,
g_atype856_3,
g_atype856_4,
g_atype856_5,
g_atype856_6,
g_atype856_7,
g_atype856_8,
g_atype856_9,
g_atype856_10,
g_atype856_11,
g_atype856_12,
g_atype856_13,
g_atype856_14,
g_atype856_15,
g_atype856_16,
};

static const long offsets856 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @LNGOFF(5,3,0,7),
+ @LNGOFF(5,3,0,8),
};

extern const char *names857[];
static const uint32 types857 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags857 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype857_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_1 [] = {0xFF01,746,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_2 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_3 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_4 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype857_16 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes857 [] = {
g_atype857_0,
g_atype857_1,
g_atype857_2,
g_atype857_3,
g_atype857_4,
g_atype857_5,
g_atype857_6,
g_atype857_7,
g_atype857_8,
g_atype857_9,
g_atype857_10,
g_atype857_11,
g_atype857_12,
g_atype857_13,
g_atype857_14,
g_atype857_15,
g_atype857_16,
};

static const long offsets857 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @LNGOFF(6,3,0,0),
+ @LNGOFF(6,3,0,1),
+ @LNGOFF(6,3,0,2),
+ @LNGOFF(6,3,0,3),
+ @LNGOFF(6,3,0,4),
+ @LNGOFF(6,3,0,5),
+ @LNGOFF(6,3,0,6),
+ @LNGOFF(6,3,0,7),
};

extern const char *names858[];
static const uint32 types858 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags858 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype858_0 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_1 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_2 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_3 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype858_16 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes858 [] = {
g_atype858_0,
g_atype858_1,
g_atype858_2,
g_atype858_3,
g_atype858_4,
g_atype858_5,
g_atype858_6,
g_atype858_7,
g_atype858_8,
g_atype858_9,
g_atype858_10,
g_atype858_11,
g_atype858_12,
g_atype858_13,
g_atype858_14,
g_atype858_15,
g_atype858_16,
};

static const long offsets858 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @LNGOFF(4,3,0,3),
+ @LNGOFF(4,3,0,4),
+ @LNGOFF(4,3,0,5),
+ @LNGOFF(4,3,0,6),
+ @LNGOFF(4,3,0,7),
+ @LNGOFF(4,3,0,8),
+ @LNGOFF(4,3,0,9),
};

extern const char *names859[];
static const uint32 types859 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags859 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype859_0 [] = {0xFF01,755,972,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_1 [] = {0xFF01,746,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_2 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_3 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_15 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype859_16 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes859 [] = {
g_atype859_0,
g_atype859_1,
g_atype859_2,
g_atype859_3,
g_atype859_4,
g_atype859_5,
g_atype859_6,
g_atype859_7,
g_atype859_8,
g_atype859_9,
g_atype859_10,
g_atype859_11,
g_atype859_12,
g_atype859_13,
g_atype859_14,
g_atype859_15,
g_atype859_16,
};

static const long offsets859 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @LNGOFF(5,3,0,0),
+ @LNGOFF(5,3,0,1),
+ @LNGOFF(5,3,0,2),
+ @LNGOFF(5,3,0,3),
+ @LNGOFF(5,3,0,4),
+ @LNGOFF(5,3,0,5),
+ @LNGOFF(5,3,0,6),
+ @PTROFF(5,3,0,7,0,0),
+ @PTROFF(5,3,0,7,0,1),
};

extern const char *names860[];
static const uint32 types860 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags860 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype860_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_1 [] = {0xFF01,746,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_2 [] = {0xFF01,746,0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_3 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_4 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_5 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_6 [] = {978,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_9 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_10 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype860_17 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes860 [] = {
g_atype860_0,
g_atype860_1,
g_atype860_2,
g_atype860_3,
g_atype860_4,
g_atype860_5,
g_atype860_6,
g_atype860_7,
g_atype860_8,
g_atype860_9,
g_atype860_10,
g_atype860_11,
g_atype860_12,
g_atype860_13,
g_atype860_14,
g_atype860_15,
g_atype860_16,
g_atype860_17,
};

static const long offsets860 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @LNGOFF(7,4,0,0),
+ @LNGOFF(7,4,0,1),
+ @LNGOFF(7,4,0,2),
+ @LNGOFF(7,4,0,3),
+ @LNGOFF(7,4,0,4),
+ @LNGOFF(7,4,0,5),
+ @LNGOFF(7,4,0,6),
};

extern const char *names861[];
static const uint32 types861 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags861 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype861_0 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_1 [] = {0xFF01,746,0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_2 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_3 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_4 [] = {978,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype861_17 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes861 [] = {
g_atype861_0,
g_atype861_1,
g_atype861_2,
g_atype861_3,
g_atype861_4,
g_atype861_5,
g_atype861_6,
g_atype861_7,
g_atype861_8,
g_atype861_9,
g_atype861_10,
g_atype861_11,
g_atype861_12,
g_atype861_13,
g_atype861_14,
g_atype861_15,
g_atype861_16,
g_atype861_17,
};

static const long offsets861 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @LNGOFF(5,4,0,0),
+ @LNGOFF(5,4,0,1),
+ @LNGOFF(5,4,0,2),
+ @LNGOFF(5,4,0,3),
+ @LNGOFF(5,4,0,4),
+ @LNGOFF(5,4,0,5),
+ @LNGOFF(5,4,0,6),
+ @LNGOFF(5,4,0,7),
+ @LNGOFF(5,4,0,8),
};

extern const char *names862[];
static const uint32 types862 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags862 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype862_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_1 [] = {0xFF01,746,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_2 [] = {0xFF01,746,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_3 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_4 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_5 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_6 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_7 [] = {985,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_8 [] = {985,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_9 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_10 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_11 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype862_18 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes862 [] = {
g_atype862_0,
g_atype862_1,
g_atype862_2,
g_atype862_3,
g_atype862_4,
g_atype862_5,
g_atype862_6,
g_atype862_7,
g_atype862_8,
g_atype862_9,
g_atype862_10,
g_atype862_11,
g_atype862_12,
g_atype862_13,
g_atype862_14,
g_atype862_15,
g_atype862_16,
g_atype862_17,
g_atype862_18,
};

static const long offsets862 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
+ @CHROFF(9,0),
+ @CHROFF(9,1),
+ @CHROFF(9,2),
+ @LNGOFF(9,3,0,0),
+ @LNGOFF(9,3,0,1),
+ @LNGOFF(9,3,0,2),
+ @LNGOFF(9,3,0,3),
+ @LNGOFF(9,3,0,4),
+ @LNGOFF(9,3,0,5),
+ @LNGOFF(9,3,0,6),
};

extern const char *names864[];
static const uint32 types864 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags864 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype864_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_1 [] = {0xFF01,221,0xFFFF};
static const EIF_TYPE_INDEX g_atype864_2 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes864 [] = {
g_atype864_0,
g_atype864_1,
g_atype864_2,
};

static const long offsets864 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names867[];
static const uint32 types867 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags867 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype867_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype867_1 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype867_2 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes867 [] = {
g_atype867_0,
g_atype867_1,
g_atype867_2,
};

static const long offsets867 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
};

extern const char *names868[];
static const uint32 types868 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags868 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype868_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype868_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes868 [] = {
g_atype868_0,
g_atype868_1,
};

static const long offsets868 [] =
{
0,
 + @REFACS(1),
};

extern const char *names869[];
static const uint32 types869 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags869 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype869_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype869_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes869 [] = {
g_atype869_0,
g_atype869_1,
};

static const long offsets869 [] =
{
0,
 + @REFACS(1),
};

extern const char *names870[];
static const uint32 types870 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags870 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype870_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype870_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes870 [] = {
g_atype870_0,
g_atype870_1,
};

static const long offsets870 [] =
{
0,
 + @REFACS(1),
};

extern const char *names871[];
static const uint32 types871 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags871 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype871_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype871_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes871 [] = {
g_atype871_0,
g_atype871_1,
};

static const long offsets871 [] =
{
0,
 + @REFACS(1),
};

extern const char *names872[];
static const uint32 types872 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags872 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype872_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype872_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes872 [] = {
g_atype872_0,
g_atype872_1,
};

static const long offsets872 [] =
{
0,
 + @REFACS(1),
};

extern const char *names873[];
static const uint32 types873 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags873 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype873_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype873_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes873 [] = {
g_atype873_0,
g_atype873_1,
};

static const long offsets873 [] =
{
0,
 + @REFACS(1),
};

extern const char *names874[];
static const uint32 types874 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags874 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype874_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype874_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes874 [] = {
g_atype874_0,
g_atype874_1,
};

static const long offsets874 [] =
{
0,
 + @REFACS(1),
};

extern const char *names875[];
static const uint32 types875 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags875 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype875_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype875_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes875 [] = {
g_atype875_0,
g_atype875_1,
};

static const long offsets875 [] =
{
0,
 + @REFACS(1),
};

extern const char *names876[];
static const uint32 types876 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags876 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype876_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype876_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes876 [] = {
g_atype876_0,
g_atype876_1,
};

static const long offsets876 [] =
{
0,
 + @REFACS(1),
};

extern const char *names877[];
static const uint32 types877 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags877 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype877_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype877_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes877 [] = {
g_atype877_0,
g_atype877_1,
};

static const long offsets877 [] =
{
0,
 + @REFACS(1),
};

extern const char *names878[];
static const uint32 types878 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags878 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype878_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype878_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes878 [] = {
g_atype878_0,
g_atype878_1,
};

static const long offsets878 [] =
{
0,
 + @REFACS(1),
};

extern const char *names879[];
static const uint32 types879 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags879 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype879_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype879_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes879 [] = {
g_atype879_0,
g_atype879_1,
};

static const long offsets879 [] =
{
0,
 + @REFACS(1),
};

extern const char *names880[];
static const uint32 types880 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags880 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype880_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype880_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes880 [] = {
g_atype880_0,
g_atype880_1,
};

static const long offsets880 [] =
{
0,
 + @REFACS(1),
};

extern const char *names881[];
static const uint32 types881 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags881 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype881_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype881_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes881 [] = {
g_atype881_0,
g_atype881_1,
};

static const long offsets881 [] =
{
0,
 + @REFACS(1),
};

extern const char *names882[];
static const uint32 types882 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags882 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype882_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype882_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes882 [] = {
g_atype882_0,
g_atype882_1,
};

static const long offsets882 [] =
{
0,
 + @REFACS(1),
};

extern const char *names883[];
static const uint32 types883 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags883 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype883_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype883_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes883 [] = {
g_atype883_0,
g_atype883_1,
};

static const long offsets883 [] =
{
0,
 + @REFACS(1),
};

extern const char *names884[];
static const uint32 types884 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags884 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype884_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype884_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes884 [] = {
g_atype884_0,
g_atype884_1,
};

static const long offsets884 [] =
{
0,
 + @REFACS(1),
};

extern const char *names885[];
static const uint32 types885 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags885 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype885_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype885_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes885 [] = {
g_atype885_0,
g_atype885_1,
};

static const long offsets885 [] =
{
0,
 + @REFACS(1),
};

extern const char *names886[];
static const uint32 types886 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags886 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype886_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype886_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes886 [] = {
g_atype886_0,
g_atype886_1,
};

static const long offsets886 [] =
{
0,
 + @REFACS(1),
};

extern const char *names887[];
static const uint32 types887 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags887 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype887_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype887_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes887 [] = {
g_atype887_0,
g_atype887_1,
};

static const long offsets887 [] =
{
0,
 + @REFACS(1),
};

extern const char *names888[];
static const uint32 types888 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags888 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype888_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype888_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes888 [] = {
g_atype888_0,
g_atype888_1,
};

static const long offsets888 [] =
{
0,
 + @REFACS(1),
};

extern const char *names889[];
static const uint32 types889 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags889 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype889_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype889_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes889 [] = {
g_atype889_0,
g_atype889_1,
};

static const long offsets889 [] =
{
0,
 + @REFACS(1),
};

extern const char *names890[];
static const uint32 types890 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags890 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype890_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype890_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes890 [] = {
g_atype890_0,
g_atype890_1,
};

static const long offsets890 [] =
{
0,
 + @REFACS(1),
};

extern const char *names891[];
static const uint32 types891 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags891 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype891_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype891_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes891 [] = {
g_atype891_0,
g_atype891_1,
};

static const long offsets891 [] =
{
0,
 + @REFACS(1),
};

extern const char *names892[];
static const uint32 types892 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags892 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype892_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype892_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes892 [] = {
g_atype892_0,
g_atype892_1,
};

static const long offsets892 [] =
{
0,
 + @REFACS(1),
};

extern const char *names893[];
static const uint32 types893 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags893 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype893_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype893_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes893 [] = {
g_atype893_0,
g_atype893_1,
};

static const long offsets893 [] =
{
0,
 + @REFACS(1),
};

extern const char *names894[];
static const uint32 types894 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags894 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype894_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype894_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes894 [] = {
g_atype894_0,
g_atype894_1,
};

static const long offsets894 [] =
{
0,
 + @REFACS(1),
};

extern const char *names895[];
static const uint32 types895 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags895 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype895_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype895_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes895 [] = {
g_atype895_0,
g_atype895_1,
};

static const long offsets895 [] =
{
0,
 + @REFACS(1),
};

extern const char *names896[];
static const uint32 types896 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags896 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype896_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype896_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes896 [] = {
g_atype896_0,
g_atype896_1,
};

static const long offsets896 [] =
{
0,
 + @REFACS(1),
};

extern const char *names897[];
static const uint32 types897 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags897 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype897_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype897_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes897 [] = {
g_atype897_0,
g_atype897_1,
};

static const long offsets897 [] =
{
0,
 + @REFACS(1),
};

extern const char *names898[];
static const uint32 types898 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags898 [] =
{1,1,};

static const EIF_TYPE_INDEX g_atype898_0 [] = {982,0xFFFF};
static const EIF_TYPE_INDEX g_atype898_1 [] = {985,0xFFFF};

static const EIF_TYPE_INDEX *gtypes898 [] = {
g_atype898_0,
g_atype898_1,
};

static const long offsets898 [] =
{
0,
 + @REFACS(1),
};

extern const char *names900[];
static const uint32 types900 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags900 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype900_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_1 [] = {0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype900_2 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes900 [] = {
g_atype900_0,
g_atype900_1,
g_atype900_2,
};

static const long offsets900 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names901[];
static const uint32 types901 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags901 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype901_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_1 [] = {0xFF01,1055,0xFFFF};
static const EIF_TYPE_INDEX g_atype901_2 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes901 [] = {
g_atype901_0,
g_atype901_1,
g_atype901_2,
};

static const long offsets901 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names902[];
static const uint32 types902 [] =
{
SK_INT64,
};

static const uint16 attr_flags902 [] =
{0,};

static const EIF_TYPE_INDEX g_atype902_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes902 [] = {
g_atype902_0,
};

static const long offsets902 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names903[];
static const uint32 types903 [] =
{
SK_INT64,
};

static const uint16 attr_flags903 [] =
{0,};

static const EIF_TYPE_INDEX g_atype903_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes903 [] = {
g_atype903_0,
};

static const long offsets903 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names904[];
static const uint32 types904 [] =
{
SK_INT64,
};

static const uint16 attr_flags904 [] =
{0,};

static const EIF_TYPE_INDEX g_atype904_0 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes904 [] = {
g_atype904_0,
};

static const long offsets904 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names905[];
static const uint32 types905 [] =
{
SK_INT32,
};

static const uint16 attr_flags905 [] =
{0,};

static const EIF_TYPE_INDEX g_atype905_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes905 [] = {
g_atype905_0,
};

static const long offsets905 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names906[];
static const uint32 types906 [] =
{
SK_INT32,
};

static const uint16 attr_flags906 [] =
{0,};

static const EIF_TYPE_INDEX g_atype906_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes906 [] = {
g_atype906_0,
};

static const long offsets906 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names907[];
static const uint32 types907 [] =
{
SK_INT32,
};

static const uint16 attr_flags907 [] =
{0,};

static const EIF_TYPE_INDEX g_atype907_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes907 [] = {
g_atype907_0,
};

static const long offsets907 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names908[];
static const uint32 types908 [] =
{
SK_INT16,
};

static const uint16 attr_flags908 [] =
{0,};

static const EIF_TYPE_INDEX g_atype908_0 [] = {909,0xFFFF};

static const EIF_TYPE_INDEX *gtypes908 [] = {
g_atype908_0,
};

static const long offsets908 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names909[];
static const uint32 types909 [] =
{
SK_INT16,
};

static const uint16 attr_flags909 [] =
{0,};

static const EIF_TYPE_INDEX g_atype909_0 [] = {909,0xFFFF};

static const EIF_TYPE_INDEX *gtypes909 [] = {
g_atype909_0,
};

static const long offsets909 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names910[];
static const uint32 types910 [] =
{
SK_INT16,
};

static const uint16 attr_flags910 [] =
{0,};

static const EIF_TYPE_INDEX g_atype910_0 [] = {909,0xFFFF};

static const EIF_TYPE_INDEX *gtypes910 [] = {
g_atype910_0,
};

static const long offsets910 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names911[];
static const uint32 types911 [] =
{
SK_INT8,
};

static const uint16 attr_flags911 [] =
{0,};

static const EIF_TYPE_INDEX g_atype911_0 [] = {912,0xFFFF};

static const EIF_TYPE_INDEX *gtypes911 [] = {
g_atype911_0,
};

static const long offsets911 [] =
{
+ @CHROFF(0,0),
};

extern const char *names912[];
static const uint32 types912 [] =
{
SK_INT8,
};

static const uint16 attr_flags912 [] =
{0,};

static const EIF_TYPE_INDEX g_atype912_0 [] = {912,0xFFFF};

static const EIF_TYPE_INDEX *gtypes912 [] = {
g_atype912_0,
};

static const long offsets912 [] =
{
+ @CHROFF(0,0),
};

extern const char *names913[];
static const uint32 types913 [] =
{
SK_INT8,
};

static const uint16 attr_flags913 [] =
{0,};

static const EIF_TYPE_INDEX g_atype913_0 [] = {912,0xFFFF};

static const EIF_TYPE_INDEX *gtypes913 [] = {
g_atype913_0,
};

static const long offsets913 [] =
{
+ @CHROFF(0,0),
};

extern const char *names914[];
static const uint32 types914 [] =
{
SK_UINT64,
};

static const uint16 attr_flags914 [] =
{0,};

static const EIF_TYPE_INDEX g_atype914_0 [] = {915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes914 [] = {
g_atype914_0,
};

static const long offsets914 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names915[];
static const uint32 types915 [] =
{
SK_UINT64,
};

static const uint16 attr_flags915 [] =
{0,};

static const EIF_TYPE_INDEX g_atype915_0 [] = {915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes915 [] = {
g_atype915_0,
};

static const long offsets915 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names916[];
static const uint32 types916 [] =
{
SK_UINT64,
};

static const uint16 attr_flags916 [] =
{0,};

static const EIF_TYPE_INDEX g_atype916_0 [] = {915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes916 [] = {
g_atype916_0,
};

static const long offsets916 [] =
{
+ @I64OFF(0,0,0,0,0,0,0),
};

extern const char *names917[];
static const uint32 types917 [] =
{
SK_UINT32,
};

static const uint16 attr_flags917 [] =
{0,};

static const EIF_TYPE_INDEX g_atype917_0 [] = {918,0xFFFF};

static const EIF_TYPE_INDEX *gtypes917 [] = {
g_atype917_0,
};

static const long offsets917 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names918[];
static const uint32 types918 [] =
{
SK_UINT32,
};

static const uint16 attr_flags918 [] =
{0,};

static const EIF_TYPE_INDEX g_atype918_0 [] = {918,0xFFFF};

static const EIF_TYPE_INDEX *gtypes918 [] = {
g_atype918_0,
};

static const long offsets918 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names919[];
static const uint32 types919 [] =
{
SK_UINT32,
};

static const uint16 attr_flags919 [] =
{0,};

static const EIF_TYPE_INDEX g_atype919_0 [] = {918,0xFFFF};

static const EIF_TYPE_INDEX *gtypes919 [] = {
g_atype919_0,
};

static const long offsets919 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names920[];
static const uint32 types920 [] =
{
SK_UINT16,
};

static const uint16 attr_flags920 [] =
{0,};

static const EIF_TYPE_INDEX g_atype920_0 [] = {921,0xFFFF};

static const EIF_TYPE_INDEX *gtypes920 [] = {
g_atype920_0,
};

static const long offsets920 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names921[];
static const uint32 types921 [] =
{
SK_UINT16,
};

static const uint16 attr_flags921 [] =
{0,};

static const EIF_TYPE_INDEX g_atype921_0 [] = {921,0xFFFF};

static const EIF_TYPE_INDEX *gtypes921 [] = {
g_atype921_0,
};

static const long offsets921 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names922[];
static const uint32 types922 [] =
{
SK_UINT16,
};

static const uint16 attr_flags922 [] =
{0,};

static const EIF_TYPE_INDEX g_atype922_0 [] = {921,0xFFFF};

static const EIF_TYPE_INDEX *gtypes922 [] = {
g_atype922_0,
};

static const long offsets922 [] =
{
+ @I16OFF(0,0,0),
};

extern const char *names923[];
static const uint32 types923 [] =
{
SK_UINT8,
};

static const uint16 attr_flags923 [] =
{0,};

static const EIF_TYPE_INDEX g_atype923_0 [] = {924,0xFFFF};

static const EIF_TYPE_INDEX *gtypes923 [] = {
g_atype923_0,
};

static const long offsets923 [] =
{
+ @CHROFF(0,0),
};

extern const char *names924[];
static const uint32 types924 [] =
{
SK_UINT8,
};

static const uint16 attr_flags924 [] =
{0,};

static const EIF_TYPE_INDEX g_atype924_0 [] = {924,0xFFFF};

static const EIF_TYPE_INDEX *gtypes924 [] = {
g_atype924_0,
};

static const long offsets924 [] =
{
+ @CHROFF(0,0),
};

extern const char *names925[];
static const uint32 types925 [] =
{
SK_UINT8,
};

static const uint16 attr_flags925 [] =
{0,};

static const EIF_TYPE_INDEX g_atype925_0 [] = {924,0xFFFF};

static const EIF_TYPE_INDEX *gtypes925 [] = {
g_atype925_0,
};

static const long offsets925 [] =
{
+ @CHROFF(0,0),
};

extern const char *names926[];
static const uint32 types926 [] =
{
SK_REAL32,
};

static const uint16 attr_flags926 [] =
{0,};

static const EIF_TYPE_INDEX g_atype926_0 [] = {927,0xFFFF};

static const EIF_TYPE_INDEX *gtypes926 [] = {
g_atype926_0,
};

static const long offsets926 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names927[];
static const uint32 types927 [] =
{
SK_REAL32,
};

static const uint16 attr_flags927 [] =
{0,};

static const EIF_TYPE_INDEX g_atype927_0 [] = {927,0xFFFF};

static const EIF_TYPE_INDEX *gtypes927 [] = {
g_atype927_0,
};

static const long offsets927 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names928[];
static const uint32 types928 [] =
{
SK_REAL32,
};

static const uint16 attr_flags928 [] =
{0,};

static const EIF_TYPE_INDEX g_atype928_0 [] = {927,0xFFFF};

static const EIF_TYPE_INDEX *gtypes928 [] = {
g_atype928_0,
};

static const long offsets928 [] =
{
+ @R32OFF(0,0,0,0,0),
};

extern const char *names929[];
static const uint32 types929 [] =
{
SK_REAL64,
};

static const uint16 attr_flags929 [] =
{0,};

static const EIF_TYPE_INDEX g_atype929_0 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes929 [] = {
g_atype929_0,
};

static const long offsets929 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names930[];
static const uint32 types930 [] =
{
SK_REAL64,
};

static const uint16 attr_flags930 [] =
{0,};

static const EIF_TYPE_INDEX g_atype930_0 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes930 [] = {
g_atype930_0,
};

static const long offsets930 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names931[];
static const uint32 types931 [] =
{
SK_REAL64,
};

static const uint16 attr_flags931 [] =
{0,};

static const EIF_TYPE_INDEX g_atype931_0 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes931 [] = {
g_atype931_0,
};

static const long offsets931 [] =
{
+ @R64OFF(0,0,0,0,0,0,0,0),
};

extern const char *names932[];
static const uint32 types932 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags932 [] =
{0,};

static const EIF_TYPE_INDEX g_atype932_0 [] = {933,0xFFFF};

static const EIF_TYPE_INDEX *gtypes932 [] = {
g_atype932_0,
};

static const long offsets932 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names933[];
static const uint32 types933 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags933 [] =
{0,};

static const EIF_TYPE_INDEX g_atype933_0 [] = {933,0xFFFF};

static const EIF_TYPE_INDEX *gtypes933 [] = {
g_atype933_0,
};

static const long offsets933 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names934[];
static const uint32 types934 [] =
{
SK_CHAR32,
};

static const uint16 attr_flags934 [] =
{0,};

static const EIF_TYPE_INDEX g_atype934_0 [] = {933,0xFFFF};

static const EIF_TYPE_INDEX *gtypes934 [] = {
g_atype934_0,
};

static const long offsets934 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names935[];
static const uint32 types935 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags935 [] =
{0,};

static const EIF_TYPE_INDEX g_atype935_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes935 [] = {
g_atype935_0,
};

static const long offsets935 [] =
{
+ @CHROFF(0,0),
};

extern const char *names936[];
static const uint32 types936 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags936 [] =
{0,};

static const EIF_TYPE_INDEX g_atype936_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes936 [] = {
g_atype936_0,
};

static const long offsets936 [] =
{
+ @CHROFF(0,0),
};

extern const char *names937[];
static const uint32 types937 [] =
{
SK_CHAR8,
};

static const uint16 attr_flags937 [] =
{0,};

static const EIF_TYPE_INDEX g_atype937_0 [] = {936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes937 [] = {
g_atype937_0,
};

static const long offsets937 [] =
{
+ @CHROFF(0,0),
};

extern const char *names938[];
static const uint32 types938 [] =
{
SK_BOOL,
};

static const uint16 attr_flags938 [] =
{0,};

static const EIF_TYPE_INDEX g_atype938_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes938 [] = {
g_atype938_0,
};

static const long offsets938 [] =
{
+ @CHROFF(0,0),
};

extern const char *names939[];
static const uint32 types939 [] =
{
SK_BOOL,
};

static const uint16 attr_flags939 [] =
{0,};

static const EIF_TYPE_INDEX g_atype939_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes939 [] = {
g_atype939_0,
};

static const long offsets939 [] =
{
+ @CHROFF(0,0),
};

extern const char *names940[];
static const uint32 types940 [] =
{
SK_BOOL,
};

static const uint16 attr_flags940 [] =
{0,};

static const EIF_TYPE_INDEX g_atype940_0 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes940 [] = {
g_atype940_0,
};

static const long offsets940 [] =
{
+ @CHROFF(0,0),
};

extern const char *names941[];
static const uint32 types941 [] =
{
SK_POINTER,
};

static const uint16 attr_flags941 [] =
{0,};

static const EIF_TYPE_INDEX g_atype941_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes941 [] = {
g_atype941_0,
};

static const long offsets941 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names942[];
static const uint32 types942 [] =
{
SK_POINTER,
};

static const uint16 attr_flags942 [] =
{0,};

static const EIF_TYPE_INDEX g_atype942_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes942 [] = {
g_atype942_0,
};

static const long offsets942 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names943[];
static const uint32 types943 [] =
{
SK_POINTER,
};

static const uint16 attr_flags943 [] =
{0,};

static const EIF_TYPE_INDEX g_atype943_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes943 [] = {
g_atype943_0,
};

static const long offsets943 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names944[];
static const uint32 types944 [] =
{
SK_POINTER,
};

static const uint16 attr_flags944 [] =
{0,};

static const EIF_TYPE_INDEX g_atype944_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes944 [] = {
g_atype944_0,
};

static const long offsets944 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names945[];
static const uint32 types945 [] =
{
SK_POINTER,
};

static const uint16 attr_flags945 [] =
{0,};

static const EIF_TYPE_INDEX g_atype945_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes945 [] = {
g_atype945_0,
};

static const long offsets945 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names946[];
static const uint32 types946 [] =
{
SK_POINTER,
};

static const uint16 attr_flags946 [] =
{0,};

static const EIF_TYPE_INDEX g_atype946_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes946 [] = {
g_atype946_0,
};

static const long offsets946 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names947[];
static const uint32 types947 [] =
{
SK_POINTER,
};

static const uint16 attr_flags947 [] =
{0,};

static const EIF_TYPE_INDEX g_atype947_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes947 [] = {
g_atype947_0,
};

static const long offsets947 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names948[];
static const uint32 types948 [] =
{
SK_POINTER,
};

static const uint16 attr_flags948 [] =
{0,};

static const EIF_TYPE_INDEX g_atype948_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes948 [] = {
g_atype948_0,
};

static const long offsets948 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names949[];
static const uint32 types949 [] =
{
SK_POINTER,
};

static const uint16 attr_flags949 [] =
{0,};

static const EIF_TYPE_INDEX g_atype949_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes949 [] = {
g_atype949_0,
};

static const long offsets949 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names950[];
static const uint32 types950 [] =
{
SK_POINTER,
};

static const uint16 attr_flags950 [] =
{0,};

static const EIF_TYPE_INDEX g_atype950_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes950 [] = {
g_atype950_0,
};

static const long offsets950 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names951[];
static const uint32 types951 [] =
{
SK_POINTER,
};

static const uint16 attr_flags951 [] =
{0,};

static const EIF_TYPE_INDEX g_atype951_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes951 [] = {
g_atype951_0,
};

static const long offsets951 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names952[];
static const uint32 types952 [] =
{
SK_POINTER,
};

static const uint16 attr_flags952 [] =
{0,};

static const EIF_TYPE_INDEX g_atype952_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes952 [] = {
g_atype952_0,
};

static const long offsets952 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names953[];
static const uint32 types953 [] =
{
SK_POINTER,
};

static const uint16 attr_flags953 [] =
{0,};

static const EIF_TYPE_INDEX g_atype953_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes953 [] = {
g_atype953_0,
};

static const long offsets953 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names954[];
static const uint32 types954 [] =
{
SK_POINTER,
};

static const uint16 attr_flags954 [] =
{0,};

static const EIF_TYPE_INDEX g_atype954_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes954 [] = {
g_atype954_0,
};

static const long offsets954 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names955[];
static const uint32 types955 [] =
{
SK_POINTER,
};

static const uint16 attr_flags955 [] =
{0,};

static const EIF_TYPE_INDEX g_atype955_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes955 [] = {
g_atype955_0,
};

static const long offsets955 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names956[];
static const uint32 types956 [] =
{
SK_POINTER,
};

static const uint16 attr_flags956 [] =
{0,};

static const EIF_TYPE_INDEX g_atype956_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes956 [] = {
g_atype956_0,
};

static const long offsets956 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names957[];
static const uint32 types957 [] =
{
SK_POINTER,
};

static const uint16 attr_flags957 [] =
{0,};

static const EIF_TYPE_INDEX g_atype957_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes957 [] = {
g_atype957_0,
};

static const long offsets957 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names958[];
static const uint32 types958 [] =
{
SK_POINTER,
};

static const uint16 attr_flags958 [] =
{0,};

static const EIF_TYPE_INDEX g_atype958_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes958 [] = {
g_atype958_0,
};

static const long offsets958 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names959[];
static const uint32 types959 [] =
{
SK_POINTER,
};

static const uint16 attr_flags959 [] =
{0,};

static const EIF_TYPE_INDEX g_atype959_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes959 [] = {
g_atype959_0,
};

static const long offsets959 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names960[];
static const uint32 types960 [] =
{
SK_POINTER,
};

static const uint16 attr_flags960 [] =
{0,};

static const EIF_TYPE_INDEX g_atype960_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes960 [] = {
g_atype960_0,
};

static const long offsets960 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names961[];
static const uint32 types961 [] =
{
SK_POINTER,
};

static const uint16 attr_flags961 [] =
{0,};

static const EIF_TYPE_INDEX g_atype961_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes961 [] = {
g_atype961_0,
};

static const long offsets961 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names962[];
static const uint32 types962 [] =
{
SK_POINTER,
};

static const uint16 attr_flags962 [] =
{0,};

static const EIF_TYPE_INDEX g_atype962_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes962 [] = {
g_atype962_0,
};

static const long offsets962 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names963[];
static const uint32 types963 [] =
{
SK_POINTER,
};

static const uint16 attr_flags963 [] =
{0,};

static const EIF_TYPE_INDEX g_atype963_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes963 [] = {
g_atype963_0,
};

static const long offsets963 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names964[];
static const uint32 types964 [] =
{
SK_POINTER,
};

static const uint16 attr_flags964 [] =
{0,};

static const EIF_TYPE_INDEX g_atype964_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes964 [] = {
g_atype964_0,
};

static const long offsets964 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names965[];
static const uint32 types965 [] =
{
SK_POINTER,
};

static const uint16 attr_flags965 [] =
{0,};

static const EIF_TYPE_INDEX g_atype965_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes965 [] = {
g_atype965_0,
};

static const long offsets965 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names966[];
static const uint32 types966 [] =
{
SK_POINTER,
};

static const uint16 attr_flags966 [] =
{0,};

static const EIF_TYPE_INDEX g_atype966_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes966 [] = {
g_atype966_0,
};

static const long offsets966 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names967[];
static const uint32 types967 [] =
{
SK_POINTER,
};

static const uint16 attr_flags967 [] =
{0,};

static const EIF_TYPE_INDEX g_atype967_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes967 [] = {
g_atype967_0,
};

static const long offsets967 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names968[];
static const uint32 types968 [] =
{
SK_POINTER,
};

static const uint16 attr_flags968 [] =
{0,};

static const EIF_TYPE_INDEX g_atype968_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes968 [] = {
g_atype968_0,
};

static const long offsets968 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names969[];
static const uint32 types969 [] =
{
SK_POINTER,
};

static const uint16 attr_flags969 [] =
{0,};

static const EIF_TYPE_INDEX g_atype969_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes969 [] = {
g_atype969_0,
};

static const long offsets969 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names970[];
static const uint32 types970 [] =
{
SK_POINTER,
};

static const uint16 attr_flags970 [] =
{0,};

static const EIF_TYPE_INDEX g_atype970_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes970 [] = {
g_atype970_0,
};

static const long offsets970 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names971[];
static const uint32 types971 [] =
{
SK_POINTER,
};

static const uint16 attr_flags971 [] =
{0,};

static const EIF_TYPE_INDEX g_atype971_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes971 [] = {
g_atype971_0,
};

static const long offsets971 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names972[];
static const uint32 types972 [] =
{
SK_POINTER,
};

static const uint16 attr_flags972 [] =
{0,};

static const EIF_TYPE_INDEX g_atype972_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes972 [] = {
g_atype972_0,
};

static const long offsets972 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names973[];
static const uint32 types973 [] =
{
SK_POINTER,
};

static const uint16 attr_flags973 [] =
{0,};

static const EIF_TYPE_INDEX g_atype973_0 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes973 [] = {
g_atype973_0,
};

static const long offsets973 [] =
{
+ @PTROFF(0,0,0,0,0,0),
};

extern const char *names974[];
static const uint32 types974 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags974 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype974_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_1 [] = {0xFFF9,0,898,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_2 [] = {772,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_3 [] = {772,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_9 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_10 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype974_11 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes974 [] = {
g_atype974_0,
g_atype974_1,
g_atype974_2,
g_atype974_3,
g_atype974_4,
g_atype974_5,
g_atype974_6,
g_atype974_7,
g_atype974_8,
g_atype974_9,
g_atype974_10,
g_atype974_11,
};

static const long offsets974 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names975[];
static const uint32 types975 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags975 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype975_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_1 [] = {0xFFF9,0,898,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_2 [] = {772,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_3 [] = {772,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_9 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_10 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype975_11 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes975 [] = {
g_atype975_0,
g_atype975_1,
g_atype975_2,
g_atype975_3,
g_atype975_4,
g_atype975_5,
g_atype975_6,
g_atype975_7,
g_atype975_8,
g_atype975_9,
g_atype975_10,
g_atype975_11,
};

static const long offsets975 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @LNGOFF(4,2,0,0),
+ @LNGOFF(4,2,0,1),
+ @LNGOFF(4,2,0,2),
+ @PTROFF(4,2,0,3,0,0),
+ @PTROFF(4,2,0,3,0,1),
+ @PTROFF(4,2,0,3,0,2),
};

extern const char *names976[];
static const uint32 types976 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags976 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype976_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_1 [] = {0xFFF9,0,898,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_2 [] = {772,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_3 [] = {772,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_4 [] = {0xFF02,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_10 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_11 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype976_12 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes976 [] = {
g_atype976_0,
g_atype976_1,
g_atype976_2,
g_atype976_3,
g_atype976_4,
g_atype976_5,
g_atype976_6,
g_atype976_7,
g_atype976_8,
g_atype976_9,
g_atype976_10,
g_atype976_11,
g_atype976_12,
};

static const long offsets976 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @PTROFF(5,2,0,3,0,0),
+ @PTROFF(5,2,0,3,0,1),
+ @PTROFF(5,2,0,3,0,2),
};

extern const char *names977[];
static const uint32 types977 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags977 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype977_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype977_1 [] = {0xFFF9,0,898,0xFFFF};
static const EIF_TYPE_INDEX g_atype977_2 [] = {772,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype977_3 [] = {772,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype977_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype977_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype977_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype977_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype977_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype977_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype977_10 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype977_11 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype977_12 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes977 [] = {
g_atype977_0,
g_atype977_1,
g_atype977_2,
g_atype977_3,
g_atype977_4,
g_atype977_5,
g_atype977_6,
g_atype977_7,
g_atype977_8,
g_atype977_9,
g_atype977_10,
g_atype977_11,
g_atype977_12,
};

static const long offsets977 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names978[];
static const uint32 types978 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_POINTER,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags978 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype978_0 [] = {0xFF02,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_1 [] = {0xFFF9,0,898,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_2 [] = {772,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_3 [] = {772,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_10 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_11 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype978_12 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes978 [] = {
g_atype978_0,
g_atype978_1,
g_atype978_2,
g_atype978_3,
g_atype978_4,
g_atype978_5,
g_atype978_6,
g_atype978_7,
g_atype978_8,
g_atype978_9,
g_atype978_10,
g_atype978_11,
g_atype978_12,
};

static const long offsets978 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @LNGOFF(4,3,0,0),
+ @LNGOFF(4,3,0,1),
+ @LNGOFF(4,3,0,2),
+ @PTROFF(4,3,0,3,0,0),
+ @PTROFF(4,3,0,3,0,1),
+ @PTROFF(4,3,0,3,0,2),
};

extern const char *names979[];
static const uint32 types979 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags979 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype979_0 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype979_1 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes979 [] = {
g_atype979_0,
g_atype979_1,
};

static const long offsets979 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names980[];
static const uint32 types980 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags980 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype980_0 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype980_1 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes980 [] = {
g_atype980_0,
g_atype980_1,
};

static const long offsets980 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names981[];
static const uint32 types981 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags981 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype981_0 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype981_1 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes981 [] = {
g_atype981_0,
g_atype981_1,
};

static const long offsets981 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names982[];
static const uint32 types982 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags982 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype982_0 [] = {0xFF01,751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype982_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype982_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype982_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes982 [] = {
g_atype982_0,
g_atype982_1,
g_atype982_2,
g_atype982_3,
};

static const long offsets982 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names983[];
static const uint32 types983 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags983 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype983_0 [] = {0xFF01,751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype983_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype983_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype983_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype983_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes983 [] = {
g_atype983_0,
g_atype983_1,
g_atype983_2,
g_atype983_3,
g_atype983_4,
};

static const long offsets983 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names984[];
static const uint32 types984 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags984 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype984_0 [] = {0xFF01,751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype984_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype984_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype984_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype984_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes984 [] = {
g_atype984_0,
g_atype984_1,
g_atype984_2,
g_atype984_3,
g_atype984_4,
};

static const long offsets984 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names985[];
static const uint32 types985 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags985 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype985_0 [] = {0xFF01,752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype985_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype985_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype985_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes985 [] = {
g_atype985_0,
g_atype985_1,
g_atype985_2,
g_atype985_3,
};

static const long offsets985 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names986[];
static const uint32 types986 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags986 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype986_0 [] = {0xFF01,752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype986_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype986_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype986_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype986_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes986 [] = {
g_atype986_0,
g_atype986_1,
g_atype986_2,
g_atype986_3,
g_atype986_4,
};

static const long offsets986 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
+ @LNGOFF(1,0,0,3),
};

extern const char *names987[];
static const uint32 types987 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags987 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype987_0 [] = {0xFF01,752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype987_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype987_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype987_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype987_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes987 [] = {
g_atype987_0,
g_atype987_1,
g_atype987_2,
g_atype987_3,
g_atype987_4,
};

static const long offsets987 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names988[];
static const uint32 types988 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags988 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype988_0 [] = {0xFF01,752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype988_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype988_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype988_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype988_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes988 [] = {
g_atype988_0,
g_atype988_1,
g_atype988_2,
g_atype988_3,
g_atype988_4,
};

static const long offsets988 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
};

extern const char *names1009[];
static const uint32 types1009 [] =
{
SK_INT32,
};

static const uint16 attr_flags1009 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1009_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1009 [] = {
g_atype1009_0,
};

static const long offsets1009 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1010[];
static const uint32 types1010 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags1010 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1010_0 [] = {86,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1010_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1010_2 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1010_3 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1010 [] = {
g_atype1010_0,
g_atype1010_1,
g_atype1010_2,
g_atype1010_3,
};

static const long offsets1010 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
};

extern const char *names1012[];
static const uint32 types1012 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1012 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1012_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1012_1 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1012 [] = {
g_atype1012_0,
g_atype1012_1,
};

static const long offsets1012 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names1014[];
static const uint32 types1014 [] =
{
SK_INT32,
};

static const uint16 attr_flags1014 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1014_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1014 [] = {
g_atype1014_0,
};

static const long offsets1014 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1016[];
static const uint32 types1016 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1016 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1016_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_2 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1016_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1016 [] = {
g_atype1016_0,
g_atype1016_1,
g_atype1016_2,
g_atype1016_3,
g_atype1016_4,
};

static const long offsets1016 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @LNGOFF(2,2,0,0),
};

extern const char *names1017[];
static const uint32 types1017 [] =
{
SK_REF,
};

static const uint16 attr_flags1017 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1017_0 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1017 [] = {
g_atype1017_0,
};

static const long offsets1017 [] =
{
0,
};

extern const char *names1018[];
static const uint32 types1018 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1018 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1018_0 [] = {0xFF01,1257,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_1 [] = {0xFF01,1000,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1018_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1018 [] = {
g_atype1018_0,
g_atype1018_1,
g_atype1018_2,
g_atype1018_3,
};

static const long offsets1018 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
};

extern const char *names1019[];
static const uint32 types1019 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1019 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1019_0 [] = {0xFF01,211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_1 [] = {0xFF01,1266,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1019_2 [] = {1011,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1019 [] = {
g_atype1019_0,
g_atype1019_1,
g_atype1019_2,
};

static const long offsets1019 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1020[];
static const uint32 types1020 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1020 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1020_0 [] = {0xFF01,211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1020_1 [] = {986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1020 [] = {
g_atype1020_0,
g_atype1020_1,
};

static const long offsets1020 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1021[];
static const uint32 types1021 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1021 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1021_0 [] = {0xFF01,211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1021_1 [] = {0xFF01,1347,0xFFFF};
static const EIF_TYPE_INDEX g_atype1021_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1021 [] = {
g_atype1021_0,
g_atype1021_1,
g_atype1021_2,
};

static const long offsets1021 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1022[];
static const uint32 types1022 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1022 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1022_0 [] = {0xFF01,211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1022_1 [] = {0xFF01,1348,0xFFFF};
static const EIF_TYPE_INDEX g_atype1022_2 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1022_3 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1022_4 [] = {0xFF01,1254,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1022_5 [] = {0xFF01,1254,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1022_6 [] = {0xFF01,1254,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1022_7 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1022 [] = {
g_atype1022_0,
g_atype1022_1,
g_atype1022_2,
g_atype1022_3,
g_atype1022_4,
g_atype1022_5,
g_atype1022_6,
g_atype1022_7,
};

static const long offsets1022 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
};

extern const char *names1024[];
static const uint32 types1024 [] =
{
SK_REF,
};

static const uint16 attr_flags1024 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1024_0 [] = {0xFF01,1034,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1024 [] = {
g_atype1024_0,
};

static const long offsets1024 [] =
{
0,
};

extern const char *names1025[];
static const uint32 types1025 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1025 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1025_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1025_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1025_2 [] = {0xFF01,1244,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1025_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1025_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1025 [] = {
g_atype1025_0,
g_atype1025_1,
g_atype1025_2,
g_atype1025_3,
g_atype1025_4,
};

static const long offsets1025 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
};

extern const char *names1026[];
static const uint32 types1026 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1026 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1026_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1026_1 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1026 [] = {
g_atype1026_0,
g_atype1026_1,
};

static const long offsets1026 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1027[];
static const uint32 types1027 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1027 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1027_0 [] = {0xFF01,1246,0xFF01,17,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_1 [] = {34,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_2 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_3 [] = {1075,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1027_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1027 [] = {
g_atype1027_0,
g_atype1027_1,
g_atype1027_2,
g_atype1027_3,
g_atype1027_4,
g_atype1027_5,
};

static const long offsets1027 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
};

extern const char *names1028[];
static const uint32 types1028 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1028 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1028_0 [] = {1421,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_1 [] = {1421,0xFFFF};
static const EIF_TYPE_INDEX g_atype1028_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1028 [] = {
g_atype1028_0,
g_atype1028_1,
g_atype1028_2,
};

static const long offsets1028 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1031[];
static const uint32 types1031 [] =
{
SK_INT32,
};

static const uint16 attr_flags1031 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1031_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1031 [] = {
g_atype1031_0,
};

static const long offsets1031 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1038[];
static const uint32 types1038 [] =
{
SK_REF,
};

static const uint16 attr_flags1038 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1038_0 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1038 [] = {
g_atype1038_0,
};

static const long offsets1038 [] =
{
0,
};

extern const char *names1040[];
static const uint32 types1040 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1040 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1040_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1040_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1040_2 [] = {1046,0xFFFF};
static const EIF_TYPE_INDEX g_atype1040_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1040_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1040_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1040 [] = {
g_atype1040_0,
g_atype1040_1,
g_atype1040_2,
g_atype1040_3,
g_atype1040_4,
g_atype1040_5,
};

static const long offsets1040 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
};

extern const char *names1041[];
static const uint32 types1041 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1041 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1041_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1041_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1041_2 [] = {1046,0xFFFF};
static const EIF_TYPE_INDEX g_atype1041_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1041_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1041_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1041 [] = {
g_atype1041_0,
g_atype1041_1,
g_atype1041_2,
g_atype1041_3,
g_atype1041_4,
g_atype1041_5,
};

static const long offsets1041 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
};

extern const char *names1042[];
static const uint32 types1042 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1042 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1042_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_2 [] = {1046,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1042_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1042 [] = {
g_atype1042_0,
g_atype1042_1,
g_atype1042_2,
g_atype1042_3,
g_atype1042_4,
g_atype1042_5,
};

static const long offsets1042 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @LNGOFF(3,1,0,0),
+ @LNGOFF(3,1,0,1),
};

extern const char *names1043[];
static const uint32 types1043 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1043 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1043_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_2 [] = {1046,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_3 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1043_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1043 [] = {
g_atype1043_0,
g_atype1043_1,
g_atype1043_2,
g_atype1043_3,
g_atype1043_4,
g_atype1043_5,
g_atype1043_6,
};

static const long offsets1043 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
};

extern const char *names1044[];
static const uint32 types1044 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1044 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1044_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_2 [] = {1046,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_3 [] = {0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1044_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1044 [] = {
g_atype1044_0,
g_atype1044_1,
g_atype1044_2,
g_atype1044_3,
g_atype1044_4,
g_atype1044_5,
g_atype1044_6,
};

static const long offsets1044 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
};

extern const char *names1045[];
static const uint32 types1045 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1045 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1045_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_2 [] = {1046,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_3 [] = {0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1045_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1045 [] = {
g_atype1045_0,
g_atype1045_1,
g_atype1045_2,
g_atype1045_3,
g_atype1045_4,
g_atype1045_5,
g_atype1045_6,
};

static const long offsets1045 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
};

extern const char *names1046[];
static const uint32 types1046 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1046 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1046_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_2 [] = {1046,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_3 [] = {0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_4 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1046_7 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1046 [] = {
g_atype1046_0,
g_atype1046_1,
g_atype1046_2,
g_atype1046_3,
g_atype1046_4,
g_atype1046_5,
g_atype1046_6,
g_atype1046_7,
};

static const long offsets1046 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @LNGOFF(5,1,0,0),
+ @LNGOFF(5,1,0,1),
};

extern const char *names1047[];
static const uint32 types1047 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1047 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1047_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_2 [] = {1046,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_3 [] = {0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1047_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1047 [] = {
g_atype1047_0,
g_atype1047_1,
g_atype1047_2,
g_atype1047_3,
g_atype1047_4,
g_atype1047_5,
g_atype1047_6,
};

static const long offsets1047 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
};

extern const char *names1048[];
static const uint32 types1048 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1048 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1048_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_3 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1048_4 [] = {1039,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1048 [] = {
g_atype1048_0,
g_atype1048_1,
g_atype1048_2,
g_atype1048_3,
g_atype1048_4,
};

static const long offsets1048 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
};

extern const char *names1049[];
static const uint32 types1049 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1049 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1049_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1049_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1049_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1049_3 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1049_4 [] = {1039,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1049 [] = {
g_atype1049_0,
g_atype1049_1,
g_atype1049_2,
g_atype1049_3,
g_atype1049_4,
};

static const long offsets1049 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
};

extern const char *names1050[];
static const uint32 types1050 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1050 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1050_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1050_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1050_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1050_3 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1050_4 [] = {1039,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1050 [] = {
g_atype1050_0,
g_atype1050_1,
g_atype1050_2,
g_atype1050_3,
g_atype1050_4,
};

static const long offsets1050 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
};

extern const char *names1051[];
static const uint32 types1051 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1051 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1051_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_3 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1051_4 [] = {1039,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1051 [] = {
g_atype1051_0,
g_atype1051_1,
g_atype1051_2,
g_atype1051_3,
g_atype1051_4,
};

static const long offsets1051 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
};

extern const char *names1052[];
static const uint32 types1052 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1052 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1052_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_3 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_4 [] = {1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1052_5 [] = {0xFF01,221,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1052 [] = {
g_atype1052_0,
g_atype1052_1,
g_atype1052_2,
g_atype1052_3,
g_atype1052_4,
g_atype1052_5,
};

static const long offsets1052 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names1053[];
static const uint32 types1053 [] =
{
SK_REF,
};

static const uint16 attr_flags1053 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1053_0 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1053 [] = {
g_atype1053_0,
};

static const long offsets1053 [] =
{
0,
};

extern const char *names1054[];
static const uint32 types1054 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1054 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1054_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_2 [] = {1046,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_3 [] = {0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1054_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1054 [] = {
g_atype1054_0,
g_atype1054_1,
g_atype1054_2,
g_atype1054_3,
g_atype1054_4,
g_atype1054_5,
g_atype1054_6,
};

static const long offsets1054 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
};

extern const char *names1055[];
static const uint32 types1055 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1055 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1055_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_2 [] = {1046,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_3 [] = {1267,0xFF01,899,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1055_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1055 [] = {
g_atype1055_0,
g_atype1055_1,
g_atype1055_2,
g_atype1055_3,
g_atype1055_4,
g_atype1055_5,
g_atype1055_6,
};

static const long offsets1055 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
};

extern const char *names1056[];
static const uint32 types1056 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1056 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1056_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_2 [] = {1046,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_3 [] = {1267,0xFF01,899,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_4 [] = {0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1056_9 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1056 [] = {
g_atype1056_0,
g_atype1056_1,
g_atype1056_2,
g_atype1056_3,
g_atype1056_4,
g_atype1056_5,
g_atype1056_6,
g_atype1056_7,
g_atype1056_8,
g_atype1056_9,
};

static const long offsets1056 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
};

extern const char *names1057[];
static const uint32 types1057 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1057 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1057_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_2 [] = {1046,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_3 [] = {1267,0xFF01,899,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1057_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1057 [] = {
g_atype1057_0,
g_atype1057_1,
g_atype1057_2,
g_atype1057_3,
g_atype1057_4,
g_atype1057_5,
g_atype1057_6,
};

static const long offsets1057 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
};

extern const char *names1058[];
static const uint32 types1058 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1058 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1058_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_2 [] = {1046,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_3 [] = {1267,0xFF01,899,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1058_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1058 [] = {
g_atype1058_0,
g_atype1058_1,
g_atype1058_2,
g_atype1058_3,
g_atype1058_4,
g_atype1058_5,
g_atype1058_6,
};

static const long offsets1058 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
};

extern const char *names1059[];
static const uint32 types1059 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1059 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1059_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_2 [] = {1046,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_3 [] = {1267,0xFF01,899,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1059_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1059 [] = {
g_atype1059_0,
g_atype1059_1,
g_atype1059_2,
g_atype1059_3,
g_atype1059_4,
g_atype1059_5,
g_atype1059_6,
};

static const long offsets1059 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
};

extern const char *names1060[];
static const uint32 types1060 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1060 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1060_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_2 [] = {1046,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_3 [] = {1267,0xFF01,899,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1060_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1060 [] = {
g_atype1060_0,
g_atype1060_1,
g_atype1060_2,
g_atype1060_3,
g_atype1060_4,
g_atype1060_5,
g_atype1060_6,
};

static const long offsets1060 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
+ @LNGOFF(4,1,0,1),
};

extern const char *names1064[];
static const uint32 types1064 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1064 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1064_0 [] = {0xFF01,750,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_1 [] = {0xFF01,1267,0xFF01,11,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1064_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1064 [] = {
g_atype1064_0,
g_atype1064_1,
g_atype1064_2,
g_atype1064_3,
};

static const long offsets1064 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
};

extern const char *names1066[];
static const uint32 types1066 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1066 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1066_0 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1066_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1066 [] = {
g_atype1066_0,
g_atype1066_1,
g_atype1066_2,
g_atype1066_3,
};

static const long offsets1066 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
};

extern const char *names1074[];
static const uint32 types1074 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1074 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1074_0 [] = {0xFF01,1349,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_1 [] = {0xFF01,1246,0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_2 [] = {0xFF01,171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_3 [] = {0xFF01,1246,0xFF01,16,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_4 [] = {0xFF01,90,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_5 [] = {1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_6 [] = {899,0xFFFF};
static const EIF_TYPE_INDEX g_atype1074_7 [] = {1267,0xFF01,899,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1074 [] = {
g_atype1074_0,
g_atype1074_1,
g_atype1074_2,
g_atype1074_3,
g_atype1074_4,
g_atype1074_5,
g_atype1074_6,
g_atype1074_7,
};

static const long offsets1074 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
};

extern const char *names1075[];
static const uint32 types1075 [] =
{
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1075 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1075_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_1 [] = {1246,0xFF01,27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_2 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1075_4 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1075 [] = {
g_atype1075_0,
g_atype1075_1,
g_atype1075_2,
g_atype1075_3,
g_atype1075_4,
};

static const long offsets1075 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
};

extern const char *names1076[];
static const uint32 types1076 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1076 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1076_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_1 [] = {0xFF01,1246,0xFF01,35,0xFFFF};
static const EIF_TYPE_INDEX g_atype1076_2 [] = {0xFF01,1026,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1076 [] = {
g_atype1076_0,
g_atype1076_1,
g_atype1076_2,
};

static const long offsets1076 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1077[];
static const uint32 types1077 [] =
{
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1077 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1077_0 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1077_1 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1077 [] = {
g_atype1077_0,
g_atype1077_1,
};

static const long offsets1077 [] =
{
+ @CHROFF(0,0),
+ @CHROFF(0,1),
};

extern const char *names1078[];
static const uint32 types1078 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1078 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1078_0 [] = {0xFF01,214,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_1 [] = {0xFF01,218,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_2 [] = {0xFF01,217,0xFFFF};
static const EIF_TYPE_INDEX g_atype1078_3 [] = {0xFF01,214,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1078 [] = {
g_atype1078_0,
g_atype1078_1,
g_atype1078_2,
g_atype1078_3,
};

static const long offsets1078 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1079[];
static const uint32 types1079 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1079 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1079_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_1 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_2 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_3 [] = {0xFF01,983,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_4 [] = {39,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_5 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_6 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_9 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_10 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_11 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_12 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_13 [] = {909,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_14 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_18 [] = {927,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_19 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_20 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_21 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1079_22 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1079 [] = {
g_atype1079_0,
g_atype1079_1,
g_atype1079_2,
g_atype1079_3,
g_atype1079_4,
g_atype1079_5,
g_atype1079_6,
g_atype1079_7,
g_atype1079_8,
g_atype1079_9,
g_atype1079_10,
g_atype1079_11,
g_atype1079_12,
g_atype1079_13,
g_atype1079_14,
g_atype1079_15,
g_atype1079_16,
g_atype1079_17,
g_atype1079_18,
g_atype1079_19,
g_atype1079_20,
g_atype1079_21,
g_atype1079_22,
};

static const long offsets1079 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @CHROFF(5,6),
+ @I16OFF(5,7,0),
+ @I16OFF(5,7,1),
+ @LNGOFF(5,7,2,0),
+ @LNGOFF(5,7,2,1),
+ @LNGOFF(5,7,2,2),
+ @LNGOFF(5,7,2,3),
+ @R32OFF(5,7,2,4,0),
+ @PTROFF(5,7,2,4,1,0),
+ @I64OFF(5,7,2,4,1,1,0),
+ @I64OFF(5,7,2,4,1,1,1),
+ @R64OFF(5,7,2,4,1,1,2,0),
};

extern const char *names1080[];
static const uint32 types1080 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1080 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1080_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_1 [] = {0xFF01,1293,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_3 [] = {0xFF01,1412,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_4 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_5 [] = {0xFF01,842,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_6 [] = {0xFF01,842,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_7 [] = {0xFF01,866,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_8 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_9 [] = {0xFF01,1267,0xFF01,43,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_10 [] = {0xFF01,314,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_11 [] = {0xFF01,1267,0xFF01,43,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_12 [] = {0xFF01,1287,939,0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1080_13 [] = {0xFF01,1275,0xFF01,1039,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1080 [] = {
g_atype1080_0,
g_atype1080_1,
g_atype1080_2,
g_atype1080_3,
g_atype1080_4,
g_atype1080_5,
g_atype1080_6,
g_atype1080_7,
g_atype1080_8,
g_atype1080_9,
g_atype1080_10,
g_atype1080_11,
g_atype1080_12,
g_atype1080_13,
};

static const long offsets1080 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
};

extern const char *names1081[];
static const uint32 types1081 [] =
{
SK_REF,
};

static const uint16 attr_flags1081 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1081_0 [] = {0xFF01,1374,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1081 [] = {
g_atype1081_0,
};

static const long offsets1081 [] =
{
0,
};

extern const char *names1082[];
static const uint32 types1082 [] =
{
SK_REF,
SK_CHAR8,
SK_CHAR32,
SK_INT32,
};

static const uint16 attr_flags1082 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1082_0 [] = {0xFF01,199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_1 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_2 [] = {933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1082_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1082 [] = {
g_atype1082_0,
g_atype1082_1,
g_atype1082_2,
g_atype1082_3,
};

static const long offsets1082 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
};

extern const char *names1083[];
static const uint32 types1083 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1083 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1083_0 [] = {0xFF01,199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_1 [] = {0xFF01,97,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_2 [] = {752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_3 [] = {751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_5 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_7 [] = {933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_18 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_19 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_20 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1083_21 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1083 [] = {
g_atype1083_0,
g_atype1083_1,
g_atype1083_2,
g_atype1083_3,
g_atype1083_4,
g_atype1083_5,
g_atype1083_6,
g_atype1083_7,
g_atype1083_8,
g_atype1083_9,
g_atype1083_10,
g_atype1083_11,
g_atype1083_12,
g_atype1083_13,
g_atype1083_14,
g_atype1083_15,
g_atype1083_16,
g_atype1083_17,
g_atype1083_18,
g_atype1083_19,
g_atype1083_20,
g_atype1083_21,
};

static const long offsets1083 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
+ @LNGOFF(5,2,0,3),
+ @LNGOFF(5,2,0,4),
+ @LNGOFF(5,2,0,5),
+ @LNGOFF(5,2,0,6),
+ @LNGOFF(5,2,0,7),
+ @LNGOFF(5,2,0,8),
+ @LNGOFF(5,2,0,9),
+ @LNGOFF(5,2,0,10),
+ @LNGOFF(5,2,0,11),
+ @LNGOFF(5,2,0,12),
+ @LNGOFF(5,2,0,13),
+ @LNGOFF(5,2,0,14),
};

extern const char *names1084[];
static const uint32 types1084 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1084 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1084_0 [] = {0xFF01,199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_1 [] = {0xFF01,97,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_2 [] = {752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_3 [] = {751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_5 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_8 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_9 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_10 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_11 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_12 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_13 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_14 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_15 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_16 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_17 [] = {933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_18 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_19 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_20 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_21 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_22 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_23 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_24 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_25 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_26 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_27 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_28 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_29 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_30 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_31 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_32 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_33 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_34 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_35 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_36 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1084_37 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1084 [] = {
g_atype1084_0,
g_atype1084_1,
g_atype1084_2,
g_atype1084_3,
g_atype1084_4,
g_atype1084_5,
g_atype1084_6,
g_atype1084_7,
g_atype1084_8,
g_atype1084_9,
g_atype1084_10,
g_atype1084_11,
g_atype1084_12,
g_atype1084_13,
g_atype1084_14,
g_atype1084_15,
g_atype1084_16,
g_atype1084_17,
g_atype1084_18,
g_atype1084_19,
g_atype1084_20,
g_atype1084_21,
g_atype1084_22,
g_atype1084_23,
g_atype1084_24,
g_atype1084_25,
g_atype1084_26,
g_atype1084_27,
g_atype1084_28,
g_atype1084_29,
g_atype1084_30,
g_atype1084_31,
g_atype1084_32,
g_atype1084_33,
g_atype1084_34,
g_atype1084_35,
g_atype1084_36,
g_atype1084_37,
};

static const long offsets1084 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
+ @CHROFF(14,0),
+ @CHROFF(14,1),
+ @CHROFF(14,2),
+ @LNGOFF(14,3,0,0),
+ @LNGOFF(14,3,0,1),
+ @LNGOFF(14,3,0,2),
+ @LNGOFF(14,3,0,3),
+ @LNGOFF(14,3,0,4),
+ @LNGOFF(14,3,0,5),
+ @LNGOFF(14,3,0,6),
+ @LNGOFF(14,3,0,7),
+ @LNGOFF(14,3,0,8),
+ @LNGOFF(14,3,0,9),
+ @LNGOFF(14,3,0,10),
+ @LNGOFF(14,3,0,11),
+ @LNGOFF(14,3,0,12),
+ @LNGOFF(14,3,0,13),
+ @LNGOFF(14,3,0,14),
+ @LNGOFF(14,3,0,15),
+ @LNGOFF(14,3,0,16),
+ @LNGOFF(14,3,0,17),
+ @LNGOFF(14,3,0,18),
+ @LNGOFF(14,3,0,19),
+ @LNGOFF(14,3,0,20),
};

extern const char *names1095[];
static const uint32 types1095 [] =
{
SK_INT32,
};

static const uint16 attr_flags1095 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1095_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1095 [] = {
g_atype1095_0,
};

static const long offsets1095 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1096[];
static const uint32 types1096 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1096 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1096_0 [] = {0xFF01,104,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_1 [] = {0xFF01,104,0xFFFF};
static const EIF_TYPE_INDEX g_atype1096_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1096 [] = {
g_atype1096_0,
g_atype1096_1,
g_atype1096_2,
};

static const long offsets1096 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1097[];
static const uint32 types1097 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1097 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1097_0 [] = {0xFF01,104,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_1 [] = {0xFF01,104,0xFFFF};
static const EIF_TYPE_INDEX g_atype1097_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1097 [] = {
g_atype1097_0,
g_atype1097_1,
g_atype1097_2,
};

static const long offsets1097 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1098[];
static const uint32 types1098 [] =
{
SK_INT32,
};

static const uint16 attr_flags1098 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1098_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1098 [] = {
g_atype1098_0,
};

static const long offsets1098 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1099[];
static const uint32 types1099 [] =
{
SK_INT32,
};

static const uint16 attr_flags1099 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1099_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1099 [] = {
g_atype1099_0,
};

static const long offsets1099 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1100[];
static const uint32 types1100 [] =
{
SK_INT32,
};

static const uint16 attr_flags1100 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1100_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1100 [] = {
g_atype1100_0,
};

static const long offsets1100 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1101[];
static const uint32 types1101 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1101 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1101_0 [] = {978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1101_2 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1101 [] = {
g_atype1101_0,
g_atype1101_1,
g_atype1101_2,
};

static const long offsets1101 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1102[];
static const uint32 types1102 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1102 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1102_0 [] = {978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1102_2 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1102 [] = {
g_atype1102_0,
g_atype1102_1,
g_atype1102_2,
};

static const long offsets1102 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1103[];
static const uint32 types1103 [] =
{
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1103 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1103_0 [] = {978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1103_2 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1103 [] = {
g_atype1103_0,
g_atype1103_1,
g_atype1103_2,
};

static const long offsets1103 [] =
{
0,
+ @CHROFF(1,0),
+ @CHROFF(1,1),
};

extern const char *names1106[];
static const uint32 types1106 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1106 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1106_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1106_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1106 [] = {
g_atype1106_0,
g_atype1106_1,
g_atype1106_2,
g_atype1106_3,
};

static const long offsets1106 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1107[];
static const uint32 types1107 [] =
{
SK_REF,
};

static const uint16 attr_flags1107 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1107_0 [] = {1106,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1107 [] = {
g_atype1107_0,
};

static const long offsets1107 [] =
{
0,
};

extern const char *names1108[];
static const uint32 types1108 [] =
{
SK_REF,
};

static const uint16 attr_flags1108 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1108_0 [] = {1107,939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1108 [] = {
g_atype1108_0,
};

static const long offsets1108 [] =
{
0,
};

extern const char *names1109[];
static const uint32 types1109 [] =
{
SK_REF,
};

static const uint16 attr_flags1109 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1109_0 [] = {1108,915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1109 [] = {
g_atype1109_0,
};

static const long offsets1109 [] =
{
0,
};

extern const char *names1110[];
static const uint32 types1110 [] =
{
SK_REF,
};

static const uint16 attr_flags1110 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1110_0 [] = {1109,918,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1110 [] = {
g_atype1110_0,
};

static const long offsets1110 [] =
{
0,
};

extern const char *names1111[];
static const uint32 types1111 [] =
{
SK_REF,
};

static const uint16 attr_flags1111 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1111_0 [] = {1110,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1111 [] = {
g_atype1111_0,
};

static const long offsets1111 [] =
{
0,
};

extern const char *names1112[];
static const uint32 types1112 [] =
{
SK_REF,
};

static const uint16 attr_flags1112 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1112_0 [] = {1111,936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1112 [] = {
g_atype1112_0,
};

static const long offsets1112 [] =
{
0,
};

extern const char *names1113[];
static const uint32 types1113 [] =
{
SK_REF,
};

static const uint16 attr_flags1113 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1113_0 [] = {1106,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1113 [] = {
g_atype1113_0,
};

static const long offsets1113 [] =
{
0,
};

extern const char *names1114[];
static const uint32 types1114 [] =
{
SK_REF,
};

static const uint16 attr_flags1114 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1114_0 [] = {1110,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1114 [] = {
g_atype1114_0,
};

static const long offsets1114 [] =
{
0,
};

extern const char *names1115[];
static const uint32 types1115 [] =
{
SK_REF,
};

static const uint16 attr_flags1115 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1115_0 [] = {1106,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1115 [] = {
g_atype1115_0,
};

static const long offsets1115 [] =
{
0,
};

extern const char *names1116[];
static const uint32 types1116 [] =
{
SK_REF,
};

static const uint16 attr_flags1116 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1116_0 [] = {1107,939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1116 [] = {
g_atype1116_0,
};

static const long offsets1116 [] =
{
0,
};

extern const char *names1117[];
static const uint32 types1117 [] =
{
SK_REF,
};

static const uint16 attr_flags1117 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1117_0 [] = {1108,915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1117 [] = {
g_atype1117_0,
};

static const long offsets1117 [] =
{
0,
};

extern const char *names1118[];
static const uint32 types1118 [] =
{
SK_REF,
};

static const uint16 attr_flags1118 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1118_0 [] = {1110,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1118 [] = {
g_atype1118_0,
};

static const long offsets1118 [] =
{
0,
};

extern const char *names1119[];
static const uint32 types1119 [] =
{
SK_REF,
};

static const uint16 attr_flags1119 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1119_0 [] = {1118,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1119 [] = {
g_atype1119_0,
};

static const long offsets1119 [] =
{
0,
};

extern const char *names1120[];
static const uint32 types1120 [] =
{
SK_REF,
};

static const uint16 attr_flags1120 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1120_0 [] = {1119,939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1120 [] = {
g_atype1120_0,
};

static const long offsets1120 [] =
{
0,
};

extern const char *names1121[];
static const uint32 types1121 [] =
{
SK_REF,
};

static const uint16 attr_flags1121 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1121_0 [] = {1120,918,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1121 [] = {
g_atype1121_0,
};

static const long offsets1121 [] =
{
0,
};

extern const char *names1122[];
static const uint32 types1122 [] =
{
SK_REF,
};

static const uint16 attr_flags1122 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1122_0 [] = {1121,915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1122 [] = {
g_atype1122_0,
};

static const long offsets1122 [] =
{
0,
};

extern const char *names1123[];
static const uint32 types1123 [] =
{
SK_REF,
};

static const uint16 attr_flags1123 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1123_0 [] = {1122,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1123 [] = {
g_atype1123_0,
};

static const long offsets1123 [] =
{
0,
};

extern const char *names1124[];
static const uint32 types1124 [] =
{
SK_REF,
};

static const uint16 attr_flags1124 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1124_0 [] = {1123,936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1124 [] = {
g_atype1124_0,
};

static const long offsets1124 [] =
{
0,
};

extern const char *names1125[];
static const uint32 types1125 [] =
{
SK_REF,
};

static const uint16 attr_flags1125 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1125_0 [] = {1124,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1125 [] = {
g_atype1125_0,
};

static const long offsets1125 [] =
{
0,
};

extern const char *names1126[];
static const uint32 types1126 [] =
{
SK_REF,
};

static const uint16 attr_flags1126 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1126_0 [] = {1125,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1126 [] = {
g_atype1126_0,
};

static const long offsets1126 [] =
{
0,
};

extern const char *names1127[];
static const uint32 types1127 [] =
{
SK_REF,
};

static const uint16 attr_flags1127 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1127_0 [] = {1126,939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1127 [] = {
g_atype1127_0,
};

static const long offsets1127 [] =
{
0,
};

extern const char *names1128[];
static const uint32 types1128 [] =
{
SK_REF,
};

static const uint16 attr_flags1128 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1128_0 [] = {1127,918,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1128 [] = {
g_atype1128_0,
};

static const long offsets1128 [] =
{
0,
};

extern const char *names1129[];
static const uint32 types1129 [] =
{
SK_REF,
};

static const uint16 attr_flags1129 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1129_0 [] = {1128,915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1129 [] = {
g_atype1129_0,
};

static const long offsets1129 [] =
{
0,
};

extern const char *names1130[];
static const uint32 types1130 [] =
{
SK_REF,
};

static const uint16 attr_flags1130 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1130_0 [] = {1129,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1130 [] = {
g_atype1130_0,
};

static const long offsets1130 [] =
{
0,
};

extern const char *names1131[];
static const uint32 types1131 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1131 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1131_0 [] = {1130,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1131_1 [] = {0xFFF5,2,0xFF01,1228,0xFFF8,1,0xFFF8,2,6620,6568,0xFFFF};
static const EIF_TYPE_INDEX g_atype1131_2 [] = {0xFF01,1228,0xFFF8,1,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1131 [] = {
g_atype1131_0,
g_atype1131_1,
g_atype1131_2,
};

static const long offsets1131 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1132[];
static const uint32 types1132 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1132 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1132_0 [] = {1131,939,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1132_1 [] = {0xFFF5,2,0xFF01,1229,939,0xFFF8,2,6620,6568,0xFFFF};
static const EIF_TYPE_INDEX g_atype1132_2 [] = {0xFF01,1229,939,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1132 [] = {
g_atype1132_0,
g_atype1132_1,
g_atype1132_2,
};

static const long offsets1132 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1133[];
static const uint32 types1133 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1133 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1133_0 [] = {1132,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1133_1 [] = {0xFF01,1150,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1133_2 [] = {0xFF01,1230,915,918,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1133 [] = {
g_atype1133_0,
g_atype1133_1,
g_atype1133_2,
};

static const long offsets1133 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1134[];
static const uint32 types1134 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1134 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1134_0 [] = {1133,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1134_1 [] = {0xFFF5,2,0xFF01,1231,906,0xFFF8,2,6620,6568,0xFFFF};
static const EIF_TYPE_INDEX g_atype1134_2 [] = {0xFF01,1231,906,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1134 [] = {
g_atype1134_0,
g_atype1134_1,
g_atype1134_2,
};

static const long offsets1134 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1135[];
static const uint32 types1135 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1135 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1135_0 [] = {1134,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1135_1 [] = {0xFF01,1152,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1135_2 [] = {0xFF01,1232,906,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1135 [] = {
g_atype1135_0,
g_atype1135_1,
g_atype1135_2,
};

static const long offsets1135 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1136[];
static const uint32 types1136 [] =
{
SK_REF,
};

static const uint16 attr_flags1136 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1136_0 [] = {1135,0xFFF8,1,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1136 [] = {
g_atype1136_0,
};

static const long offsets1136 [] =
{
0,
};

extern const char *names1137[];
static const uint32 types1137 [] =
{
SK_REF,
};

static const uint16 attr_flags1137 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1137_0 [] = {1136,939,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1137 [] = {
g_atype1137_0,
};

static const long offsets1137 [] =
{
0,
};

extern const char *names1138[];
static const uint32 types1138 [] =
{
SK_REF,
};

static const uint16 attr_flags1138 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1138_0 [] = {1137,915,918,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1138 [] = {
g_atype1138_0,
};

static const long offsets1138 [] =
{
0,
};

extern const char *names1139[];
static const uint32 types1139 [] =
{
SK_REF,
};

static const uint16 attr_flags1139 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1139_0 [] = {1138,906,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1139 [] = {
g_atype1139_0,
};

static const long offsets1139 [] =
{
0,
};

extern const char *names1140[];
static const uint32 types1140 [] =
{
SK_REF,
};

static const uint16 attr_flags1140 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1140_0 [] = {1139,906,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1140 [] = {
g_atype1140_0,
};

static const long offsets1140 [] =
{
0,
};

extern const char *names1141[];
static const uint32 types1141 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1141 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1141_0 [] = {1140,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1141_1 [] = {0xFF01,1268,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1141_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1141 [] = {
g_atype1141_0,
g_atype1141_1,
g_atype1141_2,
};

static const long offsets1141 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1142[];
static const uint32 types1142 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1142 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1142_0 [] = {1141,939,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1142_1 [] = {0xFF01,1269,939,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1142_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1142 [] = {
g_atype1142_0,
g_atype1142_1,
g_atype1142_2,
};

static const long offsets1142 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1143[];
static const uint32 types1143 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1143 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1143_0 [] = {1142,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1143_1 [] = {0xFF01,1270,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1143_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1143 [] = {
g_atype1143_0,
g_atype1143_1,
g_atype1143_2,
};

static const long offsets1143 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1144[];
static const uint32 types1144 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1144 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1144_0 [] = {1143,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1144_1 [] = {0xFF01,1271,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1144_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1144 [] = {
g_atype1144_0,
g_atype1144_1,
g_atype1144_2,
};

static const long offsets1144 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1145[];
static const uint32 types1145 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1145 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1145_0 [] = {1144,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_1 [] = {0xFF01,1272,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1145_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1145 [] = {
g_atype1145_0,
g_atype1145_1,
g_atype1145_2,
};

static const long offsets1145 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1146[];
static const uint32 types1146 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1146 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1146_0 [] = {1145,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1146_1 [] = {0xFF01,1273,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1146_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1146 [] = {
g_atype1146_0,
g_atype1146_1,
g_atype1146_2,
};

static const long offsets1146 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1147[];
static const uint32 types1147 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1147 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1147_0 [] = {1146,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1147_1 [] = {0xFF01,1274,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1147_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1147 [] = {
g_atype1147_0,
g_atype1147_1,
g_atype1147_2,
};

static const long offsets1147 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1148[];
static const uint32 types1148 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1148 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1148_0 [] = {1147,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1148_1 [] = {0xFF01,1275,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1148_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1148 [] = {
g_atype1148_0,
g_atype1148_1,
g_atype1148_2,
};

static const long offsets1148 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1149[];
static const uint32 types1149 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1149 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1149_0 [] = {1148,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1149_1 [] = {0xFF01,1276,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1149_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1149 [] = {
g_atype1149_0,
g_atype1149_1,
g_atype1149_2,
};

static const long offsets1149 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1150[];
static const uint32 types1150 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1150 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1150_0 [] = {1149,939,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1150_1 [] = {0xFF01,1277,939,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1150_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1150 [] = {
g_atype1150_0,
g_atype1150_1,
g_atype1150_2,
};

static const long offsets1150 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1151[];
static const uint32 types1151 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1151 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1151_0 [] = {1150,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1151_1 [] = {0xFF01,1278,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1151_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1151 [] = {
g_atype1151_0,
g_atype1151_1,
g_atype1151_2,
};

static const long offsets1151 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1152[];
static const uint32 types1152 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1152 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1152_0 [] = {1151,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1152_1 [] = {0xFF01,1279,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1152_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1152 [] = {
g_atype1152_0,
g_atype1152_1,
g_atype1152_2,
};

static const long offsets1152 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1153[];
static const uint32 types1153 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1153 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1153_0 [] = {1152,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_1 [] = {0xFF01,1280,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1153_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1153 [] = {
g_atype1153_0,
g_atype1153_1,
g_atype1153_2,
};

static const long offsets1153 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1154[];
static const uint32 types1154 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1154 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1154_0 [] = {1153,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_1 [] = {0xFF01,1281,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1154_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1154 [] = {
g_atype1154_0,
g_atype1154_1,
g_atype1154_2,
};

static const long offsets1154 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1155[];
static const uint32 types1155 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1155 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1155_0 [] = {1154,939,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_1 [] = {0xFF01,1282,939,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1155_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1155 [] = {
g_atype1155_0,
g_atype1155_1,
g_atype1155_2,
};

static const long offsets1155 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1156[];
static const uint32 types1156 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1156 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1156_0 [] = {1155,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_1 [] = {0xFF01,1283,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1156_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1156 [] = {
g_atype1156_0,
g_atype1156_1,
g_atype1156_2,
};

static const long offsets1156 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1157[];
static const uint32 types1157 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1157 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1157_0 [] = {1156,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_1 [] = {0xFF01,1284,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1157_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1157 [] = {
g_atype1157_0,
g_atype1157_1,
g_atype1157_2,
};

static const long offsets1157 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1158[];
static const uint32 types1158 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1158 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1158_0 [] = {1157,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_1 [] = {0xFF01,1285,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1158_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1158 [] = {
g_atype1158_0,
g_atype1158_1,
g_atype1158_2,
};

static const long offsets1158 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1159[];
static const uint32 types1159 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1159 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1159_0 [] = {1158,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_1 [] = {0xFF01,1286,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1159_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1159 [] = {
g_atype1159_0,
g_atype1159_1,
g_atype1159_2,
};

static const long offsets1159 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1160[];
static const uint32 types1160 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1160 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1160_0 [] = {1159,939,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_1 [] = {0xFF01,1287,939,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1160_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1160 [] = {
g_atype1160_0,
g_atype1160_1,
g_atype1160_2,
};

static const long offsets1160 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1161[];
static const uint32 types1161 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1161 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1161_0 [] = {1160,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_1 [] = {0xFF01,1288,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1161_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1161 [] = {
g_atype1161_0,
g_atype1161_1,
g_atype1161_2,
};

static const long offsets1161 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1162[];
static const uint32 types1162 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1162 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1162_0 [] = {1161,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_1 [] = {0xFF01,1289,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1162_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1162 [] = {
g_atype1162_0,
g_atype1162_1,
g_atype1162_2,
};

static const long offsets1162 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1163[];
static const uint32 types1163 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1163 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1163_0 [] = {1162,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_1 [] = {0xFF01,1290,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1163_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1163 [] = {
g_atype1163_0,
g_atype1163_1,
g_atype1163_2,
};

static const long offsets1163 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1164[];
static const uint32 types1164 [] =
{
SK_REF,
};

static const uint16 attr_flags1164 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1164_0 [] = {1163,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1164 [] = {
g_atype1164_0,
};

static const long offsets1164 [] =
{
0,
};

extern const char *names1165[];
static const uint32 types1165 [] =
{
SK_REF,
};

static const uint16 attr_flags1165 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1165_0 [] = {1164,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1165 [] = {
g_atype1165_0,
};

static const long offsets1165 [] =
{
0,
};

extern const char *names1166[];
static const uint32 types1166 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1166 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1166_0 [] = {1165,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_1 [] = {0xFF01,1267,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1166_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1166 [] = {
g_atype1166_0,
g_atype1166_1,
g_atype1166_2,
};

static const long offsets1166 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1167[];
static const uint32 types1167 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1167 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1167_0 [] = {1166,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_1 [] = {152,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_2 [] = {0xFF01,1246,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1167_4 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1167 [] = {
g_atype1167_0,
g_atype1167_1,
g_atype1167_2,
g_atype1167_3,
g_atype1167_4,
};

static const long offsets1167 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1168[];
static const uint32 types1168 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1168 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1168_0 [] = {1167,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_1 [] = {154,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_2 [] = {0xFF01,1247,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1168_4 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1168 [] = {
g_atype1168_0,
g_atype1168_1,
g_atype1168_2,
g_atype1168_3,
g_atype1168_4,
};

static const long offsets1168 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1169[];
static const uint32 types1169 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1169 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1169_0 [] = {1168,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_1 [] = {156,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_2 [] = {0xFF01,1249,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1169_4 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1169 [] = {
g_atype1169_0,
g_atype1169_1,
g_atype1169_2,
g_atype1169_3,
g_atype1169_4,
};

static const long offsets1169 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1170[];
static const uint32 types1170 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1170 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1170_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1170_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1170 [] = {
g_atype1170_0,
g_atype1170_1,
g_atype1170_2,
g_atype1170_3,
};

static const long offsets1170 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
};

extern const char *names1171[];
static const uint32 types1171 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1171 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1171_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1171_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1171 [] = {
g_atype1171_0,
g_atype1171_1,
g_atype1171_2,
g_atype1171_3,
};

static const long offsets1171 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
};

extern const char *names1172[];
static const uint32 types1172 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1172 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1172_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_3 [] = {0xFF01,1267,0xFF01,1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1172_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1172 [] = {
g_atype1172_0,
g_atype1172_1,
g_atype1172_2,
g_atype1172_3,
g_atype1172_4,
};

static const long offsets1172 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1173[];
static const uint32 types1173 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1173 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1173_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_3 [] = {0xFF01,1267,0xFF01,1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_4 [] = {1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1173_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1173 [] = {
g_atype1173_0,
g_atype1173_1,
g_atype1173_2,
g_atype1173_3,
g_atype1173_4,
g_atype1173_5,
};

static const long offsets1173 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names1174[];
static const uint32 types1174 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1174 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1174_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_3 [] = {0xFF01,1267,0xFF01,1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_4 [] = {1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_5 [] = {0xFF01,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_6 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1174_7 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1174 [] = {
g_atype1174_0,
g_atype1174_1,
g_atype1174_2,
g_atype1174_3,
g_atype1174_4,
g_atype1174_5,
g_atype1174_6,
g_atype1174_7,
};

static const long offsets1174 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @LNGOFF(7,0,0,0),
};

extern const char *names1175[];
static const uint32 types1175 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1175 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1175_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1175_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1175 [] = {
g_atype1175_0,
g_atype1175_1,
g_atype1175_2,
g_atype1175_3,
};

static const long offsets1175 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
};

extern const char *names1176[];
static const uint32 types1176 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1176 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1176_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_3 [] = {0xFF01,1267,0xFF01,1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_4 [] = {1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_5 [] = {0xFF01,1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_6 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_7 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_8 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_9 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1176_11 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1176 [] = {
g_atype1176_0,
g_atype1176_1,
g_atype1176_2,
g_atype1176_3,
g_atype1176_4,
g_atype1176_5,
g_atype1176_6,
g_atype1176_7,
g_atype1176_8,
g_atype1176_9,
g_atype1176_10,
g_atype1176_11,
};

static const long offsets1176 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
};

extern const char *names1177[];
static const uint32 types1177 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1177 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1177_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_3 [] = {0xFF01,1267,0xFF01,1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_4 [] = {1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_5 [] = {0xFF01,1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_6 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_7 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_8 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_9 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1177_11 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1177 [] = {
g_atype1177_0,
g_atype1177_1,
g_atype1177_2,
g_atype1177_3,
g_atype1177_4,
g_atype1177_5,
g_atype1177_6,
g_atype1177_7,
g_atype1177_8,
g_atype1177_9,
g_atype1177_10,
g_atype1177_11,
};

static const long offsets1177 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
};

extern const char *names1178[];
static const uint32 types1178 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1178 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1178_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_3 [] = {0xFF01,1267,0xFF01,1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_4 [] = {1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_5 [] = {0xFF01,1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_6 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_7 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_8 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_9 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1178_11 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1178 [] = {
g_atype1178_0,
g_atype1178_1,
g_atype1178_2,
g_atype1178_3,
g_atype1178_4,
g_atype1178_5,
g_atype1178_6,
g_atype1178_7,
g_atype1178_8,
g_atype1178_9,
g_atype1178_10,
g_atype1178_11,
};

static const long offsets1178 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
};

extern const char *names1179[];
static const uint32 types1179 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1179 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1179_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_3 [] = {0xFF01,1267,0xFF01,1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_4 [] = {0xFF01,1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1179_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1179 [] = {
g_atype1179_0,
g_atype1179_1,
g_atype1179_2,
g_atype1179_3,
g_atype1179_4,
g_atype1179_5,
};

static const long offsets1179 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names1180[];
static const uint32 types1180 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1180 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1180_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_3 [] = {0xFF01,1267,0xFF01,1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_4 [] = {0xFF01,1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1180_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1180 [] = {
g_atype1180_0,
g_atype1180_1,
g_atype1180_2,
g_atype1180_3,
g_atype1180_4,
g_atype1180_5,
};

static const long offsets1180 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names1181[];
static const uint32 types1181 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1181 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1181_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_3 [] = {0xFF01,1267,0xFF01,1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_4 [] = {0xFF01,1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1181_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1181 [] = {
g_atype1181_0,
g_atype1181_1,
g_atype1181_2,
g_atype1181_3,
g_atype1181_4,
g_atype1181_5,
};

static const long offsets1181 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names1182[];
static const uint32 types1182 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1182 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1182_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_3 [] = {0xFF01,1267,0xFF01,1182,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_4 [] = {0xFF01,1056,0xFFFF};
static const EIF_TYPE_INDEX g_atype1182_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1182 [] = {
g_atype1182_0,
g_atype1182_1,
g_atype1182_2,
g_atype1182_3,
g_atype1182_4,
g_atype1182_5,
};

static const long offsets1182 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names1183[];
static const uint32 types1183 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1183 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1183_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_3 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1183_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1183 [] = {
g_atype1183_0,
g_atype1183_1,
g_atype1183_2,
g_atype1183_3,
g_atype1183_4,
};

static const long offsets1183 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1184[];
static const uint32 types1184 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1184 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1184_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1184_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1184_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1184_3 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1184_4 [] = {0xFF01,899,0xFFFF};
static const EIF_TYPE_INDEX g_atype1184_5 [] = {0xFF01,1179,0xFFFF};
static const EIF_TYPE_INDEX g_atype1184_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1184 [] = {
g_atype1184_0,
g_atype1184_1,
g_atype1184_2,
g_atype1184_3,
g_atype1184_4,
g_atype1184_5,
g_atype1184_6,
};

static const long offsets1184 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
};

extern const char *names1185[];
static const uint32 types1185 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1185 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1185_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1185_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1185_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1185_3 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1185_4 [] = {0xFF01,899,0xFFFF};
static const EIF_TYPE_INDEX g_atype1185_5 [] = {0xFF01,1180,0xFFFF};
static const EIF_TYPE_INDEX g_atype1185_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1185 [] = {
g_atype1185_0,
g_atype1185_1,
g_atype1185_2,
g_atype1185_3,
g_atype1185_4,
g_atype1185_5,
g_atype1185_6,
};

static const long offsets1185 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
};

extern const char *names1186[];
static const uint32 types1186 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1186 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1186_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_3 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_4 [] = {0xFF01,899,0xFFFF};
static const EIF_TYPE_INDEX g_atype1186_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1186 [] = {
g_atype1186_0,
g_atype1186_1,
g_atype1186_2,
g_atype1186_3,
g_atype1186_4,
g_atype1186_5,
};

static const long offsets1186 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names1187[];
static const uint32 types1187 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1187 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1187_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_3 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_4 [] = {0xFF01,899,0xFFFF};
static const EIF_TYPE_INDEX g_atype1187_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1187 [] = {
g_atype1187_0,
g_atype1187_1,
g_atype1187_2,
g_atype1187_3,
g_atype1187_4,
g_atype1187_5,
};

static const long offsets1187 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @LNGOFF(5,0,0,0),
};

extern const char *names1188[];
static const uint32 types1188 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1188 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1188_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_3 [] = {1171,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_4 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_5 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_6 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_7 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1188_8 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1188 [] = {
g_atype1188_0,
g_atype1188_1,
g_atype1188_2,
g_atype1188_3,
g_atype1188_4,
g_atype1188_5,
g_atype1188_6,
g_atype1188_7,
g_atype1188_8,
};

static const long offsets1188 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @LNGOFF(8,0,0,0),
};

extern const char *names1212[];
static const uint32 types1212 [] =
{
SK_REF,
};

static const uint16 attr_flags1212 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1212_0 [] = {301,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1212 [] = {
g_atype1212_0,
};

static const long offsets1212 [] =
{
0,
};

extern const char *names1213[];
static const uint32 types1213 [] =
{
SK_REF,
};

static const uint16 attr_flags1213 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1213_0 [] = {302,939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1213 [] = {
g_atype1213_0,
};

static const long offsets1213 [] =
{
0,
};

extern const char *names1214[];
static const uint32 types1214 [] =
{
SK_REF,
};

static const uint16 attr_flags1214 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1214_0 [] = {304,918,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1214 [] = {
g_atype1214_0,
};

static const long offsets1214 [] =
{
0,
};

extern const char *names1215[];
static const uint32 types1215 [] =
{
SK_REF,
};

static const uint16 attr_flags1215 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1215_0 [] = {303,915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1215 [] = {
g_atype1215_0,
};

static const long offsets1215 [] =
{
0,
};

extern const char *names1216[];
static const uint32 types1216 [] =
{
SK_REF,
};

static const uint16 attr_flags1216 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1216_0 [] = {305,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1216 [] = {
g_atype1216_0,
};

static const long offsets1216 [] =
{
0,
};

extern const char *names1217[];
static const uint32 types1217 [] =
{
SK_REF,
};

static const uint16 attr_flags1217 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1217_0 [] = {306,936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1217 [] = {
g_atype1217_0,
};

static const long offsets1217 [] =
{
0,
};

extern const char *names1218[];
static const uint32 types1218 [] =
{
SK_REF,
};

static const uint16 attr_flags1218 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1218_0 [] = {301,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1218 [] = {
g_atype1218_0,
};

static const long offsets1218 [] =
{
0,
};

extern const char *names1219[];
static const uint32 types1219 [] =
{
SK_REF,
};

static const uint16 attr_flags1219 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1219_0 [] = {302,939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1219 [] = {
g_atype1219_0,
};

static const long offsets1219 [] =
{
0,
};

extern const char *names1220[];
static const uint32 types1220 [] =
{
SK_REF,
};

static const uint16 attr_flags1220 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1220_0 [] = {304,918,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1220 [] = {
g_atype1220_0,
};

static const long offsets1220 [] =
{
0,
};

extern const char *names1221[];
static const uint32 types1221 [] =
{
SK_REF,
};

static const uint16 attr_flags1221 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1221_0 [] = {303,915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1221 [] = {
g_atype1221_0,
};

static const long offsets1221 [] =
{
0,
};

extern const char *names1222[];
static const uint32 types1222 [] =
{
SK_REF,
};

static const uint16 attr_flags1222 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1222_0 [] = {305,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1222 [] = {
g_atype1222_0,
};

static const long offsets1222 [] =
{
0,
};

extern const char *names1223[];
static const uint32 types1223 [] =
{
SK_REF,
};

static const uint16 attr_flags1223 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1223_0 [] = {306,936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1223 [] = {
g_atype1223_0,
};

static const long offsets1223 [] =
{
0,
};

extern const char *names1224[];
static const uint32 types1224 [] =
{
SK_REF,
};

static const uint16 attr_flags1224 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1224_0 [] = {301,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1224 [] = {
g_atype1224_0,
};

static const long offsets1224 [] =
{
0,
};

extern const char *names1225[];
static const uint32 types1225 [] =
{
SK_REF,
};

static const uint16 attr_flags1225 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1225_0 [] = {302,939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1225 [] = {
g_atype1225_0,
};

static const long offsets1225 [] =
{
0,
};

extern const char *names1226[];
static const uint32 types1226 [] =
{
SK_REF,
};

static const uint16 attr_flags1226 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1226_0 [] = {304,918,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1226 [] = {
g_atype1226_0,
};

static const long offsets1226 [] =
{
0,
};

extern const char *names1227[];
static const uint32 types1227 [] =
{
SK_REF,
};

static const uint16 attr_flags1227 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1227_0 [] = {303,915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1227 [] = {
g_atype1227_0,
};

static const long offsets1227 [] =
{
0,
};

extern const char *names1228[];
static const uint32 types1228 [] =
{
SK_REF,
};

static const uint16 attr_flags1228 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1228_0 [] = {305,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1228 [] = {
g_atype1228_0,
};

static const long offsets1228 [] =
{
0,
};

extern const char *names1229[];
static const uint32 types1229 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1229 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1229_0 [] = {301,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_1 [] = {0xFF01,1276,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1229_2 [] = {0xFF01,1130,0xFFF8,1,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1229 [] = {
g_atype1229_0,
g_atype1229_1,
g_atype1229_2,
};

static const long offsets1229 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1230[];
static const uint32 types1230 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1230 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1230_0 [] = {301,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_1 [] = {0xFF01,1277,939,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1230_2 [] = {0xFF01,1131,939,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1230 [] = {
g_atype1230_0,
g_atype1230_1,
g_atype1230_2,
};

static const long offsets1230 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1231[];
static const uint32 types1231 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1231 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1231_0 [] = {304,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_1 [] = {0xFF01,1278,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1231_2 [] = {0xFF01,1132,915,918,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1231 [] = {
g_atype1231_0,
g_atype1231_1,
g_atype1231_2,
};

static const long offsets1231 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1232[];
static const uint32 types1232 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1232 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1232_0 [] = {301,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_1 [] = {0xFF01,1279,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1232_2 [] = {0xFF01,1133,906,0xFFF8,2,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1232 [] = {
g_atype1232_0,
g_atype1232_1,
g_atype1232_2,
};

static const long offsets1232 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1233[];
static const uint32 types1233 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1233 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1233_0 [] = {305,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_1 [] = {0xFF01,1280,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1233_2 [] = {0xFF01,1134,906,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1233 [] = {
g_atype1233_0,
g_atype1233_1,
g_atype1233_2,
};

static const long offsets1233 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1234[];
static const uint32 types1234 [] =
{
SK_REF,
};

static const uint16 attr_flags1234 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1234_0 [] = {301,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1234 [] = {
g_atype1234_0,
};

static const long offsets1234 [] =
{
0,
};

extern const char *names1235[];
static const uint32 types1235 [] =
{
SK_REF,
};

static const uint16 attr_flags1235 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1235_0 [] = {302,939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1235 [] = {
g_atype1235_0,
};

static const long offsets1235 [] =
{
0,
};

extern const char *names1236[];
static const uint32 types1236 [] =
{
SK_REF,
};

static const uint16 attr_flags1236 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1236_0 [] = {303,915,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1236 [] = {
g_atype1236_0,
};

static const long offsets1236 [] =
{
0,
};

extern const char *names1237[];
static const uint32 types1237 [] =
{
SK_REF,
};

static const uint16 attr_flags1237 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1237_0 [] = {305,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1237 [] = {
g_atype1237_0,
};

static const long offsets1237 [] =
{
0,
};

extern const char *names1238[];
static const uint32 types1238 [] =
{
SK_REF,
};

static const uint16 attr_flags1238 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1238_0 [] = {305,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1238 [] = {
g_atype1238_0,
};

static const long offsets1238 [] =
{
0,
};

extern const char *names1239[];
static const uint32 types1239 [] =
{
SK_REF,
};

static const uint16 attr_flags1239 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1239_0 [] = {301,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1239 [] = {
g_atype1239_0,
};

static const long offsets1239 [] =
{
0,
};

extern const char *names1240[];
static const uint32 types1240 [] =
{
SK_REF,
};

static const uint16 attr_flags1240 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1240_0 [] = {302,939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1240 [] = {
g_atype1240_0,
};

static const long offsets1240 [] =
{
0,
};

extern const char *names1241[];
static const uint32 types1241 [] =
{
SK_REF,
};

static const uint16 attr_flags1241 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1241_0 [] = {305,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1241 [] = {
g_atype1241_0,
};

static const long offsets1241 [] =
{
0,
};

extern const char *names1242[];
static const uint32 types1242 [] =
{
SK_REF,
};

static const uint16 attr_flags1242 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1242_0 [] = {306,936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1242 [] = {
g_atype1242_0,
};

static const long offsets1242 [] =
{
0,
};

extern const char *names1243[];
static const uint32 types1243 [] =
{
SK_REF,
};

static const uint16 attr_flags1243 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1243_0 [] = {301,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1243 [] = {
g_atype1243_0,
};

static const long offsets1243 [] =
{
0,
};

extern const char *names1244[];
static const uint32 types1244 [] =
{
SK_REF,
};

static const uint16 attr_flags1244 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1244_0 [] = {305,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1244 [] = {
g_atype1244_0,
};

static const long offsets1244 [] =
{
0,
};

extern const char *names1245[];
static const uint32 types1245 [] =
{
SK_REF,
};

static const uint16 attr_flags1245 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1245_0 [] = {301,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1245 [] = {
g_atype1245_0,
};

static const long offsets1245 [] =
{
0,
};

extern const char *names1246[];
static const uint32 types1246 [] =
{
SK_REF,
};

static const uint16 attr_flags1246 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1246_0 [] = {305,906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1246 [] = {
g_atype1246_0,
};

static const long offsets1246 [] =
{
0,
};

extern const char *names1247[];
static const uint32 types1247 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1247 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1247_0 [] = {301,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_1 [] = {152,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_2 [] = {152,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_3 [] = {0xFF01,1166,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1247_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1247 [] = {
g_atype1247_0,
g_atype1247_1,
g_atype1247_2,
g_atype1247_3,
g_atype1247_4,
};

static const long offsets1247 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1248[];
static const uint32 types1248 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1248 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1248_0 [] = {305,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_1 [] = {154,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_2 [] = {154,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_3 [] = {0xFF01,1167,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1248_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1248 [] = {
g_atype1248_0,
g_atype1248_1,
g_atype1248_2,
g_atype1248_3,
g_atype1248_4,
};

static const long offsets1248 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1249[];
static const uint32 types1249 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1249 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1249_0 [] = {301,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_1 [] = {152,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_2 [] = {152,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_3 [] = {0xFF01,1166,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1249_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1249 [] = {
g_atype1249_0,
g_atype1249_1,
g_atype1249_2,
g_atype1249_3,
g_atype1249_4,
};

static const long offsets1249 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1250[];
static const uint32 types1250 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1250 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1250_0 [] = {301,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_1 [] = {156,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_2 [] = {156,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_3 [] = {0xFF01,1168,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1250_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1250 [] = {
g_atype1250_0,
g_atype1250_1,
g_atype1250_2,
g_atype1250_3,
g_atype1250_4,
};

static const long offsets1250 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
};

extern const char *names1251[];
static const uint32 types1251 [] =
{
SK_REF,
};

static const uint16 attr_flags1251 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1251_0 [] = {301,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1251 [] = {
g_atype1251_0,
};

static const long offsets1251 [] =
{
0,
};

extern const char *names1252[];
static const uint32 types1252 [] =
{
SK_REF,
};

static const uint16 attr_flags1252 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1252_0 [] = {301,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1252 [] = {
g_atype1252_0,
};

static const long offsets1252 [] =
{
0,
};

extern const char *names1253[];
static const uint32 types1253 [] =
{
SK_REF,
};

static const uint16 attr_flags1253 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1253_0 [] = {302,939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1253 [] = {
g_atype1253_0,
};

static const long offsets1253 [] =
{
0,
};

extern const char *names1254[];
static const uint32 types1254 [] =
{
SK_REF,
};

static const uint16 attr_flags1254 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1254_0 [] = {306,936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1254 [] = {
g_atype1254_0,
};

static const long offsets1254 [] =
{
0,
};

extern const char *names1255[];
static const uint32 types1255 [] =
{
SK_REF,
};

static const uint16 attr_flags1255 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1255_0 [] = {301,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1255 [] = {
g_atype1255_0,
};

static const long offsets1255 [] =
{
0,
};

extern const char *names1256[];
static const uint32 types1256 [] =
{
SK_REF,
};

static const uint16 attr_flags1256 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1256_0 [] = {306,936,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1256 [] = {
g_atype1256_0,
};

static const long offsets1256 [] =
{
0,
};

extern const char *names1257[];
static const uint32 types1257 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1257 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1257_0 [] = {301,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1257_1 [] = {152,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1257_2 [] = {152,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1257_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1257 [] = {
g_atype1257_0,
g_atype1257_1,
g_atype1257_2,
g_atype1257_3,
};

static const long offsets1257 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
};

extern const char *names1258[];
static const uint32 types1258 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1258 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1258_0 [] = {306,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_1 [] = {155,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_2 [] = {155,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1258_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1258 [] = {
g_atype1258_0,
g_atype1258_1,
g_atype1258_2,
g_atype1258_3,
};

static const long offsets1258 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
};

extern const char *names1259[];
static const uint32 types1259 [] =
{
SK_REF,
};

static const uint16 attr_flags1259 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1259_0 [] = {301,0xFFF8,1,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1259 [] = {
g_atype1259_0,
};

static const long offsets1259 [] =
{
0,
};

extern const char *names1260[];
static const uint32 types1260 [] =
{
SK_REF,
};

static const uint16 attr_flags1260 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1260_0 [] = {302,939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1260 [] = {
g_atype1260_0,
};

static const long offsets1260 [] =
{
0,
};

extern const char *names1261[];
static const uint32 types1261 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1261 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1261_0 [] = {301,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_1 [] = {152,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1261_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1261 [] = {
g_atype1261_0,
g_atype1261_1,
g_atype1261_2,
};

static const long offsets1261 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1262[];
static const uint32 types1262 [] =
{
SK_REF,
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1262 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1262_0 [] = {302,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_1 [] = {153,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1262_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1262 [] = {
g_atype1262_0,
g_atype1262_1,
g_atype1262_2,
};

static const long offsets1262 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
};

extern const char *names1267[];
static const uint32 types1267 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1267 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1267_0 [] = {302,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_1 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_2 [] = {0xFF01,29,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1267_4 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1267 [] = {
g_atype1267_0,
g_atype1267_1,
g_atype1267_2,
g_atype1267_3,
g_atype1267_4,
};

static const long offsets1267 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @LNGOFF(3,0,0,0),
+ @LNGOFF(3,0,0,1),
};

extern const char *names1268[];
static const uint32 types1268 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1268 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1268_0 [] = {301,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1268_1 [] = {0xFF01,746,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1268_2 [] = {0xFF01,28,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1268_3 [] = {0xFF01,1165,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1268_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1268_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1268 [] = {
g_atype1268_0,
g_atype1268_1,
g_atype1268_2,
g_atype1268_3,
g_atype1268_4,
g_atype1268_5,
};

static const long offsets1268 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
};

extern const char *names1269[];
static const uint32 types1269 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1269 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1269_0 [] = {301,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_1 [] = {0xFF01,1140,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1269_10 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1269 [] = {
g_atype1269_0,
g_atype1269_1,
g_atype1269_2,
g_atype1269_3,
g_atype1269_4,
g_atype1269_5,
g_atype1269_6,
g_atype1269_7,
g_atype1269_8,
g_atype1269_9,
g_atype1269_10,
};

static const long offsets1269 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1270[];
static const uint32 types1270 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1270 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1270_0 [] = {302,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_1 [] = {0xFF01,1141,939,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1270_10 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1270 [] = {
g_atype1270_0,
g_atype1270_1,
g_atype1270_2,
g_atype1270_3,
g_atype1270_4,
g_atype1270_5,
g_atype1270_6,
g_atype1270_7,
g_atype1270_8,
g_atype1270_9,
g_atype1270_10,
};

static const long offsets1270 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1271[];
static const uint32 types1271 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1271 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1271_0 [] = {303,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_1 [] = {0xFF01,1142,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1271_10 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1271 [] = {
g_atype1271_0,
g_atype1271_1,
g_atype1271_2,
g_atype1271_3,
g_atype1271_4,
g_atype1271_5,
g_atype1271_6,
g_atype1271_7,
g_atype1271_8,
g_atype1271_9,
g_atype1271_10,
};

static const long offsets1271 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1272[];
static const uint32 types1272 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1272 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1272_0 [] = {305,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_1 [] = {0xFF01,1143,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1272_10 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1272 [] = {
g_atype1272_0,
g_atype1272_1,
g_atype1272_2,
g_atype1272_3,
g_atype1272_4,
g_atype1272_5,
g_atype1272_6,
g_atype1272_7,
g_atype1272_8,
g_atype1272_9,
g_atype1272_10,
};

static const long offsets1272 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1273[];
static const uint32 types1273 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1273 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1273_0 [] = {305,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_1 [] = {0xFF01,1144,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1273_10 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1273 [] = {
g_atype1273_0,
g_atype1273_1,
g_atype1273_2,
g_atype1273_3,
g_atype1273_4,
g_atype1273_5,
g_atype1273_6,
g_atype1273_7,
g_atype1273_8,
g_atype1273_9,
g_atype1273_10,
};

static const long offsets1273 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1274[];
static const uint32 types1274 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1274 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1274_0 [] = {301,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_1 [] = {0xFF01,1145,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1274_10 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1274 [] = {
g_atype1274_0,
g_atype1274_1,
g_atype1274_2,
g_atype1274_3,
g_atype1274_4,
g_atype1274_5,
g_atype1274_6,
g_atype1274_7,
g_atype1274_8,
g_atype1274_9,
g_atype1274_10,
};

static const long offsets1274 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
+ @LNGOFF(2,0,0,7),
+ @LNGOFF(2,0,0,8),
};

extern const char *names1275[];
static const uint32 types1275 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1275 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1275_0 [] = {301,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_1 [] = {0xFF01,1146,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_2 [] = {0xFF01,746,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_3 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_5 [] = {0xFF01,28,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1275_14 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1275 [] = {
g_atype1275_0,
g_atype1275_1,
g_atype1275_2,
g_atype1275_3,
g_atype1275_4,
g_atype1275_5,
g_atype1275_6,
g_atype1275_7,
g_atype1275_8,
g_atype1275_9,
g_atype1275_10,
g_atype1275_11,
g_atype1275_12,
g_atype1275_13,
g_atype1275_14,
};

static const long offsets1275 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @LNGOFF(6,0,0,0),
+ @LNGOFF(6,0,0,1),
+ @LNGOFF(6,0,0,2),
+ @LNGOFF(6,0,0,3),
+ @LNGOFF(6,0,0,4),
+ @LNGOFF(6,0,0,5),
+ @LNGOFF(6,0,0,6),
+ @LNGOFF(6,0,0,7),
+ @LNGOFF(6,0,0,8),
};

extern const char *names1276[];
static const uint32 types1276 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1276 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1276_0 [] = {301,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_1 [] = {0xFF01,1147,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_2 [] = {0xFF01,746,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_3 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_5 [] = {0xFF01,28,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_6 [] = {18,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1276_15 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1276 [] = {
g_atype1276_0,
g_atype1276_1,
g_atype1276_2,
g_atype1276_3,
g_atype1276_4,
g_atype1276_5,
g_atype1276_6,
g_atype1276_7,
g_atype1276_8,
g_atype1276_9,
g_atype1276_10,
g_atype1276_11,
g_atype1276_12,
g_atype1276_13,
g_atype1276_14,
g_atype1276_15,
};

static const long offsets1276 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @LNGOFF(7,0,0,0),
+ @LNGOFF(7,0,0,1),
+ @LNGOFF(7,0,0,2),
+ @LNGOFF(7,0,0,3),
+ @LNGOFF(7,0,0,4),
+ @LNGOFF(7,0,0,5),
+ @LNGOFF(7,0,0,6),
+ @LNGOFF(7,0,0,7),
+ @LNGOFF(7,0,0,8),
};

extern const char *names1277[];
static const uint32 types1277 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1277 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1277_0 [] = {301,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_1 [] = {0xFF01,1148,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_2 [] = {1228,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_3 [] = {301,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1277_12 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1277 [] = {
g_atype1277_0,
g_atype1277_1,
g_atype1277_2,
g_atype1277_3,
g_atype1277_4,
g_atype1277_5,
g_atype1277_6,
g_atype1277_7,
g_atype1277_8,
g_atype1277_9,
g_atype1277_10,
g_atype1277_11,
g_atype1277_12,
};

static const long offsets1277 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1278[];
static const uint32 types1278 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1278 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1278_0 [] = {302,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_1 [] = {0xFF01,1149,939,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_2 [] = {1229,939,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_3 [] = {301,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1278_12 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1278 [] = {
g_atype1278_0,
g_atype1278_1,
g_atype1278_2,
g_atype1278_3,
g_atype1278_4,
g_atype1278_5,
g_atype1278_6,
g_atype1278_7,
g_atype1278_8,
g_atype1278_9,
g_atype1278_10,
g_atype1278_11,
g_atype1278_12,
};

static const long offsets1278 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1279[];
static const uint32 types1279 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1279 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1279_0 [] = {303,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_1 [] = {0xFF01,1150,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_2 [] = {1230,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_3 [] = {304,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1279_12 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1279 [] = {
g_atype1279_0,
g_atype1279_1,
g_atype1279_2,
g_atype1279_3,
g_atype1279_4,
g_atype1279_5,
g_atype1279_6,
g_atype1279_7,
g_atype1279_8,
g_atype1279_9,
g_atype1279_10,
g_atype1279_11,
g_atype1279_12,
};

static const long offsets1279 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1280[];
static const uint32 types1280 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1280 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1280_0 [] = {305,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_1 [] = {0xFF01,1151,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_2 [] = {1231,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_3 [] = {301,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1280_12 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1280 [] = {
g_atype1280_0,
g_atype1280_1,
g_atype1280_2,
g_atype1280_3,
g_atype1280_4,
g_atype1280_5,
g_atype1280_6,
g_atype1280_7,
g_atype1280_8,
g_atype1280_9,
g_atype1280_10,
g_atype1280_11,
g_atype1280_12,
};

static const long offsets1280 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1281[];
static const uint32 types1281 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1281 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1281_0 [] = {305,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_1 [] = {0xFF01,1152,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_2 [] = {1232,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_3 [] = {305,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1281_12 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1281 [] = {
g_atype1281_0,
g_atype1281_1,
g_atype1281_2,
g_atype1281_3,
g_atype1281_4,
g_atype1281_5,
g_atype1281_6,
g_atype1281_7,
g_atype1281_8,
g_atype1281_9,
g_atype1281_10,
g_atype1281_11,
g_atype1281_12,
};

static const long offsets1281 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @LNGOFF(4,0,0,0),
+ @LNGOFF(4,0,0,1),
+ @LNGOFF(4,0,0,2),
+ @LNGOFF(4,0,0,3),
+ @LNGOFF(4,0,0,4),
+ @LNGOFF(4,0,0,5),
+ @LNGOFF(4,0,0,6),
+ @LNGOFF(4,0,0,7),
+ @LNGOFF(4,0,0,8),
};

extern const char *names1282[];
static const uint32 types1282 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1282 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1282_0 [] = {301,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_1 [] = {0xFF01,1153,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_2 [] = {1228,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_3 [] = {301,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_4 [] = {0xFF01,746,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_5 [] = {0xFF01,746,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_8 [] = {0xFF01,28,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_9 [] = {0xFF01,28,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1282_18 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1282 [] = {
g_atype1282_0,
g_atype1282_1,
g_atype1282_2,
g_atype1282_3,
g_atype1282_4,
g_atype1282_5,
g_atype1282_6,
g_atype1282_7,
g_atype1282_8,
g_atype1282_9,
g_atype1282_10,
g_atype1282_11,
g_atype1282_12,
g_atype1282_13,
g_atype1282_14,
g_atype1282_15,
g_atype1282_16,
g_atype1282_17,
g_atype1282_18,
};

static const long offsets1282 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1283[];
static const uint32 types1283 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1283 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1283_0 [] = {302,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_1 [] = {0xFF01,1154,939,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_2 [] = {1229,939,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_3 [] = {301,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_4 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_5 [] = {0xFF01,746,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_8 [] = {0xFF01,29,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_9 [] = {0xFF01,28,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1283_18 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1283 [] = {
g_atype1283_0,
g_atype1283_1,
g_atype1283_2,
g_atype1283_3,
g_atype1283_4,
g_atype1283_5,
g_atype1283_6,
g_atype1283_7,
g_atype1283_8,
g_atype1283_9,
g_atype1283_10,
g_atype1283_11,
g_atype1283_12,
g_atype1283_13,
g_atype1283_14,
g_atype1283_15,
g_atype1283_16,
g_atype1283_17,
g_atype1283_18,
};

static const long offsets1283 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1284[];
static const uint32 types1284 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1284 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1284_0 [] = {303,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_1 [] = {0xFF01,1155,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_2 [] = {1230,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_3 [] = {304,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_4 [] = {0xFF01,749,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_5 [] = {0xFF01,750,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_8 [] = {0xFF01,31,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_9 [] = {0xFF01,30,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1284_18 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1284 [] = {
g_atype1284_0,
g_atype1284_1,
g_atype1284_2,
g_atype1284_3,
g_atype1284_4,
g_atype1284_5,
g_atype1284_6,
g_atype1284_7,
g_atype1284_8,
g_atype1284_9,
g_atype1284_10,
g_atype1284_11,
g_atype1284_12,
g_atype1284_13,
g_atype1284_14,
g_atype1284_15,
g_atype1284_16,
g_atype1284_17,
g_atype1284_18,
};

static const long offsets1284 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1285[];
static const uint32 types1285 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1285 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1285_0 [] = {305,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_1 [] = {0xFF01,1156,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_2 [] = {1231,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_3 [] = {301,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_5 [] = {0xFF01,746,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_8 [] = {0xFF01,32,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_9 [] = {0xFF01,28,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1285_18 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1285 [] = {
g_atype1285_0,
g_atype1285_1,
g_atype1285_2,
g_atype1285_3,
g_atype1285_4,
g_atype1285_5,
g_atype1285_6,
g_atype1285_7,
g_atype1285_8,
g_atype1285_9,
g_atype1285_10,
g_atype1285_11,
g_atype1285_12,
g_atype1285_13,
g_atype1285_14,
g_atype1285_15,
g_atype1285_16,
g_atype1285_17,
g_atype1285_18,
};

static const long offsets1285 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1286[];
static const uint32 types1286 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1286 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1286_0 [] = {305,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_1 [] = {0xFF01,1157,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_2 [] = {1232,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_3 [] = {305,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_5 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_8 [] = {0xFF01,32,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_9 [] = {0xFF01,32,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_10 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1286_18 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1286 [] = {
g_atype1286_0,
g_atype1286_1,
g_atype1286_2,
g_atype1286_3,
g_atype1286_4,
g_atype1286_5,
g_atype1286_6,
g_atype1286_7,
g_atype1286_8,
g_atype1286_9,
g_atype1286_10,
g_atype1286_11,
g_atype1286_12,
g_atype1286_13,
g_atype1286_14,
g_atype1286_15,
g_atype1286_16,
g_atype1286_17,
g_atype1286_18,
};

static const long offsets1286 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
+ @LNGOFF(10,0,0,0),
+ @LNGOFF(10,0,0,1),
+ @LNGOFF(10,0,0,2),
+ @LNGOFF(10,0,0,3),
+ @LNGOFF(10,0,0,4),
+ @LNGOFF(10,0,0,5),
+ @LNGOFF(10,0,0,6),
+ @LNGOFF(10,0,0,7),
+ @LNGOFF(10,0,0,8),
};

extern const char *names1287[];
static const uint32 types1287 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1287 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1287_0 [] = {301,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_1 [] = {0xFF01,1158,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_2 [] = {1228,0xFFF8,1,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_3 [] = {301,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_4 [] = {0xFF01,746,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_5 [] = {0xFF01,746,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_8 [] = {0xFF01,28,0xFFF8,1,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_9 [] = {0xFF01,28,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_10 [] = {18,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_18 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1287_19 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1287 [] = {
g_atype1287_0,
g_atype1287_1,
g_atype1287_2,
g_atype1287_3,
g_atype1287_4,
g_atype1287_5,
g_atype1287_6,
g_atype1287_7,
g_atype1287_8,
g_atype1287_9,
g_atype1287_10,
g_atype1287_11,
g_atype1287_12,
g_atype1287_13,
g_atype1287_14,
g_atype1287_15,
g_atype1287_16,
g_atype1287_17,
g_atype1287_18,
g_atype1287_19,
};

static const long offsets1287 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1288[];
static const uint32 types1288 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1288 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1288_0 [] = {302,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_1 [] = {0xFF01,1159,939,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_2 [] = {1229,939,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_3 [] = {301,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_4 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_5 [] = {0xFF01,746,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_8 [] = {0xFF01,29,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_9 [] = {0xFF01,28,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_10 [] = {18,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_18 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1288_19 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1288 [] = {
g_atype1288_0,
g_atype1288_1,
g_atype1288_2,
g_atype1288_3,
g_atype1288_4,
g_atype1288_5,
g_atype1288_6,
g_atype1288_7,
g_atype1288_8,
g_atype1288_9,
g_atype1288_10,
g_atype1288_11,
g_atype1288_12,
g_atype1288_13,
g_atype1288_14,
g_atype1288_15,
g_atype1288_16,
g_atype1288_17,
g_atype1288_18,
g_atype1288_19,
};

static const long offsets1288 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1289[];
static const uint32 types1289 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1289 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1289_0 [] = {303,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_1 [] = {0xFF01,1160,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_2 [] = {1230,915,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_3 [] = {304,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_4 [] = {0xFF01,749,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_5 [] = {0xFF01,750,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_8 [] = {0xFF01,31,915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_9 [] = {0xFF01,30,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_10 [] = {19,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_18 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1289_19 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1289 [] = {
g_atype1289_0,
g_atype1289_1,
g_atype1289_2,
g_atype1289_3,
g_atype1289_4,
g_atype1289_5,
g_atype1289_6,
g_atype1289_7,
g_atype1289_8,
g_atype1289_9,
g_atype1289_10,
g_atype1289_11,
g_atype1289_12,
g_atype1289_13,
g_atype1289_14,
g_atype1289_15,
g_atype1289_16,
g_atype1289_17,
g_atype1289_18,
g_atype1289_19,
};

static const long offsets1289 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1290[];
static const uint32 types1290 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1290 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1290_0 [] = {305,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_1 [] = {0xFF01,1161,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_2 [] = {1231,906,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_3 [] = {301,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_5 [] = {0xFF01,746,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_8 [] = {0xFF01,32,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_9 [] = {0xFF01,28,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_10 [] = {18,0xFFF8,2,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_18 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1290_19 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1290 [] = {
g_atype1290_0,
g_atype1290_1,
g_atype1290_2,
g_atype1290_3,
g_atype1290_4,
g_atype1290_5,
g_atype1290_6,
g_atype1290_7,
g_atype1290_8,
g_atype1290_9,
g_atype1290_10,
g_atype1290_11,
g_atype1290_12,
g_atype1290_13,
g_atype1290_14,
g_atype1290_15,
g_atype1290_16,
g_atype1290_17,
g_atype1290_18,
g_atype1290_19,
};

static const long offsets1290 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1291[];
static const uint32 types1291 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1291 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1291_0 [] = {305,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_1 [] = {0xFF01,1162,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_2 [] = {1232,906,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_3 [] = {305,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_5 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_8 [] = {0xFF01,32,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_9 [] = {0xFF01,32,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_10 [] = {20,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_11 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_18 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1291_19 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1291 [] = {
g_atype1291_0,
g_atype1291_1,
g_atype1291_2,
g_atype1291_3,
g_atype1291_4,
g_atype1291_5,
g_atype1291_6,
g_atype1291_7,
g_atype1291_8,
g_atype1291_9,
g_atype1291_10,
g_atype1291_11,
g_atype1291_12,
g_atype1291_13,
g_atype1291_14,
g_atype1291_15,
g_atype1291_16,
g_atype1291_17,
g_atype1291_18,
g_atype1291_19,
};

static const long offsets1291 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @LNGOFF(11,0,0,0),
+ @LNGOFF(11,0,0,1),
+ @LNGOFF(11,0,0,2),
+ @LNGOFF(11,0,0,3),
+ @LNGOFF(11,0,0,4),
+ @LNGOFF(11,0,0,5),
+ @LNGOFF(11,0,0,6),
+ @LNGOFF(11,0,0,7),
+ @LNGOFF(11,0,0,8),
};

extern const char *names1293[];
static const uint32 types1293 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_POINTER,
SK_POINTER,
};

static const uint16 attr_flags1293 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1293_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_1 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_2 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_3 [] = {85,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_4 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_5 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_9 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype1293_10 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1293 [] = {
g_atype1293_0,
g_atype1293_1,
g_atype1293_2,
g_atype1293_3,
g_atype1293_4,
g_atype1293_5,
g_atype1293_6,
g_atype1293_7,
g_atype1293_8,
g_atype1293_9,
g_atype1293_10,
};

static const long offsets1293 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @LNGOFF(6,2,0,0),
+ @PTROFF(6,2,0,1,0,0),
+ @PTROFF(6,2,0,1,0,1),
};

extern const char *names1294[];
static const uint32 types1294 [] =
{
SK_REF,
};

static const uint16 attr_flags1294 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1294_0 [] = {0xFF01,1079,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1294 [] = {
g_atype1294_0,
};

static const long offsets1294 [] =
{
0,
};

extern const char *names1295[];
static const uint32 types1295 [] =
{
SK_REF,
};

static const uint16 attr_flags1295 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1295_0 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1295 [] = {
g_atype1295_0,
};

static const long offsets1295 [] =
{
0,
};

extern const char *names1296[];
static const uint32 types1296 [] =
{
SK_REF,
};

static const uint16 attr_flags1296 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1296_0 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1296 [] = {
g_atype1296_0,
};

static const long offsets1296 [] =
{
0,
};

extern const char *names1297[];
static const uint32 types1297 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1297 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1297_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_1 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_2 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_3 [] = {0xFF01,983,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_4 [] = {39,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_5 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_6 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_7 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_9 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_10 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_11 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_12 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_13 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_14 [] = {909,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_15 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_18 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_19 [] = {927,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_20 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_21 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_22 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1297_23 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1297 [] = {
g_atype1297_0,
g_atype1297_1,
g_atype1297_2,
g_atype1297_3,
g_atype1297_4,
g_atype1297_5,
g_atype1297_6,
g_atype1297_7,
g_atype1297_8,
g_atype1297_9,
g_atype1297_10,
g_atype1297_11,
g_atype1297_12,
g_atype1297_13,
g_atype1297_14,
g_atype1297_15,
g_atype1297_16,
g_atype1297_17,
g_atype1297_18,
g_atype1297_19,
g_atype1297_20,
g_atype1297_21,
g_atype1297_22,
g_atype1297_23,
};

static const long offsets1297 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1298[];
static const uint32 types1298 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1298 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1298_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_1 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_2 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_3 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_4 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_5 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_6 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_9 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_10 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_11 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_12 [] = {909,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_13 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_17 [] = {927,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_18 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_19 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_20 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1298_21 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1298 [] = {
g_atype1298_0,
g_atype1298_1,
g_atype1298_2,
g_atype1298_3,
g_atype1298_4,
g_atype1298_5,
g_atype1298_6,
g_atype1298_7,
g_atype1298_8,
g_atype1298_9,
g_atype1298_10,
g_atype1298_11,
g_atype1298_12,
g_atype1298_13,
g_atype1298_14,
g_atype1298_15,
g_atype1298_16,
g_atype1298_17,
g_atype1298_18,
g_atype1298_19,
g_atype1298_20,
g_atype1298_21,
};

static const long offsets1298 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1299[];
static const uint32 types1299 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1299 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1299_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_1 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_2 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_3 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_4 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_5 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_6 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_9 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_10 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_11 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_12 [] = {909,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_13 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_17 [] = {927,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_18 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_19 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_20 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1299_21 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1299 [] = {
g_atype1299_0,
g_atype1299_1,
g_atype1299_2,
g_atype1299_3,
g_atype1299_4,
g_atype1299_5,
g_atype1299_6,
g_atype1299_7,
g_atype1299_8,
g_atype1299_9,
g_atype1299_10,
g_atype1299_11,
g_atype1299_12,
g_atype1299_13,
g_atype1299_14,
g_atype1299_15,
g_atype1299_16,
g_atype1299_17,
g_atype1299_18,
g_atype1299_19,
g_atype1299_20,
g_atype1299_21,
};

static const long offsets1299 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1300[];
static const uint32 types1300 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1300 [] =
{0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1300_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_1 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_2 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_3 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_4 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_5 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_6 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_9 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_10 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_11 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_12 [] = {909,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_13 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_17 [] = {927,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_18 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_19 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_20 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1300_21 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1300 [] = {
g_atype1300_0,
g_atype1300_1,
g_atype1300_2,
g_atype1300_3,
g_atype1300_4,
g_atype1300_5,
g_atype1300_6,
g_atype1300_7,
g_atype1300_8,
g_atype1300_9,
g_atype1300_10,
g_atype1300_11,
g_atype1300_12,
g_atype1300_13,
g_atype1300_14,
g_atype1300_15,
g_atype1300_16,
g_atype1300_17,
g_atype1300_18,
g_atype1300_19,
g_atype1300_20,
g_atype1300_21,
};

static const long offsets1300 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @CHROFF(5,5),
+ @I16OFF(5,6,0),
+ @I16OFF(5,6,1),
+ @LNGOFF(5,6,2,0),
+ @LNGOFF(5,6,2,1),
+ @LNGOFF(5,6,2,2),
+ @LNGOFF(5,6,2,3),
+ @R32OFF(5,6,2,4,0),
+ @PTROFF(5,6,2,4,1,0),
+ @I64OFF(5,6,2,4,1,1,0),
+ @I64OFF(5,6,2,4,1,1,1),
+ @R64OFF(5,6,2,4,1,1,2,0),
};

extern const char *names1301[];
static const uint32 types1301 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags1301 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1301_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_1 [] = {86,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_3 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1301_4 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1301 [] = {
g_atype1301_0,
g_atype1301_1,
g_atype1301_2,
g_atype1301_3,
g_atype1301_4,
};

static const long offsets1301 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
};

extern const char *names1302[];
static const uint32 types1302 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1302 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1302_0 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_1 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_2 [] = {0xFF01,983,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_3 [] = {39,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_4 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_5 [] = {86,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_6 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_7 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_8 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_9 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_10 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_11 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_12 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_13 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_14 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_15 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_16 [] = {909,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_17 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_18 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_19 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_20 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_21 [] = {927,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_22 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_23 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_24 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1302_25 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1302 [] = {
g_atype1302_0,
g_atype1302_1,
g_atype1302_2,
g_atype1302_3,
g_atype1302_4,
g_atype1302_5,
g_atype1302_6,
g_atype1302_7,
g_atype1302_8,
g_atype1302_9,
g_atype1302_10,
g_atype1302_11,
g_atype1302_12,
g_atype1302_13,
g_atype1302_14,
g_atype1302_15,
g_atype1302_16,
g_atype1302_17,
g_atype1302_18,
g_atype1302_19,
g_atype1302_20,
g_atype1302_21,
g_atype1302_22,
g_atype1302_23,
g_atype1302_24,
g_atype1302_25,
};

static const long offsets1302 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
+ @CHROFF(7,0),
+ @CHROFF(7,1),
+ @CHROFF(7,2),
+ @CHROFF(7,3),
+ @CHROFF(7,4),
+ @CHROFF(7,5),
+ @CHROFF(7,6),
+ @CHROFF(7,7),
+ @I16OFF(7,8,0),
+ @I16OFF(7,8,1),
+ @LNGOFF(7,8,2,0),
+ @LNGOFF(7,8,2,1),
+ @LNGOFF(7,8,2,2),
+ @LNGOFF(7,8,2,3),
+ @R32OFF(7,8,2,4,0),
+ @PTROFF(7,8,2,4,1,0),
+ @I64OFF(7,8,2,4,1,1,0),
+ @I64OFF(7,8,2,4,1,1,1),
+ @R64OFF(7,8,2,4,1,1,2,0),
};

extern const char *names1303[];
static const uint32 types1303 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1303 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1303_0 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_1 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_2 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_3 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_4 [] = {86,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_5 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_6 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_7 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_9 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_10 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_11 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_12 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_13 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_14 [] = {909,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_15 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_18 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_19 [] = {927,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_20 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_21 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_22 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1303_23 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1303 [] = {
g_atype1303_0,
g_atype1303_1,
g_atype1303_2,
g_atype1303_3,
g_atype1303_4,
g_atype1303_5,
g_atype1303_6,
g_atype1303_7,
g_atype1303_8,
g_atype1303_9,
g_atype1303_10,
g_atype1303_11,
g_atype1303_12,
g_atype1303_13,
g_atype1303_14,
g_atype1303_15,
g_atype1303_16,
g_atype1303_17,
g_atype1303_18,
g_atype1303_19,
g_atype1303_20,
g_atype1303_21,
g_atype1303_22,
g_atype1303_23,
};

static const long offsets1303 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1304[];
static const uint32 types1304 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1304 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1304_0 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_1 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_2 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_3 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_4 [] = {86,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_5 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_6 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_7 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_9 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_10 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_11 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_12 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_13 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_14 [] = {909,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_15 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_18 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_19 [] = {927,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_20 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_21 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_22 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1304_23 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1304 [] = {
g_atype1304_0,
g_atype1304_1,
g_atype1304_2,
g_atype1304_3,
g_atype1304_4,
g_atype1304_5,
g_atype1304_6,
g_atype1304_7,
g_atype1304_8,
g_atype1304_9,
g_atype1304_10,
g_atype1304_11,
g_atype1304_12,
g_atype1304_13,
g_atype1304_14,
g_atype1304_15,
g_atype1304_16,
g_atype1304_17,
g_atype1304_18,
g_atype1304_19,
g_atype1304_20,
g_atype1304_21,
g_atype1304_22,
g_atype1304_23,
};

static const long offsets1304 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1305[];
static const uint32 types1305 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT8,
SK_INT8,
SK_UINT16,
SK_INT16,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_REAL32,
SK_POINTER,
SK_UINT64,
SK_INT64,
SK_REAL64,
};

static const uint16 attr_flags1305 [] =
{0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1305_0 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_1 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_2 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_3 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_4 [] = {86,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_5 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_6 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_7 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_9 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_10 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_11 [] = {924,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_12 [] = {912,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_13 [] = {921,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_14 [] = {909,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_15 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_18 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_19 [] = {927,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_20 [] = {972,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_21 [] = {915,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_22 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1305_23 [] = {930,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1305 [] = {
g_atype1305_0,
g_atype1305_1,
g_atype1305_2,
g_atype1305_3,
g_atype1305_4,
g_atype1305_5,
g_atype1305_6,
g_atype1305_7,
g_atype1305_8,
g_atype1305_9,
g_atype1305_10,
g_atype1305_11,
g_atype1305_12,
g_atype1305_13,
g_atype1305_14,
g_atype1305_15,
g_atype1305_16,
g_atype1305_17,
g_atype1305_18,
g_atype1305_19,
g_atype1305_20,
g_atype1305_21,
g_atype1305_22,
g_atype1305_23,
};

static const long offsets1305 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
+ @CHROFF(6,0),
+ @CHROFF(6,1),
+ @CHROFF(6,2),
+ @CHROFF(6,3),
+ @CHROFF(6,4),
+ @CHROFF(6,5),
+ @CHROFF(6,6),
+ @I16OFF(6,7,0),
+ @I16OFF(6,7,1),
+ @LNGOFF(6,7,2,0),
+ @LNGOFF(6,7,2,1),
+ @LNGOFF(6,7,2,2),
+ @LNGOFF(6,7,2,3),
+ @R32OFF(6,7,2,4,0),
+ @PTROFF(6,7,2,4,1,0),
+ @I64OFF(6,7,2,4,1,1,0),
+ @I64OFF(6,7,2,4,1,1,1),
+ @R64OFF(6,7,2,4,1,1,2,0),
};

extern const char *names1306[];
static const uint32 types1306 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags1306 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1306_0 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1306_3 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1306 [] = {
g_atype1306_0,
g_atype1306_1,
g_atype1306_2,
g_atype1306_3,
};

static const long offsets1306 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @PTROFF(1,1,0,1,0,0),
};

extern const char *names1307[];
static const uint32 types1307 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_POINTER,
};

static const uint16 attr_flags1307 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1307_0 [] = {319,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1307_3 [] = {972,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1307 [] = {
g_atype1307_0,
g_atype1307_1,
g_atype1307_2,
g_atype1307_3,
};

static const long offsets1307 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @PTROFF(1,1,0,1,0,0),
};

extern const char *names1309[];
static const uint32 types1309 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1309 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1309_0 [] = {0xFF01,750,918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1309_1 [] = {0xFF01,750,918,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1309 [] = {
g_atype1309_0,
g_atype1309_1,
};

static const long offsets1309 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1310[];
static const uint32 types1310 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1310 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1310_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1310_2 [] = {986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1310 [] = {
g_atype1310_0,
g_atype1310_1,
g_atype1310_2,
};

static const long offsets1310 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1311[];
static const uint32 types1311 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1311 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1311_0 [] = {340,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_1 [] = {340,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_2 [] = {340,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_3 [] = {837,0xFF01,0xFFF9,2,898,0xFF01,340,842,0xFF01,0xFFF9,2,898,0xFF01,342,0xFF01,342,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_9 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1311_10 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1311 [] = {
g_atype1311_0,
g_atype1311_1,
g_atype1311_2,
g_atype1311_3,
g_atype1311_4,
g_atype1311_5,
g_atype1311_6,
g_atype1311_7,
g_atype1311_8,
g_atype1311_9,
g_atype1311_10,
};

static const long offsets1311 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @CHROFF(4,1),
+ @CHROFF(4,2),
+ @CHROFF(4,3),
+ @CHROFF(4,4),
+ @LNGOFF(4,5,0,0),
+ @LNGOFF(4,5,0,1),
};

extern const char *names1317[];
static const uint32 types1317 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1317 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1317_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1317_1 [] = {1031,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1317 [] = {
g_atype1317_0,
g_atype1317_1,
};

static const long offsets1317 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1318[];
static const uint32 types1318 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1318 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1318_0 [] = {0xFF01,211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_2 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1318_5 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1318 [] = {
g_atype1318_0,
g_atype1318_1,
g_atype1318_2,
g_atype1318_3,
g_atype1318_4,
g_atype1318_5,
};

static const long offsets1318 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
};

extern const char *names1319[];
static const uint32 types1319 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1319 [] =
{0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1319_0 [] = {0xFF01,211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_2 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_3 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_4 [] = {0xFF01,1266,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_7 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_9 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1319_10 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1319 [] = {
g_atype1319_0,
g_atype1319_1,
g_atype1319_2,
g_atype1319_3,
g_atype1319_4,
g_atype1319_5,
g_atype1319_6,
g_atype1319_7,
g_atype1319_8,
g_atype1319_9,
g_atype1319_10,
};

static const long offsets1319 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @CHROFF(5,2),
+ @CHROFF(5,3),
+ @CHROFF(5,4),
+ @LNGOFF(5,5,0,0),
};

extern const char *names1320[];
static const uint32 types1320 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
};

static const uint16 attr_flags1320 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1320_0 [] = {0xFF01,211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1320_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1320_2 [] = {1031,0xFFFF};
static const EIF_TYPE_INDEX g_atype1320_3 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1320_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1320_5 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1320 [] = {
g_atype1320_0,
g_atype1320_1,
g_atype1320_2,
g_atype1320_3,
g_atype1320_4,
g_atype1320_5,
};

static const long offsets1320 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
};

extern const char *names1322[];
static const uint32 types1322 [] =
{
SK_REF,
};

static const uint16 attr_flags1322 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1322_0 [] = {0xFF01,211,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1322 [] = {
g_atype1322_0,
};

static const long offsets1322 [] =
{
0,
};

extern const char *names1324[];
static const uint32 types1324 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1324 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1324_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1324_1 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1324_2 [] = {0xFF01,1034,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1324 [] = {
g_atype1324_0,
g_atype1324_1,
g_atype1324_2,
};

static const long offsets1324 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1325[];
static const uint32 types1325 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1325 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1325_0 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1325_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1325_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1325_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1325 [] = {
g_atype1325_0,
g_atype1325_1,
g_atype1325_2,
g_atype1325_3,
};

static const long offsets1325 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1326[];
static const uint32 types1326 [] =
{
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1326 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1326_0 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1326_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1326_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1326_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1326 [] = {
g_atype1326_0,
g_atype1326_1,
g_atype1326_2,
g_atype1326_3,
};

static const long offsets1326 [] =
{
0,
+ @LNGOFF(1,0,0,0),
+ @LNGOFF(1,0,0,1),
+ @LNGOFF(1,0,0,2),
};

extern const char *names1328[];
static const uint32 types1328 [] =
{
SK_REF,
};

static const uint16 attr_flags1328 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1328_0 [] = {0xFF01,1335,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1328 [] = {
g_atype1328_0,
};

static const long offsets1328 [] =
{
0,
};

extern const char *names1329[];
static const uint32 types1329 [] =
{
SK_REF,
};

static const uint16 attr_flags1329 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1329_0 [] = {0xFF01,1335,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1329 [] = {
g_atype1329_0,
};

static const long offsets1329 [] =
{
0,
};

extern const char *names1330[];
static const uint32 types1330 [] =
{
SK_REF,
};

static const uint16 attr_flags1330 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1330_0 [] = {0xFF01,1335,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1330 [] = {
g_atype1330_0,
};

static const long offsets1330 [] =
{
0,
};

extern const char *names1331[];
static const uint32 types1331 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1331 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1331_0 [] = {0xFF01,1335,0xFFFF};
static const EIF_TYPE_INDEX g_atype1331_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1331_2 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1331 [] = {
g_atype1331_0,
g_atype1331_1,
g_atype1331_2,
};

static const long offsets1331 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1332[];
static const uint32 types1332 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1332 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1332_0 [] = {0xFF01,1335,0xFFFF};
static const EIF_TYPE_INDEX g_atype1332_1 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1332 [] = {
g_atype1332_0,
g_atype1332_1,
};

static const long offsets1332 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1333[];
static const uint32 types1333 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1333 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1333_0 [] = {0xFF01,1335,0xFFFF};
static const EIF_TYPE_INDEX g_atype1333_1 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1333 [] = {
g_atype1333_0,
g_atype1333_1,
};

static const long offsets1333 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1334[];
static const uint32 types1334 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1334 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1334_0 [] = {0xFF01,1335,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1334_2 [] = {0xFF01,1025,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1334 [] = {
g_atype1334_0,
g_atype1334_1,
g_atype1334_2,
};

static const long offsets1334 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1335[];
static const uint32 types1335 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1335 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1335_0 [] = {0xFF01,1335,0xFFFF};
static const EIF_TYPE_INDEX g_atype1335_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1335_2 [] = {0xFF01,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1335_3 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1335 [] = {
g_atype1335_0,
g_atype1335_1,
g_atype1335_2,
g_atype1335_3,
};

static const long offsets1335 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1336[];
static const uint32 types1336 [] =
{
SK_REF,
};

static const uint16 attr_flags1336 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1336_0 [] = {0xFF01,1248,0xFF01,1327,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1336 [] = {
g_atype1336_0,
};

static const long offsets1336 [] =
{
0,
};

extern const char *names1337[];
static const uint32 types1337 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1337 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1337_0 [] = {0xFF01,1335,0xFFFF};
static const EIF_TYPE_INDEX g_atype1337_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1337_2 [] = {0xFF01,1025,0xFFFF};
static const EIF_TYPE_INDEX g_atype1337_3 [] = {0xFF01,1248,0xFF01,1329,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1337 [] = {
g_atype1337_0,
g_atype1337_1,
g_atype1337_2,
g_atype1337_3,
};

static const long offsets1337 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1338[];
static const uint32 types1338 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1338 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1338_0 [] = {0xFF01,1248,0xFF01,1328,0xFFFF};
static const EIF_TYPE_INDEX g_atype1338_1 [] = {0xFF01,1336,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1338 [] = {
g_atype1338_0,
g_atype1338_1,
};

static const long offsets1338 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1340[];
static const uint32 types1340 [] =
{
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1340 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1340_0 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1340_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1340_2 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1340 [] = {
g_atype1340_0,
g_atype1340_1,
g_atype1340_2,
};

static const long offsets1340 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
+ @LNGOFF(0,0,0,2),
};

extern const char *names1341[];
static const uint32 types1341 [] =
{
SK_INT32,
};

static const uint16 attr_flags1341 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1341_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1341 [] = {
g_atype1341_0,
};

static const long offsets1341 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1343[];
static const uint32 types1343 [] =
{
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1343 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1343_0 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1343_3 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1343 [] = {
g_atype1343_0,
g_atype1343_1,
g_atype1343_2,
g_atype1343_3,
};

static const long offsets1343 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
+ @LNGOFF(0,0,0,2),
+ @LNGOFF(0,0,0,3),
};

extern const char *names1344[];
static const uint32 types1344 [] =
{
SK_INT32,
};

static const uint16 attr_flags1344 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1344_0 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1344 [] = {
g_atype1344_0,
};

static const long offsets1344 [] =
{
+ @LNGOFF(0,0,0,0),
};

extern const char *names1346[];
static const uint32 types1346 [] =
{
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1346 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1346_0 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1346_1 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1346_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1346_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1346_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1346_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1346_6 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1346 [] = {
g_atype1346_0,
g_atype1346_1,
g_atype1346_2,
g_atype1346_3,
g_atype1346_4,
g_atype1346_5,
g_atype1346_6,
};

static const long offsets1346 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
+ @LNGOFF(0,0,0,2),
+ @LNGOFF(0,0,0,3),
+ @LNGOFF(0,0,0,4),
+ @LNGOFF(0,0,0,5),
+ @LNGOFF(0,0,0,6),
};

extern const char *names1347[];
static const uint32 types1347 [] =
{
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1347 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1347_0 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1347_1 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1347 [] = {
g_atype1347_0,
g_atype1347_1,
};

static const long offsets1347 [] =
{
+ @LNGOFF(0,0,0,0),
+ @LNGOFF(0,0,0,1),
};

extern const char *names1348[];
static const uint32 types1348 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1348 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1348_0 [] = {0xFF01,1260,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1348_1 [] = {0xFF01,1249,0xFF01,1286,0xFF01,986,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1348_2 [] = {0xFF01,1275,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1348_3 [] = {986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1348 [] = {
g_atype1348_0,
g_atype1348_1,
g_atype1348_2,
g_atype1348_3,
};

static const long offsets1348 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1349[];
static const uint32 types1349 [] =
{
SK_REF,
};

static const uint16 attr_flags1349 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1349_0 [] = {0xFF01,1249,0xFF01,1286,0xFF01,986,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1349 [] = {
g_atype1349_0,
};

static const long offsets1349 [] =
{
0,
};

extern const char *names1350[];
static const uint32 types1350 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1350 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1350_0 [] = {1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_1 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_2 [] = {0xFF01,1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_3 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_4 [] = {0xFF01,1044,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_5 [] = {0xFF01,1041,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_6 [] = {0xFF01,1044,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_7 [] = {0xFF01,1275,0xFF01,1039,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_8 [] = {0xFF01,1286,0xFF01,1057,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_9 [] = {0xFF01,1286,0xFF01,1059,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_10 [] = {0xFF01,1286,0xFF01,1058,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_11 [] = {0xFF01,1286,0xFF01,1041,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_12 [] = {0xFF01,1286,0xFF01,1046,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1350_13 [] = {0xFF01,1286,0xFF01,1055,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1350 [] = {
g_atype1350_0,
g_atype1350_1,
g_atype1350_2,
g_atype1350_3,
g_atype1350_4,
g_atype1350_5,
g_atype1350_6,
g_atype1350_7,
g_atype1350_8,
g_atype1350_9,
g_atype1350_10,
g_atype1350_11,
g_atype1350_12,
g_atype1350_13,
};

static const long offsets1350 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
};

extern const char *names1352[];
static const uint32 types1352 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags1352 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1352_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_2 [] = {1244,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_3 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_4 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1352_5 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1352 [] = {
g_atype1352_0,
g_atype1352_1,
g_atype1352_2,
g_atype1352_3,
g_atype1352_4,
g_atype1352_5,
};

static const long offsets1352 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
+ @CHROFF(3,0),
+ @CHROFF(3,1),
+ @CHROFF(3,2),
};

extern const char *names1354[];
static const uint32 types1354 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1354 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1354_0 [] = {5,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_1 [] = {5,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1354_8 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1354 [] = {
g_atype1354_0,
g_atype1354_1,
g_atype1354_2,
g_atype1354_3,
g_atype1354_4,
g_atype1354_5,
g_atype1354_6,
g_atype1354_7,
g_atype1354_8,
};

static const long offsets1354 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
};

extern const char *names1355[];
static const uint32 types1355 [] =
{
SK_REF,
SK_REF,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1355 [] =
{0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1355_0 [] = {5,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_1 [] = {5,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1355_8 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1355 [] = {
g_atype1355_0,
g_atype1355_1,
g_atype1355_2,
g_atype1355_3,
g_atype1355_4,
g_atype1355_5,
g_atype1355_6,
g_atype1355_7,
g_atype1355_8,
};

static const long offsets1355 [] =
{
0,
 + @REFACS(1),
+ @LNGOFF(2,0,0,0),
+ @LNGOFF(2,0,0,1),
+ @LNGOFF(2,0,0,2),
+ @LNGOFF(2,0,0,3),
+ @LNGOFF(2,0,0,4),
+ @LNGOFF(2,0,0,5),
+ @LNGOFF(2,0,0,6),
};

extern const char *names1357[];
static const uint32 types1357 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1357 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1357_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1357_1 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1357 [] = {
g_atype1357_0,
g_atype1357_1,
};

static const long offsets1357 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1358[];
static const uint32 types1358 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1358 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1358_0 [] = {0xFF01,199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_1 [] = {0xFF01,97,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_2 [] = {752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_3 [] = {751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_5 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_8 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_9 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_10 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_11 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_12 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_13 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_15 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_16 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_17 [] = {0xFF01,1261,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_18 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_19 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_20 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_21 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_22 [] = {933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_23 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_24 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_25 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_26 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_27 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_28 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_29 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_30 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_31 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_32 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_33 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_34 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_35 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_36 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_37 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_38 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_39 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_40 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_41 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_42 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_43 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_44 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_45 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1358_46 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1358 [] = {
g_atype1358_0,
g_atype1358_1,
g_atype1358_2,
g_atype1358_3,
g_atype1358_4,
g_atype1358_5,
g_atype1358_6,
g_atype1358_7,
g_atype1358_8,
g_atype1358_9,
g_atype1358_10,
g_atype1358_11,
g_atype1358_12,
g_atype1358_13,
g_atype1358_14,
g_atype1358_15,
g_atype1358_16,
g_atype1358_17,
g_atype1358_18,
g_atype1358_19,
g_atype1358_20,
g_atype1358_21,
g_atype1358_22,
g_atype1358_23,
g_atype1358_24,
g_atype1358_25,
g_atype1358_26,
g_atype1358_27,
g_atype1358_28,
g_atype1358_29,
g_atype1358_30,
g_atype1358_31,
g_atype1358_32,
g_atype1358_33,
g_atype1358_34,
g_atype1358_35,
g_atype1358_36,
g_atype1358_37,
g_atype1358_38,
g_atype1358_39,
g_atype1358_40,
g_atype1358_41,
g_atype1358_42,
g_atype1358_43,
g_atype1358_44,
g_atype1358_45,
g_atype1358_46,
};

static const long offsets1358 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
+ @CHROFF(18,0),
+ @CHROFF(18,1),
+ @CHROFF(18,2),
+ @CHROFF(18,3),
+ @LNGOFF(18,4,0,0),
+ @LNGOFF(18,4,0,1),
+ @LNGOFF(18,4,0,2),
+ @LNGOFF(18,4,0,3),
+ @LNGOFF(18,4,0,4),
+ @LNGOFF(18,4,0,5),
+ @LNGOFF(18,4,0,6),
+ @LNGOFF(18,4,0,7),
+ @LNGOFF(18,4,0,8),
+ @LNGOFF(18,4,0,9),
+ @LNGOFF(18,4,0,10),
+ @LNGOFF(18,4,0,11),
+ @LNGOFF(18,4,0,12),
+ @LNGOFF(18,4,0,13),
+ @LNGOFF(18,4,0,14),
+ @LNGOFF(18,4,0,15),
+ @LNGOFF(18,4,0,16),
+ @LNGOFF(18,4,0,17),
+ @LNGOFF(18,4,0,18),
+ @LNGOFF(18,4,0,19),
+ @LNGOFF(18,4,0,20),
+ @LNGOFF(18,4,0,21),
+ @LNGOFF(18,4,0,22),
+ @LNGOFF(18,4,0,23),
+ @LNGOFF(18,4,0,24),
};

extern const char *names1359[];
static const uint32 types1359 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1359 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1359_0 [] = {0xFF01,199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_1 [] = {0xFF01,97,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_2 [] = {752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_3 [] = {751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_5 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_8 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_9 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_10 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_11 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_12 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_13 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_15 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_16 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_17 [] = {0xFF01,1261,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_18 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_19 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_20 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_21 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_22 [] = {933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_23 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_24 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_25 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_26 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_27 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_28 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_29 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_30 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_31 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_32 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_33 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_34 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_35 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_36 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_37 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_38 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_39 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_40 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_41 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_42 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_43 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_44 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_45 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1359_46 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1359 [] = {
g_atype1359_0,
g_atype1359_1,
g_atype1359_2,
g_atype1359_3,
g_atype1359_4,
g_atype1359_5,
g_atype1359_6,
g_atype1359_7,
g_atype1359_8,
g_atype1359_9,
g_atype1359_10,
g_atype1359_11,
g_atype1359_12,
g_atype1359_13,
g_atype1359_14,
g_atype1359_15,
g_atype1359_16,
g_atype1359_17,
g_atype1359_18,
g_atype1359_19,
g_atype1359_20,
g_atype1359_21,
g_atype1359_22,
g_atype1359_23,
g_atype1359_24,
g_atype1359_25,
g_atype1359_26,
g_atype1359_27,
g_atype1359_28,
g_atype1359_29,
g_atype1359_30,
g_atype1359_31,
g_atype1359_32,
g_atype1359_33,
g_atype1359_34,
g_atype1359_35,
g_atype1359_36,
g_atype1359_37,
g_atype1359_38,
g_atype1359_39,
g_atype1359_40,
g_atype1359_41,
g_atype1359_42,
g_atype1359_43,
g_atype1359_44,
g_atype1359_45,
g_atype1359_46,
};

static const long offsets1359 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
+ @CHROFF(18,0),
+ @CHROFF(18,1),
+ @CHROFF(18,2),
+ @CHROFF(18,3),
+ @LNGOFF(18,4,0,0),
+ @LNGOFF(18,4,0,1),
+ @LNGOFF(18,4,0,2),
+ @LNGOFF(18,4,0,3),
+ @LNGOFF(18,4,0,4),
+ @LNGOFF(18,4,0,5),
+ @LNGOFF(18,4,0,6),
+ @LNGOFF(18,4,0,7),
+ @LNGOFF(18,4,0,8),
+ @LNGOFF(18,4,0,9),
+ @LNGOFF(18,4,0,10),
+ @LNGOFF(18,4,0,11),
+ @LNGOFF(18,4,0,12),
+ @LNGOFF(18,4,0,13),
+ @LNGOFF(18,4,0,14),
+ @LNGOFF(18,4,0,15),
+ @LNGOFF(18,4,0,16),
+ @LNGOFF(18,4,0,17),
+ @LNGOFF(18,4,0,18),
+ @LNGOFF(18,4,0,19),
+ @LNGOFF(18,4,0,20),
+ @LNGOFF(18,4,0,21),
+ @LNGOFF(18,4,0,22),
+ @LNGOFF(18,4,0,23),
+ @LNGOFF(18,4,0,24),
};

extern const char *names1360[];
static const uint32 types1360 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1360 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1360_0 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1360_1 [] = {0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1360 [] = {
g_atype1360_0,
g_atype1360_1,
};

static const long offsets1360 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1361[];
static const uint32 types1361 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1361 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1361_0 [] = {0xFF01,199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_1 [] = {0xFF01,97,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_2 [] = {752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_3 [] = {751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_5 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_8 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_9 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_10 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_11 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_12 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_13 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_15 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_16 [] = {1000,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_17 [] = {104,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_18 [] = {1017,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_19 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_20 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_21 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_22 [] = {0xFF01,1008,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_23 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_24 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_25 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_26 [] = {933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_27 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_28 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_29 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_30 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_31 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_32 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_33 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_34 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_35 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_36 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_37 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_38 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_39 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_40 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_41 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_42 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_43 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_44 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_45 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1361_46 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1361 [] = {
g_atype1361_0,
g_atype1361_1,
g_atype1361_2,
g_atype1361_3,
g_atype1361_4,
g_atype1361_5,
g_atype1361_6,
g_atype1361_7,
g_atype1361_8,
g_atype1361_9,
g_atype1361_10,
g_atype1361_11,
g_atype1361_12,
g_atype1361_13,
g_atype1361_14,
g_atype1361_15,
g_atype1361_16,
g_atype1361_17,
g_atype1361_18,
g_atype1361_19,
g_atype1361_20,
g_atype1361_21,
g_atype1361_22,
g_atype1361_23,
g_atype1361_24,
g_atype1361_25,
g_atype1361_26,
g_atype1361_27,
g_atype1361_28,
g_atype1361_29,
g_atype1361_30,
g_atype1361_31,
g_atype1361_32,
g_atype1361_33,
g_atype1361_34,
g_atype1361_35,
g_atype1361_36,
g_atype1361_37,
g_atype1361_38,
g_atype1361_39,
g_atype1361_40,
g_atype1361_41,
g_atype1361_42,
g_atype1361_43,
g_atype1361_44,
g_atype1361_45,
g_atype1361_46,
};

static const long offsets1361 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
+ @CHROFF(23,0),
+ @CHROFF(23,1),
+ @CHROFF(23,2),
+ @LNGOFF(23,3,0,0),
+ @LNGOFF(23,3,0,1),
+ @LNGOFF(23,3,0,2),
+ @LNGOFF(23,3,0,3),
+ @LNGOFF(23,3,0,4),
+ @LNGOFF(23,3,0,5),
+ @LNGOFF(23,3,0,6),
+ @LNGOFF(23,3,0,7),
+ @LNGOFF(23,3,0,8),
+ @LNGOFF(23,3,0,9),
+ @LNGOFF(23,3,0,10),
+ @LNGOFF(23,3,0,11),
+ @LNGOFF(23,3,0,12),
+ @LNGOFF(23,3,0,13),
+ @LNGOFF(23,3,0,14),
+ @LNGOFF(23,3,0,15),
+ @LNGOFF(23,3,0,16),
+ @LNGOFF(23,3,0,17),
+ @LNGOFF(23,3,0,18),
+ @LNGOFF(23,3,0,19),
+ @LNGOFF(23,3,0,20),
};

extern const char *names1362[];
static const uint32 types1362 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1362 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1362_0 [] = {0xFF01,199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_1 [] = {0xFF01,97,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_2 [] = {752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_3 [] = {751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_5 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_8 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_9 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_10 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_11 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_12 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_13 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_15 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_16 [] = {1000,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_17 [] = {104,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_18 [] = {1017,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_19 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_20 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_21 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_22 [] = {0xFF01,1008,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_23 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_24 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_25 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_26 [] = {933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_27 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_28 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_29 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_30 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_31 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_32 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_33 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_34 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_35 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_36 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_37 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_38 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_39 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_40 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_41 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_42 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_43 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_44 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_45 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1362_46 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1362 [] = {
g_atype1362_0,
g_atype1362_1,
g_atype1362_2,
g_atype1362_3,
g_atype1362_4,
g_atype1362_5,
g_atype1362_6,
g_atype1362_7,
g_atype1362_8,
g_atype1362_9,
g_atype1362_10,
g_atype1362_11,
g_atype1362_12,
g_atype1362_13,
g_atype1362_14,
g_atype1362_15,
g_atype1362_16,
g_atype1362_17,
g_atype1362_18,
g_atype1362_19,
g_atype1362_20,
g_atype1362_21,
g_atype1362_22,
g_atype1362_23,
g_atype1362_24,
g_atype1362_25,
g_atype1362_26,
g_atype1362_27,
g_atype1362_28,
g_atype1362_29,
g_atype1362_30,
g_atype1362_31,
g_atype1362_32,
g_atype1362_33,
g_atype1362_34,
g_atype1362_35,
g_atype1362_36,
g_atype1362_37,
g_atype1362_38,
g_atype1362_39,
g_atype1362_40,
g_atype1362_41,
g_atype1362_42,
g_atype1362_43,
g_atype1362_44,
g_atype1362_45,
g_atype1362_46,
};

static const long offsets1362 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
+ @CHROFF(23,0),
+ @CHROFF(23,1),
+ @CHROFF(23,2),
+ @LNGOFF(23,3,0,0),
+ @LNGOFF(23,3,0,1),
+ @LNGOFF(23,3,0,2),
+ @LNGOFF(23,3,0,3),
+ @LNGOFF(23,3,0,4),
+ @LNGOFF(23,3,0,5),
+ @LNGOFF(23,3,0,6),
+ @LNGOFF(23,3,0,7),
+ @LNGOFF(23,3,0,8),
+ @LNGOFF(23,3,0,9),
+ @LNGOFF(23,3,0,10),
+ @LNGOFF(23,3,0,11),
+ @LNGOFF(23,3,0,12),
+ @LNGOFF(23,3,0,13),
+ @LNGOFF(23,3,0,14),
+ @LNGOFF(23,3,0,15),
+ @LNGOFF(23,3,0,16),
+ @LNGOFF(23,3,0,17),
+ @LNGOFF(23,3,0,18),
+ @LNGOFF(23,3,0,19),
+ @LNGOFF(23,3,0,20),
};

extern const char *names1363[];
static const uint32 types1363 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1363 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1363_0 [] = {0xFF01,199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_1 [] = {0xFF01,97,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_2 [] = {752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_3 [] = {751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_5 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_8 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_9 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_10 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_11 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_12 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_13 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_15 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_16 [] = {1000,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_17 [] = {104,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_18 [] = {1017,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_19 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_20 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_21 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_22 [] = {0xFF01,1008,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_23 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_24 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_25 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_26 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_27 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_28 [] = {933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_29 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_30 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_31 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_32 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_33 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_34 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_35 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_36 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_37 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_38 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_39 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_40 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_41 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_42 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_43 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_44 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_45 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_46 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_47 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1363_48 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1363 [] = {
g_atype1363_0,
g_atype1363_1,
g_atype1363_2,
g_atype1363_3,
g_atype1363_4,
g_atype1363_5,
g_atype1363_6,
g_atype1363_7,
g_atype1363_8,
g_atype1363_9,
g_atype1363_10,
g_atype1363_11,
g_atype1363_12,
g_atype1363_13,
g_atype1363_14,
g_atype1363_15,
g_atype1363_16,
g_atype1363_17,
g_atype1363_18,
g_atype1363_19,
g_atype1363_20,
g_atype1363_21,
g_atype1363_22,
g_atype1363_23,
g_atype1363_24,
g_atype1363_25,
g_atype1363_26,
g_atype1363_27,
g_atype1363_28,
g_atype1363_29,
g_atype1363_30,
g_atype1363_31,
g_atype1363_32,
g_atype1363_33,
g_atype1363_34,
g_atype1363_35,
g_atype1363_36,
g_atype1363_37,
g_atype1363_38,
g_atype1363_39,
g_atype1363_40,
g_atype1363_41,
g_atype1363_42,
g_atype1363_43,
g_atype1363_44,
g_atype1363_45,
g_atype1363_46,
g_atype1363_47,
g_atype1363_48,
};

static const long offsets1363 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
+ @CHROFF(23,0),
+ @CHROFF(23,1),
+ @CHROFF(23,2),
+ @CHROFF(23,3),
+ @CHROFF(23,4),
+ @LNGOFF(23,5,0,0),
+ @LNGOFF(23,5,0,1),
+ @LNGOFF(23,5,0,2),
+ @LNGOFF(23,5,0,3),
+ @LNGOFF(23,5,0,4),
+ @LNGOFF(23,5,0,5),
+ @LNGOFF(23,5,0,6),
+ @LNGOFF(23,5,0,7),
+ @LNGOFF(23,5,0,8),
+ @LNGOFF(23,5,0,9),
+ @LNGOFF(23,5,0,10),
+ @LNGOFF(23,5,0,11),
+ @LNGOFF(23,5,0,12),
+ @LNGOFF(23,5,0,13),
+ @LNGOFF(23,5,0,14),
+ @LNGOFF(23,5,0,15),
+ @LNGOFF(23,5,0,16),
+ @LNGOFF(23,5,0,17),
+ @LNGOFF(23,5,0,18),
+ @LNGOFF(23,5,0,19),
+ @LNGOFF(23,5,0,20),
};

extern const char *names1364[];
static const uint32 types1364 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1364 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1364_0 [] = {0xFF01,199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_1 [] = {0xFF01,97,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_2 [] = {752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_3 [] = {751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_5 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_8 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_9 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_10 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_11 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_12 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_13 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_15 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_16 [] = {1000,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_17 [] = {104,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_18 [] = {1017,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_19 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_20 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_21 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_22 [] = {0xFF01,1008,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_23 [] = {0xFF01,104,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_24 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_25 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_26 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_27 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_28 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_29 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_30 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_31 [] = {933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_32 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_33 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_34 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_35 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_36 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_37 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_38 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_39 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_40 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_41 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_42 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_43 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_44 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_45 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_46 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_47 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_48 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_49 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_50 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1364_51 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1364 [] = {
g_atype1364_0,
g_atype1364_1,
g_atype1364_2,
g_atype1364_3,
g_atype1364_4,
g_atype1364_5,
g_atype1364_6,
g_atype1364_7,
g_atype1364_8,
g_atype1364_9,
g_atype1364_10,
g_atype1364_11,
g_atype1364_12,
g_atype1364_13,
g_atype1364_14,
g_atype1364_15,
g_atype1364_16,
g_atype1364_17,
g_atype1364_18,
g_atype1364_19,
g_atype1364_20,
g_atype1364_21,
g_atype1364_22,
g_atype1364_23,
g_atype1364_24,
g_atype1364_25,
g_atype1364_26,
g_atype1364_27,
g_atype1364_28,
g_atype1364_29,
g_atype1364_30,
g_atype1364_31,
g_atype1364_32,
g_atype1364_33,
g_atype1364_34,
g_atype1364_35,
g_atype1364_36,
g_atype1364_37,
g_atype1364_38,
g_atype1364_39,
g_atype1364_40,
g_atype1364_41,
g_atype1364_42,
g_atype1364_43,
g_atype1364_44,
g_atype1364_45,
g_atype1364_46,
g_atype1364_47,
g_atype1364_48,
g_atype1364_49,
g_atype1364_50,
g_atype1364_51,
};

static const long offsets1364 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
+ @CHROFF(27,0),
+ @CHROFF(27,1),
+ @CHROFF(27,2),
+ @CHROFF(27,3),
+ @LNGOFF(27,4,0,0),
+ @LNGOFF(27,4,0,1),
+ @LNGOFF(27,4,0,2),
+ @LNGOFF(27,4,0,3),
+ @LNGOFF(27,4,0,4),
+ @LNGOFF(27,4,0,5),
+ @LNGOFF(27,4,0,6),
+ @LNGOFF(27,4,0,7),
+ @LNGOFF(27,4,0,8),
+ @LNGOFF(27,4,0,9),
+ @LNGOFF(27,4,0,10),
+ @LNGOFF(27,4,0,11),
+ @LNGOFF(27,4,0,12),
+ @LNGOFF(27,4,0,13),
+ @LNGOFF(27,4,0,14),
+ @LNGOFF(27,4,0,15),
+ @LNGOFF(27,4,0,16),
+ @LNGOFF(27,4,0,17),
+ @LNGOFF(27,4,0,18),
+ @LNGOFF(27,4,0,19),
+ @LNGOFF(27,4,0,20),
};

extern const char *names1365[];
static const uint32 types1365 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1365 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1365_0 [] = {0xFF01,199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_1 [] = {0xFF01,97,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_2 [] = {752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_3 [] = {751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_5 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_8 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_9 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_10 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_11 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_12 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_13 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_15 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_16 [] = {1000,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_17 [] = {104,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_18 [] = {1017,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_19 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_20 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_21 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_22 [] = {0xFF01,1008,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_23 [] = {0xFF01,104,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_24 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_25 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_26 [] = {1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_27 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_28 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_29 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_30 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_31 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_32 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_33 [] = {933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_34 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_35 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_36 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_37 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_38 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_39 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_40 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_41 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_42 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_43 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_44 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_45 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_46 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_47 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_48 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_49 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_50 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_51 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_52 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1365_53 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1365 [] = {
g_atype1365_0,
g_atype1365_1,
g_atype1365_2,
g_atype1365_3,
g_atype1365_4,
g_atype1365_5,
g_atype1365_6,
g_atype1365_7,
g_atype1365_8,
g_atype1365_9,
g_atype1365_10,
g_atype1365_11,
g_atype1365_12,
g_atype1365_13,
g_atype1365_14,
g_atype1365_15,
g_atype1365_16,
g_atype1365_17,
g_atype1365_18,
g_atype1365_19,
g_atype1365_20,
g_atype1365_21,
g_atype1365_22,
g_atype1365_23,
g_atype1365_24,
g_atype1365_25,
g_atype1365_26,
g_atype1365_27,
g_atype1365_28,
g_atype1365_29,
g_atype1365_30,
g_atype1365_31,
g_atype1365_32,
g_atype1365_33,
g_atype1365_34,
g_atype1365_35,
g_atype1365_36,
g_atype1365_37,
g_atype1365_38,
g_atype1365_39,
g_atype1365_40,
g_atype1365_41,
g_atype1365_42,
g_atype1365_43,
g_atype1365_44,
g_atype1365_45,
g_atype1365_46,
g_atype1365_47,
g_atype1365_48,
g_atype1365_49,
g_atype1365_50,
g_atype1365_51,
g_atype1365_52,
g_atype1365_53,
};

static const long offsets1365 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
+ @CHROFF(27,0),
+ @CHROFF(27,1),
+ @CHROFF(27,2),
+ @CHROFF(27,3),
+ @CHROFF(27,4),
+ @CHROFF(27,5),
+ @LNGOFF(27,6,0,0),
+ @LNGOFF(27,6,0,1),
+ @LNGOFF(27,6,0,2),
+ @LNGOFF(27,6,0,3),
+ @LNGOFF(27,6,0,4),
+ @LNGOFF(27,6,0,5),
+ @LNGOFF(27,6,0,6),
+ @LNGOFF(27,6,0,7),
+ @LNGOFF(27,6,0,8),
+ @LNGOFF(27,6,0,9),
+ @LNGOFF(27,6,0,10),
+ @LNGOFF(27,6,0,11),
+ @LNGOFF(27,6,0,12),
+ @LNGOFF(27,6,0,13),
+ @LNGOFF(27,6,0,14),
+ @LNGOFF(27,6,0,15),
+ @LNGOFF(27,6,0,16),
+ @LNGOFF(27,6,0,17),
+ @LNGOFF(27,6,0,18),
+ @LNGOFF(27,6,0,19),
+ @LNGOFF(27,6,0,20),
};

extern const char *names1366[];
static const uint32 types1366 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1366 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1366_0 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_1 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_2 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_3 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_5 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_8 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_9 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_10 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_11 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_12 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_18 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_19 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_20 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_21 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1366_22 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1366 [] = {
g_atype1366_0,
g_atype1366_1,
g_atype1366_2,
g_atype1366_3,
g_atype1366_4,
g_atype1366_5,
g_atype1366_6,
g_atype1366_7,
g_atype1366_8,
g_atype1366_9,
g_atype1366_10,
g_atype1366_11,
g_atype1366_12,
g_atype1366_13,
g_atype1366_14,
g_atype1366_15,
g_atype1366_16,
g_atype1366_17,
g_atype1366_18,
g_atype1366_19,
g_atype1366_20,
g_atype1366_21,
g_atype1366_22,
};

static const long offsets1366 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
+ @CHROFF(11,0),
+ @LNGOFF(11,1,0,0),
+ @LNGOFF(11,1,0,1),
+ @LNGOFF(11,1,0,2),
+ @LNGOFF(11,1,0,3),
+ @LNGOFF(11,1,0,4),
+ @LNGOFF(11,1,0,5),
+ @LNGOFF(11,1,0,6),
+ @LNGOFF(11,1,0,7),
+ @LNGOFF(11,1,0,8),
+ @LNGOFF(11,1,0,9),
+ @LNGOFF(11,1,0,10),
};

extern const char *names1367[];
static const uint32 types1367 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1367 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1367_0 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_1 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_2 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_3 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_5 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_8 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_9 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_10 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_11 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_12 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_13 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_14 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_15 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_16 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_17 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_18 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_19 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_20 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_21 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_22 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1367_23 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1367 [] = {
g_atype1367_0,
g_atype1367_1,
g_atype1367_2,
g_atype1367_3,
g_atype1367_4,
g_atype1367_5,
g_atype1367_6,
g_atype1367_7,
g_atype1367_8,
g_atype1367_9,
g_atype1367_10,
g_atype1367_11,
g_atype1367_12,
g_atype1367_13,
g_atype1367_14,
g_atype1367_15,
g_atype1367_16,
g_atype1367_17,
g_atype1367_18,
g_atype1367_19,
g_atype1367_20,
g_atype1367_21,
g_atype1367_22,
g_atype1367_23,
};

static const long offsets1367 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @CHROFF(12,0),
+ @LNGOFF(12,1,0,0),
+ @LNGOFF(12,1,0,1),
+ @LNGOFF(12,1,0,2),
+ @LNGOFF(12,1,0,3),
+ @LNGOFF(12,1,0,4),
+ @LNGOFF(12,1,0,5),
+ @LNGOFF(12,1,0,6),
+ @LNGOFF(12,1,0,7),
+ @LNGOFF(12,1,0,8),
+ @LNGOFF(12,1,0,9),
+ @LNGOFF(12,1,0,10),
};

extern const char *names1368[];
static const uint32 types1368 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1368 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1368_0 [] = {0xFF01,199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_1 [] = {0xFF01,97,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_2 [] = {752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_3 [] = {751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_5 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_8 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_9 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_10 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_11 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_12 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_13 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_15 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_16 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_17 [] = {0xFF01,1261,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_18 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_19 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_20 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_21 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_22 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_23 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_24 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_25 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_26 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_27 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_28 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_29 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_30 [] = {0xFF01,1275,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_31 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_32 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_33 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_34 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_35 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_36 [] = {933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_37 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_38 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_39 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_40 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_41 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_42 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_43 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_44 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_45 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_46 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_47 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_48 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_49 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_50 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_51 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_52 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_53 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_54 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_55 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_56 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_57 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_58 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_59 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_60 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_61 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_62 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_63 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_64 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_65 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_66 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_67 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_68 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_69 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_70 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1368_71 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1368 [] = {
g_atype1368_0,
g_atype1368_1,
g_atype1368_2,
g_atype1368_3,
g_atype1368_4,
g_atype1368_5,
g_atype1368_6,
g_atype1368_7,
g_atype1368_8,
g_atype1368_9,
g_atype1368_10,
g_atype1368_11,
g_atype1368_12,
g_atype1368_13,
g_atype1368_14,
g_atype1368_15,
g_atype1368_16,
g_atype1368_17,
g_atype1368_18,
g_atype1368_19,
g_atype1368_20,
g_atype1368_21,
g_atype1368_22,
g_atype1368_23,
g_atype1368_24,
g_atype1368_25,
g_atype1368_26,
g_atype1368_27,
g_atype1368_28,
g_atype1368_29,
g_atype1368_30,
g_atype1368_31,
g_atype1368_32,
g_atype1368_33,
g_atype1368_34,
g_atype1368_35,
g_atype1368_36,
g_atype1368_37,
g_atype1368_38,
g_atype1368_39,
g_atype1368_40,
g_atype1368_41,
g_atype1368_42,
g_atype1368_43,
g_atype1368_44,
g_atype1368_45,
g_atype1368_46,
g_atype1368_47,
g_atype1368_48,
g_atype1368_49,
g_atype1368_50,
g_atype1368_51,
g_atype1368_52,
g_atype1368_53,
g_atype1368_54,
g_atype1368_55,
g_atype1368_56,
g_atype1368_57,
g_atype1368_58,
g_atype1368_59,
g_atype1368_60,
g_atype1368_61,
g_atype1368_62,
g_atype1368_63,
g_atype1368_64,
g_atype1368_65,
g_atype1368_66,
g_atype1368_67,
g_atype1368_68,
g_atype1368_69,
g_atype1368_70,
g_atype1368_71,
};

static const long offsets1368 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
+ @CHROFF(31,0),
+ @CHROFF(31,1),
+ @CHROFF(31,2),
+ @CHROFF(31,3),
+ @CHROFF(31,4),
+ @LNGOFF(31,5,0,0),
+ @LNGOFF(31,5,0,1),
+ @LNGOFF(31,5,0,2),
+ @LNGOFF(31,5,0,3),
+ @LNGOFF(31,5,0,4),
+ @LNGOFF(31,5,0,5),
+ @LNGOFF(31,5,0,6),
+ @LNGOFF(31,5,0,7),
+ @LNGOFF(31,5,0,8),
+ @LNGOFF(31,5,0,9),
+ @LNGOFF(31,5,0,10),
+ @LNGOFF(31,5,0,11),
+ @LNGOFF(31,5,0,12),
+ @LNGOFF(31,5,0,13),
+ @LNGOFF(31,5,0,14),
+ @LNGOFF(31,5,0,15),
+ @LNGOFF(31,5,0,16),
+ @LNGOFF(31,5,0,17),
+ @LNGOFF(31,5,0,18),
+ @LNGOFF(31,5,0,19),
+ @LNGOFF(31,5,0,20),
+ @LNGOFF(31,5,0,21),
+ @LNGOFF(31,5,0,22),
+ @LNGOFF(31,5,0,23),
+ @LNGOFF(31,5,0,24),
+ @LNGOFF(31,5,0,25),
+ @LNGOFF(31,5,0,26),
+ @LNGOFF(31,5,0,27),
+ @LNGOFF(31,5,0,28),
+ @LNGOFF(31,5,0,29),
+ @LNGOFF(31,5,0,30),
+ @LNGOFF(31,5,0,31),
+ @LNGOFF(31,5,0,32),
+ @LNGOFF(31,5,0,33),
+ @LNGOFF(31,5,0,34),
+ @LNGOFF(31,5,0,35),
};

extern const char *names1369[];
static const uint32 types1369 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_CHAR8,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_CHAR32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1369 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1369_0 [] = {0xFF01,199,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_1 [] = {0xFF01,97,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_2 [] = {752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_3 [] = {751,933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_4 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_5 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_8 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_9 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_10 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_11 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_12 [] = {747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_13 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_14 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_15 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_16 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_17 [] = {0xFF01,1261,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_18 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_19 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_20 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_21 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_22 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_23 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_24 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_25 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_26 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_27 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_28 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_29 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_30 [] = {0xFF01,1275,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_31 [] = {0xFF01,746,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_32 [] = {0xFF01,28,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_33 [] = {0xFF01,746,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_34 [] = {0xFF01,28,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_35 [] = {0xFF01,746,0xFF01,27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_36 [] = {0xFF01,28,0xFF01,27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_37 [] = {0xFF01,746,0xFF01,1246,0xFF01,1075,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_38 [] = {0xFF01,28,0xFF01,1246,0xFF01,1075,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_39 [] = {0xFF01,746,0xFF01,1075,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_40 [] = {0xFF01,28,0xFF01,1075,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_41 [] = {0xFF01,746,0xFF01,1026,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_42 [] = {0xFF01,28,0xFF01,1026,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_43 [] = {0xFF01,746,0xFF01,1246,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_44 [] = {0xFF01,28,0xFF01,1246,0xFF01,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_45 [] = {0xFF01,746,0xFF01,1246,0xFF01,1076,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_46 [] = {0xFF01,28,0xFF01,1246,0xFF01,1076,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_47 [] = {0xFF01,746,0xFF01,1076,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_48 [] = {0xFF01,28,0xFF01,1076,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_49 [] = {0xFF01,746,0xFF01,1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_50 [] = {0xFF01,28,0xFF01,1074,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_51 [] = {0xFF01,746,0xFF01,26,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_52 [] = {0xFF01,28,0xFF01,26,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_53 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_54 [] = {0xFF01,29,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_55 [] = {0xFF01,746,0xFF01,1246,0xFF01,27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_56 [] = {0xFF01,28,0xFF01,1246,0xFF01,27,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_57 [] = {0xFF01,746,0xFF01,1246,0xFF01,35,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_58 [] = {0xFF01,28,0xFF01,1246,0xFF01,35,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_59 [] = {0xFF01,746,0xFF01,34,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_60 [] = {0xFF01,28,0xFF01,34,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_61 [] = {0xFF01,746,0xFF01,1247,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_62 [] = {0xFF01,28,0xFF01,1247,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_63 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_64 [] = {0xFF01,32,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_65 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_66 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_67 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_68 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_69 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_70 [] = {933,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_71 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_72 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_73 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_74 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_75 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_76 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_77 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_78 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_79 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_80 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_81 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_82 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_83 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_84 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_85 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_86 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_87 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_88 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_89 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_90 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_91 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_92 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_93 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_94 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_95 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_96 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_97 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_98 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_99 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_100 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_101 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_102 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_103 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_104 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_105 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_106 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_107 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_108 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_109 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_110 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_111 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_112 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_113 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_114 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_115 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_116 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_117 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_118 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_119 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_120 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_121 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_122 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_123 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_124 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_125 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_126 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_127 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_128 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_129 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_130 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_131 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_132 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_133 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_134 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_135 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_136 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_137 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_138 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1369_139 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1369 [] = {
g_atype1369_0,
g_atype1369_1,
g_atype1369_2,
g_atype1369_3,
g_atype1369_4,
g_atype1369_5,
g_atype1369_6,
g_atype1369_7,
g_atype1369_8,
g_atype1369_9,
g_atype1369_10,
g_atype1369_11,
g_atype1369_12,
g_atype1369_13,
g_atype1369_14,
g_atype1369_15,
g_atype1369_16,
g_atype1369_17,
g_atype1369_18,
g_atype1369_19,
g_atype1369_20,
g_atype1369_21,
g_atype1369_22,
g_atype1369_23,
g_atype1369_24,
g_atype1369_25,
g_atype1369_26,
g_atype1369_27,
g_atype1369_28,
g_atype1369_29,
g_atype1369_30,
g_atype1369_31,
g_atype1369_32,
g_atype1369_33,
g_atype1369_34,
g_atype1369_35,
g_atype1369_36,
g_atype1369_37,
g_atype1369_38,
g_atype1369_39,
g_atype1369_40,
g_atype1369_41,
g_atype1369_42,
g_atype1369_43,
g_atype1369_44,
g_atype1369_45,
g_atype1369_46,
g_atype1369_47,
g_atype1369_48,
g_atype1369_49,
g_atype1369_50,
g_atype1369_51,
g_atype1369_52,
g_atype1369_53,
g_atype1369_54,
g_atype1369_55,
g_atype1369_56,
g_atype1369_57,
g_atype1369_58,
g_atype1369_59,
g_atype1369_60,
g_atype1369_61,
g_atype1369_62,
g_atype1369_63,
g_atype1369_64,
g_atype1369_65,
g_atype1369_66,
g_atype1369_67,
g_atype1369_68,
g_atype1369_69,
g_atype1369_70,
g_atype1369_71,
g_atype1369_72,
g_atype1369_73,
g_atype1369_74,
g_atype1369_75,
g_atype1369_76,
g_atype1369_77,
g_atype1369_78,
g_atype1369_79,
g_atype1369_80,
g_atype1369_81,
g_atype1369_82,
g_atype1369_83,
g_atype1369_84,
g_atype1369_85,
g_atype1369_86,
g_atype1369_87,
g_atype1369_88,
g_atype1369_89,
g_atype1369_90,
g_atype1369_91,
g_atype1369_92,
g_atype1369_93,
g_atype1369_94,
g_atype1369_95,
g_atype1369_96,
g_atype1369_97,
g_atype1369_98,
g_atype1369_99,
g_atype1369_100,
g_atype1369_101,
g_atype1369_102,
g_atype1369_103,
g_atype1369_104,
g_atype1369_105,
g_atype1369_106,
g_atype1369_107,
g_atype1369_108,
g_atype1369_109,
g_atype1369_110,
g_atype1369_111,
g_atype1369_112,
g_atype1369_113,
g_atype1369_114,
g_atype1369_115,
g_atype1369_116,
g_atype1369_117,
g_atype1369_118,
g_atype1369_119,
g_atype1369_120,
g_atype1369_121,
g_atype1369_122,
g_atype1369_123,
g_atype1369_124,
g_atype1369_125,
g_atype1369_126,
g_atype1369_127,
g_atype1369_128,
g_atype1369_129,
g_atype1369_130,
g_atype1369_131,
g_atype1369_132,
g_atype1369_133,
g_atype1369_134,
g_atype1369_135,
g_atype1369_136,
g_atype1369_137,
g_atype1369_138,
g_atype1369_139,
};

static const long offsets1369 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
 + @REFACS(35),
 + @REFACS(36),
 + @REFACS(37),
 + @REFACS(38),
 + @REFACS(39),
 + @REFACS(40),
 + @REFACS(41),
 + @REFACS(42),
 + @REFACS(43),
 + @REFACS(44),
 + @REFACS(45),
 + @REFACS(46),
 + @REFACS(47),
 + @REFACS(48),
 + @REFACS(49),
 + @REFACS(50),
 + @REFACS(51),
 + @REFACS(52),
 + @REFACS(53),
 + @REFACS(54),
 + @REFACS(55),
 + @REFACS(56),
 + @REFACS(57),
 + @REFACS(58),
 + @REFACS(59),
 + @REFACS(60),
 + @REFACS(61),
 + @REFACS(62),
 + @REFACS(63),
 + @REFACS(64),
+ @CHROFF(65,0),
+ @CHROFF(65,1),
+ @CHROFF(65,2),
+ @CHROFF(65,3),
+ @CHROFF(65,4),
+ @LNGOFF(65,5,0,0),
+ @LNGOFF(65,5,0,1),
+ @LNGOFF(65,5,0,2),
+ @LNGOFF(65,5,0,3),
+ @LNGOFF(65,5,0,4),
+ @LNGOFF(65,5,0,5),
+ @LNGOFF(65,5,0,6),
+ @LNGOFF(65,5,0,7),
+ @LNGOFF(65,5,0,8),
+ @LNGOFF(65,5,0,9),
+ @LNGOFF(65,5,0,10),
+ @LNGOFF(65,5,0,11),
+ @LNGOFF(65,5,0,12),
+ @LNGOFF(65,5,0,13),
+ @LNGOFF(65,5,0,14),
+ @LNGOFF(65,5,0,15),
+ @LNGOFF(65,5,0,16),
+ @LNGOFF(65,5,0,17),
+ @LNGOFF(65,5,0,18),
+ @LNGOFF(65,5,0,19),
+ @LNGOFF(65,5,0,20),
+ @LNGOFF(65,5,0,21),
+ @LNGOFF(65,5,0,22),
+ @LNGOFF(65,5,0,23),
+ @LNGOFF(65,5,0,24),
+ @LNGOFF(65,5,0,25),
+ @LNGOFF(65,5,0,26),
+ @LNGOFF(65,5,0,27),
+ @LNGOFF(65,5,0,28),
+ @LNGOFF(65,5,0,29),
+ @LNGOFF(65,5,0,30),
+ @LNGOFF(65,5,0,31),
+ @LNGOFF(65,5,0,32),
+ @LNGOFF(65,5,0,33),
+ @LNGOFF(65,5,0,34),
+ @LNGOFF(65,5,0,35),
+ @LNGOFF(65,5,0,36),
+ @LNGOFF(65,5,0,37),
+ @LNGOFF(65,5,0,38),
+ @LNGOFF(65,5,0,39),
+ @LNGOFF(65,5,0,40),
+ @LNGOFF(65,5,0,41),
+ @LNGOFF(65,5,0,42),
+ @LNGOFF(65,5,0,43),
+ @LNGOFF(65,5,0,44),
+ @LNGOFF(65,5,0,45),
+ @LNGOFF(65,5,0,46),
+ @LNGOFF(65,5,0,47),
+ @LNGOFF(65,5,0,48),
+ @LNGOFF(65,5,0,49),
+ @LNGOFF(65,5,0,50),
+ @LNGOFF(65,5,0,51),
+ @LNGOFF(65,5,0,52),
+ @LNGOFF(65,5,0,53),
+ @LNGOFF(65,5,0,54),
+ @LNGOFF(65,5,0,55),
+ @LNGOFF(65,5,0,56),
+ @LNGOFF(65,5,0,57),
+ @LNGOFF(65,5,0,58),
+ @LNGOFF(65,5,0,59),
+ @LNGOFF(65,5,0,60),
+ @LNGOFF(65,5,0,61),
+ @LNGOFF(65,5,0,62),
+ @LNGOFF(65,5,0,63),
+ @LNGOFF(65,5,0,64),
+ @LNGOFF(65,5,0,65),
+ @LNGOFF(65,5,0,66),
+ @LNGOFF(65,5,0,67),
+ @LNGOFF(65,5,0,68),
+ @LNGOFF(65,5,0,69),
};

extern const char *names1370[];
static const uint32 types1370 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1370 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1370_0 [] = {0xFF01,144,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_1 [] = {0xFF01,211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_2 [] = {0xFF01,104,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_3 [] = {0xFF01,104,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_4 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_5 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_8 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_9 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_10 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_11 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_12 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_13 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_14 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_15 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_16 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_17 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_18 [] = {1244,0xFF01,1103,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_19 [] = {0xFF01,1286,0xFF01,1363,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_20 [] = {0xFF01,1286,0xFF01,1363,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_21 [] = {0xFF01,1361,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_22 [] = {0xFF01,1260,0xFF01,1361,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_23 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_24 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_25 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_26 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_27 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_28 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_29 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_30 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_31 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_32 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_33 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_34 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_35 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_36 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_37 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1370_38 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1370 [] = {
g_atype1370_0,
g_atype1370_1,
g_atype1370_2,
g_atype1370_3,
g_atype1370_4,
g_atype1370_5,
g_atype1370_6,
g_atype1370_7,
g_atype1370_8,
g_atype1370_9,
g_atype1370_10,
g_atype1370_11,
g_atype1370_12,
g_atype1370_13,
g_atype1370_14,
g_atype1370_15,
g_atype1370_16,
g_atype1370_17,
g_atype1370_18,
g_atype1370_19,
g_atype1370_20,
g_atype1370_21,
g_atype1370_22,
g_atype1370_23,
g_atype1370_24,
g_atype1370_25,
g_atype1370_26,
g_atype1370_27,
g_atype1370_28,
g_atype1370_29,
g_atype1370_30,
g_atype1370_31,
g_atype1370_32,
g_atype1370_33,
g_atype1370_34,
g_atype1370_35,
g_atype1370_36,
g_atype1370_37,
g_atype1370_38,
};

static const long offsets1370 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
+ @CHROFF(23,0),
+ @CHROFF(23,1),
+ @CHROFF(23,2),
+ @LNGOFF(23,3,0,0),
+ @LNGOFF(23,3,0,1),
+ @LNGOFF(23,3,0,2),
+ @LNGOFF(23,3,0,3),
+ @LNGOFF(23,3,0,4),
+ @LNGOFF(23,3,0,5),
+ @LNGOFF(23,3,0,6),
+ @LNGOFF(23,3,0,7),
+ @LNGOFF(23,3,0,8),
+ @LNGOFF(23,3,0,9),
+ @LNGOFF(23,3,0,10),
+ @LNGOFF(23,3,0,11),
+ @LNGOFF(23,3,0,12),
};

extern const char *names1371[];
static const uint32 types1371 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1371 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1371_0 [] = {0xFF01,144,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_1 [] = {0xFF01,211,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_2 [] = {0xFF01,104,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_3 [] = {0xFF01,104,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_4 [] = {0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_5 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_6 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_7 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_8 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_9 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_10 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_11 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_12 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_13 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_14 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_15 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_16 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_17 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_18 [] = {1244,0xFF01,1103,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_19 [] = {0xFF01,1286,0xFF01,1363,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_20 [] = {0xFF01,1286,0xFF01,1363,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_21 [] = {0xFF01,1361,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_22 [] = {0xFF01,1260,0xFF01,1361,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_23 [] = {0xFF01,746,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_24 [] = {0xFF01,28,0,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_25 [] = {0xFF01,746,0xFF01,1024,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_26 [] = {0xFF01,28,0xFF01,1024,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_27 [] = {0xFF01,746,0xFF01,1275,0xFF01,1024,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_28 [] = {0xFF01,28,0xFF01,1275,0xFF01,1024,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_29 [] = {0xFF01,746,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_30 [] = {0xFF01,28,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_31 [] = {0xFF01,746,0xFF01,1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_32 [] = {0xFF01,28,0xFF01,1309,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_33 [] = {0xFF01,746,0xFF01,1372,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_34 [] = {0xFF01,28,0xFF01,1372,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_35 [] = {0xFF01,746,0xFF01,1249,0xFF01,1351,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_36 [] = {0xFF01,28,0xFF01,1249,0xFF01,1351,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_37 [] = {0xFF01,746,0xFF01,1351,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_38 [] = {0xFF01,28,0xFF01,1351,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_39 [] = {0xFF01,746,0xFF01,1249,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_40 [] = {0xFF01,28,0xFF01,1249,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_41 [] = {0xFF01,748,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_42 [] = {0xFF01,29,939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_43 [] = {0xFF01,746,0xFF01,21,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_44 [] = {0xFF01,28,0xFF01,21,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_45 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_46 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_47 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_48 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_49 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_50 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_51 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_52 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_53 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_54 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_55 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_56 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_57 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_58 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_59 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_60 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_61 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_62 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_63 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_64 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_65 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_66 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_67 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_68 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_69 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_70 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_71 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_72 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_73 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_74 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_75 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_76 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_77 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_78 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_79 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_80 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_81 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1371_82 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1371 [] = {
g_atype1371_0,
g_atype1371_1,
g_atype1371_2,
g_atype1371_3,
g_atype1371_4,
g_atype1371_5,
g_atype1371_6,
g_atype1371_7,
g_atype1371_8,
g_atype1371_9,
g_atype1371_10,
g_atype1371_11,
g_atype1371_12,
g_atype1371_13,
g_atype1371_14,
g_atype1371_15,
g_atype1371_16,
g_atype1371_17,
g_atype1371_18,
g_atype1371_19,
g_atype1371_20,
g_atype1371_21,
g_atype1371_22,
g_atype1371_23,
g_atype1371_24,
g_atype1371_25,
g_atype1371_26,
g_atype1371_27,
g_atype1371_28,
g_atype1371_29,
g_atype1371_30,
g_atype1371_31,
g_atype1371_32,
g_atype1371_33,
g_atype1371_34,
g_atype1371_35,
g_atype1371_36,
g_atype1371_37,
g_atype1371_38,
g_atype1371_39,
g_atype1371_40,
g_atype1371_41,
g_atype1371_42,
g_atype1371_43,
g_atype1371_44,
g_atype1371_45,
g_atype1371_46,
g_atype1371_47,
g_atype1371_48,
g_atype1371_49,
g_atype1371_50,
g_atype1371_51,
g_atype1371_52,
g_atype1371_53,
g_atype1371_54,
g_atype1371_55,
g_atype1371_56,
g_atype1371_57,
g_atype1371_58,
g_atype1371_59,
g_atype1371_60,
g_atype1371_61,
g_atype1371_62,
g_atype1371_63,
g_atype1371_64,
g_atype1371_65,
g_atype1371_66,
g_atype1371_67,
g_atype1371_68,
g_atype1371_69,
g_atype1371_70,
g_atype1371_71,
g_atype1371_72,
g_atype1371_73,
g_atype1371_74,
g_atype1371_75,
g_atype1371_76,
g_atype1371_77,
g_atype1371_78,
g_atype1371_79,
g_atype1371_80,
g_atype1371_81,
g_atype1371_82,
};

static const long offsets1371 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
 + @REFACS(16),
 + @REFACS(17),
 + @REFACS(18),
 + @REFACS(19),
 + @REFACS(20),
 + @REFACS(21),
 + @REFACS(22),
 + @REFACS(23),
 + @REFACS(24),
 + @REFACS(25),
 + @REFACS(26),
 + @REFACS(27),
 + @REFACS(28),
 + @REFACS(29),
 + @REFACS(30),
 + @REFACS(31),
 + @REFACS(32),
 + @REFACS(33),
 + @REFACS(34),
 + @REFACS(35),
 + @REFACS(36),
 + @REFACS(37),
 + @REFACS(38),
 + @REFACS(39),
 + @REFACS(40),
 + @REFACS(41),
 + @REFACS(42),
 + @REFACS(43),
 + @REFACS(44),
+ @CHROFF(45,0),
+ @CHROFF(45,1),
+ @CHROFF(45,2),
+ @LNGOFF(45,3,0,0),
+ @LNGOFF(45,3,0,1),
+ @LNGOFF(45,3,0,2),
+ @LNGOFF(45,3,0,3),
+ @LNGOFF(45,3,0,4),
+ @LNGOFF(45,3,0,5),
+ @LNGOFF(45,3,0,6),
+ @LNGOFF(45,3,0,7),
+ @LNGOFF(45,3,0,8),
+ @LNGOFF(45,3,0,9),
+ @LNGOFF(45,3,0,10),
+ @LNGOFF(45,3,0,11),
+ @LNGOFF(45,3,0,12),
+ @LNGOFF(45,3,0,13),
+ @LNGOFF(45,3,0,14),
+ @LNGOFF(45,3,0,15),
+ @LNGOFF(45,3,0,16),
+ @LNGOFF(45,3,0,17),
+ @LNGOFF(45,3,0,18),
+ @LNGOFF(45,3,0,19),
+ @LNGOFF(45,3,0,20),
+ @LNGOFF(45,3,0,21),
+ @LNGOFF(45,3,0,22),
+ @LNGOFF(45,3,0,23),
+ @LNGOFF(45,3,0,24),
+ @LNGOFF(45,3,0,25),
+ @LNGOFF(45,3,0,26),
+ @LNGOFF(45,3,0,27),
+ @LNGOFF(45,3,0,28),
+ @LNGOFF(45,3,0,29),
+ @LNGOFF(45,3,0,30),
+ @LNGOFF(45,3,0,31),
+ @LNGOFF(45,3,0,32),
+ @LNGOFF(45,3,0,33),
+ @LNGOFF(45,3,0,34),
};

extern const char *names1373[];
static const uint32 types1373 [] =
{
SK_REF,
SK_REF,
SK_CHAR8,
SK_CHAR8,
SK_BOOL,
};

static const uint16 attr_flags1373 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1373_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1373_1 [] = {1244,0xFF01,1372,0xFFFF};
static const EIF_TYPE_INDEX g_atype1373_2 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1373_3 [] = {936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1373_4 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1373 [] = {
g_atype1373_0,
g_atype1373_1,
g_atype1373_2,
g_atype1373_3,
g_atype1373_4,
};

static const long offsets1373 [] =
{
0,
 + @REFACS(1),
+ @CHROFF(2,0),
+ @CHROFF(2,1),
+ @CHROFF(2,2),
};

extern const char *names1374[];
static const uint32 types1374 [] =
{
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1374 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1374_0 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1374_1 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1374 [] = {
g_atype1374_0,
g_atype1374_1,
};

static const long offsets1374 [] =
{
0,
+ @CHROFF(1,0),
};

extern const char *names1375[];
static const uint32 types1375 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1375 [] =
{0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1375_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_1 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_2 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_3 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_4 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_5 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_6 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_7 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_8 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1375_9 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1375 [] = {
g_atype1375_0,
g_atype1375_1,
g_atype1375_2,
g_atype1375_3,
g_atype1375_4,
g_atype1375_5,
g_atype1375_6,
g_atype1375_7,
g_atype1375_8,
g_atype1375_9,
};

static const long offsets1375 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
+ @CHROFF(5,0),
+ @CHROFF(5,1),
+ @LNGOFF(5,2,0,0),
+ @LNGOFF(5,2,0,1),
+ @LNGOFF(5,2,0,2),
};

extern const char *names1376[];
static const uint32 types1376 [] =
{
SK_REF,
};

static const uint16 attr_flags1376 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1376_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1376 [] = {
g_atype1376_0,
};

static const long offsets1376 [] =
{
0,
};

extern const char *names1377[];
static const uint32 types1377 [] =
{
SK_REF,
};

static const uint16 attr_flags1377 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1377_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1377 [] = {
g_atype1377_0,
};

static const long offsets1377 [] =
{
0,
};

extern const char *names1378[];
static const uint32 types1378 [] =
{
SK_REF,
};

static const uint16 attr_flags1378 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1378_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1378 [] = {
g_atype1378_0,
};

static const long offsets1378 [] =
{
0,
};

extern const char *names1379[];
static const uint32 types1379 [] =
{
SK_REF,
};

static const uint16 attr_flags1379 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1379_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1379 [] = {
g_atype1379_0,
};

static const long offsets1379 [] =
{
0,
};

extern const char *names1380[];
static const uint32 types1380 [] =
{
SK_REF,
};

static const uint16 attr_flags1380 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1380_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1380 [] = {
g_atype1380_0,
};

static const long offsets1380 [] =
{
0,
};

extern const char *names1381[];
static const uint32 types1381 [] =
{
SK_REF,
};

static const uint16 attr_flags1381 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1381_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1381 [] = {
g_atype1381_0,
};

static const long offsets1381 [] =
{
0,
};

extern const char *names1382[];
static const uint32 types1382 [] =
{
SK_REF,
};

static const uint16 attr_flags1382 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1382_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1382 [] = {
g_atype1382_0,
};

static const long offsets1382 [] =
{
0,
};

extern const char *names1383[];
static const uint32 types1383 [] =
{
SK_REF,
};

static const uint16 attr_flags1383 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1383_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1383 [] = {
g_atype1383_0,
};

static const long offsets1383 [] =
{
0,
};

extern const char *names1384[];
static const uint32 types1384 [] =
{
SK_REF,
};

static const uint16 attr_flags1384 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1384_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1384 [] = {
g_atype1384_0,
};

static const long offsets1384 [] =
{
0,
};

extern const char *names1385[];
static const uint32 types1385 [] =
{
SK_REF,
};

static const uint16 attr_flags1385 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1385_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1385 [] = {
g_atype1385_0,
};

static const long offsets1385 [] =
{
0,
};

extern const char *names1386[];
static const uint32 types1386 [] =
{
SK_REF,
};

static const uint16 attr_flags1386 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1386_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1386 [] = {
g_atype1386_0,
};

static const long offsets1386 [] =
{
0,
};

extern const char *names1387[];
static const uint32 types1387 [] =
{
SK_REF,
};

static const uint16 attr_flags1387 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1387_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1387 [] = {
g_atype1387_0,
};

static const long offsets1387 [] =
{
0,
};

extern const char *names1388[];
static const uint32 types1388 [] =
{
SK_REF,
};

static const uint16 attr_flags1388 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1388_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1388 [] = {
g_atype1388_0,
};

static const long offsets1388 [] =
{
0,
};

extern const char *names1389[];
static const uint32 types1389 [] =
{
SK_REF,
};

static const uint16 attr_flags1389 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1389_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1389 [] = {
g_atype1389_0,
};

static const long offsets1389 [] =
{
0,
};

extern const char *names1390[];
static const uint32 types1390 [] =
{
SK_REF,
};

static const uint16 attr_flags1390 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1390_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1390 [] = {
g_atype1390_0,
};

static const long offsets1390 [] =
{
0,
};

extern const char *names1391[];
static const uint32 types1391 [] =
{
SK_REF,
};

static const uint16 attr_flags1391 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1391_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1391 [] = {
g_atype1391_0,
};

static const long offsets1391 [] =
{
0,
};

extern const char *names1392[];
static const uint32 types1392 [] =
{
SK_REF,
};

static const uint16 attr_flags1392 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1392_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1392 [] = {
g_atype1392_0,
};

static const long offsets1392 [] =
{
0,
};

extern const char *names1393[];
static const uint32 types1393 [] =
{
SK_REF,
};

static const uint16 attr_flags1393 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1393_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1393 [] = {
g_atype1393_0,
};

static const long offsets1393 [] =
{
0,
};

extern const char *names1394[];
static const uint32 types1394 [] =
{
SK_REF,
};

static const uint16 attr_flags1394 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1394_0 [] = {0xFF01,771,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1394 [] = {
g_atype1394_0,
};

static const long offsets1394 [] =
{
0,
};

extern const char *names1395[];
static const uint32 types1395 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1395 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1395_0 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_1 [] = {0xFF01,1095,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_2 [] = {0xFF01,1077,0xFFFF};
static const EIF_TYPE_INDEX g_atype1395_3 [] = {0xFF01,1373,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1395 [] = {
g_atype1395_0,
g_atype1395_1,
g_atype1395_2,
g_atype1395_3,
};

static const long offsets1395 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1396[];
static const uint32 types1396 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
};

static const uint16 attr_flags1396 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1396_0 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_1 [] = {1368,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_2 [] = {0xFF01,1411,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_3 [] = {0xFF01,1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_4 [] = {0xFF01,1410,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_5 [] = {0xFF01,1079,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_6 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_7 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_8 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_9 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_10 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_11 [] = {42,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_12 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_13 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1396_14 [] = {939,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1396 [] = {
g_atype1396_0,
g_atype1396_1,
g_atype1396_2,
g_atype1396_3,
g_atype1396_4,
g_atype1396_5,
g_atype1396_6,
g_atype1396_7,
g_atype1396_8,
g_atype1396_9,
g_atype1396_10,
g_atype1396_11,
g_atype1396_12,
g_atype1396_13,
g_atype1396_14,
};

static const long offsets1396 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
+ @CHROFF(14,0),
};

extern const char *names1397[];
static const uint32 types1397 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1397 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1397_0 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_1 [] = {1368,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_2 [] = {0xFF01,1411,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_3 [] = {0xFF01,1080,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_4 [] = {0xFF01,1410,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_5 [] = {0xFF01,1079,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_6 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_7 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_8 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_9 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_10 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_11 [] = {42,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_12 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_13 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_14 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1397_15 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1397 [] = {
g_atype1397_0,
g_atype1397_1,
g_atype1397_2,
g_atype1397_3,
g_atype1397_4,
g_atype1397_5,
g_atype1397_6,
g_atype1397_7,
g_atype1397_8,
g_atype1397_9,
g_atype1397_10,
g_atype1397_11,
g_atype1397_12,
g_atype1397_13,
g_atype1397_14,
g_atype1397_15,
};

static const long offsets1397 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
+ @CHROFF(14,0),
+ @LNGOFF(14,1,0,0),
};

extern const char *names1399[];
static const uint32 types1399 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_INT32,
};

static const uint16 attr_flags1399 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1399_0 [] = {0xFF01,771,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1399_1 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1399_2 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1399_3 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1399_4 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1399_5 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1399 [] = {
g_atype1399_0,
g_atype1399_1,
g_atype1399_2,
g_atype1399_3,
g_atype1399_4,
g_atype1399_5,
};

static const long offsets1399 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
+ @CHROFF(4,0),
+ @LNGOFF(4,1,0,0),
};

extern const char *names1401[];
static const uint32 types1401 [] =
{
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1401 [] =
{0,0,0,};

static const EIF_TYPE_INDEX g_atype1401_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1401_1 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1401_2 [] = {0xFF01,276,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1401 [] = {
g_atype1401_0,
g_atype1401_1,
g_atype1401_2,
};

static const long offsets1401 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
};

extern const char *names1402[];
static const uint32 types1402 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1402 [] =
{0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1402_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_1 [] = {0xFF01,221,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_2 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_3 [] = {0xFF01,1293,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_4 [] = {0xFF01,1400,0xFFFF};
static const EIF_TYPE_INDEX g_atype1402_5 [] = {0xFF01,1050,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1402 [] = {
g_atype1402_0,
g_atype1402_1,
g_atype1402_2,
g_atype1402_3,
g_atype1402_4,
g_atype1402_5,
};

static const long offsets1402 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
};

extern const char *names1403[];
static const uint32 types1403 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1403 [] =
{0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1403_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1403_1 [] = {0xFF01,221,0xFFFF};
static const EIF_TYPE_INDEX g_atype1403_2 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1403_3 [] = {0xFF01,1293,0xFFFF};
static const EIF_TYPE_INDEX g_atype1403_4 [] = {0xFF01,1050,0xFFFF};
static const EIF_TYPE_INDEX g_atype1403_5 [] = {0xFF01,1400,0xFFFF};
static const EIF_TYPE_INDEX g_atype1403_6 [] = {0xFF01,1400,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1403 [] = {
g_atype1403_0,
g_atype1403_1,
g_atype1403_2,
g_atype1403_3,
g_atype1403_4,
g_atype1403_5,
g_atype1403_6,
};

static const long offsets1403 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
};

extern const char *names1404[];
static const uint32 types1404 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1404 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1404_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1404_1 [] = {0xFF01,221,0xFFFF};
static const EIF_TYPE_INDEX g_atype1404_2 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1404_3 [] = {0xFF01,1293,0xFFFF};
static const EIF_TYPE_INDEX g_atype1404_4 [] = {0xFF01,1051,0xFFFF};
static const EIF_TYPE_INDEX g_atype1404_5 [] = {0xFF01,278,0xFFFF};
static const EIF_TYPE_INDEX g_atype1404_6 [] = {0xFF01,277,0xFFFF};
static const EIF_TYPE_INDEX g_atype1404_7 [] = {0xFF01,863,0xFFFF};
static const EIF_TYPE_INDEX g_atype1404_8 [] = {0xFF01,1023,0xFFFF};
static const EIF_TYPE_INDEX g_atype1404_9 [] = {0xFF01,1400,0xFFFF};
static const EIF_TYPE_INDEX g_atype1404_10 [] = {0xFF01,1050,0xFFFF};
static const EIF_TYPE_INDEX g_atype1404_11 [] = {0xFF01,279,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1404 [] = {
g_atype1404_0,
g_atype1404_1,
g_atype1404_2,
g_atype1404_3,
g_atype1404_4,
g_atype1404_5,
g_atype1404_6,
g_atype1404_7,
g_atype1404_8,
g_atype1404_9,
g_atype1404_10,
g_atype1404_11,
};

static const long offsets1404 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
};

extern const char *names1405[];
static const uint32 types1405 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1405 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1405_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1405_1 [] = {0xFF01,221,0xFFFF};
static const EIF_TYPE_INDEX g_atype1405_2 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1405_3 [] = {0xFF01,1293,0xFFFF};
static const EIF_TYPE_INDEX g_atype1405_4 [] = {0xFF01,279,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1405 [] = {
g_atype1405_0,
g_atype1405_1,
g_atype1405_2,
g_atype1405_3,
g_atype1405_4,
};

static const long offsets1405 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
};

extern const char *names1406[];
static const uint32 types1406 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1406 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1406_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1406_1 [] = {0xFF01,221,0xFFFF};
static const EIF_TYPE_INDEX g_atype1406_2 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1406_3 [] = {0xFF01,1293,0xFFFF};
static const EIF_TYPE_INDEX g_atype1406_4 [] = {0xFF01,279,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1406 [] = {
g_atype1406_0,
g_atype1406_1,
g_atype1406_2,
g_atype1406_3,
g_atype1406_4,
};

static const long offsets1406 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
};

extern const char *names1407[];
static const uint32 types1407 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1407 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1407_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_1 [] = {0xFF01,221,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_2 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1407_3 [] = {0xFF01,1293,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1407 [] = {
g_atype1407_0,
g_atype1407_1,
g_atype1407_2,
g_atype1407_3,
};

static const long offsets1407 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1408[];
static const uint32 types1408 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1408 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1408_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1408_1 [] = {0xFF01,221,0xFFFF};
static const EIF_TYPE_INDEX g_atype1408_2 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1408_3 [] = {0xFF01,1293,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1408 [] = {
g_atype1408_0,
g_atype1408_1,
g_atype1408_2,
g_atype1408_3,
};

static const long offsets1408 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1409[];
static const uint32 types1409 [] =
{
SK_REF,
SK_INT32,
};

static const uint16 attr_flags1409 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1409_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1409_1 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1409 [] = {
g_atype1409_0,
g_atype1409_1,
};

static const long offsets1409 [] =
{
0,
+ @LNGOFF(1,0,0,0),
};

extern const char *names1410[];
static const uint32 types1410 [] =
{
SK_REF,
SK_REF,
};

static const uint16 attr_flags1410 [] =
{0,0,};

static const EIF_TYPE_INDEX g_atype1410_0 [] = {986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1410_1 [] = {986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1410 [] = {
g_atype1410_0,
g_atype1410_1,
};

static const long offsets1410 [] =
{
0,
 + @REFACS(1),
};

extern const char *names1411[];
static const uint32 types1411 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1411 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1411_0 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1411_1 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1411_2 [] = {0xFF01,1293,0xFFFF};
static const EIF_TYPE_INDEX g_atype1411_3 [] = {0xFF01,1412,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1411 [] = {
g_atype1411_0,
g_atype1411_1,
g_atype1411_2,
g_atype1411_3,
};

static const long offsets1411 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1412[];
static const uint32 types1412 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1412 [] =
{0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1412_0 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_1 [] = {0xFF01,1293,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_2 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_3 [] = {0xFF01,1412,0xFFFF};
static const EIF_TYPE_INDEX g_atype1412_4 [] = {0xFF01,1079,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1412 [] = {
g_atype1412_0,
g_atype1412_1,
g_atype1412_2,
g_atype1412_3,
g_atype1412_4,
};

static const long offsets1412 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
};

extern const char *names1413[];
static const uint32 types1413 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1413 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1413_0 [] = {1181,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_1 [] = {1180,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_2 [] = {1179,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_3 [] = {1173,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_4 [] = {1175,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_5 [] = {1187,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_6 [] = {1286,0xFF01,1246,0xFF01,1169,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_7 [] = {0xFF01,1286,0xFF01,1181,0xFF01,1058,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_8 [] = {0xFF01,1286,0xFF01,1180,0xFF01,1057,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_9 [] = {0xFF01,1286,0xFF01,1179,0xFF01,1059,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_10 [] = {0xFF01,1286,0xFF01,1173,0xFF01,900,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_11 [] = {0xFF01,1286,0xFF01,1187,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_12 [] = {0xFF01,1286,0xFF01,1175,0xFF01,1053,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_13 [] = {0xFF01,1286,0xFF01,1246,0xFF01,1173,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_14 [] = {0xFF01,1286,0xFF01,1246,0xFF01,1175,0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1413_15 [] = {0xFF01,1286,0xFF01,1246,0xFF01,1187,0xFF01,986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1413 [] = {
g_atype1413_0,
g_atype1413_1,
g_atype1413_2,
g_atype1413_3,
g_atype1413_4,
g_atype1413_5,
g_atype1413_6,
g_atype1413_7,
g_atype1413_8,
g_atype1413_9,
g_atype1413_10,
g_atype1413_11,
g_atype1413_12,
g_atype1413_13,
g_atype1413_14,
g_atype1413_15,
};

static const long offsets1413 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
 + @REFACS(12),
 + @REFACS(13),
 + @REFACS(14),
 + @REFACS(15),
};

extern const char *names1415[];
static const uint32 types1415 [] =
{
SK_REF,
};

static const uint16 attr_flags1415 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1415_0 [] = {986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1415 [] = {
g_atype1415_0,
};

static const long offsets1415 [] =
{
0,
};

extern const char *names1416[];
static const uint32 types1416 [] =
{
SK_REF,
};

static const uint16 attr_flags1416 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1416_0 [] = {986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1416 [] = {
g_atype1416_0,
};

static const long offsets1416 [] =
{
0,
};

extern const char *names1417[];
static const uint32 types1417 [] =
{
SK_REF,
};

static const uint16 attr_flags1417 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1417_0 [] = {986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1417 [] = {
g_atype1417_0,
};

static const long offsets1417 [] =
{
0,
};

extern const char *names1418[];
static const uint32 types1418 [] =
{
SK_REF,
};

static const uint16 attr_flags1418 [] =
{0,};

static const EIF_TYPE_INDEX g_atype1418_0 [] = {986,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1418 [] = {
g_atype1418_0,
};

static const long offsets1418 [] =
{
0,
};

extern const char *names1419[];
static const uint32 types1419 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
};

static const uint16 attr_flags1419 [] =
{0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1419_0 [] = {0xFF01,1034,0xFFFF};
static const EIF_TYPE_INDEX g_atype1419_1 [] = {0xFF01,221,0xFFFF};
static const EIF_TYPE_INDEX g_atype1419_2 [] = {0xFF01,1374,0xFFFF};
static const EIF_TYPE_INDEX g_atype1419_3 [] = {0xFF01,1293,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1419 [] = {
g_atype1419_0,
g_atype1419_1,
g_atype1419_2,
g_atype1419_3,
};

static const long offsets1419 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
};

extern const char *names1420[];
static const uint32 types1420 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
SK_INT64,
};

static const uint16 attr_flags1420 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1420_0 [] = {978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_1 [] = {0xFF01,1063,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_2 [] = {0xFF01,1308,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_3 [] = {0xFF01,11,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_4 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_5 [] = {0xFF01,983,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_6 [] = {0xFF01,11,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_7 [] = {11,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_8 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_9 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_10 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_11 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_12 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_13 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_14 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_15 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_16 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_17 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_18 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_19 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_20 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_21 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_22 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_23 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_24 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_25 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_26 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_27 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_28 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_29 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_30 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1420_31 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1420 [] = {
g_atype1420_0,
g_atype1420_1,
g_atype1420_2,
g_atype1420_3,
g_atype1420_4,
g_atype1420_5,
g_atype1420_6,
g_atype1420_7,
g_atype1420_8,
g_atype1420_9,
g_atype1420_10,
g_atype1420_11,
g_atype1420_12,
g_atype1420_13,
g_atype1420_14,
g_atype1420_15,
g_atype1420_16,
g_atype1420_17,
g_atype1420_18,
g_atype1420_19,
g_atype1420_20,
g_atype1420_21,
g_atype1420_22,
g_atype1420_23,
g_atype1420_24,
g_atype1420_25,
g_atype1420_26,
g_atype1420_27,
g_atype1420_28,
g_atype1420_29,
g_atype1420_30,
g_atype1420_31,
};

static const long offsets1420 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
+ @CHROFF(8,0),
+ @CHROFF(8,1),
+ @CHROFF(8,2),
+ @CHROFF(8,3),
+ @CHROFF(8,4),
+ @CHROFF(8,5),
+ @CHROFF(8,6),
+ @CHROFF(8,7),
+ @CHROFF(8,8),
+ @CHROFF(8,9),
+ @CHROFF(8,10),
+ @CHROFF(8,11),
+ @CHROFF(8,12),
+ @LNGOFF(8,13,0,0),
+ @LNGOFF(8,13,0,1),
+ @LNGOFF(8,13,0,2),
+ @LNGOFF(8,13,0,3),
+ @LNGOFF(8,13,0,4),
+ @LNGOFF(8,13,0,5),
+ @LNGOFF(8,13,0,6),
+ @LNGOFF(8,13,0,7),
+ @LNGOFF(8,13,0,8),
+ @I64OFF(8,13,0,9,0,0,0),
+ @I64OFF(8,13,0,9,0,0,1),
};

extern const char *names1421[];
static const uint32 types1421 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
SK_INT64,
};

static const uint16 attr_flags1421 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1421_0 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_1 [] = {978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_2 [] = {0xFF01,1063,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_3 [] = {0xFF01,1308,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_4 [] = {0xFF01,11,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_5 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_6 [] = {0xFF01,983,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_7 [] = {0xFF01,11,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_8 [] = {11,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_9 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_10 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_11 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_12 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_13 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_14 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_15 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_16 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_17 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_18 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_19 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_20 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_21 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_22 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_23 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_24 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_25 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_26 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_27 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_28 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_29 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_30 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_31 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_32 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_33 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_34 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_35 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_36 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_37 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_38 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_39 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_40 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_41 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_42 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_43 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_44 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_45 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_46 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_47 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_48 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_49 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_50 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_51 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1421_52 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1421 [] = {
g_atype1421_0,
g_atype1421_1,
g_atype1421_2,
g_atype1421_3,
g_atype1421_4,
g_atype1421_5,
g_atype1421_6,
g_atype1421_7,
g_atype1421_8,
g_atype1421_9,
g_atype1421_10,
g_atype1421_11,
g_atype1421_12,
g_atype1421_13,
g_atype1421_14,
g_atype1421_15,
g_atype1421_16,
g_atype1421_17,
g_atype1421_18,
g_atype1421_19,
g_atype1421_20,
g_atype1421_21,
g_atype1421_22,
g_atype1421_23,
g_atype1421_24,
g_atype1421_25,
g_atype1421_26,
g_atype1421_27,
g_atype1421_28,
g_atype1421_29,
g_atype1421_30,
g_atype1421_31,
g_atype1421_32,
g_atype1421_33,
g_atype1421_34,
g_atype1421_35,
g_atype1421_36,
g_atype1421_37,
g_atype1421_38,
g_atype1421_39,
g_atype1421_40,
g_atype1421_41,
g_atype1421_42,
g_atype1421_43,
g_atype1421_44,
g_atype1421_45,
g_atype1421_46,
g_atype1421_47,
g_atype1421_48,
g_atype1421_49,
g_atype1421_50,
g_atype1421_51,
g_atype1421_52,
};

static const long offsets1421 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @CHROFF(12,0),
+ @CHROFF(12,1),
+ @CHROFF(12,2),
+ @CHROFF(12,3),
+ @CHROFF(12,4),
+ @CHROFF(12,5),
+ @CHROFF(12,6),
+ @CHROFF(12,7),
+ @CHROFF(12,8),
+ @CHROFF(12,9),
+ @CHROFF(12,10),
+ @CHROFF(12,11),
+ @CHROFF(12,12),
+ @CHROFF(12,13),
+ @CHROFF(12,14),
+ @CHROFF(12,15),
+ @LNGOFF(12,16,0,0),
+ @LNGOFF(12,16,0,1),
+ @LNGOFF(12,16,0,2),
+ @LNGOFF(12,16,0,3),
+ @LNGOFF(12,16,0,4),
+ @LNGOFF(12,16,0,5),
+ @LNGOFF(12,16,0,6),
+ @LNGOFF(12,16,0,7),
+ @LNGOFF(12,16,0,8),
+ @LNGOFF(12,16,0,9),
+ @LNGOFF(12,16,0,10),
+ @LNGOFF(12,16,0,11),
+ @LNGOFF(12,16,0,12),
+ @LNGOFF(12,16,0,13),
+ @LNGOFF(12,16,0,14),
+ @LNGOFF(12,16,0,15),
+ @LNGOFF(12,16,0,16),
+ @LNGOFF(12,16,0,17),
+ @LNGOFF(12,16,0,18),
+ @LNGOFF(12,16,0,19),
+ @LNGOFF(12,16,0,20),
+ @LNGOFF(12,16,0,21),
+ @LNGOFF(12,16,0,22),
+ @I64OFF(12,16,0,23,0,0,0),
+ @I64OFF(12,16,0,23,0,0,1),
};

extern const char *names1422[];
static const uint32 types1422 [] =
{
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_REF,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_BOOL,
SK_UINT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT64,
SK_INT64,
};

static const uint16 attr_flags1422 [] =
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1422_0 [] = {0xFF01,978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_1 [] = {978,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_2 [] = {0xFF01,1063,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_3 [] = {0xFF01,1308,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_4 [] = {0xFF01,11,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_5 [] = {0xFF01,986,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_6 [] = {0xFF01,983,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_7 [] = {0xFF01,11,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_8 [] = {11,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_9 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_10 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_11 [] = {0xFF01,747,906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_12 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_13 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_14 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_15 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_16 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_17 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_18 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_19 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_20 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_21 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_22 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_23 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_24 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_25 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_26 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_27 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_28 [] = {918,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_29 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_30 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_31 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_32 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_33 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_34 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_35 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_36 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_37 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_38 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_39 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_40 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_41 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_42 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_43 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_44 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_45 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_46 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_47 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_48 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_49 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_50 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_51 [] = {903,0xFFFF};
static const EIF_TYPE_INDEX g_atype1422_52 [] = {903,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1422 [] = {
g_atype1422_0,
g_atype1422_1,
g_atype1422_2,
g_atype1422_3,
g_atype1422_4,
g_atype1422_5,
g_atype1422_6,
g_atype1422_7,
g_atype1422_8,
g_atype1422_9,
g_atype1422_10,
g_atype1422_11,
g_atype1422_12,
g_atype1422_13,
g_atype1422_14,
g_atype1422_15,
g_atype1422_16,
g_atype1422_17,
g_atype1422_18,
g_atype1422_19,
g_atype1422_20,
g_atype1422_21,
g_atype1422_22,
g_atype1422_23,
g_atype1422_24,
g_atype1422_25,
g_atype1422_26,
g_atype1422_27,
g_atype1422_28,
g_atype1422_29,
g_atype1422_30,
g_atype1422_31,
g_atype1422_32,
g_atype1422_33,
g_atype1422_34,
g_atype1422_35,
g_atype1422_36,
g_atype1422_37,
g_atype1422_38,
g_atype1422_39,
g_atype1422_40,
g_atype1422_41,
g_atype1422_42,
g_atype1422_43,
g_atype1422_44,
g_atype1422_45,
g_atype1422_46,
g_atype1422_47,
g_atype1422_48,
g_atype1422_49,
g_atype1422_50,
g_atype1422_51,
g_atype1422_52,
};

static const long offsets1422 [] =
{
0,
 + @REFACS(1),
 + @REFACS(2),
 + @REFACS(3),
 + @REFACS(4),
 + @REFACS(5),
 + @REFACS(6),
 + @REFACS(7),
 + @REFACS(8),
 + @REFACS(9),
 + @REFACS(10),
 + @REFACS(11),
+ @CHROFF(12,0),
+ @CHROFF(12,1),
+ @CHROFF(12,2),
+ @CHROFF(12,3),
+ @CHROFF(12,4),
+ @CHROFF(12,5),
+ @CHROFF(12,6),
+ @CHROFF(12,7),
+ @CHROFF(12,8),
+ @CHROFF(12,9),
+ @CHROFF(12,10),
+ @CHROFF(12,11),
+ @CHROFF(12,12),
+ @CHROFF(12,13),
+ @CHROFF(12,14),
+ @CHROFF(12,15),
+ @LNGOFF(12,16,0,0),
+ @LNGOFF(12,16,0,1),
+ @LNGOFF(12,16,0,2),
+ @LNGOFF(12,16,0,3),
+ @LNGOFF(12,16,0,4),
+ @LNGOFF(12,16,0,5),
+ @LNGOFF(12,16,0,6),
+ @LNGOFF(12,16,0,7),
+ @LNGOFF(12,16,0,8),
+ @LNGOFF(12,16,0,9),
+ @LNGOFF(12,16,0,10),
+ @LNGOFF(12,16,0,11),
+ @LNGOFF(12,16,0,12),
+ @LNGOFF(12,16,0,13),
+ @LNGOFF(12,16,0,14),
+ @LNGOFF(12,16,0,15),
+ @LNGOFF(12,16,0,16),
+ @LNGOFF(12,16,0,17),
+ @LNGOFF(12,16,0,18),
+ @LNGOFF(12,16,0,19),
+ @LNGOFF(12,16,0,20),
+ @LNGOFF(12,16,0,21),
+ @LNGOFF(12,16,0,22),
+ @I64OFF(12,16,0,23,0,0,0),
+ @I64OFF(12,16,0,23,0,0,1),
};

extern const char *names1423[];
static const uint32 types1423 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1423 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1423_0 [] = {0xFF01,752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1423_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1423_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1423_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1423_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1423_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1423_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1423_7 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1423 [] = {
g_atype1423_0,
g_atype1423_1,
g_atype1423_2,
g_atype1423_3,
g_atype1423_4,
g_atype1423_5,
g_atype1423_6,
g_atype1423_7,
};

static const long offsets1423 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

extern const char *names1424[];
static const uint32 types1424 [] =
{
SK_REF,
SK_BOOL,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
SK_INT32,
};

static const uint16 attr_flags1424 [] =
{0,0,0,0,0,0,0,0,};

static const EIF_TYPE_INDEX g_atype1424_0 [] = {0xFF01,752,936,0xFFFF};
static const EIF_TYPE_INDEX g_atype1424_1 [] = {939,0xFFFF};
static const EIF_TYPE_INDEX g_atype1424_2 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1424_3 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1424_4 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1424_5 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1424_6 [] = {906,0xFFFF};
static const EIF_TYPE_INDEX g_atype1424_7 [] = {906,0xFFFF};

static const EIF_TYPE_INDEX *gtypes1424 [] = {
g_atype1424_0,
g_atype1424_1,
g_atype1424_2,
g_atype1424_3,
g_atype1424_4,
g_atype1424_5,
g_atype1424_6,
g_atype1424_7,
};

static const long offsets1424 [] =
{
0,
+ @CHROFF(1,0),
+ @LNGOFF(1,1,0,0),
+ @LNGOFF(1,1,0,1),
+ @LNGOFF(1,1,0,2),
+ @LNGOFF(1,1,0,3),
+ @LNGOFF(1,1,0,4),
+ @LNGOFF(1,1,0,5),
};

const struct cnode egc_fsystem_init[] = {
{
	(long) 0,
	(long) 0,
	"ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PART_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PART_COMPARATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"C_DATE",
	names6,
	types6,
	attr_flags6,
	gtypes6,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets6,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_ARRAY_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_BOOLEAN_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_BOOLEAN_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"BASE_REDIRECTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 8,
	(long) 8,
	"RX_CHARACTER_SET",
	names12,
	types12,
	attr_flags12,
	gtypes12,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets12,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DESCRIPTOR_CACHE",
	names14,
	types14,
	attr_flags14,
	gtypes14,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets14,
	NULL
},
{
	(long) 0,
	(long) 0,
	"BASE_PROCESS_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PROCESS_COMMAND_RESULT",
	names16,
	types16,
	attr_flags16,
	gtypes16,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets16,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EWG_C_PHASE_1_MACRO",
	names17,
	types17,
	attr_flags17,
	gtypes17,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets17,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_C_PHASE_1_ARRAY",
	names18,
	types18,
	attr_flags18,
	gtypes18,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets18,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_HASH_FUNCTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_HASH_FUNCTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_HASH_FUNCTION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_EIFFEL_DECLARATION",
	names22,
	types22,
	attr_flags22,
	gtypes22,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets22,
	NULL
},
{
	(long) 1,
	(long) 0,
	"VERSIONABLE",
	names23,
	types23,
	attr_flags23,
	gtypes23,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets23,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PROCESS_MISC",
	names24,
	types24,
	attr_flags24,
	gtypes24,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets24,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 17,
	(long) 17,
	"WRAPC_MACRO_HEADER_PARSER",
	names26,
	types26,
	attr_flags26,
	gtypes26,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets26,
	NULL
},
{
	(long) 6,
	(long) 6,
	"EWG_C_PHASE_1_STORAGE_CLASS_SPECIFIERS",
	names27,
	types27,
	attr_flags27,
	gtypes27,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets27,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EWG_C_PHASE_1_DECLARATION",
	names28,
	types28,
	attr_flags28,
	gtypes28,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets28,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EWG_C_PHASE_1_PARAMETER_TYPE_LIST",
	names35,
	types35,
	attr_flags35,
	gtypes35,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets35,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_C_PHASE_1_POINTER",
	names36,
	types36,
	attr_flags36,
	gtypes36,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets36,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_POSITION_TABLE",
	names37,
	types37,
	attr_flags37,
	gtypes37,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets37,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_PAGE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ENCODING",
	names40,
	types40,
	attr_flags40,
	gtypes40,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets40,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CHARACTER_PROPERTY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 9,
	(long) 9,
	"WRAPC_MACRO_PARSER",
	names43,
	types43,
	attr_flags43,
	gtypes43,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets43,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EWG_CONFIG_RULE",
	names44,
	types44,
	attr_flags44,
	gtypes44,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets44,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_STRING",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RT_DBG_EXECUTION_PARAMETERS",
	names46,
	types46,
	attr_flags46,
	gtypes46,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets46,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0100,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UTF_CONVERTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0300,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_RUNTIME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_ARRAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"STD_FILES",
	names62,
	types62,
	attr_flags62,
	gtypes62,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets62,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DT_SHARED_WEEK_DAYS_FROM_SUNDAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PART_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DEBUGGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_CHARACTER_CODES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_SYSTEM_CLOCK",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 9,
	(long) 9,
	"KL_SYSTEM_CLOCK",
	names70,
	types70,
	attr_flags70,
	gtypes70,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets70,
	NULL
},
{
	(long) 0,
	(long) 0,
	"YY_PARSER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_EXECUTION_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 32,
	(long) 32,
	"BASE_PROCESS",
	names73,
	types73,
	attr_flags73,
	gtypes73,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets73,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ANY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_SHARED_CHARACTER_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_OPTION_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_ERROR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_BYTE_CODE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names84,
	types84,
	attr_flags84,
	gtypes84,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets84,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_CELL",
	names85,
	types85,
	attr_flags85,
	gtypes85,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets85,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names86,
	types86,
	attr_flags86,
	gtypes86,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets86,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_LINKABLE",
	names87,
	types87,
	attr_flags87,
	gtypes87,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets87,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CODE_SETS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_TRAVERSABLE",
	names89,
	types89,
	attr_flags89,
	gtypes89,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets89,
	NULL
},
{
	(long) 12,
	(long) 12,
	"OBJECT_GRAPH_BREADTH_FIRST_TRAVERSABLE",
	names90,
	types90,
	attr_flags90,
	gtypes90,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets90,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_C_AST_DECLARATION_PROCESSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_C_AST_DECLARATION_NULL_PROCESSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_SHARED_STRUCT_FEATURE_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_SHARED_ANY_FEATURE_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_BUFFER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_CONFIG_SHARED_WRAPPER_TYPE_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_CALLBACKS_FILTER_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_ERROR_CODES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_URI_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_DEFAULT_URI_SOURCE",
	names104,
	types104,
	attr_flags104,
	gtypes104,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets104,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_EXTERNAL_RESOLVER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_NULL_EXTERNAL_RESOLVER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_C_AST_TYPE_PROCESSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_I",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OBJECT_GRAPH_MARKER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MATH_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DOUBLE_MATH",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_DOUBLE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_C_PHASE_1_AST_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DT_SHARED_SYSTEM_CLOCK",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_DOUBLE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_EXECUTION_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFACTORING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SHARED_PROCESS_MISC",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ISE_EXCEPTION_MANAGER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEP_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names123,
	types123,
	attr_flags123,
	gtypes123,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets123,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names124,
	types124,
	attr_flags124,
	gtypes124,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets124,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names125,
	types125,
	attr_flags125,
	gtypes125,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets125,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CELL",
	names126,
	types126,
	attr_flags126,
	gtypes126,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets126,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names127,
	types127,
	attr_flags127,
	gtypes127,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets127,
	NULL
},
{
	(long) 2,
	(long) 2,
	"LINKABLE",
	names128,
	types128,
	attr_flags128,
	gtypes128,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets128,
	NULL
},
{
	(long) 0,
	(long) 0,
	"OPERATING_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"MEMORY_STRUCTURE",
	names130,
	types130,
	attr_flags130,
	gtypes130,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets130,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UNIX_SIGNALS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PROCESS_UNIX_OS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UNIX_PIPE_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_UNICODE_CHARACTERS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_UNICODE_CHARACTERS_1_1",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_UNICODE_CHARACTERS_1_0",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM_ENTRY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_EIFFEL_PARSER_ERRORS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_DTD_CALLBACKS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_DTD_CALLBACKS_NULL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_BOOLEAN_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CELL",
	names148,
	types148,
	attr_flags148,
	gtypes148,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets148,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CELL",
	names149,
	types149,
	attr_flags149,
	gtypes149,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets149,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CELL",
	names150,
	types150,
	attr_flags150,
	gtypes150,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets150,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CELL",
	names151,
	types151,
	attr_flags151,
	gtypes151,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets151,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DS_PAIR",
	names152,
	types152,
	attr_flags152,
	gtypes152,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets152,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DS_LINKABLE",
	names153,
	types153,
	attr_flags153,
	gtypes153,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets153,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DS_LINKABLE",
	names154,
	types154,
	attr_flags154,
	gtypes154,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets154,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DS_LINKABLE",
	names155,
	types155,
	attr_flags155,
	gtypes155,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets155,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DS_LINKABLE",
	names156,
	types156,
	attr_flags156,
	gtypes156,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets156,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_BILINKABLE",
	names157,
	types157,
	attr_flags157,
	gtypes157,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets157,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ENCODING_HELPER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SYSTEM_ENCODINGS_IMP",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_CL_ATTRIBUTE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STREAMS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_CHARACTER_32_CODES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_DTD_CALLBACKS_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_FORWARD_DTD_CALLBACKS",
	names165,
	types165,
	attr_flags165,
	gtypes165,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets165,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_NODE_PROCESSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"XM_NODE_TYPER",
	names167,
	types167,
	attr_flags167,
	gtypes167,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets167,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_TREE_TO_EVENTS",
	names168,
	types168,
	attr_flags168,
	gtypes168,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets168,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_C_AST_SHARED_DECLARATION_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EWG_C_AST_DECLARATION_SET",
	names172,
	types172,
	attr_flags172,
	gtypes172,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets172,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_C_AST_SHARED_TYPE_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION_GENERAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_EXTENSION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_COMMON",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_SEARCHER",
	names178,
	types178,
	attr_flags178,
	gtypes178,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets178,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_32_SEARCHER",
	names179,
	types179,
	attr_flags179,
	gtypes179,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets179,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_8_SEARCHER",
	names180,
	types180,
	attr_flags180,
	gtypes180,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets180,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC_INFORMATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"INTEGER_OVERFLOW_CHECKER",
	names182,
	types182,
	attr_flags182,
	gtypes182,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets182,
	NULL
},
{
	(long) 7,
	(long) 7,
	"STRING_TO_NUMERIC_CONVERTOR",
	names183,
	types183,
	attr_flags183,
	gtypes183,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets183,
	NULL
},
{
	(long) 11,
	(long) 11,
	"HEXADECIMAL_STRING_TO_INTEGER_CONVERTER",
	names184,
	types184,
	attr_flags184,
	gtypes184,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets184,
	NULL
},
{
	(long) 15,
	(long) 15,
	"STRING_TO_REAL_CONVERTOR",
	names185,
	types185,
	attr_flags185,
	gtypes185,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets185,
	NULL
},
{
	(long) 10,
	(long) 10,
	"STRING_TO_INTEGER_CONVERTOR",
	names186,
	types186,
	attr_flags186,
	gtypes186,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets186,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_OPERATING_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PART_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_COMPARABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_PLATFORM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MEM_CONST",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DT_DATE_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DT_SHARED_WEEK_DAYS_FROM_MONDAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DT_TIME_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DT_DATE_TIME_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_BUFFER",
	names200,
	types200,
	attr_flags200,
	gtypes200,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets200,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UTF8_BUFFER",
	names201,
	types201,
	attr_flags201,
	gtypes201,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets201,
	NULL
},
{
	(long) 10,
	(long) 10,
	"YY_UNICODE_BUFFER",
	names202,
	types202,
	attr_flags202,
	gtypes202,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets202,
	NULL
},
{
	(long) 12,
	(long) 12,
	"YY_FILE_BUFFER",
	names203,
	types203,
	attr_flags203,
	gtypes203,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets203,
	NULL
},
{
	(long) 14,
	(long) 14,
	"YY_UTF8_FILE_BUFFER",
	names204,
	types204,
	attr_flags204,
	gtypes204,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets204,
	NULL
},
{
	(long) 15,
	(long) 15,
	"YY_UNICODE_FILE_BUFFER",
	names205,
	types205,
	attr_flags205,
	gtypes205,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets205,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_IMPORTED_FORMATTERS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_UNICODE_STRUCTURE_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_EIFFEL_UNICODE_STRUCTURE_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_CHARACTER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_CALLBACKS_SOURCE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_CALLBACKS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_CALLBACKS_NULL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_FORWARD_CALLBACKS",
	names214,
	types214,
	attr_flags214,
	gtypes214,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets214,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_CALLBACKS_FILTER",
	names215,
	types215,
	attr_flags215,
	gtypes215,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets215,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_END_TAG_CHECKER",
	names216,
	types216,
	attr_flags216,
	gtypes216,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets216,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_SHARED_STRINGS_FILTER",
	names217,
	types217,
	attr_flags217,
	gtypes217,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets217,
	NULL
},
{
	(long) 6,
	(long) 6,
	"XM_CALLBACKS_TO_TREE_FILTER",
	names218,
	types218,
	attr_flags218,
	gtypes218,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets218,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_STOP_ON_ERROR_FILTER",
	names219,
	types219,
	attr_flags219,
	gtypes219,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets219,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XM_PARSER_STOP_ON_ERROR_FILTER",
	names220,
	types220,
	attr_flags220,
	gtypes220,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets220,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_SHARED_EIFFEL_COMPILER_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_EIFFEL_COMPILER_MODE",
	names222,
	types222,
	attr_flags222,
	gtypes222,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets222,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_CONFIG_SHARED_CONSTRUCT_TYPE_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names225,
	types225,
	attr_flags225,
	gtypes225,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets225,
	NULL
},
{
	(long) 3,
	(long) 3,
	"LINKED_LIST_CURSOR",
	names226,
	types226,
	attr_flags226,
	gtypes226,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets226,
	NULL
},
{
	(long) 1,
	(long) 1,
	"HASH_TABLE_CURSOR",
	names227,
	types227,
	attr_flags227,
	gtypes227,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets227,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ARRAYED_LIST_CURSOR",
	names228,
	types228,
	attr_flags228,
	gtypes228,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets228,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTION_MANAGER_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EXCEPTIONS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION",
	names232,
	types232,
	attr_flags232,
	gtypes232,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets232,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DEVELOPER_EXCEPTION",
	names233,
	types233,
	attr_flags233,
	gtypes233,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets233,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CONVERSION_FAILURE",
	names234,
	types234,
	attr_flags234,
	gtypes234,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets234,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MACHINE_EXCEPTION",
	names235,
	types235,
	attr_flags235,
	gtypes235,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets235,
	NULL
},
{
	(long) 7,
	(long) 7,
	"HARDWARE_EXCEPTION",
	names236,
	types236,
	attr_flags236,
	gtypes236,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets236,
	NULL
},
{
	(long) 7,
	(long) 7,
	"FLOATING_POINT_FAILURE",
	names237,
	types237,
	attr_flags237,
	gtypes237,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets237,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OPERATING_SYSTEM_EXCEPTION",
	names238,
	types238,
	attr_flags238,
	gtypes238,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets238,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_SIGNAL_FAILURE",
	names239,
	types239,
	attr_flags239,
	gtypes239,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets239,
	NULL
},
{
	(long) 10,
	(long) 10,
	"COM_FAILURE",
	names240,
	types240,
	attr_flags240,
	gtypes240,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets240,
	NULL
},
{
	(long) 8,
	(long) 8,
	"OPERATING_SYSTEM_FAILURE",
	names241,
	types241,
	attr_flags241,
	gtypes241,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets241,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OBSOLETE_EXCEPTION",
	names242,
	types242,
	attr_flags242,
	gtypes242,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets242,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXCEPTION_IN_SIGNAL_HANDLER_FAILURE",
	names243,
	types243,
	attr_flags243,
	gtypes243,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets243,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESUMPTION_FAILURE",
	names244,
	types244,
	attr_flags244,
	gtypes244,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets244,
	NULL
},
{
	(long) 7,
	(long) 7,
	"RESCUE_FAILURE",
	names245,
	types245,
	attr_flags245,
	gtypes245,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets245,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SYS_EXCEPTION",
	names246,
	types246,
	attr_flags246,
	gtypes246,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets246,
	NULL
},
{
	(long) 7,
	(long) 7,
	"OLD_VIOLATION",
	names247,
	types247,
	attr_flags247,
	gtypes247,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets247,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EIFFEL_RUNTIME_PANIC",
	names248,
	types248,
	attr_flags248,
	gtypes248,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets248,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIF_EXCEPTION",
	names249,
	types249,
	attr_flags249,
	gtypes249,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets249,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFEL_RUNTIME_EXCEPTION",
	names250,
	types250,
	attr_flags250,
	gtypes250,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets250,
	NULL
},
{
	(long) 8,
	(long) 8,
	"NO_MORE_MEMORY",
	names251,
	types251,
	attr_flags251,
	gtypes251,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets251,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EXTERNAL_FAILURE",
	names252,
	types252,
	attr_flags252,
	gtypes252,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets252,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DATA_EXCEPTION",
	names253,
	types253,
	attr_flags253,
	gtypes253,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets253,
	NULL
},
{
	(long) 7,
	(long) 7,
	"SERIALIZATION_FAILURE",
	names254,
	types254,
	attr_flags254,
	gtypes254,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets254,
	NULL
},
{
	(long) 7,
	(long) 7,
	"MISMATCH_FAILURE",
	names255,
	types255,
	attr_flags255,
	gtypes255,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets255,
	NULL
},
{
	(long) 9,
	(long) 9,
	"IO_FAILURE",
	names256,
	types256,
	attr_flags256,
	gtypes256,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets256,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LANGUAGE_EXCEPTION",
	names257,
	types257,
	attr_flags257,
	gtypes257,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets257,
	NULL
},
{
	(long) 7,
	(long) 7,
	"BAD_INSPECT_VALUE",
	names258,
	types258,
	attr_flags258,
	gtypes258,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets258,
	NULL
},
{
	(long) 9,
	(long) 9,
	"ROUTINE_FAILURE",
	names259,
	types259,
	attr_flags259,
	gtypes259,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets259,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_TARGET",
	names260,
	types260,
	attr_flags260,
	gtypes260,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets260,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VOID_ASSIGNED_TO_EXPANDED",
	names261,
	types261,
	attr_flags261,
	gtypes261,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets261,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EIFFELSTUDIO_SPECIFIC_LANGUAGE_EXCEPTION",
	names262,
	types262,
	attr_flags262,
	gtypes262,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets262,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ADDRESS_APPLIED_TO_MELTED_FEATURE",
	names263,
	types263,
	attr_flags263,
	gtypes263,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets263,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CREATE_ON_DEFERRED",
	names264,
	types264,
	attr_flags264,
	gtypes264,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets264,
	NULL
},
{
	(long) 7,
	(long) 7,
	"ASSERTION_VIOLATION",
	names265,
	types265,
	attr_flags265,
	gtypes265,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets265,
	NULL
},
{
	(long) 7,
	(long) 7,
	"LOOP_INVARIANT_VIOLATION",
	names266,
	types266,
	attr_flags266,
	gtypes266,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets266,
	NULL
},
{
	(long) 7,
	(long) 7,
	"VARIANT_VIOLATION",
	names267,
	types267,
	attr_flags267,
	gtypes267,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets267,
	NULL
},
{
	(long) 7,
	(long) 7,
	"CHECK_VIOLATION",
	names268,
	types268,
	attr_flags268,
	gtypes268,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets268,
	NULL
},
{
	(long) 8,
	(long) 8,
	"INVARIANT_VIOLATION",
	names269,
	types269,
	attr_flags269,
	gtypes269,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets269,
	NULL
},
{
	(long) 7,
	(long) 7,
	"POSTCONDITION_VIOLATION",
	names270,
	types270,
	attr_flags270,
	gtypes270,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets270,
	NULL
},
{
	(long) 7,
	(long) 7,
	"PRECONDITION_VIOLATION",
	names271,
	types271,
	attr_flags271,
	gtypes271,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets271,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_PRINTER",
	names272,
	types272,
	attr_flags272,
	gtypes272,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets272,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EWG_EIFFEL_COMPILER_SPECIFIC_PRINTER",
	names273,
	types273,
	attr_flags273,
	gtypes273,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets273,
	NULL
},
{
	(long) 4,
	(long) 4,
	"EWG_ABSTRACT_GENERATOR",
	names274,
	types274,
	attr_flags274,
	gtypes274,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets274,
	NULL
},
{
	(long) 4,
	(long) 4,
	"WRAPC_MAKEFILES_GENERATOR",
	names275,
	types275,
	attr_flags275,
	gtypes275,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets275,
	NULL
},
{
	(long) 4,
	(long) 4,
	"EWG_EIFFEL_API_SHARED",
	names276,
	types276,
	attr_flags276,
	gtypes276,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets276,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_ABSTRACT_C_DECLARATION_PRINTER",
	names277,
	types277,
	attr_flags277,
	gtypes277,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets277,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EWG_EIFFEL_TO_C_INDIRECTION_PRINTER",
	names278,
	types278,
	attr_flags278,
	gtypes278,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets278,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EWG_COMPOSITE_DECLARATION_PRINTER",
	names279,
	types279,
	attr_flags279,
	gtypes279,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets279,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EWG_C_TYPE_CAST_PRINTER",
	names280,
	types280,
	attr_flags280,
	gtypes280,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets280,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_C_CALLING_CONVENTION_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REFLECTED_OBJECT",
	names284,
	types284,
	attr_flags284,
	gtypes284,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets284,
	NULL
},
{
	(long) 0,
	(long) 0,
	"REFLECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RT_DBG_INTERNAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"REFLECTED_COPY_SEMANTICS_OBJECT",
	names288,
	types288,
	attr_flags288,
	gtypes288,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets288,
	NULL
},
{
	(long) 3,
	(long) 3,
	"REFLECTED_REFERENCE_OBJECT",
	names289,
	types289,
	attr_flags289,
	gtypes289,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets289,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names290,
	types290,
	attr_flags290,
	gtypes290,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets290,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names291,
	types291,
	attr_flags291,
	gtypes291,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets291,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names292,
	types292,
	attr_flags292,
	gtypes292,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets292,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names293,
	types293,
	attr_flags293,
	gtypes293,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets293,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names294,
	types294,
	attr_flags294,
	gtypes294,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets294,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names295,
	types295,
	attr_flags295,
	gtypes295,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets295,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names296,
	types296,
	attr_flags296,
	gtypes296,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets296,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names297,
	types297,
	attr_flags297,
	gtypes297,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets297,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names298,
	types298,
	attr_flags298,
	gtypes298,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets298,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names299,
	types299,
	attr_flags299,
	gtypes299,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets299,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names300,
	types300,
	attr_flags300,
	gtypes300,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets300,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TO_SPECIAL",
	names301,
	types301,
	attr_flags301,
	gtypes301,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets301,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_C_AST_DECLARATION_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_C_AST_TYPE_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_SHARED_TEMPLATE_EXPANDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_STANDARD_FILES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_CONFIG_ELEMENT_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_CONFIG_WRAPPER_CLAUSE",
	names315,
	types315,
	attr_flags315,
	gtypes315,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets315,
	NULL
},
{
	(long) 2,
	(long) 2,
	"WRAPC_CONFIG_MACRO_WRAPPER_CLAUSE",
	names316,
	types316,
	attr_flags316,
	gtypes316,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets316,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_CONFIG_NONE_WRAPPER_CLAUSE",
	names317,
	types317,
	attr_flags317,
	gtypes317,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets317,
	NULL
},
{
	(long) 6,
	(long) 6,
	"EWG_CONFIG_DEFAULT_WRAPPER_CLAUSE",
	names318,
	types318,
	attr_flags318,
	gtypes318,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets318,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DISPOSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 2,
	"MANAGED_POINTER",
	names320,
	types320,
	attr_flags320,
	gtypes320,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets320,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PROCESS_UNIX_PIPE",
	names321,
	types321,
	attr_flags321,
	gtypes321,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets321,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MEMORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x0400,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NATIVE_STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"NATIVE_STRING",
	names324,
	types324,
	attr_flags324,
	gtypes324,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets324,
	NULL
},
{
	(long) 5,
	(long) 5,
	"FILE_INFO",
	names325,
	types325,
	attr_flags325,
	gtypes325,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets325,
	NULL
},
{
	(long) 5,
	(long) 5,
	"UNIX_FILE_INFO",
	names326,
	types326,
	attr_flags326,
	gtypes326,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets326,
	NULL
},
{
	(long) 6,
	(long) 6,
	"DIRECTORY",
	names327,
	types327,
	attr_flags327,
	gtypes327,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets327,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EXECUTION_ENVIRONMENT",
	names328,
	types328,
	attr_flags328,
	gtypes328,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets328,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PROCESS_INFO",
	names329,
	types329,
	attr_flags329,
	gtypes329,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets329,
	NULL
},
{
	(long) 1,
	(long) 1,
	"PROCESS_INFO_IMP",
	names330,
	types330,
	attr_flags330,
	gtypes330,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets330,
	NULL
},
{
	(long) 29,
	(long) 29,
	"PROCESS_UNIX_PROCESS_MANAGER",
	names331,
	types331,
	attr_flags331,
	gtypes331,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets331,
	NULL
},
{
	(long) 34,
	(long) 34,
	"BASE_PROCESS_IMP",
	names332,
	types332,
	attr_flags332,
	gtypes332,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets332,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_SPECIAL_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"STRING_HANDLER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_UNICODE_CHARACTER_BUFFER",
	names335,
	types335,
	attr_flags335,
	gtypes335,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets335,
	NULL
},
{
	(long) 2,
	(long) 2,
	"KL_CHARACTER_BUFFER",
	names336,
	types336,
	attr_flags336,
	gtypes336,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets336,
	NULL
},
{
	(long) 2,
	(long) 2,
	"C_STRING",
	names337,
	types337,
	attr_flags337,
	gtypes337,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets337,
	NULL
},
{
	(long) 13,
	(long) 13,
	"IO_MEDIUM",
	names338,
	types338,
	attr_flags338,
	gtypes338,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets338,
	NULL
},
{
	(long) 20,
	(long) 20,
	"UNIX_UNNAMED_PIPE",
	names339,
	types339,
	attr_flags339,
	gtypes339,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets339,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DEBUG_OUTPUT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 15,
	(long) 15,
	"RT_DBG_CALL_RECORD",
	names341,
	types341,
	attr_flags341,
	gtypes341,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets341,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ABSTRACT_SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"RT_DBG_VALUE_RECORD",
	names343,
	types343,
	attr_flags343,
	gtypes343,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets343,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names344,
	types344,
	attr_flags344,
	gtypes344,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets344,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names345,
	types345,
	attr_flags345,
	gtypes345,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets345,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names346,
	types346,
	attr_flags346,
	gtypes346,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets346,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names347,
	types347,
	attr_flags347,
	gtypes347,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets347,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names348,
	types348,
	attr_flags348,
	gtypes348,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets348,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names349,
	types349,
	attr_flags349,
	gtypes349,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets349,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names350,
	types350,
	attr_flags350,
	gtypes350,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets350,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names351,
	types351,
	attr_flags351,
	gtypes351,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets351,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names352,
	types352,
	attr_flags352,
	gtypes352,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets352,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names353,
	types353,
	attr_flags353,
	gtypes353,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets353,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names354,
	types354,
	attr_flags354,
	gtypes354,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets354,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names355,
	types355,
	attr_flags355,
	gtypes355,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets355,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names356,
	types356,
	attr_flags356,
	gtypes356,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets356,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names357,
	types357,
	attr_flags357,
	gtypes357,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets357,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_LOCAL_RECORD",
	names358,
	types358,
	attr_flags358,
	gtypes358,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets358,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names359,
	types359,
	attr_flags359,
	gtypes359,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets359,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names360,
	types360,
	attr_flags360,
	gtypes360,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets360,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names361,
	types361,
	attr_flags361,
	gtypes361,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets361,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names362,
	types362,
	attr_flags362,
	gtypes362,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets362,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names363,
	types363,
	attr_flags363,
	gtypes363,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets363,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names364,
	types364,
	attr_flags364,
	gtypes364,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets364,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names365,
	types365,
	attr_flags365,
	gtypes365,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets365,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names366,
	types366,
	attr_flags366,
	gtypes366,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets366,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names367,
	types367,
	attr_flags367,
	gtypes367,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets367,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names368,
	types368,
	attr_flags368,
	gtypes368,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets368,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names369,
	types369,
	attr_flags369,
	gtypes369,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets369,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names370,
	types370,
	attr_flags370,
	gtypes370,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets370,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names371,
	types371,
	attr_flags371,
	gtypes371,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets371,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names372,
	types372,
	attr_flags372,
	gtypes372,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets372,
	NULL
},
{
	(long) 6,
	(long) 6,
	"RT_DBG_ATTRIBUTE_RECORD",
	names373,
	types373,
	attr_flags373,
	gtypes373,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets373,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names374,
	types374,
	attr_flags374,
	gtypes374,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets374,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names375,
	types375,
	attr_flags375,
	gtypes375,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets375,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names376,
	types376,
	attr_flags376,
	gtypes376,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets376,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names377,
	types377,
	attr_flags377,
	gtypes377,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets377,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names378,
	types378,
	attr_flags378,
	gtypes378,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets378,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names379,
	types379,
	attr_flags379,
	gtypes379,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets379,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names380,
	types380,
	attr_flags380,
	gtypes380,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets380,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names381,
	types381,
	attr_flags381,
	gtypes381,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets381,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names382,
	types382,
	attr_flags382,
	gtypes382,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets382,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names383,
	types383,
	attr_flags383,
	gtypes383,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets383,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names384,
	types384,
	attr_flags384,
	gtypes384,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets384,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names385,
	types385,
	attr_flags385,
	gtypes385,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets385,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names386,
	types386,
	attr_flags386,
	gtypes386,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets386,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names387,
	types387,
	attr_flags387,
	gtypes387,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets387,
	NULL
},
{
	(long) 5,
	(long) 5,
	"RT_DBG_FIELD_RECORD",
	names388,
	types388,
	attr_flags388,
	gtypes388,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets388,
	NULL
},
{
	(long) 0,
	(long) 0,
	"NUMERIC",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_QUEUE_ITERATION_CURSOR",
	names402,
	types402,
	attr_flags402,
	gtypes402,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets402,
	NULL
},
{
	(long) 2,
	(long) 2,
	"FILE_ITERATION_CURSOR",
	names403,
	types403,
	attr_flags403,
	gtypes403,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets403,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_MARKUP_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_IMPORTED_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_DIRECTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS_32",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"STRING_ITERATION_CURSOR",
	names426,
	types426,
	attr_flags426,
	gtypes426,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets426,
	NULL
},
{
	(long) 0,
	(long) 0,
	"ARGUMENTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_ARGUMENTS",
	names428,
	types428,
	attr_flags428,
	gtypes428,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets428,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TABLE_ITERABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TYPED_INDEXABLE_ITERATION_CURSOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names458,
	types458,
	attr_flags458,
	gtypes458,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets458,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names459,
	types459,
	attr_flags459,
	gtypes459,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets459,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names460,
	types460,
	attr_flags460,
	gtypes460,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets460,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names461,
	types461,
	attr_flags461,
	gtypes461,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets461,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names462,
	types462,
	attr_flags462,
	gtypes462,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets462,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names463,
	types463,
	attr_flags463,
	gtypes463,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets463,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names464,
	types464,
	attr_flags464,
	gtypes464,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets464,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names465,
	types465,
	attr_flags465,
	gtypes465,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets465,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names466,
	types466,
	attr_flags466,
	gtypes466,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets466,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names467,
	types467,
	attr_flags467,
	gtypes467,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets467,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names468,
	types468,
	attr_flags468,
	gtypes468,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets468,
	NULL
},
{
	(long) 7,
	(long) 6,
	"READABLE_INDEXABLE_ITERATION_CURSOR",
	names469,
	types469,
	attr_flags469,
	gtypes469,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets469,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names470,
	types470,
	attr_flags470,
	gtypes470,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets470,
	NULL
},
{
	(long) 8,
	(long) 7,
	"LINKED_LIST_ITERATION_CURSOR",
	names471,
	types471,
	attr_flags471,
	gtypes471,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets471,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names472,
	types472,
	attr_flags472,
	gtypes472,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets472,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names473,
	types473,
	attr_flags473,
	gtypes473,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets473,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names474,
	types474,
	attr_flags474,
	gtypes474,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets474,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names475,
	types475,
	attr_flags475,
	gtypes475,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets475,
	NULL
},
{
	(long) 7,
	(long) 6,
	"HASH_TABLE_ITERATION_CURSOR",
	names476,
	types476,
	attr_flags476,
	gtypes476,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets476,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names477,
	types477,
	attr_flags477,
	gtypes477,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets477,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names478,
	types478,
	attr_flags478,
	gtypes478,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets478,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names479,
	types479,
	attr_flags479,
	gtypes479,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets479,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names480,
	types480,
	attr_flags480,
	gtypes480,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets480,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names481,
	types481,
	attr_flags481,
	gtypes481,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets481,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names482,
	types482,
	attr_flags482,
	gtypes482,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets482,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names483,
	types483,
	attr_flags483,
	gtypes483,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets483,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names484,
	types484,
	attr_flags484,
	gtypes484,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets484,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names485,
	types485,
	attr_flags485,
	gtypes485,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets485,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names486,
	types486,
	attr_flags486,
	gtypes486,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets486,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names487,
	types487,
	attr_flags487,
	gtypes487,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets487,
	NULL
},
{
	(long) 3,
	(long) 3,
	"GENERAL_SPECIAL_ITERATION_CURSOR",
	names488,
	types488,
	attr_flags488,
	gtypes488,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets488,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names489,
	types489,
	attr_flags489,
	gtypes489,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets489,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names490,
	types490,
	attr_flags490,
	gtypes490,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets490,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names491,
	types491,
	attr_flags491,
	gtypes491,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets491,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names492,
	types492,
	attr_flags492,
	gtypes492,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets492,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names493,
	types493,
	attr_flags493,
	gtypes493,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets493,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names494,
	types494,
	attr_flags494,
	gtypes494,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets494,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names495,
	types495,
	attr_flags495,
	gtypes495,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets495,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names496,
	types496,
	attr_flags496,
	gtypes496,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets496,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names497,
	types497,
	attr_flags497,
	gtypes497,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets497,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names498,
	types498,
	attr_flags498,
	gtypes498,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets498,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names499,
	types499,
	attr_flags499,
	gtypes499,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets499,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_LIST_ITERATION_CURSOR",
	names500,
	types500,
	attr_flags500,
	gtypes500,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets500,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32_ITERATION_CURSOR",
	names501,
	types501,
	attr_flags501,
	gtypes501,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets501,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8_ITERATION_CURSOR",
	names502,
	types502,
	attr_flags502,
	gtypes502,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets502,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names503,
	types503,
	attr_flags503,
	gtypes503,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets503,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names504,
	types504,
	attr_flags504,
	gtypes504,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets504,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names505,
	types505,
	attr_flags505,
	gtypes505,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets505,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names506,
	types506,
	attr_flags506,
	gtypes506,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets506,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names507,
	types507,
	attr_flags507,
	gtypes507,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets507,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names508,
	types508,
	attr_flags508,
	gtypes508,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets508,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names509,
	types509,
	attr_flags509,
	gtypes509,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets509,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names510,
	types510,
	attr_flags510,
	gtypes510,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets510,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names511,
	types511,
	attr_flags511,
	gtypes511,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets511,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names512,
	types512,
	attr_flags512,
	gtypes512,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets512,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names513,
	types513,
	attr_flags513,
	gtypes513,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets513,
	NULL
},
{
	(long) 5,
	(long) 5,
	"ARRAY_ITERATION_CURSOR",
	names514,
	types514,
	attr_flags514,
	gtypes514,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets514,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names515,
	types515,
	attr_flags515,
	gtypes515,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets515,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names516,
	types516,
	attr_flags516,
	gtypes516,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets516,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names517,
	types517,
	attr_flags517,
	gtypes517,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets517,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names518,
	types518,
	attr_flags518,
	gtypes518,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets518,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names519,
	types519,
	attr_flags519,
	gtypes519,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets519,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names520,
	types520,
	attr_flags520,
	gtypes520,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets520,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names521,
	types521,
	attr_flags521,
	gtypes521,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets521,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names522,
	types522,
	attr_flags522,
	gtypes522,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets522,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names523,
	types523,
	attr_flags523,
	gtypes523,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets523,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names524,
	types524,
	attr_flags524,
	gtypes524,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets524,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names525,
	types525,
	attr_flags525,
	gtypes525,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets525,
	NULL
},
{
	(long) 3,
	(long) 3,
	"SPECIAL_ITERATION_CURSOR",
	names526,
	types526,
	attr_flags526,
	gtypes526,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets526,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names527,
	types527,
	attr_flags527,
	gtypes527,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets527,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names528,
	types528,
	attr_flags528,
	gtypes528,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets528,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names529,
	types529,
	attr_flags529,
	gtypes529,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets529,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names530,
	types530,
	attr_flags530,
	gtypes530,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets530,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names531,
	types531,
	attr_flags531,
	gtypes531,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets531,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names532,
	types532,
	attr_flags532,
	gtypes532,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets532,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names533,
	types533,
	attr_flags533,
	gtypes533,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets533,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names534,
	types534,
	attr_flags534,
	gtypes534,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets534,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names535,
	types535,
	attr_flags535,
	gtypes535,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets535,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names536,
	types536,
	attr_flags536,
	gtypes536,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets536,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names537,
	types537,
	attr_flags537,
	gtypes537,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets537,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CONTAINER",
	names538,
	types538,
	attr_flags538,
	gtypes538,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets538,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names539,
	types539,
	attr_flags539,
	gtypes539,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets539,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names540,
	types540,
	attr_flags540,
	gtypes540,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets540,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names541,
	types541,
	attr_flags541,
	gtypes541,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets541,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names542,
	types542,
	attr_flags542,
	gtypes542,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets542,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names543,
	types543,
	attr_flags543,
	gtypes543,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets543,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names544,
	types544,
	attr_flags544,
	gtypes544,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets544,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names545,
	types545,
	attr_flags545,
	gtypes545,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets545,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names546,
	types546,
	attr_flags546,
	gtypes546,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets546,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names547,
	types547,
	attr_flags547,
	gtypes547,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets547,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names548,
	types548,
	attr_flags548,
	gtypes548,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets548,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names549,
	types549,
	attr_flags549,
	gtypes549,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets549,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TRAVERSABLE",
	names550,
	types550,
	attr_flags550,
	gtypes550,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets550,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names551,
	types551,
	attr_flags551,
	gtypes551,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets551,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names552,
	types552,
	attr_flags552,
	gtypes552,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets552,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names553,
	types553,
	attr_flags553,
	gtypes553,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets553,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names554,
	types554,
	attr_flags554,
	gtypes554,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets554,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names555,
	types555,
	attr_flags555,
	gtypes555,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets555,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names556,
	types556,
	attr_flags556,
	gtypes556,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets556,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names557,
	types557,
	attr_flags557,
	gtypes557,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets557,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names558,
	types558,
	attr_flags558,
	gtypes558,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets558,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names559,
	types559,
	attr_flags559,
	gtypes559,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets559,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names560,
	types560,
	attr_flags560,
	gtypes560,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets560,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names561,
	types561,
	attr_flags561,
	gtypes561,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets561,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LINEAR",
	names562,
	types562,
	attr_flags562,
	gtypes562,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets562,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names563,
	types563,
	attr_flags563,
	gtypes563,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets563,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names564,
	types564,
	attr_flags564,
	gtypes564,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets564,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names565,
	types565,
	attr_flags565,
	gtypes565,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets565,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names566,
	types566,
	attr_flags566,
	gtypes566,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets566,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names567,
	types567,
	attr_flags567,
	gtypes567,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets567,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names568,
	types568,
	attr_flags568,
	gtypes568,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets568,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names569,
	types569,
	attr_flags569,
	gtypes569,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets569,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names570,
	types570,
	attr_flags570,
	gtypes570,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets570,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names571,
	types571,
	attr_flags571,
	gtypes571,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets571,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names572,
	types572,
	attr_flags572,
	gtypes572,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets572,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names573,
	types573,
	attr_flags573,
	gtypes573,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets573,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BILINEAR",
	names574,
	types574,
	attr_flags574,
	gtypes574,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets574,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names575,
	types575,
	attr_flags575,
	gtypes575,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets575,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names576,
	types576,
	attr_flags576,
	gtypes576,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets576,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names577,
	types577,
	attr_flags577,
	gtypes577,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets577,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names578,
	types578,
	attr_flags578,
	gtypes578,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets578,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names579,
	types579,
	attr_flags579,
	gtypes579,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets579,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names580,
	types580,
	attr_flags580,
	gtypes580,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets580,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names581,
	types581,
	attr_flags581,
	gtypes581,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets581,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names582,
	types582,
	attr_flags582,
	gtypes582,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets582,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names583,
	types583,
	attr_flags583,
	gtypes583,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets583,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names584,
	types584,
	attr_flags584,
	gtypes584,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets584,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names585,
	types585,
	attr_flags585,
	gtypes585,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets585,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COLLECTION",
	names586,
	types586,
	attr_flags586,
	gtypes586,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets586,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SET",
	names587,
	types587,
	attr_flags587,
	gtypes587,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets587,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names588,
	types588,
	attr_flags588,
	gtypes588,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets588,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names589,
	types589,
	attr_flags589,
	gtypes589,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets589,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names590,
	types590,
	attr_flags590,
	gtypes590,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets590,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names591,
	types591,
	attr_flags591,
	gtypes591,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets591,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names592,
	types592,
	attr_flags592,
	gtypes592,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets592,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names593,
	types593,
	attr_flags593,
	gtypes593,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets593,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names594,
	types594,
	attr_flags594,
	gtypes594,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets594,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names595,
	types595,
	attr_flags595,
	gtypes595,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets595,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names596,
	types596,
	attr_flags596,
	gtypes596,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets596,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names597,
	types597,
	attr_flags597,
	gtypes597,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets597,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names598,
	types598,
	attr_flags598,
	gtypes598,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets598,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BAG",
	names599,
	types599,
	attr_flags599,
	gtypes599,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets599,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names600,
	types600,
	attr_flags600,
	gtypes600,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets600,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names601,
	types601,
	attr_flags601,
	gtypes601,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets601,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names602,
	types602,
	attr_flags602,
	gtypes602,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets602,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names603,
	types603,
	attr_flags603,
	gtypes603,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets603,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names604,
	types604,
	attr_flags604,
	gtypes604,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets604,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names605,
	types605,
	attr_flags605,
	gtypes605,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets605,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names606,
	types606,
	attr_flags606,
	gtypes606,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets606,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names607,
	types607,
	attr_flags607,
	gtypes607,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets607,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names608,
	types608,
	attr_flags608,
	gtypes608,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets608,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names609,
	types609,
	attr_flags609,
	gtypes609,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets609,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names610,
	types610,
	attr_flags610,
	gtypes610,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets610,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names611,
	types611,
	attr_flags611,
	gtypes611,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets611,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names612,
	types612,
	attr_flags612,
	gtypes612,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets612,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names613,
	types613,
	attr_flags613,
	gtypes613,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets613,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TABLE",
	names614,
	types614,
	attr_flags614,
	gtypes614,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets614,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names615,
	types615,
	attr_flags615,
	gtypes615,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets615,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names616,
	types616,
	attr_flags616,
	gtypes616,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets616,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names617,
	types617,
	attr_flags617,
	gtypes617,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets617,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names618,
	types618,
	attr_flags618,
	gtypes618,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets618,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names619,
	types619,
	attr_flags619,
	gtypes619,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets619,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names620,
	types620,
	attr_flags620,
	gtypes620,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets620,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names621,
	types621,
	attr_flags621,
	gtypes621,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets621,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names622,
	types622,
	attr_flags622,
	gtypes622,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets622,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names623,
	types623,
	attr_flags623,
	gtypes623,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets623,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names624,
	types624,
	attr_flags624,
	gtypes624,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets624,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names625,
	types625,
	attr_flags625,
	gtypes625,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets625,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names626,
	types626,
	attr_flags626,
	gtypes626,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets626,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names627,
	types627,
	attr_flags627,
	gtypes627,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets627,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names628,
	types628,
	attr_flags628,
	gtypes628,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets628,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_TABLE",
	names629,
	types629,
	attr_flags629,
	gtypes629,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets629,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names630,
	types630,
	attr_flags630,
	gtypes630,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets630,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names631,
	types631,
	attr_flags631,
	gtypes631,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets631,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names632,
	types632,
	attr_flags632,
	gtypes632,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets632,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names633,
	types633,
	attr_flags633,
	gtypes633,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets633,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names634,
	types634,
	attr_flags634,
	gtypes634,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets634,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names635,
	types635,
	attr_flags635,
	gtypes635,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets635,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names636,
	types636,
	attr_flags636,
	gtypes636,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets636,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names637,
	types637,
	attr_flags637,
	gtypes637,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets637,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names638,
	types638,
	attr_flags638,
	gtypes638,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets638,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names639,
	types639,
	attr_flags639,
	gtypes639,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets639,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names640,
	types640,
	attr_flags640,
	gtypes640,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets640,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ACTIVE",
	names641,
	types641,
	attr_flags641,
	gtypes641,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets641,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names642,
	types642,
	attr_flags642,
	gtypes642,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets642,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names643,
	types643,
	attr_flags643,
	gtypes643,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets643,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names644,
	types644,
	attr_flags644,
	gtypes644,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets644,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names645,
	types645,
	attr_flags645,
	gtypes645,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets645,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names646,
	types646,
	attr_flags646,
	gtypes646,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets646,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names647,
	types647,
	attr_flags647,
	gtypes647,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets647,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names648,
	types648,
	attr_flags648,
	gtypes648,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets648,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names649,
	types649,
	attr_flags649,
	gtypes649,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets649,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names650,
	types650,
	attr_flags650,
	gtypes650,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets650,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names651,
	types651,
	attr_flags651,
	gtypes651,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets651,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names652,
	types652,
	attr_flags652,
	gtypes652,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets652,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CURSOR_STRUCTURE",
	names653,
	types653,
	attr_flags653,
	gtypes653,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets653,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names654,
	types654,
	attr_flags654,
	gtypes654,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets654,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names655,
	types655,
	attr_flags655,
	gtypes655,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets655,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names656,
	types656,
	attr_flags656,
	gtypes656,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets656,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names657,
	types657,
	attr_flags657,
	gtypes657,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets657,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names658,
	types658,
	attr_flags658,
	gtypes658,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets658,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names659,
	types659,
	attr_flags659,
	gtypes659,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets659,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names660,
	types660,
	attr_flags660,
	gtypes660,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets660,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names661,
	types661,
	attr_flags661,
	gtypes661,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets661,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names662,
	types662,
	attr_flags662,
	gtypes662,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets662,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names663,
	types663,
	attr_flags663,
	gtypes663,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets663,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names664,
	types664,
	attr_flags664,
	gtypes664,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets664,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOX",
	names665,
	types665,
	attr_flags665,
	gtypes665,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets665,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INFINITE",
	names666,
	types666,
	attr_flags666,
	gtypes666,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets666,
	NULL
},
{
	(long) 1,
	(long) 1,
	"COUNTABLE",
	names667,
	types667,
	attr_flags667,
	gtypes667,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets667,
	NULL
},
{
	(long) 2,
	(long) 2,
	"COUNTABLE_SEQUENCE",
	names668,
	types668,
	attr_flags668,
	gtypes668,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets668,
	NULL
},
{
	(long) 2,
	(long) 2,
	"PRIMES",
	names669,
	types669,
	attr_flags669,
	gtypes669,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets669,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names670,
	types670,
	attr_flags670,
	gtypes670,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets670,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names671,
	types671,
	attr_flags671,
	gtypes671,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets671,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names672,
	types672,
	attr_flags672,
	gtypes672,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets672,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names673,
	types673,
	attr_flags673,
	gtypes673,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets673,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names674,
	types674,
	attr_flags674,
	gtypes674,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets674,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names675,
	types675,
	attr_flags675,
	gtypes675,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets675,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names676,
	types676,
	attr_flags676,
	gtypes676,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets676,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names677,
	types677,
	attr_flags677,
	gtypes677,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets677,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names678,
	types678,
	attr_flags678,
	gtypes678,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets678,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names679,
	types679,
	attr_flags679,
	gtypes679,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets679,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names680,
	types680,
	attr_flags680,
	gtypes680,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets680,
	NULL
},
{
	(long) 1,
	(long) 1,
	"FINITE",
	names681,
	types681,
	attr_flags681,
	gtypes681,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets681,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DISPENSER",
	names682,
	types682,
	attr_flags682,
	gtypes682,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets682,
	NULL
},
{
	(long) 1,
	(long) 1,
	"QUEUE",
	names683,
	types683,
	attr_flags683,
	gtypes683,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets683,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names684,
	types684,
	attr_flags684,
	gtypes684,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets684,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names685,
	types685,
	attr_flags685,
	gtypes685,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets685,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names686,
	types686,
	attr_flags686,
	gtypes686,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets686,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names687,
	types687,
	attr_flags687,
	gtypes687,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets687,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names688,
	types688,
	attr_flags688,
	gtypes688,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets688,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names689,
	types689,
	attr_flags689,
	gtypes689,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets689,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names690,
	types690,
	attr_flags690,
	gtypes690,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets690,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names691,
	types691,
	attr_flags691,
	gtypes691,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets691,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names692,
	types692,
	attr_flags692,
	gtypes692,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets692,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names693,
	types693,
	attr_flags693,
	gtypes693,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets693,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names694,
	types694,
	attr_flags694,
	gtypes694,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets694,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOUNDED",
	names695,
	types695,
	attr_flags695,
	gtypes695,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets695,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names696,
	types696,
	attr_flags696,
	gtypes696,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets696,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names697,
	types697,
	attr_flags697,
	gtypes697,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets697,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names698,
	types698,
	attr_flags698,
	gtypes698,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets698,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names699,
	types699,
	attr_flags699,
	gtypes699,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets699,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names700,
	types700,
	attr_flags700,
	gtypes700,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets700,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names701,
	types701,
	attr_flags701,
	gtypes701,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets701,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names702,
	types702,
	attr_flags702,
	gtypes702,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets702,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names703,
	types703,
	attr_flags703,
	gtypes703,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets703,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names704,
	types704,
	attr_flags704,
	gtypes704,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets704,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names705,
	types705,
	attr_flags705,
	gtypes705,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets705,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names706,
	types706,
	attr_flags706,
	gtypes706,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets706,
	NULL
},
{
	(long) 1,
	(long) 1,
	"RESIZABLE",
	names707,
	types707,
	attr_flags707,
	gtypes707,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets707,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names708,
	types708,
	attr_flags708,
	gtypes708,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets708,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names709,
	types709,
	attr_flags709,
	gtypes709,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets709,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names710,
	types710,
	attr_flags710,
	gtypes710,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets710,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names711,
	types711,
	attr_flags711,
	gtypes711,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets711,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names712,
	types712,
	attr_flags712,
	gtypes712,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets712,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names713,
	types713,
	attr_flags713,
	gtypes713,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets713,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names714,
	types714,
	attr_flags714,
	gtypes714,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets714,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names715,
	types715,
	attr_flags715,
	gtypes715,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets715,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names716,
	types716,
	attr_flags716,
	gtypes716,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets716,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names717,
	types717,
	attr_flags717,
	gtypes717,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets717,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names718,
	types718,
	attr_flags718,
	gtypes718,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets718,
	NULL
},
{
	(long) 1,
	(long) 1,
	"SEQUENCE",
	names719,
	types719,
	attr_flags719,
	gtypes719,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets719,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names720,
	types720,
	attr_flags720,
	gtypes720,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets720,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names721,
	types721,
	attr_flags721,
	gtypes721,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets721,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names722,
	types722,
	attr_flags722,
	gtypes722,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets722,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names723,
	types723,
	attr_flags723,
	gtypes723,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets723,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names724,
	types724,
	attr_flags724,
	gtypes724,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets724,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names725,
	types725,
	attr_flags725,
	gtypes725,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets725,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names726,
	types726,
	attr_flags726,
	gtypes726,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets726,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names727,
	types727,
	attr_flags727,
	gtypes727,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets727,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names728,
	types728,
	attr_flags728,
	gtypes728,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets728,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names729,
	types729,
	attr_flags729,
	gtypes729,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets729,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names730,
	types730,
	attr_flags730,
	gtypes730,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets730,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UNBOUNDED",
	names731,
	types731,
	attr_flags731,
	gtypes731,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets731,
	NULL
},
{
	(long) 20,
	(long) 19,
	"FILE",
	names732,
	types732,
	attr_flags732,
	gtypes732,
	(uint16) 0x5400,
	(void (*)()) 0,
	offsets732,
	NULL
},
{
	(long) 21,
	(long) 20,
	"RAW_FILE",
	names733,
	types733,
	attr_flags733,
	gtypes733,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets733,
	NULL
},
{
	(long) 23,
	(long) 22,
	"PLAIN_TEXT_FILE",
	names734,
	types734,
	attr_flags734,
	gtypes734,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets734,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"READABLE_INDEXABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"SPECIAL",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x2000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names759,
	types759,
	attr_flags759,
	gtypes759,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets759,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names760,
	types760,
	attr_flags760,
	gtypes760,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets760,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names761,
	types761,
	attr_flags761,
	gtypes761,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets761,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names762,
	types762,
	attr_flags762,
	gtypes762,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets762,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names763,
	types763,
	attr_flags763,
	gtypes763,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets763,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names764,
	types764,
	attr_flags764,
	gtypes764,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets764,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names765,
	types765,
	attr_flags765,
	gtypes765,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets765,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names766,
	types766,
	attr_flags766,
	gtypes766,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets766,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names767,
	types767,
	attr_flags767,
	gtypes767,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets767,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names768,
	types768,
	attr_flags768,
	gtypes768,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets768,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names769,
	types769,
	attr_flags769,
	gtypes769,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets769,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INDEXABLE",
	names770,
	types770,
	attr_flags770,
	gtypes770,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets770,
	NULL
},
{
	(long) 3,
	(long) 3,
	"INTEGER_INTERVAL",
	names771,
	types771,
	attr_flags771,
	gtypes771,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets771,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names772,
	types772,
	attr_flags772,
	gtypes772,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets772,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names773,
	types773,
	attr_flags773,
	gtypes773,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets773,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names774,
	types774,
	attr_flags774,
	gtypes774,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets774,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names775,
	types775,
	attr_flags775,
	gtypes775,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets775,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names776,
	types776,
	attr_flags776,
	gtypes776,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets776,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names777,
	types777,
	attr_flags777,
	gtypes777,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets777,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names778,
	types778,
	attr_flags778,
	gtypes778,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets778,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names779,
	types779,
	attr_flags779,
	gtypes779,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets779,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names780,
	types780,
	attr_flags780,
	gtypes780,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets780,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names781,
	types781,
	attr_flags781,
	gtypes781,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets781,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names782,
	types782,
	attr_flags782,
	gtypes782,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets782,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAY",
	names783,
	types783,
	attr_flags783,
	gtypes783,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets783,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names784,
	types784,
	attr_flags784,
	gtypes784,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets784,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names785,
	types785,
	attr_flags785,
	gtypes785,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets785,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names786,
	types786,
	attr_flags786,
	gtypes786,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets786,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names787,
	types787,
	attr_flags787,
	gtypes787,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets787,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names788,
	types788,
	attr_flags788,
	gtypes788,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets788,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_ARRAY",
	names789,
	types789,
	attr_flags789,
	gtypes789,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets789,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names790,
	types790,
	attr_flags790,
	gtypes790,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets790,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names791,
	types791,
	attr_flags791,
	gtypes791,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets791,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names792,
	types792,
	attr_flags792,
	gtypes792,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets792,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names793,
	types793,
	attr_flags793,
	gtypes793,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets793,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names794,
	types794,
	attr_flags794,
	gtypes794,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets794,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names795,
	types795,
	attr_flags795,
	gtypes795,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets795,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names796,
	types796,
	attr_flags796,
	gtypes796,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets796,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names797,
	types797,
	attr_flags797,
	gtypes797,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets797,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names798,
	types798,
	attr_flags798,
	gtypes798,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets798,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names799,
	types799,
	attr_flags799,
	gtypes799,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets799,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names800,
	types800,
	attr_flags800,
	gtypes800,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets800,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHAIN",
	names801,
	types801,
	attr_flags801,
	gtypes801,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets801,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names802,
	types802,
	attr_flags802,
	gtypes802,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets802,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names803,
	types803,
	attr_flags803,
	gtypes803,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets803,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names804,
	types804,
	attr_flags804,
	gtypes804,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets804,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names805,
	types805,
	attr_flags805,
	gtypes805,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets805,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names806,
	types806,
	attr_flags806,
	gtypes806,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets806,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names807,
	types807,
	attr_flags807,
	gtypes807,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets807,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names808,
	types808,
	attr_flags808,
	gtypes808,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets808,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names809,
	types809,
	attr_flags809,
	gtypes809,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets809,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names810,
	types810,
	attr_flags810,
	gtypes810,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets810,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names811,
	types811,
	attr_flags811,
	gtypes811,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets811,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names812,
	types812,
	attr_flags812,
	gtypes812,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets812,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_CHAIN",
	names813,
	types813,
	attr_flags813,
	gtypes813,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets813,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names814,
	types814,
	attr_flags814,
	gtypes814,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets814,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names815,
	types815,
	attr_flags815,
	gtypes815,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets815,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names816,
	types816,
	attr_flags816,
	gtypes816,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets816,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names817,
	types817,
	attr_flags817,
	gtypes817,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets817,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names818,
	types818,
	attr_flags818,
	gtypes818,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets818,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names819,
	types819,
	attr_flags819,
	gtypes819,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets819,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names820,
	types820,
	attr_flags820,
	gtypes820,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets820,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names821,
	types821,
	attr_flags821,
	gtypes821,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets821,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names822,
	types822,
	attr_flags822,
	gtypes822,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets822,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names823,
	types823,
	attr_flags823,
	gtypes823,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets823,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names824,
	types824,
	attr_flags824,
	gtypes824,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets824,
	NULL
},
{
	(long) 1,
	(long) 1,
	"LIST",
	names825,
	types825,
	attr_flags825,
	gtypes825,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets825,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names826,
	types826,
	attr_flags826,
	gtypes826,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets826,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names827,
	types827,
	attr_flags827,
	gtypes827,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets827,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names828,
	types828,
	attr_flags828,
	gtypes828,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets828,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names829,
	types829,
	attr_flags829,
	gtypes829,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets829,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names830,
	types830,
	attr_flags830,
	gtypes830,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets830,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names831,
	types831,
	attr_flags831,
	gtypes831,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets831,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names832,
	types832,
	attr_flags832,
	gtypes832,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets832,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names833,
	types833,
	attr_flags833,
	gtypes833,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets833,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names834,
	types834,
	attr_flags834,
	gtypes834,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets834,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names835,
	types835,
	attr_flags835,
	gtypes835,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets835,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names836,
	types836,
	attr_flags836,
	gtypes836,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets836,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DYNAMIC_LIST",
	names837,
	types837,
	attr_flags837,
	gtypes837,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets837,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names838,
	types838,
	attr_flags838,
	gtypes838,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets838,
	NULL
},
{
	(long) 6,
	(long) 6,
	"LINKED_LIST",
	names839,
	types839,
	attr_flags839,
	gtypes839,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets839,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_SHARED_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"MISMATCH_CORRECTOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"ARRAYED_QUEUE",
	names842,
	types842,
	attr_flags842,
	gtypes842,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets842,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names843,
	types843,
	attr_flags843,
	gtypes843,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets843,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names844,
	types844,
	attr_flags844,
	gtypes844,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets844,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names845,
	types845,
	attr_flags845,
	gtypes845,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets845,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names846,
	types846,
	attr_flags846,
	gtypes846,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets846,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names847,
	types847,
	attr_flags847,
	gtypes847,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets847,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names848,
	types848,
	attr_flags848,
	gtypes848,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets848,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names849,
	types849,
	attr_flags849,
	gtypes849,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets849,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names850,
	types850,
	attr_flags850,
	gtypes850,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets850,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names851,
	types851,
	attr_flags851,
	gtypes851,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets851,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names852,
	types852,
	attr_flags852,
	gtypes852,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets852,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names853,
	types853,
	attr_flags853,
	gtypes853,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets853,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ARRAYED_LIST",
	names854,
	types854,
	attr_flags854,
	gtypes854,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets854,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names855,
	types855,
	attr_flags855,
	gtypes855,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets855,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names856,
	types856,
	attr_flags856,
	gtypes856,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets856,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names857,
	types857,
	attr_flags857,
	gtypes857,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets857,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names858,
	types858,
	attr_flags858,
	gtypes858,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets858,
	NULL
},
{
	(long) 17,
	(long) 17,
	"HASH_TABLE",
	names859,
	types859,
	attr_flags859,
	gtypes859,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets859,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names860,
	types860,
	attr_flags860,
	gtypes860,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets860,
	NULL
},
{
	(long) 18,
	(long) 18,
	"STRING_TABLE",
	names861,
	types861,
	attr_flags861,
	gtypes861,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets861,
	NULL
},
{
	(long) 19,
	(long) 19,
	"MISMATCH_INFORMATION",
	names862,
	types862,
	attr_flags862,
	gtypes862,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets862,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_SHARED_C_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EWG_EIFFEL_TO_C_TYPE_CAST_PRINTER",
	names864,
	types864,
	attr_flags864,
	gtypes864,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets864,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"HASHABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"PATH",
	names867,
	types867,
	attr_flags867,
	gtypes867,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets867,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names868,
	types868,
	attr_flags868,
	gtypes868,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets868,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names869,
	types869,
	attr_flags869,
	gtypes869,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets869,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names870,
	types870,
	attr_flags870,
	gtypes870,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets870,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names871,
	types871,
	attr_flags871,
	gtypes871,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets871,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names872,
	types872,
	attr_flags872,
	gtypes872,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets872,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names873,
	types873,
	attr_flags873,
	gtypes873,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets873,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names874,
	types874,
	attr_flags874,
	gtypes874,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets874,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names875,
	types875,
	attr_flags875,
	gtypes875,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets875,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names876,
	types876,
	attr_flags876,
	gtypes876,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets876,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names877,
	types877,
	attr_flags877,
	gtypes877,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets877,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names878,
	types878,
	attr_flags878,
	gtypes878,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets878,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names879,
	types879,
	attr_flags879,
	gtypes879,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets879,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names880,
	types880,
	attr_flags880,
	gtypes880,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets880,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names881,
	types881,
	attr_flags881,
	gtypes881,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets881,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names882,
	types882,
	attr_flags882,
	gtypes882,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets882,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names883,
	types883,
	attr_flags883,
	gtypes883,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets883,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names884,
	types884,
	attr_flags884,
	gtypes884,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets884,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names885,
	types885,
	attr_flags885,
	gtypes885,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets885,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names886,
	types886,
	attr_flags886,
	gtypes886,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets886,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names887,
	types887,
	attr_flags887,
	gtypes887,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets887,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names888,
	types888,
	attr_flags888,
	gtypes888,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets888,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names889,
	types889,
	attr_flags889,
	gtypes889,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets889,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names890,
	types890,
	attr_flags890,
	gtypes890,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets890,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names891,
	types891,
	attr_flags891,
	gtypes891,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets891,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names892,
	types892,
	attr_flags892,
	gtypes892,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets892,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names893,
	types893,
	attr_flags893,
	gtypes893,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets893,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names894,
	types894,
	attr_flags894,
	gtypes894,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets894,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names895,
	types895,
	attr_flags895,
	gtypes895,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets895,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names896,
	types896,
	attr_flags896,
	gtypes896,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets896,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names897,
	types897,
	attr_flags897,
	gtypes897,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets897,
	NULL
},
{
	(long) 2,
	(long) 0,
	"TYPE",
	names898,
	types898,
	attr_flags898,
	gtypes898,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets898,
	NULL
},
{
	(long) 0,
	(long) 0,
	"TUPLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EWG_C_AST_DECLARATION",
	names900,
	types900,
	attr_flags900,
	gtypes900,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets900,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EWG_C_AST_FUNCTION_DECLARATION",
	names901,
	types901,
	attr_flags901,
	gtypes901,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets901,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64_REF",
	names902,
	types902,
	attr_flags902,
	gtypes902,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets902,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names903,
	types903,
	attr_flags903,
	gtypes903,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets903,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_64",
	names904,
	types904,
	attr_flags904,
	gtypes904,
	(uint16) 0x2309,
	(void (*)()) 0,
	offsets904,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32_REF",
	names905,
	types905,
	attr_flags905,
	gtypes905,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets905,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names906,
	types906,
	attr_flags906,
	gtypes906,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets906,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_32",
	names907,
	types907,
	attr_flags907,
	gtypes907,
	(uint16) 0x2308,
	(void (*)()) 0,
	offsets907,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16_REF",
	names908,
	types908,
	attr_flags908,
	gtypes908,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets908,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names909,
	types909,
	attr_flags909,
	gtypes909,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets909,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_16",
	names910,
	types910,
	attr_flags910,
	gtypes910,
	(uint16) 0x2307,
	(void (*)()) 0,
	offsets910,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8_REF",
	names911,
	types911,
	attr_flags911,
	gtypes911,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets911,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names912,
	types912,
	attr_flags912,
	gtypes912,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets912,
	NULL
},
{
	(long) 1,
	(long) 1,
	"INTEGER_8",
	names913,
	types913,
	attr_flags913,
	gtypes913,
	(uint16) 0x2306,
	(void (*)()) 0,
	offsets913,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64_REF",
	names914,
	types914,
	attr_flags914,
	gtypes914,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets914,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names915,
	types915,
	attr_flags915,
	gtypes915,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets915,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_64",
	names916,
	types916,
	attr_flags916,
	gtypes916,
	(uint16) 0x230D,
	(void (*)()) 0,
	offsets916,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32_REF",
	names917,
	types917,
	attr_flags917,
	gtypes917,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets917,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names918,
	types918,
	attr_flags918,
	gtypes918,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets918,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_32",
	names919,
	types919,
	attr_flags919,
	gtypes919,
	(uint16) 0x230C,
	(void (*)()) 0,
	offsets919,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16_REF",
	names920,
	types920,
	attr_flags920,
	gtypes920,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets920,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names921,
	types921,
	attr_flags921,
	gtypes921,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets921,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_16",
	names922,
	types922,
	attr_flags922,
	gtypes922,
	(uint16) 0x230B,
	(void (*)()) 0,
	offsets922,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8_REF",
	names923,
	types923,
	attr_flags923,
	gtypes923,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets923,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names924,
	types924,
	attr_flags924,
	gtypes924,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets924,
	NULL
},
{
	(long) 1,
	(long) 1,
	"NATURAL_8",
	names925,
	types925,
	attr_flags925,
	gtypes925,
	(uint16) 0x230A,
	(void (*)()) 0,
	offsets925,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32_REF",
	names926,
	types926,
	attr_flags926,
	gtypes926,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets926,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names927,
	types927,
	attr_flags927,
	gtypes927,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets927,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_32",
	names928,
	types928,
	attr_flags928,
	gtypes928,
	(uint16) 0x2304,
	(void (*)()) 0,
	offsets928,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64_REF",
	names929,
	types929,
	attr_flags929,
	gtypes929,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets929,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names930,
	types930,
	attr_flags930,
	gtypes930,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets930,
	NULL
},
{
	(long) 1,
	(long) 1,
	"REAL_64",
	names931,
	types931,
	attr_flags931,
	gtypes931,
	(uint16) 0x2303,
	(void (*)()) 0,
	offsets931,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32_REF",
	names932,
	types932,
	attr_flags932,
	gtypes932,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets932,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names933,
	types933,
	attr_flags933,
	gtypes933,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets933,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_32",
	names934,
	types934,
	attr_flags934,
	gtypes934,
	(uint16) 0x230E,
	(void (*)()) 0,
	offsets934,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8_REF",
	names935,
	types935,
	attr_flags935,
	gtypes935,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets935,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names936,
	types936,
	attr_flags936,
	gtypes936,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets936,
	NULL
},
{
	(long) 1,
	(long) 1,
	"CHARACTER_8",
	names937,
	types937,
	attr_flags937,
	gtypes937,
	(uint16) 0x2302,
	(void (*)()) 0,
	offsets937,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN_REF",
	names938,
	types938,
	attr_flags938,
	gtypes938,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets938,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names939,
	types939,
	attr_flags939,
	gtypes939,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets939,
	NULL
},
{
	(long) 1,
	(long) 1,
	"BOOLEAN",
	names940,
	types940,
	attr_flags940,
	gtypes940,
	(uint16) 0x2301,
	(void (*)()) 0,
	offsets940,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER_REF",
	names941,
	types941,
	attr_flags941,
	gtypes941,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets941,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names942,
	types942,
	attr_flags942,
	gtypes942,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets942,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names943,
	types943,
	attr_flags943,
	gtypes943,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets943,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names944,
	types944,
	attr_flags944,
	gtypes944,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets944,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names945,
	types945,
	attr_flags945,
	gtypes945,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets945,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names946,
	types946,
	attr_flags946,
	gtypes946,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets946,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names947,
	types947,
	attr_flags947,
	gtypes947,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets947,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names948,
	types948,
	attr_flags948,
	gtypes948,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets948,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names949,
	types949,
	attr_flags949,
	gtypes949,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets949,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names950,
	types950,
	attr_flags950,
	gtypes950,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets950,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names951,
	types951,
	attr_flags951,
	gtypes951,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets951,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names952,
	types952,
	attr_flags952,
	gtypes952,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets952,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names953,
	types953,
	attr_flags953,
	gtypes953,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets953,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names954,
	types954,
	attr_flags954,
	gtypes954,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets954,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names955,
	types955,
	attr_flags955,
	gtypes955,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets955,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names956,
	types956,
	attr_flags956,
	gtypes956,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets956,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names957,
	types957,
	attr_flags957,
	gtypes957,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets957,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names958,
	types958,
	attr_flags958,
	gtypes958,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets958,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names959,
	types959,
	attr_flags959,
	gtypes959,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets959,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names960,
	types960,
	attr_flags960,
	gtypes960,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets960,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names961,
	types961,
	attr_flags961,
	gtypes961,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets961,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names962,
	types962,
	attr_flags962,
	gtypes962,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets962,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names963,
	types963,
	attr_flags963,
	gtypes963,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets963,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names964,
	types964,
	attr_flags964,
	gtypes964,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets964,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names965,
	types965,
	attr_flags965,
	gtypes965,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets965,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names966,
	types966,
	attr_flags966,
	gtypes966,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets966,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names967,
	types967,
	attr_flags967,
	gtypes967,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets967,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names968,
	types968,
	attr_flags968,
	gtypes968,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets968,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names969,
	types969,
	attr_flags969,
	gtypes969,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets969,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names970,
	types970,
	attr_flags970,
	gtypes970,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets970,
	NULL
},
{
	(long) 1,
	(long) 1,
	"TYPED_POINTER",
	names971,
	types971,
	attr_flags971,
	gtypes971,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets971,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names972,
	types972,
	attr_flags972,
	gtypes972,
	(uint16) 0x2100,
	(void (*)()) 0,
	offsets972,
	NULL
},
{
	(long) 1,
	(long) 1,
	"POINTER",
	names973,
	types973,
	attr_flags973,
	gtypes973,
	(uint16) 0x2305,
	(void (*)()) 0,
	offsets973,
	NULL
},
{
	(long) 12,
	(long) 12,
	"ROUTINE",
	names974,
	types974,
	attr_flags974,
	gtypes974,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets974,
	NULL
},
{
	(long) 12,
	(long) 12,
	"PROCEDURE",
	names975,
	types975,
	attr_flags975,
	gtypes975,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets975,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names976,
	types976,
	attr_flags976,
	gtypes976,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets976,
	NULL
},
{
	(long) 13,
	(long) 13,
	"FUNCTION",
	names977,
	types977,
	attr_flags977,
	gtypes977,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets977,
	NULL
},
{
	(long) 13,
	(long) 13,
	"PREDICATE",
	names978,
	types978,
	attr_flags978,
	gtypes978,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets978,
	NULL
},
{
	(long) 2,
	(long) 2,
	"READABLE_STRING_GENERAL",
	names979,
	types979,
	attr_flags979,
	gtypes979,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets979,
	NULL
},
{
	(long) 2,
	(long) 2,
	"IMMUTABLE_STRING_GENERAL",
	names980,
	types980,
	attr_flags980,
	gtypes980,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets980,
	NULL
},
{
	(long) 2,
	(long) 2,
	"STRING_GENERAL",
	names981,
	types981,
	attr_flags981,
	gtypes981,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets981,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_32",
	names982,
	types982,
	attr_flags982,
	gtypes982,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets982,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_32",
	names983,
	types983,
	attr_flags983,
	gtypes983,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets983,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_32",
	names984,
	types984,
	attr_flags984,
	gtypes984,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets984,
	NULL
},
{
	(long) 4,
	(long) 4,
	"READABLE_STRING_8",
	names985,
	types985,
	attr_flags985,
	gtypes985,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets985,
	NULL
},
{
	(long) 5,
	(long) 5,
	"IMMUTABLE_STRING_8",
	names986,
	types986,
	attr_flags986,
	gtypes986,
	(uint16) 0x2000,
	(void (*)()) 0,
	offsets986,
	NULL
},
{
	(long) 5,
	(long) 5,
	"STRING_8",
	names987,
	types987,
	attr_flags987,
	gtypes987,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets987,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING",
	names988,
	types988,
	attr_flags988,
	gtypes988,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets988,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_ANY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF16_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_NATURAL_32_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UTF8_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_ARRAY_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_INPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_FACTORY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_IMPORTED_STRING_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CASE_INSENSITIVE_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_EIFFEL_CHARACTER_ENTITY",
	names1009,
	types1009,
	attr_flags1009,
	gtypes1009,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1009,
	NULL
},
{
	(long) 4,
	(long) 4,
	"KL_STDIN_FILE",
	names1010,
	types1010,
	attr_flags1010,
	gtypes1010,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1010,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"ST_COPY_ON_WRITE_STRING",
	names1012,
	types1012,
	attr_flags1012,
	gtypes1012,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1012,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_INTEGER_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UC_CHARACTER",
	names1014,
	types1014,
	attr_flags1014,
	gtypes1014,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1014,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_TEMPLATE_EXPANDER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_STRING_INPUT_STREAM",
	names1016,
	types1016,
	attr_flags1016,
	gtypes1016,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1016,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_FILE_SOURCE",
	names1017,
	types1017,
	attr_flags1017,
	gtypes1017,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1017,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XM_EIFFEL_INPUT_STREAM",
	names1018,
	types1018,
	attr_flags1018,
	gtypes1018,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1018,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_WHITESPACE_NORMALIZER",
	names1019,
	types1019,
	attr_flags1019,
	gtypes1019,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1019,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_CONTENT_CONCATENATOR",
	names1020,
	types1020,
	attr_flags1020,
	gtypes1020,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1020,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_XMLNS_GENERATOR",
	names1021,
	types1021,
	attr_flags1021,
	gtypes1021,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1021,
	NULL
},
{
	(long) 8,
	(long) 8,
	"XM_NAMESPACE_RESOLVER",
	names1022,
	types1022,
	attr_flags1022,
	gtypes1022,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1022,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_STRING_EQUALITY_TESTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_C_DECLARATOR_PRINTER",
	names1024,
	types1024,
	attr_flags1024,
	gtypes1024,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1024,
	NULL
},
{
	(long) 5,
	(long) 5,
	"XM_EIFFEL_PARSER_NAME",
	names1025,
	types1025,
	attr_flags1025,
	gtypes1025,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1025,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_NAMESPACE",
	names1026,
	types1026,
	attr_flags1026,
	gtypes1026,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1026,
	NULL
},
{
	(long) 6,
	(long) 6,
	"EWG_C_PHASE_1_DIRECT_DECLARATOR",
	names1027,
	types1027,
	attr_flags1027,
	gtypes1027,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1027,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EWG_CONFIG_MATCHING_CLAUSE",
	names1028,
	types1028,
	attr_flags1028,
	gtypes1028,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1028,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STRING_VALUES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_EXECUTION_ENVIRONMENT",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_COMMAND_LINE_PARSER",
	names1031,
	types1031,
	attr_flags1031,
	gtypes1031,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1031,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_CHARACTER_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_BINARY_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_STREAM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDERR_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_STDOUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_NULL_TEXT_OUTPUT_STREAM",
	names1038,
	types1038,
	attr_flags1038,
	gtypes1038,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1038,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_TEXT_OUTPUT_FILE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"EWG_C_AST_TYPE",
	names1040,
	types1040,
	attr_flags1040,
	gtypes1040,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1040,
	NULL
},
{
	(long) 6,
	(long) 6,
	"EWG_C_AST_SIMPLE_TYPE",
	names1041,
	types1041,
	attr_flags1041,
	gtypes1041,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1041,
	NULL
},
{
	(long) 6,
	(long) 6,
	"EWG_C_AST_PRIMITIVE_TYPE",
	names1042,
	types1042,
	attr_flags1042,
	gtypes1042,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1042,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EWG_C_AST_EIFFEL_OBJECT_TYPE",
	names1043,
	types1043,
	attr_flags1043,
	gtypes1043,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1043,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EWG_C_AST_BASED_TYPE",
	names1044,
	types1044,
	attr_flags1044,
	gtypes1044,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1044,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EWG_C_AST_CONST_TYPE",
	names1045,
	types1045,
	attr_flags1045,
	gtypes1045,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1045,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EWG_C_AST_ARRAY_TYPE",
	names1046,
	types1046,
	attr_flags1046,
	gtypes1046,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1046,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EWG_C_AST_ALIAS_TYPE",
	names1047,
	types1047,
	attr_flags1047,
	gtypes1047,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1047,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EWG_C_DECLARATION_PROCESSOR",
	names1048,
	types1048,
	attr_flags1048,
	gtypes1048,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1048,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EWG_C_ISE_EXTERNAL_DECLARATION_PRINTER",
	names1049,
	types1049,
	attr_flags1049,
	gtypes1049,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1049,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EWG_C_ANONYMOUS_DECLARATION_PRINTER",
	names1050,
	types1050,
	attr_flags1050,
	gtypes1050,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1050,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EWG_C_DECLARATION_PRINTER",
	names1051,
	types1051,
	attr_flags1051,
	gtypes1051,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1051,
	NULL
},
{
	(long) 6,
	(long) 6,
	"EWG_C_TO_EIFFEL_DECLARATION_PRINTER",
	names1052,
	types1052,
	attr_flags1052,
	gtypes1052,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1052,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_STRING_OUTPUT_STREAM",
	names1053,
	types1053,
	attr_flags1053,
	gtypes1053,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1053,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EWG_C_AST_POINTER_TYPE",
	names1054,
	types1054,
	attr_flags1054,
	gtypes1054,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1054,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EWG_C_AST_COMPOSITE_TYPE",
	names1055,
	types1055,
	attr_flags1055,
	gtypes1055,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1055,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EWG_C_AST_FUNCTION_TYPE",
	names1056,
	types1056,
	attr_flags1056,
	gtypes1056,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1056,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EWG_C_AST_COMPOSITE_DATA_TYPE",
	names1057,
	types1057,
	attr_flags1057,
	gtypes1057,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1057,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EWG_C_AST_STRUCT_TYPE",
	names1058,
	types1058,
	attr_flags1058,
	gtypes1058,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1058,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EWG_C_AST_ENUM_TYPE",
	names1059,
	types1059,
	attr_flags1059,
	gtypes1059,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1059,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EWG_C_AST_UNION_TYPE",
	names1060,
	types1060,
	attr_flags1060,
	gtypes1060,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1060,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_INTEGER_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_STRUCT_FEATURE_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_ANY_FEATURE_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RX_BYTE_CODE",
	names1064,
	types1064,
	attr_flags1064,
	gtypes1064,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1064,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_EIFFEL_COMPILER_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"EWG_UNIQUE_NAME_GENERATOR",
	names1066,
	types1066,
	attr_flags1066,
	gtypes1066,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1066,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_TYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_CONFIG_CONSTRUCT_TYPE_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EWG_C_SYSTEM",
	names1074,
	types1074,
	attr_flags1074,
	gtypes1074,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1074,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EWG_C_PHASE_1_TYPE_SPECIFIER",
	names1075,
	types1075,
	attr_flags1075,
	gtypes1075,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1075,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EWG_C_PHASE_1_DECLARATOR",
	names1076,
	types1076,
	attr_flags1076,
	gtypes1076,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1076,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EWG_C_PHASE_1_TYPE_QUALIFIER",
	names1077,
	types1077,
	attr_flags1077,
	gtypes1077,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1077,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XM_TREE_CALLBACKS_PIPE",
	names1078,
	types1078,
	attr_flags1078,
	gtypes1078,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1078,
	NULL
},
{
	(long) 23,
	(long) 22,
	"CONSOLE",
	names1079,
	types1079,
	attr_flags1079,
	gtypes1079,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1079,
	NULL
},
{
	(long) 14,
	(long) 14,
	"EWG_CONFIG_SYSTEM",
	names1080,
	types1080,
	attr_flags1080,
	gtypes1080,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1080,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_POST_PARSER_PROCESSOR",
	names1081,
	types1081,
	attr_flags1081,
	gtypes1081,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1081,
	NULL
},
{
	(long) 4,
	(long) 4,
	"YY_SCANNER",
	names1082,
	types1082,
	attr_flags1082,
	gtypes1082,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1082,
	NULL
},
{
	(long) 22,
	(long) 22,
	"YY_SCANNER_SKELETON",
	names1083,
	types1083,
	attr_flags1083,
	gtypes1083,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1083,
	NULL
},
{
	(long) 38,
	(long) 38,
	"YY_COMPRESSED_SCANNER_SKELETON",
	names1084,
	types1084,
	attr_flags1084,
	gtypes1084,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1084,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_TITLECASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_UPPERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE_LOWERCASE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_V510_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_CTYPE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_GREGORIAN_CALENDAR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DT_GREGORIAN_CALENDAR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DT_WEEK_DAYS_FROM_SUNDAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DT_WEEK_DAYS_FROM_MONDAY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"RX_PCRE_ESCAPE_CONSTANTS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_STRING_MODE",
	names1095,
	types1095,
	attr_flags1095,
	gtypes1095,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1095,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_PARSER",
	names1096,
	types1096,
	attr_flags1096,
	gtypes1096,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1096,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_NON_INCREMENTAL_PARSER",
	names1097,
	types1097,
	attr_flags1097,
	gtypes1097,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1097,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DT_WEEK_DAY",
	names1098,
	types1098,
	attr_flags1098,
	gtypes1098,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1098,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DT_WEEK_DAY_FROM_MONDAY",
	names1099,
	types1099,
	attr_flags1099,
	gtypes1099,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1099,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DT_WEEK_DAY_FROM_SUNDAY",
	names1100,
	types1100,
	attr_flags1100,
	gtypes1100,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1100,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_I",
	names1101,
	types1101,
	attr_flags1101,
	gtypes1101,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1101,
	NULL
},
{
	(long) 3,
	(long) 3,
	"ENCODING_IMP",
	names1102,
	types1102,
	attr_flags1102,
	gtypes1102,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1102,
	NULL
},
{
	(long) 3,
	(long) 3,
	"UNICODE_CONVERSION",
	names1103,
	types1103,
	attr_flags1103,
	gtypes1103,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1103,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_POSITION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_STREAM_POSITION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XM_DEFAULT_POSITION",
	names1106,
	types1106,
	attr_flags1106,
	gtypes1106,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1106,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names1107,
	types1107,
	attr_flags1107,
	gtypes1107,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1107,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names1108,
	types1108,
	attr_flags1108,
	gtypes1108,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1108,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names1109,
	types1109,
	attr_flags1109,
	gtypes1109,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1109,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names1110,
	types1110,
	attr_flags1110,
	gtypes1110,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1110,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names1111,
	types1111,
	attr_flags1111,
	gtypes1111,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1111,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_CURSOR",
	names1112,
	types1112,
	attr_flags1112,
	gtypes1112,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1112,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXED_CURSOR",
	names1113,
	types1113,
	attr_flags1113,
	gtypes1113,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1113,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXED_CURSOR",
	names1114,
	types1114,
	attr_flags1114,
	gtypes1114,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1114,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names1115,
	types1115,
	attr_flags1115,
	gtypes1115,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1115,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names1116,
	types1116,
	attr_flags1116,
	gtypes1116,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1116,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names1117,
	types1117,
	attr_flags1117,
	gtypes1117,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1117,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DYNAMIC_CURSOR",
	names1118,
	types1118,
	attr_flags1118,
	gtypes1118,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1118,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names1119,
	types1119,
	attr_flags1119,
	gtypes1119,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1119,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names1120,
	types1120,
	attr_flags1120,
	gtypes1120,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1120,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names1121,
	types1121,
	attr_flags1121,
	gtypes1121,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1121,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names1122,
	types1122,
	attr_flags1122,
	gtypes1122,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1122,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names1123,
	types1123,
	attr_flags1123,
	gtypes1123,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1123,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR_CURSOR",
	names1124,
	types1124,
	attr_flags1124,
	gtypes1124,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1124,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SET_CURSOR",
	names1125,
	types1125,
	attr_flags1125,
	gtypes1125,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1125,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names1126,
	types1126,
	attr_flags1126,
	gtypes1126,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1126,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names1127,
	types1127,
	attr_flags1127,
	gtypes1127,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1127,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names1128,
	types1128,
	attr_flags1128,
	gtypes1128,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1128,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names1129,
	types1129,
	attr_flags1129,
	gtypes1129,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1129,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_CURSOR",
	names1130,
	types1130,
	attr_flags1130,
	gtypes1130,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1130,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names1131,
	types1131,
	attr_flags1131,
	gtypes1131,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1131,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names1132,
	types1132,
	attr_flags1132,
	gtypes1132,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1132,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names1133,
	types1133,
	attr_flags1133,
	gtypes1133,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1133,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names1134,
	types1134,
	attr_flags1134,
	gtypes1134,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1134,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS_CURSOR",
	names1135,
	types1135,
	attr_flags1135,
	gtypes1135,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1135,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names1136,
	types1136,
	attr_flags1136,
	gtypes1136,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1136,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names1137,
	types1137,
	attr_flags1137,
	gtypes1137,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1137,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names1138,
	types1138,
	attr_flags1138,
	gtypes1138,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1138,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names1139,
	types1139,
	attr_flags1139,
	gtypes1139,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1139,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE_CURSOR",
	names1140,
	types1140,
	attr_flags1140,
	gtypes1140,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1140,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1141,
	types1141,
	attr_flags1141,
	gtypes1141,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1141,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1142,
	types1142,
	attr_flags1142,
	gtypes1142,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1142,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1143,
	types1143,
	attr_flags1143,
	gtypes1143,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1143,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1144,
	types1144,
	attr_flags1144,
	gtypes1144,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1144,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_CONTAINER_CURSOR",
	names1145,
	types1145,
	attr_flags1145,
	gtypes1145,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1145,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_SET_CURSOR",
	names1146,
	types1146,
	attr_flags1146,
	gtypes1146,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1146,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_SET_CURSOR",
	names1147,
	types1147,
	attr_flags1147,
	gtypes1147,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1147,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_SET_CURSOR",
	names1148,
	types1148,
	attr_flags1148,
	gtypes1148,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1148,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1149,
	types1149,
	attr_flags1149,
	gtypes1149,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1149,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1150,
	types1150,
	attr_flags1150,
	gtypes1150,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1150,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1151,
	types1151,
	attr_flags1151,
	gtypes1151,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1151,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1152,
	types1152,
	attr_flags1152,
	gtypes1152,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1152,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_CURSOR",
	names1153,
	types1153,
	attr_flags1153,
	gtypes1153,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1153,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1154,
	types1154,
	attr_flags1154,
	gtypes1154,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1154,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1155,
	types1155,
	attr_flags1155,
	gtypes1155,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1155,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1156,
	types1156,
	attr_flags1156,
	gtypes1156,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1156,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1157,
	types1157,
	attr_flags1157,
	gtypes1157,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1157,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_SPARSE_TABLE_CURSOR",
	names1158,
	types1158,
	attr_flags1158,
	gtypes1158,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1158,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1159,
	types1159,
	attr_flags1159,
	gtypes1159,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1159,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1160,
	types1160,
	attr_flags1160,
	gtypes1160,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1160,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1161,
	types1161,
	attr_flags1161,
	gtypes1161,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1161,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1162,
	types1162,
	attr_flags1162,
	gtypes1162,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1162,
	"20130823"
},
{
	(long) 3,
	(long) 3,
	"DS_HASH_TABLE_CURSOR",
	names1163,
	types1163,
	attr_flags1163,
	gtypes1163,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1163,
	"20130823"
},
{
	(long) 1,
	(long) 1,
	"DS_LIST_CURSOR",
	names1164,
	types1164,
	attr_flags1164,
	gtypes1164,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1164,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST_CURSOR",
	names1165,
	types1165,
	attr_flags1165,
	gtypes1165,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1165,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_ARRAYED_LIST_CURSOR",
	names1166,
	types1166,
	attr_flags1166,
	gtypes1166,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1166,
	"20130823"
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST_CURSOR",
	names1167,
	types1167,
	attr_flags1167,
	gtypes1167,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1167,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST_CURSOR",
	names1168,
	types1168,
	attr_flags1168,
	gtypes1168,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1168,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_BILINKED_LIST_CURSOR",
	names1169,
	types1169,
	attr_flags1169,
	gtypes1169,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1169,
	NULL
},
{
	(long) 4,
	(long) 4,
	"EWG_ABSTRACT_WRAPPER",
	names1170,
	types1170,
	attr_flags1170,
	gtypes1170,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1170,
	NULL
},
{
	(long) 4,
	(long) 4,
	"EWG_ABSTRACT_DECLARATION_WRAPPER",
	names1171,
	types1171,
	attr_flags1171,
	gtypes1171,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1171,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EWG_COMPOSITE_WRAPPER",
	names1172,
	types1172,
	attr_flags1172,
	gtypes1172,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1172,
	NULL
},
{
	(long) 6,
	(long) 6,
	"EWG_CALLABLE_WRAPPER",
	names1173,
	types1173,
	attr_flags1173,
	gtypes1173,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1173,
	NULL
},
{
	(long) 8,
	(long) 8,
	"EWG_FUNCTION_WRAPPER",
	names1174,
	types1174,
	attr_flags1174,
	gtypes1174,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1174,
	NULL
},
{
	(long) 4,
	(long) 4,
	"EWG_ABSTRACT_TYPE_WRAPPER",
	names1175,
	types1175,
	attr_flags1175,
	gtypes1175,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1175,
	NULL
},
{
	(long) 12,
	(long) 12,
	"EWG_CALLBACK_WRAPPER",
	names1176,
	types1176,
	attr_flags1176,
	gtypes1176,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1176,
	NULL
},
{
	(long) 12,
	(long) 12,
	"EWG_ANSI_C_CALLBACK_WRAPPER",
	names1177,
	types1177,
	attr_flags1177,
	gtypes1177,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1177,
	NULL
},
{
	(long) 12,
	(long) 12,
	"EWG_FFCALL_CALLBACK_WRAPPER",
	names1178,
	types1178,
	attr_flags1178,
	gtypes1178,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1178,
	NULL
},
{
	(long) 6,
	(long) 6,
	"EWG_COMPOSITE_DATA_WRAPPER",
	names1179,
	types1179,
	attr_flags1179,
	gtypes1179,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1179,
	NULL
},
{
	(long) 6,
	(long) 6,
	"EWG_UNION_WRAPPER",
	names1180,
	types1180,
	attr_flags1180,
	gtypes1180,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1180,
	NULL
},
{
	(long) 6,
	(long) 6,
	"EWG_STRUCT_WRAPPER",
	names1181,
	types1181,
	attr_flags1181,
	gtypes1181,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1181,
	NULL
},
{
	(long) 6,
	(long) 6,
	"EWG_ENUM_WRAPPER",
	names1182,
	types1182,
	attr_flags1182,
	gtypes1182,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1182,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EWG_MEMBER_WRAPPER",
	names1183,
	types1183,
	attr_flags1183,
	gtypes1183,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1183,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EWG_UNION_MEMBER_WRAPPER",
	names1184,
	types1184,
	attr_flags1184,
	gtypes1184,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1184,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EWG_STRUCT_MEMBER_WRAPPER",
	names1185,
	types1185,
	attr_flags1185,
	gtypes1185,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1185,
	NULL
},
{
	(long) 6,
	(long) 6,
	"EWG_ZERO_TERMINATED_STRING_MEMBER_WRAPPER",
	names1186,
	types1186,
	attr_flags1186,
	gtypes1186,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1186,
	NULL
},
{
	(long) 6,
	(long) 6,
	"EWG_NATIVE_MEMBER_WRAPPER",
	names1187,
	types1187,
	attr_flags1187,
	gtypes1187,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1187,
	NULL
},
{
	(long) 9,
	(long) 9,
	"EWG_MACRO_WRAPPER",
	names1188,
	types1188,
	attr_flags1188,
	gtypes1188,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1188,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_CONFIG_WRAPPER_TYPE_NAMES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_CLONABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DT_DURATION",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DT_ABSOLUTE_TIME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_CONTAINER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_SORTABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_TRAVERSABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1212,
	types1212,
	attr_flags1212,
	gtypes1212,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1212,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1213,
	types1213,
	attr_flags1213,
	gtypes1213,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1213,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1214,
	types1214,
	attr_flags1214,
	gtypes1214,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1214,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1215,
	types1215,
	attr_flags1215,
	gtypes1215,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1215,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1216,
	types1216,
	attr_flags1216,
	gtypes1216,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1216,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SEARCHABLE",
	names1217,
	types1217,
	attr_flags1217,
	gtypes1217,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1217,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1218,
	types1218,
	attr_flags1218,
	gtypes1218,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1218,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1219,
	types1219,
	attr_flags1219,
	gtypes1219,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1219,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1220,
	types1220,
	attr_flags1220,
	gtypes1220,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1220,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1221,
	types1221,
	attr_flags1221,
	gtypes1221,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1221,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1222,
	types1222,
	attr_flags1222,
	gtypes1222,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1222,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LINEAR",
	names1223,
	types1223,
	attr_flags1223,
	gtypes1223,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1223,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1224,
	types1224,
	attr_flags1224,
	gtypes1224,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1224,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1225,
	types1225,
	attr_flags1225,
	gtypes1225,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1225,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1226,
	types1226,
	attr_flags1226,
	gtypes1226,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1226,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1227,
	types1227,
	attr_flags1227,
	gtypes1227,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1227,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR",
	names1228,
	types1228,
	attr_flags1228,
	gtypes1228,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1228,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1229,
	types1229,
	attr_flags1229,
	gtypes1229,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1229,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1230,
	types1230,
	attr_flags1230,
	gtypes1230,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1230,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1231,
	types1231,
	attr_flags1231,
	gtypes1231,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1231,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1232,
	types1232,
	attr_flags1232,
	gtypes1232,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1232,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_SPARSE_TABLE_KEYS",
	names1233,
	types1233,
	attr_flags1233,
	gtypes1233,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1233,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1234,
	types1234,
	attr_flags1234,
	gtypes1234,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1234,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1235,
	types1235,
	attr_flags1235,
	gtypes1235,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1235,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1236,
	types1236,
	attr_flags1236,
	gtypes1236,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1236,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1237,
	types1237,
	attr_flags1237,
	gtypes1237,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1237,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_BILINEAR_TABLE",
	names1238,
	types1238,
	attr_flags1238,
	gtypes1238,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1238,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_EXTENDIBLE",
	names1239,
	types1239,
	attr_flags1239,
	gtypes1239,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1239,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_EXTENDIBLE",
	names1240,
	types1240,
	attr_flags1240,
	gtypes1240,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1240,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_EXTENDIBLE",
	names1241,
	types1241,
	attr_flags1241,
	gtypes1241,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1241,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_EXTENDIBLE",
	names1242,
	types1242,
	attr_flags1242,
	gtypes1242,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1242,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXABLE",
	names1243,
	types1243,
	attr_flags1243,
	gtypes1243,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1243,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_INDEXABLE",
	names1244,
	types1244,
	attr_flags1244,
	gtypes1244,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1244,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST",
	names1245,
	types1245,
	attr_flags1245,
	gtypes1245,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1245,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_LIST",
	names1246,
	types1246,
	attr_flags1246,
	gtypes1246,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1246,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST",
	names1247,
	types1247,
	attr_flags1247,
	gtypes1247,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1247,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_LINKED_LIST",
	names1248,
	types1248,
	attr_flags1248,
	gtypes1248,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1248,
	NULL
},
{
	(long) 5,
	(long) 5,
	"XM_LINKED_LIST",
	names1249,
	types1249,
	attr_flags1249,
	gtypes1249,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1249,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_BILINKED_LIST",
	names1250,
	types1250,
	attr_flags1250,
	gtypes1250,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1250,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_SET",
	names1251,
	types1251,
	attr_flags1251,
	gtypes1251,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1251,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DISPENSER",
	names1252,
	types1252,
	attr_flags1252,
	gtypes1252,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1252,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DISPENSER",
	names1253,
	types1253,
	attr_flags1253,
	gtypes1253,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1253,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_DISPENSER",
	names1254,
	types1254,
	attr_flags1254,
	gtypes1254,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1254,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_QUEUE",
	names1255,
	types1255,
	attr_flags1255,
	gtypes1255,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1255,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_QUEUE",
	names1256,
	types1256,
	attr_flags1256,
	gtypes1256,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1256,
	NULL
},
{
	(long) 4,
	(long) 4,
	"DS_LINKED_QUEUE",
	names1257,
	types1257,
	attr_flags1257,
	gtypes1257,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1257,
	NULL
},
{
	(long) 4,
	(long) 4,
	"DS_LINKED_QUEUE",
	names1258,
	types1258,
	attr_flags1258,
	gtypes1258,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1258,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_STACK",
	names1259,
	types1259,
	attr_flags1259,
	gtypes1259,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1259,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DS_STACK",
	names1260,
	types1260,
	attr_flags1260,
	gtypes1260,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1260,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_LINKED_STACK",
	names1261,
	types1261,
	attr_flags1261,
	gtypes1261,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1261,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DS_LINKED_STACK",
	names1262,
	types1262,
	attr_flags1262,
	gtypes1262,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1262,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_RESIZABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_RESIZABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_RESIZABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DS_RESIZABLE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"DS_ARRAYED_STACK",
	names1267,
	types1267,
	attr_flags1267,
	gtypes1267,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1267,
	"20130823"
},
{
	(long) 6,
	(long) 6,
	"DS_ARRAYED_LIST",
	names1268,
	types1268,
	attr_flags1268,
	gtypes1268,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1268,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1269,
	types1269,
	attr_flags1269,
	gtypes1269,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1269,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1270,
	types1270,
	attr_flags1270,
	gtypes1270,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1270,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1271,
	types1271,
	attr_flags1271,
	gtypes1271,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1271,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1272,
	types1272,
	attr_flags1272,
	gtypes1272,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1272,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_CONTAINER",
	names1273,
	types1273,
	attr_flags1273,
	gtypes1273,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1273,
	"20130823"
},
{
	(long) 11,
	(long) 11,
	"DS_SPARSE_SET",
	names1274,
	types1274,
	attr_flags1274,
	gtypes1274,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1274,
	"20130823"
},
{
	(long) 15,
	(long) 15,
	"DS_ARRAYED_SPARSE_SET",
	names1275,
	types1275,
	attr_flags1275,
	gtypes1275,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1275,
	"20130823"
},
{
	(long) 16,
	(long) 16,
	"DS_HASH_SET",
	names1276,
	types1276,
	attr_flags1276,
	gtypes1276,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1276,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1277,
	types1277,
	attr_flags1277,
	gtypes1277,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1277,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1278,
	types1278,
	attr_flags1278,
	gtypes1278,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1278,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1279,
	types1279,
	attr_flags1279,
	gtypes1279,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1279,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1280,
	types1280,
	attr_flags1280,
	gtypes1280,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1280,
	"20130823"
},
{
	(long) 13,
	(long) 13,
	"DS_SPARSE_TABLE",
	names1281,
	types1281,
	attr_flags1281,
	gtypes1281,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1281,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1282,
	types1282,
	attr_flags1282,
	gtypes1282,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1282,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1283,
	types1283,
	attr_flags1283,
	gtypes1283,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1283,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1284,
	types1284,
	attr_flags1284,
	gtypes1284,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1284,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1285,
	types1285,
	attr_flags1285,
	gtypes1285,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1285,
	"20130823"
},
{
	(long) 19,
	(long) 19,
	"DS_ARRAYED_SPARSE_TABLE",
	names1286,
	types1286,
	attr_flags1286,
	gtypes1286,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1286,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1287,
	types1287,
	attr_flags1287,
	gtypes1287,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1287,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1288,
	types1288,
	attr_flags1288,
	gtypes1288,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1288,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1289,
	types1289,
	attr_flags1289,
	gtypes1289,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1289,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1290,
	types1290,
	attr_flags1290,
	gtypes1290,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1290,
	"20130823"
},
{
	(long) 20,
	(long) 20,
	"DS_HASH_TABLE",
	names1291,
	types1291,
	attr_flags1291,
	gtypes1291,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1291,
	"20130823"
},
{
	(long) 0,
	(long) 0,
	"KL_SHARED_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 11,
	(long) 11,
	"KL_DIRECTORY",
	names1293,
	types1293,
	attr_flags1293,
	gtypes1293,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1293,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_DIRECTORY_STRUCTURE",
	names1294,
	types1294,
	attr_flags1294,
	gtypes1294,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1294,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_FILE",
	names1295,
	types1295,
	attr_flags1295,
	gtypes1295,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1295,
	NULL
},
{
	(long) 1,
	(long) 1,
	"KL_OUTPUT_FILE",
	names1296,
	types1296,
	attr_flags1296,
	gtypes1296,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1296,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_TEXT_OUTPUT_FILE",
	names1297,
	types1297,
	attr_flags1297,
	gtypes1297,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1297,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_BINARY_OUTPUT_FILE",
	names1298,
	types1298,
	attr_flags1298,
	gtypes1298,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1298,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_UNIX_OUTPUT_FILE",
	names1299,
	types1299,
	attr_flags1299,
	gtypes1299,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1299,
	NULL
},
{
	(long) 22,
	(long) 21,
	"KL_WINDOWS_OUTPUT_FILE",
	names1300,
	types1300,
	attr_flags1300,
	gtypes1300,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1300,
	NULL
},
{
	(long) 5,
	(long) 5,
	"KL_INPUT_FILE",
	names1301,
	types1301,
	attr_flags1301,
	gtypes1301,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1301,
	NULL
},
{
	(long) 26,
	(long) 25,
	"KL_TEXT_INPUT_FILE",
	names1302,
	types1302,
	attr_flags1302,
	gtypes1302,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1302,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_BINARY_INPUT_FILE",
	names1303,
	types1303,
	attr_flags1303,
	gtypes1303,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1303,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_UNIX_INPUT_FILE",
	names1304,
	types1304,
	attr_flags1304,
	gtypes1304,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1304,
	NULL
},
{
	(long) 24,
	(long) 23,
	"KL_WINDOWS_INPUT_FILE",
	names1305,
	types1305,
	attr_flags1305,
	gtypes1305,
	(uint16) 0x0400,
	(void (*)()) 0,
	offsets1305,
	NULL
},
{
	(long) 4,
	(long) 4,
	"MEM_INFO",
	names1306,
	types1306,
	attr_flags1306,
	gtypes1306,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1306,
	NULL
},
{
	(long) 4,
	(long) 4,
	"GC_INFO",
	names1307,
	types1307,
	attr_flags1307,
	gtypes1307,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1307,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_CHARACTER_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"RX_CASE_MAPPING",
	names1309,
	types1309,
	attr_flags1309,
	gtypes1309,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1309,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_DTD_EXTERNAL_ID",
	names1310,
	types1310,
	attr_flags1310,
	gtypes1310,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1310,
	NULL
},
{
	(long) 11,
	(long) 11,
	"RT_DBG_EXECUTION_RECORDER",
	names1311,
	types1311,
	attr_flags1311,
	gtypes1311,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1311,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_UNIX_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KL_WINDOWS_FILE_SYSTEM_BACKSLASH_ONLY",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_OUTPUT",
	names1317,
	types1317,
	attr_flags1317,
	gtypes1317,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1317,
	NULL
},
{
	(long) 6,
	(long) 6,
	"XM_PRETTY_PRINT_FILTER",
	names1318,
	types1318,
	attr_flags1318,
	gtypes1318,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1318,
	NULL
},
{
	(long) 11,
	(long) 11,
	"XM_INDENT_PRETTY_PRINT_FILTER",
	names1319,
	types1319,
	attr_flags1319,
	gtypes1319,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1319,
	NULL
},
{
	(long) 6,
	(long) 6,
	"XM_CANONICAL_PRETTY_PRINT_FILTER",
	names1320,
	types1320,
	attr_flags1320,
	gtypes1320,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1320,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_SHARED_UNICODE_CHARACTERS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_UNICODE_VALIDATION_FILTER",
	names1322,
	types1322,
	attr_flags1322,
	gtypes1322,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1322,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_PRINT_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"UT_ERROR_HANDLER",
	names1324,
	types1324,
	attr_flags1324,
	gtypes1324,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1324,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RX_PATTERN_MATCHER",
	names1325,
	types1325,
	attr_flags1325,
	gtypes1325,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1325,
	NULL
},
{
	(long) 4,
	(long) 4,
	"RX_REGULAR_EXPRESSION",
	names1326,
	types1326,
	attr_flags1326,
	gtypes1326,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1326,
	NULL
},
{
	(long) 0,
	(long) 0,
	"XM_NODE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_COMPOSITE_NODE",
	names1328,
	types1328,
	attr_flags1328,
	gtypes1328,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1328,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_DOCUMENT_NODE",
	names1329,
	types1329,
	attr_flags1329,
	gtypes1329,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1329,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_ELEMENT_NODE",
	names1330,
	types1330,
	attr_flags1330,
	gtypes1330,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1330,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_PROCESSING_INSTRUCTION",
	names1331,
	types1331,
	attr_flags1331,
	gtypes1331,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1331,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_COMMENT",
	names1332,
	types1332,
	attr_flags1332,
	gtypes1332,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1332,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_CHARACTER_DATA",
	names1333,
	types1333,
	attr_flags1333,
	gtypes1333,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1333,
	NULL
},
{
	(long) 3,
	(long) 3,
	"XM_NAMED_NODE",
	names1334,
	types1334,
	attr_flags1334,
	gtypes1334,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1334,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XM_ATTRIBUTE",
	names1335,
	types1335,
	attr_flags1335,
	gtypes1335,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1335,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_COMPOSITE",
	names1336,
	types1336,
	attr_flags1336,
	gtypes1336,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1336,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XM_ELEMENT",
	names1337,
	types1337,
	attr_flags1337,
	gtypes1337,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1337,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_DOCUMENT",
	names1338,
	types1338,
	attr_flags1338,
	gtypes1338,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1338,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DT_DATE_VALUE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"DT_DATE_DURATION",
	names1340,
	types1340,
	attr_flags1340,
	gtypes1340,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1340,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DT_DATE",
	names1341,
	types1341,
	attr_flags1341,
	gtypes1341,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1341,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DT_TIME_VALUE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 4,
	(long) 4,
	"DT_TIME_DURATION",
	names1343,
	types1343,
	attr_flags1343,
	gtypes1343,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1343,
	NULL
},
{
	(long) 1,
	(long) 1,
	"DT_TIME",
	names1344,
	types1344,
	attr_flags1344,
	gtypes1344,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1344,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DT_DATE_TIME_VALUE",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 7,
	(long) 7,
	"DT_DATE_TIME_DURATION",
	names1346,
	types1346,
	attr_flags1346,
	gtypes1346,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1346,
	NULL
},
{
	(long) 2,
	(long) 2,
	"DT_DATE_TIME",
	names1347,
	types1347,
	attr_flags1347,
	gtypes1347,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1347,
	NULL
},
{
	(long) 4,
	(long) 4,
	"XM_XMLNS_GENERATOR_CONTEXT",
	names1348,
	types1348,
	attr_flags1348,
	gtypes1348,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1348,
	NULL
},
{
	(long) 1,
	(long) 1,
	"XM_NAMESPACE_RESOLVER_CONTEXT",
	names1349,
	types1349,
	attr_flags1349,
	gtypes1349,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1349,
	NULL
},
{
	(long) 14,
	(long) 14,
	"EWG_C_AST_TYPE_SET",
	names1350,
	types1350,
	attr_flags1350,
	gtypes1350,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1350,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UC_UNICODE_ROUTINES",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"XM_DTD_ATTRIBUTE_CONTENT",
	names1352,
	types1352,
	attr_flags1352,
	gtypes1352,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1352,
	NULL
},
{
	(long) 0,
	(long) 0,
	"DT_CLOCK",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 9,
	(long) 9,
	"DT_UTC_SYSTEM_CLOCK",
	names1354,
	types1354,
	attr_flags1354,
	gtypes1354,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1354,
	NULL
},
{
	(long) 9,
	(long) 9,
	"DT_SYSTEM_CLOCK",
	names1355,
	types1355,
	attr_flags1355,
	gtypes1355,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1355,
	NULL
},
{
	(long) 0,
	(long) 0,
	"YY_PARSER_TOKENS",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EWG_C_TOKENS",
	names1357,
	types1357,
	attr_flags1357,
	gtypes1357,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1357,
	NULL
},
{
	(long) 47,
	(long) 47,
	"EWG_C_SCANNER_SKELETON",
	names1358,
	types1358,
	attr_flags1358,
	gtypes1358,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1358,
	NULL
},
{
	(long) 47,
	(long) 47,
	"EWG_C_SCANNER",
	names1359,
	types1359,
	attr_flags1359,
	gtypes1359,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1359,
	NULL
},
{
	(long) 2,
	(long) 2,
	"XM_EIFFEL_TOKENS",
	names1360,
	types1360,
	attr_flags1360,
	gtypes1360,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1360,
	NULL
},
{
	(long) 47,
	(long) 47,
	"XM_EIFFEL_SCANNER_SKELETON",
	names1361,
	types1361,
	attr_flags1361,
	gtypes1361,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1361,
	NULL
},
{
	(long) 47,
	(long) 47,
	"XM_EIFFEL_SCANNER",
	names1362,
	types1362,
	attr_flags1362,
	gtypes1362,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1362,
	NULL
},
{
	(long) 49,
	(long) 49,
	"XM_EIFFEL_SCANNER_DTD",
	names1363,
	types1363,
	attr_flags1363,
	gtypes1363,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1363,
	NULL
},
{
	(long) 52,
	(long) 52,
	"XM_EIFFEL_ENTITY_DEF",
	names1364,
	types1364,
	attr_flags1364,
	gtypes1364,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1364,
	NULL
},
{
	(long) 54,
	(long) 54,
	"XM_EIFFEL_PE_ENTITY_DEF",
	names1365,
	types1365,
	attr_flags1365,
	gtypes1365,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1365,
	NULL
},
{
	(long) 23,
	(long) 23,
	"YY_PARSER_SKELETON",
	names1366,
	types1366,
	attr_flags1366,
	gtypes1366,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1366,
	NULL
},
{
	(long) 24,
	(long) 24,
	"EWG_PARSER_SKELETON",
	names1367,
	types1367,
	attr_flags1367,
	gtypes1367,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1367,
	NULL
},
{
	(long) 72,
	(long) 72,
	"EWG_C_PARSER_SKELETON",
	names1368,
	types1368,
	attr_flags1368,
	gtypes1368,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1368,
	NULL
},
{
	(long) 140,
	(long) 140,
	"EWG_C_PARSER",
	names1369,
	types1369,
	attr_flags1369,
	gtypes1369,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1369,
	NULL
},
{
	(long) 39,
	(long) 39,
	"XM_EIFFEL_PARSER_SKELETON",
	names1370,
	types1370,
	attr_flags1370,
	gtypes1370,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1370,
	NULL
},
{
	(long) 83,
	(long) 83,
	"XM_EIFFEL_PARSER",
	names1371,
	types1371,
	attr_flags1371,
	gtypes1371,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1371,
	NULL
},
{
	(long) 0,
	(long) 0,
	"UT_STRING_FORMATTER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 5,
	(long) 5,
	"XM_DTD_ELEMENT_CONTENT",
	names1373,
	types1373,
	attr_flags1373,
	gtypes1373,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1373,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EWG_CONFIG_VALIDATOR",
	names1374,
	types1374,
	attr_flags1374,
	gtypes1374,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1374,
	NULL
},
{
	(long) 10,
	(long) 10,
	"EWG_ERROR_HANDLER",
	names1375,
	types1375,
	attr_flags1375,
	gtypes1375,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1375,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_ERROR",
	names1376,
	types1376,
	attr_flags1376,
	gtypes1376,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1376,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_SYNTAX_ERROR",
	names1377,
	types1377,
	attr_flags1377,
	gtypes1377,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1377,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_MISSING_COMMAND_LINE_PARAMETER_VALUE_ERROR",
	names1378,
	types1378,
	attr_flags1378,
	gtypes1378,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1378,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_MISSING_COMMAND_LINE_PARAMETER_ERROR",
	names1379,
	types1379,
	attr_flags1379,
	gtypes1379,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1379,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_ILLEGAL_REGULAR_EXPRESSION_IN_ATTRIBUTE_ERROR",
	names1380,
	types1380,
	attr_flags1380,
	gtypes1380,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1380,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_USAGE_MESSAGE",
	names1381,
	types1381,
	attr_flags1381,
	gtypes1381,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1381,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_INVALID_CLASS_NAME_ERROR",
	names1382,
	types1382,
	attr_flags1382,
	gtypes1382,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1382,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_QUITING_BECAUSE_CONFIG_FILE_HAD_ERRORS_ERROR",
	names1383,
	types1383,
	attr_flags1383,
	gtypes1383,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1383,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_MESSAGE",
	names1384,
	types1384,
	attr_flags1384,
	gtypes1384,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1384,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_UNKNOWN_CONSTRUCT_TYPE_ERROR",
	names1385,
	types1385,
	attr_flags1385,
	gtypes1385,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1385,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_UNKNOWN_WRAPPER_TYPE_ERROR",
	names1386,
	types1386,
	attr_flags1386,
	gtypes1386,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1386,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_CANNOT_WRITE_TO_FILE_ERROR",
	names1387,
	types1387,
	attr_flags1387,
	gtypes1387,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1387,
	NULL
},
{
	(long) 1,
	(long) 1,
	"UT_CANNOT_READ_FILE_ERROR",
	names1388,
	types1388,
	attr_flags1388,
	gtypes1388,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1388,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_UNEXPECTED_ELEMENT_ERROR",
	names1389,
	types1389,
	attr_flags1389,
	gtypes1389,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1389,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ET_XACE_ERROR",
	names1390,
	types1390,
	attr_flags1390,
	gtypes1390,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1390,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ET_XACE_MISSING_ELEMENT_ERROR",
	names1391,
	types1391,
	attr_flags1391,
	gtypes1391,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1391,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ET_XACE_MISSING_ATTRIBUTE_ERROR",
	names1392,
	types1392,
	attr_flags1392,
	gtypes1392,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1392,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ET_XACE_WRONG_ROOT_ELEMENT_ERROR",
	names1393,
	types1393,
	attr_flags1393,
	gtypes1393,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1393,
	NULL
},
{
	(long) 1,
	(long) 1,
	"ET_XACE_UNKNOWN_ELEMENT_ERROR",
	names1394,
	types1394,
	attr_flags1394,
	gtypes1394,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1394,
	NULL
},
{
	(long) 4,
	(long) 4,
	"EWG_CONFIG_PARSER",
	names1395,
	types1395,
	attr_flags1395,
	gtypes1395,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1395,
	NULL
},
{
	(long) 15,
	(long) 15,
	"EWG_KERNEL",
	names1396,
	types1396,
	attr_flags1396,
	gtypes1396,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1396,
	NULL
},
{
	(long) 16,
	(long) 16,
	"EWG",
	names1397,
	types1397,
	attr_flags1397,
	gtypes1397,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1397,
	NULL
},
{
	(long) 0,
	(long) 0,
	"KI_PATHNAME",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x5000,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 6,
	(long) 6,
	"KL_PATHNAME",
	names1399,
	types1399,
	attr_flags1399,
	gtypes1399,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1399,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_RENAMER",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 3,
	(long) 3,
	"EWG_C_DECLARATION_LIST_PRINTER",
	names1401,
	types1401,
	attr_flags1401,
	gtypes1401,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1401,
	NULL
},
{
	(long) 6,
	(long) 6,
	"EWG_C_GLUE_HEADER_ANSI_C_CALLBACK_WRAPPER_GENERATOR",
	names1402,
	types1402,
	attr_flags1402,
	gtypes1402,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1402,
	NULL
},
{
	(long) 7,
	(long) 7,
	"EWG_C_GLUE_CODE_ANSI_C_CALLBACK_WRAPPER_GENERATOR",
	names1403,
	types1403,
	attr_flags1403,
	gtypes1403,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1403,
	NULL
},
{
	(long) 12,
	(long) 12,
	"EWG_EIFFEL_API_FUNCTION_WRAPPER_GENERATOR",
	names1404,
	types1404,
	attr_flags1404,
	gtypes1404,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1404,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EWG_EIFFEL_API_UNION_WRAPPER_GENERATOR",
	names1405,
	types1405,
	attr_flags1405,
	gtypes1405,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1405,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EWG_EIFFEL_API_STRUCT_WRAPPER_GENERATOR",
	names1406,
	types1406,
	attr_flags1406,
	gtypes1406,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1406,
	NULL
},
{
	(long) 4,
	(long) 4,
	"EWG_EIFFEL_API_ENUM_WRAPPER_GENERATOR",
	names1407,
	types1407,
	attr_flags1407,
	gtypes1407,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1407,
	NULL
},
{
	(long) 4,
	(long) 4,
	"EWG_EIFFEL_API_MACRO_WRAPPER_GENERATOR",
	names1408,
	types1408,
	attr_flags1408,
	gtypes1408,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1408,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EWG_CONFIG_CALLBACK_WRAPPER_CLAUSE",
	names1409,
	types1409,
	attr_flags1409,
	gtypes1409,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1409,
	NULL
},
{
	(long) 2,
	(long) 2,
	"EWG_CONFIG_FUNCTION_WRAPPER_CLAUSE",
	names1410,
	types1410,
	attr_flags1410,
	gtypes1410,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1410,
	NULL
},
{
	(long) 4,
	(long) 4,
	"EWG_GENERATOR",
	names1411,
	types1411,
	attr_flags1411,
	gtypes1411,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1411,
	NULL
},
{
	(long) 5,
	(long) 5,
	"EWG_EIFFEL_WRAPPER_BUILDER",
	names1412,
	types1412,
	attr_flags1412,
	gtypes1412,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1412,
	NULL
},
{
	(long) 16,
	(long) 16,
	"EWG_EIFFEL_WRAPPER_SET",
	names1413,
	types1413,
	attr_flags1413,
	gtypes1413,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1413,
	NULL
},
{
	(long) 0,
	(long) 0,
	"EWG_EIFFEL_ABSTRACTION_ANSI_C_CALLBACK_SIGNATURE_GENERATOR",
	NULL,
	NULL,
	NULL,
	NULL,
	(uint16) 0x00,
	(void (*)()) 0,
	(long *) 0,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_CONFIG_COMPOSITE_DATA_TYPE_WRAPPER_CLAUSE",
	names1415,
	types1415,
	attr_flags1415,
	gtypes1415,
	(uint16) 0x5000,
	(void (*)()) 0,
	offsets1415,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_CONFIG_ENUM_WRAPPER_CLAUSE",
	names1416,
	types1416,
	attr_flags1416,
	gtypes1416,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1416,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_CONFIG_UNION_WRAPPER_CLAUSE",
	names1417,
	types1417,
	attr_flags1417,
	gtypes1417,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1417,
	NULL
},
{
	(long) 1,
	(long) 1,
	"EWG_CONFIG_STRUCT_WRAPPER_CLAUSE",
	names1418,
	types1418,
	attr_flags1418,
	gtypes1418,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1418,
	NULL
},
{
	(long) 4,
	(long) 4,
	"EWG_EIFFEL_ABSTRACTION_ANSI_C_CALLBACK_DISPATCHER_GENERATOR",
	names1419,
	types1419,
	attr_flags1419,
	gtypes1419,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1419,
	NULL
},
{
	(long) 32,
	(long) 32,
	"RX_PCRE_COMPILER",
	names1420,
	types1420,
	attr_flags1420,
	gtypes1420,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1420,
	NULL
},
{
	(long) 53,
	(long) 53,
	"RX_PCRE_MATCHER",
	names1421,
	types1421,
	attr_flags1421,
	gtypes1421,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1421,
	NULL
},
{
	(long) 53,
	(long) 53,
	"RX_PCRE_REGULAR_EXPRESSION",
	names1422,
	types1422,
	attr_flags1422,
	gtypes1422,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1422,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_STRING",
	names1423,
	types1423,
	attr_flags1423,
	gtypes1423,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1423,
	NULL
},
{
	(long) 8,
	(long) 8,
	"UC_UTF8_STRING",
	names1424,
	types1424,
	attr_flags1424,
	gtypes1424,
	(uint16) 0x00,
	(void (*)()) 0,
	offsets1424,
	NULL
},};


#ifdef __cplusplus
}
#endif
