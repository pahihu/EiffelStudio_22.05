#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ANY */
static EIF_TYPE_INDEX ptf0[] = {0xFFFF};
static struct eif_par_types par0 = {0, ptf0, (uint16) 0, (uint16) 0, (char) 0};

/* KL_PART_COMPARATOR [G#1] */
static EIF_TYPE_INDEX ptf1[] = {0,0xFFFF};
static struct eif_par_types par1 = {1, ptf1, (uint16) 1, (uint16) 1, (char) 0};

/* KL_PART_COMPARATOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf2[] = {0,0xFFFF};
static struct eif_par_types par2 = {2, ptf2, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SORTER [G#1] */
static EIF_TYPE_INDEX ptf3[] = {0,0xFFFF};
static struct eif_par_types par3 = {3, ptf3, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SORTER [INTEGER_32] */
static EIF_TYPE_INDEX ptf4[] = {0,0xFFFF};
static struct eif_par_types par4 = {4, ptf4, (uint16) 1, (uint16) 1, (char) 0};

/* C_DATE */
static EIF_TYPE_INDEX ptf5[] = {0,0xFFFF};
static struct eif_par_types par5 = {5, ptf5, (uint16) 1, (uint16) 0, (char) 0};

/* UT_ARRAY_FORMATTER */
static EIF_TYPE_INDEX ptf6[] = {0,0xFFFF};
static struct eif_par_types par6 = {6, ptf6, (uint16) 1, (uint16) 0, (char) 0};

/* UT_BOOLEAN_FORMATTER */
static EIF_TYPE_INDEX ptf7[] = {0,0xFFFF};
static struct eif_par_types par7 = {7, ptf7, (uint16) 1, (uint16) 0, (char) 0};

/* KL_BOOLEAN_ROUTINES */
static EIF_TYPE_INDEX ptf8[] = {0,0xFFFF};
static struct eif_par_types par8 = {8, ptf8, (uint16) 1, (uint16) 0, (char) 0};

/* BASE_REDIRECTION */
static EIF_TYPE_INDEX ptf9[] = {0,0xFFFF};
static struct eif_par_types par9 = {9, ptf9, (uint16) 1, (uint16) 0, (char) 0};

/* KL_STANDARD_FILES */
static EIF_TYPE_INDEX ptf10[] = {0,0xFFFF};
static struct eif_par_types par10 = {10, ptf10, (uint16) 1, (uint16) 0, (char) 0};

/* RX_CHARACTER_SET */
static EIF_TYPE_INDEX ptf11[] = {0,0xFFFF};
static struct eif_par_types par11 = {11, ptf11, (uint16) 1, (uint16) 0, (char) 0};

/* KL_ANY_ROUTINES */
static EIF_TYPE_INDEX ptf12[] = {0,0xFFFF};
static struct eif_par_types par12 = {12, ptf12, (uint16) 1, (uint16) 0, (char) 0};

/* DESCRIPTOR_CACHE */
static EIF_TYPE_INDEX ptf13[] = {0,0xFFFF};
static struct eif_par_types par13 = {13, ptf13, (uint16) 1, (uint16) 0, (char) 0};

/* BASE_PROCESS_FACTORY */
static EIF_TYPE_INDEX ptf14[] = {0,0xFFFF};
static struct eif_par_types par14 = {14, ptf14, (uint16) 1, (uint16) 0, (char) 0};

/* PROCESS_COMMAND_RESULT */
static EIF_TYPE_INDEX ptf15[] = {0,0xFFFF};
static struct eif_par_types par15 = {15, ptf15, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_PHASE_1_MACRO */
static EIF_TYPE_INDEX ptf16[] = {0,0xFFFF};
static struct eif_par_types par16 = {16, ptf16, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_PHASE_1_ARRAY */
static EIF_TYPE_INDEX ptf17[] = {0,0xFFFF};
static struct eif_par_types par17 = {17, ptf17, (uint16) 1, (uint16) 0, (char) 0};

/* KL_HASH_FUNCTION [G#1] */
static EIF_TYPE_INDEX ptf18[] = {0,0xFFFF};
static struct eif_par_types par18 = {18, ptf18, (uint16) 1, (uint16) 1, (char) 0};

/* KL_HASH_FUNCTION [NATURAL_32] */
static EIF_TYPE_INDEX ptf19[] = {0,0xFFFF};
static struct eif_par_types par19 = {19, ptf19, (uint16) 1, (uint16) 1, (char) 0};

/* KL_HASH_FUNCTION [INTEGER_32] */
static EIF_TYPE_INDEX ptf20[] = {0,0xFFFF};
static struct eif_par_types par20 = {20, ptf20, (uint16) 1, (uint16) 1, (char) 0};

/* XM_EIFFEL_DECLARATION */
static EIF_TYPE_INDEX ptf21[] = {0,0xFFFF};
static struct eif_par_types par21 = {21, ptf21, (uint16) 1, (uint16) 0, (char) 0};

/* VERSIONABLE */
static EIF_TYPE_INDEX ptf22[] = {0,0xFFFF};
static struct eif_par_types par22 = {22, ptf22, (uint16) 1, (uint16) 0, (char) 0};

/* PROCESS_MISC */
static EIF_TYPE_INDEX ptf23[] = {0,0xFFFF};
static struct eif_par_types par23 = {23, ptf23, (uint16) 1, (uint16) 0, (char) 0};

/* KL_OPERATING_SYSTEM */
static EIF_TYPE_INDEX ptf24[] = {0,0xFFFF};
static struct eif_par_types par24 = {24, ptf24, (uint16) 1, (uint16) 0, (char) 0};

/* WRAPC_MACRO_HEADER_PARSER */
static EIF_TYPE_INDEX ptf25[] = {0,0xFFFF};
static struct eif_par_types par25 = {25, ptf25, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_PHASE_1_STORAGE_CLASS_SPECIFIERS */
static EIF_TYPE_INDEX ptf26[] = {0,0xFFFF};
static struct eif_par_types par26 = {26, ptf26, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_PHASE_1_DECLARATION */
static EIF_TYPE_INDEX ptf27[] = {0,0xFFFF};
static struct eif_par_types par27 = {27, ptf27, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SPECIAL_ROUTINES [G#1] */
static EIF_TYPE_INDEX ptf28[] = {0,0xFFFF};
static struct eif_par_types par28 = {28, ptf28, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SPECIAL_ROUTINES [BOOLEAN] */
static EIF_TYPE_INDEX ptf29[] = {0,0xFFFF};
static struct eif_par_types par29 = {29, ptf29, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SPECIAL_ROUTINES [NATURAL_32] */
static EIF_TYPE_INDEX ptf30[] = {0,0xFFFF};
static struct eif_par_types par30 = {30, ptf30, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SPECIAL_ROUTINES [NATURAL_64] */
static EIF_TYPE_INDEX ptf31[] = {0,0xFFFF};
static struct eif_par_types par31 = {31, ptf31, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SPECIAL_ROUTINES [INTEGER_32] */
static EIF_TYPE_INDEX ptf32[] = {0,0xFFFF};
static struct eif_par_types par32 = {32, ptf32, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SPECIAL_ROUTINES [CHARACTER_8] */
static EIF_TYPE_INDEX ptf33[] = {0,0xFFFF};
static struct eif_par_types par33 = {33, ptf33, (uint16) 1, (uint16) 1, (char) 0};

/* EWG_C_PHASE_1_PARAMETER_TYPE_LIST */
static EIF_TYPE_INDEX ptf34[] = {0,0xFFFF};
static struct eif_par_types par34 = {34, ptf34, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_PHASE_1_POINTER */
static EIF_TYPE_INDEX ptf35[] = {0,0xFFFF};
static struct eif_par_types par35 = {35, ptf35, (uint16) 1, (uint16) 0, (char) 0};

/* XM_POSITION_TABLE */
static EIF_TYPE_INDEX ptf36[] = {0,0xFFFF};
static struct eif_par_types par36 = {36, ptf36, (uint16) 1, (uint16) 0, (char) 0};

/* SYSTEM_ENCODINGS */
static EIF_TYPE_INDEX ptf37[] = {0,0xFFFF};
static struct eif_par_types par37 = {37, ptf37, (uint16) 1, (uint16) 0, (char) 0};

/* CODE_PAGE_CONSTANTS */
static EIF_TYPE_INDEX ptf38[] = {0,0xFFFF};
static struct eif_par_types par38 = {38, ptf38, (uint16) 1, (uint16) 0, (char) 0};

/* ENCODING */
static EIF_TYPE_INDEX ptf39[] = {0,0xFFFF};
static struct eif_par_types par39 = {39, ptf39, (uint16) 1, (uint16) 0, (char) 0};

/* SYSTEM_STRING_FACTORY */
static EIF_TYPE_INDEX ptf40[] = {0,0xFFFF};
static struct eif_par_types par40 = {40, ptf40, (uint16) 1, (uint16) 0, (char) 0};

/* CHARACTER_PROPERTY */
static EIF_TYPE_INDEX ptf41[] = {0,0xFFFF};
static struct eif_par_types par41 = {41, ptf41, (uint16) 1, (uint16) 0, (char) 0};

/* WRAPC_MACRO_PARSER */
static EIF_TYPE_INDEX ptf42[] = {0,0xFFFF};
static struct eif_par_types par42 = {42, ptf42, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_CONFIG_RULE */
static EIF_TYPE_INDEX ptf43[] = {0,0xFFFF};
static struct eif_par_types par43 = {43, ptf43, (uint16) 1, (uint16) 0, (char) 0};

/* SYSTEM_STRING */
static EIF_TYPE_INDEX ptf44[] = {0,0xFFFF};
static struct eif_par_types par44 = {44, ptf44, (uint16) 1, (uint16) 0, (char) 0};

/* RT_DBG_EXECUTION_PARAMETERS */
static EIF_TYPE_INDEX ptf45[] = {0,0xFFFF};
static struct eif_par_types par45 = {45, ptf45, (uint16) 1, (uint16) 0, (char) 0};

/* reference UTF_CONVERTER */
static EIF_TYPE_INDEX ptf46[] = {0,0xFFFF};
static struct eif_par_types par46 = {46, ptf46, (uint16) 1, (uint16) 0, (char) 1};

/* UTF_CONVERTER */
static EIF_TYPE_INDEX ptf47[] = {46,0xFFFF};
static struct eif_par_types par47 = {47, ptf47, (uint16) 1, (uint16) 0, (char) 1};

/* ISE_RUNTIME */
static EIF_TYPE_INDEX ptf48[] = {0,0xFFFF};
static struct eif_par_types par48 = {48, ptf48, (uint16) 1, (uint16) 0, (char) 0};

/* NATIVE_ARRAY [G#1] */
static EIF_TYPE_INDEX ptf49[] = {0,0xFFFF};
static struct eif_par_types par49 = {49, ptf49, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [INTEGER_32] */
static EIF_TYPE_INDEX ptf50[] = {0,0xFFFF};
static struct eif_par_types par50 = {50, ptf50, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [BOOLEAN] */
static EIF_TYPE_INDEX ptf51[] = {0,0xFFFF};
static struct eif_par_types par51 = {51, ptf51, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [NATURAL_64] */
static EIF_TYPE_INDEX ptf52[] = {0,0xFFFF};
static struct eif_par_types par52 = {52, ptf52, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [NATURAL_32] */
static EIF_TYPE_INDEX ptf53[] = {0,0xFFFF};
static struct eif_par_types par53 = {53, ptf53, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [CHARACTER_32] */
static EIF_TYPE_INDEX ptf54[] = {0,0xFFFF};
static struct eif_par_types par54 = {54, ptf54, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [CHARACTER_8] */
static EIF_TYPE_INDEX ptf55[] = {0,0xFFFF};
static struct eif_par_types par55 = {55, ptf55, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [NATURAL_8] */
static EIF_TYPE_INDEX ptf56[] = {0,0xFFFF};
static struct eif_par_types par56 = {56, ptf56, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [NATURAL_16] */
static EIF_TYPE_INDEX ptf57[] = {0,0xFFFF};
static struct eif_par_types par57 = {57, ptf57, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [POINTER] */
static EIF_TYPE_INDEX ptf58[] = {0,0xFFFF};
static struct eif_par_types par58 = {58, ptf58, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [REAL_32] */
static EIF_TYPE_INDEX ptf59[] = {0,0xFFFF};
static struct eif_par_types par59 = {59, ptf59, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [REAL_64] */
static EIF_TYPE_INDEX ptf60[] = {0,0xFFFF};
static struct eif_par_types par60 = {60, ptf60, (uint16) 1, (uint16) 1, (char) 0};

/* STD_FILES */
static EIF_TYPE_INDEX ptf61[] = {0,0xFFFF};
static struct eif_par_types par61 = {61, ptf61, (uint16) 1, (uint16) 0, (char) 0};

/* DT_SHARED_WEEK_DAYS_FROM_SUNDAY */
static EIF_TYPE_INDEX ptf62[] = {0,0xFFFF};
static struct eif_par_types par62 = {62, ptf62, (uint16) 1, (uint16) 0, (char) 0};

/* KL_PART_COMPARABLE */
static EIF_TYPE_INDEX ptf63[] = {0,0xFFFF};
static struct eif_par_types par63 = {63, ptf63, (uint16) 1, (uint16) 0, (char) 0};

/* RT_DEBUGGER */
static EIF_TYPE_INDEX ptf64[] = {0,0xFFFF};
static struct eif_par_types par64 = {64, ptf64, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_STRING_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf65[] = {0,0xFFFF};
static struct eif_par_types par65 = {65, ptf65, (uint16) 1, (uint16) 0, (char) 0};

/* KI_PLATFORM */
static EIF_TYPE_INDEX ptf66[] = {0,0xFFFF};
static struct eif_par_types par66 = {66, ptf66, (uint16) 1, (uint16) 0, (char) 0};

/* UT_CHARACTER_CODES */
static EIF_TYPE_INDEX ptf67[] = {0,0xFFFF};
static struct eif_par_types par67 = {67, ptf67, (uint16) 1, (uint16) 0, (char) 0};

/* KI_SYSTEM_CLOCK */
static EIF_TYPE_INDEX ptf68[] = {0,0xFFFF};
static struct eif_par_types par68 = {68, ptf68, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SYSTEM_CLOCK */
static EIF_TYPE_INDEX ptf69[] = {68,0xFFFF};
static struct eif_par_types par69 = {69, ptf69, (uint16) 1, (uint16) 0, (char) 0};

/* YY_PARSER */
static EIF_TYPE_INDEX ptf70[] = {0,0xFFFF};
static struct eif_par_types par70 = {70, ptf70, (uint16) 1, (uint16) 0, (char) 0};

/* SHARED_EXECUTION_ENVIRONMENT */
static EIF_TYPE_INDEX ptf71[] = {0,0xFFFF};
static struct eif_par_types par71 = {71, ptf71, (uint16) 1, (uint16) 0, (char) 0};

/* BASE_PROCESS */
static EIF_TYPE_INDEX ptf72[] = {71,0xFFFF};
static struct eif_par_types par72 = {72, ptf72, (uint16) 1, (uint16) 0, (char) 0};

/* KL_ANY */
static EIF_TYPE_INDEX ptf73[] = {0,0xFFFF};
static struct eif_par_types par73 = {73, ptf73, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_PLATFORM */
static EIF_TYPE_INDEX ptf74[] = {73,0xFFFF};
static struct eif_par_types par74 = {74, ptf74, (uint16) 1, (uint16) 0, (char) 0};

/* KL_CHARACTER_ROUTINES */
static EIF_TYPE_INDEX ptf75[] = {74,0xFFFF};
static struct eif_par_types par75 = {75, ptf75, (uint16) 1, (uint16) 0, (char) 0};

/* UC_UNICODE_CONSTANTS */
static EIF_TYPE_INDEX ptf76[] = {74,0xFFFF};
static struct eif_par_types par76 = {76, ptf76, (uint16) 1, (uint16) 0, (char) 0};

/* UC_STRING_HANDLER */
static EIF_TYPE_INDEX ptf77[] = {0,0xFFFF};
static struct eif_par_types par77 = {77, ptf77, (uint16) 1, (uint16) 0, (char) 0};

/* KI_OUTPUT_STREAM [CHARACTER_8] */
static EIF_TYPE_INDEX ptf78[] = {0,0xFFFF};
static struct eif_par_types par78 = {78, ptf78, (uint16) 1, (uint16) 1, (char) 0};

/* RX_PCRE_SHARED_CHARACTER_SETS */
static EIF_TYPE_INDEX ptf79[] = {0,0xFFFF};
static struct eif_par_types par79 = {79, ptf79, (uint16) 1, (uint16) 0, (char) 0};

/* RX_PCRE_OPTION_ROUTINES */
static EIF_TYPE_INDEX ptf80[] = {0,0xFFFF};
static struct eif_par_types par80 = {80, ptf80, (uint16) 1, (uint16) 0, (char) 0};

/* RX_PCRE_ERROR_CONSTANTS */
static EIF_TYPE_INDEX ptf81[] = {0,0xFFFF};
static struct eif_par_types par81 = {81, ptf81, (uint16) 1, (uint16) 0, (char) 0};

/* RX_PCRE_BYTE_CODE_CONSTANTS */
static EIF_TYPE_INDEX ptf82[] = {0,0xFFFF};
static struct eif_par_types par82 = {82, ptf82, (uint16) 1, (uint16) 0, (char) 0};

/* KL_CELL [G#1] */
static EIF_TYPE_INDEX ptf83[] = {0,0xFFFF};
static struct eif_par_types par83 = {83, ptf83, (uint16) 1, (uint16) 1, (char) 0};

/* KL_CELL [CHARACTER_8] */
static EIF_TYPE_INDEX ptf84[] = {0,0xFFFF};
static struct eif_par_types par84 = {84, ptf84, (uint16) 1, (uint16) 1, (char) 0};

/* KL_LINKABLE [G#1] */
static EIF_TYPE_INDEX ptf85[] = {83,0xFFF8,1,0xFFFF};
static struct eif_par_types par85 = {85, ptf85, (uint16) 1, (uint16) 1, (char) 0};

/* KL_LINKABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf86[] = {84,936,0xFFFF};
static struct eif_par_types par86 = {86, ptf86, (uint16) 1, (uint16) 1, (char) 0};

/* CODE_SETS */
static EIF_TYPE_INDEX ptf87[] = {0,0xFFFF};
static struct eif_par_types par87 = {87, ptf87, (uint16) 1, (uint16) 0, (char) 0};

/* OBJECT_GRAPH_TRAVERSABLE */
static EIF_TYPE_INDEX ptf88[] = {0,0xFFFF};
static struct eif_par_types par88 = {88, ptf88, (uint16) 1, (uint16) 0, (char) 0};

/* OBJECT_GRAPH_BREADTH_FIRST_TRAVERSABLE */
static EIF_TYPE_INDEX ptf89[] = {88,0xFFFF};
static struct eif_par_types par89 = {89, ptf89, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_AST_DECLARATION_PROCESSOR */
static EIF_TYPE_INDEX ptf90[] = {0,0xFFFF};
static struct eif_par_types par90 = {90, ptf90, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_AST_DECLARATION_NULL_PROCESSOR */
static EIF_TYPE_INDEX ptf91[] = {90,0xFFFF};
static struct eif_par_types par91 = {91, ptf91, (uint16) 1, (uint16) 0, (char) 0};

/* KI_EXCEPTIONS */
static EIF_TYPE_INDEX ptf92[] = {0,0xFFFF};
static struct eif_par_types par92 = {92, ptf92, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_SHARED_STRUCT_FEATURE_NAMES */
static EIF_TYPE_INDEX ptf93[] = {0,0xFFFF};
static struct eif_par_types par93 = {93, ptf93, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_SHARED_ANY_FEATURE_NAMES */
static EIF_TYPE_INDEX ptf94[] = {0,0xFFFF};
static struct eif_par_types par94 = {94, ptf94, (uint16) 1, (uint16) 0, (char) 0};

/* KI_BUFFER [G#1] */
static EIF_TYPE_INDEX ptf95[] = {0,0xFFFF};
static struct eif_par_types par95 = {95, ptf95, (uint16) 1, (uint16) 1, (char) 0};

/* KI_BUFFER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf96[] = {0,0xFFFF};
static struct eif_par_types par96 = {96, ptf96, (uint16) 1, (uint16) 1, (char) 0};

/* KI_CHARACTER_BUFFER */
static EIF_TYPE_INDEX ptf97[] = {96,936,0xFFFF};
static struct eif_par_types par97 = {97, ptf97, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_CONFIG_SHARED_WRAPPER_TYPE_NAMES */
static EIF_TYPE_INDEX ptf98[] = {0,0xFFFF};
static struct eif_par_types par98 = {98, ptf98, (uint16) 1, (uint16) 0, (char) 0};

/* XM_CALLBACKS_FILTER_FACTORY */
static EIF_TYPE_INDEX ptf99[] = {0,0xFFFF};
static struct eif_par_types par99 = {99, ptf99, (uint16) 1, (uint16) 0, (char) 0};

/* XM_ERROR_CODES */
static EIF_TYPE_INDEX ptf100[] = {0,0xFFFF};
static struct eif_par_types par100 = {100, ptf100, (uint16) 1, (uint16) 0, (char) 0};

/* XM_SOURCE */
static EIF_TYPE_INDEX ptf101[] = {0,0xFFFF};
static struct eif_par_types par101 = {101, ptf101, (uint16) 1, (uint16) 0, (char) 0};

/* XM_URI_SOURCE */
static EIF_TYPE_INDEX ptf102[] = {101,0xFFFF};
static struct eif_par_types par102 = {102, ptf102, (uint16) 1, (uint16) 0, (char) 0};

/* XM_DEFAULT_URI_SOURCE */
static EIF_TYPE_INDEX ptf103[] = {102,0xFFFF};
static struct eif_par_types par103 = {103, ptf103, (uint16) 1, (uint16) 0, (char) 0};

/* XM_EXTERNAL_RESOLVER */
static EIF_TYPE_INDEX ptf104[] = {0,0xFFFF};
static struct eif_par_types par104 = {104, ptf104, (uint16) 1, (uint16) 0, (char) 0};

/* XM_NULL_EXTERNAL_RESOLVER */
static EIF_TYPE_INDEX ptf105[] = {104,0xFFFF};
static struct eif_par_types par105 = {105, ptf105, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_AST_TYPE_PROCESSOR */
static EIF_TYPE_INDEX ptf106[] = {0,0xFFFF};
static struct eif_par_types par106 = {106, ptf106, (uint16) 1, (uint16) 0, (char) 0};

/* SYSTEM_ENCODINGS_I */
static EIF_TYPE_INDEX ptf107[] = {0,0xFFFF};
static struct eif_par_types par107 = {107, ptf107, (uint16) 1, (uint16) 0, (char) 0};

/* OBJECT_GRAPH_MARKER */
static EIF_TYPE_INDEX ptf108[] = {0,0xFFFF};
static struct eif_par_types par108 = {108, ptf108, (uint16) 1, (uint16) 0, (char) 0};

/* MATH_CONST */
static EIF_TYPE_INDEX ptf109[] = {0,0xFFFF};
static struct eif_par_types par109 = {109, ptf109, (uint16) 1, (uint16) 0, (char) 0};

/* DOUBLE_MATH */
static EIF_TYPE_INDEX ptf110[] = {109,0xFFFF};
static struct eif_par_types par110 = {110, ptf110, (uint16) 1, (uint16) 0, (char) 0};

/* KL_DOUBLE_ROUTINES */
static EIF_TYPE_INDEX ptf111[] = {110,0xFFF7,74,0xFFFF};
static struct eif_par_types par111 = {111, ptf111, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_C_PHASE_1_AST_FACTORY */
static EIF_TYPE_INDEX ptf112[] = {0,0xFFFF};
static struct eif_par_types par112 = {112, ptf112, (uint16) 1, (uint16) 0, (char) 0};

/* DT_SHARED_SYSTEM_CLOCK */
static EIF_TYPE_INDEX ptf113[] = {0,0xFFFF};
static struct eif_par_types par113 = {113, ptf113, (uint16) 1, (uint16) 0, (char) 0};

/* KL_IMPORTED_DOUBLE_ROUTINES */
static EIF_TYPE_INDEX ptf114[] = {0,0xFFFF};
static struct eif_par_types par114 = {114, ptf114, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_EXECUTION_ENVIRONMENT */
static EIF_TYPE_INDEX ptf115[] = {0,0xFFFF};
static struct eif_par_types par115 = {115, ptf115, (uint16) 1, (uint16) 0, (char) 0};

/* REFLECTOR_HELPER */
static EIF_TYPE_INDEX ptf116[] = {0,0xFFFF};
static struct eif_par_types par116 = {116, ptf116, (uint16) 1, (uint16) 0, (char) 0};

/* REFACTORING_HELPER */
static EIF_TYPE_INDEX ptf117[] = {0,0xFFFF};
static struct eif_par_types par117 = {117, ptf117, (uint16) 1, (uint16) 0, (char) 0};

/* SHARED_PROCESS_MISC */
static EIF_TYPE_INDEX ptf118[] = {0,0xFFFF};
static struct eif_par_types par118 = {118, ptf118, (uint16) 1, (uint16) 0, (char) 0};

/* EXCEPTION_MANAGER */
static EIF_TYPE_INDEX ptf119[] = {0,0xFFFF};
static struct eif_par_types par119 = {119, ptf119, (uint16) 1, (uint16) 0, (char) 0};

/* ISE_EXCEPTION_MANAGER */
static EIF_TYPE_INDEX ptf120[] = {119,0xFFFF};
static struct eif_par_types par120 = {120, ptf120, (uint16) 1, (uint16) 0, (char) 0};

/* EXCEP_CONST */
static EIF_TYPE_INDEX ptf121[] = {0,0xFFFF};
static struct eif_par_types par121 = {121, ptf121, (uint16) 1, (uint16) 0, (char) 0};

/* CELL [G#1] */
static EIF_TYPE_INDEX ptf122[] = {0,0xFFFF};
static struct eif_par_types par122 = {122, ptf122, (uint16) 1, (uint16) 1, (char) 0};

/* CELL [CHARACTER_32] */
static EIF_TYPE_INDEX ptf123[] = {0,0xFFFF};
static struct eif_par_types par123 = {123, ptf123, (uint16) 1, (uint16) 1, (char) 0};

/* CELL [NATURAL_64] */
static EIF_TYPE_INDEX ptf124[] = {0,0xFFFF};
static struct eif_par_types par124 = {124, ptf124, (uint16) 1, (uint16) 1, (char) 0};

/* CELL [INTEGER_32] */
static EIF_TYPE_INDEX ptf125[] = {0,0xFFFF};
static struct eif_par_types par125 = {125, ptf125, (uint16) 1, (uint16) 1, (char) 0};

/* LINKABLE [G#1] */
static EIF_TYPE_INDEX ptf126[] = {122,0xFFF8,1,0xFFFF};
static struct eif_par_types par126 = {126, ptf126, (uint16) 1, (uint16) 1, (char) 0};

/* LINKABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf127[] = {125,906,0xFFFF};
static struct eif_par_types par127 = {127, ptf127, (uint16) 1, (uint16) 1, (char) 0};

/* OPERATING_ENVIRONMENT */
static EIF_TYPE_INDEX ptf128[] = {0,0xFFFF};
static struct eif_par_types par128 = {128, ptf128, (uint16) 1, (uint16) 0, (char) 0};

/* MEMORY_STRUCTURE */
static EIF_TYPE_INDEX ptf129[] = {0,0xFFFF};
static struct eif_par_types par129 = {129, ptf129, (uint16) 1, (uint16) 0, (char) 0};

/* UNIX_SIGNALS */
static EIF_TYPE_INDEX ptf130[] = {0,0xFFFF};
static struct eif_par_types par130 = {130, ptf130, (uint16) 1, (uint16) 0, (char) 0};

/* PROCESS_UNIX_OS */
static EIF_TYPE_INDEX ptf131[] = {130,0xFFFF};
static struct eif_par_types par131 = {131, ptf131, (uint16) 1, (uint16) 0, (char) 0};

/* UNIX_PIPE_FACTORY */
static EIF_TYPE_INDEX ptf132[] = {131,0xFFFF};
static struct eif_par_types par132 = {132, ptf132, (uint16) 1, (uint16) 0, (char) 0};

/* XM_UNICODE_CHARACTERS */
static EIF_TYPE_INDEX ptf133[] = {0,0xFFFF};
static struct eif_par_types par133 = {133, ptf133, (uint16) 1, (uint16) 0, (char) 0};

/* XM_UNICODE_CHARACTERS_1_1 */
static EIF_TYPE_INDEX ptf134[] = {133,0xFFFF};
static struct eif_par_types par134 = {134, ptf134, (uint16) 1, (uint16) 0, (char) 0};

/* XM_UNICODE_CHARACTERS_1_0 */
static EIF_TYPE_INDEX ptf135[] = {133,0xFFFF};
static struct eif_par_types par135 = {135, ptf135, (uint16) 1, (uint16) 0, (char) 0};

/* KI_FILE_SYSTEM_ENTRY */
static EIF_TYPE_INDEX ptf136[] = {0,0xFFFF};
static struct eif_par_types par136 = {136, ptf136, (uint16) 1, (uint16) 0, (char) 0};

/* KI_FILE */
static EIF_TYPE_INDEX ptf137[] = {136,0xFFFF};
static struct eif_par_types par137 = {137, ptf137, (uint16) 1, (uint16) 0, (char) 0};

/* KL_VALUES [G#1, G#2] */
static EIF_TYPE_INDEX ptf138[] = {0,0xFFFF};
static struct eif_par_types par138 = {138, ptf138, (uint16) 1, (uint16) 2, (char) 0};

/* KL_VALUES [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf139[] = {0,0xFFFF};
static struct eif_par_types par139 = {139, ptf139, (uint16) 1, (uint16) 2, (char) 0};

/* KL_VALUES [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf140[] = {0,0xFFFF};
static struct eif_par_types par140 = {140, ptf140, (uint16) 1, (uint16) 2, (char) 0};

/* KL_VALUES [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf141[] = {0,0xFFFF};
static struct eif_par_types par141 = {141, ptf141, (uint16) 1, (uint16) 2, (char) 0};

/* KL_VALUES [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf142[] = {0,0xFFFF};
static struct eif_par_types par142 = {142, ptf142, (uint16) 1, (uint16) 2, (char) 0};

/* XM_EIFFEL_PARSER_ERRORS */
static EIF_TYPE_INDEX ptf143[] = {0,0xFFFF};
static struct eif_par_types par143 = {143, ptf143, (uint16) 1, (uint16) 0, (char) 0};

/* XM_DTD_CALLBACKS */
static EIF_TYPE_INDEX ptf144[] = {0,0xFFFF};
static struct eif_par_types par144 = {144, ptf144, (uint16) 1, (uint16) 0, (char) 0};

/* XM_DTD_CALLBACKS_NULL */
static EIF_TYPE_INDEX ptf145[] = {144,0xFFFF};
static struct eif_par_types par145 = {145, ptf145, (uint16) 1, (uint16) 0, (char) 0};

/* KL_IMPORTED_BOOLEAN_ROUTINES */
static EIF_TYPE_INDEX ptf146[] = {0,0xFFFF};
static struct eif_par_types par146 = {146, ptf146, (uint16) 1, (uint16) 0, (char) 0};

/* DS_CELL [G#1] */
static EIF_TYPE_INDEX ptf147[] = {0,0xFFFF};
static struct eif_par_types par147 = {147, ptf147, (uint16) 1, (uint16) 1, (char) 0};

/* DS_CELL [BOOLEAN] */
static EIF_TYPE_INDEX ptf148[] = {0,0xFFFF};
static struct eif_par_types par148 = {148, ptf148, (uint16) 1, (uint16) 1, (char) 0};

/* DS_CELL [INTEGER_32] */
static EIF_TYPE_INDEX ptf149[] = {0,0xFFFF};
static struct eif_par_types par149 = {149, ptf149, (uint16) 1, (uint16) 1, (char) 0};

/* DS_CELL [CHARACTER_8] */
static EIF_TYPE_INDEX ptf150[] = {0,0xFFFF};
static struct eif_par_types par150 = {150, ptf150, (uint16) 1, (uint16) 1, (char) 0};

/* DS_PAIR [G#1, G#2] */
static EIF_TYPE_INDEX ptf151[] = {147,0xFFF8,1,0xFFFF};
static struct eif_par_types par151 = {151, ptf151, (uint16) 1, (uint16) 2, (char) 0};

/* DS_LINKABLE [G#1] */
static EIF_TYPE_INDEX ptf152[] = {147,0xFFF8,1,0xFFFF};
static struct eif_par_types par152 = {152, ptf152, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf153[] = {148,939,0xFFFF};
static struct eif_par_types par153 = {153, ptf153, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf154[] = {149,906,0xFFFF};
static struct eif_par_types par154 = {154, ptf154, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf155[] = {150,936,0xFFFF};
static struct eif_par_types par155 = {155, ptf155, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINKABLE [G#1] */
static EIF_TYPE_INDEX ptf156[] = {152,0xFFF8,1,0xFFFF};
static struct eif_par_types par156 = {156, ptf156, (uint16) 1, (uint16) 1, (char) 0};

/* ENCODING_HELPER */
static EIF_TYPE_INDEX ptf157[] = {0,0xFFFF};
static struct eif_par_types par157 = {157, ptf157, (uint16) 1, (uint16) 0, (char) 0};

/* SYSTEM_ENCODINGS_IMP */
static EIF_TYPE_INDEX ptf158[] = {107,0xFFFF};
static struct eif_par_types par158 = {158, ptf158, (uint16) 1, (uint16) 0, (char) 0};

/* UC_IMPORTED_UTF32_ROUTINES */
static EIF_TYPE_INDEX ptf159[] = {0,0xFFFF};
static struct eif_par_types par159 = {159, ptf159, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_CL_ATTRIBUTE_CONSTANTS */
static EIF_TYPE_INDEX ptf160[] = {0,0xFFFF};
static struct eif_par_types par160 = {160, ptf160, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_STREAMS */
static EIF_TYPE_INDEX ptf161[] = {0,0xFFFF};
static struct eif_par_types par161 = {161, ptf161, (uint16) 1, (uint16) 0, (char) 0};

/* UT_CHARACTER_32_CODES */
static EIF_TYPE_INDEX ptf162[] = {0,0xFFFF};
static struct eif_par_types par162 = {162, ptf162, (uint16) 1, (uint16) 0, (char) 0};

/* XM_DTD_CALLBACKS_SOURCE */
static EIF_TYPE_INDEX ptf163[] = {0,0xFFFF};
static struct eif_par_types par163 = {163, ptf163, (uint16) 1, (uint16) 0, (char) 0};

/* XM_FORWARD_DTD_CALLBACKS */
static EIF_TYPE_INDEX ptf164[] = {163,0xFFF7,144,0xFFFF};
static struct eif_par_types par164 = {164, ptf164, (uint16) 2, (uint16) 0, (char) 0};

/* XM_NODE_PROCESSOR */
static EIF_TYPE_INDEX ptf165[] = {0,0xFFFF};
static struct eif_par_types par165 = {165, ptf165, (uint16) 1, (uint16) 0, (char) 0};

/* XM_NODE_TYPER */
static EIF_TYPE_INDEX ptf166[] = {165,0xFFFF};
static struct eif_par_types par166 = {166, ptf166, (uint16) 1, (uint16) 0, (char) 0};

/* XM_TREE_TO_EVENTS */
static EIF_TYPE_INDEX ptf167[] = {165,0xFFFF};
static struct eif_par_types par167 = {167, ptf167, (uint16) 1, (uint16) 0, (char) 0};

/* KI_INPUT_STREAM [G#1] */
static EIF_TYPE_INDEX ptf168[] = {0,0xFFFF};
static struct eif_par_types par168 = {168, ptf168, (uint16) 1, (uint16) 1, (char) 0};

/* KI_INPUT_STREAM [CHARACTER_8] */
static EIF_TYPE_INDEX ptf169[] = {0,0xFFFF};
static struct eif_par_types par169 = {169, ptf169, (uint16) 1, (uint16) 1, (char) 0};

/* EWG_C_AST_SHARED_DECLARATION_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf170[] = {0,0xFFFF};
static struct eif_par_types par170 = {170, ptf170, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_AST_DECLARATION_SET */
static EIF_TYPE_INDEX ptf171[] = {170,0xFFFF};
static struct eif_par_types par171 = {171, ptf171, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_AST_SHARED_TYPE_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf172[] = {0,0xFFFF};
static struct eif_par_types par172 = {172, ptf172, (uint16) 1, (uint16) 0, (char) 0};

/* RT_EXTENSION_COMMON */
static EIF_TYPE_INDEX ptf173[] = {0,0xFFFF};
static struct eif_par_types par173 = {173, ptf173, (uint16) 1, (uint16) 0, (char) 0};

/* RT_EXTENSION_GENERAL */
static EIF_TYPE_INDEX ptf174[] = {173,0xFFFF};
static struct eif_par_types par174 = {174, ptf174, (uint16) 1, (uint16) 0, (char) 0};

/* RT_EXTENSION */
static EIF_TYPE_INDEX ptf175[] = {174,0xFFFF};
static struct eif_par_types par175 = {175, ptf175, (uint16) 1, (uint16) 0, (char) 0};

/* RT_DBG_COMMON */
static EIF_TYPE_INDEX ptf176[] = {173,0xFFFF};
static struct eif_par_types par176 = {176, ptf176, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_SEARCHER */
static EIF_TYPE_INDEX ptf177[] = {0,0xFFFF};
static struct eif_par_types par177 = {177, ptf177, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_32_SEARCHER */
static EIF_TYPE_INDEX ptf178[] = {177,0xFFFF};
static struct eif_par_types par178 = {178, ptf178, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_8_SEARCHER */
static EIF_TYPE_INDEX ptf179[] = {177,0xFFFF};
static struct eif_par_types par179 = {179, ptf179, (uint16) 1, (uint16) 0, (char) 0};

/* NUMERIC_INFORMATION */
static EIF_TYPE_INDEX ptf180[] = {0,0xFFFF};
static struct eif_par_types par180 = {180, ptf180, (uint16) 1, (uint16) 0, (char) 0};

/* INTEGER_OVERFLOW_CHECKER */
static EIF_TYPE_INDEX ptf181[] = {180,0xFFFF};
static struct eif_par_types par181 = {181, ptf181, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_TO_NUMERIC_CONVERTOR */
static EIF_TYPE_INDEX ptf182[] = {180,0xFFFF};
static struct eif_par_types par182 = {182, ptf182, (uint16) 1, (uint16) 0, (char) 0};

/* HEXADECIMAL_STRING_TO_INTEGER_CONVERTER */
static EIF_TYPE_INDEX ptf183[] = {182,0xFFFF};
static struct eif_par_types par183 = {183, ptf183, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_TO_REAL_CONVERTOR */
static EIF_TYPE_INDEX ptf184[] = {182,0xFFFF};
static struct eif_par_types par184 = {184, ptf184, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_TO_INTEGER_CONVERTOR */
static EIF_TYPE_INDEX ptf185[] = {182,0xFFFF};
static struct eif_par_types par185 = {185, ptf185, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_ARGUMENTS */
static EIF_TYPE_INDEX ptf186[] = {0,0xFFFF};
static struct eif_par_types par186 = {186, ptf186, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_OPERATING_SYSTEM */
static EIF_TYPE_INDEX ptf187[] = {0,0xFFFF};
static struct eif_par_types par187 = {187, ptf187, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_EXCEPTIONS */
static EIF_TYPE_INDEX ptf188[] = {0,0xFFFF};
static struct eif_par_types par188 = {188, ptf188, (uint16) 1, (uint16) 0, (char) 0};

/* PART_COMPARABLE */
static EIF_TYPE_INDEX ptf189[] = {0,0xFFFF};
static struct eif_par_types par189 = {189, ptf189, (uint16) 1, (uint16) 0, (char) 0};

/* COMPARABLE */
static EIF_TYPE_INDEX ptf190[] = {189,0xFFFF};
static struct eif_par_types par190 = {190, ptf190, (uint16) 1, (uint16) 0, (char) 0};

/* KL_COMPARABLE */
static EIF_TYPE_INDEX ptf191[] = {190,0xFFFF};
static struct eif_par_types par191 = {191, ptf191, (uint16) 1, (uint16) 0, (char) 0};

/* PLATFORM */
static EIF_TYPE_INDEX ptf192[] = {0,0xFFFF};
static struct eif_par_types par192 = {192, ptf192, (uint16) 1, (uint16) 0, (char) 0};

/* KL_PLATFORM */
static EIF_TYPE_INDEX ptf193[] = {66,0xFFF7,192,0xFFFF};
static struct eif_par_types par193 = {193, ptf193, (uint16) 2, (uint16) 0, (char) 0};

/* MEM_CONST */
static EIF_TYPE_INDEX ptf194[] = {0,0xFFFF};
static struct eif_par_types par194 = {194, ptf194, (uint16) 1, (uint16) 0, (char) 0};

/* DT_DATE_HANDLER */
static EIF_TYPE_INDEX ptf195[] = {0,0xFFFF};
static struct eif_par_types par195 = {195, ptf195, (uint16) 1, (uint16) 0, (char) 0};

/* DT_SHARED_WEEK_DAYS_FROM_MONDAY */
static EIF_TYPE_INDEX ptf196[] = {0,0xFFFF};
static struct eif_par_types par196 = {196, ptf196, (uint16) 1, (uint16) 0, (char) 0};

/* DT_TIME_HANDLER */
static EIF_TYPE_INDEX ptf197[] = {0,0xFFFF};
static struct eif_par_types par197 = {197, ptf197, (uint16) 1, (uint16) 0, (char) 0};

/* DT_DATE_TIME_HANDLER */
static EIF_TYPE_INDEX ptf198[] = {195,0xFFF7,197,0xFFFF};
static struct eif_par_types par198 = {198, ptf198, (uint16) 2, (uint16) 0, (char) 0};

/* YY_BUFFER */
static EIF_TYPE_INDEX ptf199[] = {0,0xFFFF};
static struct eif_par_types par199 = {199, ptf199, (uint16) 1, (uint16) 0, (char) 0};

/* YY_UTF8_BUFFER */
static EIF_TYPE_INDEX ptf200[] = {199,0xFFFF};
static struct eif_par_types par200 = {200, ptf200, (uint16) 1, (uint16) 0, (char) 0};

/* YY_UNICODE_BUFFER */
static EIF_TYPE_INDEX ptf201[] = {199,0xFFFF};
static struct eif_par_types par201 = {201, ptf201, (uint16) 1, (uint16) 0, (char) 0};

/* YY_FILE_BUFFER */
static EIF_TYPE_INDEX ptf202[] = {199,0xFFF7,161,0xFFFF};
static struct eif_par_types par202 = {202, ptf202, (uint16) 2, (uint16) 0, (char) 0};

/* YY_UTF8_FILE_BUFFER */
static EIF_TYPE_INDEX ptf203[] = {202,0xFFF7,200,0xFFFF};
static struct eif_par_types par203 = {203, ptf203, (uint16) 2, (uint16) 0, (char) 0};

/* YY_UNICODE_FILE_BUFFER */
static EIF_TYPE_INDEX ptf204[] = {201,0xFFF7,202,0xFFFF};
static struct eif_par_types par204 = {204, ptf204, (uint16) 2, (uint16) 0, (char) 0};

/* UT_IMPORTED_FORMATTERS */
static EIF_TYPE_INDEX ptf205[] = {0,0xFFFF};
static struct eif_par_types par205 = {205, ptf205, (uint16) 1, (uint16) 0, (char) 0};

/* UC_SHARED_STRING_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf206[] = {0,0xFFFF};
static struct eif_par_types par206 = {206, ptf206, (uint16) 1, (uint16) 0, (char) 0};

/* XM_UNICODE_STRUCTURE_FACTORY */
static EIF_TYPE_INDEX ptf207[] = {206,0xFFFF};
static struct eif_par_types par207 = {207, ptf207, (uint16) 1, (uint16) 0, (char) 0};

/* XM_EIFFEL_UNICODE_STRUCTURE_FACTORY */
static EIF_TYPE_INDEX ptf208[] = {207,0xFFFF};
static struct eif_par_types par208 = {208, ptf208, (uint16) 1, (uint16) 0, (char) 0};

/* KL_IMPORTED_CHARACTER_ROUTINES */
static EIF_TYPE_INDEX ptf209[] = {0,0xFFFF};
static struct eif_par_types par209 = {209, ptf209, (uint16) 1, (uint16) 0, (char) 0};

/* XM_CALLBACKS_SOURCE */
static EIF_TYPE_INDEX ptf210[] = {0,0xFFFF};
static struct eif_par_types par210 = {210, ptf210, (uint16) 1, (uint16) 0, (char) 0};

/* XM_CALLBACKS */
static EIF_TYPE_INDEX ptf211[] = {0,0xFFFF};
static struct eif_par_types par211 = {211, ptf211, (uint16) 1, (uint16) 0, (char) 0};

/* XM_CALLBACKS_NULL */
static EIF_TYPE_INDEX ptf212[] = {211,0xFFFF};
static struct eif_par_types par212 = {212, ptf212, (uint16) 1, (uint16) 0, (char) 0};

/* XM_FORWARD_CALLBACKS */
static EIF_TYPE_INDEX ptf213[] = {210,0xFFF7,211,0xFFFF};
static struct eif_par_types par213 = {213, ptf213, (uint16) 2, (uint16) 0, (char) 0};

/* XM_CALLBACKS_FILTER */
static EIF_TYPE_INDEX ptf214[] = {211,0xFFF7,210,0xFFF7,213,0xFFFF};
static struct eif_par_types par214 = {214, ptf214, (uint16) 3, (uint16) 0, (char) 0};

/* XM_END_TAG_CHECKER */
static EIF_TYPE_INDEX ptf215[] = {214,0xFFF7,207,0xFFFF};
static struct eif_par_types par215 = {215, ptf215, (uint16) 2, (uint16) 0, (char) 0};

/* XM_SHARED_STRINGS_FILTER */
static EIF_TYPE_INDEX ptf216[] = {214,0xFFF7,207,0xFFFF};
static struct eif_par_types par216 = {216, ptf216, (uint16) 2, (uint16) 0, (char) 0};

/* XM_CALLBACKS_TO_TREE_FILTER */
static EIF_TYPE_INDEX ptf217[] = {214,0xFFFF};
static struct eif_par_types par217 = {217, ptf217, (uint16) 1, (uint16) 0, (char) 0};

/* XM_STOP_ON_ERROR_FILTER */
static EIF_TYPE_INDEX ptf218[] = {214,0xFFFF};
static struct eif_par_types par218 = {218, ptf218, (uint16) 1, (uint16) 0, (char) 0};

/* XM_PARSER_STOP_ON_ERROR_FILTER */
static EIF_TYPE_INDEX ptf219[] = {218,0xFFFF};
static struct eif_par_types par219 = {219, ptf219, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_SHARED_EIFFEL_COMPILER_NAMES */
static EIF_TYPE_INDEX ptf220[] = {0,0xFFFF};
static struct eif_par_types par220 = {220, ptf220, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_EIFFEL_COMPILER_MODE */
static EIF_TYPE_INDEX ptf221[] = {220,0xFFFF};
static struct eif_par_types par221 = {221, ptf221, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_CONFIG_SHARED_CONSTRUCT_TYPE_NAMES */
static EIF_TYPE_INDEX ptf222[] = {0,0xFFFF};
static struct eif_par_types par222 = {222, ptf222, (uint16) 1, (uint16) 0, (char) 0};

/* CURSOR */
static EIF_TYPE_INDEX ptf223[] = {0,0xFFFF};
static struct eif_par_types par223 = {223, ptf223, (uint16) 1, (uint16) 0, (char) 0};

/* LINKED_LIST_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf224[] = {223,0xFFFF};
static struct eif_par_types par224 = {224, ptf224, (uint16) 1, (uint16) 1, (char) 0};

/* LINKED_LIST_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf225[] = {223,0xFFFF};
static struct eif_par_types par225 = {225, ptf225, (uint16) 1, (uint16) 1, (char) 0};

/* HASH_TABLE_CURSOR */
static EIF_TYPE_INDEX ptf226[] = {223,0xFFFF};
static struct eif_par_types par226 = {226, ptf226, (uint16) 1, (uint16) 0, (char) 0};

/* ARRAYED_LIST_CURSOR */
static EIF_TYPE_INDEX ptf227[] = {223,0xFFFF};
static struct eif_par_types par227 = {227, ptf227, (uint16) 1, (uint16) 0, (char) 0};

/* EXCEPTION_MANAGER_FACTORY */
static EIF_TYPE_INDEX ptf228[] = {0,0xFFFF};
static struct eif_par_types par228 = {228, ptf228, (uint16) 1, (uint16) 0, (char) 0};

/* EXCEPTIONS */
static EIF_TYPE_INDEX ptf229[] = {121,0xFFF7,228,0xFFFF};
static struct eif_par_types par229 = {229, ptf229, (uint16) 2, (uint16) 0, (char) 0};

/* KL_EXCEPTIONS */
static EIF_TYPE_INDEX ptf230[] = {92,0xFFF7,229,0xFFFF};
static struct eif_par_types par230 = {230, ptf230, (uint16) 2, (uint16) 0, (char) 0};

/* EXCEPTION */
static EIF_TYPE_INDEX ptf231[] = {228,0xFFFF};
static struct eif_par_types par231 = {231, ptf231, (uint16) 1, (uint16) 0, (char) 0};

/* DEVELOPER_EXCEPTION */
static EIF_TYPE_INDEX ptf232[] = {231,0xFFFF};
static struct eif_par_types par232 = {232, ptf232, (uint16) 1, (uint16) 0, (char) 0};

/* CONVERSION_FAILURE */
static EIF_TYPE_INDEX ptf233[] = {232,0xFFFF};
static struct eif_par_types par233 = {233, ptf233, (uint16) 1, (uint16) 0, (char) 0};

/* MACHINE_EXCEPTION */
static EIF_TYPE_INDEX ptf234[] = {231,0xFFFF};
static struct eif_par_types par234 = {234, ptf234, (uint16) 1, (uint16) 0, (char) 0};

/* HARDWARE_EXCEPTION */
static EIF_TYPE_INDEX ptf235[] = {234,0xFFFF};
static struct eif_par_types par235 = {235, ptf235, (uint16) 1, (uint16) 0, (char) 0};

/* FLOATING_POINT_FAILURE */
static EIF_TYPE_INDEX ptf236[] = {235,0xFFFF};
static struct eif_par_types par236 = {236, ptf236, (uint16) 1, (uint16) 0, (char) 0};

/* OPERATING_SYSTEM_EXCEPTION */
static EIF_TYPE_INDEX ptf237[] = {234,0xFFFF};
static struct eif_par_types par237 = {237, ptf237, (uint16) 1, (uint16) 0, (char) 0};

/* OPERATING_SYSTEM_SIGNAL_FAILURE */
static EIF_TYPE_INDEX ptf238[] = {237,0xFFFF};
static struct eif_par_types par238 = {238, ptf238, (uint16) 1, (uint16) 0, (char) 0};

/* COM_FAILURE */
static EIF_TYPE_INDEX ptf239[] = {237,0xFFFF};
static struct eif_par_types par239 = {239, ptf239, (uint16) 1, (uint16) 0, (char) 0};

/* OPERATING_SYSTEM_FAILURE */
static EIF_TYPE_INDEX ptf240[] = {237,0xFFFF};
static struct eif_par_types par240 = {240, ptf240, (uint16) 1, (uint16) 0, (char) 0};

/* OBSOLETE_EXCEPTION */
static EIF_TYPE_INDEX ptf241[] = {231,0xFFFF};
static struct eif_par_types par241 = {241, ptf241, (uint16) 1, (uint16) 0, (char) 0};

/* EXCEPTION_IN_SIGNAL_HANDLER_FAILURE */
static EIF_TYPE_INDEX ptf242[] = {241,0xFFFF};
static struct eif_par_types par242 = {242, ptf242, (uint16) 1, (uint16) 0, (char) 0};

/* RESUMPTION_FAILURE */
static EIF_TYPE_INDEX ptf243[] = {241,0xFFFF};
static struct eif_par_types par243 = {243, ptf243, (uint16) 1, (uint16) 0, (char) 0};

/* RESCUE_FAILURE */
static EIF_TYPE_INDEX ptf244[] = {241,0xFFFF};
static struct eif_par_types par244 = {244, ptf244, (uint16) 1, (uint16) 0, (char) 0};

/* SYS_EXCEPTION */
static EIF_TYPE_INDEX ptf245[] = {231,0xFFFF};
static struct eif_par_types par245 = {245, ptf245, (uint16) 1, (uint16) 0, (char) 0};

/* OLD_VIOLATION */
static EIF_TYPE_INDEX ptf246[] = {245,0xFFFF};
static struct eif_par_types par246 = {246, ptf246, (uint16) 1, (uint16) 0, (char) 0};

/* EIFFEL_RUNTIME_PANIC */
static EIF_TYPE_INDEX ptf247[] = {245,0xFFFF};
static struct eif_par_types par247 = {247, ptf247, (uint16) 1, (uint16) 0, (char) 0};

/* EIF_EXCEPTION */
static EIF_TYPE_INDEX ptf248[] = {245,0xFFFF};
static struct eif_par_types par248 = {248, ptf248, (uint16) 1, (uint16) 0, (char) 0};

/* EIFFEL_RUNTIME_EXCEPTION */
static EIF_TYPE_INDEX ptf249[] = {248,0xFFFF};
static struct eif_par_types par249 = {249, ptf249, (uint16) 1, (uint16) 0, (char) 0};

/* NO_MORE_MEMORY */
static EIF_TYPE_INDEX ptf250[] = {249,0xFFFF};
static struct eif_par_types par250 = {250, ptf250, (uint16) 1, (uint16) 0, (char) 0};

/* EXTERNAL_FAILURE */
static EIF_TYPE_INDEX ptf251[] = {249,0xFFFF};
static struct eif_par_types par251 = {251, ptf251, (uint16) 1, (uint16) 0, (char) 0};

/* DATA_EXCEPTION */
static EIF_TYPE_INDEX ptf252[] = {249,0xFFFF};
static struct eif_par_types par252 = {252, ptf252, (uint16) 1, (uint16) 0, (char) 0};

/* SERIALIZATION_FAILURE */
static EIF_TYPE_INDEX ptf253[] = {252,0xFFFF};
static struct eif_par_types par253 = {253, ptf253, (uint16) 1, (uint16) 0, (char) 0};

/* MISMATCH_FAILURE */
static EIF_TYPE_INDEX ptf254[] = {252,0xFFFF};
static struct eif_par_types par254 = {254, ptf254, (uint16) 1, (uint16) 0, (char) 0};

/* IO_FAILURE */
static EIF_TYPE_INDEX ptf255[] = {252,0xFFFF};
static struct eif_par_types par255 = {255, ptf255, (uint16) 1, (uint16) 0, (char) 0};

/* LANGUAGE_EXCEPTION */
static EIF_TYPE_INDEX ptf256[] = {248,0xFFFF};
static struct eif_par_types par256 = {256, ptf256, (uint16) 1, (uint16) 0, (char) 0};

/* BAD_INSPECT_VALUE */
static EIF_TYPE_INDEX ptf257[] = {256,0xFFFF};
static struct eif_par_types par257 = {257, ptf257, (uint16) 1, (uint16) 0, (char) 0};

/* ROUTINE_FAILURE */
static EIF_TYPE_INDEX ptf258[] = {256,0xFFFF};
static struct eif_par_types par258 = {258, ptf258, (uint16) 1, (uint16) 0, (char) 0};

/* VOID_TARGET */
static EIF_TYPE_INDEX ptf259[] = {256,0xFFFF};
static struct eif_par_types par259 = {259, ptf259, (uint16) 1, (uint16) 0, (char) 0};

/* VOID_ASSIGNED_TO_EXPANDED */
static EIF_TYPE_INDEX ptf260[] = {256,0xFFFF};
static struct eif_par_types par260 = {260, ptf260, (uint16) 1, (uint16) 0, (char) 0};

/* EIFFELSTUDIO_SPECIFIC_LANGUAGE_EXCEPTION */
static EIF_TYPE_INDEX ptf261[] = {256,0xFFFF};
static struct eif_par_types par261 = {261, ptf261, (uint16) 1, (uint16) 0, (char) 0};

/* ADDRESS_APPLIED_TO_MELTED_FEATURE */
static EIF_TYPE_INDEX ptf262[] = {261,0xFFFF};
static struct eif_par_types par262 = {262, ptf262, (uint16) 1, (uint16) 0, (char) 0};

/* CREATE_ON_DEFERRED */
static EIF_TYPE_INDEX ptf263[] = {261,0xFFFF};
static struct eif_par_types par263 = {263, ptf263, (uint16) 1, (uint16) 0, (char) 0};

/* ASSERTION_VIOLATION */
static EIF_TYPE_INDEX ptf264[] = {231,0xFFFF};
static struct eif_par_types par264 = {264, ptf264, (uint16) 1, (uint16) 0, (char) 0};

/* LOOP_INVARIANT_VIOLATION */
static EIF_TYPE_INDEX ptf265[] = {264,0xFFFF};
static struct eif_par_types par265 = {265, ptf265, (uint16) 1, (uint16) 0, (char) 0};

/* VARIANT_VIOLATION */
static EIF_TYPE_INDEX ptf266[] = {264,0xFFFF};
static struct eif_par_types par266 = {266, ptf266, (uint16) 1, (uint16) 0, (char) 0};

/* CHECK_VIOLATION */
static EIF_TYPE_INDEX ptf267[] = {264,0xFFFF};
static struct eif_par_types par267 = {267, ptf267, (uint16) 1, (uint16) 0, (char) 0};

/* INVARIANT_VIOLATION */
static EIF_TYPE_INDEX ptf268[] = {264,0xFFFF};
static struct eif_par_types par268 = {268, ptf268, (uint16) 1, (uint16) 0, (char) 0};

/* POSTCONDITION_VIOLATION */
static EIF_TYPE_INDEX ptf269[] = {264,0xFFFF};
static struct eif_par_types par269 = {269, ptf269, (uint16) 1, (uint16) 0, (char) 0};

/* PRECONDITION_VIOLATION */
static EIF_TYPE_INDEX ptf270[] = {264,0xFFFF};
static struct eif_par_types par270 = {270, ptf270, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_PRINTER */
static EIF_TYPE_INDEX ptf271[] = {0,0xFFFF};
static struct eif_par_types par271 = {271, ptf271, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_EIFFEL_COMPILER_SPECIFIC_PRINTER */
static EIF_TYPE_INDEX ptf272[] = {271,0xFFFF};
static struct eif_par_types par272 = {272, ptf272, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_ABSTRACT_GENERATOR */
static EIF_TYPE_INDEX ptf273[] = {272,0xFFFF};
static struct eif_par_types par273 = {273, ptf273, (uint16) 1, (uint16) 0, (char) 0};

/* WRAPC_MAKEFILES_GENERATOR */
static EIF_TYPE_INDEX ptf274[] = {273,0xFFFF};
static struct eif_par_types par274 = {274, ptf274, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_EIFFEL_API_SHARED */
static EIF_TYPE_INDEX ptf275[] = {273,0xFFFF};
static struct eif_par_types par275 = {275, ptf275, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_ABSTRACT_C_DECLARATION_PRINTER */
static EIF_TYPE_INDEX ptf276[] = {271,0xFFFF};
static struct eif_par_types par276 = {276, ptf276, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_EIFFEL_TO_C_INDIRECTION_PRINTER */
static EIF_TYPE_INDEX ptf277[] = {276,0xFFFF};
static struct eif_par_types par277 = {277, ptf277, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_COMPOSITE_DECLARATION_PRINTER */
static EIF_TYPE_INDEX ptf278[] = {276,0xFFFF};
static struct eif_par_types par278 = {278, ptf278, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_TYPE_CAST_PRINTER */
static EIF_TYPE_INDEX ptf279[] = {276,0xFFFF};
static struct eif_par_types par279 = {279, ptf279, (uint16) 1, (uint16) 0, (char) 0};

/* UC_IMPORTED_UTF16_ROUTINES */
static EIF_TYPE_INDEX ptf280[] = {0,0xFFFF};
static struct eif_par_types par280 = {280, ptf280, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_CALLING_CONVENTION_CONSTANTS */
static EIF_TYPE_INDEX ptf281[] = {0,0xFFFF};
static struct eif_par_types par281 = {281, ptf281, (uint16) 1, (uint16) 0, (char) 0};

/* REFLECTOR_CONSTANTS */
static EIF_TYPE_INDEX ptf282[] = {0,0xFFFF};
static struct eif_par_types par282 = {282, ptf282, (uint16) 1, (uint16) 0, (char) 0};

/* REFLECTED_OBJECT */
static EIF_TYPE_INDEX ptf283[] = {282,0xFFFF};
static struct eif_par_types par283 = {283, ptf283, (uint16) 1, (uint16) 0, (char) 0};

/* REFLECTOR */
static EIF_TYPE_INDEX ptf284[] = {116,0xFFF7,282,0xFFFF};
static struct eif_par_types par284 = {284, ptf284, (uint16) 2, (uint16) 0, (char) 0};

/* INTERNAL */
static EIF_TYPE_INDEX ptf285[] = {284,0xFFF7,108,0xFFFF};
static struct eif_par_types par285 = {285, ptf285, (uint16) 2, (uint16) 0, (char) 0};

/* RT_DBG_INTERNAL */
static EIF_TYPE_INDEX ptf286[] = {282,0xFFFF};
static struct eif_par_types par286 = {286, ptf286, (uint16) 1, (uint16) 0, (char) 0};

/* REFLECTED_COPY_SEMANTICS_OBJECT */
static EIF_TYPE_INDEX ptf287[] = {283,0xFFF7,282,0xFFFF};
static struct eif_par_types par287 = {287, ptf287, (uint16) 2, (uint16) 0, (char) 0};

/* REFLECTED_REFERENCE_OBJECT */
static EIF_TYPE_INDEX ptf288[] = {283,0xFFF7,282,0xFFFF};
static struct eif_par_types par288 = {288, ptf288, (uint16) 2, (uint16) 0, (char) 0};

/* TO_SPECIAL [G#1] */
static EIF_TYPE_INDEX ptf289[] = {0,0xFFFF};
static struct eif_par_types par289 = {289, ptf289, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [INTEGER_32] */
static EIF_TYPE_INDEX ptf290[] = {0,0xFFFF};
static struct eif_par_types par290 = {290, ptf290, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [BOOLEAN] */
static EIF_TYPE_INDEX ptf291[] = {0,0xFFFF};
static struct eif_par_types par291 = {291, ptf291, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [NATURAL_64] */
static EIF_TYPE_INDEX ptf292[] = {0,0xFFFF};
static struct eif_par_types par292 = {292, ptf292, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [NATURAL_32] */
static EIF_TYPE_INDEX ptf293[] = {0,0xFFFF};
static struct eif_par_types par293 = {293, ptf293, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [CHARACTER_32] */
static EIF_TYPE_INDEX ptf294[] = {0,0xFFFF};
static struct eif_par_types par294 = {294, ptf294, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [CHARACTER_8] */
static EIF_TYPE_INDEX ptf295[] = {0,0xFFFF};
static struct eif_par_types par295 = {295, ptf295, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [NATURAL_8] */
static EIF_TYPE_INDEX ptf296[] = {0,0xFFFF};
static struct eif_par_types par296 = {296, ptf296, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [NATURAL_16] */
static EIF_TYPE_INDEX ptf297[] = {0,0xFFFF};
static struct eif_par_types par297 = {297, ptf297, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [POINTER] */
static EIF_TYPE_INDEX ptf298[] = {0,0xFFFF};
static struct eif_par_types par298 = {298, ptf298, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [REAL_32] */
static EIF_TYPE_INDEX ptf299[] = {0,0xFFFF};
static struct eif_par_types par299 = {299, ptf299, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [REAL_64] */
static EIF_TYPE_INDEX ptf300[] = {0,0xFFFF};
static struct eif_par_types par300 = {300, ptf300, (uint16) 1, (uint16) 1, (char) 0};

/* KL_EQUALITY_TESTER [G#1] */
static EIF_TYPE_INDEX ptf301[] = {0,0xFFFF};
static struct eif_par_types par301 = {301, ptf301, (uint16) 1, (uint16) 1, (char) 0};

/* KL_EQUALITY_TESTER [BOOLEAN] */
static EIF_TYPE_INDEX ptf302[] = {0,0xFFFF};
static struct eif_par_types par302 = {302, ptf302, (uint16) 1, (uint16) 1, (char) 0};

/* KL_EQUALITY_TESTER [NATURAL_64] */
static EIF_TYPE_INDEX ptf303[] = {0,0xFFFF};
static struct eif_par_types par303 = {303, ptf303, (uint16) 1, (uint16) 1, (char) 0};

/* KL_EQUALITY_TESTER [NATURAL_32] */
static EIF_TYPE_INDEX ptf304[] = {0,0xFFFF};
static struct eif_par_types par304 = {304, ptf304, (uint16) 1, (uint16) 1, (char) 0};

/* KL_EQUALITY_TESTER [INTEGER_32] */
static EIF_TYPE_INDEX ptf305[] = {0,0xFFFF};
static struct eif_par_types par305 = {305, ptf305, (uint16) 1, (uint16) 1, (char) 0};

/* KL_EQUALITY_TESTER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf306[] = {0,0xFFFF};
static struct eif_par_types par306 = {306, ptf306, (uint16) 1, (uint16) 1, (char) 0};

/* KL_STRING_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf307[] = {301,0xFF01,986,0xFFFF};
static struct eif_par_types par307 = {307, ptf307, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_AST_DECLARATION_EQUALITY_TESTER [G#1] */
static EIF_TYPE_INDEX ptf308[] = {301,0xFFF8,1,0xFFFF};
static struct eif_par_types par308 = {308, ptf308, (uint16) 1, (uint16) 1, (char) 0};

/* EWG_C_AST_TYPE_EQUALITY_TESTER [G#1] */
static EIF_TYPE_INDEX ptf309[] = {301,0xFFF8,1,0xFFFF};
static struct eif_par_types par309 = {309, ptf309, (uint16) 1, (uint16) 1, (char) 0};

/* UC_IMPORTED_UTF8_ROUTINES */
static EIF_TYPE_INDEX ptf310[] = {0,0xFFFF};
static struct eif_par_types par310 = {310, ptf310, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_SHARED_TEMPLATE_EXPANDER */
static EIF_TYPE_INDEX ptf311[] = {0,0xFFFF};
static struct eif_par_types par311 = {311, ptf311, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_STANDARD_FILES */
static EIF_TYPE_INDEX ptf312[] = {0,0xFFFF};
static struct eif_par_types par312 = {312, ptf312, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_CONFIG_ELEMENT_NAMES */
static EIF_TYPE_INDEX ptf313[] = {0,0xFFFF};
static struct eif_par_types par313 = {313, ptf313, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_CONFIG_WRAPPER_CLAUSE */
static EIF_TYPE_INDEX ptf314[] = {0,0xFFFF};
static struct eif_par_types par314 = {314, ptf314, (uint16) 1, (uint16) 0, (char) 0};

/* WRAPC_CONFIG_MACRO_WRAPPER_CLAUSE */
static EIF_TYPE_INDEX ptf315[] = {314,0xFFFF};
static struct eif_par_types par315 = {315, ptf315, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_CONFIG_NONE_WRAPPER_CLAUSE */
static EIF_TYPE_INDEX ptf316[] = {314,0xFFFF};
static struct eif_par_types par316 = {316, ptf316, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_CONFIG_DEFAULT_WRAPPER_CLAUSE */
static EIF_TYPE_INDEX ptf317[] = {314,0xFFFF};
static struct eif_par_types par317 = {317, ptf317, (uint16) 1, (uint16) 0, (char) 0};

/* DISPOSABLE */
static EIF_TYPE_INDEX ptf318[] = {0,0xFFFF};
static struct eif_par_types par318 = {318, ptf318, (uint16) 1, (uint16) 0, (char) 0};

/* MANAGED_POINTER */
static EIF_TYPE_INDEX ptf319[] = {318,0xFFF7,192,0xFFFF};
static struct eif_par_types par319 = {319, ptf319, (uint16) 2, (uint16) 0, (char) 0};

/* PROCESS_UNIX_PIPE */
static EIF_TYPE_INDEX ptf320[] = {131,0xFFF7,318,0xFFFF};
static struct eif_par_types par320 = {320, ptf320, (uint16) 2, (uint16) 0, (char) 0};

/* MEMORY */
static EIF_TYPE_INDEX ptf321[] = {318,0xFFF7,194,0xFFFF};
static struct eif_par_types par321 = {321, ptf321, (uint16) 2, (uint16) 0, (char) 0};

/* NATIVE_STRING_HANDLER */
static EIF_TYPE_INDEX ptf322[] = {0,0xFFFF};
static struct eif_par_types par322 = {322, ptf322, (uint16) 1, (uint16) 0, (char) 0};

/* NATIVE_STRING */
static EIF_TYPE_INDEX ptf323[] = {322,0xFFFF};
static struct eif_par_types par323 = {323, ptf323, (uint16) 1, (uint16) 0, (char) 0};

/* FILE_INFO */
static EIF_TYPE_INDEX ptf324[] = {296,924,0xFFF7,322,0xFFFF};
static struct eif_par_types par324 = {324, ptf324, (uint16) 2, (uint16) 0, (char) 0};

/* UNIX_FILE_INFO */
static EIF_TYPE_INDEX ptf325[] = {324,0xFFFF};
static struct eif_par_types par325 = {325, ptf325, (uint16) 1, (uint16) 0, (char) 0};

/* DIRECTORY */
static EIF_TYPE_INDEX ptf326[] = {318,0xFFF7,322,0xFFFF};
static struct eif_par_types par326 = {326, ptf326, (uint16) 2, (uint16) 0, (char) 0};

/* EXECUTION_ENVIRONMENT */
static EIF_TYPE_INDEX ptf327[] = {322,0xFFFF};
static struct eif_par_types par327 = {327, ptf327, (uint16) 1, (uint16) 0, (char) 0};

/* PROCESS_INFO */
static EIF_TYPE_INDEX ptf328[] = {327,0xFFFF};
static struct eif_par_types par328 = {328, ptf328, (uint16) 1, (uint16) 0, (char) 0};

/* PROCESS_INFO_IMP */
static EIF_TYPE_INDEX ptf329[] = {328,0xFFFF};
static struct eif_par_types par329 = {329, ptf329, (uint16) 1, (uint16) 0, (char) 0};

/* PROCESS_UNIX_PROCESS_MANAGER */
static EIF_TYPE_INDEX ptf330[] = {130,0xFFF7,131,0xFFF7,128,0xFFF7,321,0xFFF7,329,0xFFF7,64,0xFFFF};
static struct eif_par_types par330 = {330, ptf330, (uint16) 6, (uint16) 0, (char) 0};

/* BASE_PROCESS_IMP */
static EIF_TYPE_INDEX ptf331[] = {72,0xFFF7,131,0xFFF7,329,0xFFFF};
static struct eif_par_types par331 = {331, ptf331, (uint16) 3, (uint16) 0, (char) 0};

/* KL_IMPORTED_SPECIAL_ROUTINES */
static EIF_TYPE_INDEX ptf332[] = {0,0xFFFF};
static struct eif_par_types par332 = {332, ptf332, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_HANDLER */
static EIF_TYPE_INDEX ptf333[] = {0,0xFFFF};
static struct eif_par_types par333 = {333, ptf333, (uint16) 1, (uint16) 0, (char) 0};

/* KL_UNICODE_CHARACTER_BUFFER */
static EIF_TYPE_INDEX ptf334[] = {97,0xFFF7,333,0xFFFF};
static struct eif_par_types par334 = {334, ptf334, (uint16) 2, (uint16) 0, (char) 0};

/* KL_CHARACTER_BUFFER */
static EIF_TYPE_INDEX ptf335[] = {97,0xFFF7,333,0xFFFF};
static struct eif_par_types par335 = {335, ptf335, (uint16) 2, (uint16) 0, (char) 0};

/* C_STRING */
static EIF_TYPE_INDEX ptf336[] = {333,0xFFFF};
static struct eif_par_types par336 = {336, ptf336, (uint16) 1, (uint16) 0, (char) 0};

/* IO_MEDIUM */
static EIF_TYPE_INDEX ptf337[] = {318,0xFFF7,333,0xFFFF};
static struct eif_par_types par337 = {337, ptf337, (uint16) 2, (uint16) 0, (char) 0};

/* UNIX_UNNAMED_PIPE */
static EIF_TYPE_INDEX ptf338[] = {320,0xFFF7,337,0xFFFF};
static struct eif_par_types par338 = {338, ptf338, (uint16) 2, (uint16) 0, (char) 0};

/* DEBUG_OUTPUT */
static EIF_TYPE_INDEX ptf339[] = {0,0xFFFF};
static struct eif_par_types par339 = {339, ptf339, (uint16) 1, (uint16) 0, (char) 0};

/* RT_DBG_CALL_RECORD */
static EIF_TYPE_INDEX ptf340[] = {339,0xFFFF};
static struct eif_par_types par340 = {340, ptf340, (uint16) 1, (uint16) 0, (char) 0};

/* ABSTRACT_SPECIAL */
static EIF_TYPE_INDEX ptf341[] = {339,0xFFFF};
static struct eif_par_types par341 = {341, ptf341, (uint16) 1, (uint16) 0, (char) 0};

/* RT_DBG_VALUE_RECORD */
static EIF_TYPE_INDEX ptf342[] = {339,0xFFF7,176,0xFFF7,286,0xFFFF};
static struct eif_par_types par342 = {342, ptf342, (uint16) 3, (uint16) 0, (char) 0};

/* RT_DBG_LOCAL_RECORD [G#1] */
static EIF_TYPE_INDEX ptf343[] = {342,0xFFFF};
static struct eif_par_types par343 = {343, ptf343, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [POINTER] */
static EIF_TYPE_INDEX ptf344[] = {342,0xFFFF};
static struct eif_par_types par344 = {344, ptf344, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [NATURAL_64] */
static EIF_TYPE_INDEX ptf345[] = {342,0xFFFF};
static struct eif_par_types par345 = {345, ptf345, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [NATURAL_32] */
static EIF_TYPE_INDEX ptf346[] = {342,0xFFFF};
static struct eif_par_types par346 = {346, ptf346, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [INTEGER_8] */
static EIF_TYPE_INDEX ptf347[] = {342,0xFFFF};
static struct eif_par_types par347 = {347, ptf347, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [REAL_32] */
static EIF_TYPE_INDEX ptf348[] = {342,0xFFFF};
static struct eif_par_types par348 = {348, ptf348, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [REAL_64] */
static EIF_TYPE_INDEX ptf349[] = {342,0xFFFF};
static struct eif_par_types par349 = {349, ptf349, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [BOOLEAN] */
static EIF_TYPE_INDEX ptf350[] = {342,0xFFFF};
static struct eif_par_types par350 = {350, ptf350, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [INTEGER_32] */
static EIF_TYPE_INDEX ptf351[] = {342,0xFFFF};
static struct eif_par_types par351 = {351, ptf351, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [CHARACTER_32] */
static EIF_TYPE_INDEX ptf352[] = {342,0xFFFF};
static struct eif_par_types par352 = {352, ptf352, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [CHARACTER_8] */
static EIF_TYPE_INDEX ptf353[] = {342,0xFFFF};
static struct eif_par_types par353 = {353, ptf353, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [NATURAL_8] */
static EIF_TYPE_INDEX ptf354[] = {342,0xFFFF};
static struct eif_par_types par354 = {354, ptf354, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [NATURAL_16] */
static EIF_TYPE_INDEX ptf355[] = {342,0xFFFF};
static struct eif_par_types par355 = {355, ptf355, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [INTEGER_16] */
static EIF_TYPE_INDEX ptf356[] = {342,0xFFFF};
static struct eif_par_types par356 = {356, ptf356, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [INTEGER_64] */
static EIF_TYPE_INDEX ptf357[] = {342,0xFFFF};
static struct eif_par_types par357 = {357, ptf357, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [G#1] */
static EIF_TYPE_INDEX ptf358[] = {342,0xFFFF};
static struct eif_par_types par358 = {358, ptf358, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [POINTER] */
static EIF_TYPE_INDEX ptf359[] = {342,0xFFFF};
static struct eif_par_types par359 = {359, ptf359, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [NATURAL_32] */
static EIF_TYPE_INDEX ptf360[] = {342,0xFFFF};
static struct eif_par_types par360 = {360, ptf360, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [INTEGER_8] */
static EIF_TYPE_INDEX ptf361[] = {342,0xFFFF};
static struct eif_par_types par361 = {361, ptf361, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [REAL_64] */
static EIF_TYPE_INDEX ptf362[] = {342,0xFFFF};
static struct eif_par_types par362 = {362, ptf362, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [REAL_32] */
static EIF_TYPE_INDEX ptf363[] = {342,0xFFFF};
static struct eif_par_types par363 = {363, ptf363, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [NATURAL_8] */
static EIF_TYPE_INDEX ptf364[] = {342,0xFFFF};
static struct eif_par_types par364 = {364, ptf364, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [NATURAL_16] */
static EIF_TYPE_INDEX ptf365[] = {342,0xFFFF};
static struct eif_par_types par365 = {365, ptf365, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [BOOLEAN] */
static EIF_TYPE_INDEX ptf366[] = {342,0xFFFF};
static struct eif_par_types par366 = {366, ptf366, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [INTEGER_32] */
static EIF_TYPE_INDEX ptf367[] = {342,0xFFFF};
static struct eif_par_types par367 = {367, ptf367, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [INTEGER_64] */
static EIF_TYPE_INDEX ptf368[] = {342,0xFFFF};
static struct eif_par_types par368 = {368, ptf368, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [CHARACTER_8] */
static EIF_TYPE_INDEX ptf369[] = {342,0xFFFF};
static struct eif_par_types par369 = {369, ptf369, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [NATURAL_64] */
static EIF_TYPE_INDEX ptf370[] = {342,0xFFFF};
static struct eif_par_types par370 = {370, ptf370, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [INTEGER_16] */
static EIF_TYPE_INDEX ptf371[] = {342,0xFFFF};
static struct eif_par_types par371 = {371, ptf371, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [CHARACTER_32] */
static EIF_TYPE_INDEX ptf372[] = {342,0xFFFF};
static struct eif_par_types par372 = {372, ptf372, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [G#1] */
static EIF_TYPE_INDEX ptf373[] = {342,0xFFFF};
static struct eif_par_types par373 = {373, ptf373, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [INTEGER_8] */
static EIF_TYPE_INDEX ptf374[] = {342,0xFFFF};
static struct eif_par_types par374 = {374, ptf374, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [POINTER] */
static EIF_TYPE_INDEX ptf375[] = {342,0xFFFF};
static struct eif_par_types par375 = {375, ptf375, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [REAL_64] */
static EIF_TYPE_INDEX ptf376[] = {342,0xFFFF};
static struct eif_par_types par376 = {376, ptf376, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [NATURAL_32] */
static EIF_TYPE_INDEX ptf377[] = {342,0xFFFF};
static struct eif_par_types par377 = {377, ptf377, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [NATURAL_16] */
static EIF_TYPE_INDEX ptf378[] = {342,0xFFFF};
static struct eif_par_types par378 = {378, ptf378, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [NATURAL_8] */
static EIF_TYPE_INDEX ptf379[] = {342,0xFFFF};
static struct eif_par_types par379 = {379, ptf379, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [REAL_32] */
static EIF_TYPE_INDEX ptf380[] = {342,0xFFFF};
static struct eif_par_types par380 = {380, ptf380, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [INTEGER_32] */
static EIF_TYPE_INDEX ptf381[] = {342,0xFFFF};
static struct eif_par_types par381 = {381, ptf381, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [INTEGER_16] */
static EIF_TYPE_INDEX ptf382[] = {342,0xFFFF};
static struct eif_par_types par382 = {382, ptf382, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [NATURAL_64] */
static EIF_TYPE_INDEX ptf383[] = {342,0xFFFF};
static struct eif_par_types par383 = {383, ptf383, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [BOOLEAN] */
static EIF_TYPE_INDEX ptf384[] = {342,0xFFFF};
static struct eif_par_types par384 = {384, ptf384, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [CHARACTER_32] */
static EIF_TYPE_INDEX ptf385[] = {342,0xFFFF};
static struct eif_par_types par385 = {385, ptf385, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [CHARACTER_8] */
static EIF_TYPE_INDEX ptf386[] = {342,0xFFFF};
static struct eif_par_types par386 = {386, ptf386, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [INTEGER_64] */
static EIF_TYPE_INDEX ptf387[] = {342,0xFFFF};
static struct eif_par_types par387 = {387, ptf387, (uint16) 1, (uint16) 1, (char) 0};

/* NUMERIC */
static EIF_TYPE_INDEX ptf388[] = {339,0xFFFF};
static struct eif_par_types par388 = {388, ptf388, (uint16) 1, (uint16) 0, (char) 0};

/* ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf389[] = {0,0xFFFF};
static struct eif_par_types par389 = {389, ptf389, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf390[] = {0,0xFFFF};
static struct eif_par_types par390 = {390, ptf390, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf391[] = {0,0xFFFF};
static struct eif_par_types par391 = {391, ptf391, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf392[] = {0,0xFFFF};
static struct eif_par_types par392 = {392, ptf392, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf393[] = {0,0xFFFF};
static struct eif_par_types par393 = {393, ptf393, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf394[] = {0,0xFFFF};
static struct eif_par_types par394 = {394, ptf394, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf395[] = {0,0xFFFF};
static struct eif_par_types par395 = {395, ptf395, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf396[] = {0,0xFFFF};
static struct eif_par_types par396 = {396, ptf396, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf397[] = {0,0xFFFF};
static struct eif_par_types par397 = {397, ptf397, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf398[] = {0,0xFFFF};
static struct eif_par_types par398 = {398, ptf398, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf399[] = {0,0xFFFF};
static struct eif_par_types par399 = {399, ptf399, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf400[] = {0,0xFFFF};
static struct eif_par_types par400 = {400, ptf400, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_QUEUE_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf401[] = {389,0xFFF8,1,0xFFFF};
static struct eif_par_types par401 = {401, ptf401, (uint16) 1, (uint16) 1, (char) 0};

/* FILE_ITERATION_CURSOR */
static EIF_TYPE_INDEX ptf402[] = {318,0xFFF7,392,936,0xFFFF};
static struct eif_par_types par402 = {402, ptf402, (uint16) 2, (uint16) 0, (char) 0};

/* TABLE_ITERATION_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf403[] = {389,0xFFF8,1,0xFFFF};
static struct eif_par_types par403 = {403, ptf403, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERATION_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf404[] = {390,906,0xFFFF};
static struct eif_par_types par404 = {404, ptf404, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERATION_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf405[] = {389,0xFFF8,1,0xFFFF};
static struct eif_par_types par405 = {405, ptf405, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERATION_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf406[] = {390,906,0xFFFF};
static struct eif_par_types par406 = {406, ptf406, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERATION_CURSOR [POINTER, G#2] */
static EIF_TYPE_INDEX ptf407[] = {398,972,0xFFFF};
static struct eif_par_types par407 = {407, ptf407, (uint16) 1, (uint16) 2, (char) 0};

/* XM_MARKUP_CONSTANTS */
static EIF_TYPE_INDEX ptf408[] = {0,0xFFFF};
static struct eif_par_types par408 = {408, ptf408, (uint16) 1, (uint16) 0, (char) 0};

/* UC_IMPORTED_UNICODE_ROUTINES */
static EIF_TYPE_INDEX ptf409[] = {0,0xFFFF};
static struct eif_par_types par409 = {409, ptf409, (uint16) 1, (uint16) 0, (char) 0};

/* KL_IMPORTED_ARRAY_ROUTINES */
static EIF_TYPE_INDEX ptf410[] = {0,0xFFFF};
static struct eif_par_types par410 = {410, ptf410, (uint16) 1, (uint16) 0, (char) 0};

/* KI_DIRECTORY */
static EIF_TYPE_INDEX ptf411[] = {136,0xFFF7,168,0xFF01,986,0xFFF7,410,0xFFFF};
static struct eif_par_types par411 = {411, ptf411, (uint16) 3, (uint16) 0, (char) 0};

/* ITERABLE [G#1] */
static EIF_TYPE_INDEX ptf412[] = {0,0xFFFF};
static struct eif_par_types par412 = {412, ptf412, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf413[] = {0,0xFFFF};
static struct eif_par_types par413 = {413, ptf413, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf414[] = {0,0xFFFF};
static struct eif_par_types par414 = {414, ptf414, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf415[] = {0,0xFFFF};
static struct eif_par_types par415 = {415, ptf415, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf416[] = {0,0xFFFF};
static struct eif_par_types par416 = {416, ptf416, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf417[] = {0,0xFFFF};
static struct eif_par_types par417 = {417, ptf417, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf418[] = {0,0xFFFF};
static struct eif_par_types par418 = {418, ptf418, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [NATURAL_8] */
static EIF_TYPE_INDEX ptf419[] = {0,0xFFFF};
static struct eif_par_types par419 = {419, ptf419, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [NATURAL_16] */
static EIF_TYPE_INDEX ptf420[] = {0,0xFFFF};
static struct eif_par_types par420 = {420, ptf420, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [POINTER] */
static EIF_TYPE_INDEX ptf421[] = {0,0xFFFF};
static struct eif_par_types par421 = {421, ptf421, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [REAL_32] */
static EIF_TYPE_INDEX ptf422[] = {0,0xFFFF};
static struct eif_par_types par422 = {422, ptf422, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [REAL_64] */
static EIF_TYPE_INDEX ptf423[] = {0,0xFFFF};
static struct eif_par_types par423 = {423, ptf423, (uint16) 1, (uint16) 1, (char) 0};

/* ARGUMENTS_32 */
static EIF_TYPE_INDEX ptf424[] = {412,0xFF01,982,0xFFFF};
static struct eif_par_types par424 = {424, ptf424, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_ITERATION_CURSOR */
static EIF_TYPE_INDEX ptf425[] = {393,933,0xFFF7,416,933,0xFFFF};
static struct eif_par_types par425 = {425, ptf425, (uint16) 2, (uint16) 0, (char) 0};

/* ARGUMENTS */
static EIF_TYPE_INDEX ptf426[] = {412,0xFF01,986,0xFFFF};
static struct eif_par_types par426 = {426, ptf426, (uint16) 1, (uint16) 0, (char) 0};

/* KL_ARGUMENTS */
static EIF_TYPE_INDEX ptf427[] = {426,0xFFFF};
static struct eif_par_types par427 = {427, ptf427, (uint16) 1, (uint16) 0, (char) 0};

/* TABLE_ITERABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf428[] = {412,0xFFF8,1,0xFFFF};
static struct eif_par_types par428 = {428, ptf428, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf429[] = {413,906,0xFFFF};
static struct eif_par_types par429 = {429, ptf429, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf430[] = {412,0xFFF8,1,0xFFFF};
static struct eif_par_types par430 = {430, ptf430, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf431[] = {413,906,0xFFFF};
static struct eif_par_types par431 = {431, ptf431, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERABLE [POINTER, G#2] */
static EIF_TYPE_INDEX ptf432[] = {421,972,0xFFFF};
static struct eif_par_types par432 = {432, ptf432, (uint16) 1, (uint16) 2, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf433[] = {389,0xFFF8,1,0xFFF7,412,0xFFF8,1,0xFFFF};
static struct eif_par_types par433 = {433, ptf433, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf434[] = {390,906,0xFFF7,413,906,0xFFFF};
static struct eif_par_types par434 = {434, ptf434, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf435[] = {391,939,0xFFF7,414,939,0xFFFF};
static struct eif_par_types par435 = {435, ptf435, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf436[] = {392,936,0xFFF7,415,936,0xFFFF};
static struct eif_par_types par436 = {436, ptf436, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf437[] = {393,933,0xFFF7,416,933,0xFFFF};
static struct eif_par_types par437 = {437, ptf437, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf438[] = {394,915,0xFFF7,417,915,0xFFFF};
static struct eif_par_types par438 = {438, ptf438, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf439[] = {395,918,0xFFF7,418,918,0xFFFF};
static struct eif_par_types par439 = {439, ptf439, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf440[] = {396,924,0xFFF7,419,924,0xFFFF};
static struct eif_par_types par440 = {440, ptf440, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf441[] = {397,921,0xFFF7,420,921,0xFFFF};
static struct eif_par_types par441 = {441, ptf441, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf442[] = {398,972,0xFFF7,421,972,0xFFFF};
static struct eif_par_types par442 = {442, ptf442, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf443[] = {399,927,0xFFF7,422,927,0xFFFF};
static struct eif_par_types par443 = {443, ptf443, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf444[] = {400,930,0xFFF7,423,930,0xFFFF};
static struct eif_par_types par444 = {444, ptf444, (uint16) 2, (uint16) 1, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf445[] = {433,0xFFF8,1,0xFFFF};
static struct eif_par_types par445 = {445, ptf445, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf446[] = {434,906,0xFFFF};
static struct eif_par_types par446 = {446, ptf446, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf447[] = {435,939,0xFFFF};
static struct eif_par_types par447 = {447, ptf447, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [CHARACTER_8, G#2] */
static EIF_TYPE_INDEX ptf448[] = {436,936,0xFFFF};
static struct eif_par_types par448 = {448, ptf448, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [CHARACTER_32, G#2] */
static EIF_TYPE_INDEX ptf449[] = {437,933,0xFFFF};
static struct eif_par_types par449 = {449, ptf449, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [NATURAL_64, G#2] */
static EIF_TYPE_INDEX ptf450[] = {438,915,0xFFFF};
static struct eif_par_types par450 = {450, ptf450, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [NATURAL_32, G#2] */
static EIF_TYPE_INDEX ptf451[] = {439,918,0xFFFF};
static struct eif_par_types par451 = {451, ptf451, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf452[] = {440,924,0xFFFF};
static struct eif_par_types par452 = {452, ptf452, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [NATURAL_16, G#2] */
static EIF_TYPE_INDEX ptf453[] = {441,921,0xFFFF};
static struct eif_par_types par453 = {453, ptf453, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [POINTER, G#2] */
static EIF_TYPE_INDEX ptf454[] = {442,972,0xFFFF};
static struct eif_par_types par454 = {454, ptf454, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [REAL_32, G#2] */
static EIF_TYPE_INDEX ptf455[] = {443,927,0xFFFF};
static struct eif_par_types par455 = {455, ptf455, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [REAL_64, G#2] */
static EIF_TYPE_INDEX ptf456[] = {444,930,0xFFFF};
static struct eif_par_types par456 = {456, ptf456, (uint16) 1, (uint16) 2, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf457[] = {445,0xFFF8,1,0xFF01,734,0xFFF8,1,0xFFFF};
static struct eif_par_types par457 = {457, ptf457, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf458[] = {446,906,0xFF01,735,906,0xFFFF};
static struct eif_par_types par458 = {458, ptf458, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf459[] = {447,939,0xFF01,736,939,0xFFFF};
static struct eif_par_types par459 = {459, ptf459, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf460[] = {448,936,0xFF01,737,936,0xFFFF};
static struct eif_par_types par460 = {460, ptf460, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf461[] = {449,933,0xFF01,738,933,0xFFFF};
static struct eif_par_types par461 = {461, ptf461, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf462[] = {450,915,0xFF01,739,915,0xFFFF};
static struct eif_par_types par462 = {462, ptf462, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf463[] = {451,918,0xFF01,740,918,0xFFFF};
static struct eif_par_types par463 = {463, ptf463, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf464[] = {452,924,0xFF01,741,924,0xFFFF};
static struct eif_par_types par464 = {464, ptf464, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf465[] = {453,921,0xFF01,742,921,0xFFFF};
static struct eif_par_types par465 = {465, ptf465, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf466[] = {454,972,0xFF01,743,972,0xFFFF};
static struct eif_par_types par466 = {466, ptf466, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf467[] = {455,927,0xFF01,744,927,0xFFFF};
static struct eif_par_types par467 = {467, ptf467, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf468[] = {456,930,0xFF01,745,930,0xFFFF};
static struct eif_par_types par468 = {468, ptf468, (uint16) 1, (uint16) 1, (char) 0};

/* LINKED_LIST_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf469[] = {457,0xFFF8,1,0xFFFF};
static struct eif_par_types par469 = {469, ptf469, (uint16) 1, (uint16) 1, (char) 0};

/* LINKED_LIST_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf470[] = {458,906,0xFFFF};
static struct eif_par_types par470 = {470, ptf470, (uint16) 1, (uint16) 1, (char) 0};

/* HASH_TABLE_ITERATION_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf471[] = {457,0xFFF8,1,0xFFF7,403,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par471 = {471, ptf471, (uint16) 2, (uint16) 2, (char) 0};

/* HASH_TABLE_ITERATION_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf472[] = {458,906,0xFFF7,404,906,0xFFF8,2,0xFFFF};
static struct eif_par_types par472 = {472, ptf472, (uint16) 2, (uint16) 2, (char) 0};

/* HASH_TABLE_ITERATION_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf473[] = {457,0xFFF8,1,0xFFF7,405,0xFFF8,1,906,0xFFFF};
static struct eif_par_types par473 = {473, ptf473, (uint16) 2, (uint16) 2, (char) 0};

/* HASH_TABLE_ITERATION_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf474[] = {458,906,0xFFF7,406,906,906,0xFFFF};
static struct eif_par_types par474 = {474, ptf474, (uint16) 2, (uint16) 2, (char) 0};

/* HASH_TABLE_ITERATION_CURSOR [POINTER, G#2] */
static EIF_TYPE_INDEX ptf475[] = {466,972,0xFFF7,407,972,0xFFF8,2,0xFFFF};
static struct eif_par_types par475 = {475, ptf475, (uint16) 2, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf476[] = {445,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par476 = {476, ptf476, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf477[] = {446,906,0xFFF8,2,0xFFFF};
static struct eif_par_types par477 = {477, ptf477, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf478[] = {447,939,0xFFF8,2,0xFFFF};
static struct eif_par_types par478 = {478, ptf478, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [NATURAL_64, G#2] */
static EIF_TYPE_INDEX ptf479[] = {450,915,0xFFF8,2,0xFFFF};
static struct eif_par_types par479 = {479, ptf479, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [NATURAL_32, G#2] */
static EIF_TYPE_INDEX ptf480[] = {451,918,0xFFF8,2,0xFFFF};
static struct eif_par_types par480 = {480, ptf480, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [CHARACTER_32, G#2] */
static EIF_TYPE_INDEX ptf481[] = {449,933,0xFFF8,2,0xFFFF};
static struct eif_par_types par481 = {481, ptf481, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [CHARACTER_8, G#2] */
static EIF_TYPE_INDEX ptf482[] = {448,936,0xFFF8,2,0xFFFF};
static struct eif_par_types par482 = {482, ptf482, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf483[] = {452,924,0xFFF8,2,0xFFFF};
static struct eif_par_types par483 = {483, ptf483, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [NATURAL_16, G#2] */
static EIF_TYPE_INDEX ptf484[] = {453,921,0xFFF8,2,0xFFFF};
static struct eif_par_types par484 = {484, ptf484, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [POINTER, G#2] */
static EIF_TYPE_INDEX ptf485[] = {454,972,0xFFF8,2,0xFFFF};
static struct eif_par_types par485 = {485, ptf485, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [REAL_32, G#2] */
static EIF_TYPE_INDEX ptf486[] = {455,927,0xFFF8,2,0xFFFF};
static struct eif_par_types par486 = {486, ptf486, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [REAL_64, G#2] */
static EIF_TYPE_INDEX ptf487[] = {456,930,0xFFF8,2,0xFFFF};
static struct eif_par_types par487 = {487, ptf487, (uint16) 1, (uint16) 2, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf488[] = {476,0xFFF8,1,0xFF01,842,0xFFF8,1,0xFFFF};
static struct eif_par_types par488 = {488, ptf488, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf489[] = {477,906,0xFF01,843,906,0xFFFF};
static struct eif_par_types par489 = {489, ptf489, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf490[] = {478,939,0xFF01,844,939,0xFFFF};
static struct eif_par_types par490 = {490, ptf490, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf491[] = {479,915,0xFF01,845,915,0xFFFF};
static struct eif_par_types par491 = {491, ptf491, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf492[] = {480,918,0xFF01,846,918,0xFFFF};
static struct eif_par_types par492 = {492, ptf492, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf493[] = {481,933,0xFF01,847,933,0xFFFF};
static struct eif_par_types par493 = {493, ptf493, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf494[] = {482,936,0xFF01,848,936,0xFFFF};
static struct eif_par_types par494 = {494, ptf494, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf495[] = {483,924,0xFF01,849,924,0xFFFF};
static struct eif_par_types par495 = {495, ptf495, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf496[] = {484,921,0xFF01,850,921,0xFFFF};
static struct eif_par_types par496 = {496, ptf496, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf497[] = {485,972,0xFF01,851,972,0xFFFF};
static struct eif_par_types par497 = {497, ptf497, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf498[] = {486,927,0xFF01,852,927,0xFFFF};
static struct eif_par_types par498 = {498, ptf498, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf499[] = {487,930,0xFF01,853,930,0xFFFF};
static struct eif_par_types par499 = {499, ptf499, (uint16) 1, (uint16) 1, (char) 0};

/* STRING_32_ITERATION_CURSOR */
static EIF_TYPE_INDEX ptf500[] = {481,933,0xFF01,981,0xFFFF};
static struct eif_par_types par500 = {500, ptf500, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_8_ITERATION_CURSOR */
static EIF_TYPE_INDEX ptf501[] = {482,936,0xFF01,984,0xFFFF};
static struct eif_par_types par501 = {501, ptf501, (uint16) 1, (uint16) 0, (char) 0};

/* ARRAY_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf502[] = {476,0xFFF8,1,0xFF01,771,0xFFF8,1,0xFFFF};
static struct eif_par_types par502 = {502, ptf502, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf503[] = {477,906,0xFF01,772,906,0xFFFF};
static struct eif_par_types par503 = {503, ptf503, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf504[] = {478,939,0xFF01,773,939,0xFFFF};
static struct eif_par_types par504 = {504, ptf504, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf505[] = {479,915,0xFF01,774,915,0xFFFF};
static struct eif_par_types par505 = {505, ptf505, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf506[] = {480,918,0xFF01,775,918,0xFFFF};
static struct eif_par_types par506 = {506, ptf506, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf507[] = {481,933,0xFF01,776,933,0xFFFF};
static struct eif_par_types par507 = {507, ptf507, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf508[] = {482,936,0xFF01,777,936,0xFFFF};
static struct eif_par_types par508 = {508, ptf508, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf509[] = {483,924,0xFF01,778,924,0xFFFF};
static struct eif_par_types par509 = {509, ptf509, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf510[] = {484,921,0xFF01,779,921,0xFFFF};
static struct eif_par_types par510 = {510, ptf510, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf511[] = {485,972,0xFF01,780,972,0xFFFF};
static struct eif_par_types par511 = {511, ptf511, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf512[] = {486,927,0xFF01,781,927,0xFFFF};
static struct eif_par_types par512 = {512, ptf512, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf513[] = {487,930,0xFF01,782,930,0xFFFF};
static struct eif_par_types par513 = {513, ptf513, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf514[] = {476,0xFFF8,1,0xFF01,746,0xFFF8,1,0xFFFF};
static struct eif_par_types par514 = {514, ptf514, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf515[] = {477,906,0xFF01,747,906,0xFFFF};
static struct eif_par_types par515 = {515, ptf515, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf516[] = {478,939,0xFF01,748,939,0xFFFF};
static struct eif_par_types par516 = {516, ptf516, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf517[] = {479,915,0xFF01,749,915,0xFFFF};
static struct eif_par_types par517 = {517, ptf517, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf518[] = {480,918,0xFF01,750,918,0xFFFF};
static struct eif_par_types par518 = {518, ptf518, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf519[] = {481,933,0xFF01,751,933,0xFFFF};
static struct eif_par_types par519 = {519, ptf519, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf520[] = {482,936,0xFF01,752,936,0xFFFF};
static struct eif_par_types par520 = {520, ptf520, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf521[] = {483,924,0xFF01,753,924,0xFFFF};
static struct eif_par_types par521 = {521, ptf521, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf522[] = {484,921,0xFF01,754,921,0xFFFF};
static struct eif_par_types par522 = {522, ptf522, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf523[] = {485,972,0xFF01,755,972,0xFFFF};
static struct eif_par_types par523 = {523, ptf523, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf524[] = {486,927,0xFF01,756,927,0xFFFF};
static struct eif_par_types par524 = {524, ptf524, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf525[] = {487,930,0xFF01,757,930,0xFFFF};
static struct eif_par_types par525 = {525, ptf525, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [G#1] */
static EIF_TYPE_INDEX ptf526[] = {412,0xFFF8,1,0xFFFF};
static struct eif_par_types par526 = {526, ptf526, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [INTEGER_32] */
static EIF_TYPE_INDEX ptf527[] = {413,906,0xFFFF};
static struct eif_par_types par527 = {527, ptf527, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [BOOLEAN] */
static EIF_TYPE_INDEX ptf528[] = {414,939,0xFFFF};
static struct eif_par_types par528 = {528, ptf528, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf529[] = {415,936,0xFFFF};
static struct eif_par_types par529 = {529, ptf529, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [CHARACTER_32] */
static EIF_TYPE_INDEX ptf530[] = {416,933,0xFFFF};
static struct eif_par_types par530 = {530, ptf530, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [NATURAL_64] */
static EIF_TYPE_INDEX ptf531[] = {417,915,0xFFFF};
static struct eif_par_types par531 = {531, ptf531, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [NATURAL_32] */
static EIF_TYPE_INDEX ptf532[] = {418,918,0xFFFF};
static struct eif_par_types par532 = {532, ptf532, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [NATURAL_8] */
static EIF_TYPE_INDEX ptf533[] = {419,924,0xFFFF};
static struct eif_par_types par533 = {533, ptf533, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [NATURAL_16] */
static EIF_TYPE_INDEX ptf534[] = {420,921,0xFFFF};
static struct eif_par_types par534 = {534, ptf534, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [POINTER] */
static EIF_TYPE_INDEX ptf535[] = {421,972,0xFFFF};
static struct eif_par_types par535 = {535, ptf535, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [REAL_32] */
static EIF_TYPE_INDEX ptf536[] = {422,927,0xFFFF};
static struct eif_par_types par536 = {536, ptf536, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [REAL_64] */
static EIF_TYPE_INDEX ptf537[] = {423,930,0xFFFF};
static struct eif_par_types par537 = {537, ptf537, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [G#1] */
static EIF_TYPE_INDEX ptf538[] = {526,0xFFF8,1,0xFFFF};
static struct eif_par_types par538 = {538, ptf538, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf539[] = {527,906,0xFFFF};
static struct eif_par_types par539 = {539, ptf539, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf540[] = {528,939,0xFFFF};
static struct eif_par_types par540 = {540, ptf540, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf541[] = {529,936,0xFFFF};
static struct eif_par_types par541 = {541, ptf541, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf542[] = {530,933,0xFFFF};
static struct eif_par_types par542 = {542, ptf542, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf543[] = {531,915,0xFFFF};
static struct eif_par_types par543 = {543, ptf543, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf544[] = {532,918,0xFFFF};
static struct eif_par_types par544 = {544, ptf544, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [NATURAL_8] */
static EIF_TYPE_INDEX ptf545[] = {533,924,0xFFFF};
static struct eif_par_types par545 = {545, ptf545, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [NATURAL_16] */
static EIF_TYPE_INDEX ptf546[] = {534,921,0xFFFF};
static struct eif_par_types par546 = {546, ptf546, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [POINTER] */
static EIF_TYPE_INDEX ptf547[] = {535,972,0xFFFF};
static struct eif_par_types par547 = {547, ptf547, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [REAL_32] */
static EIF_TYPE_INDEX ptf548[] = {536,927,0xFFFF};
static struct eif_par_types par548 = {548, ptf548, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [REAL_64] */
static EIF_TYPE_INDEX ptf549[] = {537,930,0xFFFF};
static struct eif_par_types par549 = {549, ptf549, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [G#1] */
static EIF_TYPE_INDEX ptf550[] = {538,0xFFF8,1,0xFFFF};
static struct eif_par_types par550 = {550, ptf550, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [INTEGER_32] */
static EIF_TYPE_INDEX ptf551[] = {539,906,0xFFFF};
static struct eif_par_types par551 = {551, ptf551, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [BOOLEAN] */
static EIF_TYPE_INDEX ptf552[] = {540,939,0xFFFF};
static struct eif_par_types par552 = {552, ptf552, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf553[] = {541,936,0xFFFF};
static struct eif_par_types par553 = {553, ptf553, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf554[] = {542,933,0xFFFF};
static struct eif_par_types par554 = {554, ptf554, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [NATURAL_64] */
static EIF_TYPE_INDEX ptf555[] = {543,915,0xFFFF};
static struct eif_par_types par555 = {555, ptf555, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [NATURAL_32] */
static EIF_TYPE_INDEX ptf556[] = {544,918,0xFFFF};
static struct eif_par_types par556 = {556, ptf556, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [NATURAL_8] */
static EIF_TYPE_INDEX ptf557[] = {545,924,0xFFFF};
static struct eif_par_types par557 = {557, ptf557, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [NATURAL_16] */
static EIF_TYPE_INDEX ptf558[] = {546,921,0xFFFF};
static struct eif_par_types par558 = {558, ptf558, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [POINTER] */
static EIF_TYPE_INDEX ptf559[] = {547,972,0xFFFF};
static struct eif_par_types par559 = {559, ptf559, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [REAL_32] */
static EIF_TYPE_INDEX ptf560[] = {548,927,0xFFFF};
static struct eif_par_types par560 = {560, ptf560, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [REAL_64] */
static EIF_TYPE_INDEX ptf561[] = {549,930,0xFFFF};
static struct eif_par_types par561 = {561, ptf561, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [G#1] */
static EIF_TYPE_INDEX ptf562[] = {550,0xFFF8,1,0xFFFF};
static struct eif_par_types par562 = {562, ptf562, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [INTEGER_32] */
static EIF_TYPE_INDEX ptf563[] = {551,906,0xFFFF};
static struct eif_par_types par563 = {563, ptf563, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [BOOLEAN] */
static EIF_TYPE_INDEX ptf564[] = {552,939,0xFFFF};
static struct eif_par_types par564 = {564, ptf564, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [NATURAL_64] */
static EIF_TYPE_INDEX ptf565[] = {555,915,0xFFFF};
static struct eif_par_types par565 = {565, ptf565, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [NATURAL_32] */
static EIF_TYPE_INDEX ptf566[] = {556,918,0xFFFF};
static struct eif_par_types par566 = {566, ptf566, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf567[] = {554,933,0xFFFF};
static struct eif_par_types par567 = {567, ptf567, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf568[] = {553,936,0xFFFF};
static struct eif_par_types par568 = {568, ptf568, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [NATURAL_8] */
static EIF_TYPE_INDEX ptf569[] = {557,924,0xFFFF};
static struct eif_par_types par569 = {569, ptf569, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [NATURAL_16] */
static EIF_TYPE_INDEX ptf570[] = {558,921,0xFFFF};
static struct eif_par_types par570 = {570, ptf570, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [POINTER] */
static EIF_TYPE_INDEX ptf571[] = {559,972,0xFFFF};
static struct eif_par_types par571 = {571, ptf571, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [REAL_32] */
static EIF_TYPE_INDEX ptf572[] = {560,927,0xFFFF};
static struct eif_par_types par572 = {572, ptf572, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [REAL_64] */
static EIF_TYPE_INDEX ptf573[] = {561,930,0xFFFF};
static struct eif_par_types par573 = {573, ptf573, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [G#1] */
static EIF_TYPE_INDEX ptf574[] = {526,0xFFF8,1,0xFFFF};
static struct eif_par_types par574 = {574, ptf574, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [INTEGER_32] */
static EIF_TYPE_INDEX ptf575[] = {527,906,0xFFFF};
static struct eif_par_types par575 = {575, ptf575, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [BOOLEAN] */
static EIF_TYPE_INDEX ptf576[] = {528,939,0xFFFF};
static struct eif_par_types par576 = {576, ptf576, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [CHARACTER_8] */
static EIF_TYPE_INDEX ptf577[] = {529,936,0xFFFF};
static struct eif_par_types par577 = {577, ptf577, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [CHARACTER_32] */
static EIF_TYPE_INDEX ptf578[] = {530,933,0xFFFF};
static struct eif_par_types par578 = {578, ptf578, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [NATURAL_64] */
static EIF_TYPE_INDEX ptf579[] = {531,915,0xFFFF};
static struct eif_par_types par579 = {579, ptf579, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [NATURAL_32] */
static EIF_TYPE_INDEX ptf580[] = {532,918,0xFFFF};
static struct eif_par_types par580 = {580, ptf580, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [NATURAL_8] */
static EIF_TYPE_INDEX ptf581[] = {533,924,0xFFFF};
static struct eif_par_types par581 = {581, ptf581, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [NATURAL_16] */
static EIF_TYPE_INDEX ptf582[] = {534,921,0xFFFF};
static struct eif_par_types par582 = {582, ptf582, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [POINTER] */
static EIF_TYPE_INDEX ptf583[] = {535,972,0xFFFF};
static struct eif_par_types par583 = {583, ptf583, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [REAL_32] */
static EIF_TYPE_INDEX ptf584[] = {536,927,0xFFFF};
static struct eif_par_types par584 = {584, ptf584, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [REAL_64] */
static EIF_TYPE_INDEX ptf585[] = {537,930,0xFFFF};
static struct eif_par_types par585 = {585, ptf585, (uint16) 1, (uint16) 1, (char) 0};

/* SET [INTEGER_32] */
static EIF_TYPE_INDEX ptf586[] = {575,906,0xFFFF};
static struct eif_par_types par586 = {586, ptf586, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [G#1] */
static EIF_TYPE_INDEX ptf587[] = {574,0xFFF8,1,0xFFFF};
static struct eif_par_types par587 = {587, ptf587, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [INTEGER_32] */
static EIF_TYPE_INDEX ptf588[] = {575,906,0xFFFF};
static struct eif_par_types par588 = {588, ptf588, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [BOOLEAN] */
static EIF_TYPE_INDEX ptf589[] = {576,939,0xFFFF};
static struct eif_par_types par589 = {589, ptf589, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [CHARACTER_8] */
static EIF_TYPE_INDEX ptf590[] = {577,936,0xFFFF};
static struct eif_par_types par590 = {590, ptf590, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [CHARACTER_32] */
static EIF_TYPE_INDEX ptf591[] = {578,933,0xFFFF};
static struct eif_par_types par591 = {591, ptf591, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [NATURAL_64] */
static EIF_TYPE_INDEX ptf592[] = {579,915,0xFFFF};
static struct eif_par_types par592 = {592, ptf592, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [NATURAL_32] */
static EIF_TYPE_INDEX ptf593[] = {580,918,0xFFFF};
static struct eif_par_types par593 = {593, ptf593, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [NATURAL_8] */
static EIF_TYPE_INDEX ptf594[] = {581,924,0xFFFF};
static struct eif_par_types par594 = {594, ptf594, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [NATURAL_16] */
static EIF_TYPE_INDEX ptf595[] = {582,921,0xFFFF};
static struct eif_par_types par595 = {595, ptf595, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [POINTER] */
static EIF_TYPE_INDEX ptf596[] = {583,972,0xFFFF};
static struct eif_par_types par596 = {596, ptf596, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [REAL_32] */
static EIF_TYPE_INDEX ptf597[] = {584,927,0xFFFF};
static struct eif_par_types par597 = {597, ptf597, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [REAL_64] */
static EIF_TYPE_INDEX ptf598[] = {585,930,0xFFFF};
static struct eif_par_types par598 = {598, ptf598, (uint16) 1, (uint16) 1, (char) 0};

/* TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf599[] = {587,0xFFF8,1,0xFFFF};
static struct eif_par_types par599 = {599, ptf599, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf600[] = {587,0xFFF8,1,0xFFFF};
static struct eif_par_types par600 = {600, ptf600, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf601[] = {588,906,0xFFFF};
static struct eif_par_types par601 = {601, ptf601, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf602[] = {588,906,0xFFFF};
static struct eif_par_types par602 = {602, ptf602, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [BOOLEAN, INTEGER_32] */
static EIF_TYPE_INDEX ptf603[] = {589,939,0xFFFF};
static struct eif_par_types par603 = {603, ptf603, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [CHARACTER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf604[] = {591,933,0xFFFF};
static struct eif_par_types par604 = {604, ptf604, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [NATURAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf605[] = {592,915,0xFFFF};
static struct eif_par_types par605 = {605, ptf605, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [NATURAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf606[] = {593,918,0xFFFF};
static struct eif_par_types par606 = {606, ptf606, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [CHARACTER_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf607[] = {590,936,0xFFFF};
static struct eif_par_types par607 = {607, ptf607, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [NATURAL_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf608[] = {594,924,0xFFFF};
static struct eif_par_types par608 = {608, ptf608, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [NATURAL_16, INTEGER_32] */
static EIF_TYPE_INDEX ptf609[] = {595,921,0xFFFF};
static struct eif_par_types par609 = {609, ptf609, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [POINTER, G#2] */
static EIF_TYPE_INDEX ptf610[] = {596,972,0xFFFF};
static struct eif_par_types par610 = {610, ptf610, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [POINTER, INTEGER_32] */
static EIF_TYPE_INDEX ptf611[] = {596,972,0xFFFF};
static struct eif_par_types par611 = {611, ptf611, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [REAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf612[] = {597,927,0xFFFF};
static struct eif_par_types par612 = {612, ptf612, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [REAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf613[] = {598,930,0xFFFF};
static struct eif_par_types par613 = {613, ptf613, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf614[] = {599,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par614 = {614, ptf614, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf615[] = {600,0xFFF8,1,906,0xFFFF};
static struct eif_par_types par615 = {615, ptf615, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf616[] = {601,906,0xFFF8,2,0xFFFF};
static struct eif_par_types par616 = {616, ptf616, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf617[] = {602,906,906,0xFFFF};
static struct eif_par_types par617 = {617, ptf617, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [BOOLEAN, INTEGER_32] */
static EIF_TYPE_INDEX ptf618[] = {603,939,906,0xFFFF};
static struct eif_par_types par618 = {618, ptf618, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [NATURAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf619[] = {605,915,906,0xFFFF};
static struct eif_par_types par619 = {619, ptf619, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [NATURAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf620[] = {606,918,906,0xFFFF};
static struct eif_par_types par620 = {620, ptf620, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [CHARACTER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf621[] = {604,933,906,0xFFFF};
static struct eif_par_types par621 = {621, ptf621, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [CHARACTER_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf622[] = {607,936,906,0xFFFF};
static struct eif_par_types par622 = {622, ptf622, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [NATURAL_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf623[] = {608,924,906,0xFFFF};
static struct eif_par_types par623 = {623, ptf623, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [NATURAL_16, INTEGER_32] */
static EIF_TYPE_INDEX ptf624[] = {609,921,906,0xFFFF};
static struct eif_par_types par624 = {624, ptf624, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [POINTER, G#2] */
static EIF_TYPE_INDEX ptf625[] = {610,972,0xFFF8,2,0xFFFF};
static struct eif_par_types par625 = {625, ptf625, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [POINTER, INTEGER_32] */
static EIF_TYPE_INDEX ptf626[] = {611,972,906,0xFFFF};
static struct eif_par_types par626 = {626, ptf626, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [REAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf627[] = {612,927,906,0xFFFF};
static struct eif_par_types par627 = {627, ptf627, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [REAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf628[] = {613,930,906,0xFFFF};
static struct eif_par_types par628 = {628, ptf628, (uint16) 1, (uint16) 2, (char) 0};

/* ACTIVE [G#1] */
static EIF_TYPE_INDEX ptf629[] = {587,0xFFF8,1,0xFFFF};
static struct eif_par_types par629 = {629, ptf629, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [INTEGER_32] */
static EIF_TYPE_INDEX ptf630[] = {588,906,0xFFFF};
static struct eif_par_types par630 = {630, ptf630, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [BOOLEAN] */
static EIF_TYPE_INDEX ptf631[] = {589,939,0xFFFF};
static struct eif_par_types par631 = {631, ptf631, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf632[] = {590,936,0xFFFF};
static struct eif_par_types par632 = {632, ptf632, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf633[] = {591,933,0xFFFF};
static struct eif_par_types par633 = {633, ptf633, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [NATURAL_64] */
static EIF_TYPE_INDEX ptf634[] = {592,915,0xFFFF};
static struct eif_par_types par634 = {634, ptf634, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [NATURAL_32] */
static EIF_TYPE_INDEX ptf635[] = {593,918,0xFFFF};
static struct eif_par_types par635 = {635, ptf635, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [NATURAL_8] */
static EIF_TYPE_INDEX ptf636[] = {594,924,0xFFFF};
static struct eif_par_types par636 = {636, ptf636, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [NATURAL_16] */
static EIF_TYPE_INDEX ptf637[] = {595,921,0xFFFF};
static struct eif_par_types par637 = {637, ptf637, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [POINTER] */
static EIF_TYPE_INDEX ptf638[] = {596,972,0xFFFF};
static struct eif_par_types par638 = {638, ptf638, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [REAL_32] */
static EIF_TYPE_INDEX ptf639[] = {597,927,0xFFFF};
static struct eif_par_types par639 = {639, ptf639, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [REAL_64] */
static EIF_TYPE_INDEX ptf640[] = {598,930,0xFFFF};
static struct eif_par_types par640 = {640, ptf640, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [G#1] */
static EIF_TYPE_INDEX ptf641[] = {629,0xFFF8,1,0xFFFF};
static struct eif_par_types par641 = {641, ptf641, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [INTEGER_32] */
static EIF_TYPE_INDEX ptf642[] = {630,906,0xFFFF};
static struct eif_par_types par642 = {642, ptf642, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [BOOLEAN] */
static EIF_TYPE_INDEX ptf643[] = {631,939,0xFFFF};
static struct eif_par_types par643 = {643, ptf643, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf644[] = {632,936,0xFFFF};
static struct eif_par_types par644 = {644, ptf644, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf645[] = {633,933,0xFFFF};
static struct eif_par_types par645 = {645, ptf645, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [NATURAL_64] */
static EIF_TYPE_INDEX ptf646[] = {634,915,0xFFFF};
static struct eif_par_types par646 = {646, ptf646, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [NATURAL_32] */
static EIF_TYPE_INDEX ptf647[] = {635,918,0xFFFF};
static struct eif_par_types par647 = {647, ptf647, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [NATURAL_8] */
static EIF_TYPE_INDEX ptf648[] = {636,924,0xFFFF};
static struct eif_par_types par648 = {648, ptf648, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [NATURAL_16] */
static EIF_TYPE_INDEX ptf649[] = {637,921,0xFFFF};
static struct eif_par_types par649 = {649, ptf649, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [POINTER] */
static EIF_TYPE_INDEX ptf650[] = {638,972,0xFFFF};
static struct eif_par_types par650 = {650, ptf650, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [REAL_32] */
static EIF_TYPE_INDEX ptf651[] = {639,927,0xFFFF};
static struct eif_par_types par651 = {651, ptf651, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [REAL_64] */
static EIF_TYPE_INDEX ptf652[] = {640,930,0xFFFF};
static struct eif_par_types par652 = {652, ptf652, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [G#1] */
static EIF_TYPE_INDEX ptf653[] = {526,0xFFF8,1,0xFFFF};
static struct eif_par_types par653 = {653, ptf653, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [INTEGER_32] */
static EIF_TYPE_INDEX ptf654[] = {527,906,0xFFFF};
static struct eif_par_types par654 = {654, ptf654, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [BOOLEAN] */
static EIF_TYPE_INDEX ptf655[] = {528,939,0xFFFF};
static struct eif_par_types par655 = {655, ptf655, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [CHARACTER_8] */
static EIF_TYPE_INDEX ptf656[] = {529,936,0xFFFF};
static struct eif_par_types par656 = {656, ptf656, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [CHARACTER_32] */
static EIF_TYPE_INDEX ptf657[] = {530,933,0xFFFF};
static struct eif_par_types par657 = {657, ptf657, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [NATURAL_64] */
static EIF_TYPE_INDEX ptf658[] = {531,915,0xFFFF};
static struct eif_par_types par658 = {658, ptf658, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [NATURAL_32] */
static EIF_TYPE_INDEX ptf659[] = {532,918,0xFFFF};
static struct eif_par_types par659 = {659, ptf659, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [NATURAL_8] */
static EIF_TYPE_INDEX ptf660[] = {533,924,0xFFFF};
static struct eif_par_types par660 = {660, ptf660, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [NATURAL_16] */
static EIF_TYPE_INDEX ptf661[] = {534,921,0xFFFF};
static struct eif_par_types par661 = {661, ptf661, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [POINTER] */
static EIF_TYPE_INDEX ptf662[] = {535,972,0xFFFF};
static struct eif_par_types par662 = {662, ptf662, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [REAL_32] */
static EIF_TYPE_INDEX ptf663[] = {536,927,0xFFFF};
static struct eif_par_types par663 = {663, ptf663, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [REAL_64] */
static EIF_TYPE_INDEX ptf664[] = {537,930,0xFFFF};
static struct eif_par_types par664 = {664, ptf664, (uint16) 1, (uint16) 1, (char) 0};

/* INFINITE [INTEGER_32] */
static EIF_TYPE_INDEX ptf665[] = {654,906,0xFFFF};
static struct eif_par_types par665 = {665, ptf665, (uint16) 1, (uint16) 1, (char) 0};

/* COUNTABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf666[] = {665,906,0xFFFF};
static struct eif_par_types par666 = {666, ptf666, (uint16) 1, (uint16) 1, (char) 0};

/* COUNTABLE_SEQUENCE [INTEGER_32] */
static EIF_TYPE_INDEX ptf667[] = {666,906,0xFFF7,551,906,0xFFFF};
static struct eif_par_types par667 = {667, ptf667, (uint16) 2, (uint16) 1, (char) 0};

/* PRIMES */
static EIF_TYPE_INDEX ptf668[] = {667,906,0xFFF7,390,906,0xFFFF};
static struct eif_par_types par668 = {668, ptf668, (uint16) 2, (uint16) 0, (char) 0};

/* FINITE [G#1] */
static EIF_TYPE_INDEX ptf669[] = {653,0xFFF8,1,0xFFFF};
static struct eif_par_types par669 = {669, ptf669, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [INTEGER_32] */
static EIF_TYPE_INDEX ptf670[] = {654,906,0xFFFF};
static struct eif_par_types par670 = {670, ptf670, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [BOOLEAN] */
static EIF_TYPE_INDEX ptf671[] = {655,939,0xFFFF};
static struct eif_par_types par671 = {671, ptf671, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf672[] = {656,936,0xFFFF};
static struct eif_par_types par672 = {672, ptf672, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf673[] = {657,933,0xFFFF};
static struct eif_par_types par673 = {673, ptf673, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [NATURAL_64] */
static EIF_TYPE_INDEX ptf674[] = {658,915,0xFFFF};
static struct eif_par_types par674 = {674, ptf674, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [NATURAL_32] */
static EIF_TYPE_INDEX ptf675[] = {659,918,0xFFFF};
static struct eif_par_types par675 = {675, ptf675, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [NATURAL_8] */
static EIF_TYPE_INDEX ptf676[] = {660,924,0xFFFF};
static struct eif_par_types par676 = {676, ptf676, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [NATURAL_16] */
static EIF_TYPE_INDEX ptf677[] = {661,921,0xFFFF};
static struct eif_par_types par677 = {677, ptf677, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [POINTER] */
static EIF_TYPE_INDEX ptf678[] = {662,972,0xFFFF};
static struct eif_par_types par678 = {678, ptf678, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [REAL_32] */
static EIF_TYPE_INDEX ptf679[] = {663,927,0xFFFF};
static struct eif_par_types par679 = {679, ptf679, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [REAL_64] */
static EIF_TYPE_INDEX ptf680[] = {664,930,0xFFFF};
static struct eif_par_types par680 = {680, ptf680, (uint16) 1, (uint16) 1, (char) 0};

/* DISPENSER [G#1] */
static EIF_TYPE_INDEX ptf681[] = {629,0xFFF8,1,0xFFF7,669,0xFFF8,1,0xFFFF};
static struct eif_par_types par681 = {681, ptf681, (uint16) 2, (uint16) 1, (char) 0};

/* QUEUE [G#1] */
static EIF_TYPE_INDEX ptf682[] = {681,0xFFF8,1,0xFFFF};
static struct eif_par_types par682 = {682, ptf682, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [G#1] */
static EIF_TYPE_INDEX ptf683[] = {669,0xFFF8,1,0xFFFF};
static struct eif_par_types par683 = {683, ptf683, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [INTEGER_32] */
static EIF_TYPE_INDEX ptf684[] = {670,906,0xFFFF};
static struct eif_par_types par684 = {684, ptf684, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [BOOLEAN] */
static EIF_TYPE_INDEX ptf685[] = {671,939,0xFFFF};
static struct eif_par_types par685 = {685, ptf685, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [CHARACTER_8] */
static EIF_TYPE_INDEX ptf686[] = {672,936,0xFFFF};
static struct eif_par_types par686 = {686, ptf686, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [NATURAL_64] */
static EIF_TYPE_INDEX ptf687[] = {674,915,0xFFFF};
static struct eif_par_types par687 = {687, ptf687, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [NATURAL_32] */
static EIF_TYPE_INDEX ptf688[] = {675,918,0xFFFF};
static struct eif_par_types par688 = {688, ptf688, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [CHARACTER_32] */
static EIF_TYPE_INDEX ptf689[] = {673,933,0xFFFF};
static struct eif_par_types par689 = {689, ptf689, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [NATURAL_8] */
static EIF_TYPE_INDEX ptf690[] = {676,924,0xFFFF};
static struct eif_par_types par690 = {690, ptf690, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [NATURAL_16] */
static EIF_TYPE_INDEX ptf691[] = {677,921,0xFFFF};
static struct eif_par_types par691 = {691, ptf691, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [POINTER] */
static EIF_TYPE_INDEX ptf692[] = {678,972,0xFFFF};
static struct eif_par_types par692 = {692, ptf692, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [REAL_32] */
static EIF_TYPE_INDEX ptf693[] = {679,927,0xFFFF};
static struct eif_par_types par693 = {693, ptf693, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [REAL_64] */
static EIF_TYPE_INDEX ptf694[] = {680,930,0xFFFF};
static struct eif_par_types par694 = {694, ptf694, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [G#1] */
static EIF_TYPE_INDEX ptf695[] = {683,0xFFF8,1,0xFFFF};
static struct eif_par_types par695 = {695, ptf695, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf696[] = {684,906,0xFFFF};
static struct eif_par_types par696 = {696, ptf696, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf697[] = {685,939,0xFFFF};
static struct eif_par_types par697 = {697, ptf697, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf698[] = {686,936,0xFFFF};
static struct eif_par_types par698 = {698, ptf698, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf699[] = {687,915,0xFFFF};
static struct eif_par_types par699 = {699, ptf699, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf700[] = {688,918,0xFFFF};
static struct eif_par_types par700 = {700, ptf700, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf701[] = {689,933,0xFFFF};
static struct eif_par_types par701 = {701, ptf701, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [NATURAL_8] */
static EIF_TYPE_INDEX ptf702[] = {690,924,0xFFFF};
static struct eif_par_types par702 = {702, ptf702, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [NATURAL_16] */
static EIF_TYPE_INDEX ptf703[] = {691,921,0xFFFF};
static struct eif_par_types par703 = {703, ptf703, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [POINTER] */
static EIF_TYPE_INDEX ptf704[] = {692,972,0xFFFF};
static struct eif_par_types par704 = {704, ptf704, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [REAL_32] */
static EIF_TYPE_INDEX ptf705[] = {693,927,0xFFFF};
static struct eif_par_types par705 = {705, ptf705, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [REAL_64] */
static EIF_TYPE_INDEX ptf706[] = {694,930,0xFFFF};
static struct eif_par_types par706 = {706, ptf706, (uint16) 1, (uint16) 1, (char) 0};

/* SEQUENCE [G#1] */
static EIF_TYPE_INDEX ptf707[] = {629,0xFFF8,1,0xFFF7,562,0xFFF8,1,0xFFF7,669,0xFFF8,1,0xFFFF};
static struct eif_par_types par707 = {707, ptf707, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [INTEGER_32] */
static EIF_TYPE_INDEX ptf708[] = {630,906,0xFFF7,563,906,0xFFF7,670,906,0xFFFF};
static struct eif_par_types par708 = {708, ptf708, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [BOOLEAN] */
static EIF_TYPE_INDEX ptf709[] = {631,939,0xFFF7,564,939,0xFFF7,671,939,0xFFFF};
static struct eif_par_types par709 = {709, ptf709, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [NATURAL_64] */
static EIF_TYPE_INDEX ptf710[] = {634,915,0xFFF7,565,915,0xFFF7,674,915,0xFFFF};
static struct eif_par_types par710 = {710, ptf710, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [NATURAL_32] */
static EIF_TYPE_INDEX ptf711[] = {635,918,0xFFF7,566,918,0xFFF7,675,918,0xFFFF};
static struct eif_par_types par711 = {711, ptf711, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf712[] = {633,933,0xFFF7,567,933,0xFFF7,673,933,0xFFFF};
static struct eif_par_types par712 = {712, ptf712, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf713[] = {632,936,0xFFF7,568,936,0xFFF7,672,936,0xFFFF};
static struct eif_par_types par713 = {713, ptf713, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [NATURAL_8] */
static EIF_TYPE_INDEX ptf714[] = {636,924,0xFFF7,569,924,0xFFF7,676,924,0xFFFF};
static struct eif_par_types par714 = {714, ptf714, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [NATURAL_16] */
static EIF_TYPE_INDEX ptf715[] = {637,921,0xFFF7,570,921,0xFFF7,677,921,0xFFFF};
static struct eif_par_types par715 = {715, ptf715, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [POINTER] */
static EIF_TYPE_INDEX ptf716[] = {638,972,0xFFF7,571,972,0xFFF7,678,972,0xFFFF};
static struct eif_par_types par716 = {716, ptf716, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [REAL_32] */
static EIF_TYPE_INDEX ptf717[] = {639,927,0xFFF7,572,927,0xFFF7,679,927,0xFFFF};
static struct eif_par_types par717 = {717, ptf717, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [REAL_64] */
static EIF_TYPE_INDEX ptf718[] = {640,930,0xFFF7,573,930,0xFFF7,680,930,0xFFFF};
static struct eif_par_types par718 = {718, ptf718, (uint16) 3, (uint16) 1, (char) 0};

/* UNBOUNDED [G#1] */
static EIF_TYPE_INDEX ptf719[] = {669,0xFFF8,1,0xFFFF};
static struct eif_par_types par719 = {719, ptf719, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [INTEGER_32] */
static EIF_TYPE_INDEX ptf720[] = {670,906,0xFFFF};
static struct eif_par_types par720 = {720, ptf720, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [BOOLEAN] */
static EIF_TYPE_INDEX ptf721[] = {671,939,0xFFFF};
static struct eif_par_types par721 = {721, ptf721, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [NATURAL_64] */
static EIF_TYPE_INDEX ptf722[] = {674,915,0xFFFF};
static struct eif_par_types par722 = {722, ptf722, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [NATURAL_32] */
static EIF_TYPE_INDEX ptf723[] = {675,918,0xFFFF};
static struct eif_par_types par723 = {723, ptf723, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [CHARACTER_32] */
static EIF_TYPE_INDEX ptf724[] = {673,933,0xFFFF};
static struct eif_par_types par724 = {724, ptf724, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [CHARACTER_8] */
static EIF_TYPE_INDEX ptf725[] = {672,936,0xFFFF};
static struct eif_par_types par725 = {725, ptf725, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [NATURAL_8] */
static EIF_TYPE_INDEX ptf726[] = {676,924,0xFFFF};
static struct eif_par_types par726 = {726, ptf726, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [NATURAL_16] */
static EIF_TYPE_INDEX ptf727[] = {677,921,0xFFFF};
static struct eif_par_types par727 = {727, ptf727, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [POINTER] */
static EIF_TYPE_INDEX ptf728[] = {678,972,0xFFFF};
static struct eif_par_types par728 = {728, ptf728, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [REAL_32] */
static EIF_TYPE_INDEX ptf729[] = {679,927,0xFFFF};
static struct eif_par_types par729 = {729, ptf729, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [REAL_64] */
static EIF_TYPE_INDEX ptf730[] = {680,930,0xFFFF};
static struct eif_par_types par730 = {730, ptf730, (uint16) 1, (uint16) 1, (char) 0};

/* FILE */
static EIF_TYPE_INDEX ptf731[] = {725,936,0xFFF7,713,936,0xFFF7,337,0xFFF7,322,0xFFFF};
static struct eif_par_types par731 = {731, ptf731, (uint16) 4, (uint16) 0, (char) 0};

/* RAW_FILE */
static EIF_TYPE_INDEX ptf732[] = {731,0xFFFF};
static struct eif_par_types par732 = {732, ptf732, (uint16) 1, (uint16) 0, (char) 0};

/* PLAIN_TEXT_FILE */
static EIF_TYPE_INDEX ptf733[] = {731,0xFFFF};
static struct eif_par_types par733 = {733, ptf733, (uint16) 1, (uint16) 0, (char) 0};

/* READABLE_INDEXABLE [G#1] */
static EIF_TYPE_INDEX ptf734[] = {412,0xFFF8,1,0xFFFF};
static struct eif_par_types par734 = {734, ptf734, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf735[] = {413,906,0xFFFF};
static struct eif_par_types par735 = {735, ptf735, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf736[] = {414,939,0xFFFF};
static struct eif_par_types par736 = {736, ptf736, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf737[] = {415,936,0xFFFF};
static struct eif_par_types par737 = {737, ptf737, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf738[] = {416,933,0xFFFF};
static struct eif_par_types par738 = {738, ptf738, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf739[] = {417,915,0xFFFF};
static struct eif_par_types par739 = {739, ptf739, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf740[] = {418,918,0xFFFF};
static struct eif_par_types par740 = {740, ptf740, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [NATURAL_8] */
static EIF_TYPE_INDEX ptf741[] = {419,924,0xFFFF};
static struct eif_par_types par741 = {741, ptf741, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [NATURAL_16] */
static EIF_TYPE_INDEX ptf742[] = {420,921,0xFFFF};
static struct eif_par_types par742 = {742, ptf742, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [POINTER] */
static EIF_TYPE_INDEX ptf743[] = {421,972,0xFFFF};
static struct eif_par_types par743 = {743, ptf743, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [REAL_32] */
static EIF_TYPE_INDEX ptf744[] = {422,927,0xFFFF};
static struct eif_par_types par744 = {744, ptf744, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [REAL_64] */
static EIF_TYPE_INDEX ptf745[] = {423,930,0xFFFF};
static struct eif_par_types par745 = {745, ptf745, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL [G#1] */
static EIF_TYPE_INDEX ptf746[] = {341,0xFFF7,734,0xFFF8,1,0xFFFF};
static struct eif_par_types par746 = {746, ptf746, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [INTEGER_32] */
static EIF_TYPE_INDEX ptf747[] = {341,0xFFF7,735,906,0xFFFF};
static struct eif_par_types par747 = {747, ptf747, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [BOOLEAN] */
static EIF_TYPE_INDEX ptf748[] = {341,0xFFF7,736,939,0xFFFF};
static struct eif_par_types par748 = {748, ptf748, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [NATURAL_64] */
static EIF_TYPE_INDEX ptf749[] = {341,0xFFF7,739,915,0xFFFF};
static struct eif_par_types par749 = {749, ptf749, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [NATURAL_32] */
static EIF_TYPE_INDEX ptf750[] = {341,0xFFF7,740,918,0xFFFF};
static struct eif_par_types par750 = {750, ptf750, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [CHARACTER_32] */
static EIF_TYPE_INDEX ptf751[] = {341,0xFFF7,738,933,0xFFFF};
static struct eif_par_types par751 = {751, ptf751, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [CHARACTER_8] */
static EIF_TYPE_INDEX ptf752[] = {341,0xFFF7,737,936,0xFFFF};
static struct eif_par_types par752 = {752, ptf752, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [NATURAL_8] */
static EIF_TYPE_INDEX ptf753[] = {341,0xFFF7,741,924,0xFFFF};
static struct eif_par_types par753 = {753, ptf753, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [NATURAL_16] */
static EIF_TYPE_INDEX ptf754[] = {341,0xFFF7,742,921,0xFFFF};
static struct eif_par_types par754 = {754, ptf754, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [POINTER] */
static EIF_TYPE_INDEX ptf755[] = {341,0xFFF7,743,972,0xFFFF};
static struct eif_par_types par755 = {755, ptf755, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [REAL_32] */
static EIF_TYPE_INDEX ptf756[] = {341,0xFFF7,744,927,0xFFFF};
static struct eif_par_types par756 = {756, ptf756, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [REAL_64] */
static EIF_TYPE_INDEX ptf757[] = {341,0xFFF7,745,930,0xFFFF};
static struct eif_par_types par757 = {757, ptf757, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf758[] = {600,0xFFF8,1,906,0xFFF7,734,0xFFF8,1,0xFFFF};
static struct eif_par_types par758 = {758, ptf758, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf759[] = {602,906,906,0xFFF7,735,906,0xFFFF};
static struct eif_par_types par759 = {759, ptf759, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [BOOLEAN, INTEGER_32] */
static EIF_TYPE_INDEX ptf760[] = {603,939,906,0xFFF7,736,939,0xFFFF};
static struct eif_par_types par760 = {760, ptf760, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [CHARACTER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf761[] = {604,933,906,0xFFF7,738,933,0xFFFF};
static struct eif_par_types par761 = {761, ptf761, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [NATURAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf762[] = {605,915,906,0xFFF7,739,915,0xFFFF};
static struct eif_par_types par762 = {762, ptf762, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [NATURAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf763[] = {606,918,906,0xFFF7,740,918,0xFFFF};
static struct eif_par_types par763 = {763, ptf763, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [CHARACTER_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf764[] = {607,936,906,0xFFF7,737,936,0xFFFF};
static struct eif_par_types par764 = {764, ptf764, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [NATURAL_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf765[] = {608,924,906,0xFFF7,741,924,0xFFFF};
static struct eif_par_types par765 = {765, ptf765, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [NATURAL_16, INTEGER_32] */
static EIF_TYPE_INDEX ptf766[] = {609,921,906,0xFFF7,742,921,0xFFFF};
static struct eif_par_types par766 = {766, ptf766, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [POINTER, INTEGER_32] */
static EIF_TYPE_INDEX ptf767[] = {611,972,906,0xFFF7,743,972,0xFFFF};
static struct eif_par_types par767 = {767, ptf767, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [REAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf768[] = {612,927,906,0xFFF7,744,927,0xFFFF};
static struct eif_par_types par768 = {768, ptf768, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [REAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf769[] = {613,930,906,0xFFF7,745,930,0xFFFF};
static struct eif_par_types par769 = {769, ptf769, (uint16) 2, (uint16) 2, (char) 0};

/* INTEGER_INTERVAL */
static EIF_TYPE_INDEX ptf770[] = {696,906,0xFFF7,759,906,906,0xFFF7,586,906,0xFFFF};
static struct eif_par_types par770 = {770, ptf770, (uint16) 3, (uint16) 0, (char) 0};

/* ARRAY [G#1] */
static EIF_TYPE_INDEX ptf771[] = {695,0xFFF8,1,0xFFF7,758,0xFFF8,1,906,0xFFF7,289,0xFFF8,1,0xFFFF};
static struct eif_par_types par771 = {771, ptf771, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [INTEGER_32] */
static EIF_TYPE_INDEX ptf772[] = {696,906,0xFFF7,759,906,906,0xFFF7,290,906,0xFFFF};
static struct eif_par_types par772 = {772, ptf772, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [BOOLEAN] */
static EIF_TYPE_INDEX ptf773[] = {697,939,0xFFF7,760,939,906,0xFFF7,291,939,0xFFFF};
static struct eif_par_types par773 = {773, ptf773, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [NATURAL_64] */
static EIF_TYPE_INDEX ptf774[] = {699,915,0xFFF7,762,915,906,0xFFF7,292,915,0xFFFF};
static struct eif_par_types par774 = {774, ptf774, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [NATURAL_32] */
static EIF_TYPE_INDEX ptf775[] = {700,918,0xFFF7,763,918,906,0xFFF7,293,918,0xFFFF};
static struct eif_par_types par775 = {775, ptf775, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [CHARACTER_32] */
static EIF_TYPE_INDEX ptf776[] = {701,933,0xFFF7,761,933,906,0xFFF7,294,933,0xFFFF};
static struct eif_par_types par776 = {776, ptf776, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [CHARACTER_8] */
static EIF_TYPE_INDEX ptf777[] = {698,936,0xFFF7,764,936,906,0xFFF7,295,936,0xFFFF};
static struct eif_par_types par777 = {777, ptf777, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [NATURAL_8] */
static EIF_TYPE_INDEX ptf778[] = {702,924,0xFFF7,765,924,906,0xFFF7,296,924,0xFFFF};
static struct eif_par_types par778 = {778, ptf778, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [NATURAL_16] */
static EIF_TYPE_INDEX ptf779[] = {703,921,0xFFF7,766,921,906,0xFFF7,297,921,0xFFFF};
static struct eif_par_types par779 = {779, ptf779, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [POINTER] */
static EIF_TYPE_INDEX ptf780[] = {704,972,0xFFF7,767,972,906,0xFFF7,298,972,0xFFFF};
static struct eif_par_types par780 = {780, ptf780, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [REAL_32] */
static EIF_TYPE_INDEX ptf781[] = {705,927,0xFFF7,768,927,906,0xFFF7,299,927,0xFFFF};
static struct eif_par_types par781 = {781, ptf781, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [REAL_64] */
static EIF_TYPE_INDEX ptf782[] = {706,930,0xFFF7,769,930,906,0xFFF7,300,930,0xFFFF};
static struct eif_par_types par782 = {782, ptf782, (uint16) 3, (uint16) 1, (char) 0};

/* KL_ARRAY [G#1] */
static EIF_TYPE_INDEX ptf783[] = {771,0xFFF8,1,0xFFFF};
static struct eif_par_types par783 = {783, ptf783, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY [BOOLEAN] */
static EIF_TYPE_INDEX ptf784[] = {773,939,0xFFFF};
static struct eif_par_types par784 = {784, ptf784, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY [NATURAL_32] */
static EIF_TYPE_INDEX ptf785[] = {775,918,0xFFFF};
static struct eif_par_types par785 = {785, ptf785, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY [NATURAL_64] */
static EIF_TYPE_INDEX ptf786[] = {774,915,0xFFFF};
static struct eif_par_types par786 = {786, ptf786, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY [INTEGER_32] */
static EIF_TYPE_INDEX ptf787[] = {772,906,0xFFFF};
static struct eif_par_types par787 = {787, ptf787, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY [CHARACTER_8] */
static EIF_TYPE_INDEX ptf788[] = {777,936,0xFFFF};
static struct eif_par_types par788 = {788, ptf788, (uint16) 1, (uint16) 1, (char) 0};

/* CHAIN [G#1] */
static EIF_TYPE_INDEX ptf789[] = {641,0xFFF8,1,0xFFF7,758,0xFFF8,1,906,0xFFF7,707,0xFFF8,1,0xFFFF};
static struct eif_par_types par789 = {789, ptf789, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [INTEGER_32] */
static EIF_TYPE_INDEX ptf790[] = {642,906,0xFFF7,759,906,906,0xFFF7,708,906,0xFFFF};
static struct eif_par_types par790 = {790, ptf790, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [BOOLEAN] */
static EIF_TYPE_INDEX ptf791[] = {643,939,0xFFF7,760,939,906,0xFFF7,709,939,0xFFFF};
static struct eif_par_types par791 = {791, ptf791, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [NATURAL_64] */
static EIF_TYPE_INDEX ptf792[] = {646,915,0xFFF7,762,915,906,0xFFF7,710,915,0xFFFF};
static struct eif_par_types par792 = {792, ptf792, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [NATURAL_32] */
static EIF_TYPE_INDEX ptf793[] = {647,918,0xFFF7,763,918,906,0xFFF7,711,918,0xFFFF};
static struct eif_par_types par793 = {793, ptf793, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [CHARACTER_32] */
static EIF_TYPE_INDEX ptf794[] = {645,933,0xFFF7,761,933,906,0xFFF7,712,933,0xFFFF};
static struct eif_par_types par794 = {794, ptf794, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [CHARACTER_8] */
static EIF_TYPE_INDEX ptf795[] = {644,936,0xFFF7,764,936,906,0xFFF7,713,936,0xFFFF};
static struct eif_par_types par795 = {795, ptf795, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [NATURAL_8] */
static EIF_TYPE_INDEX ptf796[] = {648,924,0xFFF7,765,924,906,0xFFF7,714,924,0xFFFF};
static struct eif_par_types par796 = {796, ptf796, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [NATURAL_16] */
static EIF_TYPE_INDEX ptf797[] = {649,921,0xFFF7,766,921,906,0xFFF7,715,921,0xFFFF};
static struct eif_par_types par797 = {797, ptf797, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [POINTER] */
static EIF_TYPE_INDEX ptf798[] = {650,972,0xFFF7,767,972,906,0xFFF7,716,972,0xFFFF};
static struct eif_par_types par798 = {798, ptf798, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [REAL_32] */
static EIF_TYPE_INDEX ptf799[] = {651,927,0xFFF7,768,927,906,0xFFF7,717,927,0xFFFF};
static struct eif_par_types par799 = {799, ptf799, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [REAL_64] */
static EIF_TYPE_INDEX ptf800[] = {652,930,0xFFF7,769,930,906,0xFFF7,718,930,0xFFFF};
static struct eif_par_types par800 = {800, ptf800, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [G#1] */
static EIF_TYPE_INDEX ptf801[] = {789,0xFFF8,1,0xFFF7,719,0xFFF8,1,0xFFF7,615,0xFFF8,1,906,0xFFFF};
static struct eif_par_types par801 = {801, ptf801, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [INTEGER_32] */
static EIF_TYPE_INDEX ptf802[] = {790,906,0xFFF7,720,906,0xFFF7,617,906,906,0xFFFF};
static struct eif_par_types par802 = {802, ptf802, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [BOOLEAN] */
static EIF_TYPE_INDEX ptf803[] = {791,939,0xFFF7,721,939,0xFFF7,618,939,906,0xFFFF};
static struct eif_par_types par803 = {803, ptf803, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [NATURAL_64] */
static EIF_TYPE_INDEX ptf804[] = {792,915,0xFFF7,722,915,0xFFF7,619,915,906,0xFFFF};
static struct eif_par_types par804 = {804, ptf804, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [NATURAL_32] */
static EIF_TYPE_INDEX ptf805[] = {793,918,0xFFF7,723,918,0xFFF7,620,918,906,0xFFFF};
static struct eif_par_types par805 = {805, ptf805, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [CHARACTER_32] */
static EIF_TYPE_INDEX ptf806[] = {794,933,0xFFF7,724,933,0xFFF7,621,933,906,0xFFFF};
static struct eif_par_types par806 = {806, ptf806, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [CHARACTER_8] */
static EIF_TYPE_INDEX ptf807[] = {795,936,0xFFF7,725,936,0xFFF7,622,936,906,0xFFFF};
static struct eif_par_types par807 = {807, ptf807, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [NATURAL_8] */
static EIF_TYPE_INDEX ptf808[] = {796,924,0xFFF7,726,924,0xFFF7,623,924,906,0xFFFF};
static struct eif_par_types par808 = {808, ptf808, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [NATURAL_16] */
static EIF_TYPE_INDEX ptf809[] = {797,921,0xFFF7,727,921,0xFFF7,624,921,906,0xFFFF};
static struct eif_par_types par809 = {809, ptf809, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [POINTER] */
static EIF_TYPE_INDEX ptf810[] = {798,972,0xFFF7,728,972,0xFFF7,626,972,906,0xFFFF};
static struct eif_par_types par810 = {810, ptf810, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [REAL_32] */
static EIF_TYPE_INDEX ptf811[] = {799,927,0xFFF7,729,927,0xFFF7,627,927,906,0xFFFF};
static struct eif_par_types par811 = {811, ptf811, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [REAL_64] */
static EIF_TYPE_INDEX ptf812[] = {800,930,0xFFF7,730,930,0xFFF7,628,930,906,0xFFFF};
static struct eif_par_types par812 = {812, ptf812, (uint16) 3, (uint16) 1, (char) 0};

/* LIST [G#1] */
static EIF_TYPE_INDEX ptf813[] = {789,0xFFF8,1,0xFFFF};
static struct eif_par_types par813 = {813, ptf813, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf814[] = {790,906,0xFFFF};
static struct eif_par_types par814 = {814, ptf814, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [BOOLEAN] */
static EIF_TYPE_INDEX ptf815[] = {791,939,0xFFFF};
static struct eif_par_types par815 = {815, ptf815, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [NATURAL_64] */
static EIF_TYPE_INDEX ptf816[] = {792,915,0xFFFF};
static struct eif_par_types par816 = {816, ptf816, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [NATURAL_32] */
static EIF_TYPE_INDEX ptf817[] = {793,918,0xFFFF};
static struct eif_par_types par817 = {817, ptf817, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [CHARACTER_32] */
static EIF_TYPE_INDEX ptf818[] = {794,933,0xFFFF};
static struct eif_par_types par818 = {818, ptf818, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [CHARACTER_8] */
static EIF_TYPE_INDEX ptf819[] = {795,936,0xFFFF};
static struct eif_par_types par819 = {819, ptf819, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [NATURAL_8] */
static EIF_TYPE_INDEX ptf820[] = {796,924,0xFFFF};
static struct eif_par_types par820 = {820, ptf820, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [NATURAL_16] */
static EIF_TYPE_INDEX ptf821[] = {797,921,0xFFFF};
static struct eif_par_types par821 = {821, ptf821, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [POINTER] */
static EIF_TYPE_INDEX ptf822[] = {798,972,0xFFFF};
static struct eif_par_types par822 = {822, ptf822, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [REAL_32] */
static EIF_TYPE_INDEX ptf823[] = {799,927,0xFFFF};
static struct eif_par_types par823 = {823, ptf823, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [REAL_64] */
static EIF_TYPE_INDEX ptf824[] = {800,930,0xFFFF};
static struct eif_par_types par824 = {824, ptf824, (uint16) 1, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [G#1] */
static EIF_TYPE_INDEX ptf825[] = {813,0xFFF8,1,0xFFF7,801,0xFFF8,1,0xFFFF};
static struct eif_par_types par825 = {825, ptf825, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf826[] = {814,906,0xFFF7,802,906,0xFFFF};
static struct eif_par_types par826 = {826, ptf826, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [BOOLEAN] */
static EIF_TYPE_INDEX ptf827[] = {815,939,0xFFF7,803,939,0xFFFF};
static struct eif_par_types par827 = {827, ptf827, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [NATURAL_64] */
static EIF_TYPE_INDEX ptf828[] = {816,915,0xFFF7,804,915,0xFFFF};
static struct eif_par_types par828 = {828, ptf828, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [NATURAL_32] */
static EIF_TYPE_INDEX ptf829[] = {817,918,0xFFF7,805,918,0xFFFF};
static struct eif_par_types par829 = {829, ptf829, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [CHARACTER_32] */
static EIF_TYPE_INDEX ptf830[] = {818,933,0xFFF7,806,933,0xFFFF};
static struct eif_par_types par830 = {830, ptf830, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [CHARACTER_8] */
static EIF_TYPE_INDEX ptf831[] = {819,936,0xFFF7,807,936,0xFFFF};
static struct eif_par_types par831 = {831, ptf831, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [NATURAL_8] */
static EIF_TYPE_INDEX ptf832[] = {820,924,0xFFF7,808,924,0xFFFF};
static struct eif_par_types par832 = {832, ptf832, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [NATURAL_16] */
static EIF_TYPE_INDEX ptf833[] = {821,921,0xFFF7,809,921,0xFFFF};
static struct eif_par_types par833 = {833, ptf833, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [POINTER] */
static EIF_TYPE_INDEX ptf834[] = {822,972,0xFFF7,810,972,0xFFFF};
static struct eif_par_types par834 = {834, ptf834, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [REAL_32] */
static EIF_TYPE_INDEX ptf835[] = {823,927,0xFFF7,811,927,0xFFFF};
static struct eif_par_types par835 = {835, ptf835, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [REAL_64] */
static EIF_TYPE_INDEX ptf836[] = {824,930,0xFFF7,812,930,0xFFFF};
static struct eif_par_types par836 = {836, ptf836, (uint16) 2, (uint16) 1, (char) 0};

/* LINKED_LIST [G#1] */
static EIF_TYPE_INDEX ptf837[] = {825,0xFFF8,1,0xFFFF};
static struct eif_par_types par837 = {837, ptf837, (uint16) 1, (uint16) 1, (char) 0};

/* LINKED_LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf838[] = {826,906,0xFFFF};
static struct eif_par_types par838 = {838, ptf838, (uint16) 1, (uint16) 1, (char) 0};

/* EWG_SHARED_STRING_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf839[] = {0,0xFFFF};
static struct eif_par_types par839 = {839, ptf839, (uint16) 1, (uint16) 0, (char) 0};

/* MISMATCH_CORRECTOR */
static EIF_TYPE_INDEX ptf840[] = {0,0xFFFF};
static struct eif_par_types par840 = {840, ptf840, (uint16) 1, (uint16) 0, (char) 0};

/* ARRAYED_QUEUE [G#1] */
static EIF_TYPE_INDEX ptf841[] = {682,0xFFF8,1,0xFFF7,695,0xFFF8,1,0xFFF7,840,0xFFFF};
static struct eif_par_types par841 = {841, ptf841, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAYED_LIST [G#1] */
static EIF_TYPE_INDEX ptf842[] = {289,0xFFF8,1,0xFFF7,695,0xFFF8,1,0xFFF7,825,0xFFF8,1,0xFFF7,840,0xFFFF};
static struct eif_par_types par842 = {842, ptf842, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf843[] = {290,906,0xFFF7,696,906,0xFFF7,826,906,0xFFF7,840,0xFFFF};
static struct eif_par_types par843 = {843, ptf843, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [BOOLEAN] */
static EIF_TYPE_INDEX ptf844[] = {291,939,0xFFF7,697,939,0xFFF7,827,939,0xFFF7,840,0xFFFF};
static struct eif_par_types par844 = {844, ptf844, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [NATURAL_64] */
static EIF_TYPE_INDEX ptf845[] = {292,915,0xFFF7,699,915,0xFFF7,828,915,0xFFF7,840,0xFFFF};
static struct eif_par_types par845 = {845, ptf845, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [NATURAL_32] */
static EIF_TYPE_INDEX ptf846[] = {293,918,0xFFF7,700,918,0xFFF7,829,918,0xFFF7,840,0xFFFF};
static struct eif_par_types par846 = {846, ptf846, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [CHARACTER_32] */
static EIF_TYPE_INDEX ptf847[] = {294,933,0xFFF7,701,933,0xFFF7,830,933,0xFFF7,840,0xFFFF};
static struct eif_par_types par847 = {847, ptf847, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [CHARACTER_8] */
static EIF_TYPE_INDEX ptf848[] = {295,936,0xFFF7,698,936,0xFFF7,831,936,0xFFF7,840,0xFFFF};
static struct eif_par_types par848 = {848, ptf848, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [NATURAL_8] */
static EIF_TYPE_INDEX ptf849[] = {296,924,0xFFF7,702,924,0xFFF7,832,924,0xFFF7,840,0xFFFF};
static struct eif_par_types par849 = {849, ptf849, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [NATURAL_16] */
static EIF_TYPE_INDEX ptf850[] = {297,921,0xFFF7,703,921,0xFFF7,833,921,0xFFF7,840,0xFFFF};
static struct eif_par_types par850 = {850, ptf850, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [POINTER] */
static EIF_TYPE_INDEX ptf851[] = {298,972,0xFFF7,704,972,0xFFF7,834,972,0xFFF7,840,0xFFFF};
static struct eif_par_types par851 = {851, ptf851, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [REAL_32] */
static EIF_TYPE_INDEX ptf852[] = {299,927,0xFFF7,705,927,0xFFF7,835,927,0xFFF7,840,0xFFFF};
static struct eif_par_types par852 = {852, ptf852, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [REAL_64] */
static EIF_TYPE_INDEX ptf853[] = {300,930,0xFFF7,706,930,0xFFF7,836,930,0xFFF7,840,0xFFFF};
static struct eif_par_types par853 = {853, ptf853, (uint16) 4, (uint16) 1, (char) 0};

/* HASH_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf854[] = {719,0xFFF8,1,0xFFF7,614,0xFFF8,1,0xFFF8,2,0xFFF7,428,0xFFF8,1,0xFFF8,2,0xFFF7,734,0xFFF8,1,0xFFF7,840,0xFFFF};
static struct eif_par_types par854 = {854, ptf854, (uint16) 5, (uint16) 2, (char) 0};

/* HASH_TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf855[] = {720,906,0xFFF7,616,906,0xFFF8,2,0xFFF7,429,906,0xFFF8,2,0xFFF7,735,906,0xFFF7,840,0xFFFF};
static struct eif_par_types par855 = {855, ptf855, (uint16) 5, (uint16) 2, (char) 0};

/* HASH_TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf856[] = {719,0xFFF8,1,0xFFF7,615,0xFFF8,1,906,0xFFF7,430,0xFFF8,1,906,0xFFF7,734,0xFFF8,1,0xFFF7,840,0xFFFF};
static struct eif_par_types par856 = {856, ptf856, (uint16) 5, (uint16) 2, (char) 0};

/* HASH_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf857[] = {720,906,0xFFF7,617,906,906,0xFFF7,431,906,906,0xFFF7,735,906,0xFFF7,840,0xFFFF};
static struct eif_par_types par857 = {857, ptf857, (uint16) 5, (uint16) 2, (char) 0};

/* HASH_TABLE [POINTER, G#2] */
static EIF_TYPE_INDEX ptf858[] = {728,972,0xFFF7,625,972,0xFFF8,2,0xFFF7,432,972,0xFFF8,2,0xFFF7,743,972,0xFFF7,840,0xFFFF};
static struct eif_par_types par858 = {858, ptf858, (uint16) 5, (uint16) 2, (char) 0};

/* STRING_TABLE [G#1] */
static EIF_TYPE_INDEX ptf859[] = {854,0xFFF8,1,0xFF01,978,0xFFFF};
static struct eif_par_types par859 = {859, ptf859, (uint16) 1, (uint16) 1, (char) 0};

/* STRING_TABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf860[] = {855,906,0xFF01,978,0xFFFF};
static struct eif_par_types par860 = {860, ptf860, (uint16) 1, (uint16) 1, (char) 0};

/* MISMATCH_INFORMATION */
static EIF_TYPE_INDEX ptf861[] = {854,0,0xFF01,986,0xFFFF};
static struct eif_par_types par861 = {861, ptf861, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_SHARED_C_SYSTEM */
static EIF_TYPE_INDEX ptf862[] = {0,0xFFFF};
static struct eif_par_types par862 = {862, ptf862, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_EIFFEL_TO_C_TYPE_CAST_PRINTER */
static EIF_TYPE_INDEX ptf863[] = {279,0xFFF7,862,0xFFFF};
static struct eif_par_types par863 = {863, ptf863, (uint16) 2, (uint16) 0, (char) 0};

/* KL_IMPORTED_INTEGER_ROUTINES */
static EIF_TYPE_INDEX ptf864[] = {0,0xFFFF};
static struct eif_par_types par864 = {864, ptf864, (uint16) 1, (uint16) 0, (char) 0};

/* HASHABLE */
static EIF_TYPE_INDEX ptf865[] = {0,0xFFFF};
static struct eif_par_types par865 = {865, ptf865, (uint16) 1, (uint16) 0, (char) 0};

/* PATH */
static EIF_TYPE_INDEX ptf866[] = {865,0xFFF7,190,0xFFF7,322,0xFFF7,339,0xFFFF};
static struct eif_par_types par866 = {866, ptf866, (uint16) 4, (uint16) 0, (char) 0};

/* TYPE [G#1] */
static EIF_TYPE_INDEX ptf867[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par867 = {867, ptf867, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [POINTER] */
static EIF_TYPE_INDEX ptf868[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par868 = {868, ptf868, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [ANY]] */
static EIF_TYPE_INDEX ptf869[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par869 = {869, ptf869, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [REAL_64] */
static EIF_TYPE_INDEX ptf870[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par870 = {870, ptf870, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [REAL_32] */
static EIF_TYPE_INDEX ptf871[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par871 = {871, ptf871, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [NATURAL_8] */
static EIF_TYPE_INDEX ptf872[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par872 = {872, ptf872, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [NATURAL_16] */
static EIF_TYPE_INDEX ptf873[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par873 = {873, ptf873, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [NATURAL_32] */
static EIF_TYPE_INDEX ptf874[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par874 = {874, ptf874, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [NATURAL_64] */
static EIF_TYPE_INDEX ptf875[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par875 = {875, ptf875, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [INTEGER_8] */
static EIF_TYPE_INDEX ptf876[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par876 = {876, ptf876, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [INTEGER_16] */
static EIF_TYPE_INDEX ptf877[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par877 = {877, ptf877, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [INTEGER_32] */
static EIF_TYPE_INDEX ptf878[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par878 = {878, ptf878, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [INTEGER_64] */
static EIF_TYPE_INDEX ptf879[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par879 = {879, ptf879, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf880[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par880 = {880, ptf880, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [BOOLEAN] */
static EIF_TYPE_INDEX ptf881[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par881 = {881, ptf881, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf882[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par882 = {882, ptf882, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [UTF_CONVERTER] */
static EIF_TYPE_INDEX ptf883[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par883 = {883, ptf883, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [INTEGER_8]] */
static EIF_TYPE_INDEX ptf884[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par884 = {884, ptf884, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [POINTER]] */
static EIF_TYPE_INDEX ptf885[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par885 = {885, ptf885, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [NATURAL_64]] */
static EIF_TYPE_INDEX ptf886[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par886 = {886, ptf886, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [NATURAL_32]] */
static EIF_TYPE_INDEX ptf887[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par887 = {887, ptf887, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [REAL_32]] */
static EIF_TYPE_INDEX ptf888[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par888 = {888, ptf888, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [REAL_64]] */
static EIF_TYPE_INDEX ptf889[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par889 = {889, ptf889, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [BOOLEAN]] */
static EIF_TYPE_INDEX ptf890[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par890 = {890, ptf890, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [INTEGER_32]] */
static EIF_TYPE_INDEX ptf891[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par891 = {891, ptf891, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [CHARACTER_32]] */
static EIF_TYPE_INDEX ptf892[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par892 = {892, ptf892, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [CHARACTER_8]] */
static EIF_TYPE_INDEX ptf893[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par893 = {893, ptf893, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [NATURAL_8]] */
static EIF_TYPE_INDEX ptf894[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par894 = {894, ptf894, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [NATURAL_16]] */
static EIF_TYPE_INDEX ptf895[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par895 = {895, ptf895, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [INTEGER_64]] */
static EIF_TYPE_INDEX ptf896[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par896 = {896, ptf896, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [INTEGER_16]] */
static EIF_TYPE_INDEX ptf897[] = {865,0xFFF7,189,0xFFF7,339,0xFFFF};
static struct eif_par_types par897 = {897, ptf897, (uint16) 3, (uint16) 1, (char) 0};

/* TUPLE */
static EIF_TYPE_INDEX ptf898[] = {865,0xFFF7,840,0xFFF7,734,0,0xFFFF};
static struct eif_par_types par898 = {898, ptf898, (uint16) 3, (uint16) 0, (char) 0};

/* EWG_C_AST_DECLARATION */
static EIF_TYPE_INDEX ptf899[] = {839,0xFFF7,865,0xFFFF};
static struct eif_par_types par899 = {899, ptf899, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_C_AST_FUNCTION_DECLARATION */
static EIF_TYPE_INDEX ptf900[] = {899,0xFFFF};
static struct eif_par_types par900 = {900, ptf900, (uint16) 1, (uint16) 0, (char) 0};

/* INTEGER_64_REF */
static EIF_TYPE_INDEX ptf901[] = {388,0xFFF7,190,0xFFF7,865,0xFFFF};
static struct eif_par_types par901 = {901, ptf901, (uint16) 3, (uint16) 0, (char) 0};

/* reference INTEGER_64 */
static EIF_TYPE_INDEX ptf902[] = {901,0xFFFF};
static struct eif_par_types par902 = {902, ptf902, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_64 */
static EIF_TYPE_INDEX ptf903[] = {902,0xFFFF};
static struct eif_par_types par903 = {903, ptf903, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_32_REF */
static EIF_TYPE_INDEX ptf904[] = {388,0xFFF7,190,0xFFF7,865,0xFFFF};
static struct eif_par_types par904 = {904, ptf904, (uint16) 3, (uint16) 0, (char) 0};

/* reference INTEGER_32 */
static EIF_TYPE_INDEX ptf905[] = {904,0xFFFF};
static struct eif_par_types par905 = {905, ptf905, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_32 */
static EIF_TYPE_INDEX ptf906[] = {905,0xFFFF};
static struct eif_par_types par906 = {906, ptf906, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_16_REF */
static EIF_TYPE_INDEX ptf907[] = {388,0xFFF7,190,0xFFF7,865,0xFFFF};
static struct eif_par_types par907 = {907, ptf907, (uint16) 3, (uint16) 0, (char) 0};

/* reference INTEGER_16 */
static EIF_TYPE_INDEX ptf908[] = {907,0xFFFF};
static struct eif_par_types par908 = {908, ptf908, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_16 */
static EIF_TYPE_INDEX ptf909[] = {908,0xFFFF};
static struct eif_par_types par909 = {909, ptf909, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_8_REF */
static EIF_TYPE_INDEX ptf910[] = {388,0xFFF7,190,0xFFF7,865,0xFFFF};
static struct eif_par_types par910 = {910, ptf910, (uint16) 3, (uint16) 0, (char) 0};

/* reference INTEGER_8 */
static EIF_TYPE_INDEX ptf911[] = {910,0xFFFF};
static struct eif_par_types par911 = {911, ptf911, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_8 */
static EIF_TYPE_INDEX ptf912[] = {911,0xFFFF};
static struct eif_par_types par912 = {912, ptf912, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_64_REF */
static EIF_TYPE_INDEX ptf913[] = {388,0xFFF7,190,0xFFF7,865,0xFFFF};
static struct eif_par_types par913 = {913, ptf913, (uint16) 3, (uint16) 0, (char) 0};

/* reference NATURAL_64 */
static EIF_TYPE_INDEX ptf914[] = {913,0xFFFF};
static struct eif_par_types par914 = {914, ptf914, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_64 */
static EIF_TYPE_INDEX ptf915[] = {914,0xFFFF};
static struct eif_par_types par915 = {915, ptf915, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_32_REF */
static EIF_TYPE_INDEX ptf916[] = {388,0xFFF7,190,0xFFF7,865,0xFFFF};
static struct eif_par_types par916 = {916, ptf916, (uint16) 3, (uint16) 0, (char) 0};

/* reference NATURAL_32 */
static EIF_TYPE_INDEX ptf917[] = {916,0xFFFF};
static struct eif_par_types par917 = {917, ptf917, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_32 */
static EIF_TYPE_INDEX ptf918[] = {917,0xFFFF};
static struct eif_par_types par918 = {918, ptf918, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_16_REF */
static EIF_TYPE_INDEX ptf919[] = {388,0xFFF7,190,0xFFF7,865,0xFFFF};
static struct eif_par_types par919 = {919, ptf919, (uint16) 3, (uint16) 0, (char) 0};

/* reference NATURAL_16 */
static EIF_TYPE_INDEX ptf920[] = {919,0xFFFF};
static struct eif_par_types par920 = {920, ptf920, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_16 */
static EIF_TYPE_INDEX ptf921[] = {920,0xFFFF};
static struct eif_par_types par921 = {921, ptf921, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_8_REF */
static EIF_TYPE_INDEX ptf922[] = {388,0xFFF7,190,0xFFF7,865,0xFFFF};
static struct eif_par_types par922 = {922, ptf922, (uint16) 3, (uint16) 0, (char) 0};

/* reference NATURAL_8 */
static EIF_TYPE_INDEX ptf923[] = {922,0xFFFF};
static struct eif_par_types par923 = {923, ptf923, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_8 */
static EIF_TYPE_INDEX ptf924[] = {923,0xFFFF};
static struct eif_par_types par924 = {924, ptf924, (uint16) 1, (uint16) 0, (char) 1};

/* REAL_32_REF */
static EIF_TYPE_INDEX ptf925[] = {388,0xFFF7,190,0xFFF7,865,0xFFFF};
static struct eif_par_types par925 = {925, ptf925, (uint16) 3, (uint16) 0, (char) 0};

/* reference REAL_32 */
static EIF_TYPE_INDEX ptf926[] = {925,0xFFFF};
static struct eif_par_types par926 = {926, ptf926, (uint16) 1, (uint16) 0, (char) 1};

/* REAL_32 */
static EIF_TYPE_INDEX ptf927[] = {926,0xFFFF};
static struct eif_par_types par927 = {927, ptf927, (uint16) 1, (uint16) 0, (char) 1};

/* REAL_64_REF */
static EIF_TYPE_INDEX ptf928[] = {388,0xFFF7,190,0xFFF7,865,0xFFFF};
static struct eif_par_types par928 = {928, ptf928, (uint16) 3, (uint16) 0, (char) 0};

/* reference REAL_64 */
static EIF_TYPE_INDEX ptf929[] = {928,0xFFFF};
static struct eif_par_types par929 = {929, ptf929, (uint16) 1, (uint16) 0, (char) 1};

/* REAL_64 */
static EIF_TYPE_INDEX ptf930[] = {929,0xFFFF};
static struct eif_par_types par930 = {930, ptf930, (uint16) 1, (uint16) 0, (char) 1};

/* CHARACTER_32_REF */
static EIF_TYPE_INDEX ptf931[] = {190,0xFFF7,865,0xFFFF};
static struct eif_par_types par931 = {931, ptf931, (uint16) 2, (uint16) 0, (char) 0};

/* reference CHARACTER_32 */
static EIF_TYPE_INDEX ptf932[] = {931,0xFFFF};
static struct eif_par_types par932 = {932, ptf932, (uint16) 1, (uint16) 0, (char) 1};

/* CHARACTER_32 */
static EIF_TYPE_INDEX ptf933[] = {932,0xFFFF};
static struct eif_par_types par933 = {933, ptf933, (uint16) 1, (uint16) 0, (char) 1};

/* CHARACTER_8_REF */
static EIF_TYPE_INDEX ptf934[] = {190,0xFFF7,865,0xFFFF};
static struct eif_par_types par934 = {934, ptf934, (uint16) 2, (uint16) 0, (char) 0};

/* reference CHARACTER_8 */
static EIF_TYPE_INDEX ptf935[] = {934,0xFFFF};
static struct eif_par_types par935 = {935, ptf935, (uint16) 1, (uint16) 0, (char) 1};

/* CHARACTER_8 */
static EIF_TYPE_INDEX ptf936[] = {935,0xFFFF};
static struct eif_par_types par936 = {936, ptf936, (uint16) 1, (uint16) 0, (char) 1};

/* BOOLEAN_REF */
static EIF_TYPE_INDEX ptf937[] = {865,0xFFFF};
static struct eif_par_types par937 = {937, ptf937, (uint16) 1, (uint16) 0, (char) 0};

/* reference BOOLEAN */
static EIF_TYPE_INDEX ptf938[] = {937,0xFFFF};
static struct eif_par_types par938 = {938, ptf938, (uint16) 1, (uint16) 0, (char) 1};

/* BOOLEAN */
static EIF_TYPE_INDEX ptf939[] = {938,0xFFFF};
static struct eif_par_types par939 = {939, ptf939, (uint16) 1, (uint16) 0, (char) 1};

/* POINTER_REF */
static EIF_TYPE_INDEX ptf940[] = {865,0xFFF7,117,0xFFFF};
static struct eif_par_types par940 = {940, ptf940, (uint16) 2, (uint16) 0, (char) 0};

/* reference TYPED_POINTER [G#1] */
static EIF_TYPE_INDEX ptf941[] = {940,0xFFFF};
static struct eif_par_types par941 = {941, ptf941, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [G#1] */
static EIF_TYPE_INDEX ptf942[] = {941,0xFFF8,1,0xFFFF};
static struct eif_par_types par942 = {942, ptf942, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [INTEGER_8] */
static EIF_TYPE_INDEX ptf943[] = {940,0xFFFF};
static struct eif_par_types par943 = {943, ptf943, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [INTEGER_8] */
static EIF_TYPE_INDEX ptf944[] = {943,912,0xFFFF};
static struct eif_par_types par944 = {944, ptf944, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [POINTER] */
static EIF_TYPE_INDEX ptf945[] = {940,0xFFFF};
static struct eif_par_types par945 = {945, ptf945, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [POINTER] */
static EIF_TYPE_INDEX ptf946[] = {945,972,0xFFFF};
static struct eif_par_types par946 = {946, ptf946, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [NATURAL_64] */
static EIF_TYPE_INDEX ptf947[] = {940,0xFFFF};
static struct eif_par_types par947 = {947, ptf947, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [NATURAL_64] */
static EIF_TYPE_INDEX ptf948[] = {947,915,0xFFFF};
static struct eif_par_types par948 = {948, ptf948, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [NATURAL_32] */
static EIF_TYPE_INDEX ptf949[] = {940,0xFFFF};
static struct eif_par_types par949 = {949, ptf949, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [NATURAL_32] */
static EIF_TYPE_INDEX ptf950[] = {949,918,0xFFFF};
static struct eif_par_types par950 = {950, ptf950, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [REAL_32] */
static EIF_TYPE_INDEX ptf951[] = {940,0xFFFF};
static struct eif_par_types par951 = {951, ptf951, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [REAL_32] */
static EIF_TYPE_INDEX ptf952[] = {951,927,0xFFFF};
static struct eif_par_types par952 = {952, ptf952, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [REAL_64] */
static EIF_TYPE_INDEX ptf953[] = {940,0xFFFF};
static struct eif_par_types par953 = {953, ptf953, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [REAL_64] */
static EIF_TYPE_INDEX ptf954[] = {953,930,0xFFFF};
static struct eif_par_types par954 = {954, ptf954, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [BOOLEAN] */
static EIF_TYPE_INDEX ptf955[] = {940,0xFFFF};
static struct eif_par_types par955 = {955, ptf955, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [BOOLEAN] */
static EIF_TYPE_INDEX ptf956[] = {955,939,0xFFFF};
static struct eif_par_types par956 = {956, ptf956, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [INTEGER_32] */
static EIF_TYPE_INDEX ptf957[] = {940,0xFFFF};
static struct eif_par_types par957 = {957, ptf957, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [INTEGER_32] */
static EIF_TYPE_INDEX ptf958[] = {957,906,0xFFFF};
static struct eif_par_types par958 = {958, ptf958, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [CHARACTER_32] */
static EIF_TYPE_INDEX ptf959[] = {940,0xFFFF};
static struct eif_par_types par959 = {959, ptf959, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [CHARACTER_32] */
static EIF_TYPE_INDEX ptf960[] = {959,933,0xFFFF};
static struct eif_par_types par960 = {960, ptf960, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf961[] = {940,0xFFFF};
static struct eif_par_types par961 = {961, ptf961, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf962[] = {961,936,0xFFFF};
static struct eif_par_types par962 = {962, ptf962, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [NATURAL_8] */
static EIF_TYPE_INDEX ptf963[] = {940,0xFFFF};
static struct eif_par_types par963 = {963, ptf963, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [NATURAL_8] */
static EIF_TYPE_INDEX ptf964[] = {963,924,0xFFFF};
static struct eif_par_types par964 = {964, ptf964, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [NATURAL_16] */
static EIF_TYPE_INDEX ptf965[] = {940,0xFFFF};
static struct eif_par_types par965 = {965, ptf965, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [NATURAL_16] */
static EIF_TYPE_INDEX ptf966[] = {965,921,0xFFFF};
static struct eif_par_types par966 = {966, ptf966, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [INTEGER_64] */
static EIF_TYPE_INDEX ptf967[] = {940,0xFFFF};
static struct eif_par_types par967 = {967, ptf967, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [INTEGER_64] */
static EIF_TYPE_INDEX ptf968[] = {967,903,0xFFFF};
static struct eif_par_types par968 = {968, ptf968, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [INTEGER_16] */
static EIF_TYPE_INDEX ptf969[] = {940,0xFFFF};
static struct eif_par_types par969 = {969, ptf969, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [INTEGER_16] */
static EIF_TYPE_INDEX ptf970[] = {969,909,0xFFFF};
static struct eif_par_types par970 = {970, ptf970, (uint16) 1, (uint16) 1, (char) 1};

/* reference POINTER */
static EIF_TYPE_INDEX ptf971[] = {940,0xFFFF};
static struct eif_par_types par971 = {971, ptf971, (uint16) 1, (uint16) 0, (char) 1};

/* POINTER */
static EIF_TYPE_INDEX ptf972[] = {971,0xFFFF};
static struct eif_par_types par972 = {972, ptf972, (uint16) 1, (uint16) 0, (char) 1};

/* ROUTINE [G#1] */
static EIF_TYPE_INDEX ptf973[] = {865,0xFFF7,840,0xFFFF};
static struct eif_par_types par973 = {973, ptf973, (uint16) 2, (uint16) 1, (char) 0};

/* PROCEDURE [G#1] */
static EIF_TYPE_INDEX ptf974[] = {973,0xFFF8,1,0xFFFF};
static struct eif_par_types par974 = {974, ptf974, (uint16) 1, (uint16) 1, (char) 0};

/* FUNCTION [G#1, G#2] */
static EIF_TYPE_INDEX ptf975[] = {973,0xFFF8,1,0xFFFF};
static struct eif_par_types par975 = {975, ptf975, (uint16) 1, (uint16) 2, (char) 0};

/* FUNCTION [G#1, BOOLEAN] */
static EIF_TYPE_INDEX ptf976[] = {973,0xFFF8,1,0xFFFF};
static struct eif_par_types par976 = {976, ptf976, (uint16) 1, (uint16) 2, (char) 0};

/* PREDICATE [G#1] */
static EIF_TYPE_INDEX ptf977[] = {976,0xFFF8,1,939,0xFFFF};
static struct eif_par_types par977 = {977, ptf977, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_STRING_GENERAL */
static EIF_TYPE_INDEX ptf978[] = {190,0xFFF7,865,0xFFF7,333,0xFFFF};
static struct eif_par_types par978 = {978, ptf978, (uint16) 3, (uint16) 0, (char) 0};

/* IMMUTABLE_STRING_GENERAL */
static EIF_TYPE_INDEX ptf979[] = {978,0xFFFF};
static struct eif_par_types par979 = {979, ptf979, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_GENERAL */
static EIF_TYPE_INDEX ptf980[] = {978,0xFFFF};
static struct eif_par_types par980 = {980, ptf980, (uint16) 1, (uint16) 0, (char) 0};

/* READABLE_STRING_32 */
static EIF_TYPE_INDEX ptf981[] = {978,0xFFF7,738,933,0xFFFF};
static struct eif_par_types par981 = {981, ptf981, (uint16) 2, (uint16) 0, (char) 0};

/* IMMUTABLE_STRING_32 */
static EIF_TYPE_INDEX ptf982[] = {981,0xFFF7,979,0xFFF7,840,0xFFFF};
static struct eif_par_types par982 = {982, ptf982, (uint16) 3, (uint16) 0, (char) 0};

/* STRING_32 */
static EIF_TYPE_INDEX ptf983[] = {981,0xFFF7,980,0xFFF7,621,933,906,0xFFF7,761,933,906,0xFFF7,701,933,0xFFF7,294,933,0xFFF7,840,0xFFFF};
static struct eif_par_types par983 = {983, ptf983, (uint16) 7, (uint16) 0, (char) 0};

/* READABLE_STRING_8 */
static EIF_TYPE_INDEX ptf984[] = {978,0xFFF7,737,936,0xFFFF};
static struct eif_par_types par984 = {984, ptf984, (uint16) 2, (uint16) 0, (char) 0};

/* IMMUTABLE_STRING_8 */
static EIF_TYPE_INDEX ptf985[] = {984,0xFFF7,979,0xFFFF};
static struct eif_par_types par985 = {985, ptf985, (uint16) 2, (uint16) 0, (char) 0};

/* STRING_8 */
static EIF_TYPE_INDEX ptf986[] = {984,0xFFF7,980,0xFFF7,622,936,906,0xFFF7,764,936,906,0xFFF7,698,936,0xFFF7,295,936,0xFFF7,840,0xFFFF};
static struct eif_par_types par986 = {986, ptf986, (uint16) 7, (uint16) 0, (char) 0};

/* KL_STRING */
static EIF_TYPE_INDEX ptf987[] = {986,0xFFFF};
static struct eif_par_types par987 = {987, ptf987, (uint16) 1, (uint16) 0, (char) 0};

/* KL_IMPORTED_ANY_ROUTINES */
static EIF_TYPE_INDEX ptf988[] = {0,0xFFFF};
static struct eif_par_types par988 = {988, ptf988, (uint16) 1, (uint16) 0, (char) 0};

/* UC_UTF32_ROUTINES */
static EIF_TYPE_INDEX ptf989[] = {76,0xFFF7,409,0xFFF7,988,0xFFF7,864,0xFFFF};
static struct eif_par_types par989 = {989, ptf989, (uint16) 4, (uint16) 0, (char) 0};

/* UC_UTF16_ROUTINES */
static EIF_TYPE_INDEX ptf990[] = {76,0xFFF7,988,0xFFF7,864,0xFFFF};
static struct eif_par_types par990 = {990, ptf990, (uint16) 3, (uint16) 0, (char) 0};

/* KL_NATURAL_32_ROUTINES */
static EIF_TYPE_INDEX ptf991[] = {988,0xFFFF};
static struct eif_par_types par991 = {991, ptf991, (uint16) 1, (uint16) 0, (char) 0};

/* UC_UTF8_ROUTINES */
static EIF_TYPE_INDEX ptf992[] = {409,0xFFF7,988,0xFFFF};
static struct eif_par_types par992 = {992, ptf992, (uint16) 2, (uint16) 0, (char) 0};

/* KL_ARRAY_ROUTINES [G#1] */
static EIF_TYPE_INDEX ptf993[] = {988,0xFFFF};
static struct eif_par_types par993 = {993, ptf993, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY_ROUTINES [BOOLEAN] */
static EIF_TYPE_INDEX ptf994[] = {988,0xFFFF};
static struct eif_par_types par994 = {994, ptf994, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY_ROUTINES [NATURAL_32] */
static EIF_TYPE_INDEX ptf995[] = {988,0xFFFF};
static struct eif_par_types par995 = {995, ptf995, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY_ROUTINES [NATURAL_64] */
static EIF_TYPE_INDEX ptf996[] = {988,0xFFFF};
static struct eif_par_types par996 = {996, ptf996, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY_ROUTINES [INTEGER_32] */
static EIF_TYPE_INDEX ptf997[] = {988,0xFFFF};
static struct eif_par_types par997 = {997, ptf997, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY_ROUTINES [CHARACTER_8] */
static EIF_TYPE_INDEX ptf998[] = {988,0xFFFF};
static struct eif_par_types par998 = {998, ptf998, (uint16) 1, (uint16) 1, (char) 0};

/* KL_STRING_ROUTINES */
static EIF_TYPE_INDEX ptf999[] = {74,0xFFF7,209,0xFFF7,864,0xFFF7,988,0xFFF7,409,0xFFF7,280,0xFFF7,159,0xFFFF};
static struct eif_par_types par999 = {999, ptf999, (uint16) 7, (uint16) 0, (char) 0};

/* KI_CHARACTER_INPUT_STREAM */
static EIF_TYPE_INDEX ptf1000[] = {169,936,0xFFF7,988,0xFFFF};
static struct eif_par_types par1000 = {1000, ptf1000, (uint16) 2, (uint16) 0, (char) 0};

/* KI_TEXT_INPUT_STREAM */
static EIF_TYPE_INDEX ptf1001[] = {1000,0xFFFF};
static struct eif_par_types par1001 = {1001, ptf1001, (uint16) 1, (uint16) 0, (char) 0};

/* KI_INPUT_FILE */
static EIF_TYPE_INDEX ptf1002[] = {137,0xFFF7,1000,0xFFF7,74,0xFFFF};
static struct eif_par_types par1002 = {1002, ptf1002, (uint16) 3, (uint16) 0, (char) 0};

/* KI_BINARY_INPUT_FILE */
static EIF_TYPE_INDEX ptf1003[] = {1002,0xFFFF};
static struct eif_par_types par1003 = {1003, ptf1003, (uint16) 1, (uint16) 0, (char) 0};

/* KI_TEXT_INPUT_FILE */
static EIF_TYPE_INDEX ptf1004[] = {1002,0xFFF7,1001,0xFFFF};
static struct eif_par_types par1004 = {1004, ptf1004, (uint16) 2, (uint16) 0, (char) 0};

/* UC_UNICODE_FACTORY */
static EIF_TYPE_INDEX ptf1005[] = {310,0xFFF7,280,0xFFF7,409,0xFFF7,988,0xFFFF};
static struct eif_par_types par1005 = {1005, ptf1005, (uint16) 4, (uint16) 0, (char) 0};

/* KL_IMPORTED_STRING_ROUTINES */
static EIF_TYPE_INDEX ptf1006[] = {0,0xFFFF};
static struct eif_par_types par1006 = {1006, ptf1006, (uint16) 1, (uint16) 0, (char) 0};

/* KL_CASE_INSENSITIVE_STRING_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf1007[] = {301,0xFF01,986,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1007 = {1007, ptf1007, (uint16) 2, (uint16) 0, (char) 0};

/* XM_EIFFEL_CHARACTER_ENTITY */
static EIF_TYPE_INDEX ptf1008[] = {864,0xFFF7,1006,0xFFF7,988,0xFFF7,74,0xFFF7,310,0xFFF7,409,0xFFFF};
static struct eif_par_types par1008 = {1008, ptf1008, (uint16) 6, (uint16) 0, (char) 0};

/* KL_STDIN_FILE */
static EIF_TYPE_INDEX ptf1009[] = {1001,0xFFF7,1006,0xFFF7,333,0xFFFF};
static struct eif_par_types par1009 = {1009, ptf1009, (uint16) 3, (uint16) 0, (char) 0};

/* UC_STRING_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf1010[] = {301,0xFF01,986,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1010 = {1010, ptf1010, (uint16) 2, (uint16) 0, (char) 0};

/* ST_COPY_ON_WRITE_STRING */
static EIF_TYPE_INDEX ptf1011[] = {1006,0xFFFF};
static struct eif_par_types par1011 = {1011, ptf1011, (uint16) 1, (uint16) 0, (char) 0};

/* KL_INTEGER_ROUTINES */
static EIF_TYPE_INDEX ptf1012[] = {74,0xFFF7,1006,0xFFF7,988,0xFFFF};
static struct eif_par_types par1012 = {1012, ptf1012, (uint16) 3, (uint16) 0, (char) 0};

/* UC_CHARACTER */
static EIF_TYPE_INDEX ptf1013[] = {191,0xFFF7,865,0xFFF7,74,0xFFF7,409,0xFFF7,864,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1013 = {1013, ptf1013, (uint16) 6, (uint16) 0, (char) 0};

/* EWG_TEMPLATE_EXPANDER */
static EIF_TYPE_INDEX ptf1014[] = {1006,0xFFF7,410,0xFFF7,988,0xFFFF};
static struct eif_par_types par1014 = {1014, ptf1014, (uint16) 3, (uint16) 0, (char) 0};

/* KL_STRING_INPUT_STREAM */
static EIF_TYPE_INDEX ptf1015[] = {1001,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1015 = {1015, ptf1015, (uint16) 2, (uint16) 0, (char) 0};

/* XM_FILE_SOURCE */
static EIF_TYPE_INDEX ptf1016[] = {102,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1016 = {1016, ptf1016, (uint16) 2, (uint16) 0, (char) 0};

/* XM_EIFFEL_INPUT_STREAM */
static EIF_TYPE_INDEX ptf1017[] = {1000,0xFFF7,312,0xFFF7,1006,0xFFF7,988,0xFFF7,310,0xFFF7,280,0xFFFF};
static struct eif_par_types par1017 = {1017, ptf1017, (uint16) 6, (uint16) 0, (char) 0};

/* XM_WHITESPACE_NORMALIZER */
static EIF_TYPE_INDEX ptf1018[] = {214,0xFFF7,408,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1018 = {1018, ptf1018, (uint16) 3, (uint16) 0, (char) 0};

/* XM_CONTENT_CONCATENATOR */
static EIF_TYPE_INDEX ptf1019[] = {214,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1019 = {1019, ptf1019, (uint16) 2, (uint16) 0, (char) 0};

/* XM_XMLNS_GENERATOR */
static EIF_TYPE_INDEX ptf1020[] = {214,0xFFF7,408,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1020 = {1020, ptf1020, (uint16) 3, (uint16) 0, (char) 0};

/* XM_NAMESPACE_RESOLVER */
static EIF_TYPE_INDEX ptf1021[] = {214,0xFFF7,408,0xFFF7,207,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1021 = {1021, ptf1021, (uint16) 4, (uint16) 0, (char) 0};

/* EWG_STRING_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf1022[] = {301,0xFF01,986,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1022 = {1022, ptf1022, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_C_DECLARATOR_PRINTER */
static EIF_TYPE_INDEX ptf1023[] = {276,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1023 = {1023, ptf1023, (uint16) 2, (uint16) 0, (char) 0};

/* XM_EIFFEL_PARSER_NAME */
static EIF_TYPE_INDEX ptf1024[] = {865,0xFFF7,408,0xFFF7,207,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1024 = {1024, ptf1024, (uint16) 4, (uint16) 0, (char) 0};

/* XM_NAMESPACE */
static EIF_TYPE_INDEX ptf1025[] = {865,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1025 = {1025, ptf1025, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_C_PHASE_1_DIRECT_DECLARATOR */
static EIF_TYPE_INDEX ptf1026[] = {281,0xFFF7,160,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1026 = {1026, ptf1026, (uint16) 3, (uint16) 0, (char) 0};

/* EWG_CONFIG_MATCHING_CLAUSE */
static EIF_TYPE_INDEX ptf1027[] = {1006,0xFFF7,222,0xFFFF};
static struct eif_par_types par1027 = {1027, ptf1027, (uint16) 2, (uint16) 0, (char) 0};

/* KL_STRING_VALUES */
static EIF_TYPE_INDEX ptf1028[] = {138,0xFF01,986,0xFF01,986,0xFFF7,1006,0xFFF7,988,0xFFFF};
static struct eif_par_types par1028 = {1028, ptf1028, (uint16) 3, (uint16) 0, (char) 0};

/* KL_EXECUTION_ENVIRONMENT */
static EIF_TYPE_INDEX ptf1029[] = {1028,0xFFFF};
static struct eif_par_types par1029 = {1029, ptf1029, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_COMMAND_LINE_PARSER */
static EIF_TYPE_INDEX ptf1030[] = {186,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1030 = {1030, ptf1030, (uint16) 2, (uint16) 0, (char) 0};

/* KI_CHARACTER_OUTPUT_STREAM */
static EIF_TYPE_INDEX ptf1031[] = {78,936,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1031 = {1031, ptf1031, (uint16) 2, (uint16) 0, (char) 0};

/* KI_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1032[] = {137,0xFFF7,1031,0xFFFF};
static struct eif_par_types par1032 = {1032, ptf1032, (uint16) 2, (uint16) 0, (char) 0};

/* KI_BINARY_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1033[] = {1032,0xFFFF};
static struct eif_par_types par1033 = {1033, ptf1033, (uint16) 1, (uint16) 0, (char) 0};

/* KI_TEXT_OUTPUT_STREAM */
static EIF_TYPE_INDEX ptf1034[] = {1031,0xFFFF};
static struct eif_par_types par1034 = {1034, ptf1034, (uint16) 1, (uint16) 0, (char) 0};

/* KL_STDERR_FILE */
static EIF_TYPE_INDEX ptf1035[] = {1034,0xFFFF};
static struct eif_par_types par1035 = {1035, ptf1035, (uint16) 1, (uint16) 0, (char) 0};

/* KL_STDOUT_FILE */
static EIF_TYPE_INDEX ptf1036[] = {1034,0xFFFF};
static struct eif_par_types par1036 = {1036, ptf1036, (uint16) 1, (uint16) 0, (char) 0};

/* KL_NULL_TEXT_OUTPUT_STREAM */
static EIF_TYPE_INDEX ptf1037[] = {1034,0xFFFF};
static struct eif_par_types par1037 = {1037, ptf1037, (uint16) 1, (uint16) 0, (char) 0};

/* KI_TEXT_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1038[] = {1032,0xFFF7,1034,0xFFFF};
static struct eif_par_types par1038 = {1038, ptf1038, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_C_AST_TYPE */
static EIF_TYPE_INDEX ptf1039[] = {862,0xFFF7,865,0xFFF7,1006,0xFFF7,839,0xFFFF};
static struct eif_par_types par1039 = {1039, ptf1039, (uint16) 4, (uint16) 0, (char) 0};

/* EWG_C_AST_SIMPLE_TYPE */
static EIF_TYPE_INDEX ptf1040[] = {1039,0xFFFF};
static struct eif_par_types par1040 = {1040, ptf1040, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_AST_PRIMITIVE_TYPE */
static EIF_TYPE_INDEX ptf1041[] = {1040,0xFFFF};
static struct eif_par_types par1041 = {1041, ptf1041, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_AST_EIFFEL_OBJECT_TYPE */
static EIF_TYPE_INDEX ptf1042[] = {1040,0xFFFF};
static struct eif_par_types par1042 = {1042, ptf1042, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_AST_BASED_TYPE */
static EIF_TYPE_INDEX ptf1043[] = {1040,0xFFFF};
static struct eif_par_types par1043 = {1043, ptf1043, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_AST_CONST_TYPE */
static EIF_TYPE_INDEX ptf1044[] = {1043,0xFFFF};
static struct eif_par_types par1044 = {1044, ptf1044, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_AST_ARRAY_TYPE */
static EIF_TYPE_INDEX ptf1045[] = {1043,0xFFFF};
static struct eif_par_types par1045 = {1045, ptf1045, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_AST_ALIAS_TYPE */
static EIF_TYPE_INDEX ptf1046[] = {1043,0xFFFF};
static struct eif_par_types par1046 = {1046, ptf1046, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_DECLARATION_PROCESSOR */
static EIF_TYPE_INDEX ptf1047[] = {106,0xFFF7,271,0xFFF7,1006,0xFFF7,862,0xFFF7,281,0xFFFF};
static struct eif_par_types par1047 = {1047, ptf1047, (uint16) 5, (uint16) 0, (char) 0};

/* EWG_C_ISE_EXTERNAL_DECLARATION_PRINTER */
static EIF_TYPE_INDEX ptf1048[] = {1047,0xFFF7,276,0xFFFF};
static struct eif_par_types par1048 = {1048, ptf1048, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_C_ANONYMOUS_DECLARATION_PRINTER */
static EIF_TYPE_INDEX ptf1049[] = {1047,0xFFF7,276,0xFFFF};
static struct eif_par_types par1049 = {1049, ptf1049, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_C_DECLARATION_PRINTER */
static EIF_TYPE_INDEX ptf1050[] = {1047,0xFFF7,276,0xFFFF};
static struct eif_par_types par1050 = {1050, ptf1050, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_C_TO_EIFFEL_DECLARATION_PRINTER */
static EIF_TYPE_INDEX ptf1051[] = {1050,0xFFF7,862,0xFFFF};
static struct eif_par_types par1051 = {1051, ptf1051, (uint16) 2, (uint16) 0, (char) 0};

/* KL_STRING_OUTPUT_STREAM */
static EIF_TYPE_INDEX ptf1052[] = {1034,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1052 = {1052, ptf1052, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_C_AST_POINTER_TYPE */
static EIF_TYPE_INDEX ptf1053[] = {1043,0xFFF7,281,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1053 = {1053, ptf1053, (uint16) 3, (uint16) 0, (char) 0};

/* EWG_C_AST_COMPOSITE_TYPE */
static EIF_TYPE_INDEX ptf1054[] = {1039,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1054 = {1054, ptf1054, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_C_AST_FUNCTION_TYPE */
static EIF_TYPE_INDEX ptf1055[] = {1054,0xFFF7,281,0xFFF7,862,0xFFFF};
static struct eif_par_types par1055 = {1055, ptf1055, (uint16) 3, (uint16) 0, (char) 0};

/* EWG_C_AST_COMPOSITE_DATA_TYPE */
static EIF_TYPE_INDEX ptf1056[] = {1054,0xFFFF};
static struct eif_par_types par1056 = {1056, ptf1056, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_AST_STRUCT_TYPE */
static EIF_TYPE_INDEX ptf1057[] = {1056,0xFFFF};
static struct eif_par_types par1057 = {1057, ptf1057, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_AST_ENUM_TYPE */
static EIF_TYPE_INDEX ptf1058[] = {1056,0xFFFF};
static struct eif_par_types par1058 = {1058, ptf1058, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_AST_UNION_TYPE */
static EIF_TYPE_INDEX ptf1059[] = {1056,0xFFFF};
static struct eif_par_types par1059 = {1059, ptf1059, (uint16) 1, (uint16) 0, (char) 0};

/* UT_INTEGER_FORMATTER */
static EIF_TYPE_INDEX ptf1060[] = {0,0xFFF7,864,0xFFFF};
static struct eif_par_types par1060 = {1060, ptf1060, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_STRUCT_FEATURE_NAMES */
static EIF_TYPE_INDEX ptf1061[] = {839,0xFFF7,0,0xFFFF};
static struct eif_par_types par1061 = {1061, ptf1061, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_ANY_FEATURE_NAMES */
static EIF_TYPE_INDEX ptf1062[] = {839,0xFFF7,0,0xFFFF};
static struct eif_par_types par1062 = {1062, ptf1062, (uint16) 2, (uint16) 0, (char) 0};

/* RX_BYTE_CODE */
static EIF_TYPE_INDEX ptf1063[] = {0,0xFFF7,332,0xFFFF};
static struct eif_par_types par1063 = {1063, ptf1063, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_EIFFEL_COMPILER_NAMES */
static EIF_TYPE_INDEX ptf1064[] = {0,0xFFF7,839,0xFFFF};
static struct eif_par_types par1064 = {1064, ptf1064, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_UNIQUE_NAME_GENERATOR */
static EIF_TYPE_INDEX ptf1065[] = {0,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1065 = {1065, ptf1065, (uint16) 2, (uint16) 0, (char) 0};

/* KL_TYPE [G#1] */
static EIF_TYPE_INDEX ptf1066[] = {0,0xFFF7,988,0xFFFF};
static struct eif_par_types par1066 = {1066, ptf1066, (uint16) 2, (uint16) 1, (char) 0};

/* KL_TYPE [BOOLEAN] */
static EIF_TYPE_INDEX ptf1067[] = {0,0xFFF7,988,0xFFFF};
static struct eif_par_types par1067 = {1067, ptf1067, (uint16) 2, (uint16) 1, (char) 0};

/* KL_TYPE [NATURAL_32] */
static EIF_TYPE_INDEX ptf1068[] = {0,0xFFF7,988,0xFFFF};
static struct eif_par_types par1068 = {1068, ptf1068, (uint16) 2, (uint16) 1, (char) 0};

/* KL_TYPE [NATURAL_64] */
static EIF_TYPE_INDEX ptf1069[] = {0,0xFFF7,988,0xFFFF};
static struct eif_par_types par1069 = {1069, ptf1069, (uint16) 2, (uint16) 1, (char) 0};

/* KL_TYPE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1070[] = {0,0xFFF7,988,0xFFFF};
static struct eif_par_types par1070 = {1070, ptf1070, (uint16) 2, (uint16) 1, (char) 0};

/* KL_TYPE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1071[] = {0,0xFFF7,988,0xFFFF};
static struct eif_par_types par1071 = {1071, ptf1071, (uint16) 2, (uint16) 1, (char) 0};

/* EWG_CONFIG_CONSTRUCT_TYPE_NAMES */
static EIF_TYPE_INDEX ptf1072[] = {0,0xFFF7,839,0xFFFF};
static struct eif_par_types par1072 = {1072, ptf1072, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_C_SYSTEM */
static EIF_TYPE_INDEX ptf1073[] = {0,0xFFF7,839,0xFFFF};
static struct eif_par_types par1073 = {1073, ptf1073, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_C_PHASE_1_TYPE_SPECIFIER */
static EIF_TYPE_INDEX ptf1074[] = {0,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1074 = {1074, ptf1074, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_C_PHASE_1_DECLARATOR */
static EIF_TYPE_INDEX ptf1075[] = {0,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1075 = {1075, ptf1075, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_C_PHASE_1_TYPE_QUALIFIER */
static EIF_TYPE_INDEX ptf1076[] = {0,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1076 = {1076, ptf1076, (uint16) 2, (uint16) 0, (char) 0};

/* XM_TREE_CALLBACKS_PIPE */
static EIF_TYPE_INDEX ptf1077[] = {0,0xFFF7,99,0xFFFF};
static struct eif_par_types par1077 = {1077, ptf1077, (uint16) 2, (uint16) 0, (char) 0};

/* CONSOLE */
static EIF_TYPE_INDEX ptf1078[] = {733,0xFFF7,0,0xFFFF};
static struct eif_par_types par1078 = {1078, ptf1078, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_CONFIG_SYSTEM */
static EIF_TYPE_INDEX ptf1079[] = {1006,0xFFF7,0,0xFFFF};
static struct eif_par_types par1079 = {1079, ptf1079, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_POST_PARSER_PROCESSOR */
static EIF_TYPE_INDEX ptf1080[] = {0,0xFFF7,862,0xFFFF};
static struct eif_par_types par1080 = {1080, ptf1080, (uint16) 2, (uint16) 0, (char) 0};

/* YY_SCANNER */
static EIF_TYPE_INDEX ptf1081[] = {0,0xFFF7,312,0xFFFF};
static struct eif_par_types par1081 = {1081, ptf1081, (uint16) 2, (uint16) 0, (char) 0};

/* YY_SCANNER_SKELETON */
static EIF_TYPE_INDEX ptf1082[] = {1081,0xFFF7,332,0xFFF7,1006,0xFFF7,410,0xFFFF};
static struct eif_par_types par1082 = {1082, ptf1082, (uint16) 4, (uint16) 0, (char) 0};

/* YY_COMPRESSED_SCANNER_SKELETON */
static EIF_TYPE_INDEX ptf1083[] = {1082,0xFFFF};
static struct eif_par_types par1083 = {1083, ptf1083, (uint16) 1, (uint16) 0, (char) 0};

/* UC_V510_CTYPE_TITLECASE */
static EIF_TYPE_INDEX ptf1084[] = {0,0xFFF7,864,0xFFFF};
static struct eif_par_types par1084 = {1084, ptf1084, (uint16) 2, (uint16) 0, (char) 0};

/* UC_V510_CTYPE_UPPERCASE */
static EIF_TYPE_INDEX ptf1085[] = {0,0xFFF7,864,0xFFFF};
static struct eif_par_types par1085 = {1085, ptf1085, (uint16) 2, (uint16) 0, (char) 0};

/* UC_V510_CTYPE_LOWERCASE */
static EIF_TYPE_INDEX ptf1086[] = {0,0xFFF7,864,0xFFFF};
static struct eif_par_types par1086 = {1086, ptf1086, (uint16) 2, (uint16) 0, (char) 0};

/* UC_V510_CTYPE */
static EIF_TYPE_INDEX ptf1087[] = {1086,0xFFF7,1085,0xFFF7,1084,0xFFF7,76,0xFFFF};
static struct eif_par_types par1087 = {1087, ptf1087, (uint16) 4, (uint16) 0, (char) 0};

/* UC_CTYPE */
static EIF_TYPE_INDEX ptf1088[] = {1087,0xFFFF};
static struct eif_par_types par1088 = {1088, ptf1088, (uint16) 1, (uint16) 0, (char) 0};

/* KL_GREGORIAN_CALENDAR */
static EIF_TYPE_INDEX ptf1089[] = {0,0xFFF7,864,0xFFFF};
static struct eif_par_types par1089 = {1089, ptf1089, (uint16) 2, (uint16) 0, (char) 0};

/* DT_GREGORIAN_CALENDAR */
static EIF_TYPE_INDEX ptf1090[] = {1089,0xFFF7,196,0xFFFF};
static struct eif_par_types par1090 = {1090, ptf1090, (uint16) 2, (uint16) 0, (char) 0};

/* DT_WEEK_DAYS_FROM_SUNDAY */
static EIF_TYPE_INDEX ptf1091[] = {1090,0xFFFF};
static struct eif_par_types par1091 = {1091, ptf1091, (uint16) 1, (uint16) 0, (char) 0};

/* DT_WEEK_DAYS_FROM_MONDAY */
static EIF_TYPE_INDEX ptf1092[] = {1090,0xFFFF};
static struct eif_par_types par1092 = {1092, ptf1092, (uint16) 1, (uint16) 0, (char) 0};

/* RX_PCRE_ESCAPE_CONSTANTS */
static EIF_TYPE_INDEX ptf1093[] = {0,0xFFF7,162,0xFFFF};
static struct eif_par_types par1093 = {1093, ptf1093, (uint16) 2, (uint16) 0, (char) 0};

/* XM_STRING_MODE */
static EIF_TYPE_INDEX ptf1094[] = {0,0xFFF7,146,0xFFFF};
static struct eif_par_types par1094 = {1094, ptf1094, (uint16) 2, (uint16) 0, (char) 0};

/* XM_PARSER */
static EIF_TYPE_INDEX ptf1095[] = {1094,0xFFF7,100,0xFFF7,210,0xFFF7,163,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1095 = {1095, ptf1095, (uint16) 5, (uint16) 0, (char) 0};

/* XM_NON_INCREMENTAL_PARSER */
static EIF_TYPE_INDEX ptf1096[] = {1095,0xFFFF};
static struct eif_par_types par1096 = {1096, ptf1096, (uint16) 1, (uint16) 0, (char) 0};

/* DT_WEEK_DAY */
static EIF_TYPE_INDEX ptf1097[] = {0,0xFFF7,988,0xFFFF};
static struct eif_par_types par1097 = {1097, ptf1097, (uint16) 2, (uint16) 0, (char) 0};

/* DT_WEEK_DAY_FROM_MONDAY */
static EIF_TYPE_INDEX ptf1098[] = {1097,0xFFF7,1092,0xFFF7,62,0xFFFF};
static struct eif_par_types par1098 = {1098, ptf1098, (uint16) 3, (uint16) 0, (char) 0};

/* DT_WEEK_DAY_FROM_SUNDAY */
static EIF_TYPE_INDEX ptf1099[] = {1097,0xFFF7,1091,0xFFF7,196,0xFFFF};
static struct eif_par_types par1099 = {1099, ptf1099, (uint16) 3, (uint16) 0, (char) 0};

/* ENCODING_I */
static EIF_TYPE_INDEX ptf1100[] = {0,0xFFFF};
static struct eif_par_types par1100 = {1100, ptf1100, (uint16) 1, (uint16) 0, (char) 0};

/* ENCODING_IMP */
static EIF_TYPE_INDEX ptf1101[] = {1100,0xFFFF};
static struct eif_par_types par1101 = {1101, ptf1101, (uint16) 1, (uint16) 0, (char) 0};

/* UNICODE_CONVERSION */
static EIF_TYPE_INDEX ptf1102[] = {1100,0xFFFF};
static struct eif_par_types par1102 = {1102, ptf1102, (uint16) 1, (uint16) 0, (char) 0};

/* XM_POSITION */
static EIF_TYPE_INDEX ptf1103[] = {0,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1103 = {1103, ptf1103, (uint16) 2, (uint16) 0, (char) 0};

/* XM_STREAM_POSITION */
static EIF_TYPE_INDEX ptf1104[] = {1103,0xFFFF};
static struct eif_par_types par1104 = {1104, ptf1104, (uint16) 1, (uint16) 0, (char) 0};

/* XM_DEFAULT_POSITION */
static EIF_TYPE_INDEX ptf1105[] = {1103,0xFFF7,1104,0xFFFF};
static struct eif_par_types par1105 = {1105, ptf1105, (uint16) 2, (uint16) 0, (char) 0};

/* DS_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1106[] = {0,0xFFF7,988,0xFFFF};
static struct eif_par_types par1106 = {1106, ptf1106, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf1107[] = {0,0xFFF7,988,0xFFFF};
static struct eif_par_types par1107 = {1107, ptf1107, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf1108[] = {0,0xFFF7,988,0xFFFF};
static struct eif_par_types par1108 = {1108, ptf1108, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf1109[] = {0,0xFFF7,988,0xFFFF};
static struct eif_par_types par1109 = {1109, ptf1109, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1110[] = {0,0xFFF7,988,0xFFFF};
static struct eif_par_types par1110 = {1110, ptf1110, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1111[] = {0,0xFFF7,988,0xFFFF};
static struct eif_par_types par1111 = {1111, ptf1111, (uint16) 2, (uint16) 1, (char) 0};

/* DS_INDEXED_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1112[] = {1106,0xFFF8,1,0xFFFF};
static struct eif_par_types par1112 = {1112, ptf1112, (uint16) 1, (uint16) 1, (char) 0};

/* DS_INDEXED_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1113[] = {1110,906,0xFFFF};
static struct eif_par_types par1113 = {1113, ptf1113, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DYNAMIC_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1114[] = {1106,0xFFF8,1,0xFFFF};
static struct eif_par_types par1114 = {1114, ptf1114, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DYNAMIC_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf1115[] = {1107,939,0xFFFF};
static struct eif_par_types par1115 = {1115, ptf1115, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DYNAMIC_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf1116[] = {1108,915,0xFFFF};
static struct eif_par_types par1116 = {1116, ptf1116, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DYNAMIC_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1117[] = {1110,906,0xFFFF};
static struct eif_par_types par1117 = {1117, ptf1117, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1118[] = {1106,0xFFF8,1,0xFFF7,389,0xFFF8,1,0xFFF7,412,0xFFF8,1,0xFFFF};
static struct eif_par_types par1118 = {1118, ptf1118, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf1119[] = {1107,939,0xFFF7,391,939,0xFFF7,414,939,0xFFFF};
static struct eif_par_types par1119 = {1119, ptf1119, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf1120[] = {1109,918,0xFFF7,395,918,0xFFF7,418,918,0xFFFF};
static struct eif_par_types par1120 = {1120, ptf1120, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf1121[] = {1108,915,0xFFF7,394,915,0xFFF7,417,915,0xFFFF};
static struct eif_par_types par1121 = {1121, ptf1121, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1122[] = {1110,906,0xFFF7,390,906,0xFFF7,413,906,0xFFFF};
static struct eif_par_types par1122 = {1122, ptf1122, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1123[] = {1111,936,0xFFF7,392,936,0xFFF7,415,936,0xFFFF};
static struct eif_par_types par1123 = {1123, ptf1123, (uint16) 3, (uint16) 1, (char) 0};

/* DS_SET_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1124[] = {1118,0xFFF8,1,0xFFFF};
static struct eif_par_types par1124 = {1124, ptf1124, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1125[] = {1118,0xFFF8,1,0xFFFF};
static struct eif_par_types par1125 = {1125, ptf1125, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf1126[] = {1119,939,0xFFFF};
static struct eif_par_types par1126 = {1126, ptf1126, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf1127[] = {1120,918,0xFFFF};
static struct eif_par_types par1127 = {1127, ptf1127, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf1128[] = {1121,915,0xFFFF};
static struct eif_par_types par1128 = {1128, ptf1128, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1129[] = {1122,906,0xFFFF};
static struct eif_par_types par1129 = {1129, ptf1129, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SPARSE_TABLE_KEYS_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1130[] = {1125,0xFFF8,2,0xFFFF};
static struct eif_par_types par1130 = {1130, ptf1130, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1131[] = {1125,0xFFF8,2,0xFFFF};
static struct eif_par_types par1131 = {1131, ptf1131, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1132[] = {1127,918,0xFFFF};
static struct eif_par_types par1132 = {1132, ptf1132, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1133[] = {1125,0xFFF8,2,0xFFFF};
static struct eif_par_types par1133 = {1133, ptf1133, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1134[] = {1129,906,0xFFFF};
static struct eif_par_types par1134 = {1134, ptf1134, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1135[] = {1125,0xFFF8,1,0xFFFF};
static struct eif_par_types par1135 = {1135, ptf1135, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1136[] = {1126,939,0xFFFF};
static struct eif_par_types par1136 = {1136, ptf1136, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1137[] = {1128,915,0xFFFF};
static struct eif_par_types par1137 = {1137, ptf1137, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1138[] = {1129,906,0xFFFF};
static struct eif_par_types par1138 = {1138, ptf1138, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1139[] = {1129,906,0xFFFF};
static struct eif_par_types par1139 = {1139, ptf1139, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1140[] = {1125,0xFFF8,1,0xFFF7,840,0xFFFF};
static struct eif_par_types par1140 = {1140, ptf1140, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1141[] = {1126,939,0xFFF7,840,0xFFFF};
static struct eif_par_types par1141 = {1141, ptf1141, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1142[] = {1128,915,0xFFF7,840,0xFFFF};
static struct eif_par_types par1142 = {1142, ptf1142, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1143[] = {1129,906,0xFFF7,840,0xFFFF};
static struct eif_par_types par1143 = {1143, ptf1143, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1144[] = {1129,906,0xFFF7,840,0xFFFF};
static struct eif_par_types par1144 = {1144, ptf1144, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_SET_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1145[] = {1140,0xFFF8,1,0xFFF8,1,0xFFF7,1124,0xFFF8,1,0xFFFF};
static struct eif_par_types par1145 = {1145, ptf1145, (uint16) 2, (uint16) 1, (char) 0};

/* DS_ARRAYED_SPARSE_SET_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1146[] = {1145,0xFFF8,1,0xFFFF};
static struct eif_par_types par1146 = {1146, ptf1146, (uint16) 1, (uint16) 1, (char) 0};

/* DS_HASH_SET_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1147[] = {1146,0xFFF8,1,0xFFFF};
static struct eif_par_types par1147 = {1147, ptf1147, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SPARSE_TABLE_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1148[] = {1140,0xFFF8,1,0xFFF8,2,0xFFF7,1135,0xFFF8,1,0xFFF8,2,0xFFF7,1114,0xFFF8,1,0xFFFF};
static struct eif_par_types par1148 = {1148, ptf1148, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1149[] = {1141,939,0xFFF8,2,0xFFF7,1136,939,0xFFF8,2,0xFFF7,1115,939,0xFFFF};
static struct eif_par_types par1149 = {1149, ptf1149, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1150[] = {1142,915,918,0xFFF7,1137,915,918,0xFFF7,1116,915,0xFFFF};
static struct eif_par_types par1150 = {1150, ptf1150, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1151[] = {1143,906,0xFFF8,2,0xFFF7,1138,906,0xFFF8,2,0xFFF7,1117,906,0xFFFF};
static struct eif_par_types par1151 = {1151, ptf1151, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1152[] = {1144,906,906,0xFFF7,1139,906,906,0xFFF7,1117,906,0xFFFF};
static struct eif_par_types par1152 = {1152, ptf1152, (uint16) 3, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1153[] = {1148,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par1153 = {1153, ptf1153, (uint16) 1, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1154[] = {1149,939,0xFFF8,2,0xFFFF};
static struct eif_par_types par1154 = {1154, ptf1154, (uint16) 1, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1155[] = {1150,915,918,0xFFFF};
static struct eif_par_types par1155 = {1155, ptf1155, (uint16) 1, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1156[] = {1151,906,0xFFF8,2,0xFFFF};
static struct eif_par_types par1156 = {1156, ptf1156, (uint16) 1, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1157[] = {1152,906,906,0xFFFF};
static struct eif_par_types par1157 = {1157, ptf1157, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1158[] = {1153,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par1158 = {1158, ptf1158, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1159[] = {1154,939,0xFFF8,2,0xFFFF};
static struct eif_par_types par1159 = {1159, ptf1159, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1160[] = {1155,915,918,0xFFFF};
static struct eif_par_types par1160 = {1160, ptf1160, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1161[] = {1156,906,0xFFF8,2,0xFFFF};
static struct eif_par_types par1161 = {1161, ptf1161, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1162[] = {1157,906,906,0xFFFF};
static struct eif_par_types par1162 = {1162, ptf1162, (uint16) 1, (uint16) 2, (char) 0};

/* DS_LIST_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1163[] = {1125,0xFFF8,1,0xFFF7,1114,0xFFF8,1,0xFFF7,1112,0xFFF8,1,0xFFFF};
static struct eif_par_types par1163 = {1163, ptf1163, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LIST_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1164[] = {1129,906,0xFFF7,1117,906,0xFFF7,1113,906,0xFFFF};
static struct eif_par_types par1164 = {1164, ptf1164, (uint16) 3, (uint16) 1, (char) 0};

/* DS_ARRAYED_LIST_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1165[] = {1163,0xFFF8,1,0xFFF7,840,0xFFFF};
static struct eif_par_types par1165 = {1165, ptf1165, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LINKED_LIST_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1166[] = {1163,0xFFF8,1,0xFFFF};
static struct eif_par_types par1166 = {1166, ptf1166, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKED_LIST_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1167[] = {1164,906,0xFFFF};
static struct eif_par_types par1167 = {1167, ptf1167, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINKED_LIST_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1168[] = {1166,0xFFF8,1,0xFFFF};
static struct eif_par_types par1168 = {1168, ptf1168, (uint16) 1, (uint16) 1, (char) 0};

/* EWG_ABSTRACT_WRAPPER */
static EIF_TYPE_INDEX ptf1169[] = {1006,0xFFF7,0,0xFFFF};
static struct eif_par_types par1169 = {1169, ptf1169, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_ABSTRACT_DECLARATION_WRAPPER */
static EIF_TYPE_INDEX ptf1170[] = {1169,0xFFFF};
static struct eif_par_types par1170 = {1170, ptf1170, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_COMPOSITE_WRAPPER */
static EIF_TYPE_INDEX ptf1171[] = {1169,0xFFF7,839,0xFFFF};
static struct eif_par_types par1171 = {1171, ptf1171, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_CALLABLE_WRAPPER */
static EIF_TYPE_INDEX ptf1172[] = {1171,0xFFFF};
static struct eif_par_types par1172 = {1172, ptf1172, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_FUNCTION_WRAPPER */
static EIF_TYPE_INDEX ptf1173[] = {1172,0xFFF7,1170,0xFFFF};
static struct eif_par_types par1173 = {1173, ptf1173, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_ABSTRACT_TYPE_WRAPPER */
static EIF_TYPE_INDEX ptf1174[] = {1169,0xFFFF};
static struct eif_par_types par1174 = {1174, ptf1174, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_CALLBACK_WRAPPER */
static EIF_TYPE_INDEX ptf1175[] = {1172,0xFFF7,1174,0xFFFF};
static struct eif_par_types par1175 = {1175, ptf1175, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_ANSI_C_CALLBACK_WRAPPER */
static EIF_TYPE_INDEX ptf1176[] = {1175,0xFFFF};
static struct eif_par_types par1176 = {1176, ptf1176, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_FFCALL_CALLBACK_WRAPPER */
static EIF_TYPE_INDEX ptf1177[] = {1175,0xFFFF};
static struct eif_par_types par1177 = {1177, ptf1177, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_COMPOSITE_DATA_WRAPPER */
static EIF_TYPE_INDEX ptf1178[] = {1171,0xFFF7,1174,0xFFFF};
static struct eif_par_types par1178 = {1178, ptf1178, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_UNION_WRAPPER */
static EIF_TYPE_INDEX ptf1179[] = {1178,0xFFFF};
static struct eif_par_types par1179 = {1179, ptf1179, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_STRUCT_WRAPPER */
static EIF_TYPE_INDEX ptf1180[] = {1178,0xFFFF};
static struct eif_par_types par1180 = {1180, ptf1180, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_ENUM_WRAPPER */
static EIF_TYPE_INDEX ptf1181[] = {1178,0xFFFF};
static struct eif_par_types par1181 = {1181, ptf1181, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_MEMBER_WRAPPER */
static EIF_TYPE_INDEX ptf1182[] = {1169,0xFFFF};
static struct eif_par_types par1182 = {1182, ptf1182, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_UNION_MEMBER_WRAPPER */
static EIF_TYPE_INDEX ptf1183[] = {1182,0xFFFF};
static struct eif_par_types par1183 = {1183, ptf1183, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_STRUCT_MEMBER_WRAPPER */
static EIF_TYPE_INDEX ptf1184[] = {1182,0xFFFF};
static struct eif_par_types par1184 = {1184, ptf1184, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_ZERO_TERMINATED_STRING_MEMBER_WRAPPER */
static EIF_TYPE_INDEX ptf1185[] = {1182,0xFFFF};
static struct eif_par_types par1185 = {1185, ptf1185, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_NATIVE_MEMBER_WRAPPER */
static EIF_TYPE_INDEX ptf1186[] = {1182,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1186 = {1186, ptf1186, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_MACRO_WRAPPER */
static EIF_TYPE_INDEX ptf1187[] = {1182,0xFFFF};
static struct eif_par_types par1187 = {1187, ptf1187, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_CONFIG_WRAPPER_TYPE_NAMES */
static EIF_TYPE_INDEX ptf1188[] = {839,0xFFF7,0,0xFFFF};
static struct eif_par_types par1188 = {1188, ptf1188, (uint16) 2, (uint16) 0, (char) 0};

/* KL_CLONABLE */
static EIF_TYPE_INDEX ptf1189[] = {0,0xFFF7,988,0xFFFF};
static struct eif_par_types par1189 = {1189, ptf1189, (uint16) 2, (uint16) 0, (char) 0};

/* DT_DURATION */
static EIF_TYPE_INDEX ptf1190[] = {63,0xFFF7,865,0xFFF7,1189,0xFFFF};
static struct eif_par_types par1190 = {1190, ptf1190, (uint16) 3, (uint16) 0, (char) 0};

/* DT_ABSOLUTE_TIME */
static EIF_TYPE_INDEX ptf1191[] = {191,0xFFF7,865,0xFFF7,1189,0xFFFF};
static struct eif_par_types par1191 = {1191, ptf1191, (uint16) 3, (uint16) 0, (char) 0};

/* DS_CONTAINER [G#1] */
static EIF_TYPE_INDEX ptf1192[] = {0,0xFFF7,1189,0xFFFF};
static struct eif_par_types par1192 = {1192, ptf1192, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CONTAINER [BOOLEAN] */
static EIF_TYPE_INDEX ptf1193[] = {0,0xFFF7,1189,0xFFFF};
static struct eif_par_types par1193 = {1193, ptf1193, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CONTAINER [NATURAL_64] */
static EIF_TYPE_INDEX ptf1194[] = {0,0xFFF7,1189,0xFFFF};
static struct eif_par_types par1194 = {1194, ptf1194, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CONTAINER [NATURAL_32] */
static EIF_TYPE_INDEX ptf1195[] = {0,0xFFF7,1189,0xFFFF};
static struct eif_par_types par1195 = {1195, ptf1195, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CONTAINER [INTEGER_32] */
static EIF_TYPE_INDEX ptf1196[] = {0,0xFFF7,1189,0xFFFF};
static struct eif_par_types par1196 = {1196, ptf1196, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CONTAINER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1197[] = {0,0xFFF7,1189,0xFFFF};
static struct eif_par_types par1197 = {1197, ptf1197, (uint16) 2, (uint16) 1, (char) 0};

/* DS_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf1198[] = {1192,0xFFF8,1,0xFFF7,138,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par1198 = {1198, ptf1198, (uint16) 2, (uint16) 2, (char) 0};

/* DS_TABLE [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1199[] = {1193,939,0xFFF7,139,939,0xFFF8,2,0xFFFF};
static struct eif_par_types par1199 = {1199, ptf1199, (uint16) 2, (uint16) 2, (char) 0};

/* DS_TABLE [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1200[] = {1194,915,0xFFF7,140,915,918,0xFFFF};
static struct eif_par_types par1200 = {1200, ptf1200, (uint16) 2, (uint16) 2, (char) 0};

/* DS_TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1201[] = {1196,906,0xFFF7,141,906,0xFFF8,2,0xFFFF};
static struct eif_par_types par1201 = {1201, ptf1201, (uint16) 2, (uint16) 2, (char) 0};

/* DS_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1202[] = {1196,906,0xFFF7,142,906,906,0xFFFF};
static struct eif_par_types par1202 = {1202, ptf1202, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SORTABLE [G#1] */
static EIF_TYPE_INDEX ptf1203[] = {1192,0xFFF8,1,0xFFFF};
static struct eif_par_types par1203 = {1203, ptf1203, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SORTABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1204[] = {1196,906,0xFFFF};
static struct eif_par_types par1204 = {1204, ptf1204, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [G#1] */
static EIF_TYPE_INDEX ptf1205[] = {1192,0xFFF8,1,0xFFFF};
static struct eif_par_types par1205 = {1205, ptf1205, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf1206[] = {1193,939,0xFFFF};
static struct eif_par_types par1206 = {1206, ptf1206, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf1207[] = {1194,915,0xFFFF};
static struct eif_par_types par1207 = {1207, ptf1207, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf1208[] = {1195,918,0xFFFF};
static struct eif_par_types par1208 = {1208, ptf1208, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1209[] = {1196,906,0xFFFF};
static struct eif_par_types par1209 = {1209, ptf1209, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1210[] = {1197,936,0xFFFF};
static struct eif_par_types par1210 = {1210, ptf1210, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [G#1] */
static EIF_TYPE_INDEX ptf1211[] = {1192,0xFFF8,1,0xFFFF};
static struct eif_par_types par1211 = {1211, ptf1211, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf1212[] = {1193,939,0xFFFF};
static struct eif_par_types par1212 = {1212, ptf1212, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf1213[] = {1195,918,0xFFFF};
static struct eif_par_types par1213 = {1213, ptf1213, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf1214[] = {1194,915,0xFFFF};
static struct eif_par_types par1214 = {1214, ptf1214, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1215[] = {1196,906,0xFFFF};
static struct eif_par_types par1215 = {1215, ptf1215, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1216[] = {1197,936,0xFFFF};
static struct eif_par_types par1216 = {1216, ptf1216, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINEAR [G#1] */
static EIF_TYPE_INDEX ptf1217[] = {1205,0xFFF8,1,0xFFF7,1211,0xFFF8,1,0xFFF7,412,0xFFF8,1,0xFFFF};
static struct eif_par_types par1217 = {1217, ptf1217, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR [BOOLEAN] */
static EIF_TYPE_INDEX ptf1218[] = {1206,939,0xFFF7,1212,939,0xFFF7,414,939,0xFFFF};
static struct eif_par_types par1218 = {1218, ptf1218, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR [NATURAL_32] */
static EIF_TYPE_INDEX ptf1219[] = {1208,918,0xFFF7,1213,918,0xFFF7,418,918,0xFFFF};
static struct eif_par_types par1219 = {1219, ptf1219, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR [NATURAL_64] */
static EIF_TYPE_INDEX ptf1220[] = {1207,915,0xFFF7,1214,915,0xFFF7,417,915,0xFFFF};
static struct eif_par_types par1220 = {1220, ptf1220, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1221[] = {1209,906,0xFFF7,1215,906,0xFFF7,413,906,0xFFFF};
static struct eif_par_types par1221 = {1221, ptf1221, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1222[] = {1210,936,0xFFF7,1216,936,0xFFF7,415,936,0xFFFF};
static struct eif_par_types par1222 = {1222, ptf1222, (uint16) 3, (uint16) 1, (char) 0};

/* DS_BILINEAR [G#1] */
static EIF_TYPE_INDEX ptf1223[] = {1217,0xFFF8,1,0xFFFF};
static struct eif_par_types par1223 = {1223, ptf1223, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR [BOOLEAN] */
static EIF_TYPE_INDEX ptf1224[] = {1218,939,0xFFFF};
static struct eif_par_types par1224 = {1224, ptf1224, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR [NATURAL_32] */
static EIF_TYPE_INDEX ptf1225[] = {1219,918,0xFFFF};
static struct eif_par_types par1225 = {1225, ptf1225, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR [NATURAL_64] */
static EIF_TYPE_INDEX ptf1226[] = {1220,915,0xFFFF};
static struct eif_par_types par1226 = {1226, ptf1226, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1227[] = {1221,906,0xFFFF};
static struct eif_par_types par1227 = {1227, ptf1227, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SPARSE_TABLE_KEYS [G#1, G#2] */
static EIF_TYPE_INDEX ptf1228[] = {1223,0xFFF8,2,0xFFFF};
static struct eif_par_types par1228 = {1228, ptf1228, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1229[] = {1223,0xFFF8,2,0xFFFF};
static struct eif_par_types par1229 = {1229, ptf1229, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1230[] = {1225,918,0xFFFF};
static struct eif_par_types par1230 = {1230, ptf1230, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1231[] = {1223,0xFFF8,2,0xFFFF};
static struct eif_par_types par1231 = {1231, ptf1231, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1232[] = {1227,906,0xFFFF};
static struct eif_par_types par1232 = {1232, ptf1232, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf1233[] = {1198,0xFFF8,1,0xFFF8,2,0xFFF7,1223,0xFFF8,1,0xFFFF};
static struct eif_par_types par1233 = {1233, ptf1233, (uint16) 2, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1234[] = {1199,939,0xFFF8,2,0xFFF7,1224,939,0xFFFF};
static struct eif_par_types par1234 = {1234, ptf1234, (uint16) 2, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1235[] = {1200,915,918,0xFFF7,1226,915,0xFFFF};
static struct eif_par_types par1235 = {1235, ptf1235, (uint16) 2, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1236[] = {1201,906,0xFFF8,2,0xFFF7,1227,906,0xFFFF};
static struct eif_par_types par1236 = {1236, ptf1236, (uint16) 2, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1237[] = {1202,906,906,0xFFF7,1227,906,0xFFFF};
static struct eif_par_types par1237 = {1237, ptf1237, (uint16) 2, (uint16) 2, (char) 0};

/* DS_EXTENDIBLE [G#1] */
static EIF_TYPE_INDEX ptf1238[] = {1211,0xFFF8,1,0xFFFF};
static struct eif_par_types par1238 = {1238, ptf1238, (uint16) 1, (uint16) 1, (char) 0};

/* DS_EXTENDIBLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf1239[] = {1212,939,0xFFFF};
static struct eif_par_types par1239 = {1239, ptf1239, (uint16) 1, (uint16) 1, (char) 0};

/* DS_EXTENDIBLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1240[] = {1215,906,0xFFFF};
static struct eif_par_types par1240 = {1240, ptf1240, (uint16) 1, (uint16) 1, (char) 0};

/* DS_EXTENDIBLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1241[] = {1216,936,0xFFFF};
static struct eif_par_types par1241 = {1241, ptf1241, (uint16) 1, (uint16) 1, (char) 0};

/* DS_INDEXABLE [G#1] */
static EIF_TYPE_INDEX ptf1242[] = {1203,0xFFF8,1,0xFFF7,1238,0xFFF8,1,0xFFFF};
static struct eif_par_types par1242 = {1242, ptf1242, (uint16) 2, (uint16) 1, (char) 0};

/* DS_INDEXABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1243[] = {1204,906,0xFFF7,1240,906,0xFFFF};
static struct eif_par_types par1243 = {1243, ptf1243, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LIST [G#1] */
static EIF_TYPE_INDEX ptf1244[] = {1223,0xFFF8,1,0xFFF7,1242,0xFFF8,1,0xFFFF};
static struct eif_par_types par1244 = {1244, ptf1244, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf1245[] = {1227,906,0xFFF7,1243,906,0xFFFF};
static struct eif_par_types par1245 = {1245, ptf1245, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LINKED_LIST [G#1] */
static EIF_TYPE_INDEX ptf1246[] = {1244,0xFFF8,1,0xFFF7,988,0xFFFF};
static struct eif_par_types par1246 = {1246, ptf1246, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LINKED_LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf1247[] = {1245,906,0xFFF7,988,0xFFFF};
static struct eif_par_types par1247 = {1247, ptf1247, (uint16) 2, (uint16) 1, (char) 0};

/* XM_LINKED_LIST [G#1] */
static EIF_TYPE_INDEX ptf1248[] = {1246,0xFFF8,1,0xFFFF};
static struct eif_par_types par1248 = {1248, ptf1248, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINKED_LIST [G#1] */
static EIF_TYPE_INDEX ptf1249[] = {1246,0xFFF8,1,0xFFFF};
static struct eif_par_types par1249 = {1249, ptf1249, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SET [G#1] */
static EIF_TYPE_INDEX ptf1250[] = {1217,0xFFF8,1,0xFFF7,1238,0xFFF8,1,0xFFFF};
static struct eif_par_types par1250 = {1250, ptf1250, (uint16) 2, (uint16) 1, (char) 0};

/* DS_DISPENSER [G#1] */
static EIF_TYPE_INDEX ptf1251[] = {1238,0xFFF8,1,0xFFFF};
static struct eif_par_types par1251 = {1251, ptf1251, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DISPENSER [BOOLEAN] */
static EIF_TYPE_INDEX ptf1252[] = {1239,939,0xFFFF};
static struct eif_par_types par1252 = {1252, ptf1252, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DISPENSER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1253[] = {1241,936,0xFFFF};
static struct eif_par_types par1253 = {1253, ptf1253, (uint16) 1, (uint16) 1, (char) 0};

/* DS_QUEUE [G#1] */
static EIF_TYPE_INDEX ptf1254[] = {1251,0xFFF8,1,0xFFFF};
static struct eif_par_types par1254 = {1254, ptf1254, (uint16) 1, (uint16) 1, (char) 0};

/* DS_QUEUE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1255[] = {1253,936,0xFFFF};
static struct eif_par_types par1255 = {1255, ptf1255, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKED_QUEUE [G#1] */
static EIF_TYPE_INDEX ptf1256[] = {1254,0xFFF8,1,0xFFF7,988,0xFFFF};
static struct eif_par_types par1256 = {1256, ptf1256, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LINKED_QUEUE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1257[] = {1255,936,0xFFF7,988,0xFFFF};
static struct eif_par_types par1257 = {1257, ptf1257, (uint16) 2, (uint16) 1, (char) 0};

/* DS_STACK [G#1] */
static EIF_TYPE_INDEX ptf1258[] = {1251,0xFFF8,1,0xFFFF};
static struct eif_par_types par1258 = {1258, ptf1258, (uint16) 1, (uint16) 1, (char) 0};

/* DS_STACK [BOOLEAN] */
static EIF_TYPE_INDEX ptf1259[] = {1252,939,0xFFFF};
static struct eif_par_types par1259 = {1259, ptf1259, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKED_STACK [G#1] */
static EIF_TYPE_INDEX ptf1260[] = {1258,0xFFF8,1,0xFFF7,988,0xFFFF};
static struct eif_par_types par1260 = {1260, ptf1260, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LINKED_STACK [BOOLEAN] */
static EIF_TYPE_INDEX ptf1261[] = {1259,939,0xFFF7,988,0xFFFF};
static struct eif_par_types par1261 = {1261, ptf1261, (uint16) 2, (uint16) 1, (char) 0};

/* DS_RESIZABLE [G#1] */
static EIF_TYPE_INDEX ptf1262[] = {1192,0xFFF8,1,0xFFFF};
static struct eif_par_types par1262 = {1262, ptf1262, (uint16) 1, (uint16) 1, (char) 0};

/* DS_RESIZABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf1263[] = {1193,939,0xFFFF};
static struct eif_par_types par1263 = {1263, ptf1263, (uint16) 1, (uint16) 1, (char) 0};

/* DS_RESIZABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf1264[] = {1194,915,0xFFFF};
static struct eif_par_types par1264 = {1264, ptf1264, (uint16) 1, (uint16) 1, (char) 0};

/* DS_RESIZABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1265[] = {1196,906,0xFFFF};
static struct eif_par_types par1265 = {1265, ptf1265, (uint16) 1, (uint16) 1, (char) 0};

/* DS_ARRAYED_STACK [BOOLEAN] */
static EIF_TYPE_INDEX ptf1266[] = {1259,939,0xFFF7,1263,939,0xFFF7,988,0xFFF7,840,0xFFFF};
static struct eif_par_types par1266 = {1266, ptf1266, (uint16) 4, (uint16) 1, (char) 0};

/* DS_ARRAYED_LIST [G#1] */
static EIF_TYPE_INDEX ptf1267[] = {1244,0xFFF8,1,0xFFF7,1262,0xFFF8,1,0xFFF7,988,0xFFF7,840,0xFFFF};
static struct eif_par_types par1267 = {1267, ptf1267, (uint16) 4, (uint16) 1, (char) 0};

/* DS_SPARSE_CONTAINER [G#1, G#2] */
static EIF_TYPE_INDEX ptf1268[] = {1192,0xFFF8,1,0xFFF7,1223,0xFFF8,1,0xFFF7,1262,0xFFF8,1,0xFFFF};
static struct eif_par_types par1268 = {1268, ptf1268, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1269[] = {1193,939,0xFFF7,1224,939,0xFFF7,1263,939,0xFFFF};
static struct eif_par_types par1269 = {1269, ptf1269, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1270[] = {1194,915,0xFFF7,1226,915,0xFFF7,1264,915,0xFFFF};
static struct eif_par_types par1270 = {1270, ptf1270, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1271[] = {1196,906,0xFFF7,1227,906,0xFFF7,1265,906,0xFFFF};
static struct eif_par_types par1271 = {1271, ptf1271, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1272[] = {1196,906,0xFFF7,1227,906,0xFFF7,1265,906,0xFFFF};
static struct eif_par_types par1272 = {1272, ptf1272, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_SET [G#1] */
static EIF_TYPE_INDEX ptf1273[] = {1250,0xFFF8,1,0xFFF7,1268,0xFFF8,1,0xFFF8,1,0xFFF7,988,0xFFFF};
static struct eif_par_types par1273 = {1273, ptf1273, (uint16) 3, (uint16) 1, (char) 0};

/* DS_ARRAYED_SPARSE_SET [G#1] */
static EIF_TYPE_INDEX ptf1274[] = {1273,0xFFF8,1,0xFFF7,332,0xFFF7,840,0xFFFF};
static struct eif_par_types par1274 = {1274, ptf1274, (uint16) 3, (uint16) 1, (char) 0};

/* DS_HASH_SET [G#1] */
static EIF_TYPE_INDEX ptf1275[] = {1274,0xFFF8,1,0xFFFF};
static struct eif_par_types par1275 = {1275, ptf1275, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SPARSE_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf1276[] = {1233,0xFFF8,1,0xFFF8,2,0xFFF7,1268,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par1276 = {1276, ptf1276, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1277[] = {1234,939,0xFFF8,2,0xFFF7,1269,939,0xFFF8,2,0xFFFF};
static struct eif_par_types par1277 = {1277, ptf1277, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1278[] = {1235,915,918,0xFFF7,1270,915,918,0xFFFF};
static struct eif_par_types par1278 = {1278, ptf1278, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1279[] = {1236,906,0xFFF8,2,0xFFF7,1271,906,0xFFF8,2,0xFFFF};
static struct eif_par_types par1279 = {1279, ptf1279, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1280[] = {1237,906,906,0xFFF7,1272,906,906,0xFFFF};
static struct eif_par_types par1280 = {1280, ptf1280, (uint16) 2, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf1281[] = {1276,0xFFF8,1,0xFFF8,2,0xFFF7,332,0xFFF7,840,0xFFFF};
static struct eif_par_types par1281 = {1281, ptf1281, (uint16) 3, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1282[] = {1277,939,0xFFF8,2,0xFFF7,332,0xFFF7,840,0xFFFF};
static struct eif_par_types par1282 = {1282, ptf1282, (uint16) 3, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1283[] = {1278,915,918,0xFFF7,332,0xFFF7,840,0xFFFF};
static struct eif_par_types par1283 = {1283, ptf1283, (uint16) 3, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1284[] = {1279,906,0xFFF8,2,0xFFF7,332,0xFFF7,840,0xFFFF};
static struct eif_par_types par1284 = {1284, ptf1284, (uint16) 3, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1285[] = {1280,906,906,0xFFF7,332,0xFFF7,840,0xFFFF};
static struct eif_par_types par1285 = {1285, ptf1285, (uint16) 3, (uint16) 2, (char) 0};

/* DS_HASH_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf1286[] = {1281,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par1286 = {1286, ptf1286, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf1287[] = {1282,939,0xFFF8,2,0xFFFF};
static struct eif_par_types par1287 = {1287, ptf1287, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1288[] = {1283,915,918,0xFFFF};
static struct eif_par_types par1288 = {1288, ptf1288, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf1289[] = {1284,906,0xFFF8,2,0xFFFF};
static struct eif_par_types par1289 = {1289, ptf1289, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1290[] = {1285,906,906,0xFFFF};
static struct eif_par_types par1290 = {1290, ptf1290, (uint16) 1, (uint16) 2, (char) 0};

/* KL_SHARED_FILE_SYSTEM */
static EIF_TYPE_INDEX ptf1291[] = {0,0xFFF7,187,0xFFFF};
static struct eif_par_types par1291 = {1291, ptf1291, (uint16) 2, (uint16) 0, (char) 0};

/* KL_DIRECTORY */
static EIF_TYPE_INDEX ptf1292[] = {411,0xFFF7,1291,0xFFF7,1006,0xFFF7,988,0xFFF7,410,0xFFF7,326,0xFFFF};
static struct eif_par_types par1292 = {1292, ptf1292, (uint16) 6, (uint16) 0, (char) 0};

/* EWG_DIRECTORY_STRUCTURE */
static EIF_TYPE_INDEX ptf1293[] = {1291,0xFFF7,220,0xFFFF};
static struct eif_par_types par1293 = {1293, ptf1293, (uint16) 2, (uint16) 0, (char) 0};

/* KL_FILE */
static EIF_TYPE_INDEX ptf1294[] = {137,0xFFF7,1291,0xFFF7,1006,0xFFF7,988,0xFFFF};
static struct eif_par_types par1294 = {1294, ptf1294, (uint16) 4, (uint16) 0, (char) 0};

/* KL_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1295[] = {1032,0xFFF7,1294,0xFFFF};
static struct eif_par_types par1295 = {1295, ptf1295, (uint16) 2, (uint16) 0, (char) 0};

/* KL_TEXT_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1296[] = {1038,0xFFF7,1295,0xFFF7,733,0xFFFF};
static struct eif_par_types par1296 = {1296, ptf1296, (uint16) 3, (uint16) 0, (char) 0};

/* KL_BINARY_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1297[] = {1033,0xFFF7,1295,0xFFF7,732,0xFFFF};
static struct eif_par_types par1297 = {1297, ptf1297, (uint16) 3, (uint16) 0, (char) 0};

/* KL_UNIX_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1298[] = {1038,0xFFF7,1297,0xFFFF};
static struct eif_par_types par1298 = {1298, ptf1298, (uint16) 2, (uint16) 0, (char) 0};

/* KL_WINDOWS_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1299[] = {1038,0xFFF7,1297,0xFFFF};
static struct eif_par_types par1299 = {1299, ptf1299, (uint16) 2, (uint16) 0, (char) 0};

/* KL_INPUT_FILE */
static EIF_TYPE_INDEX ptf1300[] = {1002,0xFFF7,1294,0xFFF7,333,0xFFFF};
static struct eif_par_types par1300 = {1300, ptf1300, (uint16) 3, (uint16) 0, (char) 0};

/* KL_TEXT_INPUT_FILE */
static EIF_TYPE_INDEX ptf1301[] = {1004,0xFFF7,1300,0xFFF7,733,0xFFFF};
static struct eif_par_types par1301 = {1301, ptf1301, (uint16) 3, (uint16) 0, (char) 0};

/* KL_BINARY_INPUT_FILE */
static EIF_TYPE_INDEX ptf1302[] = {1003,0xFFF7,1300,0xFFF7,732,0xFFFF};
static struct eif_par_types par1302 = {1302, ptf1302, (uint16) 3, (uint16) 0, (char) 0};

/* KL_UNIX_INPUT_FILE */
static EIF_TYPE_INDEX ptf1303[] = {1004,0xFFF7,1302,0xFFFF};
static struct eif_par_types par1303 = {1303, ptf1303, (uint16) 2, (uint16) 0, (char) 0};

/* KL_WINDOWS_INPUT_FILE */
static EIF_TYPE_INDEX ptf1304[] = {1004,0xFFF7,1302,0xFFFF};
static struct eif_par_types par1304 = {1304, ptf1304, (uint16) 2, (uint16) 0, (char) 0};

/* MEM_INFO */
static EIF_TYPE_INDEX ptf1305[] = {0,0xFFFF};
static struct eif_par_types par1305 = {1305, ptf1305, (uint16) 1, (uint16) 0, (char) 0};

/* GC_INFO */
static EIF_TYPE_INDEX ptf1306[] = {0,0xFFFF};
static struct eif_par_types par1306 = {1306, ptf1306, (uint16) 1, (uint16) 0, (char) 0};

/* UT_CHARACTER_FORMATTER */
static EIF_TYPE_INDEX ptf1307[] = {0,0xFFF7,205,0xFFF7,864,0xFFFF};
static struct eif_par_types par1307 = {1307, ptf1307, (uint16) 3, (uint16) 0, (char) 0};

/* RX_CASE_MAPPING */
static EIF_TYPE_INDEX ptf1308[] = {0,0xFFF7,332,0xFFF7,864,0xFFFF};
static struct eif_par_types par1308 = {1308, ptf1308, (uint16) 3, (uint16) 0, (char) 0};

/* XM_DTD_EXTERNAL_ID */
static EIF_TYPE_INDEX ptf1309[] = {0,0xFFF7,865,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1309 = {1309, ptf1309, (uint16) 3, (uint16) 0, (char) 0};

/* RT_DBG_EXECUTION_RECORDER */
static EIF_TYPE_INDEX ptf1310[] = {0,0xFFFF};
static struct eif_par_types par1310 = {1310, ptf1310, (uint16) 1, (uint16) 0, (char) 0};

/* KI_FILE_SYSTEM */
static EIF_TYPE_INDEX ptf1311[] = {0,0xFFF7,988,0xFFF7,410,0xFFFF};
static struct eif_par_types par1311 = {1311, ptf1311, (uint16) 3, (uint16) 0, (char) 0};

/* KL_FILE_SYSTEM */
static EIF_TYPE_INDEX ptf1312[] = {1311,0xFFF7,1006,0xFFF7,988,0xFFF7,1291,0xFFFF};
static struct eif_par_types par1312 = {1312, ptf1312, (uint16) 4, (uint16) 0, (char) 0};

/* KL_UNIX_FILE_SYSTEM */
static EIF_TYPE_INDEX ptf1313[] = {1312,0xFFFF};
static struct eif_par_types par1313 = {1313, ptf1313, (uint16) 1, (uint16) 0, (char) 0};

/* KL_WINDOWS_FILE_SYSTEM */
static EIF_TYPE_INDEX ptf1314[] = {1312,0xFFFF};
static struct eif_par_types par1314 = {1314, ptf1314, (uint16) 1, (uint16) 0, (char) 0};

/* KL_WINDOWS_FILE_SYSTEM_BACKSLASH_ONLY */
static EIF_TYPE_INDEX ptf1315[] = {1314,0xFFFF};
static struct eif_par_types par1315 = {1315, ptf1315, (uint16) 1, (uint16) 0, (char) 0};

/* XM_OUTPUT */
static EIF_TYPE_INDEX ptf1316[] = {0,0xFFF7,312,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1316 = {1316, ptf1316, (uint16) 3, (uint16) 0, (char) 0};

/* XM_PRETTY_PRINT_FILTER */
static EIF_TYPE_INDEX ptf1317[] = {214,0xFFF7,1316,0xFFF7,408,0xFFFF};
static struct eif_par_types par1317 = {1317, ptf1317, (uint16) 3, (uint16) 0, (char) 0};

/* XM_INDENT_PRETTY_PRINT_FILTER */
static EIF_TYPE_INDEX ptf1318[] = {1317,0xFFFF};
static struct eif_par_types par1318 = {1318, ptf1318, (uint16) 1, (uint16) 0, (char) 0};

/* XM_CANONICAL_PRETTY_PRINT_FILTER */
static EIF_TYPE_INDEX ptf1319[] = {1317,0xFFFF};
static struct eif_par_types par1319 = {1319, ptf1319, (uint16) 1, (uint16) 0, (char) 0};

/* XM_SHARED_UNICODE_CHARACTERS */
static EIF_TYPE_INDEX ptf1320[] = {0,0xFFF7,408,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1320 = {1320, ptf1320, (uint16) 3, (uint16) 0, (char) 0};

/* XM_UNICODE_VALIDATION_FILTER */
static EIF_TYPE_INDEX ptf1321[] = {214,0xFFF7,1320,0xFFFF};
static struct eif_par_types par1321 = {1321, ptf1321, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_PRINT_ROUTINES */
static EIF_TYPE_INDEX ptf1322[] = {0,0xFFF7,1291,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1322 = {1322, ptf1322, (uint16) 3, (uint16) 0, (char) 0};

/* UT_ERROR_HANDLER */
static EIF_TYPE_INDEX ptf1323[] = {0,0xFFF7,312,0xFFF7,161,0xFFFF};
static struct eif_par_types par1323 = {1323, ptf1323, (uint16) 3, (uint16) 0, (char) 0};

/* RX_PATTERN_MATCHER */
static EIF_TYPE_INDEX ptf1324[] = {0,0xFFF7,1006,0xFFF7,988,0xFFFF};
static struct eif_par_types par1324 = {1324, ptf1324, (uint16) 3, (uint16) 0, (char) 0};

/* RX_REGULAR_EXPRESSION */
static EIF_TYPE_INDEX ptf1325[] = {1324,0xFFF7,162,0xFFF7,410,0xFFFF};
static struct eif_par_types par1325 = {1325, ptf1325, (uint16) 3, (uint16) 0, (char) 0};

/* XM_NODE */
static EIF_TYPE_INDEX ptf1326[] = {0,0xFFF7,1189,0xFFF7,207,0xFFFF};
static struct eif_par_types par1326 = {1326, ptf1326, (uint16) 3, (uint16) 0, (char) 0};

/* XM_COMPOSITE_NODE */
static EIF_TYPE_INDEX ptf1327[] = {1326,0xFFFF};
static struct eif_par_types par1327 = {1327, ptf1327, (uint16) 1, (uint16) 0, (char) 0};

/* XM_DOCUMENT_NODE */
static EIF_TYPE_INDEX ptf1328[] = {1327,0xFFFF};
static struct eif_par_types par1328 = {1328, ptf1328, (uint16) 1, (uint16) 0, (char) 0};

/* XM_ELEMENT_NODE */
static EIF_TYPE_INDEX ptf1329[] = {1327,0xFFFF};
static struct eif_par_types par1329 = {1329, ptf1329, (uint16) 1, (uint16) 0, (char) 0};

/* XM_PROCESSING_INSTRUCTION */
static EIF_TYPE_INDEX ptf1330[] = {1328,0xFFF7,1329,0xFFFF};
static struct eif_par_types par1330 = {1330, ptf1330, (uint16) 2, (uint16) 0, (char) 0};

/* XM_COMMENT */
static EIF_TYPE_INDEX ptf1331[] = {1328,0xFFF7,1329,0xFFFF};
static struct eif_par_types par1331 = {1331, ptf1331, (uint16) 2, (uint16) 0, (char) 0};

/* XM_CHARACTER_DATA */
static EIF_TYPE_INDEX ptf1332[] = {1329,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1332 = {1332, ptf1332, (uint16) 2, (uint16) 0, (char) 0};

/* XM_NAMED_NODE */
static EIF_TYPE_INDEX ptf1333[] = {1329,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1333 = {1333, ptf1333, (uint16) 2, (uint16) 0, (char) 0};

/* XM_ATTRIBUTE */
static EIF_TYPE_INDEX ptf1334[] = {1333,0xFFF7,408,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1334 = {1334, ptf1334, (uint16) 3, (uint16) 0, (char) 0};

/* XM_COMPOSITE */
static EIF_TYPE_INDEX ptf1335[] = {1326,0xFFF7,412,0xFF01,1327,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1335 = {1335, ptf1335, (uint16) 3, (uint16) 0, (char) 0};

/* XM_ELEMENT */
static EIF_TYPE_INDEX ptf1336[] = {1335,0xFFF7,1333,0xFFF7,1328,0xFFFF};
static struct eif_par_types par1336 = {1336, ptf1336, (uint16) 3, (uint16) 0, (char) 0};

/* XM_DOCUMENT */
static EIF_TYPE_INDEX ptf1337[] = {1335,0xFFFF};
static struct eif_par_types par1337 = {1337, ptf1337, (uint16) 1, (uint16) 0, (char) 0};

/* DT_DATE_VALUE */
static EIF_TYPE_INDEX ptf1338[] = {0,0xFFF7,1006,0xFFF7,864,0xFFFF};
static struct eif_par_types par1338 = {1338, ptf1338, (uint16) 3, (uint16) 0, (char) 0};

/* DT_DATE_DURATION */
static EIF_TYPE_INDEX ptf1339[] = {1190,0xFFF7,1338,0xFFF7,1090,0xFFF7,988,0xFFFF};
static struct eif_par_types par1339 = {1339, ptf1339, (uint16) 4, (uint16) 0, (char) 0};

/* DT_DATE */
static EIF_TYPE_INDEX ptf1340[] = {1191,0xFFF7,1338,0xFFF7,1090,0xFFF7,196,0xFFF7,195,0xFFFF};
static struct eif_par_types par1340 = {1340, ptf1340, (uint16) 5, (uint16) 0, (char) 0};

/* DT_TIME_VALUE */
static EIF_TYPE_INDEX ptf1341[] = {0,0xFFF7,1006,0xFFF7,864,0xFFFF};
static struct eif_par_types par1341 = {1341, ptf1341, (uint16) 3, (uint16) 0, (char) 0};

/* DT_TIME_DURATION */
static EIF_TYPE_INDEX ptf1342[] = {1190,0xFFF7,1341,0xFFF7,1090,0xFFF7,988,0xFFFF};
static struct eif_par_types par1342 = {1342, ptf1342, (uint16) 4, (uint16) 0, (char) 0};

/* DT_TIME */
static EIF_TYPE_INDEX ptf1343[] = {1191,0xFFF7,1341,0xFFF7,1090,0xFFF7,197,0xFFFF};
static struct eif_par_types par1343 = {1343, ptf1343, (uint16) 4, (uint16) 0, (char) 0};

/* DT_DATE_TIME_VALUE */
static EIF_TYPE_INDEX ptf1344[] = {1338,0xFFF7,1341,0xFFFF};
static struct eif_par_types par1344 = {1344, ptf1344, (uint16) 2, (uint16) 0, (char) 0};

/* DT_DATE_TIME_DURATION */
static EIF_TYPE_INDEX ptf1345[] = {1339,0xFFF7,1342,0xFFF7,1344,0xFFFF};
static struct eif_par_types par1345 = {1345, ptf1345, (uint16) 3, (uint16) 0, (char) 0};

/* DT_DATE_TIME */
static EIF_TYPE_INDEX ptf1346[] = {1340,0xFFF7,1343,0xFFF7,1344,0xFFF7,198,0xFFFF};
static struct eif_par_types par1346 = {1346, ptf1346, (uint16) 4, (uint16) 0, (char) 0};

/* XM_XMLNS_GENERATOR_CONTEXT */
static EIF_TYPE_INDEX ptf1347[] = {0,0xFFF7,1006,0xFFF7,408,0xFFF7,206,0xFFFF};
static struct eif_par_types par1347 = {1347, ptf1347, (uint16) 4, (uint16) 0, (char) 0};

/* XM_NAMESPACE_RESOLVER_CONTEXT */
static EIF_TYPE_INDEX ptf1348[] = {0,0xFFF7,1005,0xFFF7,207,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1348 = {1348, ptf1348, (uint16) 4, (uint16) 0, (char) 0};

/* EWG_C_AST_TYPE_SET */
static EIF_TYPE_INDEX ptf1349[] = {0,0xFFF7,1006,0xFFF7,172,0xFFF7,839,0xFFFF};
static struct eif_par_types par1349 = {1349, ptf1349, (uint16) 4, (uint16) 0, (char) 0};

/* UC_UNICODE_ROUTINES */
static EIF_TYPE_INDEX ptf1350[] = {0,0xFFF7,1088,0xFFF7,864,0xFFF7,74,0xFFFF};
static struct eif_par_types par1350 = {1350, ptf1350, (uint16) 4, (uint16) 0, (char) 0};

/* XM_DTD_ATTRIBUTE_CONTENT */
static EIF_TYPE_INDEX ptf1351[] = {0,0xFFF7,1005,0xFFF7,1006,0xFFF7,146,0xFFFF};
static struct eif_par_types par1351 = {1351, ptf1351, (uint16) 4, (uint16) 0, (char) 0};

/* DT_CLOCK */
static EIF_TYPE_INDEX ptf1352[] = {0,0xFFF7,195,0xFFF7,197,0xFFF7,198,0xFFFF};
static struct eif_par_types par1352 = {1352, ptf1352, (uint16) 4, (uint16) 0, (char) 0};

/* DT_UTC_SYSTEM_CLOCK */
static EIF_TYPE_INDEX ptf1353[] = {1352,0xFFF7,1090,0xFFF7,69,0xFFFF};
static struct eif_par_types par1353 = {1353, ptf1353, (uint16) 3, (uint16) 0, (char) 0};

/* DT_SYSTEM_CLOCK */
static EIF_TYPE_INDEX ptf1354[] = {1352,0xFFF7,1090,0xFFF7,69,0xFFFF};
static struct eif_par_types par1354 = {1354, ptf1354, (uint16) 3, (uint16) 0, (char) 0};

/* YY_PARSER_TOKENS */
static EIF_TYPE_INDEX ptf1355[] = {0,0xFFF7,74,0xFFF7,864,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1355 = {1355, ptf1355, (uint16) 4, (uint16) 0, (char) 0};

/* EWG_C_TOKENS */
static EIF_TYPE_INDEX ptf1356[] = {1355,0xFFFF};
static struct eif_par_types par1356 = {1356, ptf1356, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_C_SCANNER_SKELETON */
static EIF_TYPE_INDEX ptf1357[] = {1356,0xFFF7,1083,0xFFF7,67,0xFFF7,1291,0xFFFF};
static struct eif_par_types par1357 = {1357, ptf1357, (uint16) 4, (uint16) 0, (char) 0};

/* EWG_C_SCANNER */
static EIF_TYPE_INDEX ptf1358[] = {1357,0xFFFF};
static struct eif_par_types par1358 = {1358, ptf1358, (uint16) 1, (uint16) 0, (char) 0};

/* XM_EIFFEL_TOKENS */
static EIF_TYPE_INDEX ptf1359[] = {1355,0xFFFF};
static struct eif_par_types par1359 = {1359, ptf1359, (uint16) 1, (uint16) 0, (char) 0};

/* XM_EIFFEL_SCANNER_SKELETON */
static EIF_TYPE_INDEX ptf1360[] = {1083,0xFFF7,1359,0xFFF7,143,0xFFFF};
static struct eif_par_types par1360 = {1360, ptf1360, (uint16) 3, (uint16) 0, (char) 0};

/* XM_EIFFEL_SCANNER */
static EIF_TYPE_INDEX ptf1361[] = {1360,0xFFFF};
static struct eif_par_types par1361 = {1361, ptf1361, (uint16) 1, (uint16) 0, (char) 0};

/* XM_EIFFEL_SCANNER_DTD */
static EIF_TYPE_INDEX ptf1362[] = {1361,0xFFFF};
static struct eif_par_types par1362 = {1362, ptf1362, (uint16) 1, (uint16) 0, (char) 0};

/* XM_EIFFEL_ENTITY_DEF */
static EIF_TYPE_INDEX ptf1363[] = {865,0xFFF7,1361,0xFFF7,310,0xFFFF};
static struct eif_par_types par1363 = {1363, ptf1363, (uint16) 3, (uint16) 0, (char) 0};

/* XM_EIFFEL_PE_ENTITY_DEF */
static EIF_TYPE_INDEX ptf1364[] = {1363,0xFFFF};
static struct eif_par_types par1364 = {1364, ptf1364, (uint16) 1, (uint16) 0, (char) 0};

/* YY_PARSER_SKELETON */
static EIF_TYPE_INDEX ptf1365[] = {70,0xFFF7,1355,0xFFF7,312,0xFFF7,332,0xFFF7,410,0xFFFF};
static struct eif_par_types par1365 = {1365, ptf1365, (uint16) 5, (uint16) 0, (char) 0};

/* EWG_PARSER_SKELETON */
static EIF_TYPE_INDEX ptf1366[] = {1365,0xFFF7,862,0xFFFF};
static struct eif_par_types par1366 = {1366, ptf1366, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_C_PARSER_SKELETON */
static EIF_TYPE_INDEX ptf1367[] = {1366,0xFFF7,1358,0xFFF7,160,0xFFF7,188,0xFFF7,1006,0xFFF7,839,0xFFFF};
static struct eif_par_types par1367 = {1367, ptf1367, (uint16) 6, (uint16) 0, (char) 0};

/* EWG_C_PARSER */
static EIF_TYPE_INDEX ptf1368[] = {1367,0xFFF7,112,0xFFFF};
static struct eif_par_types par1368 = {1368, ptf1368, (uint16) 2, (uint16) 0, (char) 0};

/* XM_EIFFEL_PARSER_SKELETON */
static EIF_TYPE_INDEX ptf1369[] = {1096,0xFFF7,213,0xFFF7,164,0xFFF7,1365,0xFFF7,1359,0xFFF7,143,0xFFF7,1005,0xFFF7,310,0xFFF7,409,0xFFF7,208,0xFFF7,864,0xFFF7,988,0xFFFF};
static struct eif_par_types par1369 = {1369, ptf1369, (uint16) 12, (uint16) 0, (char) 0};

/* XM_EIFFEL_PARSER */
static EIF_TYPE_INDEX ptf1370[] = {1369,0xFFFF};
static struct eif_par_types par1370 = {1370, ptf1370, (uint16) 1, (uint16) 0, (char) 0};

/* UT_STRING_FORMATTER */
static EIF_TYPE_INDEX ptf1371[] = {0,0xFFF7,1006,0xFFF7,864,0xFFF7,988,0xFFF7,205,0xFFFF};
static struct eif_par_types par1371 = {1371, ptf1371, (uint16) 5, (uint16) 0, (char) 0};

/* XM_DTD_ELEMENT_CONTENT */
static EIF_TYPE_INDEX ptf1372[] = {0,0xFFF7,74,0xFFF7,1005,0xFFF7,207,0xFFF7,1006,0xFFFF};
static struct eif_par_types par1372 = {1372, ptf1372, (uint16) 5, (uint16) 0, (char) 0};

/* EWG_CONFIG_VALIDATOR */
static EIF_TYPE_INDEX ptf1373[] = {313,0xFFF7,98,0xFFF7,222,0xFFF7,1006,0xFFF7,0,0xFFFF};
static struct eif_par_types par1373 = {1373, ptf1373, (uint16) 5, (uint16) 0, (char) 0};

/* EWG_ERROR_HANDLER */
static EIF_TYPE_INDEX ptf1374[] = {0,0xFFF7,1323,0xFFF7,1006,0xFFF7,114,0xFFF7,113,0xFFFF};
static struct eif_par_types par1374 = {1374, ptf1374, (uint16) 5, (uint16) 0, (char) 0};

/* UT_ERROR */
static EIF_TYPE_INDEX ptf1375[] = {0,0xFFF7,186,0xFFF7,1006,0xFFF7,410,0xFFF7,988,0xFFFF};
static struct eif_par_types par1375 = {1375, ptf1375, (uint16) 5, (uint16) 0, (char) 0};

/* UT_SYNTAX_ERROR */
static EIF_TYPE_INDEX ptf1376[] = {1375,0xFFFF};
static struct eif_par_types par1376 = {1376, ptf1376, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_MISSING_COMMAND_LINE_PARAMETER_VALUE_ERROR */
static EIF_TYPE_INDEX ptf1377[] = {1375,0xFFFF};
static struct eif_par_types par1377 = {1377, ptf1377, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_MISSING_COMMAND_LINE_PARAMETER_ERROR */
static EIF_TYPE_INDEX ptf1378[] = {1375,0xFFFF};
static struct eif_par_types par1378 = {1378, ptf1378, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_ILLEGAL_REGULAR_EXPRESSION_IN_ATTRIBUTE_ERROR */
static EIF_TYPE_INDEX ptf1379[] = {1375,0xFFFF};
static struct eif_par_types par1379 = {1379, ptf1379, (uint16) 1, (uint16) 0, (char) 0};

/* UT_USAGE_MESSAGE */
static EIF_TYPE_INDEX ptf1380[] = {1375,0xFFFF};
static struct eif_par_types par1380 = {1380, ptf1380, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_INVALID_CLASS_NAME_ERROR */
static EIF_TYPE_INDEX ptf1381[] = {1375,0xFFF7,313,0xFFF7,1188,0xFFFF};
static struct eif_par_types par1381 = {1381, ptf1381, (uint16) 3, (uint16) 0, (char) 0};

/* EWG_QUITING_BECAUSE_CONFIG_FILE_HAD_ERRORS_ERROR */
static EIF_TYPE_INDEX ptf1382[] = {1375,0xFFFF};
static struct eif_par_types par1382 = {1382, ptf1382, (uint16) 1, (uint16) 0, (char) 0};

/* UT_MESSAGE */
static EIF_TYPE_INDEX ptf1383[] = {1375,0xFFFF};
static struct eif_par_types par1383 = {1383, ptf1383, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_UNKNOWN_CONSTRUCT_TYPE_ERROR */
static EIF_TYPE_INDEX ptf1384[] = {1375,0xFFF7,313,0xFFF7,1188,0xFFFF};
static struct eif_par_types par1384 = {1384, ptf1384, (uint16) 3, (uint16) 0, (char) 0};

/* EWG_UNKNOWN_WRAPPER_TYPE_ERROR */
static EIF_TYPE_INDEX ptf1385[] = {1375,0xFFF7,313,0xFFF7,1188,0xFFFF};
static struct eif_par_types par1385 = {1385, ptf1385, (uint16) 3, (uint16) 0, (char) 0};

/* UT_CANNOT_WRITE_TO_FILE_ERROR */
static EIF_TYPE_INDEX ptf1386[] = {1375,0xFFFF};
static struct eif_par_types par1386 = {1386, ptf1386, (uint16) 1, (uint16) 0, (char) 0};

/* UT_CANNOT_READ_FILE_ERROR */
static EIF_TYPE_INDEX ptf1387[] = {1375,0xFFFF};
static struct eif_par_types par1387 = {1387, ptf1387, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_UNEXPECTED_ELEMENT_ERROR */
static EIF_TYPE_INDEX ptf1388[] = {1375,0xFFF7,313,0xFFFF};
static struct eif_par_types par1388 = {1388, ptf1388, (uint16) 2, (uint16) 0, (char) 0};

/* ET_XACE_ERROR */
static EIF_TYPE_INDEX ptf1389[] = {1375,0xFFFF};
static struct eif_par_types par1389 = {1389, ptf1389, (uint16) 1, (uint16) 0, (char) 0};

/* ET_XACE_MISSING_ELEMENT_ERROR */
static EIF_TYPE_INDEX ptf1390[] = {1389,0xFFFF};
static struct eif_par_types par1390 = {1390, ptf1390, (uint16) 1, (uint16) 0, (char) 0};

/* ET_XACE_MISSING_ATTRIBUTE_ERROR */
static EIF_TYPE_INDEX ptf1391[] = {1389,0xFFFF};
static struct eif_par_types par1391 = {1391, ptf1391, (uint16) 1, (uint16) 0, (char) 0};

/* ET_XACE_WRONG_ROOT_ELEMENT_ERROR */
static EIF_TYPE_INDEX ptf1392[] = {1389,0xFFFF};
static struct eif_par_types par1392 = {1392, ptf1392, (uint16) 1, (uint16) 0, (char) 0};

/* ET_XACE_UNKNOWN_ELEMENT_ERROR */
static EIF_TYPE_INDEX ptf1393[] = {1389,0xFFFF};
static struct eif_par_types par1393 = {1393, ptf1393, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_CONFIG_PARSER */
static EIF_TYPE_INDEX ptf1394[] = {313,0xFFF7,1188,0xFFF7,115,0xFFF7,1006,0xFFF7,222,0xFFF7,0,0xFFFF};
static struct eif_par_types par1394 = {1394, ptf1394, (uint16) 6, (uint16) 0, (char) 0};

/* EWG_KERNEL */
static EIF_TYPE_INDEX ptf1395[] = {0,0xFFF7,188,0xFFF7,862,0xFFF7,1006,0xFFF7,187,0xFFF7,118,0xFFFF};
static struct eif_par_types par1395 = {1395, ptf1395, (uint16) 6, (uint16) 0, (char) 0};

/* EWG */
static EIF_TYPE_INDEX ptf1396[] = {1395,0xFFF7,1030,0xFFFF};
static struct eif_par_types par1396 = {1396, ptf1396, (uint16) 2, (uint16) 0, (char) 0};

/* KI_PATHNAME */
static EIF_TYPE_INDEX ptf1397[] = {0,0xFFF7,1189,0xFFF7,1006,0xFFF7,988,0xFFF7,410,0xFFF7,65,0xFFF7,206,0xFFFF};
static struct eif_par_types par1397 = {1397, ptf1397, (uint16) 7, (uint16) 0, (char) 0};

/* KL_PATHNAME */
static EIF_TYPE_INDEX ptf1398[] = {1397,0xFFF7,410,0xFFFF};
static struct eif_par_types par1398 = {1398, ptf1398, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_RENAMER */
static EIF_TYPE_INDEX ptf1399[] = {0,0xFFF7,75,0xFFF7,1322,0xFFF7,1291,0xFFF7,1006,0xFFF7,209,0xFFF7,839,0xFFF7,94,0xFFF7,93,0xFFFF};
static struct eif_par_types par1399 = {1399, ptf1399, (uint16) 9, (uint16) 0, (char) 0};

/* EWG_C_DECLARATION_LIST_PRINTER */
static EIF_TYPE_INDEX ptf1400[] = {271,0xFFF7,1006,0xFFF7,1399,0xFFFF};
static struct eif_par_types par1400 = {1400, ptf1400, (uint16) 3, (uint16) 0, (char) 0};

/* EWG_C_GLUE_HEADER_ANSI_C_CALLBACK_WRAPPER_GENERATOR */
static EIF_TYPE_INDEX ptf1401[] = {273,0xFFF7,862,0xFFF7,1399,0xFFF7,311,0xFFFF};
static struct eif_par_types par1401 = {1401, ptf1401, (uint16) 4, (uint16) 0, (char) 0};

/* EWG_C_GLUE_CODE_ANSI_C_CALLBACK_WRAPPER_GENERATOR */
static EIF_TYPE_INDEX ptf1402[] = {273,0xFFF7,862,0xFFF7,1399,0xFFF7,311,0xFFF7,281,0xFFFF};
static struct eif_par_types par1402 = {1402, ptf1402, (uint16) 5, (uint16) 0, (char) 0};

/* EWG_EIFFEL_API_FUNCTION_WRAPPER_GENERATOR */
static EIF_TYPE_INDEX ptf1403[] = {862,0xFFF7,1399,0xFFF7,275,0xFFFF};
static struct eif_par_types par1403 = {1403, ptf1403, (uint16) 3, (uint16) 0, (char) 0};

/* EWG_EIFFEL_API_UNION_WRAPPER_GENERATOR */
static EIF_TYPE_INDEX ptf1404[] = {311,0xFFF7,862,0xFFF7,1399,0xFFF7,275,0xFFFF};
static struct eif_par_types par1404 = {1404, ptf1404, (uint16) 4, (uint16) 0, (char) 0};

/* EWG_EIFFEL_API_STRUCT_WRAPPER_GENERATOR */
static EIF_TYPE_INDEX ptf1405[] = {311,0xFFF7,862,0xFFF7,1399,0xFFF7,275,0xFFFF};
static struct eif_par_types par1405 = {1405, ptf1405, (uint16) 4, (uint16) 0, (char) 0};

/* EWG_EIFFEL_API_ENUM_WRAPPER_GENERATOR */
static EIF_TYPE_INDEX ptf1406[] = {273,0xFFF7,1399,0xFFFF};
static struct eif_par_types par1406 = {1406, ptf1406, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_EIFFEL_API_MACRO_WRAPPER_GENERATOR */
static EIF_TYPE_INDEX ptf1407[] = {273,0xFFF7,1399,0xFFFF};
static struct eif_par_types par1407 = {1407, ptf1407, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_CONFIG_CALLBACK_WRAPPER_CLAUSE */
static EIF_TYPE_INDEX ptf1408[] = {314,0xFFF7,1399,0xFFF7,862,0xFFFF};
static struct eif_par_types par1408 = {1408, ptf1408, (uint16) 3, (uint16) 0, (char) 0};

/* EWG_CONFIG_FUNCTION_WRAPPER_CLAUSE */
static EIF_TYPE_INDEX ptf1409[] = {314,0xFFF7,1399,0xFFF7,862,0xFFFF};
static struct eif_par_types par1409 = {1409, ptf1409, (uint16) 3, (uint16) 0, (char) 0};

/* EWG_GENERATOR */
static EIF_TYPE_INDEX ptf1410[] = {1399,0xFFF7,220,0xFFF7,0,0xFFFF};
static struct eif_par_types par1410 = {1410, ptf1410, (uint16) 3, (uint16) 0, (char) 0};

/* EWG_EIFFEL_WRAPPER_BUILDER */
static EIF_TYPE_INDEX ptf1411[] = {0,0xFFF7,862,0xFFF7,1006,0xFFF7,1399,0xFFFF};
static struct eif_par_types par1411 = {1411, ptf1411, (uint16) 4, (uint16) 0, (char) 0};

/* EWG_EIFFEL_WRAPPER_SET */
static EIF_TYPE_INDEX ptf1412[] = {1399,0xFFF7,172,0xFFF7,170,0xFFF7,0,0xFFFF};
static struct eif_par_types par1412 = {1412, ptf1412, (uint16) 4, (uint16) 0, (char) 0};

/* EWG_EIFFEL_ABSTRACTION_ANSI_C_CALLBACK_SIGNATURE_GENERATOR */
static EIF_TYPE_INDEX ptf1413[] = {0,0xFFF7,311,0xFFF7,1399,0xFFFF};
static struct eif_par_types par1413 = {1413, ptf1413, (uint16) 3, (uint16) 0, (char) 0};

/* EWG_CONFIG_COMPOSITE_DATA_TYPE_WRAPPER_CLAUSE */
static EIF_TYPE_INDEX ptf1414[] = {314,0xFFF7,1399,0xFFFF};
static struct eif_par_types par1414 = {1414, ptf1414, (uint16) 2, (uint16) 0, (char) 0};

/* EWG_CONFIG_ENUM_WRAPPER_CLAUSE */
static EIF_TYPE_INDEX ptf1415[] = {1414,0xFFFF};
static struct eif_par_types par1415 = {1415, ptf1415, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_CONFIG_UNION_WRAPPER_CLAUSE */
static EIF_TYPE_INDEX ptf1416[] = {1414,0xFFFF};
static struct eif_par_types par1416 = {1416, ptf1416, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_CONFIG_STRUCT_WRAPPER_CLAUSE */
static EIF_TYPE_INDEX ptf1417[] = {1414,0xFFFF};
static struct eif_par_types par1417 = {1417, ptf1417, (uint16) 1, (uint16) 0, (char) 0};

/* EWG_EIFFEL_ABSTRACTION_ANSI_C_CALLBACK_DISPATCHER_GENERATOR */
static EIF_TYPE_INDEX ptf1418[] = {273,0xFFF7,1413,0xFFF7,311,0xFFF7,1399,0xFFFF};
static struct eif_par_types par1418 = {1418, ptf1418, (uint16) 4, (uint16) 0, (char) 0};

/* RX_PCRE_COMPILER */
static EIF_TYPE_INDEX ptf1419[] = {0,0xFFF7,82,0xFFF7,81,0xFFF7,1093,0xFFF7,80,0xFFF7,79,0xFFF7,1006,0xFFF7,209,0xFFF7,864,0xFFF7,205,0xFFF7,312,0xFFF7,74,0xFFFF};
static struct eif_par_types par1419 = {1419, ptf1419, (uint16) 12, (uint16) 0, (char) 0};

/* RX_PCRE_MATCHER */
static EIF_TYPE_INDEX ptf1420[] = {1324,0xFFF7,1419,0xFFF7,332,0xFFFF};
static struct eif_par_types par1420 = {1420, ptf1420, (uint16) 3, (uint16) 0, (char) 0};

/* RX_PCRE_REGULAR_EXPRESSION */
static EIF_TYPE_INDEX ptf1421[] = {1325,0xFFF7,1420,0xFFFF};
static struct eif_par_types par1421 = {1421, ptf1421, (uint16) 2, (uint16) 0, (char) 0};

/* UC_STRING */
static EIF_TYPE_INDEX ptf1422[] = {0,0xFFF7,987,0xFFF7,191,0xFFF7,1034,0xFFF7,77,0xFFF7,409,0xFFF7,310,0xFFF7,280,0xFFF7,159,0xFFF7,864,0xFFF7,988,0xFFF7,74,0xFFF7,339,0xFFFF};
static struct eif_par_types par1422 = {1422, ptf1422, (uint16) 13, (uint16) 0, (char) 0};

/* UC_UTF8_STRING */
static EIF_TYPE_INDEX ptf1423[] = {1422,0xFFFF};
static struct eif_par_types par1423 = {1423, ptf1423, (uint16) 1, (uint16) 0, (char) 0};

int egc_partab_size_init = 1423				;
				struct eif_par_types *egc_partab_init[] = {
&par0,
&par1,
&par2,
&par3,
&par4,
&par5,
&par6,
&par7,
&par8,
&par9,
&par10,
&par11,
&par12,
&par13,
&par14,
&par15,
&par16,
&par17,
&par18,
&par19,
&par20,
&par21,
&par22,
&par23,
&par24,
&par25,
&par26,
&par27,
&par28,
&par29,
&par30,
&par31,
&par32,
&par33,
&par34,
&par35,
&par36,
&par37,
&par38,
&par39,
&par40,
&par41,
&par42,
&par43,
&par44,
&par45,
&par46,
&par47,
&par48,
&par49,
&par50,
&par51,
&par52,
&par53,
&par54,
&par55,
&par56,
&par57,
&par58,
&par59,
&par60,
&par61,
&par62,
&par63,
&par64,
&par65,
&par66,
&par67,
&par68,
&par69,
&par70,
&par71,
&par72,
&par73,
&par74,
&par75,
&par76,
&par77,
&par78,
&par79,
&par80,
&par81,
&par82,
&par83,
&par84,
&par85,
&par86,
&par87,
&par88,
&par89,
&par90,
&par91,
&par92,
&par93,
&par94,
&par95,
&par96,
&par97,
&par98,
&par99,
&par100,
&par101,
&par102,
&par103,
&par104,
&par105,
&par106,
&par107,
&par108,
&par109,
&par110,
&par111,
&par112,
&par113,
&par114,
&par115,
&par116,
&par117,
&par118,
&par119,
&par120,
&par121,
&par122,
&par123,
&par124,
&par125,
&par126,
&par127,
&par128,
&par129,
&par130,
&par131,
&par132,
&par133,
&par134,
&par135,
&par136,
&par137,
&par138,
&par139,
&par140,
&par141,
&par142,
&par143,
&par144,
&par145,
&par146,
&par147,
&par148,
&par149,
&par150,
&par151,
&par152,
&par153,
&par154,
&par155,
&par156,
&par157,
&par158,
&par159,
&par160,
&par161,
&par162,
&par163,
&par164,
&par165,
&par166,
&par167,
&par168,
&par169,
&par170,
&par171,
&par172,
&par173,
&par174,
&par175,
&par176,
&par177,
&par178,
&par179,
&par180,
&par181,
&par182,
&par183,
&par184,
&par185,
&par186,
&par187,
&par188,
&par189,
&par190,
&par191,
&par192,
&par193,
&par194,
&par195,
&par196,
&par197,
&par198,
&par199,
&par200,
&par201,
&par202,
&par203,
&par204,
&par205,
&par206,
&par207,
&par208,
&par209,
&par210,
&par211,
&par212,
&par213,
&par214,
&par215,
&par216,
&par217,
&par218,
&par219,
&par220,
&par221,
&par222,
&par223,
&par224,
&par225,
&par226,
&par227,
&par228,
&par229,
&par230,
&par231,
&par232,
&par233,
&par234,
&par235,
&par236,
&par237,
&par238,
&par239,
&par240,
&par241,
&par242,
&par243,
&par244,
&par245,
&par246,
&par247,
&par248,
&par249,
&par250,
&par251,
&par252,
&par253,
&par254,
&par255,
&par256,
&par257,
&par258,
&par259,
&par260,
&par261,
&par262,
&par263,
&par264,
&par265,
&par266,
&par267,
&par268,
&par269,
&par270,
&par271,
&par272,
&par273,
&par274,
&par275,
&par276,
&par277,
&par278,
&par279,
&par280,
&par281,
&par282,
&par283,
&par284,
&par285,
&par286,
&par287,
&par288,
&par289,
&par290,
&par291,
&par292,
&par293,
&par294,
&par295,
&par296,
&par297,
&par298,
&par299,
&par300,
&par301,
&par302,
&par303,
&par304,
&par305,
&par306,
&par307,
&par308,
&par309,
&par310,
&par311,
&par312,
&par313,
&par314,
&par315,
&par316,
&par317,
&par318,
&par319,
&par320,
&par321,
&par322,
&par323,
&par324,
&par325,
&par326,
&par327,
&par328,
&par329,
&par330,
&par331,
&par332,
&par333,
&par334,
&par335,
&par336,
&par337,
&par338,
&par339,
&par340,
&par341,
&par342,
&par343,
&par344,
&par345,
&par346,
&par347,
&par348,
&par349,
&par350,
&par351,
&par352,
&par353,
&par354,
&par355,
&par356,
&par357,
&par358,
&par359,
&par360,
&par361,
&par362,
&par363,
&par364,
&par365,
&par366,
&par367,
&par368,
&par369,
&par370,
&par371,
&par372,
&par373,
&par374,
&par375,
&par376,
&par377,
&par378,
&par379,
&par380,
&par381,
&par382,
&par383,
&par384,
&par385,
&par386,
&par387,
&par388,
&par389,
&par390,
&par391,
&par392,
&par393,
&par394,
&par395,
&par396,
&par397,
&par398,
&par399,
&par400,
&par401,
&par402,
&par403,
&par404,
&par405,
&par406,
&par407,
&par408,
&par409,
&par410,
&par411,
&par412,
&par413,
&par414,
&par415,
&par416,
&par417,
&par418,
&par419,
&par420,
&par421,
&par422,
&par423,
&par424,
&par425,
&par426,
&par427,
&par428,
&par429,
&par430,
&par431,
&par432,
&par433,
&par434,
&par435,
&par436,
&par437,
&par438,
&par439,
&par440,
&par441,
&par442,
&par443,
&par444,
&par445,
&par446,
&par447,
&par448,
&par449,
&par450,
&par451,
&par452,
&par453,
&par454,
&par455,
&par456,
&par457,
&par458,
&par459,
&par460,
&par461,
&par462,
&par463,
&par464,
&par465,
&par466,
&par467,
&par468,
&par469,
&par470,
&par471,
&par472,
&par473,
&par474,
&par475,
&par476,
&par477,
&par478,
&par479,
&par480,
&par481,
&par482,
&par483,
&par484,
&par485,
&par486,
&par487,
&par488,
&par489,
&par490,
&par491,
&par492,
&par493,
&par494,
&par495,
&par496,
&par497,
&par498,
&par499,
&par500,
&par501,
&par502,
&par503,
&par504,
&par505,
&par506,
&par507,
&par508,
&par509,
&par510,
&par511,
&par512,
&par513,
&par514,
&par515,
&par516,
&par517,
&par518,
&par519,
&par520,
&par521,
&par522,
&par523,
&par524,
&par525,
&par526,
&par527,
&par528,
&par529,
&par530,
&par531,
&par532,
&par533,
&par534,
&par535,
&par536,
&par537,
&par538,
&par539,
&par540,
&par541,
&par542,
&par543,
&par544,
&par545,
&par546,
&par547,
&par548,
&par549,
&par550,
&par551,
&par552,
&par553,
&par554,
&par555,
&par556,
&par557,
&par558,
&par559,
&par560,
&par561,
&par562,
&par563,
&par564,
&par565,
&par566,
&par567,
&par568,
&par569,
&par570,
&par571,
&par572,
&par573,
&par574,
&par575,
&par576,
&par577,
&par578,
&par579,
&par580,
&par581,
&par582,
&par583,
&par584,
&par585,
&par586,
&par587,
&par588,
&par589,
&par590,
&par591,
&par592,
&par593,
&par594,
&par595,
&par596,
&par597,
&par598,
&par599,
&par600,
&par601,
&par602,
&par603,
&par604,
&par605,
&par606,
&par607,
&par608,
&par609,
&par610,
&par611,
&par612,
&par613,
&par614,
&par615,
&par616,
&par617,
&par618,
&par619,
&par620,
&par621,
&par622,
&par623,
&par624,
&par625,
&par626,
&par627,
&par628,
&par629,
&par630,
&par631,
&par632,
&par633,
&par634,
&par635,
&par636,
&par637,
&par638,
&par639,
&par640,
&par641,
&par642,
&par643,
&par644,
&par645,
&par646,
&par647,
&par648,
&par649,
&par650,
&par651,
&par652,
&par653,
&par654,
&par655,
&par656,
&par657,
&par658,
&par659,
&par660,
&par661,
&par662,
&par663,
&par664,
&par665,
&par666,
&par667,
&par668,
&par669,
&par670,
&par671,
&par672,
&par673,
&par674,
&par675,
&par676,
&par677,
&par678,
&par679,
&par680,
&par681,
&par682,
&par683,
&par684,
&par685,
&par686,
&par687,
&par688,
&par689,
&par690,
&par691,
&par692,
&par693,
&par694,
&par695,
&par696,
&par697,
&par698,
&par699,
&par700,
&par701,
&par702,
&par703,
&par704,
&par705,
&par706,
&par707,
&par708,
&par709,
&par710,
&par711,
&par712,
&par713,
&par714,
&par715,
&par716,
&par717,
&par718,
&par719,
&par720,
&par721,
&par722,
&par723,
&par724,
&par725,
&par726,
&par727,
&par728,
&par729,
&par730,
&par731,
&par732,
&par733,
&par734,
&par735,
&par736,
&par737,
&par738,
&par739,
&par740,
&par741,
&par742,
&par743,
&par744,
&par745,
&par746,
&par747,
&par748,
&par749,
&par750,
&par751,
&par752,
&par753,
&par754,
&par755,
&par756,
&par757,
&par758,
&par759,
&par760,
&par761,
&par762,
&par763,
&par764,
&par765,
&par766,
&par767,
&par768,
&par769,
&par770,
&par771,
&par772,
&par773,
&par774,
&par775,
&par776,
&par777,
&par778,
&par779,
&par780,
&par781,
&par782,
&par783,
&par784,
&par785,
&par786,
&par787,
&par788,
&par789,
&par790,
&par791,
&par792,
&par793,
&par794,
&par795,
&par796,
&par797,
&par798,
&par799,
&par800,
&par801,
&par802,
&par803,
&par804,
&par805,
&par806,
&par807,
&par808,
&par809,
&par810,
&par811,
&par812,
&par813,
&par814,
&par815,
&par816,
&par817,
&par818,
&par819,
&par820,
&par821,
&par822,
&par823,
&par824,
&par825,
&par826,
&par827,
&par828,
&par829,
&par830,
&par831,
&par832,
&par833,
&par834,
&par835,
&par836,
&par837,
&par838,
&par839,
&par840,
&par841,
&par842,
&par843,
&par844,
&par845,
&par846,
&par847,
&par848,
&par849,
&par850,
&par851,
&par852,
&par853,
&par854,
&par855,
&par856,
&par857,
&par858,
&par859,
&par860,
&par861,
&par862,
&par863,
&par864,
&par865,
&par866,
&par867,
&par868,
&par869,
&par870,
&par871,
&par872,
&par873,
&par874,
&par875,
&par876,
&par877,
&par878,
&par879,
&par880,
&par881,
&par882,
&par883,
&par884,
&par885,
&par886,
&par887,
&par888,
&par889,
&par890,
&par891,
&par892,
&par893,
&par894,
&par895,
&par896,
&par897,
&par898,
&par899,
&par900,
&par901,
&par902,
&par903,
&par904,
&par905,
&par906,
&par907,
&par908,
&par909,
&par910,
&par911,
&par912,
&par913,
&par914,
&par915,
&par916,
&par917,
&par918,
&par919,
&par920,
&par921,
&par922,
&par923,
&par924,
&par925,
&par926,
&par927,
&par928,
&par929,
&par930,
&par931,
&par932,
&par933,
&par934,
&par935,
&par936,
&par937,
&par938,
&par939,
&par940,
&par941,
&par942,
&par943,
&par944,
&par945,
&par946,
&par947,
&par948,
&par949,
&par950,
&par951,
&par952,
&par953,
&par954,
&par955,
&par956,
&par957,
&par958,
&par959,
&par960,
&par961,
&par962,
&par963,
&par964,
&par965,
&par966,
&par967,
&par968,
&par969,
&par970,
&par971,
&par972,
&par973,
&par974,
&par975,
&par976,
&par977,
&par978,
&par979,
&par980,
&par981,
&par982,
&par983,
&par984,
&par985,
&par986,
&par987,
&par988,
&par989,
&par990,
&par991,
&par992,
&par993,
&par994,
&par995,
&par996,
&par997,
&par998,
&par999,
&par1000,
&par1001,
&par1002,
&par1003,
&par1004,
&par1005,
&par1006,
&par1007,
&par1008,
&par1009,
&par1010,
&par1011,
&par1012,
&par1013,
&par1014,
&par1015,
&par1016,
&par1017,
&par1018,
&par1019,
&par1020,
&par1021,
&par1022,
&par1023,
&par1024,
&par1025,
&par1026,
&par1027,
&par1028,
&par1029,
&par1030,
&par1031,
&par1032,
&par1033,
&par1034,
&par1035,
&par1036,
&par1037,
&par1038,
&par1039,
&par1040,
&par1041,
&par1042,
&par1043,
&par1044,
&par1045,
&par1046,
&par1047,
&par1048,
&par1049,
&par1050,
&par1051,
&par1052,
&par1053,
&par1054,
&par1055,
&par1056,
&par1057,
&par1058,
&par1059,
&par1060,
&par1061,
&par1062,
&par1063,
&par1064,
&par1065,
&par1066,
&par1067,
&par1068,
&par1069,
&par1070,
&par1071,
&par1072,
&par1073,
&par1074,
&par1075,
&par1076,
&par1077,
&par1078,
&par1079,
&par1080,
&par1081,
&par1082,
&par1083,
&par1084,
&par1085,
&par1086,
&par1087,
&par1088,
&par1089,
&par1090,
&par1091,
&par1092,
&par1093,
&par1094,
&par1095,
&par1096,
&par1097,
&par1098,
&par1099,
&par1100,
&par1101,
&par1102,
&par1103,
&par1104,
&par1105,
&par1106,
&par1107,
&par1108,
&par1109,
&par1110,
&par1111,
&par1112,
&par1113,
&par1114,
&par1115,
&par1116,
&par1117,
&par1118,
&par1119,
&par1120,
&par1121,
&par1122,
&par1123,
&par1124,
&par1125,
&par1126,
&par1127,
&par1128,
&par1129,
&par1130,
&par1131,
&par1132,
&par1133,
&par1134,
&par1135,
&par1136,
&par1137,
&par1138,
&par1139,
&par1140,
&par1141,
&par1142,
&par1143,
&par1144,
&par1145,
&par1146,
&par1147,
&par1148,
&par1149,
&par1150,
&par1151,
&par1152,
&par1153,
&par1154,
&par1155,
&par1156,
&par1157,
&par1158,
&par1159,
&par1160,
&par1161,
&par1162,
&par1163,
&par1164,
&par1165,
&par1166,
&par1167,
&par1168,
&par1169,
&par1170,
&par1171,
&par1172,
&par1173,
&par1174,
&par1175,
&par1176,
&par1177,
&par1178,
&par1179,
&par1180,
&par1181,
&par1182,
&par1183,
&par1184,
&par1185,
&par1186,
&par1187,
&par1188,
&par1189,
&par1190,
&par1191,
&par1192,
&par1193,
&par1194,
&par1195,
&par1196,
&par1197,
&par1198,
&par1199,
&par1200,
&par1201,
&par1202,
&par1203,
&par1204,
&par1205,
&par1206,
&par1207,
&par1208,
&par1209,
&par1210,
&par1211,
&par1212,
&par1213,
&par1214,
&par1215,
&par1216,
&par1217,
&par1218,
&par1219,
&par1220,
&par1221,
&par1222,
&par1223,
&par1224,
&par1225,
&par1226,
&par1227,
&par1228,
&par1229,
&par1230,
&par1231,
&par1232,
&par1233,
&par1234,
&par1235,
&par1236,
&par1237,
&par1238,
&par1239,
&par1240,
&par1241,
&par1242,
&par1243,
&par1244,
&par1245,
&par1246,
&par1247,
&par1248,
&par1249,
&par1250,
&par1251,
&par1252,
&par1253,
&par1254,
&par1255,
&par1256,
&par1257,
&par1258,
&par1259,
&par1260,
&par1261,
&par1262,
&par1263,
&par1264,
&par1265,
&par1266,
&par1267,
&par1268,
&par1269,
&par1270,
&par1271,
&par1272,
&par1273,
&par1274,
&par1275,
&par1276,
&par1277,
&par1278,
&par1279,
&par1280,
&par1281,
&par1282,
&par1283,
&par1284,
&par1285,
&par1286,
&par1287,
&par1288,
&par1289,
&par1290,
&par1291,
&par1292,
&par1293,
&par1294,
&par1295,
&par1296,
&par1297,
&par1298,
&par1299,
&par1300,
&par1301,
&par1302,
&par1303,
&par1304,
&par1305,
&par1306,
&par1307,
&par1308,
&par1309,
&par1310,
&par1311,
&par1312,
&par1313,
&par1314,
&par1315,
&par1316,
&par1317,
&par1318,
&par1319,
&par1320,
&par1321,
&par1322,
&par1323,
&par1324,
&par1325,
&par1326,
&par1327,
&par1328,
&par1329,
&par1330,
&par1331,
&par1332,
&par1333,
&par1334,
&par1335,
&par1336,
&par1337,
&par1338,
&par1339,
&par1340,
&par1341,
&par1342,
&par1343,
&par1344,
&par1345,
&par1346,
&par1347,
&par1348,
&par1349,
&par1350,
&par1351,
&par1352,
&par1353,
&par1354,
&par1355,
&par1356,
&par1357,
&par1358,
&par1359,
&par1360,
&par1361,
&par1362,
&par1363,
&par1364,
&par1365,
&par1366,
&par1367,
&par1368,
&par1369,
&par1370,
&par1371,
&par1372,
&par1373,
&par1374,
&par1375,
&par1376,
&par1377,
&par1378,
&par1379,
&par1380,
&par1381,
&par1382,
&par1383,
&par1384,
&par1385,
&par1386,
&par1387,
&par1388,
&par1389,
&par1390,
&par1391,
&par1392,
&par1393,
&par1394,
&par1395,
&par1396,
&par1397,
&par1398,
&par1399,
&par1400,
&par1401,
&par1402,
&par1403,
&par1404,
&par1405,
&par1406,
&par1407,
&par1408,
&par1409,
&par1410,
&par1411,
&par1412,
&par1413,
&par1414,
&par1415,
&par1416,
&par1417,
&par1418,
&par1419,
&par1420,
&par1421,
&par1422,
&par1423,
NULL};

#ifdef __cplusplus
}
#endif
