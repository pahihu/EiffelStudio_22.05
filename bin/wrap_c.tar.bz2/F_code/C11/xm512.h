
#ifndef _C11_xm512_
#define _C11_xm512_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1328_9839(EIF_REFERENCE);
extern void F1328_9841(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit512(void);

#ifdef __cplusplus
}
#endif

#endif
