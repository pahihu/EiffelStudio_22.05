/*
 * Code for class DT_TIME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dt528.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DT_TIME}.hour */
EIF_INTEGER_32 F1344_10085 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O7488[Dtype(Current)-1343]) / ((EIF_INTEGER_32) 3600000L));
}

/* {DT_TIME}.minute */
EIF_INTEGER_32 F1344_10086 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O7488[Dtype(Current)-1343]) / ((EIF_INTEGER_32) 60000L)) % ((EIF_INTEGER_32) 60L));
}

/* {DT_TIME}.second */
EIF_INTEGER_32 F1344_10087 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O7488[Dtype(Current)-1343]) / ((EIF_INTEGER_32) 1000L)) % ((EIF_INTEGER_32) 60L));
}

/* {DT_TIME}.millisecond */
EIF_INTEGER_32 F1344_10088 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O7488[Dtype(Current)-1343]) % ((EIF_INTEGER_32) 1000L));
}

/* {DT_TIME}.hash_code */
EIF_INTEGER_32 F1344_10095 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O7488[Dtype(Current)-1343]);
}

/* {DT_TIME}.is_less */
EIF_BOOLEAN F1344_10113 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O7488[Dtype(Current)-1343]);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O7488[Dtype(arg1)-1343]);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 < ti4_2);
	RTLE;
	return Result;
}

/* {DT_TIME}.append_time_to_string */
void F1344_10115 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = F1344_10085(Current);
	if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 10L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '0');
	}
	tr1 = RTOSCF(4972,F865_4972, (Current));
	F1013_6999(RTCW(tr1), loc1, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) ':');
	loc2 = F1344_10086(Current);
	if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 10L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '0');
	}
	tr1 = RTOSCF(4972,F865_4972, (Current));
	F1013_6999(RTCW(tr1), loc2, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) ':');
	loc3 = F1344_10087(Current);
	if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 10L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '0');
	}
	tr1 = RTOSCF(4972,F865_4972, (Current));
	F1013_6999(RTCW(tr1), loc3, arg1);
	loc4 = F1344_10088(Current);
	if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '.');
		if ((EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 10L))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '0');
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '0');
		} else {
			if ((EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 100L))) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '0');
			}
		}
		tr1 = RTOSCF(4972,F865_4972, (Current));
		F1013_6999(RTCW(tr1), loc4, arg1);
	}
	RTLE;
}

void EIF_Minit528 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
