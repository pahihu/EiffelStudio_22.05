/*
 * Code for class XM_DOCUMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm522.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_DOCUMENT}.make */
void F1338_9944 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(9946,F1338_9946, (Current));
	tr2 = RTOSCF(9837,F1327_9837, (Current));
	F1338_9945(Current, tr1, tr2);
	RTLE;
}

/* {XM_DOCUMENT}.make_with_root_named */
void F1338_9945 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y7338,Y7338_gen_type,Dftype(Current),1335).id);
	F1247_8688(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1336, 1).id);
	F1337_9921(RTCW(tr1), Current, arg1, arg2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F1336_9908(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
	RTLE;
}

/* {XM_DOCUMENT}.default_name */

EIF_REFERENCE F1338_9946 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (9946,RTMS_EX_H("root",4,1919905652));
}

/* {XM_DOCUMENT}.last */
EIF_REFERENCE F1338_9947 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1247_8696(RTCW(tr1));
	RTLE;
	return Result;
}

/* {XM_DOCUMENT}.set_root_element */
void F1338_9950 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F1338_9951(Current);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	F1336_9908(Current, arg1);
	RTLE;
}

/* {XM_DOCUMENT}.remove_previous_root_element */
void F1338_9951 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = F1336_9896(Current);
	F1119_8288(RTCW(loc1));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_3_1_);
		if (tb1) break;
		tr1 = F1167_8376(RTCW(loc1));
		if ((EIF_BOOLEAN)(tr1 == *(EIF_REFERENCE *)(Current + _REFACS_1_))) {
			F1164_8355(RTCW(loc1));
			F1119_8291(RTCW(loc1));
		} else {
			F1119_8289(RTCW(loc1));
		}
	}
	RTLE;
}

void EIF_Minit522 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
