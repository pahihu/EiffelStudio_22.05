
#ifndef _C11_xm504_
#define _C11_xm504_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1320_9740(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1320_9741(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1320_9742(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit504(void);
extern EIF_REFERENCE F1318_9718(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F409_3802(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,3802)
extern char *(*R2185[])();

#ifdef __cplusplus
}
#endif

#endif
