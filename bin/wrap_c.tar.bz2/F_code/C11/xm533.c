/*
 * Code for class XM_NAMESPACE_RESOLVER_CONTEXT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm533.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_NAMESPACE_RESOLVER_CONTEXT}.make */
void F1349_10189 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1249,0xFF01,1286,0xFF01,986,0xFF01,986,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1247_8688(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER_CONTEXT}.add_default */
void F1349_10190 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(10200,F1349_10200, (Current));
	F1349_10191(Current, arg1, tr1);
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER_CONTEXT}.add */
void F1349_10191 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = F1247_8696(RTCW(tr1));
	F1277_9211(RTCW(tr1), arg1, arg2);
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER_CONTEXT}.shallow_has */
EIF_BOOLEAN F1349_10193 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F1247_8696(RTCW(tr1));
		tb1 = F1277_9198(RTCW(tr1), arg1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {XM_NAMESPACE_RESOLVER_CONTEXT}.has */
EIF_BOOLEAN F1349_10194 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = F1250_8798(RTCW(tr1));
	F1126_8299(RTCW(loc1));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6399[Dtype(RTCW(loc1))-1130])(loc1);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3320[Dtype(RTCW(loc1))-401])(loc1);
		Result = F1277_9198(RTCW(tr1), arg1);
		if (Result) {
			F1126_8302(RTCW(loc1));
		} else {
			F1126_8300(RTCW(loc1));
		}
	}
	RTLE;
	return Result;
}

/* {XM_NAMESPACE_RESOLVER_CONTEXT}.resolve_default */
EIF_REFERENCE F1349_10195 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(10200,F1349_10200, (Current));
	Result = F1349_10196(Current, tr1);
	RTLE;
	return Result;
}

/* {XM_NAMESPACE_RESOLVER_CONTEXT}.resolve */
EIF_REFERENCE F1349_10196 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	Result = RTOSCF(10201,F1349_10201, (Current));
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = F1250_8798(RTCW(tr1));
	F1126_8299(RTCW(loc1));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6399[Dtype(RTCW(loc1))-1130])(loc1);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3320[Dtype(RTCW(loc1))-401])(loc1);
		tb2 = F1277_9198(RTCW(tr1), arg1);
		if (tb2) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3320[Dtype(RTCW(loc1))-401])(loc1);
			Result = F1277_9190(RTCW(tr1), arg1);
			F1126_8302(RTCW(loc1));
		} else {
			F1126_8300(RTCW(loc1));
		}
	}
	RTLE;
	return Result;
}

/* {XM_NAMESPACE_RESOLVER_CONTEXT}.push */
void F1349_10197 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = F208_2300(Current);
	F1247_8715(RTCW(tr1), tr2);
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER_CONTEXT}.pop */
void F1349_10198 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		F1250_8803(RTCW(tr1));
	}
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER_CONTEXT}.default_pseudo_prefix */
static EIF_REFERENCE F1349_10200_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10200);
#define Result RTOSR(10200)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F979_6315(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10200);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1349_10200 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10200,F1349_10200_body,(Current));
}

/* {XM_NAMESPACE_RESOLVER_CONTEXT}.default_namespace */
static EIF_REFERENCE F1349_10201_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10201);
#define Result RTOSR(10201)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F979_6315(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10201);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1349_10201 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10201,F1349_10201_body,(Current));
}

void EIF_Minit533 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
