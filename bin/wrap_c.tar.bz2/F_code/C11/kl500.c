/*
 * Code for class KL_WINDOWS_FILE_SYSTEM_BACKSLASH_ONLY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl500.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_WINDOWS_FILE_SYSTEM_BACKSLASH_ONLY}.secondary_directory_separator */
static EIF_CHARACTER_8 F1316_9694_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (9694);
#define Result RTOSR(9694)
	Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\\';
	RTOSE (9694);
	RTEE;
	return Result;
#undef Result
}

EIF_CHARACTER_8 F1316_9694 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9694,F1316_9694_body,(Current));
}

void EIF_Minit500 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
