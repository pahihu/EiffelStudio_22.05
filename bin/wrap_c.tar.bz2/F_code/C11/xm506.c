/*
 * Code for class XM_UNICODE_VALIDATION_FILTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm506.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_UNICODE_VALIDATION_FILTER}.on_comment */
void F1322_9747 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1322_9752(Current, arg1);
	F214_2344(Current, arg1);
	RTLE;
}

/* {XM_UNICODE_VALIDATION_FILTER}.on_processing_instruction */
void F1322_9748 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	F1322_9753(Current, arg1);
	F1322_9752(Current, arg2);
	F214_2343(Current, arg1, arg2);
	RTLE;
}

/* {XM_UNICODE_VALIDATION_FILTER}.on_start_tag */
void F1322_9749 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,arg3);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		tb1 = F212_2320(Current, arg2);
	}
	if (tb1) {
		F1322_9753(Current, arg2);
	}
	F1322_9753(Current, arg3);
	F214_2345(Current, arg1, arg2, arg3);
	RTLE;
}

/* {XM_UNICODE_VALIDATION_FILTER}.on_attribute */
void F1322_9750 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,arg3);
	RTLR(3,arg4);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		tb1 = F212_2320(Current, arg2);
	}
	if (tb1) {
		F1322_9753(Current, arg2);
	}
	F1322_9753(Current, arg3);
	F1322_9752(Current, arg4);
	F214_2346(Current, arg1, arg2, arg3, arg4);
	RTLE;
}

/* {XM_UNICODE_VALIDATION_FILTER}.on_content */
void F1322_9751 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1322_9752(Current, arg1);
	F214_2349(Current, arg1);
	RTLE;
}

/* {XM_UNICODE_VALIDATION_FILTER}.validate */
void F1322_9752 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(9745,F1321_9745, (Current));
	tb1 = F134_1595(RTCW(tr1), arg1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(9754,F1322_9754, (Current));
		F214_2342(Current, tr1);
	}
	RTLE;
}

/* {XM_UNICODE_VALIDATION_FILTER}.validate_name */
void F1322_9753 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(9745,F1321_9745, (Current));
	tb1 = F134_1596(RTCW(tr1), arg1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(9754,F1322_9754, (Current));
		F214_2342(Current, tr1);
	}
	RTLE;
}

/* {XM_UNICODE_VALIDATION_FILTER}.error_unicode_invalid_character */

EIF_REFERENCE F1322_9754 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (9754,RTMS_EX_H("Invalid unicode character",25,710506354));
}

void EIF_Minit506 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
