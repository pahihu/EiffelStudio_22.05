
#ifndef _C11_xm547_
#define _C11_xm547_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1363_10672(EIF_REFERENCE);
extern void F1363_10675(EIF_REFERENCE);
extern void EIF_Minit547(void);
extern void F1082_7794(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1082_7806(EIF_REFERENCE);
extern void F1361_10547(EIF_REFERENCE);
extern EIF_BOOLEAN F1082_7791(EIF_REFERENCE);
extern void F1084_7920(EIF_REFERENCE);
extern void F1083_7857(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
