/*
 * Code for class XM_OUTPUT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm501.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_OUTPUT}.set_output_standard */
void F1317_9698 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(93,F11_93, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O7148[dtype-1316]) = (EIF_REFERENCE) tr1;
	*(EIF_REFERENCE *)(Current + O7146[dtype-1316]) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {XM_OUTPUT}.output */
void F1317_9703 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7146[dtype-1316]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = RTOSCF(6954,F1007_6954, (Current));
		tr1 = F1000_6914(RTCW(tr1), loc1, arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O7146[dtype-1316]) = (EIF_REFERENCE) tr1;
	} else {
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O7148[dtype-1316]) == NULL)) {
			F1317_9698(Current);
		}
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + O7148[dtype-1316]);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1088[Dtype(loc2)-1035])(loc2);
			tb1 = tb2;
		}
		if (tb1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5586[Dtype(loc2)-1035])(loc2, arg1);
		}
	}
	RTLE;
}

void EIF_Minit501 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
