
#ifndef _C11_xm515_
#define _C11_xm515_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1331_9843(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1331_9844(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit515(void);
extern void F1336_9908(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
