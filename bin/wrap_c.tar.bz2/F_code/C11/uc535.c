/*
 * Code for class UC_UNICODE_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uc535.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UC_UNICODE_ROUTINES}.valid_non_surrogate_code */
EIF_BOOLEAN F1351_10246 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 55296L))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 57343L)) && (EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 1114111L))));
}

/* {UC_UNICODE_ROUTINES}.valid_non_surrogate_natural_32_code */
EIF_BOOLEAN F1351_10247 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 >= ((EIF_NATURAL_32) 0U)) && (EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 55296U))) || (EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 > ((EIF_NATURAL_32) 57343U)) && (EIF_BOOLEAN) (arg1 <= ((EIF_NATURAL_32) 1114111U))));
}

void EIF_Minit535 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
