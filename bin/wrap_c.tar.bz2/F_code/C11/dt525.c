/*
 * Code for class DT_DATE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dt525.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DT_DATE}.year */
EIF_INTEGER_32 F1341_9999 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) < ((EIF_INTEGER_32) 0L))) {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) -(EIF_INTEGER_32) ((EIF_INTEGER_32) -*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) / ((EIF_INTEGER_32) 512L));
	} else {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) / ((EIF_INTEGER_32) 512L));
	}/* NOTREACHED */
	
}

/* {DT_DATE}.month */
EIF_INTEGER_32 F1341_10000 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) < ((EIF_INTEGER_32) 0L))) {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 512L) / ((EIF_INTEGER_32) 32L)) - (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) -*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) % ((EIF_INTEGER_32) 512L)) / ((EIF_INTEGER_32) 32L)));
	} else {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) % ((EIF_INTEGER_32) 512L)) / ((EIF_INTEGER_32) 32L));
	}/* NOTREACHED */
	
}

/* {DT_DATE}.day */
EIF_INTEGER_32 F1341_10001 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) < ((EIF_INTEGER_32) 0L))) {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 32L) - (EIF_INTEGER_32) ((EIF_INTEGER_32) -*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) % ((EIF_INTEGER_32) 32L)));
	} else {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) % ((EIF_INTEGER_32) 32L));
	}/* NOTREACHED */
	
}

/* {DT_DATE}.hash_code */
EIF_INTEGER_32 F1341_10012 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) -(EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	}
	RTLE;
	return Result;
}

/* {DT_DATE}.is_less */
EIF_BOOLEAN F1341_10026 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 < ti4_2);
	RTLE;
	return Result;
}

/* {DT_DATE}.append_date_to_string */
void F1341_10028 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = F1341_9999(Current);
	loc2 = F1341_10000(Current);
	loc3 = F1341_10001(Current);
	tr1 = RTOSCF(4972,F865_4972, (Current));
	F1013_6999(RTCW(tr1), loc1, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '/');
	if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 10L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '0');
	}
	tr1 = RTOSCF(4972,F865_4972, (Current));
	F1013_6999(RTCW(tr1), loc2, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '/');
	if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 10L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '0');
	}
	tr1 = RTOSCF(4972,F865_4972, (Current));
	F1013_6999(RTCW(tr1), loc3, arg1);
	RTLE;
}

void EIF_Minit525 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
