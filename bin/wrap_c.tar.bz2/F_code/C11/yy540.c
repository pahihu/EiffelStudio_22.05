/*
 * Code for class YY_PARSER_TOKENS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy540.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_PARSER_TOKENS}.yy_character_token_name */
EIF_REFERENCE F1356_10301 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tb1 = '\0';
	ti4_1 = RTOSCF(2200,F194_2200, (RTCV(RTOSCF(1015,F75_1015, (Current)))));
	if ((EIF_BOOLEAN) (arg1 >= ti4_1)) {
		ti4_1 = RTOSCF(2201,F194_2201, (RTCV(RTOSCF(1015,F75_1015, (Current)))));
		tb1 = (EIF_BOOLEAN) (arg1 <= ti4_1);
	}
	if (tb1) {
		tr1 = RTOSCF(4972,F865_4972, (Current));
		loc1 = F1013_6993(RTCW(tr1), arg1);
		switch (loc1) {
			case (EIF_CHARACTER_8) '\010':
				Result = RTMS_EX_H("\'\\b\'",4,660365863);
				break;
			case (EIF_CHARACTER_8) '\014':
				Result = RTMS_EX_H("\'\\f\'",4,660366887);
				break;
			case (EIF_CHARACTER_8) '\012':
				Result = RTMS_EX_H("\'\\n\'",4,660368935);
				break;
			case (EIF_CHARACTER_8) '\015':
				Result = RTMS_EX_H("\'\\r\'",4,660369959);
				break;
			case (EIF_CHARACTER_8) '\011':
				Result = RTMS_EX_H("\'\\t\'",4,660370471);
				break;
			case (EIF_CHARACTER_8) '\'':
				Result = RTMS_EX_H("\'\\\'\'",4,660350759);
				break;
			case (EIF_CHARACTER_8) '\"':
				Result = RTMS_EX_H("\'\\\"\'",4,660349479);
				break;
			case (EIF_CHARACTER_8) ' ':
			case (EIF_CHARACTER_8) '!':
			case (EIF_CHARACTER_8) '#':
			case (EIF_CHARACTER_8) '$':
			case (EIF_CHARACTER_8) '&':
			case (EIF_CHARACTER_8) '(':
			case (EIF_CHARACTER_8) ')':
			case (EIF_CHARACTER_8) '*':
			case (EIF_CHARACTER_8) '+':
			case (EIF_CHARACTER_8) ',':
			case (EIF_CHARACTER_8) '-':
			case (EIF_CHARACTER_8) '.':
			case (EIF_CHARACTER_8) '/':
			case (EIF_CHARACTER_8) '0':
			case (EIF_CHARACTER_8) '1':
			case (EIF_CHARACTER_8) '2':
			case (EIF_CHARACTER_8) '3':
			case (EIF_CHARACTER_8) '4':
			case (EIF_CHARACTER_8) '5':
			case (EIF_CHARACTER_8) '6':
			case (EIF_CHARACTER_8) '7':
			case (EIF_CHARACTER_8) '8':
			case (EIF_CHARACTER_8) '9':
			case (EIF_CHARACTER_8) ':':
			case (EIF_CHARACTER_8) ';':
			case (EIF_CHARACTER_8) '<':
			case (EIF_CHARACTER_8) '=':
			case (EIF_CHARACTER_8) '>':
			case (EIF_CHARACTER_8) '\?':
			case (EIF_CHARACTER_8) '@':
			case (EIF_CHARACTER_8) 'A':
			case (EIF_CHARACTER_8) 'B':
			case (EIF_CHARACTER_8) 'C':
			case (EIF_CHARACTER_8) 'D':
			case (EIF_CHARACTER_8) 'E':
			case (EIF_CHARACTER_8) 'F':
			case (EIF_CHARACTER_8) 'G':
			case (EIF_CHARACTER_8) 'H':
			case (EIF_CHARACTER_8) 'I':
			case (EIF_CHARACTER_8) 'J':
			case (EIF_CHARACTER_8) 'K':
			case (EIF_CHARACTER_8) 'L':
			case (EIF_CHARACTER_8) 'M':
			case (EIF_CHARACTER_8) 'N':
			case (EIF_CHARACTER_8) 'O':
			case (EIF_CHARACTER_8) 'P':
			case (EIF_CHARACTER_8) 'Q':
			case (EIF_CHARACTER_8) 'R':
			case (EIF_CHARACTER_8) 'S':
			case (EIF_CHARACTER_8) 'T':
			case (EIF_CHARACTER_8) 'U':
			case (EIF_CHARACTER_8) 'V':
			case (EIF_CHARACTER_8) 'W':
			case (EIF_CHARACTER_8) 'X':
			case (EIF_CHARACTER_8) 'Y':
			case (EIF_CHARACTER_8) 'Z':
			case (EIF_CHARACTER_8) '[':
			case (EIF_CHARACTER_8) '\\':
			case (EIF_CHARACTER_8) ']':
			case (EIF_CHARACTER_8) '^':
			case (EIF_CHARACTER_8) '_':
			case (EIF_CHARACTER_8) '`':
			case (EIF_CHARACTER_8) 'a':
			case (EIF_CHARACTER_8) 'b':
			case (EIF_CHARACTER_8) 'c':
			case (EIF_CHARACTER_8) 'd':
			case (EIF_CHARACTER_8) 'e':
			case (EIF_CHARACTER_8) 'f':
			case (EIF_CHARACTER_8) 'g':
			case (EIF_CHARACTER_8) 'h':
			case (EIF_CHARACTER_8) 'i':
			case (EIF_CHARACTER_8) 'j':
			case (EIF_CHARACTER_8) 'k':
			case (EIF_CHARACTER_8) 'l':
			case (EIF_CHARACTER_8) 'm':
			case (EIF_CHARACTER_8) 'n':
			case (EIF_CHARACTER_8) 'o':
			case (EIF_CHARACTER_8) 'p':
			case (EIF_CHARACTER_8) 'q':
			case (EIF_CHARACTER_8) 'r':
			case (EIF_CHARACTER_8) 's':
			case (EIF_CHARACTER_8) 't':
			case (EIF_CHARACTER_8) 'u':
			case (EIF_CHARACTER_8) 'v':
			case (EIF_CHARACTER_8) 'w':
			case (EIF_CHARACTER_8) 'x':
			case (EIF_CHARACTER_8) 'y':
			case (EIF_CHARACTER_8) 'z':
			case (EIF_CHARACTER_8) '{':
			case (EIF_CHARACTER_8) '|':
			case (EIF_CHARACTER_8) '}':
			case (EIF_CHARACTER_8) '~':
				Result = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F985_6612(RTCW(Result), ((EIF_INTEGER_32) 3L));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '\'');
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, loc1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '\'');
				break;
			default:
				Result = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F985_6612(RTCW(Result), ((EIF_INTEGER_32) 6L));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '\'');
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '\\');
				if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 0L))) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '0');
				} else {
					if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 0L))) {
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '-');
						loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) -arg1;
						loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
					} else {
						loc4 = (EIF_INTEGER_32) arg1;
						loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
					}
					for (;;) {
						if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) break;
						switch ((EIF_INTEGER_32) (loc4 % ((EIF_INTEGER_32) 8L))) {
							case 0L:
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '0');
								break;
							case 1L:
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '1');
								break;
							case 2L:
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '2');
								break;
							case 3L:
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '3');
								break;
							case 4L:
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '4');
								break;
							case 5L:
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '5');
								break;
							case 6L:
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '6');
								break;
							case 7L:
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '7');
								break;
							default:
								RTEC(EN_WHEN);
						}
						loc4 /= ((EIF_INTEGER_32) 8L);
					}
					loc3 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
					for (;;) {
						if ((EIF_BOOLEAN) (loc2 >= loc3)) break;
						loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3772[Dtype(RTCW(Result))-746])(Result, loc2));
						tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3772[Dtype(RTCW(Result))-746])(Result, loc3));
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3538[Dtype(RTCW(Result))-771])(Result, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &loc2);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3538[Dtype(RTCW(Result))-771])(Result, (EIF_REFERENCE) &loc1, (EIF_REFERENCE) &loc3);
						loc2++;
						loc3--;
					}
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '\'');
				break;
		}
	} else {
		Result = RTMS_EX_H("Unknown token",13,1896573550);
	}
	RTLE;
	return Result;
}

void EIF_Minit540 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
