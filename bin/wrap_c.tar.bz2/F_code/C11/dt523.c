/*
 * Code for class DT_DATE_VALUE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dt523.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DT_DATE_VALUE}.out */
EIF_REFERENCE F1339_9962 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F985_6612(RTCW(Result), ((EIF_INTEGER_32) 10L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7368[Dtype(Current)-1339])(Current, Result);
	RTLE;
	return Result;
}

/* {DT_DATE_VALUE}.append_to_string */
void F1339_9964 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7369[Dtype(Current)-1339])(Current, arg1);
}

/* {DT_DATE_VALUE}.append_date_to_string */
void F1339_9965 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(4972,F865_4972, (Current));
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7364[dtype-1339])(Current);
	F1013_6999(RTCW(tr1), ti4_1, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '/');
	tr1 = RTOSCF(4972,F865_4972, (Current));
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7365[dtype-1339])(Current);
	F1013_6999(RTCW(tr1), ti4_1, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '/');
	tr1 = RTOSCF(4972,F865_4972, (Current));
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7366[dtype-1339])(Current);
	F1013_6999(RTCW(tr1), ti4_1, arg1);
	RTLE;
}

void EIF_Minit523 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
