/*
 * Code for class EWG_C_TOKENS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew541.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EWG_C_TOKENS}.token_name */
EIF_REFERENCE F1357_10304 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	switch (arg1) {
		case 0L:
			Result = RTMS_EX_H("EOF token",9,451139182);
			break;
		case -1L:
			Result = RTMS_EX_H("Error token",11,1176850798);
			break;
		case 258L:
			Result = RTMS_EX_H("TOK_IDENTIFIER",14,799079250);
			break;
		case 259L:
			Result = RTMS_EX_H("TOK_CONSTANT",12,1449579092);
			break;
		case 260L:
			Result = RTMS_EX_H("TOK_STRING_LITERAL",18,882555468);
			break;
		case 261L:
			Result = RTMS_EX_H("TOK_SIZEOF",10,1827639878);
			break;
		case 262L:
			Result = RTMS_EX_H("TOK_PTR_OP",10,1689312336);
			break;
		case 263L:
			Result = RTMS_EX_H("TOK_INC_OP",10,1423845456);
			break;
		case 264L:
			Result = RTMS_EX_H("TOK_DEC_OP",10,1413945936);
			break;
		case 265L:
			Result = RTMS_EX_H("TOK_LEFT_OP",11,741646160);
			break;
		case 266L:
			Result = RTMS_EX_H("TOK_RIGHT_OP",12,568735312);
			break;
		case 267L:
			Result = RTMS_EX_H("TOK_LE_OP",9,1123098448);
			break;
		case 268L:
			Result = RTMS_EX_H("TOK_GE_OP",9,1123060048);
			break;
		case 269L:
			Result = RTMS_EX_H("TOK_EQ_OP",9,1324371280);
			break;
		case 270L:
			Result = RTMS_EX_H("TOK_NE_OP",9,1123113808);
			break;
		case 271L:
			Result = RTMS_EX_H("TOK_AND_OP",10,1424894032);
			break;
		case 272L:
			Result = RTMS_EX_H("TOK_OR_OP",9,1341225296);
			break;
		case 273L:
			Result = RTMS_EX_H("TOK_MUL_ASSIGN",14,71742542);
			break;
		case 274L:
			Result = RTMS_EX_H("TOK_DIV_ASSIGN",14,909515854);
			break;
		case 275L:
			Result = RTMS_EX_H("TOK_MOD_ASSIGN",14,1863484750);
			break;
		case 276L:
			Result = RTMS_EX_H("TOK_ADD_ASSIGN",14,409049422);
			break;
		case 277L:
			Result = RTMS_EX_H("TOK_SUB_ASSIGN",14,472253006);
			break;
		case 278L:
			Result = RTMS_EX_H("TOK_LEFT_ASSIGN",15,2095867214);
			break;
		case 279L:
			Result = RTMS_EX_H("TOK_RIGHT_ASSIGN",16,1283075918);
			break;
		case 280L:
			Result = RTMS_EX_H("TOK_AND_ASSIGN",14,998873422);
			break;
		case 281L:
			Result = RTMS_EX_H("TOK_XOR_ASSIGN",14,457723726);
			break;
		case 282L:
			Result = RTMS_EX_H("TOK_OR_ASSIGN",13,519443534);
			break;
		case 283L:
			Result = RTMS_EX_H("TOK_TYPE_NAME",13,1779688005);
			break;
		case 284L:
			Result = RTMS_EX_H("TOK_TYPEDEF",11,259186502);
			break;
		case 285L:
			Result = RTMS_EX_H("TOK_EXTERN",10,1699567438);
			break;
		case 286L:
			Result = RTMS_EX_H("TOK_STATIC",10,1409275459);
			break;
		case 287L:
			Result = RTMS_EX_H("TOK_AUTO",8,223535951);
			break;
		case 288L:
			Result = RTMS_EX_H("TOK_REGISTER",12,685456210);
			break;
		case 289L:
			Result = RTMS_EX_H("TOK_CHAR",8,256233554);
			break;
		case 290L:
			Result = RTMS_EX_H("TOK_SHORT",9,1172436052);
			break;
		case 291L:
			Result = RTMS_EX_H("TOK_INT",7,1083524180);
			break;
		case 292L:
			Result = RTMS_EX_H("TOK_LONG",8,407690567);
			break;
		case 293L:
			Result = RTMS_EX_H("TOK_SIGNED",10,1509460036);
			break;
		case 294L:
			Result = RTMS_EX_H("TOK_UNSIGNED",12,742909252);
			break;
		case 295L:
			Result = RTMS_EX_H("TOK_FLOAT",9,1239440724);
			break;
		case 296L:
			Result = RTMS_EX_H("TOK_DOUBLE",10,1714111301);
			break;
		case 297L:
			Result = RTMS_EX_H("TOK_CONST",9,1289688404);
			break;
		case 298L:
			Result = RTMS_EX_H("TOK_VOLATILE",12,1450410053);
			break;
		case 299L:
			Result = RTMS_EX_H("TOK_VOID",8,575461444);
			break;
		case 300L:
			Result = RTMS_EX_H("TOK_STRUCT",10,1694552148);
			break;
		case 301L:
			Result = RTMS_EX_H("TOK_UNION",9,1272720718);
			break;
		case 302L:
			Result = RTMS_EX_H("TOK_ENUM",8,290186317);
			break;
		case 303L:
			Result = RTMS_EX_H("TOK_ELLIPSIS",12,2017630803);
			break;
		case 304L:
			Result = RTMS_EX_H("TOK_CASE",8,255779397);
			break;
		case 305L:
			Result = RTMS_EX_H("TOK_DEFAULT",11,690650708);
			break;
		case 306L:
			Result = RTMS_EX_H("TOK_IF",6,1430293318);
			break;
		case 307L:
			Result = RTMS_EX_H("TOK_ELSE",8,290054725);
			break;
		case 308L:
			Result = RTMS_EX_H("TOK_SWITCH",10,1543514696);
			break;
		case 309L:
			Result = RTMS_EX_H("TOK_WHILE",9,1172072005);
			break;
		case 310L:
			Result = RTMS_EX_H("TOK_DO",6,1430292047);
			break;
		case 311L:
			Result = RTMS_EX_H("TOK_FOR",7,1083327826);
			break;
		case 312L:
			Result = RTMS_EX_H("TOK_GOTO",8,323806031);
			break;
		case 313L:
			Result = RTMS_EX_H("TOK_CONTINUE",12,1265891141);
			break;
		case 314L:
			Result = RTMS_EX_H("TOK_BREAK",9,1339417931);
			break;
		case 315L:
			Result = RTMS_EX_H("TOK_RETURN",10,1726029134);
			break;
		case 316L:
			Result = RTMS_EX_H("TOK_INLINE",10,1573398341);
			break;
		case 317L:
			Result = RTMS_EX_H("TOK_CL_INT_8",12,2021042232);
			break;
		case 318L:
			Result = RTMS_EX_H("TOK_CL_INT_16",13,1991655734);
			break;
		case 319L:
			Result = RTMS_EX_H("TOK_CL_INT_32",13,1991656242);
			break;
		case 320L:
			Result = RTMS_EX_H("TOK_CL_INT_64",13,1991657012);
			break;
		case 321L:
			Result = RTMS_EX_H("TOK_CL_FASTCALL",15,1526766924);
			break;
		case 322L:
			Result = RTMS_EX_H("TOK_CL_BASED",12,1802812484);
			break;
		case 323L:
			Result = RTMS_EX_H("TOK_CL_CDECL",12,1852233804);
			break;
		case 324L:
			Result = RTMS_EX_H("TOK_CL_STDCALL",14,1192324428);
			break;
		case 325L:
			Result = RTMS_EX_H("TOK_CL_INLINE",13,1856003653);
			break;
		case 326L:
			Result = RTMS_EX_H("TOK_CL_ASM",10,1879830605);
			break;
		default:
			Result = F1356_10301(Current, arg1);
			break;
	}
	RTLE;
	return Result;
}

void EIF_Minit541 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
