
#ifndef _C11_xm511_
#define _C11_xm511_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1327_9828(EIF_REFERENCE);
extern EIF_REFERENCE F1327_9829(EIF_REFERENCE);
extern EIF_BOOLEAN F1327_9832(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,9837)
static EIF_REFERENCE F1327_9837_body(EIF_REFERENCE);
extern EIF_REFERENCE F1327_9837(EIF_REFERENCE);
extern void EIF_Minit511(void);
extern void F1026_7176(EIF_REFERENCE);
extern char *(*R7253[])();

#ifdef __cplusplus
}
#endif

#endif
