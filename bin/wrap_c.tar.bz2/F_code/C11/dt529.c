/*
 * Code for class DT_DATE_TIME_VALUE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dt529.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DT_DATE_TIME_VALUE}.out */
EIF_REFERENCE F1345_10125 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F985_6612(RTCW(Result), ((EIF_INTEGER_32) 23L));
	F1345_10127(Current, Result);
	RTLE;
	return Result;
}

/* {DT_DATE_TIME_VALUE}.append_to_string */
void F1345_10127 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7369[dtype-1339])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) ' ');
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7431[dtype-1342])(Current, arg1);
	RTLE;
}

void EIF_Minit529 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
