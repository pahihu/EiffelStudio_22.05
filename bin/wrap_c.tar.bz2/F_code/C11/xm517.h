
#ifndef _C11_xm517_
#define _C11_xm517_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1333_9857(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit517(void);
extern void F1336_9908(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
