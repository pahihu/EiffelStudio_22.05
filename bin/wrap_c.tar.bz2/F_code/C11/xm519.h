
#ifndef _C11_xm519_
#define _C11_xm519_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1335_9874(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit519(void);
extern void F1336_9908(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
