
#ifndef _C11_ew507_
#define _C11_ew507_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1323_9762(EIF_REFERENCE, EIF_REFERENCE, EIF_CHARACTER_8, EIF_CHARACTER_8);
extern void F1323_9763(EIF_REFERENCE, EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit507(void);
extern char *(*R5044[])();
extern char *(*R3538[])();
extern char *(*R3772[])();

#ifdef __cplusplus
}
#endif

#endif
