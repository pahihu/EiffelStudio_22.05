/*
 * Code for class XM_COMPOSITE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm520.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_COMPOSITE}.is_empty */
EIF_BOOLEAN F1336_9880 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7338[Dtype(Current)-1335]);
	Result = F1193_8484(RTCW(tr1));
	RTLE;
	return Result;
}

/* {XM_COMPOSITE}.new_cursor */
EIF_REFERENCE F1336_9896 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7338[Dtype(Current)-1335]);
	Result = F1247_8697(RTCW(tr1));
	RTLE;
	return Result;
}

/* {XM_COMPOSITE}.new_iterator */
EIF_REFERENCE F1336_9897 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O7338[Dtype(Current)-1335]);
	Result = F1218_8539(RTCW(tr1));
	RTLE;
	return Result;
}

/* {XM_COMPOSITE}.force_last */
void F1336_9908 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\01';
	if (!F1336_9880(Current)) {
		tb1 = (EIF_BOOLEAN)((FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7309[dtype-1336])(Current) != arg1);
	}
	if (tb1) {
		F1336_9916(Current, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + O7338[dtype-1335]);
		F1249_8787(RTCW(tr1), arg1);
	}
	RTLE;
}

/* {XM_COMPOSITE}.before_addition */
void F1336_9916 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	if ((EIF_BOOLEAN)(tr1 != Current)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		F1336_9917(RTCW(tr1), arg1);
	}
	F1328_9841(RTCW(arg1), Current);
	RTLE;
}

/* {XM_COMPOSITE}.equality_delete */
void F1336_9917 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = F1336_9896(Current);
	F1119_8288(RTCW(loc1));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_3_1_);
		if (tb1) break;
		tr1 = F1167_8376(RTCW(loc1));
		if ((EIF_BOOLEAN)(tr1 == arg1)) {
			F1164_8355(RTCW(loc1));
		} else {
			F1119_8289(RTCW(loc1));
		}
	}
	RTLE;
}

void EIF_Minit520 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
