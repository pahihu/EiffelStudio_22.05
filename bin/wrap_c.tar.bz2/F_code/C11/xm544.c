/*
 * Code for class XM_EIFFEL_TOKENS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm544.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_EIFFEL_TOKENS}.token_name */
EIF_REFERENCE F1360_10454 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	switch (arg1) {
		case 0L:
			Result = RTMS_EX_H("EOF token",9,451139182);
			break;
		case -1L:
			Result = RTMS_EX_H("Error token",11,1176850798);
			break;
		case 258L:
			Result = RTMS_EX_H("NAME",4,1312902469);
			break;
		case 259L:
			Result = RTMS_EX_H("NAME_UTF8",9,1989351480);
			break;
		case 260L:
			Result = RTMS_EX_H("NMTOKEN",7,2086415182);
			break;
		case 261L:
			Result = RTMS_EX_H("NMTOKEN_UTF8",12,498575928);
			break;
		case 262L:
			Result = RTMS_EX_H("EQ",2,17745);
			break;
		case 263L:
			Result = RTMS_EX_H("SPACE",5,1347091781);
			break;
		case 264L:
			Result = RTMS_EX_H("APOS",4,1095782227);
			break;
		case 265L:
			Result = RTMS_EX_H("QUOT",4,1364545364);
			break;
		case 266L:
			Result = RTMS_EX_H("CHARDATA",8,1020623681);
			break;
		case 267L:
			Result = RTMS_EX_H("CHARDATA_UTF8",13,484183352);
			break;
		case 268L:
			Result = RTMS_EX_H("COMMENT_START",13,1983202132);
			break;
		case 269L:
			Result = RTMS_EX_H("COMMENT_END",11,1710351428);
			break;
		case 270L:
			Result = RTMS_EX_H("COMMENT_DASHDASH",16,1718001224);
			break;
		case 271L:
			Result = RTMS_EX_H("PI_START",8,1854360404);
			break;
		case 272L:
			Result = RTMS_EX_H("PI_TARGET",9,409534036);
			break;
		case 273L:
			Result = RTMS_EX_H("PI_TARGET_UTF8",14,2030603320);
			break;
		case 274L:
			Result = RTMS_EX_H("PI_END",6,1756224580);
			break;
		case 275L:
			Result = RTMS_EX_H("PI_RESERVED",11,105471556);
			break;
		case 276L:
			Result = RTMS_EX_H("XMLDECLARATION_START",20,1509077588);
			break;
		case 277L:
			Result = RTMS_EX_H("XMLDECLARATION_END",18,1816282948);
			break;
		case 278L:
			Result = RTMS_EX_H("XMLDECLARATION_VERSION",22,370394958);
			break;
		case 279L:
			Result = RTMS_EX_H("XMLDECLARATION_VERSION_10",25,1689308720);
			break;
		case 280L:
			Result = RTMS_EX_H("XMLDECLARATION_STANDALONE",25,1955084613);
			break;
		case 281L:
			Result = RTMS_EX_H("XMLDECLARATION_STANDALONE_YES",29,1470696275);
			break;
		case 282L:
			Result = RTMS_EX_H("XMLDECLARATION_STANDALONE_NO",28,1834455375);
			break;
		case 283L:
			Result = RTMS_EX_H("XMLDECLARATION_ENCODING",23,449168455);
			break;
		case 284L:
			Result = RTMS_EX_H("XMLDECLARATION_ENCODING_VALUE",29,1036614725);
			break;
		case 285L:
			Result = RTMS_EX_H("CDATA_START",11,248501332);
			break;
		case 286L:
			Result = RTMS_EX_H("CDATA_END",9,1939929924);
			break;
		case 287L:
			Result = RTMS_EX_H("DOCTYPE_START",13,175946068);
			break;
		case 288L:
			Result = RTMS_EX_H("DOCTYPE_END",11,461799748);
			break;
		case 289L:
			Result = RTMS_EX_H("DOCTYPE_DECLARATION_START",25,395018836);
			break;
		case 290L:
			Result = RTMS_EX_H("DOCTYPE_DECLARATION_END",23,1901724740);
			break;
		case 291L:
			Result = RTMS_EX_H("DOCTYPE_ELEMENT_EMPTY",21,1802183257);
			break;
		case 292L:
			Result = RTMS_EX_H("DOCTYPE_ELEMENT_ANY",19,1160078425);
			break;
		case 293L:
			Result = RTMS_EX_H("DOCTYPE_ELEMENT",15,277885012);
			break;
		case 294L:
			Result = RTMS_EX_H("DOCTYPE_ATTLIST",15,411428948);
			break;
		case 295L:
			Result = RTMS_EX_H("DOCTYPE_ENTITY",14,235723609);
			break;
		case 296L:
			Result = RTMS_EX_H("DOCTYPE_NOTATION",16,2064480846);
			break;
		case 297L:
			Result = RTMS_EX_H("DOCTYPE_GROUP_START",19,1111293268);
			break;
		case 298L:
			Result = RTMS_EX_H("DOCTYPE_GROUP_END",17,2000989764);
			break;
		case 299L:
			Result = RTMS_EX_H("DOCTYPE_GROUP_OR",16,1349993810);
			break;
		case 300L:
			Result = RTMS_EX_H("DOCTYPE_GROUP_SEQ",17,2001904977);
			break;
		case 301L:
			Result = RTMS_EX_H("DOCTYPE_GROUP_ZEROONE",21,1381138757);
			break;
		case 302L:
			Result = RTMS_EX_H("DOCTYPE_GROUP_ANY",17,2000727641);
			break;
		case 303L:
			Result = RTMS_EX_H("DOCTYPE_GROUP_ONEMORE",21,123658565);
			break;
		case 304L:
			Result = RTMS_EX_H("DOCTYPE_PCDATA",14,2135786049);
			break;
		case 305L:
			Result = RTMS_EX_H("DOCTYPE_PUBLIC",14,2103087939);
			break;
		case 306L:
			Result = RTMS_EX_H("DOCTYPE_SYSTEM",14,247273037);
			break;
		case 307L:
			Result = RTMS_EX_H("DOCTYPE_SYSTEM_UTF8",19,641087032);
			break;
		case 308L:
			Result = RTMS_EX_H("DOCTYPE_REQUIRED",16,1137490500);
			break;
		case 309L:
			Result = RTMS_EX_H("DOCTYPE_IMPLIED",15,129204292);
			break;
		case 310L:
			Result = RTMS_EX_H("DOCTYPE_FIXED",13,2140280644);
			break;
		case 311L:
			Result = RTMS_EX_H("DOCTYPE_ATT_CDATA",17,1582974273);
			break;
		case 312L:
			Result = RTMS_EX_H("DOCTYPE_ATT_ID",14,229344324);
			break;
		case 313L:
			Result = RTMS_EX_H("DOCTYPE_ATT_IDREF",17,1584130630);
			break;
		case 314L:
			Result = RTMS_EX_H("DOCTYPE_ATT_IDREFS",18,1811237459);
			break;
		case 315L:
			Result = RTMS_EX_H("DOCTYPE_ATT_ENTITY",18,1837270105);
			break;
		case 316L:
			Result = RTMS_EX_H("DOCTYPE_ATT_ENTITIES",20,287215699);
			break;
		case 317L:
			Result = RTMS_EX_H("DOCTYPE_ATT_NMTOKEN",19,376059982);
			break;
		case 318L:
			Result = RTMS_EX_H("DOCTYPE_ATT_NMTOKENS",20,1782243923);
			break;
		case 319L:
			Result = RTMS_EX_H("DOCTYPE_ATT_NOTATION",20,792546894);
			break;
		case 320L:
			Result = RTMS_EX_H("DOCTYPE_PERCENT",15,1337971796);
			break;
		case 321L:
			Result = RTMS_EX_H("DOCTYPE_PEREFERENCE",19,1581336133);
			break;
		case 322L:
			Result = RTMS_EX_H("DOCTYPE_PEREFERENCE_UTF8",24,1557334328);
			break;
		case 323L:
			Result = RTMS_EX_H("ENTITYVALUE_PEREFERENCE",23,712579909);
			break;
		case 324L:
			Result = RTMS_EX_H("ENTITYVALUE_PEREFERENCE_UTF8",28,482821176);
			break;
		case 325L:
			Result = RTMS_EX_H("DOCTYPE_IGNORE",14,143263557);
			break;
		case 326L:
			Result = RTMS_EX_H("DOCTYPE_INCLUDE",15,131856709);
			break;
		case 327L:
			Result = RTMS_EX_H("DOCTYPE_NDATA",13,2054952513);
			break;
		case 328L:
			Result = RTMS_EX_H("DOCTYPE_CONDITIONAL_START",25,1025255252);
			break;
		case 329L:
			Result = RTMS_EX_H("DOCTYPE_CONDITIONAL_END",23,694137412);
			break;
		case 330L:
			Result = RTMS_EX_H("DOCTYPE_CONDITIONAL_IGNORE",26,670954053);
			break;
		case 331L:
			Result = RTMS_EX_H("VALUE_START",11,693245012);
			break;
		case 332L:
			Result = RTMS_EX_H("VALUE_END",9,8463172);
			break;
		case 333L:
			Result = RTMS_EX_H("TAG_START",9,1503833428);
			break;
		case 334L:
			Result = RTMS_EX_H("TAG_START_END",13,1892697156);
			break;
		case 335L:
			Result = RTMS_EX_H("TAG_END_EMPTY",13,152207193);
			break;
		case 336L:
			Result = RTMS_EX_H("TAG_END",7,1055706180);
			break;
		case 337L:
			Result = RTMS_EX_H("TAG_NAME_FIRST",14,2029550420);
			break;
		case 338L:
			Result = RTMS_EX_H("TAG_NAME_FIRST_UTF8",19,1921067064);
			break;
		case 339L:
			Result = RTMS_EX_H("TAG_NAME_ATOM",13,662958157);
			break;
		case 340L:
			Result = RTMS_EX_H("TAG_NAME_ATOM_UTF8",18,156326456);
			break;
		case 341L:
			Result = RTMS_EX_H("TAG_NAME_COLON",14,2129796430);
			break;
		case 342L:
			Result = RTMS_EX_H("CONTENT_ENTITY",14,855493465);
			break;
		case 343L:
			Result = RTMS_EX_H("CONTENT_ENTITY_UTF8",19,1561443128);
			break;
		case 344L:
			Result = RTMS_EX_H("CONTENT_CONDITIONAL_END",23,1317585476);
			break;
		case 345L:
			Result = RTMS_EX_H("ATTRIBUTE_ENTITY",16,1329998681);
			break;
		case 346L:
			Result = RTMS_EX_H("ATTRIBUTE_ENTITY_UTF8",21,8405816);
			break;
		case 347L:
			Result = RTMS_EX_H("ATTRIBUTE_LT",12,1726083668);
			break;
		case 348L:
			Result = RTMS_EX_H("ENTITY_INVALID",14,81538372);
			break;
		case 349L:
			Result = RTMS_EX_H("INPUT_INVALID",13,1414269252);
			break;
		default:
			Result = F1356_10301(Current, arg1);
			break;
	}
	RTLE;
	return Result;
}

void EIF_Minit544 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
