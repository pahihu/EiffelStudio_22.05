/*
 * Code for class XM_DTD_ATTRIBUTE_CONTENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm536.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_DTD_ATTRIBUTE_CONTENT}.make */
void F1352_10252 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1352_10269(Current);
	F1352_10265(Current);
	tr1 = RTMS_EX_H("\?",1,63);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.out */
EIF_REFERENCE F1352_10253 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(6954,F1007_6954, (Current));
	tr2 = RTOSCF(6954,F1007_6954, (Current));
	tr2 = F1000_6920(RTCW(tr2), *(EIF_REFERENCE *)(Current));
	Result = F1000_6913(RTCW(tr1), tr2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) ' ');
	if (F1352_10268(Current)) {
		tr1 = RTOSCF(6954,F1007_6954, (Current));
		tr2 = RTMS_EX_H("CDATA",5,1145646657);
		tr1 = F1000_6914(RTCW(tr1), Result, tr2);
		Result = (EIF_REFERENCE) tr1;
	} else {
		if (F1352_10274(Current)) {
			tr1 = RTOSCF(6954,F1007_6954, (Current));
			tr2 = RTMS_EX_H("ID",2,18756);
			tr1 = F1000_6914(RTCW(tr1), Result, tr2);
			Result = (EIF_REFERENCE) tr1;
		} else {
			if (F1352_10276(Current)) {
				tr1 = RTOSCF(6954,F1007_6954, (Current));
				tr2 = RTMS_EX_H("IDREF",5,1146803014);
				tr1 = F1000_6914(RTCW(tr1), Result, tr2);
				Result = (EIF_REFERENCE) tr1;
			} else {
				if (F1352_10278(Current)) {
					tr1 = RTOSCF(6954,F1007_6954, (Current));
					tr2 = RTMS_EX_H("ENTITY",6,1550350425);
					tr1 = F1000_6914(RTCW(tr1), Result, tr2);
					Result = (EIF_REFERENCE) tr1;
				} else {
					if (F1352_10280(Current)) {
						tr1 = RTOSCF(6954,F1007_6954, (Current));
						tr2 = RTMS_EX_H("NMTOKEN",7,2086415182);
						tr1 = F1000_6914(RTCW(tr1), Result, tr2);
						Result = (EIF_REFERENCE) tr1;
					} else {
						if (F1352_10270(Current)) {
							tr1 = RTOSCF(6954,F1007_6954, (Current));
							tr2 = RTMS_EX_H("NOTATION",8,557597262);
							tr1 = F1000_6914(RTCW(tr1), Result, tr2);
							Result = (EIF_REFERENCE) tr1;
						} else {
							if (F1352_10272(Current)) {
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '(');
								tr1 = F1352_10284(Current);
								loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6568[Dtype(RTCW(tr1))-1228])(tr1);
								F1119_8288(RTCW(loc1));
								for (;;) {
									tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3321[Dtype(RTCW(loc1))-401])(loc1);
									if (tb1) break;
									tb2 = F1119_8285(RTCW(loc1));
									if ((EIF_BOOLEAN) !tb2) {
										(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '|');
									}
									tr1 = RTOSCF(6954,F1007_6954, (Current));
									tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3320[Dtype(RTCW(loc1))-401])(loc1);
									tr1 = F1000_6914(RTCW(tr1), Result, tr2);
									Result = (EIF_REFERENCE) tr1;
									F1119_8289(RTCW(loc1));
								}
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) ')');
							}
						}
					}
				}
			}
		}
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) 'S');
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) ' ');
	if (F1352_10262(Current)) {
		tr1 = RTOSCF(6954,F1007_6954, (Current));
		tr2 = RTMS_EX_H("#REQUIRED",9,1694990916);
		tr1 = F1000_6914(RTCW(tr1), Result, tr2);
		Result = (EIF_REFERENCE) tr1;
	} else {
		if (F1352_10264(Current)) {
			tr1 = RTOSCF(6954,F1007_6954, (Current));
			tr2 = RTMS_EX_H("#IMPLIED",8,1674883140);
			tr1 = F1000_6914(RTCW(tr1), Result, tr2);
			Result = (EIF_REFERENCE) tr1;
		} else {
			if (F1352_10266(Current)) {
				tr1 = RTOSCF(6954,F1007_6954, (Current));
				tr2 = RTMS_EX_H("#FIXED ",7,2055359008);
				tr1 = F1000_6914(RTCW(tr1), Result, tr2);
				Result = (EIF_REFERENCE) tr1;
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) ' ');
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '\"');
		tr1 = RTOSCF(6954,F1007_6954, (Current));
		tr1 = F1000_6914(RTCW(tr1), Result, loc2);
		Result = (EIF_REFERENCE) tr1;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(Result))-986])(Result, (EIF_CHARACTER_8) '\"');
	}
	RTLE;
	return Result;
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.set_name */
void F1352_10255 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.set_default_value */
void F1352_10259 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_1_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'D';
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.has_default_value */
EIF_BOOLEAN F1352_10260 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL);
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.copy_default */
void F1352_10261 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tb1 = F1352_10266(RTCW(arg1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		F1352_10267(Current, tr1);
	} else {
		tb1 = F1352_10260(RTCW(arg1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			F1352_10259(Current, tr1);
		}
	}
	tb1 = F1352_10262(RTCW(arg1));
	if (tb1) {
		F1352_10263(Current);
	} else {
		tb1 = F1352_10264(RTCW(arg1));
		if (tb1) {
			F1352_10265(Current);
		}
	}
	RTLE;
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.is_value_required */
EIF_BOOLEAN F1352_10262 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_1_);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_8) 'R');
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.set_value_required */
void F1352_10263 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_1_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'R';
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.is_value_implied */
EIF_BOOLEAN F1352_10264 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_1_) == (EIF_CHARACTER_8) 'I');
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.set_value_implied */
void F1352_10265 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_1_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'I';
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.is_value_fixed */
EIF_BOOLEAN F1352_10266 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_1_) == (EIF_CHARACTER_8) 'F');
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.set_value_fixed */
void F1352_10267 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1352_10259(Current, arg1);
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_1_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'F';
	RTLE;
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.is_data */
EIF_BOOLEAN F1352_10268 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) == (EIF_CHARACTER_8) 'C');
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.set_data */
void F1352_10269 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'C';
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.is_notation */
EIF_BOOLEAN F1352_10270 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) == (EIF_CHARACTER_8) 'N');
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.set_notation */
void F1352_10271 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'N';
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.is_enumeration */
EIF_BOOLEAN F1352_10272 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) == (EIF_CHARACTER_8) 'U');
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.set_enumeration */
void F1352_10273 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'U';
	tr1 = RTOSCF(10287,F1352_10287, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.is_id */
EIF_BOOLEAN F1352_10274 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) == (EIF_CHARACTER_8) 'I');
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.set_id */
void F1352_10275 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'I';
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.is_id_ref */
EIF_BOOLEAN F1352_10276 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) == (EIF_CHARACTER_8) 'R');
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.set_id_ref */
void F1352_10277 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'R';
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.is_entity */
EIF_BOOLEAN F1352_10278 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) == (EIF_CHARACTER_8) 'E');
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.set_entity */
void F1352_10279 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'E';
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.is_token */
EIF_BOOLEAN F1352_10280 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) == (EIF_CHARACTER_8) 'T');
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.set_token */
void F1352_10281 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_3_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'T';
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.set_list_type */
void F1352_10283 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.enumeration */
EIF_REFERENCE F1352_10284 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("is_enumeration", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc1;
	RTLE;
	return Result;
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.set_enumeration_list */
void F1352_10285 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F1352_10273(Current);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {XM_DTD_ATTRIBUTE_CONTENT}.default_enumeration_list */
static EIF_REFERENCE F1352_10287_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (10287);
#define Result RTOSR(10287)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1246,0xFF01,986,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1246, _OBJSIZ_4_0_0_1_0_0_0_0_);
	}
	F1247_8688(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10287);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1352_10287 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10287,F1352_10287_body,(Current));
}

void EIF_Minit536 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
