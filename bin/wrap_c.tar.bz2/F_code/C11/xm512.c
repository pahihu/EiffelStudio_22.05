/*
 * Code for class XM_COMPOSITE_NODE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm512.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_COMPOSITE_NODE}.parent */
EIF_REFERENCE F1328_9839 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current);
}


/* {XM_COMPOSITE_NODE}.node_set_parent */
void F1328_9841 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

void EIF_Minit512 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
