/*
 * Code for class EWG_C_AST_TYPE_SET
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew534.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EWG_C_AST_TYPE_SET}.make */
void F1350_10202 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1275,0xFF01,1039,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1269_9027(RTCW(tr1), ((EIF_INTEGER_32) 20000L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = RTOSCF(1931,F173_1931, (Current));
	F1212_8536(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1286,0xFF01,1057,0xFF01,986,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1277_9185(RTCW(tr1), ((EIF_INTEGER_32) 6000L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOSCF(1932,F173_1932, (Current));
	F1212_8536(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOSCF(4734,F840_4734, (Current));
	F1277_9203(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1286,0xFF01,1059,0xFF01,986,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1277_9185(RTCW(tr1), ((EIF_INTEGER_32) 6000L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tr2 = RTOSCF(1933,F173_1933, (Current));
	F1212_8536(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tr2 = RTOSCF(4734,F840_4734, (Current));
	F1277_9203(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1286,0xFF01,1058,0xFF01,986,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1277_9185(RTCW(tr1), ((EIF_INTEGER_32) 6000L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tr2 = RTOSCF(1934,F173_1934, (Current));
	F1212_8536(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tr2 = RTOSCF(4734,F840_4734, (Current));
	F1277_9203(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1286,0xFF01,1041,0xFF01,986,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1277_9185(RTCW(tr1), ((EIF_INTEGER_32) 6000L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr2 = RTOSCF(1935,F173_1935, (Current));
	F1212_8536(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tr2 = RTOSCF(4734,F840_4734, (Current));
	F1277_9203(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1286,0xFF01,1046,0xFF01,986,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1277_9185(RTCW(tr1), ((EIF_INTEGER_32) 6000L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	tr2 = RTOSCF(1936,F173_1936, (Current));
	F1212_8536(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	tr2 = RTOSCF(4734,F840_4734, (Current));
	F1277_9203(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1286,0xFF01,1055,0xFF01,986,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1277_9185(RTCW(tr1), ((EIF_INTEGER_32) 6000L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	tr2 = RTOSCF(1937,F173_1937, (Current));
	F1212_8536(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	tr2 = RTOSCF(4734,F840_4734, (Current));
	F1277_9203(RTCW(tr1), tr2);
	F1350_10203(Current);
	RTLE;
}

/* {EWG_C_AST_TYPE_SET}.add_common_types */
void F1350_10203 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1041, 1).id);
	tr2 = RTMS_EX_H("void",4,1987012964);
	tr3 = RTMS_EX_H("void_needs_no_header.h",22,1458328424);
	F1040_7283(RTCW(tr1), tr2, tr3);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F1350_10230(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
	tr1 = RTLNSMART(eif_new_type(1053, 1).id);
	tr2 = RTMS_EX_H("void_pointer_needs_no_header.h",30,741177960);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1054_7464(RTCW(tr1), tr2, tr3);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	F1350_10230(Current, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	tr1 = RTLNSMART(eif_new_type(1041, 1).id);
	tr2 = RTMS_EX_H("float",5,1820022132);
	tr3 = RTMS_EX_H("float_needs_no_header.h",23,958914152);
	F1040_7283(RTCW(tr1), tr2, tr3);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	F1350_10230(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_));
	tr1 = RTLNSMART(eif_new_type(1044, 1).id);
	tr2 = RTMS_EX_H("const_float_needs_no_header.h",29,1403412328);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1045_7378(RTCW(tr1), tr2, tr3);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	F1350_10230(Current, *(EIF_REFERENCE *)(Current + _REFACS_4_));
	tr1 = RTLNSMART(eif_new_type(1041, 1).id);
	tr2 = RTMS_EX_H("double",6,19365221);
	tr3 = RTMS_EX_H("double_needs_no_header.h",24,658516072);
	F1040_7283(RTCW(tr1), tr2, tr3);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	F1350_10230(Current, *(EIF_REFERENCE *)(Current + _REFACS_5_));
	tr1 = RTLNSMART(eif_new_type(1044, 1).id);
	tr2 = RTMS_EX_H("const_double_needs_no_header.h",30,633619304);
	tr3 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1045_7378(RTCW(tr1), tr2, tr3);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	F1350_10230(Current, *(EIF_REFERENCE *)(Current + _REFACS_6_));
	RTLE;
}

/* {EWG_C_AST_TYPE_SET}.find_struct_by_name */
EIF_REFERENCE F1350_10206 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tb1 = F1277_9198(RTCW(tr1), arg1);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		Result = F1277_9190(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

/* {EWG_C_AST_TYPE_SET}.find_enum_by_name */
EIF_REFERENCE F1350_10207 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	tb1 = F1277_9198(RTCW(tr1), arg1);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		Result = F1277_9190(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

/* {EWG_C_AST_TYPE_SET}.find_union_by_name */
EIF_REFERENCE F1350_10208 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	tb1 = F1277_9198(RTCW(tr1), arg1);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
		Result = F1277_9190(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

/* {EWG_C_AST_TYPE_SET}.find_primitive_by_name */
EIF_REFERENCE F1350_10209 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	tb1 = F1277_9198(RTCW(tr1), arg1);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		Result = F1277_9190(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

/* {EWG_C_AST_TYPE_SET}.find_alias_by_name */
EIF_REFERENCE F1350_10210 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	tb1 = F1277_9198(RTCW(tr1), arg1);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
		Result = F1277_9190(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

/* {EWG_C_AST_TYPE_SET}.find_function_by_name */
EIF_REFERENCE F1350_10211 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	tb1 = F1277_9198(RTCW(tr1), arg1);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
		Result = F1277_9190(RTCW(tr1), arg1);
	}
	RTLE;
	return Result;
}

/* {EWG_C_AST_TYPE_SET}.count */
EIF_INTEGER_32 F1350_10212 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_7_0_0_8_);
	RTLE;
	return Result;
}

/* {EWG_C_AST_TYPE_SET}.new_cursor */
EIF_REFERENCE F1350_10213 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	Result = F1276_9178(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EWG_C_AST_TYPE_SET}.new_alias_cursor */
EIF_REFERENCE F1350_10214 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	Result = F1287_9262(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EWG_C_AST_TYPE_SET}.alias_types_count */
EIF_INTEGER_32 F1350_10215 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_11_0_0_8_);
	RTLE;
	return Result;
}

/* {EWG_C_AST_TYPE_SET}.add_type */
void F1350_10230 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,loc8);
	RTLR(11,loc9);
	RTLR(12,loc10);
	RTLR(13,loc11);
	RTLIU(14);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1274_9127(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tb1 = F1269_9036(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tr1 = F1269_9028(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		F1274_9133(RTCW(tr1), arg1);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			loc2 = arg1;
			loc2 = RTRV(eif_new_type(1057, 0x01),loc2);
			if (EIF_TEST(loc2)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
				F1277_9210(RTCW(tr1), loc2, loc1);
			} else {
				loc3 = arg1;
				loc3 = RTRV(eif_new_type(1059, 0x01),loc3);
				if (EIF_TEST(loc3)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
					F1277_9210(RTCW(tr1), loc3, loc1);
				} else {
					loc4 = arg1;
					loc4 = RTRV(eif_new_type(1058, 0x01),loc4);
					if (EIF_TEST(loc4)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
						F1277_9210(RTCW(tr1), loc4, loc1);
					} else {
						loc5 = arg1;
						loc5 = RTRV(eif_new_type(1041, 0x01),loc5);
						if (EIF_TEST(loc5)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
							F1277_9210(RTCW(tr1), loc5, loc1);
						} else {
							loc6 = arg1;
							loc6 = RTRV(eif_new_type(1046, 0x01),loc6);
							if (EIF_TEST(loc6)) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
								F1277_9210(RTCW(tr1), loc6, loc1);
							} else {
								loc7 = arg1;
								loc7 = RTRV(eif_new_type(1045, 0x01),loc7);
								if (EIF_TEST(loc7)) {
								} else {
									loc8 = arg1;
									loc8 = RTRV(eif_new_type(1044, 0x01),loc8);
									if (EIF_TEST(loc8)) {
									} else {
										loc9 = arg1;
										loc9 = RTRV(eif_new_type(1053, 0x01),loc9);
										if (EIF_TEST(loc9)) {
										} else {
											loc10 = arg1;
											loc10 = RTRV(eif_new_type(1055, 0x01),loc10);
											if (EIF_TEST(loc10)) {
												tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
												F1277_9210(RTCW(tr1), loc10, loc1);
											} else {
												loc11 = arg1;
												loc11 = RTRV(eif_new_type(1042, 0x01),loc11);
												if (EIF_TEST(loc11)) {
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	RTLE;
}

void EIF_Minit534 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
