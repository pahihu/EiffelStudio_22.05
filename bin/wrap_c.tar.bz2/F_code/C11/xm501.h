
#ifndef _C11_xm501_
#define _C11_xm501_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1317_9698(EIF_REFERENCE);
extern void F1317_9703(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit501(void);
extern EIF_REFERENCE F1000_6914(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1007_6954(EIF_REFERENCE);
extern EIF_REFERENCE F11_93(EIF_REFERENCE);
extern EIF_REFERENCE F313_2884(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,93)
RTOSHF(EIF_REFERENCE,2884)
RTOSHF(EIF_REFERENCE,6954)
extern char *(*R1088[])();
extern char *(*R5586[])();
extern long O7146[];
extern long O7148[];

#ifdef __cplusplus
}
#endif

#endif
