/*
 * Code for class XM_CANONICAL_PRETTY_PRINT_FILTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm504.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_CANONICAL_PRETTY_PRINT_FILTER}.on_comment */
void F1320_9740 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2185[Dtype(RTCW(tr1))-212])(tr1, arg1);
	RTLE;
}

/* {XM_CANONICAL_PRETTY_PRINT_FILTER}.is_escaped */
EIF_BOOLEAN F1320_9741 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	tb2 = '\01';
	tb3 = '\01';
	tb4 = '\01';
	tb5 = '\01';
	ti4_1 = (EIF_INTEGER_32) ((EIF_CHARACTER_8) '<');
	if (!(EIF_BOOLEAN)(arg1 == ti4_1)) {
		ti4_1 = (EIF_INTEGER_32) ((EIF_CHARACTER_8) '>');
		tb5 = (EIF_BOOLEAN)(arg1 == ti4_1);
	}
	if (!tb5) {
		ti4_1 = (EIF_INTEGER_32) ((EIF_CHARACTER_8) '&');
		tb4 = (EIF_BOOLEAN)(arg1 == ti4_1);
	}
	if (!tb4) {
		tb3 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 9L));
	}
	if (!tb3) {
		tb2 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 10L));
	}
	if (!tb2) {
		tb1 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 13L));
	}
	if (!tb1) {
		ti4_1 = (EIF_INTEGER_32) ((EIF_CHARACTER_8) '\"');
		Result = (EIF_BOOLEAN)(arg1 == ti4_1);
	}
	return Result;
}

/* {XM_CANONICAL_PRETTY_PRINT_FILTER}.escaped_char */
EIF_REFERENCE F1320_9742 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) ((EIF_CHARACTER_8) '\"');
	if ((EIF_BOOLEAN)(arg1 == ti4_1)) {
		RTLE;
		return (EIF_REFERENCE) RTOSCF(3802,F409_3802, (Current));
	} else {
		RTLE;
		return (EIF_REFERENCE) F1318_9718(Current, arg1);
	}/* NOTREACHED */
	
}

void EIF_Minit504 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
