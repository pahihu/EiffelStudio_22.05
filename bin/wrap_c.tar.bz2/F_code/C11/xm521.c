/*
 * Code for class XM_ELEMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm521.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_ELEMENT}.make */
void F1337_9921 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg3;
	tr1 = RTLNSMART(eif_final_id(Y7338,Y7338_gen_type,Dftype(Current),1335).id);
	F1247_8688(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_ELEMENT}.make_last */
void F1337_9922 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg3;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	tr1 = RTLNSMART(eif_final_id(Y7338,Y7338_gen_type,Dftype(Current),1335).id);
	F1247_8688(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	F1336_9908(RTCW(arg1), Current);
	RTLE;
}

/* {XM_ELEMENT}.make_root */
void F1337_9923 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg3;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	tr1 = RTLNSMART(eif_final_id(Y7338,Y7338_gen_type,Dftype(Current),1335).id);
	F1247_8688(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	F1338_9950(RTCW(arg1), Current);
	RTLE;
}

/* {XM_ELEMENT}.has_attribute_by_name */
EIF_BOOLEAN F1337_9926 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	loc1 = F1336_9896(Current);
	F1119_8288(RTCW(loc1));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3321[Dtype(RTCW(loc1))-401])(loc1);
		if (tb1) break;
		tb2 = '\0';
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3320[Dtype(RTCW(loc1))-401])(loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(1334, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			tb2 = F1337_9927(Current, loc2, arg1);
		}
		if (tb2) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F1119_8291(RTCW(loc1));
		} else {
			F1119_8289(RTCW(loc1));
		}
	}
	RTLE;
	return Result;
}

/* {XM_ELEMENT}.attribute_same_name */
EIF_BOOLEAN F1337_9927 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	if (F208_2293(Current, tr1, arg2)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
		Result = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
	}
	RTLE;
	return Result;
}

/* {XM_ELEMENT}.named_same_name */
EIF_BOOLEAN F1337_9928 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	if (F208_2293(Current, tr1, arg2)) {
		Result = F1334_9864(Current, arg1);
	}
	RTLE;
	return Result;
}

/* {XM_ELEMENT}.element_by_name */
EIF_REFERENCE F1337_9931 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	loc1 = F1336_9896(Current);
	F1119_8288(RTCW(loc1));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3321[Dtype(RTCW(loc1))-401])(loc1);
		if (tb1) break;
		tb2 = '\0';
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3320[Dtype(RTCW(loc1))-401])(loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(1336, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			tb2 = F1337_9928(Current, loc2, arg1);
		}
		if (tb2) {
			Result = (EIF_REFERENCE) loc2;
			F1119_8291(RTCW(loc1));
		} else {
			F1119_8289(RTCW(loc1));
		}
	}
	RTLE;
	return Result;
}

/* {XM_ELEMENT}.last */
EIF_REFERENCE F1337_9933 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = F1247_8696(RTCW(tr1));
	RTLE;
	return Result;
}

/* {XM_ELEMENT}.attribute_by_name */
EIF_REFERENCE F1337_9934 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	loc1 = F1336_9896(Current);
	F1119_8288(RTCW(loc1));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R3321[Dtype(RTCW(loc1))-401])(loc1);
		if (tb1) break;
		tb2 = '\0';
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3320[Dtype(RTCW(loc1))-401])(loc1);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(1334, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			tb2 = F1337_9927(Current, loc2, arg1);
		}
		if (tb2) {
			Result = (EIF_REFERENCE) loc2;
			F1119_8291(RTCW(loc1));
		} else {
			F1119_8289(RTCW(loc1));
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit521 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
