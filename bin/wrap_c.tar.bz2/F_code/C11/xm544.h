
#ifndef _C11_xm544_
#define _C11_xm544_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1360_10454(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit544(void);
extern EIF_REFERENCE F1356_10301(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
