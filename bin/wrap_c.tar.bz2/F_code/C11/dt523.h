
#ifndef _C11_dt523_
#define _C11_dt523_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1339_9962(EIF_REFERENCE);
extern void F1339_9964(EIF_REFERENCE, EIF_REFERENCE);
extern void F1339_9965(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit523(void);
extern void F1013_6999(EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE);
extern void F985_6612(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F865_4972(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,4972)
extern char *(*R5187[])();
extern char *(*R7364[])();
extern char *(*R7365[])();
extern char *(*R7366[])();
extern char *(*R7368[])();
extern char *(*R7369[])();

#ifdef __cplusplus
}
#endif

#endif
