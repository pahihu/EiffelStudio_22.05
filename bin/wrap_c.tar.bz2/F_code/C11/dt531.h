
#ifndef _C11_dt531_
#define _C11_dt531_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1347_10165(EIF_REFERENCE);
extern EIF_BOOLEAN F1347_10171(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit531(void);

#ifdef __cplusplus
}
#endif

#endif
