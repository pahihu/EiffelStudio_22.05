
#ifndef _C11_dt529_
#define _C11_dt529_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1345_10125(EIF_REFERENCE);
extern void F1345_10127(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit529(void);
extern void F985_6612(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R5187[])();
extern char *(*R7431[])();
extern char *(*R7369[])();

#ifdef __cplusplus
}
#endif

#endif
