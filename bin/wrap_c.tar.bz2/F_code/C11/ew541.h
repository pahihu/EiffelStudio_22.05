
#ifndef _C11_ew541_
#define _C11_ew541_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1357_10304(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit541(void);
extern EIF_REFERENCE F1356_10301(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
