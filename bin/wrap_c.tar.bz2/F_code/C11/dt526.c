/*
 * Code for class DT_TIME_VALUE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dt526.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DT_TIME_VALUE}.out */
EIF_REFERENCE F1342_10038 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(986, 0x01).id, 986, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F985_6612(RTCW(Result), ((EIF_INTEGER_32) 12L));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7430[Dtype(Current)-1342])(Current, Result);
	RTLE;
	return Result;
}

/* {DT_TIME_VALUE}.append_to_string */
void F1342_10042 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7431[Dtype(Current)-1342])(Current, arg1);
}

/* {DT_TIME_VALUE}.append_time_to_string */
void F1342_10043 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(4972,F865_4972, (Current));
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7423[dtype-1342])(Current);
	F1013_6999(RTCW(tr1), ti4_1, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) ':');
	tr1 = RTOSCF(4972,F865_4972, (Current));
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7424[dtype-1342])(Current);
	F1013_6999(RTCW(tr1), ti4_1, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) ':');
	tr1 = RTOSCF(4972,F865_4972, (Current));
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7425[dtype-1342])(Current);
	F1013_6999(RTCW(tr1), ti4_1, arg1);
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7426[dtype-1342])(Current);
	if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '.');
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '-');
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) -loc1;
		}
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 10L))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '0');
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '0');
		} else {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 100L))) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5187[Dtype(RTCW(arg1))-986])(arg1, (EIF_CHARACTER_8) '0');
			}
		}
		tr1 = RTOSCF(4972,F865_4972, (Current));
		F1013_6999(RTCW(tr1), loc1, arg1);
	}
	RTLE;
}

void EIF_Minit526 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
