
#ifndef _C11_xm518_
#define _C11_xm518_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1334_9864(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit518(void);
extern EIF_BOOLEAN F1026_7179(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
