/*
 * Code for class XM_XMLNS_GENERATOR_CONTEXT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm532.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_XMLNS_GENERATOR_CONTEXT}.make */
void F1348_10174 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1249,0xFF01,1286,0xFF01,986,0xFF01,986,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1247_8692(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1275,0xFF01,986,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1269_9027(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTOSCF(2292,F207_2292, (Current));
	F1212_8536(RTCW(tr1), tr2);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1260,0xFF01,986,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1261_8884(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTOSCF(3807,F409_3807, (Current));
	F1261_8893(RTCW(tr1), tr2);
	RTLE;
}

/* {XM_XMLNS_GENERATOR_CONTEXT}.is_same_as_default */
EIF_BOOLEAN F1348_10176 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(6954,F1007_6954, (Current));
	tr2 = *(EIF_REFERENCE *)(Current);
	tr2 = F1261_8887(RTCW(tr2));
	Result = F1000_6906(RTCW(tr1), arg1, tr2);
	RTLE;
	return Result;
}

/* {XM_XMLNS_GENERATOR_CONTEXT}.set_default */
void F1348_10177 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F1261_8894(RTCW(tr1), arg1);
	RTLE;
}

/* {XM_XMLNS_GENERATOR_CONTEXT}.has */
EIF_BOOLEAN F1348_10181 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = F1250_8798(RTCW(tr1));
	F1126_8299(RTCW(loc1));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6399[Dtype(RTCW(loc1))-1130])(loc1);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3320[Dtype(RTCW(loc1))-401])(loc1);
		Result = F1277_9198(RTCW(tr1), arg1);
		if (Result) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3320[Dtype(RTCW(loc1))-401])(loc1);
			tr1 = F1277_9190(RTCW(tr1), arg1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
			F1126_8302(RTCW(loc1));
		} else {
			F1126_8300(RTCW(loc1));
		}
	}
	RTLE;
	return Result;
}

/* {XM_XMLNS_GENERATOR_CONTEXT}.item */
EIF_REFERENCE F1348_10182 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if (F1348_10181(Current, arg1)) {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_3_);
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {XM_XMLNS_GENERATOR_CONTEXT}.new_element_cursor */
EIF_REFERENCE F1348_10183 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = F1247_8696(RTCW(tr1));
	Result = F1287_9262(RTCW(tr1));
	RTLE;
	return Result;
}

/* {XM_XMLNS_GENERATOR_CONTEXT}.force */
void F1348_10184 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = F1247_8696(RTCW(tr1));
	F1277_9210(RTCW(tr1), arg1, arg2);
	RTLE;
}

/* {XM_XMLNS_GENERATOR_CONTEXT}.element_has_prefix */
EIF_BOOLEAN F1348_10185 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	Result = F1274_9123(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {XM_XMLNS_GENERATOR_CONTEXT}.element_prefix */
void F1348_10186 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1274_9132(RTCW(tr1), arg1);
	RTLE;
}

/* {XM_XMLNS_GENERATOR_CONTEXT}.on_start_element */
void F1348_10187 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1286,0xFF01,986,0xFF01,986,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 1286, _OBJSIZ_11_0_0_9_0_0_0_0_);
	}
	F1277_9187(RTCW(loc1));
	tr1 = RTOSCF(2292,F207_2292, (Current));
	F1277_9203(RTCW(loc1), tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1247_8715(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1269_9050(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = *(EIF_REFERENCE *)(Current);
	tr2 = F1261_8887(RTCW(tr2));
	F1261_8893(RTCW(tr1), tr2);
	RTLE;
}

/* {XM_XMLNS_GENERATOR_CONTEXT}.on_end_element */
void F1348_10188 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1250_8803(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current);
	F1261_8897(RTCW(tr1));
	RTLE;
}

void EIF_Minit532 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
