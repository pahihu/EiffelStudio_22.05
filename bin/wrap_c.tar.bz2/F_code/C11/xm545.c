/*
 * Code for class XM_EIFFEL_SCANNER_SKELETON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm545.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_EIFFEL_SCANNER_SKELETON}.make_scanner */
void F1361_10547 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1008, 1).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(7824,F1082_7824, (Current));
	F1083_7839(Current, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5946[Dtype(Current)-1361])(Current);
	RTLE;
}

/* {XM_EIFFEL_SCANNER_SKELETON}.reset */
void F1361_10548 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1084_7919(Current);
	tr1 = RTMS_EX_H("-",1,45);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) tr1;
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {XM_EIFFEL_SCANNER_SKELETON}.push_start_condition_dtd_ignore */
void F1361_10549 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1083_7858(Current, ((EIF_INTEGER_32) 17L));
}

/* {XM_EIFFEL_SCANNER_SKELETON}.set_input_buffer */
void F1361_10550 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1083_7871(Current, arg1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2105[Dtype(RTCW(arg1))-199])(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_EIFFEL_SCANNER_SKELETON}.set_input_stream */
void F1361_10551 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) arg1;
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) NULL;
	loc1 = RTLNSMART(eif_new_type(1017, 0).id);
	F1018_7047(RTCW(loc1), arg1);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) loc1;
	tr1 = F1082_7818(Current, loc1);
	F1361_10550(Current, tr1);
	RTLE;
}

/* {XM_EIFFEL_SCANNER_SKELETON}.set_input_from_resolver */
void F1361_10552 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	RTCT0("a_resolver_resolved", EX_CHECK);
	{
		/* INLINED CODE (XM_EXTERNAL_RESOLVER.last_stream) */
		tr1 = (EIF_REFERENCE)  0;
		(void) RTCW(arg1);
		/* END INLINED CODE */
	}
	tr1 = tr1;
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	F1361_10551(Current, loc1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {XM_EIFFEL_SCANNER_SKELETON}.close_input */
void F1361_10553 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1854[Dtype(loc1)-1009])(loc1);
			if (tb1) {
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R1861[Dtype(loc1)-1009])(loc1);
			}
			{
				/* INLINED CODE (XM_EXTERNAL_RESOLVER.resolve_finish) */
				(void) loc2;
				/* END INLINED CODE */
			}
			;
		}
		*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) NULL;
		*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {XM_EIFFEL_SCANNER_SKELETON}.is_applicable_encoding */
EIF_BOOLEAN F1361_10557 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	RTCT0("filter_set", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = '\0';
	tb1 = F1018_7048(loc1, arg1);
	if (tb1) {
		tb1 = F1018_7049(loc1, arg1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_SCANNER_SKELETON}.set_encoding */
void F1361_10558 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	RTCT0("filter_set", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	F1018_7050(loc1, arg1);
	RTLE;
}

/* {XM_EIFFEL_SCANNER_SKELETON}.fatal_error */
void F1361_10565 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) arg1;
}

/* {XM_EIFFEL_SCANNER_SKELETON}.report_invalid_unicode_character_error */
void F1361_10566 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("Surrogate or invalid Unicode character \'\\u{",43,1170503291);
	tr2 = RTLNS(eif_new_type(918, 0x00).id, 918, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr2 = arg1;
	tr2 = F917_5754(RTCW(tr2));
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5149[Dtype(tr1)-985])(tr1, tr2);
	tr2 = RTMS_EX_H("}\'",2,32039);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R5149[Dtype(RTCW(tr1))-985])(tr1, tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_EIFFEL_SCANNER_SKELETON}.error_position */
EIF_REFERENCE F1361_10567 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1105, 0x01).id, 1105, _OBJSIZ_1_0_0_3_0_0_0_0_);
	F1106_8263(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_20_), *(EIF_INTEGER_32 *)(Current + O6059[dtype-1082]), *(EIF_INTEGER_32 *)(Current + O6060[dtype-1082]), *(EIF_INTEGER_32 *)(Current + O6061[dtype-1082]));
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_EIFFEL_SCANNER_SKELETON}.system_literal_text */
EIF_REFERENCE F1361_10571 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	ti4_1 = F1083_7852(Current);
	loc2 = F1083_7846(Current, ti4_1);
	loc1 = F1083_7852(Current);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN)(F1083_7846(Current, loc1) == loc2)) break;
		loc1--;
	}
	ti4_1 = F1083_7852(Current);
	Result = F1083_7848(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
	RTLE;
	return Result;
}

/* {XM_EIFFEL_SCANNER_SKELETON}.normalized_newline */
static EIF_REFERENCE F1361_10573_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (10573);
#define Result RTOSR(10573)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("\012",1,10);
	RTOSE (10573);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1361_10573 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10573,F1361_10573_body,(Current));
}

/* {XM_EIFFEL_SCANNER_SKELETON}.has_normalized_newline */
EIF_BOOLEAN F1361_10574 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {XM_EIFFEL_SCANNER_SKELETON}.normalized_space */

EIF_REFERENCE F1361_10575 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10575,RTMS_EX_H(" ",1,32));
}

/* {XM_EIFFEL_SCANNER_SKELETON}.two_normalized_spaces */

EIF_REFERENCE F1361_10576 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (10576,RTMS_EX_H("  ",2,8224));
}

void EIF_Minit545 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
