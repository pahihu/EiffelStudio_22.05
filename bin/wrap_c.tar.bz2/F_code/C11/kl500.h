
#ifndef _C11_kl500_
#define _C11_kl500_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_CHARACTER_8,9694)
static EIF_CHARACTER_8 F1316_9694_body(EIF_REFERENCE);
extern EIF_CHARACTER_8 F1316_9694(EIF_REFERENCE);
extern void EIF_Minit500(void);

#ifdef __cplusplus
}
#endif

#endif
