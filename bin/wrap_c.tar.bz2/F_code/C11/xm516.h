
#ifndef _C11_xm516_
#define _C11_xm516_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1332_9851(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1332_9852(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit516(void);
extern void F1336_9908(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
