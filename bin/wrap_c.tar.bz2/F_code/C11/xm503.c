/*
 * Code for class XM_INDENT_PRETTY_PRINT_FILTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm503.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_INDENT_PRETTY_PRINT_FILTER}.initialize */
void F1319_9723 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(9726,F1319_9726, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1266,939,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1267_8916(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	{
		/* INLINED CODE (XM_INDENT_PRETTY_PRINT_FILTER.default_space_preserve) */
		tb1 = (EIF_BOOLEAN)  0;
		/* END INLINED CODE */
	}
	tb2 = tb1;
	F1267_8927(RTCW(tr1), tb2);
	RTLE;
}

/* {XM_INDENT_PRETTY_PRINT_FILTER}.default_indent */

EIF_REFERENCE F1319_9726 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (9726,RTMS_EX_H(" ",1,32));
}

/* {XM_INDENT_PRETTY_PRINT_FILTER}.on_start */
void F1319_9727 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1266,939,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1267_8916(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	{
		/* INLINED CODE (XM_INDENT_PRETTY_PRINT_FILTER.default_space_preserve) */
		tb1 = (EIF_BOOLEAN)  0;
		/* END INLINED CODE */
	}
	tb2 = tb1;
	F1267_8927(RTCW(tr1), tb2);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F214_2339(Current);
	RTLE;
}

/* {XM_INDENT_PRETTY_PRINT_FILTER}.on_start_tag */
void F1319_9728 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	F1318_9716(Current);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_3_)) {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_4_)) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_5_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			F1319_9739(Current);
		}
		F1319_9738(Current);
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_0_))++;
	F1318_9706(Current, arg1, arg2, arg3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tb1 = F1267_8919(RTCW(tr2));
	F1267_8927(RTCW(tr1), tb1);
	RTLE;
}

/* {XM_INDENT_PRETTY_PRINT_FILTER}.on_attribute */
void F1319_9729 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg2);
	RTLR(1,arg3);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,arg4);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTGC;
	if (F1319_9734(Current, arg2, arg3)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1267_8931(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr2 = RTOSCF(6954,F1007_6954, (Current));
		tr3 = RTOSCF(3811,F409_3811, (Current));
		tb1 = F1000_6906(RTCW(tr2), tr3, arg4);
		F1267_8927(RTCW(tr1), tb1);
	}
	F1318_9707(Current, arg1, arg2, arg3, arg4);
	RTLE;
}

/* {XM_INDENT_PRETTY_PRINT_FILTER}.on_end_tag */
void F1319_9730 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_0_))--;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_1_) && *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_))) {
		F1318_9709(Current, arg1, arg2, arg3);
	} else {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_5_3_)) {
			F1319_9739(Current);
			F1319_9738(Current);
		}
		F1318_9709(Current, arg1, arg2, arg3);
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1267_8931(RTCW(tr1));
	RTLE;
}

/* {XM_INDENT_PRETTY_PRINT_FILTER}.on_content */
void F1319_9731 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F1318_9710(Current, arg1);
	RTLE;
}

/* {XM_INDENT_PRETTY_PRINT_FILTER}.has_xml_space */
EIF_BOOLEAN F1319_9734 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = F212_2320(Current, arg1);
	}
	if (tb2) {
		tr1 = RTOSCF(6954,F1007_6954, (Current));
		tr2 = RTOSCF(3809,F409_3809, (Current));
		tb2 = F1000_6906(RTCW(tr1), tr2, arg1);
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = RTOSCF(6954,F1007_6954, (Current));
		tr2 = RTOSCF(3810,F409_3810, (Current));
		tb1 = F1000_6906(RTCW(tr1), tr2, arg2);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {XM_INDENT_PRETTY_PRINT_FILTER}.default_space_preserve */
EIF_BOOLEAN F1319_9736 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {XM_INDENT_PRETTY_PRINT_FILTER}.output_indent */
void F1319_9738 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tb1 = F1267_8919(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_5_5_0_0_))) break;
			F1317_9703(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_));
			loc1++;
		}
	}
	RTLE;
}

/* {XM_INDENT_PRETTY_PRINT_FILTER}.output_indent_new_line */
void F1319_9739 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tb1 = F1267_8919(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(3789,F409_3789, (Current));
		F1317_9703(Current, tr1);
	}
	RTLE;
}

void EIF_Minit503 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
