
#ifndef _C11_dt526_
#define _C11_dt526_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1342_10038(EIF_REFERENCE);
extern void F1342_10042(EIF_REFERENCE, EIF_REFERENCE);
extern void F1342_10043(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit526(void);
extern void F1013_6999(EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE);
extern void F985_6612(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F865_4972(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,4972)
extern char *(*R7423[])();
extern char *(*R7424[])();
extern char *(*R7425[])();
extern char *(*R7426[])();
extern char *(*R5187[])();
extern char *(*R7430[])();
extern char *(*R7431[])();

#ifdef __cplusplus
}
#endif

#endif
