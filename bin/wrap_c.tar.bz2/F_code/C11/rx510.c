/*
 * Code for class RX_REGULAR_EXPRESSION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "rx510.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RX_REGULAR_EXPRESSION}.append_replacement_to_string */
void F1326_9817 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc5 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4960[Dtype(RTCW(arg2))-982])(arg2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc3)) break;
		loc5 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4923[Dtype(RTCW(arg2))-982])(arg2, loc1);
		if ((EIF_BOOLEAN)(loc5 == ((EIF_NATURAL_32) 92U))) {
			loc1++;
			loc2 = (EIF_INTEGER_32) loc1;
			loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			for (;;) {
				tb1 = '\01';
				if (!(EIF_BOOLEAN) (loc1 > loc3)) {
					tb2 = '\01';
					tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4923[Dtype(RTCW(arg2))-982])(arg2, loc1);
					if (!(EIF_BOOLEAN) (tu4_1 < ((EIF_NATURAL_32) 48U))) {
						tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4923[Dtype(RTCW(arg2))-982])(arg2, loc1);
						tb2 = (EIF_BOOLEAN) (tu4_1 > ((EIF_NATURAL_32) 57U));
					}
					tb1 = tb2;
				}
				if (tb1) break;
				loc5 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4923[Dtype(RTCW(arg2))-982])(arg2, loc1);
				ti4_1 = (EIF_INTEGER_32) (EIF_NATURAL_32) (loc5 - ((EIF_NATURAL_32) 48U));
				loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 * ((EIF_INTEGER_32) 10L)) + ti4_1);
				loc1++;
			}
			if ((EIF_BOOLEAN) (loc1 <= loc3)) {
				loc5 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4923[Dtype(RTCW(arg2))-982])(arg2, loc1);
				if ((EIF_BOOLEAN)(loc5 == ((EIF_NATURAL_32) 92U))) {
					if ((EIF_BOOLEAN) (loc1 > loc2)) {
						if ((EIF_BOOLEAN) (loc4 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_3_))) {
							F1325_9807(Current, arg1, loc4);
						}
					} else {
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R5020[Dtype(RTCW(arg1))-983])(arg1, loc5);
					}
					loc1++;
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R5020[Dtype(RTCW(arg1))-983])(arg1, ((EIF_NATURAL_32) 92U));
					loc1 = (EIF_INTEGER_32) loc2;
				}
			} else {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R5020[Dtype(RTCW(arg1))-983])(arg1, ((EIF_NATURAL_32) 92U));
				loc1 = (EIF_INTEGER_32) loc2;
			}
		} else {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R5020[Dtype(RTCW(arg1))-983])(arg1, loc5);
			loc1++;
		}
	}
	RTLE;
}

/* {RX_REGULAR_EXPRESSION}.replace_all */
EIF_REFERENCE F1326_9821 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	RTCT0("precodition", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc3 = tr1;
	loc3 = RTRV(eif_new_type(986, 0x01),loc3);
	if (EIF_TEST(loc3)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = RTOSCF(6954,F1007_6954, (Current));
	Result = F1000_6897(RTCW(tr1), loc3, (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_) - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_1_)) + ((EIF_INTEGER_32) 1L)));
	F1326_9823(Current, Result, arg1);
	RTLE;
	return Result;
}

/* {RX_REGULAR_EXPRESSION}.append_replace_all_to_string */
void F1326_9823 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) !F1325_9792(Current)) break;
		loc2 = F1421_11732(Current, ((EIF_INTEGER_32) 0L));
		loc3 = F1421_11733(Current, ((EIF_INTEGER_32) 0L));
		tr1 = RTOSCF(6954,F1007_6954, (Current));
		F1000_6917(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_1_), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
		F1326_9817(Current, arg1, arg2);
		if ((EIF_BOOLEAN) (loc2 > loc3)) {
			if ((EIF_BOOLEAN) (loc2 <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_))) {
				tr1 = *(EIF_REFERENCE *)(Current);
				tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4923[Dtype(RTCW(tr1))-982])(tr1, loc2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_NATURAL_32)) R5020[Dtype(RTCW(arg1))-983])(arg1, tu4_1);
				loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				F1421_11735(Current, *(EIF_REFERENCE *)(Current), loc4, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_));
			} else {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_1_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_) + ((EIF_INTEGER_32) 1L));
			}
		} else {
			loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
			F1421_11735(Current, *(EIF_REFERENCE *)(Current), loc4, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_));
		}
	}
	tr1 = RTOSCF(6954,F1007_6954, (Current));
	F1000_6917(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_1_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_1_) = (EIF_INTEGER_32) loc1;
	RTLE;
}

void EIF_Minit510 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
