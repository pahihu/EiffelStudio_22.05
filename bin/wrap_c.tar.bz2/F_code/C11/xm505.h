
#ifndef _C11_xm505_
#define _C11_xm505_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,9745)
static EIF_REFERENCE F1321_9745_body(EIF_REFERENCE);
extern EIF_REFERENCE F1321_9745(EIF_REFERENCE);
extern void EIF_Minit505(void);

#ifdef __cplusplus
}
#endif

#endif
