/*
 * Code for class EWG_C_SCANNER_SKELETON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew542.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EWG_C_SCANNER_SKELETON}.make */
void F1358_10374 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1082_7768(Current);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) arg1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1261,939,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {EWG_C_SCANNER_SKELETON}.enable_msc_extensions */
void F1358_10378 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_65_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EWG_C_SCANNER_SKELETON}.read_token */
void F1358_10379 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_5_2_0_2_);
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O6059[dtype-1082]) - ti4_1) > ((EIF_INTEGER_32) 20L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
		F1375_11160(RTCW(tr1), *(EIF_INTEGER_32 *)(Current + O6059[dtype-1082]));
	}
	F1084_7920(Current);
	RTLE;
}

/* {EWG_C_SCANNER_SKELETON}.print_last_token */
void F1358_10380 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(94,F11_94, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
	tr2 = RTMS_EX_H("Last token code: ",17,1619278880);
	F1036_7265(RTCW(tr1), tr2);
	tr1 = RTOSCF(94,F11_94, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
	F1032_7240(RTCW(tr1), *(EIF_INTEGER_32 *)(Current + O5950[dtype-1081]));
	tr1 = RTOSCF(94,F11_94, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
	tr2 = RTMS_EX_H(" / ",3,2109216);
	F1036_7265(RTCW(tr1), tr2);
	tr1 = RTOSCF(94,F11_94, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
	tr2 = F1357_10304(Current, *(EIF_INTEGER_32 *)(Current + O5950[dtype-1081]));
	F1036_7265(RTCW(tr1), tr2);
	tr1 = RTOSCF(94,F11_94, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
	tr2 = RTMS_EX_H(" / ",3,2109216);
	F1036_7265(RTCW(tr1), tr2);
	switch (*(EIF_INTEGER_32 *)(Current + O5950[dtype-1081])) {
		case 0L:
			tr1 = RTOSCF(94,F11_94, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
			tr2 = RTMS_EX_H("EOF token",9,451139182);
			F1036_7265(RTCW(tr1), tr2);
			break;
		case -1L:
			tr1 = RTOSCF(94,F11_94, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
			tr2 = RTMS_EX_H("Error token",11,1176850798);
			F1036_7265(RTCW(tr1), tr2);
			break;
		case -2L:
			tr1 = RTOSCF(94,F11_94, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
			tr2 = RTMS_EX_H("Unknown token",13,1896573550);
			F1036_7265(RTCW(tr1), tr2);
			break;
		default:
			tr1 = RTOSCF(94,F11_94, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
			F1036_7264(RTCW(tr1), (EIF_CHARACTER_8) '\"');
			tr1 = RTOSCF(94,F11_94, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
			tr2 = F1083_7843(Current);
			F1036_7265(RTCW(tr1), tr2);
			tr1 = RTOSCF(94,F11_94, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
			tr2 = RTMS_EX_H("\"",1,34);
			F1036_7265(RTCW(tr1), tr2);
			break;
	}
	tr1 = RTOSCF(94,F11_94, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
	tr2 = RTMS_EX_H(" [",2,8283);
	F1036_7265(RTCW(tr1), tr2);
	tr1 = RTOSCF(94,F11_94, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
	F1032_7240(RTCW(tr1), *(EIF_INTEGER_32 *)(Current + O6061[dtype-1082]));
	tr1 = RTOSCF(94,F11_94, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
	tr2 = RTMS_EX_H(",",1,44);
	F1036_7265(RTCW(tr1), tr2);
	tr1 = RTOSCF(94,F11_94, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
	F1032_7240(RTCW(tr1), *(EIF_INTEGER_32 *)(Current + O6060[dtype-1082]));
	tr1 = RTOSCF(94,F11_94, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
	tr2 = RTMS_EX_H("]",1,93);
	F1036_7265(RTCW(tr1), tr2);
	tr1 = RTOSCF(94,F11_94, (RTCV(RTOSCF(2884,F313_2884, (Current)))));
	tr2 = RTMS_EX_H("\012",1,10);
	F1036_7265(RTCW(tr1), tr2);
	RTLE;
}

/* {EWG_C_SCANNER_SKELETON}.is_type_name_reporting_enabled */
EIF_BOOLEAN F1358_10381 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	tb2 = F1194_8484(RTCW(tr1));
	if (!tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
		tb2 = F1262_8887(RTCW(tr1));
		tb1 = (EIF_BOOLEAN)(tb2 == (EIF_BOOLEAN) 1);
	}
	if (tb1) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {EWG_C_SCANNER_SKELETON}.set_header_line_number */
void F1358_10390 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_65_5_0_21_) = (EIF_INTEGER_32) arg1;
}

/* {EWG_C_SCANNER_SKELETON}.set_header_file_name */
void F1358_10391 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(9266,F1292_9266, (Current));
	tr2 = RTOSCF(9269,F1292_9269, (Current));
	tr1 = F1312_9604(RTCW(tr1), arg1, tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {EWG_C_SCANNER_SKELETON}.report_type_or_identifier */
void F1358_10392 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\0';
	if (F1358_10381(Current)) {
		tb1 = F1368_10785(Current, arg1);
	}
	if (tb1) {
		*(EIF_INTEGER_32 *)(Current + O5950[dtype-1081]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 283L);
	} else {
		*(EIF_INTEGER_32 *)(Current + O5950[dtype-1081]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 258L);
	}
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {EWG_C_SCANNER_SKELETON}.push_reporting_type_name_scope */
void F1358_10393 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1262_8892(RTCW(tr1), (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EWG_C_SCANNER_SKELETON}.pop_type_name_scope */
void F1358_10395 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1262_8897(RTCW(tr1));
	RTLE;
}

/* {EWG_C_SCANNER_SKELETON}.disable_type_name_reporting_for_this_scope */
void F1358_10396 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	F1262_8894(RTCW(tr1), (EIF_BOOLEAN) 0);
	RTLE;
}

/* {EWG_C_SCANNER_SKELETON}.enable_implementation_mode */
void F1358_10398 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1083_7857(Current, ((EIF_INTEGER_32) 2L));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_65_5_0_22_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {EWG_C_SCANNER_SKELETON}.disable_implementation_mode */
void F1358_10399 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1083_7857(Current, ((EIF_INTEGER_32) 0L));
}

void EIF_Minit542 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
