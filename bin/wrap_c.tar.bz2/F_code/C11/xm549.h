
#ifndef _C11_xm549_
#define _C11_xm549_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1365_10692(EIF_REFERENCE);
extern void F1365_10693(EIF_REFERENCE);
extern void F1365_10694(EIF_REFERENCE);
extern void EIF_Minit549(void);
extern void F1082_7806(EIF_REFERENCE);
extern EIF_BOOLEAN F1082_7791(EIF_REFERENCE);
extern void F1364_10691(EIF_REFERENCE);
extern void F1364_10690(EIF_REFERENCE);
extern EIF_REFERENCE F1361_10575(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,10575)

#ifdef __cplusplus
}
#endif

#endif
