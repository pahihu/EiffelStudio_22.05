
#ifndef _C11_uc535_
#define _C11_uc535_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1351_10246(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F1351_10247(EIF_REFERENCE, EIF_NATURAL_32);
extern void EIF_Minit535(void);

#ifdef __cplusplus
}
#endif

#endif
