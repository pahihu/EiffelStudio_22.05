/*
 * Code for class RX_PATTERN_MATCHER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "rx509.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RX_PATTERN_MATCHER}.wipe_out */
void F1325_9789 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = RTOSCF(9814,F1325_9814, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {RX_PATTERN_MATCHER}.has_matched */
EIF_BOOLEAN F1325_9792 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_12_16_0_3_) > ((EIF_INTEGER_32) 0L));
}

/* {RX_PATTERN_MATCHER}.recognizes */
EIF_BOOLEAN F1325_9796 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1325_9808(Current, arg1);
	if (F1325_9792(Current)) {
		Result = '\0';
		if ((EIF_BOOLEAN)(F1421_11732(Current, ((EIF_INTEGER_32) 0L)) == ((EIF_INTEGER_32) 1L))) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4960[Dtype(RTCW(arg1))-982])(arg1);
			Result = (EIF_BOOLEAN)(F1421_11733(Current, ((EIF_INTEGER_32) 0L)) == ti4_1);
		}
	}
	RTLE;
	return Result;
}

/* {RX_PATTERN_MATCHER}.append_captured_substring_to_string */
void F1325_9807 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = F1421_11732(Current, arg2);
	loc2 = F1421_11733(Current, arg2);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc1 >= ((EIF_INTEGER_32) 1L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4960[Dtype(RTCW(tr1))-982])(tr1);
		tb1 = (EIF_BOOLEAN) (loc2 <= ti4_1);
	}
	if (tb1) {
		tr1 = RTOSCF(6954,F1007_6954, (Current));
		F1000_6917(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current), loc1, loc2);
	}
	RTLE;
}

/* {RX_PATTERN_MATCHER}.match */
void F1325_9808 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4960[Dtype(RTCW(arg1))-982])(arg1);
	F1421_11734(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
	RTLE;
}

/* {RX_PATTERN_MATCHER}.set_subject */
void F1325_9813 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {RX_PATTERN_MATCHER}.no_subject */

EIF_REFERENCE F1325_9814 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (9814,RTMS_EX_H("",0,0));
}

void EIF_Minit509 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
