/*
 * Code for class XM_PRETTY_PRINT_FILTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm502.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_PRETTY_PRINT_FILTER}.on_processing_instruction */
void F1318_9704 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(3784,F409_3784, (Current));
	F1318_9719(Current, tr1);
	F1317_9703(Current, arg1);
	tr1 = RTOSCF(3786,F409_3786, (Current));
	F1318_9719(Current, tr1);
	F1317_9703(Current, arg2);
	tr1 = RTOSCF(3785,F409_3785, (Current));
	F1318_9719(Current, tr1);
	*(EIF_BOOLEAN *)(Current + O7153[Dtype(Current)-1317]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F214_2343(Current, arg1, arg2);
	RTLE;
}

/* {XM_PRETTY_PRINT_FILTER}.on_comment */
void F1318_9705 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(3805,F409_3805, (Current));
	F1318_9719(Current, tr1);
	F1317_9703(Current, arg1);
	tr1 = RTOSCF(3806,F409_3806, (Current));
	F1318_9719(Current, tr1);
	*(EIF_BOOLEAN *)(Current + O7153[Dtype(Current)-1317]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F214_2344(Current, arg1);
	RTLE;
}

/* {XM_PRETTY_PRINT_FILTER}.on_start_tag */
void F1318_9706 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	F1318_9716(Current);
	tr1 = RTOSCF(3778,F409_3778, (Current));
	F1318_9719(Current, tr1);
	F1318_9722(Current, arg2, arg3);
	*(EIF_BOOLEAN *)(Current + O7153[Dtype(Current)-1317]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F214_2345(Current, arg1, arg2, arg3);
	RTLE;
}

/* {XM_PRETTY_PRINT_FILTER}.on_attribute */
void F1318_9707 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	F1318_9716(Current);
	tr1 = RTOSCF(3786,F409_3786, (Current));
	F1318_9719(Current, tr1);
	F1318_9722(Current, arg2, arg3);
	tr1 = RTOSCF(3787,F409_3787, (Current));
	F1318_9719(Current, tr1);
	tr1 = RTOSCF(3788,F409_3788, (Current));
	F1318_9719(Current, tr1);
	F1318_9720(Current, arg4);
	tr1 = RTOSCF(3788,F409_3788, (Current));
	F1318_9719(Current, tr1);
	*(EIF_BOOLEAN *)(Current + O7153[Dtype(Current)-1317]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F214_2346(Current, arg1, arg2, arg3, arg4);
	RTLE;
}

/* {XM_PRETTY_PRINT_FILTER}.on_start_tag_finish */
void F1318_9708 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O7150[dtype-1317])) {
		*(EIF_BOOLEAN *)(Current + O7154[dtype-1317]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tr1 = RTOSCF(3779,F409_3779, (Current));
		F1318_9719(Current, tr1);
	}
	*(EIF_BOOLEAN *)(Current + O7153[dtype-1317]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F214_2347(Current);
	RTLE;
}

/* {XM_PRETTY_PRINT_FILTER}.on_end_tag */
void F1318_9709 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7153[dtype-1317]) && *(EIF_BOOLEAN *)(Current + O7150[dtype-1317]))) {
		tr1 = RTOSCF(3783,F409_3783, (Current));
		F1318_9719(Current, tr1);
		*(EIF_BOOLEAN *)(Current + O7154[dtype-1317]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		tr1 = RTOSCF(3780,F409_3780, (Current));
		F1318_9719(Current, tr1);
		F1318_9722(Current, arg2, arg3);
		tr1 = RTOSCF(3781,F409_3781, (Current));
		F1318_9719(Current, tr1);
	}
	*(EIF_BOOLEAN *)(Current + O7153[dtype-1317]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F214_2348(Current, arg1, arg2, arg3);
	RTLE;
}

/* {XM_PRETTY_PRINT_FILTER}.on_content */
void F1318_9710 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F1318_9716(Current);
	F1318_9721(Current, arg1);
	*(EIF_BOOLEAN *)(Current + O7153[Dtype(Current)-1317]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F214_2349(Current, arg1);
	RTLE;
}

/* {XM_PRETTY_PRINT_FILTER}.flush_pending_tag_end */
void F1318_9716 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O7154[dtype-1317])) {
		tr1 = RTOSCF(3779,F409_3779, (Current));
		F1318_9719(Current, tr1);
		*(EIF_BOOLEAN *)(Current + O7154[dtype-1317]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

/* {XM_PRETTY_PRINT_FILTER}.is_escaped */
EIF_BOOLEAN F1318_9717 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	tb2 = '\01';
	ti4_1 = (EIF_INTEGER_32) ((EIF_CHARACTER_8) '<');
	if (!(EIF_BOOLEAN)(arg1 == ti4_1)) {
		ti4_1 = (EIF_INTEGER_32) ((EIF_CHARACTER_8) '>');
		tb2 = (EIF_BOOLEAN)(arg1 == ti4_1);
	}
	if (!tb2) {
		ti4_1 = (EIF_INTEGER_32) ((EIF_CHARACTER_8) '&');
		tb1 = (EIF_BOOLEAN)(arg1 == ti4_1);
	}
	if (!tb1) {
		Result = (EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 128L));
	}
	return Result;
}

/* {XM_PRETTY_PRINT_FILTER}.escaped_char */
EIF_REFERENCE F1318_9718 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) ((EIF_CHARACTER_8) '<');
	if ((EIF_BOOLEAN)(arg1 == ti4_1)) {
		RTLE;
		return (EIF_REFERENCE) RTOSCF(3799,F409_3799, (Current));
	} else {
		ti4_1 = (EIF_INTEGER_32) ((EIF_CHARACTER_8) '>');
		if ((EIF_BOOLEAN)(arg1 == ti4_1)) {
			Result = RTOSCF(3800,F409_3800, (Current));
		} else {
			ti4_1 = (EIF_INTEGER_32) ((EIF_CHARACTER_8) '&');
			if ((EIF_BOOLEAN)(arg1 == ti4_1)) {
				Result = RTOSCF(3801,F409_3801, (Current));
				RTLE;
				return (EIF_REFERENCE) Result;
			} else {
				tr1 = RTOSCF(6954,F1007_6954, (Current));
				tr2 = RTMS_EX_H("&#",2,9763);
				tr3 = eif_out__i4_s1(arg1);
				Result = F1000_6904(RTCW(tr1), tr2, tr3);
				tr1 = RTOSCF(6954,F1007_6954, (Current));
				tr2 = RTMS_EX_H(";",1,59);
				tr1 = F1000_6904(RTCW(tr1), Result, tr2);
				Result = (EIF_REFERENCE) tr1;
			}
		}
	}
	RTLE;
	return Result;
}

/* {XM_PRETTY_PRINT_FILTER}.output_constant */
void F1318_9719 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1317_9703(Current, arg1);
}

/* {XM_PRETTY_PRINT_FILTER}.output_quote_escaped */
void F1318_9720 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5135[Dtype(RTCW(arg1))-986])(arg1, loc2);
		ti4_2 = (EIF_INTEGER_32) ((EIF_CHARACTER_8) '\"');
		if ((EIF_BOOLEAN)(ti4_1 == ti4_2)) {
			if ((EIF_BOOLEAN) (loc1 < (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)))) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5001[Dtype(RTCW(arg1))-982])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
				F1318_9721(Current, tr1);
			}
			tr1 = RTOSCF(3802,F409_3802, (Current));
			F1318_9719(Current, tr1);
			loc1 = (EIF_INTEGER_32) loc2;
		}
		loc2++;
	}
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
		F1318_9721(Current, arg1);
	} else {
		if ((EIF_BOOLEAN) (loc1 < (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)))) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5001[Dtype(RTCW(arg1))-982])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
			F1318_9721(Current, tr1);
		}
	}
	RTLE;
}

/* {XM_PRETTY_PRINT_FILTER}.output_escaped */
void F1318_9721 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R5135[Dtype(RTCW(arg1))-986])(arg1, loc2);
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R7156[dtype-1317])(Current, loc4)) {
			if ((EIF_BOOLEAN) (loc1 < (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)))) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5001[Dtype(RTCW(arg1))-982])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
				F1317_9703(Current, tr1);
			}
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R7157[dtype-1317])(Current, loc4);
			F1318_9719(Current, tr1);
			loc1 = (EIF_INTEGER_32) loc2;
		}
		loc2++;
	}
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
		F1317_9703(Current, arg1);
	} else {
		if ((EIF_BOOLEAN) (loc1 < (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)))) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R5001[Dtype(RTCW(arg1))-982])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
			F1317_9703(Current, tr1);
		}
	}
	RTLE;
}

/* {XM_PRETTY_PRINT_FILTER}.output_name */
void F1318_9722 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb1 = F212_2320(Current, arg1);
	}
	if (tb1) {
		F1317_9703(Current, arg1);
		tr1 = RTOSCF(3790,F409_3790, (Current));
		F1318_9719(Current, tr1);
	}
	F1317_9703(Current, arg2);
	RTLE;
}

void EIF_Minit502 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
