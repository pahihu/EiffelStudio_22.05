/*
 * Code for class XM_NODE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm511.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_NODE}.parent */
EIF_REFERENCE F1327_9828 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {XM_NODE}.parent_element */
EIF_REFERENCE F1327_9829 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("attached {XM_ELEMENT} parent as l_element", EX_CHECK);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7253[Dtype(Current)-1330])(Current);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1336, 0x01),loc2);
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc2;
	RTLE;
	return Result;
}

/* {XM_NODE}.is_root_node */
EIF_BOOLEAN F1327_9832 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R7253[Dtype(Current)-1330])(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == NULL);
	RTLE;
	return Result;
}

/* {XM_NODE}.default_ns */
static EIF_REFERENCE F1327_9837_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (9837);
#define Result RTOSR(9837)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1025, 0x01).id, 1025, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1026_7176(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9837);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1327_9837 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9837,F1327_9837_body,(Current));
}

void EIF_Minit511 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
