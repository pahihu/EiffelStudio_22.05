/*
 * Code for class DT_TIME_DURATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dt527.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DT_TIME_DURATION}.hour */
EIF_INTEGER_32 F1343_10051 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O7460[Dtype(Current)-1342]);
}


/* {DT_TIME_DURATION}.minute */
EIF_INTEGER_32 F1343_10052 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O7459[Dtype(Current)-1342]);
}


/* {DT_TIME_DURATION}.second */
EIF_INTEGER_32 F1343_10053 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O7458[Dtype(Current)-1342]);
}


/* {DT_TIME_DURATION}.millisecond */
EIF_INTEGER_32 F1343_10054 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O7457[Dtype(Current)-1342]);
}


/* {DT_TIME_DURATION}.millisecond_count */
EIF_INTEGER_32 F1343_10056 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O7460[dtype-1342]) * ((EIF_INTEGER_32) 60L)) + *(EIF_INTEGER_32 *)(Current + O7459[dtype-1342])) * ((EIF_INTEGER_32) 60L)) + *(EIF_INTEGER_32 *)(Current + O7458[dtype-1342])) * ((EIF_INTEGER_32) 1000L)) + *(EIF_INTEGER_32 *)(Current + O7457[dtype-1342]));
}

/* {DT_TIME_DURATION}.hash_code */
EIF_INTEGER_32 F1343_10057 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F1343_10056(Current);
	if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) -(EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	}
	RTLE;
	return Result;
}

/* {DT_TIME_DURATION}.is_equal */
EIF_BOOLEAN F1343_10076 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(6778,F989_6778, (Current));
	tb1 = F13_114(RTCW(tr1), Current, arg1);
	if (tb1) {
		RTLE;
		return (EIF_BOOLEAN) F1343_10077(Current, arg1);
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {DT_TIME_DURATION}.same_time_duration */
EIF_BOOLEAN F1343_10077 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = F1343_10056(Current);
	ti4_2 = F1343_10056(RTCW(arg1));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTLE;
	return Result;
}

void EIF_Minit527 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
