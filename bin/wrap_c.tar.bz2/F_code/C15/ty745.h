
#ifndef _C15_ty745_
#define _C15_ty745_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F448_3922(EIF_REFERENCE);
extern void EIF_Minit745(void);
extern char *(*R3455[])();
extern char *(*R3772[])();
extern char *(*R3468[])();

#ifdef __cplusplus
}
#endif

#endif
