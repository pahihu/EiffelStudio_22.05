
#ifndef _C15_ds734_
#define _C15_ds734_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1288_9262(EIF_REFERENCE);
extern EIF_INTEGER_32 F1288_9265(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit734(void);
extern void F1142_8314(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4044[])();
extern EIF_TYPE_INDEX Y1616[];
extern EIF_TYPE_INDEX *Y1616_gen_type [];
extern EIF_TYPE_INDEX Y6545[];
extern EIF_TYPE_INDEX *Y6545_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
