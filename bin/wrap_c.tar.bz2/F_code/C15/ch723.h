
#ifndef _C15_ch723_
#define _C15_ch723_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F791_4642(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F791_4645(EIF_REFERENCE);
extern EIF_BOOLEAN F791_4650(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit723(void);
extern char *(*R3548[])();
extern char *(*R3550[])();
extern char *(*R3562[])();
extern char *(*R3879[])();
extern char *(*R3542[])();

#ifdef __cplusplus
}
#endif

#endif
