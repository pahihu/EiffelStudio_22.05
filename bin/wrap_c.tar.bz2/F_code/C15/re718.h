
#ifndef _C15_re718_
#define _C15_re718_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F697_4126(EIF_REFERENCE);
extern void F697_4128(EIF_REFERENCE);
extern void EIF_Minit718(void);
extern char *(*R3565[])();
extern char *(*R3571[])();

#ifdef __cplusplus
}
#endif

#endif
