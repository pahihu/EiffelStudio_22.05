
#ifndef _C15_ar731_
#define _C15_ar731_

#ifdef __cplusplus
extern "C" {
#endif

extern void F490_3982(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F490_3983(EIF_REFERENCE);
extern EIF_REFERENCE F490_3984(EIF_REFERENCE);
extern EIF_REFERENCE F490_3986(EIF_REFERENCE);
extern EIF_INTEGER_32 F490_3987(EIF_REFERENCE);
extern void EIF_Minit731(void);
extern EIF_INTEGER_32 F844_4792(EIF_REFERENCE);
extern EIF_REFERENCE F844_4773(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y3323[];
extern EIF_TYPE_INDEX *Y3323_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
