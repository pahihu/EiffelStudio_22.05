
#ifndef _C15_ge739_
#define _C15_ge739_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F479_3962(EIF_REFERENCE);
extern EIF_INTEGER_32 F479_3964(EIF_REFERENCE);
extern EIF_BOOLEAN F479_3971(EIF_REFERENCE);
extern void F479_3976(EIF_REFERENCE);
extern void F479_3977(EIF_REFERENCE);
extern EIF_REFERENCE F479_3978(EIF_REFERENCE);
extern void EIF_Minit739(void);
extern char *(*R3483[])();
extern char *(*R3456[])();
extern long O3482[];
extern long O3484[];

#ifdef __cplusplus
}
#endif

#endif
