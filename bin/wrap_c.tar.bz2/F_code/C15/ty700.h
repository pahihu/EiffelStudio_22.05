
#ifndef _C15_ty700_
#define _C15_ty700_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F447_3922(EIF_REFERENCE);
extern void EIF_Minit700(void);
extern char *(*R3455[])();
extern char *(*R3772[])();
extern char *(*R3468[])();

#ifdef __cplusplus
}
#endif

#endif
