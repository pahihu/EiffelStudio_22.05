
#ifndef _C15_re740_
#define _C15_re740_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F737_4485(EIF_REFERENCE);
extern void EIF_Minit740(void);
extern void F460_3928(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R3467[])();
extern EIF_TYPE_INDEX Y3399[];
extern EIF_TYPE_INDEX *Y3399_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
