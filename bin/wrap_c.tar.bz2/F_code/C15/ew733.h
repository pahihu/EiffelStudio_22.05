
#ifndef _C15_ew733_
#define _C15_ew733_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F310_2881(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit733(void);
extern char *(*R5643[])();

#ifdef __cplusplus
}
#endif

#endif
