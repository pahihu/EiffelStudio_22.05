/*
 * Code for class reference POINTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "po336.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {POINTER}.hash_code */
EIF_INTEGER_32 F972_6257 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F941_6231(Current);
}

/* {POINTER}.is_default_pointer */
EIF_BOOLEAN F972_6258 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F941_6236(Current);
}

/* {POINTER}.plus */
EIF_POINTER F972_6259 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_POINTER) F941_6237(Current, arg1);
}

/* {POINTER}.out */
EIF_REFERENCE F972_6261 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F941_6248(Current);
}

void EIF_Minit336 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
