
#ifndef _C7_re319_
#define _C7_re319_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F926_5988(EIF_REFERENCE);
extern EIF_BOOLEAN F926_5999(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F926_6000(EIF_REFERENCE, EIF_REFERENCE);
extern void F926_6001(EIF_REFERENCE, EIF_REAL_32);
extern EIF_INTEGER_32 F926_6010(EIF_REFERENCE);
extern EIF_REFERENCE F926_6027(EIF_REFERENCE);
extern void EIF_Minit319(void);
extern char *(*R4711[])();

#ifdef __cplusplus
}
#endif

#endif
