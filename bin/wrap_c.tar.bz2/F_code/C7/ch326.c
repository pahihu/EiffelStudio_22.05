/*
 * Code for class CHARACTER_32
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ch326.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CHARACTER_32}.code */
EIF_INTEGER_32 F934_6156 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = (EIF_INTEGER_32) F934_6157(Current);
	RTLE;
	return Result;
}

/* {CHARACTER_32}.natural_32_code */
EIF_NATURAL_32 F934_6157 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_NATURAL_32) F932_6122(Current);
}

/* {CHARACTER_32}.to_character_8 */
EIF_CHARACTER_8 F934_6158 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_CHARACTER_8) F932_6137(Current);
}

void EIF_Minit326 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
