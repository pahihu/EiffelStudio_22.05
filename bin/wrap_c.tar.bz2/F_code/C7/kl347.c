/*
 * Code for class KL_IMPORTED_ANY_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl347.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_IMPORTED_ANY_ROUTINES}.any_ */
static EIF_REFERENCE F989_6778_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6778);
#define Result RTOSR(6778)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(12, 0x01).id, 12, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6778);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F989_6778 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6778,F989_6778_body,(Current));
}

void EIF_Minit347 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
