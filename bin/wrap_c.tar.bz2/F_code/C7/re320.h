
#ifndef _C7_re320_
#define _C7_re320_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F928_6029(EIF_REFERENCE, EIF_REAL_32);
extern EIF_INTEGER_32 F928_6033(EIF_REFERENCE);
extern EIF_REFERENCE F928_6052(EIF_REFERENCE);
extern void EIF_Minit320(void);
extern EIF_INTEGER_32 F926_6010(EIF_REFERENCE);
extern EIF_REFERENCE F926_6027(EIF_REFERENCE);
extern EIF_BOOLEAN F926_5999(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
