
#ifndef _C7_st339_
#define _C7_st339_

#ifdef __cplusplus
extern "C" {
#endif

extern void F981_6413(EIF_REFERENCE);
extern void F981_6415(EIF_REFERENCE, EIF_NATURAL_32);
extern void F981_6426(EIF_REFERENCE, EIF_REFERENCE);
extern void F981_6438(EIF_REFERENCE);
extern void EIF_Minit339(void);
extern char *(*R5016[])();
extern char *(*R5019[])();
extern char *(*R5020[])();
extern char *(*R4960[])();
extern char *(*R4961[])();
extern char *(*R4923[])();
extern char *(*R5041[])();
extern char *(*R5042[])();
extern char *(*R5049[])();
extern long O5013[];
extern long O5014[];

#ifdef __cplusplus
}
#endif

#endif
