
#ifndef _C7_ch330_
#define _C7_ch330_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F936_6207(EIF_REFERENCE);
extern EIF_CHARACTER_32 F936_6208(EIF_REFERENCE);
extern void EIF_Minit330(void);
extern EIF_NATURAL_32 F935_6161(EIF_REFERENCE);
extern EIF_CHARACTER_32 F935_6178(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
