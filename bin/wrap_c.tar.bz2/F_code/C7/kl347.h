
#ifndef _C7_kl347_
#define _C7_kl347_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,6778)
static EIF_REFERENCE F989_6778_body(EIF_REFERENCE);
extern EIF_REFERENCE F989_6778(EIF_REFERENCE);
extern void EIF_Minit347(void);

#ifdef __cplusplus
}
#endif

#endif
