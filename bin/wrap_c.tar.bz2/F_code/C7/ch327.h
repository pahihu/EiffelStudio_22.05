
#ifndef _C7_ch327_
#define _C7_ch327_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F933_6156(EIF_REFERENCE);
extern EIF_NATURAL_32 F933_6157(EIF_REFERENCE);
extern EIF_CHARACTER_8 F933_6158(EIF_REFERENCE);
extern void EIF_Minit327(void);
extern EIF_NATURAL_32 F932_6122(EIF_REFERENCE);
extern EIF_CHARACTER_8 F932_6137(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
