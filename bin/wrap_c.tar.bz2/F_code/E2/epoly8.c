#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O1242[4];
void O1242_init () {
	O1242[0] = 0;
	O1242[1] = + _CHROFF_0_0_;
	O1242[2] = 0;
	O1242[3] = + _CHROFF_1_0_;
}

long O1487[6];
void O1487_init () {
	O1487[0] = 0;
	O1487[1] = + _LNGOFF_0_0_0_0_;
	O1487[2] = + _I64OFF_0_0_0_0_0_0_0_;
	O1487[3] = + _LNGOFF_0_0_0_0_;
	O1487[4] = 0;
	O1487[5] = + _LNGOFF_1_0_0_0_;
}

long O1491[2];
void O1491_init () {
	O1491[0] =  + _REFACS_1_;
	O1491[1] = 0;
}

long O1680[10];
void O1680_init () {
	O1680[0] = 0;
	O1680[1] = + _CHROFF_0_0_;
	O1680[2] = + _LNGOFF_0_0_0_0_;
	O1680[3] = + _CHROFF_0_0_;
	{long i; for (i = 4; i < 6; i++) O1680[i] = 0;}
	O1680[6] = + _CHROFF_1_0_;
	O1680[7] = + _LNGOFF_1_0_0_0_;
	O1680[8] = + _CHROFF_1_0_;
	O1680[9] = 0;
}

long O1689[5];
void O1689_init () {
	O1689[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 4; i++) O1689[i] = 0;}
	O1689[4] =  + _REFACS_1_;
}

long O1967[4];
void O1967_init () {
	O1967[0] = + _CHROFF_2_0_;
	O1967[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O1967[i] = + _CHROFF_2_0_;}
}

long O1968[4];
void O1968_init () {
	O1968[0] = + _CHROFF_2_1_;
	O1968[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O1968[i] = + _CHROFF_2_1_;}
}

static EIF_TYPE_INDEX Y2106_pgtype0[] = {0xFF01,97,0xFFFF};
static EIF_TYPE_INDEX Y2106_pgtype1[] = {0xFF01,97,0xFFFF};
static EIF_TYPE_INDEX Y2106_pgtype2[] = {0xFF01,334,0xFFFF};
static EIF_TYPE_INDEX Y2106_pgtype3[] = {0xFF01,97,0xFFFF};
static EIF_TYPE_INDEX Y2106_pgtype4[] = {0xFF01,97,0xFFFF};
static EIF_TYPE_INDEX Y2106_pgtype5[] = {0xFF01,334,0xFFFF};
EIF_TYPE_INDEX *Y2106_gen_type [6];
EIF_TYPE_INDEX Y2106 [6];
void Y2106_init (void)
{
	egc_routines_types [2106] = Y2106;
	egc_routines_gen_types [2106] = Y2106_gen_type;
	egc_routines_offset [2106] = 199;
	Y2106_gen_type [0] = Y2106_pgtype0;
	Y2106_gen_type [1] = Y2106_pgtype1;
	Y2106_gen_type [2] = Y2106_pgtype2;
	Y2106_gen_type [3] = Y2106_pgtype3;
	Y2106_gen_type [4] = Y2106_pgtype4;
	Y2106_gen_type [5] = Y2106_pgtype5;
	{long i; for (i = 0; i < 2; i++) Y2106[i] = 97;};
	Y2106[2] = 334;
	{long i; for (i = 3; i < 5; i++) Y2106[i] = 97;};
	Y2106[5] = 334;
}

long O2107[6];
void O2107_init () {
	{long i; for (i = 0; i < 3; i++) O2107[i] = + _LNGOFF_1_3_0_0_;}
	{long i; for (i = 3; i < 5; i++) O2107[i] = + _LNGOFF_2_4_0_0_;}
	O2107[5] = + _LNGOFF_2_5_0_0_;
}

long O2108[6];
void O2108_init () {
	{long i; for (i = 0; i < 3; i++) O2108[i] = + _LNGOFF_1_3_0_1_;}
	{long i; for (i = 3; i < 5; i++) O2108[i] = + _LNGOFF_2_4_0_1_;}
	O2108[5] = + _LNGOFF_2_5_0_1_;
}

long O2109[6];
void O2109_init () {
	{long i; for (i = 0; i < 3; i++) O2109[i] = + _LNGOFF_1_3_0_2_;}
	{long i; for (i = 3; i < 5; i++) O2109[i] = + _LNGOFF_2_4_0_2_;}
	O2109[5] = + _LNGOFF_2_5_0_2_;
}

long O2110[6];
void O2110_init () {
	{long i; for (i = 0; i < 3; i++) O2110[i] = + _LNGOFF_1_3_0_3_;}
	{long i; for (i = 3; i < 5; i++) O2110[i] = + _LNGOFF_2_4_0_3_;}
	O2110[5] = + _LNGOFF_2_5_0_3_;
}

long O2111[6];
void O2111_init () {
	{long i; for (i = 0; i < 3; i++) O2111[i] = + _LNGOFF_1_3_0_4_;}
	{long i; for (i = 3; i < 5; i++) O2111[i] = + _LNGOFF_2_4_0_4_;}
	O2111[5] = + _LNGOFF_2_5_0_4_;
}

long O2112[6];
void O2112_init () {
	{long i; for (i = 0; i < 3; i++) O2112[i] = + _LNGOFF_1_3_0_5_;}
	{long i; for (i = 3; i < 5; i++) O2112[i] = + _LNGOFF_2_4_0_5_;}
	O2112[5] = + _LNGOFF_2_5_0_5_;
}

long O2113[6];
void O2113_init () {
	{long i; for (i = 0; i < 3; i++) O2113[i] = + _CHROFF_1_0_;}
	{long i; for (i = 3; i < 6; i++) O2113[i] = + _CHROFF_2_0_;}
}

long O2118[6];
void O2118_init () {
	{long i; for (i = 0; i < 3; i++) O2118[i] = + _CHROFF_1_1_;}
	{long i; for (i = 3; i < 6; i++) O2118[i] = + _CHROFF_2_1_;}
}

long O2196[1158];
void O2196_init () {
	{long i; for (i = 0; i < 7; i++) O2196[i] = 0;}
	{long i; for (i = 805; i < 809; i++) O2196[i] = 0;}
	{long i; for (i = 1104; i < 1107; i++) O2196[i] = 0;}
	O2196[1108] = 0;
	{long i; for (i = 1156; i < 1158; i++) O2196[i] =  + _REFACS_1_;}
}

long O2216[2];
void O2216_init () {
	O2216[0] = + _CHROFF_2_0_;
	O2216[1] = + _CHROFF_3_0_;
}

long O2363[585];
void O2363_init () {
	O2363[0] = + _CHROFF_1_0_;
	O2363[584] = + _CHROFF_2_0_;
}

static EIF_TYPE_INDEX Y2614_pgtype0[] = {0xFF01,746,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype1[] = {0xFF01,747,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype2[] = {0xFF01,748,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype3[] = {0xFF01,749,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype4[] = {0xFF01,750,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype5[] = {0xFF01,751,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype6[] = {0xFF01,752,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype7[] = {0xFF01,753,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype8[] = {0xFF01,754,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype9[] = {0xFF01,755,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype10[] = {0xFF01,756,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype11[] = {0xFF01,757,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype12[] = {0xFF01,753,924,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype13[] = {0xFF01,753,924,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype14[] = {0xFF01,746,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype15[] = {0xFF01,747,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype16[] = {0xFF01,748,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype17[] = {0xFF01,749,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype18[] = {0xFF01,750,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype19[] = {0xFF01,751,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype20[] = {0xFF01,752,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype21[] = {0xFF01,753,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype22[] = {0xFF01,754,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype23[] = {0xFF01,755,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype24[] = {0xFF01,756,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype25[] = {0xFF01,757,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype26[] = {0xFF01,746,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype27[] = {0xFF01,748,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype28[] = {0xFF01,750,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype29[] = {0xFF01,749,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype30[] = {0xFF01,747,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype31[] = {0xFF01,752,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype32[] = {0xFF01,746,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype33[] = {0xFF01,747,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype34[] = {0xFF01,748,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype35[] = {0xFF01,749,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype36[] = {0xFF01,750,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype37[] = {0xFF01,751,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype38[] = {0xFF01,752,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype39[] = {0xFF01,753,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype40[] = {0xFF01,754,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype41[] = {0xFF01,755,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype42[] = {0xFF01,756,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype43[] = {0xFF01,757,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype44[] = {0xFF01,751,933,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype45[] = {0xFF01,752,936,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype46[] = {0xFF01,752,936,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype47[] = {0xFF01,752,936,0xFFFF};
static EIF_TYPE_INDEX Y2614_pgtype48[] = {0xFF01,752,936,0xFFFF};
EIF_TYPE_INDEX *Y2614_gen_type [1135];
EIF_TYPE_INDEX Y2614 [1135];
void Y2614_init (void)
{
	egc_routines_types [2614] = Y2614;
	egc_routines_gen_types [2614] = Y2614_gen_type;
	egc_routines_offset [2614] = 289;
	Y2614_gen_type [0] = Y2614_pgtype0;
	Y2614_gen_type [1] = Y2614_pgtype1;
	Y2614_gen_type [2] = Y2614_pgtype2;
	Y2614_gen_type [3] = Y2614_pgtype3;
	Y2614_gen_type [4] = Y2614_pgtype4;
	Y2614_gen_type [5] = Y2614_pgtype5;
	Y2614_gen_type [6] = Y2614_pgtype6;
	Y2614_gen_type [7] = Y2614_pgtype7;
	Y2614_gen_type [8] = Y2614_pgtype8;
	Y2614_gen_type [9] = Y2614_pgtype9;
	Y2614_gen_type [10] = Y2614_pgtype10;
	Y2614_gen_type [11] = Y2614_pgtype11;
	Y2614_gen_type [35] = Y2614_pgtype12;
	Y2614_gen_type [36] = Y2614_pgtype13;
	Y2614_gen_type [482] = Y2614_pgtype14;
	Y2614_gen_type [483] = Y2614_pgtype15;
	Y2614_gen_type [484] = Y2614_pgtype16;
	Y2614_gen_type [485] = Y2614_pgtype17;
	Y2614_gen_type [486] = Y2614_pgtype18;
	Y2614_gen_type [487] = Y2614_pgtype19;
	Y2614_gen_type [488] = Y2614_pgtype20;
	Y2614_gen_type [489] = Y2614_pgtype21;
	Y2614_gen_type [490] = Y2614_pgtype22;
	Y2614_gen_type [491] = Y2614_pgtype23;
	Y2614_gen_type [492] = Y2614_pgtype24;
	Y2614_gen_type [493] = Y2614_pgtype25;
	Y2614_gen_type [494] = Y2614_pgtype26;
	Y2614_gen_type [495] = Y2614_pgtype27;
	Y2614_gen_type [496] = Y2614_pgtype28;
	Y2614_gen_type [497] = Y2614_pgtype29;
	Y2614_gen_type [498] = Y2614_pgtype30;
	Y2614_gen_type [499] = Y2614_pgtype31;
	Y2614_gen_type [553] = Y2614_pgtype32;
	Y2614_gen_type [554] = Y2614_pgtype33;
	Y2614_gen_type [555] = Y2614_pgtype34;
	Y2614_gen_type [556] = Y2614_pgtype35;
	Y2614_gen_type [557] = Y2614_pgtype36;
	Y2614_gen_type [558] = Y2614_pgtype37;
	Y2614_gen_type [559] = Y2614_pgtype38;
	Y2614_gen_type [560] = Y2614_pgtype39;
	Y2614_gen_type [561] = Y2614_pgtype40;
	Y2614_gen_type [562] = Y2614_pgtype41;
	Y2614_gen_type [563] = Y2614_pgtype42;
	Y2614_gen_type [564] = Y2614_pgtype43;
	Y2614_gen_type [694] = Y2614_pgtype44;
	Y2614_gen_type [697] = Y2614_pgtype45;
	Y2614_gen_type [698] = Y2614_pgtype46;
	Y2614_gen_type [1133] = Y2614_pgtype47;
	Y2614_gen_type [1134] = Y2614_pgtype48;
	Y2614[0] = 746;
	Y2614[1] = 747;
	Y2614[2] = 748;
	Y2614[3] = 749;
	Y2614[4] = 750;
	Y2614[5] = 751;
	Y2614[6] = 752;
	Y2614[7] = 753;
	Y2614[8] = 754;
	Y2614[9] = 755;
	Y2614[10] = 756;
	Y2614[11] = 757;
	{long i; for (i = 35; i < 37; i++) Y2614[i] = 753;};
	Y2614[482] = 746;
	Y2614[483] = 747;
	Y2614[484] = 748;
	Y2614[485] = 749;
	Y2614[486] = 750;
	Y2614[487] = 751;
	Y2614[488] = 752;
	Y2614[489] = 753;
	Y2614[490] = 754;
	Y2614[491] = 755;
	Y2614[492] = 756;
	Y2614[493] = 757;
	Y2614[494] = 746;
	Y2614[495] = 748;
	Y2614[496] = 750;
	Y2614[497] = 749;
	Y2614[498] = 747;
	Y2614[499] = 752;
	Y2614[553] = 746;
	Y2614[554] = 747;
	Y2614[555] = 748;
	Y2614[556] = 749;
	Y2614[557] = 750;
	Y2614[558] = 751;
	Y2614[559] = 752;
	Y2614[560] = 753;
	Y2614[561] = 754;
	Y2614[562] = 755;
	Y2614[563] = 756;
	Y2614[564] = 757;
	Y2614[694] = 751;
	{long i; for (i = 697; i < 699; i++) Y2614[i] = 752;};
	{long i; for (i = 1133; i < 1135; i++) Y2614[i] = 752;};
}

long O2758[19];
void O2758_init () {
	O2758[0] = + _LNGOFF_0_0_0_0_;
	O2758[18] = + _LNGOFF_2_7_2_1_;
}

long O2759[19];
void O2759_init () {
	O2759[0] = + _LNGOFF_0_0_0_1_;
	O2759[18] = + _LNGOFF_2_7_2_2_;
}

long O2916[967];
void O2916_init () {
	O2916[0] = + _PTROFF_3_0_0_1_0_0_;
	O2916[966] = + _PTROFF_6_2_0_1_0_0_;
}

long O2922[967];
void O2922_init () {
	O2922[0] = + _LNGOFF_3_0_0_0_;
	O2922[966] = + _LNGOFF_6_2_0_0_;
}

long O2956[5];
void O2956_init () {
	{long i; for (i = 0; i < 3; i++) O2956[i] = + _LNGOFF_0_0_0_0_;}
	O2956[3] = + _LNGOFF_15_11_0_0_;
	O2956[4] = + _LNGOFF_13_16_0_4_;
}

long O3111[968];
void O3111_init () {
	O3111[0] = + _CHROFF_1_0_;
	O3111[1] = + _CHROFF_2_0_;
	O3111[394] = + _CHROFF_3_0_;
	O3111[395] = + _CHROFF_4_0_;
	O3111[396] = + _CHROFF_5_0_;
	O3111[741] = + _CHROFF_5_0_;
	O3111[959] = + _CHROFF_6_0_;
	{long i; for (i = 960; i < 963; i++) O3111[i] = + _CHROFF_5_0_;}
	O3111[964] = + _CHROFF_7_1_;
	{long i; for (i = 965; i < 968; i++) O3111[i] = + _CHROFF_6_1_;}
}

long O3112[968];
void O3112_init () {
	{long i; for (i = 0; i < 2; i++) O3112[i] = 0;}
	{long i; for (i = 394; i < 397; i++) O3112[i] = 0;}
	O3112[741] = 0;
	{long i; for (i = 959; i < 963; i++) O3112[i] = 0;}
	O3112[964] =  + _REFACS_6_;
	{long i; for (i = 965; i < 968; i++) O3112[i] =  + _REFACS_5_;}
}

long O3471[19];
void O3471_init () {
	{long i; for (i = 0; i < 12; i++) O3471[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 12; i < 14; i++) O3471[i] = + _LNGOFF_2_1_0_0_;}
	{long i; for (i = 14; i < 19; i++) O3471[i] = + _LNGOFF_1_1_0_0_;}
}

long O3475[19];
void O3475_init () {
	{long i; for (i = 0; i < 12; i++) O3475[i] = + _CHROFF_1_0_;}
	{long i; for (i = 12; i < 14; i++) O3475[i] = + _CHROFF_2_0_;}
	{long i; for (i = 14; i < 19; i++) O3475[i] = + _CHROFF_1_0_;}
}

long O3476[19];
void O3476_init () {
	{long i; for (i = 0; i < 12; i++) O3476[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 12; i < 14; i++) O3476[i] = + _LNGOFF_2_1_0_1_;}
	{long i; for (i = 14; i < 19; i++) O3476[i] = + _LNGOFF_1_1_0_1_;}
}

long O3477[19];
void O3477_init () {
	{long i; for (i = 0; i < 12; i++) O3477[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 12; i < 14; i++) O3477[i] = + _LNGOFF_2_1_0_2_;}
	{long i; for (i = 14; i < 19; i++) O3477[i] = + _LNGOFF_1_1_0_2_;}
}

long O3478[19];
void O3478_init () {
	{long i; for (i = 0; i < 12; i++) O3478[i] = + _LNGOFF_1_1_0_3_;}
	{long i; for (i = 12; i < 14; i++) O3478[i] = + _LNGOFF_2_1_0_3_;}
	{long i; for (i = 14; i < 19; i++) O3478[i] = + _LNGOFF_1_1_0_3_;}
}

long O3479[19];
void O3479_init () {
	{long i; for (i = 0; i < 12; i++) O3479[i] = + _LNGOFF_1_1_0_4_;}
	{long i; for (i = 12; i < 14; i++) O3479[i] = + _LNGOFF_2_1_0_4_;}
	{long i; for (i = 14; i < 19; i++) O3479[i] = + _LNGOFF_1_1_0_4_;}
}

long O3482[50];
void O3482_init () {
	{long i; for (i = 0; i < 12; i++) O3482[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 12; i < 38; i++) O3482[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 38; i < 50; i++) O3482[i] = + _LNGOFF_1_0_0_0_;}
}

long O3484[50];
void O3484_init () {
	{long i; for (i = 0; i < 12; i++) O3484[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 12; i < 38; i++) O3484[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 38; i < 50; i++) O3484[i] = + _LNGOFF_1_0_0_1_;}
}

long O3500[898];
void O3500_init () {
	{long i; for (i = 0; i < 205; i++) O3500[i] = + _CHROFF_0_0_;}
	O3500[205] = + _CHROFF_3_2_;
	O3500[206] = + _CHROFF_4_2_;
	O3500[207] = + _CHROFF_5_2_;
	{long i; for (i = 232; i < 245; i++) O3500[i] = + _CHROFF_0_0_;}
	{long i; for (i = 245; i < 263; i++) O3500[i] = + _CHROFF_1_0_;}
	{long i; for (i = 263; i < 311; i++) O3500[i] = + _CHROFF_0_0_;}
	{long i; for (i = 311; i < 313; i++) O3500[i] = + _CHROFF_2_0_;}
	{long i; for (i = 315; i < 328; i++) O3500[i] = + _CHROFF_1_0_;}
	O3500[328] = + _CHROFF_7_0_;
	O3500[329] = + _CHROFF_5_0_;
	O3500[330] = + _CHROFF_6_0_;
	O3500[331] = + _CHROFF_4_0_;
	O3500[332] = + _CHROFF_5_0_;
	O3500[333] = + _CHROFF_7_0_;
	O3500[334] = + _CHROFF_5_0_;
	O3500[335] = + _CHROFF_9_0_;
	O3500[457] = + _CHROFF_1_0_;
	{long i; for (i = 460; i < 462; i++) O3500[i] = + _CHROFF_1_0_;}
	O3500[552] = + _CHROFF_5_2_;
	O3500[770] = + _CHROFF_6_2_;
	{long i; for (i = 771; i < 774; i++) O3500[i] = + _CHROFF_5_2_;}
	O3500[775] = + _CHROFF_7_2_;
	{long i; for (i = 776; i < 779; i++) O3500[i] = + _CHROFF_6_2_;}
	{long i; for (i = 896; i < 898; i++) O3500[i] = + _CHROFF_1_0_;}
}

long O3589[574];
void O3589_init () {
	O3589[0] = + _PTROFF_3_6_2_4_1_0_;
	O3589[1] = + _PTROFF_4_6_2_4_1_0_;
	O3589[2] = + _PTROFF_5_7_2_4_1_0_;
	O3589[347] = + _PTROFF_5_7_2_4_1_0_;
	O3589[565] = + _PTROFF_6_7_2_4_1_0_;
	{long i; for (i = 566; i < 569; i++) O3589[i] = + _PTROFF_5_6_2_4_1_0_;}
	O3589[570] = + _PTROFF_7_8_2_4_1_0_;
	{long i; for (i = 571; i < 574; i++) O3589[i] = + _PTROFF_6_7_2_4_1_0_;}
}

long O3672[574];
void O3672_init () {
	{long i; for (i = 0; i < 3; i++) O3672[i] =  + _REFACS_1_;}
	O3672[347] =  + _REFACS_1_;
	{long i; for (i = 565; i < 569; i++) O3672[i] =  + _REFACS_1_;}
	{long i; for (i = 570; i < 574; i++) O3672[i] = 0;}
}

long O3674[574];
void O3674_init () {
	{long i; for (i = 0; i < 3; i++) O3674[i] =  + _REFACS_2_;}
	O3674[347] =  + _REFACS_2_;
	{long i; for (i = 565; i < 569; i++) O3674[i] =  + _REFACS_2_;}
	{long i; for (i = 570; i < 574; i++) O3674[i] =  + _REFACS_1_;}
}

long O3728[574];
void O3728_init () {
	O3728[0] = + _LNGOFF_3_6_2_3_;
	O3728[1] = + _LNGOFF_4_6_2_3_;
	O3728[2] = + _LNGOFF_5_7_2_3_;
	O3728[347] = + _LNGOFF_5_7_2_3_;
	O3728[565] = + _LNGOFF_6_7_2_3_;
	{long i; for (i = 566; i < 569; i++) O3728[i] = + _LNGOFF_5_6_2_3_;}
	O3728[570] = + _LNGOFF_7_8_2_3_;
	{long i; for (i = 571; i < 574; i++) O3728[i] = + _LNGOFF_6_7_2_3_;}
}


#ifdef __cplusplus
}
#endif
