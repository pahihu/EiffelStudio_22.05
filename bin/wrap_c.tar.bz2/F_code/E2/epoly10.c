#include "epoly10.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4935[442])();
void R4935_init () {
	{long i; for (i = 0; i < 2; i++) R4935[i] = (char *(*)()) F982_6475;}
	{long i; for (i = 3; i < 6; i++) R4935[i] = (char *(*)()) F985_6643;}
	{long i; for (i = 440; i < 442; i++) R4935[i] = (char *(*)()) F985_6643;}
}

char *(*R4937[442])();
void R4937_init () {
	{long i; for (i = 0; i < 2; i++) R4937[i] = (char *(*)()) F982_6477;}
	{long i; for (i = 3; i < 6; i++) R4937[i] = (char *(*)()) F985_6645;}
	{long i; for (i = 440; i < 442; i++) R4937[i] = (char *(*)()) F985_6645;}
}

char *(*R4938[442])();
void R4938_init () {
	R4938[0] = (char *(*)()) F983_6516;
	R4938[1] = (char *(*)()) F674_4113;
	R4938[3] = (char *(*)()) F986_6681;
	{long i; for (i = 4; i < 6; i++) R4938[i] = (char *(*)()) F673_4113;}
	{long i; for (i = 440; i < 442; i++) R4938[i] = (char *(*)()) F673_4113;}
}

char *(*R4960[442])();
void R4960_init () {
	{long i; for (i = 0; i < 2; i++) R4960[i] = (char *(*)()) F982_6466;}
	{long i; for (i = 3; i < 6; i++) R4960[i] = (char *(*)()) F985_6634;}
	{long i; for (i = 440; i < 442; i++) R4960[i] = (char *(*)()) F1423_11803;}
}

char *(*R4961[442])();
void R4961_init () {
	{long i; for (i = 0; i < 2; i++) R4961[i] = (char *(*)()) F982_6465;}
	{long i; for (i = 3; i < 6; i++) R4961[i] = (char *(*)()) F985_6633;}
	{long i; for (i = 440; i < 442; i++) R4961[i] = (char *(*)()) F1423_11805;}
}

char *(*R4965[442])();
void R4965_init () {
	{long i; for (i = 0; i < 2; i++) R4965[i] = (char *(*)()) F979_6359;}
	{long i; for (i = 3; i < 6; i++) R4965[i] = (char *(*)()) F979_6359;}
	{long i; for (i = 440; i < 442; i++) R4965[i] = (char *(*)()) F1423_11810;}
}

char *(*R4966[442])();
void R4966_init () {
	{long i; for (i = 0; i < 2; i++) R4966[i] = (char *(*)()) F979_6360;}
	{long i; for (i = 3; i < 6; i++) R4966[i] = (char *(*)()) F979_6360;}
	{long i; for (i = 440; i < 442; i++) R4966[i] = (char *(*)()) F1423_11816;}
}

char *(*R4971[442])();
void R4971_init () {
	{long i; for (i = 0; i < 2; i++) R4971[i] = (char *(*)()) F982_6462;}
	{long i; for (i = 3; i < 6; i++) R4971[i] = (char *(*)()) F985_6630;}
	{long i; for (i = 440; i < 442; i++) R4971[i] = (char *(*)()) F1423_11791;}
}

char *(*R4982[442])();
void R4982_init () {
	R4982[0] = (char *(*)()) F983_6511;
	{long i; for (i = 4; i < 6; i++) R4982[i] = (char *(*)()) F987_6760;}
	{long i; for (i = 440; i < 442; i++) R4982[i] = (char *(*)()) F1423_11860;}
}

char *(*R4983[438])();
void R4983_init () {
	{long i; for (i = 0; i < 2; i++) R4983[i] = (char *(*)()) F987_6761;}
	{long i; for (i = 436; i < 438; i++) R4983[i] = (char *(*)()) F1423_11861;}
}

char *(*R5001[442])();
void R5001_init () {
	R5001[0] = (char *(*)()) F983_6513;
	R5001[1] = (char *(*)()) F984_6607;
	R5001[3] = (char *(*)()) F986_6679;
	{long i; for (i = 4; i < 6; i++) R5001[i] = (char *(*)()) F987_6772;}
	{long i; for (i = 440; i < 442; i++) R5001[i] = (char *(*)()) F1423_11789;}
}

char *(*R5016[441])();
void R5016_init () {
	R5016[0] = (char *(*)()) F984_6609;
	{long i; for (i = 3; i < 5; i++) R5016[i] = (char *(*)()) F987_6774;}
	{long i; for (i = 439; i < 441; i++) R5016[i] = (char *(*)()) F987_6774;}
}

char *(*R5019[441])();
void R5019_init () {
	R5019[0] = (char *(*)()) F984_6548;
	{long i; for (i = 3; i < 5; i++) R5019[i] = (char *(*)()) F987_6713;}
	{long i; for (i = 439; i < 441; i++) R5019[i] = (char *(*)()) F1423_11902;}
}

char *(*R5020[441])();
void R5020_init () {
	R5020[0] = (char *(*)()) F981_6415;
	{long i; for (i = 3; i < 5; i++) R5020[i] = (char *(*)()) F981_6415;}
	{long i; for (i = 439; i < 441; i++) R5020[i] = (char *(*)()) F1423_11903;}
}

char *(*R5031[441])();
void R5031_init () {
	R5031[0] = (char *(*)()) F984_6559;
	{long i; for (i = 3; i < 5; i++) R5031[i] = (char *(*)()) F987_6724;}
	{long i; for (i = 439; i < 441; i++) R5031[i] = (char *(*)()) F1423_11825;}
}

char *(*R5039[438])();
void R5039_init () {
	{long i; for (i = 0; i < 2; i++) R5039[i] = (char *(*)()) F987_6707;}
	{long i; for (i = 436; i < 438; i++) R5039[i] = (char *(*)()) F1423_11849;}
}

char *(*R5040[438])();
void R5040_init () {
	{long i; for (i = 0; i < 2; i++) R5040[i] = (char *(*)()) F987_6708;}
	{long i; for (i = 436; i < 438; i++) R5040[i] = (char *(*)()) F1423_11850;}
}

char *(*R5041[441])();
void R5041_init () {
	R5041[0] = (char *(*)()) F984_6544;
	{long i; for (i = 3; i < 5; i++) R5041[i] = (char *(*)()) F987_6709;}
	{long i; for (i = 439; i < 441; i++) R5041[i] = (char *(*)()) F1423_11898;}
}

char *(*R5042[441])();
void R5042_init () {
	R5042[0] = (char *(*)()) F984_6545;
	{long i; for (i = 3; i < 5; i++) R5042[i] = (char *(*)()) F987_6710;}
	{long i; for (i = 439; i < 441; i++) R5042[i] = (char *(*)()) F1423_11899;}
}

char *(*R5044[438])();
void R5044_init () {
	{long i; for (i = 0; i < 2; i++) R5044[i] = (char *(*)()) F987_6746;}
	{long i; for (i = 436; i < 438; i++) R5044[i] = (char *(*)()) F1423_11853;}
}

char *(*R5045[438])();
void R5045_init () {
	{long i; for (i = 0; i < 2; i++) R5045[i] = (char *(*)()) F987_6747;}
	{long i; for (i = 436; i < 438; i++) R5045[i] = (char *(*)()) F1423_11851;}
}

char *(*R5047[438])();
void R5047_init () {
	{long i; for (i = 0; i < 2; i++) R5047[i] = (char *(*)()) F987_6749;}
	{long i; for (i = 436; i < 438; i++) R5047[i] = (char *(*)()) F1423_11852;}
}

char *(*R5048[441])();
void R5048_init () {
	R5048[0] = (char *(*)()) F984_6589;
	{long i; for (i = 3; i < 5; i++) R5048[i] = (char *(*)()) F987_6754;}
	{long i; for (i = 439; i < 441; i++) R5048[i] = (char *(*)()) F1423_11896;}
}


#ifdef __cplusplus
}
#endif
