#include "epoly1.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R11[1424])();
void R11_init () {
	R11[0] = (char *(*)()) F1_8;
	{long i; for (i = 5; i < 18; i++) R11[i] = (char *(*)()) F1_8;}
	R11[21] = (char *(*)()) F1_8;
	{long i; for (i = 23; i < 63; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 64; i < 66; i++) R11[i] = (char *(*)()) F1_8;}
	R11[67] = (char *(*)()) F1_8;
	R11[69] = (char *(*)()) F1_8;
	R11[71] = (char *(*)()) F1_8;
	{long i; for (i = 73; i < 78; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 79; i < 88; i++) R11[i] = (char *(*)()) F1_8;}
	R11[89] = (char *(*)()) F1_8;
	R11[91] = (char *(*)()) F1_8;
	{long i; for (i = 93; i < 95; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 98; i < 101; i++) R11[i] = (char *(*)()) F1_8;}
	R11[103] = (char *(*)()) F1_8;
	R11[105] = (char *(*)()) F1_8;
	{long i; for (i = 108; i < 129; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 130; i < 133; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 134; i < 136; i++) R11[i] = (char *(*)()) F1_8;}
	R11[143] = (char *(*)()) F1_8;
	{long i; for (i = 145; i < 163; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 165; i < 168; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 170; i < 173; i++) R11[i] = (char *(*)()) F1_8;}
	R11[175] = (char *(*)()) F1_8;
	{long i; for (i = 178; i < 182; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 183; i < 189; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 192; i < 210; i++) R11[i] = (char *(*)()) F1_8;}
	R11[212] = (char *(*)()) F1_8;
	{long i; for (i = 214; i < 234; i++) R11[i] = (char *(*)()) F1_8;}
	R11[236] = (char *(*)()) F1_8;
	{long i; for (i = 238; i < 241; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 242; i < 245; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 246; i < 248; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 250; i < 252; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 253; i < 256; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 257; i < 261; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 262; i < 264; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 265; i < 273; i++) R11[i] = (char *(*)()) F1_8;}
	R11[274] = (char *(*)()) F1_8;
	{long i; for (i = 277; i < 283; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 284; i < 286; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 287; i < 314; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 315; i < 318; i++) R11[i] = (char *(*)()) F1_8;}
	R11[319] = (char *(*)()) F320_2957;
	{long i; for (i = 320; i < 323; i++) R11[i] = (char *(*)()) F1_8;}
	R11[323] = (char *(*)()) F324_3107;
	{long i; for (i = 324; i < 326; i++) R11[i] = (char *(*)()) F325_3156;}
	{long i; for (i = 326; i < 328; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 329; i < 337; i++) R11[i] = (char *(*)()) F1_8;}
	R11[338] = (char *(*)()) F1_8;
	R11[340] = (char *(*)()) F1_8;
	{long i; for (i = 343; i < 388; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 401; i < 403; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 408; i < 411; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 424; i < 428; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 457; i < 476; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 488; i < 526; i++) R11[i] = (char *(*)()) F1_8;}
	R11[668] = (char *(*)()) F1_8;
	{long i; for (i = 732; i < 734; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 746; i < 758; i++) R11[i] = (char *(*)()) F1_8;}
	R11[770] = (char *(*)()) F771_4553;
	R11[771] = (char *(*)()) F772_4594;
	R11[772] = (char *(*)()) F773_4594;
	R11[773] = (char *(*)()) F774_4594;
	R11[774] = (char *(*)()) F775_4594;
	R11[775] = (char *(*)()) F776_4594;
	R11[776] = (char *(*)()) F777_4594;
	R11[777] = (char *(*)()) F778_4594;
	R11[778] = (char *(*)()) F779_4594;
	R11[779] = (char *(*)()) F780_4594;
	R11[780] = (char *(*)()) F781_4594;
	R11[781] = (char *(*)()) F782_4594;
	R11[782] = (char *(*)()) F783_4594;
	R11[783] = (char *(*)()) F772_4594;
	R11[784] = (char *(*)()) F774_4594;
	R11[785] = (char *(*)()) F776_4594;
	R11[786] = (char *(*)()) F775_4594;
	R11[787] = (char *(*)()) F773_4594;
	R11[788] = (char *(*)()) F778_4594;
	R11[837] = (char *(*)()) F814_4676;
	R11[838] = (char *(*)()) F815_4676;
	{long i; for (i = 839; i < 841; i++) R11[i] = (char *(*)()) F1_8;}
	R11[841] = (char *(*)()) F842_4741;
	R11[842] = (char *(*)()) F843_4793;
	R11[843] = (char *(*)()) F844_4793;
	R11[844] = (char *(*)()) F845_4793;
	R11[845] = (char *(*)()) F846_4793;
	R11[846] = (char *(*)()) F847_4793;
	R11[847] = (char *(*)()) F848_4793;
	R11[848] = (char *(*)()) F849_4793;
	R11[849] = (char *(*)()) F850_4793;
	R11[850] = (char *(*)()) F851_4793;
	R11[851] = (char *(*)()) F852_4793;
	R11[852] = (char *(*)()) F853_4793;
	R11[853] = (char *(*)()) F854_4793;
	R11[854] = (char *(*)()) F855_4858;
	R11[855] = (char *(*)()) F856_4858;
	R11[856] = (char *(*)()) F857_4858;
	R11[857] = (char *(*)()) F858_4858;
	R11[858] = (char *(*)()) F859_4858;
	R11[859] = (char *(*)()) F860_4952;
	R11[860] = (char *(*)()) F861_4952;
	R11[861] = (char *(*)()) F855_4858;
	{long i; for (i = 862; i < 865; i++) R11[i] = (char *(*)()) F1_8;}
	R11[866] = (char *(*)()) F867_5010;
	R11[867] = (char *(*)()) F868_5047;
	R11[868] = (char *(*)()) F869_5047;
	R11[869] = (char *(*)()) F870_5047;
	R11[870] = (char *(*)()) F871_5047;
	R11[871] = (char *(*)()) F872_5047;
	R11[872] = (char *(*)()) F873_5047;
	R11[873] = (char *(*)()) F874_5047;
	R11[874] = (char *(*)()) F875_5047;
	R11[875] = (char *(*)()) F876_5047;
	R11[876] = (char *(*)()) F877_5047;
	R11[877] = (char *(*)()) F878_5047;
	R11[878] = (char *(*)()) F879_5047;
	R11[879] = (char *(*)()) F880_5047;
	R11[880] = (char *(*)()) F881_5047;
	R11[881] = (char *(*)()) F882_5047;
	R11[882] = (char *(*)()) F883_5047;
	R11[883] = (char *(*)()) F884_5047;
	R11[884] = (char *(*)()) F885_5047;
	R11[885] = (char *(*)()) F886_5047;
	R11[886] = (char *(*)()) F887_5047;
	R11[887] = (char *(*)()) F888_5047;
	R11[888] = (char *(*)()) F889_5047;
	R11[889] = (char *(*)()) F890_5047;
	R11[890] = (char *(*)()) F891_5047;
	R11[891] = (char *(*)()) F892_5047;
	R11[892] = (char *(*)()) F893_5047;
	R11[893] = (char *(*)()) F894_5047;
	R11[894] = (char *(*)()) F895_5047;
	R11[895] = (char *(*)()) F896_5047;
	R11[896] = (char *(*)()) F897_5047;
	R11[897] = (char *(*)()) F898_5047;
	R11[898] = (char *(*)()) F899_5090;
	{long i; for (i = 899; i < 901; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 901; i < 904; i++) R11[i] = (char *(*)()) F902_5223;}
	{long i; for (i = 904; i < 907; i++) R11[i] = (char *(*)()) F905_5321;}
	{long i; for (i = 907; i < 910; i++) R11[i] = (char *(*)()) F908_5420;}
	{long i; for (i = 910; i < 913; i++) R11[i] = (char *(*)()) F911_5519;}
	{long i; for (i = 913; i < 916; i++) R11[i] = (char *(*)()) F914_5618;}
	{long i; for (i = 916; i < 919; i++) R11[i] = (char *(*)()) F917_5712;}
	{long i; for (i = 919; i < 922; i++) R11[i] = (char *(*)()) F920_5806;}
	{long i; for (i = 922; i < 925; i++) R11[i] = (char *(*)()) F923_5901;}
	{long i; for (i = 925; i < 928; i++) R11[i] = (char *(*)()) F926_6000;}
	{long i; for (i = 928; i < 931; i++) R11[i] = (char *(*)()) F929_6066;}
	{long i; for (i = 931; i < 934; i++) R11[i] = (char *(*)()) F932_6127;}
	{long i; for (i = 934; i < 937; i++) R11[i] = (char *(*)()) F935_6167;}
	{long i; for (i = 937; i < 940; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 940; i < 973; i++) R11[i] = (char *(*)()) F941_6233;}
	R11[974] = (char *(*)()) F974_6270;
	R11[975] = (char *(*)()) F976_6308;
	{long i; for (i = 976; i < 978; i++) R11[i] = (char *(*)()) F977_6308;}
	{long i; for (i = 982; i < 984; i++) R11[i] = (char *(*)()) F982_6469;}
	{long i; for (i = 985; i < 988; i++) R11[i] = (char *(*)()) F985_6637;}
	{long i; for (i = 988; i < 1000; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1005; i < 1013; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1013] = (char *(*)()) F191_2133;
	{long i; for (i = 1014; i < 1024; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1024] = (char *(*)()) F1025_7171;
	R11[1025] = (char *(*)()) F1026_7179;
	{long i; for (i = 1026; i < 1028; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1029; i < 1031; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1035; i < 1038; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1041; i < 1043; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1044; i < 1054; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1055] = (char *(*)()) F1_8;
	{long i; for (i = 1057; i < 1081; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1084; i < 1095; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1098; i < 1100; i++) R11[i] = (char *(*)()) F1098_8186;}
	{long i; for (i = 1101; i < 1103; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1105] = (char *(*)()) F1_8;
	{long i; for (i = 1130; i < 1132; i++) R11[i] = (char *(*)()) F1107_8275;}
	R11[1132] = (char *(*)()) F1110_8275;
	R11[1133] = (char *(*)()) F1107_8275;
	R11[1134] = (char *(*)()) F1111_8275;
	R11[1140] = (char *(*)()) F1107_8275;
	R11[1141] = (char *(*)()) F1108_8275;
	R11[1142] = (char *(*)()) F1109_8275;
	{long i; for (i = 1143; i < 1145; i++) R11[i] = (char *(*)()) F1111_8275;}
	{long i; for (i = 1145; i < 1149; i++) R11[i] = (char *(*)()) F1107_8275;}
	R11[1149] = (char *(*)()) F1108_8275;
	R11[1150] = (char *(*)()) F1109_8275;
	{long i; for (i = 1151; i < 1153; i++) R11[i] = (char *(*)()) F1111_8275;}
	R11[1153] = (char *(*)()) F1107_8275;
	R11[1154] = (char *(*)()) F1108_8275;
	R11[1155] = (char *(*)()) F1109_8275;
	{long i; for (i = 1156; i < 1158; i++) R11[i] = (char *(*)()) F1111_8275;}
	R11[1158] = (char *(*)()) F1107_8275;
	R11[1159] = (char *(*)()) F1108_8275;
	R11[1160] = (char *(*)()) F1109_8275;
	{long i; for (i = 1161; i < 1163; i++) R11[i] = (char *(*)()) F1111_8275;}
	{long i; for (i = 1165; i < 1167; i++) R11[i] = (char *(*)()) F1107_8275;}
	R11[1167] = (char *(*)()) F1111_8275;
	R11[1168] = (char *(*)()) F1107_8275;
	{long i; for (i = 1171; i < 1174; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1175; i < 1182; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1183; i < 1190; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1228] = (char *(*)()) F1229_8589;
	R11[1229] = (char *(*)()) F1230_8589;
	R11[1230] = (char *(*)()) F1231_8589;
	R11[1231] = (char *(*)()) F1232_8589;
	R11[1232] = (char *(*)()) F1233_8589;
	R11[1246] = (char *(*)()) F1247_8711;
	R11[1247] = (char *(*)()) F1248_8711;
	{long i; for (i = 1248; i < 1250; i++) R11[i] = (char *(*)()) F1247_8711;}
	R11[1256] = (char *(*)()) F1257_8862;
	R11[1257] = (char *(*)()) F1258_8862;
	R11[1260] = (char *(*)()) F1261_8891;
	R11[1261] = (char *(*)()) F1262_8891;
	R11[1266] = (char *(*)()) F1267_8925;
	R11[1267] = (char *(*)()) F1268_8962;
	R11[1275] = (char *(*)()) F1274_9128;
	R11[1286] = (char *(*)()) F1277_9202;
	R11[1287] = (char *(*)()) F1278_9202;
	R11[1288] = (char *(*)()) F1279_9202;
	R11[1289] = (char *(*)()) F1280_9202;
	R11[1290] = (char *(*)()) F1281_9202;
	{long i; for (i = 1291; i < 1294; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1296; i < 1300; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1301; i < 1311; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1313; i < 1324; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1330; i < 1333; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1334] = (char *(*)()) F1_8;
	{long i; for (i = 1336; i < 1338; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1339] = (char *(*)()) F1340_9990;
	R11[1340] = (char *(*)()) F1_8;
	R11[1342] = (char *(*)()) F1343_10076;
	R11[1343] = (char *(*)()) F1_8;
	R11[1345] = (char *(*)()) F1346_10152;
	{long i; for (i = 1346; i < 1352; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1353; i < 1355; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1361; i < 1365; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1368] = (char *(*)()) F1_8;
	{long i; for (i = 1370; i < 1375; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1376; i < 1389; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1390; i < 1395; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1396] = (char *(*)()) F1_8;
	R11[1398] = (char *(*)()) F1398_11318;
	{long i; for (i = 1399; i < 1414; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1415; i < 1422; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1422; i < 1424; i++) R11[i] = (char *(*)()) F1423_11813;}
}

char *(*R18[1424])();
void R18_init () {
	R18[0] = (char *(*)()) F1_15;
	{long i; for (i = 5; i < 18; i++) R18[i] = (char *(*)()) F1_15;}
	R18[21] = (char *(*)()) F1_15;
	{long i; for (i = 23; i < 63; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 64; i < 66; i++) R18[i] = (char *(*)()) F1_15;}
	R18[67] = (char *(*)()) F1_15;
	R18[69] = (char *(*)()) F1_15;
	R18[71] = (char *(*)()) F1_15;
	{long i; for (i = 73; i < 78; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 79; i < 88; i++) R18[i] = (char *(*)()) F1_15;}
	R18[89] = (char *(*)()) F1_15;
	R18[91] = (char *(*)()) F1_15;
	{long i; for (i = 93; i < 95; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 98; i < 101; i++) R18[i] = (char *(*)()) F1_15;}
	R18[103] = (char *(*)()) F1_15;
	R18[105] = (char *(*)()) F1_15;
	{long i; for (i = 108; i < 129; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 130; i < 133; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 134; i < 136; i++) R18[i] = (char *(*)()) F1_15;}
	R18[143] = (char *(*)()) F1_15;
	{long i; for (i = 145; i < 163; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 165; i < 168; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 170; i < 173; i++) R18[i] = (char *(*)()) F1_15;}
	R18[175] = (char *(*)()) F1_15;
	{long i; for (i = 178; i < 182; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 183; i < 189; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 192; i < 210; i++) R18[i] = (char *(*)()) F1_15;}
	R18[212] = (char *(*)()) F1_15;
	{long i; for (i = 214; i < 234; i++) R18[i] = (char *(*)()) F1_15;}
	R18[236] = (char *(*)()) F1_15;
	{long i; for (i = 238; i < 241; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 242; i < 245; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 246; i < 248; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 250; i < 252; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 253; i < 256; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 257; i < 261; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 262; i < 264; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 265; i < 273; i++) R18[i] = (char *(*)()) F1_15;}
	R18[274] = (char *(*)()) F1_15;
	{long i; for (i = 277; i < 283; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 284; i < 286; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 287; i < 314; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 315; i < 318; i++) R18[i] = (char *(*)()) F1_15;}
	R18[319] = (char *(*)()) F320_2958;
	{long i; for (i = 320; i < 324; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 324; i < 326; i++) R18[i] = (char *(*)()) F325_3157;}
	{long i; for (i = 326; i < 328; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 329; i < 337; i++) R18[i] = (char *(*)()) F1_15;}
	R18[338] = (char *(*)()) F1_15;
	R18[340] = (char *(*)()) F1_15;
	{long i; for (i = 343; i < 388; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 401; i < 403; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 408; i < 411; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 424; i < 428; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 457; i < 476; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 488; i < 526; i++) R18[i] = (char *(*)()) F1_15;}
	R18[668] = (char *(*)()) F1_15;
	{long i; for (i = 732; i < 734; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 746; i < 758; i++) R18[i] = (char *(*)()) F1_15;}
	R18[770] = (char *(*)()) F771_4567;
	R18[771] = (char *(*)()) F772_4632;
	R18[772] = (char *(*)()) F773_4632;
	R18[773] = (char *(*)()) F774_4632;
	R18[774] = (char *(*)()) F775_4632;
	R18[775] = (char *(*)()) F776_4632;
	R18[776] = (char *(*)()) F777_4632;
	R18[777] = (char *(*)()) F778_4632;
	R18[778] = (char *(*)()) F779_4632;
	R18[779] = (char *(*)()) F780_4632;
	R18[780] = (char *(*)()) F781_4632;
	R18[781] = (char *(*)()) F782_4632;
	R18[782] = (char *(*)()) F783_4632;
	R18[783] = (char *(*)()) F772_4632;
	R18[784] = (char *(*)()) F774_4632;
	R18[785] = (char *(*)()) F776_4632;
	R18[786] = (char *(*)()) F775_4632;
	R18[787] = (char *(*)()) F773_4632;
	R18[788] = (char *(*)()) F778_4632;
	R18[837] = (char *(*)()) F838_4725;
	R18[838] = (char *(*)()) F839_4725;
	{long i; for (i = 839; i < 841; i++) R18[i] = (char *(*)()) F1_15;}
	R18[841] = (char *(*)()) F842_4754;
	R18[842] = (char *(*)()) F843_4820;
	R18[843] = (char *(*)()) F844_4820;
	R18[844] = (char *(*)()) F845_4820;
	R18[845] = (char *(*)()) F846_4820;
	R18[846] = (char *(*)()) F847_4820;
	R18[847] = (char *(*)()) F848_4820;
	R18[848] = (char *(*)()) F849_4820;
	R18[849] = (char *(*)()) F850_4820;
	R18[850] = (char *(*)()) F851_4820;
	R18[851] = (char *(*)()) F852_4820;
	R18[852] = (char *(*)()) F853_4820;
	R18[853] = (char *(*)()) F854_4820;
	R18[854] = (char *(*)()) F855_4892;
	R18[855] = (char *(*)()) F856_4892;
	R18[856] = (char *(*)()) F857_4892;
	R18[857] = (char *(*)()) F858_4892;
	R18[858] = (char *(*)()) F859_4892;
	R18[859] = (char *(*)()) F855_4892;
	R18[860] = (char *(*)()) F856_4892;
	R18[861] = (char *(*)()) F855_4892;
	{long i; for (i = 862; i < 865; i++) R18[i] = (char *(*)()) F1_15;}
	R18[866] = (char *(*)()) F867_5013;
	{long i; for (i = 867; i < 973; i++) R18[i] = (char *(*)()) F1_15;}
	R18[974] = (char *(*)()) F974_6277;
	R18[975] = (char *(*)()) F976_6309;
	{long i; for (i = 976; i < 978; i++) R18[i] = (char *(*)()) F977_6309;}
	R18[982] = (char *(*)()) F983_6503;
	R18[983] = (char *(*)()) F982_6484;
	R18[985] = (char *(*)()) F986_6668;
	{long i; for (i = 986; i < 988; i++) R18[i] = (char *(*)()) F985_6652;}
	{long i; for (i = 988; i < 1000; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1005; i < 1028; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1029; i < 1031; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1035; i < 1038; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1041; i < 1043; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1044; i < 1054; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1055] = (char *(*)()) F1_15;
	{long i; for (i = 1057; i < 1081; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1084; i < 1095; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1098; i < 1100; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1101; i < 1103; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1105] = (char *(*)()) F1_15;
	{long i; for (i = 1130; i < 1132; i++) R18[i] = (char *(*)()) F1107_8274;}
	R18[1132] = (char *(*)()) F1110_8274;
	R18[1133] = (char *(*)()) F1107_8274;
	R18[1134] = (char *(*)()) F1111_8274;
	R18[1140] = (char *(*)()) F1107_8274;
	R18[1141] = (char *(*)()) F1108_8274;
	R18[1142] = (char *(*)()) F1109_8274;
	{long i; for (i = 1143; i < 1145; i++) R18[i] = (char *(*)()) F1111_8274;}
	{long i; for (i = 1145; i < 1149; i++) R18[i] = (char *(*)()) F1107_8274;}
	R18[1149] = (char *(*)()) F1108_8274;
	R18[1150] = (char *(*)()) F1109_8274;
	{long i; for (i = 1151; i < 1153; i++) R18[i] = (char *(*)()) F1111_8274;}
	R18[1153] = (char *(*)()) F1107_8274;
	R18[1154] = (char *(*)()) F1108_8274;
	R18[1155] = (char *(*)()) F1109_8274;
	{long i; for (i = 1156; i < 1158; i++) R18[i] = (char *(*)()) F1111_8274;}
	R18[1158] = (char *(*)()) F1107_8274;
	R18[1159] = (char *(*)()) F1108_8274;
	R18[1160] = (char *(*)()) F1109_8274;
	{long i; for (i = 1161; i < 1163; i++) R18[i] = (char *(*)()) F1111_8274;}
	{long i; for (i = 1165; i < 1167; i++) R18[i] = (char *(*)()) F1107_8274;}
	R18[1167] = (char *(*)()) F1111_8274;
	R18[1168] = (char *(*)()) F1107_8274;
	{long i; for (i = 1171; i < 1174; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1175; i < 1182; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1183; i < 1190; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1228] = (char *(*)()) F1229_8590;
	R18[1229] = (char *(*)()) F1230_8590;
	R18[1230] = (char *(*)()) F1231_8590;
	R18[1231] = (char *(*)()) F1232_8590;
	R18[1232] = (char *(*)()) F1233_8590;
	R18[1246] = (char *(*)()) F1247_8710;
	R18[1247] = (char *(*)()) F1248_8710;
	{long i; for (i = 1248; i < 1250; i++) R18[i] = (char *(*)()) F1247_8710;}
	R18[1256] = (char *(*)()) F1257_8861;
	R18[1257] = (char *(*)()) F1258_8861;
	R18[1260] = (char *(*)()) F1261_8890;
	R18[1261] = (char *(*)()) F1262_8890;
	R18[1266] = (char *(*)()) F1267_8924;
	R18[1267] = (char *(*)()) F1268_8961;
	R18[1275] = (char *(*)()) F1269_9047;
	R18[1286] = (char *(*)()) F1277_9214;
	R18[1287] = (char *(*)()) F1278_9214;
	R18[1288] = (char *(*)()) F1279_9214;
	R18[1289] = (char *(*)()) F1280_9214;
	R18[1290] = (char *(*)()) F1281_9214;
	{long i; for (i = 1291; i < 1294; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1296; i < 1300; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1301; i < 1311; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1313; i < 1324; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1330; i < 1333; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1334] = (char *(*)()) F1_15;
	{long i; for (i = 1336; i < 1338; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1339; i < 1341; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1342; i < 1344; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1345; i < 1352; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1353; i < 1355; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1361; i < 1365; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1368] = (char *(*)()) F1_15;
	{long i; for (i = 1370; i < 1375; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1376; i < 1389; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1390; i < 1395; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1396] = (char *(*)()) F1_15;
	R18[1398] = (char *(*)()) F1399_11337;
	{long i; for (i = 1399; i < 1414; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1415; i < 1422; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1422; i < 1424; i++) R18[i] = (char *(*)()) F1423_11856;}
}

char *(*R28[1424])();
void R28_init () {
	R28[0] = (char *(*)()) F1_25;
	{long i; for (i = 5; i < 16; i++) R28[i] = (char *(*)()) F1_25;}
	R28[16] = (char *(*)()) F17_143;
	R28[17] = (char *(*)()) F1_25;
	R28[21] = (char *(*)()) F1_25;
	{long i; for (i = 23; i < 26; i++) R28[i] = (char *(*)()) F1_25;}
	R28[26] = (char *(*)()) F27_243;
	{long i; for (i = 27; i < 63; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 64; i < 66; i++) R28[i] = (char *(*)()) F1_25;}
	R28[67] = (char *(*)()) F1_25;
	R28[69] = (char *(*)()) F1_25;
	R28[71] = (char *(*)()) F1_25;
	{long i; for (i = 73; i < 78; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 79; i < 88; i++) R28[i] = (char *(*)()) F1_25;}
	R28[89] = (char *(*)()) F1_25;
	R28[91] = (char *(*)()) F1_25;
	{long i; for (i = 93; i < 95; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 98; i < 101; i++) R28[i] = (char *(*)()) F1_25;}
	R28[103] = (char *(*)()) F103_1340;
	R28[105] = (char *(*)()) F1_25;
	{long i; for (i = 108; i < 129; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 130; i < 133; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 134; i < 136; i++) R28[i] = (char *(*)()) F1_25;}
	R28[143] = (char *(*)()) F1_25;
	{long i; for (i = 145; i < 163; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 165; i < 168; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 170; i < 173; i++) R28[i] = (char *(*)()) F1_25;}
	R28[175] = (char *(*)()) F1_25;
	{long i; for (i = 178; i < 182; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 183; i < 189; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 192; i < 210; i++) R28[i] = (char *(*)()) F1_25;}
	R28[212] = (char *(*)()) F1_25;
	{long i; for (i = 214; i < 231; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 231; i < 234; i++) R28[i] = (char *(*)()) F232_2471;}
	R28[236] = (char *(*)()) F232_2471;
	{long i; for (i = 238; i < 241; i++) R28[i] = (char *(*)()) F232_2471;}
	{long i; for (i = 242; i < 245; i++) R28[i] = (char *(*)()) F232_2471;}
	{long i; for (i = 246; i < 248; i++) R28[i] = (char *(*)()) F232_2471;}
	{long i; for (i = 250; i < 252; i++) R28[i] = (char *(*)()) F232_2471;}
	{long i; for (i = 253; i < 256; i++) R28[i] = (char *(*)()) F232_2471;}
	{long i; for (i = 257; i < 261; i++) R28[i] = (char *(*)()) F232_2471;}
	{long i; for (i = 262; i < 264; i++) R28[i] = (char *(*)()) F232_2471;}
	{long i; for (i = 265; i < 271; i++) R28[i] = (char *(*)()) F232_2471;}
	{long i; for (i = 271; i < 273; i++) R28[i] = (char *(*)()) F1_25;}
	R28[274] = (char *(*)()) F1_25;
	{long i; for (i = 277; i < 283; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 284; i < 286; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 287; i < 314; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 315; i < 318; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 319; i < 328; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 329; i < 337; i++) R28[i] = (char *(*)()) F1_25;}
	R28[338] = (char *(*)()) F1_25;
	R28[340] = (char *(*)()) F1_25;
	{long i; for (i = 343; i < 388; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 401; i < 403; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 408; i < 411; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 424; i < 428; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 457; i < 476; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 488; i < 526; i++) R28[i] = (char *(*)()) F1_25;}
	R28[668] = (char *(*)()) F1_25;
	{long i; for (i = 732; i < 734; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 746; i < 758; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 770; i < 789; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 837; i < 861; i++) R28[i] = (char *(*)()) F1_25;}
	R28[861] = (char *(*)()) F862_4961;
	{long i; for (i = 862; i < 865; i++) R28[i] = (char *(*)()) F1_25;}
	R28[866] = (char *(*)()) F867_5014;
	R28[867] = (char *(*)()) F868_5055;
	R28[868] = (char *(*)()) F869_5055;
	R28[869] = (char *(*)()) F870_5055;
	R28[870] = (char *(*)()) F871_5055;
	R28[871] = (char *(*)()) F872_5055;
	R28[872] = (char *(*)()) F873_5055;
	R28[873] = (char *(*)()) F874_5055;
	R28[874] = (char *(*)()) F875_5055;
	R28[875] = (char *(*)()) F876_5055;
	R28[876] = (char *(*)()) F877_5055;
	R28[877] = (char *(*)()) F878_5055;
	R28[878] = (char *(*)()) F879_5055;
	R28[879] = (char *(*)()) F880_5055;
	R28[880] = (char *(*)()) F881_5055;
	R28[881] = (char *(*)()) F882_5055;
	R28[882] = (char *(*)()) F883_5055;
	R28[883] = (char *(*)()) F884_5055;
	R28[884] = (char *(*)()) F885_5055;
	R28[885] = (char *(*)()) F886_5055;
	R28[886] = (char *(*)()) F887_5055;
	R28[887] = (char *(*)()) F888_5055;
	R28[888] = (char *(*)()) F889_5055;
	R28[889] = (char *(*)()) F890_5055;
	R28[890] = (char *(*)()) F891_5055;
	R28[891] = (char *(*)()) F892_5055;
	R28[892] = (char *(*)()) F893_5055;
	R28[893] = (char *(*)()) F894_5055;
	R28[894] = (char *(*)()) F895_5055;
	R28[895] = (char *(*)()) F896_5055;
	R28[896] = (char *(*)()) F897_5055;
	R28[897] = (char *(*)()) F898_5055;
	{long i; for (i = 898; i < 901; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 901; i < 904; i++) R28[i] = (char *(*)()) F902_5282;}
	{long i; for (i = 904; i < 907; i++) R28[i] = (char *(*)()) F905_5381;}
	{long i; for (i = 907; i < 910; i++) R28[i] = (char *(*)()) F908_5480;}
	{long i; for (i = 910; i < 913; i++) R28[i] = (char *(*)()) F911_5579;}
	{long i; for (i = 913; i < 916; i++) R28[i] = (char *(*)()) F914_5675;}
	{long i; for (i = 916; i < 919; i++) R28[i] = (char *(*)()) F917_5769;}
	{long i; for (i = 919; i < 922; i++) R28[i] = (char *(*)()) F920_5864;}
	{long i; for (i = 922; i < 925; i++) R28[i] = (char *(*)()) F923_5959;}
	R28[925] = (char *(*)()) F926_6027;
	R28[926] = (char *(*)()) F927_6052;
	R28[927] = (char *(*)()) F928_6052;
	R28[928] = (char *(*)()) F929_6093;
	R28[929] = (char *(*)()) F930_6118;
	R28[930] = (char *(*)()) F931_6118;
	{long i; for (i = 931; i < 934; i++) R28[i] = (char *(*)()) F932_6134;}
	{long i; for (i = 934; i < 937; i++) R28[i] = (char *(*)()) F935_6174;}
	{long i; for (i = 937; i < 940; i++) R28[i] = (char *(*)()) F938_6222;}
	{long i; for (i = 940; i < 971; i++) R28[i] = (char *(*)()) F941_6248;}
	R28[971] = (char *(*)()) F972_6261;
	R28[972] = (char *(*)()) F973_6261;
	{long i; for (i = 974; i < 978; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 982; i < 984; i++) R28[i] = (char *(*)()) F982_6489;}
	{long i; for (i = 985; i < 988; i++) R28[i] = (char *(*)()) F985_6657;}
	{long i; for (i = 988; i < 1000; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1005; i < 1013; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1013] = (char *(*)()) F1014_7023;
	{long i; for (i = 1014; i < 1016; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1016] = (char *(*)()) F1017_7045;
	{long i; for (i = 1017; i < 1024; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1024] = (char *(*)()) F1025_7172;
	R28[1025] = (char *(*)()) F1026_7181;
	{long i; for (i = 1026; i < 1028; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1029; i < 1031; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1035; i < 1038; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1041; i < 1043; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1044; i < 1054; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1055] = (char *(*)()) F1_25;
	{long i; for (i = 1057; i < 1076; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1076] = (char *(*)()) F1077_7655;
	{long i; for (i = 1077; i < 1081; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1084; i < 1095; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1098; i < 1100; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1101; i < 1103; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1105] = (char *(*)()) F1104_8261;
	{long i; for (i = 1130; i < 1135; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1140; i < 1163; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1165; i < 1169; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1171; i < 1174; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1175; i < 1182; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1183; i < 1190; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1228; i < 1233; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1246; i < 1250; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1256; i < 1258; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1260; i < 1262; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1266; i < 1268; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1275] = (char *(*)()) F1_25;
	{long i; for (i = 1286; i < 1294; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1296; i < 1300; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1301; i < 1309; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1309] = (char *(*)()) F1310_9504;
	R28[1310] = (char *(*)()) F1_25;
	{long i; for (i = 1313; i < 1324; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1330; i < 1333; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1334] = (char *(*)()) F1_25;
	{long i; for (i = 1336; i < 1338; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1339; i < 1341; i++) R28[i] = (char *(*)()) F1339_9962;}
	{long i; for (i = 1342; i < 1344; i++) R28[i] = (char *(*)()) F1342_10038;}
	{long i; for (i = 1345; i < 1347; i++) R28[i] = (char *(*)()) F1345_10125;}
	{long i; for (i = 1347; i < 1351; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1351] = (char *(*)()) F1352_10253;
	{long i; for (i = 1353; i < 1355; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1361; i < 1365; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1368] = (char *(*)()) F1_25;
	{long i; for (i = 1370; i < 1372; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1372] = (char *(*)()) F1373_11091;
	{long i; for (i = 1373; i < 1375; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1376; i < 1389; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1390; i < 1395; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1396] = (char *(*)()) F1_25;
	{long i; for (i = 1398; i < 1414; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1415; i < 1422; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1422; i < 1424; i++) R28[i] = (char *(*)()) F1423_11858;}
}

char *(*R259[6])();
void R259_init () {
	R259[0] = (char *(*)()) F29_256;
	R259[1] = (char *(*)()) F30_256;
	R259[2] = (char *(*)()) F31_256;
	R259[3] = (char *(*)()) F32_256;
	R259[4] = (char *(*)()) F33_256;
	R259[5] = (char *(*)()) F34_256;
}

char *(*R264[6])();
void R264_init () {
	R264[0] = (char *(*)()) F29_261;
	R264[1] = (char *(*)()) F30_261_264_47;
	R264[2] = (char *(*)()) F31_261_264_47;
	R264[3] = (char *(*)()) F32_261_264_47;
	R264[4] = (char *(*)()) F33_261_264_47;
	R264[5] = (char *(*)()) F34_261_264_47;
}
static void F30_261_264_47 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F30_261(Current, arg1, *(EIF_BOOLEAN *)arg2, arg3);
}
static void F31_261_264_47 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F31_261(Current, arg1, *(EIF_NATURAL_32 *)arg2, arg3);
}
static void F32_261_264_47 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F32_261(Current, arg1, *(EIF_NATURAL_64 *)arg2, arg3);
}
static void F33_261_264_47 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F33_261(Current, arg1, *(EIF_INTEGER_32 *)arg2, arg3);
}
static void F34_261_264_47 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F34_261(Current, arg1, *(EIF_CHARACTER_8 *)arg2, arg3);
}

char *(*R267[6])();
void R267_init () {
	R267[0] = (char *(*)()) F29_264;
	R267[1] = (char *(*)()) F30_264;
	R267[2] = (char *(*)()) F31_264;
	R267[3] = (char *(*)()) F32_264;
	R267[4] = (char *(*)()) F33_264;
	R267[5] = (char *(*)()) F34_264;
}

char *(*R920[3])();
void R920_init () {
	R920[0] = (char *(*)()) F1367_10778;
	R920[2] = (char *(*)()) F1370_10937;
}

char *(*R923[3])();
void R923_init () {
	R923[0] = (char *(*)()) F1358_10379;
	R923[2] = (char *(*)()) F1370_10968;
}

char *(*R924[3])();
void R924_init () {
	R924[0] = (char *(*)()) F1082_7776;
	R924[2] = (char *(*)()) F1370_10967;
}

char *(*R1086[389])();
void R1086_init () {
	R1086[0] = (char *(*)()) F1036_7264;
	R1086[1] = (char *(*)()) F1037_7272;
	R1086[2] = (char *(*)()) F1038_7277;
	R1086[17] = (char *(*)()) F1053_7461;
	{long i; for (i = 261; i < 265; i++) R1086[i] = (char *(*)()) F1296_9360;}
	{long i; for (i = 387; i < 389; i++) R1086[i] = (char *(*)()) F1423_11828;}
}

char *(*R1088[389])();
void R1088_init () {
	R1088[0] = (char *(*)()) F1036_7263;
	R1088[1] = (char *(*)()) F1037_7271;
	R1088[2] = (char *(*)()) F1038_7279;
	R1088[17] = (char *(*)()) F1053_7460;
	{long i; for (i = 261; i < 265; i++) R1088[i] = (char *(*)()) F1296_9359;}
	{long i; for (i = 387; i < 389; i++) R1088[i] = (char *(*)()) F1423_11872;}
}

char *(*R1242[4])();
void R1242_init () {
	R1242[0] = (char *(*)()) F84_1239;
	R1242[1] = (char *(*)()) F85_1239_1242_1;
	R1242[2] = (char *(*)()) F84_1239;
	R1242[3] = (char *(*)()) F85_1239_1242_1;
}
static EIF_REFERENCE F85_1239_1242_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F85_1239(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R1296[2])();
void R1296_init () {
	R1296[0] = (char *(*)()) F335_3363_1296_35;
	R1296[1] = (char *(*)()) F336_3392_1296_35;
}
static EIF_REFERENCE F335_3363_1296_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F335_3363(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F336_3392_1296_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F336_3392(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R1297[2])();
void R1297_init () {
	R1297[0] = (char *(*)()) F335_3371;
	R1297[1] = (char *(*)()) F336_3396;
}

char *(*R1298[2])();
void R1298_init () {
	R1298[0] = (char *(*)()) F335_3375_1298_135;
	R1298[1] = (char *(*)()) F336_3398_1298_135;
}
static void F335_3375_1298_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F335_3375(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F336_3398_1298_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F336_3398(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}

char *(*R1299[2])();
void R1299_init () {
	R1299[0] = (char *(*)()) F335_3384;
	R1299[1] = (char *(*)()) F336_3403;
}

char *(*R1300[2])();
void R1300_init () {
	R1300[0] = (char *(*)()) F335_3386;
	R1300[1] = (char *(*)()) F336_3404;
}

char *(*R1302[2])();
void R1302_init () {
	R1302[0] = (char *(*)()) F335_3388;
	R1302[1] = (char *(*)()) F336_3406;
}

char *(*R1306[2])();
void R1306_init () {
	R1306[0] = (char *(*)()) F335_3364;
	R1306[1] = (char *(*)()) F98_1306;
}

char *(*R1307[2])();
void R1307_init () {
	R1307[0] = (char *(*)()) F335_3365;
	R1307[1] = (char *(*)()) F98_1307;
}

char *(*R1308[2])();
void R1308_init () {
	R1308[0] = (char *(*)()) F335_3366;
	R1308[1] = (char *(*)()) F336_3393;
}

char *(*R1313[2])();
void R1313_init () {
	R1313[0] = (char *(*)()) F98_1313;
	R1313[1] = (char *(*)()) F336_3397;
}

char *(*R1314[2])();
void R1314_init () {
	R1314[0] = (char *(*)()) F335_3372;
	R1314[1] = (char *(*)()) F98_1314;
}

char *(*R1319[2])();
void R1319_init () {
	R1319[0] = (char *(*)()) F335_3382;
	R1319[1] = (char *(*)()) F336_3402;
}

char *(*R1338[914])();
void R1338_init () {
	R1338[0] = (char *(*)()) F104_1342;
	R1338[913] = (char *(*)()) F1017_7044;
}

char *(*R1353[5])();
void R1353_init () {
	R1353[0] = (char *(*)()) F1048_7425;
	R1353[1] = (char *(*)()) F1049_7441;
	{long i; for (i = 2; i < 5; i++) R1353[i] = (char *(*)()) F1048_7425;}
}

char *(*R1427[2])();
void R1427_init () {
	R1427[0] = (char *(*)()) F120_1433;
	R1427[1] = (char *(*)()) F121_1444;
}

char *(*R1428[2])();
void R1428_init () {
	R1428[0] = (char *(*)()) F120_1434;
	R1428[1] = (char *(*)()) F121_1445;
}

char *(*R1434[2])();
void R1434_init () {
	R1434[0] = (char *(*)()) F120_1440;
	R1434[1] = (char *(*)()) F121_1451;
}

char *(*R1437[2])();
void R1437_init () {
	R1437[0] = (char *(*)()) F120_1443;
	R1437[1] = (char *(*)()) F121_1454;
}

char *(*R1487[6])();
void R1487_init () {
	R1487[0] = (char *(*)()) F123_1504;
	R1487[1] = (char *(*)()) F124_1504_1487_1;
	R1487[2] = (char *(*)()) F125_1504_1487_1;
	R1487[3] = (char *(*)()) F126_1504_1487_1;
	R1487[4] = (char *(*)()) F123_1504;
	R1487[5] = (char *(*)()) F126_1504_1487_1;
}
static EIF_REFERENCE F124_1504_1487_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F124_1504(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(933, 0x00).id, 933, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F125_1504_1487_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F125_1504(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(915, 0x00).id, 915, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F126_1504_1487_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F126_1504(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R1488[6])();
void R1488_init () {
	R1488[0] = (char *(*)()) F123_1505;
	R1488[1] = (char *(*)()) F124_1505_1488_4;
	R1488[2] = (char *(*)()) F125_1505_1488_4;
	R1488[3] = (char *(*)()) F126_1505_1488_4;
	R1488[4] = (char *(*)()) F123_1505;
	R1488[5] = (char *(*)()) F126_1505_1488_4;
}
static void F124_1505_1488_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F124_1505(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F125_1505_1488_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F125_1505(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F126_1505_1488_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F126_1505(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R1492[2])();
void R1492_init () {
	R1492[0] = (char *(*)()) F127_1508;
	R1492[1] = (char *(*)()) F128_1508;
}

char *(*R1584[2])();
void R1584_init () {
	R1584[0] = (char *(*)()) F135_1606;
	R1584[1] = (char *(*)()) F136_1610;
}

char *(*R1585[2])();
void R1585_init () {
	R1585[0] = (char *(*)()) F135_1608;
	R1585[1] = (char *(*)()) F136_1611;
}

char *(*R1586[2])();
void R1586_init () {
	R1586[0] = (char *(*)()) F135_1607;
	R1586[1] = (char *(*)()) F136_1612;
}

char *(*R1599[13])();
void R1599_init () {
	R1599[0] = (char *(*)()) F1293_9275;
	{long i; for (i = 4; i < 8; i++) R1599[i] = (char *(*)()) F1296_9359;}
	{long i; for (i = 9; i < 13; i++) R1599[i] = (char *(*)()) F1301_9385;}
}

static EIF_TYPE_INDEX Y1616_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype5[] = {0xFF01,986,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype6[] = {0xFF01,986,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1616_pgtype31[] = {0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y1616_gen_type [1153];
EIF_TYPE_INDEX Y1616 [1153];
void Y1616_init (void)
{
	egc_routines_types [1616] = Y1616;
	egc_routines_gen_types [1616] = Y1616_gen_type;
	egc_routines_offset [1616] = 138;
	Y1616_gen_type [0] = Y1616_pgtype0;
	Y1616_gen_type [1] = Y1616_pgtype1;
	Y1616_gen_type [2] = Y1616_pgtype2;
	Y1616_gen_type [3] = Y1616_pgtype3;
	Y1616_gen_type [4] = Y1616_pgtype4;
	Y1616_gen_type [890] = Y1616_pgtype5;
	Y1616_gen_type [891] = Y1616_pgtype6;
	Y1616_gen_type [1060] = Y1616_pgtype7;
	Y1616_gen_type [1061] = Y1616_pgtype8;
	Y1616_gen_type [1062] = Y1616_pgtype9;
	Y1616_gen_type [1063] = Y1616_pgtype10;
	Y1616_gen_type [1064] = Y1616_pgtype11;
	Y1616_gen_type [1095] = Y1616_pgtype12;
	Y1616_gen_type [1096] = Y1616_pgtype13;
	Y1616_gen_type [1097] = Y1616_pgtype14;
	Y1616_gen_type [1098] = Y1616_pgtype15;
	Y1616_gen_type [1099] = Y1616_pgtype16;
	Y1616_gen_type [1138] = Y1616_pgtype17;
	Y1616_gen_type [1139] = Y1616_pgtype18;
	Y1616_gen_type [1140] = Y1616_pgtype19;
	Y1616_gen_type [1141] = Y1616_pgtype20;
	Y1616_gen_type [1142] = Y1616_pgtype21;
	Y1616_gen_type [1143] = Y1616_pgtype22;
	Y1616_gen_type [1144] = Y1616_pgtype23;
	Y1616_gen_type [1145] = Y1616_pgtype24;
	Y1616_gen_type [1146] = Y1616_pgtype25;
	Y1616_gen_type [1147] = Y1616_pgtype26;
	Y1616_gen_type [1148] = Y1616_pgtype27;
	Y1616_gen_type [1149] = Y1616_pgtype28;
	Y1616_gen_type [1150] = Y1616_pgtype29;
	Y1616_gen_type [1151] = Y1616_pgtype30;
	Y1616_gen_type [1152] = Y1616_pgtype31;
	{long i; for (i = 890; i < 892; i++) Y1616[i] = 986;};
}

char *(*R1670[1226])();
void R1670_init () {
	R1670[0] = (char *(*)()) F146_1702;
	R1670[1225] = (char *(*)()) F165_1860;
}

char *(*R1671[1226])();
void R1671_init () {
	R1671[0] = (char *(*)()) F146_1703;
	R1671[1225] = (char *(*)()) F165_1861;
}

char *(*R1672[1226])();
void R1672_init () {
	R1672[0] = (char *(*)()) F146_1704;
	R1672[1225] = (char *(*)()) F165_1862;
}


#ifdef __cplusplus
}
#endif
