#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O3737[574];
void O3737_init () {
	O3737[0] = + _CHROFF_3_3_;
	O3737[1] = + _CHROFF_4_3_;
	O3737[2] = + _CHROFF_5_3_;
	O3737[347] = + _CHROFF_5_3_;
	O3737[565] = + _CHROFF_6_3_;
	{long i; for (i = 566; i < 569; i++) O3737[i] = + _CHROFF_5_3_;}
	O3737[570] = + _CHROFF_7_3_;
	{long i; for (i = 571; i < 574; i++) O3737[i] = + _CHROFF_6_3_;}
}

long O3751[569];
void O3751_init () {
	O3751[0] =  + _REFACS_3_;
	O3751[345] =  + _REFACS_3_;
	O3751[563] =  + _REFACS_3_;
	O3751[568] =  + _REFACS_2_;
}

long O3759[569];
void O3759_init () {
	O3759[0] =  + _REFACS_4_;
	O3759[345] =  + _REFACS_4_;
	O3759[563] =  + _REFACS_4_;
	O3759[568] =  + _REFACS_3_;
}

EIF_TYPE_INDEX *Y3919_gen_type [1];
EIF_TYPE_INDEX Y3919 [1];
void Y3919_init (void)
{
	egc_routines_types [3919] = Y3919;
	egc_routines_gen_types [3919] = Y3919_gen_type;
	egc_routines_offset [3919] = 841;
	Y3919[0] = 906;
}

long O3939[8];
void O3939_init () {
	O3939[0] = 0;
	O3939[1] = + _LNGOFF_5_3_0_0_;
	O3939[2] = 0;
	O3939[3] = + _LNGOFF_4_3_0_0_;
	O3939[4] = + _PTROFF_5_3_0_7_0_0_;
	O3939[5] = 0;
	O3939[6] = + _LNGOFF_5_4_0_0_;
	O3939[7] = 0;
}

long O3948[8];
void O3948_init () {
	O3948[0] = + _LNGOFF_7_3_0_0_;
	O3948[1] = + _LNGOFF_5_3_0_1_;
	O3948[2] = + _LNGOFF_6_3_0_0_;
	O3948[3] = + _LNGOFF_4_3_0_1_;
	O3948[4] = + _LNGOFF_5_3_0_0_;
	O3948[5] = + _LNGOFF_7_4_0_0_;
	O3948[6] = + _LNGOFF_5_4_0_1_;
	O3948[7] = + _LNGOFF_9_3_0_0_;
}

long O3975[8];
void O3975_init () {
	O3975[0] =  + _REFACS_1_;
	O3975[1] = 0;
	O3975[2] =  + _REFACS_1_;
	{long i; for (i = 3; i < 5; i++) O3975[i] = 0;}
	O3975[5] =  + _REFACS_1_;
	O3975[6] = 0;
	O3975[7] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y3975_pgtype0[] = {0xFF01,746,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3975_pgtype1[] = {0xFF01,747,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3975_pgtype2[] = {0xFF01,746,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3975_pgtype3[] = {0xFF01,747,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3975_pgtype4[] = {0xFF01,755,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3975_pgtype5[] = {0xFF01,746,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3975_pgtype6[] = {0xFF01,747,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3975_pgtype7[] = {0xFF01,746,0,0xFFFF};
EIF_TYPE_INDEX *Y3975_gen_type [8];
EIF_TYPE_INDEX Y3975 [8];
void Y3975_init (void)
{
	egc_routines_types [3975] = Y3975;
	egc_routines_gen_types [3975] = Y3975_gen_type;
	egc_routines_offset [3975] = 854;
	Y3975_gen_type [0] = Y3975_pgtype0;
	Y3975_gen_type [1] = Y3975_pgtype1;
	Y3975_gen_type [2] = Y3975_pgtype2;
	Y3975_gen_type [3] = Y3975_pgtype3;
	Y3975_gen_type [4] = Y3975_pgtype4;
	Y3975_gen_type [5] = Y3975_pgtype5;
	Y3975_gen_type [6] = Y3975_pgtype6;
	Y3975_gen_type [7] = Y3975_pgtype7;
	Y3975[0] = 746;
	Y3975[1] = 747;
	Y3975[2] = 746;
	Y3975[3] = 747;
	Y3975[4] = 755;
	Y3975[5] = 746;
	Y3975[6] = 747;
	Y3975[7] = 746;
}

long O3976[8];
void O3976_init () {
	O3976[0] =  + _REFACS_2_;
	O3976[1] =  + _REFACS_1_;
	O3976[2] =  + _REFACS_2_;
	{long i; for (i = 3; i < 5; i++) O3976[i] =  + _REFACS_1_;}
	O3976[5] =  + _REFACS_2_;
	O3976[6] =  + _REFACS_1_;
	O3976[7] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y3976_pgtype0[] = {0xFF01,746,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3976_pgtype1[] = {0xFF01,746,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3976_pgtype2[] = {0xFF01,747,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3976_pgtype3[] = {0xFF01,747,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3976_pgtype4[] = {0xFF01,746,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3976_pgtype5[] = {0xFF01,746,0xFF01,978,0xFFFF};
static EIF_TYPE_INDEX Y3976_pgtype6[] = {0xFF01,746,0xFF01,978,0xFFFF};
static EIF_TYPE_INDEX Y3976_pgtype7[] = {0xFF01,746,0xFF01,986,0xFFFF};
EIF_TYPE_INDEX *Y3976_gen_type [8];
EIF_TYPE_INDEX Y3976 [8];
void Y3976_init (void)
{
	egc_routines_types [3976] = Y3976;
	egc_routines_gen_types [3976] = Y3976_gen_type;
	egc_routines_offset [3976] = 854;
	Y3976_gen_type [0] = Y3976_pgtype0;
	Y3976_gen_type [1] = Y3976_pgtype1;
	Y3976_gen_type [2] = Y3976_pgtype2;
	Y3976_gen_type [3] = Y3976_pgtype3;
	Y3976_gen_type [4] = Y3976_pgtype4;
	Y3976_gen_type [5] = Y3976_pgtype5;
	Y3976_gen_type [6] = Y3976_pgtype6;
	Y3976_gen_type [7] = Y3976_pgtype7;
	{long i; for (i = 0; i < 2; i++) Y3976[i] = 746;};
	{long i; for (i = 2; i < 4; i++) Y3976[i] = 747;};
	{long i; for (i = 4; i < 8; i++) Y3976[i] = 746;};
}

long O3977[8];
void O3977_init () {
	O3977[0] =  + _REFACS_3_;
	O3977[1] =  + _REFACS_2_;
	O3977[2] =  + _REFACS_3_;
	{long i; for (i = 3; i < 5; i++) O3977[i] =  + _REFACS_2_;}
	O3977[5] =  + _REFACS_3_;
	O3977[6] =  + _REFACS_2_;
	O3977[7] =  + _REFACS_3_;
}

long O3978[8];
void O3978_init () {
	O3978[0] =  + _REFACS_4_;
	O3978[1] =  + _REFACS_3_;
	O3978[2] =  + _REFACS_4_;
	{long i; for (i = 3; i < 5; i++) O3978[i] =  + _REFACS_3_;}
	O3978[5] =  + _REFACS_4_;
	O3978[6] =  + _REFACS_3_;
	O3978[7] =  + _REFACS_4_;
}

long O3979[8];
void O3979_init () {
	O3979[0] = + _LNGOFF_7_3_0_1_;
	O3979[1] = + _LNGOFF_5_3_0_2_;
	O3979[2] = + _LNGOFF_6_3_0_1_;
	O3979[3] = + _LNGOFF_4_3_0_2_;
	O3979[4] = + _LNGOFF_5_3_0_1_;
	O3979[5] = + _LNGOFF_7_4_0_1_;
	O3979[6] = + _LNGOFF_5_4_0_2_;
	O3979[7] = + _LNGOFF_9_3_0_1_;
}

long O3980[8];
void O3980_init () {
	O3980[0] = + _CHROFF_7_2_;
	O3980[1] = + _CHROFF_5_2_;
	O3980[2] = + _CHROFF_6_2_;
	O3980[3] = + _CHROFF_4_2_;
	O3980[4] = + _CHROFF_5_2_;
	O3980[5] = + _CHROFF_7_2_;
	O3980[6] = + _CHROFF_5_2_;
	O3980[7] = + _CHROFF_9_2_;
}

long O3981[8];
void O3981_init () {
	O3981[0] = + _LNGOFF_7_3_0_2_;
	O3981[1] = + _LNGOFF_5_3_0_3_;
	O3981[2] = + _LNGOFF_6_3_0_2_;
	O3981[3] = + _LNGOFF_4_3_0_3_;
	O3981[4] = + _LNGOFF_5_3_0_2_;
	O3981[5] = + _LNGOFF_7_4_0_2_;
	O3981[6] = + _LNGOFF_5_4_0_3_;
	O3981[7] = + _LNGOFF_9_3_0_2_;
}

long O3984[8];
void O3984_init () {
	O3984[0] = + _LNGOFF_7_3_0_3_;
	O3984[1] = + _LNGOFF_5_3_0_4_;
	O3984[2] = + _LNGOFF_6_3_0_3_;
	O3984[3] = + _LNGOFF_4_3_0_4_;
	O3984[4] = + _LNGOFF_5_3_0_3_;
	O3984[5] = + _LNGOFF_7_4_0_3_;
	O3984[6] = + _LNGOFF_5_4_0_4_;
	O3984[7] = + _LNGOFF_9_3_0_3_;
}

long O3985[8];
void O3985_init () {
	O3985[0] = + _LNGOFF_7_3_0_4_;
	O3985[1] = + _LNGOFF_5_3_0_5_;
	O3985[2] = + _LNGOFF_6_3_0_4_;
	O3985[3] = + _LNGOFF_4_3_0_5_;
	O3985[4] = + _LNGOFF_5_3_0_4_;
	O3985[5] = + _LNGOFF_7_4_0_4_;
	O3985[6] = + _LNGOFF_5_4_0_5_;
	O3985[7] = + _LNGOFF_9_3_0_4_;
}

long O3989[8];
void O3989_init () {
	O3989[0] = + _LNGOFF_7_3_0_5_;
	O3989[1] = + _LNGOFF_5_3_0_6_;
	O3989[2] = + _LNGOFF_6_3_0_5_;
	O3989[3] = + _LNGOFF_4_3_0_6_;
	O3989[4] = + _LNGOFF_5_3_0_5_;
	O3989[5] = + _LNGOFF_7_4_0_5_;
	O3989[6] = + _LNGOFF_5_4_0_6_;
	O3989[7] = + _LNGOFF_9_3_0_5_;
}

long O3990[8];
void O3990_init () {
	O3990[0] =  + _REFACS_5_;
	O3990[1] = + _LNGOFF_5_3_0_7_;
	O3990[2] =  + _REFACS_5_;
	O3990[3] = + _LNGOFF_4_3_0_7_;
	O3990[4] = + _PTROFF_5_3_0_7_0_1_;
	O3990[5] =  + _REFACS_5_;
	O3990[6] = + _LNGOFF_5_4_0_7_;
	O3990[7] =  + _REFACS_5_;
}

long O3991[8];
void O3991_init () {
	O3991[0] =  + _REFACS_6_;
	O3991[1] =  + _REFACS_4_;
	O3991[2] = + _LNGOFF_6_3_0_6_;
	O3991[3] = + _LNGOFF_4_3_0_8_;
	O3991[4] =  + _REFACS_4_;
	O3991[5] =  + _REFACS_6_;
	O3991[6] =  + _REFACS_4_;
	O3991[7] =  + _REFACS_6_;
}

long O4025[8];
void O4025_init () {
	O4025[0] = + _LNGOFF_7_3_0_6_;
	O4025[1] = + _LNGOFF_5_3_0_8_;
	O4025[2] = + _LNGOFF_6_3_0_7_;
	O4025[3] = + _LNGOFF_4_3_0_9_;
	O4025[4] = + _LNGOFF_5_3_0_6_;
	O4025[5] = + _LNGOFF_7_4_0_6_;
	O4025[6] = + _LNGOFF_5_4_0_8_;
	O4025[7] = + _LNGOFF_9_3_0_6_;
}

long O4028[2];
void O4028_init () {
	O4028[0] = + _CHROFF_7_3_;
	O4028[1] = + _CHROFF_5_3_;
}

long O4886[5];
void O4886_init () {
	{long i; for (i = 0; i < 2; i++) O4886[i] = + _CHROFF_4_0_;}
	O4886[2] = + _CHROFF_5_0_;
	{long i; for (i = 3; i < 5; i++) O4886[i] = + _CHROFF_4_0_;}
}

long O4887[5];
void O4887_init () {
	{long i; for (i = 0; i < 2; i++) O4887[i] = + _LNGOFF_4_2_0_0_;}
	O4887[2] = + _LNGOFF_5_2_0_0_;
	{long i; for (i = 3; i < 5; i++) O4887[i] = + _LNGOFF_4_3_0_0_;}
}

long O4895[5];
void O4895_init () {
	{long i; for (i = 0; i < 2; i++) O4895[i] = + _PTROFF_4_2_0_3_0_0_;}
	O4895[2] = + _PTROFF_5_2_0_3_0_0_;
	{long i; for (i = 3; i < 5; i++) O4895[i] = + _PTROFF_4_3_0_3_0_0_;}
}

long O4896[5];
void O4896_init () {
	{long i; for (i = 0; i < 2; i++) O4896[i] = + _PTROFF_4_2_0_3_0_1_;}
	O4896[2] = + _PTROFF_5_2_0_3_0_1_;
	{long i; for (i = 3; i < 5; i++) O4896[i] = + _PTROFF_4_3_0_3_0_1_;}
}

long O4898[5];
void O4898_init () {
	{long i; for (i = 0; i < 2; i++) O4898[i] = + _PTROFF_4_2_0_3_0_2_;}
	O4898[2] = + _PTROFF_5_2_0_3_0_2_;
	{long i; for (i = 3; i < 5; i++) O4898[i] = + _PTROFF_4_3_0_3_0_2_;}
}

long O4899[5];
void O4899_init () {
	{long i; for (i = 0; i < 2; i++) O4899[i] = + _LNGOFF_4_2_0_1_;}
	O4899[2] = + _LNGOFF_5_2_0_1_;
	{long i; for (i = 3; i < 5; i++) O4899[i] = + _LNGOFF_4_3_0_1_;}
}

long O4900[5];
void O4900_init () {
	{long i; for (i = 0; i < 2; i++) O4900[i] = + _CHROFF_4_1_;}
	O4900[2] = + _CHROFF_5_1_;
	{long i; for (i = 3; i < 5; i++) O4900[i] = + _CHROFF_4_1_;}
}

long O4901[5];
void O4901_init () {
	{long i; for (i = 0; i < 2; i++) O4901[i] = + _LNGOFF_4_2_0_2_;}
	O4901[2] = + _LNGOFF_5_2_0_2_;
	{long i; for (i = 3; i < 5; i++) O4901[i] = + _LNGOFF_4_3_0_2_;}
}

long O4914[3];
void O4914_init () {
	O4914[0] =  + _REFACS_4_;
	{long i; for (i = 1; i < 3; i++) O4914[i] = + _CHROFF_4_2_;}
}

long O5013[446];
void O5013_init () {
	{long i; for (i = 0; i < 3; i++) O5013[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O5013[i] = + _LNGOFF_1_0_0_0_;}
	O5013[5] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 6; i < 8; i++) O5013[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 8; i < 10; i++) O5013[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 444; i < 446; i++) O5013[i] = + _LNGOFF_1_1_0_0_;}
}

long O5014[446];
void O5014_init () {
	{long i; for (i = 0; i < 3; i++) O5014[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O5014[i] = + _LNGOFF_1_0_0_1_;}
	O5014[5] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 6; i < 8; i++) O5014[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 8; i < 10; i++) O5014[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 444; i < 446; i++) O5014[i] = + _LNGOFF_1_1_0_1_;}
}

long O5079[3];
void O5079_init () {
	{long i; for (i = 0; i < 2; i++) O5079[i] = + _LNGOFF_1_0_0_2_;}
	O5079[2] = + _LNGOFF_1_1_0_2_;
}

long O5159[440];
void O5159_init () {
	{long i; for (i = 0; i < 2; i++) O5159[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 4; i++) O5159[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 438; i < 440; i++) O5159[i] = + _LNGOFF_1_1_0_2_;}
}

long O5584[367];
void O5584_init () {
	O5584[0] = + _LNGOFF_0_0_0_0_;
	O5584[366] = + _LNGOFF_14_1_0_0_;
}

long O5617[21];
void O5617_init () {
	{long i; for (i = 0; i < 3; i++) O5617[i] = + _LNGOFF_3_1_0_0_;}
	{long i; for (i = 3; i < 6; i++) O5617[i] = + _LNGOFF_4_1_0_0_;}
	O5617[6] = + _LNGOFF_5_1_0_0_;
	O5617[7] = + _LNGOFF_4_1_0_0_;
	{long i; for (i = 14; i < 16; i++) O5617[i] = + _LNGOFF_4_1_0_0_;}
	O5617[16] = + _LNGOFF_5_2_0_0_;
	{long i; for (i = 17; i < 21; i++) O5617[i] = + _LNGOFF_4_1_0_0_;}
}

long O5667[21];
void O5667_init () {
	{long i; for (i = 0; i < 3; i++) O5667[i] = + _LNGOFF_3_1_0_1_;}
	{long i; for (i = 3; i < 6; i++) O5667[i] = + _LNGOFF_4_1_0_1_;}
	O5667[6] = + _LNGOFF_5_1_0_1_;
	O5667[7] = + _LNGOFF_4_1_0_1_;
	{long i; for (i = 14; i < 16; i++) O5667[i] = + _LNGOFF_4_1_0_1_;}
	O5667[16] = + _LNGOFF_5_2_0_1_;
	{long i; for (i = 17; i < 21; i++) O5667[i] = + _LNGOFF_4_1_0_1_;}
}

long O5668[21];
void O5668_init () {
	{long i; for (i = 0; i < 3; i++) O5668[i] = + _CHROFF_3_0_;}
	{long i; for (i = 3; i < 6; i++) O5668[i] = + _CHROFF_4_0_;}
	O5668[6] = + _CHROFF_5_0_;
	O5668[7] = + _CHROFF_4_0_;
	{long i; for (i = 14; i < 16; i++) O5668[i] = + _CHROFF_4_0_;}
	O5668[16] = + _CHROFF_5_0_;
	{long i; for (i = 17; i < 21; i++) O5668[i] = + _CHROFF_4_0_;}
}

long O5950[288];
void O5950_init () {
	O5950[0] = + _LNGOFF_1_1_0_1_;
	O5950[1] = + _LNGOFF_5_2_0_1_;
	O5950[2] = + _LNGOFF_14_3_0_1_;
	{long i; for (i = 276; i < 278; i++) O5950[i] = + _LNGOFF_18_4_0_1_;}
	{long i; for (i = 279; i < 281; i++) O5950[i] = + _LNGOFF_23_3_0_1_;}
	O5950[281] = + _LNGOFF_23_5_0_1_;
	O5950[282] = + _LNGOFF_27_4_0_1_;
	O5950[283] = + _LNGOFF_27_6_0_1_;
	O5950[286] = + _LNGOFF_31_5_0_1_;
	O5950[287] = + _LNGOFF_65_5_0_1_;
}

long O6029[287];
void O6029_init () {
	O6029[0] = + _LNGOFF_5_2_0_2_;
	O6029[1] = + _LNGOFF_14_3_0_2_;
	{long i; for (i = 275; i < 277; i++) O6029[i] = + _LNGOFF_18_4_0_2_;}
	{long i; for (i = 278; i < 280; i++) O6029[i] = + _LNGOFF_23_3_0_2_;}
	O6029[280] = + _LNGOFF_23_5_0_2_;
	O6029[281] = + _LNGOFF_27_4_0_2_;
	O6029[282] = + _LNGOFF_27_6_0_2_;
	O6029[285] = + _LNGOFF_31_5_0_2_;
	O6029[286] = + _LNGOFF_65_5_0_2_;
}

long O6033[287];
void O6033_init () {
	O6033[0] = + _LNGOFF_5_2_0_3_;
	O6033[1] = + _LNGOFF_14_3_0_3_;
	{long i; for (i = 275; i < 277; i++) O6033[i] = + _LNGOFF_18_4_0_3_;}
	{long i; for (i = 278; i < 280; i++) O6033[i] = + _LNGOFF_23_3_0_3_;}
	O6033[280] = + _LNGOFF_23_5_0_3_;
	O6033[281] = + _LNGOFF_27_4_0_3_;
	O6033[282] = + _LNGOFF_27_6_0_3_;
	O6033[285] = + _LNGOFF_31_5_0_3_;
	O6033[286] = + _LNGOFF_65_5_0_3_;
}

long O6034[287];
void O6034_init () {
	O6034[0] = + _LNGOFF_5_2_0_4_;
	O6034[1] = + _LNGOFF_14_3_0_4_;
	{long i; for (i = 275; i < 277; i++) O6034[i] = + _LNGOFF_18_4_0_4_;}
	{long i; for (i = 278; i < 280; i++) O6034[i] = + _LNGOFF_23_3_0_4_;}
	O6034[280] = + _LNGOFF_23_5_0_4_;
	O6034[281] = + _LNGOFF_27_4_0_4_;
	O6034[282] = + _LNGOFF_27_6_0_4_;
	O6034[285] = + _LNGOFF_31_5_0_4_;
	O6034[286] = + _LNGOFF_65_5_0_4_;
}

long O6035[287];
void O6035_init () {
	O6035[0] = + _LNGOFF_5_2_0_5_;
	O6035[1] = + _LNGOFF_14_3_0_5_;
	{long i; for (i = 275; i < 277; i++) O6035[i] = + _LNGOFF_18_4_0_5_;}
	{long i; for (i = 278; i < 280; i++) O6035[i] = + _LNGOFF_23_3_0_5_;}
	O6035[280] = + _LNGOFF_23_5_0_5_;
	O6035[281] = + _LNGOFF_27_4_0_5_;
	O6035[282] = + _LNGOFF_27_6_0_5_;
	O6035[285] = + _LNGOFF_31_5_0_5_;
	O6035[286] = + _LNGOFF_65_5_0_5_;
}

long O6036[287];
void O6036_init () {
	O6036[0] = + _LNGOFF_5_2_0_6_;
	O6036[1] = + _LNGOFF_14_3_0_6_;
	{long i; for (i = 275; i < 277; i++) O6036[i] = + _LNGOFF_18_4_0_6_;}
	{long i; for (i = 278; i < 280; i++) O6036[i] = + _LNGOFF_23_3_0_6_;}
	O6036[280] = + _LNGOFF_23_5_0_6_;
	O6036[281] = + _LNGOFF_27_4_0_6_;
	O6036[282] = + _LNGOFF_27_6_0_6_;
	O6036[285] = + _LNGOFF_31_5_0_6_;
	O6036[286] = + _LNGOFF_65_5_0_6_;
}

long O6037[287];
void O6037_init () {
	O6037[0] = + _LNGOFF_5_2_0_7_;
	O6037[1] = + _LNGOFF_14_3_0_7_;
	{long i; for (i = 275; i < 277; i++) O6037[i] = + _LNGOFF_18_4_0_7_;}
	{long i; for (i = 278; i < 280; i++) O6037[i] = + _LNGOFF_23_3_0_7_;}
	O6037[280] = + _LNGOFF_23_5_0_7_;
	O6037[281] = + _LNGOFF_27_4_0_7_;
	O6037[282] = + _LNGOFF_27_6_0_7_;
	O6037[285] = + _LNGOFF_31_5_0_7_;
	O6037[286] = + _LNGOFF_65_5_0_7_;
}

long O6038[287];
void O6038_init () {
	O6038[0] = + _CHROFF_5_1_;
	O6038[1] = + _CHROFF_14_1_;
	{long i; for (i = 275; i < 277; i++) O6038[i] = + _CHROFF_18_1_;}
	{long i; for (i = 278; i < 281; i++) O6038[i] = + _CHROFF_23_1_;}
	{long i; for (i = 281; i < 283; i++) O6038[i] = + _CHROFF_27_1_;}
	O6038[285] = + _CHROFF_31_1_;
	O6038[286] = + _CHROFF_65_1_;
}

long O6039[287];
void O6039_init () {
	O6039[0] = + _LNGOFF_5_2_0_8_;
	O6039[1] = + _LNGOFF_14_3_0_8_;
	{long i; for (i = 275; i < 277; i++) O6039[i] = + _LNGOFF_18_4_0_8_;}
	{long i; for (i = 278; i < 280; i++) O6039[i] = + _LNGOFF_23_3_0_8_;}
	O6039[280] = + _LNGOFF_23_5_0_8_;
	O6039[281] = + _LNGOFF_27_4_0_8_;
	O6039[282] = + _LNGOFF_27_6_0_8_;
	O6039[285] = + _LNGOFF_31_5_0_8_;
	O6039[286] = + _LNGOFF_65_5_0_8_;
}

long O6040[287];
void O6040_init () {
	O6040[0] = + _LNGOFF_5_2_0_9_;
	O6040[1] = + _LNGOFF_14_3_0_9_;
	{long i; for (i = 275; i < 277; i++) O6040[i] = + _LNGOFF_18_4_0_9_;}
	{long i; for (i = 278; i < 280; i++) O6040[i] = + _LNGOFF_23_3_0_9_;}
	O6040[280] = + _LNGOFF_23_5_0_9_;
	O6040[281] = + _LNGOFF_27_4_0_9_;
	O6040[282] = + _LNGOFF_27_6_0_9_;
	O6040[285] = + _LNGOFF_31_5_0_9_;
	O6040[286] = + _LNGOFF_65_5_0_9_;
}

long O6041[287];
void O6041_init () {
	O6041[0] = + _LNGOFF_5_2_0_10_;
	O6041[1] = + _LNGOFF_14_3_0_10_;
	{long i; for (i = 275; i < 277; i++) O6041[i] = + _LNGOFF_18_4_0_10_;}
	{long i; for (i = 278; i < 280; i++) O6041[i] = + _LNGOFF_23_3_0_10_;}
	O6041[280] = + _LNGOFF_23_5_0_10_;
	O6041[281] = + _LNGOFF_27_4_0_10_;
	O6041[282] = + _LNGOFF_27_6_0_10_;
	O6041[285] = + _LNGOFF_31_5_0_10_;
	O6041[286] = + _LNGOFF_65_5_0_10_;
}

long O6058[287];
void O6058_init () {
	O6058[0] = + _LNGOFF_5_2_0_11_;
	O6058[1] = + _LNGOFF_14_3_0_11_;
	{long i; for (i = 275; i < 277; i++) O6058[i] = + _LNGOFF_18_4_0_11_;}
	{long i; for (i = 278; i < 280; i++) O6058[i] = + _LNGOFF_23_3_0_11_;}
	O6058[280] = + _LNGOFF_23_5_0_11_;
	O6058[281] = + _LNGOFF_27_4_0_11_;
	O6058[282] = + _LNGOFF_27_6_0_11_;
	O6058[285] = + _LNGOFF_31_5_0_11_;
	O6058[286] = + _LNGOFF_65_5_0_11_;
}

long O6059[287];
void O6059_init () {
	O6059[0] = + _LNGOFF_5_2_0_12_;
	O6059[1] = + _LNGOFF_14_3_0_12_;
	{long i; for (i = 275; i < 277; i++) O6059[i] = + _LNGOFF_18_4_0_12_;}
	{long i; for (i = 278; i < 280; i++) O6059[i] = + _LNGOFF_23_3_0_12_;}
	O6059[280] = + _LNGOFF_23_5_0_12_;
	O6059[281] = + _LNGOFF_27_4_0_12_;
	O6059[282] = + _LNGOFF_27_6_0_12_;
	O6059[285] = + _LNGOFF_31_5_0_12_;
	O6059[286] = + _LNGOFF_65_5_0_12_;
}

long O6060[287];
void O6060_init () {
	O6060[0] = + _LNGOFF_5_2_0_13_;
	O6060[1] = + _LNGOFF_14_3_0_13_;
	{long i; for (i = 275; i < 277; i++) O6060[i] = + _LNGOFF_18_4_0_13_;}
	{long i; for (i = 278; i < 280; i++) O6060[i] = + _LNGOFF_23_3_0_13_;}
	O6060[280] = + _LNGOFF_23_5_0_13_;
	O6060[281] = + _LNGOFF_27_4_0_13_;
	O6060[282] = + _LNGOFF_27_6_0_13_;
	O6060[285] = + _LNGOFF_31_5_0_13_;
	O6060[286] = + _LNGOFF_65_5_0_13_;
}

long O6061[287];
void O6061_init () {
	O6061[0] = + _LNGOFF_5_2_0_14_;
	O6061[1] = + _LNGOFF_14_3_0_14_;
	{long i; for (i = 275; i < 277; i++) O6061[i] = + _LNGOFF_18_4_0_14_;}
	{long i; for (i = 278; i < 280; i++) O6061[i] = + _LNGOFF_23_3_0_14_;}
	O6061[280] = + _LNGOFF_23_5_0_14_;
	O6061[281] = + _LNGOFF_27_4_0_14_;
	O6061[282] = + _LNGOFF_27_6_0_14_;
	O6061[285] = + _LNGOFF_31_5_0_14_;
	O6061[286] = + _LNGOFF_65_5_0_14_;
}

long O6071[286];
void O6071_init () {
	O6071[0] = + _CHROFF_14_2_;
	{long i; for (i = 274; i < 276; i++) O6071[i] = + _CHROFF_18_2_;}
	{long i; for (i = 277; i < 280; i++) O6071[i] = + _CHROFF_23_2_;}
	{long i; for (i = 280; i < 282; i++) O6071[i] = + _CHROFF_27_2_;}
	O6071[284] = + _CHROFF_31_2_;
	O6071[285] = + _CHROFF_65_2_;
}

long O6073[286];
void O6073_init () {
	O6073[0] = + _LNGOFF_14_3_0_15_;
	{long i; for (i = 274; i < 276; i++) O6073[i] = + _LNGOFF_18_4_0_15_;}
	{long i; for (i = 277; i < 279; i++) O6073[i] = + _LNGOFF_23_3_0_15_;}
	O6073[279] = + _LNGOFF_23_5_0_15_;
	O6073[280] = + _LNGOFF_27_4_0_15_;
	O6073[281] = + _LNGOFF_27_6_0_15_;
	O6073[284] = + _LNGOFF_31_5_0_15_;
	O6073[285] = + _LNGOFF_65_5_0_15_;
}

long O6074[286];
void O6074_init () {
	O6074[0] = + _LNGOFF_14_3_0_16_;
	{long i; for (i = 274; i < 276; i++) O6074[i] = + _LNGOFF_18_4_0_16_;}
	{long i; for (i = 277; i < 279; i++) O6074[i] = + _LNGOFF_23_3_0_16_;}
	O6074[279] = + _LNGOFF_23_5_0_16_;
	O6074[280] = + _LNGOFF_27_4_0_16_;
	O6074[281] = + _LNGOFF_27_6_0_16_;
	O6074[284] = + _LNGOFF_31_5_0_16_;
	O6074[285] = + _LNGOFF_65_5_0_16_;
}

long O6075[286];
void O6075_init () {
	O6075[0] = + _LNGOFF_14_3_0_17_;
	{long i; for (i = 274; i < 276; i++) O6075[i] = + _LNGOFF_18_4_0_17_;}
	{long i; for (i = 277; i < 279; i++) O6075[i] = + _LNGOFF_23_3_0_17_;}
	O6075[279] = + _LNGOFF_23_5_0_17_;
	O6075[280] = + _LNGOFF_27_4_0_17_;
	O6075[281] = + _LNGOFF_27_6_0_17_;
	O6075[284] = + _LNGOFF_31_5_0_17_;
	O6075[285] = + _LNGOFF_65_5_0_17_;
}

long O6076[286];
void O6076_init () {
	O6076[0] = + _LNGOFF_14_3_0_18_;
	{long i; for (i = 274; i < 276; i++) O6076[i] = + _LNGOFF_18_4_0_18_;}
	{long i; for (i = 277; i < 279; i++) O6076[i] = + _LNGOFF_23_3_0_18_;}
	O6076[279] = + _LNGOFF_23_5_0_18_;
	O6076[280] = + _LNGOFF_27_4_0_18_;
	O6076[281] = + _LNGOFF_27_6_0_18_;
	O6076[284] = + _LNGOFF_31_5_0_18_;
	O6076[285] = + _LNGOFF_65_5_0_18_;
}

long O6077[286];
void O6077_init () {
	O6077[0] = + _LNGOFF_14_3_0_19_;
	{long i; for (i = 274; i < 276; i++) O6077[i] = + _LNGOFF_18_4_0_19_;}
	{long i; for (i = 277; i < 279; i++) O6077[i] = + _LNGOFF_23_3_0_19_;}
	O6077[279] = + _LNGOFF_23_5_0_19_;
	O6077[280] = + _LNGOFF_27_4_0_19_;
	O6077[281] = + _LNGOFF_27_6_0_19_;
	O6077[284] = + _LNGOFF_31_5_0_19_;
	O6077[285] = + _LNGOFF_65_5_0_19_;
}

long O6078[286];
void O6078_init () {
	O6078[0] = + _LNGOFF_14_3_0_20_;
	{long i; for (i = 274; i < 276; i++) O6078[i] = + _LNGOFF_18_4_0_20_;}
	{long i; for (i = 277; i < 279; i++) O6078[i] = + _LNGOFF_23_3_0_20_;}
	O6078[279] = + _LNGOFF_23_5_0_20_;
	O6078[280] = + _LNGOFF_27_4_0_20_;
	O6078[281] = + _LNGOFF_27_6_0_20_;
	O6078[284] = + _LNGOFF_31_5_0_20_;
	O6078[285] = + _LNGOFF_65_5_0_20_;
}

long O6268[277];
void O6268_init () {
	O6268[0] = + _LNGOFF_0_0_0_0_;
	{long i; for (i = 1; i < 3; i++) O6268[i] = + _LNGOFF_2_0_0_0_;}
	O6268[275] = + _LNGOFF_23_3_0_0_;
	O6268[276] = + _LNGOFF_45_3_0_0_;
}


#ifdef __cplusplus
}
#endif
