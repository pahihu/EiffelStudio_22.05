#include "epoly2.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R1673[1226])();
void R1673_init () {
	R1673[0] = (char *(*)()) F146_1705;
	R1673[1225] = (char *(*)()) F165_1863;
}

char *(*R1674[1226])();
void R1674_init () {
	R1674[0] = (char *(*)()) F146_1706;
	R1674[1225] = (char *(*)()) F165_1864;
}

char *(*R1675[1226])();
void R1675_init () {
	R1675[0] = (char *(*)()) F146_1707;
	R1675[1225] = (char *(*)()) F165_1865;
}

char *(*R1676[1226])();
void R1676_init () {
	R1676[0] = (char *(*)()) F146_1708;
	R1676[1225] = (char *(*)()) F165_1866;
}

char *(*R1677[1226])();
void R1677_init () {
	R1677[0] = (char *(*)()) F146_1709;
	R1677[1225] = (char *(*)()) F165_1867;
}

char *(*R1680[10])();
void R1680_init () {
	R1680[0] = (char *(*)()) F148_1711;
	R1680[1] = (char *(*)()) F149_1711_1680_1;
	R1680[2] = (char *(*)()) F150_1711_1680_1;
	R1680[3] = (char *(*)()) F151_1711_1680_1;
	{long i; for (i = 4; i < 6; i++) R1680[i] = (char *(*)()) F148_1711;}
	R1680[6] = (char *(*)()) F149_1711_1680_1;
	R1680[7] = (char *(*)()) F150_1711_1680_1;
	R1680[8] = (char *(*)()) F151_1711_1680_1;
	R1680[9] = (char *(*)()) F148_1711;
}
static EIF_REFERENCE F149_1711_1680_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F149_1711(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F150_1711_1680_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F150_1711(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F151_1711_1680_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F151_1711(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R1682[10])();
void R1682_init () {
	R1682[0] = (char *(*)()) F148_1713;
	R1682[1] = (char *(*)()) F149_1713_1682_4;
	R1682[2] = (char *(*)()) F150_1713_1682_4;
	R1682[3] = (char *(*)()) F151_1713_1682_4;
	{long i; for (i = 4; i < 6; i++) R1682[i] = (char *(*)()) F148_1713;}
	R1682[6] = (char *(*)()) F149_1713_1682_4;
	R1682[7] = (char *(*)()) F150_1713_1682_4;
	R1682[8] = (char *(*)()) F151_1713_1682_4;
	R1682[9] = (char *(*)()) F148_1713;
}
static void F149_1713_1682_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F149_1713(Current, *(EIF_BOOLEAN *)arg1);
}
static void F150_1713_1682_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F150_1713(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F151_1713_1682_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F151_1713(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R1683[10])();
void R1683_init () {
	R1683[0] = (char *(*)()) F148_1714;
	R1683[1] = (char *(*)()) F149_1714_1683_4;
	R1683[2] = (char *(*)()) F150_1714_1683_4;
	R1683[3] = (char *(*)()) F151_1714_1683_4;
	{long i; for (i = 4; i < 6; i++) R1683[i] = (char *(*)()) F148_1714;}
	R1683[6] = (char *(*)()) F149_1714_1683_4;
	R1683[7] = (char *(*)()) F150_1714_1683_4;
	R1683[8] = (char *(*)()) F151_1714_1683_4;
	R1683[9] = (char *(*)()) F148_1714;
}
static void F149_1714_1683_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F149_1714(Current, *(EIF_BOOLEAN *)arg1);
}
static void F150_1714_1683_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F150_1714(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F151_1714_1683_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F151_1714(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R1690[5])();
void R1690_init () {
	R1690[0] = (char *(*)()) F153_1720;
	R1690[1] = (char *(*)()) F154_1720;
	R1690[2] = (char *(*)()) F155_1720;
	R1690[3] = (char *(*)()) F156_1720;
	R1690[4] = (char *(*)()) F157_1723;
}

char *(*R1691[5])();
void R1691_init () {
	R1691[0] = (char *(*)()) F153_1721;
	R1691[1] = (char *(*)()) F154_1721;
	R1691[2] = (char *(*)()) F155_1721;
	R1691[3] = (char *(*)()) F156_1721;
	R1691[4] = (char *(*)()) F153_1721;
}

char *(*R1851[296])();
void R1851_init () {
	R1851[0] = (char *(*)()) F1010_6972;
	R1851[6] = (char *(*)()) F1016_7035;
	R1851[8] = (char *(*)()) F1018_7055;
	{long i; for (i = 292; i < 296; i++) R1851[i] = (char *(*)()) F1301_9387;}
}

char *(*R1854[296])();
void R1854_init () {
	R1854[0] = (char *(*)()) F170_1909;
	R1854[6] = (char *(*)()) F170_1909;
	R1854[8] = (char *(*)()) F170_1909;
	R1854[283] = (char *(*)()) F137_1627;
	{long i; for (i = 292; i < 296; i++) R1854[i] = (char *(*)()) F137_1627;}
}

char *(*R1857[296])();
void R1857_init () {
	R1857[0] = (char *(*)()) F1010_6971;
	R1857[6] = (char *(*)()) F1016_7029;
	R1857[8] = (char *(*)()) F1018_7060;
	{long i; for (i = 292; i < 296; i++) R1857[i] = (char *(*)()) F1003_6940;}
}

char *(*R1859[296])();
void R1859_init () {
	R1859[0] = (char *(*)()) F1010_6966;
	R1859[6] = (char *(*)()) F1016_7031;
	R1859[8] = (char *(*)()) F1018_7061;
	R1859[283] = (char *(*)()) F1293_9271;
	{long i; for (i = 292; i < 296; i++) R1859[i] = (char *(*)()) F1295_9330;}
}

char *(*R1860[296])();
void R1860_init () {
	R1860[0] = (char *(*)()) F1010_6967_1860_1;
	R1860[6] = (char *(*)()) F1016_7032_1860_1;
	R1860[8] = (char *(*)()) F1018_7062_1860_1;
	R1860[283] = (char *(*)()) F1293_9272;
	R1860[292] = (char *(*)()) F1302_9404_1860_1;
	{long i; for (i = 293; i < 296; i++) R1860[i] = (char *(*)()) F1303_9410_1860_1;}
}
static EIF_REFERENCE F1010_6967_1860_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1010_6967(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1016_7032_1860_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1016_7032(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1018_7062_1860_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1018_7062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1302_9404_1860_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1302_9404(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1303_9410_1860_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1303_9410(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R1861[296])();
void R1861_init () {
	R1861[0] = (char *(*)()) F170_1916;
	R1861[6] = (char *(*)()) F170_1916;
	R1861[8] = (char *(*)()) F170_1916;
	{long i; for (i = 292; i < 296; i++) R1861[i] = (char *(*)()) F1301_9393;}
}

char *(*R1929[2])();
void R1929_init () {
	R1929[0] = (char *(*)()) F179_1993;
	R1929[1] = (char *(*)()) F180_1997;
}

char *(*R1931[2])();
void R1931_init () {
	R1931[0] = (char *(*)()) F179_1994;
	R1931[1] = (char *(*)()) F180_1998;
}

char *(*R2039[558])();
void R2039_init () {
	R2039[0] = (char *(*)()) F867_5009;
	R2039[35] = (char *(*)()) F902_5222;
	R2039[36] = (char *(*)()) F903_5284_2039_2;
	R2039[37] = (char *(*)()) F904_5284_2039_2;
	R2039[38] = (char *(*)()) F905_5320;
	R2039[39] = (char *(*)()) F906_5383_2039_2;
	R2039[40] = (char *(*)()) F907_5383_2039_2;
	R2039[41] = (char *(*)()) F908_5419;
	R2039[42] = (char *(*)()) F909_5482_2039_2;
	R2039[43] = (char *(*)()) F910_5482_2039_2;
	R2039[44] = (char *(*)()) F911_5518;
	R2039[45] = (char *(*)()) F912_5581_2039_2;
	R2039[46] = (char *(*)()) F913_5581_2039_2;
	R2039[47] = (char *(*)()) F914_5617;
	R2039[48] = (char *(*)()) F915_5676_2039_2;
	R2039[49] = (char *(*)()) F916_5676_2039_2;
	R2039[50] = (char *(*)()) F917_5711;
	R2039[51] = (char *(*)()) F918_5770_2039_2;
	R2039[52] = (char *(*)()) F919_5770_2039_2;
	R2039[53] = (char *(*)()) F920_5805;
	R2039[54] = (char *(*)()) F921_5865_2039_2;
	R2039[55] = (char *(*)()) F922_5865_2039_2;
	R2039[56] = (char *(*)()) F923_5900;
	R2039[57] = (char *(*)()) F924_5960_2039_2;
	R2039[58] = (char *(*)()) F925_5960_2039_2;
	R2039[59] = (char *(*)()) F926_5999;
	R2039[60] = (char *(*)()) F927_6029_2039_2;
	R2039[61] = (char *(*)()) F928_6029_2039_2;
	R2039[62] = (char *(*)()) F929_6065;
	R2039[63] = (char *(*)()) F930_6095_2039_2;
	R2039[64] = (char *(*)()) F931_6095_2039_2;
	{long i; for (i = 65; i < 68; i++) R2039[i] = (char *(*)()) F932_6126;}
	{long i; for (i = 68; i < 71; i++) R2039[i] = (char *(*)()) F935_6166;}
	{long i; for (i = 116; i < 118; i++) R2039[i] = (char *(*)()) F982_6474;}
	{long i; for (i = 119; i < 122; i++) R2039[i] = (char *(*)()) F985_6642;}
	R2039[147] = (char *(*)()) F1014_7017;
	R2039[474] = (char *(*)()) F1341_10026;
	R2039[477] = (char *(*)()) F1344_10113;
	R2039[480] = (char *(*)()) F1347_10171;
	{long i; for (i = 556; i < 558; i++) R2039[i] = (char *(*)()) F1423_11814;}
}
static EIF_BOOLEAN F903_5284_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F903_5284(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F904_5284_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F904_5284(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F906_5383_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F906_5383(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F907_5383_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F907_5383(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F909_5482_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F909_5482(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F910_5482_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F910_5482(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F912_5581_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F912_5581(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F913_5581_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F913_5581(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F915_5676_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F915_5676(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F916_5676_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F916_5676(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F918_5770_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F918_5770(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F919_5770_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F919_5770(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F921_5865_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F921_5865(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F922_5865_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F922_5865(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F924_5960_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F924_5960(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F925_5960_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F925_5960(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F927_6029_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F927_6029(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F928_6029_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F928_6029(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F930_6095_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F930_6095(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F931_6095_2039_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F931_6095(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R2105[6])();
void R2105_init () {
	{long i; for (i = 0; i < 3; i++) R2105[i] = (char *(*)()) F200_2214;}
	{long i; for (i = 3; i < 6; i++) R2105[i] = (char *(*)()) F203_2251;}
}

char *(*R2121[6])();
void R2121_init () {
	{long i; for (i = 0; i < 3; i++) R2121[i] = (char *(*)()) F200_2230;}
	R2121[3] = (char *(*)()) F203_2258;
	R2121[4] = (char *(*)()) F204_2268;
	R2121[5] = (char *(*)()) F205_2284;
}

char *(*R2122[6])();
void R2122_init () {
	{long i; for (i = 0; i < 4; i++) R2122[i] = (char *(*)()) F200_2231;}
	R2122[4] = (char *(*)()) F204_2269;
	R2122[5] = (char *(*)()) F205_2285;
}

char *(*R2124[6])();
void R2124_init () {
	{long i; for (i = 0; i < 4; i++) R2124[i] = (char *(*)()) F200_2233;}
	R2124[4] = (char *(*)()) F204_2270;
	R2124[5] = (char *(*)()) F205_2286;
}

char *(*R2126[6])();
void R2126_init () {
	{long i; for (i = 0; i < 2; i++) R2126[i] = (char *(*)()) F200_2235;}
	R2126[2] = (char *(*)()) F202_2247;
	{long i; for (i = 3; i < 5; i++) R2126[i] = (char *(*)()) F200_2235;}
	R2126[5] = (char *(*)()) F202_2247;
}

char *(*R2179[1157])();
void R2179_init () {
	R2179[0] = (char *(*)()) F215_2352;
	R2179[1] = (char *(*)()) F216_2353;
	R2179[2] = (char *(*)()) F217_2361;
	R2179[3] = (char *(*)()) F218_2372;
	{long i; for (i = 4; i < 6; i++) R2179[i] = (char *(*)()) F215_2352;}
	R2179[804] = (char *(*)()) F1019_7082;
	R2179[805] = (char *(*)()) F215_2352;
	R2179[806] = (char *(*)()) F1021_7108;
	R2179[807] = (char *(*)()) F1022_7124;
	R2179[1103] = (char *(*)()) F215_2352;
	R2179[1104] = (char *(*)()) F1319_9723;
	R2179[1105] = (char *(*)()) F215_2352;
	R2179[1107] = (char *(*)()) F215_2352;
	R2179[1156] = (char *(*)()) F1370_10909;
}

char *(*R2180[1159])();
void R2180_init () {
	R2180[0] = (char *(*)()) F213_2326;
	R2180[2] = (char *(*)()) F214_2339;
	R2180[3] = (char *(*)()) F216_2354;
	R2180[4] = (char *(*)()) F217_2362;
	R2180[5] = (char *(*)()) F218_2378;
	{long i; for (i = 6; i < 8; i++) R2180[i] = (char *(*)()) F219_2393;}
	R2180[806] = (char *(*)()) F1019_7092;
	R2180[807] = (char *(*)()) F214_2339;
	R2180[808] = (char *(*)()) F1021_7117;
	R2180[809] = (char *(*)()) F1022_7126;
	R2180[1105] = (char *(*)()) F214_2339;
	R2180[1106] = (char *(*)()) F1319_9727;
	R2180[1107] = (char *(*)()) F214_2339;
	R2180[1109] = (char *(*)()) F214_2339;
	R2180[1158] = (char *(*)()) F214_2339;
}


#ifdef __cplusplus
}
#endif
