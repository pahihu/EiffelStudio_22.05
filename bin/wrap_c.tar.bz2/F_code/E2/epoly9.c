#include "epoly9.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R3626[573])();
void R3626_init () {
	{long i; for (i = 0; i < 2; i++) R3626[i] = (char *(*)()) F732_4209;}
	R3626[346] = (char *(*)()) F732_4209;
	{long i; for (i = 564; i < 568; i++) R3626[i] = (char *(*)()) F732_4209;}
	R3626[569] = (char *(*)()) F1302_9409;
	{long i; for (i = 570; i < 573; i++) R3626[i] = (char *(*)()) F1303_9412;}
}

char *(*R3627[573])();
void R3627_init () {
	{long i; for (i = 0; i < 2; i++) R3627[i] = (char *(*)()) F732_4210;}
	R3627[346] = (char *(*)()) F732_4210;
	R3627[564] = (char *(*)()) F1297_9376;
	{long i; for (i = 565; i < 568; i++) R3627[i] = (char *(*)()) F1298_9378;}
	{long i; for (i = 569; i < 573; i++) R3627[i] = (char *(*)()) F732_4210;}
}

char *(*R3628[573])();
void R3628_init () {
	{long i; for (i = 0; i < 2; i++) R3628[i] = (char *(*)()) F732_4211;}
	R3628[346] = (char *(*)()) F732_4211;
	R3628[564] = (char *(*)()) F1297_9377;
	{long i; for (i = 565; i < 568; i++) R3628[i] = (char *(*)()) F1298_9379;}
	{long i; for (i = 569; i < 573; i++) R3628[i] = (char *(*)()) F732_4211;}
}

char *(*R3670[573])();
void R3670_init () {
	R3670[0] = (char *(*)()) F733_4414;
	R3670[1] = (char *(*)()) F732_4297;
	R3670[346] = (char *(*)()) F732_4297;
	R3670[564] = (char *(*)()) F732_4297;
	{long i; for (i = 565; i < 568; i++) R3670[i] = (char *(*)()) F733_4414;}
	R3670[569] = (char *(*)()) F732_4297;
	{long i; for (i = 570; i < 573; i++) R3670[i] = (char *(*)()) F733_4414;}
}

char *(*R3671[573])();
void R3671_init () {
	{long i; for (i = 0; i < 2; i++) R3671[i] = (char *(*)()) F732_4298;}
	R3671[346] = (char *(*)()) F1079_7724;
	{long i; for (i = 564; i < 568; i++) R3671[i] = (char *(*)()) F732_4298;}
	{long i; for (i = 569; i < 573; i++) R3671[i] = (char *(*)()) F732_4298;}
}

char *(*R3754[569])();
void R3754_init () {
	R3754[0] = (char *(*)()) F734_4466;
	R3754[345] = (char *(*)()) F1079_7666;
	R3754[563] = (char *(*)()) F734_4466;
	R3754[568] = (char *(*)()) F734_4466;
}

char *(*R3772[678])();
void R3772_init () {
	R3772[0] = (char *(*)()) F747_4493;
	R3772[1] = (char *(*)()) F748_4493_3772_35;
	R3772[2] = (char *(*)()) F749_4493_3772_35;
	R3772[3] = (char *(*)()) F750_4493_3772_35;
	R3772[4] = (char *(*)()) F751_4493_3772_35;
	R3772[5] = (char *(*)()) F752_4493_3772_35;
	R3772[6] = (char *(*)()) F753_4493_3772_35;
	R3772[7] = (char *(*)()) F754_4493_3772_35;
	R3772[8] = (char *(*)()) F755_4493_3772_35;
	R3772[9] = (char *(*)()) F756_4493_3772_35;
	R3772[10] = (char *(*)()) F757_4493_3772_35;
	R3772[11] = (char *(*)()) F758_4493_3772_35;
	R3772[24] = (char *(*)()) F771_4545_3772_35;
	R3772[25] = (char *(*)()) F772_4584;
	R3772[26] = (char *(*)()) F773_4584_3772_35;
	R3772[27] = (char *(*)()) F774_4584_3772_35;
	R3772[28] = (char *(*)()) F775_4584_3772_35;
	R3772[29] = (char *(*)()) F776_4584_3772_35;
	R3772[30] = (char *(*)()) F777_4584_3772_35;
	R3772[31] = (char *(*)()) F778_4584_3772_35;
	R3772[32] = (char *(*)()) F779_4584_3772_35;
	R3772[33] = (char *(*)()) F780_4584_3772_35;
	R3772[34] = (char *(*)()) F781_4584_3772_35;
	R3772[35] = (char *(*)()) F782_4584_3772_35;
	R3772[36] = (char *(*)()) F783_4584_3772_35;
	R3772[37] = (char *(*)()) F772_4584;
	R3772[38] = (char *(*)()) F774_4584_3772_35;
	R3772[39] = (char *(*)()) F776_4584_3772_35;
	R3772[40] = (char *(*)()) F775_4584_3772_35;
	R3772[41] = (char *(*)()) F773_4584_3772_35;
	R3772[42] = (char *(*)()) F778_4584_3772_35;
	R3772[91] = (char *(*)()) F790_4642;
	R3772[92] = (char *(*)()) F791_4642_3772_35;
	R3772[96] = (char *(*)()) F843_4775;
	R3772[97] = (char *(*)()) F844_4775_3772_35;
	R3772[98] = (char *(*)()) F845_4775_3772_35;
	R3772[99] = (char *(*)()) F846_4775_3772_35;
	R3772[100] = (char *(*)()) F847_4775_3772_35;
	R3772[101] = (char *(*)()) F848_4775_3772_35;
	R3772[102] = (char *(*)()) F849_4775_3772_35;
	R3772[103] = (char *(*)()) F850_4775_3772_35;
	R3772[104] = (char *(*)()) F851_4775_3772_35;
	R3772[105] = (char *(*)()) F852_4775_3772_35;
	R3772[106] = (char *(*)()) F853_4775_3772_35;
	R3772[107] = (char *(*)()) F854_4775_3772_35;
	R3772[108] = (char *(*)()) F855_4851;
	R3772[109] = (char *(*)()) F856_4851_3772_35;
	R3772[110] = (char *(*)()) F857_4851;
	R3772[111] = (char *(*)()) F858_4851_3772_35;
	R3772[112] = (char *(*)()) F859_4851_3772_35;
	R3772[113] = (char *(*)()) F855_4851;
	R3772[114] = (char *(*)()) F856_4851_3772_35;
	R3772[115] = (char *(*)()) F855_4851;
	R3772[152] = (char *(*)()) F899_5067;
	R3772[236] = (char *(*)()) F983_6504_3772_35;
	R3772[237] = (char *(*)()) F984_6527_3772_35;
	R3772[239] = (char *(*)()) F986_6669_3772_35;
	{long i; for (i = 240; i < 242; i++) R3772[i] = (char *(*)()) F987_6691_3772_35;}
	{long i; for (i = 676; i < 678; i++) R3772[i] = (char *(*)()) F1423_11787_3772_35;}
}
static EIF_REFERENCE F748_4493_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F748_4493(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F749_4493_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F749_4493(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F750_4493_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F750_4493(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(915, 0x00).id, 915, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F751_4493_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F751_4493(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(918, 0x00).id, 918, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F752_4493_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F752_4493(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(933, 0x00).id, 933, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F753_4493_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F753_4493(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F754_4493_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F754_4493(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(924, 0x00).id, 924, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F755_4493_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F755_4493(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(921, 0x00).id, 921, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F756_4493_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F756_4493(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F757_4493_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F757_4493(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F758_4493_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F758_4493(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(930, 0x00).id, 930, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F771_4545_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F771_4545(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F773_4584_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F773_4584(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F774_4584_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F774_4584(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F775_4584_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F775_4584(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(915, 0x00).id, 915, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F776_4584_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F776_4584(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(918, 0x00).id, 918, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F777_4584_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F777_4584(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(933, 0x00).id, 933, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F778_4584_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F778_4584(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F779_4584_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F779_4584(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(924, 0x00).id, 924, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F780_4584_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F780_4584(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(921, 0x00).id, 921, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F781_4584_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F781_4584(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F782_4584_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F782_4584(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F783_4584_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F783_4584(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(930, 0x00).id, 930, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F791_4642_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F791_4642(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F844_4775_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F844_4775(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F845_4775_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F845_4775(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F846_4775_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F846_4775(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(915, 0x00).id, 915, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F847_4775_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F847_4775(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(918, 0x00).id, 918, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F848_4775_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F848_4775(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(933, 0x00).id, 933, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F849_4775_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F849_4775(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F850_4775_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F850_4775(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(924, 0x00).id, 924, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F851_4775_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F851_4775(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(921, 0x00).id, 921, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F852_4775_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F852_4775(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F853_4775_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F853_4775(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F854_4775_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F854_4775(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(930, 0x00).id, 930, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F856_4851_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F856_4851(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_4851_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F858_4851(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_4851_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F859_4851(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F983_6504_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F983_6504(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(933, 0x00).id, 933, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F984_6527_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F984_6527(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(933, 0x00).id, 933, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F986_6669_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F986_6669(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F987_6691_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F987_6691(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1423_11787_3772_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1423_11787(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R3773[678])();
void R3773_init () {
	R3773[0] = (char *(*)()) F747_4501;
	R3773[1] = (char *(*)()) F748_4501;
	R3773[2] = (char *(*)()) F749_4501;
	R3773[3] = (char *(*)()) F750_4501;
	R3773[4] = (char *(*)()) F751_4501;
	R3773[5] = (char *(*)()) F752_4501;
	R3773[6] = (char *(*)()) F753_4501;
	R3773[7] = (char *(*)()) F754_4501;
	R3773[8] = (char *(*)()) F755_4501;
	R3773[9] = (char *(*)()) F756_4501;
	R3773[10] = (char *(*)()) F757_4501;
	R3773[11] = (char *(*)()) F758_4501;
	R3773[24] = (char *(*)()) F771_4542;
	R3773[25] = (char *(*)()) F772_4589;
	R3773[26] = (char *(*)()) F773_4589;
	R3773[27] = (char *(*)()) F774_4589;
	R3773[28] = (char *(*)()) F775_4589;
	R3773[29] = (char *(*)()) F776_4589;
	R3773[30] = (char *(*)()) F777_4589;
	R3773[31] = (char *(*)()) F778_4589;
	R3773[32] = (char *(*)()) F779_4589;
	R3773[33] = (char *(*)()) F780_4589;
	R3773[34] = (char *(*)()) F781_4589;
	R3773[35] = (char *(*)()) F782_4589;
	R3773[36] = (char *(*)()) F783_4589;
	R3773[37] = (char *(*)()) F772_4589;
	R3773[38] = (char *(*)()) F774_4589;
	R3773[39] = (char *(*)()) F776_4589;
	R3773[40] = (char *(*)()) F775_4589;
	R3773[41] = (char *(*)()) F773_4589;
	R3773[42] = (char *(*)()) F778_4589;
	R3773[91] = (char *(*)()) F790_4645;
	R3773[92] = (char *(*)()) F791_4645;
	R3773[96] = (char *(*)()) F790_4645;
	R3773[97] = (char *(*)()) F791_4645;
	R3773[98] = (char *(*)()) F792_4645;
	R3773[99] = (char *(*)()) F793_4645;
	R3773[100] = (char *(*)()) F794_4645;
	R3773[101] = (char *(*)()) F795_4645;
	R3773[102] = (char *(*)()) F796_4645;
	R3773[103] = (char *(*)()) F797_4645;
	R3773[104] = (char *(*)()) F798_4645;
	R3773[105] = (char *(*)()) F799_4645;
	R3773[106] = (char *(*)()) F800_4645;
	R3773[107] = (char *(*)()) F801_4645;
	R3773[108] = (char *(*)()) F855_4856;
	R3773[109] = (char *(*)()) F856_4856;
	R3773[110] = (char *(*)()) F857_4856;
	R3773[111] = (char *(*)()) F858_4856;
	R3773[112] = (char *(*)()) F859_4856;
	R3773[113] = (char *(*)()) F855_4856;
	R3773[114] = (char *(*)()) F856_4856;
	R3773[115] = (char *(*)()) F855_4856;
	R3773[152] = (char *(*)()) F899_5097;
	{long i; for (i = 236; i < 238; i++) R3773[i] = (char *(*)()) F982_6468;}
	{long i; for (i = 239; i < 242; i++) R3773[i] = (char *(*)()) F985_6636;}
	{long i; for (i = 676; i < 678; i++) R3773[i] = (char *(*)()) F985_6636;}
}

EIF_TYPE_INDEX *Y3773_gen_type [690];
EIF_TYPE_INDEX Y3773 [690];
void Y3773_init (void)
{
	egc_routines_types [3773] = Y3773;
	egc_routines_gen_types [3773] = Y3773_gen_type;
	egc_routines_offset [3773] = 734;
	{long i; for (i = 0; i < 105; i++) Y3773[i] = 906;};
	{long i; for (i = 108; i < 128; i++) Y3773[i] = 906;};
	Y3773[164] = 906;
	{long i; for (i = 247; i < 254; i++) Y3773[i] = 906;};
	{long i; for (i = 688; i < 690; i++) Y3773[i] = 906;};
}

char *(*R3774[678])();
void R3774_init () {
	R3774[0] = (char *(*)()) F747_4502;
	R3774[1] = (char *(*)()) F748_4502;
	R3774[2] = (char *(*)()) F749_4502;
	R3774[3] = (char *(*)()) F750_4502;
	R3774[4] = (char *(*)()) F751_4502;
	R3774[5] = (char *(*)()) F752_4502;
	R3774[6] = (char *(*)()) F753_4502;
	R3774[7] = (char *(*)()) F754_4502;
	R3774[8] = (char *(*)()) F755_4502;
	R3774[9] = (char *(*)()) F756_4502;
	R3774[10] = (char *(*)()) F757_4502;
	R3774[11] = (char *(*)()) F758_4502;
	R3774[24] = (char *(*)()) F771_4544;
	R3774[25] = (char *(*)()) F772_4590;
	R3774[26] = (char *(*)()) F773_4590;
	R3774[27] = (char *(*)()) F774_4590;
	R3774[28] = (char *(*)()) F775_4590;
	R3774[29] = (char *(*)()) F776_4590;
	R3774[30] = (char *(*)()) F777_4590;
	R3774[31] = (char *(*)()) F778_4590;
	R3774[32] = (char *(*)()) F779_4590;
	R3774[33] = (char *(*)()) F780_4590;
	R3774[34] = (char *(*)()) F781_4590;
	R3774[35] = (char *(*)()) F782_4590;
	R3774[36] = (char *(*)()) F783_4590;
	R3774[37] = (char *(*)()) F772_4590;
	R3774[38] = (char *(*)()) F774_4590;
	R3774[39] = (char *(*)()) F776_4590;
	R3774[40] = (char *(*)()) F775_4590;
	R3774[41] = (char *(*)()) F773_4590;
	R3774[42] = (char *(*)()) F778_4590;
	R3774[91] = (char *(*)()) F838_4697;
	R3774[92] = (char *(*)()) F839_4697;
	R3774[96] = (char *(*)()) F843_4790;
	R3774[97] = (char *(*)()) F844_4790;
	R3774[98] = (char *(*)()) F845_4790;
	R3774[99] = (char *(*)()) F846_4790;
	R3774[100] = (char *(*)()) F847_4790;
	R3774[101] = (char *(*)()) F848_4790;
	R3774[102] = (char *(*)()) F849_4790;
	R3774[103] = (char *(*)()) F850_4790;
	R3774[104] = (char *(*)()) F851_4790;
	R3774[105] = (char *(*)()) F852_4790;
	R3774[106] = (char *(*)()) F853_4790;
	R3774[107] = (char *(*)()) F854_4790;
	R3774[108] = (char *(*)()) F855_4857;
	R3774[109] = (char *(*)()) F856_4857;
	R3774[110] = (char *(*)()) F857_4857;
	R3774[111] = (char *(*)()) F858_4857;
	R3774[112] = (char *(*)()) F859_4857;
	R3774[113] = (char *(*)()) F855_4857;
	R3774[114] = (char *(*)()) F856_4857;
	R3774[115] = (char *(*)()) F855_4857;
	R3774[152] = (char *(*)()) F899_5096;
	{long i; for (i = 236; i < 238; i++) R3774[i] = (char *(*)()) F982_6466;}
	{long i; for (i = 239; i < 242; i++) R3774[i] = (char *(*)()) F985_6634;}
	{long i; for (i = 676; i < 678; i++) R3774[i] = (char *(*)()) F1423_11803;}
}

char *(*R3776[678])();
void R3776_init () {
	R3776[0] = (char *(*)()) F747_4507;
	R3776[1] = (char *(*)()) F748_4507;
	R3776[2] = (char *(*)()) F749_4507;
	R3776[3] = (char *(*)()) F750_4507;
	R3776[4] = (char *(*)()) F751_4507;
	R3776[5] = (char *(*)()) F752_4507;
	R3776[6] = (char *(*)()) F753_4507;
	R3776[7] = (char *(*)()) F754_4507;
	R3776[8] = (char *(*)()) F755_4507;
	R3776[9] = (char *(*)()) F756_4507;
	R3776[10] = (char *(*)()) F757_4507;
	R3776[11] = (char *(*)()) F758_4507;
	R3776[24] = (char *(*)()) F771_4548;
	R3776[25] = (char *(*)()) F772_4599;
	R3776[26] = (char *(*)()) F773_4599;
	R3776[27] = (char *(*)()) F774_4599;
	R3776[28] = (char *(*)()) F775_4599;
	R3776[29] = (char *(*)()) F776_4599;
	R3776[30] = (char *(*)()) F777_4599;
	R3776[31] = (char *(*)()) F778_4599;
	R3776[32] = (char *(*)()) F779_4599;
	R3776[33] = (char *(*)()) F780_4599;
	R3776[34] = (char *(*)()) F781_4599;
	R3776[35] = (char *(*)()) F782_4599;
	R3776[36] = (char *(*)()) F783_4599;
	R3776[37] = (char *(*)()) F772_4599;
	R3776[38] = (char *(*)()) F774_4599;
	R3776[39] = (char *(*)()) F776_4599;
	R3776[40] = (char *(*)()) F775_4599;
	R3776[41] = (char *(*)()) F773_4599;
	R3776[42] = (char *(*)()) F778_4599;
	R3776[91] = (char *(*)()) F790_4650;
	R3776[92] = (char *(*)()) F791_4650;
	R3776[96] = (char *(*)()) F843_4796;
	R3776[97] = (char *(*)()) F844_4796;
	R3776[98] = (char *(*)()) F845_4796;
	R3776[99] = (char *(*)()) F846_4796;
	R3776[100] = (char *(*)()) F847_4796;
	R3776[101] = (char *(*)()) F848_4796;
	R3776[102] = (char *(*)()) F849_4796;
	R3776[103] = (char *(*)()) F850_4796;
	R3776[104] = (char *(*)()) F851_4796;
	R3776[105] = (char *(*)()) F852_4796;
	R3776[106] = (char *(*)()) F853_4796;
	R3776[107] = (char *(*)()) F854_4796;
	R3776[108] = (char *(*)()) F855_4873;
	R3776[109] = (char *(*)()) F856_4873;
	R3776[110] = (char *(*)()) F857_4873;
	R3776[111] = (char *(*)()) F858_4873;
	R3776[112] = (char *(*)()) F859_4873;
	R3776[113] = (char *(*)()) F855_4873;
	R3776[114] = (char *(*)()) F856_4873;
	R3776[115] = (char *(*)()) F855_4873;
	R3776[152] = (char *(*)()) F899_5094;
	{long i; for (i = 236; i < 238; i++) R3776[i] = (char *(*)()) F979_6327;}
	{long i; for (i = 239; i < 242; i++) R3776[i] = (char *(*)()) F979_6327;}
	{long i; for (i = 676; i < 678; i++) R3776[i] = (char *(*)()) F979_6327;}
}

char *(*R3777[12])();
void R3777_init () {
	R3777[0] = (char *(*)()) F747_4490;
	R3777[1] = (char *(*)()) F748_4490;
	R3777[2] = (char *(*)()) F749_4490;
	R3777[3] = (char *(*)()) F750_4490;
	R3777[4] = (char *(*)()) F751_4490;
	R3777[5] = (char *(*)()) F752_4490;
	R3777[6] = (char *(*)()) F753_4490;
	R3777[7] = (char *(*)()) F754_4490;
	R3777[8] = (char *(*)()) F755_4490;
	R3777[9] = (char *(*)()) F756_4490;
	R3777[10] = (char *(*)()) F757_4490;
	R3777[11] = (char *(*)()) F758_4490;
}

char *(*R3778[12])();
void R3778_init () {
	R3778[0] = (char *(*)()) F747_4491;
	R3778[1] = (char *(*)()) F748_4491_3778_135;
	R3778[2] = (char *(*)()) F749_4491_3778_135;
	R3778[3] = (char *(*)()) F750_4491_3778_135;
	R3778[4] = (char *(*)()) F751_4491_3778_135;
	R3778[5] = (char *(*)()) F752_4491_3778_135;
	R3778[6] = (char *(*)()) F753_4491_3778_135;
	R3778[7] = (char *(*)()) F754_4491_3778_135;
	R3778[8] = (char *(*)()) F755_4491_3778_135;
	R3778[9] = (char *(*)()) F756_4491_3778_135;
	R3778[10] = (char *(*)()) F757_4491_3778_135;
	R3778[11] = (char *(*)()) F758_4491_3778_135;
}
static void F748_4491_3778_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F748_4491(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F749_4491_3778_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F749_4491(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F750_4491_3778_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F750_4491(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F751_4491_3778_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F751_4491(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F752_4491_3778_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F752_4491(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F753_4491_3778_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F753_4491(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F754_4491_3778_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F754_4491(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F755_4491_3778_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F755_4491(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F756_4491_3778_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F756_4491(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F757_4491_3778_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F757_4491(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F758_4491_3778_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F758_4491(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3787[12])();
void R3787_init () {
	R3787[0] = (char *(*)()) F747_4506;
	R3787[1] = (char *(*)()) F748_4506;
	R3787[2] = (char *(*)()) F749_4506;
	R3787[3] = (char *(*)()) F750_4506;
	R3787[4] = (char *(*)()) F751_4506;
	R3787[5] = (char *(*)()) F752_4506;
	R3787[6] = (char *(*)()) F753_4506;
	R3787[7] = (char *(*)()) F754_4506;
	R3787[8] = (char *(*)()) F755_4506;
	R3787[9] = (char *(*)()) F756_4506;
	R3787[10] = (char *(*)()) F757_4506;
	R3787[11] = (char *(*)()) F758_4506;
}

char *(*R3788[12])();
void R3788_init () {
	R3788[0] = (char *(*)()) F747_4508;
	R3788[1] = (char *(*)()) F748_4508_3788_135;
	R3788[2] = (char *(*)()) F749_4508_3788_135;
	R3788[3] = (char *(*)()) F750_4508_3788_135;
	R3788[4] = (char *(*)()) F751_4508_3788_135;
	R3788[5] = (char *(*)()) F752_4508_3788_135;
	R3788[6] = (char *(*)()) F753_4508_3788_135;
	R3788[7] = (char *(*)()) F754_4508_3788_135;
	R3788[8] = (char *(*)()) F755_4508_3788_135;
	R3788[9] = (char *(*)()) F756_4508_3788_135;
	R3788[10] = (char *(*)()) F757_4508_3788_135;
	R3788[11] = (char *(*)()) F758_4508_3788_135;
}
static void F748_4508_3788_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F748_4508(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F749_4508_3788_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F749_4508(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F750_4508_3788_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F750_4508(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F751_4508_3788_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F751_4508(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F752_4508_3788_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F752_4508(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F753_4508_3788_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F753_4508(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F754_4508_3788_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F754_4508(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F755_4508_3788_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F755_4508(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F756_4508_3788_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F756_4508(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F757_4508_3788_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F757_4508(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F758_4508_3788_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F758_4508(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3789[12])();
void R3789_init () {
	R3789[0] = (char *(*)()) F747_4509;
	R3789[1] = (char *(*)()) F748_4509_3789_135;
	R3789[2] = (char *(*)()) F749_4509_3789_135;
	R3789[3] = (char *(*)()) F750_4509_3789_135;
	R3789[4] = (char *(*)()) F751_4509_3789_135;
	R3789[5] = (char *(*)()) F752_4509_3789_135;
	R3789[6] = (char *(*)()) F753_4509_3789_135;
	R3789[7] = (char *(*)()) F754_4509_3789_135;
	R3789[8] = (char *(*)()) F755_4509_3789_135;
	R3789[9] = (char *(*)()) F756_4509_3789_135;
	R3789[10] = (char *(*)()) F757_4509_3789_135;
	R3789[11] = (char *(*)()) F758_4509_3789_135;
}
static void F748_4509_3789_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F748_4509(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F749_4509_3789_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F749_4509(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F750_4509_3789_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F750_4509(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F751_4509_3789_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F751_4509(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F752_4509_3789_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F752_4509(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F753_4509_3789_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F753_4509(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F754_4509_3789_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F754_4509(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F755_4509_3789_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F755_4509(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F756_4509_3789_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F756_4509(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F757_4509_3789_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F757_4509(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F758_4509_3789_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F758_4509(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3790[12])();
void R3790_init () {
	R3790[0] = (char *(*)()) F747_4510;
	R3790[1] = (char *(*)()) F748_4510_3790_4;
	R3790[2] = (char *(*)()) F749_4510_3790_4;
	R3790[3] = (char *(*)()) F750_4510_3790_4;
	R3790[4] = (char *(*)()) F751_4510_3790_4;
	R3790[5] = (char *(*)()) F752_4510_3790_4;
	R3790[6] = (char *(*)()) F753_4510_3790_4;
	R3790[7] = (char *(*)()) F754_4510_3790_4;
	R3790[8] = (char *(*)()) F755_4510_3790_4;
	R3790[9] = (char *(*)()) F756_4510_3790_4;
	R3790[10] = (char *(*)()) F757_4510_3790_4;
	R3790[11] = (char *(*)()) F758_4510_3790_4;
}
static void F748_4510_3790_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F748_4510(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F749_4510_3790_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F749_4510(Current, *(EIF_BOOLEAN *)arg1);
}
static void F750_4510_3790_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F750_4510(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F751_4510_3790_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F751_4510(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F752_4510_3790_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F752_4510(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F753_4510_3790_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F753_4510(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F754_4510_3790_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F754_4510(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F755_4510_3790_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F755_4510(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F756_4510_3790_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F756_4510(Current, *(EIF_POINTER *)arg1);
}
static void F757_4510_3790_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F757_4510(Current, *(EIF_REAL_32 *)arg1);
}
static void F758_4510_3790_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F758_4510(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R3792[12])();
void R3792_init () {
	R3792[0] = (char *(*)()) F747_4512;
	R3792[1] = (char *(*)()) F748_4512_3792_51;
	R3792[2] = (char *(*)()) F749_4512_3792_51;
	R3792[3] = (char *(*)()) F750_4512_3792_51;
	R3792[4] = (char *(*)()) F751_4512_3792_51;
	R3792[5] = (char *(*)()) F752_4512_3792_51;
	R3792[6] = (char *(*)()) F753_4512_3792_51;
	R3792[7] = (char *(*)()) F754_4512_3792_51;
	R3792[8] = (char *(*)()) F755_4512_3792_51;
	R3792[9] = (char *(*)()) F756_4512_3792_51;
	R3792[10] = (char *(*)()) F757_4512_3792_51;
	R3792[11] = (char *(*)()) F758_4512_3792_51;
}
static void F748_4512_3792_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F748_4512(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F749_4512_3792_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F749_4512(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F750_4512_3792_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F750_4512(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F751_4512_3792_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F751_4512(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F752_4512_3792_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F752_4512(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F753_4512_3792_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F753_4512(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F754_4512_3792_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F754_4512(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F755_4512_3792_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F755_4512(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F756_4512_3792_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F756_4512(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F757_4512_3792_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F757_4512(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F758_4512_3792_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F758_4512(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R3795[12])();
void R3795_init () {
	R3795[0] = (char *(*)()) F747_4515;
	R3795[1] = (char *(*)()) F748_4515;
	R3795[2] = (char *(*)()) F749_4515;
	R3795[3] = (char *(*)()) F750_4515;
	R3795[4] = (char *(*)()) F751_4515;
	R3795[5] = (char *(*)()) F752_4515;
	R3795[6] = (char *(*)()) F753_4515;
	R3795[7] = (char *(*)()) F754_4515;
	R3795[8] = (char *(*)()) F755_4515;
	R3795[9] = (char *(*)()) F756_4515;
	R3795[10] = (char *(*)()) F757_4515;
	R3795[11] = (char *(*)()) F758_4515;
}

char *(*R3796[12])();
void R3796_init () {
	R3796[0] = (char *(*)()) F747_4516;
	R3796[1] = (char *(*)()) F748_4516;
	R3796[2] = (char *(*)()) F749_4516;
	R3796[3] = (char *(*)()) F750_4516;
	R3796[4] = (char *(*)()) F751_4516;
	R3796[5] = (char *(*)()) F752_4516;
	R3796[6] = (char *(*)()) F753_4516;
	R3796[7] = (char *(*)()) F754_4516;
	R3796[8] = (char *(*)()) F755_4516;
	R3796[9] = (char *(*)()) F756_4516;
	R3796[10] = (char *(*)()) F757_4516;
	R3796[11] = (char *(*)()) F758_4516;
}

char *(*R3797[12])();
void R3797_init () {
	R3797[0] = (char *(*)()) F747_4517;
	R3797[1] = (char *(*)()) F748_4517;
	R3797[2] = (char *(*)()) F749_4517;
	R3797[3] = (char *(*)()) F750_4517;
	R3797[4] = (char *(*)()) F751_4517;
	R3797[5] = (char *(*)()) F752_4517;
	R3797[6] = (char *(*)()) F753_4517;
	R3797[7] = (char *(*)()) F754_4517;
	R3797[8] = (char *(*)()) F755_4517;
	R3797[9] = (char *(*)()) F756_4517;
	R3797[10] = (char *(*)()) F757_4517;
	R3797[11] = (char *(*)()) F758_4517;
}

char *(*R3798[12])();
void R3798_init () {
	R3798[0] = (char *(*)()) F747_4518;
	R3798[1] = (char *(*)()) F748_4518;
	R3798[2] = (char *(*)()) F749_4518;
	R3798[3] = (char *(*)()) F750_4518;
	R3798[4] = (char *(*)()) F751_4518;
	R3798[5] = (char *(*)()) F752_4518;
	R3798[6] = (char *(*)()) F753_4518;
	R3798[7] = (char *(*)()) F754_4518;
	R3798[8] = (char *(*)()) F755_4518;
	R3798[9] = (char *(*)()) F756_4518;
	R3798[10] = (char *(*)()) F757_4518;
	R3798[11] = (char *(*)()) F758_4518;
}

char *(*R3799[12])();
void R3799_init () {
	R3799[0] = (char *(*)()) F747_4519;
	R3799[1] = (char *(*)()) F748_4519;
	R3799[2] = (char *(*)()) F749_4519;
	R3799[3] = (char *(*)()) F750_4519;
	R3799[4] = (char *(*)()) F751_4519;
	R3799[5] = (char *(*)()) F752_4519;
	R3799[6] = (char *(*)()) F753_4519;
	R3799[7] = (char *(*)()) F754_4519;
	R3799[8] = (char *(*)()) F755_4519;
	R3799[9] = (char *(*)()) F756_4519;
	R3799[10] = (char *(*)()) F757_4519;
	R3799[11] = (char *(*)()) F758_4519;
}

char *(*R3802[12])();
void R3802_init () {
	R3802[0] = (char *(*)()) F747_4522;
	R3802[1] = (char *(*)()) F748_4522;
	R3802[2] = (char *(*)()) F749_4522;
	R3802[3] = (char *(*)()) F750_4522;
	R3802[4] = (char *(*)()) F751_4522;
	R3802[5] = (char *(*)()) F752_4522;
	R3802[6] = (char *(*)()) F753_4522;
	R3802[7] = (char *(*)()) F754_4522;
	R3802[8] = (char *(*)()) F755_4522;
	R3802[9] = (char *(*)()) F756_4522;
	R3802[10] = (char *(*)()) F757_4522;
	R3802[11] = (char *(*)()) F758_4522;
}

char *(*R3803[12])();
void R3803_init () {
	R3803[0] = (char *(*)()) F747_4523;
	R3803[1] = (char *(*)()) F748_4523;
	R3803[2] = (char *(*)()) F749_4523;
	R3803[3] = (char *(*)()) F750_4523;
	R3803[4] = (char *(*)()) F751_4523;
	R3803[5] = (char *(*)()) F752_4523;
	R3803[6] = (char *(*)()) F753_4523;
	R3803[7] = (char *(*)()) F754_4523;
	R3803[8] = (char *(*)()) F755_4523;
	R3803[9] = (char *(*)()) F756_4523;
	R3803[10] = (char *(*)()) F757_4523;
	R3803[11] = (char *(*)()) F758_4523;
}

char *(*R3805[12])();
void R3805_init () {
	R3805[0] = (char *(*)()) F747_4525;
	R3805[1] = (char *(*)()) F748_4525;
	R3805[2] = (char *(*)()) F749_4525;
	R3805[3] = (char *(*)()) F750_4525;
	R3805[4] = (char *(*)()) F751_4525;
	R3805[5] = (char *(*)()) F752_4525;
	R3805[6] = (char *(*)()) F753_4525;
	R3805[7] = (char *(*)()) F754_4525;
	R3805[8] = (char *(*)()) F755_4525;
	R3805[9] = (char *(*)()) F756_4525;
	R3805[10] = (char *(*)()) F757_4525;
	R3805[11] = (char *(*)()) F758_4525;
}

char *(*R3806[12])();
void R3806_init () {
	R3806[0] = (char *(*)()) F747_4526;
	R3806[1] = (char *(*)()) F748_4526_3806_36;
	R3806[2] = (char *(*)()) F749_4526_3806_36;
	R3806[3] = (char *(*)()) F750_4526_3806_36;
	R3806[4] = (char *(*)()) F751_4526_3806_36;
	R3806[5] = (char *(*)()) F752_4526_3806_36;
	R3806[6] = (char *(*)()) F753_4526_3806_36;
	R3806[7] = (char *(*)()) F754_4526_3806_36;
	R3806[8] = (char *(*)()) F755_4526_3806_36;
	R3806[9] = (char *(*)()) F756_4526_3806_36;
	R3806[10] = (char *(*)()) F757_4526_3806_36;
	R3806[11] = (char *(*)()) F758_4526_3806_36;
}
static EIF_REFERENCE F748_4526_3806_36 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F748_4526(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F749_4526_3806_36 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F749_4526(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F750_4526_3806_36 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F750_4526(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F751_4526_3806_36 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F751_4526(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F752_4526_3806_36 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F752_4526(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F753_4526_3806_36 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F753_4526(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F754_4526_3806_36 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F754_4526(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F755_4526_3806_36 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F755_4526(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F756_4526_3806_36 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F756_4526(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F757_4526_3806_36 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F757_4526(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F758_4526_3806_36 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F758_4526(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3808[12])();
void R3808_init () {
	R3808[0] = (char *(*)()) F747_4528;
	R3808[1] = (char *(*)()) F748_4528;
	R3808[2] = (char *(*)()) F749_4528;
	R3808[3] = (char *(*)()) F750_4528;
	R3808[4] = (char *(*)()) F751_4528;
	R3808[5] = (char *(*)()) F752_4528;
	R3808[6] = (char *(*)()) F753_4528;
	R3808[7] = (char *(*)()) F754_4528;
	R3808[8] = (char *(*)()) F755_4528;
	R3808[9] = (char *(*)()) F756_4528;
	R3808[10] = (char *(*)()) F757_4528;
	R3808[11] = (char *(*)()) F758_4528;
}

char *(*R3817[12])();
void R3817_init () {
	R3817[0] = (char *(*)()) F747_4538;
	R3817[1] = (char *(*)()) F748_4538;
	R3817[2] = (char *(*)()) F749_4538;
	R3817[3] = (char *(*)()) F750_4538;
	R3817[4] = (char *(*)()) F751_4538;
	R3817[5] = (char *(*)()) F752_4538;
	R3817[6] = (char *(*)()) F753_4538;
	R3817[7] = (char *(*)()) F754_4538;
	R3817[8] = (char *(*)()) F755_4538;
	R3817[9] = (char *(*)()) F756_4538;
	R3817[10] = (char *(*)()) F757_4538;
	R3817[11] = (char *(*)()) F758_4538;
}

char *(*R3841[18])();
void R3841_init () {
	R3841[0] = (char *(*)()) F772_4582;
	R3841[1] = (char *(*)()) F773_4582;
	R3841[2] = (char *(*)()) F774_4582;
	R3841[3] = (char *(*)()) F775_4582;
	R3841[4] = (char *(*)()) F776_4582;
	R3841[5] = (char *(*)()) F777_4582;
	R3841[6] = (char *(*)()) F778_4582;
	R3841[7] = (char *(*)()) F779_4582;
	R3841[8] = (char *(*)()) F780_4582;
	R3841[9] = (char *(*)()) F781_4582;
	R3841[10] = (char *(*)()) F782_4582;
	R3841[11] = (char *(*)()) F783_4582;
	R3841[12] = (char *(*)()) F772_4582;
	R3841[13] = (char *(*)()) F774_4582;
	R3841[14] = (char *(*)()) F776_4582;
	R3841[15] = (char *(*)()) F775_4582;
	R3841[16] = (char *(*)()) F773_4582;
	R3841[17] = (char *(*)()) F778_4582;
}

char *(*R3851[18])();
void R3851_init () {
	R3851[0] = (char *(*)()) F772_4608;
	R3851[1] = (char *(*)()) F773_4608;
	R3851[2] = (char *(*)()) F774_4608;
	R3851[3] = (char *(*)()) F775_4608;
	R3851[4] = (char *(*)()) F776_4608;
	R3851[5] = (char *(*)()) F777_4608;
	R3851[6] = (char *(*)()) F778_4608;
	R3851[7] = (char *(*)()) F779_4608;
	R3851[8] = (char *(*)()) F780_4608;
	R3851[9] = (char *(*)()) F781_4608;
	R3851[10] = (char *(*)()) F782_4608;
	R3851[11] = (char *(*)()) F783_4608;
	R3851[12] = (char *(*)()) F772_4608;
	R3851[13] = (char *(*)()) F774_4608;
	R3851[14] = (char *(*)()) F776_4608;
	R3851[15] = (char *(*)()) F775_4608;
	R3851[16] = (char *(*)()) F773_4608;
	R3851[17] = (char *(*)()) F778_4608;
}

char *(*R3865[18])();
void R3865_init () {
	R3865[0] = (char *(*)()) F772_4624;
	R3865[1] = (char *(*)()) F773_4624_3865_51;
	R3865[2] = (char *(*)()) F774_4624_3865_51;
	R3865[3] = (char *(*)()) F775_4624_3865_51;
	R3865[4] = (char *(*)()) F776_4624_3865_51;
	R3865[5] = (char *(*)()) F777_4624_3865_51;
	R3865[6] = (char *(*)()) F778_4624_3865_51;
	R3865[7] = (char *(*)()) F779_4624_3865_51;
	R3865[8] = (char *(*)()) F780_4624_3865_51;
	R3865[9] = (char *(*)()) F781_4624_3865_51;
	R3865[10] = (char *(*)()) F782_4624_3865_51;
	R3865[11] = (char *(*)()) F783_4624_3865_51;
	R3865[12] = (char *(*)()) F772_4624;
	R3865[13] = (char *(*)()) F774_4624_3865_51;
	R3865[14] = (char *(*)()) F776_4624_3865_51;
	R3865[15] = (char *(*)()) F775_4624_3865_51;
	R3865[16] = (char *(*)()) F773_4624_3865_51;
	R3865[17] = (char *(*)()) F778_4624_3865_51;
}
static void F773_4624_3865_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F773_4624(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F774_4624_3865_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F774_4624(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F775_4624_3865_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F775_4624(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F776_4624_3865_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F776_4624(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F777_4624_3865_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F777_4624(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F778_4624_3865_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F778_4624(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F779_4624_3865_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F779_4624(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F780_4624_3865_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F780_4624(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F781_4624_3865_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F781_4624(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F782_4624_3865_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F782_4624(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F783_4624_3865_51 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F783_4624(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R3872[18])();
void R3872_init () {
	R3872[0] = (char *(*)()) F772_4636;
	R3872[1] = (char *(*)()) F773_4636;
	R3872[2] = (char *(*)()) F774_4636;
	R3872[3] = (char *(*)()) F775_4636;
	R3872[4] = (char *(*)()) F776_4636;
	R3872[5] = (char *(*)()) F777_4636;
	R3872[6] = (char *(*)()) F778_4636;
	R3872[7] = (char *(*)()) F779_4636;
	R3872[8] = (char *(*)()) F780_4636;
	R3872[9] = (char *(*)()) F781_4636;
	R3872[10] = (char *(*)()) F782_4636;
	R3872[11] = (char *(*)()) F783_4636;
	R3872[12] = (char *(*)()) F772_4636;
	R3872[13] = (char *(*)()) F774_4636;
	R3872[14] = (char *(*)()) F776_4636;
	R3872[15] = (char *(*)()) F775_4636;
	R3872[16] = (char *(*)()) F773_4636;
	R3872[17] = (char *(*)()) F778_4636;
}

char *(*R3878[2])();
void R3878_init () {
	R3878[0] = (char *(*)()) F838_4711;
	R3878[1] = (char *(*)()) F839_4711;
}

char *(*R3879[17])();
void R3879_init () {
	R3879[0] = (char *(*)()) F838_4712;
	R3879[1] = (char *(*)()) F839_4712;
	R3879[5] = (char *(*)()) F843_4804;
	R3879[6] = (char *(*)()) F844_4804;
	R3879[7] = (char *(*)()) F845_4804;
	R3879[8] = (char *(*)()) F846_4804;
	R3879[9] = (char *(*)()) F847_4804;
	R3879[10] = (char *(*)()) F848_4804;
	R3879[11] = (char *(*)()) F849_4804;
	R3879[12] = (char *(*)()) F850_4804;
	R3879[13] = (char *(*)()) F851_4804;
	R3879[14] = (char *(*)()) F852_4804;
	R3879[15] = (char *(*)()) F853_4804;
	R3879[16] = (char *(*)()) F854_4804;
}

char *(*R3897[2])();
void R3897_init () {
	R3897[0] = (char *(*)()) F838_4727;
	R3897[1] = (char *(*)()) F839_4727_3897_5;
}
static EIF_REFERENCE F839_4727_3897_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F839_4727(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3901[2])();
void R3901_init () {
	R3901[0] = (char *(*)()) F838_4731;
	R3901[1] = (char *(*)()) F839_4731;
}

char *(*R3903[2])();
void R3903_init () {
	R3903[0] = (char *(*)()) F838_4733;
	R3903[1] = (char *(*)()) F839_4733;
}

char *(*R3908[584])();
void R3908_init () {
	R3908[0] = (char *(*)()) F841_4735;
	R3908[1] = (char *(*)()) F842_4761;
	R3908[2] = (char *(*)()) F843_4830;
	R3908[3] = (char *(*)()) F844_4830;
	R3908[4] = (char *(*)()) F845_4830;
	R3908[5] = (char *(*)()) F846_4830;
	R3908[6] = (char *(*)()) F847_4830;
	R3908[7] = (char *(*)()) F848_4830;
	R3908[8] = (char *(*)()) F849_4830;
	R3908[9] = (char *(*)()) F850_4830;
	R3908[10] = (char *(*)()) F851_4830;
	R3908[11] = (char *(*)()) F852_4830;
	R3908[12] = (char *(*)()) F853_4830;
	R3908[13] = (char *(*)()) F854_4830;
	R3908[14] = (char *(*)()) F855_4894;
	R3908[15] = (char *(*)()) F856_4894;
	R3908[16] = (char *(*)()) F857_4894;
	R3908[17] = (char *(*)()) F858_4894;
	R3908[18] = (char *(*)()) F859_4894;
	R3908[19] = (char *(*)()) F855_4894;
	R3908[20] = (char *(*)()) F856_4894;
	R3908[21] = (char *(*)()) F855_4894;
	R3908[58] = (char *(*)()) F899_5175;
	{long i; for (i = 134; i < 138; i++) R3908[i] = (char *(*)()) F974_6281;}
	R3908[142] = (char *(*)()) F983_6520;
	R3908[143] = (char *(*)()) F984_6611;
	{long i; for (i = 146; i < 148; i++) R3908[i] = (char *(*)()) F987_6775;}
	R3908[300] = (char *(*)()) F1141_8327;
	R3908[301] = (char *(*)()) F1142_8327;
	R3908[302] = (char *(*)()) F1143_8327;
	R3908[303] = (char *(*)()) F1144_8327;
	R3908[304] = (char *(*)()) F1145_8327;
	{long i; for (i = 305; i < 309; i++) R3908[i] = (char *(*)()) F1141_8327;}
	R3908[309] = (char *(*)()) F1142_8327;
	R3908[310] = (char *(*)()) F1143_8327;
	R3908[311] = (char *(*)()) F1144_8327;
	R3908[312] = (char *(*)()) F1145_8327;
	R3908[313] = (char *(*)()) F1141_8327;
	R3908[314] = (char *(*)()) F1142_8327;
	R3908[315] = (char *(*)()) F1143_8327;
	R3908[316] = (char *(*)()) F1144_8327;
	R3908[317] = (char *(*)()) F1145_8327;
	R3908[318] = (char *(*)()) F1141_8327;
	R3908[319] = (char *(*)()) F1142_8327;
	R3908[320] = (char *(*)()) F1143_8327;
	R3908[321] = (char *(*)()) F1144_8327;
	R3908[322] = (char *(*)()) F1145_8327;
	R3908[325] = (char *(*)()) F1166_8373;
	R3908[426] = (char *(*)()) F1267_8944;
	R3908[427] = (char *(*)()) F1268_9025;
	R3908[435] = (char *(*)()) F1275_9176;
	R3908[446] = (char *(*)()) F1282_9260;
	R3908[447] = (char *(*)()) F1283_9260;
	R3908[448] = (char *(*)()) F1284_9260;
	R3908[449] = (char *(*)()) F1285_9260;
	R3908[450] = (char *(*)()) F1286_9260;
	{long i; for (i = 582; i < 584; i++) R3908[i] = (char *(*)()) F987_6775;}
}

char *(*R3924[12])();
void R3924_init () {
	R3924[0] = (char *(*)()) F843_4773;
	R3924[1] = (char *(*)()) F844_4773;
	R3924[2] = (char *(*)()) F845_4773;
	R3924[3] = (char *(*)()) F846_4773;
	R3924[4] = (char *(*)()) F847_4773;
	R3924[5] = (char *(*)()) F848_4773;
	R3924[6] = (char *(*)()) F849_4773;
	R3924[7] = (char *(*)()) F850_4773;
	R3924[8] = (char *(*)()) F851_4773;
	R3924[9] = (char *(*)()) F852_4773;
	R3924[10] = (char *(*)()) F853_4773;
	R3924[11] = (char *(*)()) F854_4773;
}

char *(*R3928[12])();
void R3928_init () {
	R3928[0] = (char *(*)()) F843_4792;
	R3928[1] = (char *(*)()) F844_4792;
	R3928[2] = (char *(*)()) F845_4792;
	R3928[3] = (char *(*)()) F846_4792;
	R3928[4] = (char *(*)()) F847_4792;
	R3928[5] = (char *(*)()) F848_4792;
	R3928[6] = (char *(*)()) F849_4792;
	R3928[7] = (char *(*)()) F850_4792;
	R3928[8] = (char *(*)()) F851_4792;
	R3928[9] = (char *(*)()) F852_4792;
	R3928[10] = (char *(*)()) F853_4792;
	R3928[11] = (char *(*)()) F854_4792;
}

char *(*R3935[8])();
void R3935_init () {
	R3935[0] = (char *(*)()) F855_4835;
	R3935[1] = (char *(*)()) F856_4835;
	R3935[2] = (char *(*)()) F857_4835;
	R3935[3] = (char *(*)()) F858_4835;
	R3935[4] = (char *(*)()) F859_4835;
	R3935[5] = (char *(*)()) F855_4835;
	R3935[6] = (char *(*)()) F856_4835;
	R3935[7] = (char *(*)()) F855_4835;
}

char *(*R3936[8])();
void R3936_init () {
	R3936[0] = (char *(*)()) F855_4836;
	R3936[1] = (char *(*)()) F856_4836;
	R3936[2] = (char *(*)()) F857_4836;
	R3936[3] = (char *(*)()) F858_4836;
	R3936[4] = (char *(*)()) F859_4836;
	R3936[5] = (char *(*)()) F855_4836;
	R3936[6] = (char *(*)()) F856_4836;
	R3936[7] = (char *(*)()) F855_4836;
}

char *(*R3938[8])();
void R3938_init () {
	R3938[0] = (char *(*)()) F855_4838;
	R3938[1] = (char *(*)()) F856_4838;
	R3938[2] = (char *(*)()) F857_4838;
	R3938[3] = (char *(*)()) F858_4838;
	R3938[4] = (char *(*)()) F859_4838;
	R3938[5] = (char *(*)()) F855_4838;
	R3938[6] = (char *(*)()) F856_4838;
	R3938[7] = (char *(*)()) F855_4838;
}

char *(*R3939[8])();
void R3939_init () {
	R3939[0] = (char *(*)()) F855_4839;
	R3939[1] = (char *(*)()) F856_4839_3939_1;
	R3939[2] = (char *(*)()) F857_4839;
	R3939[3] = (char *(*)()) F858_4839_3939_1;
	R3939[4] = (char *(*)()) F859_4839_3939_1;
	R3939[5] = (char *(*)()) F855_4839;
	R3939[6] = (char *(*)()) F856_4839_3939_1;
	R3939[7] = (char *(*)()) F855_4839;
}
static EIF_REFERENCE F856_4839_3939_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F856_4839(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_4839_3939_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F858_4839(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_4839_3939_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F859_4839(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R3947[8])();
void R3947_init () {
	R3947[0] = (char *(*)()) F855_4852;
	R3947[1] = (char *(*)()) F856_4852;
	R3947[2] = (char *(*)()) F857_4852_3947_29;
	R3947[3] = (char *(*)()) F858_4852_3947_29;
	R3947[4] = (char *(*)()) F859_4852;
	R3947[5] = (char *(*)()) F860_4949;
	R3947[6] = (char *(*)()) F861_4949;
	R3947[7] = (char *(*)()) F855_4852;
}
static EIF_INTEGER_32 F857_4852_3947_29 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F857_4852(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F858_4852_3947_29 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F858_4852(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3949[8])();
void R3949_init () {
	R3949[0] = (char *(*)()) F855_4859;
	R3949[1] = (char *(*)()) F856_4859;
	R3949[2] = (char *(*)()) F857_4859_3949_3;
	R3949[3] = (char *(*)()) F858_4859_3949_3;
	R3949[4] = (char *(*)()) F859_4859;
	R3949[5] = (char *(*)()) F860_4951;
	R3949[6] = (char *(*)()) F861_4951;
	R3949[7] = (char *(*)()) F855_4859;
}
static EIF_BOOLEAN F857_4859_3949_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F857_4859(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F858_4859_3949_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F858_4859(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R3955[8])();
void R3955_init () {
	R3955[0] = (char *(*)()) F855_4867;
	R3955[1] = (char *(*)()) F856_4867;
	R3955[2] = (char *(*)()) F857_4867;
	R3955[3] = (char *(*)()) F858_4867;
	R3955[4] = (char *(*)()) F859_4867;
	R3955[5] = (char *(*)()) F855_4867;
	R3955[6] = (char *(*)()) F856_4867;
	R3955[7] = (char *(*)()) F855_4867;
}

char *(*R3956[8])();
void R3956_init () {
	R3956[0] = (char *(*)()) F855_4868;
	R3956[1] = (char *(*)()) F856_4868;
	R3956[2] = (char *(*)()) F857_4868;
	R3956[3] = (char *(*)()) F858_4868;
	R3956[4] = (char *(*)()) F859_4868;
	R3956[5] = (char *(*)()) F855_4868;
	R3956[6] = (char *(*)()) F856_4868;
	R3956[7] = (char *(*)()) F855_4868;
}

char *(*R3964[8])();
void R3964_init () {
	R3964[0] = (char *(*)()) F855_4877;
	R3964[1] = (char *(*)()) F856_4877;
	R3964[2] = (char *(*)()) F857_4877_3964_4;
	R3964[3] = (char *(*)()) F858_4877_3964_4;
	R3964[4] = (char *(*)()) F859_4877;
	R3964[5] = (char *(*)()) F855_4877;
	R3964[6] = (char *(*)()) F856_4877;
	R3964[7] = (char *(*)()) F855_4877;
}
static void F857_4877_3964_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F857_4877(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F858_4877_3964_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F858_4877(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3966[8])();
void R3966_init () {
	R3966[0] = (char *(*)()) F855_4879;
	R3966[1] = (char *(*)()) F856_4879;
	R3966[2] = (char *(*)()) F857_4879;
	R3966[3] = (char *(*)()) F858_4879;
	R3966[4] = (char *(*)()) F859_4879;
	R3966[5] = (char *(*)()) F855_4879;
	R3966[6] = (char *(*)()) F856_4879;
	R3966[7] = (char *(*)()) F855_4879;
}

char *(*R3967[8])();
void R3967_init () {
	R3967[0] = (char *(*)()) F855_4880;
	R3967[1] = (char *(*)()) F856_4880;
	R3967[2] = (char *(*)()) F857_4880;
	R3967[3] = (char *(*)()) F858_4880;
	R3967[4] = (char *(*)()) F859_4880;
	R3967[5] = (char *(*)()) F855_4880;
	R3967[6] = (char *(*)()) F856_4880;
	R3967[7] = (char *(*)()) F855_4880;
}

char *(*R3973[8])();
void R3973_init () {
	R3973[0] = (char *(*)()) F855_4893;
	R3973[1] = (char *(*)()) F856_4893;
	R3973[2] = (char *(*)()) F857_4893;
	R3973[3] = (char *(*)()) F858_4893;
	R3973[4] = (char *(*)()) F859_4893;
	R3973[5] = (char *(*)()) F860_4953;
	R3973[6] = (char *(*)()) F861_4953;
	R3973[7] = (char *(*)()) F855_4893;
}

char *(*R3982[8])();
void R3982_init () {
	R3982[0] = (char *(*)()) F855_4903;
	R3982[1] = (char *(*)()) F856_4903;
	R3982[2] = (char *(*)()) F857_4903;
	R3982[3] = (char *(*)()) F858_4903;
	R3982[4] = (char *(*)()) F859_4903;
	R3982[5] = (char *(*)()) F855_4903;
	R3982[6] = (char *(*)()) F856_4903;
	R3982[7] = (char *(*)()) F855_4903;
}

char *(*R3983[8])();
void R3983_init () {
	R3983[0] = (char *(*)()) F855_4904;
	R3983[1] = (char *(*)()) F856_4904;
	R3983[2] = (char *(*)()) F857_4904;
	R3983[3] = (char *(*)()) F858_4904;
	R3983[4] = (char *(*)()) F859_4904;
	R3983[5] = (char *(*)()) F855_4904;
	R3983[6] = (char *(*)()) F856_4904;
	R3983[7] = (char *(*)()) F855_4904;
}

char *(*R3990[8])();
void R3990_init () {
	R3990[0] = (char *(*)()) F855_4911;
	R3990[1] = (char *(*)()) F856_4911_3990_1;
	R3990[2] = (char *(*)()) F857_4911;
	R3990[3] = (char *(*)()) F858_4911_3990_1;
	R3990[4] = (char *(*)()) F859_4911_3990_1;
	R3990[5] = (char *(*)()) F855_4911;
	R3990[6] = (char *(*)()) F856_4911_3990_1;
	R3990[7] = (char *(*)()) F855_4911;
}
static EIF_REFERENCE F856_4911_3990_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F856_4911(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_4911_3990_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F858_4911(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_4911_3990_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F859_4911(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R3991[8])();
void R3991_init () {
	R3991[0] = (char *(*)()) F855_4912;
	R3991[1] = (char *(*)()) F856_4912;
	R3991[2] = (char *(*)()) F857_4912_3991_1;
	R3991[3] = (char *(*)()) F858_4912_3991_1;
	R3991[4] = (char *(*)()) F859_4912;
	R3991[5] = (char *(*)()) F855_4912;
	R3991[6] = (char *(*)()) F856_4912;
	R3991[7] = (char *(*)()) F855_4912;
}
static EIF_REFERENCE F857_4912_3991_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F857_4912(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_4912_3991_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F858_4912(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R3992[8])();
void R3992_init () {
	R3992[0] = (char *(*)()) F855_4913;
	R3992[1] = (char *(*)()) F856_4913;
	R3992[2] = (char *(*)()) F857_4913;
	R3992[3] = (char *(*)()) F858_4913;
	R3992[4] = (char *(*)()) F859_4913;
	R3992[5] = (char *(*)()) F855_4913;
	R3992[6] = (char *(*)()) F856_4913;
	R3992[7] = (char *(*)()) F855_4913;
}

char *(*R3993[8])();
void R3993_init () {
	R3993[0] = (char *(*)()) F855_4914;
	R3993[1] = (char *(*)()) F856_4914;
	R3993[2] = (char *(*)()) F857_4914;
	R3993[3] = (char *(*)()) F858_4914;
	R3993[4] = (char *(*)()) F859_4914;
	R3993[5] = (char *(*)()) F855_4914;
	R3993[6] = (char *(*)()) F856_4914;
	R3993[7] = (char *(*)()) F855_4914;
}

char *(*R3994[8])();
void R3994_init () {
	R3994[0] = (char *(*)()) F855_4915;
	R3994[1] = (char *(*)()) F856_4915;
	R3994[2] = (char *(*)()) F857_4915;
	R3994[3] = (char *(*)()) F858_4915;
	R3994[4] = (char *(*)()) F859_4915;
	R3994[5] = (char *(*)()) F855_4915;
	R3994[6] = (char *(*)()) F856_4915;
	R3994[7] = (char *(*)()) F855_4915;
}

char *(*R3995[8])();
void R3995_init () {
	R3995[0] = (char *(*)()) F855_4916;
	R3995[1] = (char *(*)()) F856_4916;
	R3995[2] = (char *(*)()) F857_4916;
	R3995[3] = (char *(*)()) F858_4916;
	R3995[4] = (char *(*)()) F859_4916;
	R3995[5] = (char *(*)()) F855_4916;
	R3995[6] = (char *(*)()) F856_4916;
	R3995[7] = (char *(*)()) F855_4916;
}

char *(*R3996[8])();
void R3996_init () {
	R3996[0] = (char *(*)()) F855_4917;
	R3996[1] = (char *(*)()) F856_4917;
	R3996[2] = (char *(*)()) F857_4917;
	R3996[3] = (char *(*)()) F858_4917;
	R3996[4] = (char *(*)()) F859_4917;
	R3996[5] = (char *(*)()) F855_4917;
	R3996[6] = (char *(*)()) F856_4917;
	R3996[7] = (char *(*)()) F855_4917;
}

char *(*R3998[8])();
void R3998_init () {
	R3998[0] = (char *(*)()) F855_4919;
	R3998[1] = (char *(*)()) F856_4919;
	R3998[2] = (char *(*)()) F857_4919;
	R3998[3] = (char *(*)()) F858_4919;
	R3998[4] = (char *(*)()) F859_4919;
	R3998[5] = (char *(*)()) F855_4919;
	R3998[6] = (char *(*)()) F856_4919;
	R3998[7] = (char *(*)()) F855_4919;
}

char *(*R3999[8])();
void R3999_init () {
	R3999[0] = (char *(*)()) F855_4920;
	R3999[1] = (char *(*)()) F856_4920;
	R3999[2] = (char *(*)()) F857_4920;
	R3999[3] = (char *(*)()) F858_4920;
	R3999[4] = (char *(*)()) F859_4920;
	R3999[5] = (char *(*)()) F855_4920;
	R3999[6] = (char *(*)()) F856_4920;
	R3999[7] = (char *(*)()) F855_4920;
}

char *(*R4000[8])();
void R4000_init () {
	R4000[0] = (char *(*)()) F855_4921;
	R4000[1] = (char *(*)()) F856_4921;
	R4000[2] = (char *(*)()) F857_4921;
	R4000[3] = (char *(*)()) F858_4921;
	R4000[4] = (char *(*)()) F859_4921;
	R4000[5] = (char *(*)()) F855_4921;
	R4000[6] = (char *(*)()) F856_4921;
	R4000[7] = (char *(*)()) F855_4921;
}

char *(*R4004[8])();
void R4004_init () {
	R4004[0] = (char *(*)()) F855_4925;
	R4004[1] = (char *(*)()) F856_4925;
	R4004[2] = (char *(*)()) F857_4925_4004_4;
	R4004[3] = (char *(*)()) F858_4925_4004_4;
	R4004[4] = (char *(*)()) F859_4925;
	R4004[5] = (char *(*)()) F855_4925;
	R4004[6] = (char *(*)()) F856_4925;
	R4004[7] = (char *(*)()) F855_4925;
}
static void F857_4925_4004_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F857_4925(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F858_4925_4004_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F858_4925(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4010[8])();
void R4010_init () {
	R4010[0] = (char *(*)()) F855_4931;
	R4010[1] = (char *(*)()) F856_4931;
	R4010[2] = (char *(*)()) F857_4931;
	R4010[3] = (char *(*)()) F858_4931;
	R4010[4] = (char *(*)()) F859_4931;
	R4010[5] = (char *(*)()) F855_4931;
	R4010[6] = (char *(*)()) F856_4931;
	R4010[7] = (char *(*)()) F855_4931;
}

char *(*R4023[8])();
void R4023_init () {
	R4023[0] = (char *(*)()) F855_4944;
	R4023[1] = (char *(*)()) F856_4944;
	R4023[2] = (char *(*)()) F857_4944;
	R4023[3] = (char *(*)()) F858_4944;
	R4023[4] = (char *(*)()) F859_4944;
	R4023[5] = (char *(*)()) F855_4944;
	R4023[6] = (char *(*)()) F856_4944;
	R4023[7] = (char *(*)()) F855_4944;
}

char *(*R4026[2])();
void R4026_init () {
	R4026[0] = (char *(*)()) F860_4947;
	R4026[1] = (char *(*)()) F861_4947;
}

char *(*R4044[558])();
void R4044_init () {
	R4044[0] = (char *(*)()) F867_4999;
	R4044[1] = (char *(*)()) F868_5041;
	R4044[2] = (char *(*)()) F869_5041;
	R4044[3] = (char *(*)()) F870_5041;
	R4044[4] = (char *(*)()) F871_5041;
	R4044[5] = (char *(*)()) F872_5041;
	R4044[6] = (char *(*)()) F873_5041;
	R4044[7] = (char *(*)()) F874_5041;
	R4044[8] = (char *(*)()) F875_5041;
	R4044[9] = (char *(*)()) F876_5041;
	R4044[10] = (char *(*)()) F877_5041;
	R4044[11] = (char *(*)()) F878_5041;
	R4044[12] = (char *(*)()) F879_5041;
	R4044[13] = (char *(*)()) F880_5041;
	R4044[14] = (char *(*)()) F881_5041;
	R4044[15] = (char *(*)()) F882_5041;
	R4044[16] = (char *(*)()) F883_5041;
	R4044[17] = (char *(*)()) F884_5041;
	R4044[18] = (char *(*)()) F885_5041;
	R4044[19] = (char *(*)()) F886_5041;
	R4044[20] = (char *(*)()) F887_5041;
	R4044[21] = (char *(*)()) F888_5041;
	R4044[22] = (char *(*)()) F889_5041;
	R4044[23] = (char *(*)()) F890_5041;
	R4044[24] = (char *(*)()) F891_5041;
	R4044[25] = (char *(*)()) F892_5041;
	R4044[26] = (char *(*)()) F893_5041;
	R4044[27] = (char *(*)()) F894_5041;
	R4044[28] = (char *(*)()) F895_5041;
	R4044[29] = (char *(*)()) F896_5041;
	R4044[30] = (char *(*)()) F897_5041;
	R4044[31] = (char *(*)()) F898_5041;
	R4044[32] = (char *(*)()) F899_5093;
	{long i; for (i = 33; i < 35; i++) R4044[i] = (char *(*)()) F900_5203;}
	{long i; for (i = 35; i < 38; i++) R4044[i] = (char *(*)()) F902_5215;}
	{long i; for (i = 38; i < 41; i++) R4044[i] = (char *(*)()) F905_5313;}
	{long i; for (i = 41; i < 44; i++) R4044[i] = (char *(*)()) F908_5412;}
	{long i; for (i = 44; i < 47; i++) R4044[i] = (char *(*)()) F911_5511;}
	{long i; for (i = 47; i < 50; i++) R4044[i] = (char *(*)()) F914_5610;}
	{long i; for (i = 50; i < 53; i++) R4044[i] = (char *(*)()) F917_5704;}
	{long i; for (i = 53; i < 56; i++) R4044[i] = (char *(*)()) F920_5798;}
	{long i; for (i = 56; i < 59; i++) R4044[i] = (char *(*)()) F923_5893;}
	{long i; for (i = 59; i < 62; i++) R4044[i] = (char *(*)()) F926_5988;}
	{long i; for (i = 62; i < 65; i++) R4044[i] = (char *(*)()) F929_6054;}
	{long i; for (i = 65; i < 68; i++) R4044[i] = (char *(*)()) F932_6121;}
	{long i; for (i = 68; i < 71; i++) R4044[i] = (char *(*)()) F935_6162;}
	{long i; for (i = 71; i < 74; i++) R4044[i] = (char *(*)()) F938_6210;}
	{long i; for (i = 74; i < 105; i++) R4044[i] = (char *(*)()) F941_6231;}
	R4044[105] = (char *(*)()) F972_6257;
	R4044[106] = (char *(*)()) F973_6257;
	{long i; for (i = 108; i < 112; i++) R4044[i] = (char *(*)()) F974_6265;}
	{long i; for (i = 116; i < 118; i++) R4044[i] = (char *(*)()) F979_6324;}
	{long i; for (i = 119; i < 122; i++) R4044[i] = (char *(*)()) F979_6324;}
	R4044[147] = (char *(*)()) F1014_7015;
	R4044[158] = (char *(*)()) F1025_7166;
	R4044[159] = (char *(*)()) F1026_7180;
	{long i; for (i = 175; i < 177; i++) R4044[i] = (char *(*)()) F1040_7333;}
	{long i; for (i = 178; i < 181; i++) R4044[i] = (char *(*)()) F1040_7333;}
	R4044[187] = (char *(*)()) F1040_7333;
	R4044[189] = (char *(*)()) F1040_7333;
	{long i; for (i = 191; i < 194; i++) R4044[i] = (char *(*)()) F1040_7333;}
	R4044[443] = (char *(*)()) F1310_9500;
	R4044[473] = (char *(*)()) F1340_9972;
	R4044[474] = (char *(*)()) F1341_10012;
	R4044[476] = (char *(*)()) F1343_10057;
	R4044[477] = (char *(*)()) F1344_10095;
	R4044[479] = (char *(*)()) F1346_10142;
	R4044[480] = (char *(*)()) F1347_10165;
	{long i; for (i = 497; i < 499; i++) R4044[i] = (char *(*)()) F1364_10685;}
	{long i; for (i = 556; i < 558; i++) R4044[i] = (char *(*)()) F1423_11798;}
}

char *(*R4102[31])();
void R4102_init () {
	R4102[0] = (char *(*)()) F868_5037;
	R4102[1] = (char *(*)()) F869_5037;
	R4102[2] = (char *(*)()) F870_5037;
	R4102[3] = (char *(*)()) F871_5037;
	R4102[4] = (char *(*)()) F872_5037;
	R4102[5] = (char *(*)()) F873_5037;
	R4102[6] = (char *(*)()) F874_5037;
	R4102[7] = (char *(*)()) F875_5037;
	R4102[8] = (char *(*)()) F876_5037;
	R4102[9] = (char *(*)()) F877_5037;
	R4102[10] = (char *(*)()) F878_5037;
	R4102[11] = (char *(*)()) F879_5037;
	R4102[12] = (char *(*)()) F880_5037;
	R4102[13] = (char *(*)()) F881_5037;
	R4102[14] = (char *(*)()) F882_5037;
	R4102[15] = (char *(*)()) F883_5037;
	R4102[16] = (char *(*)()) F884_5037;
	R4102[17] = (char *(*)()) F885_5037;
	R4102[18] = (char *(*)()) F886_5037;
	R4102[19] = (char *(*)()) F887_5037;
	R4102[20] = (char *(*)()) F888_5037;
	R4102[21] = (char *(*)()) F889_5037;
	R4102[22] = (char *(*)()) F890_5037;
	R4102[23] = (char *(*)()) F891_5037;
	R4102[24] = (char *(*)()) F892_5037;
	R4102[25] = (char *(*)()) F893_5037;
	R4102[26] = (char *(*)()) F894_5037;
	R4102[27] = (char *(*)()) F895_5037;
	R4102[28] = (char *(*)()) F896_5037;
	R4102[29] = (char *(*)()) F897_5037;
	R4102[30] = (char *(*)()) F898_5037;
}

char *(*R4103[31])();
void R4103_init () {
	R4103[0] = (char *(*)()) F868_5038;
	R4103[1] = (char *(*)()) F869_5038;
	R4103[2] = (char *(*)()) F870_5038;
	R4103[3] = (char *(*)()) F871_5038;
	R4103[4] = (char *(*)()) F872_5038;
	R4103[5] = (char *(*)()) F873_5038;
	R4103[6] = (char *(*)()) F874_5038;
	R4103[7] = (char *(*)()) F875_5038;
	R4103[8] = (char *(*)()) F876_5038;
	R4103[9] = (char *(*)()) F877_5038;
	R4103[10] = (char *(*)()) F878_5038;
	R4103[11] = (char *(*)()) F879_5038;
	R4103[12] = (char *(*)()) F880_5038;
	R4103[13] = (char *(*)()) F881_5038;
	R4103[14] = (char *(*)()) F882_5038;
	R4103[15] = (char *(*)()) F883_5038;
	R4103[16] = (char *(*)()) F884_5038;
	R4103[17] = (char *(*)()) F885_5038;
	R4103[18] = (char *(*)()) F886_5038;
	R4103[19] = (char *(*)()) F887_5038;
	R4103[20] = (char *(*)()) F888_5038;
	R4103[21] = (char *(*)()) F889_5038;
	R4103[22] = (char *(*)()) F890_5038;
	R4103[23] = (char *(*)()) F891_5038;
	R4103[24] = (char *(*)()) F892_5038;
	R4103[25] = (char *(*)()) F893_5038;
	R4103[26] = (char *(*)()) F894_5038;
	R4103[27] = (char *(*)()) F895_5038;
	R4103[28] = (char *(*)()) F896_5038;
	R4103[29] = (char *(*)()) F897_5038;
	R4103[30] = (char *(*)()) F898_5038;
}

char *(*R4105[31])();
void R4105_init () {
	R4105[0] = (char *(*)()) F868_5040;
	R4105[1] = (char *(*)()) F869_5040;
	R4105[2] = (char *(*)()) F870_5040;
	R4105[3] = (char *(*)()) F871_5040;
	R4105[4] = (char *(*)()) F872_5040;
	R4105[5] = (char *(*)()) F873_5040;
	R4105[6] = (char *(*)()) F874_5040;
	R4105[7] = (char *(*)()) F875_5040;
	R4105[8] = (char *(*)()) F876_5040;
	R4105[9] = (char *(*)()) F877_5040;
	R4105[10] = (char *(*)()) F878_5040;
	R4105[11] = (char *(*)()) F879_5040;
	R4105[12] = (char *(*)()) F880_5040;
	R4105[13] = (char *(*)()) F881_5040;
	R4105[14] = (char *(*)()) F882_5040;
	R4105[15] = (char *(*)()) F883_5040;
	R4105[16] = (char *(*)()) F884_5040;
	R4105[17] = (char *(*)()) F885_5040;
	R4105[18] = (char *(*)()) F886_5040;
	R4105[19] = (char *(*)()) F887_5040;
	R4105[20] = (char *(*)()) F888_5040;
	R4105[21] = (char *(*)()) F889_5040;
	R4105[22] = (char *(*)()) F890_5040;
	R4105[23] = (char *(*)()) F891_5040;
	R4105[24] = (char *(*)()) F892_5040;
	R4105[25] = (char *(*)()) F893_5040;
	R4105[26] = (char *(*)()) F894_5040;
	R4105[27] = (char *(*)()) F895_5040;
	R4105[28] = (char *(*)()) F896_5040;
	R4105[29] = (char *(*)()) F897_5040;
	R4105[30] = (char *(*)()) F898_5040;
}

char *(*R4107[31])();
void R4107_init () {
	R4107[0] = (char *(*)()) F868_5043;
	R4107[1] = (char *(*)()) F869_5043;
	R4107[2] = (char *(*)()) F870_5043;
	R4107[3] = (char *(*)()) F871_5043;
	R4107[4] = (char *(*)()) F872_5043;
	R4107[5] = (char *(*)()) F873_5043;
	R4107[6] = (char *(*)()) F874_5043;
	R4107[7] = (char *(*)()) F875_5043;
	R4107[8] = (char *(*)()) F876_5043;
	R4107[9] = (char *(*)()) F877_5043;
	R4107[10] = (char *(*)()) F878_5043;
	R4107[11] = (char *(*)()) F879_5043;
	R4107[12] = (char *(*)()) F880_5043;
	R4107[13] = (char *(*)()) F881_5043;
	R4107[14] = (char *(*)()) F882_5043;
	R4107[15] = (char *(*)()) F883_5043;
	R4107[16] = (char *(*)()) F884_5043;
	R4107[17] = (char *(*)()) F885_5043;
	R4107[18] = (char *(*)()) F886_5043;
	R4107[19] = (char *(*)()) F887_5043;
	R4107[20] = (char *(*)()) F888_5043;
	R4107[21] = (char *(*)()) F889_5043;
	R4107[22] = (char *(*)()) F890_5043;
	R4107[23] = (char *(*)()) F891_5043;
	R4107[24] = (char *(*)()) F892_5043;
	R4107[25] = (char *(*)()) F893_5043;
	R4107[26] = (char *(*)()) F894_5043;
	R4107[27] = (char *(*)()) F895_5043;
	R4107[28] = (char *(*)()) F896_5043;
	R4107[29] = (char *(*)()) F897_5043;
	R4107[30] = (char *(*)()) F898_5043;
}

char *(*R4110[31])();
void R4110_init () {
	R4110[0] = (char *(*)()) F868_5046;
	R4110[1] = (char *(*)()) F869_5046;
	R4110[2] = (char *(*)()) F870_5046;
	R4110[3] = (char *(*)()) F871_5046;
	R4110[4] = (char *(*)()) F872_5046;
	R4110[5] = (char *(*)()) F873_5046;
	R4110[6] = (char *(*)()) F874_5046;
	R4110[7] = (char *(*)()) F875_5046;
	R4110[8] = (char *(*)()) F876_5046;
	R4110[9] = (char *(*)()) F877_5046;
	R4110[10] = (char *(*)()) F878_5046;
	R4110[11] = (char *(*)()) F879_5046;
	R4110[12] = (char *(*)()) F880_5046;
	R4110[13] = (char *(*)()) F881_5046;
	R4110[14] = (char *(*)()) F882_5046;
	R4110[15] = (char *(*)()) F883_5046;
	R4110[16] = (char *(*)()) F884_5046;
	R4110[17] = (char *(*)()) F885_5046;
	R4110[18] = (char *(*)()) F886_5046;
	R4110[19] = (char *(*)()) F887_5046;
	R4110[20] = (char *(*)()) F888_5046;
	R4110[21] = (char *(*)()) F889_5046;
	R4110[22] = (char *(*)()) F890_5046;
	R4110[23] = (char *(*)()) F891_5046;
	R4110[24] = (char *(*)()) F892_5046;
	R4110[25] = (char *(*)()) F893_5046;
	R4110[26] = (char *(*)()) F894_5046;
	R4110[27] = (char *(*)()) F895_5046;
	R4110[28] = (char *(*)()) F896_5046;
	R4110[29] = (char *(*)()) F897_5046;
	R4110[30] = (char *(*)()) F898_5046;
}

char *(*R4115[31])();
void R4115_init () {
	R4115[0] = (char *(*)()) F868_5054;
	R4115[1] = (char *(*)()) F869_5054_4115_1;
	R4115[2] = (char *(*)()) F870_5054_4115_1;
	R4115[3] = (char *(*)()) F871_5054_4115_1;
	R4115[4] = (char *(*)()) F872_5054_4115_1;
	R4115[5] = (char *(*)()) F873_5054_4115_1;
	R4115[6] = (char *(*)()) F874_5054_4115_1;
	R4115[7] = (char *(*)()) F875_5054_4115_1;
	R4115[8] = (char *(*)()) F876_5054_4115_1;
	R4115[9] = (char *(*)()) F877_5054_4115_1;
	R4115[10] = (char *(*)()) F878_5054_4115_1;
	R4115[11] = (char *(*)()) F879_5054_4115_1;
	R4115[12] = (char *(*)()) F880_5054_4115_1;
	R4115[13] = (char *(*)()) F881_5054_4115_1;
	R4115[14] = (char *(*)()) F882_5054_4115_1;
	R4115[15] = (char *(*)()) F883_5054_4115_1;
	R4115[16] = (char *(*)()) F884_5054;
	R4115[17] = (char *(*)()) F885_5054_4115_1;
	R4115[18] = (char *(*)()) F886_5054_4115_1;
	R4115[19] = (char *(*)()) F887_5054_4115_1;
	R4115[20] = (char *(*)()) F888_5054_4115_1;
	R4115[21] = (char *(*)()) F889_5054_4115_1;
	R4115[22] = (char *(*)()) F890_5054_4115_1;
	R4115[23] = (char *(*)()) F891_5054_4115_1;
	R4115[24] = (char *(*)()) F892_5054_4115_1;
	R4115[25] = (char *(*)()) F893_5054_4115_1;
	R4115[26] = (char *(*)()) F894_5054_4115_1;
	R4115[27] = (char *(*)()) F895_5054_4115_1;
	R4115[28] = (char *(*)()) F896_5054_4115_1;
	R4115[29] = (char *(*)()) F897_5054_4115_1;
	R4115[30] = (char *(*)()) F898_5054_4115_1;
}
static EIF_REFERENCE F869_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F869_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F870_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F870_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {942,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 942, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F871_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F871_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(930, 0x00).id, 930, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F872_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F872_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F873_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F873_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(924, 0x00).id, 924, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F874_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F874_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(921, 0x00).id, 921, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F875_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F875_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(918, 0x00).id, 918, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F876_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F876_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(915, 0x00).id, 915, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F877_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F877_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(912, 0x00).id, 912, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F878_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F878_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(909, 0x00).id, 909, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F879_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F879_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F880_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F880_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(903, 0x00).id, 903, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F881_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F881_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F882_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F882_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F883_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F883_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(933, 0x00).id, 933, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F885_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F885_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {944,912,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 944, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F886_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F886_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {946,972,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 946, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F887_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F887_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {948,915,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 948, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F888_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F888_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {950,918,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 950, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F889_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F889_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {952,927,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 952, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F890_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F890_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {954,930,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 954, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F891_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F891_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {956,939,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 956, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F892_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F892_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {958,906,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 958, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F893_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F893_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {960,933,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 960, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F894_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F894_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {962,936,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 962, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F895_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F895_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {964,924,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 964, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F896_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F896_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {966,921,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 966, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F897_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F897_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {968,903,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 968, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F898_5054_4115_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F898_5054(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {970,909,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 970, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}

char *(*R4125[31])();
void R4125_init () {
	R4125[0] = (char *(*)()) F868_5066;
	R4125[1] = (char *(*)()) F869_5066;
	R4125[2] = (char *(*)()) F870_5066;
	R4125[3] = (char *(*)()) F871_5066;
	R4125[4] = (char *(*)()) F872_5066;
	R4125[5] = (char *(*)()) F873_5066;
	R4125[6] = (char *(*)()) F874_5066;
	R4125[7] = (char *(*)()) F875_5066;
	R4125[8] = (char *(*)()) F876_5066;
	R4125[9] = (char *(*)()) F877_5066;
	R4125[10] = (char *(*)()) F878_5066;
	R4125[11] = (char *(*)()) F879_5066;
	R4125[12] = (char *(*)()) F880_5066;
	R4125[13] = (char *(*)()) F881_5066;
	R4125[14] = (char *(*)()) F882_5066;
	R4125[15] = (char *(*)()) F883_5066;
	R4125[16] = (char *(*)()) F884_5066;
	R4125[17] = (char *(*)()) F885_5066;
	R4125[18] = (char *(*)()) F886_5066;
	R4125[19] = (char *(*)()) F887_5066;
	R4125[20] = (char *(*)()) F888_5066;
	R4125[21] = (char *(*)()) F889_5066;
	R4125[22] = (char *(*)()) F890_5066;
	R4125[23] = (char *(*)()) F891_5066;
	R4125[24] = (char *(*)()) F892_5066;
	R4125[25] = (char *(*)()) F893_5066;
	R4125[26] = (char *(*)()) F894_5066;
	R4125[27] = (char *(*)()) F895_5066;
	R4125[28] = (char *(*)()) F896_5066;
	R4125[29] = (char *(*)()) F897_5066;
	R4125[30] = (char *(*)()) F898_5066;
}

char *(*R4259[2])();
void R4259_init () {
	R4259[0] = (char *(*)()) F900_5207;
	R4259[1] = (char *(*)()) F901_5212;
}

char *(*R4260[2])();
void R4260_init () {
	R4260[0] = (char *(*)()) F900_5208;
	R4260[1] = (char *(*)()) F901_5213;
}

char *(*R4281[3])();
void R4281_init () {
	R4281[0] = (char *(*)()) F902_5246;
	R4281[1] = (char *(*)()) F903_5296;
	R4281[2] = (char *(*)()) F904_5296;
}

char *(*R4282[3])();
void R4282_init () {
	R4282[0] = (char *(*)()) F902_5247;
	R4282[1] = (char *(*)()) F903_5297;
	R4282[2] = (char *(*)()) F904_5297;
}

char *(*R4285[3])();
void R4285_init () {
	R4285[0] = (char *(*)()) F902_5250;
	R4285[1] = (char *(*)()) F903_5300;
	R4285[2] = (char *(*)()) F904_5300;
}

char *(*R4337[3])();
void R4337_init () {
	R4337[0] = (char *(*)()) F905_5345;
	R4337[1] = (char *(*)()) F906_5395;
	R4337[2] = (char *(*)()) F907_5395;
}

char *(*R4338[3])();
void R4338_init () {
	R4338[0] = (char *(*)()) F905_5346;
	R4338[1] = (char *(*)()) F906_5396;
	R4338[2] = (char *(*)()) F907_5396;
}

char *(*R4342[3])();
void R4342_init () {
	R4342[0] = (char *(*)()) F905_5350;
	R4342[1] = (char *(*)()) F906_5400;
	R4342[2] = (char *(*)()) F907_5400;
}

char *(*R4394[3])();
void R4394_init () {
	R4394[0] = (char *(*)()) F908_5445;
	R4394[1] = (char *(*)()) F909_5495;
	R4394[2] = (char *(*)()) F910_5495;
}

char *(*R4397[3])();
void R4397_init () {
	R4397[0] = (char *(*)()) F908_5448;
	R4397[1] = (char *(*)()) F909_5498;
	R4397[2] = (char *(*)()) F910_5498;
}

char *(*R4447[3])();
void R4447_init () {
	R4447[0] = (char *(*)()) F911_5541;
	R4447[1] = (char *(*)()) F912_5591;
	R4447[2] = (char *(*)()) F913_5591;
}

char *(*R4450[3])();
void R4450_init () {
	R4450[0] = (char *(*)()) F911_5544;
	R4450[1] = (char *(*)()) F912_5594;
	R4450[2] = (char *(*)()) F913_5594;
}

char *(*R4453[3])();
void R4453_init () {
	R4453[0] = (char *(*)()) F911_5547;
	R4453[1] = (char *(*)()) F912_5597;
	R4453[2] = (char *(*)()) F913_5597;
}

char *(*R4507[3])();
void R4507_init () {
	R4507[0] = (char *(*)()) F914_5644;
	R4507[1] = (char *(*)()) F915_5691;
	R4507[2] = (char *(*)()) F916_5691;
}

char *(*R4553[3])();
void R4553_init () {
	R4553[0] = (char *(*)()) F917_5732;
	R4553[1] = (char *(*)()) F918_5779;
	R4553[2] = (char *(*)()) F919_5779;
}

char *(*R4554[3])();
void R4554_init () {
	R4554[0] = (char *(*)()) F917_5733;
	R4554[1] = (char *(*)()) F918_5780;
	R4554[2] = (char *(*)()) F919_5780;
}

char *(*R4556[3])();
void R4556_init () {
	R4556[0] = (char *(*)()) F917_5735;
	R4556[1] = (char *(*)()) F918_5782;
	R4556[2] = (char *(*)()) F919_5782;
}

char *(*R4559[3])();
void R4559_init () {
	R4559[0] = (char *(*)()) F917_5738;
	R4559[1] = (char *(*)()) F918_5785;
	R4559[2] = (char *(*)()) F919_5785;
}

char *(*R4560[3])();
void R4560_init () {
	R4560[0] = (char *(*)()) F917_5739;
	R4560[1] = (char *(*)()) F918_5786;
	R4560[2] = (char *(*)()) F919_5786;
}

char *(*R4608[3])();
void R4608_init () {
	R4608[0] = (char *(*)()) F920_5829;
	R4608[1] = (char *(*)()) F921_5876;
	R4608[2] = (char *(*)()) F922_5876;
}

char *(*R4609[3])();
void R4609_init () {
	R4609[0] = (char *(*)()) F920_5830;
	R4609[1] = (char *(*)()) F921_5877;
	R4609[2] = (char *(*)()) F922_5877;
}

char *(*R4612[3])();
void R4612_init () {
	R4612[0] = (char *(*)()) F920_5833;
	R4612[1] = (char *(*)()) F921_5880;
	R4612[2] = (char *(*)()) F922_5880;
}

char *(*R4660[3])();
void R4660_init () {
	R4660[0] = (char *(*)()) F923_5923;
	R4660[1] = (char *(*)()) F924_5970;
	R4660[2] = (char *(*)()) F925_5970;
}

char *(*R4661[3])();
void R4661_init () {
	R4661[0] = (char *(*)()) F923_5924;
	R4661[1] = (char *(*)()) F924_5971;
	R4661[2] = (char *(*)()) F925_5971;
}

char *(*R4662[3])();
void R4662_init () {
	R4662[0] = (char *(*)()) F923_5925;
	R4662[1] = (char *(*)()) F924_5972;
	R4662[2] = (char *(*)()) F925_5972;
}

char *(*R4663[3])();
void R4663_init () {
	R4663[0] = (char *(*)()) F923_5926;
	R4663[1] = (char *(*)()) F924_5973;
	R4663[2] = (char *(*)()) F925_5973;
}

char *(*R4665[3])();
void R4665_init () {
	R4665[0] = (char *(*)()) F923_5928;
	R4665[1] = (char *(*)()) F924_5975;
	R4665[2] = (char *(*)()) F925_5975;
}

char *(*R4711[3])();
void R4711_init () {
	R4711[0] = (char *(*)()) F926_6010;
	R4711[1] = (char *(*)()) F927_6033;
	R4711[2] = (char *(*)()) F928_6033;
}

char *(*R4745[3])();
void R4745_init () {
	R4745[0] = (char *(*)()) F929_6076;
	R4745[1] = (char *(*)()) F930_6099;
	R4745[2] = (char *(*)()) F931_6099;
}

char *(*R4752[3])();
void R4752_init () {
	R4752[0] = (char *(*)()) F929_6083;
	R4752[1] = (char *(*)()) F930_6103;
	R4752[2] = (char *(*)()) F931_6103;
}

char *(*R4766[3])();
void R4766_init () {
	R4766[0] = (char *(*)()) F932_6122;
	R4766[1] = (char *(*)()) F933_6157;
	R4766[2] = (char *(*)()) F934_6157;
}

char *(*R4890[4])();
void R4890_init () {
	R4890[0] = (char *(*)()) F975_6302;
	R4890[1] = (char *(*)()) F976_6305;
	{long i; for (i = 2; i < 4; i++) R4890[i] = (char *(*)()) F977_6305;}
}

char *(*R4914[3])();
void R4914_init () {
	R4914[0] = (char *(*)()) F976_6304;
	{long i; for (i = 1; i < 3; i++) R4914[i] = (char *(*)()) F977_6304_4914_1;}
}
static EIF_REFERENCE F977_6304_4914_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F977_6304(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R4915[3])();
void R4915_init () {
	R4915[0] = (char *(*)()) F976_6306;
	{long i; for (i = 1; i < 3; i++) R4915[i] = (char *(*)()) F977_6306_4915_5;}
}
static EIF_REFERENCE F977_6306_4915_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F977_6306(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R4919[3])();
void R4919_init () {
	R4919[0] = (char *(*)()) F976_6313;
	{long i; for (i = 1; i < 3; i++) R4919[i] = (char *(*)()) F977_6313_4919_482;}
}
static EIF_REFERENCE F977_6313_4919_482 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F977_6313(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y4920_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4920_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4920_pgtype2[] = {939,0xFFFF};
EIF_TYPE_INDEX *Y4920_gen_type [3];
EIF_TYPE_INDEX Y4920 [3];
void Y4920_init (void)
{
	egc_routines_types [4920] = Y4920;
	egc_routines_gen_types [4920] = Y4920_gen_type;
	egc_routines_offset [4920] = 975;
	Y4920_gen_type [0] = Y4920_pgtype0;
	Y4920_gen_type [1] = Y4920_pgtype1;
	Y4920_gen_type [2] = Y4920_pgtype2;
	Y4920[2] = 939;
}

char *(*R4921[442])();
void R4921_init () {
	{long i; for (i = 0; i < 2; i++) R4921[i] = (char *(*)()) F982_6445;}
	{long i; for (i = 3; i < 6; i++) R4921[i] = (char *(*)()) F985_6612;}
	{long i; for (i = 440; i < 442; i++) R4921[i] = (char *(*)()) F1423_11772;}
}

char *(*R4923[442])();
void R4923_init () {
	R4923[0] = (char *(*)()) F983_6506;
	R4923[1] = (char *(*)()) F984_6529;
	R4923[3] = (char *(*)()) F986_6672;
	{long i; for (i = 4; i < 6; i++) R4923[i] = (char *(*)()) F987_6694;}
	{long i; for (i = 440; i < 442; i++) R4923[i] = (char *(*)()) F1423_11900;}
}

char *(*R4924[442])();
void R4924_init () {
	R4924[0] = (char *(*)()) F983_6504;
	R4924[1] = (char *(*)()) F984_6527;
	R4924[3] = (char *(*)()) F986_6671;
	{long i; for (i = 4; i < 6; i++) R4924[i] = (char *(*)()) F987_6693;}
	{long i; for (i = 440; i < 442; i++) R4924[i] = (char *(*)()) F987_6693;}
}


#ifdef __cplusplus
}
#endif
