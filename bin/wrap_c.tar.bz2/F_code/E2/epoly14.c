#include "epoly14.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R6401[39])();
void R6401_init () {
	{long i; for (i = 0; i < 2; i++) R6401[i] = (char *(*)()) F1126_8300;}
	R6401[2] = (char *(*)()) F1128_8300;
	R6401[3] = (char *(*)()) F1126_8300;
	R6401[4] = (char *(*)()) F1130_8300;
	R6401[10] = (char *(*)()) F1126_8300;
	R6401[11] = (char *(*)()) F1127_8300;
	R6401[12] = (char *(*)()) F1129_8300;
	{long i; for (i = 13; i < 15; i++) R6401[i] = (char *(*)()) F1130_8300;}
	{long i; for (i = 15; i < 19; i++) R6401[i] = (char *(*)()) F1126_8300;}
	R6401[19] = (char *(*)()) F1127_8300;
	R6401[20] = (char *(*)()) F1129_8300;
	{long i; for (i = 21; i < 23; i++) R6401[i] = (char *(*)()) F1130_8300;}
	R6401[23] = (char *(*)()) F1126_8300;
	R6401[24] = (char *(*)()) F1127_8300;
	R6401[25] = (char *(*)()) F1129_8300;
	{long i; for (i = 26; i < 28; i++) R6401[i] = (char *(*)()) F1130_8300;}
	R6401[28] = (char *(*)()) F1126_8300;
	R6401[29] = (char *(*)()) F1127_8300;
	R6401[30] = (char *(*)()) F1129_8300;
	{long i; for (i = 31; i < 33; i++) R6401[i] = (char *(*)()) F1130_8300;}
	{long i; for (i = 35; i < 37; i++) R6401[i] = (char *(*)()) F1126_8300;}
	R6401[37] = (char *(*)()) F1130_8300;
	R6401[38] = (char *(*)()) F1126_8300;
}

char *(*R6403[39])();
void R6403_init () {
	{long i; for (i = 0; i < 2; i++) R6403[i] = (char *(*)()) F1126_8302;}
	R6403[2] = (char *(*)()) F1128_8302;
	R6403[3] = (char *(*)()) F1126_8302;
	R6403[4] = (char *(*)()) F1130_8302;
	R6403[10] = (char *(*)()) F1126_8302;
	R6403[11] = (char *(*)()) F1127_8302;
	R6403[12] = (char *(*)()) F1129_8302;
	{long i; for (i = 13; i < 15; i++) R6403[i] = (char *(*)()) F1130_8302;}
	{long i; for (i = 15; i < 19; i++) R6403[i] = (char *(*)()) F1126_8302;}
	R6403[19] = (char *(*)()) F1127_8302;
	R6403[20] = (char *(*)()) F1129_8302;
	{long i; for (i = 21; i < 23; i++) R6403[i] = (char *(*)()) F1130_8302;}
	R6403[23] = (char *(*)()) F1126_8302;
	R6403[24] = (char *(*)()) F1127_8302;
	R6403[25] = (char *(*)()) F1129_8302;
	{long i; for (i = 26; i < 28; i++) R6403[i] = (char *(*)()) F1130_8302;}
	R6403[28] = (char *(*)()) F1126_8302;
	R6403[29] = (char *(*)()) F1127_8302;
	R6403[30] = (char *(*)()) F1129_8302;
	{long i; for (i = 31; i < 33; i++) R6403[i] = (char *(*)()) F1130_8302;}
	{long i; for (i = 35; i < 37; i++) R6403[i] = (char *(*)()) F1126_8302;}
	R6403[37] = (char *(*)()) F1130_8302;
	R6403[38] = (char *(*)()) F1126_8302;
}

char *(*R6404[5])();
void R6404_init () {
	R6404[0] = (char *(*)()) F1131_8304;
	R6404[1] = (char *(*)()) F1132_8304;
	R6404[2] = (char *(*)()) F1133_8304;
	R6404[3] = (char *(*)()) F1134_8304;
	R6404[4] = (char *(*)()) F1135_8304;
}

char *(*R6405[5])();
void R6405_init () {
	R6405[0] = (char *(*)()) F1131_8305;
	R6405[1] = (char *(*)()) F1132_8305;
	R6405[2] = (char *(*)()) F1133_8305;
	R6405[3] = (char *(*)()) F1134_8305;
	R6405[4] = (char *(*)()) F1135_8305;
}

char *(*R6409[15])();
void R6409_init () {
	R6409[0] = (char *(*)()) F1149_8335;
	R6409[1] = (char *(*)()) F1150_8335;
	R6409[2] = (char *(*)()) F1151_8335_6409_1;
	R6409[3] = (char *(*)()) F1152_8335;
	R6409[4] = (char *(*)()) F1153_8335_6409_1;
	R6409[5] = (char *(*)()) F1149_8335;
	R6409[6] = (char *(*)()) F1150_8335;
	R6409[7] = (char *(*)()) F1151_8335_6409_1;
	R6409[8] = (char *(*)()) F1152_8335;
	R6409[9] = (char *(*)()) F1153_8335_6409_1;
	R6409[10] = (char *(*)()) F1149_8335;
	R6409[11] = (char *(*)()) F1150_8335;
	R6409[12] = (char *(*)()) F1151_8335_6409_1;
	R6409[13] = (char *(*)()) F1152_8335;
	R6409[14] = (char *(*)()) F1153_8335_6409_1;
}
static EIF_REFERENCE F1151_8335_6409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1151_8335(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(918, 0x00).id, 918, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1153_8335_6409_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1153_8335(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6411[23])();
void R6411_init () {
	R6411[0] = (char *(*)()) F1141_8314;
	R6411[1] = (char *(*)()) F1142_8314;
	R6411[2] = (char *(*)()) F1143_8314;
	R6411[3] = (char *(*)()) F1144_8314;
	R6411[4] = (char *(*)()) F1145_8314;
	{long i; for (i = 5; i < 9; i++) R6411[i] = (char *(*)()) F1141_8314;}
	R6411[9] = (char *(*)()) F1142_8314;
	R6411[10] = (char *(*)()) F1143_8314;
	R6411[11] = (char *(*)()) F1144_8314;
	R6411[12] = (char *(*)()) F1145_8314;
	R6411[13] = (char *(*)()) F1141_8314;
	R6411[14] = (char *(*)()) F1142_8314;
	R6411[15] = (char *(*)()) F1143_8314;
	R6411[16] = (char *(*)()) F1144_8314;
	R6411[17] = (char *(*)()) F1145_8314;
	R6411[18] = (char *(*)()) F1141_8314;
	R6411[19] = (char *(*)()) F1142_8314;
	R6411[20] = (char *(*)()) F1143_8314;
	R6411[21] = (char *(*)()) F1144_8314;
	R6411[22] = (char *(*)()) F1145_8314;
}

char *(*R6413[23])();
void R6413_init () {
	R6413[0] = (char *(*)()) F1141_8320;
	R6413[1] = (char *(*)()) F1142_8320;
	R6413[2] = (char *(*)()) F1143_8320;
	R6413[3] = (char *(*)()) F1144_8320;
	R6413[4] = (char *(*)()) F1145_8320;
	{long i; for (i = 5; i < 9; i++) R6413[i] = (char *(*)()) F1141_8320;}
	R6413[9] = (char *(*)()) F1142_8320;
	R6413[10] = (char *(*)()) F1143_8320;
	R6413[11] = (char *(*)()) F1144_8320;
	R6413[12] = (char *(*)()) F1145_8320;
	R6413[13] = (char *(*)()) F1141_8320;
	R6413[14] = (char *(*)()) F1142_8320;
	R6413[15] = (char *(*)()) F1143_8320;
	R6413[16] = (char *(*)()) F1144_8320;
	R6413[17] = (char *(*)()) F1145_8320;
	R6413[18] = (char *(*)()) F1141_8320;
	R6413[19] = (char *(*)()) F1142_8320;
	R6413[20] = (char *(*)()) F1143_8320;
	R6413[21] = (char *(*)()) F1144_8320;
	R6413[22] = (char *(*)()) F1145_8320;
}

char *(*R6414[23])();
void R6414_init () {
	R6414[0] = (char *(*)()) F1141_8321;
	R6414[1] = (char *(*)()) F1142_8321;
	R6414[2] = (char *(*)()) F1143_8321;
	R6414[3] = (char *(*)()) F1144_8321;
	R6414[4] = (char *(*)()) F1145_8321;
	{long i; for (i = 5; i < 9; i++) R6414[i] = (char *(*)()) F1141_8321;}
	R6414[9] = (char *(*)()) F1142_8321;
	R6414[10] = (char *(*)()) F1143_8321;
	R6414[11] = (char *(*)()) F1144_8321;
	R6414[12] = (char *(*)()) F1145_8321;
	R6414[13] = (char *(*)()) F1141_8321;
	R6414[14] = (char *(*)()) F1142_8321;
	R6414[15] = (char *(*)()) F1143_8321;
	R6414[16] = (char *(*)()) F1144_8321;
	R6414[17] = (char *(*)()) F1145_8321;
	R6414[18] = (char *(*)()) F1141_8321;
	R6414[19] = (char *(*)()) F1142_8321;
	R6414[20] = (char *(*)()) F1143_8321;
	R6414[21] = (char *(*)()) F1144_8321;
	R6414[22] = (char *(*)()) F1145_8321;
}

char *(*R6415[23])();
void R6415_init () {
	R6415[0] = (char *(*)()) F1141_8322;
	R6415[1] = (char *(*)()) F1142_8322;
	R6415[2] = (char *(*)()) F1143_8322;
	R6415[3] = (char *(*)()) F1144_8322;
	R6415[4] = (char *(*)()) F1145_8322;
	{long i; for (i = 5; i < 9; i++) R6415[i] = (char *(*)()) F1141_8322;}
	R6415[9] = (char *(*)()) F1142_8322;
	R6415[10] = (char *(*)()) F1143_8322;
	R6415[11] = (char *(*)()) F1144_8322;
	R6415[12] = (char *(*)()) F1145_8322;
	R6415[13] = (char *(*)()) F1141_8322;
	R6415[14] = (char *(*)()) F1142_8322;
	R6415[15] = (char *(*)()) F1143_8322;
	R6415[16] = (char *(*)()) F1144_8322;
	R6415[17] = (char *(*)()) F1145_8322;
	R6415[18] = (char *(*)()) F1141_8322;
	R6415[19] = (char *(*)()) F1142_8322;
	R6415[20] = (char *(*)()) F1143_8322;
	R6415[21] = (char *(*)()) F1144_8322;
	R6415[22] = (char *(*)()) F1145_8322;
}

char *(*R6419[23])();
void R6419_init () {
	R6419[0] = (char *(*)()) F1141_8328;
	R6419[1] = (char *(*)()) F1142_8328;
	R6419[2] = (char *(*)()) F1143_8328;
	R6419[3] = (char *(*)()) F1144_8328;
	R6419[4] = (char *(*)()) F1145_8328;
	{long i; for (i = 5; i < 9; i++) R6419[i] = (char *(*)()) F1141_8328;}
	R6419[9] = (char *(*)()) F1142_8328;
	R6419[10] = (char *(*)()) F1143_8328;
	R6419[11] = (char *(*)()) F1144_8328;
	R6419[12] = (char *(*)()) F1145_8328;
	R6419[13] = (char *(*)()) F1141_8328;
	R6419[14] = (char *(*)()) F1142_8328;
	R6419[15] = (char *(*)()) F1143_8328;
	R6419[16] = (char *(*)()) F1144_8328;
	R6419[17] = (char *(*)()) F1145_8328;
	R6419[18] = (char *(*)()) F1141_8328;
	R6419[19] = (char *(*)()) F1142_8328;
	R6419[20] = (char *(*)()) F1143_8328;
	R6419[21] = (char *(*)()) F1144_8328;
	R6419[22] = (char *(*)()) F1145_8328;
}

char *(*R6444[3])();
void R6444_init () {
	R6444[0] = (char *(*)()) F1167_8375;
	R6444[1] = (char *(*)()) F1168_8375;
	R6444[2] = (char *(*)()) F1167_8375;
}

char *(*R6446[3])();
void R6446_init () {
	R6446[0] = (char *(*)()) F1167_8384;
	R6446[1] = (char *(*)()) F1168_8384;
	R6446[2] = (char *(*)()) F1167_8384;
}

char *(*R6447[3])();
void R6447_init () {
	R6447[0] = (char *(*)()) F1167_8385;
	R6447[1] = (char *(*)()) F1168_8385;
	R6447[2] = (char *(*)()) F1167_8385;
}

char *(*R6448[3])();
void R6448_init () {
	R6448[0] = (char *(*)()) F1167_8386;
	R6448[1] = (char *(*)()) F1168_8386;
	R6448[2] = (char *(*)()) F1167_8386;
}

char *(*R6449[3])();
void R6449_init () {
	R6449[0] = (char *(*)()) F1167_8387;
	R6449[1] = (char *(*)()) F1168_8387;
	R6449[2] = (char *(*)()) F1167_8387;
}

char *(*R6477[7])();
void R6477_init () {
	{long i; for (i = 0; i < 3; i++) R6477[i] = (char *(*)()) F1176_8421;}
	{long i; for (i = 3; i < 7; i++) R6477[i] = (char *(*)()) F1179_8432;}
}

char *(*R6499[5])();
void R6499_init () {
	R6499[0] = (char *(*)()) F1184_8448;
	R6499[1] = (char *(*)()) F1185_8453;
	R6499[2] = (char *(*)()) F1186_8457;
	R6499[3] = (char *(*)()) F1187_8459;
	R6499[4] = (char *(*)()) F1188_8467;
}

char *(*R6536[63])();
void R6536_init () {
	R6536[0] = (char *(*)()) F1229_8579;
	R6536[1] = (char *(*)()) F1230_8579;
	R6536[2] = (char *(*)()) F1231_8579;
	R6536[3] = (char *(*)()) F1232_8579;
	R6536[4] = (char *(*)()) F1233_8579;
	R6536[18] = (char *(*)()) F1247_8698;
	R6536[19] = (char *(*)()) F1248_8698;
	{long i; for (i = 20; i < 22; i++) R6536[i] = (char *(*)()) F1247_8698;}
	R6536[28] = (char *(*)()) F1257_8859;
	R6536[29] = (char *(*)()) F1258_8859;
	R6536[32] = (char *(*)()) F1261_8888;
	R6536[33] = (char *(*)()) F1262_8888;
	R6536[38] = (char *(*)()) F1267_8921;
	R6536[39] = (char *(*)()) F1268_8956;
	R6536[47] = (char *(*)()) F1269_9032;
	R6536[58] = (char *(*)()) F1269_9032;
	R6536[59] = (char *(*)()) F1270_9032;
	R6536[60] = (char *(*)()) F1271_9032;
	R6536[61] = (char *(*)()) F1272_9032;
	R6536[62] = (char *(*)()) F1273_9032;
}

char *(*R6537[63])();
void R6537_init () {
	{long i; for (i = 0; i < 2; i++) R6537[i] = (char *(*)()) F1193_8484;}
	R6537[2] = (char *(*)()) F1196_8484;
	R6537[3] = (char *(*)()) F1193_8484;
	R6537[4] = (char *(*)()) F1197_8484;
	R6537[18] = (char *(*)()) F1193_8484;
	R6537[19] = (char *(*)()) F1197_8484;
	{long i; for (i = 20; i < 22; i++) R6537[i] = (char *(*)()) F1193_8484;}
	R6537[28] = (char *(*)()) F1193_8484;
	R6537[29] = (char *(*)()) F1198_8484;
	R6537[32] = (char *(*)()) F1193_8484;
	R6537[33] = (char *(*)()) F1194_8484;
	R6537[38] = (char *(*)()) F1194_8484;
	R6537[39] = (char *(*)()) F1193_8484;
	R6537[47] = (char *(*)()) F1193_8484;
	R6537[58] = (char *(*)()) F1193_8484;
	R6537[59] = (char *(*)()) F1194_8484;
	R6537[60] = (char *(*)()) F1195_8484;
	{long i; for (i = 61; i < 63; i++) R6537[i] = (char *(*)()) F1197_8484;}
}

char *(*R6538[45])();
void R6538_init () {
	R6538[0] = (char *(*)()) F1247_8748;
	R6538[1] = (char *(*)()) F1248_8748;
	{long i; for (i = 2; i < 4; i++) R6538[i] = (char *(*)()) F1247_8748;}
	R6538[10] = (char *(*)()) F1257_8870;
	R6538[11] = (char *(*)()) F1258_8870;
	R6538[14] = (char *(*)()) F1261_8900;
	R6538[15] = (char *(*)()) F1262_8900;
	R6538[21] = (char *(*)()) F1268_8998;
	R6538[29] = (char *(*)()) F1269_9050;
	R6538[40] = (char *(*)()) F1269_9050;
	R6538[41] = (char *(*)()) F1270_9050;
	R6538[42] = (char *(*)()) F1271_9050;
	R6538[43] = (char *(*)()) F1272_9050;
	R6538[44] = (char *(*)()) F1273_9050;
}

static EIF_TYPE_INDEX Y6545_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype36[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype37[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype38[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype39[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype40[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6545_pgtype98[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y6545_gen_type [99];
EIF_TYPE_INDEX Y6545 [99];
void Y6545_init (void)
{
	egc_routines_types [6545] = Y6545;
	egc_routines_gen_types [6545] = Y6545_gen_type;
	egc_routines_offset [6545] = 1192;
	Y6545_gen_type [0] = Y6545_pgtype0;
	Y6545_gen_type [1] = Y6545_pgtype1;
	Y6545_gen_type [2] = Y6545_pgtype2;
	Y6545_gen_type [3] = Y6545_pgtype3;
	Y6545_gen_type [4] = Y6545_pgtype4;
	Y6545_gen_type [5] = Y6545_pgtype5;
	Y6545_gen_type [6] = Y6545_pgtype6;
	Y6545_gen_type [7] = Y6545_pgtype7;
	Y6545_gen_type [8] = Y6545_pgtype8;
	Y6545_gen_type [9] = Y6545_pgtype9;
	Y6545_gen_type [10] = Y6545_pgtype10;
	Y6545_gen_type [11] = Y6545_pgtype11;
	Y6545_gen_type [12] = Y6545_pgtype12;
	Y6545_gen_type [13] = Y6545_pgtype13;
	Y6545_gen_type [14] = Y6545_pgtype14;
	Y6545_gen_type [15] = Y6545_pgtype15;
	Y6545_gen_type [16] = Y6545_pgtype16;
	Y6545_gen_type [17] = Y6545_pgtype17;
	Y6545_gen_type [18] = Y6545_pgtype18;
	Y6545_gen_type [19] = Y6545_pgtype19;
	Y6545_gen_type [20] = Y6545_pgtype20;
	Y6545_gen_type [21] = Y6545_pgtype21;
	Y6545_gen_type [22] = Y6545_pgtype22;
	Y6545_gen_type [23] = Y6545_pgtype23;
	Y6545_gen_type [24] = Y6545_pgtype24;
	Y6545_gen_type [25] = Y6545_pgtype25;
	Y6545_gen_type [26] = Y6545_pgtype26;
	Y6545_gen_type [27] = Y6545_pgtype27;
	Y6545_gen_type [28] = Y6545_pgtype28;
	Y6545_gen_type [29] = Y6545_pgtype29;
	Y6545_gen_type [30] = Y6545_pgtype30;
	Y6545_gen_type [31] = Y6545_pgtype31;
	Y6545_gen_type [32] = Y6545_pgtype32;
	Y6545_gen_type [33] = Y6545_pgtype33;
	Y6545_gen_type [34] = Y6545_pgtype34;
	Y6545_gen_type [35] = Y6545_pgtype35;
	Y6545_gen_type [36] = Y6545_pgtype36;
	Y6545_gen_type [37] = Y6545_pgtype37;
	Y6545_gen_type [38] = Y6545_pgtype38;
	Y6545_gen_type [39] = Y6545_pgtype39;
	Y6545_gen_type [40] = Y6545_pgtype40;
	Y6545_gen_type [41] = Y6545_pgtype41;
	Y6545_gen_type [42] = Y6545_pgtype42;
	Y6545_gen_type [43] = Y6545_pgtype43;
	Y6545_gen_type [44] = Y6545_pgtype44;
	Y6545_gen_type [45] = Y6545_pgtype45;
	Y6545_gen_type [46] = Y6545_pgtype46;
	Y6545_gen_type [47] = Y6545_pgtype47;
	Y6545_gen_type [48] = Y6545_pgtype48;
	Y6545_gen_type [49] = Y6545_pgtype49;
	Y6545_gen_type [50] = Y6545_pgtype50;
	Y6545_gen_type [51] = Y6545_pgtype51;
	Y6545_gen_type [52] = Y6545_pgtype52;
	Y6545_gen_type [53] = Y6545_pgtype53;
	Y6545_gen_type [54] = Y6545_pgtype54;
	Y6545_gen_type [55] = Y6545_pgtype55;
	Y6545_gen_type [56] = Y6545_pgtype56;
	Y6545_gen_type [57] = Y6545_pgtype57;
	Y6545_gen_type [58] = Y6545_pgtype58;
	Y6545_gen_type [59] = Y6545_pgtype59;
	Y6545_gen_type [60] = Y6545_pgtype60;
	Y6545_gen_type [61] = Y6545_pgtype61;
	Y6545_gen_type [62] = Y6545_pgtype62;
	Y6545_gen_type [63] = Y6545_pgtype63;
	Y6545_gen_type [64] = Y6545_pgtype64;
	Y6545_gen_type [65] = Y6545_pgtype65;
	Y6545_gen_type [66] = Y6545_pgtype66;
	Y6545_gen_type [67] = Y6545_pgtype67;
	Y6545_gen_type [68] = Y6545_pgtype68;
	Y6545_gen_type [69] = Y6545_pgtype69;
	Y6545_gen_type [70] = Y6545_pgtype70;
	Y6545_gen_type [71] = Y6545_pgtype71;
	Y6545_gen_type [72] = Y6545_pgtype72;
	Y6545_gen_type [73] = Y6545_pgtype73;
	Y6545_gen_type [74] = Y6545_pgtype74;
	Y6545_gen_type [75] = Y6545_pgtype75;
	Y6545_gen_type [76] = Y6545_pgtype76;
	Y6545_gen_type [77] = Y6545_pgtype77;
	Y6545_gen_type [78] = Y6545_pgtype78;
	Y6545_gen_type [79] = Y6545_pgtype79;
	Y6545_gen_type [80] = Y6545_pgtype80;
	Y6545_gen_type [81] = Y6545_pgtype81;
	Y6545_gen_type [82] = Y6545_pgtype82;
	Y6545_gen_type [83] = Y6545_pgtype83;
	Y6545_gen_type [84] = Y6545_pgtype84;
	Y6545_gen_type [85] = Y6545_pgtype85;
	Y6545_gen_type [86] = Y6545_pgtype86;
	Y6545_gen_type [87] = Y6545_pgtype87;
	Y6545_gen_type [88] = Y6545_pgtype88;
	Y6545_gen_type [89] = Y6545_pgtype89;
	Y6545_gen_type [90] = Y6545_pgtype90;
	Y6545_gen_type [91] = Y6545_pgtype91;
	Y6545_gen_type [92] = Y6545_pgtype92;
	Y6545_gen_type [93] = Y6545_pgtype93;
	Y6545_gen_type [94] = Y6545_pgtype94;
	Y6545_gen_type [95] = Y6545_pgtype95;
	Y6545_gen_type [96] = Y6545_pgtype96;
	Y6545_gen_type [97] = Y6545_pgtype97;
	Y6545_gen_type [98] = Y6545_pgtype98;
}

char *(*R6547[5])();
void R6547_init () {
	R6547[0] = (char *(*)()) F1277_9190;
	R6547[1] = (char *(*)()) F1278_9190_6547_5;
	R6547[2] = (char *(*)()) F1279_9190_6547_5;
	R6547[3] = (char *(*)()) F1280_9190_6547_5;
	R6547[4] = (char *(*)()) F1281_9190_6547_5;
}
static EIF_REFERENCE F1278_9190_6547_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1278_9190(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1279_9190_6547_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1279_9190(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(915, 0x00).id, 915, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1280_9190_6547_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1280_9190(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1281_9190_6547_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1281_9190(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6550[5])();
void R6550_init () {
	R6550[0] = (char *(*)()) F1277_9198;
	R6550[1] = (char *(*)()) F1278_9198;
	R6550[2] = (char *(*)()) F1279_9198_6550_2;
	R6550[3] = (char *(*)()) F1280_9198;
	R6550[4] = (char *(*)()) F1281_9198_6550_2;
}
static EIF_BOOLEAN F1279_9198_6550_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1279_9198(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F1281_9198_6550_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1281_9198(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R6568[63])();
void R6568_init () {
	R6568[0] = (char *(*)()) F1229_8578;
	R6568[1] = (char *(*)()) F1230_8578;
	R6568[2] = (char *(*)()) F1231_8578;
	R6568[3] = (char *(*)()) F1232_8578;
	R6568[4] = (char *(*)()) F1233_8578;
	R6568[18] = (char *(*)()) F1247_8697;
	R6568[19] = (char *(*)()) F1248_8697;
	R6568[20] = (char *(*)()) F1247_8697;
	R6568[21] = (char *(*)()) F1250_8798;
	R6568[39] = (char *(*)()) F1268_8955;
	R6568[47] = (char *(*)()) F1276_9178;
	R6568[58] = (char *(*)()) F1287_9262;
	R6568[59] = (char *(*)()) F1288_9262;
	R6568[60] = (char *(*)()) F1289_9262;
	R6568[61] = (char *(*)()) F1290_9262;
	R6568[62] = (char *(*)()) F1291_9262;
}

static EIF_TYPE_INDEX Y6568_pgtype0[] = {0xFF01,1106,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype1[] = {0xFF01,1107,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype2[] = {0xFF01,1108,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype3[] = {0xFF01,1109,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype4[] = {0xFF01,1110,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype5[] = {0xFF01,1111,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype6[] = {0xFF01,1118,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype7[] = {0xFF01,1119,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype8[] = {0xFF01,1120,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype9[] = {0xFF01,1121,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype10[] = {0xFF01,1122,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype11[] = {0xFF01,1123,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype12[] = {0xFF01,1125,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype13[] = {0xFF01,1126,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype14[] = {0xFF01,1127,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype15[] = {0xFF01,1128,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype16[] = {0xFF01,1129,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype17[] = {0xFF01,1130,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype18[] = {0xFF01,1131,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype19[] = {0xFF01,1132,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype20[] = {0xFF01,1133,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype21[] = {0xFF01,1134,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype22[] = {0xFF01,1135,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype23[] = {0xFF01,1136,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype24[] = {0xFF01,1137,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype25[] = {0xFF01,1138,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype26[] = {0xFF01,1139,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype27[] = {0xFF01,1163,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype28[] = {0xFF01,1164,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype29[] = {0xFF01,1166,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype30[] = {0xFF01,1167,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype31[] = {0xFF01,1166,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype32[] = {0xFF01,1168,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype33[] = {0xFF01,1124,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype34[] = {0xFF01,1165,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype35[] = {0xFF01,1140,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype36[] = {0xFF01,1141,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype37[] = {0xFF01,1142,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype38[] = {0xFF01,1143,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype39[] = {0xFF01,1144,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype40[] = {0xFF01,1145,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype41[] = {0xFF01,1146,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype42[] = {0xFF01,1147,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype43[] = {0xFF01,1148,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype44[] = {0xFF01,1149,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype45[] = {0xFF01,1150,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype46[] = {0xFF01,1151,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype47[] = {0xFF01,1152,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype48[] = {0xFF01,1153,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype49[] = {0xFF01,1154,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype50[] = {0xFF01,1155,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype51[] = {0xFF01,1156,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype52[] = {0xFF01,1157,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype53[] = {0xFF01,1158,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype54[] = {0xFF01,1159,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype55[] = {0xFF01,1160,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype56[] = {0xFF01,1161,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6568_pgtype57[] = {0xFF01,1162,0xFFF8,1,0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y6568_gen_type [86];
EIF_TYPE_INDEX Y6568 [86];
void Y6568_init (void)
{
	egc_routines_types [6568] = Y6568;
	egc_routines_gen_types [6568] = Y6568_gen_type;
	egc_routines_offset [6568] = 1205;
	Y6568_gen_type [0] = Y6568_pgtype0;
	Y6568_gen_type [1] = Y6568_pgtype1;
	Y6568_gen_type [2] = Y6568_pgtype2;
	Y6568_gen_type [3] = Y6568_pgtype3;
	Y6568_gen_type [4] = Y6568_pgtype4;
	Y6568_gen_type [5] = Y6568_pgtype5;
	Y6568_gen_type [12] = Y6568_pgtype6;
	Y6568_gen_type [13] = Y6568_pgtype7;
	Y6568_gen_type [14] = Y6568_pgtype8;
	Y6568_gen_type [15] = Y6568_pgtype9;
	Y6568_gen_type [16] = Y6568_pgtype10;
	Y6568_gen_type [17] = Y6568_pgtype11;
	Y6568_gen_type [18] = Y6568_pgtype12;
	Y6568_gen_type [19] = Y6568_pgtype13;
	Y6568_gen_type [20] = Y6568_pgtype14;
	Y6568_gen_type [21] = Y6568_pgtype15;
	Y6568_gen_type [22] = Y6568_pgtype16;
	Y6568_gen_type [23] = Y6568_pgtype17;
	Y6568_gen_type [24] = Y6568_pgtype18;
	Y6568_gen_type [25] = Y6568_pgtype19;
	Y6568_gen_type [26] = Y6568_pgtype20;
	Y6568_gen_type [27] = Y6568_pgtype21;
	Y6568_gen_type [28] = Y6568_pgtype22;
	Y6568_gen_type [29] = Y6568_pgtype23;
	Y6568_gen_type [30] = Y6568_pgtype24;
	Y6568_gen_type [31] = Y6568_pgtype25;
	Y6568_gen_type [32] = Y6568_pgtype26;
	Y6568_gen_type [39] = Y6568_pgtype27;
	Y6568_gen_type [40] = Y6568_pgtype28;
	Y6568_gen_type [41] = Y6568_pgtype29;
	Y6568_gen_type [42] = Y6568_pgtype30;
	Y6568_gen_type [43] = Y6568_pgtype31;
	Y6568_gen_type [44] = Y6568_pgtype32;
	Y6568_gen_type [45] = Y6568_pgtype33;
	Y6568_gen_type [62] = Y6568_pgtype34;
	Y6568_gen_type [63] = Y6568_pgtype35;
	Y6568_gen_type [64] = Y6568_pgtype36;
	Y6568_gen_type [65] = Y6568_pgtype37;
	Y6568_gen_type [66] = Y6568_pgtype38;
	Y6568_gen_type [67] = Y6568_pgtype39;
	Y6568_gen_type [68] = Y6568_pgtype40;
	Y6568_gen_type [69] = Y6568_pgtype41;
	Y6568_gen_type [70] = Y6568_pgtype42;
	Y6568_gen_type [71] = Y6568_pgtype43;
	Y6568_gen_type [72] = Y6568_pgtype44;
	Y6568_gen_type [73] = Y6568_pgtype45;
	Y6568_gen_type [74] = Y6568_pgtype46;
	Y6568_gen_type [75] = Y6568_pgtype47;
	Y6568_gen_type [76] = Y6568_pgtype48;
	Y6568_gen_type [77] = Y6568_pgtype49;
	Y6568_gen_type [78] = Y6568_pgtype50;
	Y6568_gen_type [79] = Y6568_pgtype51;
	Y6568_gen_type [80] = Y6568_pgtype52;
	Y6568_gen_type [81] = Y6568_pgtype53;
	Y6568_gen_type [82] = Y6568_pgtype54;
	Y6568_gen_type [83] = Y6568_pgtype55;
	Y6568_gen_type [84] = Y6568_pgtype56;
	Y6568_gen_type [85] = Y6568_pgtype57;
	Y6568[0] = 1106;
	Y6568[1] = 1107;
	Y6568[2] = 1108;
	Y6568[3] = 1109;
	Y6568[4] = 1110;
	Y6568[5] = 1111;
	Y6568[12] = 1118;
	Y6568[13] = 1119;
	Y6568[14] = 1120;
	Y6568[15] = 1121;
	Y6568[16] = 1122;
	Y6568[17] = 1123;
	Y6568[18] = 1125;
	Y6568[19] = 1126;
	Y6568[20] = 1127;
	Y6568[21] = 1128;
	Y6568[22] = 1129;
	Y6568[23] = 1130;
	Y6568[24] = 1131;
	Y6568[25] = 1132;
	Y6568[26] = 1133;
	Y6568[27] = 1134;
	Y6568[28] = 1135;
	Y6568[29] = 1136;
	Y6568[30] = 1137;
	Y6568[31] = 1138;
	Y6568[32] = 1139;
	Y6568[39] = 1163;
	Y6568[40] = 1164;
	Y6568[41] = 1166;
	Y6568[42] = 1167;
	Y6568[43] = 1166;
	Y6568[44] = 1168;
	Y6568[45] = 1124;
	Y6568[62] = 1165;
	Y6568[63] = 1140;
	Y6568[64] = 1141;
	Y6568[65] = 1142;
	Y6568[66] = 1143;
	Y6568[67] = 1144;
	Y6568[68] = 1145;
	Y6568[69] = 1146;
	Y6568[70] = 1147;
	Y6568[71] = 1148;
	Y6568[72] = 1149;
	Y6568[73] = 1150;
	Y6568[74] = 1151;
	Y6568[75] = 1152;
	Y6568[76] = 1153;
	Y6568[77] = 1154;
	Y6568[78] = 1155;
	Y6568[79] = 1156;
	Y6568[80] = 1157;
	Y6568[81] = 1158;
	Y6568[82] = 1159;
	Y6568[83] = 1160;
	Y6568[84] = 1161;
	Y6568[85] = 1162;
}

char *(*R6571[63])();
void R6571_init () {
	{long i; for (i = 0; i < 2; i++) R6571[i] = (char *(*)()) F1206_8519;}
	R6571[2] = (char *(*)()) F1209_8519;
	R6571[3] = (char *(*)()) F1206_8519;
	R6571[4] = (char *(*)()) F1210_8519;
	R6571[18] = (char *(*)()) F1206_8519;
	R6571[19] = (char *(*)()) F1210_8519;
	{long i; for (i = 20; i < 22; i++) R6571[i] = (char *(*)()) F1206_8519;}
	R6571[39] = (char *(*)()) F1206_8519;
	R6571[47] = (char *(*)()) F1206_8519;
	R6571[58] = (char *(*)()) F1206_8519;
	R6571[59] = (char *(*)()) F1207_8519;
	R6571[60] = (char *(*)()) F1208_8519;
	{long i; for (i = 61; i < 63; i++) R6571[i] = (char *(*)()) F1210_8519;}
}

char *(*R6573[63])();
void R6573_init () {
	R6573[0] = (char *(*)()) F1229_8592;
	R6573[1] = (char *(*)()) F1230_8592;
	R6573[2] = (char *(*)()) F1231_8592;
	R6573[3] = (char *(*)()) F1232_8592;
	R6573[4] = (char *(*)()) F1233_8592;
	R6573[18] = (char *(*)()) F1247_8753;
	R6573[19] = (char *(*)()) F1248_8753;
	{long i; for (i = 20; i < 22; i++) R6573[i] = (char *(*)()) F1247_8753;}
	R6573[39] = (char *(*)()) F1268_9004;
	R6573[47] = (char *(*)()) F1269_9097;
	R6573[58] = (char *(*)()) F1269_9097;
	R6573[59] = (char *(*)()) F1270_9097;
	R6573[60] = (char *(*)()) F1271_9097;
	R6573[61] = (char *(*)()) F1272_9097;
	R6573[62] = (char *(*)()) F1273_9097;
}

char *(*R6574[63])();
void R6574_init () {
	R6574[0] = (char *(*)()) F1229_8593;
	R6574[1] = (char *(*)()) F1230_8593;
	R6574[2] = (char *(*)()) F1231_8593;
	R6574[3] = (char *(*)()) F1232_8593;
	R6574[4] = (char *(*)()) F1233_8593;
	R6574[18] = (char *(*)()) F1247_8754;
	R6574[19] = (char *(*)()) F1248_8754;
	{long i; for (i = 20; i < 22; i++) R6574[i] = (char *(*)()) F1247_8754;}
	R6574[39] = (char *(*)()) F1268_9005;
	R6574[47] = (char *(*)()) F1269_9098;
	R6574[58] = (char *(*)()) F1269_9098;
	R6574[59] = (char *(*)()) F1270_9098;
	R6574[60] = (char *(*)()) F1271_9098;
	R6574[61] = (char *(*)()) F1272_9098;
	R6574[62] = (char *(*)()) F1273_9098;
}

char *(*R6575[63])();
void R6575_init () {
	R6575[0] = (char *(*)()) F1229_8595;
	R6575[1] = (char *(*)()) F1230_8595;
	R6575[2] = (char *(*)()) F1231_8595_6575_5;
	R6575[3] = (char *(*)()) F1232_8595;
	R6575[4] = (char *(*)()) F1233_8595_6575_5;
	R6575[18] = (char *(*)()) F1247_8758;
	R6575[19] = (char *(*)()) F1248_8758_6575_5;
	{long i; for (i = 20; i < 22; i++) R6575[i] = (char *(*)()) F1247_8758;}
	R6575[39] = (char *(*)()) F1268_9010;
	R6575[47] = (char *(*)()) F1269_9103;
	R6575[58] = (char *(*)()) F1269_9103;
	R6575[59] = (char *(*)()) F1270_9103_6575_5;
	R6575[60] = (char *(*)()) F1271_9103_6575_5;
	R6575[61] = (char *(*)()) F1272_9103_6575_5;
	R6575[62] = (char *(*)()) F1273_9103_6575_5;
}
static EIF_REFERENCE F1231_8595_6575_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1231_8595(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(918, 0x00).id, 918, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1233_8595_6575_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1233_8595(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1248_8758_6575_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1248_8758(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1270_9103_6575_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1270_9103(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1271_9103_6575_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1271_9103(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(915, 0x00).id, 915, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1272_9103_6575_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1272_9103(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1273_9103_6575_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1273_9103(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6576[63])();
void R6576_init () {
	{long i; for (i = 0; i < 2; i++) R6576[i] = (char *(*)()) F1206_8524;}
	R6576[2] = (char *(*)()) F1209_8524;
	R6576[3] = (char *(*)()) F1206_8524;
	R6576[4] = (char *(*)()) F1210_8524;
	R6576[18] = (char *(*)()) F1206_8524;
	R6576[19] = (char *(*)()) F1210_8524;
	{long i; for (i = 20; i < 22; i++) R6576[i] = (char *(*)()) F1206_8524;}
	R6576[39] = (char *(*)()) F1206_8524;
	R6576[47] = (char *(*)()) F1206_8524;
	R6576[58] = (char *(*)()) F1206_8524;
	R6576[59] = (char *(*)()) F1207_8524;
	R6576[60] = (char *(*)()) F1208_8524;
	{long i; for (i = 61; i < 63; i++) R6576[i] = (char *(*)()) F1210_8524;}
}

char *(*R6577[63])();
void R6577_init () {
	R6577[0] = (char *(*)()) F1229_8598;
	R6577[1] = (char *(*)()) F1230_8598;
	R6577[2] = (char *(*)()) F1231_8598;
	R6577[3] = (char *(*)()) F1232_8598;
	R6577[4] = (char *(*)()) F1233_8598;
	R6577[18] = (char *(*)()) F1247_8762;
	R6577[19] = (char *(*)()) F1248_8762;
	{long i; for (i = 20; i < 22; i++) R6577[i] = (char *(*)()) F1247_8762;}
	R6577[39] = (char *(*)()) F1268_9014;
	R6577[47] = (char *(*)()) F1269_9106;
	R6577[58] = (char *(*)()) F1269_9106;
	R6577[59] = (char *(*)()) F1270_9106;
	R6577[60] = (char *(*)()) F1271_9106;
	R6577[61] = (char *(*)()) F1272_9106;
	R6577[62] = (char *(*)()) F1273_9106;
}

char *(*R6579[63])();
void R6579_init () {
	{long i; for (i = 0; i < 2; i++) R6579[i] = (char *(*)()) F1206_8527;}
	R6579[2] = (char *(*)()) F1209_8527;
	R6579[3] = (char *(*)()) F1206_8527;
	R6579[4] = (char *(*)()) F1210_8527;
	R6579[18] = (char *(*)()) F1206_8527;
	R6579[19] = (char *(*)()) F1210_8527;
	{long i; for (i = 20; i < 22; i++) R6579[i] = (char *(*)()) F1206_8527;}
	R6579[39] = (char *(*)()) F1206_8527;
	R6579[47] = (char *(*)()) F1206_8527;
	R6579[58] = (char *(*)()) F1206_8527;
	R6579[59] = (char *(*)()) F1207_8527;
	R6579[60] = (char *(*)()) F1208_8527;
	{long i; for (i = 61; i < 63; i++) R6579[i] = (char *(*)()) F1210_8527;}
}

char *(*R6580[63])();
void R6580_init () {
	{long i; for (i = 0; i < 2; i++) R6580[i] = (char *(*)()) F1206_8528;}
	R6580[2] = (char *(*)()) F1209_8528;
	R6580[3] = (char *(*)()) F1206_8528;
	R6580[4] = (char *(*)()) F1210_8528;
	R6580[18] = (char *(*)()) F1206_8528;
	R6580[19] = (char *(*)()) F1210_8528;
	{long i; for (i = 20; i < 22; i++) R6580[i] = (char *(*)()) F1206_8528;}
	R6580[39] = (char *(*)()) F1206_8528;
	R6580[47] = (char *(*)()) F1206_8528;
	R6580[58] = (char *(*)()) F1206_8528;
	R6580[59] = (char *(*)()) F1207_8528;
	R6580[60] = (char *(*)()) F1208_8528;
	{long i; for (i = 61; i < 63; i++) R6580[i] = (char *(*)()) F1210_8528;}
}

char *(*R6589[22])();
void R6589_init () {
	R6589[0] = (char *(*)()) F1247_8695;
	R6589[1] = (char *(*)()) F1248_8695_6589_1;
	{long i; for (i = 2; i < 4; i++) R6589[i] = (char *(*)()) F1247_8695;}
	R6589[21] = (char *(*)()) F1268_8953;
}
static EIF_REFERENCE F1248_8695_6589_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1248_8695(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6599[63])();
void R6599_init () {
	R6599[0] = (char *(*)()) F1229_8596;
	R6599[1] = (char *(*)()) F1230_8596;
	R6599[2] = (char *(*)()) F1231_8596;
	R6599[3] = (char *(*)()) F1232_8596;
	R6599[4] = (char *(*)()) F1233_8596;
	R6599[18] = (char *(*)()) F1247_8760;
	R6599[19] = (char *(*)()) F1248_8760;
	{long i; for (i = 20; i < 22; i++) R6599[i] = (char *(*)()) F1247_8760;}
	R6599[39] = (char *(*)()) F1268_9012;
	R6599[47] = (char *(*)()) F1269_9104;
	R6599[58] = (char *(*)()) F1269_9104;
	R6599[59] = (char *(*)()) F1270_9104;
	R6599[60] = (char *(*)()) F1271_9104;
	R6599[61] = (char *(*)()) F1272_9104;
	R6599[62] = (char *(*)()) F1273_9104;
}

char *(*R6600[63])();
void R6600_init () {
	{long i; for (i = 0; i < 2; i++) R6600[i] = (char *(*)()) F1218_8556;}
	R6600[2] = (char *(*)()) F1220_8556;
	R6600[3] = (char *(*)()) F1218_8556;
	R6600[4] = (char *(*)()) F1222_8556;
	R6600[18] = (char *(*)()) F1218_8556;
	R6600[19] = (char *(*)()) F1222_8556;
	{long i; for (i = 20; i < 22; i++) R6600[i] = (char *(*)()) F1218_8556;}
	R6600[39] = (char *(*)()) F1218_8556;
	R6600[47] = (char *(*)()) F1218_8556;
	R6600[58] = (char *(*)()) F1218_8556;
	R6600[59] = (char *(*)()) F1219_8556;
	R6600[60] = (char *(*)()) F1221_8556;
	{long i; for (i = 61; i < 63; i++) R6600[i] = (char *(*)()) F1222_8556;}
}

char *(*R6601[63])();
void R6601_init () {
	R6601[0] = (char *(*)()) F1229_8599;
	R6601[1] = (char *(*)()) F1230_8599;
	R6601[2] = (char *(*)()) F1231_8599;
	R6601[3] = (char *(*)()) F1232_8599;
	R6601[4] = (char *(*)()) F1233_8599;
	R6601[18] = (char *(*)()) F1247_8763;
	R6601[19] = (char *(*)()) F1248_8763;
	{long i; for (i = 20; i < 22; i++) R6601[i] = (char *(*)()) F1247_8763;}
	R6601[39] = (char *(*)()) F1268_9015;
	R6601[47] = (char *(*)()) F1269_9107;
	R6601[58] = (char *(*)()) F1269_9107;
	R6601[59] = (char *(*)()) F1270_9107;
	R6601[60] = (char *(*)()) F1271_9107;
	R6601[61] = (char *(*)()) F1272_9107;
	R6601[62] = (char *(*)()) F1273_9107;
}

char *(*R6602[63])();
void R6602_init () {
	R6602[0] = (char *(*)()) F1229_8601;
	R6602[1] = (char *(*)()) F1230_8601;
	R6602[2] = (char *(*)()) F1231_8601;
	R6602[3] = (char *(*)()) F1232_8601;
	R6602[4] = (char *(*)()) F1233_8601;
	R6602[18] = (char *(*)()) F1247_8765;
	R6602[19] = (char *(*)()) F1248_8765;
	{long i; for (i = 20; i < 22; i++) R6602[i] = (char *(*)()) F1247_8765;}
	R6602[39] = (char *(*)()) F1268_9017;
	R6602[47] = (char *(*)()) F1269_9109;
	R6602[58] = (char *(*)()) F1269_9109;
	R6602[59] = (char *(*)()) F1270_9109;
	R6602[60] = (char *(*)()) F1271_9109;
	R6602[61] = (char *(*)()) F1272_9109;
	R6602[62] = (char *(*)()) F1273_9109;
}

char *(*R6604[63])();
void R6604_init () {
	R6604[0] = (char *(*)()) F1229_8605;
	R6604[1] = (char *(*)()) F1230_8605;
	R6604[2] = (char *(*)()) F1231_8605;
	R6604[3] = (char *(*)()) F1232_8605;
	R6604[4] = (char *(*)()) F1233_8605;
	R6604[18] = (char *(*)()) F1247_8769;
	R6604[19] = (char *(*)()) F1248_8769;
	{long i; for (i = 20; i < 22; i++) R6604[i] = (char *(*)()) F1247_8769;}
	R6604[39] = (char *(*)()) F1268_9021;
	R6604[47] = (char *(*)()) F1269_9113;
	R6604[58] = (char *(*)()) F1269_9113;
	R6604[59] = (char *(*)()) F1270_9113;
	R6604[60] = (char *(*)()) F1271_9113;
	R6604[61] = (char *(*)()) F1272_9113;
	R6604[62] = (char *(*)()) F1273_9113;
}

char *(*R6605[22])();
void R6605_init () {
	R6605[0] = (char *(*)()) F1247_8696;
	R6605[1] = (char *(*)()) F1248_8696_6605_1;
	{long i; for (i = 2; i < 4; i++) R6605[i] = (char *(*)()) F1247_8696;}
	R6605[21] = (char *(*)()) F1268_8954;
}
static EIF_REFERENCE F1248_8696_6605_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1248_8696(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6612[63])();
void R6612_init () {
	R6612[0] = (char *(*)()) F1229_8597;
	R6612[1] = (char *(*)()) F1230_8597;
	R6612[2] = (char *(*)()) F1231_8597;
	R6612[3] = (char *(*)()) F1232_8597;
	R6612[4] = (char *(*)()) F1233_8597;
	R6612[18] = (char *(*)()) F1247_8761;
	R6612[19] = (char *(*)()) F1248_8761;
	{long i; for (i = 20; i < 22; i++) R6612[i] = (char *(*)()) F1247_8761;}
	R6612[39] = (char *(*)()) F1268_9013;
	R6612[47] = (char *(*)()) F1269_9105;
	R6612[58] = (char *(*)()) F1269_9105;
	R6612[59] = (char *(*)()) F1270_9105;
	R6612[60] = (char *(*)()) F1271_9105;
	R6612[61] = (char *(*)()) F1272_9105;
	R6612[62] = (char *(*)()) F1273_9105;
}

char *(*R6614[63])();
void R6614_init () {
	R6614[0] = (char *(*)()) F1229_8600;
	R6614[1] = (char *(*)()) F1230_8600;
	R6614[2] = (char *(*)()) F1231_8600;
	R6614[3] = (char *(*)()) F1232_8600;
	R6614[4] = (char *(*)()) F1233_8600;
	R6614[18] = (char *(*)()) F1247_8764;
	R6614[19] = (char *(*)()) F1248_8764;
	{long i; for (i = 20; i < 22; i++) R6614[i] = (char *(*)()) F1247_8764;}
	R6614[39] = (char *(*)()) F1268_9016;
	R6614[47] = (char *(*)()) F1269_9108;
	R6614[58] = (char *(*)()) F1269_9108;
	R6614[59] = (char *(*)()) F1270_9108;
	R6614[60] = (char *(*)()) F1271_9108;
	R6614[61] = (char *(*)()) F1272_9108;
	R6614[62] = (char *(*)()) F1273_9108;
}

char *(*R6615[63])();
void R6615_init () {
	R6615[0] = (char *(*)()) F1229_8602;
	R6615[1] = (char *(*)()) F1230_8602;
	R6615[2] = (char *(*)()) F1231_8602;
	R6615[3] = (char *(*)()) F1232_8602;
	R6615[4] = (char *(*)()) F1233_8602;
	R6615[18] = (char *(*)()) F1247_8766;
	R6615[19] = (char *(*)()) F1248_8766;
	R6615[20] = (char *(*)()) F1247_8766;
	R6615[21] = (char *(*)()) F1250_8811;
	R6615[39] = (char *(*)()) F1268_9018;
	R6615[47] = (char *(*)()) F1269_9110;
	R6615[58] = (char *(*)()) F1269_9110;
	R6615[59] = (char *(*)()) F1270_9110;
	R6615[60] = (char *(*)()) F1271_9110;
	R6615[61] = (char *(*)()) F1272_9110;
	R6615[62] = (char *(*)()) F1273_9110;
}

char *(*R6617[63])();
void R6617_init () {
	R6617[0] = (char *(*)()) F1229_8606;
	R6617[1] = (char *(*)()) F1230_8606;
	R6617[2] = (char *(*)()) F1231_8606;
	R6617[3] = (char *(*)()) F1232_8606;
	R6617[4] = (char *(*)()) F1233_8606;
	R6617[18] = (char *(*)()) F1247_8770;
	R6617[19] = (char *(*)()) F1248_8770;
	{long i; for (i = 20; i < 22; i++) R6617[i] = (char *(*)()) F1247_8770;}
	R6617[39] = (char *(*)()) F1268_9022;
	R6617[47] = (char *(*)()) F1269_9114;
	R6617[58] = (char *(*)()) F1269_9114;
	R6617[59] = (char *(*)()) F1270_9114;
	R6617[60] = (char *(*)()) F1271_9114;
	R6617[61] = (char *(*)()) F1272_9114;
	R6617[62] = (char *(*)()) F1273_9114;
}

char *(*R6618[5])();
void R6618_init () {
	R6618[0] = (char *(*)()) F1229_8575;
	R6618[1] = (char *(*)()) F1230_8575;
	R6618[2] = (char *(*)()) F1231_8575;
	R6618[3] = (char *(*)()) F1232_8575;
	R6618[4] = (char *(*)()) F1233_8575;
}

char *(*R6619[5])();
void R6619_init () {
	R6619[0] = (char *(*)()) F1229_8594;
	R6619[1] = (char *(*)()) F1230_8594;
	R6619[2] = (char *(*)()) F1231_8594;
	R6619[3] = (char *(*)()) F1232_8594;
	R6619[4] = (char *(*)()) F1233_8594;
}

char *(*R6621[5])();
void R6621_init () {
	R6621[0] = (char *(*)()) F1229_8609;
	R6621[1] = (char *(*)()) F1230_8609;
	R6621[2] = (char *(*)()) F1231_8609;
	R6621[3] = (char *(*)()) F1232_8609;
	R6621[4] = (char *(*)()) F1233_8609;
}

char *(*R6625[5])();
void R6625_init () {
	R6625[0] = (char *(*)()) F1277_9226;
	R6625[1] = (char *(*)()) F1278_9226;
	R6625[2] = (char *(*)()) F1279_9226_6625_5;
	R6625[3] = (char *(*)()) F1280_9226;
	R6625[4] = (char *(*)()) F1281_9226_6625_5;
}
static EIF_REFERENCE F1279_9226_6625_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1279_9226(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(918, 0x00).id, 918, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1281_9226_6625_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1281_9226(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6627[30])();
void R6627_init () {
	R6627[0] = (char *(*)()) F1247_8714;
	R6627[1] = (char *(*)()) F1248_8714_6627_4;
	R6627[2] = (char *(*)()) F1249_8792;
	R6627[3] = (char *(*)()) F1247_8714;
	R6627[14] = (char *(*)()) F1261_8892;
	R6627[15] = (char *(*)()) F1262_8892_6627_4;
	R6627[21] = (char *(*)()) F1268_8965;
	R6627[29] = (char *(*)()) F1274_9131;
}
static void F1248_8714_6627_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1248_8714(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1262_8892_6627_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1262_8892(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R6628[30])();
void R6628_init () {
	R6628[0] = (char *(*)()) F1247_8715;
	R6628[1] = (char *(*)()) F1248_8715_6628_4;
	R6628[2] = (char *(*)()) F1249_8787;
	R6628[3] = (char *(*)()) F1247_8715;
	R6628[10] = (char *(*)()) F1257_8864;
	R6628[11] = (char *(*)()) F1258_8864_6628_4;
	R6628[14] = (char *(*)()) F1261_8893;
	R6628[15] = (char *(*)()) F1262_8893_6628_4;
	R6628[20] = (char *(*)()) F1267_8927_6628_4;
	R6628[21] = (char *(*)()) F1268_8970;
	R6628[29] = (char *(*)()) F1274_9134;
}
static void F1248_8715_6628_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1248_8715(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1258_8864_6628_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1258_8864(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1262_8893_6628_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1262_8893(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1267_8927_6628_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1267_8927(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R6629[30])();
void R6629_init () {
	R6629[0] = (char *(*)()) F1247_8726;
	R6629[1] = (char *(*)()) F1248_8726;
	R6629[2] = (char *(*)()) F1249_8782;
	R6629[3] = (char *(*)()) F1247_8726;
	R6629[29] = (char *(*)()) F1274_9136;
}

char *(*R6632[22])();
void R6632_init () {
	R6632[0] = (char *(*)()) F1247_8694;
	R6632[1] = (char *(*)()) F1248_8694_6632_35;
	{long i; for (i = 2; i < 4; i++) R6632[i] = (char *(*)()) F1247_8694;}
	R6632[21] = (char *(*)()) F1268_8952;
}
static EIF_REFERENCE F1248_8694_6632_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1248_8694(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6635[4])();
void R6635_init () {
	R6635[0] = (char *(*)()) F1247_8712;
	R6635[1] = (char *(*)()) F1248_8712_6635_4;
	R6635[2] = (char *(*)()) F1249_8791;
	R6635[3] = (char *(*)()) F1247_8712;
}
static void F1248_8712_6635_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1248_8712(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R6637[22])();
void R6637_init () {
	R6637[0] = (char *(*)()) F1247_8713;
	R6637[1] = (char *(*)()) F1248_8713_6637_4;
	R6637[2] = (char *(*)()) F1249_8786;
	R6637[3] = (char *(*)()) F1247_8713;
	R6637[21] = (char *(*)()) F1268_8969;
}
static void F1248_8713_6637_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1248_8713(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R6645[4])();
void R6645_init () {
	R6645[0] = (char *(*)()) F1247_8734;
	R6645[1] = (char *(*)()) F1248_8734;
	{long i; for (i = 2; i < 4; i++) R6645[i] = (char *(*)()) F1247_8734;}
}

char *(*R6646[22])();
void R6646_init () {
	R6646[0] = (char *(*)()) F1247_8735;
	R6646[1] = (char *(*)()) F1248_8735;
	R6646[2] = (char *(*)()) F1247_8735;
	R6646[3] = (char *(*)()) F1250_8803;
	R6646[21] = (char *(*)()) F1268_8985;
}

char *(*R6677[22])();
void R6677_init () {
	R6677[0] = (char *(*)()) F1247_8737;
	R6677[1] = (char *(*)()) F1248_8737;
	R6677[2] = (char *(*)()) F1247_8737;
	R6677[3] = (char *(*)()) F1250_8804;
	R6677[21] = (char *(*)()) F1268_8987;
}

char *(*R6687[22])();
void R6687_init () {
	R6687[0] = (char *(*)()) F1247_8759;
	R6687[1] = (char *(*)()) F1248_8759;
	{long i; for (i = 2; i < 4; i++) R6687[i] = (char *(*)()) F1247_8759;}
	R6687[21] = (char *(*)()) F1268_9011;
}

char *(*R6689[4])();
void R6689_init () {
	R6689[0] = (char *(*)()) F1247_8688;
	R6689[1] = (char *(*)()) F1248_8688;
	{long i; for (i = 2; i < 4; i++) R6689[i] = (char *(*)()) F1247_8688;}
}

char *(*R6695[4])();
void R6695_init () {
	R6695[0] = (char *(*)()) F1247_8751;
	R6695[1] = (char *(*)()) F1248_8751;
	R6695[2] = (char *(*)()) F1247_8751;
	R6695[3] = (char *(*)()) F1250_8810;
}

char *(*R6696[4])();
void R6696_init () {
	R6696[0] = (char *(*)()) F1247_8752;
	R6696[1] = (char *(*)()) F1248_8752;
	{long i; for (i = 2; i < 4; i++) R6696[i] = (char *(*)()) F1247_8752;}
}

char *(*R6697[4])();
void R6697_init () {
	R6697[0] = (char *(*)()) F1247_8755;
	R6697[1] = (char *(*)()) F1248_8755;
	{long i; for (i = 2; i < 4; i++) R6697[i] = (char *(*)()) F1247_8755;}
}

char *(*R6698[4])();
void R6698_init () {
	R6698[0] = (char *(*)()) F1247_8756;
	R6698[1] = (char *(*)()) F1248_8756;
	{long i; for (i = 2; i < 4; i++) R6698[i] = (char *(*)()) F1247_8756;}
}

char *(*R6699[4])();
void R6699_init () {
	R6699[0] = (char *(*)()) F1247_8757;
	R6699[1] = (char *(*)()) F1248_8757;
	{long i; for (i = 2; i < 4; i++) R6699[i] = (char *(*)()) F1247_8757;}
}

char *(*R6734[2])();
void R6734_init () {
	R6734[0] = (char *(*)()) F1261_8882;
	R6734[1] = (char *(*)()) F1262_8882;
}

char *(*R6739[25])();
void R6739_init () {
	R6739[0] = (char *(*)()) F1264_8910;
	R6739[1] = (char *(*)()) F1263_8910;
	R6739[9] = (char *(*)()) F1263_8910;
	R6739[20] = (char *(*)()) F1263_8910;
	R6739[21] = (char *(*)()) F1264_8910;
	R6739[22] = (char *(*)()) F1265_8910;
	{long i; for (i = 23; i < 25; i++) R6739[i] = (char *(*)()) F1266_8910;}
}

char *(*R6741[25])();
void R6741_init () {
	R6741[0] = (char *(*)()) F1267_8935;
	R6741[1] = (char *(*)()) F1268_8999;
	R6741[9] = (char *(*)()) F1269_9051;
	R6741[20] = (char *(*)()) F1269_9051;
	R6741[21] = (char *(*)()) F1270_9051;
	R6741[22] = (char *(*)()) F1271_9051;
	R6741[23] = (char *(*)()) F1272_9051;
	R6741[24] = (char *(*)()) F1273_9051;
}

char *(*R6742[25])();
void R6742_init () {
	R6742[0] = (char *(*)()) F1264_8913;
	R6742[1] = (char *(*)()) F1263_8913;
	R6742[9] = (char *(*)()) F1269_9116;
	R6742[20] = (char *(*)()) F1269_9116;
	R6742[21] = (char *(*)()) F1270_9116;
	R6742[22] = (char *(*)()) F1271_9116;
	R6742[23] = (char *(*)()) F1272_9116;
	R6742[24] = (char *(*)()) F1273_9116;
}

char *(*R6767[16])();
void R6767_init () {
	R6767[0] = (char *(*)()) F1269_9027;
	R6767[11] = (char *(*)()) F1269_9027;
	R6767[12] = (char *(*)()) F1270_9027;
	R6767[13] = (char *(*)()) F1271_9027;
	R6767[14] = (char *(*)()) F1272_9027;
	R6767[15] = (char *(*)()) F1273_9027;
}

char *(*R6771[16])();
void R6771_init () {
	R6771[0] = (char *(*)()) F1269_9046;
	R6771[11] = (char *(*)()) F1269_9046;
	R6771[12] = (char *(*)()) F1270_9046;
	R6771[13] = (char *(*)()) F1271_9046;
	R6771[14] = (char *(*)()) F1272_9046;
	R6771[15] = (char *(*)()) F1273_9046;
}

char *(*R6776[16])();
void R6776_init () {
	R6776[0] = (char *(*)()) F1275_9153;
	R6776[11] = (char *(*)()) F1282_9228;
	R6776[12] = (char *(*)()) F1283_9228_6776_35;
	R6776[13] = (char *(*)()) F1284_9228_6776_35;
	R6776[14] = (char *(*)()) F1285_9228_6776_35;
	R6776[15] = (char *(*)()) F1286_9228_6776_35;
}
static EIF_REFERENCE F1283_9228_6776_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1283_9228(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1284_9228_6776_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1284_9228(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(915, 0x00).id, 915, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1285_9228_6776_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1285_9228(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1286_9228_6776_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1286_9228(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6777[16])();
void R6777_init () {
	R6777[0] = (char *(*)()) F1275_9157;
	R6777[11] = (char *(*)()) F1282_9229;
	R6777[12] = (char *(*)()) F1283_9229_6777_135;
	R6777[13] = (char *(*)()) F1284_9229_6777_135;
	R6777[14] = (char *(*)()) F1285_9229_6777_135;
	R6777[15] = (char *(*)()) F1286_9229_6777_135;
}
static void F1283_9229_6777_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1283_9229(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1284_9229_6777_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1284_9229(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F1285_9229_6777_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1285_9229(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1286_9229_6777_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1286_9229(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R6778[16])();
void R6778_init () {
	R6778[0] = (char *(*)()) F1274_9143;
	R6778[11] = (char *(*)()) F1282_9230;
	R6778[12] = (char *(*)()) F1283_9230;
	R6778[13] = (char *(*)()) F1284_9230_6778_35;
	R6778[14] = (char *(*)()) F1285_9230;
	R6778[15] = (char *(*)()) F1286_9230_6778_35;
}
static EIF_REFERENCE F1284_9230_6778_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1284_9230(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(918, 0x00).id, 918, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1286_9230_6778_35 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1286_9230(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R6779[16])();
void R6779_init () {
	R6779[0] = (char *(*)()) F1275_9154;
	R6779[11] = (char *(*)()) F1282_9231;
	R6779[12] = (char *(*)()) F1283_9231;
	R6779[13] = (char *(*)()) F1284_9231;
	R6779[14] = (char *(*)()) F1285_9231;
	R6779[15] = (char *(*)()) F1286_9231;
}

char *(*R6782[16])();
void R6782_init () {
	R6782[0] = (char *(*)()) F1269_9060;
	R6782[11] = (char *(*)()) F1269_9060;
	R6782[12] = (char *(*)()) F1270_9060;
	R6782[13] = (char *(*)()) F1271_9060_6782_4;
	R6782[14] = (char *(*)()) F1272_9060;
	R6782[15] = (char *(*)()) F1273_9060_6782_4;
}
static void F1271_9060_6782_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1271_9060(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F1273_9060_6782_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1273_9060(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R6783[16])();
void R6783_init () {
	R6783[0] = (char *(*)()) F1269_9061;
	R6783[11] = (char *(*)()) F1269_9061;
	R6783[12] = (char *(*)()) F1270_9061;
	R6783[13] = (char *(*)()) F1271_9061_6783_29;
	R6783[14] = (char *(*)()) F1272_9061;
	R6783[15] = (char *(*)()) F1273_9061_6783_29;
}
static EIF_INTEGER_32 F1271_9061_6783_29 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1271_9061(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_INTEGER_32 F1273_9061_6783_29 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1273_9061(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R6784[16])();
void R6784_init () {
	R6784[0] = (char *(*)()) F1274_9144;
	R6784[11] = (char *(*)()) F1277_9196;
	R6784[12] = (char *(*)()) F1278_9196;
	R6784[13] = (char *(*)()) F1279_9196;
	R6784[14] = (char *(*)()) F1280_9196;
	R6784[15] = (char *(*)()) F1281_9196;
}

char *(*R6785[16])();
void R6785_init () {
	R6785[0] = (char *(*)()) F1274_9145;
	R6785[11] = (char *(*)()) F1277_9223;
	R6785[12] = (char *(*)()) F1278_9223;
	R6785[13] = (char *(*)()) F1279_9223;
	R6785[14] = (char *(*)()) F1280_9223;
	R6785[15] = (char *(*)()) F1281_9223;
}

char *(*R6786[16])();
void R6786_init () {
	R6786[0] = (char *(*)()) F1276_9181;
	R6786[11] = (char *(*)()) F1287_9265;
	R6786[12] = (char *(*)()) F1288_9265;
	R6786[13] = (char *(*)()) F1289_9265_6786_29;
	R6786[14] = (char *(*)()) F1290_9265;
	R6786[15] = (char *(*)()) F1291_9265_6786_29;
}
static EIF_INTEGER_32 F1289_9265_6786_29 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1289_9265(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_INTEGER_32 F1291_9265_6786_29 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1291_9265(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R6787[16])();
void R6787_init () {
	R6787[0] = (char *(*)()) F1269_9065;
	R6787[11] = (char *(*)()) F1269_9065;
	R6787[12] = (char *(*)()) F1270_9065;
	R6787[13] = (char *(*)()) F1271_9065;
	R6787[14] = (char *(*)()) F1272_9065;
	R6787[15] = (char *(*)()) F1273_9065;
}

char *(*R6788[16])();
void R6788_init () {
	R6788[0] = (char *(*)()) F1275_9156;
	R6788[11] = (char *(*)()) F1282_9233;
	R6788[12] = (char *(*)()) F1283_9233;
	R6788[13] = (char *(*)()) F1284_9233;
	R6788[14] = (char *(*)()) F1285_9233;
	R6788[15] = (char *(*)()) F1286_9233;
}

char *(*R6789[16])();
void R6789_init () {
	R6789[0] = (char *(*)()) F1275_9158;
	R6789[11] = (char *(*)()) F1282_9234;
	R6789[12] = (char *(*)()) F1283_9234;
	R6789[13] = (char *(*)()) F1284_9234;
	R6789[14] = (char *(*)()) F1285_9234;
	R6789[15] = (char *(*)()) F1286_9234;
}

char *(*R6790[16])();
void R6790_init () {
	R6790[0] = (char *(*)()) F1275_9159;
	R6790[11] = (char *(*)()) F1282_9235;
	R6790[12] = (char *(*)()) F1283_9235;
	R6790[13] = (char *(*)()) F1284_9235;
	R6790[14] = (char *(*)()) F1285_9235;
	R6790[15] = (char *(*)()) F1286_9235;
}

char *(*R6791[16])();
void R6791_init () {
	R6791[0] = (char *(*)()) F1275_9160;
	R6791[11] = (char *(*)()) F1282_9236;
	R6791[12] = (char *(*)()) F1283_9236;
	R6791[13] = (char *(*)()) F1284_9236;
	R6791[14] = (char *(*)()) F1285_9236;
	R6791[15] = (char *(*)()) F1286_9236;
}

char *(*R6792[16])();
void R6792_init () {
	R6792[0] = (char *(*)()) F1275_9161;
	R6792[11] = (char *(*)()) F1282_9237;
	R6792[12] = (char *(*)()) F1283_9237;
	R6792[13] = (char *(*)()) F1284_9237;
	R6792[14] = (char *(*)()) F1285_9237;
	R6792[15] = (char *(*)()) F1286_9237;
}

char *(*R6793[16])();
void R6793_init () {
	R6793[0] = (char *(*)()) F1274_9146;
	R6793[11] = (char *(*)()) F1282_9239;
	R6793[12] = (char *(*)()) F1283_9239;
	R6793[13] = (char *(*)()) F1284_9239;
	R6793[14] = (char *(*)()) F1285_9239;
	R6793[15] = (char *(*)()) F1286_9239;
}

char *(*R6794[16])();
void R6794_init () {
	R6794[0] = (char *(*)()) F1274_9147;
	R6794[11] = (char *(*)()) F1282_9240;
	R6794[12] = (char *(*)()) F1283_9240;
	R6794[13] = (char *(*)()) F1284_9240_6794_135;
	R6794[14] = (char *(*)()) F1285_9240;
	R6794[15] = (char *(*)()) F1286_9240_6794_135;
}
static void F1284_9240_6794_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1284_9240(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F1286_9240_6794_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1286_9240(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R6795[16])();
void R6795_init () {
	R6795[0] = (char *(*)()) F1274_9148;
	R6795[11] = (char *(*)()) F1282_9241;
	R6795[12] = (char *(*)()) F1283_9241;
	R6795[13] = (char *(*)()) F1284_9241;
	R6795[14] = (char *(*)()) F1285_9241;
	R6795[15] = (char *(*)()) F1286_9241;
}

char *(*R6796[16])();
void R6796_init () {
	R6796[0] = (char *(*)()) F1274_9149;
	R6796[11] = (char *(*)()) F1282_9242;
	R6796[12] = (char *(*)()) F1283_9242;
	R6796[13] = (char *(*)()) F1284_9242;
	R6796[14] = (char *(*)()) F1285_9242;
	R6796[15] = (char *(*)()) F1286_9242;
}

char *(*R6797[16])();
void R6797_init () {
	R6797[0] = (char *(*)()) F1274_9150;
	R6797[11] = (char *(*)()) F1282_9243;
	R6797[12] = (char *(*)()) F1283_9243;
	R6797[13] = (char *(*)()) F1284_9243;
	R6797[14] = (char *(*)()) F1285_9243;
	R6797[15] = (char *(*)()) F1286_9243;
}

char *(*R6798[16])();
void R6798_init () {
	R6798[0] = (char *(*)()) F1274_9151;
	R6798[11] = (char *(*)()) F1282_9244;
	R6798[12] = (char *(*)()) F1283_9244;
	R6798[13] = (char *(*)()) F1284_9244;
	R6798[14] = (char *(*)()) F1285_9244;
	R6798[15] = (char *(*)()) F1286_9244;
}

char *(*R6799[16])();
void R6799_init () {
	R6799[0] = (char *(*)()) F1275_9163;
	R6799[11] = (char *(*)()) F1282_9246;
	R6799[12] = (char *(*)()) F1283_9246;
	R6799[13] = (char *(*)()) F1284_9246;
	R6799[14] = (char *(*)()) F1285_9246;
	R6799[15] = (char *(*)()) F1286_9246;
}

char *(*R6800[16])();
void R6800_init () {
	R6800[0] = (char *(*)()) F1275_9164;
	R6800[11] = (char *(*)()) F1282_9247;
	R6800[12] = (char *(*)()) F1283_9247;
	R6800[13] = (char *(*)()) F1284_9247;
	R6800[14] = (char *(*)()) F1285_9247;
	R6800[15] = (char *(*)()) F1286_9247;
}

char *(*R6801[16])();
void R6801_init () {
	R6801[0] = (char *(*)()) F1275_9165;
	R6801[11] = (char *(*)()) F1282_9248;
	R6801[12] = (char *(*)()) F1283_9248;
	R6801[13] = (char *(*)()) F1284_9248;
	R6801[14] = (char *(*)()) F1285_9248;
	R6801[15] = (char *(*)()) F1286_9248;
}

char *(*R6802[16])();
void R6802_init () {
	R6802[0] = (char *(*)()) F1275_9166;
	R6802[11] = (char *(*)()) F1282_9249;
	R6802[12] = (char *(*)()) F1283_9249;
	R6802[13] = (char *(*)()) F1284_9249;
	R6802[14] = (char *(*)()) F1285_9249;
	R6802[15] = (char *(*)()) F1286_9249;
}

char *(*R6803[16])();
void R6803_init () {
	R6803[0] = (char *(*)()) F1275_9167;
	R6803[11] = (char *(*)()) F1282_9250;
	R6803[12] = (char *(*)()) F1283_9250;
	R6803[13] = (char *(*)()) F1284_9250;
	R6803[14] = (char *(*)()) F1285_9250;
	R6803[15] = (char *(*)()) F1286_9250;
}

char *(*R6804[16])();
void R6804_init () {
	R6804[0] = (char *(*)()) F1275_9169;
	R6804[11] = (char *(*)()) F1282_9252;
	R6804[12] = (char *(*)()) F1283_9252;
	R6804[13] = (char *(*)()) F1284_9252;
	R6804[14] = (char *(*)()) F1285_9252;
	R6804[15] = (char *(*)()) F1286_9252;
}

char *(*R6805[16])();
void R6805_init () {
	R6805[0] = (char *(*)()) F1275_9170;
	R6805[11] = (char *(*)()) F1282_9253;
	R6805[12] = (char *(*)()) F1283_9253;
	R6805[13] = (char *(*)()) F1284_9253;
	R6805[14] = (char *(*)()) F1285_9253;
	R6805[15] = (char *(*)()) F1286_9253;
}

char *(*R6806[16])();
void R6806_init () {
	R6806[0] = (char *(*)()) F1275_9171;
	R6806[11] = (char *(*)()) F1282_9254;
	R6806[12] = (char *(*)()) F1283_9254;
	R6806[13] = (char *(*)()) F1284_9254;
	R6806[14] = (char *(*)()) F1285_9254;
	R6806[15] = (char *(*)()) F1286_9254;
}

char *(*R6807[16])();
void R6807_init () {
	R6807[0] = (char *(*)()) F1275_9172;
	R6807[11] = (char *(*)()) F1282_9255;
	R6807[12] = (char *(*)()) F1283_9255;
	R6807[13] = (char *(*)()) F1284_9255;
	R6807[14] = (char *(*)()) F1285_9255;
	R6807[15] = (char *(*)()) F1286_9255;
}

char *(*R6808[16])();
void R6808_init () {
	R6808[0] = (char *(*)()) F1275_9173;
	R6808[11] = (char *(*)()) F1282_9256;
	R6808[12] = (char *(*)()) F1283_9256;
	R6808[13] = (char *(*)()) F1284_9256;
	R6808[14] = (char *(*)()) F1285_9256;
	R6808[15] = (char *(*)()) F1286_9256;
}

char *(*R6809[16])();
void R6809_init () {
	R6809[0] = (char *(*)()) F1275_9174;
	R6809[11] = (char *(*)()) F1282_9257;
	R6809[12] = (char *(*)()) F1283_9257;
	R6809[13] = (char *(*)()) F1284_9257;
	R6809[14] = (char *(*)()) F1285_9257;
	R6809[15] = (char *(*)()) F1286_9257;
}

char *(*R6819[16])();
void R6819_init () {
	R6819[0] = (char *(*)()) F1269_9099;
	R6819[11] = (char *(*)()) F1269_9099;
	R6819[12] = (char *(*)()) F1270_9099;
	R6819[13] = (char *(*)()) F1271_9099;
	R6819[14] = (char *(*)()) F1272_9099;
	R6819[15] = (char *(*)()) F1273_9099;
}

char *(*R6820[16])();
void R6820_init () {
	R6820[0] = (char *(*)()) F1269_9100;
	R6820[11] = (char *(*)()) F1269_9100;
	R6820[12] = (char *(*)()) F1270_9100;
	R6820[13] = (char *(*)()) F1271_9100;
	R6820[14] = (char *(*)()) F1272_9100;
	R6820[15] = (char *(*)()) F1273_9100;
}

char *(*R6822[16])();
void R6822_init () {
	R6822[0] = (char *(*)()) F1269_9102;
	R6822[11] = (char *(*)()) F1269_9102;
	R6822[12] = (char *(*)()) F1270_9102;
	R6822[13] = (char *(*)()) F1271_9102;
	R6822[14] = (char *(*)()) F1272_9102;
	R6822[15] = (char *(*)()) F1273_9102;
}

char *(*R6823[16])();
void R6823_init () {
	R6823[0] = (char *(*)()) F1269_9117;
	R6823[11] = (char *(*)()) F1269_9117;
	R6823[12] = (char *(*)()) F1270_9117;
	R6823[13] = (char *(*)()) F1271_9117;
	R6823[14] = (char *(*)()) F1272_9117;
	R6823[15] = (char *(*)()) F1273_9117;
}

static EIF_TYPE_INDEX Y6827_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6827_pgtype22[] = {0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y6827_gen_type [23];
EIF_TYPE_INDEX Y6827 [23];
void Y6827_init (void)
{
	egc_routines_types [6827] = Y6827;
	egc_routines_gen_types [6827] = Y6827_gen_type;
	egc_routines_offset [6827] = 1268;
	Y6827_gen_type [0] = Y6827_pgtype0;
	Y6827_gen_type [1] = Y6827_pgtype1;
	Y6827_gen_type [2] = Y6827_pgtype2;
	Y6827_gen_type [3] = Y6827_pgtype3;
	Y6827_gen_type [4] = Y6827_pgtype4;
	Y6827_gen_type [5] = Y6827_pgtype5;
	Y6827_gen_type [6] = Y6827_pgtype6;
	Y6827_gen_type [7] = Y6827_pgtype7;
	Y6827_gen_type [8] = Y6827_pgtype8;
	Y6827_gen_type [9] = Y6827_pgtype9;
	Y6827_gen_type [10] = Y6827_pgtype10;
	Y6827_gen_type [11] = Y6827_pgtype11;
	Y6827_gen_type [12] = Y6827_pgtype12;
	Y6827_gen_type [13] = Y6827_pgtype13;
	Y6827_gen_type [14] = Y6827_pgtype14;
	Y6827_gen_type [15] = Y6827_pgtype15;
	Y6827_gen_type [16] = Y6827_pgtype16;
	Y6827_gen_type [17] = Y6827_pgtype17;
	Y6827_gen_type [18] = Y6827_pgtype18;
	Y6827_gen_type [19] = Y6827_pgtype19;
	Y6827_gen_type [20] = Y6827_pgtype20;
	Y6827_gen_type [21] = Y6827_pgtype21;
	Y6827_gen_type [22] = Y6827_pgtype22;
}

char *(*R6838[5])();
void R6838_init () {
	R6838[0] = (char *(*)()) F1277_9185;
	R6838[1] = (char *(*)()) F1278_9185;
	R6838[2] = (char *(*)()) F1279_9185;
	R6838[3] = (char *(*)()) F1280_9185;
	R6838[4] = (char *(*)()) F1281_9185;
}

char *(*R6841[5])();
void R6841_init () {
	R6841[0] = (char *(*)()) F1277_9188;
	R6841[1] = (char *(*)()) F1278_9188;
	R6841[2] = (char *(*)()) F1279_9188;
	R6841[3] = (char *(*)()) F1280_9188;
	R6841[4] = (char *(*)()) F1281_9188;
}

char *(*R6855[5])();
void R6855_init () {
	R6855[0] = (char *(*)()) F1277_9225;
	R6855[1] = (char *(*)()) F1278_9225;
	R6855[2] = (char *(*)()) F1279_9225;
	R6855[3] = (char *(*)()) F1280_9225;
	R6855[4] = (char *(*)()) F1281_9225;
}

char *(*R6863[5])();
void R6863_init () {
	R6863[0] = (char *(*)()) F1282_9261;
	R6863[1] = (char *(*)()) F1283_9261;
	R6863[2] = (char *(*)()) F1284_9261;
	R6863[3] = (char *(*)()) F1285_9261;
	R6863[4] = (char *(*)()) F1286_9261;
}

char *(*R6931[4])();
void R6931_init () {
	R6931[0] = (char *(*)()) F1297_9376;
	{long i; for (i = 1; i < 4; i++) R6931[i] = (char *(*)()) F1298_9378;}
}

char *(*R6936[4])();
void R6936_init () {
	R6936[0] = (char *(*)()) F734_4462;
	{long i; for (i = 1; i < 4; i++) R6936[i] = (char *(*)()) F733_4407;}
}

char *(*R6943[4])();
void R6943_init () {
	R6943[0] = (char *(*)()) F1302_9409;
	{long i; for (i = 1; i < 4; i++) R6943[i] = (char *(*)()) F1303_9412;}
}

char *(*R7114[3])();
void R7114_init () {
	R7114[0] = (char *(*)()) F1314_9646;
	{long i; for (i = 1; i < 3; i++) R7114[i] = (char *(*)()) F1315_9674;}
}

char *(*R7115[3])();
void R7115_init () {
	R7115[0] = (char *(*)()) F1314_9647;
	{long i; for (i = 1; i < 3; i++) R7115[i] = (char *(*)()) F1315_9675;}
}

char *(*R7116[3])();
void R7116_init () {
	R7116[0] = (char *(*)()) F1314_9648;
	{long i; for (i = 1; i < 3; i++) R7116[i] = (char *(*)()) F1315_9676;}
}

char *(*R7126[3])();
void R7126_init () {
	R7126[0] = (char *(*)()) F1314_9657;
	{long i; for (i = 1; i < 3; i++) R7126[i] = (char *(*)()) F1315_9685;}
}

char *(*R7127[3])();
void R7127_init () {
	R7127[0] = (char *(*)()) F1314_9658;
	{long i; for (i = 1; i < 3; i++) R7127[i] = (char *(*)()) F1315_9686;}
}

char *(*R7130[3])();
void R7130_init () {
	R7130[0] = (char *(*)()) F1314_9660;
	{long i; for (i = 1; i < 3; i++) R7130[i] = (char *(*)()) F1315_9688;}
}

char *(*R7139[2])();
void R7139_init () {
	R7139[0] = (char *(*)()) F1315_9692;
	R7139[1] = (char *(*)()) F1316_9694;
}

char *(*R7156[3])();
void R7156_init () {
	{long i; for (i = 0; i < 2; i++) R7156[i] = (char *(*)()) F1318_9717;}
	R7156[2] = (char *(*)()) F1320_9741;
}

char *(*R7157[3])();
void R7157_init () {
	{long i; for (i = 0; i < 2; i++) R7157[i] = (char *(*)()) F1318_9718;}
	R7157[2] = (char *(*)()) F1320_9742;
}

char *(*R7194[52])();
void R7194_init () {
	R7194[0] = (char *(*)()) F1324_9769;
	R7194[51] = (char *(*)()) F1375_11147;
}

char *(*R7196[52])();
void R7196_init () {
	R7196[0] = (char *(*)()) F1324_9771;
	R7196[51] = (char *(*)()) F1375_11148;
}

char *(*R7253[8])();
void R7253_init () {
	{long i; for (i = 0; i < 3; i++) R7253[i] = (char *(*)()) F1328_9839;}
	R7253[4] = (char *(*)()) F1328_9839;
	R7253[6] = (char *(*)()) F1328_9839;
	R7253[7] = (char *(*)()) F1327_9828;
}

char *(*R7309[2])();
void R7309_init () {
	R7309[0] = (char *(*)()) F1337_9933;
	R7309[1] = (char *(*)()) F1338_9947;
}

char *(*R7364[8])();
void R7364_init () {
	R7364[0] = (char *(*)()) F1340_9969;
	R7364[1] = (char *(*)()) F1341_9999;
	R7364[6] = (char *(*)()) F1340_9969;
	R7364[7] = (char *(*)()) F1341_9999;
}

char *(*R7365[8])();
void R7365_init () {
	R7365[0] = (char *(*)()) F1340_9970;
	R7365[1] = (char *(*)()) F1341_10000;
	R7365[6] = (char *(*)()) F1340_9970;
	R7365[7] = (char *(*)()) F1341_10000;
}

char *(*R7366[8])();
void R7366_init () {
	R7366[0] = (char *(*)()) F1340_9971;
	R7366[1] = (char *(*)()) F1341_10001;
	R7366[6] = (char *(*)()) F1340_9971;
	R7366[7] = (char *(*)()) F1341_10001;
}

char *(*R7368[8])();
void R7368_init () {
	{long i; for (i = 0; i < 2; i++) R7368[i] = (char *(*)()) F1339_9964;}
	{long i; for (i = 6; i < 8; i++) R7368[i] = (char *(*)()) F1345_10127;}
}

char *(*R7369[8])();
void R7369_init () {
	R7369[0] = (char *(*)()) F1339_9965;
	R7369[1] = (char *(*)()) F1341_10028;
	R7369[6] = (char *(*)()) F1339_9965;
	R7369[7] = (char *(*)()) F1341_10028;
}

char *(*R7423[5])();
void R7423_init () {
	R7423[0] = (char *(*)()) F1343_10051;
	R7423[1] = (char *(*)()) F1344_10085;
	R7423[3] = (char *(*)()) F1343_10051;
	R7423[4] = (char *(*)()) F1344_10085;
}

char *(*R7424[5])();
void R7424_init () {
	R7424[0] = (char *(*)()) F1343_10052;
	R7424[1] = (char *(*)()) F1344_10086;
	R7424[3] = (char *(*)()) F1343_10052;
	R7424[4] = (char *(*)()) F1344_10086;
}

char *(*R7425[5])();
void R7425_init () {
	R7425[0] = (char *(*)()) F1343_10053;
	R7425[1] = (char *(*)()) F1344_10087;
	R7425[3] = (char *(*)()) F1343_10053;
	R7425[4] = (char *(*)()) F1344_10087;
}

char *(*R7426[5])();
void R7426_init () {
	R7426[0] = (char *(*)()) F1343_10054;
	R7426[1] = (char *(*)()) F1344_10088;
	R7426[3] = (char *(*)()) F1343_10054;
	R7426[4] = (char *(*)()) F1344_10088;
}

char *(*R7430[5])();
void R7430_init () {
	{long i; for (i = 0; i < 2; i++) R7430[i] = (char *(*)()) F1342_10042;}
	{long i; for (i = 3; i < 5; i++) R7430[i] = (char *(*)()) F1345_10127;}
}

char *(*R7431[5])();
void R7431_init () {
	R7431[0] = (char *(*)()) F1342_10043;
	R7431[1] = (char *(*)()) F1344_10115;
	R7431[3] = (char *(*)()) F1342_10043;
	R7431[4] = (char *(*)()) F1344_10115;
}

char *(*R7882[4])();
void R7882_init () {
	{long i; for (i = 0; i < 2; i++) R7882[i] = (char *(*)()) F1361_10573;}
	{long i; for (i = 2; i < 4; i++) R7882[i] = (char *(*)()) F1364_10687;}
}

char *(*R7883[4])();
void R7883_init () {
	{long i; for (i = 0; i < 2; i++) R7883[i] = (char *(*)()) F1361_10574;}
	{long i; for (i = 2; i < 4; i++) R7883[i] = (char *(*)()) F1364_10688;}
}

char *(*R8001[3])();
void R8001_init () {
	R8001[0] = (char *(*)()) F1369_10798;
	R8001[2] = (char *(*)()) F1371_10987;
}

char *(*R8002[3])();
void R8002_init () {
	R8002[0] = (char *(*)()) F1369_10799;
	R8002[2] = (char *(*)()) F1371_10988;
}

char *(*R8003[3])();
void R8003_init () {
	R8003[0] = (char *(*)()) F1369_10790;
	R8003[2] = (char *(*)()) F1371_10979;
}

char *(*R8004[3])();
void R8004_init () {
	R8004[0] = (char *(*)()) F1369_10791;
	R8004[2] = (char *(*)()) F1371_10980;
}

char *(*R8005[3])();
void R8005_init () {
	R8005[0] = (char *(*)()) F1369_10792;
	R8005[2] = (char *(*)()) F1371_10981;
}

char *(*R8006[3])();
void R8006_init () {
	R8006[0] = (char *(*)()) F1369_10793;
	R8006[2] = (char *(*)()) F1371_10982;
}

char *(*R8007[3])();
void R8007_init () {
	R8007[0] = (char *(*)()) F1369_10794;
	R8007[2] = (char *(*)()) F1371_10983;
}

char *(*R8008[3])();
void R8008_init () {
	R8008[0] = (char *(*)()) F1369_10795;
	R8008[2] = (char *(*)()) F1371_10984;
}

char *(*R8009[3])();
void R8009_init () {
	R8009[0] = (char *(*)()) F1369_10796;
	R8009[2] = (char *(*)()) F1371_10985;
}

char *(*R8032[3])();
void R8032_init () {
	R8032[0] = (char *(*)()) F1369_10902;
	R8032[2] = (char *(*)()) F1371_11064;
}

char *(*R8033[3])();
void R8033_init () {
	R8033[0] = (char *(*)()) F1369_10903;
	R8033[2] = (char *(*)()) F1371_11065;
}

char *(*R8034[3])();
void R8034_init () {
	R8034[0] = (char *(*)()) F1369_10904;
	R8034[2] = (char *(*)()) F1371_11066;
}

char *(*R8035[3])();
void R8035_init () {
	R8035[0] = (char *(*)()) F1369_10905;
	R8035[2] = (char *(*)()) F1371_11067;
}

char *(*R8036[3])();
void R8036_init () {
	R8036[0] = (char *(*)()) F1369_10906;
	R8036[2] = (char *(*)()) F1371_11068;
}

char *(*R8037[3])();
void R8037_init () {
	R8037[0] = (char *(*)()) F1369_10907;
	R8037[2] = (char *(*)()) F1371_11069;
}

char *(*R8400[18])();
void R8400_init () {
	R8400[0] = (char *(*)()) F1377_11187;
	R8400[1] = (char *(*)()) F1378_11190;
	R8400[2] = (char *(*)()) F1379_11193;
	R8400[3] = (char *(*)()) F1380_11196;
	R8400[4] = (char *(*)()) F1381_11199;
	R8400[5] = (char *(*)()) F1382_11202;
	R8400[6] = (char *(*)()) F1383_11205;
	R8400[7] = (char *(*)()) F1384_11208;
	R8400[8] = (char *(*)()) F1385_11211;
	R8400[9] = (char *(*)()) F1386_11214;
	R8400[10] = (char *(*)()) F1387_11217;
	R8400[11] = (char *(*)()) F1388_11220;
	R8400[12] = (char *(*)()) F1389_11223;
	R8400[14] = (char *(*)()) F1391_11226;
	R8400[15] = (char *(*)()) F1392_11229;
	R8400[16] = (char *(*)()) F1393_11232;
	R8400[17] = (char *(*)()) F1394_11235;
}

char *(*R8801[3])();
void R8801_init () {
	R8801[0] = (char *(*)()) F1420_11680;
	{long i; for (i = 1; i < 3; i++) R8801[i] = (char *(*)()) F1421_11729;}
}
char *(*R2[1424])();
void R2_init () {}
char *(*R6[1424])();
void R6_init () {}

char *(*R3[1424])();
void R3_init () {
	R3[319] = (char *(*)()) F320_3039;
	R3[320] = (char *(*)()) F321_3050;
	R3[321] = (char *(*)()) F322_3081;
	R3[326] = (char *(*)()) F327_3207;
	R3[330] = (char *(*)()) F322_3081;
	R3[338] = (char *(*)()) F339_3541;
	R3[402] = (char *(*)()) F403_3775;
	{long i; for (i = 732; i < 734; i++) R3[i] = (char *(*)()) F338_3478;}
	R3[1078] = (char *(*)()) F1079_7671;
	R3[1292] = (char *(*)()) F327_3207;
	{long i; for (i = 1296; i < 1300; i++) R3[i] = (char *(*)()) F338_3478;}
	{long i; for (i = 1301; i < 1305; i++) R3[i] = (char *(*)()) F338_3478;}
}

char *(*R4[1424])();
void R4_init () {
	R4[0] = (char *(*)()) F1_15;
	{long i; for (i = 5; i < 18; i++) R4[i] = (char *(*)()) F1_15;}
	R4[21] = (char *(*)()) F1_15;
	{long i; for (i = 23; i < 63; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 64; i < 66; i++) R4[i] = (char *(*)()) F1_15;}
	R4[67] = (char *(*)()) F1_15;
	R4[69] = (char *(*)()) F1_15;
	R4[71] = (char *(*)()) F1_15;
	{long i; for (i = 73; i < 78; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 79; i < 88; i++) R4[i] = (char *(*)()) F1_15;}
	R4[89] = (char *(*)()) F1_15;
	R4[91] = (char *(*)()) F1_15;
	{long i; for (i = 93; i < 95; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 98; i < 101; i++) R4[i] = (char *(*)()) F1_15;}
	R4[103] = (char *(*)()) F1_15;
	R4[105] = (char *(*)()) F1_15;
	{long i; for (i = 108; i < 129; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 130; i < 133; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 134; i < 136; i++) R4[i] = (char *(*)()) F1_15;}
	R4[143] = (char *(*)()) F1_15;
	{long i; for (i = 145; i < 163; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 165; i < 168; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 170; i < 173; i++) R4[i] = (char *(*)()) F1_15;}
	R4[175] = (char *(*)()) F1_15;
	{long i; for (i = 178; i < 182; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 183; i < 189; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 192; i < 210; i++) R4[i] = (char *(*)()) F1_15;}
	R4[212] = (char *(*)()) F1_15;
	{long i; for (i = 214; i < 234; i++) R4[i] = (char *(*)()) F1_15;}
	R4[236] = (char *(*)()) F1_15;
	{long i; for (i = 238; i < 241; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 242; i < 245; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 246; i < 248; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 250; i < 252; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 253; i < 256; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 257; i < 261; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 262; i < 264; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 265; i < 273; i++) R4[i] = (char *(*)()) F1_15;}
	R4[274] = (char *(*)()) F1_15;
	{long i; for (i = 277; i < 283; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 284; i < 286; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 287; i < 314; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 315; i < 318; i++) R4[i] = (char *(*)()) F1_15;}
	R4[319] = (char *(*)()) F320_2958;
	{long i; for (i = 320; i < 324; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 324; i < 326; i++) R4[i] = (char *(*)()) F325_3157;}
	{long i; for (i = 326; i < 328; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 329; i < 337; i++) R4[i] = (char *(*)()) F1_15;}
	R4[338] = (char *(*)()) F1_15;
	R4[340] = (char *(*)()) F1_15;
	{long i; for (i = 343; i < 388; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 401; i < 403; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 408; i < 411; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 424; i < 428; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 457; i < 476; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 488; i < 526; i++) R4[i] = (char *(*)()) F1_15;}
	R4[668] = (char *(*)()) F1_15;
	{long i; for (i = 732; i < 734; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 746; i < 758; i++) R4[i] = (char *(*)()) F1_15;}
	R4[770] = (char *(*)()) F771_4567;
	R4[771] = (char *(*)()) F772_4632;
	R4[772] = (char *(*)()) F773_4632;
	R4[773] = (char *(*)()) F774_4632;
	R4[774] = (char *(*)()) F775_4632;
	R4[775] = (char *(*)()) F776_4632;
	R4[776] = (char *(*)()) F777_4632;
	R4[777] = (char *(*)()) F778_4632;
	R4[778] = (char *(*)()) F779_4632;
	R4[779] = (char *(*)()) F780_4632;
	R4[780] = (char *(*)()) F781_4632;
	R4[781] = (char *(*)()) F782_4632;
	R4[782] = (char *(*)()) F783_4632;
	R4[783] = (char *(*)()) F772_4632;
	R4[784] = (char *(*)()) F774_4632;
	R4[785] = (char *(*)()) F776_4632;
	R4[786] = (char *(*)()) F775_4632;
	R4[787] = (char *(*)()) F773_4632;
	R4[788] = (char *(*)()) F778_4632;
	R4[837] = (char *(*)()) F838_4725;
	R4[838] = (char *(*)()) F839_4725;
	{long i; for (i = 839; i < 841; i++) R4[i] = (char *(*)()) F1_15;}
	R4[841] = (char *(*)()) F842_4754;
	R4[842] = (char *(*)()) F843_4820;
	R4[843] = (char *(*)()) F844_4820;
	R4[844] = (char *(*)()) F845_4820;
	R4[845] = (char *(*)()) F846_4820;
	R4[846] = (char *(*)()) F847_4820;
	R4[847] = (char *(*)()) F848_4820;
	R4[848] = (char *(*)()) F849_4820;
	R4[849] = (char *(*)()) F850_4820;
	R4[850] = (char *(*)()) F851_4820;
	R4[851] = (char *(*)()) F852_4820;
	R4[852] = (char *(*)()) F853_4820;
	R4[853] = (char *(*)()) F854_4820;
	R4[854] = (char *(*)()) F855_4892;
	R4[855] = (char *(*)()) F856_4892;
	R4[856] = (char *(*)()) F857_4892;
	R4[857] = (char *(*)()) F858_4892;
	R4[858] = (char *(*)()) F859_4892;
	R4[859] = (char *(*)()) F855_4892;
	R4[860] = (char *(*)()) F856_4892;
	R4[861] = (char *(*)()) F855_4892;
	{long i; for (i = 862; i < 865; i++) R4[i] = (char *(*)()) F1_15;}
	R4[866] = (char *(*)()) F867_5013;
	{long i; for (i = 867; i < 973; i++) R4[i] = (char *(*)()) F1_15;}
	R4[974] = (char *(*)()) F974_6277;
	R4[975] = (char *(*)()) F976_6309;
	{long i; for (i = 976; i < 978; i++) R4[i] = (char *(*)()) F977_6309;}
	R4[982] = (char *(*)()) F983_6503;
	R4[983] = (char *(*)()) F982_6484;
	R4[985] = (char *(*)()) F986_6668;
	{long i; for (i = 986; i < 988; i++) R4[i] = (char *(*)()) F985_6652;}
	{long i; for (i = 988; i < 1000; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1005; i < 1028; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1029; i < 1031; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1035; i < 1038; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1041; i < 1043; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1044; i < 1054; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1055] = (char *(*)()) F1_15;
	{long i; for (i = 1057; i < 1081; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1084; i < 1095; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1098; i < 1100; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1101; i < 1103; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1105] = (char *(*)()) F1_15;
	{long i; for (i = 1130; i < 1132; i++) R4[i] = (char *(*)()) F1107_8274;}
	R4[1132] = (char *(*)()) F1110_8274;
	R4[1133] = (char *(*)()) F1107_8274;
	R4[1134] = (char *(*)()) F1111_8274;
	R4[1140] = (char *(*)()) F1107_8274;
	R4[1141] = (char *(*)()) F1108_8274;
	R4[1142] = (char *(*)()) F1109_8274;
	{long i; for (i = 1143; i < 1145; i++) R4[i] = (char *(*)()) F1111_8274;}
	{long i; for (i = 1145; i < 1149; i++) R4[i] = (char *(*)()) F1107_8274;}
	R4[1149] = (char *(*)()) F1108_8274;
	R4[1150] = (char *(*)()) F1109_8274;
	{long i; for (i = 1151; i < 1153; i++) R4[i] = (char *(*)()) F1111_8274;}
	R4[1153] = (char *(*)()) F1107_8274;
	R4[1154] = (char *(*)()) F1108_8274;
	R4[1155] = (char *(*)()) F1109_8274;
	{long i; for (i = 1156; i < 1158; i++) R4[i] = (char *(*)()) F1111_8274;}
	R4[1158] = (char *(*)()) F1107_8274;
	R4[1159] = (char *(*)()) F1108_8274;
	R4[1160] = (char *(*)()) F1109_8274;
	{long i; for (i = 1161; i < 1163; i++) R4[i] = (char *(*)()) F1111_8274;}
	{long i; for (i = 1165; i < 1167; i++) R4[i] = (char *(*)()) F1107_8274;}
	R4[1167] = (char *(*)()) F1111_8274;
	R4[1168] = (char *(*)()) F1107_8274;
	{long i; for (i = 1171; i < 1174; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1175; i < 1182; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1183; i < 1190; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1228] = (char *(*)()) F1229_8590;
	R4[1229] = (char *(*)()) F1230_8590;
	R4[1230] = (char *(*)()) F1231_8590;
	R4[1231] = (char *(*)()) F1232_8590;
	R4[1232] = (char *(*)()) F1233_8590;
	R4[1246] = (char *(*)()) F1247_8710;
	R4[1247] = (char *(*)()) F1248_8710;
	{long i; for (i = 1248; i < 1250; i++) R4[i] = (char *(*)()) F1247_8710;}
	R4[1256] = (char *(*)()) F1257_8861;
	R4[1257] = (char *(*)()) F1258_8861;
	R4[1260] = (char *(*)()) F1261_8890;
	R4[1261] = (char *(*)()) F1262_8890;
	R4[1266] = (char *(*)()) F1267_8924;
	R4[1267] = (char *(*)()) F1268_8961;
	R4[1275] = (char *(*)()) F1269_9047;
	R4[1286] = (char *(*)()) F1277_9214;
	R4[1287] = (char *(*)()) F1278_9214;
	R4[1288] = (char *(*)()) F1279_9214;
	R4[1289] = (char *(*)()) F1280_9214;
	R4[1290] = (char *(*)()) F1281_9214;
	{long i; for (i = 1291; i < 1294; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1296; i < 1300; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1301; i < 1311; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1313; i < 1324; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1330; i < 1333; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1334] = (char *(*)()) F1_15;
	{long i; for (i = 1336; i < 1338; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1339; i < 1341; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1342; i < 1344; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1345; i < 1352; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1353; i < 1355; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1361; i < 1365; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1368] = (char *(*)()) F1_15;
	{long i; for (i = 1370; i < 1375; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1376; i < 1389; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1390; i < 1395; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1396] = (char *(*)()) F1_15;
	R4[1398] = (char *(*)()) F1399_11337;
	{long i; for (i = 1399; i < 1414; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1415; i < 1422; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1422; i < 1424; i++) R4[i] = (char *(*)()) F1423_11856;}
}

char *(*R5[1424])();
void R5_init () {
	R5[0] = (char *(*)()) F1_8;
	{long i; for (i = 5; i < 18; i++) R5[i] = (char *(*)()) F1_8;}
	R5[21] = (char *(*)()) F1_8;
	{long i; for (i = 23; i < 63; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 64; i < 66; i++) R5[i] = (char *(*)()) F1_8;}
	R5[67] = (char *(*)()) F1_8;
	R5[69] = (char *(*)()) F1_8;
	R5[71] = (char *(*)()) F1_8;
	{long i; for (i = 73; i < 78; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 79; i < 88; i++) R5[i] = (char *(*)()) F1_8;}
	R5[89] = (char *(*)()) F1_8;
	R5[91] = (char *(*)()) F1_8;
	{long i; for (i = 93; i < 95; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 98; i < 101; i++) R5[i] = (char *(*)()) F1_8;}
	R5[103] = (char *(*)()) F1_8;
	R5[105] = (char *(*)()) F1_8;
	{long i; for (i = 108; i < 129; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 130; i < 133; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 134; i < 136; i++) R5[i] = (char *(*)()) F1_8;}
	R5[143] = (char *(*)()) F1_8;
	{long i; for (i = 145; i < 163; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 165; i < 168; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 170; i < 173; i++) R5[i] = (char *(*)()) F1_8;}
	R5[175] = (char *(*)()) F1_8;
	{long i; for (i = 178; i < 182; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 183; i < 189; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 192; i < 210; i++) R5[i] = (char *(*)()) F1_8;}
	R5[212] = (char *(*)()) F1_8;
	{long i; for (i = 214; i < 234; i++) R5[i] = (char *(*)()) F1_8;}
	R5[236] = (char *(*)()) F1_8;
	{long i; for (i = 238; i < 241; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 242; i < 245; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 246; i < 248; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 250; i < 252; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 253; i < 256; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 257; i < 261; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 262; i < 264; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 265; i < 273; i++) R5[i] = (char *(*)()) F1_8;}
	R5[274] = (char *(*)()) F1_8;
	{long i; for (i = 277; i < 283; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 284; i < 286; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 287; i < 314; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 315; i < 318; i++) R5[i] = (char *(*)()) F1_8;}
	R5[319] = (char *(*)()) F320_2957;
	{long i; for (i = 320; i < 323; i++) R5[i] = (char *(*)()) F1_8;}
	R5[323] = (char *(*)()) F324_3107;
	{long i; for (i = 324; i < 326; i++) R5[i] = (char *(*)()) F325_3156;}
	{long i; for (i = 326; i < 328; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 329; i < 337; i++) R5[i] = (char *(*)()) F1_8;}
	R5[338] = (char *(*)()) F1_8;
	R5[340] = (char *(*)()) F1_8;
	{long i; for (i = 343; i < 388; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 401; i < 403; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 408; i < 411; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 424; i < 428; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 457; i < 476; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 488; i < 526; i++) R5[i] = (char *(*)()) F1_8;}
	R5[668] = (char *(*)()) F1_8;
	{long i; for (i = 732; i < 734; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 746; i < 758; i++) R5[i] = (char *(*)()) F1_8;}
	R5[770] = (char *(*)()) F771_4553;
	R5[771] = (char *(*)()) F772_4594;
	R5[772] = (char *(*)()) F773_4594;
	R5[773] = (char *(*)()) F774_4594;
	R5[774] = (char *(*)()) F775_4594;
	R5[775] = (char *(*)()) F776_4594;
	R5[776] = (char *(*)()) F777_4594;
	R5[777] = (char *(*)()) F778_4594;
	R5[778] = (char *(*)()) F779_4594;
	R5[779] = (char *(*)()) F780_4594;
	R5[780] = (char *(*)()) F781_4594;
	R5[781] = (char *(*)()) F782_4594;
	R5[782] = (char *(*)()) F783_4594;
	R5[783] = (char *(*)()) F772_4594;
	R5[784] = (char *(*)()) F774_4594;
	R5[785] = (char *(*)()) F776_4594;
	R5[786] = (char *(*)()) F775_4594;
	R5[787] = (char *(*)()) F773_4594;
	R5[788] = (char *(*)()) F778_4594;
	R5[837] = (char *(*)()) F814_4676;
	R5[838] = (char *(*)()) F815_4676;
	{long i; for (i = 839; i < 841; i++) R5[i] = (char *(*)()) F1_8;}
	R5[841] = (char *(*)()) F842_4741;
	R5[842] = (char *(*)()) F843_4793;
	R5[843] = (char *(*)()) F844_4793;
	R5[844] = (char *(*)()) F845_4793;
	R5[845] = (char *(*)()) F846_4793;
	R5[846] = (char *(*)()) F847_4793;
	R5[847] = (char *(*)()) F848_4793;
	R5[848] = (char *(*)()) F849_4793;
	R5[849] = (char *(*)()) F850_4793;
	R5[850] = (char *(*)()) F851_4793;
	R5[851] = (char *(*)()) F852_4793;
	R5[852] = (char *(*)()) F853_4793;
	R5[853] = (char *(*)()) F854_4793;
	R5[854] = (char *(*)()) F855_4858;
	R5[855] = (char *(*)()) F856_4858;
	R5[856] = (char *(*)()) F857_4858;
	R5[857] = (char *(*)()) F858_4858;
	R5[858] = (char *(*)()) F859_4858;
	R5[859] = (char *(*)()) F860_4952;
	R5[860] = (char *(*)()) F861_4952;
	R5[861] = (char *(*)()) F855_4858;
	{long i; for (i = 862; i < 865; i++) R5[i] = (char *(*)()) F1_8;}
	R5[866] = (char *(*)()) F867_5010;
	R5[867] = (char *(*)()) F868_5047;
	R5[868] = (char *(*)()) F869_5047;
	R5[869] = (char *(*)()) F870_5047;
	R5[870] = (char *(*)()) F871_5047;
	R5[871] = (char *(*)()) F872_5047;
	R5[872] = (char *(*)()) F873_5047;
	R5[873] = (char *(*)()) F874_5047;
	R5[874] = (char *(*)()) F875_5047;
	R5[875] = (char *(*)()) F876_5047;
	R5[876] = (char *(*)()) F877_5047;
	R5[877] = (char *(*)()) F878_5047;
	R5[878] = (char *(*)()) F879_5047;
	R5[879] = (char *(*)()) F880_5047;
	R5[880] = (char *(*)()) F881_5047;
	R5[881] = (char *(*)()) F882_5047;
	R5[882] = (char *(*)()) F883_5047;
	R5[883] = (char *(*)()) F884_5047;
	R5[884] = (char *(*)()) F885_5047;
	R5[885] = (char *(*)()) F886_5047;
	R5[886] = (char *(*)()) F887_5047;
	R5[887] = (char *(*)()) F888_5047;
	R5[888] = (char *(*)()) F889_5047;
	R5[889] = (char *(*)()) F890_5047;
	R5[890] = (char *(*)()) F891_5047;
	R5[891] = (char *(*)()) F892_5047;
	R5[892] = (char *(*)()) F893_5047;
	R5[893] = (char *(*)()) F894_5047;
	R5[894] = (char *(*)()) F895_5047;
	R5[895] = (char *(*)()) F896_5047;
	R5[896] = (char *(*)()) F897_5047;
	R5[897] = (char *(*)()) F898_5047;
	R5[898] = (char *(*)()) F899_5090;
	{long i; for (i = 899; i < 901; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 901; i < 904; i++) R5[i] = (char *(*)()) F902_5223;}
	{long i; for (i = 904; i < 907; i++) R5[i] = (char *(*)()) F905_5321;}
	{long i; for (i = 907; i < 910; i++) R5[i] = (char *(*)()) F908_5420;}
	{long i; for (i = 910; i < 913; i++) R5[i] = (char *(*)()) F911_5519;}
	{long i; for (i = 913; i < 916; i++) R5[i] = (char *(*)()) F914_5618;}
	{long i; for (i = 916; i < 919; i++) R5[i] = (char *(*)()) F917_5712;}
	{long i; for (i = 919; i < 922; i++) R5[i] = (char *(*)()) F920_5806;}
	{long i; for (i = 922; i < 925; i++) R5[i] = (char *(*)()) F923_5901;}
	{long i; for (i = 925; i < 928; i++) R5[i] = (char *(*)()) F926_6000;}
	{long i; for (i = 928; i < 931; i++) R5[i] = (char *(*)()) F929_6066;}
	{long i; for (i = 931; i < 934; i++) R5[i] = (char *(*)()) F932_6127;}
	{long i; for (i = 934; i < 937; i++) R5[i] = (char *(*)()) F935_6167;}
	{long i; for (i = 937; i < 940; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 940; i < 973; i++) R5[i] = (char *(*)()) F941_6233;}
	R5[974] = (char *(*)()) F974_6270;
	R5[975] = (char *(*)()) F976_6308;
	{long i; for (i = 976; i < 978; i++) R5[i] = (char *(*)()) F977_6308;}
	{long i; for (i = 982; i < 984; i++) R5[i] = (char *(*)()) F982_6469;}
	{long i; for (i = 985; i < 988; i++) R5[i] = (char *(*)()) F985_6637;}
	{long i; for (i = 988; i < 1000; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1005; i < 1013; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1013] = (char *(*)()) F191_2133;
	{long i; for (i = 1014; i < 1024; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1024] = (char *(*)()) F1025_7171;
	R5[1025] = (char *(*)()) F1026_7179;
	{long i; for (i = 1026; i < 1028; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1029; i < 1031; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1035; i < 1038; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1041; i < 1043; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1044; i < 1054; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1055] = (char *(*)()) F1_8;
	{long i; for (i = 1057; i < 1081; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1084; i < 1095; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1098; i < 1100; i++) R5[i] = (char *(*)()) F1098_8186;}
	{long i; for (i = 1101; i < 1103; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1105] = (char *(*)()) F1_8;
	{long i; for (i = 1130; i < 1132; i++) R5[i] = (char *(*)()) F1107_8275;}
	R5[1132] = (char *(*)()) F1110_8275;
	R5[1133] = (char *(*)()) F1107_8275;
	R5[1134] = (char *(*)()) F1111_8275;
	R5[1140] = (char *(*)()) F1107_8275;
	R5[1141] = (char *(*)()) F1108_8275;
	R5[1142] = (char *(*)()) F1109_8275;
	{long i; for (i = 1143; i < 1145; i++) R5[i] = (char *(*)()) F1111_8275;}
	{long i; for (i = 1145; i < 1149; i++) R5[i] = (char *(*)()) F1107_8275;}
	R5[1149] = (char *(*)()) F1108_8275;
	R5[1150] = (char *(*)()) F1109_8275;
	{long i; for (i = 1151; i < 1153; i++) R5[i] = (char *(*)()) F1111_8275;}
	R5[1153] = (char *(*)()) F1107_8275;
	R5[1154] = (char *(*)()) F1108_8275;
	R5[1155] = (char *(*)()) F1109_8275;
	{long i; for (i = 1156; i < 1158; i++) R5[i] = (char *(*)()) F1111_8275;}
	R5[1158] = (char *(*)()) F1107_8275;
	R5[1159] = (char *(*)()) F1108_8275;
	R5[1160] = (char *(*)()) F1109_8275;
	{long i; for (i = 1161; i < 1163; i++) R5[i] = (char *(*)()) F1111_8275;}
	{long i; for (i = 1165; i < 1167; i++) R5[i] = (char *(*)()) F1107_8275;}
	R5[1167] = (char *(*)()) F1111_8275;
	R5[1168] = (char *(*)()) F1107_8275;
	{long i; for (i = 1171; i < 1174; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1175; i < 1182; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1183; i < 1190; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1228] = (char *(*)()) F1229_8589;
	R5[1229] = (char *(*)()) F1230_8589;
	R5[1230] = (char *(*)()) F1231_8589;
	R5[1231] = (char *(*)()) F1232_8589;
	R5[1232] = (char *(*)()) F1233_8589;
	R5[1246] = (char *(*)()) F1247_8711;
	R5[1247] = (char *(*)()) F1248_8711;
	{long i; for (i = 1248; i < 1250; i++) R5[i] = (char *(*)()) F1247_8711;}
	R5[1256] = (char *(*)()) F1257_8862;
	R5[1257] = (char *(*)()) F1258_8862;
	R5[1260] = (char *(*)()) F1261_8891;
	R5[1261] = (char *(*)()) F1262_8891;
	R5[1266] = (char *(*)()) F1267_8925;
	R5[1267] = (char *(*)()) F1268_8962;
	R5[1275] = (char *(*)()) F1274_9128;
	R5[1286] = (char *(*)()) F1277_9202;
	R5[1287] = (char *(*)()) F1278_9202;
	R5[1288] = (char *(*)()) F1279_9202;
	R5[1289] = (char *(*)()) F1280_9202;
	R5[1290] = (char *(*)()) F1281_9202;
	{long i; for (i = 1291; i < 1294; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1296; i < 1300; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1301; i < 1311; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1313; i < 1324; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1330; i < 1333; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1334] = (char *(*)()) F1_8;
	{long i; for (i = 1336; i < 1338; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1339] = (char *(*)()) F1340_9990;
	R5[1340] = (char *(*)()) F1_8;
	R5[1342] = (char *(*)()) F1343_10076;
	R5[1343] = (char *(*)()) F1_8;
	R5[1345] = (char *(*)()) F1346_10152;
	{long i; for (i = 1346; i < 1352; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1353; i < 1355; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1361; i < 1365; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1368] = (char *(*)()) F1_8;
	{long i; for (i = 1370; i < 1375; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1376; i < 1389; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1390; i < 1395; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1396] = (char *(*)()) F1_8;
	R5[1398] = (char *(*)()) F1398_11318;
	{long i; for (i = 1399; i < 1414; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1415; i < 1422; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1422; i < 1424; i++) R5[i] = (char *(*)()) F1423_11813;}
}


#ifdef __cplusplus
}
#endif
