#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O6457[19];
void O6457_init () {
	{long i; for (i = 0; i < 2; i++) O6457[i] = + _LNGOFF_3_0_0_0_;}
	O6457[2] = + _LNGOFF_4_0_0_0_;
	O6457[3] = + _LNGOFF_5_0_0_0_;
	O6457[4] = + _LNGOFF_7_0_0_0_;
	O6457[5] = + _LNGOFF_3_0_0_0_;
	{long i; for (i = 6; i < 9; i++) O6457[i] = + _LNGOFF_10_0_0_0_;}
	{long i; for (i = 9; i < 13; i++) O6457[i] = + _LNGOFF_5_0_0_0_;}
	O6457[13] = + _LNGOFF_4_0_0_0_;
	{long i; for (i = 14; i < 16; i++) O6457[i] = + _LNGOFF_6_0_0_0_;}
	{long i; for (i = 16; i < 18; i++) O6457[i] = + _LNGOFF_5_0_0_0_;}
	O6457[18] = + _LNGOFF_8_0_0_0_;
}

static EIF_TYPE_INDEX Y6587_pgtype0[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype1[] = {302,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype2[] = {304,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype3[] = {303,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype4[] = {305,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype5[] = {306,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype6[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype7[] = {302,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype8[] = {304,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype9[] = {303,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype10[] = {305,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype11[] = {306,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype12[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype13[] = {302,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype14[] = {304,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype15[] = {303,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype16[] = {305,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype17[] = {301,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype18[] = {301,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype19[] = {304,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype20[] = {301,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype21[] = {305,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype22[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype23[] = {302,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype24[] = {303,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype25[] = {305,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype26[] = {305,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype27[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype28[] = {302,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype29[] = {305,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype30[] = {306,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype31[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype32[] = {305,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype33[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype34[] = {305,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype35[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype36[] = {305,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype37[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype38[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype39[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype40[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype41[] = {302,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype42[] = {306,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype43[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype44[] = {306,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype45[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype46[] = {306,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype47[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype48[] = {302,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype49[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype50[] = {302,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype51[] = {302,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype52[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype53[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype54[] = {302,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype55[] = {303,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype56[] = {305,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype57[] = {305,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype58[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype59[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype60[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype61[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype62[] = {302,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype63[] = {303,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype64[] = {305,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype65[] = {305,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype66[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype67[] = {302,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype68[] = {303,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype69[] = {305,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype70[] = {305,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype71[] = {301,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype72[] = {302,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype73[] = {303,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype74[] = {305,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6587_pgtype75[] = {305,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y6587_gen_type [80];
EIF_TYPE_INDEX Y6587 [80];
void Y6587_init (void)
{
	egc_routines_types [6587] = Y6587;
	egc_routines_gen_types [6587] = Y6587_gen_type;
	egc_routines_offset [6587] = 1211;
	Y6587_gen_type [0] = Y6587_pgtype0;
	Y6587_gen_type [1] = Y6587_pgtype1;
	Y6587_gen_type [2] = Y6587_pgtype2;
	Y6587_gen_type [3] = Y6587_pgtype3;
	Y6587_gen_type [4] = Y6587_pgtype4;
	Y6587_gen_type [5] = Y6587_pgtype5;
	Y6587_gen_type [6] = Y6587_pgtype6;
	Y6587_gen_type [7] = Y6587_pgtype7;
	Y6587_gen_type [8] = Y6587_pgtype8;
	Y6587_gen_type [9] = Y6587_pgtype9;
	Y6587_gen_type [10] = Y6587_pgtype10;
	Y6587_gen_type [11] = Y6587_pgtype11;
	Y6587_gen_type [12] = Y6587_pgtype12;
	Y6587_gen_type [13] = Y6587_pgtype13;
	Y6587_gen_type [14] = Y6587_pgtype14;
	Y6587_gen_type [15] = Y6587_pgtype15;
	Y6587_gen_type [16] = Y6587_pgtype16;
	Y6587_gen_type [17] = Y6587_pgtype17;
	Y6587_gen_type [18] = Y6587_pgtype18;
	Y6587_gen_type [19] = Y6587_pgtype19;
	Y6587_gen_type [20] = Y6587_pgtype20;
	Y6587_gen_type [21] = Y6587_pgtype21;
	Y6587_gen_type [22] = Y6587_pgtype22;
	Y6587_gen_type [23] = Y6587_pgtype23;
	Y6587_gen_type [24] = Y6587_pgtype24;
	Y6587_gen_type [25] = Y6587_pgtype25;
	Y6587_gen_type [26] = Y6587_pgtype26;
	Y6587_gen_type [27] = Y6587_pgtype27;
	Y6587_gen_type [28] = Y6587_pgtype28;
	Y6587_gen_type [29] = Y6587_pgtype29;
	Y6587_gen_type [30] = Y6587_pgtype30;
	Y6587_gen_type [31] = Y6587_pgtype31;
	Y6587_gen_type [32] = Y6587_pgtype32;
	Y6587_gen_type [33] = Y6587_pgtype33;
	Y6587_gen_type [34] = Y6587_pgtype34;
	Y6587_gen_type [35] = Y6587_pgtype35;
	Y6587_gen_type [36] = Y6587_pgtype36;
	Y6587_gen_type [37] = Y6587_pgtype37;
	Y6587_gen_type [38] = Y6587_pgtype38;
	Y6587_gen_type [39] = Y6587_pgtype39;
	Y6587_gen_type [40] = Y6587_pgtype40;
	Y6587_gen_type [41] = Y6587_pgtype41;
	Y6587_gen_type [42] = Y6587_pgtype42;
	Y6587_gen_type [43] = Y6587_pgtype43;
	Y6587_gen_type [44] = Y6587_pgtype44;
	Y6587_gen_type [45] = Y6587_pgtype45;
	Y6587_gen_type [46] = Y6587_pgtype46;
	Y6587_gen_type [47] = Y6587_pgtype47;
	Y6587_gen_type [48] = Y6587_pgtype48;
	Y6587_gen_type [49] = Y6587_pgtype49;
	Y6587_gen_type [50] = Y6587_pgtype50;
	Y6587_gen_type [55] = Y6587_pgtype51;
	Y6587_gen_type [56] = Y6587_pgtype52;
	Y6587_gen_type [57] = Y6587_pgtype53;
	Y6587_gen_type [58] = Y6587_pgtype54;
	Y6587_gen_type [59] = Y6587_pgtype55;
	Y6587_gen_type [60] = Y6587_pgtype56;
	Y6587_gen_type [61] = Y6587_pgtype57;
	Y6587_gen_type [62] = Y6587_pgtype58;
	Y6587_gen_type [63] = Y6587_pgtype59;
	Y6587_gen_type [64] = Y6587_pgtype60;
	Y6587_gen_type [65] = Y6587_pgtype61;
	Y6587_gen_type [66] = Y6587_pgtype62;
	Y6587_gen_type [67] = Y6587_pgtype63;
	Y6587_gen_type [68] = Y6587_pgtype64;
	Y6587_gen_type [69] = Y6587_pgtype65;
	Y6587_gen_type [70] = Y6587_pgtype66;
	Y6587_gen_type [71] = Y6587_pgtype67;
	Y6587_gen_type [72] = Y6587_pgtype68;
	Y6587_gen_type [73] = Y6587_pgtype69;
	Y6587_gen_type [74] = Y6587_pgtype70;
	Y6587_gen_type [75] = Y6587_pgtype71;
	Y6587_gen_type [76] = Y6587_pgtype72;
	Y6587_gen_type [77] = Y6587_pgtype73;
	Y6587_gen_type [78] = Y6587_pgtype74;
	Y6587_gen_type [79] = Y6587_pgtype75;
	Y6587[0] = 301;
	Y6587[1] = 302;
	Y6587[2] = 304;
	Y6587[3] = 303;
	Y6587[4] = 305;
	Y6587[5] = 306;
	Y6587[6] = 301;
	Y6587[7] = 302;
	Y6587[8] = 304;
	Y6587[9] = 303;
	Y6587[10] = 305;
	Y6587[11] = 306;
	Y6587[12] = 301;
	Y6587[13] = 302;
	Y6587[14] = 304;
	Y6587[15] = 303;
	Y6587[16] = 305;
	{long i; for (i = 17; i < 19; i++) Y6587[i] = 301;};
	Y6587[19] = 304;
	Y6587[20] = 301;
	Y6587[21] = 305;
	Y6587[22] = 301;
	Y6587[23] = 302;
	Y6587[24] = 303;
	{long i; for (i = 25; i < 27; i++) Y6587[i] = 305;};
	Y6587[27] = 301;
	Y6587[28] = 302;
	Y6587[29] = 305;
	Y6587[30] = 306;
	Y6587[31] = 301;
	Y6587[32] = 305;
	Y6587[33] = 301;
	Y6587[34] = 305;
	Y6587[35] = 301;
	Y6587[36] = 305;
	{long i; for (i = 37; i < 41; i++) Y6587[i] = 301;};
	Y6587[41] = 302;
	Y6587[42] = 306;
	Y6587[43] = 301;
	Y6587[44] = 306;
	Y6587[45] = 301;
	Y6587[46] = 306;
	Y6587[47] = 301;
	Y6587[48] = 302;
	Y6587[49] = 301;
	Y6587[50] = 302;
	Y6587[55] = 302;
	{long i; for (i = 56; i < 58; i++) Y6587[i] = 301;};
	Y6587[58] = 302;
	Y6587[59] = 303;
	{long i; for (i = 60; i < 62; i++) Y6587[i] = 305;};
	{long i; for (i = 62; i < 66; i++) Y6587[i] = 301;};
	Y6587[66] = 302;
	Y6587[67] = 303;
	{long i; for (i = 68; i < 70; i++) Y6587[i] = 305;};
	Y6587[70] = 301;
	Y6587[71] = 302;
	Y6587[72] = 303;
	{long i; for (i = 73; i < 75; i++) Y6587[i] = 305;};
	Y6587[75] = 301;
	Y6587[76] = 302;
	Y6587[77] = 303;
	{long i; for (i = 78; i < 80; i++) Y6587[i] = 305;};
}

static EIF_TYPE_INDEX Y6620_pgtype0[] = {0xFF01,1276,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6620_pgtype1[] = {0xFF01,1277,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6620_pgtype2[] = {0xFF01,1278,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6620_pgtype3[] = {0xFF01,1279,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6620_pgtype4[] = {0xFF01,1280,0xFFF8,1,0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y6620_gen_type [5];
EIF_TYPE_INDEX Y6620 [5];
void Y6620_init (void)
{
	egc_routines_types [6620] = Y6620;
	egc_routines_gen_types [6620] = Y6620_gen_type;
	egc_routines_offset [6620] = 1228;
	Y6620_gen_type [0] = Y6620_pgtype0;
	Y6620_gen_type [1] = Y6620_pgtype1;
	Y6620_gen_type [2] = Y6620_pgtype2;
	Y6620_gen_type [3] = Y6620_pgtype3;
	Y6620_gen_type [4] = Y6620_pgtype4;
	Y6620[0] = 1276;
	Y6620[1] = 1277;
	Y6620[2] = 1278;
	Y6620[3] = 1279;
	Y6620[4] = 1280;
}

static EIF_TYPE_INDEX Y6693_pgtype0[] = {152,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6693_pgtype1[] = {154,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6693_pgtype2[] = {152,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6693_pgtype3[] = {156,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y6693_gen_type [4];
EIF_TYPE_INDEX Y6693 [4];
void Y6693_init (void)
{
	egc_routines_types [6693] = Y6693;
	egc_routines_gen_types [6693] = Y6693_gen_type;
	egc_routines_offset [6693] = 1246;
	Y6693_gen_type [0] = Y6693_pgtype0;
	Y6693_gen_type [1] = Y6693_pgtype1;
	Y6693_gen_type [2] = Y6693_pgtype2;
	Y6693_gen_type [3] = Y6693_pgtype3;
	Y6693[0] = 152;
	Y6693[1] = 154;
	Y6693[2] = 152;
	Y6693[3] = 156;
}

long O6775[23];
void O6775_init () {
	{long i; for (i = 0; i < 6; i++) O6775[i] = + _LNGOFF_2_0_0_0_;}
	O6775[6] = + _LNGOFF_6_0_0_0_;
	O6775[7] = + _LNGOFF_7_0_0_0_;
	{long i; for (i = 8; i < 13; i++) O6775[i] = + _LNGOFF_4_0_0_0_;}
	{long i; for (i = 13; i < 18; i++) O6775[i] = + _LNGOFF_10_0_0_0_;}
	{long i; for (i = 18; i < 23; i++) O6775[i] = + _LNGOFF_11_0_0_0_;}
}

long O6810[23];
void O6810_init () {
	{long i; for (i = 0; i < 6; i++) O6810[i] = + _LNGOFF_2_0_0_1_;}
	O6810[6] = + _LNGOFF_6_0_0_1_;
	O6810[7] = + _LNGOFF_7_0_0_1_;
	{long i; for (i = 8; i < 13; i++) O6810[i] = + _LNGOFF_4_0_0_1_;}
	{long i; for (i = 13; i < 18; i++) O6810[i] = + _LNGOFF_10_0_0_1_;}
	{long i; for (i = 18; i < 23; i++) O6810[i] = + _LNGOFF_11_0_0_1_;}
}

long O6811[23];
void O6811_init () {
	{long i; for (i = 0; i < 6; i++) O6811[i] = + _LNGOFF_2_0_0_2_;}
	O6811[6] = + _LNGOFF_6_0_0_2_;
	O6811[7] = + _LNGOFF_7_0_0_2_;
	{long i; for (i = 8; i < 13; i++) O6811[i] = + _LNGOFF_4_0_0_2_;}
	{long i; for (i = 13; i < 18; i++) O6811[i] = + _LNGOFF_10_0_0_2_;}
	{long i; for (i = 18; i < 23; i++) O6811[i] = + _LNGOFF_11_0_0_2_;}
}

long O6812[23];
void O6812_init () {
	{long i; for (i = 0; i < 6; i++) O6812[i] = + _LNGOFF_2_0_0_3_;}
	O6812[6] = + _LNGOFF_6_0_0_3_;
	O6812[7] = + _LNGOFF_7_0_0_3_;
	{long i; for (i = 8; i < 13; i++) O6812[i] = + _LNGOFF_4_0_0_3_;}
	{long i; for (i = 13; i < 18; i++) O6812[i] = + _LNGOFF_10_0_0_3_;}
	{long i; for (i = 18; i < 23; i++) O6812[i] = + _LNGOFF_11_0_0_3_;}
}

long O6813[23];
void O6813_init () {
	{long i; for (i = 0; i < 6; i++) O6813[i] = + _LNGOFF_2_0_0_4_;}
	O6813[6] = + _LNGOFF_6_0_0_4_;
	O6813[7] = + _LNGOFF_7_0_0_4_;
	{long i; for (i = 8; i < 13; i++) O6813[i] = + _LNGOFF_4_0_0_4_;}
	{long i; for (i = 13; i < 18; i++) O6813[i] = + _LNGOFF_10_0_0_4_;}
	{long i; for (i = 18; i < 23; i++) O6813[i] = + _LNGOFF_11_0_0_4_;}
}

long O6814[23];
void O6814_init () {
	{long i; for (i = 0; i < 6; i++) O6814[i] = + _LNGOFF_2_0_0_5_;}
	O6814[6] = + _LNGOFF_6_0_0_5_;
	O6814[7] = + _LNGOFF_7_0_0_5_;
	{long i; for (i = 8; i < 13; i++) O6814[i] = + _LNGOFF_4_0_0_5_;}
	{long i; for (i = 13; i < 18; i++) O6814[i] = + _LNGOFF_10_0_0_5_;}
	{long i; for (i = 18; i < 23; i++) O6814[i] = + _LNGOFF_11_0_0_5_;}
}

long O6815[23];
void O6815_init () {
	{long i; for (i = 0; i < 6; i++) O6815[i] = + _LNGOFF_2_0_0_6_;}
	O6815[6] = + _LNGOFF_6_0_0_6_;
	O6815[7] = + _LNGOFF_7_0_0_6_;
	{long i; for (i = 8; i < 13; i++) O6815[i] = + _LNGOFF_4_0_0_6_;}
	{long i; for (i = 13; i < 18; i++) O6815[i] = + _LNGOFF_10_0_0_6_;}
	{long i; for (i = 18; i < 23; i++) O6815[i] = + _LNGOFF_11_0_0_6_;}
}

long O6825[23];
void O6825_init () {
	{long i; for (i = 0; i < 6; i++) O6825[i] = + _LNGOFF_2_0_0_7_;}
	O6825[6] = + _LNGOFF_6_0_0_7_;
	O6825[7] = + _LNGOFF_7_0_0_7_;
	{long i; for (i = 8; i < 13; i++) O6825[i] = + _LNGOFF_4_0_0_7_;}
	{long i; for (i = 13; i < 18; i++) O6825[i] = + _LNGOFF_10_0_0_7_;}
	{long i; for (i = 18; i < 23; i++) O6825[i] = + _LNGOFF_11_0_0_7_;}
}

long O6826[23];
void O6826_init () {
	{long i; for (i = 0; i < 6; i++) O6826[i] = + _LNGOFF_2_0_0_8_;}
	O6826[6] = + _LNGOFF_6_0_0_8_;
	O6826[7] = + _LNGOFF_7_0_0_8_;
	{long i; for (i = 8; i < 13; i++) O6826[i] = + _LNGOFF_4_0_0_8_;}
	{long i; for (i = 13; i < 18; i++) O6826[i] = + _LNGOFF_10_0_0_8_;}
	{long i; for (i = 18; i < 23; i++) O6826[i] = + _LNGOFF_11_0_0_8_;}
}

static EIF_TYPE_INDEX Y6832_pgtype0[] = {0xFF01,28,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y6832_pgtype1[] = {0xFF01,28,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y6832_gen_type [2];
EIF_TYPE_INDEX Y6832 [2];
void Y6832_init (void)
{
	egc_routines_types [6832] = Y6832;
	egc_routines_gen_types [6832] = Y6832_gen_type;
	egc_routines_offset [6832] = 1274;
	Y6832_gen_type [0] = Y6832_pgtype0;
	Y6832_gen_type [1] = Y6832_pgtype1;
	{long i; for (i = 0; i < 2; i++) Y6832[i] = 28;};
}

static EIF_TYPE_INDEX Y6862_pgtype0[] = {0xFF01,28,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6862_pgtype1[] = {0xFF01,28,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6862_pgtype2[] = {0xFF01,30,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6862_pgtype3[] = {0xFF01,28,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6862_pgtype4[] = {0xFF01,32,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6862_pgtype5[] = {0xFF01,28,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6862_pgtype6[] = {0xFF01,28,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6862_pgtype7[] = {0xFF01,30,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6862_pgtype8[] = {0xFF01,28,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6862_pgtype9[] = {0xFF01,32,0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y6862_gen_type [10];
EIF_TYPE_INDEX Y6862 [10];
void Y6862_init (void)
{
	egc_routines_types [6862] = Y6862;
	egc_routines_gen_types [6862] = Y6862_gen_type;
	egc_routines_offset [6862] = 1281;
	Y6862_gen_type [0] = Y6862_pgtype0;
	Y6862_gen_type [1] = Y6862_pgtype1;
	Y6862_gen_type [2] = Y6862_pgtype2;
	Y6862_gen_type [3] = Y6862_pgtype3;
	Y6862_gen_type [4] = Y6862_pgtype4;
	Y6862_gen_type [5] = Y6862_pgtype5;
	Y6862_gen_type [6] = Y6862_pgtype6;
	Y6862_gen_type [7] = Y6862_pgtype7;
	Y6862_gen_type [8] = Y6862_pgtype8;
	Y6862_gen_type [9] = Y6862_pgtype9;
	{long i; for (i = 0; i < 2; i++) Y6862[i] = 28;};
	Y6862[2] = 30;
	Y6862[3] = 28;
	Y6862[4] = 32;
	{long i; for (i = 5; i < 7; i++) Y6862[i] = 28;};
	Y6862[7] = 30;
	Y6862[8] = 28;
	Y6862[9] = 32;
}

long O6925[11];
void O6925_init () {
	{long i; for (i = 0; i < 2; i++) O6925[i] = 0;}
	O6925[2] =  + _REFACS_5_;
	{long i; for (i = 3; i < 6; i++) O6925[i] =  + _REFACS_4_;}
	O6925[6] = 0;
	O6925[7] =  + _REFACS_4_;
	{long i; for (i = 8; i < 11; i++) O6925[i] =  + _REFACS_3_;}
}

long O6934[5];
void O6934_init () {
	O6934[0] =  + _REFACS_1_;
	O6934[1] =  + _REFACS_5_;
	{long i; for (i = 2; i < 5; i++) O6934[i] =  + _REFACS_4_;}
}

long O6944[5];
void O6944_init () {
	O6944[0] = + _CHROFF_3_1_;
	O6944[1] = + _CHROFF_7_5_;
	{long i; for (i = 2; i < 5; i++) O6944[i] = + _CHROFF_6_4_;}
}

long O6945[5];
void O6945_init () {
	O6945[0] =  + _REFACS_2_;
	O6945[1] =  + _REFACS_6_;
	{long i; for (i = 2; i < 5; i++) O6945[i] =  + _REFACS_5_;}
}

long O6946[5];
void O6946_init () {
	O6946[0] = + _CHROFF_3_0_;
	O6946[1] = + _CHROFF_7_1_;
	{long i; for (i = 2; i < 5; i++) O6946[i] = + _CHROFF_6_1_;}
}

long O7146[4];
void O7146_init () {
	O7146[0] = 0;
	{long i; for (i = 1; i < 4; i++) O7146[i] =  + _REFACS_1_;}
}

long O7148[4];
void O7148_init () {
	O7148[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 4; i++) O7148[i] =  + _REFACS_2_;}
}

long O7150[3];
void O7150_init () {
	O7150[0] = + _CHROFF_3_0_;
	O7150[1] = + _CHROFF_5_0_;
	O7150[2] = + _CHROFF_3_0_;
}

long O7153[3];
void O7153_init () {
	O7153[0] = + _CHROFF_3_1_;
	O7153[1] = + _CHROFF_5_1_;
	O7153[2] = + _CHROFF_3_1_;
}

long O7154[3];
void O7154_init () {
	O7154[0] = + _CHROFF_3_2_;
	O7154[1] = + _CHROFF_5_2_;
	O7154[2] = + _CHROFF_3_2_;
}

long O7338[3];
void O7338_init () {
	O7338[0] = 0;
	O7338[1] =  + _REFACS_3_;
	O7338[2] = 0;
}

static EIF_TYPE_INDEX Y7338_pgtype0[] = {0xFF01,1248,0xFF01,1327,0xFFFF};
static EIF_TYPE_INDEX Y7338_pgtype1[] = {0xFF01,1248,0xFF01,1329,0xFFFF};
static EIF_TYPE_INDEX Y7338_pgtype2[] = {0xFF01,1248,0xFF01,1328,0xFFFF};
EIF_TYPE_INDEX *Y7338_gen_type [3];
EIF_TYPE_INDEX Y7338 [3];
void Y7338_init (void)
{
	egc_routines_types [7338] = Y7338;
	egc_routines_gen_types [7338] = Y7338_gen_type;
	egc_routines_offset [7338] = 1335;
	Y7338_gen_type [0] = Y7338_pgtype0;
	Y7338_gen_type [1] = Y7338_pgtype1;
	Y7338_gen_type [2] = Y7338_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y7338[i] = 1248;};
}

long O7457[4];
void O7457_init () {
	O7457[0] = + _LNGOFF_0_0_0_0_;
	O7457[3] = + _LNGOFF_0_0_0_3_;
}

long O7458[4];
void O7458_init () {
	O7458[0] = + _LNGOFF_0_0_0_1_;
	O7458[3] = + _LNGOFF_0_0_0_4_;
}

long O7459[4];
void O7459_init () {
	O7459[0] = + _LNGOFF_0_0_0_2_;
	O7459[3] = + _LNGOFF_0_0_0_5_;
}

long O7460[4];
void O7460_init () {
	O7460[0] = + _LNGOFF_0_0_0_3_;
	O7460[3] = + _LNGOFF_0_0_0_6_;
}

long O7488[4];
void O7488_init () {
	O7488[0] = + _LNGOFF_0_0_0_0_;
	O7488[3] = + _LNGOFF_0_0_0_1_;
}

long O7984[6];
void O7984_init () {
	{long i; for (i = 0; i < 2; i++) O7984[i] = 0;}
	{long i; for (i = 2; i < 4; i++) O7984[i] =  + _REFACS_18_;}
	{long i; for (i = 4; i < 6; i++) O7984[i] =  + _REFACS_6_;}
}

long O7985[6];
void O7985_init () {
	{long i; for (i = 0; i < 2; i++) O7985[i] =  + _REFACS_1_;}
	{long i; for (i = 2; i < 4; i++) O7985[i] =  + _REFACS_19_;}
	{long i; for (i = 4; i < 6; i++) O7985[i] =  + _REFACS_7_;}
}

long O7986[6];
void O7986_init () {
	{long i; for (i = 0; i < 2; i++) O7986[i] =  + _REFACS_2_;}
	{long i; for (i = 2; i < 4; i++) O7986[i] =  + _REFACS_20_;}
	{long i; for (i = 4; i < 6; i++) O7986[i] =  + _REFACS_8_;}
}

long O7987[6];
void O7987_init () {
	{long i; for (i = 0; i < 2; i++) O7987[i] =  + _REFACS_3_;}
	{long i; for (i = 2; i < 4; i++) O7987[i] =  + _REFACS_21_;}
	{long i; for (i = 4; i < 6; i++) O7987[i] =  + _REFACS_9_;}
}

long O7988[6];
void O7988_init () {
	{long i; for (i = 0; i < 2; i++) O7988[i] =  + _REFACS_4_;}
	{long i; for (i = 2; i < 4; i++) O7988[i] =  + _REFACS_22_;}
	{long i; for (i = 4; i < 6; i++) O7988[i] =  + _REFACS_10_;}
}

long O7989[6];
void O7989_init () {
	{long i; for (i = 0; i < 2; i++) O7989[i] =  + _REFACS_5_;}
	{long i; for (i = 2; i < 4; i++) O7989[i] =  + _REFACS_23_;}
	{long i; for (i = 4; i < 6; i++) O7989[i] =  + _REFACS_11_;}
}

long O7990[6];
void O7990_init () {
	{long i; for (i = 0; i < 2; i++) O7990[i] =  + _REFACS_6_;}
	{long i; for (i = 2; i < 4; i++) O7990[i] =  + _REFACS_24_;}
	{long i; for (i = 4; i < 6; i++) O7990[i] =  + _REFACS_12_;}
}

long O7991[6];
void O7991_init () {
	{long i; for (i = 0; i < 2; i++) O7991[i] =  + _REFACS_7_;}
	{long i; for (i = 2; i < 4; i++) O7991[i] =  + _REFACS_25_;}
	{long i; for (i = 4; i < 6; i++) O7991[i] =  + _REFACS_13_;}
}

long O7994[6];
void O7994_init () {
	O7994[0] = + _LNGOFF_11_1_0_0_;
	O7994[1] = + _LNGOFF_12_1_0_0_;
	O7994[2] = + _LNGOFF_31_5_0_25_;
	O7994[3] = + _LNGOFF_65_5_0_25_;
	O7994[4] = + _LNGOFF_23_3_0_1_;
	O7994[5] = + _LNGOFF_45_3_0_1_;
}

long O7995[6];
void O7995_init () {
	O7995[0] = + _LNGOFF_11_1_0_1_;
	O7995[1] = + _LNGOFF_12_1_0_1_;
	O7995[2] = + _LNGOFF_31_5_0_26_;
	O7995[3] = + _LNGOFF_65_5_0_26_;
	O7995[4] = + _LNGOFF_23_3_0_2_;
	O7995[5] = + _LNGOFF_45_3_0_2_;
}

long O7996[6];
void O7996_init () {
	O7996[0] = + _LNGOFF_11_1_0_2_;
	O7996[1] = + _LNGOFF_12_1_0_2_;
	O7996[2] = + _LNGOFF_31_5_0_27_;
	O7996[3] = + _LNGOFF_65_5_0_27_;
	O7996[4] = + _LNGOFF_23_3_0_3_;
	O7996[5] = + _LNGOFF_45_3_0_3_;
}

long O7997[6];
void O7997_init () {
	O7997[0] = + _LNGOFF_11_1_0_3_;
	O7997[1] = + _LNGOFF_12_1_0_3_;
	O7997[2] = + _LNGOFF_31_5_0_28_;
	O7997[3] = + _LNGOFF_65_5_0_28_;
	O7997[4] = + _LNGOFF_23_3_0_4_;
	O7997[5] = + _LNGOFF_45_3_0_4_;
}

long O7998[6];
void O7998_init () {
	O7998[0] = + _LNGOFF_11_1_0_4_;
	O7998[1] = + _LNGOFF_12_1_0_4_;
	O7998[2] = + _LNGOFF_31_5_0_29_;
	O7998[3] = + _LNGOFF_65_5_0_29_;
	O7998[4] = + _LNGOFF_23_3_0_5_;
	O7998[5] = + _LNGOFF_45_3_0_5_;
}

long O7999[6];
void O7999_init () {
	O7999[0] = + _LNGOFF_11_1_0_5_;
	O7999[1] = + _LNGOFF_12_1_0_5_;
	O7999[2] = + _LNGOFF_31_5_0_30_;
	O7999[3] = + _LNGOFF_65_5_0_30_;
	O7999[4] = + _LNGOFF_23_3_0_6_;
	O7999[5] = + _LNGOFF_45_3_0_6_;
}

long O8000[6];
void O8000_init () {
	O8000[0] = + _LNGOFF_11_1_0_6_;
	O8000[1] = + _LNGOFF_12_1_0_6_;
	O8000[2] = + _LNGOFF_31_5_0_31_;
	O8000[3] = + _LNGOFF_65_5_0_31_;
	O8000[4] = + _LNGOFF_23_3_0_7_;
	O8000[5] = + _LNGOFF_45_3_0_7_;
}

long O8012[6];
void O8012_init () {
	{long i; for (i = 0; i < 2; i++) O8012[i] =  + _REFACS_10_;}
	{long i; for (i = 2; i < 4; i++) O8012[i] =  + _REFACS_28_;}
	{long i; for (i = 4; i < 6; i++) O8012[i] =  + _REFACS_16_;}
}

long O8013[6];
void O8013_init () {
	O8013[0] = + _LNGOFF_11_1_0_7_;
	O8013[1] = + _LNGOFF_12_1_0_7_;
	O8013[2] = + _LNGOFF_31_5_0_32_;
	O8013[3] = + _LNGOFF_65_5_0_32_;
	O8013[4] = + _LNGOFF_23_3_0_8_;
	O8013[5] = + _LNGOFF_45_3_0_8_;
}

long O8014[6];
void O8014_init () {
	O8014[0] = + _CHROFF_11_0_;
	O8014[1] = + _CHROFF_12_0_;
	O8014[2] = + _CHROFF_31_4_;
	O8014[3] = + _CHROFF_65_4_;
	O8014[4] = + _CHROFF_23_0_;
	O8014[5] = + _CHROFF_45_0_;
}

long O8015[6];
void O8015_init () {
	O8015[0] = + _LNGOFF_11_1_0_8_;
	O8015[1] = + _LNGOFF_12_1_0_8_;
	O8015[2] = + _LNGOFF_31_5_0_33_;
	O8015[3] = + _LNGOFF_65_5_0_33_;
	O8015[4] = + _LNGOFF_23_3_0_9_;
	O8015[5] = + _LNGOFF_45_3_0_9_;
}

long O8016[6];
void O8016_init () {
	O8016[0] = + _LNGOFF_11_1_0_9_;
	O8016[1] = + _LNGOFF_12_1_0_9_;
	O8016[2] = + _LNGOFF_31_5_0_34_;
	O8016[3] = + _LNGOFF_65_5_0_34_;
	O8016[4] = + _LNGOFF_23_3_0_10_;
	O8016[5] = + _LNGOFF_45_3_0_10_;
}

long O8041[6];
void O8041_init () {
	O8041[0] = + _LNGOFF_11_1_0_10_;
	O8041[1] = + _LNGOFF_12_1_0_10_;
	O8041[2] = + _LNGOFF_31_5_0_35_;
	O8041[3] = + _LNGOFF_65_5_0_35_;
	O8041[4] = + _LNGOFF_23_3_0_11_;
	O8041[5] = + _LNGOFF_45_3_0_11_;
}

long O8764[3];
void O8764_init () {
	O8764[0] = + _CHROFF_8_0_;
	{long i; for (i = 1; i < 3; i++) O8764[i] = + _CHROFF_12_0_;}
}

long O8765[3];
void O8765_init () {
	O8765[0] = + _CHROFF_8_1_;
	{long i; for (i = 1; i < 3; i++) O8765[i] = + _CHROFF_12_1_;}
}

long O8766[3];
void O8766_init () {
	O8766[0] = + _CHROFF_8_2_;
	{long i; for (i = 1; i < 3; i++) O8766[i] = + _CHROFF_12_2_;}
}

long O8767[3];
void O8767_init () {
	O8767[0] = + _CHROFF_8_3_;
	{long i; for (i = 1; i < 3; i++) O8767[i] = + _CHROFF_12_3_;}
}

long O8768[3];
void O8768_init () {
	O8768[0] = + _CHROFF_8_4_;
	{long i; for (i = 1; i < 3; i++) O8768[i] = + _CHROFF_12_4_;}
}

long O8769[3];
void O8769_init () {
	O8769[0] = + _CHROFF_8_5_;
	{long i; for (i = 1; i < 3; i++) O8769[i] = + _CHROFF_12_5_;}
}

long O8770[3];
void O8770_init () {
	O8770[0] = + _CHROFF_8_6_;
	{long i; for (i = 1; i < 3; i++) O8770[i] = + _CHROFF_12_6_;}
}

long O8771[3];
void O8771_init () {
	O8771[0] = + _CHROFF_8_7_;
	{long i; for (i = 1; i < 3; i++) O8771[i] = + _CHROFF_12_7_;}
}

long O8772[3];
void O8772_init () {
	O8772[0] = + _CHROFF_8_8_;
	{long i; for (i = 1; i < 3; i++) O8772[i] = + _CHROFF_12_8_;}
}

long O8773[3];
void O8773_init () {
	O8773[0] = + _CHROFF_8_9_;
	{long i; for (i = 1; i < 3; i++) O8773[i] = + _CHROFF_12_9_;}
}

long O8774[3];
void O8774_init () {
	O8774[0] = + _CHROFF_8_10_;
	{long i; for (i = 1; i < 3; i++) O8774[i] = + _CHROFF_12_10_;}
}

long O8775[3];
void O8775_init () {
	O8775[0] = 0;
	{long i; for (i = 1; i < 3; i++) O8775[i] =  + _REFACS_1_;}
}

long O8776[3];
void O8776_init () {
	O8776[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O8776[i] =  + _REFACS_2_;}
}

long O8777[3];
void O8777_init () {
	O8777[0] =  + _REFACS_2_;
	{long i; for (i = 1; i < 3; i++) O8777[i] =  + _REFACS_3_;}
}

long O8778[3];
void O8778_init () {
	O8778[0] =  + _REFACS_3_;
	{long i; for (i = 1; i < 3; i++) O8778[i] =  + _REFACS_4_;}
}

long O8797[3];
void O8797_init () {
	O8797[0] =  + _REFACS_4_;
	{long i; for (i = 1; i < 3; i++) O8797[i] =  + _REFACS_5_;}
}

long O8798[3];
void O8798_init () {
	O8798[0] = + _LNGOFF_8_13_0_1_;
	{long i; for (i = 1; i < 3; i++) O8798[i] = + _LNGOFF_12_16_0_4_;}
}

long O8799[3];
void O8799_init () {
	O8799[0] = + _LNGOFF_8_13_0_2_;
	{long i; for (i = 1; i < 3; i++) O8799[i] = + _LNGOFF_12_16_0_5_;}
}

long O8809[3];
void O8809_init () {
	O8809[0] = + _CHROFF_8_11_;
	{long i; for (i = 1; i < 3; i++) O8809[i] = + _CHROFF_12_11_;}
}

long O8810[3];
void O8810_init () {
	O8810[0] = + _CHROFF_8_12_;
	{long i; for (i = 1; i < 3; i++) O8810[i] = + _CHROFF_12_12_;}
}

long O8811[3];
void O8811_init () {
	O8811[0] = + _LNGOFF_8_13_0_0_;
	{long i; for (i = 1; i < 3; i++) O8811[i] = + _LNGOFF_12_16_0_0_;}
}

long O8816[3];
void O8816_init () {
	O8816[0] = + _LNGOFF_8_13_0_3_;
	{long i; for (i = 1; i < 3; i++) O8816[i] = + _LNGOFF_12_16_0_6_;}
}

long O8817[3];
void O8817_init () {
	O8817[0] =  + _REFACS_5_;
	{long i; for (i = 1; i < 3; i++) O8817[i] =  + _REFACS_6_;}
}

long O8818[3];
void O8818_init () {
	O8818[0] = + _LNGOFF_8_13_0_4_;
	{long i; for (i = 1; i < 3; i++) O8818[i] = + _LNGOFF_12_16_0_7_;}
}

long O8819[3];
void O8819_init () {
	O8819[0] = + _LNGOFF_8_13_0_5_;
	{long i; for (i = 1; i < 3; i++) O8819[i] = + _LNGOFF_12_16_0_8_;}
}

long O8820[3];
void O8820_init () {
	O8820[0] = + _LNGOFF_8_13_0_6_;
	{long i; for (i = 1; i < 3; i++) O8820[i] = + _LNGOFF_12_16_0_9_;}
}

long O8821[3];
void O8821_init () {
	O8821[0] = + _LNGOFF_8_13_0_7_;
	{long i; for (i = 1; i < 3; i++) O8821[i] = + _LNGOFF_12_16_0_10_;}
}

long O8822[3];
void O8822_init () {
	O8822[0] =  + _REFACS_6_;
	{long i; for (i = 1; i < 3; i++) O8822[i] =  + _REFACS_7_;}
}

long O8823[3];
void O8823_init () {
	O8823[0] =  + _REFACS_7_;
	{long i; for (i = 1; i < 3; i++) O8823[i] =  + _REFACS_8_;}
}

long O8824[3];
void O8824_init () {
	O8824[0] = + _I64OFF_8_13_0_9_0_0_0_;
	{long i; for (i = 1; i < 3; i++) O8824[i] = + _I64OFF_12_16_0_23_0_0_0_;}
}

long O8825[3];
void O8825_init () {
	O8825[0] = + _I64OFF_8_13_0_9_0_0_1_;
	{long i; for (i = 1; i < 3; i++) O8825[i] = + _I64OFF_12_16_0_23_0_0_1_;}
}

long O8826[3];
void O8826_init () {
	O8826[0] = + _LNGOFF_8_13_0_8_;
	{long i; for (i = 1; i < 3; i++) O8826[i] = + _LNGOFF_12_16_0_11_;}
}


#ifdef __cplusplus
}
#endif
