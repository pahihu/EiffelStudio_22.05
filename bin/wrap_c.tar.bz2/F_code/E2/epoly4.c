#include "epoly4.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2190[1159])();
void R2190_init () {
	R2190[0] = (char *(*)()) F213_2336;
	{long i; for (i = 2; i < 4; i++) R2190[i] = (char *(*)()) F214_2349;}
	R2190[4] = (char *(*)()) F217_2368;
	R2190[5] = (char *(*)()) F218_2381;
	{long i; for (i = 6; i < 8; i++) R2190[i] = (char *(*)()) F219_2402;}
	R2190[806] = (char *(*)()) F1019_7083;
	R2190[807] = (char *(*)()) F1020_7101;
	{long i; for (i = 808; i < 810; i++) R2190[i] = (char *(*)()) F214_2349;}
	R2190[1105] = (char *(*)()) F1318_9710;
	R2190[1106] = (char *(*)()) F1319_9731;
	R2190[1107] = (char *(*)()) F1318_9710;
	R2190[1109] = (char *(*)()) F1322_9751;
	R2190[1158] = (char *(*)()) F214_2349;
}

char *(*R2229[2])();
void R2229_init () {
	R2229[0] = (char *(*)()) F225_2415;
	R2229[1] = (char *(*)()) F226_2415;
}

char *(*R2272[40])();
void R2272_init () {
	R2272[0] = (char *(*)()) F232_2458;
	{long i; for (i = 1; i < 3; i++) R2272[i] = (char *(*)()) F233_2482;}
	R2272[5] = (char *(*)()) F237_2485;
	R2272[7] = (char *(*)()) F239_2487;
	R2272[8] = (char *(*)()) F240_2493;
	R2272[9] = (char *(*)()) F241_2510;
	R2272[11] = (char *(*)()) F243_2514;
	R2272[12] = (char *(*)()) F244_2516;
	R2272[13] = (char *(*)()) F245_2518;
	R2272[15] = (char *(*)()) F247_2520;
	R2272[16] = (char *(*)()) F248_2522;
	R2272[19] = (char *(*)()) F251_2526;
	R2272[20] = (char *(*)()) F252_2530;
	R2272[22] = (char *(*)()) F254_2532;
	R2272[23] = (char *(*)()) F255_2534;
	R2272[24] = (char *(*)()) F256_2536;
	R2272[26] = (char *(*)()) F258_2542;
	R2272[27] = (char *(*)()) F259_2546;
	R2272[28] = (char *(*)()) F260_2550;
	R2272[29] = (char *(*)()) F261_2552;
	R2272[31] = (char *(*)()) F263_2554;
	R2272[32] = (char *(*)()) F264_2556;
	R2272[34] = (char *(*)()) F266_2558;
	R2272[35] = (char *(*)()) F267_2560;
	R2272[36] = (char *(*)()) F268_2562;
	R2272[37] = (char *(*)()) F269_2564;
	R2272[38] = (char *(*)()) F270_2568;
	R2272[39] = (char *(*)()) F271_2570;
}

char *(*R2333[1148])();
void R2333_init () {
	R2333[0] = (char *(*)()) F272_2574;
	R2333[1] = (char *(*)()) F273_2578;
	R2333[3] = (char *(*)()) F273_2578;
	R2333[6] = (char *(*)()) F272_2574;
	R2333[7] = (char *(*)()) F279_2606;
	R2333[8] = (char *(*)()) F272_2574;
	R2333[592] = (char *(*)()) F272_2574;
	R2333[752] = (char *(*)()) F272_2574;
	{long i; for (i = 776; i < 781; i++) R2333[i] = (char *(*)()) F1048_7417;}
	R2333[1129] = (char *(*)()) F1401_11369;
	R2333[1130] = (char *(*)()) F1402_11374;
	R2333[1131] = (char *(*)()) F1403_11389;
	R2333[1132] = (char *(*)()) F1404_11405;
	R2333[1133] = (char *(*)()) F1405_11443;
	R2333[1134] = (char *(*)()) F1406_11459;
	{long i; for (i = 1135; i < 1137; i++) R2333[i] = (char *(*)()) F273_2578;}
	R2333[1147] = (char *(*)()) F273_2578;
}

char *(*R2341[1145])();
void R2341_init () {
	R2341[0] = (char *(*)()) F275_2587;
	R2341[1127] = (char *(*)()) F1402_11376;
	R2341[1128] = (char *(*)()) F1403_11391;
	R2341[1129] = (char *(*)()) F1404_11406;
	R2341[1130] = (char *(*)()) F1405_11445;
	R2341[1131] = (char *(*)()) F1406_11461;
	R2341[1132] = (char *(*)()) F1407_11479;
	R2341[1133] = (char *(*)()) F1408_11483;
	R2341[1144] = (char *(*)()) F1419_11627;
}

char *(*R2357[775])();
void R2357_init () {
	R2357[0] = (char *(*)()) F278_2605;
	R2357[1] = (char *(*)()) F279_2610;
	R2357[2] = (char *(*)()) F280_2614;
	R2357[586] = (char *(*)()) F280_2614;
	R2357[746] = (char *(*)()) F1024_7151;
	R2357[771] = (char *(*)()) F1049_7440;
	R2357[772] = (char *(*)()) F1050_7444;
	R2357[773] = (char *(*)()) F1051_7447;
	R2357[774] = (char *(*)()) F1052_7453;
}

char *(*R2365[585])();
void R2365_init () {
	R2365[0] = (char *(*)()) F280_2615;
	R2365[584] = (char *(*)()) F864_4971;
}

char *(*R2612[1135])();
void R2612_init () {
	R2612[0] = (char *(*)()) F290_2870;
	R2612[1] = (char *(*)()) F291_2870;
	R2612[2] = (char *(*)()) F292_2870;
	R2612[3] = (char *(*)()) F293_2870;
	R2612[4] = (char *(*)()) F294_2870;
	R2612[5] = (char *(*)()) F295_2870;
	R2612[6] = (char *(*)()) F296_2870;
	R2612[7] = (char *(*)()) F297_2870;
	R2612[8] = (char *(*)()) F298_2870;
	R2612[9] = (char *(*)()) F299_2870;
	R2612[10] = (char *(*)()) F300_2870;
	R2612[11] = (char *(*)()) F301_2870;
	{long i; for (i = 35; i < 37; i++) R2612[i] = (char *(*)()) F297_2870;}
	R2612[482] = (char *(*)()) F290_2870;
	R2612[483] = (char *(*)()) F291_2870;
	R2612[484] = (char *(*)()) F292_2870;
	R2612[485] = (char *(*)()) F293_2870;
	R2612[486] = (char *(*)()) F294_2870;
	R2612[487] = (char *(*)()) F295_2870;
	R2612[488] = (char *(*)()) F296_2870;
	R2612[489] = (char *(*)()) F297_2870;
	R2612[490] = (char *(*)()) F298_2870;
	R2612[491] = (char *(*)()) F299_2870;
	R2612[492] = (char *(*)()) F300_2870;
	R2612[493] = (char *(*)()) F301_2870;
	R2612[494] = (char *(*)()) F290_2870;
	R2612[495] = (char *(*)()) F292_2870;
	R2612[496] = (char *(*)()) F294_2870;
	R2612[497] = (char *(*)()) F293_2870;
	R2612[498] = (char *(*)()) F291_2870;
	R2612[499] = (char *(*)()) F296_2870;
	R2612[553] = (char *(*)()) F290_2870;
	R2612[554] = (char *(*)()) F291_2870;
	R2612[555] = (char *(*)()) F292_2870;
	R2612[556] = (char *(*)()) F293_2870;
	R2612[557] = (char *(*)()) F294_2870;
	R2612[558] = (char *(*)()) F295_2870;
	R2612[559] = (char *(*)()) F296_2870;
	R2612[560] = (char *(*)()) F297_2870;
	R2612[561] = (char *(*)()) F298_2870;
	R2612[562] = (char *(*)()) F299_2870;
	R2612[563] = (char *(*)()) F300_2870;
	R2612[564] = (char *(*)()) F301_2870;
	R2612[694] = (char *(*)()) F295_2870;
	{long i; for (i = 697; i < 699; i++) R2612[i] = (char *(*)()) F296_2870;}
	{long i; for (i = 1133; i < 1135; i++) R2612[i] = (char *(*)()) F296_2870;}
}

char *(*R2613[1135])();
void R2613_init () {
	R2613[0] = (char *(*)()) F290_2871;
	R2613[1] = (char *(*)()) F291_2871_2613_135;
	R2613[2] = (char *(*)()) F292_2871_2613_135;
	R2613[3] = (char *(*)()) F293_2871_2613_135;
	R2613[4] = (char *(*)()) F294_2871_2613_135;
	R2613[5] = (char *(*)()) F295_2871_2613_135;
	R2613[6] = (char *(*)()) F296_2871_2613_135;
	R2613[7] = (char *(*)()) F297_2871_2613_135;
	R2613[8] = (char *(*)()) F298_2871_2613_135;
	R2613[9] = (char *(*)()) F299_2871_2613_135;
	R2613[10] = (char *(*)()) F300_2871_2613_135;
	R2613[11] = (char *(*)()) F301_2871_2613_135;
	{long i; for (i = 35; i < 37; i++) R2613[i] = (char *(*)()) F297_2871_2613_135;}
	R2613[482] = (char *(*)()) F290_2871;
	R2613[483] = (char *(*)()) F291_2871_2613_135;
	R2613[484] = (char *(*)()) F292_2871_2613_135;
	R2613[485] = (char *(*)()) F293_2871_2613_135;
	R2613[486] = (char *(*)()) F294_2871_2613_135;
	R2613[487] = (char *(*)()) F295_2871_2613_135;
	R2613[488] = (char *(*)()) F296_2871_2613_135;
	R2613[489] = (char *(*)()) F297_2871_2613_135;
	R2613[490] = (char *(*)()) F298_2871_2613_135;
	R2613[491] = (char *(*)()) F299_2871_2613_135;
	R2613[492] = (char *(*)()) F300_2871_2613_135;
	R2613[493] = (char *(*)()) F301_2871_2613_135;
	R2613[494] = (char *(*)()) F290_2871;
	R2613[495] = (char *(*)()) F292_2871_2613_135;
	R2613[496] = (char *(*)()) F294_2871_2613_135;
	R2613[497] = (char *(*)()) F293_2871_2613_135;
	R2613[498] = (char *(*)()) F291_2871_2613_135;
	R2613[499] = (char *(*)()) F296_2871_2613_135;
	R2613[553] = (char *(*)()) F290_2871;
	R2613[554] = (char *(*)()) F291_2871_2613_135;
	R2613[555] = (char *(*)()) F292_2871_2613_135;
	R2613[556] = (char *(*)()) F293_2871_2613_135;
	R2613[557] = (char *(*)()) F294_2871_2613_135;
	R2613[558] = (char *(*)()) F295_2871_2613_135;
	R2613[559] = (char *(*)()) F296_2871_2613_135;
	R2613[560] = (char *(*)()) F297_2871_2613_135;
	R2613[561] = (char *(*)()) F298_2871_2613_135;
	R2613[562] = (char *(*)()) F299_2871_2613_135;
	R2613[563] = (char *(*)()) F300_2871_2613_135;
	R2613[564] = (char *(*)()) F301_2871_2613_135;
	R2613[694] = (char *(*)()) F295_2871_2613_135;
	{long i; for (i = 697; i < 699; i++) R2613[i] = (char *(*)()) F296_2871_2613_135;}
	{long i; for (i = 1133; i < 1135; i++) R2613[i] = (char *(*)()) F296_2871_2613_135;}
}
static void F291_2871_2613_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F291_2871(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F292_2871_2613_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F292_2871(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F293_2871_2613_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F293_2871(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F294_2871_2613_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F294_2871(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F295_2871_2613_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F295_2871(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F296_2871_2613_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F296_2871(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F297_2871_2613_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F297_2871(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F298_2871_2613_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F298_2871(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F299_2871_2613_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F299_2871(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F300_2871_2613_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F300_2871(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F301_2871_2613_135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F301_2871(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R2619[1135])();
void R2619_init () {
	R2619[0] = (char *(*)()) F290_2877;
	R2619[1] = (char *(*)()) F291_2877;
	R2619[2] = (char *(*)()) F292_2877;
	R2619[3] = (char *(*)()) F293_2877;
	R2619[4] = (char *(*)()) F294_2877;
	R2619[5] = (char *(*)()) F295_2877;
	R2619[6] = (char *(*)()) F296_2877;
	R2619[7] = (char *(*)()) F297_2877;
	R2619[8] = (char *(*)()) F298_2877;
	R2619[9] = (char *(*)()) F299_2877;
	R2619[10] = (char *(*)()) F300_2877;
	R2619[11] = (char *(*)()) F301_2877;
	{long i; for (i = 35; i < 37; i++) R2619[i] = (char *(*)()) F297_2877;}
	R2619[482] = (char *(*)()) F290_2877;
	R2619[483] = (char *(*)()) F291_2877;
	R2619[484] = (char *(*)()) F292_2877;
	R2619[485] = (char *(*)()) F293_2877;
	R2619[486] = (char *(*)()) F294_2877;
	R2619[487] = (char *(*)()) F295_2877;
	R2619[488] = (char *(*)()) F296_2877;
	R2619[489] = (char *(*)()) F297_2877;
	R2619[490] = (char *(*)()) F298_2877;
	R2619[491] = (char *(*)()) F299_2877;
	R2619[492] = (char *(*)()) F300_2877;
	R2619[493] = (char *(*)()) F301_2877;
	R2619[494] = (char *(*)()) F290_2877;
	R2619[495] = (char *(*)()) F292_2877;
	R2619[496] = (char *(*)()) F294_2877;
	R2619[497] = (char *(*)()) F293_2877;
	R2619[498] = (char *(*)()) F291_2877;
	R2619[499] = (char *(*)()) F296_2877;
	R2619[553] = (char *(*)()) F290_2877;
	R2619[554] = (char *(*)()) F291_2877;
	R2619[555] = (char *(*)()) F292_2877;
	R2619[556] = (char *(*)()) F293_2877;
	R2619[557] = (char *(*)()) F294_2877;
	R2619[558] = (char *(*)()) F295_2877;
	R2619[559] = (char *(*)()) F296_2877;
	R2619[560] = (char *(*)()) F297_2877;
	R2619[561] = (char *(*)()) F298_2877;
	R2619[562] = (char *(*)()) F299_2877;
	R2619[563] = (char *(*)()) F300_2877;
	R2619[564] = (char *(*)()) F301_2877;
	R2619[694] = (char *(*)()) F295_2877;
	{long i; for (i = 697; i < 699; i++) R2619[i] = (char *(*)()) F296_2877;}
	{long i; for (i = 1133; i < 1135; i++) R2619[i] = (char *(*)()) F296_2877;}
}

static EIF_TYPE_INDEX Y2620_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype12[] = {924,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype13[] = {924,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype44[] = {933,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype45[] = {936,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype46[] = {936,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype47[] = {936,0xFFFF};
static EIF_TYPE_INDEX Y2620_pgtype48[] = {936,0xFFFF};
EIF_TYPE_INDEX *Y2620_gen_type [1135];
EIF_TYPE_INDEX Y2620 [1135];
void Y2620_init (void)
{
	egc_routines_types [2620] = Y2620;
	egc_routines_gen_types [2620] = Y2620_gen_type;
	egc_routines_offset [2620] = 289;
	Y2620_gen_type [0] = Y2620_pgtype0;
	Y2620_gen_type [1] = Y2620_pgtype1;
	Y2620_gen_type [2] = Y2620_pgtype2;
	Y2620_gen_type [3] = Y2620_pgtype3;
	Y2620_gen_type [4] = Y2620_pgtype4;
	Y2620_gen_type [5] = Y2620_pgtype5;
	Y2620_gen_type [6] = Y2620_pgtype6;
	Y2620_gen_type [7] = Y2620_pgtype7;
	Y2620_gen_type [8] = Y2620_pgtype8;
	Y2620_gen_type [9] = Y2620_pgtype9;
	Y2620_gen_type [10] = Y2620_pgtype10;
	Y2620_gen_type [11] = Y2620_pgtype11;
	Y2620_gen_type [35] = Y2620_pgtype12;
	Y2620_gen_type [36] = Y2620_pgtype13;
	Y2620_gen_type [482] = Y2620_pgtype14;
	Y2620_gen_type [483] = Y2620_pgtype15;
	Y2620_gen_type [484] = Y2620_pgtype16;
	Y2620_gen_type [485] = Y2620_pgtype17;
	Y2620_gen_type [486] = Y2620_pgtype18;
	Y2620_gen_type [487] = Y2620_pgtype19;
	Y2620_gen_type [488] = Y2620_pgtype20;
	Y2620_gen_type [489] = Y2620_pgtype21;
	Y2620_gen_type [490] = Y2620_pgtype22;
	Y2620_gen_type [491] = Y2620_pgtype23;
	Y2620_gen_type [492] = Y2620_pgtype24;
	Y2620_gen_type [493] = Y2620_pgtype25;
	Y2620_gen_type [494] = Y2620_pgtype26;
	Y2620_gen_type [495] = Y2620_pgtype27;
	Y2620_gen_type [496] = Y2620_pgtype28;
	Y2620_gen_type [497] = Y2620_pgtype29;
	Y2620_gen_type [498] = Y2620_pgtype30;
	Y2620_gen_type [499] = Y2620_pgtype31;
	Y2620_gen_type [553] = Y2620_pgtype32;
	Y2620_gen_type [554] = Y2620_pgtype33;
	Y2620_gen_type [555] = Y2620_pgtype34;
	Y2620_gen_type [556] = Y2620_pgtype35;
	Y2620_gen_type [557] = Y2620_pgtype36;
	Y2620_gen_type [558] = Y2620_pgtype37;
	Y2620_gen_type [559] = Y2620_pgtype38;
	Y2620_gen_type [560] = Y2620_pgtype39;
	Y2620_gen_type [561] = Y2620_pgtype40;
	Y2620_gen_type [562] = Y2620_pgtype41;
	Y2620_gen_type [563] = Y2620_pgtype42;
	Y2620_gen_type [564] = Y2620_pgtype43;
	Y2620_gen_type [694] = Y2620_pgtype44;
	Y2620_gen_type [697] = Y2620_pgtype45;
	Y2620_gen_type [698] = Y2620_pgtype46;
	Y2620_gen_type [1133] = Y2620_pgtype47;
	Y2620_gen_type [1134] = Y2620_pgtype48;
	{long i; for (i = 35; i < 37; i++) Y2620[i] = 924;};
	Y2620[694] = 933;
	{long i; for (i = 697; i < 699; i++) Y2620[i] = 936;};
	{long i; for (i = 1133; i < 1135; i++) Y2620[i] = 936;};
}

char *(*R2621[722])();
void R2621_init () {
	R2621[0] = (char *(*)()) F302_2878;
	R2621[1] = (char *(*)()) F303_2878_2621_3;
	R2621[2] = (char *(*)()) F304_2878_2621_3;
	R2621[3] = (char *(*)()) F305_2878_2621_3;
	R2621[4] = (char *(*)()) F306_2878_2621_3;
	R2621[5] = (char *(*)()) F307_2878_2621_3;
	R2621[6] = (char *(*)()) F308_2879;
	R2621[7] = (char *(*)()) F309_2880;
	R2621[8] = (char *(*)()) F310_2881;
	R2621[706] = (char *(*)()) F1008_6955;
	R2621[709] = (char *(*)()) F1011_6982;
	R2621[721] = (char *(*)()) F1023_7149;
}
static EIF_BOOLEAN F303_2878_2621_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F303_2878(Current, *(EIF_BOOLEAN *)arg1, *(EIF_BOOLEAN *)arg2);
}
static EIF_BOOLEAN F304_2878_2621_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F304_2878(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_NATURAL_64 *)arg2);
}
static EIF_BOOLEAN F305_2878_2621_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F305_2878(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static EIF_BOOLEAN F306_2878_2621_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F306_2878(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F307_2878_2621_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F307_2878(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_CHARACTER_8 *)arg2);
}


#ifdef __cplusplus
}
#endif
