#include "epoly7.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R3498[692])();
void R3498_init () {
	{long i; for (i = 0; i < 2; i++) R3498[i] = (char *(*)()) F673_4113;}
	R3498[38] = (char *(*)()) F671_4113;
	R3498[39] = (char *(*)()) F670_4113;
	R3498[40] = (char *(*)()) F671_4113;
	R3498[41] = (char *(*)()) F672_4113;
	R3498[42] = (char *(*)()) F675_4113;
	R3498[43] = (char *(*)()) F676_4113;
	R3498[44] = (char *(*)()) F674_4113;
	R3498[45] = (char *(*)()) F673_4113;
	R3498[46] = (char *(*)()) F677_4113;
	R3498[47] = (char *(*)()) F678_4113;
	R3498[48] = (char *(*)()) F679_4113;
	R3498[49] = (char *(*)()) F680_4113;
	R3498[50] = (char *(*)()) F681_4113;
	R3498[51] = (char *(*)()) F670_4113;
	R3498[52] = (char *(*)()) F672_4113;
	R3498[53] = (char *(*)()) F676_4113;
	R3498[54] = (char *(*)()) F675_4113;
	R3498[55] = (char *(*)()) F671_4113;
	R3498[56] = (char *(*)()) F673_4113;
	R3498[105] = (char *(*)()) F670_4113;
	R3498[106] = (char *(*)()) F671_4113;
	R3498[110] = (char *(*)()) F670_4113;
	R3498[111] = (char *(*)()) F671_4113;
	R3498[112] = (char *(*)()) F672_4113;
	R3498[113] = (char *(*)()) F675_4113;
	R3498[114] = (char *(*)()) F676_4113;
	R3498[115] = (char *(*)()) F674_4113;
	R3498[116] = (char *(*)()) F673_4113;
	R3498[117] = (char *(*)()) F677_4113;
	R3498[118] = (char *(*)()) F678_4113;
	R3498[119] = (char *(*)()) F679_4113;
	R3498[120] = (char *(*)()) F680_4113;
	R3498[121] = (char *(*)()) F681_4113;
	R3498[122] = (char *(*)()) F670_4113;
	R3498[123] = (char *(*)()) F671_4113;
	R3498[124] = (char *(*)()) F670_4113;
	R3498[125] = (char *(*)()) F671_4113;
	R3498[126] = (char *(*)()) F679_4113;
	R3498[127] = (char *(*)()) F670_4113;
	R3498[128] = (char *(*)()) F671_4113;
	R3498[129] = (char *(*)()) F670_4113;
	R3498[251] = (char *(*)()) F674_4113;
	{long i; for (i = 254; i < 256; i++) R3498[i] = (char *(*)()) F673_4113;}
	{long i; for (i = 564; i < 568; i++) R3498[i] = (char *(*)()) F673_4113;}
	{long i; for (i = 569; i < 573; i++) R3498[i] = (char *(*)()) F673_4113;}
	{long i; for (i = 690; i < 692; i++) R3498[i] = (char *(*)()) F673_4113;}
}

char *(*R3502[756])();
void R3502_init () {
	R3502[0] = (char *(*)()) F528_4015;
	{long i; for (i = 64; i < 66; i++) R3502[i] = (char *(*)()) F530_4015;}
	R3502[102] = (char *(*)()) F528_4015;
	R3502[103] = (char *(*)()) F527_4015;
	R3502[104] = (char *(*)()) F528_4015;
	R3502[105] = (char *(*)()) F529_4015;
	R3502[106] = (char *(*)()) F532_4015;
	R3502[107] = (char *(*)()) F533_4015;
	R3502[108] = (char *(*)()) F531_4015;
	R3502[109] = (char *(*)()) F530_4015;
	R3502[110] = (char *(*)()) F534_4015;
	R3502[111] = (char *(*)()) F535_4015;
	R3502[112] = (char *(*)()) F536_4015;
	R3502[113] = (char *(*)()) F537_4015;
	R3502[114] = (char *(*)()) F538_4015;
	R3502[115] = (char *(*)()) F527_4015;
	R3502[116] = (char *(*)()) F529_4015;
	R3502[117] = (char *(*)()) F533_4015;
	R3502[118] = (char *(*)()) F532_4015;
	R3502[119] = (char *(*)()) F528_4015;
	R3502[120] = (char *(*)()) F530_4015;
	R3502[169] = (char *(*)()) F527_4015;
	R3502[170] = (char *(*)()) F528_4015;
	{long i; for (i = 173; i < 175; i++) R3502[i] = (char *(*)()) F527_4015;}
	R3502[175] = (char *(*)()) F528_4015;
	R3502[176] = (char *(*)()) F529_4015;
	R3502[177] = (char *(*)()) F532_4015;
	R3502[178] = (char *(*)()) F533_4015;
	R3502[179] = (char *(*)()) F531_4015;
	R3502[180] = (char *(*)()) F530_4015;
	R3502[181] = (char *(*)()) F534_4015;
	R3502[182] = (char *(*)()) F535_4015;
	R3502[183] = (char *(*)()) F536_4015;
	R3502[184] = (char *(*)()) F537_4015;
	R3502[185] = (char *(*)()) F538_4015;
	R3502[186] = (char *(*)()) F527_4015;
	R3502[187] = (char *(*)()) F528_4015;
	R3502[188] = (char *(*)()) F527_4015;
	R3502[189] = (char *(*)()) F528_4015;
	R3502[190] = (char *(*)()) F536_4015;
	R3502[191] = (char *(*)()) F527_4015;
	R3502[192] = (char *(*)()) F528_4015;
	R3502[193] = (char *(*)()) F527_4015;
	R3502[315] = (char *(*)()) F531_4015;
	{long i; for (i = 318; i < 320; i++) R3502[i] = (char *(*)()) F530_4015;}
	R3502[410] = (char *(*)()) F530_4015;
	{long i; for (i = 628; i < 632; i++) R3502[i] = (char *(*)()) F530_4015;}
	{long i; for (i = 633; i < 637; i++) R3502[i] = (char *(*)()) F530_4015;}
	{long i; for (i = 754; i < 756; i++) R3502[i] = (char *(*)()) F530_4015;}
}

char *(*R3507[2])();
void R3507_init () {
	R3507[0] = (char *(*)()) F838_4701;
	R3507[1] = (char *(*)()) F839_4701;
}

char *(*R3508[186])();
void R3508_init () {
	R3508[0] = (char *(*)()) F668_4092;
	R3508[169] = (char *(*)()) F838_4707;
	R3508[170] = (char *(*)()) F839_4707;
	R3508[174] = (char *(*)()) F843_4800;
	R3508[175] = (char *(*)()) F844_4800;
	R3508[176] = (char *(*)()) F845_4800;
	R3508[177] = (char *(*)()) F846_4800;
	R3508[178] = (char *(*)()) F847_4800;
	R3508[179] = (char *(*)()) F848_4800;
	R3508[180] = (char *(*)()) F849_4800;
	R3508[181] = (char *(*)()) F850_4800;
	R3508[182] = (char *(*)()) F851_4800;
	R3508[183] = (char *(*)()) F852_4800;
	R3508[184] = (char *(*)()) F853_4800;
	R3508[185] = (char *(*)()) F854_4800;
}

char *(*R3515[186])();
void R3515_init () {
	R3515[0] = (char *(*)()) F668_4083;
	R3515[169] = (char *(*)()) F838_4693;
	R3515[170] = (char *(*)()) F839_4693;
	R3515[174] = (char *(*)()) F843_4779;
	R3515[175] = (char *(*)()) F844_4779;
	R3515[176] = (char *(*)()) F845_4779;
	R3515[177] = (char *(*)()) F846_4779;
	R3515[178] = (char *(*)()) F847_4779;
	R3515[179] = (char *(*)()) F848_4779;
	R3515[180] = (char *(*)()) F849_4779;
	R3515[181] = (char *(*)()) F850_4779;
	R3515[182] = (char *(*)()) F851_4779;
	R3515[183] = (char *(*)()) F852_4779;
	R3515[184] = (char *(*)()) F853_4779;
	R3515[185] = (char *(*)()) F854_4779;
}

char *(*R3519[186])();
void R3519_init () {
	R3519[0] = (char *(*)()) F668_4085;
	R3519[169] = (char *(*)()) F838_4699;
	R3519[170] = (char *(*)()) F839_4699;
	R3519[174] = (char *(*)()) F814_4677;
	R3519[175] = (char *(*)()) F815_4677;
	R3519[176] = (char *(*)()) F816_4677;
	R3519[177] = (char *(*)()) F817_4677;
	R3519[178] = (char *(*)()) F818_4677;
	R3519[179] = (char *(*)()) F819_4677;
	R3519[180] = (char *(*)()) F820_4677;
	R3519[181] = (char *(*)()) F821_4677;
	R3519[182] = (char *(*)()) F822_4677;
	R3519[183] = (char *(*)()) F823_4677;
	R3519[184] = (char *(*)()) F824_4677;
	R3519[185] = (char *(*)()) F825_4677;
}

char *(*R3520[2])();
void R3520_init () {
	R3520[0] = (char *(*)()) F838_4708;
	R3520[1] = (char *(*)()) F839_4708;
}

char *(*R3521[186])();
void R3521_init () {
	R3521[0] = (char *(*)()) F668_4091;
	R3521[169] = (char *(*)()) F838_4709;
	R3521[170] = (char *(*)()) F839_4709;
	R3521[174] = (char *(*)()) F843_4802;
	R3521[175] = (char *(*)()) F844_4802;
	R3521[176] = (char *(*)()) F845_4802;
	R3521[177] = (char *(*)()) F846_4802;
	R3521[178] = (char *(*)()) F847_4802;
	R3521[179] = (char *(*)()) F848_4802;
	R3521[180] = (char *(*)()) F849_4802;
	R3521[181] = (char *(*)()) F850_4802;
	R3521[182] = (char *(*)()) F851_4802;
	R3521[183] = (char *(*)()) F852_4802;
	R3521[184] = (char *(*)()) F853_4802;
	R3521[185] = (char *(*)()) F854_4802;
}

char *(*R3528[692])();
void R3528_init () {
	{long i; for (i = 0; i < 2; i++) R3528[i] = (char *(*)()) F732_4236_3528_4;}
	R3528[105] = (char *(*)()) F838_4715;
	R3528[106] = (char *(*)()) F839_4715_3528_4;
	R3528[110] = (char *(*)()) F843_4810;
	R3528[111] = (char *(*)()) F844_4810_3528_4;
	R3528[112] = (char *(*)()) F845_4810_3528_4;
	R3528[113] = (char *(*)()) F846_4810_3528_4;
	R3528[114] = (char *(*)()) F847_4810_3528_4;
	R3528[115] = (char *(*)()) F848_4810_3528_4;
	R3528[116] = (char *(*)()) F849_4810_3528_4;
	R3528[117] = (char *(*)()) F850_4810_3528_4;
	R3528[118] = (char *(*)()) F851_4810_3528_4;
	R3528[119] = (char *(*)()) F852_4810_3528_4;
	R3528[120] = (char *(*)()) F853_4810_3528_4;
	R3528[121] = (char *(*)()) F854_4810_3528_4;
	R3528[251] = (char *(*)()) F984_6574_3528_4;
	{long i; for (i = 254; i < 256; i++) R3528[i] = (char *(*)()) F987_6739_3528_4;}
	R3528[346] = (char *(*)()) F732_4236_3528_4;
	{long i; for (i = 564; i < 568; i++) R3528[i] = (char *(*)()) F732_4236_3528_4;}
	{long i; for (i = 569; i < 573; i++) R3528[i] = (char *(*)()) F732_4236_3528_4;}
	{long i; for (i = 690; i < 692; i++) R3528[i] = (char *(*)()) F987_6739_3528_4;}
}
static void F732_4236_3528_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F732_4236(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F839_4715_3528_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F839_4715(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F844_4810_3528_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F844_4810(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F845_4810_3528_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F845_4810(Current, *(EIF_BOOLEAN *)arg1);
}
static void F846_4810_3528_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F846_4810(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F847_4810_3528_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F847_4810(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F848_4810_3528_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F848_4810(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F849_4810_3528_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F849_4810(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F850_4810_3528_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F850_4810(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F851_4810_3528_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F851_4810(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F852_4810_3528_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F852_4810(Current, *(EIF_POINTER *)arg1);
}
static void F853_4810_3528_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F853_4810(Current, *(EIF_REAL_32 *)arg1);
}
static void F854_4810_3528_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F854_4810(Current, *(EIF_REAL_64 *)arg1);
}
static void F984_6574_3528_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F984_6574(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F987_6739_3528_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F987_6739(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R3535[654])();
void R3535_init () {
	R3535[0] = (char *(*)()) F771_4545_3535_5;
	R3535[1] = (char *(*)()) F772_4584_3535_5;
	R3535[2] = (char *(*)()) F773_4584_3535_5;
	R3535[3] = (char *(*)()) F774_4584_3535_5;
	R3535[4] = (char *(*)()) F775_4584_3535_5;
	R3535[5] = (char *(*)()) F776_4584_3535_5;
	R3535[6] = (char *(*)()) F777_4584_3535_5;
	R3535[7] = (char *(*)()) F778_4584_3535_5;
	R3535[8] = (char *(*)()) F779_4584_3535_5;
	R3535[9] = (char *(*)()) F780_4584_3535_5;
	R3535[10] = (char *(*)()) F781_4584_3535_5;
	R3535[11] = (char *(*)()) F782_4584_3535_5;
	R3535[12] = (char *(*)()) F783_4584_3535_5;
	R3535[13] = (char *(*)()) F772_4584_3535_5;
	R3535[14] = (char *(*)()) F774_4584_3535_5;
	R3535[15] = (char *(*)()) F776_4584_3535_5;
	R3535[16] = (char *(*)()) F775_4584_3535_5;
	R3535[17] = (char *(*)()) F773_4584_3535_5;
	R3535[18] = (char *(*)()) F778_4584_3535_5;
	R3535[67] = (char *(*)()) F790_4642_3535_5;
	R3535[68] = (char *(*)()) F791_4642_3535_5;
	R3535[72] = (char *(*)()) F843_4775_3535_5;
	R3535[73] = (char *(*)()) F844_4775_3535_5;
	R3535[74] = (char *(*)()) F845_4775_3535_5;
	R3535[75] = (char *(*)()) F846_4775_3535_5;
	R3535[76] = (char *(*)()) F847_4775_3535_5;
	R3535[77] = (char *(*)()) F848_4775_3535_5;
	R3535[78] = (char *(*)()) F849_4775_3535_5;
	R3535[79] = (char *(*)()) F850_4775_3535_5;
	R3535[80] = (char *(*)()) F851_4775_3535_5;
	R3535[81] = (char *(*)()) F852_4775_3535_5;
	R3535[82] = (char *(*)()) F853_4775_3535_5;
	R3535[83] = (char *(*)()) F854_4775_3535_5;
	R3535[213] = (char *(*)()) F984_6527_3535_5;
	{long i; for (i = 216; i < 218; i++) R3535[i] = (char *(*)()) F987_6691_3535_5;}
	{long i; for (i = 652; i < 654; i++) R3535[i] = (char *(*)()) F1423_11787_3535_5;}
}
static EIF_REFERENCE F771_4545_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F771_4545(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F772_4584_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F772_4584(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F773_4584_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F773_4584(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F774_4584_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F774_4584(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F775_4584_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F775_4584(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(915, 0x00).id, 915, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F776_4584_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F776_4584(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(918, 0x00).id, 918, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F777_4584_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F777_4584(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(933, 0x00).id, 933, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F778_4584_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F778_4584(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F779_4584_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F779_4584(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(924, 0x00).id, 924, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F780_4584_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F780_4584(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(921, 0x00).id, 921, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F781_4584_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F781_4584(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F782_4584_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F782_4584(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F783_4584_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F783_4584(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(930, 0x00).id, 930, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F790_4642_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F790_4642(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F791_4642_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F791_4642(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F843_4775_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F843_4775(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F844_4775_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F844_4775(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F845_4775_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F845_4775(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F846_4775_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F846_4775(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(915, 0x00).id, 915, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F847_4775_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F847_4775(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(918, 0x00).id, 918, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F848_4775_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F848_4775(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(933, 0x00).id, 933, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F849_4775_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F849_4775(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F850_4775_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F850_4775(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(924, 0x00).id, 924, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F851_4775_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F851_4775(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(921, 0x00).id, 921, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F852_4775_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F852_4775(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F853_4775_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F853_4775(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F854_4775_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F854_4775(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(930, 0x00).id, 930, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F984_6527_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F984_6527(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(933, 0x00).id, 933, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F987_6691_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F987_6691(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1423_11787_3535_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1423_11787(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R3538[653])();
void R3538_init () {
	R3538[0] = (char *(*)()) F772_4603_3538_10;
	R3538[1] = (char *(*)()) F773_4603_3538_10;
	R3538[2] = (char *(*)()) F774_4603_3538_10;
	R3538[3] = (char *(*)()) F775_4603_3538_10;
	R3538[4] = (char *(*)()) F776_4603_3538_10;
	R3538[5] = (char *(*)()) F777_4603_3538_10;
	R3538[6] = (char *(*)()) F778_4603_3538_10;
	R3538[7] = (char *(*)()) F779_4603_3538_10;
	R3538[8] = (char *(*)()) F780_4603_3538_10;
	R3538[9] = (char *(*)()) F781_4603_3538_10;
	R3538[10] = (char *(*)()) F782_4603_3538_10;
	R3538[11] = (char *(*)()) F783_4603_3538_10;
	R3538[12] = (char *(*)()) F772_4603_3538_10;
	R3538[13] = (char *(*)()) F774_4603_3538_10;
	R3538[14] = (char *(*)()) F776_4603_3538_10;
	R3538[15] = (char *(*)()) F775_4603_3538_10;
	R3538[16] = (char *(*)()) F773_4603_3538_10;
	R3538[17] = (char *(*)()) F778_4603_3538_10;
	R3538[83] = (char *(*)()) F855_4881;
	R3538[84] = (char *(*)()) F856_4881_3538_10;
	R3538[85] = (char *(*)()) F857_4881_3538_10;
	R3538[86] = (char *(*)()) F858_4881_3538_10;
	R3538[87] = (char *(*)()) F859_4881_3538_10;
	R3538[88] = (char *(*)()) F855_4881;
	R3538[89] = (char *(*)()) F856_4881_3538_10;
	R3538[90] = (char *(*)()) F855_4881;
	R3538[212] = (char *(*)()) F984_6547_3538_10;
	{long i; for (i = 215; i < 217; i++) R3538[i] = (char *(*)()) F987_6712_3538_10;}
	{long i; for (i = 651; i < 653; i++) R3538[i] = (char *(*)()) F1423_11822_3538_10;}
}
static void F772_4603_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F772_4603(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F773_4603_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F773_4603(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F774_4603_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F774_4603(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F775_4603_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F775_4603(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F776_4603_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F776_4603(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F777_4603_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F777_4603(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F778_4603_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F778_4603(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F779_4603_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F779_4603(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F780_4603_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F780_4603(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F781_4603_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F781_4603(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F782_4603_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F782_4603(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F783_4603_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F783_4603(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F856_4881_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F856_4881(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F857_4881_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F857_4881(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F858_4881_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F858_4881(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F859_4881_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F859_4881(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F984_6547_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F984_6547(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F987_6712_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F987_6712(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1423_11822_3538_10 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1423_11822(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y3540_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype30[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype31[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype32[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype33[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype34[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype35[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype36[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype37[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype38[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype39[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype40[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype41[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype42[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype43[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype44[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype45[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype46[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype47[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype48[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype49[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype50[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype51[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype52[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype53[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype54[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype55[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype56[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype57[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype58[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype59[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype60[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype61[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype62[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype63[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype64[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype65[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype66[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype67[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype68[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype69[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype70[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype71[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype72[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype73[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype74[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype75[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype76[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype77[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype78[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype79[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype80[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype81[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype82[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype83[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype84[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype85[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype86[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype87[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype88[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype89[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype90[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype91[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype92[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype93[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype94[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype95[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype96[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype97[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype98[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype99[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype100[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype101[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype102[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype103[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype104[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype105[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype106[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype107[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype108[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype109[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype110[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype111[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype112[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype113[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype114[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype115[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype116[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype117[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype118[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype119[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype120[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype121[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype122[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype123[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype124[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype125[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype126[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype127[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype128[] = {0xFF01,978,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype129[] = {0xFF01,978,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype130[] = {0xFF01,986,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype131[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype132[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype133[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype134[] = {906,0xFFFF};
static EIF_TYPE_INDEX Y3540_pgtype135[] = {906,0xFFFF};
EIF_TYPE_INDEX *Y3540_gen_type [825];
EIF_TYPE_INDEX Y3540 [825];
void Y3540_init (void)
{
	egc_routines_types [3540] = Y3540;
	egc_routines_gen_types [3540] = Y3540_gen_type;
	egc_routines_offset [3540] = 599;
	Y3540_gen_type [0] = Y3540_pgtype0;
	Y3540_gen_type [1] = Y3540_pgtype1;
	Y3540_gen_type [2] = Y3540_pgtype2;
	Y3540_gen_type [3] = Y3540_pgtype3;
	Y3540_gen_type [4] = Y3540_pgtype4;
	Y3540_gen_type [5] = Y3540_pgtype5;
	Y3540_gen_type [6] = Y3540_pgtype6;
	Y3540_gen_type [7] = Y3540_pgtype7;
	Y3540_gen_type [8] = Y3540_pgtype8;
	Y3540_gen_type [9] = Y3540_pgtype9;
	Y3540_gen_type [10] = Y3540_pgtype10;
	Y3540_gen_type [11] = Y3540_pgtype11;
	Y3540_gen_type [12] = Y3540_pgtype12;
	Y3540_gen_type [13] = Y3540_pgtype13;
	Y3540_gen_type [14] = Y3540_pgtype14;
	Y3540_gen_type [15] = Y3540_pgtype15;
	Y3540_gen_type [16] = Y3540_pgtype16;
	Y3540_gen_type [17] = Y3540_pgtype17;
	Y3540_gen_type [18] = Y3540_pgtype18;
	Y3540_gen_type [19] = Y3540_pgtype19;
	Y3540_gen_type [20] = Y3540_pgtype20;
	Y3540_gen_type [21] = Y3540_pgtype21;
	Y3540_gen_type [22] = Y3540_pgtype22;
	Y3540_gen_type [23] = Y3540_pgtype23;
	Y3540_gen_type [24] = Y3540_pgtype24;
	Y3540_gen_type [25] = Y3540_pgtype25;
	Y3540_gen_type [26] = Y3540_pgtype26;
	Y3540_gen_type [27] = Y3540_pgtype27;
	Y3540_gen_type [28] = Y3540_pgtype28;
	Y3540_gen_type [29] = Y3540_pgtype29;
	Y3540_gen_type [159] = Y3540_pgtype30;
	Y3540_gen_type [160] = Y3540_pgtype31;
	Y3540_gen_type [161] = Y3540_pgtype32;
	Y3540_gen_type [162] = Y3540_pgtype33;
	Y3540_gen_type [163] = Y3540_pgtype34;
	Y3540_gen_type [164] = Y3540_pgtype35;
	Y3540_gen_type [165] = Y3540_pgtype36;
	Y3540_gen_type [166] = Y3540_pgtype37;
	Y3540_gen_type [167] = Y3540_pgtype38;
	Y3540_gen_type [168] = Y3540_pgtype39;
	Y3540_gen_type [169] = Y3540_pgtype40;
	Y3540_gen_type [170] = Y3540_pgtype41;
	Y3540_gen_type [171] = Y3540_pgtype42;
	Y3540_gen_type [172] = Y3540_pgtype43;
	Y3540_gen_type [173] = Y3540_pgtype44;
	Y3540_gen_type [174] = Y3540_pgtype45;
	Y3540_gen_type [175] = Y3540_pgtype46;
	Y3540_gen_type [176] = Y3540_pgtype47;
	Y3540_gen_type [177] = Y3540_pgtype48;
	Y3540_gen_type [178] = Y3540_pgtype49;
	Y3540_gen_type [179] = Y3540_pgtype50;
	Y3540_gen_type [180] = Y3540_pgtype51;
	Y3540_gen_type [181] = Y3540_pgtype52;
	Y3540_gen_type [182] = Y3540_pgtype53;
	Y3540_gen_type [183] = Y3540_pgtype54;
	Y3540_gen_type [184] = Y3540_pgtype55;
	Y3540_gen_type [185] = Y3540_pgtype56;
	Y3540_gen_type [186] = Y3540_pgtype57;
	Y3540_gen_type [187] = Y3540_pgtype58;
	Y3540_gen_type [188] = Y3540_pgtype59;
	Y3540_gen_type [189] = Y3540_pgtype60;
	Y3540_gen_type [190] = Y3540_pgtype61;
	Y3540_gen_type [191] = Y3540_pgtype62;
	Y3540_gen_type [192] = Y3540_pgtype63;
	Y3540_gen_type [193] = Y3540_pgtype64;
	Y3540_gen_type [194] = Y3540_pgtype65;
	Y3540_gen_type [195] = Y3540_pgtype66;
	Y3540_gen_type [196] = Y3540_pgtype67;
	Y3540_gen_type [197] = Y3540_pgtype68;
	Y3540_gen_type [198] = Y3540_pgtype69;
	Y3540_gen_type [199] = Y3540_pgtype70;
	Y3540_gen_type [200] = Y3540_pgtype71;
	Y3540_gen_type [201] = Y3540_pgtype72;
	Y3540_gen_type [202] = Y3540_pgtype73;
	Y3540_gen_type [203] = Y3540_pgtype74;
	Y3540_gen_type [204] = Y3540_pgtype75;
	Y3540_gen_type [205] = Y3540_pgtype76;
	Y3540_gen_type [206] = Y3540_pgtype77;
	Y3540_gen_type [207] = Y3540_pgtype78;
	Y3540_gen_type [208] = Y3540_pgtype79;
	Y3540_gen_type [209] = Y3540_pgtype80;
	Y3540_gen_type [210] = Y3540_pgtype81;
	Y3540_gen_type [211] = Y3540_pgtype82;
	Y3540_gen_type [212] = Y3540_pgtype83;
	Y3540_gen_type [213] = Y3540_pgtype84;
	Y3540_gen_type [214] = Y3540_pgtype85;
	Y3540_gen_type [215] = Y3540_pgtype86;
	Y3540_gen_type [216] = Y3540_pgtype87;
	Y3540_gen_type [217] = Y3540_pgtype88;
	Y3540_gen_type [218] = Y3540_pgtype89;
	Y3540_gen_type [219] = Y3540_pgtype90;
	Y3540_gen_type [220] = Y3540_pgtype91;
	Y3540_gen_type [221] = Y3540_pgtype92;
	Y3540_gen_type [222] = Y3540_pgtype93;
	Y3540_gen_type [223] = Y3540_pgtype94;
	Y3540_gen_type [224] = Y3540_pgtype95;
	Y3540_gen_type [225] = Y3540_pgtype96;
	Y3540_gen_type [226] = Y3540_pgtype97;
	Y3540_gen_type [227] = Y3540_pgtype98;
	Y3540_gen_type [228] = Y3540_pgtype99;
	Y3540_gen_type [229] = Y3540_pgtype100;
	Y3540_gen_type [230] = Y3540_pgtype101;
	Y3540_gen_type [231] = Y3540_pgtype102;
	Y3540_gen_type [232] = Y3540_pgtype103;
	Y3540_gen_type [233] = Y3540_pgtype104;
	Y3540_gen_type [234] = Y3540_pgtype105;
	Y3540_gen_type [235] = Y3540_pgtype106;
	Y3540_gen_type [236] = Y3540_pgtype107;
	Y3540_gen_type [237] = Y3540_pgtype108;
	Y3540_gen_type [238] = Y3540_pgtype109;
	Y3540_gen_type [239] = Y3540_pgtype110;
	Y3540_gen_type [243] = Y3540_pgtype111;
	Y3540_gen_type [244] = Y3540_pgtype112;
	Y3540_gen_type [245] = Y3540_pgtype113;
	Y3540_gen_type [246] = Y3540_pgtype114;
	Y3540_gen_type [247] = Y3540_pgtype115;
	Y3540_gen_type [248] = Y3540_pgtype116;
	Y3540_gen_type [249] = Y3540_pgtype117;
	Y3540_gen_type [250] = Y3540_pgtype118;
	Y3540_gen_type [251] = Y3540_pgtype119;
	Y3540_gen_type [252] = Y3540_pgtype120;
	Y3540_gen_type [253] = Y3540_pgtype121;
	Y3540_gen_type [254] = Y3540_pgtype122;
	Y3540_gen_type [255] = Y3540_pgtype123;
	Y3540_gen_type [256] = Y3540_pgtype124;
	Y3540_gen_type [257] = Y3540_pgtype125;
	Y3540_gen_type [258] = Y3540_pgtype126;
	Y3540_gen_type [259] = Y3540_pgtype127;
	Y3540_gen_type [260] = Y3540_pgtype128;
	Y3540_gen_type [261] = Y3540_pgtype129;
	Y3540_gen_type [262] = Y3540_pgtype130;
	Y3540_gen_type [384] = Y3540_pgtype131;
	Y3540_gen_type [387] = Y3540_pgtype132;
	Y3540_gen_type [388] = Y3540_pgtype133;
	Y3540_gen_type [823] = Y3540_pgtype134;
	Y3540_gen_type [824] = Y3540_pgtype135;
	{long i; for (i = 159; i < 240; i++) Y3540[i] = 906;};
	{long i; for (i = 243; i < 255; i++) Y3540[i] = 906;};
	{long i; for (i = 260; i < 262; i++) Y3540[i] = 978;};
	Y3540[262] = 986;
	Y3540[384] = 906;
	{long i; for (i = 387; i < 389; i++) Y3540[i] = 906;};
	{long i; for (i = 823; i < 825; i++) Y3540[i] = 906;};
}

char *(*R3542[186])();
void R3542_init () {
	R3542[0] = (char *(*)()) F668_4084_3542_1;
	R3542[169] = (char *(*)()) F838_4690;
	R3542[170] = (char *(*)()) F839_4690_3542_1;
	R3542[174] = (char *(*)()) F843_4774;
	R3542[175] = (char *(*)()) F844_4774_3542_1;
	R3542[176] = (char *(*)()) F845_4774_3542_1;
	R3542[177] = (char *(*)()) F846_4774_3542_1;
	R3542[178] = (char *(*)()) F847_4774_3542_1;
	R3542[179] = (char *(*)()) F848_4774_3542_1;
	R3542[180] = (char *(*)()) F849_4774_3542_1;
	R3542[181] = (char *(*)()) F850_4774_3542_1;
	R3542[182] = (char *(*)()) F851_4774_3542_1;
	R3542[183] = (char *(*)()) F852_4774_3542_1;
	R3542[184] = (char *(*)()) F853_4774_3542_1;
	R3542[185] = (char *(*)()) F854_4774_3542_1;
}
static EIF_REFERENCE F668_4084_3542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F668_4084(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F839_4690_3542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F839_4690(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F844_4774_3542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F844_4774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(906, 0x00).id, 906, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F845_4774_3542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F845_4774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(939, 0x00).id, 939, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F846_4774_3542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F846_4774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(915, 0x00).id, 915, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F847_4774_3542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F847_4774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(918, 0x00).id, 918, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F848_4774_3542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F848_4774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(933, 0x00).id, 933, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F849_4774_3542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F849_4774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(936, 0x00).id, 936, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F850_4774_3542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F850_4774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(924, 0x00).id, 924, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F851_4774_3542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F851_4774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(921, 0x00).id, 921, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F852_4774_3542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F852_4774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(972, 0x00).id, 972, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F853_4774_3542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F853_4774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(927, 0x00).id, 927, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F854_4774_3542_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F854_4774(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(930, 0x00).id, 930, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y3542_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3542_pgtype101[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y3542_gen_type [676];
EIF_TYPE_INDEX Y3542 [676];
void Y3542_init (void)
{
	egc_routines_types [3542] = Y3542;
	egc_routines_gen_types [3542] = Y3542_gen_type;
	egc_routines_offset [3542] = 629;
	Y3542_gen_type [0] = Y3542_pgtype0;
	Y3542_gen_type [1] = Y3542_pgtype1;
	Y3542_gen_type [2] = Y3542_pgtype2;
	Y3542_gen_type [3] = Y3542_pgtype3;
	Y3542_gen_type [4] = Y3542_pgtype4;
	Y3542_gen_type [5] = Y3542_pgtype5;
	Y3542_gen_type [6] = Y3542_pgtype6;
	Y3542_gen_type [7] = Y3542_pgtype7;
	Y3542_gen_type [8] = Y3542_pgtype8;
	Y3542_gen_type [9] = Y3542_pgtype9;
	Y3542_gen_type [10] = Y3542_pgtype10;
	Y3542_gen_type [11] = Y3542_pgtype11;
	Y3542_gen_type [12] = Y3542_pgtype12;
	Y3542_gen_type [13] = Y3542_pgtype13;
	Y3542_gen_type [14] = Y3542_pgtype14;
	Y3542_gen_type [15] = Y3542_pgtype15;
	Y3542_gen_type [16] = Y3542_pgtype16;
	Y3542_gen_type [17] = Y3542_pgtype17;
	Y3542_gen_type [18] = Y3542_pgtype18;
	Y3542_gen_type [19] = Y3542_pgtype19;
	Y3542_gen_type [20] = Y3542_pgtype20;
	Y3542_gen_type [21] = Y3542_pgtype21;
	Y3542_gen_type [22] = Y3542_pgtype22;
	Y3542_gen_type [23] = Y3542_pgtype23;
	Y3542_gen_type [38] = Y3542_pgtype24;
	Y3542_gen_type [52] = Y3542_pgtype25;
	Y3542_gen_type [53] = Y3542_pgtype26;
	Y3542_gen_type [78] = Y3542_pgtype27;
	Y3542_gen_type [79] = Y3542_pgtype28;
	Y3542_gen_type [80] = Y3542_pgtype29;
	Y3542_gen_type [81] = Y3542_pgtype30;
	Y3542_gen_type [82] = Y3542_pgtype31;
	Y3542_gen_type [83] = Y3542_pgtype32;
	Y3542_gen_type [84] = Y3542_pgtype33;
	Y3542_gen_type [85] = Y3542_pgtype34;
	Y3542_gen_type [86] = Y3542_pgtype35;
	Y3542_gen_type [87] = Y3542_pgtype36;
	Y3542_gen_type [88] = Y3542_pgtype37;
	Y3542_gen_type [89] = Y3542_pgtype38;
	Y3542_gen_type [160] = Y3542_pgtype39;
	Y3542_gen_type [161] = Y3542_pgtype40;
	Y3542_gen_type [162] = Y3542_pgtype41;
	Y3542_gen_type [163] = Y3542_pgtype42;
	Y3542_gen_type [164] = Y3542_pgtype43;
	Y3542_gen_type [165] = Y3542_pgtype44;
	Y3542_gen_type [166] = Y3542_pgtype45;
	Y3542_gen_type [167] = Y3542_pgtype46;
	Y3542_gen_type [168] = Y3542_pgtype47;
	Y3542_gen_type [169] = Y3542_pgtype48;
	Y3542_gen_type [170] = Y3542_pgtype49;
	Y3542_gen_type [171] = Y3542_pgtype50;
	Y3542_gen_type [172] = Y3542_pgtype51;
	Y3542_gen_type [173] = Y3542_pgtype52;
	Y3542_gen_type [174] = Y3542_pgtype53;
	Y3542_gen_type [175] = Y3542_pgtype54;
	Y3542_gen_type [176] = Y3542_pgtype55;
	Y3542_gen_type [177] = Y3542_pgtype56;
	Y3542_gen_type [178] = Y3542_pgtype57;
	Y3542_gen_type [179] = Y3542_pgtype58;
	Y3542_gen_type [180] = Y3542_pgtype59;
	Y3542_gen_type [181] = Y3542_pgtype60;
	Y3542_gen_type [182] = Y3542_pgtype61;
	Y3542_gen_type [183] = Y3542_pgtype62;
	Y3542_gen_type [184] = Y3542_pgtype63;
	Y3542_gen_type [185] = Y3542_pgtype64;
	Y3542_gen_type [186] = Y3542_pgtype65;
	Y3542_gen_type [187] = Y3542_pgtype66;
	Y3542_gen_type [188] = Y3542_pgtype67;
	Y3542_gen_type [189] = Y3542_pgtype68;
	Y3542_gen_type [190] = Y3542_pgtype69;
	Y3542_gen_type [191] = Y3542_pgtype70;
	Y3542_gen_type [192] = Y3542_pgtype71;
	Y3542_gen_type [193] = Y3542_pgtype72;
	Y3542_gen_type [194] = Y3542_pgtype73;
	Y3542_gen_type [195] = Y3542_pgtype74;
	Y3542_gen_type [196] = Y3542_pgtype75;
	Y3542_gen_type [197] = Y3542_pgtype76;
	Y3542_gen_type [198] = Y3542_pgtype77;
	Y3542_gen_type [199] = Y3542_pgtype78;
	Y3542_gen_type [200] = Y3542_pgtype79;
	Y3542_gen_type [201] = Y3542_pgtype80;
	Y3542_gen_type [202] = Y3542_pgtype81;
	Y3542_gen_type [203] = Y3542_pgtype82;
	Y3542_gen_type [204] = Y3542_pgtype83;
	Y3542_gen_type [205] = Y3542_pgtype84;
	Y3542_gen_type [206] = Y3542_pgtype85;
	Y3542_gen_type [207] = Y3542_pgtype86;
	Y3542_gen_type [208] = Y3542_pgtype87;
	Y3542_gen_type [209] = Y3542_pgtype88;
	Y3542_gen_type [212] = Y3542_pgtype89;
	Y3542_gen_type [213] = Y3542_pgtype90;
	Y3542_gen_type [214] = Y3542_pgtype91;
	Y3542_gen_type [215] = Y3542_pgtype92;
	Y3542_gen_type [216] = Y3542_pgtype93;
	Y3542_gen_type [217] = Y3542_pgtype94;
	Y3542_gen_type [218] = Y3542_pgtype95;
	Y3542_gen_type [219] = Y3542_pgtype96;
	Y3542_gen_type [220] = Y3542_pgtype97;
	Y3542_gen_type [221] = Y3542_pgtype98;
	Y3542_gen_type [222] = Y3542_pgtype99;
	Y3542_gen_type [223] = Y3542_pgtype100;
	Y3542_gen_type [224] = Y3542_pgtype101;
	Y3542[39] = 906;
	{long i; for (i = 102; i < 105; i++) Y3542[i] = 936;};
	Y3542[449] = 936;
	{long i; for (i = 667; i < 671; i++) Y3542[i] = 936;};
	{long i; for (i = 672; i < 676; i++) Y3542[i] = 936;};
}

char *(*R3548[17])();
void R3548_init () {
	R3548[0] = (char *(*)()) F838_4694;
	R3548[1] = (char *(*)()) F839_4694;
	R3548[5] = (char *(*)()) F843_4780;
	R3548[6] = (char *(*)()) F844_4780;
	R3548[7] = (char *(*)()) F845_4780;
	R3548[8] = (char *(*)()) F846_4780;
	R3548[9] = (char *(*)()) F847_4780;
	R3548[10] = (char *(*)()) F848_4780;
	R3548[11] = (char *(*)()) F849_4780;
	R3548[12] = (char *(*)()) F850_4780;
	R3548[13] = (char *(*)()) F851_4780;
	R3548[14] = (char *(*)()) F852_4780;
	R3548[15] = (char *(*)()) F853_4780;
	R3548[16] = (char *(*)()) F854_4780;
}

static EIF_TYPE_INDEX Y3548_pgtype0[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype1[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype2[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype3[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype4[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype5[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype6[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype7[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype8[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype9[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype10[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype11[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype12[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype13[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype14[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype15[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype16[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype17[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype18[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype19[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype20[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype21[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype22[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype23[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype24[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype25[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype26[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype27[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype28[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype29[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype30[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype31[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype32[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype33[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype34[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype35[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype36[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype37[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype38[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype39[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype40[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype41[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype42[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype43[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype44[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype45[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype46[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype47[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype48[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype49[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype50[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype51[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype52[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype53[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype54[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype55[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype56[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype57[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype58[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype59[] = {0xFF01,223,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype60[] = {0xFF01,224,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype61[] = {0xFF01,225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype62[] = {0xFF01,227,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype63[] = {0xFF01,227,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype64[] = {0xFF01,227,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype65[] = {0xFF01,227,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype66[] = {0xFF01,227,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype67[] = {0xFF01,227,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype68[] = {0xFF01,227,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype69[] = {0xFF01,227,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype70[] = {0xFF01,227,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype71[] = {0xFF01,227,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype72[] = {0xFF01,227,0xFFFF};
static EIF_TYPE_INDEX Y3548_pgtype73[] = {0xFF01,227,0xFFFF};
EIF_TYPE_INDEX *Y3548_gen_type [213];
EIF_TYPE_INDEX Y3548 [213];
void Y3548_init (void)
{
	egc_routines_types [3548] = Y3548;
	egc_routines_gen_types [3548] = Y3548_gen_type;
	egc_routines_offset [3548] = 641;
	Y3548_gen_type [0] = Y3548_pgtype0;
	Y3548_gen_type [1] = Y3548_pgtype1;
	Y3548_gen_type [2] = Y3548_pgtype2;
	Y3548_gen_type [3] = Y3548_pgtype3;
	Y3548_gen_type [4] = Y3548_pgtype4;
	Y3548_gen_type [5] = Y3548_pgtype5;
	Y3548_gen_type [6] = Y3548_pgtype6;
	Y3548_gen_type [7] = Y3548_pgtype7;
	Y3548_gen_type [8] = Y3548_pgtype8;
	Y3548_gen_type [9] = Y3548_pgtype9;
	Y3548_gen_type [10] = Y3548_pgtype10;
	Y3548_gen_type [11] = Y3548_pgtype11;
	Y3548_gen_type [148] = Y3548_pgtype12;
	Y3548_gen_type [149] = Y3548_pgtype13;
	Y3548_gen_type [150] = Y3548_pgtype14;
	Y3548_gen_type [151] = Y3548_pgtype15;
	Y3548_gen_type [152] = Y3548_pgtype16;
	Y3548_gen_type [153] = Y3548_pgtype17;
	Y3548_gen_type [154] = Y3548_pgtype18;
	Y3548_gen_type [155] = Y3548_pgtype19;
	Y3548_gen_type [156] = Y3548_pgtype20;
	Y3548_gen_type [157] = Y3548_pgtype21;
	Y3548_gen_type [158] = Y3548_pgtype22;
	Y3548_gen_type [159] = Y3548_pgtype23;
	Y3548_gen_type [160] = Y3548_pgtype24;
	Y3548_gen_type [161] = Y3548_pgtype25;
	Y3548_gen_type [162] = Y3548_pgtype26;
	Y3548_gen_type [163] = Y3548_pgtype27;
	Y3548_gen_type [164] = Y3548_pgtype28;
	Y3548_gen_type [165] = Y3548_pgtype29;
	Y3548_gen_type [166] = Y3548_pgtype30;
	Y3548_gen_type [167] = Y3548_pgtype31;
	Y3548_gen_type [168] = Y3548_pgtype32;
	Y3548_gen_type [169] = Y3548_pgtype33;
	Y3548_gen_type [170] = Y3548_pgtype34;
	Y3548_gen_type [171] = Y3548_pgtype35;
	Y3548_gen_type [172] = Y3548_pgtype36;
	Y3548_gen_type [173] = Y3548_pgtype37;
	Y3548_gen_type [174] = Y3548_pgtype38;
	Y3548_gen_type [175] = Y3548_pgtype39;
	Y3548_gen_type [176] = Y3548_pgtype40;
	Y3548_gen_type [177] = Y3548_pgtype41;
	Y3548_gen_type [178] = Y3548_pgtype42;
	Y3548_gen_type [179] = Y3548_pgtype43;
	Y3548_gen_type [180] = Y3548_pgtype44;
	Y3548_gen_type [181] = Y3548_pgtype45;
	Y3548_gen_type [182] = Y3548_pgtype46;
	Y3548_gen_type [183] = Y3548_pgtype47;
	Y3548_gen_type [184] = Y3548_pgtype48;
	Y3548_gen_type [185] = Y3548_pgtype49;
	Y3548_gen_type [186] = Y3548_pgtype50;
	Y3548_gen_type [187] = Y3548_pgtype51;
	Y3548_gen_type [188] = Y3548_pgtype52;
	Y3548_gen_type [189] = Y3548_pgtype53;
	Y3548_gen_type [190] = Y3548_pgtype54;
	Y3548_gen_type [191] = Y3548_pgtype55;
	Y3548_gen_type [192] = Y3548_pgtype56;
	Y3548_gen_type [193] = Y3548_pgtype57;
	Y3548_gen_type [194] = Y3548_pgtype58;
	Y3548_gen_type [195] = Y3548_pgtype59;
	Y3548_gen_type [196] = Y3548_pgtype60;
	Y3548_gen_type [197] = Y3548_pgtype61;
	Y3548_gen_type [201] = Y3548_pgtype62;
	Y3548_gen_type [202] = Y3548_pgtype63;
	Y3548_gen_type [203] = Y3548_pgtype64;
	Y3548_gen_type [204] = Y3548_pgtype65;
	Y3548_gen_type [205] = Y3548_pgtype66;
	Y3548_gen_type [206] = Y3548_pgtype67;
	Y3548_gen_type [207] = Y3548_pgtype68;
	Y3548_gen_type [208] = Y3548_pgtype69;
	Y3548_gen_type [209] = Y3548_pgtype70;
	Y3548_gen_type [210] = Y3548_pgtype71;
	Y3548_gen_type [211] = Y3548_pgtype72;
	Y3548_gen_type [212] = Y3548_pgtype73;
	{long i; for (i = 0; i < 12; i++) Y3548[i] = 223;};
	{long i; for (i = 148; i < 196; i++) Y3548[i] = 223;};
	Y3548[196] = 224;
	Y3548[197] = 225;
	{long i; for (i = 201; i < 213; i++) Y3548[i] = 227;};
}

char *(*R3550[17])();
void R3550_init () {
	R3550[0] = (char *(*)()) F838_4713;
	R3550[1] = (char *(*)()) F839_4713;
	R3550[5] = (char *(*)()) F843_4805;
	R3550[6] = (char *(*)()) F844_4805;
	R3550[7] = (char *(*)()) F845_4805;
	R3550[8] = (char *(*)()) F846_4805;
	R3550[9] = (char *(*)()) F847_4805;
	R3550[10] = (char *(*)()) F848_4805;
	R3550[11] = (char *(*)()) F849_4805;
	R3550[12] = (char *(*)()) F850_4805;
	R3550[13] = (char *(*)()) F851_4805;
	R3550[14] = (char *(*)()) F852_4805;
	R3550[15] = (char *(*)()) F853_4805;
	R3550[16] = (char *(*)()) F854_4805;
}

char *(*R3562[692])();
void R3562_init () {
	{long i; for (i = 0; i < 2; i++) R3562[i] = (char *(*)()) F732_4169;}
	R3562[38] = (char *(*)()) F771_4551;
	R3562[39] = (char *(*)()) F772_4591;
	R3562[40] = (char *(*)()) F773_4591;
	R3562[41] = (char *(*)()) F774_4591;
	R3562[42] = (char *(*)()) F775_4591;
	R3562[43] = (char *(*)()) F776_4591;
	R3562[44] = (char *(*)()) F777_4591;
	R3562[45] = (char *(*)()) F778_4591;
	R3562[46] = (char *(*)()) F779_4591;
	R3562[47] = (char *(*)()) F780_4591;
	R3562[48] = (char *(*)()) F781_4591;
	R3562[49] = (char *(*)()) F782_4591;
	R3562[50] = (char *(*)()) F783_4591;
	R3562[51] = (char *(*)()) F772_4591;
	R3562[52] = (char *(*)()) F774_4591;
	R3562[53] = (char *(*)()) F776_4591;
	R3562[54] = (char *(*)()) F775_4591;
	R3562[55] = (char *(*)()) F773_4591;
	R3562[56] = (char *(*)()) F778_4591;
	R3562[105] = (char *(*)()) F838_4697;
	R3562[106] = (char *(*)()) F839_4697;
	R3562[109] = (char *(*)()) F842_4742;
	R3562[110] = (char *(*)()) F843_4790;
	R3562[111] = (char *(*)()) F844_4790;
	R3562[112] = (char *(*)()) F845_4790;
	R3562[113] = (char *(*)()) F846_4790;
	R3562[114] = (char *(*)()) F847_4790;
	R3562[115] = (char *(*)()) F848_4790;
	R3562[116] = (char *(*)()) F849_4790;
	R3562[117] = (char *(*)()) F850_4790;
	R3562[118] = (char *(*)()) F851_4790;
	R3562[119] = (char *(*)()) F852_4790;
	R3562[120] = (char *(*)()) F853_4790;
	R3562[121] = (char *(*)()) F854_4790;
	R3562[122] = (char *(*)()) F855_4853;
	R3562[123] = (char *(*)()) F856_4853;
	R3562[124] = (char *(*)()) F857_4853;
	R3562[125] = (char *(*)()) F858_4853;
	R3562[126] = (char *(*)()) F859_4853;
	R3562[127] = (char *(*)()) F855_4853;
	R3562[128] = (char *(*)()) F856_4853;
	R3562[129] = (char *(*)()) F855_4853;
	R3562[251] = (char *(*)()) F982_6466;
	{long i; for (i = 254; i < 256; i++) R3562[i] = (char *(*)()) F985_6634;}
	R3562[346] = (char *(*)()) F1079_7670;
	{long i; for (i = 564; i < 568; i++) R3562[i] = (char *(*)()) F732_4169;}
	{long i; for (i = 569; i < 573; i++) R3562[i] = (char *(*)()) F732_4169;}
	{long i; for (i = 690; i < 692; i++) R3562[i] = (char *(*)()) F1423_11803;}
}

char *(*R3565[654])();
void R3565_init () {
	R3565[0] = (char *(*)()) F771_4550;
	R3565[1] = (char *(*)()) F772_4592;
	R3565[2] = (char *(*)()) F773_4592;
	R3565[3] = (char *(*)()) F774_4592;
	R3565[4] = (char *(*)()) F775_4592;
	R3565[5] = (char *(*)()) F776_4592;
	R3565[6] = (char *(*)()) F777_4592;
	R3565[7] = (char *(*)()) F778_4592;
	R3565[8] = (char *(*)()) F779_4592;
	R3565[9] = (char *(*)()) F780_4592;
	R3565[10] = (char *(*)()) F781_4592;
	R3565[11] = (char *(*)()) F782_4592;
	R3565[12] = (char *(*)()) F783_4592;
	R3565[13] = (char *(*)()) F772_4592;
	R3565[14] = (char *(*)()) F774_4592;
	R3565[15] = (char *(*)()) F776_4592;
	R3565[16] = (char *(*)()) F775_4592;
	R3565[17] = (char *(*)()) F773_4592;
	R3565[18] = (char *(*)()) F778_4592;
	R3565[71] = (char *(*)()) F842_4743;
	R3565[72] = (char *(*)()) F843_4791;
	R3565[73] = (char *(*)()) F844_4791;
	R3565[74] = (char *(*)()) F845_4791;
	R3565[75] = (char *(*)()) F846_4791;
	R3565[76] = (char *(*)()) F847_4791;
	R3565[77] = (char *(*)()) F848_4791;
	R3565[78] = (char *(*)()) F849_4791;
	R3565[79] = (char *(*)()) F850_4791;
	R3565[80] = (char *(*)()) F851_4791;
	R3565[81] = (char *(*)()) F852_4791;
	R3565[82] = (char *(*)()) F853_4791;
	R3565[83] = (char *(*)()) F854_4791;
	R3565[213] = (char *(*)()) F982_6465;
	{long i; for (i = 216; i < 218; i++) R3565[i] = (char *(*)()) F985_6633;}
	{long i; for (i = 652; i < 654; i++) R3565[i] = (char *(*)()) F1423_11805;}
}

char *(*R3569[654])();
void R3569_init () {
	R3569[0] = (char *(*)()) F697_4126;
	R3569[1] = (char *(*)()) F696_4126;
	R3569[2] = (char *(*)()) F697_4126;
	R3569[3] = (char *(*)()) F698_4126;
	R3569[4] = (char *(*)()) F700_4126;
	R3569[5] = (char *(*)()) F701_4126;
	R3569[6] = (char *(*)()) F702_4126;
	R3569[7] = (char *(*)()) F699_4126;
	R3569[8] = (char *(*)()) F703_4126;
	R3569[9] = (char *(*)()) F704_4126;
	R3569[10] = (char *(*)()) F705_4126;
	R3569[11] = (char *(*)()) F706_4126;
	R3569[12] = (char *(*)()) F707_4126;
	R3569[13] = (char *(*)()) F696_4126;
	R3569[14] = (char *(*)()) F698_4126;
	R3569[15] = (char *(*)()) F701_4126;
	R3569[16] = (char *(*)()) F700_4126;
	R3569[17] = (char *(*)()) F697_4126;
	R3569[18] = (char *(*)()) F699_4126;
	{long i; for (i = 71; i < 73; i++) R3569[i] = (char *(*)()) F696_4126;}
	R3569[73] = (char *(*)()) F697_4126;
	R3569[74] = (char *(*)()) F698_4126;
	R3569[75] = (char *(*)()) F700_4126;
	R3569[76] = (char *(*)()) F701_4126;
	R3569[77] = (char *(*)()) F702_4126;
	R3569[78] = (char *(*)()) F699_4126;
	R3569[79] = (char *(*)()) F703_4126;
	R3569[80] = (char *(*)()) F704_4126;
	R3569[81] = (char *(*)()) F705_4126;
	R3569[82] = (char *(*)()) F706_4126;
	R3569[83] = (char *(*)()) F707_4126;
	R3569[213] = (char *(*)()) F702_4126;
	{long i; for (i = 216; i < 218; i++) R3569[i] = (char *(*)()) F699_4126;}
	{long i; for (i = 652; i < 654; i++) R3569[i] = (char *(*)()) F699_4126;}
}

char *(*R3571[654])();
void R3571_init () {
	R3571[0] = (char *(*)()) F771_4561;
	R3571[1] = (char *(*)()) F772_4622;
	R3571[2] = (char *(*)()) F773_4622;
	R3571[3] = (char *(*)()) F774_4622;
	R3571[4] = (char *(*)()) F775_4622;
	R3571[5] = (char *(*)()) F776_4622;
	R3571[6] = (char *(*)()) F777_4622;
	R3571[7] = (char *(*)()) F778_4622;
	R3571[8] = (char *(*)()) F779_4622;
	R3571[9] = (char *(*)()) F780_4622;
	R3571[10] = (char *(*)()) F781_4622;
	R3571[11] = (char *(*)()) F782_4622;
	R3571[12] = (char *(*)()) F783_4622;
	R3571[13] = (char *(*)()) F772_4622;
	R3571[14] = (char *(*)()) F774_4622;
	R3571[15] = (char *(*)()) F776_4622;
	R3571[16] = (char *(*)()) F775_4622;
	R3571[17] = (char *(*)()) F773_4622;
	R3571[18] = (char *(*)()) F778_4622;
	R3571[71] = (char *(*)()) F842_4765;
	R3571[72] = (char *(*)()) F843_4817;
	R3571[73] = (char *(*)()) F844_4817;
	R3571[74] = (char *(*)()) F845_4817;
	R3571[75] = (char *(*)()) F846_4817;
	R3571[76] = (char *(*)()) F847_4817;
	R3571[77] = (char *(*)()) F848_4817;
	R3571[78] = (char *(*)()) F849_4817;
	R3571[79] = (char *(*)()) F850_4817;
	R3571[80] = (char *(*)()) F851_4817;
	R3571[81] = (char *(*)()) F852_4817;
	R3571[82] = (char *(*)()) F853_4817;
	R3571[83] = (char *(*)()) F854_4817;
	R3571[213] = (char *(*)()) F984_6593;
	{long i; for (i = 216; i < 218; i++) R3571[i] = (char *(*)()) F987_6758;}
	{long i; for (i = 652; i < 654; i++) R3571[i] = (char *(*)()) F987_6758;}
}

char *(*R3573[573])();
void R3573_init () {
	{long i; for (i = 0; i < 2; i++) R3573[i] = (char *(*)()) F714_4133_3573_4;}
	R3573[105] = (char *(*)()) F708_4133;
	R3573[106] = (char *(*)()) F709_4133_3573_4;
	R3573[110] = (char *(*)()) F843_4809;
	R3573[111] = (char *(*)()) F844_4809_3573_4;
	R3573[112] = (char *(*)()) F845_4809_3573_4;
	R3573[113] = (char *(*)()) F846_4809_3573_4;
	R3573[114] = (char *(*)()) F847_4809_3573_4;
	R3573[115] = (char *(*)()) F848_4809_3573_4;
	R3573[116] = (char *(*)()) F849_4809_3573_4;
	R3573[117] = (char *(*)()) F850_4809_3573_4;
	R3573[118] = (char *(*)()) F851_4809_3573_4;
	R3573[119] = (char *(*)()) F852_4809_3573_4;
	R3573[120] = (char *(*)()) F853_4809_3573_4;
	R3573[121] = (char *(*)()) F854_4809_3573_4;
	R3573[346] = (char *(*)()) F714_4133_3573_4;
	{long i; for (i = 564; i < 568; i++) R3573[i] = (char *(*)()) F714_4133_3573_4;}
	{long i; for (i = 569; i < 573; i++) R3573[i] = (char *(*)()) F714_4133_3573_4;}
}
static void F714_4133_3573_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F714_4133(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F709_4133_3573_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F709_4133(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F844_4809_3573_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F844_4809(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F845_4809_3573_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F845_4809(Current, *(EIF_BOOLEAN *)arg1);
}
static void F846_4809_3573_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F846_4809(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F847_4809_3573_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F847_4809(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F848_4809_3573_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F848_4809(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F849_4809_3573_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F849_4809(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F850_4809_3573_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F850_4809(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F851_4809_3573_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F851_4809(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F852_4809_3573_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F852_4809(Current, *(EIF_POINTER *)arg1);
}
static void F853_4809_3573_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F853_4809(Current, *(EIF_REAL_32 *)arg1);
}
static void F854_4809_3573_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F854_4809(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R3576[573])();
void R3576_init () {
	R3576[0] = (char *(*)()) F732_4139;
	R3576[1] = (char *(*)()) F734_4420;
	R3576[346] = (char *(*)()) F734_4420;
	R3576[564] = (char *(*)()) F734_4420;
	{long i; for (i = 565; i < 568; i++) R3576[i] = (char *(*)()) F732_4139;}
	R3576[569] = (char *(*)()) F734_4420;
	{long i; for (i = 570; i < 573; i++) R3576[i] = (char *(*)()) F732_4139;}
}

char *(*R3601[573])();
void R3601_init () {
	{long i; for (i = 0; i < 2; i++) R3601[i] = (char *(*)()) F732_4173;}
	R3601[346] = (char *(*)()) F1079_7668;
	{long i; for (i = 564; i < 568; i++) R3601[i] = (char *(*)()) F732_4173;}
	{long i; for (i = 569; i < 573; i++) R3601[i] = (char *(*)()) F732_4173;}
}


#ifdef __cplusplus
}
#endif
