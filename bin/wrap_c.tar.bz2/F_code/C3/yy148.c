/*
 * Code for class YY_FILE_BUFFER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy148.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_FILE_BUFFER}.make */
void F203_2248 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = RTOSCF(2237,F200_2237, (Current));
	F203_2249(Current, arg1, ti4_1);
	RTLE;
}

/* {YY_FILE_BUFFER}.make_with_size */
void F203_2249 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O2108[dtype-199]) = (EIF_INTEGER_32) arg2;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2126[dtype-199])(Current, (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 2L)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	F203_2254(Current, arg1);
	RTLE;
}

/* {YY_FILE_BUFFER}.make_from_string */
void F203_2250 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = RTOSCF(1753,F162_1753, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F200_2212(Current, arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {YY_FILE_BUFFER}.name */
EIF_REFERENCE F203_2251 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1859[Dtype(RTCW(tr1))-1009])(tr1);
	RTLE;
	return Result;
}

/* {YY_FILE_BUFFER}.set_file */
void F203_2254 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F203_2255(Current, arg1, *(EIF_INTEGER_32 *)(Current + O2108[Dtype(Current)-199]));
}

/* {YY_FILE_BUFFER}.set_file_with_size */
void F203_2255 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1857[Dtype(RTCW(arg1))-1009])(arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_) = (EIF_BOOLEAN) tb1;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2122[dtype-199])(Current);
	if ((EIF_BOOLEAN) (arg2 > *(EIF_INTEGER_32 *)(Current + O2108[dtype-199]))) {
		*(EIF_INTEGER_32 *)(Current + O2108[dtype-199]) = (EIF_INTEGER_32) arg2;
		tr1 = *(EIF_REFERENCE *)(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R1302[Dtype(RTCW(tr1))-334])(tr1, (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 2L)));
	}
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {YY_FILE_BUFFER}.fill */
void F203_2258 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2124[dtype-199])(Current);
		loc3 = *(EIF_REFERENCE *)(Current);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R1851[Dtype(RTCW(tr1))-1009])(tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1857[Dtype(RTCW(tr1))-1009])(tr1);
			if ((EIF_BOOLEAN) !tb1) {
				(*(EIF_INTEGER_32 *)(Current + O2107[dtype-199]))++;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1860[Dtype(RTCW(tr1))-1009])(tr1));
				ti4_1 = *(EIF_INTEGER_32 *)(Current + O2107[dtype-199]);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1298[Dtype(RTCW(loc3))-334])(loc3, (EIF_REFERENCE) &tc1, ti4_1);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		} else {
			loc1 = *(EIF_INTEGER_32 *)(Current + O2108[dtype-199]);
			ti4_1 = *(EIF_INTEGER_32 *)(Current + O2107[dtype-199]);
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
			loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R1299[Dtype(RTCW(loc3))-334])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O2107[dtype-199]) + ((EIF_INTEGER_32) 1L)), loc1);
			if ((EIF_BOOLEAN) (loc2 < loc1)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1857[Dtype(RTCW(tr1))-1009])(tr1);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_) = (EIF_BOOLEAN) tb1;
			}
			if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			(*(EIF_INTEGER_32 *)(Current + O2107[dtype-199])) += loc2;
		}
		tc1 = (EIF_CHARACTER_8) '\000';
		ti4_1 = *(EIF_INTEGER_32 *)(Current + O2107[dtype-199]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1298[Dtype(RTCW(loc3))-334])(loc3, (EIF_REFERENCE) &tc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		tc1 = (EIF_CHARACTER_8) '\000';
		ti4_1 = *(EIF_INTEGER_32 *)(Current + O2107[dtype-199]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1298[Dtype(RTCW(loc3))-334])(loc3, (EIF_REFERENCE) &tc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
	} else {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

void EIF_Minit148 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
