/*
 * Code for class EWG_C_AST_SHARED_DECLARATION_EQUALITY_TESTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew116.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EWG_C_AST_SHARED_DECLARATION_EQUALITY_TESTER}.declaration_equality_tester */
static EIF_REFERENCE F171_1918_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1918);
#define Result RTOSR(1918)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,308,0xFF01,899,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 308, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1918);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F171_1918 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1918,F171_1918_body,(Current));
}

/* {EWG_C_AST_SHARED_DECLARATION_EQUALITY_TESTER}.function_declaration_equality_tester */
static EIF_REFERENCE F171_1919_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1919);
#define Result RTOSR(1919)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,308,0xFF01,900,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 308, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1919);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F171_1919 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1919,F171_1919_body,(Current));
}

void EIF_Minit116 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
