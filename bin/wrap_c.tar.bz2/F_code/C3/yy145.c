/*
 * Code for class YY_BUFFER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy145.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_BUFFER}.make */
void F200_2212 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2126[Dtype(Current)-199])(Current, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
	F98_1318(RTCW(loc1), arg1, ((EIF_INTEGER_32) 1L));
	tc1 = (EIF_CHARACTER_8) '\000';
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1298[Dtype(RTCW(loc1))-334])(loc1, (EIF_REFERENCE) &tc1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
	tc1 = (EIF_CHARACTER_8) '\000';
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1298[Dtype(RTCW(loc1))-334])(loc1, (EIF_REFERENCE) &tc1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 2L)));
	F200_2213(Current, loc1);
	RTLE;
}

/* {YY_BUFFER}.make_from_buffer */
void F200_2213 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1297[Dtype(RTCW(arg1))-334])(arg1);
	*(EIF_INTEGER_32 *)(Current + O2108[dtype-199]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 2L));
	*(EIF_INTEGER_32 *)(Current + O2107[dtype-199]) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O2108[dtype-199]);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	*(EIF_INTEGER_32 *)(Current + O2112[dtype-199]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O2110[dtype-199]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O2111[dtype-199]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O2109[dtype-199]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_BOOLEAN *)(Current + O2113[dtype-199]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {YY_BUFFER}.name */
EIF_REFERENCE F200_2214 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) RTOSCF(2239,F200_2239, (Current));
}

/* {YY_BUFFER}.set_position */
void F200_2224 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O2109[dtype-199]) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current + O2110[dtype-199]) = (EIF_INTEGER_32) arg2;
	*(EIF_INTEGER_32 *)(Current + O2111[dtype-199]) = (EIF_INTEGER_32) arg3;
	RTLE;
}

/* {YY_BUFFER}.set_index */
void F200_2225 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O2112[Dtype(Current)-199]) = (EIF_INTEGER_32) arg1;
}

/* {YY_BUFFER}.set_beginning_of_line */
void F200_2226 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O2113[Dtype(Current)-199]) = (EIF_BOOLEAN) arg1;
}

/* {YY_BUFFER}.fill */
void F200_2230 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O2118[Dtype(Current)-199]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {YY_BUFFER}.flush */
void F200_2231 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tc1 = (EIF_CHARACTER_8) '\000';
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1298[Dtype(RTCW(tr1))-334])(tr1, (EIF_REFERENCE) &tc1, ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current);
	tc1 = (EIF_CHARACTER_8) '\000';
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1298[Dtype(RTCW(tr1))-334])(tr1, (EIF_REFERENCE) &tc1, ((EIF_INTEGER_32) 2L));
	*(EIF_INTEGER_32 *)(Current + O2107[dtype-199]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current + O2112[dtype-199]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O2110[dtype-199]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O2111[dtype-199]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O2109[dtype-199]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_BOOLEAN *)(Current + O2113[dtype-199]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O2118[dtype-199]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {YY_BUFFER}.compact_left */
void F200_2233 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O2107[dtype-199]);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O2112[dtype-199]);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ti4_1) + ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current + O2108[dtype-199]))) {
		F200_2236(Current);
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O2112[dtype-199]) != ((EIF_INTEGER_32) 1L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R1300[Dtype(RTCW(tr1))-334])(tr1, *(EIF_INTEGER_32 *)(Current + O2112[dtype-199]), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
		*(EIF_INTEGER_32 *)(Current + O2112[dtype-199]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		*(EIF_INTEGER_32 *)(Current + O2107[dtype-199]) = (EIF_INTEGER_32) loc1;
	}
	RTLE;
}

/* {YY_BUFFER}.new_default_buffer */
EIF_REFERENCE F200_2235 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(335, 0x01).id, 335, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F336_3391(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {YY_BUFFER}.resize */
void F200_2236 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O2108[dtype-199]) == ((EIF_INTEGER_32) 0L))) {
		ti4_1 = RTOSCF(2237,F200_2237, (Current));
		*(EIF_INTEGER_32 *)(Current + O2108[dtype-199]) = (EIF_INTEGER_32) ti4_1;
	} else {
		(*(EIF_INTEGER_32 *)(Current + O2108[dtype-199])) *= ((EIF_INTEGER_32) 2L);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1297[Dtype(RTCW(tr1))-334])(tr1);
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O2108[dtype-199]) + ((EIF_INTEGER_32) 2L)) > ti4_1)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R1302[Dtype(RTCW(tr1))-334])(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O2108[dtype-199]) + ((EIF_INTEGER_32) 2L)));
	}
	RTLE;
}

/* {YY_BUFFER}.default_capacity */
static EIF_INTEGER_32 F200_2237_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (2237);
#define Result RTOSR(2237)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16384L);
	RTOSE (2237);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F200_2237 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2237,F200_2237_body,(Current));
}

/* {YY_BUFFER}.name_constant */

EIF_REFERENCE F200_2239 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2239,RTMS_EX_H("<string>",8,1911048254));
}

void EIF_Minit145 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
