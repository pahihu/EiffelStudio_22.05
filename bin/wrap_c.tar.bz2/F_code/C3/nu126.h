
#ifndef _C3_nu126_
#define _C3_nu126_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F181_2001(EIF_REFERENCE);
extern void EIF_Minit126(void);

#ifdef __cplusplus
}
#endif

#endif
