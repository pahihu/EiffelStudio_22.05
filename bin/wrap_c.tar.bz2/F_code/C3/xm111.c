/*
 * Code for class XM_DTD_CALLBACKS_SOURCE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm111.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_DTD_CALLBACKS_SOURCE}.null_dtd_callbacks */
EIF_REFERENCE F164_1857 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(145, 0x01).id, 145, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit111 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
