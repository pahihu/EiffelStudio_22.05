
#ifndef _C3_yy147_
#define _C3_yy147_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F202_2247(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit147(void);
extern void F335_3360(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2106[];
extern EIF_TYPE_INDEX *Y2106_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
