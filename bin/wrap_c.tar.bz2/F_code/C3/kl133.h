
#ifndef _C3_kl133_
#define _C3_kl133_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2123)
static EIF_REFERENCE F188_2123_body(EIF_REFERENCE);
extern EIF_REFERENCE F188_2123(EIF_REFERENCE);
extern void EIF_Minit133(void);

#ifdef __cplusplus
}
#endif

#endif
