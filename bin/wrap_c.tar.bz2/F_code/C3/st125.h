
#ifndef _C3_st125_
#define _C3_st125_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F180_1997(EIF_REFERENCE);
extern EIF_INTEGER_32 F180_1998(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit125(void);
extern char *(*R4960[])();
extern char *(*R4923[])();
extern char *(*R5157[])();

#ifdef __cplusplus
}
#endif

#endif
