/*
 * Code for class KL_SHARED_STREAMS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl109.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SHARED_STREAMS}.null_input_stream */
static EIF_REFERENCE F162_1753_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1753);
#define Result RTOSR(1753)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1015, 0x01).id, 1015, _OBJSIZ_2_2_0_1_0_0_0_0_);
	tr2 = RTMS_EX_H("",0,0);
	F1016_7027(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1753);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_1753 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1753,F162_1753_body,(Current));
}

/* {KL_SHARED_STREAMS}.null_output_stream */
static EIF_REFERENCE F162_1754_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1754);
#define Result RTOSR(1754)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1037, 0x01).id, 1037, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("null",4,1853189228);
	F1038_7276(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1754);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F162_1754 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1754,F162_1754_body,(Current));
}

void EIF_Minit109 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
