
#ifndef _C3_in127_
#define _C3_in127_

#ifdef __cplusplus
extern "C" {
#endif

extern void F182_2023(EIF_REFERENCE);
extern EIF_BOOLEAN F182_2024(EIF_REFERENCE, EIF_NATURAL_64, EIF_NATURAL_64, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit127(void);
extern void F750_4510(EIF_REFERENCE, EIF_NATURAL_64);

#ifdef __cplusplus
}
#endif

#endif
