
#ifndef _C3_xm112_
#define _C3_xm112_

#ifdef __cplusplus
extern "C" {
#endif

extern void F165_1860(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void F165_1861(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F165_1862(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F165_1863(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F165_1864(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F165_1865(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F165_1866(EIF_REFERENCE, EIF_REFERENCE);
extern void F165_1867(EIF_REFERENCE);
extern void EIF_Minit112(void);
extern char *(*R1670[])();
extern char *(*R1671[])();
extern char *(*R1672[])();
extern char *(*R1673[])();
extern char *(*R1674[])();
extern char *(*R1675[])();
extern char *(*R1676[])();
extern char *(*R1677[])();

#ifdef __cplusplus
}
#endif

#endif
