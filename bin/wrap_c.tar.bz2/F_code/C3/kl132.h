
#ifndef _C3_kl132_
#define _C3_kl132_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2122)
static EIF_REFERENCE F187_2122_body(EIF_REFERENCE);
extern EIF_REFERENCE F187_2122(EIF_REFERENCE);
extern void EIF_Minit132(void);
extern void F428_3902(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
