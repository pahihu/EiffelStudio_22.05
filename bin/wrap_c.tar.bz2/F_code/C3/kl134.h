
#ifndef _C3_kl134_
#define _C3_kl134_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2124)
static EIF_REFERENCE F189_2124_body(EIF_REFERENCE);
extern EIF_REFERENCE F189_2124(EIF_REFERENCE);
extern void EIF_Minit134(void);

#ifdef __cplusplus
}
#endif

#endif
