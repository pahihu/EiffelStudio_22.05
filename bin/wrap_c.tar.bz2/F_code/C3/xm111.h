
#ifndef _C3_xm111_
#define _C3_xm111_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F164_1857(EIF_REFERENCE);
extern void EIF_Minit111(void);

#ifdef __cplusplus
}
#endif

#endif
