/*
 * Code for class XM_EIFFEL_PARSER_ERRORS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm101.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_EIFFEL_PARSER_ERRORS}.error_no_cdata_end_in_content */

EIF_REFERENCE F144_1639 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1639,RTMS_EX_H("]]> not allowed in content",26,1964888692));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_no_dash_dash_in_comment */

EIF_REFERENCE F144_1640 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1640,RTMS_EX_H("-- not allowed in comment",25,443946356));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_lt_not_allowed_attribute_value */

EIF_REFERENCE F144_1642 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1642,RTMS_EX_H("< not allowed in attribute value",32,125757285));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_unsupported_encoding */

EIF_REFERENCE F144_1645 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1645,RTMS_EX_H("unsupported character encoding",30,441955687));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_misplaced_dtd_declaration */

EIF_REFERENCE F144_1652 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1652,RTMS_EX_H("Misplaced markup declaration",28,268357742));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_xml_declaration */

EIF_REFERENCE F144_1653 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1653,RTMS_EX_H("Misformed XML Declaration",25,811286638));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_start_tag */

EIF_REFERENCE F144_1655 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1655,RTMS_EX_H("Misformed start tag",19,1177630823));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_element_content */

EIF_REFERENCE F144_1656 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1656,RTMS_EX_H("Error in element content",24,1573352820));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_element_end_tag */

EIF_REFERENCE F144_1657 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1657,RTMS_EX_H("Missing element end tag",23,970914919));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_attribute */

EIF_REFERENCE F144_1660 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1660,RTMS_EX_H("Misformed attribute in tag",26,513136999));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_attribute_duplicate */

EIF_REFERENCE F144_1661 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1661,RTMS_EX_H("Attribute declared twice",24,1052150629));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_end_tag */

EIF_REFERENCE F144_1662 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1662,RTMS_EX_H("Error in end tag",16,1903110759));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_end_tag_mismatch */

EIF_REFERENCE F144_1663 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1663,RTMS_EX_H("End tag does not match start tag",32,1993968231));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_entity_xml_declaration */

EIF_REFERENCE F144_1665 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1665,RTMS_EX_H("Error in XML declaration",24,614745454));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_entity_literal_in_attribute */

EIF_REFERENCE F144_1666 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1666,RTMS_EX_H("Literal entity expected in attribute",36,1952294245));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_entity_undefined */

EIF_REFERENCE F144_1667 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1667,RTMS_EX_H("Entity is not defined",21,512939108));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_external_reference_in_quoted_value */

EIF_REFERENCE F144_1668 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1668,RTMS_EX_H("External reference in quoted value",34,2040173925));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_recursive_entity */

EIF_REFERENCE F144_1669 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1669,RTMS_EX_H("Entity cannot be recursively included",37,830722148));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_doctype_external_no_resolver */

EIF_REFERENCE F144_1672 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1672,RTMS_EX_H("Parser is not configured to support external DTDs",49,264345715));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_doctype_undefined_pe_entity */

EIF_REFERENCE F144_1673 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1673,RTMS_EX_H("Undefined PE entity",19,1303207545));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_doctype_element */

EIF_REFERENCE F144_1674 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1674,RTMS_EX_H("Misformed element type declaration",34,2068678510));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_doctype_attribute */

EIF_REFERENCE F144_1675 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1675,RTMS_EX_H("Misformed attribute list declaration",36,1439973998));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_doctype_attribute_item */

EIF_REFERENCE F144_1676 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1676,RTMS_EX_H("Misformed attribute definition declaration",42,1870495598));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_doctype_entity */

EIF_REFERENCE F144_1677 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1677,RTMS_EX_H("Misformed entity declaration",28,1604395630));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_doctype_notation */

EIF_REFERENCE F144_1678 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1678,RTMS_EX_H("Misformed entity notation",25,1724650606));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_doctype_conditional_section */

EIF_REFERENCE F144_1679 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1679,RTMS_EX_H("Misformed conditional section",29,28963182));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_doctype_peref_only_in_dtd */

EIF_REFERENCE F144_1680 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1680,RTMS_EX_H("PE reference only allowed in DTD",32,2100959300));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_pi_xml_reserved */

EIF_REFERENCE F144_1681 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1681,RTMS_EX_H("xml prefix reserved in processing instruction",45,1396484718));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_namespaces_name_misformed */

EIF_REFERENCE F144_1683 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1683,RTMS_EX_H("Name misformed",14,1268274532));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_unicode_in_ascii_string_mode */

EIF_REFERENCE F144_1688 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1688,RTMS_EX_H("Unexpected non-ASCII character in ASCII-only mode",49,762535269));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_unicode_in_latin1_string_mode */

EIF_REFERENCE F144_1689 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1689,RTMS_EX_H("Unexpected non-latin1 character in latin1-only mode",51,1704080485));
}

/* {XM_EIFFEL_PARSER_ERRORS}.error_unicode_invalid_utf8 */

EIF_REFERENCE F144_1690 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (1690,RTMS_EX_H("Invalid UTF8 character sequence",31,933059941));
}

void EIF_Minit101 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
