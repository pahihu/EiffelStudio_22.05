/*
 * Code for class KL_SHARED_ARGUMENTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl132.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SHARED_ARGUMENTS}.arguments */
static EIF_REFERENCE F187_2122_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2122);
#define Result RTOSR(2122)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(427, 0x01).id, 427, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F428_3902(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2122);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F187_2122 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2122,F187_2122_body,(Current));
}

void EIF_Minit132 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
