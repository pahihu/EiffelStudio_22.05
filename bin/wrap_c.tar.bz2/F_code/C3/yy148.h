
#ifndef _C3_yy148_
#define _C3_yy148_

#ifdef __cplusplus
extern "C" {
#endif

extern void F203_2248(EIF_REFERENCE, EIF_REFERENCE);
extern void F203_2249(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F203_2250(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F203_2251(EIF_REFERENCE);
extern void F203_2254(EIF_REFERENCE, EIF_REFERENCE);
extern void F203_2255(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F203_2258(EIF_REFERENCE);
extern void EIF_Minit148(void);
extern EIF_INTEGER_32 F200_2237(EIF_REFERENCE);
extern EIF_REFERENCE F162_1753(EIF_REFERENCE);
extern void F200_2212(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_INTEGER_32,2237)
RTOSHF(EIF_REFERENCE,1753)
extern char *(*R1302[])();
extern char *(*R1851[])();
extern char *(*R1857[])();
extern char *(*R1859[])();
extern char *(*R2122[])();
extern char *(*R2124[])();
extern char *(*R2126[])();
extern char *(*R1860[])();
extern char *(*R1298[])();
extern char *(*R1299[])();
extern long O2107[];
extern long O2108[];

#ifdef __cplusplus
}
#endif

#endif
