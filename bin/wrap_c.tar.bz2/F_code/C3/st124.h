
#ifndef _C3_st124_
#define _C3_st124_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F179_1993(EIF_REFERENCE);
extern EIF_INTEGER_32 F179_1994(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit124(void);
extern char *(*R4960[])();
extern char *(*R5077[])();
extern char *(*R4923[])();

#ifdef __cplusplus
}
#endif

#endif
