/*
 * Code for class KL_PLATFORM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl139.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_PLATFORM}.minimum_character_code */
static EIF_INTEGER_32 F194_2200_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (2200);
#define Result RTOSR(2200)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTOSE (2200);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F194_2200 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2200,F194_2200_body,(Current));
}

/* {KL_PLATFORM}.maximum_character_code */
static EIF_INTEGER_32 F194_2201_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (2201);
#define Result RTOSR(2201)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 255L);
	RTOSE (2201);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F194_2201 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2201,F194_2201_body,(Current));
}

/* {KL_PLATFORM}.maximum_integer */
static EIF_INTEGER_32 F194_2203_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (2203);
#define Result RTOSR(2203)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	RTOSE (2203);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F194_2203 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2203,F194_2203_body,(Current));
}

void EIF_Minit139 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
