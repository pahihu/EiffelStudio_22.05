/*
 * Code for class XM_DTD_CALLBACKS_NULL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm103.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_DTD_CALLBACKS_NULL}.make */
void F146_1700 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {XM_DTD_CALLBACKS_NULL}.on_doctype */
void F146_1702 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	
	
	RTGC;
}

/* {XM_DTD_CALLBACKS_NULL}.on_element_declaration */
void F146_1703 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {XM_DTD_CALLBACKS_NULL}.on_attribute_declaration */
void F146_1704 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {XM_DTD_CALLBACKS_NULL}.on_entity_declaration */
void F146_1705 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	
	
	RTGC;
}

/* {XM_DTD_CALLBACKS_NULL}.on_notation_declaration */
void F146_1706 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {XM_DTD_CALLBACKS_NULL}.on_dtd_processing_instruction */
void F146_1707 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {XM_DTD_CALLBACKS_NULL}.on_dtd_comment */
void F146_1708 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {XM_DTD_CALLBACKS_NULL}.on_dtd_end */
void F146_1709 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

void EIF_Minit103 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
