
#ifndef _C3_pl138_
#define _C3_pl138_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F193_2140(EIF_REFERENCE);
RTOSHF (EIF_BOOLEAN,2145)
static EIF_BOOLEAN F193_2145_body(EIF_REFERENCE);
extern EIF_BOOLEAN F193_2145(EIF_REFERENCE);
extern EIF_INTEGER_32 F193_2160(EIF_REFERENCE);
extern void EIF_Minit138(void);

#ifdef __cplusplus
}
#endif

#endif
