/*
 * Code for class YY_UTF8_FILE_BUFFER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy149.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_UTF8_FILE_BUFFER}.fill */
void F204_2268 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc7 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_CHARACTER_8 tc3;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_))) {
		F204_2270(Current);
		loc3 = *(EIF_REFERENCE *)(Current);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_)) {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) == ((EIF_INTEGER_32) 1L))) {
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R1299[Dtype(RTCW(loc3))-334])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
			} else {
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) == ((EIF_INTEGER_32) 2L))) {
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
					loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)) + loc1);
					loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R1299[Dtype(RTCW(loc3))-334])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), loc6, loc1);
				} else {
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_6_) == ((EIF_INTEGER_32) 1L))) {
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R1299[Dtype(RTCW(loc3))-334])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
					} else {
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
						loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)) + loc1);
						loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R1299[Dtype(RTCW(loc3))-334])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), loc6, loc1);
					}
				}
			}
		} else {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) == ((EIF_INTEGER_32) 1L))) {
				loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
				loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R1299[Dtype(RTCW(loc3))-334])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
			} else {
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) == ((EIF_INTEGER_32) 2L))) {
					loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_);
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ti4_1) / ((EIF_INTEGER_32) 2L));
					loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
					loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)) + loc1);
					loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R1299[Dtype(RTCW(loc3))-334])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), loc6, loc1);
				} else {
					loc1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(6832,F993_6832, (Current)))+ _LNGOFF_1_1_0_2_);
					loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
					loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)) + loc1);
					loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R1299[Dtype(RTCW(loc3))-334])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), loc6, loc1);
					for (;;) {
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (loc2 >= loc1)) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1857[Dtype(RTCW(tr1))-1009])(tr1);
							tb1 = tb2;
						}
						if (tb1) break;
						ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R1299[Dtype(RTCW(loc3))-334])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (loc6 + loc2), (EIF_INTEGER_32) (loc1 - loc2));
						loc2 += ti4_1;
					}
					tb2 = '\0';
					if ((EIF_BOOLEAN) (loc2 >= loc1)) {
						tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R1296[Dtype(RTCW(loc3))-334])(loc3, loc6));
						tc2 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R1296[Dtype(RTCW(loc3))-334])(loc3, (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L))));
						tc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R1296[Dtype(RTCW(loc3))-334])(loc3, (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 2L))));
						tr1 = RTLNS(eif_new_type(992, 0x01).id, 992, _OBJSIZ_0_0_0_0_0_0_0_0_);
						tb2 = F993_6828(RTCW(tr1), tc1, tc2, tc3);
					}
					if (tb2) {
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_);
						ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
						loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R1299[Dtype(RTCW(loc3))-334])(loc3, *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
					} else {
						if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_6_) == ((EIF_INTEGER_32) 1L))) {
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						} else {
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
						}
					}
				}
			}
		}
		if ((EIF_BOOLEAN) (loc2 < loc1)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1857[Dtype(RTCW(tr1))-1009])(tr1);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_) = (EIF_BOOLEAN) tb2;
		}
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) == ((EIF_INTEGER_32) 2L))) {
			loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
			for (;;) {
				if ((EIF_BOOLEAN) (loc4 > loc2)) break;
				loc7 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R1296[Dtype(RTCW(loc3))-334])(loc3, loc6));
				loc8 = (EIF_INTEGER_32) (loc7);
				if ((EIF_BOOLEAN) (loc8 <= ((EIF_INTEGER_32) 127L))) {
					loc5++;
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1298[Dtype(RTCW(loc3))-334])(loc3, (EIF_REFERENCE) &loc7, loc5);
				} else {
					loc5++;
					tr1 = RTLNS(eif_new_type(1012, 0x01).id, 1012, _OBJSIZ_0_0_0_0_0_0_0_0_);
					tc1 = F1013_6993(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc8 / ((EIF_INTEGER_32) 64L)) + ((EIF_INTEGER_32) 192L)));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1298[Dtype(RTCW(loc3))-334])(loc3, (EIF_REFERENCE) &tc1, loc5);
					loc5++;
					tr1 = RTLNS(eif_new_type(1012, 0x01).id, 1012, _OBJSIZ_0_0_0_0_0_0_0_0_);
					tc1 = F1013_6993(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc8 % ((EIF_INTEGER_32) 64L)) + ((EIF_INTEGER_32) 128L)));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1298[Dtype(RTCW(loc3))-334])(loc3, (EIF_REFERENCE) &tc1, loc5);
				}
				loc6++;
				loc4++;
			}
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_) = (EIF_INTEGER_32) loc5;
		} else {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_)) += loc2;
		}
		if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		tc1 = (EIF_CHARACTER_8) '\000';
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1298[Dtype(RTCW(loc3))-334])(loc3, (EIF_REFERENCE) &tc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		tc1 = (EIF_CHARACTER_8) '\000';
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R1298[Dtype(RTCW(loc3))-334])(loc3, (EIF_REFERENCE) &tc1, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
	} else {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

/* {YY_UTF8_FILE_BUFFER}.flush */
void F204_2269 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F200_2231(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {YY_UTF8_FILE_BUFFER}.compact_left */
void F204_2270 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) == ((EIF_INTEGER_32) 1L))) {
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_7_) == ((EIF_INTEGER_32) 2L))) {
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		} else {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_)) {
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
			} else {
				loc2 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(6832,F993_6832, (Current)))+ _LNGOFF_1_1_0_2_);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 * ((EIF_INTEGER_32) 2L));
			}
		}
	}
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_5_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ti4_1) + ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + loc2) > loc3)) {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_) == ((EIF_INTEGER_32) 0L))) {
			ti4_1 = RTOSCF(2237,F200_2237, (Current));
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_) = (EIF_INTEGER_32) ti4_1;
		} else {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_)) *= ((EIF_INTEGER_32) 2L);
		}
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_) < (EIF_INTEGER_32) (loc3 + loc2))) {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + loc2);
		}
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1297[Dtype(RTCW(tr1))-334])(tr1);
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_) + ((EIF_INTEGER_32) 2L)) > ti4_1)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R1302[Dtype(RTCW(tr1))-334])(tr1, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_1_) + ((EIF_INTEGER_32) 2L)));
		}
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_5_) != ((EIF_INTEGER_32) 1L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R1300[Dtype(RTCW(tr1))-334])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_5_), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_4_0_0_) = (EIF_INTEGER_32) loc1;
	}
	RTLE;
}

void EIF_Minit149 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
