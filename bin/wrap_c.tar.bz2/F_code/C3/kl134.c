/*
 * Code for class KL_SHARED_EXCEPTIONS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl134.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SHARED_EXCEPTIONS}.exceptions */
static EIF_REFERENCE F189_2124_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2124);
#define Result RTOSR(2124)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(230, 0x01).id, 230, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2124);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F189_2124 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2124,F189_2124_body,(Current));
}

void EIF_Minit134 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
