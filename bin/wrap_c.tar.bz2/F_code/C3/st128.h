
#ifndef _C3_st128_
#define _C3_st128_

#ifdef __cplusplus
extern "C" {
#endif

extern void F183_2040(EIF_REFERENCE, EIF_BOOLEAN);
extern void F183_2041(EIF_REFERENCE, EIF_BOOLEAN);
extern void F183_2042(EIF_REFERENCE, EIF_REFERENCE);
extern void F183_2043(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit128(void);
extern void F985_6614(EIF_REFERENCE, EIF_REFERENCE);
extern long O1967[];
extern long O1968[];

#ifdef __cplusplus
}
#endif

#endif
