
#ifndef _C3_yy149_
#define _C3_yy149_

#ifdef __cplusplus
extern "C" {
#endif

extern void F204_2268(EIF_REFERENCE);
extern void F204_2269(EIF_REFERENCE);
extern void F204_2270(EIF_REFERENCE);
extern void EIF_Minit149(void);
extern EIF_CHARACTER_8 F1013_6993(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F993_6832(EIF_REFERENCE);
extern EIF_INTEGER_32 F200_2237(EIF_REFERENCE);
extern void F200_2231(EIF_REFERENCE);
extern EIF_BOOLEAN F993_6828(EIF_REFERENCE, EIF_CHARACTER_8, EIF_CHARACTER_8, EIF_CHARACTER_8);
RTOSHF(EIF_REFERENCE,6832)
RTOSHF(EIF_INTEGER_32,2237)
extern char *(*R1300[])();
extern char *(*R1302[])();
extern char *(*R1857[])();
extern char *(*R1296[])();
extern char *(*R1297[])();
extern char *(*R1298[])();
extern char *(*R1299[])();

#ifdef __cplusplus
}
#endif

#endif
