/*
 * Code for class EWG_C_AST_DECLARATION_SET
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew117.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EWG_C_AST_DECLARATION_SET}.make */
void F172_1920 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1275,0xFF01,899,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1269_9027(RTCW(tr1), ((EIF_INTEGER_32) 10000L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = RTOSCF(1918,F171_1918, (Current));
	F1212_8536(RTCW(tr1), tr2);
	RTLE;
}

/* {EWG_C_AST_DECLARATION_SET}.count */
EIF_INTEGER_32 F172_1923 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_7_0_0_8_);
	RTLE;
	return Result;
}

/* {EWG_C_AST_DECLARATION_SET}.function_declaration_count */
EIF_INTEGER_32 F172_1924 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F172_1928(Current);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6536[Dtype(RTCW(tr1))-1228])(tr1);
	RTLE;
	return Result;
}

/* {EWG_C_AST_DECLARATION_SET}.new_cursor */
EIF_REFERENCE F172_1925 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1276_9178(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EWG_C_AST_DECLARATION_SET}.new_function_declaration_cursor */
EIF_REFERENCE F172_1926 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = F172_1928(Current);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6568[Dtype(RTCW(tr1))-1228])(tr1);
	RTLE;
	return Result;
}

/* {EWG_C_AST_DECLARATION_SET}.add_declaration */
void F172_1927 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F1274_9123(RTCW(tr1), arg1);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F1274_9121(RTCW(tr1), arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F1274_9133(RTCW(tr1), arg1);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	}
	RTLE;
}

/* {EWG_C_AST_DECLARATION_SET}.function_declarations */
EIF_REFERENCE F172_1928 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1275,0xFF01,900,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 1275, _OBJSIZ_7_0_0_9_0_0_0_0_);
	}
	F1269_9027(RTCW(loc1), ((EIF_INTEGER_32) 10000L));
	tr1 = RTOSCF(1919,F171_1919, (Current));
	F1212_8536(RTCW(loc1), tr1);
	loc2 = F172_1925(Current);
	F1119_8288(RTCW(loc2));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6382[Dtype(RTCW(loc2))-1130])(loc2);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3320[Dtype(RTCW(loc2))-401])(loc2);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(900, 0x01),loc3);
		if (EIF_TEST(loc3)) {
			F1274_9133(RTCW(loc1), loc3);
		}
		F1119_8289(RTCW(loc2));
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

void EIF_Minit117 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
