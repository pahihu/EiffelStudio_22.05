
#ifndef _C3_ew116_
#define _C3_ew116_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,1918)
static EIF_REFERENCE F171_1918_body(EIF_REFERENCE);
extern EIF_REFERENCE F171_1918(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,1919)
static EIF_REFERENCE F171_1919_body(EIF_REFERENCE);
extern EIF_REFERENCE F171_1919(EIF_REFERENCE);
extern void EIF_Minit116(void);

#ifdef __cplusplus
}
#endif

#endif
