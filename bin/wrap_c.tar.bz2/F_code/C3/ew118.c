/*
 * Code for class EWG_C_AST_SHARED_TYPE_EQUALITY_TESTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ew118.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EWG_C_AST_SHARED_TYPE_EQUALITY_TESTER}.type_equality_tester */
static EIF_REFERENCE F173_1931_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1931);
#define Result RTOSR(1931)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,309,0xFF01,1039,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 309, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1931);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F173_1931 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1931,F173_1931_body,(Current));
}

/* {EWG_C_AST_SHARED_TYPE_EQUALITY_TESTER}.struct_equality_tester */
static EIF_REFERENCE F173_1932_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1932);
#define Result RTOSR(1932)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,309,0xFF01,1057,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 309, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1932);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F173_1932 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1932,F173_1932_body,(Current));
}

/* {EWG_C_AST_SHARED_TYPE_EQUALITY_TESTER}.union_equality_tester */
static EIF_REFERENCE F173_1933_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1933);
#define Result RTOSR(1933)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,309,0xFF01,1059,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 309, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1933);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F173_1933 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1933,F173_1933_body,(Current));
}

/* {EWG_C_AST_SHARED_TYPE_EQUALITY_TESTER}.enum_equality_tester */
static EIF_REFERENCE F173_1934_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1934);
#define Result RTOSR(1934)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,309,0xFF01,1058,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 309, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1934);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F173_1934 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1934,F173_1934_body,(Current));
}

/* {EWG_C_AST_SHARED_TYPE_EQUALITY_TESTER}.primitive_equality_tester */
static EIF_REFERENCE F173_1935_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1935);
#define Result RTOSR(1935)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,309,0xFF01,1041,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 309, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1935);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F173_1935 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1935,F173_1935_body,(Current));
}

/* {EWG_C_AST_SHARED_TYPE_EQUALITY_TESTER}.alias_equality_tester */
static EIF_REFERENCE F173_1936_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1936);
#define Result RTOSR(1936)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,309,0xFF01,1046,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 309, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1936);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F173_1936 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1936,F173_1936_body,(Current));
}

/* {EWG_C_AST_SHARED_TYPE_EQUALITY_TESTER}.function_equality_tester */
static EIF_REFERENCE F173_1937_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1937);
#define Result RTOSR(1937)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,309,0xFF01,1055,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 309, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1937);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F173_1937 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1937,F173_1937_body,(Current));
}

/* {EWG_C_AST_SHARED_TYPE_EQUALITY_TESTER}.pointer_equality_tester */
static EIF_REFERENCE F173_1938_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (1938);
#define Result RTOSR(1938)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,309,0xFF01,1053,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 309, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (1938);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F173_1938 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(1938,F173_1938_body,(Current));
}

void EIF_Minit118 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
