
#ifndef _C3_yy145_
#define _C3_yy145_

#ifdef __cplusplus
extern "C" {
#endif

extern void F200_2212(EIF_REFERENCE, EIF_REFERENCE);
extern void F200_2213(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F200_2214(EIF_REFERENCE);
extern void F200_2224(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F200_2225(EIF_REFERENCE, EIF_INTEGER_32);
extern void F200_2226(EIF_REFERENCE, EIF_BOOLEAN);
extern void F200_2230(EIF_REFERENCE);
extern void F200_2231(EIF_REFERENCE);
extern void F200_2233(EIF_REFERENCE);
extern EIF_REFERENCE F200_2235(EIF_REFERENCE, EIF_INTEGER_32);
extern void F200_2236(EIF_REFERENCE);
RTOSHF (EIF_INTEGER_32,2237)
static EIF_INTEGER_32 F200_2237_body(EIF_REFERENCE);
extern EIF_INTEGER_32 F200_2237(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 2239)


extern EIF_REFERENCE F200_2239(EIF_REFERENCE);
extern void EIF_Minit145(void);
extern void F336_3391(EIF_REFERENCE, EIF_INTEGER_32);
extern void F98_1318(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R1300[])();
extern char *(*R1302[])();
extern char *(*R2126[])();
extern char *(*R1297[])();
extern char *(*R1298[])();
extern long O2107[];
extern long O2108[];
extern long O2109[];
extern long O2110[];
extern long O2111[];
extern long O2112[];
extern long O2113[];
extern long O2118[];

#ifdef __cplusplus
}
#endif

#endif
