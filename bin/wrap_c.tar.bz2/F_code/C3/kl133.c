/*
 * Code for class KL_SHARED_OPERATING_SYSTEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl133.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SHARED_OPERATING_SYSTEM}.operating_system */
static EIF_REFERENCE F188_2123_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2123);
#define Result RTOSR(2123)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(24, 0x01).id, 24, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2123);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F188_2123 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2123,F188_2123_body,(Current));
}

void EIF_Minit133 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
