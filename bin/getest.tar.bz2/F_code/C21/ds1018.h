
#ifndef _C21_ds1018_
#define _C21_ds1018_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1237_11471(EIF_REFERENCE);
extern void EIF_Minit1018(void);
extern char *(*R9283[])();

#ifdef __cplusplus
}
#endif

#endif
