
#ifndef _C21_ds1048_
#define _C21_ds1048_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1156_11176(EIF_REFERENCE, EIF_REFERENCE);
extern void F1156_11177(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1156_11178(EIF_REFERENCE);
extern EIF_BOOLEAN F1156_11179(EIF_REFERENCE);
extern EIF_BOOLEAN F1156_11180(EIF_REFERENCE);
extern void EIF_Minit1048(void);
extern char *(*R4738[])();
extern char *(*R9315[])();
extern char *(*R9047[])();

#ifdef __cplusplus
}
#endif

#endif
