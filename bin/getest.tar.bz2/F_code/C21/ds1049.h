
#ifndef _C21_ds1049_
#define _C21_ds1049_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1186_11207(EIF_REFERENCE);
extern void EIF_Minit1049(void);
extern char *(*R9372[])();

#ifdef __cplusplus
}
#endif

#endif
