
#ifndef _C21_kl1019_
#define _C21_kl1019_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F352_5238(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1019(void);

#ifdef __cplusplus
}
#endif

#endif
