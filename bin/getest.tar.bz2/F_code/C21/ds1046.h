
#ifndef _C21_ds1046_
#define _C21_ds1046_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1356_12165(EIF_REFERENCE);
extern EIF_INTEGER_32 F1356_12168(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1046(void);
extern char *(*R6305[])();
extern char *(*R9059[])();
extern EIF_TYPE_INDEX Y1385[];
extern EIF_TYPE_INDEX *Y1385_gen_type [];
extern EIF_TYPE_INDEX Y9292[];
extern EIF_TYPE_INDEX *Y9292_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
