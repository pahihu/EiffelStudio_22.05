
#ifndef _C21_to1021_
#define _C21_to1021_

#ifdef __cplusplus
extern "C" {
#endif

extern void F304_4782(EIF_REFERENCE, EIF_INTEGER_32);
extern void F304_4783(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F304_4789(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1021(void);
extern char *(*R5287[])();
extern EIF_TYPE_INDEX Y4339[];
extern EIF_TYPE_INDEX *Y4339_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
