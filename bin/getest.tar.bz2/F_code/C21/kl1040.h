
#ifndef _C21_kl1040_
#define _C21_kl1040_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1041_9403(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1041_9407(EIF_REFERENCE, EIF_REFERENCE);
extern void F1041_9408(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1041_9410(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit1040(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R5185[])();
extern char *(*R5157[])();
extern char *(*R5171[])();
extern char *(*R5195[])();
extern char *(*R5160[])();

#ifdef __cplusplus
}
#endif

#endif
