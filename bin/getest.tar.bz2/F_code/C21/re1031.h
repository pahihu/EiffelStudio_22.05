
#ifndef _C21_re1031_
#define _C21_re1031_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F651_5533(EIF_REFERENCE);
extern void EIF_Minit1031(void);
extern char *(*R4926[])();

#ifdef __cplusplus
}
#endif

#endif
