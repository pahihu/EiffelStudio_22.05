
#ifndef _C21_ds1037_
#define _C21_ds1037_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1127_11140(EIF_REFERENCE);
extern EIF_BOOLEAN F1127_11143(EIF_REFERENCE, EIF_REFERENCE);
extern void F1127_11146(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1127_11147(EIF_REFERENCE, EIF_REFERENCE);
extern void F1127_11149(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1037(void);
extern EIF_REFERENCE F1037_9359(EIF_REFERENCE);
extern EIF_BOOLEAN F21_186(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,9359)
extern char *(*R9030[])();
extern char *(*R9031[])();
extern char *(*R9322[])();
extern char *(*R9324[])();
extern char *(*R9326[])();
extern char *(*R9327[])();
extern char *(*R9029[])();

#ifdef __cplusplus
}
#endif

#endif
