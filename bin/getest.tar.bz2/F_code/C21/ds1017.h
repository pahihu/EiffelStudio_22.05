
#ifndef _C21_ds1017_
#define _C21_ds1017_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1260_11519(EIF_REFERENCE, EIF_REFERENCE);
extern void F1260_11523(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1017(void);

#ifdef __cplusplus
}
#endif

#endif
