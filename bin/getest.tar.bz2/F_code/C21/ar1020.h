
#ifndef _C21_ar1020_
#define _C21_ar1020_

#ifdef __cplusplus
extern "C" {
#endif

extern void F715_5936(EIF_REFERENCE);
extern void F715_5937(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F715_5938(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F715_5939(EIF_REFERENCE, EIF_REFERENCE);
extern void F715_5940(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F715_5942(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F715_5947(EIF_REFERENCE);
extern EIF_INTEGER_32 F715_5948(EIF_REFERENCE);
extern EIF_INTEGER_32 F715_5949(EIF_REFERENCE);
extern EIF_INTEGER_32 F715_5950(EIF_REFERENCE);
extern EIF_BOOLEAN F715_5952(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F715_5957(EIF_REFERENCE, EIF_INTEGER_32);
extern void F715_5961(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F715_5963(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F715_5966(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F715_5982(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F715_5990(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F715_5994(EIF_REFERENCE);
extern void EIF_Minit1020(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R5133[])();
extern char *(*R5296[])();
extern char *(*R5297[])();
extern char *(*R5299[])();
extern char *(*R5304[])();
extern char *(*R4337[])();
extern char *(*R4338[])();
extern char *(*R5301[])();
extern char *(*R5192[])();
extern char *(*R5305[])();
extern char *(*R4923[])();
extern char *(*R4926[])();
extern char *(*R4344[])();
extern char *(*R4896[])();
extern char *(*R5314[])();
extern char *(*R5315[])();
extern char *(*R4930[])();
extern char *(*R5283[])();
extern char *(*R5284[])();
extern char *(*R6406[])();
extern EIF_TYPE_INDEX Y4760[];
extern EIF_TYPE_INDEX *Y4760_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
