
#ifndef _C21_ds1047_
#define _C21_ds1047_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1278_11562(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1278_11565(EIF_REFERENCE);
extern EIF_INTEGER_32 F1278_11566(EIF_REFERENCE);
extern EIF_BOOLEAN F1278_11575(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1278_11576(EIF_REFERENCE, EIF_REFERENCE);
extern void F1278_11577(EIF_REFERENCE, EIF_REFERENCE);
extern void F1278_11579(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1278_11580(EIF_REFERENCE);
extern EIF_REFERENCE F1278_11581(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1278_11582(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1278_11583(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1278_11584(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1278_11585(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1278_11586(EIF_REFERENCE, EIF_REFERENCE);
extern void F1278_11587(EIF_REFERENCE, EIF_REFERENCE);
extern void F1278_11588(EIF_REFERENCE, EIF_REFERENCE);
extern void F1278_11589(EIF_REFERENCE, EIF_REFERENCE);
extern void F1278_11592(EIF_REFERENCE, EIF_REFERENCE);
extern void F1278_11596(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1047(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R11[])();
extern char *(*R18[])();
extern char *(*R9031[])();
extern char *(*R9320[])();
extern char *(*R4737[])();
extern char *(*R4738[])();
extern char *(*R4739[])();
extern char *(*R9052[])();
extern char *(*R9053[])();
extern char *(*R9057[])();
extern char *(*R9315[])();
extern char *(*R9600[])();
extern char *(*R9365[])();
extern char *(*R9366[])();
extern char *(*R9042[])();
extern char *(*R9043[])();
extern char *(*R9045[])();
extern char *(*R9046[])();
extern char *(*R9048[])();
extern char *(*R9049[])();
extern EIF_TYPE_INDEX Y9292[];
extern EIF_TYPE_INDEX *Y9292_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
