
#ifndef _C21_kl1041_
#define _C21_kl1041_

#ifdef __cplusplus
extern "C" {
#endif

extern void F727_5995(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1041(void);

#ifdef __cplusplus
}
#endif

#endif
