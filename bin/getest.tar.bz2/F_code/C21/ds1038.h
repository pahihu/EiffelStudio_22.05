
#ifndef _C21_ds1038_
#define _C21_ds1038_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1254_11502(EIF_REFERENCE);
extern EIF_BOOLEAN F1254_11506(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1254_11511(EIF_REFERENCE, EIF_REFERENCE);
extern void F1254_11514(EIF_REFERENCE, EIF_REFERENCE);
extern void F1254_11515(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1038(void);
extern char *(*R9030[])();
extern char *(*R9035[])();
extern char *(*R9321[])();
extern char *(*R9322[])();
extern char *(*R9029[])();

#ifdef __cplusplus
}
#endif

#endif
