
#ifndef _C21_ds1035_
#define _C21_ds1035_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1266_11526(EIF_REFERENCE);
extern EIF_BOOLEAN F1266_11528(EIF_REFERENCE);
extern void F1266_11531(EIF_REFERENCE);
extern void F1266_11532(EIF_REFERENCE);
extern void F1266_11534(EIF_REFERENCE);
extern EIF_BOOLEAN F1266_11543(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1035(void);
extern char *(*R9351[])();
extern char *(*R9321[])();
extern char *(*R4738[])();
extern char *(*R9347[])();
extern char *(*R9348[])();
extern char *(*R9349[])();
extern char *(*R9315[])();
extern char *(*R9043[])();

#ifdef __cplusplus
}
#endif

#endif
