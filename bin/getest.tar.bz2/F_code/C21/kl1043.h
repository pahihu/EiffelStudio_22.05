
#ifndef _C21_kl1043_
#define _C21_kl1043_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F36_474(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F36_477(EIF_REFERENCE, EIF_REFERENCE);
extern void F36_479(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F36_480(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F36_482(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F36_483(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1043(void);
extern char *(*R5297[])();
extern char *(*R5301[])();
extern char *(*R5308[])();
extern char *(*R5314[])();
extern char *(*R5315[])();
extern char *(*R5283[])();
extern char *(*R5284[])();

#ifdef __cplusplus
}
#endif

#endif
