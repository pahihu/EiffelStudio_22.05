/*
 * Code for class DS_HASH_TABLE [G#1, G#2]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1046.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_HASH_TABLE}.new_cursor */
EIF_REFERENCE F1356_12165 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1201,0,0,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y9292,Y9292_gen_type,Dftype(Current),1236);
			typarr0[2] = l_type.annotations | 0xFF00;
			typarr0[3] = l_type.id;
		}
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y1385,Y1385_gen_type,Dftype(Current),137);
			typarr0[4] = l_type.annotations | 0xFF00;
			typarr0[5] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 1201, _OBJSIZ_2_0_0_1_0_0_0_0_);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9059[Dtype(RTCW(tr1))-1183])(tr1, Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {DS_HASH_TABLE}.hash_position */
EIF_INTEGER_32 F1356_12168 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = RTCCL(arg1);
			Result = (RTNA((loc1, tr1)), ((EIF_INTEGER_32) 0));
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_1_);
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ti4_1);
		} else {
			Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6305[Dtype(RTCW(arg1))-911])(arg1);
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_1_);
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ti4_1);
		}
	} else {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_1_);
		RTLE;
		return (EIF_INTEGER_32) Result;
	}
	RTLE;
	return Result;
}

void EIF_Minit1046 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
