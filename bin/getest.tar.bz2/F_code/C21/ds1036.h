
#ifndef _C21_ds1036_
#define _C21_ds1036_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1142_11157(EIF_REFERENCE);
extern void F1142_11160(EIF_REFERENCE);
extern void F1142_11161(EIF_REFERENCE);
extern void F1142_11163(EIF_REFERENCE);
extern void EIF_Minit1036(void);
extern char *(*R9351[])();
extern char *(*R9346[])();
extern char *(*R9348[])();
extern char *(*R9349[])();
extern char *(*R9029[])();

#ifdef __cplusplus
}
#endif

#endif
