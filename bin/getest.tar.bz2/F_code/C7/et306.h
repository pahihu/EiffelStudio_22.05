
#ifndef _C7_et306_
#define _C7_et306_

#ifdef __cplusplus
extern "C" {
#endif

extern void F903_7402(EIF_REFERENCE, EIF_REFERENCE);
extern void F903_7403(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F903_7404(EIF_REFERENCE, EIF_REFERENCE);
extern void F903_7405(EIF_REFERENCE, EIF_REFERENCE);
extern void F903_7406(EIF_REFERENCE, EIF_REFERENCE);
extern void F903_7407(EIF_REFERENCE, EIF_REFERENCE);
extern void F903_7408(EIF_REFERENCE, EIF_REFERENCE);
extern void F903_7409(EIF_REFERENCE, EIF_REFERENCE);
extern void F903_7410(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit306(void);
extern void F1768_17276(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1769_17321(EIF_REFERENCE);
extern void F1768_17289(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F875_6913(EIF_REFERENCE);
extern void F875_6911(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1769_17332(EIF_REFERENCE);
extern void F1772_17710(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R11118[])();
extern char *(*R10237[])();
extern char *(*R11236[])();
extern char *(*R11238[])();
extern char *(*R12763[])();
extern char *(*R12764[])();
extern char *(*R11220[])();
extern long O12762[];
extern long O12766[];

#ifdef __cplusplus
}
#endif

#endif
