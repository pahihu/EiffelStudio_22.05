
#ifndef _C7_et311_
#define _C7_et311_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F909_7492(EIF_REFERENCE, EIF_INTEGER_32);
RTOSHF (EIF_REFERENCE,7493)
static EIF_REFERENCE F909_7493_body(EIF_REFERENCE);
extern EIF_REFERENCE F909_7493(EIF_REFERENCE);
extern void EIF_Minit311(void);

#ifdef __cplusplus
}
#endif

#endif
