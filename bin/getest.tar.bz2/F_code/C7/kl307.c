/*
 * Code for class KL_IMPORTED_INTEGER_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl307.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_IMPORTED_INTEGER_ROUTINES}.integer_ */
static EIF_REFERENCE F904_7412_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (7412);
#define Result RTOSR(7412)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1060, 0x01).id, 1060, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (7412);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F904_7412 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(7412,F904_7412_body,(Current));
}

void EIF_Minit307 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
