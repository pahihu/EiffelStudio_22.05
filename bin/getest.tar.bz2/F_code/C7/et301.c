/*
 * Code for class ET_FEATURE_ADAPTATION_RESOLVER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et301.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_FEATURE_ADAPTATION_RESOLVER}.make */
void F898_7306 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	F875_6911(Current, arg1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1355,0xFF01,1421,0xFF01,1682,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1340_12088(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTOSCF(5041,F327_5041, (Current));
	F1340_12106(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1337,0xFF01,1682,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1326_11930(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = RTOSCF(5041,F327_5041, (Current));
	F1260_11523(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1360,983,0xFF01,1682,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1345_12088(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = RTOSCF(5041,F327_5041, (Current));
	F1345_12106(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1360,983,0xFF01,1682,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1345_12088(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = RTOSCF(5041,F327_5041, (Current));
	F1345_12106(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1360,983,0xFF01,1682,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1345_12088(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr2 = RTOSCF(5041,F327_5041, (Current));
	F1345_12106(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1357,0xFF01,1117,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1342_12088(RTCW(tr1), ((EIF_INTEGER_32) 400L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {ET_FEATURE_ADAPTATION_RESOLVER}.resolve_feature_adaptations */
void F898_7307 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_14_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = *(EIF_REFERENCE *)(Current);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	F898_7308(Current, arg2);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc4 = F1772_17609(RTCW(tr1));
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc3 > loc4)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		loc2 = F1772_17610(RTCW(tr1), loc3);
		loc6 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_3_0_0_0_);
		loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc5 > loc6)) break;
			tr1 = F1412_13191(RTCW(loc2), loc5);
			F898_7309(Current, tr1, arg2);
			loc5++;
		}
		loc3++;
	}
	F898_7321(Current, arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	RTLE;
}

/* {ET_FEATURE_ADAPTATION_RESOLVER}.add_current_features */
void F898_7308 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(13);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,arg1);
	RTLR(5,loc1);
	RTLR(6,loc6);
	RTLR(7,loc5);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLR(10,loc14);
	RTLR(11,loc7);
	RTLR(12,loc3);
	RTLIU(13);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_25_);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_26_);
	loc9 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_1_);
	loc10 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_0_0_1_);
	loc11 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_11_0_0_8_);
	loc11 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc9 + loc10) + loc11);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_11_0_0_7_);
	if ((EIF_BOOLEAN) (ti4_1 < loc11)) {
		F1326_11954(RTCW(arg1), loc11);
	}
	loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc8 > loc9)) break;
		loc1 = F910_7494(RTCW(loc2), loc8);
		loc6 = F1610_14386(RTCW(loc1));
		F1340_12104(RTCW(arg1), loc6);
		tb1 = F1326_11939(RTCW(arg1));
		if (tb1) {
			F885_7075(Current);
			loc5 = F1326_11931(RTCW(arg1));
			tr1 = F875_6917(Current);
			tr2 = *(EIF_REFERENCE *)(Current);
			tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8998[Dtype(RTCW(loc5))-1124])(loc5);
			F1764_16726(RTCW(tr1), tr2, tr3, loc1);
		} else {
			F1340_12112(RTCW(arg1), loc1, loc6);
			tr1 = F1610_14388(RTCW(loc1));
			loc14 = tr1;
			if (EIF_TEST(loc14)) {
				loc13 = *(EIF_INTEGER_32 *)(loc14+ _LNGOFF_1_0_0_0_);
				loc12 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc12 > loc13)) break;
					loc7 = F905_7415(loc14, loc12);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10975[Dtype(RTCW(loc1))-1613])(loc1);
					if (tb1) {
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11413[Dtype(RTCW(loc7))-1679])(loc7);
						if (tb1) {
							(FUNCTION_CAST(void, (EIF_REFERENCE)) R11424[Dtype(RTCW(loc7))-1679])(loc7);
						}
					} else {
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10976[Dtype(RTCW(loc1))-1613])(loc1);
						if (tb1) {
							tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11412[Dtype(RTCW(loc7))-1679])(loc7);
							if (tb1) {
								(FUNCTION_CAST(void, (EIF_REFERENCE)) R11423[Dtype(RTCW(loc7))-1679])(loc7);
							}
						}
					}
					loc12++;
				}
			}
		}
		loc8++;
	}
	loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc8 > loc10)) break;
		loc3 = F909_7492(RTCW(loc4), loc8);
		loc6 = F1610_14386(RTCW(loc3));
		F1340_12104(RTCW(arg1), loc6);
		tb1 = F1326_11939(RTCW(arg1));
		if (tb1) {
			F885_7075(Current);
			loc5 = F1326_11931(RTCW(arg1));
			tr1 = F875_6917(Current);
			tr2 = *(EIF_REFERENCE *)(Current);
			tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8998[Dtype(RTCW(loc5))-1124])(loc5);
			F1764_16726(RTCW(tr1), tr2, tr3, loc3);
		} else {
			F1340_12112(RTCW(arg1), loc3, loc6);
		}
		loc8++;
	}
	RTLE;
}

/* {ET_FEATURE_ADAPTATION_RESOLVER}.add_inherited_features */
void F898_7309 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc20 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc21 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc22 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc23 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc24 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc25 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc26 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc27 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc28 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	RTLD;
	
	RTLI(18);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,loc10);
	RTLR(5,loc12);
	RTLR(6,arg2);
	RTLR(7,loc11);
	RTLR(8,loc17);
	RTLR(9,loc18);
	RTLR(10,loc19);
	RTLR(11,loc24);
	RTLR(12,loc25);
	RTLR(13,loc28);
	RTLR(14,loc14);
	RTLR(15,loc15);
	RTLR(16,loc16);
	RTLR(17,loc13);
	RTLIU(18);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		F898_7315(Current, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc2 = F1237_11471(RTCW(tr1));
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc2;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		F898_7316(Current, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc3 = F1237_11471(RTCW(tr1));
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc3;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		F898_7317(Current, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc8 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_11_0_0_8_);
		loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc8 > ((EIF_INTEGER_32) 0L));
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		F898_7318(Current, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc7 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_11_0_0_8_);
		loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 0L));
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		F898_7319(Current, arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc9 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_11_0_0_8_);
		loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc9 > ((EIF_INTEGER_32) 0L));
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc1 = F1769_17321(RTCW(tr1));
	loc10 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_25_);
	loc12 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_26_);
	loc21 = *(EIF_INTEGER_32 *)(RTCW(loc10)+ _LNGOFF_1_0_0_0_);
	loc22 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_1_0_0_0_);
	loc23 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_11_0_0_8_);
	loc23 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc21 + loc22) + loc23);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_11_0_0_7_);
	if ((EIF_BOOLEAN) (ti4_1 < loc23)) {
		F1326_11954(RTCW(arg2), loc23);
	}
	loc20 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc20 > loc21)) break;
		loc11 = F910_7494(RTCW(loc10), loc20);
		loc17 = F898_7324(Current, loc11, arg1);
		loc18 = F1610_14386(RTCW(loc11));
		if (loc2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1340_12104(RTCW(tr1), loc18);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tb1 = F1326_11939(RTCW(tr1));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc19 = F1326_11931(RTCW(tr1));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1326_11952(RTCW(tr1));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc2 = F1237_11471(RTCW(tr1));
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc2;
				F23_221(RTCW(loc17), loc19);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc19));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc11) + O8996[Dtype(loc11)-1122]);
				F1679_15285(RTCW(tr1), ti4_1);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc19) + _REFACS_1_);
				loc18 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10815[Dtype(RTCW(tr1))-1590])(tr1);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc11) + O8996[Dtype(loc11)-1122]);
				F1679_15285(RTCW(loc18), ti4_1);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc19) + _REFACS_1_);
				loc24 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10816[Dtype(RTCW(tr1))-1590])(tr1);
				if ((EIF_BOOLEAN)(loc24 != NULL)) {
					loc27 = *(EIF_INTEGER_32 *)(RTCW(loc24)+ _LNGOFF_1_0_0_0_);
					loc26 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc26 > loc27)) break;
						loc25 = F905_7415(RTCW(loc24), loc26);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10975[Dtype(RTCW(loc11))-1613])(loc11);
						if (tb1) {
							tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11413[Dtype(RTCW(loc25))-1679])(loc25);
							if (tb1) {
								(FUNCTION_CAST(void, (EIF_REFERENCE)) R11424[Dtype(RTCW(loc25))-1679])(loc25);
							}
						} else {
							tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10976[Dtype(RTCW(loc11))-1613])(loc11);
							if (tb1) {
								tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11412[Dtype(RTCW(loc25))-1679])(loc25);
								if (tb1) {
									(FUNCTION_CAST(void, (EIF_REFERENCE)) R11423[Dtype(RTCW(loc25))-1679])(loc25);
								}
							}
						}
						loc26++;
					}
				}
			}
		}
		if (loc3) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1334_12030(RTCW(tr1), loc18);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tb1 = F1326_11939(RTCW(tr1));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tr1 = F1326_11931(RTCW(tr1));
				loc28 = F1683_15423(RTCW(tr1));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc11) + O8996[Dtype(loc11)-1122]);
				F1679_15285(RTCW(loc28), ti4_1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				F1326_11952(RTCW(tr1));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				loc3 = F1237_11471(RTCW(tr1));
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc3;
			}
		}
		if (loc5) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			F1345_12104(RTCW(tr1), loc18);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tb1 = F1332_11939(RTCW(tr1));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				tr1 = F1345_12096(RTCW(tr1));
				loc28 = F1683_15423(RTCW(tr1));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc11) + O8996[Dtype(loc11)-1122]);
				F1679_15285(RTCW(loc28), ti4_1);
				F23_222(RTCW(loc17), loc28);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				tb1 = F1332_11931(RTCW(tr1));
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
					F1345_12108(RTCW(tr1), (EIF_BOOLEAN) 1);
					loc8--;
				}
			}
		}
		if (loc4) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			F1345_12104(RTCW(tr1), loc18);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			tb1 = F1332_11939(RTCW(tr1));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				tr1 = F1345_12096(RTCW(tr1));
				loc28 = F1683_15423(RTCW(tr1));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc11) + O8996[Dtype(loc11)-1122]);
				F1679_15285(RTCW(loc28), ti4_1);
				F23_223(RTCW(loc17), loc28);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				tb1 = F1332_11931(RTCW(tr1));
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					F1345_12108(RTCW(tr1), (EIF_BOOLEAN) 1);
					loc7--;
				}
			}
		}
		if (loc6) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			F1345_12104(RTCW(tr1), loc18);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tb1 = F1332_11939(RTCW(tr1));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				tr1 = F1345_12096(RTCW(tr1));
				loc28 = F1683_15423(RTCW(tr1));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc11) + O8996[Dtype(loc11)-1122]);
				F1679_15285(RTCW(loc28), ti4_1);
				F23_224(RTCW(loc17), loc28);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				tb1 = F1332_11931(RTCW(tr1));
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					F1345_12108(RTCW(tr1), (EIF_BOOLEAN) 1);
					loc9--;
				}
			}
		}
		F1340_12104(RTCW(arg2), loc18);
		tb1 = F1326_11939(RTCW(arg2));
		if (tb1) {
			loc14 = F1326_11931(RTCW(arg2));
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8986[Dtype(RTCW(loc14))-1124])(loc14);
			if (tb1) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8999[Dtype(RTCW(loc14))-1124])(loc14);
				loc15 = F898_7326(Current, tr1, loc17);
				F1340_12108(RTCW(arg2), loc15);
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9002[Dtype(RTCW(loc14))-1124])(loc14);
				F1124_11123(RTCW(tr1), loc17);
			}
		} else {
			loc16 = F898_7325(Current, loc17);
			F1340_12112(RTCW(arg2), loc16, loc18);
		}
		loc20++;
	}
	loc20 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc20 > loc22)) break;
		loc13 = F909_7492(RTCW(loc12), loc20);
		loc17 = F898_7324(Current, loc13, arg1);
		loc18 = F1610_14386(RTCW(loc13));
		if (loc2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1340_12104(RTCW(tr1), loc18);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tb1 = F1326_11939(RTCW(tr1));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc19 = F1326_11931(RTCW(tr1));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1326_11952(RTCW(tr1));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc2 = F1237_11471(RTCW(tr1));
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc2;
				F23_221(RTCW(loc17), loc19);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc19));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13) + O8996[Dtype(loc13)-1122]);
				F1679_15285(RTCW(tr1), ti4_1);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc19) + _REFACS_1_);
				loc18 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10815[Dtype(RTCW(tr1))-1590])(tr1);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13) + O8996[Dtype(loc13)-1122]);
				F1679_15285(RTCW(loc18), ti4_1);
			}
		}
		if (loc3) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1334_12030(RTCW(tr1), loc18);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tb1 = F1326_11939(RTCW(tr1));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tr1 = F1326_11931(RTCW(tr1));
				loc28 = F1683_15423(RTCW(tr1));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13) + O8996[Dtype(loc13)-1122]);
				F1679_15285(RTCW(loc28), ti4_1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				F1326_11952(RTCW(tr1));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				loc3 = F1237_11471(RTCW(tr1));
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc3;
			}
		}
		if (loc5) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			F1345_12104(RTCW(tr1), loc18);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tb1 = F1332_11939(RTCW(tr1));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				tr1 = F1345_12096(RTCW(tr1));
				loc28 = F1683_15423(RTCW(tr1));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13) + O8996[Dtype(loc13)-1122]);
				F1679_15285(RTCW(loc28), ti4_1);
				F23_222(RTCW(loc17), loc28);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				tb1 = F1332_11931(RTCW(tr1));
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
					F1345_12108(RTCW(tr1), (EIF_BOOLEAN) 1);
					loc8--;
				}
			}
		}
		if (loc4) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			F1345_12104(RTCW(tr1), loc18);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			tb1 = F1332_11939(RTCW(tr1));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				tr1 = F1345_12096(RTCW(tr1));
				loc28 = F1683_15423(RTCW(tr1));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13) + O8996[Dtype(loc13)-1122]);
				F1679_15285(RTCW(loc28), ti4_1);
				F23_223(RTCW(loc17), loc28);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				tb1 = F1332_11931(RTCW(tr1));
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					F1345_12108(RTCW(tr1), (EIF_BOOLEAN) 1);
					loc7--;
				}
			}
		}
		if (loc6) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			F1345_12104(RTCW(tr1), loc18);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tb1 = F1332_11939(RTCW(tr1));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				tr1 = F1345_12096(RTCW(tr1));
				loc28 = F1683_15423(RTCW(tr1));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13) + O8996[Dtype(loc13)-1122]);
				F1679_15285(RTCW(loc28), ti4_1);
				F23_224(RTCW(loc17), loc28);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				tb1 = F1332_11931(RTCW(tr1));
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					F1345_12108(RTCW(tr1), (EIF_BOOLEAN) 1);
					loc9--;
				}
			}
		}
		F1340_12104(RTCW(arg2), loc18);
		tb1 = F1326_11939(RTCW(arg2));
		if (tb1) {
			loc14 = F1326_11931(RTCW(arg2));
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8986[Dtype(RTCW(loc14))-1124])(loc14);
			if (tb1) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8999[Dtype(RTCW(loc14))-1124])(loc14);
				loc15 = F898_7326(Current, tr1, loc17);
				F1340_12108(RTCW(arg2), loc15);
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9002[Dtype(RTCW(loc14))-1124])(loc14);
				F1124_11123(RTCW(tr1), loc17);
			}
		} else {
			loc16 = F898_7325(Current, loc17);
			F1340_12112(RTCW(arg2), loc16, loc18);
		}
		loc20++;
	}
	if (loc2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1266_11531(RTCW(tr1));
		for (;;) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tb1 = F1266_11528(RTCW(tr1));
			if (tb1) break;
			F885_7075(Current);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			loc19 = F1254_11502(RTCW(tr1));
			tr1 = F875_6917(Current);
			F1764_16711(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1, loc19);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1266_11532(RTCW(tr1));
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1326_11953(RTCW(tr1));
	}
	if (loc3) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1266_11531(RTCW(tr1));
		for (;;) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tb2 = F1266_11528(RTCW(tr1));
			if (tb2) break;
			F885_7075(Current);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr1 = F1254_11502(RTCW(tr1));
			loc18 = F1683_15423(RTCW(tr1));
			tr1 = F875_6917(Current);
			F1764_16724(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1, loc18);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1266_11532(RTCW(tr1));
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1326_11953(RTCW(tr1));
	}
	if (loc5) {
		if ((EIF_BOOLEAN) (loc8 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			F1270_11531(RTCW(tr1));
			for (;;) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				tb3 = F1270_11528(RTCW(tr1));
				if (tb3) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				tb4 = F1258_11502(RTCW(tr1));
				if ((EIF_BOOLEAN) !tb4) {
					F885_7075(Current);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
					tr1 = F1345_12097(RTCW(tr1));
					loc18 = F1683_15423(RTCW(tr1));
					tr1 = F875_6917(Current);
					F1764_16612(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1, loc18);
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				F1270_11532(RTCW(tr1));
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1332_11953(RTCW(tr1));
	}
	if (loc4) {
		if ((EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			F1270_11531(RTCW(tr1));
			for (;;) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				tb4 = F1270_11528(RTCW(tr1));
				if (tb4) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				tb5 = F1258_11502(RTCW(tr1));
				if ((EIF_BOOLEAN) !tb5) {
					F885_7075(Current);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					tr1 = F1345_12097(RTCW(tr1));
					loc18 = F1683_15423(RTCW(tr1));
					tr1 = F875_6917(Current);
					F1764_16606(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1, loc18);
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				F1270_11532(RTCW(tr1));
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F1332_11953(RTCW(tr1));
	}
	if (loc6) {
		if ((EIF_BOOLEAN) (loc9 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			F1270_11531(RTCW(tr1));
			for (;;) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				tb5 = F1270_11528(RTCW(tr1));
				if (tb5) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				tb6 = F1258_11502(RTCW(tr1));
				if ((EIF_BOOLEAN) !tb6) {
					F885_7075(Current);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					tr1 = F1345_12097(RTCW(tr1));
					loc18 = F1683_15423(RTCW(tr1));
					tr1 = F875_6917(Current);
					F1764_16733(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1, loc18);
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				F1270_11532(RTCW(tr1));
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		F1332_11953(RTCW(tr1));
	}
	RTLE;
}

/* {ET_FEATURE_ADAPTATION_RESOLVER}.fill_rename_table */
void F898_7315 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc5);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLIU(8);
	
	RTGC;
	RTCT0("precondition", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = *(EIF_INTEGER_32 *)(loc5 + O6235[Dtype(loc5)-904]);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_11_0_0_7_);
	if ((EIF_BOOLEAN) (ti4_1 < loc2)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1326_11954(RTCW(tr1), loc2);
	}
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = F1424_13285(loc5, loc1);
		loc4 = *(EIF_REFERENCE *)(RTCW(loc3));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1340_12104(RTCW(tr1), loc4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tb1 = F1326_11939(RTCW(tr1));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1340_12110(RTCW(tr1), loc3, loc4);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr1 = F1326_11931(RTCW(tr1));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			tr2 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_1_);
			tb1 = F1589_14160(RTCW(tr1), tr2);
			if ((EIF_BOOLEAN) !tb1) {
				F885_7075(Current);
			}
			tr1 = F875_6917(Current);
			tr2 = *(EIF_REFERENCE *)(Current);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr3 = F1326_11931(RTCW(tr3));
			F1764_16712(RTCW(tr1), tr2, arg1, tr3, loc3);
		}
		loc1++;
	}
	RTLE;
}

/* {ET_FEATURE_ADAPTATION_RESOLVER}.fill_export_table */
void F898_7316 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc9);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc10);
	RTLR(5,loc4);
	RTLR(6,Current);
	RTLR(7,loc11);
	RTLR(8,loc8);
	RTLR(9,tr2);
	RTLR(10,tr3);
	RTLIU(11);
	
	RTGC;
	RTCT0("precondition", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = *(EIF_INTEGER_32 *)(loc9+ _LNGOFF_2_0_0_0_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = F905_7415(loc9, loc1);
		loc10 = loc3;
		loc10 = RTRV(eif_new_type(1586, 0x01),loc10);
		if (EIF_TEST(loc10)) {
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				tr1 = F875_6917(Current);
				F1764_16723(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1, loc4, loc10);
			} else {
				loc4 = (EIF_REFERENCE) loc10;
			}
		} else {
			loc11 = loc3;
			loc11 = RTRV(eif_new_type(1670, 0x01),loc11);
			if (EIF_TEST(loc11)) {
				loc6 = *(EIF_INTEGER_32 *)(loc11+ _LNGOFF_2_0_0_0_);
				loc7 += loc6;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_7_0_0_7_);
				if ((EIF_BOOLEAN) (ti4_1 < loc7)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					F1326_11954(RTCW(tr1), loc7);
				}
				loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc5 > loc6)) break;
					loc8 = F1668_15156(loc11, loc5);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					F1334_12030(RTCW(tr1), loc8);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					tb1 = F1326_11939(RTCW(tr1));
					if ((EIF_BOOLEAN) !tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
						F1334_12033(RTCW(tr1), loc8);
					} else {
						tr1 = F875_6917(Current);
						tr2 = *(EIF_REFERENCE *)(Current);
						tr3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
						tr3 = F1326_11931(RTCW(tr3));
						tr3 = F1683_15423(RTCW(tr3));
						F1764_16725(RTCW(tr1), tr2, arg1, tr3, loc8);
					}
					loc5++;
				}
			}
		}
		loc1++;
	}
	RTLE;
}

/* {ET_FEATURE_ADAPTATION_RESOLVER}.fill_undefine_table */
void F898_7317 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc4);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	RTCT0("precondition", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_2_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_11_0_0_7_);
	if ((EIF_BOOLEAN) (ti4_1 < loc2)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1332_11954(RTCW(tr1), loc2);
	}
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = F1668_15156(loc4, loc1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1345_12104(RTCW(tr1), loc3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tb1 = F1332_11939(RTCW(tr1));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			F1345_12110(RTCW(tr1), (EIF_BOOLEAN) 0, loc3);
		} else {
			tr1 = F875_6917(Current);
			tr2 = *(EIF_REFERENCE *)(Current);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr3 = F1345_12096(RTCW(tr3));
			tr3 = F1683_15423(RTCW(tr3));
			F1764_16616(RTCW(tr1), tr2, arg1, tr3, loc3);
		}
		loc1++;
	}
	RTLE;
}

/* {ET_FEATURE_ADAPTATION_RESOLVER}.fill_redefine_table */
void F898_7318 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc4);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	RTCT0("precondition", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_2_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_11_0_0_7_);
	if ((EIF_BOOLEAN) (ti4_1 < loc2)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F1332_11954(RTCW(tr1), loc2);
	}
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = F1668_15156(loc4, loc1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F1345_12104(RTCW(tr1), loc3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tb1 = F1332_11939(RTCW(tr1));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			F1345_12110(RTCW(tr1), (EIF_BOOLEAN) 0, loc3);
		} else {
			tr1 = F875_6917(Current);
			tr2 = *(EIF_REFERENCE *)(Current);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			tr3 = F1345_12096(RTCW(tr3));
			tr3 = F1683_15423(RTCW(tr3));
			F1764_16609(RTCW(tr1), tr2, arg1, tr3, loc3);
		}
		loc1++;
	}
	RTLE;
}

/* {ET_FEATURE_ADAPTATION_RESOLVER}.fill_select_table */
void F898_7319 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc4);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	RTCT0("precondition", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_2_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_11_0_0_7_);
	if ((EIF_BOOLEAN) (ti4_1 < loc2)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		F1332_11954(RTCW(tr1), loc2);
	}
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = F1668_15156(loc4, loc1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		F1345_12104(RTCW(tr1), loc3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tb1 = F1332_11939(RTCW(tr1));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			F1345_12110(RTCW(tr1), (EIF_BOOLEAN) 0, loc3);
		} else {
			tr1 = F875_6917(Current);
			tr2 = *(EIF_REFERENCE *)(Current);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tr3 = F1345_12096(RTCW(tr3));
			tr3 = F1683_15423(RTCW(tr3));
			F1764_16734(RTCW(tr1), tr2, arg1, tr3, loc3);
		}
		loc1++;
	}
	RTLE;
}

/* {ET_FEATURE_ADAPTATION_RESOLVER}.process_replication */
void F898_7321 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,loc4);
	RTLR(5,tr1);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	F1266_11531(RTCW(arg1));
	for (;;) {
		tb1 = F1266_11528(RTCW(arg1));
		if (tb1) break;
		loc1 = F1254_11502(RTCW(arg1));
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8989[Dtype(RTCW(loc1))-1124])(loc1);
		if (tb2) {
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9002[Dtype(RTCW(loc1))-1124])(loc1);
			loc5 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O8996[Dtype(loc2)-1122]);
			F898_7322(Current, loc2, loc5);
			loc4 = *(EIF_REFERENCE *)(RTCW(loc2));
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				loc7 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_0_0_0_);
				loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc6 > loc7)) break;
					loc5 = F1790_18006(RTCW(loc4), loc6);
					F898_7322(Current, loc2, loc5);
					loc6++;
				}
			}
		}
		F1266_11532(RTCW(arg1));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1266_11531(RTCW(tr1));
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		tb2 = F1266_11528(RTCW(tr1));
		if (tb2) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		loc3 = F1254_11502(RTCW(tr1));
		tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8939[Dtype(RTCW(loc3))-1118])(loc3);
		if (tb3) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			loc5 = F1342_12097(RTCW(tr1));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8940[Dtype(RTCW(loc3))-1118])(loc3);
			F898_7323(Current, tr1, loc5);
		} else {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8942[Dtype(RTCW(loc3))-1118])(loc3);
			if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L))) {
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		F1266_11532(RTCW(tr1));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1328_11953(RTCW(tr1));
	RTLE;
}

/* {ET_FEATURE_ADAPTATION_RESOLVER}.record_replicable_feature */
void F898_7322 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,arg1);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1342_12104(RTCW(tr1), arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tb1 = F1328_11939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		loc2 = F1328_11931(RTCW(tr1));
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8939[Dtype(RTCW(loc2))-1118])(loc2);
		if (tb1) {
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8940[Dtype(RTCW(loc2))-1118])(loc2);
			F1119_11036(RTCW(loc3), arg1);
		} else {
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8941[Dtype(RTCW(loc2))-1118])(loc2);
			loc3 = RTLNS(eif_new_type(1118, 0x01).id, 1118, _OBJSIZ_1_0_0_1_0_0_0_0_);
			F1119_11030(RTCW(loc3), loc1, arg1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			F1342_12108(RTCW(tr1), loc3);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		F1342_12114(RTCW(tr1), arg1, arg2);
	}
	RTLE;
}

/* {ET_FEATURE_ADAPTATION_RESOLVER}.process_replicated_feature */
void F898_7323 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,loc4);
	RTLR(5,loc3);
	RTLR(6,tr1);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLIU(9);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_0_0_0_);
	switch (ti4_1) {
		case 0L:
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1321,0xFF01,22,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc2 = RTLNS(typres0.id, 1321, _OBJSIZ_4_0_0_2_0_0_0_0_);
			}
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_4_0_0_0_);
			F1322_11840(RTCW(loc2), ti4_1);
			F1266_11531(RTCW(loc1));
			for (;;) {
				tb1 = F1266_11528(RTCW(loc1));
				if (tb1) break;
				loc4 = F1254_11502(RTCW(loc1));
				loc3 = F1124_11112(RTCW(loc4), arg2);
				F1322_11859(RTCW(loc2), loc3);
				F1266_11532(RTCW(loc1));
			}
			F885_7075(Current);
			tr1 = F875_6917(Current);
			F1764_16731(RTCW(tr1), *(EIF_REFERENCE *)(Current), loc2);
			break;
		case 1L:
			loc5 = F1119_11033(RTCW(arg1));
			F1266_11531(RTCW(loc1));
			for (;;) {
				tb2 = F1266_11528(RTCW(loc1));
				if (tb2) break;
				loc4 = F1254_11502(RTCW(loc1));
				tb3 = F1124_11106(RTCW(loc4));
				if ((EIF_BOOLEAN) !tb3) {
					F1124_11121(RTCW(loc4), arg2);
				} else {
					F1124_11122(RTCW(loc4));
					loc5 = (EIF_REFERENCE) loc4;
				}
				F1266_11532(RTCW(loc1));
			}
			F1266_11531(RTCW(loc1));
			for (;;) {
				tb3 = F1266_11528(RTCW(loc1));
				if (tb3) break;
				loc4 = F1254_11502(RTCW(loc1));
				tb4 = F1124_11106(RTCW(loc4));
				if ((EIF_BOOLEAN) !tb4) {
					loc3 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_1_);
					for (;;) {
						if ((EIF_BOOLEAN)(loc3 == NULL)) break;
						tb4 = F23_198(RTCW(loc3), arg2);
						if (tb4) {
							F1124_11124(RTCW(loc5), loc3);
						}
						tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_6_);
						loc3 = (EIF_REFERENCE) tr1;
					}
				}
				F1266_11532(RTCW(loc1));
			}
			break;
		default:
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1321,0xFF01,22,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc2 = RTLNS(typres0.id, 1321, _OBJSIZ_4_0_0_2_0_0_0_0_);
			}
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_4_0_0_0_);
			F1322_11840(RTCW(loc2), ti4_1);
			F1266_11531(RTCW(loc1));
			for (;;) {
				tb4 = F1266_11528(RTCW(loc1));
				if (tb4) break;
				loc4 = F1254_11502(RTCW(loc1));
				tr1 = F1124_11113(RTCW(loc4));
				loc6 = tr1;
				if (EIF_TEST(loc6)) {
					F1124_11122(RTCW(loc4));
					F1322_11859(RTCW(loc2), loc6);
				}
				F1266_11532(RTCW(loc1));
			}
			F885_7075(Current);
			tr1 = F875_6917(Current);
			F1764_16732(RTCW(tr1), *(EIF_REFERENCE *)(Current), loc2);
			break;
	}
	RTLE;
}

/* {ET_FEATURE_ADAPTATION_RESOLVER}.new_parent_feature */
EIF_REFERENCE F898_7324 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = (EIF_REFERENCE) loc1;
		F23_194(RTCW(Result), arg1, arg2);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_7_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	} else {
		Result = RTLNS(eif_new_type(22, 0x01).id, 22, _OBJSIZ_8_2_0_0_0_0_0_0_);
		F23_193(RTCW(Result), arg1, arg2);
		F23_227(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_8_));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {ET_FEATURE_ADAPTATION_RESOLVER}.new_inherited_feature */
EIF_REFERENCE F898_7325 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = (EIF_REFERENCE) loc1;
		F1126_11133(RTCW(Result), arg1);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_4_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	} else {
		Result = RTLNS(eif_new_type(1125, 0x01).id, 1125, _OBJSIZ_7_1_0_1_0_0_0_0_);
		F1126_11132(RTCW(Result), arg1);
		F1124_11126(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_10_));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {ET_FEATURE_ADAPTATION_RESOLVER}.new_redeclared_feature */
EIF_REFERENCE F898_7326 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = (EIF_REFERENCE) loc1;
		F1125_11128(RTCW(Result), arg1, arg2);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_4_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x01).id, 1124, _OBJSIZ_6_1_0_1_0_0_0_0_);
		F1125_11127(RTCW(Result), arg1, arg2);
		F1124_11126(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_12_));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

void EIF_Minit301 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
