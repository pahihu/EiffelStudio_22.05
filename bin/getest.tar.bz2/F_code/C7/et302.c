/*
 * Code for class ET_FORMAL_PARAMETER_CHECKER2
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et302.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_FORMAL_PARAMETER_CHECKER2}.make */
void F899_7333 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F875_6911(Current, arg1);
	tr1 = RTLNSMART(eif_new_type(1767, 1).id);
	F1768_17276(RTCW(tr1), *(EIF_REFERENCE *)(Current), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER2}.check_formal_parameters_validity */
void F899_7334 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,arg1);
	RTLR(3,loc5);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc4 = *(EIF_REFERENCE *)(Current);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		loc2 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_3_0_0_0_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc3 = F1667_15147(loc5, loc1);
			F899_7335(Current, loc3);
			loc1++;
		}
	}
	RTAR(Current, loc4);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc4;
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER2}.check_constraint_validity */
void F899_7335 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11170[Dtype(RTCW(arg1))-1651])(arg1);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10920[Dtype(loc3)-1602])(loc3);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R10917[Dtype(loc3)-1602])(loc3, loc1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10439[Dtype(RTCW(tr1))-1606])(tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10237[Dtype(RTCW(tr1))-1401])(tr1, Current);
			loc1++;
		}
	}
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER2}.check_class_type_constraint */
void F899_7336 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc7);
	RTLR(1,arg1);
	RTLR(2,loc9);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLR(5,loc6);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLR(9,loc10);
	RTLIU(10);
	
	RTGC;
	loc7 = F1769_17321(RTCW(arg1));
	tb1 = '\0';
	tb2 = F1769_17333(RTCW(loc7));
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_5_);
		loc9 = tr1;
		tb1 = EIF_TEST(loc9);
	}
	if (tb1) {
		tr1 = F875_6913(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R12763[Dtype(RTCW(arg1))-1770])(arg1, tr1);
		loc6 = *(EIF_REFERENCE *)(RTCW(arg1) + O12766[Dtype(arg1)-1770]);
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc6 == NULL)) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11236[Dtype(RTCW(loc6))-1662])(loc6);
			ti4_2 = *(EIF_INTEGER_32 *)(loc9+ _LNGOFF_3_0_0_0_);
			tb1 = (EIF_BOOLEAN)(ti4_1 != ti4_2);
		}
		if (tb1) {
			F885_7075(Current);
		} else {
			loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11236[Dtype(RTCW(loc6))-1662])(loc6);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11238[Dtype(RTCW(loc6))-1662])(loc6, loc1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10237[Dtype(RTCW(loc3))-1401])(loc3, Current);
				loc1++;
			}
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11238[Dtype(RTCW(loc6))-1662])(loc6, loc1);
				loc4 = F1667_15147(loc9, loc1);
				loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11170[Dtype(RTCW(loc4))-1651])(loc4);
				if ((EIF_BOOLEAN)(loc5 == NULL)) {
					loc5 = *(EIF_REFERENCE *)(RTCV(F875_6913(Current)) + _REFACS_7_);
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1768_17289(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current));
				loc8 = F1649_14738(RTCW(loc3), loc5, *(EIF_REFERENCE *)(Current + _REFACS_2_), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_1_));
				if ((EIF_BOOLEAN) !loc8) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_30_20_0_3_);
					if ((EIF_BOOLEAN)(ti4_1 == loc1)) {
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R12764[Dtype(RTCW(arg1))-1770])(arg1, *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_2_), *(EIF_REFERENCE *)(Current + _REFACS_1_));
						tb1 = '\0';
						tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O12766[Dtype(arg1)-1770]);
						loc10 = tr1;
						if (EIF_TEST(loc10)) {
							tb1 = (EIF_BOOLEAN)(loc10 != loc6);
						}
						if (tb1) {
							loc6 = (EIF_REFERENCE) loc10;
							loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11238[Dtype(RTCW(loc6))-1662])(loc6, loc1);
							loc8 = F1649_14738(RTCW(loc3), loc5, *(EIF_REFERENCE *)(Current + _REFACS_2_), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_1_));
						}
					}
				}
				if ((EIF_BOOLEAN) !loc8) {
					F885_7075(Current);
					tr1 = F875_6917(Current);
					F1764_16792(RTCW(tr1), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current), arg1, loc3, loc5);
				}
				loc1++;
			}
		}
	}
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER2}.check_tuple_type_constraint */
void F899_7337 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11236[Dtype(loc3)-1662])(loc3);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11238[Dtype(loc3)-1662])(loc3, loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10237[Dtype(RTCW(tr1))-1401])(tr1, Current);
			loc1++;
		}
	}
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER2}.process_class */
void F899_7338 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F899_7339(Current, arg1);
}

/* {ET_FORMAL_PARAMETER_CHECKER2}.process_class_type */
void F899_7339 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F899_7336(Current, arg1);
}

/* {ET_FORMAL_PARAMETER_CHECKER2}.process_tuple_type */
void F899_7340 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F899_7337(Current, arg1);
}

void EIF_Minit302 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
