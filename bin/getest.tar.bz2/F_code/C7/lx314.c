/*
 * Code for class LX_SYMBOL_CLASS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx314.h"
#include "eif_built_in.h"
#include "eif_helpers.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_SYMBOL_CLASS}.make */
void F912_7498 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_0_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_) = (EIF_INTEGER_32) arg2;
	RTLE;
}

/* {LX_SYMBOL_CLASS}.hash_code */
EIF_INTEGER_32 F912_7501 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_64 loc1 = (EIF_NATURAL_64) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_NATURAL_64 tu8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,tr2);
	RTLR(5,loc7);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_);
	tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_);
	tu8_2 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_);
	tu8_3 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_);
	loc1 = (EIF_NATURAL_64) (EIF_NATURAL_64) ((EIF_NATURAL_64) ((EIF_NATURAL_64) (loc1 + tu8_1) + tu8_2) + tu8_3);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc5 = tr1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_) >= ((EIF_INTEGER_32) 256L)) && EIF_TEST(loc5))) {
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		loc3 = F912_7526(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_));
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc2 > loc3)) {
				tb2 = '\0';
				tb3 = '\0';
				/* INLINED CODE (SPECIAL.item) */
				tr2 = *((EIF_REFERENCE *)loc5 + (loc2));
				/* END INLINED CODE */
				tr1 = tr2;
				loc6 = tr1;
				if (EIF_TEST(loc6)) {
					ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc6);
					tb3 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
				}
				if (tb3) {
					tb3 = '\01';
					tb4 = F789_6168(loc6, (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
					if (!tb4) {
						tb4 = F789_6168(loc6, (EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(4294967295)), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
						tb3 = tb4;
					}
					tb2 = (EIF_BOOLEAN) !tb3;
				}
				tb1 = tb2;
			}
			if (tb1) break;
			loc2++;
		}
		tb2 = '\0';
		if ((EIF_BOOLEAN) (loc2 <= loc3)) {
			/* INLINED CODE (SPECIAL.item) */
			tr2 = *((EIF_REFERENCE *)loc5 + (loc2));
			/* END INLINED CODE */
			tr1 = tr2;
			loc7 = tr1;
			tb2 = EIF_TEST(loc7);
		}
		if (tb2) {
			loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc4 >= ((EIF_INTEGER_32) 172L))) break;
				/* INLINED CODE (SPECIAL.item) */
				tu8_2 = *((EIF_NATURAL_64 *)loc7 + (loc4));
				/* END INLINED CODE */
				tu8_1 = tu8_2;
				loc1 += tu8_1;
				loc4++;
			}
		}
	}
	tu8_1 = eif_bit_and(loc1,(EIF_NATURAL_64) ((EIF_INTEGER_32) 65535L));
	Result = (EIF_INTEGER_32) tu8_1;
	tu8_1 = eif_bit_and(loc1,(EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(4294901760)));
	tu8_1 = eif_bit_shift_right(tu8_1,((EIF_INTEGER_32) 32L));
	ti4_1 = (EIF_INTEGER_32) tu8_1;
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) -(EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	}
	RTLE;
	return Result;
}

/* {LX_SYMBOL_CLASS}.is_full */
EIF_BOOLEAN F912_7503 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_64 loc8 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_NATURAL_64 tu8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc9);
	RTLR(3,loc10);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	if ((EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_) != (EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(4294967295)))) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_0_) == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_) >= ((EIF_INTEGER_32) 63L)))) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_0_);
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_);
			loc2 = eif_min_int32 (ti4_1,((EIF_INTEGER_32) 63L));
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > loc2))) break;
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_);
				tr1 = RTOSCF(7522,F912_7522, (Current));
				/* INLINED CODE (SPECIAL.item) */
				tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (loc1));
				/* END INLINED CODE */
				tu8_2 = tu8_3;
				tu8_1 = eif_bit_and(tu8_1,tu8_2);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
				loc1++;
			}
		}
	}
	if ((EIF_BOOLEAN) (Result && (EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_) != (EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(4294967295))))) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_0_) <= ((EIF_INTEGER_32) 64L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_) >= ((EIF_INTEGER_32) 127L)))) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_0_);
			loc1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 64L));
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_);
			loc2 = eif_min_int32 (ti4_1,((EIF_INTEGER_32) 127L));
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > loc2))) break;
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_);
				tr1 = RTOSCF(7522,F912_7522, (Current));
				/* INLINED CODE (SPECIAL.item) */
				tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 % ((EIF_INTEGER_32) 64L))));
				/* END INLINED CODE */
				tu8_2 = tu8_3;
				tu8_1 = eif_bit_and(tu8_1,tu8_2);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
				loc1++;
			}
		}
	}
	if ((EIF_BOOLEAN) (Result && (EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_) != (EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(4294967295))))) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_0_) <= ((EIF_INTEGER_32) 128L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_) >= ((EIF_INTEGER_32) 191L)))) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_0_);
			loc1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 128L));
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_);
			loc2 = eif_min_int32 (ti4_1,((EIF_INTEGER_32) 191L));
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > loc2))) break;
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_);
				tr1 = RTOSCF(7522,F912_7522, (Current));
				/* INLINED CODE (SPECIAL.item) */
				tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 % ((EIF_INTEGER_32) 64L))));
				/* END INLINED CODE */
				tu8_2 = tu8_3;
				tu8_1 = eif_bit_and(tu8_1,tu8_2);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
				loc1++;
			}
		}
	}
	if ((EIF_BOOLEAN) (Result && (EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_) != (EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(4294967295))))) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_0_) <= ((EIF_INTEGER_32) 192L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_) >= ((EIF_INTEGER_32) 255L)))) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_0_);
			loc1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 192L));
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_);
			loc2 = eif_min_int32 (ti4_1,((EIF_INTEGER_32) 255L));
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > loc2))) break;
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_);
				tr1 = RTOSCF(7522,F912_7522, (Current));
				/* INLINED CODE (SPECIAL.item) */
				tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 % ((EIF_INTEGER_32) 64L))));
				/* END INLINED CODE */
				tu8_2 = tu8_3;
				tu8_1 = eif_bit_and(tu8_1,tu8_2);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
				loc1++;
			}
		}
	}
	if ((EIF_BOOLEAN) (Result && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_) >= ((EIF_INTEGER_32) 256L)))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc9 = tr1;
		if (EIF_TEST(loc9)) {
			loc4 = F912_7526(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_));
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_0_) > ((EIF_INTEGER_32) 256L))) {
				loc5 = F912_7526(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_0_));
				loc3 = (EIF_INTEGER_32) loc5;
			} else {
				loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			}
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc3 > loc4))) break;
				/* INLINED CODE (SPECIAL.item) */
				tr2 = *((EIF_REFERENCE *)loc9 + (loc3));
				/* END INLINED CODE */
				tr1 = tr2;
				loc10 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc10)) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				} else {
					tb1 = '\0';
					ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc10);
					if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
						tb2 = F789_6168(loc10, (EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(4294967295)), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) {
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 == loc4) || (EIF_BOOLEAN)(loc3 == loc5))) {
							if ((EIF_BOOLEAN)(loc3 == loc4)) {
								loc7 = F912_7527(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_));
							} else {
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 172L);
							}
							if ((EIF_BOOLEAN)(loc3 == loc5)) {
								loc6 = F912_7527(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_0_));
							} else {
								loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							}
							tb1 = F789_6168(loc10, (EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(4294967295)), (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (loc7 - ((EIF_INTEGER_32) 1L)));
							if ((EIF_BOOLEAN) !tb1) {
								Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							} else {
								if ((EIF_BOOLEAN)(loc6 == loc7)) {
									/* INLINED CODE (SPECIAL.item) */
									tu8_2 = *((EIF_NATURAL_64 *)loc10 + (loc7));
									/* END INLINED CODE */
									loc8 = tu8_2;
									if ((EIF_BOOLEAN)(loc8 != (EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(4294967295)))) {
										loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_0_);
										loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 % ((EIF_INTEGER_32) 64L));
										loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_);
										loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 % ((EIF_INTEGER_32) 64L));
										for (;;) {
											if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > loc2))) break;
											tr1 = RTOSCF(7522,F912_7522, (Current));
											/* INLINED CODE (SPECIAL.item) */
											tu8_2 = *((EIF_NATURAL_64 *)RTCW(tr1) + (loc1));
											/* END INLINED CODE */
											tu8_1 = tu8_2;
											tu8_1 = eif_bit_and(loc8,tu8_1);
											Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
											loc1++;
										}
									}
								} else {
									if ((EIF_BOOLEAN) (loc7 < ((EIF_INTEGER_32) 172L))) {
										/* INLINED CODE (SPECIAL.item) */
										tu8_2 = *((EIF_NATURAL_64 *)loc10 + (loc7));
										/* END INLINED CODE */
										loc8 = tu8_2;
										if ((EIF_BOOLEAN)(loc8 != (EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(4294967295)))) {
											loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
											loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_);
											loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 % ((EIF_INTEGER_32) 64L));
											for (;;) {
												if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > loc2))) break;
												tr1 = RTOSCF(7522,F912_7522, (Current));
												/* INLINED CODE (SPECIAL.item) */
												tu8_2 = *((EIF_NATURAL_64 *)RTCW(tr1) + (loc1));
												/* END INLINED CODE */
												tu8_1 = tu8_2;
												tu8_1 = eif_bit_and(loc8,tu8_1);
												Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
												loc1++;
											}
										}
									}
									if ((EIF_BOOLEAN) (loc6 >= ((EIF_INTEGER_32) 0L))) {
										/* INLINED CODE (SPECIAL.item) */
										tu8_2 = *((EIF_NATURAL_64 *)loc10 + (loc6));
										/* END INLINED CODE */
										loc8 = tu8_2;
										if ((EIF_BOOLEAN)(loc8 != (EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(4294967295)))) {
											loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_0_);
											loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 % ((EIF_INTEGER_32) 64L));
											loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 63L);
											for (;;) {
												if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > loc2))) break;
												tr1 = RTOSCF(7522,F912_7522, (Current));
												/* INLINED CODE (SPECIAL.item) */
												tu8_2 = *((EIF_NATURAL_64 *)RTCW(tr1) + (loc1));
												/* END INLINED CODE */
												tu8_1 = tu8_2;
												tu8_1 = eif_bit_and(loc8,tu8_1);
												Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
												loc1++;
											}
										}
									}
								}
							}
						} else {
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
					}
				}
			}
		} else {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
	}
	RTLE;
	return Result;
}

/* {LX_SYMBOL_CLASS}.has */
EIF_BOOLEAN F912_7505 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F912_7506(Current, arg1);
	tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(Result != tb1);
	RTLE;
	return Result;
}

/* {LX_SYMBOL_CLASS}.added */
EIF_BOOLEAN F912_7506 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_NATURAL_64 tu8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 64L))) {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_);
			tr1 = RTOSCF(7522,F912_7522, (Current));
			/* INLINED CODE (SPECIAL.item) */
			tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (arg1));
			/* END INLINED CODE */
			tu8_2 = tu8_3;
			tu8_1 = eif_bit_and(tu8_1,tu8_2);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
		} else {
			if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 128L))) {
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_);
				tr1 = RTOSCF(7522,F912_7522, (Current));
				/* INLINED CODE (SPECIAL.item) */
				tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 64L))));
				/* END INLINED CODE */
				tu8_2 = tu8_3;
				tu8_1 = eif_bit_and(tu8_1,tu8_2);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
			} else {
				if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 192L))) {
					tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_);
					tr1 = RTOSCF(7522,F912_7522, (Current));
					/* INLINED CODE (SPECIAL.item) */
					tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 64L))));
					/* END INLINED CODE */
					tu8_2 = tu8_3;
					tu8_1 = eif_bit_and(tu8_1,tu8_2);
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
				} else {
					if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 256L))) {
						tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_);
						tr1 = RTOSCF(7522,F912_7522, (Current));
						/* INLINED CODE (SPECIAL.item) */
						tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 64L))));
						/* END INLINED CODE */
						tu8_2 = tu8_3;
						tu8_1 = eif_bit_and(tu8_1,tu8_2);
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
					} else {
						loc2 = F912_7524(Current, arg1);
						if ((EIF_BOOLEAN)(loc2 == NULL)) {
							RTLE;
							return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						} else {
							ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc2);
							if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
								RTLE;
								return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								loc1 = F912_7527(Current, arg1);
								/* INLINED CODE (SPECIAL.item) */
								tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc2) + (loc1));
								/* END INLINED CODE */
								tu8_1 = tu8_2;
								tr1 = RTOSCF(7522,F912_7522, (Current));
								/* INLINED CODE (SPECIAL.item) */
								tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 64L))));
								/* END INLINED CODE */
								tu8_2 = tu8_3;
								tu8_1 = eif_bit_and(tu8_1,tu8_2);
								Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
							}
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {LX_SYMBOL_CLASS}.same_symbol_class */
EIF_BOOLEAN F912_7507 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,tr1);
	RTLR(4,loc6);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLR(7,loc4);
	RTLR(8,loc7);
	RTLIU(9);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_1_);
		if ((EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) != tb1)) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_2_0_0_);
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_0_) != ti4_1)) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_2_0_1_);
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_) != ti4_1)) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				} else {
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
						Result = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
					} else {
						tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
						if (tb1) {
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						} else {
							tu8_1 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_0_);
							if ((EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_) != tu8_1)) {
								Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							} else {
								tu8_1 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_1_);
								if ((EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_) != tu8_1)) {
									Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								} else {
									tu8_1 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_2_);
									if ((EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_) != tu8_1)) {
										Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									} else {
										tu8_1 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_3_);
										if ((EIF_BOOLEAN)(*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_) != tu8_1)) {
											Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
										} else {
											if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_) >= ((EIF_INTEGER_32) 256L))) {
												Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
												tr1 = *(EIF_REFERENCE *)(Current);
												loc5 = tr1;
												if (EIF_TEST(loc5)) {
													tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
													loc6 = tr1;
													if (EIF_TEST(loc6)) {
														loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
														loc1 = F912_7526(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_));
														for (;;) {
															if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc2 > loc1))) break;
															/* INLINED CODE (SPECIAL.item) */
															tr2 = *((EIF_REFERENCE *)loc5 + (loc2));
															/* END INLINED CODE */
															loc3 = tr2;
															/* INLINED CODE (SPECIAL.item) */
															tr2 = *((EIF_REFERENCE *)loc6 + (loc2));
															/* END INLINED CODE */
															loc4 = tr2;
															if ((EIF_BOOLEAN)(loc3 == NULL)) {
																if ((EIF_BOOLEAN)(loc4 != NULL)) {
																	Result = '\0';
																	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc4);
																	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
																		tb1 = F789_6168(RTCW(loc4), (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
																		Result = tb1;
																	}
																}
															} else {
																ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc3);
																if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
																	Result = '\0';
																	if ((EIF_BOOLEAN)(loc4 != NULL)) {
																		tb1 = '\01';
																		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc4);
																		if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
																			tb2 = F789_6168(RTCW(loc4), (EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(4294967295)), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
																			tb1 = tb2;
																		}
																		Result = tb1;
																	}
																} else {
																	if ((EIF_BOOLEAN)(loc4 == NULL)) {
																		Result = F789_6168(RTCW(loc3), (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
																	} else {
																		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc4);
																		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
																			Result = F789_6168(RTCW(loc3), (EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(4294967295)), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
																		} else {
																			Result = F789_6169(RTCW(loc3), loc4, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 172L));
																		}
																	}
																}
															}
															loc2++;
														}
													} else {
														loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
														loc1 = F912_7526(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_));
														for (;;) {
															if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc2 > loc1))) break;
															/* INLINED CODE (SPECIAL.item) */
															tr2 = *((EIF_REFERENCE *)loc5 + (loc2));
															/* END INLINED CODE */
															loc3 = tr2;
															if ((EIF_BOOLEAN)(loc3 != NULL)) {
																Result = '\0';
																ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc3);
																if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
																	tb1 = F789_6168(RTCW(loc3), (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
																	Result = tb1;
																}
															}
															loc2++;
														}
													}
												} else {
													tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
													loc7 = tr1;
													if (EIF_TEST(loc7)) {
														loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
														loc1 = F912_7526(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_));
														for (;;) {
															if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc2 > loc1))) break;
															/* INLINED CODE (SPECIAL.item) */
															tr2 = *((EIF_REFERENCE *)loc7 + (loc2));
															/* END INLINED CODE */
															loc4 = tr2;
															if ((EIF_BOOLEAN)(loc4 != NULL)) {
																Result = '\0';
																ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc4);
																if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
																	tb1 = F789_6168(RTCW(loc4), (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
																	Result = tb1;
																}
															}
															loc2++;
														}
													}
												}
											} else {
												RTLE;
												return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {LX_SYMBOL_CLASS}.is_equal */
EIF_BOOLEAN F912_7508 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F912_7507(Current, arg1);
}

/* {LX_SYMBOL_CLASS}.set_negated */
void F912_7509 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) arg1;
}

/* {LX_SYMBOL_CLASS}.add_symbol */
void F912_7510 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_NATURAL_64 tu8_3;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 64L))) {
		tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_);
		tr1 = RTOSCF(7522,F912_7522, (Current));
		/* INLINED CODE (SPECIAL.item) */
		tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + (arg1));
		/* END INLINED CODE */
		tu8_2 = tu8_3;
		tu8_1 = eif_bit_or(tu8_1,tu8_2);
		*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_) = (EIF_NATURAL_64) tu8_1;
	} else {
		if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 128L))) {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_);
			tr1 = RTOSCF(7522,F912_7522, (Current));
			/* INLINED CODE (SPECIAL.item) */
			tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 64L))));
			/* END INLINED CODE */
			tu8_2 = tu8_3;
			tu8_1 = eif_bit_or(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_) = (EIF_NATURAL_64) tu8_1;
		} else {
			if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 192L))) {
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_);
				tr1 = RTOSCF(7522,F912_7522, (Current));
				/* INLINED CODE (SPECIAL.item) */
				tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 64L))));
				/* END INLINED CODE */
				tu8_2 = tu8_3;
				tu8_1 = eif_bit_or(tu8_1,tu8_2);
				*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_) = (EIF_NATURAL_64) tu8_1;
			} else {
				if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 256L))) {
					tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_);
					tr1 = RTOSCF(7522,F912_7522, (Current));
					/* INLINED CODE (SPECIAL.item) */
					tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 64L))));
					/* END INLINED CODE */
					tu8_2 = tu8_3;
					tu8_1 = eif_bit_or(tu8_1,tu8_2);
					*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_) = (EIF_NATURAL_64) tu8_1;
				} else {
					loc2 = F912_7525(Current, arg1);
					ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc2);
					if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L))) {
						loc1 = F912_7527(Current, arg1);
						/* INLINED CODE (SPECIAL.item) */
						tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc2) + (loc1));
						/* END INLINED CODE */
						tu8_1 = tu8_2;
						tr1 = RTOSCF(7522,F912_7522, (Current));
						/* INLINED CODE (SPECIAL.item) */
						tu8_3 = *((EIF_NATURAL_64 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 64L))));
						/* END INLINED CODE */
						tu8_2 = tu8_3;
						tu8_1 = eif_bit_or(tu8_1,tu8_2);
						/* INLINED CODE (SPECIAL.put) */
						*((EIF_NATURAL_64 *)RTCW(loc2) + (loc1)) = tu8_1;
						/* END INLINED CODE */
						;
					}
				}
			}
		}
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_SYMBOL_CLASS}.add_symbol_class */
void F912_7511 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_NATURAL_64 tu8_3;
	EIF_NATURAL_64 tu8_4;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc5);
	RTLR(3,loc10);
	RTLR(4,tr1);
	RTLR(5,loc11);
	RTLR(6,tr2);
	RTLR(7,loc12);
	RTLR(8,loc13);
	RTLR(9,loc3);
	RTLR(10,loc4);
	RTLIU(11);
	
	RTGC;
	loc7 = *(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
	loc8 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_1_);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc7 && loc8)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	if (loc7) {
		if (loc8) {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_);
			tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_0_);
			tu8_1 = eif_bit_and(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_) = (EIF_NATURAL_64) tu8_1;
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_);
			tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_1_);
			tu8_1 = eif_bit_and(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_) = (EIF_NATURAL_64) tu8_1;
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_);
			tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_2_);
			tu8_1 = eif_bit_and(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_) = (EIF_NATURAL_64) tu8_1;
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_);
			tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_3_);
			tu8_1 = eif_bit_and(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_) = (EIF_NATURAL_64) tu8_1;
		} else {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_);
			tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_0_);
			tu8_2 = eif_bit_not(tu8_2);
			tu8_1 = eif_bit_and(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_) = (EIF_NATURAL_64) tu8_1;
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_);
			tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_1_);
			tu8_2 = eif_bit_not(tu8_2);
			tu8_1 = eif_bit_and(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_) = (EIF_NATURAL_64) tu8_1;
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_);
			tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_2_);
			tu8_2 = eif_bit_not(tu8_2);
			tu8_1 = eif_bit_and(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_) = (EIF_NATURAL_64) tu8_1;
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_);
			tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_3_);
			tu8_2 = eif_bit_not(tu8_2);
			tu8_1 = eif_bit_and(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_) = (EIF_NATURAL_64) tu8_1;
		}
	} else {
		if (loc8) {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_);
			tu8_1 = eif_bit_not(tu8_1);
			tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_0_);
			tu8_1 = eif_bit_and(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_) = (EIF_NATURAL_64) tu8_1;
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_);
			tu8_1 = eif_bit_not(tu8_1);
			tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_1_);
			tu8_1 = eif_bit_and(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_) = (EIF_NATURAL_64) tu8_1;
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_);
			tu8_1 = eif_bit_not(tu8_1);
			tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_2_);
			tu8_1 = eif_bit_and(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_) = (EIF_NATURAL_64) tu8_1;
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_);
			tu8_1 = eif_bit_not(tu8_1);
			tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_3_);
			tu8_1 = eif_bit_and(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_) = (EIF_NATURAL_64) tu8_1;
		} else {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_);
			tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_0_);
			tu8_1 = eif_bit_or(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_) = (EIF_NATURAL_64) tu8_1;
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_);
			tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_1_);
			tu8_1 = eif_bit_or(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_) = (EIF_NATURAL_64) tu8_1;
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_);
			tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_2_);
			tu8_1 = eif_bit_or(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_) = (EIF_NATURAL_64) tu8_1;
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_);
			tu8_2 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_1_2_0_2_0_0_3_);
			tu8_1 = eif_bit_or(tu8_1,tu8_2);
			*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_) = (EIF_NATURAL_64) tu8_1;
		}
	}
	loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tb1 = '\0';
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_);
		tu8_2 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_);
		tu8_3 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_);
		tu8_4 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_);
		loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(tu8_1 == (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(tu8_2 == (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L))) && (EIF_BOOLEAN)(tu8_3 == (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L))) && (EIF_BOOLEAN)(tu8_4 == (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L)));
	}
	loc5 = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_) < ((EIF_INTEGER_32) 256L))) {
	} else {
		if ((EIF_BOOLEAN)(loc5 == NULL)) {
			tb1 = '\0';
			if ((EIF_BOOLEAN) !loc7) {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
				loc10 = tr1;
				tb1 = EIF_TEST(loc10);
			}
			if (tb1) {
				loc1 = F912_7526(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_));
				for (;;) {
					if ((EIF_BOOLEAN) (loc2 > loc1)) break;
					/* INLINED CODE (SPECIAL.item) */
					tr2 = *((EIF_REFERENCE *)loc10 + (loc2));
					/* END INLINED CODE */
					tr1 = tr2;
					loc11 = tr1;
					if (EIF_TEST(loc11)) {
						if ((EIF_BOOLEAN)(loc5 == NULL)) {
							loc5 = F912_7523(Current);
						}
						ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc11);
						if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
							tr1 = RTOSCF(7530,F912_7530, (Current));
							/* INLINED CODE (SPECIAL.put) */
							*((EIF_REFERENCE *)RTCW(loc5) + (loc2)) = tr1;
							RTAR(loc5,tr1);
							/* END INLINED CODE */
							;
							loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						} else {
							tr1 = F1_14(loc11);
							/* INLINED CODE (SPECIAL.put) */
							*((EIF_REFERENCE *)RTCW(loc5) + (loc2)) = tr1;
							RTAR(loc5,tr1);
							/* END INLINED CODE */
							;
							if (loc9) {
								loc9 = F789_6168(loc11, (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
							}
						}
					}
					loc2++;
				}
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			loc12 = tr1;
			if ((EIF_BOOLEAN) !EIF_TEST(loc12)) {
				if (loc8) {
					ti4_1 = F912_7526(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_));
					F787_6175(RTCW(loc5), NULL, ((EIF_INTEGER_32) 0L), ti4_1);
				} else {
					if (loc9) {
						loc1 = F912_7526(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_));
						for (;;) {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc9 || (EIF_BOOLEAN) (loc2 > loc1))) break;
							/* INLINED CODE (SPECIAL.item) */
							tr2 = *((EIF_REFERENCE *)RTCW(loc5) + (loc2));
							/* END INLINED CODE */
							tr1 = tr2;
							loc13 = tr1;
							if (EIF_TEST(loc13)) {
								ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc13);
								if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
									loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								} else {
									loc9 = F789_6168(loc13, (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
								}
							}
							loc2++;
						}
					}
				}
			} else {
				loc1 = F912_7526(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_));
				for (;;) {
					if ((EIF_BOOLEAN) (loc2 > loc1)) break;
					/* INLINED CODE (SPECIAL.item) */
					tr2 = *((EIF_REFERENCE *)RTCW(loc5) + (loc2));
					/* END INLINED CODE */
					loc3 = tr2;
					/* INLINED CODE (SPECIAL.item) */
					tr2 = *((EIF_REFERENCE *)loc12 + (loc2));
					/* END INLINED CODE */
					loc4 = tr2;
					if ((EIF_BOOLEAN)(loc3 == NULL)) {
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc7 && (EIF_BOOLEAN)(loc4 != NULL))) {
							ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc4);
							if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
								tr1 = RTOSCF(7530,F912_7530, (Current));
								/* INLINED CODE (SPECIAL.put) */
								*((EIF_REFERENCE *)RTCW(loc5) + (loc2)) = tr1;
								RTAR(loc5,tr1);
								/* END INLINED CODE */
								;
								loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							} else {
								tr1 = F1_14(loc4);
								/* INLINED CODE (SPECIAL.put) */
								*((EIF_REFERENCE *)RTCW(loc5) + (loc2)) = tr1;
								RTAR(loc5,tr1);
								/* END INLINED CODE */
								;
								if (loc9) {
									loc9 = F789_6168(RTCW(loc4), (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
								}
							}
						}
					} else {
						if ((EIF_BOOLEAN)(loc4 == NULL)) {
							if (loc8) {
								F789_6175(RTCW(loc3), (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
							} else {
								if (loc9) {
									ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc3);
									if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
										loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									} else {
										loc9 = F789_6168(RTCW(loc3), (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
									}
								}
							}
						} else {
							ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc3);
							if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
								if (loc7) {
									if (loc8) {
										ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc4);
										if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
											tr1 = F1_14(loc4);
											/* INLINED CODE (SPECIAL.put) */
											*((EIF_REFERENCE *)RTCW(loc5) + (loc2)) = tr1;
											RTAR(loc5,tr1);
											/* END INLINED CODE */
											;
											if (loc9) {
												loc9 = F789_6168(RTCW(loc4), (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
											}
										} else {
											loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
										}
									} else {
										ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc4);
										if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
											/* INLINED CODE (SPECIAL.put) */
											*((EIF_REFERENCE *)RTCW(loc5) + (loc2)) = NULL;
											RTAR(loc5,NULL);
											/* END INLINED CODE */
											;
										} else {
											loc3 = F1_14(loc4);
											/* INLINED CODE (SPECIAL.put) */
											*((EIF_REFERENCE *)RTCW(loc5) + (loc2)) = loc3;
											RTAR(loc5,loc3);
											/* END INLINED CODE */
											;
											loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
											for (;;) {
												if ((EIF_BOOLEAN) (loc6 >= ((EIF_INTEGER_32) 172L))) break;
												/* INLINED CODE (SPECIAL.item) */
												tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc3) + (loc6));
												/* END INLINED CODE */
												tu8_1 = tu8_2;
												tu8_1 = eif_bit_not(tu8_1);
												/* INLINED CODE (SPECIAL.put) */
												*((EIF_NATURAL_64 *)RTCW(loc3) + (loc6)) = tu8_1;
												/* END INLINED CODE */
												;
												loc6++;
											}
											if (loc9) {
												loc9 = F789_6168(RTCW(loc3), (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
											}
										}
									}
								} else {
									if (loc8) {
										/* INLINED CODE (SPECIAL.put) */
										*((EIF_REFERENCE *)RTCW(loc5) + (loc2)) = NULL;
										RTAR(loc5,NULL);
										/* END INLINED CODE */
										;
									} else {
										loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									}
								}
							} else {
								ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc4);
								if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
									if (loc7) {
										if (loc8) {
											if (loc9) {
												loc9 = F789_6168(RTCW(loc3), (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
											}
										} else {
											/* INLINED CODE (SPECIAL.put) */
											*((EIF_REFERENCE *)RTCW(loc5) + (loc2)) = NULL;
											RTAR(loc5,NULL);
											/* END INLINED CODE */
											;
										}
									} else {
										if (loc8) {
											loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
											for (;;) {
												if ((EIF_BOOLEAN) (loc6 >= ((EIF_INTEGER_32) 172L))) break;
												/* INLINED CODE (SPECIAL.item) */
												tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc3) + (loc6));
												/* END INLINED CODE */
												tu8_1 = tu8_2;
												tu8_1 = eif_bit_not(tu8_1);
												/* INLINED CODE (SPECIAL.put) */
												*((EIF_NATURAL_64 *)RTCW(loc3) + (loc6)) = tu8_1;
												/* END INLINED CODE */
												;
												loc6++;
											}
											if (loc9) {
												loc9 = F789_6168(RTCW(loc3), (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
											}
										} else {
											tr1 = RTOSCF(7530,F912_7530, (Current));
											/* INLINED CODE (SPECIAL.put) */
											*((EIF_REFERENCE *)RTCW(loc5) + (loc2)) = tr1;
											RTAR(loc5,tr1);
											/* END INLINED CODE */
											;
											loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
										}
									}
								} else {
									loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
									for (;;) {
										if ((EIF_BOOLEAN) (loc6 >= ((EIF_INTEGER_32) 172L))) break;
										if (loc7) {
											if (loc8) {
												/* INLINED CODE (SPECIAL.item) */
												tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc3) + (loc6));
												/* END INLINED CODE */
												tu8_1 = tu8_2;
												/* INLINED CODE (SPECIAL.item) */
												tu8_3 = *((EIF_NATURAL_64 *)RTCW(loc4) + (loc6));
												/* END INLINED CODE */
												tu8_2 = tu8_3;
												tu8_1 = eif_bit_and(tu8_1,tu8_2);
												/* INLINED CODE (SPECIAL.put) */
												*((EIF_NATURAL_64 *)RTCW(loc3) + (loc6)) = tu8_1;
												/* END INLINED CODE */
												;
											} else {
												/* INLINED CODE (SPECIAL.item) */
												tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc3) + (loc6));
												/* END INLINED CODE */
												tu8_1 = tu8_2;
												/* INLINED CODE (SPECIAL.item) */
												tu8_3 = *((EIF_NATURAL_64 *)RTCW(loc4) + (loc6));
												/* END INLINED CODE */
												tu8_2 = tu8_3;
												tu8_2 = eif_bit_not(tu8_2);
												tu8_1 = eif_bit_and(tu8_1,tu8_2);
												/* INLINED CODE (SPECIAL.put) */
												*((EIF_NATURAL_64 *)RTCW(loc3) + (loc6)) = tu8_1;
												/* END INLINED CODE */
												;
											}
										} else {
											if (loc8) {
												/* INLINED CODE (SPECIAL.item) */
												tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc3) + (loc6));
												/* END INLINED CODE */
												tu8_1 = tu8_2;
												tu8_1 = eif_bit_not(tu8_1);
												/* INLINED CODE (SPECIAL.item) */
												tu8_3 = *((EIF_NATURAL_64 *)RTCW(loc4) + (loc6));
												/* END INLINED CODE */
												tu8_2 = tu8_3;
												tu8_1 = eif_bit_and(tu8_1,tu8_2);
												/* INLINED CODE (SPECIAL.put) */
												*((EIF_NATURAL_64 *)RTCW(loc3) + (loc6)) = tu8_1;
												/* END INLINED CODE */
												;
											} else {
												/* INLINED CODE (SPECIAL.item) */
												tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc3) + (loc6));
												/* END INLINED CODE */
												tu8_1 = tu8_2;
												/* INLINED CODE (SPECIAL.item) */
												tu8_3 = *((EIF_NATURAL_64 *)RTCW(loc4) + (loc6));
												/* END INLINED CODE */
												tu8_2 = tu8_3;
												tu8_1 = eif_bit_or(tu8_1,tu8_2);
												/* INLINED CODE (SPECIAL.put) */
												*((EIF_NATURAL_64 *)RTCW(loc3) + (loc6)) = tu8_1;
												/* END INLINED CODE */
												;
											}
										}
										if (loc9) {
											/* INLINED CODE (SPECIAL.item) */
											tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc3) + (loc6));
											/* END INLINED CODE */
											tu8_1 = tu8_2;
											loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 == (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
										}
										loc6++;
									}
								}
							}
						}
					}
					loc2++;
				}
			}
		}
	}
	tb1 = '\0';
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_1_0_);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) loc9;
	}
	RTLE;
}

/* {LX_SYMBOL_CLASS}.remove_symbol_class */
void F912_7512 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
	F912_7511(Current, arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_1_1_);
	RTLE;
}

/* {LX_SYMBOL_CLASS}.convert_to_equivalence */
void F912_7514 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_64 loc7 = (EIF_NATURAL_64) 0;
	EIF_NATURAL_64 loc8 = (EIF_NATURAL_64) 0;
	EIF_NATURAL_64 loc9 = (EIF_NATURAL_64) 0;
	EIF_NATURAL_64 loc10 = (EIF_NATURAL_64) 0;
	EIF_NATURAL_64 loc11 = (EIF_NATURAL_64) 0;
	EIF_BOOLEAN loc12 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc14 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc15);
	RTLR(4,loc13);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_);
	loc7 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_);
	loc8 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_);
	loc9 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_);
	loc10 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_0_) = (EIF_NATURAL_64) (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_1_) = (EIF_NATURAL_64) (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_2_) = (EIF_NATURAL_64) (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L);
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_1_2_0_2_0_0_3_) = (EIF_NATURAL_64) (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O1234[Dtype(arg1)-112]);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_) = (EIF_INTEGER_32) ti4_1;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_0_);
	loc3 = eif_min_int32 (loc6,((EIF_INTEGER_32) 255L));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc3)) break;
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 64L))) {
			tr1 = RTOSCF(7522,F912_7522, (Current));
			/* INLINED CODE (SPECIAL.item) */
			tu8_2 = *((EIF_NATURAL_64 *)RTCW(tr1) + (loc1));
			/* END INLINED CODE */
			tu8_1 = tu8_2;
			tu8_1 = eif_bit_and(loc7,tu8_1);
			loc12 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
		} else {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 128L))) {
				tr1 = RTOSCF(7522,F912_7522, (Current));
				/* INLINED CODE (SPECIAL.item) */
				tu8_2 = *((EIF_NATURAL_64 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 % ((EIF_INTEGER_32) 64L))));
				/* END INLINED CODE */
				tu8_1 = tu8_2;
				tu8_1 = eif_bit_and(loc8,tu8_1);
				loc12 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
			} else {
				if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 192L))) {
					tr1 = RTOSCF(7522,F912_7522, (Current));
					/* INLINED CODE (SPECIAL.item) */
					tu8_2 = *((EIF_NATURAL_64 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 % ((EIF_INTEGER_32) 64L))));
					/* END INLINED CODE */
					tu8_1 = tu8_2;
					tu8_1 = eif_bit_and(loc9,tu8_1);
					loc12 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
				} else {
					tr1 = RTOSCF(7522,F912_7522, (Current));
					/* INLINED CODE (SPECIAL.item) */
					tu8_2 = *((EIF_NATURAL_64 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 % ((EIF_INTEGER_32) 64L))));
					/* END INLINED CODE */
					tu8_1 = tu8_2;
					tu8_1 = eif_bit_and(loc10,tu8_1);
					loc12 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
				}
			}
		}
		tb1 = '\0';
		if (loc12) {
			tb2 = F113_1248(RTCW(arg1), loc1);
			tb1 = tb2;
		}
		if (tb1) {
			ti4_1 = F113_1240(RTCW(arg1), loc1);
			F912_7510(Current, ti4_1);
		}
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	loc15 = tr1;
	if (EIF_TEST(loc15)) {
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_) >= ((EIF_INTEGER_32) 256L))) {
			loc14 = F912_7526(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_));
		} else {
			loc14 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		}
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 256L);
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc6)) break;
			/* INLINED CODE (SPECIAL.item) */
			tr2 = *((EIF_REFERENCE *)loc15 + (loc4));
			/* END INLINED CODE */
			loc13 = tr2;
			if ((EIF_BOOLEAN) (loc4 > loc14)) {
				/* INLINED CODE (SPECIAL.put) */
				*((EIF_REFERENCE *)loc15 + (loc4)) = NULL;
				RTAR(loc15,NULL);
				/* END INLINED CODE */
				;
			}
			if ((EIF_BOOLEAN)(loc13 == NULL)) {
				loc1 += ((EIF_INTEGER_32) 11008L);
			} else {
				ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc13);
				if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
					/* INLINED CODE (SPECIAL.put) */
					*((EIF_REFERENCE *)loc15 + (loc4)) = NULL;
					RTAR(loc15,NULL);
					/* END INLINED CODE */
					;
					loc3 = eif_min_int32 (loc6,(EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 11008L)));
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > loc3)) break;
						tb1 = F113_1248(RTCW(arg1), loc1);
						if (tb1) {
							ti4_1 = F113_1240(RTCW(arg1), loc1);
							F912_7510(Current, ti4_1);
						}
						loc1++;
					}
				} else {
					loc3 = eif_min_int32 (loc6,(EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 11008L)));
					loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 65L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > loc3)) break;
						if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 64L))) {
							loc5++;
							/* INLINED CODE (SPECIAL.item) */
							tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc13) + (loc5));
							/* END INLINED CODE */
							tu8_1 = tu8_2;
							if ((EIF_BOOLEAN)(tu8_1 == (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L))) {
								loc1 += ((EIF_INTEGER_32) 64L);
							} else {
								/* INLINED CODE (SPECIAL.item) */
								tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc13) + (loc5));
								/* END INLINED CODE */
								tu8_1 = tu8_2;
								if ((EIF_BOOLEAN)(tu8_1 == (EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(4294967295)))) {
									/* INLINED CODE (SPECIAL.put) */
									*((EIF_NATURAL_64 *)RTCW(loc13) + (loc5)) = (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L);
									/* END INLINED CODE */
									;
									loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
									for (;;) {
										if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > loc3) || (EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 64L)))) break;
										tb1 = F113_1248(RTCW(arg1), loc1);
										if (tb1) {
											ti4_1 = F113_1240(RTCW(arg1), loc1);
											F912_7510(Current, ti4_1);
										}
										loc1++;
										loc2++;
									}
								} else {
									/* INLINED CODE (SPECIAL.item) */
									tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc13) + (loc5));
									/* END INLINED CODE */
									loc11 = tu8_2;
									/* INLINED CODE (SPECIAL.put) */
									*((EIF_NATURAL_64 *)RTCW(loc13) + (loc5)) = (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L);
									/* END INLINED CODE */
									;
									loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								}
							}
						} else {
							tr1 = RTOSCF(7522,F912_7522, (Current));
							/* INLINED CODE (SPECIAL.item) */
							tu8_2 = *((EIF_NATURAL_64 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 % ((EIF_INTEGER_32) 64L))));
							/* END INLINED CODE */
							tu8_1 = tu8_2;
							tu8_1 = eif_bit_and(loc11,tu8_1);
							loc12 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu8_1 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
							tb1 = '\0';
							if (loc12) {
								tb2 = F113_1248(RTCW(arg1), loc1);
								tb1 = tb2;
							}
							if (tb1) {
								ti4_1 = F113_1240(RTCW(arg1), loc1);
								F912_7510(Current, ti4_1);
							}
							loc1++;
							loc2++;
						}
					}
				}
			}
			loc4++;
		}
	}
	RTLE;
}

/* {LX_SYMBOL_CLASS}.set_maximum_symbol_equivalence_class */
void F912_7515 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_64 loc3 = (EIF_NATURAL_64) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc6);
	RTLR(2,tr1);
	RTLR(3,loc7);
	RTLR(4,tr2);
	RTLR(5,loc5);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			loc1 = F912_7526(Current, arg1);
			/* INLINED CODE (SPECIAL.item) */
			tr2 = *((EIF_REFERENCE *)loc6 + (loc1));
			/* END INLINED CODE */
			tr1 = tr2;
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				loc5 = (EIF_REFERENCE) loc7;
				ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc5);
				if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
					{
						static EIF_TYPE_INDEX typarr0[] = {788,959,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						loc5 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 172L),sizeof(EIF_NATURAL_64), EIF_TRUE);
					}
					F789_6154(RTCW(loc5), (EIF_NATURAL_64) ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 172L));
					/* INLINED CODE (SPECIAL.put) */
					*((EIF_REFERENCE *)loc6 + (loc1)) = loc5;
					RTAR(loc6,loc5);
					/* END INLINED CODE */
					;
				}
				loc2 = F912_7527(Current, arg1);
				/* INLINED CODE (SPECIAL.item) */
				tu8_2 = *((EIF_NATURAL_64 *)RTCW(loc5) + (loc2));
				/* END INLINED CODE */
				loc3 = tu8_2;
				loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 % ((EIF_INTEGER_32) 64L)) + ((EIF_INTEGER_32) 1L));
				for (;;) {
					if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 63L))) break;
					tr1 = RTOSCF(7522,F912_7522, (Current));
					/* INLINED CODE (SPECIAL.item) */
					tu8_2 = *((EIF_NATURAL_64 *)RTCW(tr1) + (loc4));
					/* END INLINED CODE */
					tu8_1 = tu8_2;
					tu8_1 = eif_bit_not(tu8_1);
					tu8_1 = eif_bit_and(loc3,tu8_1);
					loc3 = (EIF_NATURAL_64) tu8_1;
					loc4++;
				}
				/* INLINED CODE (SPECIAL.put) */
				*((EIF_NATURAL_64 *)RTCW(loc5) + (loc2)) = loc3;
				/* END INLINED CODE */
				;
				F789_6175(RTCW(loc5), (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (((EIF_INTEGER_32) 172L) - ((EIF_INTEGER_32) 1L)));
			}
			ti4_1 = F787_6165(loc6);
			F787_6175(loc6, NULL, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), ti4_1);
		}
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_) = (EIF_INTEGER_32) arg1;
	}
	RTLE;
}

/* {LX_SYMBOL_CLASS}.copy */
void F912_7516 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc5);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	eif_builtin_ANY_standard_copy__o_ (Current, arg1);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_) < ((EIF_INTEGER_32) 256L))) {
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			loc2 = F912_7526(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_));
			{
				static EIF_TYPE_INDEX typarr0[] = {786,788,959,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc3 = RTLNSP2(typres0.id,EO_REF,(EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)),sizeof(EIF_REFERENCE), EIF_FALSE);
			}
			F787_6154(RTCW(loc3), NULL, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc3;
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				/* INLINED CODE (SPECIAL.item) */
				tr2 = *((EIF_REFERENCE *)loc4 + (loc1));
				/* END INLINED CODE */
				tr1 = tr2;
				loc5 = tr1;
				if (EIF_TEST(loc5)) {
					ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc5);
					if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
						tr1 = RTOSCF(7530,F912_7530, (Current));
						/* INLINED CODE (SPECIAL.put) */
						*((EIF_REFERENCE *)RTCW(loc3) + (loc1)) = tr1;
						RTAR(loc3,tr1);
						/* END INLINED CODE */
						;
					} else {
						tr1 = F1_14(loc5);
						/* INLINED CODE (SPECIAL.put) */
						*((EIF_REFERENCE *)RTCW(loc3) + (loc1)) = tr1;
						RTAR(loc3,tr1);
						/* END INLINED CODE */
						;
					}
				}
				loc1++;
			}
		}
	}
	RTLE;
}

/* {LX_SYMBOL_CLASS}.masks */
static EIF_REFERENCE F912_7522_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_64 loc2 = (EIF_NATURAL_64) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (7522);
#define Result RTOSR(7522)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,788,959,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 64L),sizeof(EIF_NATURAL_64), EIF_TRUE);
	}
	F789_6154(RTCW(tr1), (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 64L));
	Result = (EIF_REFERENCE) tr1;
	loc2 = (EIF_NATURAL_64) (EIF_NATURAL_64) ((EIF_INTEGER_32) 1L);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_64 *)RTCW(Result) + (((EIF_INTEGER_32) 0L))) = loc2;
	/* END INLINED CODE */
	;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 64L))) break;
		tu8_1 = eif_bit_shift_left(loc2,((EIF_INTEGER_32) 1L));
		loc2 = (EIF_NATURAL_64) tu8_1;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_64 *)RTCW(Result) + (loc1)) = loc2;
		/* END INLINED CODE */
		;
		loc1++;
	}
	RTOSE (7522);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F912_7522 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(7522,F912_7522_body,(Current));
}

/* {LX_SYMBOL_CLASS}.attached_other_sets */
EIF_REFERENCE F912_7523 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		ti4_1 = F912_7526(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_2_0_1_));
		{
			static EIF_TYPE_INDEX typarr0[] = {786,788,959,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNSP2(typres0.id,EO_REF,(EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)),sizeof(EIF_REFERENCE), EIF_FALSE);
		}
		F787_6154(RTCW(loc1), NULL, (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {LX_SYMBOL_CLASS}.chunk */
EIF_REFERENCE F912_7524 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = F912_7526(Current, arg1);
		/* INLINED CODE (SPECIAL.item) */
		tr2 = *((EIF_REFERENCE *)loc1 + (ti4_1));
		/* END INLINED CODE */
		Result = tr2;
	}
	RTLE;
	return Result;
}

/* {LX_SYMBOL_CLASS}.attached_chunk */
EIF_REFERENCE F912_7525 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = F912_7526(Current, arg1);
	loc3 = F912_7523(Current);
	/* INLINED CODE (SPECIAL.item) */
	tr2 = *((EIF_REFERENCE *)RTCW(loc3) + (loc1));
	/* END INLINED CODE */
	loc2 = tr2;
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {788,959,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc2 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 172L),sizeof(EIF_NATURAL_64), EIF_TRUE);
		}
		F789_6154(RTCW(loc2), (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 172L));
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_REFERENCE *)RTCW(loc3) + (loc1)) = loc2;
		RTAR(loc3,loc2);
		/* END INLINED CODE */
		;
	}
	RTLE;
	return (EIF_REFERENCE) loc2;
}

/* {LX_SYMBOL_CLASS}.chunk_index */
EIF_INTEGER_32 F912_7526 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 256L)) / ((EIF_INTEGER_32) 11008L));
}

/* {LX_SYMBOL_CLASS}.index_in_chunk */
EIF_INTEGER_32 F912_7527 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 256L)) / ((EIF_INTEGER_32) 64L)) % ((EIF_INTEGER_32) 172L));
}

/* {LX_SYMBOL_CLASS}.chunk_of_ones */
static EIF_REFERENCE F912_7530_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (7530);
#define Result RTOSR(7530)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,788,959,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSP2(typres0.id,0,((EIF_INTEGER_32) 0L),sizeof(EIF_NATURAL_64), EIF_TRUE);
		RT_SPECIAL_COUNT(tr1) = 0;
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (7530);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F912_7530 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(7530,F912_7530_body,(Current));
}

void EIF_Minit314 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
