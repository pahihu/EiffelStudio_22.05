/*
 * Code for class ET_DOTNET_FEATURE_ADAPTATION_RESOLVER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et300.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_DOTNET_FEATURE_ADAPTATION_RESOLVER}.make */
void F897_7287 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	F875_6911(Current, arg1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1337,0xFF01,1610,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1326_11930(RTCW(tr1), ((EIF_INTEGER_32) 400L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	loc1 = RTLNS(eif_new_type(359, 0x01).id, 359, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1260_11523(RTCW(tr1), loc1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1355,0xFF01,1311,0xFF01,1610,0xFF01,1610,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1340_12088(RTCW(tr1), ((EIF_INTEGER_32) 400L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1340_12106(RTCW(tr1), loc1);
	RTLE;
}

/* {ET_DOTNET_FEATURE_ADAPTATION_RESOLVER}.resolve_feature_adaptations */
void F897_7288 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc6);
	RTLR(5,tr1);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = *(EIF_REFERENCE *)(Current);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	F897_7289(Current, arg2);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_21_);
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		loc5 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_1_0_0_0_);
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc4 > loc5)) break;
			loc2 = F905_7415(loc6, loc4);
			tb1 = '\01';
			if (!loc3) {
				tb2 = F1412_13190(RTCW(loc2));
				tb1 = tb2;
			}
			loc3 = (EIF_BOOLEAN) tb1;
			F897_7291(Current, loc2, arg2);
			loc4++;
		}
	}
	if ((EIF_BOOLEAN) !loc3) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tb1 = F1772_17490(RTCW(tr1));
		if (tb1) {
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCV(F875_6913(Current)) + _REFACS_56_);
			F897_7291(Current, tr1, arg2);
		}
	}
	F897_7294(Current, arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1326_11953(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1326_11953(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	RTLE;
}

/* {ET_DOTNET_FEATURE_ADAPTATION_RESOLVER}.add_current_features */
void F897_7289 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,arg1);
	RTLR(5,loc1);
	RTLR(6,loc9);
	RTLR(7,loc3);
	RTLR(8,loc10);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_25_);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_26_);
	loc6 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_1_);
	loc7 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_0_0_1_);
	loc8 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_11_0_0_8_);
	loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 + loc7) + loc8);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_7_0_0_7_);
	if ((EIF_BOOLEAN) (ti4_1 < loc8)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1326_11954(RTCW(tr1), loc8);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_11_0_0_7_);
	if ((EIF_BOOLEAN) (ti4_1 < loc8)) {
		F1326_11954(RTCW(arg1), loc8);
	}
	loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc5 > loc6)) break;
		loc1 = F910_7494(RTCW(loc2), loc5);
		loc9 = loc1;
		loc9 = RTRV(eif_new_type(1610, 0x01),loc9);
		if (EIF_TEST(loc9)) {
			F897_7290(Current, loc9, arg1);
		} else {
			F885_7075(Current);
			F1764_17045(RTCV(F875_6917(Current)));
		}
		loc5++;
	}
	loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc5 > loc7)) break;
		loc3 = F909_7492(RTCW(loc4), loc5);
		loc10 = loc3;
		loc10 = RTRV(eif_new_type(1610, 0x01),loc10);
		if (EIF_TEST(loc10)) {
			F897_7290(Current, loc10, arg1);
		} else {
			F885_7075(Current);
			F1764_17045(RTCV(F875_6917(Current)));
		}
		loc5++;
	}
	RTLE;
}

/* {ET_DOTNET_FEATURE_ADAPTATION_RESOLVER}.add_current_feature */
void F897_7290 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLR(5,tr1);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	loc1 = (RTNA((RTCW(arg1))), ((EIF_REFERENCE) 0));
	F1340_12104(RTCW(arg2), loc1);
	tb1 = F1326_11939(RTCW(arg2));
	if (tb1) {
		F885_7075(Current);
		loc2 = F1326_11931(RTCW(arg2));
		tr1 = F875_6917(Current);
		tr2 = *(EIF_REFERENCE *)(Current);
		tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8998[Dtype(RTCW(loc2))-1124])(loc2);
		F1764_16726(RTCW(tr1), tr2, tr3, arg1);
	} else {
		F1340_12116(RTCW(arg2), arg1, loc1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1334_12030(RTCW(tr1), arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tb1 = F1326_11939(RTCW(tr1));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1340_12104(RTCW(tr1), arg1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tb1 = F1326_11939(RTCW(tr1));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tr1 = F1326_11931(RTCW(tr1));
				F1312_11744(RTCW(tr1), arg1);
			} else {
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,1311,0xFF01,1610,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
					loc3 = RTLNS(typres0.id, 1311, _OBJSIZ_4_0_0_1_0_0_0_0_);
				}
				F1312_11717(RTCW(loc3));
				F1312_11744(RTCW(loc3), arg1);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				F1340_12116(RTCW(tr1), loc3, arg1);
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1334_12037(RTCW(tr1), arg1);
		}
	}
	RTLE;
}

/* {ET_DOTNET_FEATURE_ADAPTATION_RESOLVER}.add_inherited_features_from_parents */
void F897_7291 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_0_0_0_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = F1412_13191(RTCW(arg1), loc1);
		F897_7292(Current, tr1, arg2);
		loc1++;
	}
	RTLE;
}

/* {ET_DOTNET_FEATURE_ADAPTATION_RESOLVER}.add_inherited_features */
void F897_7292 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(12);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc4);
	RTLR(5,loc3);
	RTLR(6,loc9);
	RTLR(7,Current);
	RTLR(8,arg2);
	RTLR(9,loc6);
	RTLR(10,loc5);
	RTLR(11,loc10);
	RTLIU(12);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc1 = F1769_17321(RTCW(tr1));
	loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_25_);
	loc4 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_26_);
	loc8 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_0_0_1_);
	loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc7 > loc8)) break;
		loc3 = F910_7494(RTCW(loc2), loc7);
		loc9 = loc3;
		loc9 = RTRV(eif_new_type(1610, 0x01),loc9);
		if (EIF_TEST(loc9)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1334_12030(RTCW(tr1), loc9);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tb1 = F1326_11939(RTCW(tr1));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tr1 = F1326_11931(RTCW(tr1));
				F897_7293(Current, arg1, loc9, tr1, arg2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				F1340_12104(RTCW(tr1), loc9);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tb1 = F1326_11939(RTCW(tr1));
				if (tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					loc6 = F1326_11931(RTCW(tr1));
					F1266_11531(RTCW(loc6));
					for (;;) {
						tb1 = F1266_11528(RTCW(loc6));
						if (tb1) break;
						tr1 = F1254_11502(RTCW(loc6));
						F897_7293(Current, arg1, loc9, tr1, arg2);
						F1266_11532(RTCW(loc6));
					}
				}
			}
		} else {
			F885_7075(Current);
			F1764_17045(RTCV(F875_6917(Current)));
		}
		loc7++;
	}
	loc8 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_0_0_1_);
	loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc7 > loc8)) break;
		loc5 = F909_7492(RTCW(loc4), loc7);
		loc10 = loc5;
		loc10 = RTRV(eif_new_type(1610, 0x01),loc10);
		if (EIF_TEST(loc10)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1334_12030(RTCW(tr1), loc10);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tb2 = F1326_11939(RTCW(tr1));
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tr1 = F1326_11931(RTCW(tr1));
				F897_7293(Current, arg1, loc10, tr1, arg2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				F1340_12104(RTCW(tr1), loc10);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				tb2 = F1326_11939(RTCW(tr1));
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					loc6 = F1326_11931(RTCW(tr1));
					F1266_11531(RTCW(loc6));
					for (;;) {
						tb2 = F1266_11528(RTCW(loc6));
						if (tb2) break;
						tr1 = F1254_11502(RTCW(loc6));
						F897_7293(Current, arg1, loc10, tr1, arg2);
						F1266_11532(RTCW(loc6));
					}
				}
			}
		} else {
			F885_7075(Current);
			F1764_17045(RTCV(F875_6917(Current)));
		}
		loc7++;
	}
	RTLE;
}

/* {ET_DOTNET_FEATURE_ADAPTATION_RESOLVER}.add_inherited_feature */
void F897_7293 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc2);
	RTLR(1,arg3);
	RTLR(2,loc1);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,Current);
	RTLR(6,arg4);
	RTLR(7,loc3);
	RTLR(8,loc5);
	RTLR(9,arg1);
	RTLR(10,loc4);
	RTLIU(11);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_11_);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_11_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg3));
	if ((EIF_BOOLEAN) !tb1) {
		if ((EIF_BOOLEAN)(loc1 == loc2)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_10_);
			(RTNA((RTCW(arg3), tr1)));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_19_3_0_2_);
			(RTNA((RTCW(arg3), ti4_1)));
			loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	} else {
		tb1 = '\0';
		tb2 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current);
		tb3 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_30_7_);
		if (tb3) {
			tb3 = (RTNA((RTCW(arg3))), ((EIF_BOOLEAN) 0));
			tb2 = tb3;
		}
		if (tb2) {
			tb1 = (EIF_BOOLEAN)(loc2 != loc1);
		}
		if (tb1) {
		} else {
			tb1 = '\0';
			tb2 = (RTNA((RTCW(arg2))), ((EIF_BOOLEAN) 0));
			if (tb2) {
				tb1 = (EIF_BOOLEAN)(loc2 != loc1);
			}
			if (tb1) {
			} else {
				tb1 = F1602_14315(RTCW(loc2), loc1, *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_1_));
				if ((EIF_BOOLEAN) !tb1) {
				} else {
					loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					if ((EIF_BOOLEAN)(loc1 == loc2)) {
						tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_10_);
						(RTNA((RTCW(arg3), tr1)));
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_19_3_0_2_);
						(RTNA((RTCW(arg3), ti4_1)));
					}
				}
			}
		}
	}
	if (loc6) {
		tr1 = (RTNA((RTCW(arg3))), ((EIF_REFERENCE) 0));
		F1340_12104(RTCW(arg4), tr1);
		tb1 = F1326_11939(RTCW(arg4));
		if (tb1) {
			loc3 = F1326_11931(RTCW(arg4));
			loc5 = F897_7297(Current, arg2, arg1);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8986[Dtype(RTCW(loc3))-1124])(loc3);
			if (tb1) {
				loc4 = F897_7299(Current, arg3, loc5);
				F1340_12108(RTCW(arg4), loc4);
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9002[Dtype(RTCW(loc3))-1124])(loc3);
				F1124_11123(RTCW(tr1), loc5);
			}
		} else {
			F885_7075(Current);
			F1764_17045(RTCV(F875_6917(Current)));
		}
	}
	RTLE;
}

/* {ET_DOTNET_FEATURE_ADAPTATION_RESOLVER}.add_any_features */
void F897_7294 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc14 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(19);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc4);
	RTLR(5,loc6);
	RTLR(6,arg1);
	RTLR(7,loc3);
	RTLR(8,loc16);
	RTLR(9,loc9);
	RTLR(10,loc19);
	RTLR(11,loc7);
	RTLR(12,tr2);
	RTLR(13,loc18);
	RTLR(14,loc8);
	RTLR(15,loc17);
	RTLR(16,loc15);
	RTLR(17,loc5);
	RTLR(18,loc20);
	RTLIU(19);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCV(F875_6914(Current)) + _REFACS_6_);
	loc1 = F1769_17321(RTCW(tr1));
	loc2 = *(EIF_REFERENCE *)(RTCV(F875_6914(Current)) + _REFACS_9_);
	loc4 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_25_);
	loc6 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_26_);
	loc12 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_0_0_0_);
	loc13 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_1_0_0_0_);
	loc14 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_11_0_0_8_);
	loc14 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc12 + loc13) + loc14);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_11_0_0_7_);
	if ((EIF_BOOLEAN) (ti4_1 < loc14)) {
		F1326_11954(RTCW(arg1), loc14);
	}
	loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc10 > loc12)) break;
		loc3 = F910_7494(RTCW(loc4), loc10);
		loc16 = F897_7297(Current, loc3, loc2);
		loc9 = F1610_14386(RTCW(loc3));
		tb1 = F1340_12101(RTCW(arg1), loc9);
		if (tb1) {
			loc11 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc19 = loc9;
			loc19 = RTRV(eif_new_type(1751, 0x01),loc19);
			if (EIF_TEST(loc19)) {
				tr1 = RTMS_EX_H("any_",4,1634629983);
				tr2 = *(EIF_REFERENCE *)(loc19 + _REFACS_1_);
				loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7467[Dtype(tr1)-1034])(tr1, tr2);
			} else {
				loc7 = RTMS_EX_H("any_query",9,85805177);
			}
			loc18 = RTLNS(eif_new_type(1751, 0x01).id, 1751, _OBJSIZ_2_1_0_4_0_0_0_0_);
			F1752_16140(RTCW(loc18), loc7);
			for (;;) {
				tb1 = F1340_12101(RTCW(arg1), loc18);
				if ((EIF_BOOLEAN) !tb1) break;
				loc8 = RTLNS(eif_new_type(1034, 0x01).id, 1034, _OBJSIZ_1_1_0_3_0_0_0_0_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_1_1_0_2_);
				F1033_9193(RTCW(loc8), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7503[Dtype(RTCW(loc8))-1034])(loc8, loc7);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7505[Dtype(RTCW(loc8))-1034])(loc8, (EIF_CHARACTER_8) '_');
				tr1 = eif_out__i4_s1(loc11);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7503[Dtype(RTCW(loc8))-1034])(loc8, tr1);
				loc18 = RTLNS(eif_new_type(1751, 0x01).id, 1751, _OBJSIZ_2_1_0_4_0_0_0_0_);
				F1752_16140(RTCW(loc18), loc8);
				loc11++;
			}
			loc17 = RTLNS(eif_new_type(1421, 0x01).id, 1421, _OBJSIZ_3_0_0_0_0_0_0_0_);
			F1422_13266(RTCW(loc17), loc9, loc18);
			F23_221(RTCW(loc16), loc17);
			loc9 = (EIF_REFERENCE) loc18;
		}
		loc15 = F897_7298(Current, loc16);
		F1340_12112(RTCW(arg1), loc15, loc9);
		loc10++;
	}
	loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc10 > loc13)) break;
		loc5 = F909_7492(RTCW(loc6), loc10);
		loc16 = F897_7297(Current, loc5, loc2);
		loc9 = F1610_14386(RTCW(loc5));
		tb2 = F1340_12101(RTCW(arg1), loc9);
		if (tb2) {
			loc11 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc20 = loc9;
			loc20 = RTRV(eif_new_type(1751, 0x01),loc20);
			if (EIF_TEST(loc20)) {
				tr1 = RTMS_EX_H("any_",4,1634629983);
				tr2 = *(EIF_REFERENCE *)(loc20 + _REFACS_1_);
				loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7467[Dtype(tr1)-1034])(tr1, tr2);
			} else {
				loc7 = RTMS_EX_H("any_procedure",13,2041763685);
			}
			loc18 = RTLNS(eif_new_type(1751, 0x01).id, 1751, _OBJSIZ_2_1_0_4_0_0_0_0_);
			F1752_16140(RTCW(loc18), loc7);
			for (;;) {
				tb2 = F1340_12101(RTCW(arg1), loc18);
				if ((EIF_BOOLEAN) !tb2) break;
				loc8 = RTLNS(eif_new_type(1034, 0x01).id, 1034, _OBJSIZ_1_1_0_3_0_0_0_0_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_1_1_0_2_);
				F1033_9193(RTCW(loc8), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7503[Dtype(RTCW(loc8))-1034])(loc8, loc7);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R7505[Dtype(RTCW(loc8))-1034])(loc8, (EIF_CHARACTER_8) '_');
				tr1 = eif_out__i4_s1(loc11);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7503[Dtype(RTCW(loc8))-1034])(loc8, tr1);
				loc18 = RTLNS(eif_new_type(1751, 0x01).id, 1751, _OBJSIZ_2_1_0_4_0_0_0_0_);
				F1752_16140(RTCW(loc18), loc8);
				loc11++;
			}
			loc17 = RTLNS(eif_new_type(1421, 0x01).id, 1421, _OBJSIZ_3_0_0_0_0_0_0_0_);
			F1422_13266(RTCW(loc17), loc9, loc18);
			F23_221(RTCW(loc16), loc17);
			loc9 = (EIF_REFERENCE) loc18;
		}
		loc15 = F897_7298(Current, loc16);
		F1340_12112(RTCW(arg1), loc15, loc9);
		loc10++;
	}
	RTLE;
}

/* {ET_DOTNET_FEATURE_ADAPTATION_RESOLVER}.new_parent_feature */
EIF_REFERENCE F897_7297 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = (EIF_REFERENCE) loc1;
		F23_194(RTCW(Result), arg1, arg2);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_7_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	} else {
		Result = RTLNS(eif_new_type(22, 0x01).id, 22, _OBJSIZ_8_2_0_0_0_0_0_0_);
		F23_193(RTCW(Result), arg1, arg2);
		F23_227(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_4_));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {ET_DOTNET_FEATURE_ADAPTATION_RESOLVER}.new_inherited_feature */
EIF_REFERENCE F897_7298 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = (EIF_REFERENCE) loc1;
		F1126_11133(RTCW(Result), arg1);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_4_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	} else {
		Result = RTLNS(eif_new_type(1125, 0x01).id, 1125, _OBJSIZ_7_1_0_1_0_0_0_0_);
		F1126_11132(RTCW(Result), arg1);
		F1124_11126(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_6_));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {ET_DOTNET_FEATURE_ADAPTATION_RESOLVER}.new_redeclared_feature */
EIF_REFERENCE F897_7299 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = (EIF_REFERENCE) loc1;
		F1125_11128(RTCW(Result), arg1, arg2);
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_4_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x01).id, 1124, _OBJSIZ_6_1_0_1_0_0_0_0_);
		F1125_11127(RTCW(Result), arg1, arg2);
		F1124_11126(RTCW(Result), *(EIF_REFERENCE *)(Current + _REFACS_8_));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

void EIF_Minit300 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
