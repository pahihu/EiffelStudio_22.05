/*
 * Code for class ET_UNFOLDED_TUPLE_ACTUAL_PARAMETERS_RESOLVER1
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et306.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_UNFOLDED_TUPLE_ACTUAL_PARAMETERS_RESOLVER1}.make */
void F903_7402 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F875_6911(Current, arg1);
	tr1 = RTLNSMART(eif_new_type(1767, 1).id);
	F1768_17276(RTCW(tr1), *(EIF_REFERENCE *)(Current), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {ET_UNFOLDED_TUPLE_ACTUAL_PARAMETERS_RESOLVER1}.resolve_type */
void F903_7403 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10237[Dtype(RTCW(arg1))-1401])(arg1, Current);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	RTLE;
}

/* {ET_UNFOLDED_TUPLE_ACTUAL_PARAMETERS_RESOLVER1}.resolve_class_type */
void F903_7404 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc6);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,Current);
	RTLR(5,loc4);
	RTLR(6,loc7);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O12766[Dtype(arg1)-1770]);
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11236[Dtype(loc6)-1662])(loc6);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11238[Dtype(loc6)-1662])(loc6, loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10237[Dtype(RTCW(loc3))-1401])(loc3, Current);
			loc1++;
		}
	}
	loc4 = F1769_17321(RTCW(arg1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	F1772_17710(RTCW(loc4), tr1);
	tr1 = F875_6913(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R12763[Dtype(RTCW(arg1))-1770])(arg1, tr1);
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O12762[Dtype(arg1)-1770]);
	if ((EIF_BOOLEAN) !tb1) {
		loc5 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_30_20_0_3_);
		tb1 = '\0';
		tb2 = '\0';
		if ((EIF_BOOLEAN)(loc5 != ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O12766[Dtype(arg1)-1770]);
			loc7 = tr1;
			tb2 = EIF_TEST(loc7);
		}
		if (tb2) {
			ti4_1 = F1769_17332(RTCW(loc4));
			ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11236[Dtype(loc7)-1662])(loc7);
			tb1 = (EIF_BOOLEAN)(ti4_1 == ti4_2);
		}
		if (tb1) {
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11238[Dtype(loc7)-1662])(loc7, loc5);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11118[Dtype(RTCW(loc3))-1650])(loc3);
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1768_17289(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R12764[Dtype(RTCW(arg1))-1770])(arg1, *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_2_), *(EIF_REFERENCE *)(Current + _REFACS_1_));
			}
		}
	}
	RTLE;
}

/* {ET_UNFOLDED_TUPLE_ACTUAL_PARAMETERS_RESOLVER1}.resolve_qualified_like_identifier */
void F903_7405 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11220[Dtype(RTCW(arg1))-1659])(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10237[Dtype(RTCW(tr1))-1401])(tr1, Current);
	RTLE;
}

/* {ET_UNFOLDED_TUPLE_ACTUAL_PARAMETERS_RESOLVER1}.resolve_tuple_type */
void F903_7406 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11236[Dtype(loc4)-1662])(loc4);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11238[Dtype(loc4)-1662])(loc4, loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10237[Dtype(RTCW(loc3))-1401])(loc3, Current);
			loc1++;
		}
	}
	RTLE;
}

/* {ET_UNFOLDED_TUPLE_ACTUAL_PARAMETERS_RESOLVER1}.process_class_type */
void F903_7407 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F903_7404(Current, arg1);
}

/* {ET_UNFOLDED_TUPLE_ACTUAL_PARAMETERS_RESOLVER1}.process_qualified_like_braced_type */
void F903_7408 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F903_7405(Current, arg1);
}

/* {ET_UNFOLDED_TUPLE_ACTUAL_PARAMETERS_RESOLVER1}.process_qualified_like_type */
void F903_7409 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F903_7405(Current, arg1);
}

/* {ET_UNFOLDED_TUPLE_ACTUAL_PARAMETERS_RESOLVER1}.process_tuple_type */
void F903_7410 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F903_7406(Current, arg1);
}

void EIF_Minit306 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
