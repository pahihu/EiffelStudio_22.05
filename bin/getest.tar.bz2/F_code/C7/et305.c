/*
 * Code for class ET_ADAPTED_BASE_CLASS_CHECKER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et305.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ADAPTED_BASE_CLASS_CHECKER}.make */
void F902_7394 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F875_6911(Current, arg1);
	tr1 = RTOSCF(4251,F282_4251, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {ET_ADAPTED_BASE_CLASS_CHECKER}.check_adapted_base_classes_validity */
void F902_7395 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(18);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg4);
	RTLR(3,loc2);
	RTLR(4,arg5);
	RTLR(5,arg1);
	RTLR(6,arg2);
	RTLR(7,loc5);
	RTLR(8,tr1);
	RTLR(9,loc6);
	RTLR(10,loc12);
	RTLR(11,loc7);
	RTLR(12,loc8);
	RTLR(13,tr2);
	RTLR(14,tr3);
	RTLR(15,tr4);
	RTLR(16,loc13);
	RTLR(17,arg3);
	RTLIU(18);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = *(EIF_REFERENCE *)(Current);
	RTAR(Current, arg4);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg4;
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	RTAR(Current, arg5);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg5;
	loc11 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O11345[Dtype(arg1)-1678]);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_4_0_0_1_);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc3 > loc4)) break;
		tr1 = F1322_11846(RTCW(arg2), loc3);
		loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1217[Dtype(RTCW(tr1))-1608])(tr1);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_9_);
			F1772_17710(RTCW(loc5), tr1);
			tb1 = F1772_17666(RTCW(loc5));
			if ((EIF_BOOLEAN) !tb1) {
				F885_7075(Current);
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_10_);
			F1772_17710(RTCW(loc5), tr1);
			tb1 = F1772_17675(RTCW(loc5));
			if ((EIF_BOOLEAN) !tb1) {
				F885_7075(Current);
			}
		}
		loc3++;
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) == *(EIF_REFERENCE *)(Current + _REFACS_2_)) || (EIF_BOOLEAN)(loc11 == ((EIF_INTEGER_32) 0L)))) {
			F1322_11889(RTCW(arg2), ((EIF_INTEGER_32) 1L));
		} else {
			F1322_11892(RTCW(arg2));
		}
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != *(EIF_REFERENCE *)(Current + _REFACS_2_)) && (EIF_BOOLEAN)(loc11 != ((EIF_INTEGER_32) 0L))) || (EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 1L)))) {
			loc6 = F1322_11847(RTCW(arg2));
			loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1217[Dtype(RTCW(loc6))-1608])(loc6);
			if ((EIF_BOOLEAN)(loc11 != ((EIF_INTEGER_32) 0L))) {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11352[Dtype(RTCW(arg1))-1679])(arg1);
				if (tb1) {
					tb1 = '\0';
					if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 1L))) {
						tb2 = F1772_17464(RTCW(loc5));
						tb1 = tb2;
					}
					if (tb1) {
					} else {
						tb1 = '\0';
						if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 1L))) {
							tb2 = F1772_17491(RTCW(loc5));
							tb1 = tb2;
						}
						if (tb1) {
						} else {
							loc3 = (EIF_INTEGER_32) loc4;
							for (;;) {
								if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 1L))) break;
								loc6 = F1322_11846(RTCW(arg2), loc3);
								loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1217[Dtype(RTCW(loc6))-1608])(loc6);
								tb1 = F1772_17464(RTCW(loc5));
								if (tb1) {
								} else {
									tb1 = '\01';
									tb2 = F1772_17491(RTCW(loc5));
									if (!(EIF_BOOLEAN) !tb2) {
										tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1218[Dtype(RTCW(loc6))-1608])(loc6);
										ti4_1 = F1769_17332(RTCW(tr1));
										tb1 = (EIF_BOOLEAN) (ti4_1 < loc11);
									}
									if (tb1) {
										F1322_11880(RTCW(arg2), loc3);
									}
								}
								loc3--;
							}
						}
					}
				} else {
					loc3 = (EIF_INTEGER_32) loc4;
					for (;;) {
						if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 1L))) break;
						loc6 = F1322_11846(RTCW(arg2), loc3);
						loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1217[Dtype(RTCW(loc6))-1608])(loc6);
						tb1 = F1772_17464(RTCW(loc5));
						if (tb1) {
						} else {
							tr1 = F1772_17637(RTCW(loc5), loc11);
							if ((EIF_BOOLEAN)(tr1 == NULL)) {
								F1322_11880(RTCW(arg2), loc3);
							}
						}
						loc3--;
					}
				}
				loc4 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_4_0_0_1_);
			}
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) == *(EIF_REFERENCE *)(Current + _REFACS_2_))) {
				if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
					F1322_11859(RTCW(arg2), loc6);
				} else {
					if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 1L))) {
						loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						for (;;) {
							if ((EIF_BOOLEAN) (loc3 > loc4)) break;
							loc6 = F1322_11846(RTCW(arg2), loc3);
							loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1217[Dtype(RTCW(loc6))-1608])(loc6);
							tr1 = F112_1234(RTCW(loc6), arg1);
							loc12 = tr1;
							if (EIF_TEST(loc12)) {
								if ((EIF_BOOLEAN)(loc7 != NULL)) {
									if ((EIF_BOOLEAN)(loc8 != NULL)) {
										tb1 = '\01';
										if (!(EIF_BOOLEAN)(loc8 != loc12)) {
											tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1218[Dtype(RTCW(loc7))-1608])(loc7);
											tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1218[Dtype(RTCW(loc6))-1608])(loc6);
											tr3 = *(EIF_REFERENCE *)(Current);
											tr4 = *(EIF_REFERENCE *)(Current);
											tb2 = F1649_14722(RTCW(tr1), tr2, tr3, tr4);
											tb1 = (EIF_BOOLEAN) !tb2;
										}
										if (tb1) {
											F885_7075(Current);
											if ((EIF_BOOLEAN)(loc11 == ((EIF_INTEGER_32) 0L))) {
												if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_))) {
													tr1 = F875_6917(Current);
													F1764_16700(RTCW(tr1), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_2_), arg1, loc8, loc7, loc12, loc6);
												}
											} else {
												F1764_17045(RTCV(F875_6917(Current)));
											}
										}
									} else {
										if ((EIF_BOOLEAN)(loc10 != ((EIF_INTEGER_32) 0L))) {
											F885_7075(Current);
											if ((EIF_BOOLEAN)(loc11 == ((EIF_INTEGER_32) 0L))) {
												if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_))) {
													tr1 = F875_6917(Current);
													F1764_16701(RTCW(tr1), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_2_), arg1, loc12, loc6, loc10, loc7);
												}
											} else {
												F1764_17045(RTCV(F875_6917(Current)));
											}
										}
									}
								} else {
									loc7 = (EIF_REFERENCE) loc6;
									loc8 = (EIF_REFERENCE) loc12;
								}
							} else {
								tb1 = '\0';
								tb2 = F1772_17491(RTCW(loc5));
								if (tb2) {
									loc13 = arg1;
									loc13 = RTRV(eif_new_type(1751, 0x01),loc13);
									tb1 = EIF_TEST(loc13);
								}
								if (tb1) {
									loc9 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1224[Dtype(RTCW(loc6))-1608])(loc6, loc13, arg3);
									if ((EIF_BOOLEAN)(loc9 == ((EIF_INTEGER_32) 0L))) {
									} else {
										if ((EIF_BOOLEAN)(loc7 != NULL)) {
											if ((EIF_BOOLEAN)(loc8 != NULL)) {
												F885_7075(Current);
												if ((EIF_BOOLEAN)(loc11 == ((EIF_INTEGER_32) 0L))) {
													if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_))) {
														tr1 = F875_6917(Current);
														F1764_16701(RTCW(tr1), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_2_), arg1, loc8, loc7, loc9, loc6);
													}
												} else {
													F1764_17045(RTCV(F875_6917(Current)));
												}
											} else {
												if ((EIF_BOOLEAN)(loc10 != ((EIF_INTEGER_32) 0L))) {
													F885_7075(Current);
													if ((EIF_BOOLEAN)(loc11 == ((EIF_INTEGER_32) 0L))) {
														if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_))) {
															tr1 = F875_6917(Current);
															F1764_16702(RTCW(tr1), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_2_), arg1, loc10, loc7, loc9, loc6);
														}
													} else {
														F1764_17045(RTCV(F875_6917(Current)));
													}
												}
											}
										} else {
											loc7 = (EIF_REFERENCE) loc6;
											loc10 = (EIF_INTEGER_32) loc9;
										}
									}
								}
							}
							loc3++;
						}
						if ((EIF_BOOLEAN)(loc7 != NULL)) {
							F1322_11892(RTCW(arg2));
							F1322_11859(RTCW(arg2), loc7);
						} else {
							F885_7075(Current);
							if ((EIF_BOOLEAN)(loc11 == ((EIF_INTEGER_32) 0L))) {
								if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_))) {
									tr1 = F875_6917(Current);
									F1764_16699(RTCW(tr1), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_2_), arg1, arg2);
								}
							} else {
								F1764_17045(RTCV(F875_6917(Current)));
							}
							F1322_11889(RTCW(arg2), ((EIF_INTEGER_32) 1L));
						}
					}
				}
			}
		}
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	RTAR(Current, loc2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc2;
	RTLE;
}

/* {ET_ADAPTED_BASE_CLASS_CHECKER}.reset_context_if_multiple_constraints */
void F902_7396 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg3);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	if (arg1) {
		tb1 = F1767_17243(RTCW(arg3));
		if (tb1) {
			loc1 = RTOSCF(3581,F282_3581, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
		} else {
			tb1 = F1767_17245(RTCW(arg3));
			if (tb1) {
				loc1 = RTOSCF(3582,F282_3582, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
			}
		}
		tr1 = RTOSCF(3584,F282_3584, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
		F288_4386(RTCW(arg3), tr1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1218[Dtype(RTCW(arg2))-1608])(arg2);
		F288_4386(RTCW(arg3), tr1);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			F288_4386(RTCW(arg3), loc1);
		}
	}
	RTLE;
}

/* {ET_ADAPTED_BASE_CLASS_CHECKER}.set_feature_flattening_error_only */
void F902_7399 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_1_) = (EIF_BOOLEAN) arg1;
}

/* {ET_ADAPTED_BASE_CLASS_CHECKER}.set_class_interface_error_only */
void F902_7400 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_2_) = (EIF_BOOLEAN) arg1;
}

void EIF_Minit305 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
