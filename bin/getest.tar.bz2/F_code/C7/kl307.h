
#ifndef _C7_kl307_
#define _C7_kl307_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,7412)
static EIF_REFERENCE F904_7412_body(EIF_REFERENCE);
extern EIF_REFERENCE F904_7412(EIF_REFERENCE);
extern void EIF_Minit307(void);

#ifdef __cplusplus
}
#endif

#endif
