/*
 * Code for class ET_PARENT_CHECKER1
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et303.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_PARENT_CHECKER1}.check_parents_validity */
void F900_7342 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,arg1);
	RTLR(3,loc8);
	RTLR(4,tr1);
	RTLR(5,loc6);
	RTLR(6,loc7);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc5 = *(EIF_REFERENCE *)(Current);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_21_);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		loc2 = *(EIF_INTEGER_32 *)(loc8+ _LNGOFF_1_0_0_0_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc6 = F905_7415(loc8, loc1);
			loc4 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_3_0_0_0_);
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc3 > loc4)) break;
				loc7 = F1412_13191(RTCW(loc6), loc3);
				RTAR(Current, loc7);
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc7;
				tr1 = *(EIF_REFERENCE *)(RTCW(loc7));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10237[Dtype(RTCW(tr1))-1401])(tr1, Current);
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
				loc3++;
			}
			loc1++;
		}
	}
	RTAR(Current, loc5);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc5;
	RTLE;
}

/* {ET_PARENT_CHECKER1}.check_class_type_validity */
void F900_7343 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc5);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,loc6);
	RTLR(6,loc7);
	RTLR(7,loc4);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	loc5 = F1769_17321(RTCW(arg1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	F1772_17710(RTCW(loc5), tr1);
	tb1 = F1772_17536(RTCW(loc5));
	if ((EIF_BOOLEAN) !tb1) {
		F885_7075(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
		if ((EIF_BOOLEAN)(arg1 == tr1)) {
		} else {
			tr1 = F875_6917(Current);
			F1764_16795(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1);
		}
	} else {
		tb1 = '\01';
		tb2 = F1772_17550(RTCW(loc5));
		if (!(EIF_BOOLEAN) !tb2) {
			tb2 = F1772_17552(RTCW(loc5));
			tb1 = tb2;
		}
		if (tb1) {
			F885_7075(Current);
		} else {
			tb1 = '\01';
			tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_5_);
			loc6 = tr1;
			if (!((EIF_BOOLEAN) !EIF_TEST(loc6))) {
				tb2 = F1662_15080(loc6);
				tb1 = tb2;
			}
			if (tb1) {
				tb1 = F1769_17333(RTCW(arg1));
				if (tb1) {
					F885_7075(Current);
					tr1 = F875_6917(Current);
					F1764_16796(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1);
				}
			} else {
				tr1 = F875_6913(Current);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R12763[Dtype(RTCW(arg1))-1770])(arg1, tr1);
				tb1 = '\01';
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O12766[Dtype(arg1)-1770]);
				loc7 = tr1;
				if (!((EIF_BOOLEAN) !EIF_TEST(loc7))) {
					tb2 = F1662_15080(loc7);
					tb1 = tb2;
				}
				if (tb1) {
					F885_7075(Current);
					tr1 = F875_6917(Current);
					F1764_16797(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1);
				} else {
					ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11236[Dtype(loc7)-1662])(loc7);
					ti4_2 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_3_0_0_0_);
					if ((EIF_BOOLEAN)(ti4_1 != ti4_2)) {
						F885_7075(Current);
						tr1 = F875_6917(Current);
						F1764_16797(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1);
					} else {
						loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11236[Dtype(loc7)-1662])(loc7);
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 > loc2)) break;
							loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11238[Dtype(loc7)-1662])(loc7, loc1);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10237[Dtype(RTCW(loc4))-1401])(loc4, Current);
							loc3 = F1667_15147(loc6, loc1);
							tb1 = F1652_14828(RTCW(loc3));
							if (tb1) {
								tb1 = F1649_14702(RTCW(loc4), *(EIF_REFERENCE *)(Current));
								if ((EIF_BOOLEAN) !tb1) {
									F885_7075(Current);
									tr1 = F875_6917(Current);
									F1764_16866(RTCW(tr1), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current), arg1, loc4, loc3);
								}
							} else {
								tb1 = F1652_14829(RTCW(loc3));
								if (tb1) {
									tb1 = F1649_14704(RTCW(loc4), *(EIF_REFERENCE *)(Current));
									if ((EIF_BOOLEAN) !tb1) {
										F885_7075(Current);
										tr1 = F875_6917(Current);
										F1764_16865(RTCW(tr1), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current), arg1, loc4, loc3);
									}
								}
							}
							loc1++;
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {ET_PARENT_CHECKER1}.check_like_type_validity */
void F900_7344 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	F885_7075(Current);
	tr1 = F875_6917(Current);
	F1764_16710(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1);
	RTLE;
}

/* {ET_PARENT_CHECKER1}.check_tuple_type_validity */
void F900_7345 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
	if ((EIF_BOOLEAN)(arg1 == tr1)) {
		F885_7075(Current);
		tr1 = F875_6917(Current);
		F1764_16852(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1);
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11236[Dtype(loc3)-1662])(loc3);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11238[Dtype(loc3)-1662])(loc3, loc1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10237[Dtype(RTCW(tr1))-1401])(tr1, Current);
				loc1++;
			}
		}
	}
	RTLE;
}

/* {ET_PARENT_CHECKER1}.process_class */
void F900_7346 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F900_7347(Current, arg1);
}

/* {ET_PARENT_CHECKER1}.process_class_type */
void F900_7347 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F900_7343(Current, arg1, loc1);
	}
	RTLE;
}

/* {ET_PARENT_CHECKER1}.process_like_current */
void F900_7348 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F900_7350(Current, arg1);
}

/* {ET_PARENT_CHECKER1}.process_like_feature */
void F900_7349 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F900_7350(Current, arg1);
}

/* {ET_PARENT_CHECKER1}.process_like_type */
void F900_7350 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F900_7344(Current, arg1, loc1);
	}
	RTLE;
}

/* {ET_PARENT_CHECKER1}.process_qualified_like_braced_type */
void F900_7351 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F900_7350(Current, arg1);
}

/* {ET_PARENT_CHECKER1}.process_qualified_like_type */
void F900_7352 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F900_7350(Current, arg1);
}

/* {ET_PARENT_CHECKER1}.process_tuple_type */
void F900_7353 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F900_7345(Current, arg1, loc1);
	}
	RTLE;
}

void EIF_Minit303 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
