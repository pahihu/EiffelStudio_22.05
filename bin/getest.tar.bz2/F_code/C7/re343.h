
#ifndef _C7_re343_
#define _C7_re343_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F971_8570(EIF_REFERENCE, EIF_REAL_32);
extern EIF_INTEGER_32 F971_8574(EIF_REFERENCE);
extern void EIF_Minit343(void);
extern EIF_BOOLEAN F970_8540(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F970_8551(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
