
#ifndef _C7_ch349_
#define _C7_ch349_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F977_8697(EIF_REFERENCE);
extern EIF_NATURAL_32 F977_8698(EIF_REFERENCE);
extern EIF_CHARACTER_8 F977_8699(EIF_REFERENCE);
extern void EIF_Minit349(void);
extern EIF_NATURAL_32 F976_8663(EIF_REFERENCE);
extern EIF_CHARACTER_8 F976_8678(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
