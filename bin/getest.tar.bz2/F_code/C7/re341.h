
#ifndef _C7_re341_
#define _C7_re341_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F970_8529(EIF_REFERENCE);
extern EIF_BOOLEAN F970_8540(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F970_8541(EIF_REFERENCE, EIF_REFERENCE);
extern void F970_8542(EIF_REFERENCE, EIF_REAL_32);
extern EIF_INTEGER_32 F970_8551(EIF_REFERENCE);
extern void EIF_Minit341(void);
extern char *(*R6991[])();

#ifdef __cplusplus
}
#endif

#endif
