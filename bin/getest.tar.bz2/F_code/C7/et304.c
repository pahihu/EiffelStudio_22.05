/*
 * Code for class ET_FORMAL_PARAMETER_CHECKER1
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et304.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_FORMAL_PARAMETER_CHECKER1}.make */
void F901_7355 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F875_6911(Current, arg1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1321,0xFF01,1607,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1322_11840(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1321,0xFF01,1607,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1322_11840(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1322,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1323_11840(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1322,950,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1323_11840(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1323,962,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1324_11840(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1323,962,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1324_11840(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.check_formal_parameters_validity */
void F901_7356 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,loc8);
	RTLR(2,arg1);
	RTLR(3,loc9);
	RTLR(4,tr1);
	RTLR(5,loc4);
	RTLR(6,loc6);
	RTLR(7,loc7);
	RTLR(8,loc5);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc8 = *(EIF_REFERENCE *)(Current);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		loc3 = *(EIF_INTEGER_32 *)(loc9+ _LNGOFF_3_0_0_0_);
		F901_7362(Current, loc3);
		F901_7363(Current, loc3);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			loc4 = F1667_15147(loc9, loc1);
			loc6 = *(EIF_REFERENCE *)(RTCW(loc4));
			tr1 = F875_6913(Current);
			tb1 = F1378_12410(RTCW(tr1), loc6);
			if (tb1) {
				F885_7075(Current);
				tr1 = F875_6913(Current);
				tr1 = F1378_12416(RTCW(tr1), loc6);
				loc7 = F1365_12175(RTCW(tr1));
				tr1 = F875_6917(Current);
				F1764_16574(RTCW(tr1), *(EIF_REFERENCE *)(Current), loc4, loc7);
			} else {
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc2 >= loc1)) break;
					loc5 = F1667_15147(loc9, loc2);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc5));
					tb1 = F1752_16176(RTCW(tr1), loc6);
					if (tb1) {
						F885_7075(Current);
						tr1 = F875_6917(Current);
						F1764_16575(RTCW(tr1), *(EIF_REFERENCE *)(Current), loc5, loc4);
					}
					loc2++;
				}
			}
			F901_7357(Current, loc4);
			loc1++;
		}
		F901_7365(Current, loc9);
		F901_7366(Current, loc9);
		F901_7367(Current, loc9);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F1323_11892(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1322_11892(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		F1323_11892(RTCW(tr1));
	}
	RTAR(Current, loc8);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc8;
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.check_constraint_validity */
void F901_7357 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc5);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	loc5 = arg1;
	loc5 = RTRV(eif_new_type(1652, 0x01),loc5);
	if (EIF_TEST(loc5)) {
		RTAR(Current, loc5);
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) loc5;
		loc1 = *(EIF_REFERENCE *)(loc5 + _REFACS_7_);
		loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R10920[Dtype(RTCW(loc1))-1602])(loc1);
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc3 > loc4)) break;
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R10917[Dtype(RTCW(loc1))-1602])(loc1, loc3);
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) loc2;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10439[Dtype(RTCW(loc2))-1606])(loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10237[Dtype(RTCW(tr1))-1401])(tr1, Current);
			loc3++;
		}
		*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) NULL;
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O11163[Dtype(arg1)-1650]);
		F1323_11857(RTCW(tr1), ((EIF_INTEGER_32) 1L), ti4_1);
	}
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.check_class_type_constraint */
void F901_7358 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc6);
	RTLR(5,loc7);
	RTLR(6,loc5);
	RTLR(7,loc4);
	RTLR(8,arg2);
	RTLR(9,arg3);
	RTLIU(10);
	
	RTGC;
	loc3 = F1769_17321(RTCW(arg1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
	F1772_17710(RTCW(loc3), tr1);
	tb1 = F1772_17536(RTCW(loc3));
	if ((EIF_BOOLEAN) !tb1) {
		F885_7075(Current);
		tr1 = F875_6917(Current);
		F1764_16795(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1);
	} else {
		tb1 = '\01';
		tb2 = F1772_17550(RTCW(loc3));
		if (!(EIF_BOOLEAN) !tb2) {
			tb2 = F1772_17552(RTCW(loc3));
			tb1 = tb2;
		}
		if (tb1) {
			F885_7075(Current);
		} else {
			tb1 = F1769_17333(RTCW(loc3));
			if ((EIF_BOOLEAN) !tb1) {
				tb1 = F1769_17333(RTCW(arg1));
				if (tb1) {
					F885_7075(Current);
					tr1 = F875_6917(Current);
					F1764_16796(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1);
				}
			} else {
				tr1 = F875_6913(Current);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R12763[Dtype(RTCW(arg1))-1770])(arg1, tr1);
				tb1 = F1769_17333(RTCW(arg1));
				if ((EIF_BOOLEAN) !tb1) {
					F885_7075(Current);
					tr1 = F875_6917(Current);
					F1764_16797(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1);
				} else {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_5_);
					loc6 = tr1;
					if ((EIF_BOOLEAN) !EIF_TEST(loc6)) {
						F885_7075(Current);
						F1764_17045(RTCV(F875_6917(Current)));
					} else {
						tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O12766[Dtype(arg1)-1770]);
						loc7 = tr1;
						if ((EIF_BOOLEAN) !EIF_TEST(loc7)) {
							F885_7075(Current);
							F1764_17045(RTCV(F875_6917(Current)));
						} else {
							ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11236[Dtype(loc7)-1662])(loc7);
							ti4_2 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_3_0_0_0_);
							if ((EIF_BOOLEAN)(ti4_1 != ti4_2)) {
								F885_7075(Current);
								tr1 = F875_6917(Current);
								F1764_16797(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1);
							} else {
								loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11236[Dtype(loc7)-1662])(loc7);
								loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
								for (;;) {
									if ((EIF_BOOLEAN) (loc1 > loc2)) break;
									loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11238[Dtype(loc7)-1662])(loc7, loc1);
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10237[Dtype(RTCW(loc5))-1401])(loc5, Current);
									loc4 = F1667_15147(loc6, loc1);
									tb1 = F1652_14828(RTCW(loc4));
									if (tb1) {
										tb1 = F1649_14702(RTCW(loc5), *(EIF_REFERENCE *)(Current));
										if ((EIF_BOOLEAN) !tb1) {
											F885_7075(Current);
											tr1 = F875_6917(Current);
											F1764_16866(RTCW(tr1), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current), arg1, loc5, loc4);
										}
									} else {
										tb1 = F1652_14829(RTCW(loc4));
										if (tb1) {
											tb1 = F1649_14704(RTCW(loc5), *(EIF_REFERENCE *)(Current));
											if ((EIF_BOOLEAN) !tb1) {
												F885_7075(Current);
												tr1 = F875_6917(Current);
												F1764_16865(RTCW(tr1), *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current), arg1, loc5, loc4);
											}
										}
									}
									loc1++;
								}
							}
						}
					}
				}
			}
		}
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10439[Dtype(RTCW(arg2))-1606])(arg2);
	if ((EIF_BOOLEAN)(tr1 == arg1)) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10919[Dtype(RTCW(arg1))-1650])(arg1);
		if (tb1) {
			F901_7364(Current, arg1, arg2, arg3);
		}
	}
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.check_formal_parameter_type_constraint */
void F901_7359 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg3);
	RTLR(4,loc4);
	RTLR(5,Current);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10439[Dtype(RTCW(arg2))-1606])(arg2);
	if ((EIF_BOOLEAN)(tr1 == arg1)) {
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O11163[Dtype(arg1)-1650]);
		loc1 = *(EIF_INTEGER_32 *)(RTCW(arg3)+ _LNGOFF_8_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		loc4 = tr1;
		if ((EIF_BOOLEAN) !EIF_TEST(loc4)) {
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10830[Dtype(loc4)-1594])(loc4);
			if (tb1) {
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
			} else {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10831[Dtype(loc4)-1594])(loc4);
				if (tb1) {
					loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				} else {
					loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr2 = *(EIF_REFERENCE *)(Current);
		ti4_1 = F1769_17332(RTCW(tr2));
		F1323_11857(RTCW(tr1), loc3, (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)) * ti4_1) + loc2));
	}
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.check_like_type_constraint */
void F901_7360 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	F885_7075(Current);
	tr1 = F875_6917(Current);
	F1764_16688(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1);
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.check_tuple_type_constraint */
void F901_7361 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R11236[Dtype(loc3)-1662])(loc3);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R11238[Dtype(loc3)-1662])(loc3, loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10237[Dtype(RTCW(tr1))-1401])(tr1, Current);
			loc1++;
		}
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10439[Dtype(RTCW(arg2))-1606])(arg2);
	if ((EIF_BOOLEAN)(tr1 == arg1)) {
		tb1 = F1769_17334(RTCW(arg1));
		if (tb1) {
			F901_7364(Current, arg1, arg2, arg3);
		}
	}
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.initalize_formal_dependencies */
void F901_7362 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1323_11892(RTCW(tr1));
	F901_7386(Current, ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (arg1 * arg1), *(EIF_REFERENCE *)(Current + _REFACS_4_));
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.initalize_base_type_dependencies */
void F901_7363 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1322_11892(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1323_11892(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(RTCV(F875_6913(Current)) + _REFACS_7_);
	F1322_11864(RTCW(tr1), tr2);
	F901_7386(Current, ((EIF_INTEGER_32) 0L), arg1, *(EIF_REFERENCE *)(Current + _REFACS_5_));
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.add_base_type_dependency */
void F901_7364 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc4);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,Current);
	RTLR(6,tr2);
	RTLR(7,arg3);
	RTLIU(8);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10440[Dtype(RTCW(arg2))-1606])(arg2);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc2 = RTLNS(eif_new_type(1608, 0x01).id, 1608, _OBJSIZ_2_0_0_0_0_0_0_0_);
		F1607_14361(RTCW(loc2), arg1, loc4);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1322_11864(RTCW(tr1), loc2);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1322_11864(RTCW(tr1), arg1);
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = F1769_17332(RTCW(tr1));
	F901_7386(Current, ((EIF_INTEGER_32) 0L), loc1, *(EIF_REFERENCE *)(Current + _REFACS_5_));
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R12747[Dtype(RTCW(arg1))-1769])(arg1);
	if (tb1) {
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	} else {
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_4_0_0_1_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg3)+ _LNGOFF_8_0_0_0_);
	F1323_11857(RTCW(tr1), loc3, (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)) * loc1) + ti4_2));
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.propagate_recursive_formal_dependencies */
void F901_7365 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_0_0_0_);
	for (;;) {
		if (loc9) break;
		loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc2 > loc4)) break;
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc3 > loc4)) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
				loc6 = F1323_11846(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)) * loc4) + loc3));
				if ((EIF_BOOLEAN)(loc6 != ((EIF_INTEGER_32) 0L))) {
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > loc5)) break;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
						loc7 = F1323_11846(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)) * loc4) + loc2));
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
						loc8 = F1323_11846(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)) * loc4) + loc3));
						if ((EIF_BOOLEAN)(loc8 != ((EIF_INTEGER_32) 0L))) {
							if ((EIF_BOOLEAN)(loc6 == ((EIF_INTEGER_32) 2L))) {
								loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
							} else {
								if ((EIF_BOOLEAN)(loc6 == ((EIF_INTEGER_32) 1L))) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr1 = F1322_11846(RTCW(tr1), loc1);
									tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10439[Dtype(RTCW(tr1))-1606])(tr1);
									tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R12746[Dtype(RTCW(tr1))-1769])(tr1);
									if ((EIF_BOOLEAN) !tb1) {
										loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
									}
								}
							}
							if ((EIF_BOOLEAN) (loc8 > loc7)) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
								F1323_11857(RTCW(tr1), loc8, (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)) * loc4) + loc2));
								loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							}
						}
						loc1++;
					}
				}
				loc3++;
			}
			loc2++;
		}
		if (loc9) {
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc2 > loc4)) break;
				loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc1 > loc5)) break;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					ti4_1 = F1323_11846(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)) * loc4) + loc2));
					if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L))) {
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						loc1 = (EIF_INTEGER_32) loc5;
					}
					loc1++;
				}
				if (loc10) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					F1323_11857(RTCW(tr1), ((EIF_INTEGER_32) 1L), loc2);
					loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc2 = (EIF_INTEGER_32) loc4;
				}
				loc2++;
			}
		}
	}
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.set_recursive_formal_constraints */
void F901_7366 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc5 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,loc10);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,tr2);
	RTLR(5,loc9);
	RTLIU(6);
	
	RTGC;
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_0_0_0_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc4)) break;
		tr1 = F1667_15147(RTCW(arg1), loc1);
		loc10 = tr1;
		loc10 = RTRV(eif_new_type(1652, 0x01),loc10);
		if (EIF_TEST(loc10)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			F1324_11892(RTCW(tr1));
			F901_7387(Current, (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L), loc4, *(EIF_REFERENCE *)(Current + _REFACS_6_));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			F1324_11892(RTCW(tr1));
			F901_7387(Current, (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L), loc4, *(EIF_REFERENCE *)(Current + _REFACS_7_));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			F1324_11857(RTCW(tr1), ((EIF_NATURAL_32) 1U), loc1);
			loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			for (;;) {
				if (loc7) break;
				loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc2 > loc4)) break;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
					loc5 = F1324_11846(RTCW(tr1), loc2);
					if ((EIF_BOOLEAN)(loc5 != (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
						loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						for (;;) {
							if ((EIF_BOOLEAN) (loc3 > loc4)) break;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
							loc6 = F1323_11846(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)) * loc4) + loc3));
							tu4_1 = eif_bit_and(loc5,((EIF_NATURAL_32) 1U));
							if ((EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 1U))) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
								tu4_1 = eif_bit_xor(loc5,((EIF_NATURAL_32) 1U));
								F1324_11857(RTCW(tr1), tu4_1, loc2);
								if ((EIF_BOOLEAN)(loc6 == ((EIF_INTEGER_32) 3L))) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
									tu4_1 = F1324_11846(RTCW(tr1), loc3);
									tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 1U));
									if ((EIF_BOOLEAN)(tu4_1 != ((EIF_NATURAL_32) 1U))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
										tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
										tu4_1 = F1324_11846(RTCW(tr2), loc3);
										tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 1U));
										F1324_11857(RTCW(tr1), tu4_1, loc3);
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
										tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
										tu4_1 = F1324_11846(RTCW(tr2), loc3);
										tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 1U));
										F1324_11857(RTCW(tr1), tu4_1, loc3);
										loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									}
								} else {
									if ((EIF_BOOLEAN)(loc6 == ((EIF_INTEGER_32) 2L))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
										tu4_1 = F1324_11846(RTCW(tr1), loc3);
										tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 2U));
										if ((EIF_BOOLEAN)(tu4_1 != ((EIF_NATURAL_32) 2U))) {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
											tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
											tu4_1 = F1324_11846(RTCW(tr2), loc3);
											tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 2U));
											F1324_11857(RTCW(tr1), tu4_1, loc3);
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
											tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
											tu4_1 = F1324_11846(RTCW(tr2), loc3);
											tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 2U));
											F1324_11857(RTCW(tr1), tu4_1, loc3);
											loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
										}
									} else {
										if ((EIF_BOOLEAN)(loc6 == ((EIF_INTEGER_32) 1L))) {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
											tu4_1 = F1324_11846(RTCW(tr1), loc3);
											tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 4U));
											if ((EIF_BOOLEAN)(tu4_1 != ((EIF_NATURAL_32) 4U))) {
												tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
												tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
												tu4_1 = F1324_11846(RTCW(tr2), loc3);
												tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 4U));
												F1324_11857(RTCW(tr1), tu4_1, loc3);
												tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
												tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
												tu4_1 = F1324_11846(RTCW(tr2), loc3);
												tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 4U));
												F1324_11857(RTCW(tr1), tu4_1, loc3);
												loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
											}
										}
									}
								}
							}
							tu4_1 = eif_bit_and(loc5,((EIF_NATURAL_32) 2U));
							if ((EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 2U))) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
								tu4_1 = eif_bit_xor(loc5,((EIF_NATURAL_32) 2U));
								F1324_11857(RTCW(tr1), tu4_1, loc2);
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								tu4_1 = F1324_11846(RTCW(tr1), loc3);
								tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 2U));
								if ((EIF_BOOLEAN)(tu4_1 != ((EIF_NATURAL_32) 2U))) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
									tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
									tu4_1 = F1324_11846(RTCW(tr2), loc3);
									tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 2U));
									F1324_11857(RTCW(tr1), tu4_1, loc3);
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
									tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
									tu4_1 = F1324_11846(RTCW(tr2), loc3);
									tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 2U));
									F1324_11857(RTCW(tr1), tu4_1, loc3);
									loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								}
							}
							tu4_1 = eif_bit_and(loc5,((EIF_NATURAL_32) 4U));
							if ((EIF_BOOLEAN)(tu4_1 == ((EIF_NATURAL_32) 4U))) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
								tu4_1 = eif_bit_xor(loc5,((EIF_NATURAL_32) 4U));
								F1324_11857(RTCW(tr1), tu4_1, loc2);
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
								tu4_1 = F1324_11846(RTCW(tr1), loc3);
								tu4_1 = eif_bit_and(tu4_1,((EIF_NATURAL_32) 4U));
								if ((EIF_BOOLEAN)(tu4_1 != ((EIF_NATURAL_32) 4U))) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
									tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
									tu4_1 = F1324_11846(RTCW(tr2), loc3);
									tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 4U));
									F1324_11857(RTCW(tr1), tu4_1, loc3);
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
									tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
									tu4_1 = F1324_11846(RTCW(tr2), loc3);
									tu4_1 = eif_bit_or(tu4_1,((EIF_NATURAL_32) 4U));
									F1324_11857(RTCW(tr1), tu4_1, loc3);
									loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								}
							}
							loc3++;
						}
					}
					loc2++;
				}
			}
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc2 > loc4)) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				tu4_1 = F1324_11846(RTCW(tr1), loc2);
				if ((EIF_BOOLEAN)(tu4_1 != (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
					loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc2 = (EIF_INTEGER_32) loc4;
				}
				loc2++;
			}
			if ((EIF_BOOLEAN) !loc8) {
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,790,962,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
					loc9 = RTLNSP2(typres0.id,0,(EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)),sizeof(EIF_NATURAL_32), EIF_TRUE);
				}
				F791_6154(RTCW(loc9), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc2 > loc4)) break;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					tu4_1 = F1324_11846(RTCW(tr1), loc2);
					/* INLINED CODE (SPECIAL.put) */
					*((EIF_NATURAL_32 *)RTCW(loc9) + (loc2)) = tu4_1;
					/* END INLINED CODE */
					;
					loc2++;
				}
				F1653_14850(loc10, loc9);
			}
		}
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1324_11892(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1324_11892(RTCW(tr1));
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.set_constraint_base_types */
void F901_7367 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc7);
	RTLR(4,loc8);
	RTLR(5,loc6);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_0_0_0_);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		tr1 = F1667_15147(RTCW(arg1), loc2);
		loc7 = tr1;
		loc7 = RTRV(eif_new_type(1652, 0x01),loc7);
		if (EIF_TEST(loc7)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1322_11892(RTCW(tr1));
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc4)) break;
				tr1 = F901_7368(Current, loc2, loc1, loc3);
				loc8 = tr1;
				if (EIF_TEST(loc8)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					F1322_11864(RTCW(tr1), loc8);
				}
				loc1++;
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
			if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 0L))) {
			} else {
				if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 1L))) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					tr1 = F1322_11847(RTCW(tr1));
					F1653_14849(loc7, tr1);
				} else {
					loc6 = RTLNS(eif_new_type(1604, 0x01).id, 1604, _OBJSIZ_3_0_0_1_0_0_0_0_);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
					tr1 = F1322_11846(RTCW(tr1), loc5);
					F1605_14340(RTCW(loc6), tr1, loc5);
					loc5--;
					for (;;) {
						if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 0L))) break;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
						tr1 = F1322_11846(RTCW(tr1), loc5);
						F905_7423(RTCW(loc6), tr1);
						loc5--;
					}
					F1653_14849(loc7, loc6);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			F1322_11892(RTCW(tr1));
		}
		loc2++;
	}
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.base_type_constraint */
EIF_REFERENCE F901_7368 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc5);
	RTLR(5,loc4);
	RTLR(6,loc6);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = F1322_11846(RTCW(tr1), arg2);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10439[Dtype(RTCW(loc1))-1606])(loc1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = F1323_11846(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)) * arg3) + arg1));
	if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 2L))) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R12747[Dtype(RTCW(loc2))-1769])(loc2);
		if (tb1) {
			RTLE;
			return (EIF_REFERENCE) loc1;
		} else {
			tr1 = RTOSCF(3644,F282_3644, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11104[Dtype(RTCW(loc2))-1650])(loc2, tr1);
			loc2 = (EIF_REFERENCE) tr1;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10440[Dtype(RTCW(loc1))-1606])(loc1);
			loc5 = tr1;
			if (EIF_TEST(loc5)) {
				loc4 = RTLNS(eif_new_type(1608, 0x01).id, 1608, _OBJSIZ_2_0_0_0_0_0_0_0_);
				F1607_14361(RTCW(loc4), loc2, loc5);
				RTLE;
				return (EIF_REFERENCE) loc4;
			} else {
				RTLE;
				return (EIF_REFERENCE) loc2;
			}
		}
	} else {
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 1L))) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R12747[Dtype(RTCW(loc2))-1769])(loc2);
			if (tb1) {
				tr1 = RTOSCF(3654,F282_3654, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R11104[Dtype(RTCW(loc2))-1650])(loc2, tr1);
				loc2 = (EIF_REFERENCE) tr1;
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10440[Dtype(RTCW(loc1))-1606])(loc1);
				loc6 = tr1;
				if (EIF_TEST(loc6)) {
					loc4 = RTLNS(eif_new_type(1608, 0x01).id, 1608, _OBJSIZ_2_0_0_0_0_0_0_0_);
					F1607_14361(RTCW(loc4), loc2, loc6);
					RTLE;
					return (EIF_REFERENCE) loc4;
				} else {
					RTLE;
					return (EIF_REFERENCE) loc2;
				}
			} else {
				RTLE;
				return (EIF_REFERENCE) loc1;
			}
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.process_class */
void F901_7369 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F901_7370(Current, arg1);
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.process_class_type */
void F901_7370 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc1 = tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = tr1;
	if ((EIF_BOOLEAN) (EIF_TEST(loc1) && EIF_TEST(loc2))) {
		F901_7358(Current, arg1, loc2, loc1);
	}
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.process_formal_parameter_type */
void F901_7371 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc1 = tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = tr1;
	if ((EIF_BOOLEAN) (EIF_TEST(loc1) && EIF_TEST(loc2))) {
		F901_7359(Current, arg1, loc2, loc1);
	}
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.process_like_current */
void F901_7372 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F901_7374(Current, arg1);
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.process_like_feature */
void F901_7373 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F901_7374(Current, arg1);
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.process_like_type */
void F901_7374 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc1 = tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = tr1;
	if ((EIF_BOOLEAN) (EIF_TEST(loc1) && EIF_TEST(loc2))) {
		F901_7360(Current, arg1, loc2, loc1);
	}
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.process_qualified_like_braced_type */
void F901_7375 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F901_7374(Current, arg1);
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.process_qualified_like_type */
void F901_7376 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F901_7374(Current, arg1);
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.process_tuple_type */
void F901_7377 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	loc1 = tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = tr1;
	if ((EIF_BOOLEAN) (EIF_TEST(loc1) && EIF_TEST(loc2))) {
		F901_7361(Current, arg1, loc2, loc1);
	}
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.add_n_items_to_list */
void F901_7386 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,arg3);
	RTLIU(1);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > arg2)) break;
		F1323_11864(RTCW(arg3), arg1);
		loc1++;
	}
	RTLE;
}

/* {ET_FORMAL_PARAMETER_CHECKER1}.add_n_flags_to_list */
void F901_7387 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,arg3);
	RTLIU(1);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > arg2)) break;
		F1324_11864(RTCW(arg3), arg1);
		loc1++;
	}
	RTLE;
}

void EIF_Minit304 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
