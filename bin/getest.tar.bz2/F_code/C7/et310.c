/*
 * Code for class ET_FEATURE_LIST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et310.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_FEATURE_LIST}.reset */
void F908_7457 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ti4_1);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		/* INLINED CODE (SPECIAL.item) */
		tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
		/* END INLINED CODE */
		tr1 = tr3;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10939[Dtype(RTCW(tr1))-1613])(tr1);
		loc1--;
	}
	RTLE;
}

/* {ET_FEATURE_LIST}.reset_after_features_flattened */
void F908_7458 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ti4_1);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		/* INLINED CODE (SPECIAL.item) */
		tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
		/* END INLINED CODE */
		tr1 = tr3;
		F1610_14383(RTCW(tr1));
		loc1--;
	}
	RTLE;
}

/* {ET_FEATURE_LIST}.reset_after_interface_checked */
void F908_7459 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ti4_1);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		/* INLINED CODE (SPECIAL.item) */
		tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
		/* END INLINED CODE */
		tr1 = tr3;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10941[Dtype(RTCW(tr1))-1613])(tr1);
		loc1--;
	}
	RTLE;
}

/* {ET_FEATURE_LIST}.named_feature */
EIF_REFERENCE F908_7460 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,loc4);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,Result);
	RTLR(8,loc5);
	RTLIU(9);
	
	RTGC;
	loc4 = arg1;
	loc4 = RTRV(eif_new_type(1751, 0x01),loc4);
	if (EIF_TEST(loc4)) {
		loc3 = *(EIF_INTEGER_32 *)(loc4+ _LNGOFF_2_1_0_3_);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
			tr1 = *(EIF_REFERENCE *)(Current);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
			/* END INLINED CODE */
			loc2 = tr3;
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O11013[Dtype(loc2)-1609]);
			if ((EIF_BOOLEAN)(loc3 == ti4_1)) {
				tr1 = F1610_14386(RTCW(loc2));
				tb1 = F1752_16174(loc4, tr1);
				if (tb1) {
					Result = (EIF_REFERENCE) loc2;
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				} else {
					loc1--;
				}
			} else {
				loc1--;
			}
		}
	} else {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
			tr1 = *(EIF_REFERENCE *)(Current);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
			/* END INLINED CODE */
			loc2 = tr3;
			tb1 = '\0';
			tr1 = F1610_14388(RTCW(loc2));
			loc5 = tr1;
			if (EIF_TEST(loc5)) {
				tb2 = F1411_13182(loc5, arg1);
				tb1 = tb2;
			}
			if (tb1) {
				Result = (EIF_REFERENCE) loc2;
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			} else {
				loc1--;
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_FEATURE_LIST}.seeded_feature */
EIF_REFERENCE F908_7462 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc8);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ti4_1);
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
		for (;;) {
			if (loc7) break;
			if ((EIF_BOOLEAN)(loc3 == loc4)) {
				tr1 = *(EIF_REFERENCE *)(Current);
				/* INLINED CODE (SPECIAL.item) */
				tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc3));
				/* END INLINED CODE */
				loc8 = tr3;
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O8996[Dtype(loc8)-1122]);
				if ((EIF_BOOLEAN)(ti4_1 == arg1)) {
					Result = (EIF_REFERENCE) loc8;
				}
				loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				if ((EIF_BOOLEAN)((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)) == loc4)) {
					tr1 = *(EIF_REFERENCE *)(Current);
					/* INLINED CODE (SPECIAL.item) */
					tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc3));
					/* END INLINED CODE */
					loc8 = tr3;
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O8996[Dtype(loc8)-1122]);
					if ((EIF_BOOLEAN)(ti4_1 == arg1)) {
						Result = (EIF_REFERENCE) loc8;
					} else {
						tr1 = *(EIF_REFERENCE *)(Current);
						/* INLINED CODE (SPECIAL.item) */
						tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc4));
						/* END INLINED CODE */
						loc8 = tr3;
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O8996[Dtype(loc8)-1122]);
						if ((EIF_BOOLEAN)(ti4_1 == arg1)) {
							Result = (EIF_REFERENCE) loc8;
						}
					}
					loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 - loc3) / ((EIF_INTEGER_32) 2L)));
					tr1 = *(EIF_REFERENCE *)(Current);
					/* INLINED CODE (SPECIAL.item) */
					tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc5));
					/* END INLINED CODE */
					loc8 = tr3;
					loc6 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O8996[Dtype(loc8)-1122]);
					if ((EIF_BOOLEAN)(arg1 == loc6)) {
						Result = (EIF_REFERENCE) loc8;
						loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						if ((EIF_BOOLEAN) (arg1 < loc6)) {
							loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - ((EIF_INTEGER_32) 1L));
						} else {
							loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L));
						}
					}
				}
			}
		}
	}
	if ((EIF_BOOLEAN)(Result == NULL)) {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
			tr1 = *(EIF_REFERENCE *)(Current);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
			/* END INLINED CODE */
			loc8 = tr3;
			tb1 = F1123_11089(RTCW(loc8), arg1);
			if (tb1) {
				Result = (EIF_REFERENCE) loc8;
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			} else {
				loc1--;
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_FEATURE_LIST}.set_declared_count */
void F908_7466 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_) = (EIF_INTEGER_32) arg1;
}

/* {ET_FEATURE_LIST}.add_overloaded_features */
void F908_7467 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc5);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,arg2);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLIU(10);
	
	RTGC;
	loc5 = arg1;
	loc5 = RTRV(eif_new_type(1751, 0x01),loc5);
	if (EIF_TEST(loc5)) {
		loc3 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_2_1_0_3_);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
			tr1 = *(EIF_REFERENCE *)(Current);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
			/* END INLINED CODE */
			loc2 = tr3;
			tb1 = '\0';
			tb2 = '\0';
			if ((EIF_BOOLEAN) !loc4) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O11013[Dtype(loc2)-1609]);
				tb2 = (EIF_BOOLEAN)(loc3 == ti4_1);
			}
			if (tb2) {
				tr1 = F1610_14386(RTCW(loc2));
				tb2 = F1752_16174(loc5, tr1);
				tb1 = tb2;
			}
			if (tb1) {
				F1322_11864(RTCW(arg2), loc2);
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tr1 = F1610_14391(RTCW(loc2));
				tb1 = F1752_16174(loc5, tr1);
				if (tb1) {
					F1322_11864(RTCW(arg2), loc2);
				}
			}
			loc1--;
		}
	} else {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
			tr1 = *(EIF_REFERENCE *)(Current);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
			/* END INLINED CODE */
			loc2 = tr3;
			tb1 = '\0';
			tb2 = '\0';
			if ((EIF_BOOLEAN) !loc4) {
				tr1 = F1610_14388(RTCW(loc2));
				loc6 = tr1;
				tb2 = EIF_TEST(loc6);
			}
			if (tb2) {
				tb2 = F1411_13182(loc6, arg1);
				tb1 = tb2;
			}
			if (tb1) {
				F1322_11864(RTCW(arg2), loc2);
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tb1 = '\0';
				tr1 = F1610_14392(RTCW(loc2));
				loc7 = tr1;
				if (EIF_TEST(loc7)) {
					tb2 = F1411_13182(loc7, arg1);
					tb1 = tb2;
				}
				if (tb1) {
					F1322_11864(RTCW(arg2), loc2);
				}
			}
			loc1--;
		}
	}
	RTLE;
}

/* {ET_FEATURE_LIST}.fixed_array */
static EIF_REFERENCE F908_7491_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (7491);
#define Result RTOSR(7491)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,35,0xFF01,1609,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 35, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (7491);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F908_7491 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(7491,F908_7491_body,(Current));
}

void EIF_Minit310 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
