
#ifndef _C7_et312_
#define _C7_et312_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F910_7494(EIF_REFERENCE, EIF_INTEGER_32);
RTOSHF (EIF_REFERENCE,7495)
static EIF_REFERENCE F910_7495_body(EIF_REFERENCE);
extern EIF_REFERENCE F910_7495(EIF_REFERENCE);
extern void EIF_Minit312(void);

#ifdef __cplusplus
}
#endif

#endif
