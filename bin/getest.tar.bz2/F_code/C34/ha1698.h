
#ifndef _C34_ha1698_
#define _C34_ha1698_

#ifdef __cplusplus
extern "C" {
#endif

extern void F865_6395(EIF_REFERENCE, EIF_INTEGER_32);
extern void F865_6398(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F865_6399(EIF_REFERENCE);
extern EIF_REFERENCE F865_6401(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F865_6403(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F865_6410(EIF_REFERENCE);
extern EIF_INTEGER_32 F865_6412(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F865_6413(EIF_REFERENCE);
extern EIF_INTEGER_32 F865_6416(EIF_REFERENCE);
extern EIF_INTEGER_32 F865_6417(EIF_REFERENCE);
extern EIF_BOOLEAN F865_6418(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F865_6419(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_BOOLEAN F865_6427(EIF_REFERENCE);
extern EIF_BOOLEAN F865_6428(EIF_REFERENCE);
extern void F865_6437(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F865_6439(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F865_6440(EIF_REFERENCE, EIF_INTEGER_32);
extern void F865_6441(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F865_6442(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F865_6449(EIF_REFERENCE);
extern void F865_6452(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F865_6453(EIF_REFERENCE, EIF_INTEGER_32);
extern void F865_6454(EIF_REFERENCE);
extern EIF_INTEGER_32 F865_6463(EIF_REFERENCE);
extern EIF_BOOLEAN F865_6464(EIF_REFERENCE);
extern EIF_REFERENCE F865_6471(EIF_REFERENCE);
extern EIF_INTEGER_32 F865_6472(EIF_REFERENCE);
extern EIF_INTEGER_32 F865_6473(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F865_6474(EIF_REFERENCE, EIF_INTEGER_32);
extern void F865_6477(EIF_REFERENCE, EIF_REFERENCE);
extern void F865_6479(EIF_REFERENCE, EIF_REFERENCE);
extern void F865_6480(EIF_REFERENCE, EIF_REFERENCE);
extern void F865_6481(EIF_REFERENCE, EIF_REFERENCE);
extern void F865_6485(EIF_REFERENCE, EIF_INTEGER_32);
extern void F865_6491(EIF_REFERENCE);
extern void F865_6504(EIF_REFERENCE);
extern void EIF_Minit1698(void);
extern EIF_REFERENCE F848_6296(EIF_REFERENCE);
extern void F788_6191(EIF_REFERENCE);
extern EIF_INTEGER_32 F793_6165(EIF_REFERENCE);
extern void F788_6172(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F624_5510(EIF_REFERENCE, EIF_INTEGER_32);
extern void F788_6154(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F793_6154(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F788_6175(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern EIF_REFERENCE F862_6401(EIF_REFERENCE, EIF_REFERENCE);
extern void F848_6295(EIF_REFERENCE);
extern EIF_BOOLEAN F862_6403(EIF_REFERENCE, EIF_REFERENCE);
extern void F793_6175(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F793_6172(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
RTOSHF(EIF_REFERENCE,6296)
extern char *(*R5484[])();
extern char *(*R5488[])();
extern char *(*R4828[])();
extern char *(*R5133[])();
extern char *(*R5448[])();
extern char *(*R4750[])();
extern char *(*R5298[])();
extern char *(*R5466[])();
extern char *(*R4831[])();
extern char *(*R5450[])();
extern char *(*R5451[])();
extern char *(*R5457[])();
extern char *(*R5419[])();
extern char *(*R5431[])();
extern char *(*R5422[])();
extern char *(*R5423[])();
extern char *(*R5467[])();
extern char *(*R5476[])();
extern char *(*R5284[])();
extern char *(*R4863[])();
extern char *(*R5494[])();
extern char *(*R4759[])();
extern char *(*R4737[])();
extern char *(*R4738[])();
extern char *(*R4739[])();
extern char *(*R4899[])();
extern char *(*R5433[])();
extern char *(*R5477[])();
extern char *(*R5317[])();
extern char *(*R5507[])();
extern char *(*R5283[])();
extern char *(*R5439[])();
extern char *(*R5480[])();
extern char *(*R5440[])();
extern char *(*R5482[])();
extern char *(*R5483[])();
extern long O5509[];
extern long O5473[];
extern long O5474[];
extern long O5432[];
extern long O4861[];
extern long O5475[];
extern long O5459[];
extern long O5460[];
extern long O5461[];
extern long O5462[];
extern long O5463[];
extern long O5464[];
extern long O5465[];
extern long O5423[];
extern long O5468[];
extern long O5469[];
extern EIF_TYPE_INDEX Y4901[];
extern EIF_TYPE_INDEX *Y4901_gen_type [];
extern EIF_TYPE_INDEX Y5459[];
extern EIF_TYPE_INDEX *Y5459_gen_type [];
extern EIF_TYPE_INDEX Y4760[];
extern EIF_TYPE_INDEX *Y4760_gen_type [];
extern EIF_TYPE_INDEX Y5460[];
extern EIF_TYPE_INDEX *Y5460_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
