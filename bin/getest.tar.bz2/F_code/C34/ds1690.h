
#ifndef _C34_ds1690_
#define _C34_ds1690_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1311_11690(EIF_REFERENCE, EIF_NATURAL_32);
extern void EIF_Minit1690(void);
extern void F1324_11866(EIF_REFERENCE, EIF_NATURAL_32, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
