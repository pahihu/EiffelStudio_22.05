
#ifndef _C34_ds1683_
#define _C34_ds1683_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1252_11501(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1683(void);
extern void F80_1024(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
