/*
 * Code for class KL_PART_COMPARATOR [NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl1695.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_PART_COMPARATOR}.less_than */
EIF_BOOLEAN F276_2700 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_NATURAL_32 arg2)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (RTNA((Current, arg1, arg2)), ((EIF_BOOLEAN) 0));
}

/* {KL_PART_COMPARATOR}.detachable_less_than */
EIF_BOOLEAN F276_2701 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_NATURAL_32 arg2)
{
	GTCX
	
	
	RTGC;
	if (EIF_FALSE) {
		return (EIF_BOOLEAN) EIF_TRUE;
	} else {
		if (EIF_FALSE) {
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			return (EIF_BOOLEAN) (RTNA((Current, arg1, arg2)), ((EIF_BOOLEAN) 0));
		}
	}/* NOTREACHED */
	
}

void EIF_Minit1695 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
