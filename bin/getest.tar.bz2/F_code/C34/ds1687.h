
#ifndef _C34_ds1687_
#define _C34_ds1687_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1317_11804(EIF_REFERENCE);
extern EIF_INTEGER_32 F1317_11807(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1687(void);

#ifdef __cplusplus
}
#endif

#endif
