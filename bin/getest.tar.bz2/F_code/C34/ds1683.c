/*
 * Code for class DS_SORTABLE [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1683.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SORTABLE}.sort */
void F1252_11501 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F80_1024(RTCW(arg1), Current);
}

void EIF_Minit1683 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
