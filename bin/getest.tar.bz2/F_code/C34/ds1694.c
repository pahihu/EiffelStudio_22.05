/*
 * Code for class DS_SORTABLE [NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1694.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SORTABLE}.sort */
void F1253_11501 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(RTNA((RTCW(arg1), Current)));
}

void EIF_Minit1694 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
