
#ifndef _C34_ha1699_
#define _C34_ha1699_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F430_5363(EIF_REFERENCE);
extern EIF_INTEGER_32 F430_5364(EIF_REFERENCE);
extern EIF_BOOLEAN F430_5366(EIF_REFERENCE);
extern void F430_5367(EIF_REFERENCE);
extern EIF_REFERENCE F430_5368(EIF_REFERENCE);
extern void EIF_Minit1699(void);
extern char *(*R4825[])();
extern char *(*R5450[])();
extern char *(*R5451[])();
extern char *(*R5133[])();
extern long O5459[];
extern long O5460[];

#ifdef __cplusplus
}
#endif

#endif
