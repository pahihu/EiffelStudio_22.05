
#ifndef _C34_kl1684_
#define _C34_kl1684_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F275_2700(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_BOOLEAN F275_2701(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit1684(void);
extern EIF_BOOLEAN F367_5251(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
