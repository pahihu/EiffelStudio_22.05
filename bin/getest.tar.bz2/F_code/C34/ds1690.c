/*
 * Code for class DS_LIST [NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1690.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_LIST}.force_left */
void F1311_11690 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	
	
	F1324_11866(Current, arg1, *(EIF_REFERENCE *)(Current + _REFACS_3_));
}

void EIF_Minit1690 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
