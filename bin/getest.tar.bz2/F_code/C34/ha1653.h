
#ifndef _C34_ha1653_
#define _C34_ha1653_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F429_5363(EIF_REFERENCE);
extern EIF_REFERENCE F429_5364(EIF_REFERENCE);
extern EIF_BOOLEAN F429_5366(EIF_REFERENCE);
extern void F429_5367(EIF_REFERENCE);
extern EIF_REFERENCE F429_5368(EIF_REFERENCE);
extern void EIF_Minit1653(void);
extern EIF_BOOLEAN F414_5349(EIF_REFERENCE);
extern char *(*R5283[])();
extern char *(*R5450[])();
extern char *(*R5451[])();
extern char *(*R5133[])();

#ifdef __cplusplus
}
#endif

#endif
