/*
 * Code for class DS_LIST [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1680.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_LIST}.force_left */
void F1310_11690 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	F1323_11866(Current, arg1, *(EIF_REFERENCE *)(Current + _REFACS_3_));
}

void EIF_Minit1680 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
