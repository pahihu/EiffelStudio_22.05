
#ifndef _C34_kl1695_
#define _C34_kl1695_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F276_2700(EIF_REFERENCE, EIF_NATURAL_32, EIF_NATURAL_32);
extern EIF_BOOLEAN F276_2701(EIF_REFERENCE, EIF_NATURAL_32, EIF_NATURAL_32);
extern void EIF_Minit1695(void);

#ifdef __cplusplus
}
#endif

#endif
