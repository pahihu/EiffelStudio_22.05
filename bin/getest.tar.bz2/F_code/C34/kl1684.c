/*
 * Code for class KL_PART_COMPARATOR [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl1684.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_PART_COMPARATOR}.less_than */
EIF_BOOLEAN F275_2700 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F275_2701(Current, arg1, arg2);
}

/* {KL_PART_COMPARATOR}.detachable_less_than */
EIF_BOOLEAN F275_2701 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (EIF_FALSE) {
		RTLE;
		return (EIF_BOOLEAN) EIF_TRUE;
	} else {
		if (EIF_FALSE) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			RTLE;
			return (EIF_BOOLEAN) F367_5251(Current, arg1, arg2);
		}
	}/* NOTREACHED */
	
}

void EIF_Minit1684 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
