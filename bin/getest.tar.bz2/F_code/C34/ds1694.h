
#ifndef _C34_ds1694_
#define _C34_ds1694_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1253_11501(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1694(void);

#ifdef __cplusplus
}
#endif

#endif
