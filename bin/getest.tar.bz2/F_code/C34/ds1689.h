
#ifndef _C34_ds1689_
#define _C34_ds1689_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1212_11215(EIF_REFERENCE);
extern void EIF_Minit1689(void);
extern EIF_INTEGER_32 F1324_11905(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
