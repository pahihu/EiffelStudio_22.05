/*
 * Code for class DS_ARRAYED_LIST [NATURAL_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1686.h"
#include "eif_built_in.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_ARRAYED_LIST}.make */
void F1324_11840 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y9494,Y9494_gen_type,Dftype(Current),1321).id);
	F1_29(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F39_474(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) arg1;
	tr1 = F1324_11849(Current);
	F1324_11898(Current, tr1);
	RTLE;
}

/* {DS_ARRAYED_LIST}.make_from_linear */
void F1324_11842 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9283[Dtype(RTCW(arg1))-1277])(arg1);
	F1324_11840(Current, loc3);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) = (EIF_INTEGER_32) loc3;
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9315[Dtype(RTCW(arg1))-1277])(arg1);
	F1145_11160(RTCW(loc1));
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 >= loc3)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tu4_1 = F1130_11140(RTCW(loc1));
		F39_479(RTCW(tr1), tr2, tu4_1, loc2);
		F1145_11161(RTCW(loc1));
		loc2++;
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.make_default */
void F1324_11844 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F1317_11804(Current);
	F1324_11840(Current, ti4_1);
	RTLE;
}

/* {DS_ARRAYED_LIST}.item */
EIF_NATURAL_32 F1324_11846 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	/* INLINED CODE (SPECIAL.item) */
	tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L))));
	/* END INLINED CODE */
	Result = tu4_2;
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.first */
EIF_NATURAL_32 F1324_11847 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	/* INLINED CODE (SPECIAL.item) */
	tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (((EIF_INTEGER_32) 0L)));
	/* END INLINED CODE */
	Result = tu4_2;
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.last */
EIF_NATURAL_32 F1324_11848 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	/* INLINED CODE (SPECIAL.item) */
	tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) - ((EIF_INTEGER_32) 1L))));
	/* END INLINED CODE */
	Result = tu4_2;
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.new_cursor */
EIF_REFERENCE F1324_11849 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1215,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y9292,Y9292_gen_type,Dftype(Current),1236);
			typarr0[2] = l_type.annotations | 0xFF00;
			typarr0[3] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 1215, _OBJSIZ_2_0_0_1_0_0_0_0_);
	}
	F1216_11247(RTCW(tr1), Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {DS_ARRAYED_LIST}.count */
EIF_INTEGER_32 F1324_11850 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
}


/* {DS_ARRAYED_LIST}.capacity */
EIF_INTEGER_32 F1324_11851 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_);
}


/* {DS_ARRAYED_LIST}.has */
EIF_BOOLEAN F1324_11853 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			/* INLINED CODE (SPECIAL.item) */
			tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (loc1));
			/* END INLINED CODE */
			tu4_1 = tu4_2;
			tb1 = F355_5238(loc2, tu4_1, arg1);
			if (tb1) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			} else {
				loc1--;
			}
		}
	} else {
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			/* INLINED CODE (SPECIAL.item) */
			tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (loc1));
			/* END INLINED CODE */
			tu4_1 = tu4_2;
			if ((EIF_BOOLEAN)(tu4_1 == arg1)) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			} else {
				loc1--;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.extendible */
EIF_BOOLEAN F1324_11854 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) >= (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) + arg1));
}

/* {DS_ARRAYED_LIST}.copy */
void F1324_11855 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1324_11900(Current);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb1 = F1257_11506(Current, loc1);
		}
		if (tb1) {
			F1324_11898(Current, loc1);
		} else {
			tr1 = F1324_11849(Current);
			F1324_11898(Current, tr1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (tr2);
		tr1 = F791_6186(RTCW(tr1), ti4_1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.is_equal */
EIF_BOOLEAN F1324_11856 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 tu4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		tr1 = RTOSCF(9359,F1037_9359, (Current));
		tb2 = F21_186(RTCW(tr1), Current, arg1);
		if (tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_1_);
			tb1 = (EIF_BOOLEAN)(ti4_1 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
		}
		if (tb1) {
			loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > loc2))) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				/* INLINED CODE (SPECIAL.item) */
				tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (loc1));
				/* END INLINED CODE */
				tu4_1 = tu4_2;
				/* INLINED CODE (SPECIAL.item) */
				tu4_3 = *((EIF_NATURAL_32 *)RTCW(loc3) + (loc1));
				/* END INLINED CODE */
				tu4_2 = tu4_3;
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == tu4_2);
				loc1++;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.replace */
void F1324_11857 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_NATURAL_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)))) = arg1;
	/* END INLINED CODE */
	;
	RTLE;
}

/* {DS_ARRAYED_LIST}.put_first */
void F1324_11858 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	
	
	F1324_11860(Current, arg1, ((EIF_INTEGER_32) 1L));
}

/* {DS_ARRAYED_LIST}.put_last */
void F1324_11859 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F39_479(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))++;
	RTLE;
}

/* {DS_ARRAYED_LIST}.put */
void F1324_11860 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 == (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) + ((EIF_INTEGER_32) 1L)))) {
		F1324_11859(Current, arg1);
	} else {
		F1324_11895(Current, arg2, ((EIF_INTEGER_32) 1L));
		F1324_11903(Current, arg2, ((EIF_INTEGER_32) 1L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)))) = arg1;
		/* END INLINED CODE */
		;
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.force_first */
void F1324_11863 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1324_11854(Current, ((EIF_INTEGER_32) 1L))) {
		ti4_1 = F1317_11807(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) + ((EIF_INTEGER_32) 1L)));
		F1324_11893(Current, ti4_1);
	}
	F1324_11860(Current, arg1, ((EIF_INTEGER_32) 1L));
	RTLE;
}

/* {DS_ARRAYED_LIST}.force_last */
void F1324_11864 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1324_11854(Current, ((EIF_INTEGER_32) 1L))) {
		ti4_1 = F1317_11807(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) + ((EIF_INTEGER_32) 1L)));
		F1324_11893(Current, ti4_1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F39_479(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))++;
	RTLE;
}

/* {DS_ARRAYED_LIST}.force_left_cursor */
void F1324_11866 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1324_11854(Current, ((EIF_INTEGER_32) 1L))) {
		ti4_1 = F1317_11807(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) + ((EIF_INTEGER_32) 1L)));
		F1324_11893(Current, ti4_1);
	}
	ti4_1 = F1212_11215(RTCW(arg2));
	F1324_11860(Current, arg1, ti4_1);
	RTLE;
}

/* {DS_ARRAYED_LIST}.extend_last */
void F1324_11869 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9315[Dtype(RTCW(arg1))-1277])(arg1);
	F1145_11160(RTCW(loc2));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4738[Dtype(RTCW(loc2))-426])(loc2);
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tu4_1 = F1130_11140(RTCW(loc2));
		F39_479(RTCW(tr1), tr2, tu4_1, loc1);
		loc1++;
		F1145_11161(RTCW(loc2));
	}
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9283[Dtype(RTCW(arg1))-1277])(arg1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_)) += ti4_1;
	RTLE;
}

/* {DS_ARRAYED_LIST}.append_last */
void F1324_11874 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R9283[Dtype(RTCW(arg1))-1277])(arg1);
	if ((EIF_BOOLEAN) !F1324_11854(Current, loc1)) {
		ti4_1 = F1317_11807(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) + loc1));
		F1324_11893(Current, ti4_1);
	}
	F1324_11869(Current, arg1);
	RTLE;
}

/* {DS_ARRAYED_LIST}.remove_first */
void F1324_11878 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1324_11880(Current, ((EIF_INTEGER_32) 1L));
}

/* {DS_ARRAYED_LIST}.remove_last */
void F1324_11879 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1324_11901(Current);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))--;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F791_6182(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	RTLE;
}

/* {DS_ARRAYED_LIST}.remove */
void F1324_11880 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))) {
		F1324_11879(Current);
	} else {
		F1324_11902(Current, (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)));
		F1324_11896(Current, (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)), ((EIF_INTEGER_32) 1L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F791_6182(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.prune_last */
void F1324_11885 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1324_11900(Current);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_)) -= arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F791_6182(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	RTLE;
}

/* {DS_ARRAYED_LIST}.keep_first */
void F1324_11889 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1324_11900(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) = (EIF_INTEGER_32) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F791_6182(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	RTLE;
}

/* {DS_ARRAYED_LIST}.delete */
void F1324_11891 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	F1324_11900(Current);
	if ((EIF_BOOLEAN) !F1240_11471(Current)) {
		loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ((EIF_INTEGER_32) 1L));
		tr1 = *(EIF_REFERENCE *)(Current);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc3)) break;
				for (;;) {
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (loc1 > loc3)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						/* INLINED CODE (SPECIAL.item) */
						tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (loc1));
						/* END INLINED CODE */
						tu4_1 = tu4_2;
						tb2 = F355_5238(loc4, tu4_1, arg1);
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) break;
					loc1++;
				}
				for (;;) {
					tb2 = '\01';
					if (!(EIF_BOOLEAN) (loc1 > loc3)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						/* INLINED CODE (SPECIAL.item) */
						tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (loc1));
						/* END INLINED CODE */
						tu4_1 = tu4_2;
						tb3 = F355_5238(loc4, tu4_1, arg1);
						tb2 = tb3;
					}
					if (tb2) break;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					/* INLINED CODE (SPECIAL.item) */
					tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr2) + (loc1));
					/* END INLINED CODE */
					tu4_1 = tu4_2;
					/* INLINED CODE (SPECIAL.put) */
					*((EIF_NATURAL_32 *)RTCW(tr1) + (loc2)) = tu4_1;
					/* END INLINED CODE */
					;
					loc2++;
					loc1++;
				}
			}
		} else {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc3)) break;
				for (;;) {
					tb3 = '\01';
					if (!(EIF_BOOLEAN) (loc1 > loc3)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						/* INLINED CODE (SPECIAL.item) */
						tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (loc1));
						/* END INLINED CODE */
						tu4_1 = tu4_2;
						tb3 = (EIF_BOOLEAN)(tu4_1 != arg1);
					}
					if (tb3) break;
					loc1++;
				}
				for (;;) {
					tb4 = '\01';
					if (!(EIF_BOOLEAN) (loc1 > loc3)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						/* INLINED CODE (SPECIAL.item) */
						tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (loc1));
						/* END INLINED CODE */
						tu4_1 = tu4_2;
						tb4 = (EIF_BOOLEAN)(tu4_1 == arg1);
					}
					if (tb4) break;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					/* INLINED CODE (SPECIAL.item) */
					tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr2) + (loc1));
					/* END INLINED CODE */
					tu4_1 = tu4_2;
					/* INLINED CODE (SPECIAL.put) */
					*((EIF_NATURAL_32 *)RTCW(tr1) + (loc2)) = tu4_1;
					/* END INLINED CODE */
					;
					loc2++;
					loc1++;
				}
			}
		}
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) = (EIF_INTEGER_32) loc2;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F791_6182(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.wipe_out */
void F1324_11892 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1324_11900(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F791_6182(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {DS_ARRAYED_LIST}.resize */
void F1324_11893 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F39_482(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) arg1;
	RTLE;
}

/* {DS_ARRAYED_LIST}.move_right */
void F1324_11895 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))) {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + arg2) - ((EIF_INTEGER_32) 2L));
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			/* INLINED CODE (SPECIAL.item) */
			tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr3) + ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			tu4_1 = tu4_2;
			F39_479(RTCW(tr1), tr2, tu4_1, loc1);
			loc1++;
		}
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + arg2) - ((EIF_INTEGER_32) 1L));
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			/* INLINED CODE (SPECIAL.item) */
			tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr3) + ((EIF_INTEGER_32) (loc1 - arg2)));
			/* END INLINED CODE */
			tu4_1 = tu4_2;
			F39_479(RTCW(tr1), tr2, tu4_1, loc1);
			loc1++;
		}
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + arg2) - ((EIF_INTEGER_32) 1L));
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < loc2)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			/* INLINED CODE (SPECIAL.item) */
			tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr2) + ((EIF_INTEGER_32) (loc1 - arg2)));
			/* END INLINED CODE */
			tu4_1 = tu4_2;
			/* INLINED CODE (SPECIAL.put) */
			*((EIF_NATURAL_32 *)RTCW(tr1) + (loc1)) = tu4_1;
			/* END INLINED CODE */
			;
			loc1--;
		}
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_)) += arg2;
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.move_left */
void F1324_11896 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L));
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		/* INLINED CODE (SPECIAL.item) */
		tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr2) + (loc1));
		/* END INLINED CODE */
		tu4_1 = tu4_2;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 - arg2))) = tu4_1;
		/* END INLINED CODE */
		;
		loc1++;
	}
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_)) -= arg2;
	RTLE;
}

/* {DS_ARRAYED_LIST}.set_internal_cursor */
void F1324_11898 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {DS_ARRAYED_LIST}.internal_cursor */
EIF_REFERENCE F1324_11899 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {DS_ARRAYED_LIST}.move_all_cursors_after */
void F1324_11900 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		F1216_11254(RTCW(loc1));
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		F1130_11149(RTCW(loc1), NULL);
		loc1 = (EIF_REFERENCE) loc2;
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.move_last_cursors_after */
void F1324_11901 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == loc1)) {
		F1216_11254(RTCW(loc2));
	}
	loc4 = (EIF_REFERENCE) loc2;
	tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
	loc2 = (EIF_REFERENCE) tr1;
	for (;;) {
		if ((EIF_BOOLEAN)(loc2 == NULL)) break;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == loc1)) {
			F1216_11254(RTCW(loc2));
			loc3 = *(EIF_REFERENCE *)(RTCW(loc2));
			F1130_11149(RTCW(loc4), loc3);
			F1130_11149(RTCW(loc2), NULL);
			loc2 = (EIF_REFERENCE) loc3;
		} else {
			loc4 = (EIF_REFERENCE) loc2;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
			loc2 = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.move_cursors_left */
void F1324_11902 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc2 == NULL)) break;
		loc1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_0_0_0_);
		if ((EIF_BOOLEAN) (loc1 >= (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)))) {
			F1216_11253(RTCW(loc2), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
		loc2 = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.move_cursors_right */
void F1324_11903 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_0_0_0_);
		if ((EIF_BOOLEAN) (loc2 >= (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)))) {
			F1216_11253(RTCW(loc1), (EIF_INTEGER_32) (loc2 + arg2));
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		loc1 = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.cursor_item */
EIF_NATURAL_32 F1324_11904 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	/* INLINED CODE (SPECIAL.item) */
	tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (ti4_1));
	/* END INLINED CODE */
	Result = tu4_2;
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.cursor_index */
EIF_INTEGER_32 F1324_11905 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_1 = ((EIF_INTEGER_32) -2L);
	if ((EIF_BOOLEAN)(Result == ti4_1)) {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	}
	RTLE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
}

/* {DS_ARRAYED_LIST}.cursor_is_first */
EIF_BOOLEAN F1324_11906 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN) !F1240_11471(Current)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		Result = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
	}
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.cursor_is_last */
EIF_BOOLEAN F1324_11907 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN) !F1240_11471(Current)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		Result = (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) - ((EIF_INTEGER_32) 1L)));
	}
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.cursor_same_position */
EIF_BOOLEAN F1324_11908 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_0_0_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.cursor_start */
void F1324_11909 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1153_11170(RTCW(arg1));
	if (F1240_11471(Current)) {
		F1216_11254(RTCW(arg1));
	} else {
		F1216_11253(RTCW(arg1), ((EIF_INTEGER_32) 0L));
		if (loc1) {
			F1257_11514(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.cursor_finish */
void F1324_11910 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1153_11170(RTCW(arg1));
	F1216_11253(RTCW(arg1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) - ((EIF_INTEGER_32) 1L)));
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) != ((EIF_INTEGER_32) 0L)) && loc1)) {
		F1257_11514(Current, arg1);
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.cursor_forth */
void F1324_11911 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) -1L));
	loc2++;
	if ((EIF_BOOLEAN) (loc2 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))) {
		loc2 = ((EIF_INTEGER_32) -2L);
		if ((EIF_BOOLEAN) !loc1) {
			F1257_11515(Current, arg1);
		}
	} else {
		if (loc1) {
			F1257_11514(Current, arg1);
		}
	}
	F1216_11253(RTCW(arg1), loc2);
	RTLE;
}

/* {DS_ARRAYED_LIST}.cursor_back */
void F1324_11912 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_1 = ((EIF_INTEGER_32) -2L);
	if ((EIF_BOOLEAN)(loc2 == ti4_1)) {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	} else {
		loc2--;
	}
	F1216_11253(RTCW(arg1), loc2);
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) -1L))) {
		if ((EIF_BOOLEAN) !loc1) {
			F1257_11515(Current, arg1);
		}
	} else {
		if (loc1) {
			F1257_11514(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.cursor_go_after */
void F1324_11915 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1153_11170(RTCW(arg1));
	F1216_11254(RTCW(arg1));
	if ((EIF_BOOLEAN) !loc1) {
		F1257_11515(Current, arg1);
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.correct_mismatch */
void F1324_11919 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(6296,F848_6296, (Current))) + _REFACS_7_);
	loc2 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc2))) {
		tb2 = F1034_9262(loc2);
		tb1 = tb2;
	}
	if (tb1) {
		F1324_11920(Current);
	} else {
		tb1 = F1027_8927(loc2);
		if (tb1) {
			loc1 = F1027_8961(loc2);
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 20130823L))) {
				F1324_11920(Current);
			} else {
				F848_6295(Current);
			}
		} else {
			F848_6295(Current);
		}
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.correct_mismatch_20130823 */
void F1324_11920 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	/* INLINED CODE (SPECIAL.overlapping_move) */
	memmove((EIF_NATURAL_32 *)RTCW(tr1) + (((EIF_INTEGER_32) 0L)),(EIF_NATURAL_32 *)RTCW(tr1) + ((EIF_INTEGER_32) 1L), (rt_uint_ptr)sizeof(EIF_NATURAL_32) * (rt_uint_ptr)*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	RT_SPECIAL_COUNT(tr1) = eif_max_int32(RT_SPECIAL_COUNT(tr1), ((EIF_INTEGER_32) 0L) + *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	/* END INLINED CODE */
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F791_6182(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (tr1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

void EIF_Minit1686 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
