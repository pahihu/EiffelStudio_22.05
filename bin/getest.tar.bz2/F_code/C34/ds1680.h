
#ifndef _C34_ds1680_
#define _C34_ds1680_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1310_11690(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1680(void);
extern void F1323_11866(EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
