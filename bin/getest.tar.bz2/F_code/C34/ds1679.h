
#ifndef _C34_ds1679_
#define _C34_ds1679_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1211_11215(EIF_REFERENCE);
extern void EIF_Minit1679(void);
extern EIF_INTEGER_32 F1323_11905(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
