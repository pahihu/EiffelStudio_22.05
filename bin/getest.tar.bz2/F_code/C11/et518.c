/*
 * Code for class ET_INDEXING_LIST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et518.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_INDEXING_LIST}.make_with_capacity */
void F1417_13237 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(3668,F282_3668, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F905_7414(Current, arg1);
	RTLE;
}

/* {ET_INDEXING_LIST}.position */
EIF_REFERENCE F1417_13239 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1687_15455(RTCW(tr1));
	tb1 = '\0';
	tb2 = F1112_10963(RTCW(Result));
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !F905_7420(Current);
	}
	if (tb1) {
		Result = F1529_13834(RTCV(F905_7416(Current)));
	}
	RTLE;
	return Result;
}

/* {ET_INDEXING_LIST}.last_leaf */
EIF_REFERENCE F1417_13241 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	if (F905_7420(Current)) {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_1_);
	} else {
		Result = F1529_13836(RTCV(F905_7417(Current)));
	}
	RTLE;
	return Result;
}

/* {ET_INDEXING_LIST}.set_indexing_keyword */
void F1417_13244 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {ET_INDEXING_LIST}.append_tagged_indexing_terms_to_list */
void F1417_13245 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc3);
	RTLR(6,arg1);
	RTLR(7,arg2);
	RTLIU(8);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		/* INLINED CODE (SPECIAL.item) */
		tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
		/* END INLINED CODE */
		tr1 = tr3;
		loc2 = F1529_13833(RTCW(tr1));
		tb1 = '\0';
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10659[Dtype(RTCW(loc2))-1528])(loc2);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			tr1 = RTOSCF(9540,F1056_9540, (Current));
			tr2 = F1752_16147(loc3);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_1_);
			tb2 = F1048_9428(RTCW(tr1), tr2, arg1);
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
			F1398_13045(RTCW(tr1), arg2);
		}
		loc1--;
	}
	RTLE;
}

/* {ET_INDEXING_LIST}.fixed_array */
static EIF_REFERENCE F1417_13247_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (13247);
#define Result RTOSR(13247)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,35,0xFF01,1526,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 35, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (13247);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1417_13247 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13247,F1417_13247_body,(Current));
}

void EIF_Minit518 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
