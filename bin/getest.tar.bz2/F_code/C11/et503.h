
#ifndef _C11_et503_
#define _C11_et503_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1402_13082(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1402_13083(EIF_REFERENCE);
extern EIF_REFERENCE F1402_13085(EIF_REFERENCE);
extern EIF_REFERENCE F1402_13087(EIF_REFERENCE);
extern EIF_REFERENCE F1402_13089(EIF_REFERENCE);
extern void F1402_13090(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit503(void);
extern EIF_REFERENCE F1406_13127(EIF_REFERENCE);
extern void F1406_13122(EIF_REFERENCE);
extern char *(*R10452[])();
extern char *(*R10428[])();
extern char *(*R10232[])();
extern char *(*R1631[])();
extern char *(*R10228[])();

#ifdef __cplusplus
}
#endif

#endif
