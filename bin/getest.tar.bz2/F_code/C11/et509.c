/*
 * Code for class ET_AGENT_ARGUMENT_OPERAND_LIST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et509.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_AGENT_ARGUMENT_OPERAND_LIST}.make_with_capacity */
void F1408_13143 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(3625,F282_3625, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(3632,F282_3632, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	F905_7414(Current, arg1);
	RTLE;
}

/* {ET_AGENT_ARGUMENT_OPERAND_LIST}.reset */
void F1408_13144 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc2);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLIU(8);
	
	RTGC;
	loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_);
	loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - ((EIF_INTEGER_32) 1L));
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc3 > loc4)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		/* INLINED CODE (SPECIAL.item) */
		tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc3));
		/* END INLINED CODE */
		loc1 = tr3;
		loc2 = F1440_13371(RTCW(loc1));
		loc5 = loc2;
		loc5 = RTRV(eif_new_type(1489, 0x01),loc5);
		if (EIF_TEST(loc5)) {
			loc2 = *(EIF_REFERENCE *)(loc5);
			loc6 = loc1;
			loc6 = RTRV(eif_new_type(1438, 0x01),loc6);
			if (EIF_TEST(loc6)) {
				(RTNA((loc6, loc2)));
			} else {
				tr1 = *(EIF_REFERENCE *)(Current);
				/* INLINED CODE (SPECIAL.put) */
				*((EIF_REFERENCE *)RTCW(tr1) + (loc3)) = loc2;
				RTAR(tr1,loc2);
				/* END INLINED CODE */
				;
			}
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10390[Dtype(RTCW(loc2))-1430])(loc2);
		loc3++;
	}
	RTLE;
}

/* {ET_AGENT_ARGUMENT_OPERAND_LIST}.actual_argument */
EIF_REFERENCE F1408_13145 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = F905_7415(Current, arg1);
	Result = F1440_13371(RTCW(tr1));
	RTLE;
	return Result;
}

/* {ET_AGENT_ARGUMENT_OPERAND_LIST}.position */
EIF_REFERENCE F1408_13148 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1687_15455(RTCW(tr1));
	tb1 = '\0';
	tb2 = F1112_10963(RTCW(Result));
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !F146_1415(Current);
	}
	if (tb1) {
		tr1 = F905_7415(Current, ((EIF_INTEGER_32) 1L));
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10228[Dtype(RTCW(tr1))-1392])(tr1);
	}
	RTLE;
	return Result;
}

/* {ET_AGENT_ARGUMENT_OPERAND_LIST}.last_leaf */
EIF_REFERENCE F1408_13150 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_2_);
}

/* {ET_AGENT_ARGUMENT_OPERAND_LIST}.fixed_array */
static EIF_REFERENCE F1408_13153_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (13153);
#define Result RTOSR(13153)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,35,0xFF01,1437,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 35, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (13153);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1408_13153 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13153,F1408_13153_body,(Current));
}

void EIF_Minit509 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
