/*
 * Code for class ET_CONVERT_FEATURE_LIST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et516.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_CONVERT_FEATURE_LIST}.make_with_capacity */
void F1415_13214 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(3648,F282_3648, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F905_7414(Current, arg1);
	RTLE;
}

/* {ET_CONVERT_FEATURE_LIST}.reset */
void F1415_13215 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		/* INLINED CODE (SPECIAL.item) */
		tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
		/* END INLINED CODE */
		tr1 = tr3;
		tr1 = F1523_13802(RTCW(tr1));
		F1523_13795(RTCW(tr1));
		loc1++;
	}
	RTLE;
}

/* {ET_CONVERT_FEATURE_LIST}.convert_feature */
EIF_REFERENCE F1415_13217 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = F905_7415(Current, arg1);
	Result = F1523_13802(RTCW(tr1));
	RTLE;
	return Result;
}

/* {ET_CONVERT_FEATURE_LIST}.position */
EIF_REFERENCE F1415_13219 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1687_15455(RTCW(tr1));
	tb1 = '\0';
	tb2 = F1112_10963(RTCW(Result));
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !F905_7420(Current);
	}
	if (tb1) {
		Result = F1523_13800(RTCV(F905_7416(Current)));
	}
	RTLE;
	return Result;
}

/* {ET_CONVERT_FEATURE_LIST}.last_leaf */
EIF_REFERENCE F1415_13221 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if (F905_7420(Current)) {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_1_);
	} else {
		tr1 = F905_7417(Current);
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10232[Dtype(RTCW(tr1))-1392])(tr1);
	}
	RTLE;
	return Result;
}

/* {ET_CONVERT_FEATURE_LIST}.fixed_array */
static EIF_REFERENCE F1415_13224_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (13224);
#define Result RTOSR(13224)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,35,0xFF01,1520,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 35, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (13224);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1415_13224 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13224,F1415_13224_body,(Current));
}

void EIF_Minit516 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
