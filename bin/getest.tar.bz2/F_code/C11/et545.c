/*
 * Code for class ET_ASSERTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et545.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ASSERTION}.reset */
void F1444_13389 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {ET_ASSERTION}.is_class_assertion */
EIF_BOOLEAN F1444_13390 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {ET_ASSERTION}.assertion */
EIF_REFERENCE F1444_13392 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

void EIF_Minit545 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
