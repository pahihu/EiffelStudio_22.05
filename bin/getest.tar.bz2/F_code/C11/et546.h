
#ifndef _C11_et546_
#define _C11_et546_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1445_13393(EIF_REFERENCE, EIF_REFERENCE);
extern void F1445_13394(EIF_REFERENCE);
extern EIF_BOOLEAN F1445_13395(EIF_REFERENCE);
extern EIF_REFERENCE F1445_13398(EIF_REFERENCE);
extern EIF_REFERENCE F1445_13399(EIF_REFERENCE);
extern EIF_REFERENCE F1445_13401(EIF_REFERENCE);
extern void F1445_13402(EIF_REFERENCE, EIF_REFERENCE);
extern void F1445_13403(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit546(void);
extern EIF_REFERENCE F1687_15455(EIF_REFERENCE);
extern EIF_REFERENCE F1687_15458(EIF_REFERENCE);
extern char *(*R10428[])();
extern char *(*R10429[])();
extern char *(*R10232[])();
extern char *(*R1747[])();

#ifdef __cplusplus
}
#endif

#endif
