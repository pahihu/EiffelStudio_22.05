/*
 * Code for class ET_RENAME_LIST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et525.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_RENAME_LIST}.make_with_capacity */
void F1424_13282 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(3684,F282_3684, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F905_7414(Current, arg1);
	RTLE;
}

/* {ET_RENAME_LIST}.reset */
void F1424_13283 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current + O6235[Dtype(Current)-904]);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		/* INLINED CODE (SPECIAL.item) */
		tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
		/* END INLINED CODE */
		tr1 = tr3;
		tr1 = F1422_13271(RTCW(tr1));
		F1422_13267(RTCW(tr1));
		loc1++;
	}
	RTLE;
}

/* {ET_RENAME_LIST}.rename_pair */
EIF_REFERENCE F1424_13285 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = F905_7415(Current, arg1);
	Result = F1422_13271(RTCW(tr1));
	RTLE;
	return Result;
}

/* {ET_RENAME_LIST}.index_of_old_name */
EIF_INTEGER_32 F1424_13286 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current + O6235[dtype-904]);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		/* INLINED CODE (SPECIAL.item) */
		tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
		/* END INLINED CODE */
		tr1 = tr3;
		tr1 = F1422_13271(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11434[Dtype(RTCW(tr1))-1710])(tr1, arg1);
		if (tb1) {
			Result = *(EIF_INTEGER_32 *)(Current + O6235[dtype-904]);
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result - loc1);
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		} else {
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {ET_RENAME_LIST}.index_of_new_name */
EIF_INTEGER_32 F1424_13287 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current + O6235[dtype-904]);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	loc3 = arg1;
	loc3 = RTRV(eif_new_type(1751, 0x01),loc3);
	if (EIF_TEST(loc3)) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = *(EIF_REFERENCE *)(Current);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
			/* END INLINED CODE */
			tr1 = tr3;
			tr1 = F1422_13271(RTCW(tr1));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10815[Dtype(RTCW(tr1))-1590])(tr1);
			tb1 = F1752_16174(loc3, tr1);
			if (tb1) {
				Result = *(EIF_INTEGER_32 *)(Current + O6235[dtype-904]);
				Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result - loc1);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
			} else {
				loc1++;
			}
		}
	} else {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current);
			/* INLINED CODE (SPECIAL.item) */
			tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
			/* END INLINED CODE */
			tr1 = tr3;
			tr1 = F1422_13271(RTCW(tr1));
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10816[Dtype(RTCW(tr1))-1590])(tr1);
			loc4 = tr1;
			if (EIF_TEST(loc4)) {
				tb2 = F1411_13182(loc4, arg1);
				tb1 = tb2;
			}
			if (tb1) {
				Result = *(EIF_INTEGER_32 *)(Current + O6235[dtype-904]);
				Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result - loc1);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
			} else {
				loc1++;
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_RENAME_LIST}.position */
EIF_REFERENCE F1424_13288 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1687_15455(RTCW(tr1));
	tb1 = '\0';
	tb2 = F1112_10963(RTCW(Result));
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !F905_7420(Current);
	}
	if (tb1) {
		Result = F1422_13272(RTCV(F905_7416(Current)));
	}
	RTLE;
	return Result;
}

/* {ET_RENAME_LIST}.last_leaf */
EIF_REFERENCE F1424_13290 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	if (F905_7420(Current)) {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_1_);
	} else {
		Result = F1422_13274(RTCV(F905_7417(Current)));
	}
	RTLE;
	return Result;
}

/* {ET_RENAME_LIST}.fixed_array */
static EIF_REFERENCE F1424_13293_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (13293);
#define Result RTOSR(13293)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,35,0xFF01,1420,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 35, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (13293);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1424_13293 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13293,F1424_13293_body,(Current));
}

void EIF_Minit525 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
