
#ifndef _C11_et537_
#define _C11_et537_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1436_13347(EIF_REFERENCE);
extern EIF_REFERENCE F1436_13350(EIF_REFERENCE);
extern void EIF_Minit537(void);

#ifdef __cplusplus
}
#endif

#endif
