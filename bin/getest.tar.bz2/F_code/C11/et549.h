
#ifndef _C11_et549_
#define _C11_et549_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1448_13415(EIF_REFERENCE);
extern void EIF_Minit549(void);

#ifdef __cplusplus
}
#endif

#endif
