/*
 * Code for class ET_ELSEIF_EXPRESSION_LIST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et504.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ELSEIF_EXPRESSION_LIST}.reset */
void F1403_13091 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		/* INLINED CODE (SPECIAL.item) */
		tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
		/* END INLINED CODE */
		tr1 = tr3;
		F1404_13099(RTCW(tr1));
		loc1++;
	}
	RTLE;
}

/* {ET_ELSEIF_EXPRESSION_LIST}.position */
EIF_REFERENCE F1403_13092 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !F905_7420(Current)) {
		Result = F1404_13104(RTCV(F905_7416(Current)));
	} else {
		Result = RTOSCF(4244,F282_4244, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	}
	RTLE;
	return Result;
}

/* {ET_ELSEIF_EXPRESSION_LIST}.last_leaf */
EIF_REFERENCE F1403_13094 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !F905_7420(Current)) {
		Result = F1404_13106(RTCV(F905_7417(Current)));
	} else {
		Result = RTOSCF(3606,F282_3606, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	}
	RTLE;
	return Result;
}

/* {ET_ELSEIF_EXPRESSION_LIST}.is_instance_free */
EIF_BOOLEAN F1403_13095 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = F905_7415(Current, loc1);
		tb1 = F1404_13107(RTCW(tr1));
		if ((EIF_BOOLEAN) !tb1) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc1 = (EIF_INTEGER_32) loc2;
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {ET_ELSEIF_EXPRESSION_LIST}.fixed_array */
static EIF_REFERENCE F1403_13097_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (13097);
#define Result RTOSR(13097)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,35,0xFF01,1403,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 35, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (13097);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1403_13097 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13097,F1403_13097_body,(Current));
}

void EIF_Minit504 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
