/*
 * Code for class ET_OPERAND
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et529.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_OPERAND}.reset */
void F1428_13319 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {ET_OPERAND}.is_instance_free */
EIF_BOOLEAN F1428_13321 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {ET_OPERAND}.set_index */
void F1428_13324 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current + O10394[Dtype(Current)-1427]) = (EIF_INTEGER_32) arg1;
}

void EIF_Minit529 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
