
#ifndef _C11_et527_
#define _C11_et527_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1426_13300(EIF_REFERENCE);
extern EIF_BOOLEAN F1426_13303(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,13308)
static EIF_REFERENCE F1426_13308_body(EIF_REFERENCE);
extern EIF_REFERENCE F1426_13308(EIF_REFERENCE);
extern void EIF_Minit527(void);
extern char *(*R10631[])();
extern char *(*R11128[])();
extern char *(*R10915[])();

#ifdef __cplusplus
}
#endif

#endif
