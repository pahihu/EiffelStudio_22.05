
#ifndef _C11_et532_
#define _C11_et532_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1431_13325(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1431_13327(EIF_REFERENCE);
extern EIF_REFERENCE F1431_13329(EIF_REFERENCE);
extern EIF_BOOLEAN F1431_13331(EIF_REFERENCE);
extern void F1431_13332(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit532(void);
extern void F166_1807(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R10232[])();
extern char *(*R10528[])();
extern char *(*R10228[])();

#ifdef __cplusplus
}
#endif

#endif
