
#ifndef _C11_et529_
#define _C11_et529_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1428_13319(EIF_REFERENCE);
extern EIF_BOOLEAN F1428_13321(EIF_REFERENCE);
extern void F1428_13324(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit529(void);
extern long O10394[];

#ifdef __cplusplus
}
#endif

#endif
