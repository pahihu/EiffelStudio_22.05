
#ifndef _C11_et505_
#define _C11_et505_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1404_13098(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1404_13099(EIF_REFERENCE);
extern EIF_REFERENCE F1404_13101(EIF_REFERENCE);
extern EIF_REFERENCE F1404_13104(EIF_REFERENCE);
extern EIF_REFERENCE F1404_13106(EIF_REFERENCE);
extern EIF_BOOLEAN F1404_13107(EIF_REFERENCE);
extern void F1404_13109(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit505(void);
extern EIF_REFERENCE F870_6526(EIF_REFERENCE);
extern EIF_REFERENCE F282_3693(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,3693)
RTOSHF(EIF_REFERENCE,6526)
extern char *(*R1629[])();
extern char *(*R1389[])();
extern char *(*R10452[])();
extern char *(*R10428[])();
extern char *(*R10232[])();
extern char *(*R10228[])();

#ifdef __cplusplus
}
#endif

#endif
