
#ifndef _C11_et542_
#define _C11_et542_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1441_13372(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1441_13376(EIF_REFERENCE);
extern EIF_REFERENCE F1441_13378(EIF_REFERENCE);
extern void F1441_13380(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit542(void);
extern void F166_1808(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R10232[])();
extern char *(*R10529[])();
extern char *(*R10228[])();

#ifdef __cplusplus
}
#endif

#endif
