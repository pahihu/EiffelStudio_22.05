/*
 * Code for class ET_FEATURE_CLAUSE_LIST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et515.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_FEATURE_CLAUSE_LIST}.position */
EIF_REFERENCE F1414_13208 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !F905_7420(Current)) {
		Result = F1410_13169(RTCV(F905_7416(Current)));
	} else {
		Result = RTOSCF(4244,F282_4244, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	}
	RTLE;
	return Result;
}

/* {ET_FEATURE_CLAUSE_LIST}.last_leaf */
EIF_REFERENCE F1414_13210 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !F905_7420(Current)) {
		Result = F1410_13171(RTCV(F905_7417(Current)));
	} else {
		Result = RTOSCF(3606,F282_3606, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	}
	RTLE;
	return Result;
}

/* {ET_FEATURE_CLAUSE_LIST}.fixed_array */
static EIF_REFERENCE F1414_13212_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (13212);
#define Result RTOSR(13212)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,35,0xFF01,1409,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 35, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (13212);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1414_13212 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13212,F1414_13212_body,(Current));
}

void EIF_Minit515 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
