/*
 * Code for class ET_ELSEIF_EXPRESSION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et505.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ELSEIF_EXPRESSION}.make */
void F1404_13098 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	tr1 = RTOSCF(3693,F282_3693, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {ET_ELSEIF_EXPRESSION}.reset */
void F1404_13099 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1404_13101(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10428[Dtype(RTCW(tr1))-1444])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R10428[Dtype(RTCW(tr1))-1444])(tr1);
	RTLE;
}

/* {ET_ELSEIF_EXPRESSION}.conditional_expression */
EIF_REFERENCE F1404_13101 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10452[Dtype(RTCW(tr1))-1451])(tr1);
	RTLE;
	return Result;
}

/* {ET_ELSEIF_EXPRESSION}.position */
EIF_REFERENCE F1404_13104 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10228[Dtype(RTCW(tr1))-1392])(tr1);
	RTLE;
	return Result;
}

/* {ET_ELSEIF_EXPRESSION}.last_leaf */
EIF_REFERENCE F1404_13106 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10232[Dtype(RTCW(tr1))-1392])(tr1);
	RTLE;
	return Result;
}

/* {ET_ELSEIF_EXPRESSION}.is_instance_free */
EIF_BOOLEAN F1404_13107 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tr1 = F1404_13101(Current);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1389[Dtype(RTCW(tr1))-288])(tr1);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1389[Dtype(RTCW(tr1))-288])(tr1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {ET_ELSEIF_EXPRESSION}.process */
void F1404_13109 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1629[Dtype(RTCW(arg1))-165])(arg1, Current);
}

void EIF_Minit505 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
