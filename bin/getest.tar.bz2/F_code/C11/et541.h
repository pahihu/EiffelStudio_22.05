
#ifndef _C11_et541_
#define _C11_et541_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1440_13371(EIF_REFERENCE);
extern void EIF_Minit541(void);

#ifdef __cplusplus
}
#endif

#endif
