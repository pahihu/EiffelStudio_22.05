
#ifndef _C11_et545_
#define _C11_et545_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1444_13389(EIF_REFERENCE);
extern EIF_BOOLEAN F1444_13390(EIF_REFERENCE);
extern EIF_REFERENCE F1444_13392(EIF_REFERENCE);
extern void EIF_Minit545(void);

#ifdef __cplusplus
}
#endif

#endif
