/*
 * Code for class ET_PARENT_LIST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et513.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_PARENT_LIST}.make_with_capacity */
void F1412_13187 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(3669,F282_3669, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F905_7414(Current, arg1);
	RTLE;
}

/* {ET_PARENT_LIST}.reset */
void F1412_13188 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		/* INLINED CODE (SPECIAL.item) */
		tr3 = *((EIF_REFERENCE *)RTCW(tr1) + (loc1));
		/* END INLINED CODE */
		tr1 = tr3;
		tr1 = F1509_13731(RTCW(tr1));
		F1509_13723(RTCW(tr1));
		loc1++;
	}
	RTLE;
}

/* {ET_PARENT_LIST}.is_conforming */
EIF_BOOLEAN F1412_13189 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) == NULL);
}

/* {ET_PARENT_LIST}.has_conforming_parent */
EIF_BOOLEAN F1412_13190 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) == NULL) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) > ((EIF_INTEGER_32) 0L)));
}

/* {ET_PARENT_LIST}.parent */
EIF_REFERENCE F1412_13191 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = F905_7415(Current, arg1);
	Result = F1509_13731(RTCW(tr1));
	RTLE;
	return Result;
}

/* {ET_PARENT_LIST}.position */
EIF_REFERENCE F1412_13194 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1687_15455(RTCW(tr1));
	tb1 = F1112_10963(RTCW(Result));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			Result = F1409_13159(loc1);
			RTLE;
			return (EIF_REFERENCE) Result;
		} else {
			if ((EIF_BOOLEAN) !F905_7420(Current)) {
				Result = F1509_13732(RTCV(F905_7416(Current)));
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_PARENT_LIST}.last_leaf */
EIF_REFERENCE F1412_13196 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if (F905_7420(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = F1409_13161(loc1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			RTLE;
			return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_1_);
		}
	} else {
		Result = F1509_13734(RTCV(F905_7417(Current)));
	}
	RTLE;
	return Result;
}

/* {ET_PARENT_LIST}.set_clients_clause */
void F1412_13198 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {ET_PARENT_LIST}.fixed_array */
static EIF_REFERENCE F1412_13200_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (13200);
#define Result RTOSR(13200)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,35,0xFF01,1506,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 35, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (13200);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1412_13200 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13200,F1412_13200_body,(Current));
}

void EIF_Minit513 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
