#include "eif_eiffel.h"
#include "eif_rout_obj.h"
#include "eaddress.h"
#include "eoffsets.h"

#ifdef __cplusplus
extern "C" {
#endif

	/* MISMATCH_INFORMATION wipe_out */
void A272_98 (EIF_REFERENCE Current)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F862_6449)(Current);
}

	/* MISMATCH_INFORMATION internal_put */
void A272_162 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER)) F869_6522)(Current, arg1, arg2);
}

	/* MISMATCH_INFORMATION set_string_versions */
void A272_163 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER)) F869_6523)(Current, arg1, arg2);
}

	/* ET_CLIENT_LIST has_class */
EIF_BOOLEAN _A309_62_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_CLIENT_LIST has_class */
EIF_BOOLEAN __A309_62_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* ET_CLASS implementation_checked */
EIF_BOOLEAN _A873_472_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17689)(open [1].it_r);
}

	/* ET_CLASS implementation_checked */
EIF_BOOLEAN __A873_472_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17689)(op_1);
}

	/* ET_CLASS interface_checked */
EIF_BOOLEAN _A873_457_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17674)(open [1].it_r);
}

	/* ET_CLASS interface_checked */
EIF_BOOLEAN __A873_457_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17674)(op_1);
}

	/* ET_CLASS features_flattened */
EIF_BOOLEAN _A873_448_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17665)(open [1].it_r);
}

	/* ET_CLASS features_flattened */
EIF_BOOLEAN __A873_448_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17665)(op_1);
}

	/* ET_CLASS ancestors_built */
EIF_BOOLEAN _A873_395_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17612)(open [1].it_r);
}

	/* ET_CLASS ancestors_built */
EIF_BOOLEAN __A873_395_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17612)(op_1);
}

	/* ET_CLASS is_parsed */
EIF_BOOLEAN _A873_333_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17550)(open [1].it_r);
}

	/* ET_CLASS is_parsed */
EIF_BOOLEAN __A873_333_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17550)(op_1);
}

	/* ET_CLASS is_marked */
EIF_BOOLEAN _A873_108_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F988_8806)(open [1].it_r);
}

	/* ET_CLASS is_marked */
EIF_BOOLEAN __A873_108_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F988_8806)(op_1);
}

	/* ET_CLASS is_in_override_group */
EIF_BOOLEAN _A873_330_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17547)(open [1].it_r);
}

	/* ET_CLASS is_in_override_group */
EIF_BOOLEAN __A873_330_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17547)(op_1);
}

	/* ET_CLASS is_in_group_recursive */
EIF_BOOLEAN _A873_321_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS is_in_group_recursive */
EIF_BOOLEAN __A873_321_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS is_in_group */
EIF_BOOLEAN _A873_320_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1772_17537)(open [1].it_r, closed [1].it_r);
}

	/* ET_CLASS is_in_group */
EIF_BOOLEAN __A873_320_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1772_17537)(op_1, closed [1].it_r);
}

	/* ET_CLASS add_by_group */
void _A873_318_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS add_by_group */
void __A873_318_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS reset_errors */
void _A873_243_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS reset_errors */
void __A873_243_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS reset_after_parsed_and_errors */
void _A873_244_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17461)(open [1].it_r);
}

	/* ET_CLASS reset_after_parsed_and_errors */
void __A873_244_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17461)(op_1);
}

	/* ET_CLASS reset_after_preparsed */
void _A873_238_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17455)(open [1].it_r);
}

	/* ET_CLASS reset_after_preparsed */
void __A873_238_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17455)(op_1);
}

	/* ET_CLASS has_syntax_error */
EIF_BOOLEAN _A873_335_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17552)(open [1].it_r);
}

	/* ET_CLASS has_syntax_error */
EIF_BOOLEAN __A873_335_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17552)(op_1);
}

	/* ET_CLASS reset_after_parsed */
void _A873_239_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17456)(open [1].it_r);
}

	/* ET_CLASS reset_after_parsed */
void __A873_239_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17456)(op_1);
}

	/* ET_CLASS has_ancestors_error */
EIF_BOOLEAN _A873_397_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17614)(open [1].it_r);
}

	/* ET_CLASS has_ancestors_error */
EIF_BOOLEAN __A873_397_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17614)(op_1);
}

	/* ET_CLASS set_ancestors_error */
void _A873_399_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17616)(open [1].it_r);
}

	/* ET_CLASS set_ancestors_error */
void __A873_399_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17616)(op_1);
}

	/* ET_CLASS reset_after_ancestors_built */
void _A873_240_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17457)(open [1].it_r);
}

	/* ET_CLASS reset_after_ancestors_built */
void __A873_240_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17457)(op_1);
}

	/* ET_CLASS has_flattening_error */
EIF_BOOLEAN _A873_450_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17667)(open [1].it_r);
}

	/* ET_CLASS has_flattening_error */
EIF_BOOLEAN __A873_450_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17667)(op_1);
}

	/* ET_CLASS set_flattening_error */
void _A873_452_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17669)(open [1].it_r);
}

	/* ET_CLASS set_flattening_error */
void __A873_452_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17669)(op_1);
}

	/* ET_CLASS reset_after_features_flattened */
void _A873_241_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17458)(open [1].it_r);
}

	/* ET_CLASS reset_after_features_flattened */
void __A873_241_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17458)(op_1);
}

	/* ET_CLASS has_interface_error */
EIF_BOOLEAN _A873_459_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17676)(open [1].it_r);
}

	/* ET_CLASS has_interface_error */
EIF_BOOLEAN __A873_459_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17676)(op_1);
}

	/* ET_CLASS set_interface_error */
void _A873_461_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17678)(open [1].it_r);
}

	/* ET_CLASS set_interface_error */
void __A873_461_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17678)(op_1);
}

	/* ET_CLASS reset_after_interface_checked */
void _A873_242_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17459)(open [1].it_r);
}

	/* ET_CLASS reset_after_interface_checked */
void __A873_242_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17459)(op_1);
}

	/* ET_CLASS not_implementation_checked */
EIF_BOOLEAN _A873_99_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F988_8802)(open [1].it_r);
}

	/* ET_CLASS not_implementation_checked */
EIF_BOOLEAN __A873_99_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F988_8802)(op_1);
}

	/* ET_CLASS has_implementation_error */
EIF_BOOLEAN _A873_474_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17691)(open [1].it_r);
}

	/* ET_CLASS has_implementation_error */
EIF_BOOLEAN __A873_474_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17691)(op_1);
}

	/* ET_CLASS set_implementation_error */
void _A873_476_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17693)(open [1].it_r);
}

	/* ET_CLASS set_implementation_error */
void __A873_476_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1772_17693)(op_1);
}

	/* ET_CLASS unmark_ignored_class */
void _A873_282_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS unmark_ignored_class */
void __A873_282_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS mark_ignored_class */
void _A873_281_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS mark_ignored_class */
void __A873_281_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS is_unknown */
EIF_BOOLEAN _A873_278_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17495)(open [1].it_r);
}

	/* ET_CLASS is_unknown */
EIF_BOOLEAN __A873_278_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1772_17495)(op_1);
}

	/* ET_CLASS add_to_conforming_descendants */
void _A873_387_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS add_to_conforming_descendants */
void __A873_387_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS add_to_descendants */
void _A873_385_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS add_to_descendants */
void __A873_385_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_MASTER_CLASS process */
void _A466_164_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1365_12280)(open [1].it_r, closed [1].it_r);
}

	/* ET_MASTER_CLASS process */
void __A466_164_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1365_12280)(op_1, closed [1].it_r);
}

	/* ET_MASTER_CLASS reset_local_modified_class */
void _A466_162_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS reset_local_modified_class */
void __A466_162_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* ET_MASTER_CLASS unmark_overridden */
void _A466_144_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_MASTER_CLASS unmark_overridden */
void __A466_144_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_MASTER_CLASS mark_overridden */
void _A466_143_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_MASTER_CLASS mark_overridden */
void __A466_143_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_MASTER_CLASS local_override_classes_do_if */
void _A466_151_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1365_12267)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS local_override_classes_do_if */
void __A466_151_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1365_12267)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS is_in_universe */
EIF_BOOLEAN _A466_86_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_MASTER_CLASS is_in_universe */
EIF_BOOLEAN __A466_86_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_MASTER_CLASS local_non_override_classes_do_if */
void _A466_152_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1365_12268)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS local_non_override_classes_do_if */
void __A466_152_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1365_12268)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS local_classes_do_all */
void _A466_145_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_MASTER_CLASS local_classes_do_all */
void __A466_145_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_MASTER_CLASS local_classes_do_if */
void _A466_150_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1365_12266)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS local_classes_do_if */
void __A466_150_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1365_12266)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS is_preparsed */
EIF_BOOLEAN _A466_98_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1365_12214)(open [1].it_r);
}

	/* ET_MASTER_CLASS is_preparsed */
EIF_BOOLEAN __A466_98_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1365_12214)(op_1);
}

	/* ET_MASTER_CLASS has_syntax_error */
EIF_BOOLEAN _A466_101_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1365_12217)(open [1].it_r);
}

	/* ET_MASTER_CLASS has_syntax_error */
EIF_BOOLEAN __A466_101_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1365_12217)(op_1);
}

	/* ET_MASTER_CLASS local_classes_do_unless_actual */
void _A466_154_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1365_12270)(open [1].it_r, closed [1].it_r);
}

	/* ET_MASTER_CLASS local_classes_do_unless_actual */
void __A466_154_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1365_12270)(op_1, closed [1].it_r);
}

	/* ET_MASTER_CLASS set_modified */
void _A466_97_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) F1365_12213)(open [1].it_r, closed [1].it_b);
}

	/* ET_MASTER_CLASS set_modified */
void __A466_97_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) F1365_12213)(op_1, closed [1].it_b);
}

	/* ET_MASTER_CLASS remove_unknown_imported_classes */
void _A466_136_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1365_12252)(open [1].it_r);
}

	/* ET_MASTER_CLASS remove_unknown_imported_classes */
void __A466_136_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1365_12252)(op_1);
}

	/* ET_MASTER_CLASS reset_local_modified_classes */
void _A466_161_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1365_12277)(open [1].it_r, closed [1].it_r);
}

	/* ET_MASTER_CLASS reset_local_modified_classes */
void __A466_161_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1365_12277)(op_1, closed [1].it_r);
}

	/* ET_MASTER_CLASS remove_unknown_local_classes */
void _A466_134_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1365_12250)(open [1].it_r);
}

	/* ET_MASTER_CLASS remove_unknown_local_classes */
void __A466_134_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1365_12250)(op_1);
}

	/* ET_MASTER_CLASS local_ignored_classes_do_if */
void _A466_153_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1365_12269)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS local_ignored_classes_do_if */
void __A466_153_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1365_12269)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS has_imported_class */
EIF_BOOLEAN _A466_95_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_MASTER_CLASS has_imported_class */
EIF_BOOLEAN __A466_95_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* DS_ARRAYED_LIST [G#1] force_last */
void _A1065_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_ARRAYED_LIST [INTEGER_32] force_last */
void _A1677_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* DS_ARRAYED_LIST [NATURAL_32] force_last */
void _A1686_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_n4);
}

	/* DS_ARRAYED_LIST [G#1] force_last */
void __A1065_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_ARRAYED_LIST [INTEGER_32] force_last */
void __A1677_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_ARRAYED_LIST [NATURAL_32] force_last */
void __A1686_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_NATURAL_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_ARRAYED_LIST [G#1] has_void */
EIF_BOOLEAN _A1065_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* DS_ARRAYED_LIST [INTEGER_32] has_void */
EIF_BOOLEAN _A1677_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* DS_ARRAYED_LIST [NATURAL_32] has_void */
EIF_BOOLEAN _A1686_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* DS_ARRAYED_LIST [G#1] has_void */
EIF_BOOLEAN __A1065_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* DS_ARRAYED_LIST [INTEGER_32] has_void */
EIF_BOOLEAN __A1677_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* DS_ARRAYED_LIST [NATURAL_32] has_void */
EIF_BOOLEAN __A1686_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* DS_ARRAYED_LIST [G#1] is_empty */
EIF_BOOLEAN _A1065_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9284[Dtype(open [1].it_r) - 1277])(open [1].it_r);
}

	/* DS_ARRAYED_LIST [INTEGER_32] is_empty */
EIF_BOOLEAN _A1677_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1238_11471)(open [1].it_r);
}

	/* DS_ARRAYED_LIST [NATURAL_32] is_empty */
EIF_BOOLEAN _A1686_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1240_11471)(open [1].it_r);
}

	/* DS_ARRAYED_LIST [G#1] is_empty */
EIF_BOOLEAN __A1065_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R9284[Dtype(op_1) - 1277])(op_1);
}

	/* DS_ARRAYED_LIST [INTEGER_32] is_empty */
EIF_BOOLEAN __A1677_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1238_11471)(op_1);
}

	/* DS_ARRAYED_LIST [NATURAL_32] is_empty */
EIF_BOOLEAN __A1686_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1240_11471)(op_1);
}

	/* DS_ARRAYED_LIST [G#1] there_exists */
EIF_BOOLEAN _A1065_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R9290[Dtype(open [1].it_r) - 1321])(open [1].it_r, closed [1].it_r);
}

	/* DS_ARRAYED_LIST [INTEGER_32] there_exists */
EIF_BOOLEAN _A1677_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1307_11680)(open [1].it_r, closed [1].it_r);
}

	/* DS_ARRAYED_LIST [NATURAL_32] there_exists */
EIF_BOOLEAN _A1686_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1308_11680)(open [1].it_r, closed [1].it_r);
}

	/* DS_ARRAYED_LIST [G#1] there_exists */
EIF_BOOLEAN __A1065_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R9290[Dtype(op_1) - 1321])(op_1, closed [1].it_r);
}

	/* DS_ARRAYED_LIST [INTEGER_32] there_exists */
EIF_BOOLEAN __A1677_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1307_11680)(op_1, closed [1].it_r);
}

	/* DS_ARRAYED_LIST [NATURAL_32] there_exists */
EIF_BOOLEAN __A1686_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1308_11680)(op_1, closed [1].it_r);
}

	/* TS_CLUSTER process_class */
void _A415_50_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* TS_CLUSTER process_class */
void __A415_50_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* TS_CLUSTER is_testcase_class */
EIF_BOOLEAN _A415_45_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* TS_CLUSTER is_testcase_class */
EIF_BOOLEAN __A415_45_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* UT_TRISTATE set_true */
void _A14_38 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* UT_TRISTATE set_true */
void __A14_38 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* UT_TRISTATE is_true */
EIF_BOOLEAN _A14_35 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* UT_TRISTATE is_true */
EIF_BOOLEAN __A14_35 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] call */
void _A1628_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] call */
void _A1702_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] call */
void _A1703_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_c1, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] call */
void _A1704_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_b, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] call */
void __A1628_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] call */
void __A1702_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] call */
void __A1703_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_CHARACTER_8 op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] call */
void __A1704_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_BOOLEAN op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] negated */
EIF_BOOLEAN _A1628_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] negated */
EIF_BOOLEAN _A1702_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] negated */
EIF_BOOLEAN _A1703_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_c1, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] negated */
EIF_BOOLEAN _A1704_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_b, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] negated */
EIF_BOOLEAN __A1628_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] negated */
EIF_BOOLEAN __A1702_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] negated */
EIF_BOOLEAN __A1703_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_CHARACTER_8 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] negated */
EIF_BOOLEAN __A1704_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_BOOLEAN op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] conjuncted */
EIF_BOOLEAN _A1628_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] conjuncted */
EIF_BOOLEAN _A1702_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] conjuncted */
EIF_BOOLEAN _A1703_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_c1, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] conjuncted */
EIF_BOOLEAN _A1704_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_b, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] conjuncted */
EIF_BOOLEAN __A1628_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] conjuncted */
EIF_BOOLEAN __A1702_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] conjuncted */
EIF_BOOLEAN __A1703_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_CHARACTER_8 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] conjuncted */
EIF_BOOLEAN __A1704_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_BOOLEAN op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] conjuncted_semistrict */
EIF_BOOLEAN _A1628_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] conjuncted_semistrict */
EIF_BOOLEAN _A1702_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] conjuncted_semistrict */
EIF_BOOLEAN _A1703_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_c1, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] conjuncted_semistrict */
EIF_BOOLEAN _A1704_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_b, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] conjuncted_semistrict */
EIF_BOOLEAN __A1628_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] conjuncted_semistrict */
EIF_BOOLEAN __A1702_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] conjuncted_semistrict */
EIF_BOOLEAN __A1703_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_CHARACTER_8 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] conjuncted_semistrict */
EIF_BOOLEAN __A1704_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_BOOLEAN op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* ET_UNIVERSE fake inline-agent#22622#254#83# of classes_modified_recursive */
EIF_BOOLEAN _A479_282_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1378_22622)(closed [1].it_r, open [1].it_r);
}

	/* ET_UNIVERSE fake inline-agent#22622#254#83# of classes_modified_recursive */
EIF_BOOLEAN __A479_282_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1378_22622)(closed [1].it_r, op_2);
}

	/* ET_UNIVERSE master_classes_do_if */
void _A479_253_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1378_12594)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE master_classes_do_if */
void __A479_253_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1378_12594)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE master_classes_do_if_until */
void _A479_254_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1378_12595)(open [1].it_r, closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* ET_UNIVERSE master_classes_do_if_until */
void __A479_254_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1378_12595)(op_1, closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* ET_UNIVERSE master_classes_do_all */
void _A479_251_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1378_12592)(open [1].it_r, closed [1].it_r);
}

	/* ET_UNIVERSE master_classes_do_all */
void __A479_251_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1378_12592)(op_1, closed [1].it_r);
}

	/* ET_UNIVERSE master_classes_do_until */
void _A479_252_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1378_12593)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE master_classes_do_until */
void __A479_252_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1378_12593)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE classes_do_if */
void _A479_243_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1378_12584)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE classes_do_if */
void __A479_243_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1378_12584)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE classes_do_if_until */
void _A479_245_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE classes_do_if_until */
void __A479_245_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE classes_do_unless */
void _A479_244_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE classes_do_unless */
void __A479_244_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE classes_do_all */
void _A479_241_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE classes_do_all */
void __A479_241_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE classes_do_until */
void _A479_242_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE classes_do_until */
void __A479_242_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE insert_in_hash_table */
void _A479_280_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_i4, open [1].it_r);
}

	/* ET_UNIVERSE insert_in_hash_table */
void __A479_280_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_4)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_i4, op_4);
}

	/* ET_UNIVERSE add_classes_by_wildcarded_name */
void _A479_80_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE add_classes_by_wildcarded_name */
void __A479_80_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE do_class_by_wildcarded_name */
void _A479_268_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* ET_UNIVERSE do_class_by_wildcarded_name */
void __A479_268_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* ET_UNIVERSE do_class_by_name */
void _A479_267_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE do_class_by_name */
void __A479_267_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE do_master_class_by_name */
void _A479_266_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE do_master_class_by_name */
void __A479_266_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE has_class */
EIF_BOOLEAN _A479_71_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE has_class */
EIF_BOOLEAN __A479_71_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE has_master_class */
EIF_BOOLEAN _A479_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1378_12410)(open [1].it_r, closed [1].it_r);
}

	/* ET_UNIVERSE has_master_class */
EIF_BOOLEAN __A479_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1378_12410)(op_1, closed [1].it_r);
}

	/* DS_HASH_TABLE [G#1, G#2] has */
EIF_BOOLEAN _A1046_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_TABLE [INTEGER_32, G#2] has */
EIF_BOOLEAN _A1080_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_TABLE [G#1, INTEGER_32] has */
EIF_BOOLEAN _A1162_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_BOOLEAN Result;
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(950, 0x00).id, 950, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = open [1].it_i4;
	Result = f_ptr (closed [1].it_r, arg1);
	RTLE;
	return Result;
}

	/* DS_HASH_TABLE [NATURAL_64, NATURAL_32] has */
EIF_BOOLEAN _A1295_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_n4);
}

	/* DS_HASH_TABLE [G#1, NATURAL_8] has */
EIF_BOOLEAN _A1706_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_8), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_n1);
}

	/* DS_HASH_TABLE [BOOLEAN, G#2] has */
EIF_BOOLEAN _A1734_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_TABLE [NATURAL_8, G#2] has */
EIF_BOOLEAN _A1798_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_TABLE [INTEGER_32, INTEGER_32] has */
EIF_BOOLEAN _A1855_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* DS_HASH_TABLE [G#1, G#2] has */
EIF_BOOLEAN __A1046_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [INTEGER_32, G#2] has */
EIF_BOOLEAN __A1080_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [G#1, INTEGER_32] has */
EIF_BOOLEAN __A1162_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	EIF_BOOLEAN Result;
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(950, 0x00).id, 950, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = op_2;
	Result = f_ptr (closed [1].it_r, arg1);
	RTLE;
	return Result;
}

	/* DS_HASH_TABLE [NATURAL_64, NATURAL_32] has */
EIF_BOOLEAN __A1295_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_NATURAL_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [G#1, NATURAL_8] has */
EIF_BOOLEAN __A1706_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_8), EIF_TYPED_VALUE * closed, EIF_NATURAL_8 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [BOOLEAN, G#2] has */
EIF_BOOLEAN __A1734_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [NATURAL_8, G#2] has */
EIF_BOOLEAN __A1798_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [INTEGER_32, INTEGER_32] has */
EIF_BOOLEAN __A1855_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN _A371_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F627_5520)(open [1].it_r);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN __A371_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F627_5520)(op_1);
}

	/* DS_HASH_SET [G#1] force_last */
void _A1751_141_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_SET [INTEGER_32] force_last */
void _A1638_141_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* DS_HASH_SET [G#1] force_last */
void __A1751_141_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_SET [INTEGER_32] force_last */
void __A1638_141_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_SET [G#1] has */
EIF_BOOLEAN _A1751_131_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_SET [INTEGER_32] has */
EIF_BOOLEAN _A1638_131_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* DS_HASH_SET [G#1] has */
EIF_BOOLEAN __A1751_131_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_SET [INTEGER_32] has */
EIF_BOOLEAN __A1638_131_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* ET_ANCESTORS_STATUS_CHECKER process_class */
void _A282_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_ANCESTORS_STATUS_CHECKER process_class */
void __A282_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_FLATTENING_STATUS_CHECKER process_class */
void _A281_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_FLATTENING_STATUS_CHECKER process_class */
void __A281_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_INTERFACE_STATUS_CHECKER process_class */
void _A280_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_INTERFACE_STATUS_CHECKER process_class */
void __A280_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_IMPLEMENTATION_STATUS_CHECKER process_class */
void _A279_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_IMPLEMENTATION_STATUS_CHECKER process_class */
void __A279_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_INTERNAL_UNIVERSE dotnet_assemblies_do_if */
void _A480_309_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1379_12662)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_INTERNAL_UNIVERSE dotnet_assemblies_do_if */
void __A480_309_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1379_12662)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_INTERNAL_UNIVERSE clusters_do_explicit */
void _A480_301_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1379_12654)(open [1].it_r, closed [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE clusters_do_explicit */
void __A480_301_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1379_12654)(op_1, closed [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE add_implicit_subclusters */
void _A480_299_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE add_implicit_subclusters */
void __A480_299_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_INTERNAL_UNIVERSE do_cluster_with_absolute_pathname */
void _A480_312_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE do_cluster_with_absolute_pathname */
void __A480_312_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_INTERNAL_UNIVERSE has_cluster_with_absolute_pathname */
EIF_BOOLEAN _A480_276_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE has_cluster_with_absolute_pathname */
EIF_BOOLEAN __A480_276_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_INTERNAL_UNIVERSE has_cluster_by_name */
EIF_BOOLEAN _A480_274_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE has_cluster_by_name */
EIF_BOOLEAN __A480_274_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_INTERNAL_UNIVERSE has_cluster */
EIF_BOOLEAN _A480_272_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE has_cluster */
EIF_BOOLEAN __A480_272_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_DOTNET_ASSEMBLIES put_last */
void _A428_40_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_DOTNET_ASSEMBLIES put_last */
void __A428_40_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_CLUSTER process */
void _A487_171_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1386_12919)(open [1].it_r, closed [1].it_r);
}

	/* ET_CLUSTER process */
void __A487_171_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1386_12919)(op_1, closed [1].it_r);
}

	/* DS_CELL [G#1] put */
void _A1233_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_CELL [INTEGER_32] put */
void _A1294_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* DS_CELL [G#1] put */
void __A1233_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_CELL [INTEGER_32] put */
void __A1294_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_SYSTEM build_scm_write_mapping */
void _A481_421_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_SYSTEM build_scm_write_mapping */
void __A481_421_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_SYSTEM build_scm_read_mapping */
void _A481_417_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_SYSTEM build_scm_read_mapping */
void __A481_417_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_PARENT_LIST has_conforming_parent */
EIF_BOOLEAN _A513_68_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1412_13190)(open [1].it_r);
}

	/* ET_PARENT_LIST has_conforming_parent */
EIF_BOOLEAN __A513_68_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1412_13190)(op_1);
}

	/* ET_EIFFEL_SCANNER_SKELETON add_universe_full_name */
void _A900_510_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* ET_EIFFEL_SCANNER_SKELETON add_universe_full_name */
void __A900_510_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* ET_CLUSTER_DEPENDENCE_CONSTRAINT matches_pathname */
EIF_BOOLEAN _A967_48_4 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, open [1].it_r);
}

	/* ET_CLUSTER_DEPENDENCE_CONSTRAINT matches_pathname */
EIF_BOOLEAN __A967_48_4 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_4)
{
	return f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, op_4);
}

	/* KL_STRING_ROUTINES same_case_insensitive */
EIF_BOOLEAN _A377_56_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* KL_STRING_ROUTINES same_case_insensitive */
EIF_BOOLEAN __A377_56_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* TS_TESTCASES generate_call_to_i_th_build_suite_feature */
void _A968_53_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, closed [2].it_r);
}

	/* TS_TESTCASES generate_call_to_i_th_build_suite_feature */
void __A968_53_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* TS_TESTCASES generate_i_th_build_suite_feature */
void _A968_52_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, closed [2].it_r);
}

	/* TS_TESTCASES generate_i_th_build_suite_feature */
void __A968_52_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}


#ifdef __cplusplus
}
#endif
