/*
 * Code for class DS_INDEXABLE_SORTER [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1873.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_INDEXABLE_SORTER}.make */
void F80_1016 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {DS_INDEXABLE_SORTER}.sort */
void F80_1024 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F80_1026(Current, arg1, *(EIF_REFERENCE *)(Current));
}

/* {DS_INDEXABLE_SORTER}.sort_with_comparator */
void F80_1026 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tb1 = F1238_11471(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_1_);
		F83_1031(Current, arg1, arg2, ((EIF_INTEGER_32) 1L), ti4_1);
	}
	RTLE;
}

/* {DS_INDEXABLE_SORTER}.subsort */
void F80_1027 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	F83_1031(Current, arg1, *(EIF_REFERENCE *)(Current), arg2, arg3);
}

void EIF_Minit1873 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
