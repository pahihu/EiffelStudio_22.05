
#ifndef _C38_ce1853_
#define _C38_ce1853_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F130_1386(EIF_REFERENCE);
extern void F130_1387(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit1853(void);

#ifdef __cplusplus
}
#endif

#endif
