
#ifndef _C38_ds1855_
#define _C38_ds1855_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1363_12165(EIF_REFERENCE);
extern EIF_INTEGER_32 F1363_12168(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1855(void);
extern void F1176_11186(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_TYPE_INDEX Y1385[];
extern EIF_TYPE_INDEX *Y1385_gen_type [];
extern EIF_TYPE_INDEX Y9292[];
extern EIF_TYPE_INDEX *Y9292_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
