
#ifndef _C38_kl1868_
#define _C38_kl1868_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F365_5246(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_BOOLEAN F365_5249(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit1868(void);
extern EIF_BOOLEAN F367_5251(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
