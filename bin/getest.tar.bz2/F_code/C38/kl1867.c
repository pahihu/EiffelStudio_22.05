/*
 * Code for class KL_COMPARABLE_COMPARATOR [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl1867.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_COMPARABLE_COMPARATOR}.make */
void F367_5250 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {KL_COMPARABLE_COMPARATOR}.attached_less_than */
EIF_BOOLEAN F367_5251 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (arg1 < arg2);
}

void EIF_Minit1867 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
