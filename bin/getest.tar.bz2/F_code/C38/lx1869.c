/*
 * Code for class LX_SYMBOL_TRANSITION [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx1869.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_SYMBOL_TRANSITION}.make */
void F1234_11457 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) = (EIF_INTEGER_32) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {LX_SYMBOL_TRANSITION}.labeled */
EIF_BOOLEAN F1234_11460 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_) == arg1);
}

/* {LX_SYMBOL_TRANSITION}.record */
void F1234_11461 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R1240[Dtype(RTCW(arg1))-112])(arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_0_));
}

void EIF_Minit1869 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
