
#ifndef _C38_ce1852_
#define _C38_ce1852_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F129_1386(EIF_REFERENCE);
extern void F129_1387(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit1852(void);

#ifdef __cplusplus
}
#endif

#endif
