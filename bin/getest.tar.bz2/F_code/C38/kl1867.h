
#ifndef _C38_kl1867_
#define _C38_kl1867_

#ifdef __cplusplus
extern "C" {
#endif

extern void F367_5250(EIF_REFERENCE);
extern EIF_BOOLEAN F367_5251(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit1867(void);

#ifdef __cplusplus
}
#endif

#endif
