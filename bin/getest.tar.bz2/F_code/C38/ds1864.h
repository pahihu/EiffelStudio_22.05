
#ifndef _C38_ds1864_
#define _C38_ds1864_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1209_11213(EIF_REFERENCE);
extern void EIF_Minit1864(void);

#ifdef __cplusplus
}
#endif

#endif
