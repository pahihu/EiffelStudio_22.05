
#ifndef _C38_ds1858_
#define _C38_ds1858_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1193_11207(EIF_REFERENCE);
extern void EIF_Minit1858(void);
extern EIF_INTEGER_32 F1347_12129(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
