/*
 * Code for class DS_BUBBLE_SORTER [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1872.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_BUBBLE_SORTER}.subsort_with_comparator */
void F83_1031 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) arg4;
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 <= arg3)) break;
		loc2 = (EIF_INTEGER_32) arg3;
		for (;;) {
			if ((EIF_BOOLEAN) (loc2 >= loc1)) break;
			loc4 = F1323_11846(RTCW(arg1), loc2);
			loc5 = F1323_11846(RTCW(arg1), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
			tb1 = F275_2700(RTCW(arg2), loc5, loc4);
			if (tb1) {
				F1323_11857(RTCW(arg1), loc5, loc2);
				F1323_11857(RTCW(arg1), loc4, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
			loc2++;
		}
		if (loc3) {
			loc1--;
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			loc1 = (EIF_INTEGER_32) arg3;
		}
	}
	RTLE;
}

void EIF_Minit1872 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
