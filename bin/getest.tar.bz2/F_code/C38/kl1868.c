/*
 * Code for class KL_COMPARATOR [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl1868.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_COMPARATOR}.attached_order_equal */
EIF_BOOLEAN F365_5246 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN) !F367_5251(Current, arg1, arg2)) {
		Result = (EIF_BOOLEAN) !F367_5251(Current, arg2, arg1);
	}
	RTLE;
	return Result;
}

/* {KL_COMPARATOR}.test */
EIF_BOOLEAN F365_5249 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == arg2)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		if (EIF_FALSE) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			if (EIF_FALSE) {
				RTLE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				Result = F365_5246(Current, arg2, arg1);
				RTLE;
				return (EIF_BOOLEAN) Result;
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit1868 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
