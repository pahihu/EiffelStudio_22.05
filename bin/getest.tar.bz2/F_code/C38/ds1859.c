/*
 * Code for class DS_SPARSE_TABLE [INTEGER_32, INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1859.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_TABLE}.make */
void F1347_12085 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y9601,Y9601_gen_type,Dftype(Current),1339).id);
	F1_29(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	F1347_12091(Current, arg1, NULL, *(EIF_REFERENCE *)(Current + _REFACS_3_));
	RTLE;
}

/* {DS_SPARSE_TABLE}.make_map */
void F1347_12088 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	F1347_12091(Current, arg1, NULL, NULL);
}

/* {DS_SPARSE_TABLE}.make_with_equality_testers */
void F1347_12091 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg3;
	F1330_11930(Current, arg1);
	RTLE;
}

/* {DS_SPARSE_TABLE}.item */
EIF_INTEGER_32 F1347_12093 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1330_11963(Current, arg1);
	RTLE;
	return (EIF_INTEGER_32) F1355_12131(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_));
}

/* {DS_SPARSE_TABLE}.value */
EIF_INTEGER_32 F1347_12094 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = F1330_11964(Current, arg1);
	if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) -1L))) {
		RTLE;
		return (EIF_INTEGER_32) F1355_12131(Current, loc1);
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {DS_SPARSE_TABLE}.found_key */
EIF_INTEGER_32 F1347_12096 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F1355_12133(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_6_));
}

/* {DS_SPARSE_TABLE}.key_for_iteration */
EIF_INTEGER_32 F1347_12097 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F1347_12129(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_));
}

/* {DS_SPARSE_TABLE}.key_equality_tester */
EIF_REFERENCE F1347_12099 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {DS_SPARSE_TABLE}.keys */
EIF_REFERENCE F1347_12100 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTLE;
		return (EIF_REFERENCE) loc2;
	} else {
		loc1 = RTLNSMART(eif_final_id(Y9599,Y9599_gen_type,dftype,1339).id);
		F1285_11562(RTCW(loc1), Current);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
		RTLE;
		return (EIF_REFERENCE) loc1;
	}/* NOTREACHED */
	
}

/* {DS_SPARSE_TABLE}.has */
EIF_BOOLEAN F1347_12101 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1330_11963(Current, arg1);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) != ((EIF_INTEGER_32) -1L));
}

/* {DS_SPARSE_TABLE}.search */
void F1347_12104 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1330_11963(Current, arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_6_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_);
	RTLE;
}

/* {DS_SPARSE_TABLE}.is_equal */
EIF_BOOLEAN F1347_12105 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		tr1 = RTOSCF(9359,F1037_9359, (Current));
		tb2 = F21_186(RTCW(tr1), Current, arg1);
		if (tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_11_0_0_8_);
			tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) == ti4_1);
		}
		if (tb1) {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L)))) break;
				if ((EIF_BOOLEAN) (F1355_12134(Current, loc2) > ((EIF_INTEGER_32) -2L))) {
					loc1 = F1355_12133(Current, loc2);
					Result = '\0';
					tb1 = F1347_12101(RTCW(arg1), loc1);
					if (tb1) {
						ti4_1 = F1347_12093(RTCW(arg1), loc1);
						Result = (EIF_BOOLEAN)(ti4_1 == F1355_12131(Current, loc2));
					}
				}
				loc2--;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_TABLE}.set_key_equality_tester */
void F1347_12106 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1285_11596(loc1, arg1);
	}
	RTLE;
}

/* {DS_SPARSE_TABLE}.replace_found_item */
void F1347_12108 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	F1355_12132(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_6_));
}

/* {DS_SPARSE_TABLE}.put_new */
void F1347_12110 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1330_11949(Current);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_))++;
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
	} else {
		ti4_1 = F1355_12134(Current, loc1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
	}
	loc2 = F1363_12168(Current, arg2);
	ti4_1 = F1355_12156(Current, loc2);
	F1355_12150(Current, ti4_1, loc1);
	F1355_12157(Current, loc1, loc2);
	F1355_12132(Current, arg1, loc1);
	F1355_12143(Current, arg2, loc1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))++;
	RTLE;
}

/* {DS_SPARSE_TABLE}.put_last */
void F1347_12111 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1330_11949(Current);
	F1330_11963(Current, arg2);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		F1355_12132(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_));
	} else {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
		if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_))) {
			F1330_11955(Current);
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
		}
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_) = (EIF_INTEGER_32) loc1;
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_4_);
		ti4_1 = F1355_12156(Current, loc2);
		F1355_12150(Current, ti4_1, loc1);
		F1355_12157(Current, loc1, loc2);
		F1355_12132(Current, arg1, loc1);
		F1355_12143(Current, arg2, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))++;
	}
	RTLE;
}

/* {DS_SPARSE_TABLE}.put_last_new */
void F1347_12112 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1330_11949(Current);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_))) {
		F1330_11955(Current);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_) = (EIF_INTEGER_32) loc1;
	loc2 = F1363_12168(Current, arg2);
	ti4_1 = F1355_12156(Current, loc2);
	F1355_12150(Current, ti4_1, loc1);
	F1355_12157(Current, loc1, loc2);
	F1355_12132(Current, arg1, loc1);
	F1355_12143(Current, arg2, loc1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))++;
	RTLE;
}

/* {DS_SPARSE_TABLE}.force */
void F1347_12113 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1330_11949(Current);
	F1330_11963(Current, arg2);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		F1355_12132(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_));
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_))) {
			ti4_1 = F1330_12019(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) + ((EIF_INTEGER_32) 1L)));
			F1330_11954(Current, ti4_1);
			loc2 = F1363_12168(Current, arg2);
		} else {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_4_);
		}
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_))++;
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
		} else {
			ti4_1 = F1355_12134(Current, loc1);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
		}
		ti4_1 = F1355_12156(Current, loc2);
		F1355_12150(Current, ti4_1, loc1);
		F1355_12157(Current, loc1, loc2);
		F1355_12132(Current, arg1, loc1);
		F1355_12143(Current, arg2, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))++;
	}
	RTLE;
}

/* {DS_SPARSE_TABLE}.force_new */
void F1347_12114 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1330_11949(Current);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_))) {
		ti4_1 = F1330_12019(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_) + ((EIF_INTEGER_32) 1L)));
		F1330_11954(Current, ti4_1);
	}
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_))++;
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
	} else {
		ti4_1 = F1355_12134(Current, loc1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
	}
	loc2 = F1363_12168(Current, arg2);
	ti4_1 = F1355_12156(Current, loc2);
	F1355_12150(Current, ti4_1, loc1);
	F1355_12157(Current, loc1, loc2);
	F1355_12132(Current, arg1, loc1);
	F1355_12143(Current, arg2, loc1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))++;
	RTLE;
}

/* {DS_SPARSE_TABLE}.force_last */
void F1347_12115 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1330_11949(Current);
	F1330_11963(Current, arg2);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		F1355_12132(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_3_));
	} else {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
		if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_))) {
			ti4_1 = F1330_12019(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			F1330_11954(Current, ti4_1);
			loc2 = F1363_12168(Current, arg2);
		} else {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_4_);
		}
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_) = (EIF_INTEGER_32) loc1;
		ti4_1 = F1355_12156(Current, loc2);
		F1355_12150(Current, ti4_1, loc1);
		F1355_12157(Current, loc1, loc2);
		F1355_12132(Current, arg1, loc1);
		F1355_12143(Current, arg2, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))++;
	}
	RTLE;
}

/* {DS_SPARSE_TABLE}.force_last_new */
void F1347_12116 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1330_11949(Current);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_7_))) {
		ti4_1 = F1330_12019(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
		F1330_11954(Current, ti4_1);
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_0_) = (EIF_INTEGER_32) loc1;
	loc2 = F1363_12168(Current, arg2);
	ti4_1 = F1355_12156(Current, loc2);
	F1355_12150(Current, ti4_1, loc1);
	F1355_12157(Current, loc1, loc2);
	F1355_12132(Current, arg1, loc1);
	F1355_12143(Current, arg2, loc1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_0_0_8_))++;
	RTLE;
}

/* {DS_SPARSE_TABLE}.copy */
void F1347_12117 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		F1330_11950(Current, arg1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {DS_SPARSE_TABLE}.internal_set_key_equality_tester */
void F1347_12126 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1285_11596(loc1, arg1);
	}
	RTLE;
}

/* {DS_SPARSE_TABLE}.set_internal_keys */
void F1347_12128 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {DS_SPARSE_TABLE}.cursor_key */
EIF_INTEGER_32 F1347_12129 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	Result = F1355_12133(Current, ti4_1);
	RTLE;
	return Result;
}

void EIF_Minit1859 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
