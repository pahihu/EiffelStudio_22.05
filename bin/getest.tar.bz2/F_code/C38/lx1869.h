
#ifndef _C38_lx1869_
#define _C38_lx1869_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1234_11457(EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE);
extern EIF_BOOLEAN F1234_11460(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1234_11461(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1869(void);
extern char *(*R1240[])();

#ifdef __cplusplus
}
#endif

#endif
