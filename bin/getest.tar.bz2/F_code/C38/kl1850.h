
#ifndef _C38_kl1850_
#define _C38_kl1850_

#ifdef __cplusplus
extern "C" {
#endif

extern void F366_5250(EIF_REFERENCE);
extern EIF_BOOLEAN F366_5251(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1850(void);
extern char *(*R1948[])();

#ifdef __cplusplus
}
#endif

#endif
