
#ifndef _C38_lx1854_
#define _C38_lx1854_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1235_11463(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1235_11466(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1235_11467(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1854(void);
extern EIF_BOOLEAN F912_7505(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R1241[])();

#ifdef __cplusplus
}
#endif

#endif
