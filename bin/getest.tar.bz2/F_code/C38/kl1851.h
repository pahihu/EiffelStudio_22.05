
#ifndef _C38_kl1851_
#define _C38_kl1851_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F364_5246(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F364_5249(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1851(void);
extern char *(*R2277[])();
extern char *(*R4755[])();

#ifdef __cplusplus
}
#endif

#endif
