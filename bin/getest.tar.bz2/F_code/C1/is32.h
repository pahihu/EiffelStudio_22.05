
#ifndef _C1_is32_
#define _C1_is32_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F47_567(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F47_572(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F47_574(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F47_582(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit32(void);

#ifdef __cplusplus
}
#endif

#endif
