
#ifndef _C1_lx11_
#define _C1_lx11_

#ifdef __cplusplus
extern "C" {
#endif

extern void F15_150(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_BOOLEAN);
extern void F15_158(EIF_REFERENCE, EIF_REFERENCE);
extern void F15_159(EIF_REFERENCE, EIF_REFERENCE);
extern void F15_160(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit11(void);
extern void F1322_11840(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1322_11864(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
