/*
 * Code for class STD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st33.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STD_FILES}.input */
static EIF_REFERENCE F60_676_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (676);
#define Result RTOSR(676)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1091, 0x01).id, 1091, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stdin",5,1953620846);
	F1092_10432(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (676);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F60_676 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(676,F60_676_body,(Current));
}

/* {STD_FILES}.output */
static EIF_REFERENCE F60_677_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (677);
#define Result RTOSR(677)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1091, 0x01).id, 1091, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stdout",6,1912016244);
	F1092_10433(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (677);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F60_677 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(677,F60_677_body,(Current));
}

/* {STD_FILES}.error */
static EIF_REFERENCE F60_678_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (678);
#define Result RTOSR(678)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1091, 0x01).id, 1091, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stderr",6,1911360114);
	F1092_10434(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (678);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F60_678 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(678,F60_678_body,(Current));
}

/* {STD_FILES}.set_output_default */
void F60_704 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(677,F60_677, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit33 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
