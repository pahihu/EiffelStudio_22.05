/*
 * Code for class LX_DESCRIPTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx27.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_DESCRIPTION}.make */
void F35_403 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_22_0_1_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1114111L) - ((EIF_INTEGER_32) 2048L));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_22_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 200L);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_18_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1321,0xFF01,190,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1322_11840(RTCW(tr1), ((EIF_INTEGER_32) 250L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1321,0xFF01,190,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1322_11840(RTCW(tr1), ((EIF_INTEGER_32) 40L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1321,0xFF01,1034,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1322_11840(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1324, 1).id);
	F1325_11921(RTCW(tr1), ((EIF_INTEGER_32) 40L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {LX_DESCRIPTION}.set_case_insensitive */
void F35_433 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_maximum_symbol */
void F35_434 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_22_0_1_) = (EIF_INTEGER_32) arg1;
}

/* {LX_DESCRIPTION}.set_equiv_classes_used */
void F35_437 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_4_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_meta_equiv_classes_used */
void F35_438 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_5_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_full_table */
void F35_439 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_6_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_equiv_classes */
void F35_466 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
}

/* {LX_DESCRIPTION}.set_bol_needed */
void F35_467 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_19_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_variable_trail_context */
void F35_468 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_20_) = (EIF_BOOLEAN) arg1;
}

void EIF_Minit27 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
