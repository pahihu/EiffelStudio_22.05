
#ifndef _C1_lx12_
#define _C1_lx12_

#ifdef __cplusplus
extern "C" {
#endif

extern void F16_161(EIF_REFERENCE);
extern void EIF_Minit12(void);

#ifdef __cplusplus
}
#endif

#endif
