
#ifndef _C1_kl49_
#define _C1_kl49_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,1037)
static EIF_REFERENCE F86_1037_body(EIF_REFERENCE);
extern EIF_REFERENCE F86_1037(EIF_REFERENCE);
extern void EIF_Minit49(void);

#ifdef __cplusplus
}
#endif

#endif
