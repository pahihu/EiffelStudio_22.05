/*
 * Code for class KL_STANDARD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl26.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STANDARD_FILES}.input */
static EIF_REFERENCE F34_400_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (400);
#define Result RTOSR(400)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1062, 0x01).id, 1062, _OBJSIZ_2_2_0_0_0_0_0_0_);
	F1063_10079(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (400);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F34_400 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(400,F34_400_body,(Current));
}

/* {KL_STANDARD_FILES}.output */
static EIF_REFERENCE F34_401_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (401);
#define Result RTOSR(401)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1073, 0x01).id, 1073, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (401);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F34_401 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(401,F34_401_body,(Current));
}

/* {KL_STANDARD_FILES}.error */
static EIF_REFERENCE F34_402_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (402);
#define Result RTOSR(402)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1072, 0x01).id, 1072, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (402);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F34_402 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(402,F34_402_body,(Current));
}

void EIF_Minit26 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
