
#ifndef _C1_ts35_
#define _C1_ts35_

#ifdef __cplusplus
extern "C" {
#endif

extern void F62_763(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F62_769(EIF_REFERENCE, EIF_REFERENCE);
extern void F62_770(EIF_REFERENCE, EIF_REFERENCE);
extern void F62_771(EIF_REFERENCE, EIF_REFERENCE);
extern void F62_772(EIF_REFERENCE, EIF_BOOLEAN);
extern void F62_773(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit35(void);
extern void F1093_10505(EIF_REFERENCE, EIF_BOOLEAN);
extern void F1142_11161(EIF_REFERENCE);
extern void F1142_11160(EIF_REFERENCE);
extern void F1093_10503(EIF_REFERENCE, EIF_REFERENCE);
extern void F1093_10504(EIF_REFERENCE, EIF_REFERENCE);
extern void F1093_10506(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R9315[])();
extern char *(*R4737[])();
extern char *(*R4738[])();

#ifdef __cplusplus
}
#endif

#endif
