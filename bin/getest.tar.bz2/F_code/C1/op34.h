
#ifndef _C1_op34_
#define _C1_op34_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F61_760(EIF_REFERENCE);
extern void EIF_Minit34(void);

#ifdef __cplusplus
}
#endif

#endif
