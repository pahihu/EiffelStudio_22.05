
#ifndef _C1_lx27_
#define _C1_lx27_

#ifdef __cplusplus
extern "C" {
#endif

extern void F35_403(EIF_REFERENCE);
extern void F35_433(EIF_REFERENCE, EIF_BOOLEAN);
extern void F35_434(EIF_REFERENCE, EIF_INTEGER_32);
extern void F35_437(EIF_REFERENCE, EIF_BOOLEAN);
extern void F35_438(EIF_REFERENCE, EIF_BOOLEAN);
extern void F35_439(EIF_REFERENCE, EIF_BOOLEAN);
extern void F35_466(EIF_REFERENCE, EIF_REFERENCE);
extern void F35_467(EIF_REFERENCE, EIF_BOOLEAN);
extern void F35_468(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit27(void);
extern void F1322_11840(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1325_11921(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
