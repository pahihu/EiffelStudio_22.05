
#ifndef _C1_ut14_
#define _C1_ut14_

#ifdef __cplusplus
extern "C" {
#endif

extern void F18_170(EIF_REFERENCE);
extern EIF_BOOLEAN F18_172(EIF_REFERENCE);
extern void F18_175(EIF_REFERENCE);
extern void F18_176(EIF_REFERENCE);
extern void EIF_Minit14(void);

#ifdef __cplusplus
}
#endif

#endif
