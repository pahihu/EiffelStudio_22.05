
#ifndef _C17_et820_
#define _C17_et820_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1719_15919(EIF_REFERENCE, EIF_REFERENCE, EIF_NATURAL_64, EIF_BOOLEAN);
extern void F1719_15920(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit820(void);
extern void F1113_10974(EIF_REFERENCE);
extern char *(*R1755[])();

#ifdef __cplusplus
}
#endif

#endif
