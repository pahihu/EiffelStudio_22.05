/*
 * Code for class ET_BOOLEAN_CONSTANT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et816.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_BOOLEAN_CONSTANT}.is_boolean_constant */
EIF_BOOLEAN F1715_15871 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {ET_BOOLEAN_CONSTANT}.has_indexing_term_value */
EIF_BOOLEAN F1715_15872 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(9540,F1056_9540, (Current));
	Result = F1048_9428(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), arg1);
	RTLE;
	return Result;
}

/* {ET_BOOLEAN_CONSTANT}.indexing_term_value */
EIF_REFERENCE F1715_15873 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_1_);
}

void EIF_Minit816 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
