
#ifndef _C17_et822_
#define _C17_et822_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1721_15926(EIF_REFERENCE, EIF_REFERENCE, EIF_NATURAL_64, EIF_BOOLEAN);
extern void F1721_15927(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit822(void);
extern void F1113_10974(EIF_REFERENCE);
extern char *(*R1701[])();

#ifdef __cplusplus
}
#endif

#endif
