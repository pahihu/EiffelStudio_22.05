
#ifndef _C17_et834_
#define _C17_et834_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1733_16040(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1733_16041(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit834(void);
extern void F1559_13965(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R1720[])();
extern EIF_TYPE_INDEX Y10741[];
extern EIF_TYPE_INDEX *Y10741_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
