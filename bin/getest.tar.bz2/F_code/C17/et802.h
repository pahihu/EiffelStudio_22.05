
#ifndef _C17_et802_
#define _C17_et802_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1701_15640(EIF_REFERENCE, EIF_CHARACTER_32);
extern EIF_REFERENCE F1701_15642(EIF_REFERENCE);
extern void F1701_15645(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit802(void);
extern void F1113_10973(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1113_10975(EIF_REFERENCE);
extern EIF_INTEGER_32 F1113_10976(EIF_REFERENCE);
extern void F1113_10974(EIF_REFERENCE);
extern char *(*R1582[])();

#ifdef __cplusplus
}
#endif

#endif
