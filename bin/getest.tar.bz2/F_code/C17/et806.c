/*
 * Code for class ET_REGULAR_MANIFEST_STRING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et806.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_REGULAR_MANIFEST_STRING}.make */
void F1705_15682 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	F1113_10974(Current);
	RTLE;
}

/* {ET_REGULAR_MANIFEST_STRING}.value */
EIF_REFERENCE F1705_15683 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {ET_REGULAR_MANIFEST_STRING}.last_position */
EIF_REFERENCE F1705_15685 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_0_0_0_1_0_0_0_0_);
	ti4_1 = F1113_10975(Current);
	ti4_2 = F1113_10976(Current);
	tr1 = RTLNS(eif_new_type(1048, 0x01).id, 1048, _OBJSIZ_0_0_0_0_0_0_0_0_);
	ti4_3 = F1049_9480(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	F1113_10973(RTCW(Result), ti4_1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 + ti4_3) + ((EIF_INTEGER_32) 1L)));
	RTLE;
	return Result;
}

/* {ET_REGULAR_MANIFEST_STRING}.process */
void F1705_15687 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1731[Dtype(RTCW(arg1))-165])(arg1, Current);
}

void EIF_Minit806 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
