
#ifndef _C17_et807_
#define _C17_et807_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1706_15689(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1706_15690(EIF_REFERENCE);
extern EIF_REFERENCE F1706_15691(EIF_REFERENCE);
extern void EIF_Minit807(void);
extern void F1113_10973(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1113_10975(EIF_REFERENCE);
extern EIF_INTEGER_32 F1113_10976(EIF_REFERENCE);
extern void F1113_10974(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
