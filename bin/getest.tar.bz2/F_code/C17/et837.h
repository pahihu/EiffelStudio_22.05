
#ifndef _C17_et837_
#define _C17_et837_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1736_16053(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit837(void);
extern char *(*R1740[])();

#ifdef __cplusplus
}
#endif

#endif
