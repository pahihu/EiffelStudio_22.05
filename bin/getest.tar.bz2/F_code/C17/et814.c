/*
 * Code for class ET_PRECURSOR_KEYWORD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et814.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_PRECURSOR_KEYWORD}.lower_name */
EIF_REFERENCE F1713_15863 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOSCF(4124,F282_4124, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	RTLE;
	return Result;
}

/* {ET_PRECURSOR_KEYWORD}.hash_code */
EIF_INTEGER_32 F1713_15864 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	Result = (EIF_INTEGER_32) (tc1);
	RTLE;
	return Result;
}

/* {ET_PRECURSOR_KEYWORD}.is_equal */
EIF_BOOLEAN F1713_15866 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(9359,F1037_9359, (Current));
	Result = F21_186(RTCW(tr1), Current, arg1);
	RTLE;
	return Result;
}

/* {ET_PRECURSOR_KEYWORD}.precursor_keyword */
EIF_REFERENCE F1713_15867 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

void EIF_Minit814 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
