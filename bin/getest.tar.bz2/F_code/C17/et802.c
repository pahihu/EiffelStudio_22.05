/*
 * Code for class ET_C1_CHARACTER_CONSTANT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et802.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_C1_CHARACTER_CONSTANT}.make */
void F1701_15640 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_CHARACTER_32) arg1;
	F1113_10974(Current);
	RTLE;
}

/* {ET_C1_CHARACTER_CONSTANT}.last_position */
EIF_REFERENCE F1701_15642 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_0_0_0_1_0_0_0_0_);
	ti4_1 = F1113_10975(Current);
	ti4_2 = F1113_10976(Current);
	F1113_10973(RTCW(Result), ti4_1, (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 2L)));
	RTLE;
	return Result;
}

/* {ET_C1_CHARACTER_CONSTANT}.process */
void F1701_15645 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1582[Dtype(RTCW(arg1))-165])(arg1, Current);
}

void EIF_Minit802 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
