
#ifndef _C17_et801_
#define _C17_et801_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1700_15633(EIF_REFERENCE, EIF_CHARACTER_8);
extern EIF_CHARACTER_8 F1700_15634(EIF_REFERENCE);
extern EIF_REFERENCE F1700_15635(EIF_REFERENCE);
extern void F1700_15638(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit801(void);
extern void F1113_10973(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1113_10975(EIF_REFERENCE);
extern EIF_INTEGER_32 F1113_10976(EIF_REFERENCE);
extern void F1113_10974(EIF_REFERENCE);
extern char *(*R1583[])();

#ifdef __cplusplus
}
#endif

#endif
