
#ifndef _C17_et841_
#define _C17_et841_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1740_16081(EIF_REFERENCE);
extern EIF_REFERENCE F1740_16083(EIF_REFERENCE);
extern void EIF_Minit841(void);
extern char *(*R10727[])();
extern char *(*R10663[])();
extern char *(*R10428[])();
extern char *(*R10915[])();

#ifdef __cplusplus
}
#endif

#endif
