/*
 * Code for class ET_C3_CHARACTER_CONSTANT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et800.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_C3_CHARACTER_CONSTANT}.make */
void F1699_15626 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_CHARACTER_32 arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_4_1_0_0_) = (EIF_CHARACTER_32) arg2;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_) = (EIF_BOOLEAN) arg3;
	F1113_10974(Current);
	RTLE;
}

/* {ET_C3_CHARACTER_CONSTANT}.last_position */
EIF_REFERENCE F1699_15628 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_0_0_0_1_0_0_0_0_);
	ti4_1 = F1113_10975(Current);
	ti4_2 = F1113_10976(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	ti4_3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	F1113_10973(RTCW(Result), ti4_1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 + ti4_3) + ((EIF_INTEGER_32) 4L)));
	RTLE;
	return Result;
}

/* {ET_C3_CHARACTER_CONSTANT}.has_invalid_code */
EIF_BOOLEAN F1699_15629 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_4_0_);
}


/* {ET_C3_CHARACTER_CONSTANT}.process */
void F1699_15631 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1584[Dtype(RTCW(arg1))-165])(arg1, Current);
}

void EIF_Minit800 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
