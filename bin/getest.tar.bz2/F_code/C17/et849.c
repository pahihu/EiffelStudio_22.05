/*
 * Code for class ET_QUALIFIED_CALL_INSTRUCTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et849.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_QUALIFIED_CALL_INSTRUCTION}.reset */
void F1748_16112 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1570_14028(Current);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {ET_QUALIFIED_CALL_INSTRUCTION}.process */
void F1748_16113 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1725[Dtype(RTCW(arg1))-165])(arg1, Current);
}

void EIF_Minit849 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
