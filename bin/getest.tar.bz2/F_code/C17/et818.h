
#ifndef _C17_et818_
#define _C17_et818_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1717_15875(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit818(void);
extern char *(*R1643[])();

#ifdef __cplusplus
}
#endif

#endif
