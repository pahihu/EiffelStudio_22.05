
#ifndef _C17_et845_
#define _C17_et845_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1744_16107(EIF_REFERENCE);
extern void F1744_16108(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit845(void);
extern void F1559_13965(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern long O11860[];

#ifdef __cplusplus
}
#endif

#endif
