/*
 * Code for class ET_STATIC_CALL_INSTRUCTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et826.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_STATIC_CALL_INSTRUCTION}.set_parenthesis_call */
void F1725_15956 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y10734,Y10734_gen_type,Dftype(Current),1561).id);
	F1559_13965(RTCW(tr1), arg1, arg2, arg3);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {ET_STATIC_CALL_INSTRUCTION}.process */
void F1725_15957 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1743[Dtype(RTCW(arg1))-165])(arg1, Current);
}

void EIF_Minit826 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
