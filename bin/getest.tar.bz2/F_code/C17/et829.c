/*
 * Code for class ET_DEBUG_INSTRUCTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et829.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_DEBUG_INSTRUCTION}.make */
void F1728_15986 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	tr1 = RTOSCF(3658,F282_3658, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {ET_DEBUG_INSTRUCTION}.reset */
void F1728_15987 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1406_13122(loc1);
	}
	RTLE;
}

/* {ET_DEBUG_INSTRUCTION}.position */
EIF_REFERENCE F1728_15991 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,Result);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = *(EIF_REFERENCE *)(loc2 + _REFACS_1_);
		tr1 = F1687_15455(RTCW(loc1));
		tb1 = F1112_10963(RTCW(tr1));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = F1687_15455(RTCW(loc1));
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				Result = F1396_13022(loc3);
			} else {
				tb1 = F905_7420(loc2);
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = F905_7415(loc2, ((EIF_INTEGER_32) 1L));
					Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10228[Dtype(RTCW(tr1))-1392])(tr1);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					Result = F1687_15455(RTCW(tr1));
				}
			}
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			Result = F1396_13022(loc4);
			RTLE;
			return (EIF_REFERENCE) Result;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			Result = F1687_15455(RTCW(tr1));
		}
	}
	RTLE;
	return Result;
}

/* {ET_DEBUG_INSTRUCTION}.last_leaf */
EIF_REFERENCE F1728_15993 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_2_);
}

/* {ET_DEBUG_INSTRUCTION}.process */
void F1728_15996 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1617[Dtype(RTCW(arg1))-165])(arg1, Current);
}

void EIF_Minit829 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
