
#ifndef _C17_et813_
#define _C17_et813_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1712_15861(EIF_REFERENCE);
extern void F1712_15862(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit813(void);
extern char *(*R1614[])();

#ifdef __cplusplus
}
#endif

#endif
