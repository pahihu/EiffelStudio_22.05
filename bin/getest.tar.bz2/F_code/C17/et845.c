/*
 * Code for class ET_CALL_INSTRUCTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et845.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_CALL_INSTRUCTION}.parenthesis_call */
EIF_REFERENCE F1744_16107 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O11860[Dtype(Current)-1743]);
}


/* {ET_CALL_INSTRUCTION}.set_parenthesis_call */
void F1744_16108 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1748, 0).id);
	F1559_13965(RTCW(tr1), arg1, arg2, arg3);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O11860[Dtype(Current)-1743]) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit845 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
