
#ifndef _C17_et849_
#define _C17_et849_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1748_16112(EIF_REFERENCE);
extern void F1748_16113(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit849(void);
extern void F1570_14028(EIF_REFERENCE);
extern char *(*R1725[])();

#ifdef __cplusplus
}
#endif

#endif
