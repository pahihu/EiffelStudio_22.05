
#ifndef _C17_et838_
#define _C17_et838_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1737_16054(EIF_REFERENCE);
extern void EIF_Minit838(void);
extern void F1597_14243(EIF_REFERENCE);
extern void F1406_13122(EIF_REFERENCE);
extern char *(*R10402[])();
extern char *(*R10398[])();

#ifdef __cplusplus
}
#endif

#endif
