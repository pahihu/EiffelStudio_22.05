
#ifndef _C17_et826_
#define _C17_et826_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1725_15956(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1725_15957(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit826(void);
extern void F1559_13965(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R1743[])();
extern EIF_TYPE_INDEX Y10734[];
extern EIF_TYPE_INDEX *Y10734_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
