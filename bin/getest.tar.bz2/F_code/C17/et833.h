
#ifndef _C17_et833_
#define _C17_et833_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1732_16038(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit833(void);
extern char *(*R1739[])();

#ifdef __cplusplus
}
#endif

#endif
