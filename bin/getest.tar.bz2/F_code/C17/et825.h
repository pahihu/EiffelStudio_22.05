
#ifndef _C17_et825_
#define _C17_et825_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1724_15953(EIF_REFERENCE);
extern void EIF_Minit825(void);

#ifdef __cplusplus
}
#endif

#endif
