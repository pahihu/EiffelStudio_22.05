/*
 * Code for class ET_BINARY_INTEGER_CONSTANT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et824.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_BINARY_INTEGER_CONSTANT}.make */
void F1723_15941 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_64 arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_) = (EIF_NATURAL_64) arg2;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_) = (EIF_BOOLEAN) arg3;
	F1113_10974(Current);
	RTLE;
}

/* {ET_BINARY_INTEGER_CONSTANT}.is_binary */
EIF_BOOLEAN F1723_15946 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {ET_BINARY_INTEGER_CONSTANT}.is_integer_8 */
EIF_BOOLEAN F1723_15947 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = tr1;
		if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
			tu8_2 = (EIF_NATURAL_64) ((EIF_NATURAL_8) 255U);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
		} else {
			tb1 = F1693_15554(loc1);
			if (tb1) {
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
				tu8_2 = RTOSCF(15914,F1718_15914, (Current));
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
			} else {
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
				tu8_2 = (EIF_NATURAL_64) ((EIF_INTEGER_8) 127L);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_BINARY_INTEGER_CONSTANT}.is_integer_16 */
EIF_BOOLEAN F1723_15948 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = tr1;
		if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
			tu8_2 = (EIF_NATURAL_64) ((EIF_NATURAL_16) 65535U);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
		} else {
			tb1 = F1693_15554(loc1);
			if (tb1) {
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
				tu8_2 = RTOSCF(15915,F1718_15915, (Current));
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
			} else {
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
				tu8_2 = (EIF_NATURAL_64) ((EIF_INTEGER_16) 32767L);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_BINARY_INTEGER_CONSTANT}.is_integer_32 */
EIF_BOOLEAN F1723_15949 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = tr1;
		if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
			tu8_2 = (EIF_NATURAL_64) ((EIF_NATURAL_32) 4294967295U);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
		} else {
			tb1 = F1693_15554(loc1);
			if (tb1) {
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
				tu8_2 = RTOSCF(15916,F1718_15916, (Current));
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
			} else {
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
				tu8_2 = (EIF_NATURAL_64) ((EIF_INTEGER_32) 2147483647L);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_BINARY_INTEGER_CONSTANT}.is_integer_64 */
EIF_BOOLEAN F1723_15950 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = tr1;
		if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			tb1 = F1693_15554(loc1);
			if (tb1) {
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
				tu8_2 = RTOSCF(15917,F1718_15917, (Current));
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
			} else {
				tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
				tu8_2 = (EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(9223372036854775807));
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_BINARY_INTEGER_CONSTANT}.process */
void F1723_15951 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1576[Dtype(RTCW(arg1))-165])(arg1, Current);
}

void EIF_Minit824 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
