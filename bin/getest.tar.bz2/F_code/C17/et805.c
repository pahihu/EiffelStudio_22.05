/*
 * Code for class ET_SPECIAL_MANIFEST_STRING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et805.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_SPECIAL_MANIFEST_STRING}.make */
void F1704_15674 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg2;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_) = (EIF_BOOLEAN) arg3;
	F1113_10974(Current);
	RTLE;
}

/* {ET_SPECIAL_MANIFEST_STRING}.has_invalid_code */
EIF_BOOLEAN F1704_15675 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_);
}


/* {ET_SPECIAL_MANIFEST_STRING}.value */
EIF_REFERENCE F1704_15676 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_4_);
}


/* {ET_SPECIAL_MANIFEST_STRING}.literal */
EIF_REFERENCE F1704_15677 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {ET_SPECIAL_MANIFEST_STRING}.last_position */
EIF_REFERENCE F1704_15678 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tc1 = (EIF_CHARACTER_8) '\012';
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R4895[Dtype(RTCW(tr1))-1034])(tr1, (EIF_REFERENCE) &tc1);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
		Result = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_0_0_0_1_0_0_0_0_);
		ti4_1 = F1113_10975(Current);
		ti4_2 = F1113_10976(Current);
		tr1 = RTLNS(eif_new_type(1048, 0x01).id, 1048, _OBJSIZ_0_0_0_0_0_0_0_0_);
		ti4_3 = F1049_9480(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_));
		F1113_10973(RTCW(Result), ti4_1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 + ti4_3) + ((EIF_INTEGER_32) 1L)));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
		loc2 = (EIF_INTEGER_32) loc3;
		for (;;) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5133[Dtype(RTCW(tr1))-714])(tr1, loc2));
			if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\012')) break;
			loc2--;
		}
		Result = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_0_0_0_1_0_0_0_0_);
		ti4_1 = F1113_10975(Current);
		tr1 = RTLNS(eif_new_type(1048, 0x01).id, 1048, _OBJSIZ_0_0_0_0_0_0_0_0_);
		ti4_2 = F1049_9481(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)), loc3);
		F1113_10973(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + loc1), (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
	}
	RTLE;
	return Result;
}

/* {ET_SPECIAL_MANIFEST_STRING}.process */
void F1704_15680 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1741[Dtype(RTCW(arg1))-165])(arg1, Current);
}

void EIF_Minit805 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
