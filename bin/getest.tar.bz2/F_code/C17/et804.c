/*
 * Code for class ET_VERBATIM_STRING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et804.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_VERBATIM_STRING}.make */
void F1703_15665 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_BOOLEAN arg6)
{
	GTCX
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLR(5,arg5);
	RTLIU(6);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg3;
	RTAR(Current, arg4);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg4;
	RTAR(Current, arg5);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg5;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_8_0_) = (EIF_BOOLEAN) arg6;
	F1113_10974(Current);
	RTLE;
}

/* {ET_VERBATIM_STRING}.value */
EIF_REFERENCE F1703_15666 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_7_);
}


/* {ET_VERBATIM_STRING}.literal */
EIF_REFERENCE F1703_15667 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_6_);
}


/* {ET_VERBATIM_STRING}.last_position */
EIF_REFERENCE F1703_15672 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_0_0_0_1_0_0_0_0_);
	ti4_1 = F1113_10975(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tc1 = (EIF_CHARACTER_8) '\012';
	ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE)) R4895[Dtype(RTCW(tr1))-1034])(tr1, (EIF_REFERENCE) &tc1);
	tr1 = RTLNS(eif_new_type(1048, 0x01).id, 1048, _OBJSIZ_0_0_0_0_0_0_0_0_);
	ti4_3 = F1049_9480(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_5_));
	tr2 = RTLNS(eif_new_type(1048, 0x01).id, 1048, _OBJSIZ_0_0_0_0_0_0_0_0_);
	ti4_4 = F1049_9480(RTCW(tr2), *(EIF_REFERENCE *)(Current + _REFACS_3_));
	F1113_10973(RTCW(Result), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + ((EIF_INTEGER_32) 1L)), (EIF_INTEGER_32) (ti4_3 + ti4_4));
	RTLE;
	return Result;
}

/* {ET_VERBATIM_STRING}.process */
void F1703_15673 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1764[Dtype(RTCW(arg1))-165])(arg1, Current);
}

void EIF_Minit804 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
