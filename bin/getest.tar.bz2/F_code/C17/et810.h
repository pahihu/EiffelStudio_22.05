
#ifndef _C17_et810_
#define _C17_et810_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1709_15841(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit810(void);
extern char *(*R1765[])();

#ifdef __cplusplus
}
#endif

#endif
