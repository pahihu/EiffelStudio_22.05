
#ifndef _C17_et847_
#define _C17_et847_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1746_16109(EIF_REFERENCE);
extern void F1746_16110(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit847(void);
extern void F1567_14016(EIF_REFERENCE);
extern char *(*R1762[])();

#ifdef __cplusplus
}
#endif

#endif
