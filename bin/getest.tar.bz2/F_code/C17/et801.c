/*
 * Code for class ET_C2_CHARACTER_CONSTANT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et801.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_C2_CHARACTER_CONSTANT}.make */
void F1700_15633 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tw1 = (EIF_CHARACTER_32) arg1;
	*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_CHARACTER_32) tw1;
	F1113_10974(Current);
	RTLE;
}

/* {ET_C2_CHARACTER_CONSTANT}.literal */
EIF_CHARACTER_8 F1700_15634 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	switch (*(EIF_CHARACTER_32 *)(Current+ _LNGOFF_3_0_0_0_)) {
		case (EIF_CHARACTER_8) '@':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'A';
			break;
		case (EIF_CHARACTER_8) '\010':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'B';
			break;
		case (EIF_CHARACTER_8) '^':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'C';
			break;
		case (EIF_CHARACTER_8) '$':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'D';
			break;
		case (EIF_CHARACTER_8) '\014':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'F';
			break;
		case (EIF_CHARACTER_8) '\\':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'H';
			break;
		case (EIF_CHARACTER_8) '~':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'L';
			break;
		case (EIF_CHARACTER_8) '\012':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'N';
			break;
		case (EIF_CHARACTER_8) '`':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'Q';
			break;
		case (EIF_CHARACTER_8) '\015':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'R';
			break;
		case (EIF_CHARACTER_8) '#':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'S';
			break;
		case (EIF_CHARACTER_8) '\011':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'T';
			break;
		case (EIF_CHARACTER_8) '\000':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'U';
			break;
		case (EIF_CHARACTER_8) '|':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'V';
			break;
		case (EIF_CHARACTER_8) '%':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '%';
			break;
		case (EIF_CHARACTER_8) '\'':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\'';
			break;
		case (EIF_CHARACTER_8) '\"':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\"';
			break;
		case (EIF_CHARACTER_8) '[':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '(';
			break;
		case (EIF_CHARACTER_8) ']':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) ')';
			break;
		case (EIF_CHARACTER_8) '{':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '<';
			break;
		case (EIF_CHARACTER_8) '}':
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '>';
			break;
		default:
			Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'A';
			break;
	}
	RTLE;
	return Result;
}

/* {ET_C2_CHARACTER_CONSTANT}.last_position */
EIF_REFERENCE F1700_15635 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_0_0_0_1_0_0_0_0_);
	ti4_1 = F1113_10975(Current);
	ti4_2 = F1113_10976(Current);
	F1113_10973(RTCW(Result), ti4_1, (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 3L)));
	RTLE;
	return Result;
}

/* {ET_C2_CHARACTER_CONSTANT}.process */
void F1700_15638 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1583[Dtype(RTCW(arg1))-165])(arg1, Current);
}

void EIF_Minit801 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
