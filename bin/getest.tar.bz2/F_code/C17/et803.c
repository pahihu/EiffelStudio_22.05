/*
 * Code for class ET_MANIFEST_STRING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et803.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_MANIFEST_STRING}.reset */
void F1702_15647 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10617[Dtype(loc1)-1513])(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10915[Dtype(RTCW(tr1))-1602])(tr1);
	}
	RTLE;
}

/* {ET_MANIFEST_STRING}.is_string_8 */
EIF_BOOLEAN F1702_15648 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11569[dtype-1702])(Current)) {
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11570[dtype-1702])(Current);
		tr1 = RTLNS(eif_new_type(1048, 0x01).id, 1048, _OBJSIZ_0_0_0_0_0_0_0_0_);
		Result = F1049_9455(RTCW(tr1), tr2);
	}
	RTLE;
	return Result;
}

/* {ET_MANIFEST_STRING}.is_string_32 */
EIF_BOOLEAN F1702_15649 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11569[dtype-1702])(Current)) {
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11570[dtype-1702])(Current);
		tr1 = RTLNS(eif_new_type(1048, 0x01).id, 1048, _OBJSIZ_0_0_0_0_0_0_0_0_);
		Result = F1049_9456(RTCW(tr1), tr2);
	}
	RTLE;
	return Result;
}

/* {ET_MANIFEST_STRING}.has_invalid_code */
EIF_BOOLEAN F1702_15650 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {ET_MANIFEST_STRING}.has_indexing_term_value */
EIF_BOOLEAN F1702_15652 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(9540,F1056_9540, (Current));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11570[Dtype(Current)-1702])(Current);
	Result = F1048_9428(RTCW(tr1), tr2, arg1);
	RTLE;
	return Result;
}

/* {ET_MANIFEST_STRING}.position */
EIF_REFERENCE F1702_15657 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10228[Dtype(loc1)-1392])(loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTLE;
		return (EIF_REFERENCE) Current;
	}/* NOTREACHED */
	
}

/* {ET_MANIFEST_STRING}.value_position */
EIF_REFERENCE F1702_15658 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

/* {ET_MANIFEST_STRING}.manifest_string */
EIF_REFERENCE F1702_15660 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

/* {ET_MANIFEST_STRING}.indexing_term_value */
EIF_REFERENCE F1702_15661 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R11570[Dtype(Current)-1702])(Current);
}

/* {ET_MANIFEST_STRING}.set_cast_type */
void F1702_15662 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {ET_MANIFEST_STRING}.set_type */
void F1702_15663 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {ET_MANIFEST_STRING}.manifest_constant_convert_feature */
EIF_REFERENCE F1702_15664 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) == NULL)) {
		tr1 = RTOSCF(3587,F282_3587, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
		tr2 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_53_);
		tr3 = RTOSCF(3587,F282_3587, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
		tb1 = F1767_17256(RTCW(arg2), tr1, tr2, tr3);
		if (tb1) {
			if (F1702_15648(Current)) {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_82_);
				RTLE;
				return (EIF_REFERENCE) tr1;
			}
		} else {
			tr1 = RTOSCF(3587,F282_3587, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
			tr2 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_54_);
			tr3 = RTOSCF(3587,F282_3587, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
			tb1 = F1767_17256(RTCW(arg2), tr1, tr2, tr3);
			if (tb1) {
				if (F1702_15649(Current)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_83_);
					RTLE;
					return (EIF_REFERENCE) tr1;
				}
			}
		}
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit803 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
