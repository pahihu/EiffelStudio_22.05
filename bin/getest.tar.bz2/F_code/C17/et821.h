
#ifndef _C17_et821_
#define _C17_et821_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1720_15922(EIF_REFERENCE, EIF_REFERENCE, EIF_NATURAL_64, EIF_BOOLEAN);
extern void F1720_15923(EIF_REFERENCE, EIF_NATURAL_64);
extern void F1720_15924(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit821(void);
extern void F1113_10974(EIF_REFERENCE);
extern char *(*R1730[])();

#ifdef __cplusplus
}
#endif

#endif
