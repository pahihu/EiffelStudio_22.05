
#ifndef _C17_et817_
#define _C17_et817_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1716_15874(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit817(void);
extern char *(*R1749[])();

#ifdef __cplusplus
}
#endif

#endif
