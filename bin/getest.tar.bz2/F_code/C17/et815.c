/*
 * Code for class ET_RESULT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et815.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_RESULT}.process */
void F1714_15870 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1737[Dtype(RTCW(arg1))-165])(arg1, Current);
}

void EIF_Minit815 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
