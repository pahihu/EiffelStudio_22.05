/*
 * Code for class ET_KEYWORD_OPERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et811.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_KEYWORD_OPERATOR}.is_infix_and */
EIF_BOOLEAN F1710_15843 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) 'T';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD_OPERATOR}.is_infix_implies */
EIF_BOOLEAN F1710_15844 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) 'U';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD_OPERATOR}.is_infix_or */
EIF_BOOLEAN F1710_15845 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) 'V';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD_OPERATOR}.is_infix_xor */
EIF_BOOLEAN F1710_15846 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) 'W';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD_OPERATOR}.is_prefix_not */
EIF_BOOLEAN F1710_15848 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) '[';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD_OPERATOR}.name */
EIF_REFERENCE F1710_15849 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	switch (*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_)) {
		case (EIF_CHARACTER_8) 'T':
			Result = RTOSCF(4213,F282_4213, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'U':
			Result = RTOSCF(4214,F282_4214, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'V':
			Result = RTOSCF(4215,F282_4215, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'W':
			Result = RTOSCF(4216,F282_4216, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
			break;
		case (EIF_CHARACTER_8) '[':
			Result = RTOSCF(4231,F282_4231, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
			break;
		default:
			Result = RTOSCF(4192,F282_4192, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
			break;
	}
	RTLE;
	return Result;
}

/* {ET_KEYWORD_OPERATOR}.hash_code */
EIF_INTEGER_32 F1710_15850 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	Result = (EIF_INTEGER_32) (tc1);
	RTLE;
	return Result;
}

void EIF_Minit811 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
