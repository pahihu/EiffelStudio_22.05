
#ifndef _C17_et815_
#define _C17_et815_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1714_15870(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit815(void);
extern char *(*R1737[])();

#ifdef __cplusplus
}
#endif

#endif
