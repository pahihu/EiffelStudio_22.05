/*
 * Code for class ET_KEYWORD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et809.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_KEYWORD}.make_across */
void F1708_15705 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\001';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4076,F282_4076, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_agent */
void F1708_15706 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\002';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4077,F282_4077, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_alias */
void F1708_15707 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\003';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4078,F282_4078, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_all */
void F1708_15708 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\004';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4079,F282_4079, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_and */
void F1708_15709 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) 'T';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4080,F282_4080, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_as */
void F1708_15710 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\005';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4082,F282_4082, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_assign */
void F1708_15711 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\006';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4083,F282_4083, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_attached */
void F1708_15712 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\007';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4084,F282_4084, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_attribute */
void F1708_15713 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\010';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4085,F282_4085, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_check */
void F1708_15714 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\011';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4086,F282_4086, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_class */
void F1708_15715 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\012';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4087,F282_4087, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_convert */
void F1708_15716 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\013';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4088,F282_4088, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_create */
void F1708_15717 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\014';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4089,F282_4089, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_creation */
void F1708_15718 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\015';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4090,F282_4090, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_current */
void F1708_15719 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\016';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4069,F282_4069, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_debug */
void F1708_15720 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\017';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4092,F282_4092, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_deferred */
void F1708_15721 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\020';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4093,F282_4093, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_detachable */
void F1708_15722 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\021';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4094,F282_4094, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_do */
void F1708_15723 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\022';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4095,F282_4095, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_else */
void F1708_15724 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\023';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4096,F282_4096, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_elseif */
void F1708_15725 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\024';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4097,F282_4097, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_end */
void F1708_15726 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\025';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4098,F282_4098, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_ensure */
void F1708_15727 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\026';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4099,F282_4099, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_expanded */
void F1708_15728 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\027';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4100,F282_4100, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_export */
void F1708_15729 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\030';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4101,F282_4101, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_external */
void F1708_15730 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\031';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4102,F282_4102, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_false */
void F1708_15731 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\032';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4070,F282_4070, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_feature */
void F1708_15732 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\033';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4104,F282_4104, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_from */
void F1708_15733 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\034';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4105,F282_4105, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_frozen */
void F1708_15734 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\035';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4106,F282_4106, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_if */
void F1708_15735 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\036';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4107,F282_4107, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_implies */
void F1708_15736 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) 'U';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4108,F282_4108, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_indexing */
void F1708_15737 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\037';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4109,F282_4109, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_inherit */
void F1708_15738 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '!';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4110,F282_4110, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_inspect */
void F1708_15739 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '!';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4111,F282_4111, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_invariant */
void F1708_15740 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\"';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4112,F282_4112, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_is */
void F1708_15741 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '#';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4113,F282_4113, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_like */
void F1708_15742 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '$';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4114,F282_4114, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_local */
void F1708_15743 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '%';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4115,F282_4115, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_loop */
void F1708_15744 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '&';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4116,F282_4116, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_not */
void F1708_15745 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '[';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4117,F282_4117, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_note */
void F1708_15746 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\'';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4118,F282_4118, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_obsolete */
void F1708_15747 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '(';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4119,F282_4119, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_old */
void F1708_15748 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) ')';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4120,F282_4120, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_once */
void F1708_15749 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '*';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4121,F282_4121, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_or */
void F1708_15750 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) 'V';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4122,F282_4122, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_precursor */
void F1708_15751 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '+';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4124,F282_4124, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_redefine */
void F1708_15752 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) ',';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4125,F282_4125, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_reference */
void F1708_15753 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '-';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4126,F282_4126, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_rename */
void F1708_15754 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '.';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4127,F282_4127, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_require */
void F1708_15755 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '/';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4128,F282_4128, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_rescue */
void F1708_15756 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '0';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4129,F282_4129, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_result */
void F1708_15757 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '1';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4072,F282_4072, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_retry */
void F1708_15758 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '2';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4131,F282_4131, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_select */
void F1708_15759 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '3';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4132,F282_4132, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_separate */
void F1708_15760 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '4';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4133,F282_4133, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_some */
void F1708_15761 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '5';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4134,F282_4134, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_strip */
void F1708_15762 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '6';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4135,F282_4135, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_then */
void F1708_15763 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '7';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4136,F282_4136, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_true */
void F1708_15764 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '8';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4073,F282_4073, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_undefine */
void F1708_15765 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '9';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4138,F282_4138, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_unique */
void F1708_15766 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) ':';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4139,F282_4139, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_until */
void F1708_15767 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) ';';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4140,F282_4140, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_variant */
void F1708_15768 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '<';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4141,F282_4141, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_void */
void F1708_15769 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '=';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4074,F282_4074, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_when */
void F1708_15770 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '>';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4143,F282_4143, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.make_xor */
void F1708_15771 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) 'W';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	tr1 = RTOSCF(4144,F282_4144, (RTCV(RTOSCF(6526,F870_6526, (Current)))));
	F1706_15689(Current, tr1);
	RTLE;
}

/* {ET_KEYWORD}.is_attached */
EIF_BOOLEAN F1708_15779 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) '\007';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD}.is_deferred */
EIF_BOOLEAN F1708_15788 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) '\020';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD}.is_detachable */
EIF_BOOLEAN F1708_15789 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) '\021';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD}.is_expanded */
EIF_BOOLEAN F1708_15795 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) '\027';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD}.is_false */
EIF_BOOLEAN F1708_15798 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) '\032';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD}.is_if */
EIF_BOOLEAN F1708_15802 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) '\036';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD}.is_inspect */
EIF_BOOLEAN F1708_15806 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) '!';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD}.is_is */
EIF_BOOLEAN F1708_15808 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) '#';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD}.is_precursor */
EIF_BOOLEAN F1708_15818 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) '+';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD}.is_reference */
EIF_BOOLEAN F1708_15820 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) '-';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD}.is_separate */
EIF_BOOLEAN F1708_15827 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) '4';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

void EIF_Minit809 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
