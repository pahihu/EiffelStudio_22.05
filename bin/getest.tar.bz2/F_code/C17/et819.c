/*
 * Code for class ET_INTEGER_CONSTANT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et819.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_INTEGER_CONSTANT}.reset */
void F1718_15876 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) NULL;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10617[Dtype(loc1)-1513])(loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10915[Dtype(RTCW(tr1))-1602])(tr1);
	}
	RTLE;
}

/* {ET_INTEGER_CONSTANT}.indexing_term_value */
EIF_REFERENCE F1718_15890 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1693_15529(loc1);
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7467[Dtype(RTCW(tr1))-1034])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_1_));
	} else {
		Result = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {ET_INTEGER_CONSTANT}.position */
EIF_REFERENCE F1718_15891 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10228[Dtype(loc1)-1392])(loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = F1687_15455(loc2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			RTLE;
			return (EIF_REFERENCE) Current;
		}
	}/* NOTREACHED */
	
}

/* {ET_INTEGER_CONSTANT}.value_position */
EIF_REFERENCE F1718_15892 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1687_15455(loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		RTLE;
		return (EIF_REFERENCE) Current;
	}/* NOTREACHED */
	
}

/* {ET_INTEGER_CONSTANT}.last_position */
EIF_REFERENCE F1718_15893 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1112, 0x01).id, 1112, _OBJSIZ_0_0_0_1_0_0_0_0_);
	ti4_1 = F1113_10975(Current);
	ti4_2 = F1113_10976(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	F1113_10973(RTCW(Result), ti4_1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 + ti4_3) - ((EIF_INTEGER_32) 1L)));
	RTLE;
	return Result;
}

/* {ET_INTEGER_CONSTANT}.is_negative */
EIF_BOOLEAN F1718_15895 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = F1693_15554(loc1);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {ET_INTEGER_CONSTANT}.is_integer_constant */
EIF_BOOLEAN F1718_15896 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {ET_INTEGER_CONSTANT}.is_hexadecimal */
EIF_BOOLEAN F1718_15897 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {ET_INTEGER_CONSTANT}.is_binary */
EIF_BOOLEAN F1718_15898 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {ET_INTEGER_CONSTANT}.is_integer_8 */
EIF_BOOLEAN F1718_15900 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		if (F1718_15895(Current)) {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
			tu8_2 = RTOSCF(15914,F1718_15914, (Current));
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
		} else {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
			tu8_2 = (EIF_NATURAL_64) ((EIF_INTEGER_8) 127L);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
		}
	}
	RTLE;
	return Result;
}

/* {ET_INTEGER_CONSTANT}.is_integer_16 */
EIF_BOOLEAN F1718_15901 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		if (F1718_15895(Current)) {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
			tu8_2 = RTOSCF(15915,F1718_15915, (Current));
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
		} else {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
			tu8_2 = (EIF_NATURAL_64) ((EIF_INTEGER_16) 32767L);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
		}
	}
	RTLE;
	return Result;
}

/* {ET_INTEGER_CONSTANT}.is_integer_32 */
EIF_BOOLEAN F1718_15902 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		if (F1718_15895(Current)) {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
			tu8_2 = RTOSCF(15916,F1718_15916, (Current));
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
		} else {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
			tu8_2 = (EIF_NATURAL_64) ((EIF_INTEGER_32) 2147483647L);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
		}
	}
	RTLE;
	return Result;
}

/* {ET_INTEGER_CONSTANT}.is_integer_64 */
EIF_BOOLEAN F1718_15903 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		if (F1718_15895(Current)) {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
			tu8_2 = RTOSCF(15917,F1718_15917, (Current));
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
		} else {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
			tu8_2 = (EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(9223372036854775807));
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
		}
	}
	RTLE;
	return Result;
}

/* {ET_INTEGER_CONSTANT}.is_natural_8 */
EIF_BOOLEAN F1718_15904 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		if (F1718_15895(Current)) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
			tu8_2 = (EIF_NATURAL_64) ((EIF_NATURAL_8) 255U);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
		}
	}
	RTLE;
	return Result;
}

/* {ET_INTEGER_CONSTANT}.is_natural_16 */
EIF_BOOLEAN F1718_15905 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		if (F1718_15895(Current)) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
			tu8_2 = (EIF_NATURAL_64) ((EIF_NATURAL_16) 65535U);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
		}
	}
	RTLE;
	return Result;
}

/* {ET_INTEGER_CONSTANT}.is_natural_32 */
EIF_BOOLEAN F1718_15906 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		if (F1718_15895(Current)) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			tu8_1 = *(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_);
			tu8_2 = (EIF_NATURAL_64) ((EIF_NATURAL_32) 4294967295U);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (tu8_1 <= tu8_2);
		}
	}
	RTLE;
	return Result;
}

/* {ET_INTEGER_CONSTANT}.is_natural_64 */
EIF_BOOLEAN F1718_15907 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		if (F1718_15895(Current)) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}/* NOTREACHED */
	
}

/* {ET_INTEGER_CONSTANT}.has_indexing_term_value */
EIF_BOOLEAN F1718_15908 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
		tr1 = RTOSCF(9540,F1056_9540, (Current));
		Result = F1048_9428(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), arg1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (ti4_2 - ((EIF_INTEGER_32) 1L)))) {
			tb1 = '\0';
			tb2 = F1693_15554(loc1);
			if (tb2) {
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5133[Dtype(RTCW(arg1))-714])(arg1, ((EIF_INTEGER_32) 1L)));
				tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '-');
			}
			if (tb1) {
				tr1 = RTOSCF(9540,F1056_9540, (Current));
				tr2 = RTMS_EX_H("-",1,45);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7467[Dtype(tr2)-1034])(tr2, *(EIF_REFERENCE *)(Current + _REFACS_1_));
				Result = F1048_9428(RTCW(tr1), tr2, arg1);
			} else {
				tb1 = '\0';
				tb2 = F1693_15559(loc1);
				if (tb2) {
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5133[Dtype(RTCW(arg1))-714])(arg1, ((EIF_INTEGER_32) 1L)));
					tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '+');
				}
				if (tb1) {
					tr1 = RTOSCF(9540,F1056_9540, (Current));
					tr2 = RTMS_EX_H("+",1,43);
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R7467[Dtype(tr2)-1034])(tr2, *(EIF_REFERENCE *)(Current + _REFACS_1_));
					Result = F1048_9428(RTCW(tr1), tr2, arg1);
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_INTEGER_CONSTANT}.set_sign */
void F1718_15910 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {ET_INTEGER_CONSTANT}.set_cast_type */
void F1718_15911 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {ET_INTEGER_CONSTANT}.set_type */
void F1718_15912 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
}

/* {ET_INTEGER_CONSTANT}.manifest_constant_convert_feature */
EIF_REFERENCE F1718_15913 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_3_) == NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_28_);
		tb1 = F1767_17255(RTCW(arg2), tr1);
		if (tb1) {
			if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11750[dtype-1718])(Current)) {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_72_);
				RTLE;
				return (EIF_REFERENCE) tr1;
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_29_);
			tb1 = F1767_17255(RTCW(arg2), tr1);
			if (tb1) {
				if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11751[dtype-1718])(Current)) {
					Result = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_73_);
				}
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_30_);
				tb1 = F1767_17255(RTCW(arg2), tr1);
				if (tb1) {
					if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11752[dtype-1718])(Current)) {
						Result = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_74_);
					}
				} else {
					tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_31_);
					tb1 = F1767_17255(RTCW(arg2), tr1);
					if (tb1) {
						if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11753[dtype-1718])(Current)) {
							Result = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_75_);
						}
					} else {
						tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_35_);
						tb1 = F1767_17255(RTCW(arg2), tr1);
						if (tb1) {
							if (F1718_15904(Current)) {
								Result = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_76_);
							}
						} else {
							tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_36_);
							tb1 = F1767_17255(RTCW(arg2), tr1);
							if (tb1) {
								if (F1718_15905(Current)) {
									Result = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_77_);
								}
							} else {
								tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_37_);
								tb1 = F1767_17255(RTCW(arg2), tr1);
								if (tb1) {
									if (F1718_15906(Current)) {
										Result = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_78_);
									}
								} else {
									tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_38_);
									tb1 = F1767_17255(RTCW(arg2), tr1);
									if (tb1) {
										if (F1718_15907(Current)) {
											Result = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_79_);
										}
									} else {
										tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_45_);
										tb1 = F1767_17255(RTCW(arg2), tr1);
										if (tb1) {
											Result = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_80_);
										} else {
											tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_46_);
											tb1 = F1767_17255(RTCW(arg2), tr1);
											if (tb1) {
												Result = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_81_);
												RTLE;
												return (EIF_REFERENCE) Result;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_INTEGER_CONSTANT}.integer_8_min_value_abs */
static EIF_NATURAL_64 F1718_15914_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (15914);
#define Result RTOSR(15914)
	Result = (EIF_NATURAL_64) ((EIF_INTEGER_8) -(EIF_INTEGER_8) (((EIF_INTEGER_8) -128L) + (EIF_INTEGER_8) ((EIF_INTEGER_32) 1L)));
	Result = (EIF_NATURAL_64) (EIF_NATURAL_64) (Result + (EIF_NATURAL_64) ((EIF_INTEGER_32) 1L));
	RTOSE (15914);
	RTEE;
	return Result;
#undef Result
}

EIF_NATURAL_64 F1718_15914 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15914,F1718_15914_body,(Current));
}

/* {ET_INTEGER_CONSTANT}.integer_16_min_value_abs */
static EIF_NATURAL_64 F1718_15915_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (15915);
#define Result RTOSR(15915)
	Result = (EIF_NATURAL_64) ((EIF_INTEGER_16) -(EIF_INTEGER_16) (((EIF_INTEGER_16) -32768L) + (EIF_INTEGER_16) ((EIF_INTEGER_32) 1L)));
	Result = (EIF_NATURAL_64) (EIF_NATURAL_64) (Result + (EIF_NATURAL_64) ((EIF_INTEGER_32) 1L));
	RTOSE (15915);
	RTEE;
	return Result;
#undef Result
}

EIF_NATURAL_64 F1718_15915 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15915,F1718_15915_body,(Current));
}

/* {ET_INTEGER_CONSTANT}.integer_32_min_value_abs */
static EIF_NATURAL_64 F1718_15916_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (15916);
#define Result RTOSR(15916)
	Result = (EIF_NATURAL_64) (EIF_INTEGER_32) -(EIF_INTEGER_32) (((EIF_INTEGER_32) 0x80000000L) + ((EIF_INTEGER_32) 1L));
	Result = (EIF_NATURAL_64) (EIF_NATURAL_64) (Result + (EIF_NATURAL_64) ((EIF_INTEGER_32) 1L));
	RTOSE (15916);
	RTEE;
	return Result;
#undef Result
}

EIF_NATURAL_64 F1718_15916 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15916,F1718_15916_body,(Current));
}

/* {ET_INTEGER_CONSTANT}.integer_64_min_value_abs */
static EIF_NATURAL_64 F1718_15917_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (15917);
#define Result RTOSR(15917)
	Result = (EIF_NATURAL_64) ((EIF_INTEGER_64) -(EIF_INTEGER_64) (((EIF_INTEGER_64) RTI64C(0x8000000000000000)) + (EIF_INTEGER_64) ((EIF_INTEGER_32) 1L)));
	Result = (EIF_NATURAL_64) (EIF_NATURAL_64) (Result + (EIF_NATURAL_64) ((EIF_INTEGER_32) 1L));
	RTOSE (15917);
	RTEE;
	return Result;
#undef Result
}

EIF_NATURAL_64 F1718_15917 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(15917,F1718_15917_body,(Current));
}

void EIF_Minit819 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
