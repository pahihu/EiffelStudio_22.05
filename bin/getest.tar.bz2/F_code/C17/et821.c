/*
 * Code for class ET_REGULAR_INTEGER_CONSTANT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et821.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_REGULAR_INTEGER_CONSTANT}.make */
void F1720_15922 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_64 arg2, EIF_BOOLEAN arg3)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_) = (EIF_NATURAL_64) arg2;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_) = (EIF_BOOLEAN) arg3;
	F1113_10974(Current);
	RTLE;
}

/* {ET_REGULAR_INTEGER_CONSTANT}.set_value */
void F1720_15923 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_NATURAL_64 *)(Current+ _I64OFF_5_1_0_2_0_0_0_) = (EIF_NATURAL_64) arg1;
	tr1 = eif_out__u8_s1(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_5_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {ET_REGULAR_INTEGER_CONSTANT}.process */
void F1720_15924 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1730[Dtype(RTCW(arg1))-165])(arg1, Current);
}

void EIF_Minit821 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
