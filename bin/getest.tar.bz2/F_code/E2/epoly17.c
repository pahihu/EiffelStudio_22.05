#include "epoly17.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R1769[1645])();
void R1769_init () {
	{long i; for (i = 0; i < 5; i++) R1769[i] = (char *(*)()) F166_2021;}
	R1769[707] = (char *(*)()) F873_6904;
	{long i; for (i = 710; i < 719; i++) R1769[i] = (char *(*)()) F166_2021;}
	{long i; for (i = 720; i < 738; i++) R1769[i] = (char *(*)()) F166_2021;}
	{long i; for (i = 893; i < 895; i++) R1769[i] = (char *(*)()) F166_2021;}
	R1769[1636] = (char *(*)()) F166_2021;
	R1769[1644] = (char *(*)()) F166_2021;
}

char *(*R1948[1683])();
void R1948_init () {
	R1948[0] = (char *(*)()) F191_2291;
	R1948[722] = (char *(*)()) F913_7565;
	R1948[756] = (char *(*)()) F947_7825_1948_2;
	R1948[757] = (char *(*)()) F948_7825_1948_2;
	R1948[759] = (char *(*)()) F950_7924_1948_2;
	R1948[760] = (char *(*)()) F951_7924_1948_2;
	R1948[762] = (char *(*)()) F953_8023_1948_2;
	R1948[763] = (char *(*)()) F954_8023_1948_2;
	R1948[765] = (char *(*)()) F956_8122_1948_2;
	R1948[766] = (char *(*)()) F957_8122_1948_2;
	R1948[768] = (char *(*)()) F959_8217_1948_2;
	R1948[769] = (char *(*)()) F960_8217_1948_2;
	R1948[771] = (char *(*)()) F962_8311_1948_2;
	R1948[772] = (char *(*)()) F963_8311_1948_2;
	R1948[774] = (char *(*)()) F965_8406_1948_2;
	R1948[775] = (char *(*)()) F966_8406_1948_2;
	R1948[777] = (char *(*)()) F968_8501_1948_2;
	R1948[778] = (char *(*)()) F969_8501_1948_2;
	R1948[780] = (char *(*)()) F971_8570_1948_2;
	R1948[781] = (char *(*)()) F972_8570_1948_2;
	R1948[783] = (char *(*)()) F974_8636_1948_2;
	R1948[784] = (char *(*)()) F975_8636_1948_2;
	{long i; for (i = 786; i < 788; i++) R1948[i] = (char *(*)()) F976_8667;}
	{long i; for (i = 789; i < 791; i++) R1948[i] = (char *(*)()) F979_8707;}
	{long i; for (i = 840; i < 842; i++) R1948[i] = (char *(*)()) F1030_9055;}
	{long i; for (i = 843; i < 845; i++) R1948[i] = (char *(*)()) F1033_9223;}
	R1948[892] = (char *(*)()) F1083_10268;
	R1948[1040] = (char *(*)()) F1231_11426;
	R1948[1682] = (char *(*)()) F1873_22336;
}
static EIF_BOOLEAN F947_7825_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F947_7825(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F948_7825_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F948_7825(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F950_7924_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F950_7924(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F951_7924_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F951_7924(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F953_8023_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F953_8023(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F954_8023_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F954_8023(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F956_8122_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F956_8122(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F957_8122_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F957_8122(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F959_8217_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F959_8217(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F960_8217_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F960_8217(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F962_8311_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F962_8311(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F963_8311_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F963_8311(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F965_8406_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F965_8406(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F966_8406_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F966_8406(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F968_8501_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F968_8501(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F969_8501_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F969_8501(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F971_8570_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F971_8570(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F972_8570_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F972_8570(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F974_8636_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F974_8636(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F975_8636_1948_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F975_8636(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R2051[6])();
void R2051_init () {
	R2051[0] = (char *(*)()) F199_2383;
	R2051[2] = (char *(*)()) F199_2383;
	R2051[3] = (char *(*)()) F202_2411;
	R2051[5] = (char *(*)()) F204_2437;
}

char *(*R2052[6])();
void R2052_init () {
	R2052[0] = (char *(*)()) F199_2384;
	{long i; for (i = 2; i < 4; i++) R2052[i] = (char *(*)()) F199_2384;}
	R2052[5] = (char *(*)()) F204_2438;
}

char *(*R2054[6])();
void R2054_init () {
	R2054[0] = (char *(*)()) F199_2386;
	{long i; for (i = 2; i < 4; i++) R2054[i] = (char *(*)()) F199_2386;}
	R2054[5] = (char *(*)()) F204_2439;
}

char *(*R2056[6])();
void R2056_init () {
	R2056[0] = (char *(*)()) F199_2388;
	R2056[2] = (char *(*)()) F201_2400;
	R2056[3] = (char *(*)()) F199_2388;
	R2056[5] = (char *(*)()) F201_2400;
}

char *(*R2089[1564])();
void R2089_init () {
	R2089[0] = (char *(*)()) F209_2459;
	R2089[1] = (char *(*)()) F210_2465;
	{long i; for (i = 3; i < 5; i++) R2089[i] = (char *(*)()) F211_2468;}
	{long i; for (i = 1438; i < 1440; i++) R2089[i] = (char *(*)()) F1647_14659;}
	R2089[1442] = (char *(*)()) F1649_14694;
	{long i; for (i = 1443; i < 1445; i++) R2089[i] = (char *(*)()) F1644_14641;}
	{long i; for (i = 1446; i < 1448; i++) R2089[i] = (char *(*)()) F1649_14694;}
	R2089[1449] = (char *(*)()) F1649_14694;
	{long i; for (i = 1451; i < 1453; i++) R2089[i] = (char *(*)()) F1649_14694;}
	{long i; for (i = 1561; i < 1564; i++) R2089[i] = (char *(*)()) F1649_14694;}
}

char *(*R2090[1564])();
void R2090_init () {
	R2090[0] = (char *(*)()) F209_2460;
	R2090[1] = (char *(*)()) F210_2466;
	{long i; for (i = 3; i < 5; i++) R2090[i] = (char *(*)()) F212_2474;}
	{long i; for (i = 1438; i < 1440; i++) R2090[i] = (char *(*)()) F1647_14665;}
	R2090[1442] = (char *(*)()) F1651_14778;
	{long i; for (i = 1443; i < 1445; i++) R2090[i] = (char *(*)()) F1652_14825;}
	R2090[1446] = (char *(*)()) F1655_14878;
	R2090[1447] = (char *(*)()) F1656_14919;
	R2090[1449] = (char *(*)()) F1658_14971;
	{long i; for (i = 1451; i < 1453; i++) R2090[i] = (char *(*)()) F1659_15023;}
	R2090[1561] = (char *(*)()) F1770_17390;
	R2090[1562] = (char *(*)()) F1771_17424;
	R2090[1563] = (char *(*)()) F1772_17509;
}

char *(*R2091[1564])();
void R2091_init () {
	R2091[0] = (char *(*)()) F209_2461;
	R2091[1] = (char *(*)()) F210_2467;
	{long i; for (i = 3; i < 5; i++) R2091[i] = (char *(*)()) F211_2470;}
	{long i; for (i = 1438; i < 1440; i++) R2091[i] = (char *(*)()) F1646_14657;}
	{long i; for (i = 1442; i < 1445; i++) R2091[i] = (char *(*)()) F211_2470;}
	{long i; for (i = 1446; i < 1448; i++) R2091[i] = (char *(*)()) F211_2470;}
	R2091[1449] = (char *(*)()) F211_2470;
	{long i; for (i = 1451; i < 1453; i++) R2091[i] = (char *(*)()) F211_2470;}
	{long i; for (i = 1561; i < 1564; i++) R2091[i] = (char *(*)()) F211_2470;}
}

char *(*R2106[1561])();
void R2106_init () {
	R2106[0] = (char *(*)()) F212_2475;
	R2106[1] = (char *(*)()) F213_2478;
	{long i; for (i = 1439; i < 1442; i++) R2106[i] = (char *(*)()) F1649_14746;}
	{long i; for (i = 1443; i < 1445; i++) R2106[i] = (char *(*)()) F1649_14746;}
	R2106[1446] = (char *(*)()) F1649_14746;
	{long i; for (i = 1448; i < 1450; i++) R2106[i] = (char *(*)()) F1649_14746;}
	{long i; for (i = 1558; i < 1561; i++) R2106[i] = (char *(*)()) F1649_14746;}
}

char *(*R2112[205])();
void R2112_init () {
	{long i; for (i = 0; i < 2; i++) R2112[i] = (char *(*)()) F214_2479;}
	R2112[4] = (char *(*)()) F214_2479;
	R2112[6] = (char *(*)()) F874_6905;
	R2112[8] = (char *(*)()) F874_6905;
	R2112[9] = (char *(*)()) F214_2479;
	{long i; for (i = 140; i < 144; i++) R2112[i] = (char *(*)()) F214_2479;}
	R2112[154] = (char *(*)()) F214_2479;
	R2112[156] = (char *(*)()) F214_2479;
	R2112[158] = (char *(*)()) F874_6905;
	R2112[159] = (char *(*)()) F214_2479;
	R2112[161] = (char *(*)()) F214_2479;
	R2112[163] = (char *(*)()) F214_2479;
	R2112[165] = (char *(*)()) F874_6905;
	R2112[166] = (char *(*)()) F214_2479;
	R2112[204] = (char *(*)()) F214_2479;
}

char *(*R2115[205])();
void R2115_init () {
	{long i; for (i = 0; i < 2; i++) R2115[i] = (char *(*)()) F214_2482;}
	R2115[4] = (char *(*)()) F214_2482;
	R2115[6] = (char *(*)()) F874_6908;
	R2115[8] = (char *(*)()) F874_6908;
	R2115[9] = (char *(*)()) F214_2482;
	{long i; for (i = 140; i < 144; i++) R2115[i] = (char *(*)()) F214_2482;}
	R2115[154] = (char *(*)()) F214_2482;
	R2115[156] = (char *(*)()) F214_2482;
	R2115[158] = (char *(*)()) F874_6908;
	R2115[159] = (char *(*)()) F214_2482;
	R2115[161] = (char *(*)()) F214_2482;
	R2115[163] = (char *(*)()) F214_2482;
	R2115[165] = (char *(*)()) F874_6908;
	R2115[166] = (char *(*)()) F214_2482;
	R2115[204] = (char *(*)()) F214_2482;
}


#ifdef __cplusplus
}
#endif
