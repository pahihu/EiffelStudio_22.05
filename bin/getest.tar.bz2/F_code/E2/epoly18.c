#include "epoly18.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2116[205])();
void R2116_init () {
	R2116[0] = (char *(*)()) F214_2483;
	R2116[1] = (char *(*)()) F1469_13604;
	R2116[4] = (char *(*)()) F214_2483;
	R2116[6] = (char *(*)()) F214_2483;
	{long i; for (i = 8; i < 10; i++) R2116[i] = (char *(*)()) F1469_13604;}
	{long i; for (i = 140; i < 144; i++) R2116[i] = (char *(*)()) F1612_14483;}
	R2116[154] = (char *(*)()) F1612_14483;
	R2116[156] = (char *(*)()) F1612_14483;
	{long i; for (i = 158; i < 160; i++) R2116[i] = (char *(*)()) F1612_14483;}
	R2116[161] = (char *(*)()) F214_2483;
	R2116[163] = (char *(*)()) F214_2483;
	{long i; for (i = 165; i < 167; i++) R2116[i] = (char *(*)()) F214_2483;}
	R2116[204] = (char *(*)()) F214_2483;
}

char *(*R2117[205])();
void R2117_init () {
	{long i; for (i = 0; i < 2; i++) R2117[i] = (char *(*)()) F218_2509;}
	R2117[4] = (char *(*)()) F218_2509;
	R2117[6] = (char *(*)()) F218_2509;
	{long i; for (i = 8; i < 10; i++) R2117[i] = (char *(*)()) F218_2509;}
	{long i; for (i = 140; i < 144; i++) R2117[i] = (char *(*)()) F214_2484;}
	R2117[154] = (char *(*)()) F218_2509;
	R2117[156] = (char *(*)()) F218_2509;
	{long i; for (i = 158; i < 160; i++) R2117[i] = (char *(*)()) F218_2509;}
	R2117[161] = (char *(*)()) F218_2509;
	R2117[163] = (char *(*)()) F218_2509;
	{long i; for (i = 165; i < 167; i++) R2117[i] = (char *(*)()) F218_2509;}
	R2117[204] = (char *(*)()) F214_2484;
}

char *(*R2119[205])();
void R2119_init () {
	{long i; for (i = 0; i < 2; i++) R2119[i] = (char *(*)()) F214_2486;}
	R2119[4] = (char *(*)()) F220_2514;
	R2119[6] = (char *(*)()) F220_2514;
	{long i; for (i = 8; i < 10; i++) R2119[i] = (char *(*)()) F220_2514;}
	{long i; for (i = 140; i < 143; i++) R2119[i] = (char *(*)()) F214_2486;}
	R2119[143] = (char *(*)()) F217_2504;
	R2119[154] = (char *(*)()) F214_2486;
	R2119[156] = (char *(*)()) F214_2486;
	{long i; for (i = 158; i < 160; i++) R2119[i] = (char *(*)()) F220_2514;}
	R2119[161] = (char *(*)()) F214_2486;
	R2119[163] = (char *(*)()) F214_2486;
	{long i; for (i = 165; i < 167; i++) R2119[i] = (char *(*)()) F220_2514;}
	R2119[204] = (char *(*)()) F214_2486;
}

char *(*R2120[205])();
void R2120_init () {
	{long i; for (i = 0; i < 2; i++) R2120[i] = (char *(*)()) F216_2494;}
	R2120[4] = (char *(*)()) F216_2494;
	R2120[6] = (char *(*)()) F216_2494;
	{long i; for (i = 8; i < 10; i++) R2120[i] = (char *(*)()) F216_2494;}
	{long i; for (i = 140; i < 143; i++) R2120[i] = (char *(*)()) F214_2487;}
	R2120[143] = (char *(*)()) F216_2494;
	R2120[154] = (char *(*)()) F216_2494;
	R2120[156] = (char *(*)()) F216_2494;
	{long i; for (i = 158; i < 160; i++) R2120[i] = (char *(*)()) F216_2494;}
	R2120[161] = (char *(*)()) F216_2494;
	R2120[163] = (char *(*)()) F216_2494;
	{long i; for (i = 165; i < 167; i++) R2120[i] = (char *(*)()) F216_2494;}
	R2120[204] = (char *(*)()) F214_2487;
}

char *(*R2121[205])();
void R2121_init () {
	{long i; for (i = 0; i < 2; i++) R2121[i] = (char *(*)()) F216_2495;}
	R2121[4] = (char *(*)()) F216_2495;
	R2121[6] = (char *(*)()) F216_2495;
	{long i; for (i = 8; i < 10; i++) R2121[i] = (char *(*)()) F216_2495;}
	{long i; for (i = 140; i < 143; i++) R2121[i] = (char *(*)()) F214_2488;}
	R2121[143] = (char *(*)()) F216_2495;
	R2121[154] = (char *(*)()) F216_2495;
	R2121[156] = (char *(*)()) F216_2495;
	{long i; for (i = 158; i < 160; i++) R2121[i] = (char *(*)()) F216_2495;}
	R2121[161] = (char *(*)()) F216_2495;
	R2121[163] = (char *(*)()) F216_2495;
	{long i; for (i = 165; i < 167; i++) R2121[i] = (char *(*)()) F216_2495;}
	R2121[204] = (char *(*)()) F214_2488;
}

char *(*R2124[65])();
void R2124_init () {
	{long i; for (i = 0; i < 4; i++) R2124[i] = (char *(*)()) F1610_14401;}
	R2124[14] = (char *(*)()) F1610_14401;
	R2124[16] = (char *(*)()) F1610_14401;
	{long i; for (i = 18; i < 20; i++) R2124[i] = (char *(*)()) F1610_14401;}
	R2124[21] = (char *(*)()) F1610_14401;
	R2124[23] = (char *(*)()) F1610_14401;
	{long i; for (i = 25; i < 27; i++) R2124[i] = (char *(*)()) F1610_14401;}
	R2124[64] = (char *(*)()) F1678_15270;
}

char *(*R2165[6])();
void R2165_init () {
	R2165[0] = (char *(*)()) F1386_12863;
	{long i; for (i = 4; i < 6; i++) R2165[i] = (char *(*)()) F1389_12966;}
}

char *(*R2216[40])();
void R2216_init () {
	R2216[0] = (char *(*)()) F234_2586;
	R2216[1] = (char *(*)()) F235_2610;
	R2216[5] = (char *(*)()) F239_2613;
	R2216[7] = (char *(*)()) F241_2615;
	R2216[8] = (char *(*)()) F242_2621;
	R2216[9] = (char *(*)()) F243_2638;
	R2216[11] = (char *(*)()) F245_2642;
	R2216[12] = (char *(*)()) F246_2646;
	R2216[15] = (char *(*)()) F249_2648;
	R2216[16] = (char *(*)()) F250_2652;
	R2216[18] = (char *(*)()) F252_2654;
	R2216[19] = (char *(*)()) F253_2656;
	R2216[20] = (char *(*)()) F254_2658;
	R2216[22] = (char *(*)()) F256_2664;
	R2216[23] = (char *(*)()) F257_2668;
	R2216[24] = (char *(*)()) F258_2672;
	R2216[25] = (char *(*)()) F259_2674;
	R2216[27] = (char *(*)()) F261_2676;
	R2216[28] = (char *(*)()) F262_2678;
	R2216[30] = (char *(*)()) F264_2680;
	R2216[31] = (char *(*)()) F265_2682;
	R2216[32] = (char *(*)()) F266_2684;
	R2216[34] = (char *(*)()) F268_2686;
	R2216[35] = (char *(*)()) F269_2688;
	R2216[36] = (char *(*)()) F270_2690;
	R2216[37] = (char *(*)()) F271_2692;
	R2216[38] = (char *(*)()) F272_2696;
	R2216[39] = (char *(*)()) F273_2698;
}

char *(*R2275[89])();
void R2275_init () {
	R2275[0] = (char *(*)()) F279_2711;
	R2275[1] = (char *(*)()) F280_2714;
	R2275[87] = (char *(*)()) F274_2700;
	R2275[88] = (char *(*)()) F275_2700_2275_3;
}
static EIF_BOOLEAN F275_2700_2275_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F275_2700(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R2276[89])();
void R2276_init () {
	{long i; for (i = 0; i < 2; i++) R2276[i] = (char *(*)()) F274_2701;}
	R2276[87] = (char *(*)()) F274_2701;
	R2276[88] = (char *(*)()) F275_2701_2276_3;
}
static EIF_BOOLEAN F275_2701_2276_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F275_2701(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R2277[89])();
void R2277_init () {
	R2277[0] = (char *(*)()) F279_2712;
	R2277[1] = (char *(*)()) F280_2715;
	R2277[87] = (char *(*)()) F366_5251;
	R2277[88] = (char *(*)()) F367_5251_2277_3;
}
static EIF_BOOLEAN F367_5251_2277_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F367_5251(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R3973[1480])();
void R3973_init () {
	R3973[0] = (char *(*)()) F289_4404;
	R3973[1] = (char *(*)()) F290_4408;
	R3973[2] = (char *(*)()) F291_4412;
	R3973[3] = (char *(*)()) F292_4416;
	R3973[1479] = (char *(*)()) F1768_17318;
}

char *(*R4337[1554])();
void R4337_init () {
	R4337[0] = (char *(*)()) F309_4782;
	R4337[395] = (char *(*)()) F304_4782;
	R4337[396] = (char *(*)()) F305_4782;
	R4337[397] = (char *(*)()) F306_4782;
	R4337[398] = (char *(*)()) F307_4782;
	R4337[399] = (char *(*)()) F308_4782;
	R4337[400] = (char *(*)()) F309_4782;
	R4337[401] = (char *(*)()) F310_4782;
	R4337[402] = (char *(*)()) F311_4782;
	R4337[403] = (char *(*)()) F312_4782;
	R4337[404] = (char *(*)()) F313_4782;
	R4337[405] = (char *(*)()) F314_4782;
	R4337[406] = (char *(*)()) F315_4782;
	R4337[407] = (char *(*)()) F304_4782;
	R4337[408] = (char *(*)()) F305_4782;
	R4337[409] = (char *(*)()) F306_4782;
	R4337[410] = (char *(*)()) F308_4782;
	R4337[411] = (char *(*)()) F310_4782;
	R4337[412] = (char *(*)()) F309_4782;
	R4337[413] = (char *(*)()) F312_4782;
	R4337[712] = (char *(*)()) F313_4782;
	R4337[715] = (char *(*)()) F312_4782;
	R4337[1553] = (char *(*)()) F312_4782;
}

char *(*R4338[1554])();
void R4338_init () {
	R4338[0] = (char *(*)()) F309_4783_4338_152;
	R4338[395] = (char *(*)()) F304_4783;
	R4338[396] = (char *(*)()) F305_4783_4338_152;
	R4338[397] = (char *(*)()) F306_4783_4338_152;
	R4338[398] = (char *(*)()) F307_4783_4338_152;
	R4338[399] = (char *(*)()) F308_4783_4338_152;
	R4338[400] = (char *(*)()) F309_4783_4338_152;
	R4338[401] = (char *(*)()) F310_4783_4338_152;
	R4338[402] = (char *(*)()) F311_4783_4338_152;
	R4338[403] = (char *(*)()) F312_4783_4338_152;
	R4338[404] = (char *(*)()) F313_4783_4338_152;
	R4338[405] = (char *(*)()) F314_4783_4338_152;
	R4338[406] = (char *(*)()) F315_4783_4338_152;
	R4338[407] = (char *(*)()) F304_4783;
	R4338[408] = (char *(*)()) F305_4783_4338_152;
	R4338[409] = (char *(*)()) F306_4783_4338_152;
	R4338[410] = (char *(*)()) F308_4783_4338_152;
	R4338[411] = (char *(*)()) F310_4783_4338_152;
	R4338[412] = (char *(*)()) F309_4783_4338_152;
	R4338[413] = (char *(*)()) F312_4783_4338_152;
	R4338[712] = (char *(*)()) F313_4783_4338_152;
	R4338[715] = (char *(*)()) F312_4783_4338_152;
	R4338[1553] = (char *(*)()) F312_4783_4338_152;
}
static void F309_4783_4338_152 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F309_4783(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F305_4783_4338_152 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F305_4783(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F306_4783_4338_152 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F306_4783(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F307_4783_4338_152 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F307_4783(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F308_4783_4338_152 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F308_4783(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F310_4783_4338_152 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F310_4783(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F311_4783_4338_152 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F311_4783(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F312_4783_4338_152 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F312_4783(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F313_4783_4338_152 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F313_4783(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F314_4783_4338_152 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F314_4783(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F315_4783_4338_152 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F315_4783(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4344[1554])();
void R4344_init () {
	R4344[0] = (char *(*)()) F309_4789;
	R4344[395] = (char *(*)()) F304_4789;
	R4344[396] = (char *(*)()) F305_4789;
	R4344[397] = (char *(*)()) F306_4789;
	R4344[398] = (char *(*)()) F307_4789;
	R4344[399] = (char *(*)()) F308_4789;
	R4344[400] = (char *(*)()) F309_4789;
	R4344[401] = (char *(*)()) F310_4789;
	R4344[402] = (char *(*)()) F311_4789;
	R4344[403] = (char *(*)()) F312_4789;
	R4344[404] = (char *(*)()) F313_4789;
	R4344[405] = (char *(*)()) F314_4789;
	R4344[406] = (char *(*)()) F315_4789;
	R4344[407] = (char *(*)()) F304_4789;
	R4344[408] = (char *(*)()) F305_4789;
	R4344[409] = (char *(*)()) F306_4789;
	R4344[410] = (char *(*)()) F308_4789;
	R4344[411] = (char *(*)()) F310_4789;
	R4344[412] = (char *(*)()) F309_4789;
	R4344[413] = (char *(*)()) F312_4789;
	R4344[712] = (char *(*)()) F313_4789;
	R4344[715] = (char *(*)()) F312_4789;
	R4344[1553] = (char *(*)()) F312_4789;
}

char *(*R4669[283])();
void R4669_init () {
	R4669[0] = (char *(*)()) F1092_10438;
	R4669[277] = (char *(*)()) F687_5581;
	R4669[282] = (char *(*)()) F687_5581;
}

char *(*R4682[283])();
void R4682_init () {
	R4682[0] = (char *(*)()) F1092_10461;
	R4682[277] = (char *(*)()) F687_5655;
	R4682[282] = (char *(*)()) F687_5655;
}

char *(*R4684[283])();
void R4684_init () {
	R4684[0] = (char *(*)()) F1092_10459;
	R4684[277] = (char *(*)()) F687_5658;
	R4684[282] = (char *(*)()) F687_5658;
}

char *(*R4712[283])();
void R4712_init () {
	R4712[0] = (char *(*)()) F1092_10456;
	R4712[277] = (char *(*)()) F687_5688;
	R4712[282] = (char *(*)()) F687_5688;
}

char *(*R4725[283])();
void R4725_init () {
	R4725[0] = (char *(*)()) F1092_10450;
	R4725[277] = (char *(*)()) F687_5695;
	R4725[282] = (char *(*)()) F687_5695;
}

char *(*R4737[790])();
void R4737_init () {
	R4737[0] = (char *(*)()) F427_5363;
	R4737[1] = (char *(*)()) F428_5363_4737_1;
	R4737[2] = (char *(*)()) F429_5363_4737_1;
	R4737[3] = (char *(*)()) F430_5363;
	R4737[4] = (char *(*)()) F431_5363_4737_1;
	{long i; for (i = 729; i < 731; i++) R4737[i] = (char *(*)()) F1127_11140;}
	R4737[731] = (char *(*)()) F1128_11140_4737_1;
	R4737[732] = (char *(*)()) F1130_11140_4737_1;
	R4737[733] = (char *(*)()) F1132_11140_4737_1;
	{long i; for (i = 734; i < 736; i++) R4737[i] = (char *(*)()) F1127_11140;}
	R4737[736] = (char *(*)()) F1128_11140_4737_1;
	R4737[757] = (char *(*)()) F1127_11140;
	R4737[758] = (char *(*)()) F1128_11140_4737_1;
	R4737[775] = (char *(*)()) F1127_11140;
	R4737[776] = (char *(*)()) F1128_11140_4737_1;
	R4737[777] = (char *(*)()) F1127_11140;
	R4737[778] = (char *(*)()) F1129_11140_4737_1;
	R4737[779] = (char *(*)()) F1127_11140;
	R4737[780] = (char *(*)()) F1131_11140_4737_1;
	R4737[781] = (char *(*)()) F1132_11140_4737_1;
	R4737[782] = (char *(*)()) F1128_11140_4737_1;
	R4737[786] = (char *(*)()) F1213_11234;
	R4737[787] = (char *(*)()) F1127_11140;
	R4737[788] = (char *(*)()) F1128_11140_4737_1;
	R4737[789] = (char *(*)()) F1130_11140_4737_1;
}
static EIF_REFERENCE F428_5363_4737_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F428_5363(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1020, 0x00).id, 1020, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F429_5363_4737_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F429_5363(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(950, 0x00).id, 950, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F431_5363_4737_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F431_5363(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(950, 0x00).id, 950, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1128_11140_4737_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1128_11140(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(950, 0x00).id, 950, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1130_11140_4737_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1130_11140(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(962, 0x00).id, 962, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1132_11140_4737_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1132_11140(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(968, 0x00).id, 968, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1129_11140_4737_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1129_11140(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1131_11140_4737_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1131_11140(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(983, 0x00).id, 983, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R4738[790])();
void R4738_init () {
	R4738[0] = (char *(*)()) F427_5366;
	R4738[1] = (char *(*)()) F428_5366;
	R4738[2] = (char *(*)()) F429_5366;
	R4738[3] = (char *(*)()) F430_5366;
	R4738[4] = (char *(*)()) F431_5366;
	R4738[197] = (char *(*)()) F623_5492;
	R4738[729] = (char *(*)()) F1156_11179;
	R4738[730] = (char *(*)()) F1157_11179;
	R4738[731] = (char *(*)()) F1158_11179;
	R4738[732] = (char *(*)()) F1159_11179;
	R4738[733] = (char *(*)()) F1160_11179;
	R4738[734] = (char *(*)()) F1161_11179;
	R4738[735] = (char *(*)()) F1162_11179;
	R4738[736] = (char *(*)()) F1163_11179;
	R4738[757] = (char *(*)()) F1172_11188;
	R4738[758] = (char *(*)()) F1176_11188;
	R4738[775] = (char *(*)()) F1172_11188;
	R4738[776] = (char *(*)()) F1173_11188;
	R4738[777] = (char *(*)()) F1174_11188;
	R4738[778] = (char *(*)()) F1175_11188;
	R4738[779] = (char *(*)()) F1177_11188;
	R4738[780] = (char *(*)()) F1178_11188;
	R4738[781] = (char *(*)()) F1179_11188;
	R4738[782] = (char *(*)()) F1176_11188;
	R4738[786] = (char *(*)()) F1213_11236;
	R4738[787] = (char *(*)()) F1214_11249;
	R4738[788] = (char *(*)()) F1215_11249;
	R4738[789] = (char *(*)()) F1216_11249;
}


#ifdef __cplusplus
}
#endif
