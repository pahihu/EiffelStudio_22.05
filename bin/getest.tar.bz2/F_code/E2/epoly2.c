#include "epoly2.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R1391[1464])();
void R1391_init () {
	R1391[0] = (char *(*)()) F288_4380;
	R1391[1119] = (char *(*)()) F905_7418;
	{long i; for (i = 1167; i < 1173; i++) R1391[i] = (char *(*)()) F1455_13458;}
	R1391[1174] = (char *(*)()) F1455_13458;
	R1391[1176] = (char *(*)()) F1455_13458;
	R1391[1178] = (char *(*)()) F1455_13458;
	{long i; for (i = 1185; i < 1187; i++) R1391[i] = (char *(*)()) F1455_13458;}
	R1391[1189] = (char *(*)()) F1455_13458;
	R1391[1191] = (char *(*)()) F1455_13458;
	{long i; for (i = 1193; i < 1195; i++) R1391[i] = (char *(*)()) F1455_13458;}
	R1391[1200] = (char *(*)()) F1455_13458;
	R1391[1202] = (char *(*)()) F1455_13458;
	{long i; for (i = 1204; i < 1208; i++) R1391[i] = (char *(*)()) F1455_13458;}
	R1391[1225] = (char *(*)()) F1455_13458;
	R1391[1244] = (char *(*)()) F1455_13458;
	R1391[1257] = (char *(*)()) F1455_13458;
	{long i; for (i = 1264; i < 1268; i++) R1391[i] = (char *(*)()) F1455_13458;}
	R1391[1269] = (char *(*)()) F1455_13458;
	R1391[1271] = (char *(*)()) F1455_13458;
	R1391[1274] = (char *(*)()) F1455_13458;
	R1391[1276] = (char *(*)()) F1455_13458;
	R1391[1280] = (char *(*)()) F1455_13458;
	R1391[1282] = (char *(*)()) F1455_13458;
	{long i; for (i = 1293; i < 1295; i++) R1391[i] = (char *(*)()) F1455_13458;}
	{long i; for (i = 1295; i < 1297; i++) R1391[i] = (char *(*)()) F905_7418;}
	{long i; for (i = 1311; i < 1313; i++) R1391[i] = (char *(*)()) F1455_13458;}
	R1391[1380] = (char *(*)()) F1455_13458;
	{long i; for (i = 1401; i < 1403; i++) R1391[i] = (char *(*)()) F1455_13458;}
	{long i; for (i = 1410; i < 1413; i++) R1391[i] = (char *(*)()) F1455_13458;}
	{long i; for (i = 1414; i < 1417; i++) R1391[i] = (char *(*)()) F1455_13458;}
	R1391[1420] = (char *(*)()) F1455_13458;
	R1391[1423] = (char *(*)()) F1455_13458;
	R1391[1425] = (char *(*)()) F1455_13458;
	{long i; for (i = 1427; i < 1429; i++) R1391[i] = (char *(*)()) F1455_13458;}
	{long i; for (i = 1430; i < 1435; i++) R1391[i] = (char *(*)()) F1455_13458;}
	R1391[1461] = (char *(*)()) F1750_16130;
	R1391[1463] = (char *(*)()) F1455_13458;
}

char *(*R1395[313])();
void R1395_init () {
	R1395[0] = (char *(*)()) F1062_10072;
	R1395[1] = (char *(*)()) F1063_10086;
	R1395[304] = (char *(*)()) F1366_12302;
	R1395[312] = (char *(*)()) F1373_12371;
}

char *(*R1401[313])();
void R1401_init () {
	R1401[0] = (char *(*)()) F1062_10066;
	R1401[1] = (char *(*)()) F1063_10085;
	R1401[304] = (char *(*)()) F1366_12287;
	R1401[312] = (char *(*)()) F1053_9536;
}

char *(*R1403[313])();
void R1403_init () {
	R1403[0] = (char *(*)()) F1062_10068;
	R1403[1] = (char *(*)()) F1063_10080;
	R1403[304] = (char *(*)()) F1366_12282;
	R1403[312] = (char *(*)()) F1367_12314;
}

char *(*R1404[313])();
void R1404_init () {
	R1404[0] = (char *(*)()) F1062_10069_1404_1;
	R1404[1] = (char *(*)()) F1063_10081_1404_1;
	R1404[304] = (char *(*)()) F1366_12283;
	R1404[312] = (char *(*)()) F1374_12388_1404_1;
}
static EIF_REFERENCE F1062_10069_1404_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1062_10069(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1063_10081_1404_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1063_10081(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1374_12388_1404_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1374_12388(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R1408[9])();
void R1408_init () {
	R1408[0] = (char *(*)()) F1366_12281;
	R1408[3] = (char *(*)()) F1367_12313;
	R1408[8] = (char *(*)()) F1373_12366;
}

char *(*R1529[7])();
void R1529_init () {
	R1529[0] = (char *(*)()) F158_1558;
	R1529[1] = (char *(*)()) F159_1558_1529_1;
	R1529[4] = (char *(*)()) F158_1558;
	{long i; for (i = 5; i < 7; i++) R1529[i] = (char *(*)()) F159_1558_1529_1;}
}
static EIF_REFERENCE F159_1558_1529_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F159_1558(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(950, 0x00).id, 950, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R1531[7])();
void R1531_init () {
	R1531[0] = (char *(*)()) F158_1560;
	R1531[1] = (char *(*)()) F159_1560_1531_4;
	R1531[4] = (char *(*)()) F158_1560;
	{long i; for (i = 5; i < 7; i++) R1531[i] = (char *(*)()) F159_1560_1531_4;}
}
static void F159_1560_1531_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F159_1560(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R1532[7])();
void R1532_init () {
	R1532[0] = (char *(*)()) F158_1561;
	R1532[1] = (char *(*)()) F159_1561_1532_4;
	R1532[4] = (char *(*)()) F158_1561;
	{long i; for (i = 5; i < 7; i++) R1532[i] = (char *(*)()) F159_1561_1532_4;}
}
static void F159_1561_1532_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F159_1561(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R1539[3])();
void R1539_init () {
	R1539[0] = (char *(*)()) F162_1567;
	R1539[1] = (char *(*)()) F163_1567;
	R1539[2] = (char *(*)()) F164_1570;
}

char *(*R1547[1645])();
void R1547_init () {
	{long i; for (i = 0; i < 5; i++) R1547[i] = (char *(*)()) F166_1799;}
	R1547[707] = (char *(*)()) F166_1799;
	{long i; for (i = 710; i < 719; i++) R1547[i] = (char *(*)()) F166_1799;}
	{long i; for (i = 720; i < 730; i++) R1547[i] = (char *(*)()) F166_1799;}
	R1547[730] = (char *(*)()) F896_7221;
	{long i; for (i = 731; i < 738; i++) R1547[i] = (char *(*)()) F166_1799;}
	R1547[893] = (char *(*)()) F1059_9850;
	R1547[894] = (char *(*)()) F166_1799;
	R1547[1636] = (char *(*)()) F166_1799;
	R1547[1644] = (char *(*)()) F166_1799;
}

char *(*R1548[1645])();
void R1548_init () {
	{long i; for (i = 0; i < 5; i++) R1548[i] = (char *(*)()) F166_1800;}
	R1548[707] = (char *(*)()) F166_1800;
	{long i; for (i = 710; i < 719; i++) R1548[i] = (char *(*)()) F166_1800;}
	{long i; for (i = 720; i < 730; i++) R1548[i] = (char *(*)()) F166_1800;}
	R1548[730] = (char *(*)()) F896_7222;
	{long i; for (i = 731; i < 738; i++) R1548[i] = (char *(*)()) F166_1800;}
	R1548[893] = (char *(*)()) F1059_9851;
	R1548[894] = (char *(*)()) F166_1800;
	R1548[1636] = (char *(*)()) F166_1800;
	R1548[1644] = (char *(*)()) F166_1800;
}

char *(*R1549[1645])();
void R1549_init () {
	{long i; for (i = 0; i < 5; i++) R1549[i] = (char *(*)()) F166_1801;}
	R1549[707] = (char *(*)()) F166_1801;
	{long i; for (i = 710; i < 719; i++) R1549[i] = (char *(*)()) F166_1801;}
	{long i; for (i = 720; i < 730; i++) R1549[i] = (char *(*)()) F166_1801;}
	R1549[730] = (char *(*)()) F896_7223;
	{long i; for (i = 731; i < 738; i++) R1549[i] = (char *(*)()) F166_1801;}
	{long i; for (i = 893; i < 895; i++) R1549[i] = (char *(*)()) F166_1801;}
	R1549[1636] = (char *(*)()) F166_1801;
	R1549[1644] = (char *(*)()) F166_1801;
}

char *(*R1567[1645])();
void R1567_init () {
	{long i; for (i = 0; i < 5; i++) R1567[i] = (char *(*)()) F166_1819;}
	R1567[707] = (char *(*)()) F166_1819;
	{long i; for (i = 710; i < 719; i++) R1567[i] = (char *(*)()) F166_1819;}
	{long i; for (i = 720; i < 730; i++) R1567[i] = (char *(*)()) F166_1819;}
	R1567[730] = (char *(*)()) F896_7225;
	{long i; for (i = 731; i < 738; i++) R1567[i] = (char *(*)()) F166_1819;}
	R1567[893] = (char *(*)()) F1059_9852;
	R1567[894] = (char *(*)()) F166_1819;
	R1567[1636] = (char *(*)()) F166_1819;
	R1567[1644] = (char *(*)()) F166_1819;
}

char *(*R1568[1645])();
void R1568_init () {
	{long i; for (i = 0; i < 5; i++) R1568[i] = (char *(*)()) F166_1820;}
	R1568[707] = (char *(*)()) F166_1820;
	{long i; for (i = 710; i < 719; i++) R1568[i] = (char *(*)()) F166_1820;}
	{long i; for (i = 720; i < 730; i++) R1568[i] = (char *(*)()) F166_1820;}
	R1568[730] = (char *(*)()) F896_7226;
	{long i; for (i = 731; i < 738; i++) R1568[i] = (char *(*)()) F166_1820;}
	R1568[893] = (char *(*)()) F1059_9853;
	R1568[894] = (char *(*)()) F166_1820;
	R1568[1636] = (char *(*)()) F166_1820;
	R1568[1644] = (char *(*)()) F166_1820;
}


#ifdef __cplusplus
}
#endif
