#include "epoly1.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R11[1869])();
void R11_init () {
	{long i; for (i = 0; i < 2; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 5; i < 9; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 10; i < 14; i++) R11[i] = (char *(*)()) F1_8;}
	R11[16] = (char *(*)()) F1_8;
	{long i; for (i = 18; i < 20; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 28; i < 38; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 40; i < 43; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 55; i < 58; i++) R11[i] = (char *(*)()) F1_8;}
	R11[69] = (char *(*)()) F1_8;
	{long i; for (i = 76; i < 79; i++) R11[i] = (char *(*)()) F1_8;}
	R11[83] = (char *(*)()) F1_8;
	R11[102] = (char *(*)()) F1_8;
	R11[105] = (char *(*)()) F1_8;
	{long i; for (i = 108; i < 110; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 120; i < 126; i++) R11[i] = (char *(*)()) F1_8;}
	R11[151] = (char *(*)()) F1_8;
	{long i; for (i = 153; i < 155; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 157; i < 160; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 161; i < 166; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 173; i < 175; i++) R11[i] = (char *(*)()) F1_8;}
	R11[176] = (char *(*)()) F1_8;
	R11[178] = (char *(*)()) F1_8;
	R11[180] = (char *(*)()) F1_8;
	R11[186] = (char *(*)()) F189_2264;
	{long i; for (i = 187; i < 189; i++) R11[i] = (char *(*)()) F1_8;}
	R11[194] = (char *(*)()) F1_8;
	{long i; for (i = 196; i < 198; i++) R11[i] = (char *(*)()) F1_8;}
	R11[199] = (char *(*)()) F1_8;
	{long i; for (i = 204; i < 206; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 207; i < 209; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 227; i < 231; i++) R11[i] = (char *(*)()) F1_8;}
	R11[234] = (char *(*)()) F1_8;
	{long i; for (i = 236; i < 239; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 240; i < 242; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 244; i < 246; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 247; i < 250; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 251; i < 255; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 256; i < 258; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 259; i < 262; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 263; i < 269; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 274; i < 276; i++) R11[i] = (char *(*)()) F1_8;}
	R11[277] = (char *(*)()) F1_8;
	{long i; for (i = 284; i < 288; i++) R11[i] = (char *(*)()) F1_8;}
	R11[289] = (char *(*)()) F1_8;
	R11[290] = (char *(*)()) F295_4444;
	R11[293] = (char *(*)()) F1_8;
	R11[314] = (char *(*)()) F319_4840;
	R11[315] = (char *(*)()) F320_4889;
	R11[317] = (char *(*)()) F1_8;
	R11[320] = (char *(*)()) F1_8;
	{long i; for (i = 324; i < 327; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 347; i < 353; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 354; i < 359; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 361; i < 363; i++) R11[i] = (char *(*)()) F1_8;}
	R11[375] = (char *(*)()) F1_8;
	R11[378] = (char *(*)()) F1_8;
	{long i; for (i = 422; i < 427; i++) R11[i] = (char *(*)()) F1_8;}
	R11[619] = (char *(*)()) F1_8;
	R11[709] = (char *(*)()) F714_5911;
	R11[710] = (char *(*)()) F715_5952;
	R11[711] = (char *(*)()) F716_5952;
	R11[712] = (char *(*)()) F717_5952;
	R11[713] = (char *(*)()) F718_5952;
	R11[714] = (char *(*)()) F719_5952;
	R11[715] = (char *(*)()) F720_5952;
	R11[716] = (char *(*)()) F721_5952;
	R11[717] = (char *(*)()) F722_5952;
	R11[718] = (char *(*)()) F723_5952;
	R11[719] = (char *(*)()) F724_5952;
	R11[720] = (char *(*)()) F725_5952;
	R11[721] = (char *(*)()) F726_5952;
	R11[722] = (char *(*)()) F715_5952;
	R11[723] = (char *(*)()) F716_5952;
	R11[724] = (char *(*)()) F717_5952;
	R11[725] = (char *(*)()) F719_5952;
	R11[726] = (char *(*)()) F721_5952;
	R11[727] = (char *(*)()) F720_5952;
	R11[728] = (char *(*)()) F723_5952;
	{long i; for (i = 782; i < 794; i++) R11[i] = (char *(*)()) F1_8;}
	R11[857] = (char *(*)()) F862_6418;
	R11[858] = (char *(*)()) F863_6418;
	R11[859] = (char *(*)()) F864_6418;
	R11[860] = (char *(*)()) F865_6418;
	R11[861] = (char *(*)()) F866_6418;
	R11[864] = (char *(*)()) F862_6418;
	{long i; for (i = 866; i < 869; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 871; i < 880; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 881; i < 899; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 901; i < 906; i++) R11[i] = (char *(*)()) F1_8;}
	R11[907] = (char *(*)()) F912_7508;
	R11[908] = (char *(*)()) F913_7566;
	R11[909] = (char *(*)()) F914_7603;
	R11[910] = (char *(*)()) F915_7603;
	R11[911] = (char *(*)()) F916_7603;
	R11[912] = (char *(*)()) F917_7603;
	R11[913] = (char *(*)()) F918_7603;
	R11[914] = (char *(*)()) F919_7603;
	R11[915] = (char *(*)()) F920_7603;
	R11[916] = (char *(*)()) F921_7603;
	R11[917] = (char *(*)()) F922_7603;
	R11[918] = (char *(*)()) F923_7603;
	R11[919] = (char *(*)()) F924_7603;
	R11[920] = (char *(*)()) F925_7603;
	R11[921] = (char *(*)()) F926_7603;
	R11[922] = (char *(*)()) F927_7603;
	R11[923] = (char *(*)()) F928_7603;
	R11[924] = (char *(*)()) F929_7603;
	R11[925] = (char *(*)()) F930_7603;
	R11[926] = (char *(*)()) F931_7603;
	R11[927] = (char *(*)()) F932_7603;
	R11[928] = (char *(*)()) F933_7603;
	R11[929] = (char *(*)()) F934_7603;
	R11[930] = (char *(*)()) F935_7603;
	R11[931] = (char *(*)()) F936_7603;
	R11[932] = (char *(*)()) F937_7603;
	R11[933] = (char *(*)()) F938_7603;
	R11[934] = (char *(*)()) F939_7603;
	R11[935] = (char *(*)()) F940_7603;
	R11[936] = (char *(*)()) F941_7603;
	R11[937] = (char *(*)()) F942_7603;
	R11[938] = (char *(*)()) F943_7603;
	R11[939] = (char *(*)()) F944_7603;
	R11[940] = (char *(*)()) F945_7646;
	{long i; for (i = 942; i < 944; i++) R11[i] = (char *(*)()) F946_7764;}
	{long i; for (i = 945; i < 947; i++) R11[i] = (char *(*)()) F949_7862;}
	{long i; for (i = 948; i < 950; i++) R11[i] = (char *(*)()) F952_7961;}
	{long i; for (i = 951; i < 953; i++) R11[i] = (char *(*)()) F955_8060;}
	{long i; for (i = 954; i < 956; i++) R11[i] = (char *(*)()) F958_8159;}
	{long i; for (i = 957; i < 959; i++) R11[i] = (char *(*)()) F961_8253;}
	{long i; for (i = 960; i < 962; i++) R11[i] = (char *(*)()) F964_8347;}
	{long i; for (i = 963; i < 965; i++) R11[i] = (char *(*)()) F967_8442;}
	{long i; for (i = 966; i < 968; i++) R11[i] = (char *(*)()) F970_8541;}
	{long i; for (i = 969; i < 971; i++) R11[i] = (char *(*)()) F973_8607;}
	{long i; for (i = 972; i < 974; i++) R11[i] = (char *(*)()) F976_8668;}
	{long i; for (i = 975; i < 977; i++) R11[i] = (char *(*)()) F979_8708;}
	{long i; for (i = 978; i < 980; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 985; i < 1017; i++) R11[i] = (char *(*)()) F989_8814;}
	R11[1018] = (char *(*)()) F1022_8851;
	R11[1021] = (char *(*)()) F1025_8889;
	{long i; for (i = 1026; i < 1028; i++) R11[i] = (char *(*)()) F1030_9050;}
	{long i; for (i = 1029; i < 1031; i++) R11[i] = (char *(*)()) F1033_9218;}
	{long i; for (i = 1036; i < 1045; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1052] = (char *(*)()) F1_8;
	{long i; for (i = 1054; i < 1060; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1061] = (char *(*)()) F1_8;
	R11[1063] = (char *(*)()) F1_8;
	{long i; for (i = 1068; i < 1071; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1073; i < 1076; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1077; i < 1090; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1100; i < 1102; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1108; i < 1110; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1114] = (char *(*)()) F1_8;
	{long i; for (i = 1120; i < 1122; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1151; i < 1153; i++) R11[i] = (char *(*)()) F1127_11147;}
	R11[1153] = (char *(*)()) F1128_11147;
	R11[1154] = (char *(*)()) F1130_11147;
	R11[1155] = (char *(*)()) F1132_11147;
	{long i; for (i = 1156; i < 1158; i++) R11[i] = (char *(*)()) F1127_11147;}
	R11[1158] = (char *(*)()) F1128_11147;
	R11[1179] = (char *(*)()) F1127_11147;
	R11[1180] = (char *(*)()) F1128_11147;
	R11[1197] = (char *(*)()) F1127_11147;
	R11[1198] = (char *(*)()) F1128_11147;
	R11[1199] = (char *(*)()) F1127_11147;
	R11[1200] = (char *(*)()) F1129_11147;
	R11[1201] = (char *(*)()) F1127_11147;
	R11[1202] = (char *(*)()) F1131_11147;
	R11[1203] = (char *(*)()) F1132_11147;
	R11[1204] = (char *(*)()) F1128_11147;
	{long i; for (i = 1208; i < 1210; i++) R11[i] = (char *(*)()) F1127_11147;}
	R11[1210] = (char *(*)()) F1128_11147;
	R11[1211] = (char *(*)()) F1130_11147;
	R11[1217] = (char *(*)()) F1222_11303;
	R11[1221] = (char *(*)()) F1226_11324;
	R11[1224] = (char *(*)()) F1_8;
	R11[1226] = (char *(*)()) F1231_11425;
	R11[1227] = (char *(*)()) F1232_11445;
	{long i; for (i = 1229; i < 1232; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1273] = (char *(*)()) F1278_11576;
	R11[1274] = (char *(*)()) F1279_11576;
	R11[1275] = (char *(*)()) F1280_11576;
	R11[1276] = (char *(*)()) F1281_11576;
	R11[1277] = (char *(*)()) F1282_11576;
	R11[1278] = (char *(*)()) F1283_11576;
	R11[1279] = (char *(*)()) F1284_11576;
	R11[1280] = (char *(*)()) F1285_11576;
	R11[1307] = (char *(*)()) F1312_11740;
	R11[1314] = (char *(*)()) F1319_11819;
	R11[1315] = (char *(*)()) F1320_11819;
	R11[1316] = (char *(*)()) F1321_11819;
	R11[1317] = (char *(*)()) F1322_11856;
	R11[1318] = (char *(*)()) F1323_11856;
	R11[1319] = (char *(*)()) F1324_11856;
	R11[1320] = (char *(*)()) F1322_11856;
	R11[1333] = (char *(*)()) F1334_12031;
	R11[1334] = (char *(*)()) F1335_12031;
	R11[1351] = (char *(*)()) F1340_12105;
	R11[1352] = (char *(*)()) F1341_12105;
	R11[1353] = (char *(*)()) F1342_12105;
	R11[1354] = (char *(*)()) F1343_12105;
	R11[1355] = (char *(*)()) F1344_12105;
	R11[1356] = (char *(*)()) F1345_12105;
	R11[1357] = (char *(*)()) F1346_12105;
	R11[1358] = (char *(*)()) F1347_12105;
	{long i; for (i = 1360; i < 1362; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1364] = (char *(*)()) F1_8;
	R11[1369] = (char *(*)()) F1_8;
	R11[1375] = (char *(*)()) F1_8;
	R11[1381] = (char *(*)()) F1_8;
	{long i; for (i = 1385; i < 1387; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1388; i < 1413; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1414] = (char *(*)()) F1_8;
	R11[1417] = (char *(*)()) F1_8;
	{long i; for (i = 1419; i < 1421; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1422] = (char *(*)()) F1_8;
	R11[1426] = (char *(*)()) F1_8;
	R11[1432] = (char *(*)()) F1_8;
	R11[1436] = (char *(*)()) F1_8;
	R11[1440] = (char *(*)()) F1_8;
	R11[1442] = (char *(*)()) F1_8;
	R11[1447] = (char *(*)()) F1_8;
	{long i; for (i = 1451; i < 1457; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1458] = (char *(*)()) F1_8;
	R11[1460] = (char *(*)()) F1_8;
	R11[1462] = (char *(*)()) F1_8;
	{long i; for (i = 1469; i < 1471; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1473] = (char *(*)()) F1_8;
	R11[1475] = (char *(*)()) F1_8;
	{long i; for (i = 1477; i < 1479; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1484] = (char *(*)()) F1_8;
	R11[1486] = (char *(*)()) F1_8;
	{long i; for (i = 1488; i < 1492; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1501] = (char *(*)()) F1_8;
	R11[1504] = (char *(*)()) F1_8;
	{long i; for (i = 1509; i < 1512; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1519; i < 1522; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1524; i < 1526; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1528] = (char *(*)()) F1_8;
	R11[1541] = (char *(*)()) F1_8;
	{long i; for (i = 1548; i < 1552; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1553] = (char *(*)()) F1_8;
	{long i; for (i = 1555; i < 1557; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1558] = (char *(*)()) F1_8;
	R11[1560] = (char *(*)()) F1_8;
	R11[1564] = (char *(*)()) F1_8;
	R11[1566] = (char *(*)()) F1_8;
	{long i; for (i = 1570; i < 1572; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1574; i < 1576; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1577; i < 1581; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1582] = (char *(*)()) F1_8;
	R11[1586] = (char *(*)()) F1_8;
	{long i; for (i = 1590; i < 1592; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1595; i < 1597; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1598] = (char *(*)()) F1_8;
	R11[1600] = (char *(*)()) F1_8;
	R11[1602] = (char *(*)()) F1_8;
	R11[1604] = (char *(*)()) F1_8;
	{long i; for (i = 1609; i < 1613; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1623] = (char *(*)()) F1_8;
	R11[1625] = (char *(*)()) F1_8;
	{long i; for (i = 1627; i < 1629; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1630] = (char *(*)()) F1_8;
	R11[1632] = (char *(*)()) F1_8;
	{long i; for (i = 1634; i < 1636; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1642; i < 1644; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1646; i < 1649; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1650; i < 1652; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1653] = (char *(*)()) F1_8;
	{long i; for (i = 1655; i < 1657; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1658; i < 1663; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1664; i < 1669; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1670; i < 1674; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1675] = (char *(*)()) F1_8;
	R11[1677] = (char *(*)()) F1_8;
	{long i; for (i = 1680; i < 1682; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1683] = (char *(*)()) F1_8;
	{long i; for (i = 1685; i < 1687; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1688; i < 1693; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1694; i < 1697; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1698; i < 1701; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1702; i < 1706; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1706] = (char *(*)()) F1711_15857;
	R11[1707] = (char *(*)()) F1_8;
	R11[1708] = (char *(*)()) F1713_15866;
	R11[1709] = (char *(*)()) F1_8;
	{long i; for (i = 1711; i < 1713; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1714; i < 1719; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1720; i < 1730; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1731] = (char *(*)()) F1_8;
	{long i; for (i = 1733; i < 1735; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1736; i < 1738; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1741] = (char *(*)()) F1_8;
	{long i; for (i = 1743; i < 1746; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1747] = (char *(*)()) F1752_16177;
	{long i; for (i = 1750; i < 1752; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1755; i < 1757; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1758; i < 1762; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1763] = (char *(*)()) F1_8;
	{long i; for (i = 1765; i < 1767; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1767] = (char *(*)()) F1772_17706;
	{long i; for (i = 1783; i < 1785; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1785] = (char *(*)()) F1790_18014;
	R11[1786] = (char *(*)()) F1_8;
	R11[1797] = (char *(*)()) F1_8;
	R11[1805] = (char *(*)()) F1_8;
	R11[1807] = (char *(*)()) F1_8;
	{long i; for (i = 1809; i < 1811; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1818; i < 1820; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1822; i < 1827; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1828] = (char *(*)()) F1_8;
	{long i; for (i = 1830; i < 1833; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1834; i < 1836; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1838; i < 1840; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1841] = (char *(*)()) F1_8;
	{long i; for (i = 1843; i < 1852; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1854; i < 1858; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1859; i < 1863; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1864] = (char *(*)()) F1868_22138;
	R11[1868] = (char *(*)()) F1873_22335;
}

char *(*R18[1869])();
void R18_init () {
	{long i; for (i = 0; i < 2; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 5; i < 9; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 10; i < 14; i++) R18[i] = (char *(*)()) F1_15;}
	R18[16] = (char *(*)()) F1_15;
	{long i; for (i = 18; i < 20; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 28; i < 38; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 40; i < 43; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 55; i < 58; i++) R18[i] = (char *(*)()) F1_15;}
	R18[69] = (char *(*)()) F1_15;
	{long i; for (i = 76; i < 79; i++) R18[i] = (char *(*)()) F1_15;}
	R18[83] = (char *(*)()) F1_15;
	R18[102] = (char *(*)()) F1_15;
	R18[105] = (char *(*)()) F1_15;
	{long i; for (i = 108; i < 110; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 120; i < 126; i++) R18[i] = (char *(*)()) F1_15;}
	R18[151] = (char *(*)()) F1_15;
	{long i; for (i = 153; i < 155; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 157; i < 160; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 161; i < 166; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 173; i < 175; i++) R18[i] = (char *(*)()) F1_15;}
	R18[176] = (char *(*)()) F1_15;
	R18[178] = (char *(*)()) F1_15;
	R18[180] = (char *(*)()) F1_15;
	{long i; for (i = 186; i < 189; i++) R18[i] = (char *(*)()) F1_15;}
	R18[194] = (char *(*)()) F1_15;
	{long i; for (i = 196; i < 198; i++) R18[i] = (char *(*)()) F1_15;}
	R18[199] = (char *(*)()) F1_15;
	{long i; for (i = 204; i < 206; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 207; i < 209; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 227; i < 231; i++) R18[i] = (char *(*)()) F1_15;}
	R18[234] = (char *(*)()) F1_15;
	{long i; for (i = 236; i < 239; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 240; i < 242; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 244; i < 246; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 247; i < 250; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 251; i < 255; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 256; i < 258; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 259; i < 262; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 263; i < 269; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 274; i < 276; i++) R18[i] = (char *(*)()) F1_15;}
	R18[277] = (char *(*)()) F1_15;
	{long i; for (i = 284; i < 288; i++) R18[i] = (char *(*)()) F1_15;}
	R18[289] = (char *(*)()) F1_15;
	R18[290] = (char *(*)()) F295_4445;
	R18[293] = (char *(*)()) F1_15;
	R18[314] = (char *(*)()) F1_15;
	R18[315] = (char *(*)()) F320_4890;
	R18[317] = (char *(*)()) F1_15;
	R18[320] = (char *(*)()) F1_15;
	{long i; for (i = 324; i < 327; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 347; i < 353; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 354; i < 359; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 361; i < 363; i++) R18[i] = (char *(*)()) F1_15;}
	R18[375] = (char *(*)()) F1_15;
	R18[378] = (char *(*)()) F1_15;
	{long i; for (i = 422; i < 427; i++) R18[i] = (char *(*)()) F1_15;}
	R18[619] = (char *(*)()) F1_15;
	R18[709] = (char *(*)()) F714_5925;
	R18[710] = (char *(*)()) F715_5990;
	R18[711] = (char *(*)()) F716_5990;
	R18[712] = (char *(*)()) F717_5990;
	R18[713] = (char *(*)()) F718_5990;
	R18[714] = (char *(*)()) F719_5990;
	R18[715] = (char *(*)()) F720_5990;
	R18[716] = (char *(*)()) F721_5990;
	R18[717] = (char *(*)()) F722_5990;
	R18[718] = (char *(*)()) F723_5990;
	R18[719] = (char *(*)()) F724_5990;
	R18[720] = (char *(*)()) F725_5990;
	R18[721] = (char *(*)()) F726_5990;
	R18[722] = (char *(*)()) F715_5990;
	R18[723] = (char *(*)()) F716_5990;
	R18[724] = (char *(*)()) F717_5990;
	R18[725] = (char *(*)()) F719_5990;
	R18[726] = (char *(*)()) F721_5990;
	R18[727] = (char *(*)()) F720_5990;
	R18[728] = (char *(*)()) F723_5990;
	{long i; for (i = 782; i < 794; i++) R18[i] = (char *(*)()) F1_15;}
	R18[857] = (char *(*)()) F862_6452;
	R18[858] = (char *(*)()) F863_6452;
	R18[859] = (char *(*)()) F864_6452;
	R18[860] = (char *(*)()) F865_6452;
	R18[861] = (char *(*)()) F866_6452;
	R18[864] = (char *(*)()) F862_6452;
	{long i; for (i = 866; i < 869; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 871; i < 880; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 881; i < 899; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 901; i < 906; i++) R18[i] = (char *(*)()) F1_15;}
	R18[907] = (char *(*)()) F912_7516;
	R18[908] = (char *(*)()) F913_7569;
	{long i; for (i = 909; i < 941; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 942; i < 944; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 945; i < 947; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 948; i < 950; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 951; i < 953; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 954; i < 956; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 957; i < 959; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 960; i < 962; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 963; i < 965; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 966; i < 968; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 969; i < 971; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 972; i < 974; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 975; i < 977; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 978; i < 980; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 985; i < 1017; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1018] = (char *(*)()) F1022_8858;
	R18[1021] = (char *(*)()) F1025_8890;
	R18[1026] = (char *(*)()) F1031_9084;
	R18[1027] = (char *(*)()) F1030_9065;
	R18[1029] = (char *(*)()) F1034_9249;
	R18[1030] = (char *(*)()) F1033_9233;
	{long i; for (i = 1036; i < 1045; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1052] = (char *(*)()) F1_15;
	{long i; for (i = 1054; i < 1060; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1061] = (char *(*)()) F1_15;
	R18[1063] = (char *(*)()) F1_15;
	{long i; for (i = 1068; i < 1071; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1073; i < 1076; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1077; i < 1090; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1100; i < 1102; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1108; i < 1110; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1114] = (char *(*)()) F1_15;
	{long i; for (i = 1120; i < 1122; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1151; i < 1153; i++) R18[i] = (char *(*)()) F1127_11146;}
	R18[1153] = (char *(*)()) F1128_11146;
	R18[1154] = (char *(*)()) F1130_11146;
	R18[1155] = (char *(*)()) F1132_11146;
	{long i; for (i = 1156; i < 1158; i++) R18[i] = (char *(*)()) F1127_11146;}
	R18[1158] = (char *(*)()) F1128_11146;
	R18[1179] = (char *(*)()) F1127_11146;
	R18[1180] = (char *(*)()) F1128_11146;
	R18[1197] = (char *(*)()) F1127_11146;
	R18[1198] = (char *(*)()) F1128_11146;
	R18[1199] = (char *(*)()) F1127_11146;
	R18[1200] = (char *(*)()) F1129_11146;
	R18[1201] = (char *(*)()) F1127_11146;
	R18[1202] = (char *(*)()) F1131_11146;
	R18[1203] = (char *(*)()) F1132_11146;
	R18[1204] = (char *(*)()) F1128_11146;
	{long i; for (i = 1208; i < 1210; i++) R18[i] = (char *(*)()) F1127_11146;}
	R18[1210] = (char *(*)()) F1128_11146;
	R18[1211] = (char *(*)()) F1130_11146;
	R18[1217] = (char *(*)()) F1222_11302;
	R18[1221] = (char *(*)()) F1226_11323;
	R18[1224] = (char *(*)()) F1_15;
	{long i; for (i = 1226; i < 1228; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1229; i < 1232; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1273] = (char *(*)()) F1278_11577;
	R18[1274] = (char *(*)()) F1279_11577;
	R18[1275] = (char *(*)()) F1280_11577;
	R18[1276] = (char *(*)()) F1281_11577;
	R18[1277] = (char *(*)()) F1282_11577;
	R18[1278] = (char *(*)()) F1283_11577;
	R18[1279] = (char *(*)()) F1284_11577;
	R18[1280] = (char *(*)()) F1285_11577;
	R18[1307] = (char *(*)()) F1312_11739;
	R18[1314] = (char *(*)()) F1319_11818;
	R18[1315] = (char *(*)()) F1320_11818;
	R18[1316] = (char *(*)()) F1321_11818;
	R18[1317] = (char *(*)()) F1322_11855;
	R18[1318] = (char *(*)()) F1323_11855;
	R18[1319] = (char *(*)()) F1324_11855;
	R18[1320] = (char *(*)()) F1322_11855;
	R18[1333] = (char *(*)()) F1326_11950;
	R18[1334] = (char *(*)()) F1330_11950;
	R18[1351] = (char *(*)()) F1340_12117;
	R18[1352] = (char *(*)()) F1341_12117;
	R18[1353] = (char *(*)()) F1342_12117;
	R18[1354] = (char *(*)()) F1343_12117;
	R18[1355] = (char *(*)()) F1344_12117;
	R18[1356] = (char *(*)()) F1345_12117;
	R18[1357] = (char *(*)()) F1346_12117;
	R18[1358] = (char *(*)()) F1347_12117;
	{long i; for (i = 1360; i < 1362; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1364] = (char *(*)()) F1_15;
	R18[1369] = (char *(*)()) F1_15;
	R18[1375] = (char *(*)()) F1_15;
	R18[1381] = (char *(*)()) F1_15;
	{long i; for (i = 1385; i < 1387; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1388; i < 1413; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1414] = (char *(*)()) F1_15;
	R18[1417] = (char *(*)()) F1_15;
	{long i; for (i = 1419; i < 1421; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1422] = (char *(*)()) F1_15;
	R18[1426] = (char *(*)()) F1_15;
	R18[1432] = (char *(*)()) F1_15;
	R18[1436] = (char *(*)()) F1_15;
	R18[1440] = (char *(*)()) F1_15;
	R18[1442] = (char *(*)()) F1_15;
	R18[1447] = (char *(*)()) F1_15;
	{long i; for (i = 1451; i < 1457; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1458] = (char *(*)()) F1_15;
	R18[1460] = (char *(*)()) F1_15;
	R18[1462] = (char *(*)()) F1_15;
	{long i; for (i = 1469; i < 1471; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1473] = (char *(*)()) F1_15;
	R18[1475] = (char *(*)()) F1_15;
	{long i; for (i = 1477; i < 1479; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1484] = (char *(*)()) F1_15;
	R18[1486] = (char *(*)()) F1_15;
	{long i; for (i = 1488; i < 1492; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1501] = (char *(*)()) F1_15;
	R18[1504] = (char *(*)()) F1_15;
	{long i; for (i = 1509; i < 1512; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1519; i < 1522; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1524; i < 1526; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1528] = (char *(*)()) F1_15;
	R18[1541] = (char *(*)()) F1_15;
	{long i; for (i = 1548; i < 1552; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1553] = (char *(*)()) F1_15;
	{long i; for (i = 1555; i < 1557; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1558] = (char *(*)()) F1_15;
	R18[1560] = (char *(*)()) F1_15;
	R18[1564] = (char *(*)()) F1_15;
	R18[1566] = (char *(*)()) F1_15;
	{long i; for (i = 1570; i < 1572; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1574; i < 1576; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1577; i < 1581; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1582] = (char *(*)()) F1_15;
	R18[1586] = (char *(*)()) F1_15;
	{long i; for (i = 1590; i < 1592; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1595; i < 1597; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1598] = (char *(*)()) F1_15;
	R18[1600] = (char *(*)()) F1_15;
	R18[1602] = (char *(*)()) F1_15;
	R18[1604] = (char *(*)()) F1_15;
	{long i; for (i = 1609; i < 1613; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1623] = (char *(*)()) F1_15;
	R18[1625] = (char *(*)()) F1_15;
	{long i; for (i = 1627; i < 1629; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1630] = (char *(*)()) F1_15;
	R18[1632] = (char *(*)()) F1_15;
	{long i; for (i = 1634; i < 1636; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1642; i < 1644; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1646; i < 1649; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1650; i < 1652; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1653] = (char *(*)()) F1_15;
	{long i; for (i = 1655; i < 1657; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1658; i < 1663; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1664; i < 1669; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1670; i < 1674; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1675] = (char *(*)()) F1_15;
	R18[1677] = (char *(*)()) F1_15;
	{long i; for (i = 1680; i < 1682; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1683] = (char *(*)()) F1_15;
	{long i; for (i = 1685; i < 1687; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1688; i < 1693; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1694; i < 1697; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1698; i < 1701; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1702; i < 1710; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1711; i < 1713; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1714; i < 1719; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1720; i < 1730; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1731] = (char *(*)()) F1_15;
	{long i; for (i = 1733; i < 1735; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1736; i < 1738; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1741] = (char *(*)()) F1_15;
	{long i; for (i = 1743; i < 1746; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1747] = (char *(*)()) F1_15;
	{long i; for (i = 1750; i < 1752; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1755; i < 1757; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1758; i < 1762; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1763] = (char *(*)()) F1_15;
	{long i; for (i = 1765; i < 1767; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1767] = (char *(*)()) F1772_17704;
	{long i; for (i = 1783; i < 1785; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1785] = (char *(*)()) F1790_18013;
	R18[1786] = (char *(*)()) F1_15;
	R18[1797] = (char *(*)()) F1_15;
	R18[1805] = (char *(*)()) F1_15;
	R18[1807] = (char *(*)()) F1_15;
	{long i; for (i = 1809; i < 1811; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1818; i < 1820; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1822; i < 1827; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1828] = (char *(*)()) F1_15;
	{long i; for (i = 1830; i < 1833; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1834; i < 1836; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1838; i < 1840; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1841] = (char *(*)()) F1_15;
	{long i; for (i = 1843; i < 1852; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1854; i < 1858; i++) R18[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1859; i < 1863; i++) R18[i] = (char *(*)()) F1_15;}
	R18[1864] = (char *(*)()) F1869_22157;
	R18[1868] = (char *(*)()) F1873_22378;
}

char *(*R142[4])();
void R142_init () {
	R142[0] = (char *(*)()) F10_140;
	R142[1] = (char *(*)()) F11_140_142_23;
	R142[2] = (char *(*)()) F12_140_142_23;
	R142[3] = (char *(*)()) F13_140_142_23;
}
static void F11_140_142_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F11_140(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F12_140_142_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F12_140(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F13_140_142_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F13_140(Current, *(EIF_BOOLEAN *)arg1, arg2);
}

char *(*R478[7])();
void R478_init () {
	R478[0] = (char *(*)()) F36_474;
	R478[1] = (char *(*)()) F37_474;
	R478[2] = (char *(*)()) F38_474;
	R478[3] = (char *(*)()) F39_474;
	R478[4] = (char *(*)()) F40_474;
	R478[5] = (char *(*)()) F41_474;
	R478[6] = (char *(*)()) F42_474;
}

char *(*R483[7])();
void R483_init () {
	R483[0] = (char *(*)()) F36_479;
	R483[1] = (char *(*)()) F37_479_483_60;
	R483[2] = (char *(*)()) F38_479_483_60;
	R483[3] = (char *(*)()) F39_479_483_60;
	R483[4] = (char *(*)()) F40_479_483_60;
	R483[5] = (char *(*)()) F41_479_483_60;
	R483[6] = (char *(*)()) F42_479_483_60;
}
static void F37_479_483_60 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F37_479(Current, arg1, *(EIF_INTEGER_32 *)arg2, arg3);
}
static void F38_479_483_60 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F38_479(Current, arg1, *(EIF_NATURAL_64 *)arg2, arg3);
}
static void F39_479_483_60 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F39_479(Current, arg1, *(EIF_NATURAL_32 *)arg2, arg3);
}
static void F40_479_483_60 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F40_479(Current, arg1, *(EIF_BOOLEAN *)arg2, arg3);
}
static void F41_479_483_60 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F41_479(Current, arg1, *(EIF_NATURAL_8 *)arg2, arg3);
}
static void F42_479_483_60 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F42_479(Current, arg1, *(EIF_CHARACTER_8 *)arg2, arg3);
}

char *(*R484[7])();
void R484_init () {
	R484[0] = (char *(*)()) F36_480;
	R484[1] = (char *(*)()) F37_480;
	R484[2] = (char *(*)()) F38_480;
	R484[3] = (char *(*)()) F39_480;
	R484[4] = (char *(*)()) F40_480;
	R484[5] = (char *(*)()) F41_480;
	R484[6] = (char *(*)()) F42_480;
}

char *(*R486[7])();
void R486_init () {
	R486[0] = (char *(*)()) F36_482;
	R486[1] = (char *(*)()) F37_482;
	R486[2] = (char *(*)()) F38_482;
	R486[3] = (char *(*)()) F39_482;
	R486[4] = (char *(*)()) F40_482;
	R486[5] = (char *(*)()) F41_482;
	R486[6] = (char *(*)()) F42_482;
}

static EIF_TYPE_INDEX Y1003_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1003_pgtype1[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y1003_gen_type [2];
EIF_TYPE_INDEX Y1003 [2];
void Y1003_init (void)
{
	egc_routines_types [1003] = Y1003;
	egc_routines_gen_types [1003] = Y1003_gen_type;
	egc_routines_offset [1003] = 72;
	Y1003_gen_type [0] = Y1003_pgtype0;
	Y1003_gen_type [1] = Y1003_pgtype1;
}

char *(*R1009[3])();
void R1009_init () {
	{long i; for (i = 0; i < 2; i++) R1009[i] = (char *(*)()) F79_1024;}
	R1009[2] = (char *(*)()) F80_1024;
}

char *(*R1011[3])();
void R1011_init () {
	{long i; for (i = 0; i < 2; i++) R1011[i] = (char *(*)()) F79_1026;}
	R1011[2] = (char *(*)()) F80_1026;
}

char *(*R1020[3])();
void R1020_init () {
	R1020[0] = (char *(*)()) F81_1030;
	R1020[1] = (char *(*)()) F82_1031;
	R1020[2] = (char *(*)()) F83_1031;
}

char *(*R1096[801])();
void R1096_init () {
	R1096[0] = (char *(*)()) F1073_10135;
	R1096[1] = (char *(*)()) F1074_10143;
	R1096[2] = (char *(*)()) F1075_10148;
	R1096[296] = (char *(*)()) F1368_12344;
	R1096[800] = (char *(*)()) F1873_22350;
}

char *(*R1160[6])();
void R1160_init () {
	R1160[0] = (char *(*)()) F1809_18753;
	R1160[2] = (char *(*)()) F1811_20438;
	{long i; for (i = 4; i < 6; i++) R1160[i] = (char *(*)()) F1813_20566;}
}

char *(*R1217[164])();
void R1217_init () {
	R1217[0] = (char *(*)()) F1608_14375;
	{long i; for (i = 161; i < 164; i++) R1217[i] = (char *(*)()) F1769_17321;}
}

char *(*R1218[164])();
void R1218_init () {
	R1218[0] = (char *(*)()) F1609_14376;
	{long i; for (i = 161; i < 164; i++) R1218[i] = (char *(*)()) F1649_14695;}
}

char *(*R1219[164])();
void R1219_init () {
	R1219[0] = (char *(*)()) F1609_14377;
	{long i; for (i = 161; i < 163; i++) R1219[i] = (char *(*)()) F112_1232;}
	R1219[163] = (char *(*)()) F1772_17632;
}

char *(*R1220[164])();
void R1220_init () {
	R1220[0] = (char *(*)()) F1609_14378;
	{long i; for (i = 161; i < 163; i++) R1220[i] = (char *(*)()) F112_1233;}
	R1220[163] = (char *(*)()) F1772_17633;
}

char *(*R1222[164])();
void R1222_init () {
	R1222[0] = (char *(*)()) F1609_14379;
	{long i; for (i = 161; i < 163; i++) R1222[i] = (char *(*)()) F112_1235;}
	R1222[163] = (char *(*)()) F1772_17638;
}

char *(*R1223[164])();
void R1223_init () {
	R1223[0] = (char *(*)()) F1609_14380;
	{long i; for (i = 161; i < 163; i++) R1223[i] = (char *(*)()) F112_1236;}
	R1223[163] = (char *(*)()) F1772_17639;
}

char *(*R1224[164])();
void R1224_init () {
	R1224[0] = (char *(*)()) F112_1237;
	{long i; for (i = 161; i < 163; i++) R1224[i] = (char *(*)()) F112_1237;}
	R1224[163] = (char *(*)()) F1772_17658;
}

char *(*R1226[2])();
void R1226_init () {
	R1226[0] = (char *(*)()) F113_1239;
	R1226[1] = (char *(*)()) F114_1259;
}

char *(*R1240[2])();
void R1240_init () {
	R1240[0] = (char *(*)()) F113_1253;
	R1240[1] = (char *(*)()) F114_1262;
}

char *(*R1241[2])();
void R1241_init () {
	R1241[0] = (char *(*)()) F113_1254;
	R1241[1] = (char *(*)()) F114_1263;
}

char *(*R1253[2])();
void R1253_init () {
	R1253[0] = (char *(*)()) F329_5045_1253_46;
	R1253[1] = (char *(*)()) F330_5074_1253_46;
}
static EIF_REFERENCE F329_5045_1253_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F329_5045(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F330_5074_1253_46 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F330_5074(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R1254[2])();
void R1254_init () {
	R1254[0] = (char *(*)()) F329_5053;
	R1254[1] = (char *(*)()) F330_5078;
}

char *(*R1255[2])();
void R1255_init () {
	R1255[0] = (char *(*)()) F329_5057_1255_152;
	R1255[1] = (char *(*)()) F330_5080_1255_152;
}
static void F329_5057_1255_152 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F329_5057(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F330_5080_1255_152 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F330_5080(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}

char *(*R1256[2])();
void R1256_init () {
	R1256[0] = (char *(*)()) F329_5066;
	R1256[1] = (char *(*)()) F330_5085;
}

char *(*R1257[2])();
void R1257_init () {
	R1257[0] = (char *(*)()) F329_5068;
	R1257[1] = (char *(*)()) F330_5086;
}

char *(*R1259[2])();
void R1259_init () {
	R1259[0] = (char *(*)()) F329_5070;
	R1259[1] = (char *(*)()) F330_5088;
}

char *(*R1263[2])();
void R1263_init () {
	R1263[0] = (char *(*)()) F329_5046;
	R1263[1] = (char *(*)()) F118_1279;
}

char *(*R1264[2])();
void R1264_init () {
	R1264[0] = (char *(*)()) F329_5047;
	R1264[1] = (char *(*)()) F118_1280;
}

char *(*R1265[2])();
void R1265_init () {
	R1265[0] = (char *(*)()) F329_5048;
	R1265[1] = (char *(*)()) F330_5075;
}

char *(*R1266[2])();
void R1266_init () {
	R1266[0] = (char *(*)()) F329_5049;
	R1266[1] = (char *(*)()) F330_5076;
}

char *(*R1270[2])();
void R1270_init () {
	R1270[0] = (char *(*)()) F118_1286;
	R1270[1] = (char *(*)()) F330_5079;
}

char *(*R1271[2])();
void R1271_init () {
	R1271[0] = (char *(*)()) F329_5054;
	R1271[1] = (char *(*)()) F118_1287;
}

char *(*R1272[2])();
void R1272_init () {
	R1272[0] = (char *(*)()) F329_5059;
	R1272[1] = (char *(*)()) F330_5081;
}

char *(*R1274[2])();
void R1274_init () {
	R1274[0] = (char *(*)()) F329_5061;
	R1274[1] = (char *(*)()) F330_5083;
}

char *(*R1276[2])();
void R1276_init () {
	R1276[0] = (char *(*)()) F329_5064;
	R1276[1] = (char *(*)()) F330_5084;
}

char *(*R1358[4])();
void R1358_init () {
	R1358[0] = (char *(*)()) F127_1386;
	R1358[1] = (char *(*)()) F128_1386_1358_1;
	R1358[2] = (char *(*)()) F129_1386_1358_1;
	R1358[3] = (char *(*)()) F130_1386_1358_1;
}
static EIF_REFERENCE F128_1386_1358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F128_1386(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(950, 0x00).id, 950, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F129_1386_1358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F129_1386(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F130_1386_1358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F130_1386(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(977, 0x00).id, 977, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R1383[298])();
void R1383_init () {
	R1383[0] = (char *(*)()) F1066_10099;
	R1383[290] = (char *(*)()) F1340_12094;
	R1383[291] = (char *(*)()) F1341_12094_1383_5;
	R1383[292] = (char *(*)()) F1342_12094_1383_5;
	R1383[293] = (char *(*)()) F1343_12094_1383_5;
	R1383[294] = (char *(*)()) F1344_12094_1383_5;
	R1383[295] = (char *(*)()) F1345_12094_1383_5;
	R1383[296] = (char *(*)()) F1346_12094_1383_5;
	R1383[297] = (char *(*)()) F1347_12094_1383_5;
}
static EIF_REFERENCE F1341_12094_1383_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1341_12094(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(950, 0x00).id, 950, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1342_12094_1383_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1342_12094(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F1343_12094_1383_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1343_12094(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1344_12094_1383_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1344_12094(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_REFERENCE F1345_12094_1383_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1345_12094(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(983, 0x00).id, 983, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1346_12094_1383_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1346_12094(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(968, 0x00).id, 968, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1347_12094_1383_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1347_12094(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(950, 0x00).id, 950, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y1385_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype8[] = {0xFF01,1034,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype9[] = {0xFF01,1034,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype32[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype33[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype34[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype35[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype36[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype37[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype38[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype39[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype40[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype41[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype42[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype43[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype44[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype45[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype46[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype47[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype48[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1385_pgtype49[] = {0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y1385_gen_type [1226];
EIF_TYPE_INDEX Y1385 [1226];
void Y1385_init (void)
{
	egc_routines_types [1385] = Y1385;
	egc_routines_gen_types [1385] = Y1385_gen_type;
	egc_routines_offset [1385] = 137;
	Y1385_gen_type [0] = Y1385_pgtype0;
	Y1385_gen_type [1] = Y1385_pgtype1;
	Y1385_gen_type [2] = Y1385_pgtype2;
	Y1385_gen_type [3] = Y1385_pgtype3;
	Y1385_gen_type [4] = Y1385_pgtype4;
	Y1385_gen_type [5] = Y1385_pgtype5;
	Y1385_gen_type [6] = Y1385_pgtype6;
	Y1385_gen_type [7] = Y1385_pgtype7;
	Y1385_gen_type [927] = Y1385_pgtype8;
	Y1385_gen_type [928] = Y1385_pgtype9;
	Y1385_gen_type [1105] = Y1385_pgtype10;
	Y1385_gen_type [1106] = Y1385_pgtype11;
	Y1385_gen_type [1107] = Y1385_pgtype12;
	Y1385_gen_type [1108] = Y1385_pgtype13;
	Y1385_gen_type [1109] = Y1385_pgtype14;
	Y1385_gen_type [1110] = Y1385_pgtype15;
	Y1385_gen_type [1111] = Y1385_pgtype16;
	Y1385_gen_type [1112] = Y1385_pgtype17;
	Y1385_gen_type [1148] = Y1385_pgtype18;
	Y1385_gen_type [1149] = Y1385_pgtype19;
	Y1385_gen_type [1150] = Y1385_pgtype20;
	Y1385_gen_type [1151] = Y1385_pgtype21;
	Y1385_gen_type [1152] = Y1385_pgtype22;
	Y1385_gen_type [1153] = Y1385_pgtype23;
	Y1385_gen_type [1154] = Y1385_pgtype24;
	Y1385_gen_type [1155] = Y1385_pgtype25;
	Y1385_gen_type [1202] = Y1385_pgtype26;
	Y1385_gen_type [1203] = Y1385_pgtype27;
	Y1385_gen_type [1204] = Y1385_pgtype28;
	Y1385_gen_type [1205] = Y1385_pgtype29;
	Y1385_gen_type [1206] = Y1385_pgtype30;
	Y1385_gen_type [1207] = Y1385_pgtype31;
	Y1385_gen_type [1208] = Y1385_pgtype32;
	Y1385_gen_type [1209] = Y1385_pgtype33;
	Y1385_gen_type [1210] = Y1385_pgtype34;
	Y1385_gen_type [1211] = Y1385_pgtype35;
	Y1385_gen_type [1212] = Y1385_pgtype36;
	Y1385_gen_type [1213] = Y1385_pgtype37;
	Y1385_gen_type [1214] = Y1385_pgtype38;
	Y1385_gen_type [1215] = Y1385_pgtype39;
	Y1385_gen_type [1216] = Y1385_pgtype40;
	Y1385_gen_type [1217] = Y1385_pgtype41;
	Y1385_gen_type [1218] = Y1385_pgtype42;
	Y1385_gen_type [1219] = Y1385_pgtype43;
	Y1385_gen_type [1220] = Y1385_pgtype44;
	Y1385_gen_type [1221] = Y1385_pgtype45;
	Y1385_gen_type [1222] = Y1385_pgtype46;
	Y1385_gen_type [1223] = Y1385_pgtype47;
	Y1385_gen_type [1224] = Y1385_pgtype48;
	Y1385_gen_type [1225] = Y1385_pgtype49;
	{long i; for (i = 927; i < 929; i++) Y1385[i] = 1034;};
}

char *(*R1389[1464])();
void R1389_init () {
	R1389[0] = (char *(*)()) F289_4403;
	R1389[1119] = (char *(*)()) F146_1417;
	R1389[1167] = (char *(*)()) F1456_13473;
	R1389[1168] = (char *(*)()) F1457_13483;
	R1389[1169] = (char *(*)()) F1458_13498;
	{long i; for (i = 1170; i < 1173; i++) R1389[i] = (char *(*)()) F1459_13514;}
	R1389[1174] = (char *(*)()) F1428_13321;
	R1389[1176] = (char *(*)()) F1464_13553;
	R1389[1178] = (char *(*)()) F1450_13432;
	{long i; for (i = 1185; i < 1187; i++) R1389[i] = (char *(*)()) F1468_13599;}
	R1389[1189] = (char *(*)()) F1468_13599;
	R1389[1191] = (char *(*)()) F1468_13599;
	{long i; for (i = 1193; i < 1195; i++) R1389[i] = (char *(*)()) F1468_13599;}
	R1389[1200] = (char *(*)()) F1488_13628;
	R1389[1202] = (char *(*)()) F1490_13640;
	{long i; for (i = 1204; i < 1206; i++) R1389[i] = (char *(*)()) F1428_13321;}
	R1389[1206] = (char *(*)()) F1495_13663;
	R1389[1207] = (char *(*)()) F1496_13668;
	R1389[1225] = (char *(*)()) F1428_13321;
	R1389[1244] = (char *(*)()) F1533_13861;
	R1389[1257] = (char *(*)()) F1490_13640;
	R1389[1264] = (char *(*)()) F1464_13553;
	R1389[1265] = (char *(*)()) F1488_13628;
	R1389[1266] = (char *(*)()) F1490_13640;
	R1389[1267] = (char *(*)()) F1488_13628;
	R1389[1269] = (char *(*)()) F1450_13432;
	R1389[1271] = (char *(*)()) F1450_13432;
	R1389[1274] = (char *(*)()) F1428_13321;
	R1389[1276] = (char *(*)()) F1565_14010;
	R1389[1280] = (char *(*)()) F1450_13432;
	R1389[1282] = (char *(*)()) F1450_13432;
	{long i; for (i = 1293; i < 1295; i++) R1389[i] = (char *(*)()) F1581_14110;}
	R1389[1295] = (char *(*)()) F146_1417;
	R1389[1296] = (char *(*)()) F1585_14135;
	{long i; for (i = 1311; i < 1313; i++) R1389[i] = (char *(*)()) F1599_14277;}
	R1389[1380] = (char *(*)()) F1669_15168;
	{long i; for (i = 1401; i < 1403; i++) R1389[i] = (char *(*)()) F1428_13321;}
	{long i; for (i = 1410; i < 1413; i++) R1389[i] = (char *(*)()) F1428_13321;}
	{long i; for (i = 1414; i < 1417; i++) R1389[i] = (char *(*)()) F1428_13321;}
	R1389[1420] = (char *(*)()) F1428_13321;
	R1389[1423] = (char *(*)()) F1712_15861;
	R1389[1425] = (char *(*)()) F1428_13321;
	{long i; for (i = 1427; i < 1429; i++) R1389[i] = (char *(*)()) F1428_13321;}
	{long i; for (i = 1430; i < 1435; i++) R1389[i] = (char *(*)()) F1428_13321;}
	R1389[1461] = (char *(*)()) F1450_13432;
	R1389[1463] = (char *(*)()) F1752_16160;
}

char *(*R1390[1464])();
void R1390_init () {
	R1390[0] = (char *(*)()) F288_4376;
	R1390[1119] = (char *(*)()) F1408_13145;
	{long i; for (i = 1167; i < 1173; i++) R1390[i] = (char *(*)()) F1455_13451;}
	R1390[1174] = (char *(*)()) F1455_13451;
	R1390[1176] = (char *(*)()) F1455_13451;
	R1390[1178] = (char *(*)()) F1455_13451;
	{long i; for (i = 1185; i < 1187; i++) R1390[i] = (char *(*)()) F1455_13451;}
	R1390[1189] = (char *(*)()) F1455_13451;
	R1390[1191] = (char *(*)()) F1455_13451;
	{long i; for (i = 1193; i < 1195; i++) R1390[i] = (char *(*)()) F1455_13451;}
	R1390[1200] = (char *(*)()) F1455_13451;
	R1390[1202] = (char *(*)()) F1455_13451;
	{long i; for (i = 1204; i < 1208; i++) R1390[i] = (char *(*)()) F1455_13451;}
	R1390[1225] = (char *(*)()) F1455_13451;
	R1390[1244] = (char *(*)()) F1455_13451;
	R1390[1257] = (char *(*)()) F1455_13451;
	{long i; for (i = 1264; i < 1268; i++) R1390[i] = (char *(*)()) F1455_13451;}
	R1390[1269] = (char *(*)()) F1455_13451;
	R1390[1271] = (char *(*)()) F1455_13451;
	R1390[1274] = (char *(*)()) F1455_13451;
	R1390[1276] = (char *(*)()) F1455_13451;
	R1390[1280] = (char *(*)()) F1455_13451;
	R1390[1282] = (char *(*)()) F1455_13451;
	{long i; for (i = 1293; i < 1295; i++) R1390[i] = (char *(*)()) F1455_13451;}
	{long i; for (i = 1295; i < 1297; i++) R1390[i] = (char *(*)()) F1581_14104;}
	{long i; for (i = 1311; i < 1313; i++) R1390[i] = (char *(*)()) F1455_13451;}
	R1390[1380] = (char *(*)()) F1455_13451;
	{long i; for (i = 1401; i < 1403; i++) R1390[i] = (char *(*)()) F1455_13451;}
	{long i; for (i = 1410; i < 1413; i++) R1390[i] = (char *(*)()) F1455_13451;}
	{long i; for (i = 1414; i < 1417; i++) R1390[i] = (char *(*)()) F1455_13451;}
	R1390[1420] = (char *(*)()) F1455_13451;
	R1390[1423] = (char *(*)()) F1455_13451;
	R1390[1425] = (char *(*)()) F1455_13451;
	{long i; for (i = 1427; i < 1429; i++) R1390[i] = (char *(*)()) F1455_13451;}
	{long i; for (i = 1430; i < 1435; i++) R1390[i] = (char *(*)()) F1455_13451;}
	R1390[1461] = (char *(*)()) F1750_16129;
	R1390[1463] = (char *(*)()) F1455_13451;
}


#ifdef __cplusplus
}
#endif
