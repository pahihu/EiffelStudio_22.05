#include "epoly19.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4739[790])();
void R4739_init () {
	R4739[0] = (char *(*)()) F427_5367;
	R4739[1] = (char *(*)()) F428_5367;
	R4739[2] = (char *(*)()) F429_5367;
	R4739[3] = (char *(*)()) F430_5367;
	R4739[4] = (char *(*)()) F431_5367;
	R4739[197] = (char *(*)()) F623_5498;
	{long i; for (i = 729; i < 731; i++) R4739[i] = (char *(*)()) F1142_11161;}
	R4739[731] = (char *(*)()) F1143_11161;
	R4739[732] = (char *(*)()) F1145_11161;
	R4739[733] = (char *(*)()) F1147_11161;
	{long i; for (i = 734; i < 736; i++) R4739[i] = (char *(*)()) F1142_11161;}
	R4739[736] = (char *(*)()) F1143_11161;
	R4739[757] = (char *(*)()) F1142_11161;
	R4739[758] = (char *(*)()) F1143_11161;
	R4739[775] = (char *(*)()) F1142_11161;
	R4739[776] = (char *(*)()) F1143_11161;
	R4739[777] = (char *(*)()) F1142_11161;
	R4739[778] = (char *(*)()) F1144_11161;
	R4739[779] = (char *(*)()) F1142_11161;
	R4739[780] = (char *(*)()) F1146_11161;
	R4739[781] = (char *(*)()) F1147_11161;
	R4739[782] = (char *(*)()) F1143_11161;
	{long i; for (i = 786; i < 788; i++) R4739[i] = (char *(*)()) F1142_11161;}
	R4739[788] = (char *(*)()) F1143_11161;
	R4739[789] = (char *(*)()) F1145_11161;
}

char *(*R4750[5])();
void R4750_init () {
	R4750[0] = (char *(*)()) F427_5364;
	R4750[1] = (char *(*)()) F428_5364;
	R4750[2] = (char *(*)()) F429_5364;
	R4750[3] = (char *(*)()) F430_5364_4750_1;
	R4750[4] = (char *(*)()) F431_5364_4750_1;
}
static EIF_REFERENCE F430_5364_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F430_5364(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(950, 0x00).id, 950, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F431_5364_4750_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F431_5364(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(950, 0x00).id, 950, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4752[713])();
void R4752_init () {
	R4752[0] = (char *(*)()) F352_5238;
	R4752[1] = (char *(*)()) F353_5238_4752_3;
	R4752[2] = (char *(*)()) F354_5238_4752_3;
	R4752[3] = (char *(*)()) F355_5238_4752_3;
	R4752[4] = (char *(*)()) F356_5238_4752_3;
	R4752[5] = (char *(*)()) F357_5238_4752_3;
	R4752[7] = (char *(*)()) F359_5240;
	R4752[8] = (char *(*)()) F360_5242;
	R4752[9] = (char *(*)()) F361_5243;
	R4752[10] = (char *(*)()) F362_5244;
	R4752[11] = (char *(*)()) F363_5245;
	R4752[14] = (char *(*)()) F364_5249;
	R4752[15] = (char *(*)()) F365_5249_4752_3;
	R4752[705] = (char *(*)()) F1057_9541;
	R4752[712] = (char *(*)()) F1064_10096;
}
static EIF_BOOLEAN F353_5238_4752_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F353_5238(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F354_5238_4752_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F354_5238(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_NATURAL_64 *)arg2);
}
static EIF_BOOLEAN F355_5238_4752_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F355_5238(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static EIF_BOOLEAN F356_5238_4752_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F356_5238(Current, *(EIF_BOOLEAN *)arg1, *(EIF_BOOLEAN *)arg2);
}
static EIF_BOOLEAN F357_5238_4752_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F357_5238(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_NATURAL_8 *)arg2);
}
static EIF_BOOLEAN F365_5249_4752_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F365_5249(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R4755[2])();
void R4755_init () {
	R4755[0] = (char *(*)()) F364_5246;
	R4755[1] = (char *(*)()) F365_5246_4755_3;
}
static EIF_BOOLEAN F365_5246_4755_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F365_5246(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R4759[502])();
void R4759_init () {
	R4759[0] = (char *(*)()) F862_6410;
	R4759[1] = (char *(*)()) F863_6410;
	R4759[2] = (char *(*)()) F864_6410;
	R4759[3] = (char *(*)()) F865_6410;
	R4759[4] = (char *(*)()) F866_6410;
	R4759[7] = (char *(*)()) F862_6410;
	{long i; for (i = 416; i < 418; i++) R4759[i] = (char *(*)()) F1266_11526;}
	R4759[418] = (char *(*)()) F1267_11526;
	R4759[419] = (char *(*)()) F1269_11526;
	R4759[420] = (char *(*)()) F1271_11526;
	{long i; for (i = 421; i < 423; i++) R4759[i] = (char *(*)()) F1266_11526;}
	R4759[423] = (char *(*)()) F1267_11526;
	R4759[450] = (char *(*)()) F1266_11526;
	R4759[460] = (char *(*)()) F1266_11526;
	R4759[461] = (char *(*)()) F1267_11526;
	R4759[462] = (char *(*)()) F1269_11526;
	R4759[463] = (char *(*)()) F1266_11526;
	R4759[476] = (char *(*)()) F1266_11526;
	R4759[477] = (char *(*)()) F1267_11526;
	R4759[494] = (char *(*)()) F1266_11526;
	R4759[495] = (char *(*)()) F1267_11526;
	R4759[496] = (char *(*)()) F1266_11526;
	R4759[497] = (char *(*)()) F1268_11526;
	R4759[498] = (char *(*)()) F1266_11526;
	R4759[499] = (char *(*)()) F1270_11526;
	R4759[500] = (char *(*)()) F1271_11526;
	R4759[501] = (char *(*)()) F1267_11526;
}

static EIF_TYPE_INDEX Y4760_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype12[] = {0xFF01,1030,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype13[] = {977,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype14[] = {0xFF01,1034,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype15[] = {0xFF01,1034,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype88[] = {977,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype89[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype256[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype260[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype261[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype264[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype265[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype274[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype275[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype319[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype320[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype321[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype332[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype333[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype334[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype339[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype340[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype343[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype346[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype358[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype362[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype363[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype364[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype365[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype366[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype367[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype368[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype369[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype370[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype371[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype372[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype373[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype374[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype375[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype376[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype377[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype378[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype379[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype380[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype381[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype382[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype383[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype384[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype385[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype386[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype387[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype438[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype446[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype447[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype448[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype449[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype450[] = {977,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype451[] = {977,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype452[] = {977,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype453[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype454[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype455[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype456[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype457[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype458[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype459[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype460[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype461[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype462[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype463[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype464[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype465[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype466[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype467[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype468[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype469[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype470[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype471[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype472[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype473[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype474[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype475[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype476[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype477[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype478[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype479[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype480[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype481[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype482[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype483[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype484[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype485[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype486[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype487[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype488[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype489[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype490[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype491[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype492[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype493[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype494[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype495[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype496[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype497[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype498[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype499[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype500[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype501[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype502[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype503[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype504[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype505[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype506[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype507[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype508[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype509[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype510[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype511[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype512[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype513[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype514[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype515[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype516[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype517[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype518[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype519[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype520[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype521[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype522[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype523[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype524[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype525[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype526[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype527[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype528[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype529[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype530[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype531[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype532[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype533[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype534[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype535[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype536[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype537[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype538[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype539[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype540[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype541[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype542[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype543[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype544[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype545[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype546[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype547[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype548[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype549[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype550[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype551[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype552[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype553[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype554[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype555[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype556[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype557[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype558[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype559[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype560[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype561[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype562[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype563[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype564[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype565[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype566[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype567[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype568[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype569[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype570[] = {0xFF01,14,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype571[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype572[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype573[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype574[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype575[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype576[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype577[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype578[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype579[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype580[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype581[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype582[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype583[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype584[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype585[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype586[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype587[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype588[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype589[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype590[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype591[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype592[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype593[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype594[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype595[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype596[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype597[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype598[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype599[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype600[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype601[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype602[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype603[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype604[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype605[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype606[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype607[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype608[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype609[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype610[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype611[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype612[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype613[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype614[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype615[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype616[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype617[] = {980,0xFFFF};
static EIF_TYPE_INDEX Y4760_pgtype618[] = {980,0xFFFF};
EIF_TYPE_INDEX *Y4760_gen_type [1507];
EIF_TYPE_INDEX Y4760 [1507];
void Y4760_init (void)
{
	egc_routines_types [4760] = Y4760;
	egc_routines_gen_types [4760] = Y4760_gen_type;
	egc_routines_offset [4760] = 367;
	Y4760_gen_type [0] = Y4760_pgtype0;
	Y4760_gen_type [1] = Y4760_pgtype1;
	Y4760_gen_type [2] = Y4760_pgtype2;
	Y4760_gen_type [3] = Y4760_pgtype3;
	Y4760_gen_type [4] = Y4760_pgtype4;
	Y4760_gen_type [5] = Y4760_pgtype5;
	Y4760_gen_type [6] = Y4760_pgtype6;
	Y4760_gen_type [7] = Y4760_pgtype7;
	Y4760_gen_type [8] = Y4760_pgtype8;
	Y4760_gen_type [9] = Y4760_pgtype9;
	Y4760_gen_type [10] = Y4760_pgtype10;
	Y4760_gen_type [11] = Y4760_pgtype11;
	Y4760_gen_type [12] = Y4760_pgtype12;
	Y4760_gen_type [13] = Y4760_pgtype13;
	Y4760_gen_type [14] = Y4760_pgtype14;
	Y4760_gen_type [15] = Y4760_pgtype15;
	Y4760_gen_type [16] = Y4760_pgtype16;
	Y4760_gen_type [17] = Y4760_pgtype17;
	Y4760_gen_type [18] = Y4760_pgtype18;
	Y4760_gen_type [19] = Y4760_pgtype19;
	Y4760_gen_type [20] = Y4760_pgtype20;
	Y4760_gen_type [21] = Y4760_pgtype21;
	Y4760_gen_type [22] = Y4760_pgtype22;
	Y4760_gen_type [23] = Y4760_pgtype23;
	Y4760_gen_type [24] = Y4760_pgtype24;
	Y4760_gen_type [25] = Y4760_pgtype25;
	Y4760_gen_type [26] = Y4760_pgtype26;
	Y4760_gen_type [27] = Y4760_pgtype27;
	Y4760_gen_type [28] = Y4760_pgtype28;
	Y4760_gen_type [29] = Y4760_pgtype29;
	Y4760_gen_type [30] = Y4760_pgtype30;
	Y4760_gen_type [31] = Y4760_pgtype31;
	Y4760_gen_type [32] = Y4760_pgtype32;
	Y4760_gen_type [33] = Y4760_pgtype33;
	Y4760_gen_type [34] = Y4760_pgtype34;
	Y4760_gen_type [35] = Y4760_pgtype35;
	Y4760_gen_type [36] = Y4760_pgtype36;
	Y4760_gen_type [37] = Y4760_pgtype37;
	Y4760_gen_type [38] = Y4760_pgtype38;
	Y4760_gen_type [39] = Y4760_pgtype39;
	Y4760_gen_type [40] = Y4760_pgtype40;
	Y4760_gen_type [41] = Y4760_pgtype41;
	Y4760_gen_type [42] = Y4760_pgtype42;
	Y4760_gen_type [43] = Y4760_pgtype43;
	Y4760_gen_type [44] = Y4760_pgtype44;
	Y4760_gen_type [45] = Y4760_pgtype45;
	Y4760_gen_type [46] = Y4760_pgtype46;
	Y4760_gen_type [47] = Y4760_pgtype47;
	Y4760_gen_type [48] = Y4760_pgtype48;
	Y4760_gen_type [49] = Y4760_pgtype49;
	Y4760_gen_type [50] = Y4760_pgtype50;
	Y4760_gen_type [51] = Y4760_pgtype51;
	Y4760_gen_type [52] = Y4760_pgtype52;
	Y4760_gen_type [53] = Y4760_pgtype53;
	Y4760_gen_type [54] = Y4760_pgtype54;
	Y4760_gen_type [55] = Y4760_pgtype55;
	Y4760_gen_type [56] = Y4760_pgtype56;
	Y4760_gen_type [57] = Y4760_pgtype57;
	Y4760_gen_type [58] = Y4760_pgtype58;
	Y4760_gen_type [59] = Y4760_pgtype59;
	Y4760_gen_type [60] = Y4760_pgtype60;
	Y4760_gen_type [61] = Y4760_pgtype61;
	Y4760_gen_type [62] = Y4760_pgtype62;
	Y4760_gen_type [63] = Y4760_pgtype63;
	Y4760_gen_type [64] = Y4760_pgtype64;
	Y4760_gen_type [65] = Y4760_pgtype65;
	Y4760_gen_type [66] = Y4760_pgtype66;
	Y4760_gen_type [67] = Y4760_pgtype67;
	Y4760_gen_type [68] = Y4760_pgtype68;
	Y4760_gen_type [69] = Y4760_pgtype69;
	Y4760_gen_type [70] = Y4760_pgtype70;
	Y4760_gen_type [71] = Y4760_pgtype71;
	Y4760_gen_type [72] = Y4760_pgtype72;
	Y4760_gen_type [73] = Y4760_pgtype73;
	Y4760_gen_type [74] = Y4760_pgtype74;
	Y4760_gen_type [75] = Y4760_pgtype75;
	Y4760_gen_type [76] = Y4760_pgtype76;
	Y4760_gen_type [77] = Y4760_pgtype77;
	Y4760_gen_type [78] = Y4760_pgtype78;
	Y4760_gen_type [79] = Y4760_pgtype79;
	Y4760_gen_type [80] = Y4760_pgtype80;
	Y4760_gen_type [81] = Y4760_pgtype81;
	Y4760_gen_type [82] = Y4760_pgtype82;
	Y4760_gen_type [83] = Y4760_pgtype83;
	Y4760_gen_type [84] = Y4760_pgtype84;
	Y4760_gen_type [85] = Y4760_pgtype85;
	Y4760_gen_type [86] = Y4760_pgtype86;
	Y4760_gen_type [87] = Y4760_pgtype87;
	Y4760_gen_type [88] = Y4760_pgtype88;
	Y4760_gen_type [89] = Y4760_pgtype89;
	Y4760_gen_type [90] = Y4760_pgtype90;
	Y4760_gen_type [91] = Y4760_pgtype91;
	Y4760_gen_type [92] = Y4760_pgtype92;
	Y4760_gen_type [93] = Y4760_pgtype93;
	Y4760_gen_type [94] = Y4760_pgtype94;
	Y4760_gen_type [95] = Y4760_pgtype95;
	Y4760_gen_type [96] = Y4760_pgtype96;
	Y4760_gen_type [97] = Y4760_pgtype97;
	Y4760_gen_type [98] = Y4760_pgtype98;
	Y4760_gen_type [99] = Y4760_pgtype99;
	Y4760_gen_type [100] = Y4760_pgtype100;
	Y4760_gen_type [101] = Y4760_pgtype101;
	Y4760_gen_type [102] = Y4760_pgtype102;
	Y4760_gen_type [103] = Y4760_pgtype103;
	Y4760_gen_type [104] = Y4760_pgtype104;
	Y4760_gen_type [105] = Y4760_pgtype105;
	Y4760_gen_type [106] = Y4760_pgtype106;
	Y4760_gen_type [107] = Y4760_pgtype107;
	Y4760_gen_type [108] = Y4760_pgtype108;
	Y4760_gen_type [109] = Y4760_pgtype109;
	Y4760_gen_type [110] = Y4760_pgtype110;
	Y4760_gen_type [111] = Y4760_pgtype111;
	Y4760_gen_type [112] = Y4760_pgtype112;
	Y4760_gen_type [113] = Y4760_pgtype113;
	Y4760_gen_type [114] = Y4760_pgtype114;
	Y4760_gen_type [115] = Y4760_pgtype115;
	Y4760_gen_type [116] = Y4760_pgtype116;
	Y4760_gen_type [117] = Y4760_pgtype117;
	Y4760_gen_type [118] = Y4760_pgtype118;
	Y4760_gen_type [119] = Y4760_pgtype119;
	Y4760_gen_type [120] = Y4760_pgtype120;
	Y4760_gen_type [121] = Y4760_pgtype121;
	Y4760_gen_type [122] = Y4760_pgtype122;
	Y4760_gen_type [123] = Y4760_pgtype123;
	Y4760_gen_type [124] = Y4760_pgtype124;
	Y4760_gen_type [125] = Y4760_pgtype125;
	Y4760_gen_type [126] = Y4760_pgtype126;
	Y4760_gen_type [127] = Y4760_pgtype127;
	Y4760_gen_type [128] = Y4760_pgtype128;
	Y4760_gen_type [129] = Y4760_pgtype129;
	Y4760_gen_type [130] = Y4760_pgtype130;
	Y4760_gen_type [131] = Y4760_pgtype131;
	Y4760_gen_type [132] = Y4760_pgtype132;
	Y4760_gen_type [133] = Y4760_pgtype133;
	Y4760_gen_type [134] = Y4760_pgtype134;
	Y4760_gen_type [135] = Y4760_pgtype135;
	Y4760_gen_type [136] = Y4760_pgtype136;
	Y4760_gen_type [137] = Y4760_pgtype137;
	Y4760_gen_type [138] = Y4760_pgtype138;
	Y4760_gen_type [139] = Y4760_pgtype139;
	Y4760_gen_type [140] = Y4760_pgtype140;
	Y4760_gen_type [141] = Y4760_pgtype141;
	Y4760_gen_type [142] = Y4760_pgtype142;
	Y4760_gen_type [143] = Y4760_pgtype143;
	Y4760_gen_type [144] = Y4760_pgtype144;
	Y4760_gen_type [145] = Y4760_pgtype145;
	Y4760_gen_type [146] = Y4760_pgtype146;
	Y4760_gen_type [147] = Y4760_pgtype147;
	Y4760_gen_type [148] = Y4760_pgtype148;
	Y4760_gen_type [149] = Y4760_pgtype149;
	Y4760_gen_type [150] = Y4760_pgtype150;
	Y4760_gen_type [151] = Y4760_pgtype151;
	Y4760_gen_type [152] = Y4760_pgtype152;
	Y4760_gen_type [153] = Y4760_pgtype153;
	Y4760_gen_type [154] = Y4760_pgtype154;
	Y4760_gen_type [155] = Y4760_pgtype155;
	Y4760_gen_type [156] = Y4760_pgtype156;
	Y4760_gen_type [157] = Y4760_pgtype157;
	Y4760_gen_type [158] = Y4760_pgtype158;
	Y4760_gen_type [159] = Y4760_pgtype159;
	Y4760_gen_type [160] = Y4760_pgtype160;
	Y4760_gen_type [161] = Y4760_pgtype161;
	Y4760_gen_type [162] = Y4760_pgtype162;
	Y4760_gen_type [163] = Y4760_pgtype163;
	Y4760_gen_type [164] = Y4760_pgtype164;
	Y4760_gen_type [165] = Y4760_pgtype165;
	Y4760_gen_type [166] = Y4760_pgtype166;
	Y4760_gen_type [167] = Y4760_pgtype167;
	Y4760_gen_type [168] = Y4760_pgtype168;
	Y4760_gen_type [169] = Y4760_pgtype169;
	Y4760_gen_type [170] = Y4760_pgtype170;
	Y4760_gen_type [171] = Y4760_pgtype171;
	Y4760_gen_type [172] = Y4760_pgtype172;
	Y4760_gen_type [173] = Y4760_pgtype173;
	Y4760_gen_type [174] = Y4760_pgtype174;
	Y4760_gen_type [175] = Y4760_pgtype175;
	Y4760_gen_type [176] = Y4760_pgtype176;
	Y4760_gen_type [177] = Y4760_pgtype177;
	Y4760_gen_type [178] = Y4760_pgtype178;
	Y4760_gen_type [179] = Y4760_pgtype179;
	Y4760_gen_type [180] = Y4760_pgtype180;
	Y4760_gen_type [181] = Y4760_pgtype181;
	Y4760_gen_type [182] = Y4760_pgtype182;
	Y4760_gen_type [183] = Y4760_pgtype183;
	Y4760_gen_type [184] = Y4760_pgtype184;
	Y4760_gen_type [185] = Y4760_pgtype185;
	Y4760_gen_type [186] = Y4760_pgtype186;
	Y4760_gen_type [187] = Y4760_pgtype187;
	Y4760_gen_type [188] = Y4760_pgtype188;
	Y4760_gen_type [189] = Y4760_pgtype189;
	Y4760_gen_type [190] = Y4760_pgtype190;
	Y4760_gen_type [191] = Y4760_pgtype191;
	Y4760_gen_type [192] = Y4760_pgtype192;
	Y4760_gen_type [193] = Y4760_pgtype193;
	Y4760_gen_type [194] = Y4760_pgtype194;
	Y4760_gen_type [195] = Y4760_pgtype195;
	Y4760_gen_type [196] = Y4760_pgtype196;
	Y4760_gen_type [197] = Y4760_pgtype197;
	Y4760_gen_type [198] = Y4760_pgtype198;
	Y4760_gen_type [199] = Y4760_pgtype199;
	Y4760_gen_type [200] = Y4760_pgtype200;
	Y4760_gen_type [201] = Y4760_pgtype201;
	Y4760_gen_type [202] = Y4760_pgtype202;
	Y4760_gen_type [203] = Y4760_pgtype203;
	Y4760_gen_type [204] = Y4760_pgtype204;
	Y4760_gen_type [205] = Y4760_pgtype205;
	Y4760_gen_type [206] = Y4760_pgtype206;
	Y4760_gen_type [207] = Y4760_pgtype207;
	Y4760_gen_type [208] = Y4760_pgtype208;
	Y4760_gen_type [209] = Y4760_pgtype209;
	Y4760_gen_type [210] = Y4760_pgtype210;
	Y4760_gen_type [211] = Y4760_pgtype211;
	Y4760_gen_type [212] = Y4760_pgtype212;
	Y4760_gen_type [213] = Y4760_pgtype213;
	Y4760_gen_type [214] = Y4760_pgtype214;
	Y4760_gen_type [215] = Y4760_pgtype215;
	Y4760_gen_type [216] = Y4760_pgtype216;
	Y4760_gen_type [217] = Y4760_pgtype217;
	Y4760_gen_type [218] = Y4760_pgtype218;
	Y4760_gen_type [219] = Y4760_pgtype219;
	Y4760_gen_type [220] = Y4760_pgtype220;
	Y4760_gen_type [221] = Y4760_pgtype221;
	Y4760_gen_type [222] = Y4760_pgtype222;
	Y4760_gen_type [223] = Y4760_pgtype223;
	Y4760_gen_type [224] = Y4760_pgtype224;
	Y4760_gen_type [225] = Y4760_pgtype225;
	Y4760_gen_type [226] = Y4760_pgtype226;
	Y4760_gen_type [227] = Y4760_pgtype227;
	Y4760_gen_type [228] = Y4760_pgtype228;
	Y4760_gen_type [229] = Y4760_pgtype229;
	Y4760_gen_type [230] = Y4760_pgtype230;
	Y4760_gen_type [231] = Y4760_pgtype231;
	Y4760_gen_type [232] = Y4760_pgtype232;
	Y4760_gen_type [233] = Y4760_pgtype233;
	Y4760_gen_type [234] = Y4760_pgtype234;
	Y4760_gen_type [235] = Y4760_pgtype235;
	Y4760_gen_type [236] = Y4760_pgtype236;
	Y4760_gen_type [237] = Y4760_pgtype237;
	Y4760_gen_type [238] = Y4760_pgtype238;
	Y4760_gen_type [239] = Y4760_pgtype239;
	Y4760_gen_type [240] = Y4760_pgtype240;
	Y4760_gen_type [241] = Y4760_pgtype241;
	Y4760_gen_type [242] = Y4760_pgtype242;
	Y4760_gen_type [243] = Y4760_pgtype243;
	Y4760_gen_type [244] = Y4760_pgtype244;
	Y4760_gen_type [245] = Y4760_pgtype245;
	Y4760_gen_type [246] = Y4760_pgtype246;
	Y4760_gen_type [247] = Y4760_pgtype247;
	Y4760_gen_type [248] = Y4760_pgtype248;
	Y4760_gen_type [249] = Y4760_pgtype249;
	Y4760_gen_type [250] = Y4760_pgtype250;
	Y4760_gen_type [251] = Y4760_pgtype251;
	Y4760_gen_type [252] = Y4760_pgtype252;
	Y4760_gen_type [253] = Y4760_pgtype253;
	Y4760_gen_type [254] = Y4760_pgtype254;
	Y4760_gen_type [255] = Y4760_pgtype255;
	Y4760_gen_type [256] = Y4760_pgtype256;
	Y4760_gen_type [257] = Y4760_pgtype257;
	Y4760_gen_type [258] = Y4760_pgtype258;
	Y4760_gen_type [259] = Y4760_pgtype259;
	Y4760_gen_type [260] = Y4760_pgtype260;
	Y4760_gen_type [261] = Y4760_pgtype261;
	Y4760_gen_type [262] = Y4760_pgtype262;
	Y4760_gen_type [263] = Y4760_pgtype263;
	Y4760_gen_type [264] = Y4760_pgtype264;
	Y4760_gen_type [265] = Y4760_pgtype265;
	Y4760_gen_type [266] = Y4760_pgtype266;
	Y4760_gen_type [267] = Y4760_pgtype267;
	Y4760_gen_type [268] = Y4760_pgtype268;
	Y4760_gen_type [269] = Y4760_pgtype269;
	Y4760_gen_type [270] = Y4760_pgtype270;
	Y4760_gen_type [271] = Y4760_pgtype271;
	Y4760_gen_type [272] = Y4760_pgtype272;
	Y4760_gen_type [273] = Y4760_pgtype273;
	Y4760_gen_type [274] = Y4760_pgtype274;
	Y4760_gen_type [275] = Y4760_pgtype275;
	Y4760_gen_type [276] = Y4760_pgtype276;
	Y4760_gen_type [277] = Y4760_pgtype277;
	Y4760_gen_type [278] = Y4760_pgtype278;
	Y4760_gen_type [279] = Y4760_pgtype279;
	Y4760_gen_type [280] = Y4760_pgtype280;
	Y4760_gen_type [281] = Y4760_pgtype281;
	Y4760_gen_type [282] = Y4760_pgtype282;
	Y4760_gen_type [283] = Y4760_pgtype283;
	Y4760_gen_type [284] = Y4760_pgtype284;
	Y4760_gen_type [285] = Y4760_pgtype285;
	Y4760_gen_type [286] = Y4760_pgtype286;
	Y4760_gen_type [287] = Y4760_pgtype287;
	Y4760_gen_type [288] = Y4760_pgtype288;
	Y4760_gen_type [289] = Y4760_pgtype289;
	Y4760_gen_type [290] = Y4760_pgtype290;
	Y4760_gen_type [291] = Y4760_pgtype291;
	Y4760_gen_type [292] = Y4760_pgtype292;
	Y4760_gen_type [293] = Y4760_pgtype293;
	Y4760_gen_type [294] = Y4760_pgtype294;
	Y4760_gen_type [295] = Y4760_pgtype295;
	Y4760_gen_type [296] = Y4760_pgtype296;
	Y4760_gen_type [297] = Y4760_pgtype297;
	Y4760_gen_type [298] = Y4760_pgtype298;
	Y4760_gen_type [299] = Y4760_pgtype299;
	Y4760_gen_type [300] = Y4760_pgtype300;
	Y4760_gen_type [301] = Y4760_pgtype301;
	Y4760_gen_type [302] = Y4760_pgtype302;
	Y4760_gen_type [303] = Y4760_pgtype303;
	Y4760_gen_type [304] = Y4760_pgtype304;
	Y4760_gen_type [305] = Y4760_pgtype305;
	Y4760_gen_type [306] = Y4760_pgtype306;
	Y4760_gen_type [307] = Y4760_pgtype307;
	Y4760_gen_type [308] = Y4760_pgtype308;
	Y4760_gen_type [309] = Y4760_pgtype309;
	Y4760_gen_type [310] = Y4760_pgtype310;
	Y4760_gen_type [311] = Y4760_pgtype311;
	Y4760_gen_type [312] = Y4760_pgtype312;
	Y4760_gen_type [313] = Y4760_pgtype313;
	Y4760_gen_type [314] = Y4760_pgtype314;
	Y4760_gen_type [315] = Y4760_pgtype315;
	Y4760_gen_type [316] = Y4760_pgtype316;
	Y4760_gen_type [317] = Y4760_pgtype317;
	Y4760_gen_type [318] = Y4760_pgtype318;
	Y4760_gen_type [319] = Y4760_pgtype319;
	Y4760_gen_type [320] = Y4760_pgtype320;
	Y4760_gen_type [321] = Y4760_pgtype321;
	Y4760_gen_type [322] = Y4760_pgtype322;
	Y4760_gen_type [323] = Y4760_pgtype323;
	Y4760_gen_type [324] = Y4760_pgtype324;
	Y4760_gen_type [325] = Y4760_pgtype325;
	Y4760_gen_type [326] = Y4760_pgtype326;
	Y4760_gen_type [327] = Y4760_pgtype327;
	Y4760_gen_type [328] = Y4760_pgtype328;
	Y4760_gen_type [329] = Y4760_pgtype329;
	Y4760_gen_type [330] = Y4760_pgtype330;
	Y4760_gen_type [331] = Y4760_pgtype331;
	Y4760_gen_type [332] = Y4760_pgtype332;
	Y4760_gen_type [333] = Y4760_pgtype333;
	Y4760_gen_type [334] = Y4760_pgtype334;
	Y4760_gen_type [335] = Y4760_pgtype335;
	Y4760_gen_type [336] = Y4760_pgtype336;
	Y4760_gen_type [337] = Y4760_pgtype337;
	Y4760_gen_type [338] = Y4760_pgtype338;
	Y4760_gen_type [339] = Y4760_pgtype339;
	Y4760_gen_type [340] = Y4760_pgtype340;
	Y4760_gen_type [341] = Y4760_pgtype341;
	Y4760_gen_type [342] = Y4760_pgtype342;
	Y4760_gen_type [343] = Y4760_pgtype343;
	Y4760_gen_type [344] = Y4760_pgtype344;
	Y4760_gen_type [345] = Y4760_pgtype345;
	Y4760_gen_type [346] = Y4760_pgtype346;
	Y4760_gen_type [347] = Y4760_pgtype347;
	Y4760_gen_type [348] = Y4760_pgtype348;
	Y4760_gen_type [349] = Y4760_pgtype349;
	Y4760_gen_type [350] = Y4760_pgtype350;
	Y4760_gen_type [351] = Y4760_pgtype351;
	Y4760_gen_type [352] = Y4760_pgtype352;
	Y4760_gen_type [353] = Y4760_pgtype353;
	Y4760_gen_type [354] = Y4760_pgtype354;
	Y4760_gen_type [355] = Y4760_pgtype355;
	Y4760_gen_type [356] = Y4760_pgtype356;
	Y4760_gen_type [357] = Y4760_pgtype357;
	Y4760_gen_type [358] = Y4760_pgtype358;
	Y4760_gen_type [359] = Y4760_pgtype359;
	Y4760_gen_type [360] = Y4760_pgtype360;
	Y4760_gen_type [361] = Y4760_pgtype361;
	Y4760_gen_type [362] = Y4760_pgtype362;
	Y4760_gen_type [363] = Y4760_pgtype363;
	Y4760_gen_type [364] = Y4760_pgtype364;
	Y4760_gen_type [365] = Y4760_pgtype365;
	Y4760_gen_type [366] = Y4760_pgtype366;
	Y4760_gen_type [367] = Y4760_pgtype367;
	Y4760_gen_type [368] = Y4760_pgtype368;
	Y4760_gen_type [369] = Y4760_pgtype369;
	Y4760_gen_type [370] = Y4760_pgtype370;
	Y4760_gen_type [371] = Y4760_pgtype371;
	Y4760_gen_type [372] = Y4760_pgtype372;
	Y4760_gen_type [373] = Y4760_pgtype373;
	Y4760_gen_type [374] = Y4760_pgtype374;
	Y4760_gen_type [375] = Y4760_pgtype375;
	Y4760_gen_type [376] = Y4760_pgtype376;
	Y4760_gen_type [377] = Y4760_pgtype377;
	Y4760_gen_type [378] = Y4760_pgtype378;
	Y4760_gen_type [379] = Y4760_pgtype379;
	Y4760_gen_type [380] = Y4760_pgtype380;
	Y4760_gen_type [381] = Y4760_pgtype381;
	Y4760_gen_type [382] = Y4760_pgtype382;
	Y4760_gen_type [383] = Y4760_pgtype383;
	Y4760_gen_type [384] = Y4760_pgtype384;
	Y4760_gen_type [385] = Y4760_pgtype385;
	Y4760_gen_type [386] = Y4760_pgtype386;
	Y4760_gen_type [387] = Y4760_pgtype387;
	Y4760_gen_type [388] = Y4760_pgtype388;
	Y4760_gen_type [389] = Y4760_pgtype389;
	Y4760_gen_type [390] = Y4760_pgtype390;
	Y4760_gen_type [391] = Y4760_pgtype391;
	Y4760_gen_type [392] = Y4760_pgtype392;
	Y4760_gen_type [393] = Y4760_pgtype393;
	Y4760_gen_type [394] = Y4760_pgtype394;
	Y4760_gen_type [395] = Y4760_pgtype395;
	Y4760_gen_type [396] = Y4760_pgtype396;
	Y4760_gen_type [397] = Y4760_pgtype397;
	Y4760_gen_type [398] = Y4760_pgtype398;
	Y4760_gen_type [399] = Y4760_pgtype399;
	Y4760_gen_type [400] = Y4760_pgtype400;
	Y4760_gen_type [401] = Y4760_pgtype401;
	Y4760_gen_type [402] = Y4760_pgtype402;
	Y4760_gen_type [403] = Y4760_pgtype403;
	Y4760_gen_type [404] = Y4760_pgtype404;
	Y4760_gen_type [405] = Y4760_pgtype405;
	Y4760_gen_type [406] = Y4760_pgtype406;
	Y4760_gen_type [407] = Y4760_pgtype407;
	Y4760_gen_type [408] = Y4760_pgtype408;
	Y4760_gen_type [409] = Y4760_pgtype409;
	Y4760_gen_type [410] = Y4760_pgtype410;
	Y4760_gen_type [411] = Y4760_pgtype411;
	Y4760_gen_type [412] = Y4760_pgtype412;
	Y4760_gen_type [413] = Y4760_pgtype413;
	Y4760_gen_type [414] = Y4760_pgtype414;
	Y4760_gen_type [415] = Y4760_pgtype415;
	Y4760_gen_type [419] = Y4760_pgtype416;
	Y4760_gen_type [420] = Y4760_pgtype417;
	Y4760_gen_type [421] = Y4760_pgtype418;
	Y4760_gen_type [422] = Y4760_pgtype419;
	Y4760_gen_type [423] = Y4760_pgtype420;
	Y4760_gen_type [424] = Y4760_pgtype421;
	Y4760_gen_type [425] = Y4760_pgtype422;
	Y4760_gen_type [426] = Y4760_pgtype423;
	Y4760_gen_type [427] = Y4760_pgtype424;
	Y4760_gen_type [428] = Y4760_pgtype425;
	Y4760_gen_type [429] = Y4760_pgtype426;
	Y4760_gen_type [430] = Y4760_pgtype427;
	Y4760_gen_type [481] = Y4760_pgtype428;
	Y4760_gen_type [482] = Y4760_pgtype429;
	Y4760_gen_type [483] = Y4760_pgtype430;
	Y4760_gen_type [484] = Y4760_pgtype431;
	Y4760_gen_type [485] = Y4760_pgtype432;
	Y4760_gen_type [486] = Y4760_pgtype433;
	Y4760_gen_type [487] = Y4760_pgtype434;
	Y4760_gen_type [488] = Y4760_pgtype435;
	Y4760_gen_type [489] = Y4760_pgtype436;
	Y4760_gen_type [490] = Y4760_pgtype437;
	Y4760_gen_type [491] = Y4760_pgtype438;
	Y4760_gen_type [492] = Y4760_pgtype439;
	Y4760_gen_type [493] = Y4760_pgtype440;
	Y4760_gen_type [494] = Y4760_pgtype441;
	Y4760_gen_type [495] = Y4760_pgtype442;
	Y4760_gen_type [496] = Y4760_pgtype443;
	Y4760_gen_type [497] = Y4760_pgtype444;
	Y4760_gen_type [498] = Y4760_pgtype445;
	Y4760_gen_type [499] = Y4760_pgtype446;
	Y4760_gen_type [500] = Y4760_pgtype447;
	Y4760_gen_type [501] = Y4760_pgtype448;
	Y4760_gen_type [577] = Y4760_pgtype449;
	Y4760_gen_type [662] = Y4760_pgtype450;
	Y4760_gen_type [663] = Y4760_pgtype451;
	Y4760_gen_type [664] = Y4760_pgtype452;
	Y4760_gen_type [665] = Y4760_pgtype453;
	Y4760_gen_type [666] = Y4760_pgtype454;
	Y4760_gen_type [667] = Y4760_pgtype455;
	Y4760_gen_type [668] = Y4760_pgtype456;
	Y4760_gen_type [724] = Y4760_pgtype457;
	Y4760_gen_type [774] = Y4760_pgtype458;
	Y4760_gen_type [775] = Y4760_pgtype459;
	Y4760_gen_type [776] = Y4760_pgtype460;
	Y4760_gen_type [777] = Y4760_pgtype461;
	Y4760_gen_type [778] = Y4760_pgtype462;
	Y4760_gen_type [779] = Y4760_pgtype463;
	Y4760_gen_type [780] = Y4760_pgtype464;
	Y4760_gen_type [781] = Y4760_pgtype465;
	Y4760_gen_type [782] = Y4760_pgtype466;
	Y4760_gen_type [783] = Y4760_pgtype467;
	Y4760_gen_type [784] = Y4760_pgtype468;
	Y4760_gen_type [785] = Y4760_pgtype469;
	Y4760_gen_type [786] = Y4760_pgtype470;
	Y4760_gen_type [787] = Y4760_pgtype471;
	Y4760_gen_type [788] = Y4760_pgtype472;
	Y4760_gen_type [789] = Y4760_pgtype473;
	Y4760_gen_type [790] = Y4760_pgtype474;
	Y4760_gen_type [791] = Y4760_pgtype475;
	Y4760_gen_type [792] = Y4760_pgtype476;
	Y4760_gen_type [793] = Y4760_pgtype477;
	Y4760_gen_type [794] = Y4760_pgtype478;
	Y4760_gen_type [795] = Y4760_pgtype479;
	Y4760_gen_type [796] = Y4760_pgtype480;
	Y4760_gen_type [797] = Y4760_pgtype481;
	Y4760_gen_type [798] = Y4760_pgtype482;
	Y4760_gen_type [799] = Y4760_pgtype483;
	Y4760_gen_type [800] = Y4760_pgtype484;
	Y4760_gen_type [801] = Y4760_pgtype485;
	Y4760_gen_type [802] = Y4760_pgtype486;
	Y4760_gen_type [803] = Y4760_pgtype487;
	Y4760_gen_type [804] = Y4760_pgtype488;
	Y4760_gen_type [805] = Y4760_pgtype489;
	Y4760_gen_type [806] = Y4760_pgtype490;
	Y4760_gen_type [807] = Y4760_pgtype491;
	Y4760_gen_type [808] = Y4760_pgtype492;
	Y4760_gen_type [809] = Y4760_pgtype493;
	Y4760_gen_type [810] = Y4760_pgtype494;
	Y4760_gen_type [811] = Y4760_pgtype495;
	Y4760_gen_type [812] = Y4760_pgtype496;
	Y4760_gen_type [813] = Y4760_pgtype497;
	Y4760_gen_type [814] = Y4760_pgtype498;
	Y4760_gen_type [815] = Y4760_pgtype499;
	Y4760_gen_type [816] = Y4760_pgtype500;
	Y4760_gen_type [817] = Y4760_pgtype501;
	Y4760_gen_type [818] = Y4760_pgtype502;
	Y4760_gen_type [819] = Y4760_pgtype503;
	Y4760_gen_type [820] = Y4760_pgtype504;
	Y4760_gen_type [821] = Y4760_pgtype505;
	Y4760_gen_type [822] = Y4760_pgtype506;
	Y4760_gen_type [823] = Y4760_pgtype507;
	Y4760_gen_type [824] = Y4760_pgtype508;
	Y4760_gen_type [825] = Y4760_pgtype509;
	Y4760_gen_type [826] = Y4760_pgtype510;
	Y4760_gen_type [827] = Y4760_pgtype511;
	Y4760_gen_type [828] = Y4760_pgtype512;
	Y4760_gen_type [829] = Y4760_pgtype513;
	Y4760_gen_type [830] = Y4760_pgtype514;
	Y4760_gen_type [831] = Y4760_pgtype515;
	Y4760_gen_type [832] = Y4760_pgtype516;
	Y4760_gen_type [833] = Y4760_pgtype517;
	Y4760_gen_type [834] = Y4760_pgtype518;
	Y4760_gen_type [835] = Y4760_pgtype519;
	Y4760_gen_type [836] = Y4760_pgtype520;
	Y4760_gen_type [837] = Y4760_pgtype521;
	Y4760_gen_type [838] = Y4760_pgtype522;
	Y4760_gen_type [839] = Y4760_pgtype523;
	Y4760_gen_type [840] = Y4760_pgtype524;
	Y4760_gen_type [841] = Y4760_pgtype525;
	Y4760_gen_type [842] = Y4760_pgtype526;
	Y4760_gen_type [843] = Y4760_pgtype527;
	Y4760_gen_type [844] = Y4760_pgtype528;
	Y4760_gen_type [845] = Y4760_pgtype529;
	Y4760_gen_type [846] = Y4760_pgtype530;
	Y4760_gen_type [847] = Y4760_pgtype531;
	Y4760_gen_type [848] = Y4760_pgtype532;
	Y4760_gen_type [898] = Y4760_pgtype533;
	Y4760_gen_type [899] = Y4760_pgtype534;
	Y4760_gen_type [900] = Y4760_pgtype535;
	Y4760_gen_type [901] = Y4760_pgtype536;
	Y4760_gen_type [902] = Y4760_pgtype537;
	Y4760_gen_type [903] = Y4760_pgtype538;
	Y4760_gen_type [904] = Y4760_pgtype539;
	Y4760_gen_type [905] = Y4760_pgtype540;
	Y4760_gen_type [906] = Y4760_pgtype541;
	Y4760_gen_type [907] = Y4760_pgtype542;
	Y4760_gen_type [908] = Y4760_pgtype543;
	Y4760_gen_type [909] = Y4760_pgtype544;
	Y4760_gen_type [910] = Y4760_pgtype545;
	Y4760_gen_type [911] = Y4760_pgtype546;
	Y4760_gen_type [912] = Y4760_pgtype547;
	Y4760_gen_type [913] = Y4760_pgtype548;
	Y4760_gen_type [914] = Y4760_pgtype549;
	Y4760_gen_type [915] = Y4760_pgtype550;
	Y4760_gen_type [916] = Y4760_pgtype551;
	Y4760_gen_type [917] = Y4760_pgtype552;
	Y4760_gen_type [918] = Y4760_pgtype553;
	Y4760_gen_type [919] = Y4760_pgtype554;
	Y4760_gen_type [920] = Y4760_pgtype555;
	Y4760_gen_type [921] = Y4760_pgtype556;
	Y4760_gen_type [922] = Y4760_pgtype557;
	Y4760_gen_type [923] = Y4760_pgtype558;
	Y4760_gen_type [924] = Y4760_pgtype559;
	Y4760_gen_type [925] = Y4760_pgtype560;
	Y4760_gen_type [936] = Y4760_pgtype561;
	Y4760_gen_type [937] = Y4760_pgtype562;
	Y4760_gen_type [941] = Y4760_pgtype563;
	Y4760_gen_type [942] = Y4760_pgtype564;
	Y4760_gen_type [943] = Y4760_pgtype565;
	Y4760_gen_type [944] = Y4760_pgtype566;
	Y4760_gen_type [954] = Y4760_pgtype567;
	Y4760_gen_type [955] = Y4760_pgtype568;
	Y4760_gen_type [956] = Y4760_pgtype569;
	Y4760_gen_type [957] = Y4760_pgtype570;
	Y4760_gen_type [958] = Y4760_pgtype571;
	Y4760_gen_type [959] = Y4760_pgtype572;
	Y4760_gen_type [960] = Y4760_pgtype573;
	Y4760_gen_type [961] = Y4760_pgtype574;
	Y4760_gen_type [962] = Y4760_pgtype575;
	Y4760_gen_type [963] = Y4760_pgtype576;
	Y4760_gen_type [964] = Y4760_pgtype577;
	Y4760_gen_type [965] = Y4760_pgtype578;
	Y4760_gen_type [966] = Y4760_pgtype579;
	Y4760_gen_type [967] = Y4760_pgtype580;
	Y4760_gen_type [968] = Y4760_pgtype581;
	Y4760_gen_type [969] = Y4760_pgtype582;
	Y4760_gen_type [970] = Y4760_pgtype583;
	Y4760_gen_type [971] = Y4760_pgtype584;
	Y4760_gen_type [972] = Y4760_pgtype585;
	Y4760_gen_type [973] = Y4760_pgtype586;
	Y4760_gen_type [974] = Y4760_pgtype587;
	Y4760_gen_type [975] = Y4760_pgtype588;
	Y4760_gen_type [976] = Y4760_pgtype589;
	Y4760_gen_type [977] = Y4760_pgtype590;
	Y4760_gen_type [978] = Y4760_pgtype591;
	Y4760_gen_type [979] = Y4760_pgtype592;
	Y4760_gen_type [980] = Y4760_pgtype593;
	Y4760_gen_type [981] = Y4760_pgtype594;
	Y4760_gen_type [982] = Y4760_pgtype595;
	Y4760_gen_type [983] = Y4760_pgtype596;
	Y4760_gen_type [984] = Y4760_pgtype597;
	Y4760_gen_type [985] = Y4760_pgtype598;
	Y4760_gen_type [986] = Y4760_pgtype599;
	Y4760_gen_type [987] = Y4760_pgtype600;
	Y4760_gen_type [988] = Y4760_pgtype601;
	Y4760_gen_type [989] = Y4760_pgtype602;
	Y4760_gen_type [990] = Y4760_pgtype603;
	Y4760_gen_type [991] = Y4760_pgtype604;
	Y4760_gen_type [992] = Y4760_pgtype605;
	Y4760_gen_type [993] = Y4760_pgtype606;
	Y4760_gen_type [994] = Y4760_pgtype607;
	Y4760_gen_type [995] = Y4760_pgtype608;
	Y4760_gen_type [1001] = Y4760_pgtype609;
	Y4760_gen_type [1002] = Y4760_pgtype610;
	Y4760_gen_type [1003] = Y4760_pgtype611;
	Y4760_gen_type [1004] = Y4760_pgtype612;
	Y4760_gen_type [1006] = Y4760_pgtype613;
	Y4760_gen_type [1007] = Y4760_pgtype614;
	Y4760_gen_type [1008] = Y4760_pgtype615;
	Y4760_gen_type [1009] = Y4760_pgtype616;
	Y4760_gen_type [1505] = Y4760_pgtype617;
	Y4760_gen_type [1506] = Y4760_pgtype618;
	Y4760[12] = 1030;
	Y4760[13] = 977;
	{long i; for (i = 14; i < 16; i++) Y4760[i] = 1034;};
	Y4760[88] = 977;
	Y4760[89] = 980;
	Y4760[256] = 950;
	{long i; for (i = 319; i < 322; i++) Y4760[i] = 980;};
	Y4760[346] = 950;
	Y4760[501] = 0;
	Y4760[577] = 0;
	{long i; for (i = 662; i < 665; i++) Y4760[i] = 977;};
	{long i; for (i = 665; i < 669; i++) Y4760[i] = 980;};
	Y4760[724] = 980;
	Y4760[957] = 14;
	{long i; for (i = 1001; i < 1005; i++) Y4760[i] = 980;};
	{long i; for (i = 1006; i < 1010; i++) Y4760[i] = 980;};
	{long i; for (i = 1505; i < 1507; i++) Y4760[i] = 980;};
}

char *(*R4825[5])();
void R4825_init () {
	R4825[0] = (char *(*)()) F413_5349;
	R4825[1] = (char *(*)()) F418_5349;
	R4825[2] = (char *(*)()) F414_5349;
	R4825[3] = (char *(*)()) F413_5349;
	R4825[4] = (char *(*)()) F414_5349;
}

char *(*R4828[5])();
void R4828_init () {
	R4828[0] = (char *(*)()) F413_5354;
	R4828[1] = (char *(*)()) F418_5354;
	R4828[2] = (char *(*)()) F414_5354;
	R4828[3] = (char *(*)()) F413_5354;
	R4828[4] = (char *(*)()) F414_5354;
}

char *(*R4831[5])();
void R4831_init () {
	R4831[0] = (char *(*)()) F413_5335;
	R4831[1] = (char *(*)()) F418_5335;
	R4831[2] = (char *(*)()) F414_5335;
	R4831[3] = (char *(*)()) F413_5335;
	R4831[4] = (char *(*)()) F414_5335;
}

char *(*R4858[1250])();
void R4858_init () {
	R4858[0] = (char *(*)()) F624_5513_4858_2;
	R4858[411] = (char *(*)()) F1033_9228_4858_2;
	R4858[1249] = (char *(*)()) F1873_22330_4858_2;
}
static EIF_BOOLEAN F624_5513_4858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F624_5513(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1033_9228_4858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1033_9228(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1873_22330_4858_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1873_22330(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4863[1250])();
void R4863_init () {
	R4863[0] = (char *(*)()) F483_5422;
	R4863[90] = (char *(*)()) F483_5422;
	R4863[91] = (char *(*)()) F482_5422;
	R4863[92] = (char *(*)()) F483_5422;
	R4863[93] = (char *(*)()) F485_5422;
	R4863[94] = (char *(*)()) F487_5422;
	R4863[95] = (char *(*)()) F488_5422;
	R4863[96] = (char *(*)()) F489_5422;
	R4863[97] = (char *(*)()) F490_5422;
	R4863[98] = (char *(*)()) F491_5422;
	R4863[99] = (char *(*)()) F484_5422;
	R4863[100] = (char *(*)()) F486_5422;
	R4863[101] = (char *(*)()) F492_5422;
	R4863[102] = (char *(*)()) F493_5422;
	R4863[103] = (char *(*)()) F482_5422;
	R4863[104] = (char *(*)()) F483_5422;
	R4863[105] = (char *(*)()) F485_5422;
	R4863[106] = (char *(*)()) F488_5422;
	R4863[107] = (char *(*)()) F490_5422;
	R4863[108] = (char *(*)()) F489_5422;
	R4863[109] = (char *(*)()) F484_5422;
	R4863[238] = (char *(*)()) F482_5422;
	R4863[239] = (char *(*)()) F487_5422;
	R4863[240] = (char *(*)()) F483_5422;
	R4863[241] = (char *(*)()) F482_5422;
	R4863[242] = (char *(*)()) F483_5422;
	R4863[245] = (char *(*)()) F482_5422;
	R4863[408] = (char *(*)()) F486_5422;
	R4863[411] = (char *(*)()) F484_5422;
	R4863[468] = (char *(*)()) F484_5422;
	R4863[745] = (char *(*)()) F484_5422;
	R4863[750] = (char *(*)()) F484_5422;
	R4863[1249] = (char *(*)()) F484_5422;
}

char *(*R4895[839])();
void R4895_init () {
	R4895[0] = (char *(*)()) F1033_9216_4895_38;
	R4895[838] = (char *(*)()) F1873_22324_4895_38;
}
static EIF_INTEGER_32 F1033_9216_4895_38 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1033_9216(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_INTEGER_32 F1873_22324_4895_38 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1873_22324(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4896[1159])();
void R4896_init () {
	R4896[0] = (char *(*)()) F715_5942_4896_5;
	R4896[1] = (char *(*)()) F716_5942_4896_5;
	R4896[2] = (char *(*)()) F717_5942_4896_5;
	R4896[3] = (char *(*)()) F718_5942_4896_5;
	R4896[4] = (char *(*)()) F719_5942_4896_5;
	R4896[5] = (char *(*)()) F720_5942_4896_5;
	R4896[6] = (char *(*)()) F721_5942_4896_5;
	R4896[7] = (char *(*)()) F722_5942_4896_5;
	R4896[8] = (char *(*)()) F723_5942_4896_5;
	R4896[9] = (char *(*)()) F724_5942_4896_5;
	R4896[10] = (char *(*)()) F725_5942_4896_5;
	R4896[11] = (char *(*)()) F726_5942_4896_5;
	R4896[12] = (char *(*)()) F715_5942_4896_5;
	R4896[13] = (char *(*)()) F716_5942_4896_5;
	R4896[14] = (char *(*)()) F717_5942_4896_5;
	R4896[15] = (char *(*)()) F719_5942_4896_5;
	R4896[16] = (char *(*)()) F721_5942_4896_5;
	R4896[17] = (char *(*)()) F720_5942_4896_5;
	R4896[18] = (char *(*)()) F723_5942_4896_5;
	R4896[317] = (char *(*)()) F1032_9108_4896_5;
	R4896[320] = (char *(*)()) F1035_9272_4896_5;
	R4896[1158] = (char *(*)()) F1873_22309_4896_5;
}
static EIF_REFERENCE F715_5942_4896_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F715_5942(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F716_5942_4896_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F716_5942(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(950, 0x00).id, 950, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F717_5942_4896_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F717_5942(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(959, 0x00).id, 959, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F718_5942_4896_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F718_5942(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(1020, 0x00).id, 1020, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F719_5942_4896_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F719_5942(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(962, 0x00).id, 962, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F720_5942_4896_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F720_5942(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(968, 0x00).id, 968, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F721_5942_4896_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F721_5942(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(983, 0x00).id, 983, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F722_5942_4896_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F722_5942(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(965, 0x00).id, 965, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F723_5942_4896_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F723_5942(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F724_5942_4896_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F724_5942(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(977, 0x00).id, 977, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F725_5942_4896_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F725_5942(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(971, 0x00).id, 971, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F726_5942_4896_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F726_5942(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(974, 0x00).id, 974, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1032_9108_4896_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F1032_9108(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(977, 0x00).id, 977, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1035_9272_4896_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1035_9272(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1873_22309_4896_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1873_22309(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(980, 0x00).id, 980, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4899[1159])();
void R4899_init () {
	R4899[0] = (char *(*)()) F715_5961_4899_23;
	R4899[1] = (char *(*)()) F716_5961_4899_23;
	R4899[2] = (char *(*)()) F717_5961_4899_23;
	R4899[3] = (char *(*)()) F718_5961_4899_23;
	R4899[4] = (char *(*)()) F719_5961_4899_23;
	R4899[5] = (char *(*)()) F720_5961_4899_23;
	R4899[6] = (char *(*)()) F721_5961_4899_23;
	R4899[7] = (char *(*)()) F722_5961_4899_23;
	R4899[8] = (char *(*)()) F723_5961_4899_23;
	R4899[9] = (char *(*)()) F724_5961_4899_23;
	R4899[10] = (char *(*)()) F725_5961_4899_23;
	R4899[11] = (char *(*)()) F726_5961_4899_23;
	R4899[12] = (char *(*)()) F715_5961_4899_23;
	R4899[13] = (char *(*)()) F716_5961_4899_23;
	R4899[14] = (char *(*)()) F717_5961_4899_23;
	R4899[15] = (char *(*)()) F719_5961_4899_23;
	R4899[16] = (char *(*)()) F721_5961_4899_23;
	R4899[17] = (char *(*)()) F720_5961_4899_23;
	R4899[18] = (char *(*)()) F723_5961_4899_23;
	R4899[147] = (char *(*)()) F862_6441;
	R4899[148] = (char *(*)()) F863_6441_4899_23;
	R4899[149] = (char *(*)()) F864_6441_4899_23;
	R4899[150] = (char *(*)()) F865_6441_4899_23;
	R4899[151] = (char *(*)()) F866_6441_4899_23;
	R4899[154] = (char *(*)()) F862_6441;
	R4899[317] = (char *(*)()) F1032_9128_4899_23;
	R4899[320] = (char *(*)()) F1035_9293_4899_23;
	R4899[1158] = (char *(*)()) F1873_22344_4899_23;
}
static void F715_5961_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F715_5961(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F716_5961_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F716_5961(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F717_5961_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F717_5961(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F718_5961_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F718_5961(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F719_5961_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F719_5961(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F720_5961_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F720_5961(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F721_5961_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F721_5961(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F722_5961_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F722_5961(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F723_5961_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F723_5961(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F724_5961_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F724_5961(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F725_5961_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F725_5961(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F726_5961_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F726_5961(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F863_6441_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F863_6441(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F864_6441_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F864_6441(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F865_6441_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F865_6441(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F866_6441_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F866_6441(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1032_9128_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1032_9128(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1035_9293_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1035_9293(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1873_22344_4899_23 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1873_22344(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y4901_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype30[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype31[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype32[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype33[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype34[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype35[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype36[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype37[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype38[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype39[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype40[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype41[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype42[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype43[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype44[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype45[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype46[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype47[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype48[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype49[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype50[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype51[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype52[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype53[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype54[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype55[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype56[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype57[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype58[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype59[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype60[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype61[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype62[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype63[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype64[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype65[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype66[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype67[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype68[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype69[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype70[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype71[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype72[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype73[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype74[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype75[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype76[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype77[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype78[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype79[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype80[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype81[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype82[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype83[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype84[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype85[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype86[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype87[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype88[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype89[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype90[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype91[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype92[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype93[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype94[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype95[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype96[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype97[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype98[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype99[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype100[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype101[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype102[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype103[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype104[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype105[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype106[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype107[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype108[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype109[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype110[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype111[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype112[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype113[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype114[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype115[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype116[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype117[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype118[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype119[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype120[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype121[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype122[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype123[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype124[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype125[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype126[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype127[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype128[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype129[] = {0xFF01,1026,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype130[] = {0xFF01,1026,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype131[] = {0xFF01,1034,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype132[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype133[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype134[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype135[] = {950,0xFFFF};
static EIF_TYPE_INDEX Y4901_pgtype136[] = {950,0xFFFF};
EIF_TYPE_INDEX *Y4901_gen_type [1320];
EIF_TYPE_INDEX Y4901 [1320];
void Y4901_init (void)
{
	egc_routines_types [4901] = Y4901;
	egc_routines_gen_types [4901] = Y4901_gen_type;
	egc_routines_offset [4901] = 554;
	Y4901_gen_type [0] = Y4901_pgtype0;
	Y4901_gen_type [1] = Y4901_pgtype1;
	Y4901_gen_type [2] = Y4901_pgtype2;
	Y4901_gen_type [3] = Y4901_pgtype3;
	Y4901_gen_type [4] = Y4901_pgtype4;
	Y4901_gen_type [5] = Y4901_pgtype5;
	Y4901_gen_type [6] = Y4901_pgtype6;
	Y4901_gen_type [7] = Y4901_pgtype7;
	Y4901_gen_type [8] = Y4901_pgtype8;
	Y4901_gen_type [9] = Y4901_pgtype9;
	Y4901_gen_type [10] = Y4901_pgtype10;
	Y4901_gen_type [11] = Y4901_pgtype11;
	Y4901_gen_type [12] = Y4901_pgtype12;
	Y4901_gen_type [13] = Y4901_pgtype13;
	Y4901_gen_type [14] = Y4901_pgtype14;
	Y4901_gen_type [15] = Y4901_pgtype15;
	Y4901_gen_type [16] = Y4901_pgtype16;
	Y4901_gen_type [17] = Y4901_pgtype17;
	Y4901_gen_type [18] = Y4901_pgtype18;
	Y4901_gen_type [19] = Y4901_pgtype19;
	Y4901_gen_type [20] = Y4901_pgtype20;
	Y4901_gen_type [21] = Y4901_pgtype21;
	Y4901_gen_type [22] = Y4901_pgtype22;
	Y4901_gen_type [23] = Y4901_pgtype23;
	Y4901_gen_type [24] = Y4901_pgtype24;
	Y4901_gen_type [25] = Y4901_pgtype25;
	Y4901_gen_type [26] = Y4901_pgtype26;
	Y4901_gen_type [27] = Y4901_pgtype27;
	Y4901_gen_type [28] = Y4901_pgtype28;
	Y4901_gen_type [29] = Y4901_pgtype29;
	Y4901_gen_type [147] = Y4901_pgtype30;
	Y4901_gen_type [148] = Y4901_pgtype31;
	Y4901_gen_type [149] = Y4901_pgtype32;
	Y4901_gen_type [150] = Y4901_pgtype33;
	Y4901_gen_type [151] = Y4901_pgtype34;
	Y4901_gen_type [152] = Y4901_pgtype35;
	Y4901_gen_type [153] = Y4901_pgtype36;
	Y4901_gen_type [154] = Y4901_pgtype37;
	Y4901_gen_type [155] = Y4901_pgtype38;
	Y4901_gen_type [156] = Y4901_pgtype39;
	Y4901_gen_type [157] = Y4901_pgtype40;
	Y4901_gen_type [158] = Y4901_pgtype41;
	Y4901_gen_type [159] = Y4901_pgtype42;
	Y4901_gen_type [160] = Y4901_pgtype43;
	Y4901_gen_type [161] = Y4901_pgtype44;
	Y4901_gen_type [162] = Y4901_pgtype45;
	Y4901_gen_type [163] = Y4901_pgtype46;
	Y4901_gen_type [164] = Y4901_pgtype47;
	Y4901_gen_type [165] = Y4901_pgtype48;
	Y4901_gen_type [166] = Y4901_pgtype49;
	Y4901_gen_type [167] = Y4901_pgtype50;
	Y4901_gen_type [168] = Y4901_pgtype51;
	Y4901_gen_type [169] = Y4901_pgtype52;
	Y4901_gen_type [170] = Y4901_pgtype53;
	Y4901_gen_type [171] = Y4901_pgtype54;
	Y4901_gen_type [172] = Y4901_pgtype55;
	Y4901_gen_type [173] = Y4901_pgtype56;
	Y4901_gen_type [174] = Y4901_pgtype57;
	Y4901_gen_type [175] = Y4901_pgtype58;
	Y4901_gen_type [176] = Y4901_pgtype59;
	Y4901_gen_type [177] = Y4901_pgtype60;
	Y4901_gen_type [178] = Y4901_pgtype61;
	Y4901_gen_type [179] = Y4901_pgtype62;
	Y4901_gen_type [180] = Y4901_pgtype63;
	Y4901_gen_type [181] = Y4901_pgtype64;
	Y4901_gen_type [182] = Y4901_pgtype65;
	Y4901_gen_type [183] = Y4901_pgtype66;
	Y4901_gen_type [184] = Y4901_pgtype67;
	Y4901_gen_type [185] = Y4901_pgtype68;
	Y4901_gen_type [186] = Y4901_pgtype69;
	Y4901_gen_type [187] = Y4901_pgtype70;
	Y4901_gen_type [188] = Y4901_pgtype71;
	Y4901_gen_type [189] = Y4901_pgtype72;
	Y4901_gen_type [190] = Y4901_pgtype73;
	Y4901_gen_type [191] = Y4901_pgtype74;
	Y4901_gen_type [192] = Y4901_pgtype75;
	Y4901_gen_type [193] = Y4901_pgtype76;
	Y4901_gen_type [194] = Y4901_pgtype77;
	Y4901_gen_type [195] = Y4901_pgtype78;
	Y4901_gen_type [196] = Y4901_pgtype79;
	Y4901_gen_type [197] = Y4901_pgtype80;
	Y4901_gen_type [198] = Y4901_pgtype81;
	Y4901_gen_type [199] = Y4901_pgtype82;
	Y4901_gen_type [200] = Y4901_pgtype83;
	Y4901_gen_type [201] = Y4901_pgtype84;
	Y4901_gen_type [202] = Y4901_pgtype85;
	Y4901_gen_type [203] = Y4901_pgtype86;
	Y4901_gen_type [204] = Y4901_pgtype87;
	Y4901_gen_type [205] = Y4901_pgtype88;
	Y4901_gen_type [206] = Y4901_pgtype89;
	Y4901_gen_type [207] = Y4901_pgtype90;
	Y4901_gen_type [208] = Y4901_pgtype91;
	Y4901_gen_type [209] = Y4901_pgtype92;
	Y4901_gen_type [210] = Y4901_pgtype93;
	Y4901_gen_type [211] = Y4901_pgtype94;
	Y4901_gen_type [212] = Y4901_pgtype95;
	Y4901_gen_type [213] = Y4901_pgtype96;
	Y4901_gen_type [214] = Y4901_pgtype97;
	Y4901_gen_type [215] = Y4901_pgtype98;
	Y4901_gen_type [216] = Y4901_pgtype99;
	Y4901_gen_type [217] = Y4901_pgtype100;
	Y4901_gen_type [218] = Y4901_pgtype101;
	Y4901_gen_type [219] = Y4901_pgtype102;
	Y4901_gen_type [220] = Y4901_pgtype103;
	Y4901_gen_type [221] = Y4901_pgtype104;
	Y4901_gen_type [222] = Y4901_pgtype105;
	Y4901_gen_type [223] = Y4901_pgtype106;
	Y4901_gen_type [224] = Y4901_pgtype107;
	Y4901_gen_type [225] = Y4901_pgtype108;
	Y4901_gen_type [226] = Y4901_pgtype109;
	Y4901_gen_type [227] = Y4901_pgtype110;
	Y4901_gen_type [228] = Y4901_pgtype111;
	Y4901_gen_type [295] = Y4901_pgtype112;
	Y4901_gen_type [296] = Y4901_pgtype113;
	Y4901_gen_type [297] = Y4901_pgtype114;
	Y4901_gen_type [298] = Y4901_pgtype115;
	Y4901_gen_type [299] = Y4901_pgtype116;
	Y4901_gen_type [300] = Y4901_pgtype117;
	Y4901_gen_type [301] = Y4901_pgtype118;
	Y4901_gen_type [302] = Y4901_pgtype119;
	Y4901_gen_type [303] = Y4901_pgtype120;
	Y4901_gen_type [304] = Y4901_pgtype121;
	Y4901_gen_type [305] = Y4901_pgtype122;
	Y4901_gen_type [306] = Y4901_pgtype123;
	Y4901_gen_type [307] = Y4901_pgtype124;
	Y4901_gen_type [308] = Y4901_pgtype125;
	Y4901_gen_type [309] = Y4901_pgtype126;
	Y4901_gen_type [310] = Y4901_pgtype127;
	Y4901_gen_type [311] = Y4901_pgtype128;
	Y4901_gen_type [312] = Y4901_pgtype129;
	Y4901_gen_type [313] = Y4901_pgtype130;
	Y4901_gen_type [314] = Y4901_pgtype131;
	Y4901_gen_type [477] = Y4901_pgtype132;
	Y4901_gen_type [480] = Y4901_pgtype133;
	Y4901_gen_type [481] = Y4901_pgtype134;
	Y4901_gen_type [1318] = Y4901_pgtype135;
	Y4901_gen_type [1319] = Y4901_pgtype136;
	{long i; for (i = 147; i < 229; i++) Y4901[i] = 950;};
	{long i; for (i = 295; i < 307; i++) Y4901[i] = 950;};
	{long i; for (i = 312; i < 314; i++) Y4901[i] = 1026;};
	Y4901[314] = 1034;
	Y4901[477] = 950;
	{long i; for (i = 480; i < 482; i++) Y4901[i] = 950;};
	{long i; for (i = 1318; i < 1320; i++) Y4901[i] = 950;};
}


#ifdef __cplusplus
}
#endif
