
#ifndef _C1_ut21_
#define _C1_ut21_

#ifdef __cplusplus
extern "C" {
#endif

extern void F25_266(EIF_REFERENCE);
extern EIF_BOOLEAN F25_268(EIF_REFERENCE);
extern void F25_271(EIF_REFERENCE);
extern void F25_272(EIF_REFERENCE);
extern void EIF_Minit21(void);

#ifdef __cplusplus
}
#endif

#endif
