
#ifndef _C1_kl35_
#define _C1_kl35_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F46_577(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit35(void);

#ifdef __cplusplus
}
#endif

#endif
