
#ifndef _C1_lx13_
#define _C1_lx13_

#ifdef __cplusplus
extern "C" {
#endif

extern void F17_163(EIF_REFERENCE);
extern void F17_193(EIF_REFERENCE, EIF_BOOLEAN);
extern void F17_194(EIF_REFERENCE, EIF_INTEGER_32);
extern void F17_197(EIF_REFERENCE, EIF_BOOLEAN);
extern void F17_198(EIF_REFERENCE, EIF_BOOLEAN);
extern void F17_199(EIF_REFERENCE, EIF_BOOLEAN);
extern void F17_226(EIF_REFERENCE, EIF_REFERENCE);
extern void F17_227(EIF_REFERENCE, EIF_BOOLEAN);
extern void F17_228(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit13(void);
extern void F1544_13921(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1541_13840(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
