
#ifndef _C1_xm9_
#define _C1_xm9_

#ifdef __cplusplus
extern "C" {
#endif

extern void F9_98(EIF_REFERENCE);
extern EIF_REFERENCE F9_99(EIF_REFERENCE);
extern EIF_REFERENCE F9_100(EIF_REFERENCE);
extern void F9_105(EIF_REFERENCE, EIF_REFERENCE);
extern void F9_106(EIF_REFERENCE, EIF_REFERENCE);
extern void F9_107(EIF_REFERENCE, EIF_BOOLEAN);
extern void F9_108(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit9(void);
extern char *(*R2634[])();

#ifdef __cplusplus
}
#endif

#endif
