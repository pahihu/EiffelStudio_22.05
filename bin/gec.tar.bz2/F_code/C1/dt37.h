
#ifndef _C1_dt37_
#define _C1_dt37_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F48_593_body(EIF_REFERENCE);
extern EIF_REFERENCE F48_593(EIF_REFERENCE);
extern void EIF_Minit37(void);

#ifdef __cplusplus
}
#endif

#endif
