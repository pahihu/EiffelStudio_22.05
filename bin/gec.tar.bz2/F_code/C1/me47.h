
#ifndef _C1_me47_
#define _C1_me47_

#ifdef __cplusplus
extern "C" {
#endif

extern void F70_938(EIF_REFERENCE);
extern EIF_POINTER F70_941(EIF_REFERENCE);
extern void EIF_Minit47(void);
extern void F405_5357(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
