/*
 * Code for class XM_EIFFEL_DECLARATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm9.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_EIFFEL_DECLARATION}.make */
void F9_98 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(3057,F9_99, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(3058,F9_100, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) EIF_TRUE;
	RTLE;
}

/* {XM_EIFFEL_DECLARATION}.default_version */

EIF_REFERENCE F9_99 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (3057,RTMS_EX_H("1.0",3,3223088));
}

/* {XM_EIFFEL_DECLARATION}.default_encoding */

EIF_REFERENCE F9_100 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (3058,RTMS_EX_H("utf-8",5,1953751864));
}

/* {XM_EIFFEL_DECLARATION}.set_version */
void F9_105 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {XM_EIFFEL_DECLARATION}.set_encoding */
void F9_106 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {XM_EIFFEL_DECLARATION}.set_stand_alone */
void F9_107 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) arg1;
}

/* {XM_EIFFEL_DECLARATION}.process */
void F9_108 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R2634[Dtype(RTCW(arg1))-273])(arg1, *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current + _REFACS_1_), *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_));
}

void EIF_Minit9 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
