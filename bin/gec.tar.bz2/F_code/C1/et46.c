/*
 * Code for class ET_ECF_SETTING_NAMES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et46.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ECF_SETTING_NAMES}.absent_explicit_assertion_setting_name */

EIF_REFERENCE F69_875 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (29,RTMS_EX_H("absent_explicit_assertion",25,1492485742));
}

/* {ET_ECF_SETTING_NAMES}.address_expression_setting_name */

EIF_REFERENCE F69_876 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (30,RTMS_EX_H("address_expression",18,582140782));
}

/* {ET_ECF_SETTING_NAMES}.array_optimization_setting_name */

EIF_REFERENCE F69_877 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (31,RTMS_EX_H("array_optimization",18,887890542));
}

/* {ET_ECF_SETTING_NAMES}.automatic_backup_setting_name */

EIF_REFERENCE F69_878 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (32,RTMS_EX_H("automatic_backup",16,994296176));
}

/* {ET_ECF_SETTING_NAMES}.check_for_void_target_setting_name */

EIF_REFERENCE F69_879 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (33,RTMS_EX_H("check_for_void_target",21,1202472308));
}

/* {ET_ECF_SETTING_NAMES}.check_generic_creation_constraint_setting_name */

EIF_REFERENCE F69_880 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (34,RTMS_EX_H("check_generic_creation_constraint",33,76943988));
}

/* {ET_ECF_SETTING_NAMES}.check_vape_setting_name */

EIF_REFERENCE F69_881 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (35,RTMS_EX_H("check_vape",10,405013349));
}

/* {ET_ECF_SETTING_NAMES}.cls_compliant_setting_name */

EIF_REFERENCE F69_882 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (36,RTMS_EX_H("cls_compliant",13,823584116));
}

/* {ET_ECF_SETTING_NAMES}.concurrency_setting_name */

EIF_REFERENCE F69_883 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (37,RTMS_EX_H("concurrency",11,300205945));
}

/* {ET_ECF_SETTING_NAMES}.console_application_setting_name */

EIF_REFERENCE F69_884 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (38,RTMS_EX_H("console_application",19,375043438));
}

/* {ET_ECF_SETTING_NAMES}.dead_code_removal_setting_name */

EIF_REFERENCE F69_885 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (39,RTMS_EX_H("dead_code_removal",17,1064146540));
}

/* {ET_ECF_SETTING_NAMES}.dotnet_naming_convention_setting_name */

EIF_REFERENCE F69_886 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (40,RTMS_EX_H("dotnet_naming_convention",24,1299737966));
}

/* {ET_ECF_SETTING_NAMES}.dynamic_runtime_setting_name */

EIF_REFERENCE F69_887 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (41,RTMS_EX_H("dynamic_runtime",15,1723645541));
}

/* {ET_ECF_SETTING_NAMES}.enforce_unique_class_names_setting_name */

EIF_REFERENCE F69_888 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (42,RTMS_EX_H("enforce_unique_class_names",26,1541728115));
}

/* {ET_ECF_SETTING_NAMES}.exception_trace_setting_name */

EIF_REFERENCE F69_889 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (43,RTMS_EX_H("exception_trace",15,2042636389));
}

/* {ET_ECF_SETTING_NAMES}.finalize_setting_name */

EIF_REFERENCE F69_892 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (3,RTMS_EX_H("finalize",8,1220601701));
}

/* {ET_ECF_SETTING_NAMES}.force_32bits_setting_name */

EIF_REFERENCE F69_893 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (44,RTMS_EX_H("force_32bits",12,1670958451));
}

/* {ET_ECF_SETTING_NAMES}.full_type_checking_setting_name */

EIF_REFERENCE F69_894 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (45,RTMS_EX_H("full_type_checking",18,958781543));
}

/* {ET_ECF_SETTING_NAMES}.il_verifiable_setting_name */

EIF_REFERENCE F69_895 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (46,RTMS_EX_H("il_verifiable",13,1528054629));
}

/* {ET_ECF_SETTING_NAMES}.inlining_setting_name */

EIF_REFERENCE F69_896 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (47,RTMS_EX_H("inlining",8,1620076135));
}

/* {ET_ECF_SETTING_NAMES}.inlining_size_setting_name */

EIF_REFERENCE F69_897 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (48,RTMS_EX_H("inlining_size",13,1191342437));
}

/* {ET_ECF_SETTING_NAMES}.java_generation_setting_name */

EIF_REFERENCE F69_898 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (49,RTMS_EX_H("java_generation",15,436362606));
}

/* {ET_ECF_SETTING_NAMES}.library_root_setting_name */

EIF_REFERENCE F69_899 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (50,RTMS_EX_H("library_root",12,550974580));
}

/* {ET_ECF_SETTING_NAMES}.line_generation_setting_name */

EIF_REFERENCE F69_900 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (51,RTMS_EX_H("line_generation",15,444800878));
}

/* {ET_ECF_SETTING_NAMES}.manifest_array_type_setting_name */

EIF_REFERENCE F69_901 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (52,RTMS_EX_H("manifest_array_type",19,1326410085));
}

/* {ET_ECF_SETTING_NAMES}.msil_generation_setting_name */

EIF_REFERENCE F69_907 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (53,RTMS_EX_H("msil_generation",15,2084028270));
}

/* {ET_ECF_SETTING_NAMES}.msil_generation_type_setting_name */

EIF_REFERENCE F69_908 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (54,RTMS_EX_H("msil_generation_type",20,404540773));
}

/* {ET_ECF_SETTING_NAMES}.msil_use_optimized_precompile_setting_name */

EIF_REFERENCE F69_910 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (55,RTMS_EX_H("msil_use_optimized_precompile",29,154263397));
}

/* {ET_ECF_SETTING_NAMES}.multithreaded_setting_name */

EIF_REFERENCE F69_911 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (56,RTMS_EX_H("multithreaded",13,1599663972));
}

/* {ET_ECF_SETTING_NAMES}.old_feature_replication_setting_name */

EIF_REFERENCE F69_912 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (57,RTMS_EX_H("old_feature_replication",23,660525166));
}

/* {ET_ECF_SETTING_NAMES}.old_verbatim_strings_setting_name */

EIF_REFERENCE F69_913 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (58,RTMS_EX_H("old_verbatim_strings",20,301586803));
}

/* {ET_ECF_SETTING_NAMES}.total_order_on_reals_setting_name */

EIF_REFERENCE F69_916 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (59,RTMS_EX_H("total_order_on_reals",20,243982195));
}

/* {ET_ECF_SETTING_NAMES}.use_all_cluster_name_as_namespace_setting_name */

EIF_REFERENCE F69_917 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (60,RTMS_EX_H("use_all_cluster_name_as_namespace",33,659613541));
}

/* {ET_ECF_SETTING_NAMES}.use_cluster_name_as_namespace_setting_name */

EIF_REFERENCE F69_918 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (61,RTMS_EX_H("use_cluster_name_as_namespace",29,815842661));
}

/* {ET_ECF_SETTING_NAMES}.all_setting_value */

EIF_REFERENCE F69_919 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (62,RTMS_EX_H("all",3,6384748));
}

/* {ET_ECF_SETTING_NAMES}.default_setting_value */

EIF_REFERENCE F69_920 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (63,RTMS_EX_H("default",7,626575476));
}

/* {ET_ECF_SETTING_NAMES}.exe_setting_value */

EIF_REFERENCE F69_922 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (64,RTMS_EX_H("exe",3,6649957));
}

/* {ET_ECF_SETTING_NAMES}.false_setting_value */

EIF_REFERENCE F69_923 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (65,RTMS_EX_H("false",5,1635280741));
}

/* {ET_ECF_SETTING_NAMES}.feature_setting_value */

EIF_REFERENCE F69_924 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (66,RTMS_EX_H("feature",7,1951938661));
}

/* {ET_ECF_SETTING_NAMES}.finalize_setting_value */

EIF_REFERENCE F69_925 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (67,RTMS_EX_H("finalize",8,1220601701));
}

/* {ET_ECF_SETTING_NAMES}.none_setting_value */

EIF_REFERENCE F69_929 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (68,RTMS_EX_H("none",4,1852796517));
}

/* {ET_ECF_SETTING_NAMES}.true_setting_value */

EIF_REFERENCE F69_933 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (4,RTMS_EX_H("true",4,1953658213));
}

/* {ET_ECF_SETTING_NAMES}.unix_setting_value */

EIF_REFERENCE F69_934 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (69,RTMS_EX_H("unix",4,1970170232));
}

/* {ET_ECF_SETTING_NAMES}.windows_setting_value */

EIF_REFERENCE F69_936 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (70,RTMS_EX_H("windows",7,1657536371));
}

/* {ET_ECF_SETTING_NAMES}.workbench_setting_value */

EIF_REFERENCE F69_937 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (71,RTMS_EX_H("workbench",9,1911020904));
}

void EIF_Minit46 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
