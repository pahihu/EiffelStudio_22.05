/*
 * Code for class UT_TRISTATE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ut21.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UT_TRISTATE}.make_false */
void F25_266 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F25_272(Current);
}

/* {UT_TRISTATE}.is_true */
EIF_BOOLEAN F25_268 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_0_0_) == (EIF_CHARACTER_8) 'T');
}

/* {UT_TRISTATE}.set_true */
void F25_271 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_0_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'T';
}

/* {UT_TRISTATE}.set_false */
void F25_272 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_0_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'F';
}

void EIF_Minit21 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
