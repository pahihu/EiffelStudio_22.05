
#ifndef _C1_et30_
#define _C1_et30_

#ifdef __cplusplus
extern "C" {
#endif

extern void F41_469(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F41_470(EIF_REFERENCE);
extern void EIF_Minit30(void);
extern EIF_BOOLEAN F1177_10251(EIF_REFERENCE);
extern EIF_REFERENCE F69_907(EIF_REFERENCE);
extern EIF_REFERENCE F1242_11635(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1183_10510(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
