
#ifndef _C1_op44_
#define _C1_op44_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F67_871(EIF_REFERENCE);
extern void EIF_Minit44(void);

#ifdef __cplusplus
}
#endif

#endif
