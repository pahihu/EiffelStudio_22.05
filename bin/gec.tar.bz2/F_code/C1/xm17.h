
#ifndef _C1_xm17_
#define _C1_xm17_

#ifdef __cplusplus
extern "C" {
#endif

extern void F21_247(EIF_REFERENCE);
extern EIF_BOOLEAN F21_248(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F21_249(EIF_REFERENCE, EIF_REFERENCE);
extern void F21_250(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit17(void);
extern void F1333_13086(EIF_REFERENCE);
extern EIF_REFERENCE F1411_13173(EIF_REFERENCE);
extern void F1333_13085(EIF_REFERENCE);
extern void F1513_13604(EIF_REFERENCE);
extern void F246_2391(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1333_13088(EIF_REFERENCE);
extern char *(*R10795[])();
extern char *(*R10736[])();

#ifdef __cplusplus
}
#endif

#endif
