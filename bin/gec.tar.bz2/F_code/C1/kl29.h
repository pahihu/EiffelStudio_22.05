
#ifndef _C1_kl29_
#define _C1_kl29_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F40_466_body(EIF_REFERENCE);
extern EIF_REFERENCE F40_466(EIF_REFERENCE);
static EIF_REFERENCE F40_467_body(EIF_REFERENCE);
extern EIF_REFERENCE F40_467(EIF_REFERENCE);
static EIF_REFERENCE F40_468_body(EIF_REFERENCE);
extern EIF_REFERENCE F40_468(EIF_REFERENCE);
extern void EIF_Minit29(void);
extern void F1222_11020(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
