/*
 * Code for class ET_ECF_OPTION_NAMES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et33.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ECF_OPTION_NAMES}.assertions_check_option_name */

EIF_REFERENCE F44_492 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1787,RTMS_EX_H("check",5,1752235371));
}

/* {ET_ECF_OPTION_NAMES}.assertions_invariant_option_name */

EIF_REFERENCE F44_493 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1788,RTMS_EX_H("invariant",9,997544820));
}

/* {ET_ECF_OPTION_NAMES}.assertions_loop_option_name */

EIF_REFERENCE F44_494 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1789,RTMS_EX_H("loop",4,1819242352));
}

/* {ET_ECF_OPTION_NAMES}.assertions_postcondition_option_name */

EIF_REFERENCE F44_495 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1790,RTMS_EX_H("postcondition",13,29888366));
}

/* {ET_ECF_OPTION_NAMES}.assertions_precondition_option_name */

EIF_REFERENCE F44_496 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1791,RTMS_EX_H("precondition",12,694692206));
}

/* {ET_ECF_OPTION_NAMES}.assertions_supplier_precondition_option_name */

EIF_REFERENCE F44_497 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1792,RTMS_EX_H("supplier_precondition",21,1130264430));
}

/* {ET_ECF_OPTION_NAMES}.cat_call_detection_option_name */

EIF_REFERENCE F44_498 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1793,RTMS_EX_H("cat_call_detection",18,407749998));
}

/* {ET_ECF_OPTION_NAMES}.debug_option_name */

EIF_REFERENCE F44_499 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1794,RTMS_EX_H("debug",5,1701719399));
}

/* {ET_ECF_OPTION_NAMES}.full_class_checking_option_name */

EIF_REFERENCE F44_500 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1795,RTMS_EX_H("full_class_checking",19,821682023));
}

/* {ET_ECF_OPTION_NAMES}.is_attached_by_default_option_name */

EIF_REFERENCE F44_501 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (526,RTMS_EX_H("is_attached_by_default",22,1750772596));
}

/* {ET_ECF_OPTION_NAMES}.is_obsolete_routine_type_option_name */

EIF_REFERENCE F44_502 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (527,RTMS_EX_H("is_obsolete_routine_type",24,1942807653));
}

/* {ET_ECF_OPTION_NAMES}.is_void_safe_option_name */

EIF_REFERENCE F44_503 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1796,RTMS_EX_H("is_void_safe",12,1531546981));
}

/* {ET_ECF_OPTION_NAMES}.manifest_array_type_option_name */

EIF_REFERENCE F44_504 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1797,RTMS_EX_H("manifest_array_type",19,1326410085));
}

/* {ET_ECF_OPTION_NAMES}.msil_application_optimize_option_name */

EIF_REFERENCE F44_505 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1798,RTMS_EX_H("msil_application_optimize",25,667769189));
}

/* {ET_ECF_OPTION_NAMES}.optimize_option_name */

EIF_REFERENCE F44_507 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1799,RTMS_EX_H("optimize",8,479566181));
}

/* {ET_ECF_OPTION_NAMES}.profile_option_name */

EIF_REFERENCE F44_508 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1800,RTMS_EX_H("profile",7,332661605));
}

/* {ET_ECF_OPTION_NAMES}.syntax_option_name */

EIF_REFERENCE F44_509 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1801,RTMS_EX_H("syntax",6,2080149368));
}

/* {ET_ECF_OPTION_NAMES}.syntax_level_option_name */

EIF_REFERENCE F44_510 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1802,RTMS_EX_H("syntax_level",12,1690338668));
}

/* {ET_ECF_OPTION_NAMES}.trace_option_name */

EIF_REFERENCE F44_511 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (528,RTMS_EX_H("trace",5,1919875941));
}

/* {ET_ECF_OPTION_NAMES}.void_safety_option_name */

EIF_REFERENCE F44_512 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1803,RTMS_EX_H("void_safety",11,1966795897));
}

/* {ET_ECF_OPTION_NAMES}.warning_option_name */

EIF_REFERENCE F44_513 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1804,RTMS_EX_H("warning",7,1809215079));
}

/* {ET_ECF_OPTION_NAMES}.warning_export_class_missing_option_name */

EIF_REFERENCE F44_514 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1805,RTMS_EX_H("export_class_missing",20,2052986983));
}

/* {ET_ECF_OPTION_NAMES}.warning_manifest_array_type_name */

EIF_REFERENCE F44_515 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1806,RTMS_EX_H("manifest_array_type",19,1326410085));
}

/* {ET_ECF_OPTION_NAMES}.warning_obsolete_class_option_name */

EIF_REFERENCE F44_516 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1807,RTMS_EX_H("obsolete_class",14,1102600563));
}

/* {ET_ECF_OPTION_NAMES}.warning_obsolete_feature_option_name */

EIF_REFERENCE F44_517 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1808,RTMS_EX_H("obsolete_feature",16,995561829));
}

/* {ET_ECF_OPTION_NAMES}.warning_old_verbatim_strings_option_name */

EIF_REFERENCE F44_518 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1809,RTMS_EX_H("old_verbatim_strings",20,301586803));
}

/* {ET_ECF_OPTION_NAMES}.warning_once_in_generic_option_name */

EIF_REFERENCE F44_519 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1810,RTMS_EX_H("once_in_generic",15,384858723));
}

/* {ET_ECF_OPTION_NAMES}.warning_option_unknown_class_option_name */

EIF_REFERENCE F44_520 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1811,RTMS_EX_H("option_unknown_class",20,2049985907));
}

/* {ET_ECF_OPTION_NAMES}.warning_renaming_unknown_class_option_name */

EIF_REFERENCE F44_521 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1812,RTMS_EX_H("renaming_unknown_class",22,527017075));
}

/* {ET_ECF_OPTION_NAMES}.warning_same_uuid_option_name */

EIF_REFERENCE F44_522 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1813,RTMS_EX_H("same_uuid",9,1559839332));
}

/* {ET_ECF_OPTION_NAMES}.warning_syntax_option_name */

EIF_REFERENCE F44_523 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1814,RTMS_EX_H("syntax",6,2080149368));
}

/* {ET_ECF_OPTION_NAMES}.warning_unused_local_option_name */

EIF_REFERENCE F44_524 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1815,RTMS_EX_H("unused_local",12,2107775852));
}

/* {ET_ECF_OPTION_NAMES}.warning_vjrv_option_name */

EIF_REFERENCE F44_525 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1816,RTMS_EX_H("vjrv",4,1986687606));
}

/* {ET_ECF_OPTION_NAMES}.warning_vwab_option_name */

EIF_REFERENCE F44_526 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1817,RTMS_EX_H("vwab",4,1987535202));
}

/* {ET_ECF_OPTION_NAMES}.warning_vweq_option_name */

EIF_REFERENCE F44_527 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1818,RTMS_EX_H("vweq",4,1987536241));
}

/* {ET_ECF_OPTION_NAMES}.all_option_value */

EIF_REFERENCE F44_528 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1819,RTMS_EX_H("all",3,6384748));
}

/* {ET_ECF_OPTION_NAMES}.false_option_value */

EIF_REFERENCE F44_531 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1820,RTMS_EX_H("false",5,1635280741));
}

/* {ET_ECF_OPTION_NAMES}.mismatch_warning_option_value */

EIF_REFERENCE F44_534 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1821,RTMS_EX_H("mismatch_warning",16,1759222119));
}

/* {ET_ECF_OPTION_NAMES}.none_option_value */

EIF_REFERENCE F44_535 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1822,RTMS_EX_H("none",4,1852796517));
}

/* {ET_ECF_OPTION_NAMES}.obsolete_option_value */

EIF_REFERENCE F44_536 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1823,RTMS_EX_H("obsolete",8,2004093797));
}

/* {ET_ECF_OPTION_NAMES}.standard_option_value */

EIF_REFERENCE F44_538 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1824,RTMS_EX_H("standard",8,157435492));
}

/* {ET_ECF_OPTION_NAMES}.transitional_option_value */

EIF_REFERENCE F44_539 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1825,RTMS_EX_H("transitional",12,1290118508));
}

/* {ET_ECF_OPTION_NAMES}.true_option_value */

EIF_REFERENCE F44_540 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1826,RTMS_EX_H("true",4,1953658213));
}

/* {ET_ECF_OPTION_NAMES}.warning_option_value */

EIF_REFERENCE F44_541 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1827,RTMS_EX_H("warning",7,1809215079));
}

void EIF_Minit33 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
