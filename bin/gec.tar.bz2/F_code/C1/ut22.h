
#ifndef _C1_ut22_
#define _C1_ut22_

#ifdef __cplusplus
extern "C" {
#endif

extern void F26_275(EIF_REFERENCE, EIF_INTEGER_32);
extern void F26_278(EIF_REFERENCE);
extern void EIF_Minit22(void);

#ifdef __cplusplus
}
#endif

#endif
