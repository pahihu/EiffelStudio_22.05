/*
 * Code for class ET_SYSTEM_PROCESSOR_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et45.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_SYSTEM_PROCESSOR_FACTORY}.new_system_processor */
EIF_REFERENCE F68_874 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 1L))) {
		tb1 = (EIF_BOOLEAN) eif_builtin_PLATFORM_is_thread_capable__b;
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(1290, 0x01).id, 1290, _OBJSIZ_17_21_0_2_0_0_0_0_);
		F1291_12812(RTCW(tr1), arg1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTLNS(eif_new_type(1289, 0x01).id, 1289, _OBJSIZ_16_21_0_2_0_0_0_0_);
		F1290_12656(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

void EIF_Minit45 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
