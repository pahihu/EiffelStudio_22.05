
#ifndef _C1_lx3_
#define _C1_lx3_

#ifdef __cplusplus
extern "C" {
#endif

extern void F3_36(EIF_REFERENCE);
extern void EIF_Minit3(void);

#ifdef __cplusplus
}
#endif

#endif
