/*
 * Code for class XM_POSITION_TABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm17.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_POSITION_TABLE}.make */
void F21_247 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1512,0xFF01,245,0xFF01,1296,0xFF01,2009,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1513_13604(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_POSITION_TABLE}.has */
EIF_BOOLEAN F21_248 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10736[Dtype(RTCW(tr1))-1479])(tr1);
	F1333_13085(RTCW(loc1));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_3_1_);
		if (tb1) break;
		tr1 = F1411_13173(RTCW(loc1));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		if ((EIF_BOOLEAN)(tr1 == arg1)) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F1333_13088(RTCW(loc1));
		} else {
			F1333_13086(RTCW(loc1));
		}
	}
	RTLE;
	return Result;
}

/* {XM_POSITION_TABLE}.item */
EIF_REFERENCE F21_249 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc2);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10736[Dtype(RTCW(tr1))-1479])(tr1);
	F1333_13085(RTCW(loc1));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_3_1_);
		if (tb1) break;
		tr1 = F1411_13173(RTCW(loc1));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
		if ((EIF_BOOLEAN)(tr1 == arg1)) {
			tr1 = F1411_13173(RTCW(loc1));
			loc2 = *(EIF_REFERENCE *)(RTCW(tr1));
			F1333_13088(RTCW(loc1));
		} else {
			F1333_13086(RTCW(loc1));
		}
	}
	RTCT0("has", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc2;
	RTLE;
	return Result;
}

/* {XM_POSITION_TABLE}.put */
void F21_250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,245,0xFF01,1296,0xFF01,2009,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 245, _OBJSIZ_2_0_0_0_0_0_0_0_);
	}
	F246_2391(RTCW(loc1), arg1, arg2);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10795[Dtype(RTCW(tr1))-1512])(tr1, loc1);
	RTLE;
}

void EIF_Minit17 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
