
#ifndef _C1_et15_
#define _C1_et15_

#ifdef __cplusplus
extern "C" {
#endif

extern void F19_237(EIF_REFERENCE, EIF_REFERENCE);
extern void F19_242(EIF_REFERENCE, EIF_REFERENCE);
extern void F19_243(EIF_REFERENCE, EIF_REFERENCE);
extern void F19_244(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit15(void);

#ifdef __cplusplus
}
#endif

#endif
