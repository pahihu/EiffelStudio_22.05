
#ifndef _C1_is42_
#define _C1_is42_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F53_678(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F53_683(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F53_685(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F53_693(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit42(void);

#ifdef __cplusplus
}
#endif

#endif
