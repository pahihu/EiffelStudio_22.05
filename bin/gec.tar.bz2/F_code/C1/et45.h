
#ifndef _C1_et45_
#define _C1_et45_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F68_874(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit45(void);
extern void F1291_12812(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1290_12656(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
