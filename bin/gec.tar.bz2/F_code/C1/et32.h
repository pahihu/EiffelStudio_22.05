
#ifndef _C1_et32_
#define _C1_et32_

#ifdef __cplusplus
extern "C" {
#endif

extern void F43_483(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F43_491(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit32(void);

#ifdef __cplusplus
}
#endif

#endif
