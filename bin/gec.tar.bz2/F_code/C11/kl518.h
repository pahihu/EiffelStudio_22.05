
#ifndef _C11_kl518_
#define _C11_kl518_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F1207_10828_body(EIF_REFERENCE);
extern EIF_REFERENCE F1207_10828(EIF_REFERENCE);
extern void EIF_Minit518(void);

#ifdef __cplusplus
}
#endif

#endif
