/*
 * Code for class XM_EIFFEL_INPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm522.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_EIFFEL_INPUT_STREAM}.make_from_stream */
void F1211_10853 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1526,1121,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1184, 1).id);
	F1177_10174(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 6L);
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.is_valid_encoding */
EIF_BOOLEAN F1211_10854 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		Result = '\01';
		tb1 = '\01';
		tb2 = '\01';
		tr1 = RTOUCR(10,F1207_10828, (Current));
		tr2 = RTOUCR(3122,F1211_10858, (Current));
		tb3 = F1198_10706(RTCW(tr1), arg1, tr2);
		if (!tb3) {
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr2 = RTOUCR(3123,F1211_10857, (Current));
			tb3 = F1198_10706(RTCW(tr1), arg1, tr2);
			tb2 = tb3;
		}
		if (!tb2) {
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr2 = RTOUCR(3124,F1211_10859, (Current));
			tb2 = F1198_10706(RTCW(tr1), arg1, tr2);
			tb1 = tb2;
		}
		if (!tb1) {
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr2 = RTOUCR(3125,F1211_10860, (Current));
			tb1 = F1198_10706(RTCW(tr1), arg1, tr2);
			Result = tb1;
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.is_applicable_encoding */
EIF_BOOLEAN F1211_10855 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 6L))) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\01';
		tr1 = RTOUCR(10,F1207_10828, (Current));
		tr2 = RTOUCR(3122,F1211_10858, (Current));
		tb2 = F1198_10706(RTCW(tr1), arg1, tr2);
		if (!tb2) {
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr2 = RTOUCR(3123,F1211_10857, (Current));
			tb2 = F1198_10706(RTCW(tr1), arg1, tr2);
			tb1 = tb2;
		}
		if (tb1) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 2L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 1L))) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 3L)));
		} else {
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr2 = RTOUCR(3124,F1211_10859, (Current));
			tb1 = F1198_10706(RTCW(tr1), arg1, tr2);
			if (tb1) {
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_);
				ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L)) || (EIF_BOOLEAN)(ti4_2 == ((EIF_INTEGER_32) 1L)));
			} else {
				tr1 = RTOUCR(10,F1207_10828, (Current));
				tr2 = RTOUCR(3125,F1211_10860, (Current));
				tb1 = F1198_10706(RTCW(tr1), arg1, tr2);
				if (tb1) {
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_);
					ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_);
					RTLE;
					return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 4L)) || (EIF_BOOLEAN)(ti4_2 == ((EIF_INTEGER_32) 5L)));
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.set_encoding */
void F1211_10856 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOUCR(10,F1207_10828, (Current));
	tr2 = RTOUCR(3122,F1211_10858, (Current));
	tb1 = F1198_10706(RTCW(tr1), arg1, tr2);
	if (tb1) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	} else {
		tr1 = RTOUCR(10,F1207_10828, (Current));
		tr2 = RTOUCR(3125,F1211_10860, (Current));
		tb1 = F1198_10706(RTCW(tr1), arg1, tr2);
		if (tb1) {
		} else {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.encoding_us_ascii */

EIF_REFERENCE F1211_10857 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (3123,RTMS_EX_H("us-ascii",8,1951510633));
}

/* {XM_EIFFEL_INPUT_STREAM}.encoding_latin_1 */

EIF_REFERENCE F1211_10858 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (3122,RTMS_EX_H("iso-8859-1",10,1003358513));
}

/* {XM_EIFFEL_INPUT_STREAM}.encoding_utf_8 */

EIF_REFERENCE F1211_10859 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (3124,RTMS_EX_H("utf-8",5,1953751864));
}

/* {XM_EIFFEL_INPUT_STREAM}.encoding_utf_16 */

EIF_REFERENCE F1211_10860 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (3125,RTMS_EX_H("utf-16",6,1945159990));
}

/* {XM_EIFFEL_INPUT_STREAM}.read_character */
void F1211_10861 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 6L))) {
		F1211_10880(Current);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2236[Dtype(RTCW(tr1))-1210])(tr1);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			F1211_10879(Current);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current);
			F1527_13761(RTCW(tr1));
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2236[Dtype(RTCW(tr1))-1210])(tr1);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				F1211_10879(Current);
			}
		} else {
			F1211_10879(Current);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.read_string */
void F1211_10862 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(10,F1207_10828, (Current));
	F1198_10723(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	F1211_10861(Current);
	loc1 = (EIF_INTEGER_32) arg1;
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
			tb1 = F1211_10866(Current);
		}
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tc1 = F1211_10868(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(tr1))-1184])(tr1, tc1);
		F1211_10861(Current);
		loc1--;
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.read_to_string */
EIF_INTEGER_32 F1211_10863 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\01';
	if (!(EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 6L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 2L)))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		F1211_10861(Current);
		if ((EIF_BOOLEAN) !F1211_10866(Current)) {
			tc1 = F1211_10868(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5674[Dtype(RTCW(arg1))-829])(arg1, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &arg2);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 1L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8717[Dtype(RTCW(tr1))-1210])(tr1, arg1, arg2, arg3);
		} else {
			Result = F1201_10807(Current, arg1, arg2, arg3);
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.end_of_input */
EIF_BOOLEAN F1211_10866 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2236[Dtype(RTCW(tr1))-1210])(tr1);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.name */
EIF_REFERENCE F1211_10867 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2238[Dtype(RTCW(tr1))-1210])(tr1);
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.last_character */
EIF_CHARACTER_8 F1211_10868 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_0_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = F1527_13752(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2239[Dtype(RTCW(tr1))-1210])(tr1));
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_INPUT_STREAM}.last_string */
EIF_REFERENCE F1211_10869 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_2_);
}


/* {XM_EIFFEL_INPUT_STREAM}.noqueue_read_character */
void F1211_10879 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 1L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 2L)))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2230[Dtype(RTCW(tr1))-1210])(tr1);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 3L))) {
			F1211_10882(Current);
		} else {
			F1211_10881(Current);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.utf16_detect_read_character */
void F1211_10880 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2230[Dtype(RTCW(tr1))-1210])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2236[Dtype(RTCW(tr1))-1210])(tr1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2239[Dtype(RTCW(tr1))-1210])(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2230[Dtype(RTCW(tr1))-1210])(tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2236[Dtype(RTCW(tr1))-1210])(tr1);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc2 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2239[Dtype(RTCW(tr1))-1210])(tr1));
			tr1 = RTOUCR(3021,F367_3607, (Current));
			ti4_1 = (EIF_INTEGER_32) (loc1);
			ti4_2 = (EIF_INTEGER_32) (loc2);
			tb1 = F1189_10655(RTCW(tr1), ti4_1, ti4_2);
			if (tb1) {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
			} else {
				tr1 = RTOUCR(3021,F367_3607, (Current));
				ti4_1 = (EIF_INTEGER_32) (loc1);
				ti4_2 = (EIF_INTEGER_32) (loc2);
				tb1 = F1189_10656(RTCW(tr1), ti4_1, ti4_2);
				if (tb1) {
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
				} else {
					tb1 = '\0';
					ti4_1 = (EIF_INTEGER_32) (loc1);
					if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
						tb1 = (EIF_BOOLEAN)(loc2 == (EIF_CHARACTER_8) '<');
					}
					if (tb1) {
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
						tr1 = *(EIF_REFERENCE *)(Current);
						F1527_13758(RTCW(tr1), (EIF_CHARACTER_8) '<');
					} else {
						tb1 = '\0';
						if ((EIF_BOOLEAN)(loc1 == (EIF_CHARACTER_8) '<')) {
							ti4_1 = (EIF_INTEGER_32) (loc2);
							tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
						}
						if (tb1) {
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
							tr1 = *(EIF_REFERENCE *)(Current);
							F1527_13758(RTCW(tr1), (EIF_CHARACTER_8) '<');
						} else {
							tr1 = RTOUCR(2951,F426_5714, (Current));
							tb1 = F1199_10739(RTCW(tr1), loc1, loc2);
							if (tb1) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								(FUNCTION_CAST(void, (EIF_REFERENCE)) R2230[Dtype(RTCW(tr1))-1210])(tr1);
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2236[Dtype(RTCW(tr1))-1210])(tr1);
								if ((EIF_BOOLEAN) !tb1) {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
									loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2239[Dtype(RTCW(tr1))-1210])(tr1));
									tr1 = RTOUCR(2951,F426_5714, (Current));
									tb1 = F1199_10738(RTCW(tr1), loc1, loc2, loc3);
									if (tb1) {
									} else {
										tr1 = *(EIF_REFERENCE *)(Current);
										F1527_13758(RTCW(tr1), loc1);
										tr1 = *(EIF_REFERENCE *)(Current);
										F1527_13758(RTCW(tr1), loc2);
										tr1 = *(EIF_REFERENCE *)(Current);
										F1527_13758(RTCW(tr1), loc3);
									}
								} else {
									tr1 = *(EIF_REFERENCE *)(Current);
									F1527_13758(RTCW(tr1), loc1);
									tr1 = *(EIF_REFERENCE *)(Current);
									F1527_13758(RTCW(tr1), loc2);
								}
							} else {
								tr1 = *(EIF_REFERENCE *)(Current);
								F1527_13758(RTCW(tr1), loc1);
								tr1 = *(EIF_REFERENCE *)(Current);
								F1527_13758(RTCW(tr1), loc2);
							}
						}
					}
				}
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			F1527_13758(RTCW(tr1), loc1);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.utf16_read_character */
void F1211_10881 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2230[Dtype(RTCW(tr1))-1210])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2236[Dtype(RTCW(tr1))-1210])(tr1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2239[Dtype(RTCW(tr1))-1210])(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2230[Dtype(RTCW(tr1))-1210])(tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2236[Dtype(RTCW(tr1))-1210])(tr1);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc2 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2239[Dtype(RTCW(tr1))-1210])(tr1));
			loc3 = F1211_10884(Current, loc1, loc2);
			loc4 = F1211_10885(Current, loc1, loc2);
			tr1 = RTOUCR(3021,F367_3607, (Current));
			tb1 = F1189_10658(RTCW(tr1), loc3);
			if (tb1) {
				tr1 = RTOUCR(3021,F367_3607, (Current));
				tb1 = F1189_10659(RTCW(tr1), loc3);
				if (tb1) {
					tr1 = RTOUCR(3021,F367_3607, (Current));
					loc5 = F1189_10661(RTCW(tr1), loc3, loc4);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R2230[Dtype(RTCW(tr1))-1210])(tr1);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2236[Dtype(RTCW(tr1))-1210])(tr1);
					if ((EIF_BOOLEAN) !tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						loc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2239[Dtype(RTCW(tr1))-1210])(tr1));
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R2230[Dtype(RTCW(tr1))-1210])(tr1);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2236[Dtype(RTCW(tr1))-1210])(tr1);
						if ((EIF_BOOLEAN) !tb1) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							loc2 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2239[Dtype(RTCW(tr1))-1210])(tr1));
							loc3 = F1211_10884(Current, loc1, loc2);
							loc4 = F1211_10885(Current, loc1, loc2);
							tr1 = RTOUCR(3021,F367_3607, (Current));
							tb1 = F1189_10660(RTCW(tr1), loc3);
							if (tb1) {
								tr1 = RTOUCR(3021,F367_3607, (Current));
								tr2 = RTOUCR(3021,F367_3607, (Current));
								ti4_1 = F1189_10661(RTCW(tr2), loc3, loc4);
								ti4_1 = F1189_10662(RTCW(tr1), loc5, ti4_1);
								F1211_10883(Current, ti4_1);
							}
						}
					}
				}
			} else {
				F1211_10883(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 * ((EIF_INTEGER_32) 256L)) + loc4));
			}
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.latin1_read_character */
void F1211_10882 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2230[Dtype(RTCW(tr1))-1210])(tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2236[Dtype(RTCW(tr1))-1210])(tr1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2239[Dtype(RTCW(tr1))-1210])(tr1));
		ti4_1 = (EIF_INTEGER_32) (tc1);
		if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 128L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2239[Dtype(RTCW(tr1))-1210])(tr1));
			ti4_1 = (EIF_INTEGER_32) (tc1);
			F1211_10883(Current, ti4_1);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.append_character */
void F1211_10883 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc3 = RTOUCR(3126,F1211_10887, (Current));
	tr1 = RTOUCR(10,F1207_10828, (Current));
	F1198_10723(RTCW(tr1), loc3);
	tr1 = RTOUCR(2951,F426_5714, (Current));
	F1199_10765(RTCW(tr1), loc3, arg1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5908[Dtype(RTCW(loc3))-829])(loc3, loc1));
		F1527_13758(RTCW(tr1), tc1);
		loc1++;
	}
	RTLE;
}

/* {XM_EIFFEL_INPUT_STREAM}.most_significant */
EIF_INTEGER_32 F1211_10884 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 4L))) {
		ti4_1 = (EIF_INTEGER_32) (arg1);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		ti4_1 = (EIF_INTEGER_32) (arg2);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}/* NOTREACHED */
	
}

/* {XM_EIFFEL_INPUT_STREAM}.least_significant */
EIF_INTEGER_32 F1211_10885 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_0_0_0_) == ((EIF_INTEGER_32) 4L))) {
		ti4_1 = (EIF_INTEGER_32) (arg2);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	} else {
		ti4_1 = (EIF_INTEGER_32) (arg1);
		RTLE;
		return (EIF_INTEGER_32) ti4_1;
	}/* NOTREACHED */
	
}

/* {XM_EIFFEL_INPUT_STREAM}.utf8_buffer */
static EIF_REFERENCE F1211_10887_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(3126)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1184, 0x01).id, 1184, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1183_10471(RTCW(tr1), ((EIF_INTEGER_32) 6L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1211_10887 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(3126,F1211_10887_body,(Current));
}

void EIF_Minit522 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
