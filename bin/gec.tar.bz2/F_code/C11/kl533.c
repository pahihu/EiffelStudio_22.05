/*
 * Code for class KL_STDIN_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl533.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STDIN_FILE}.make */
void F1222_11020 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1184, 1).id);
	F1177_10174(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {KL_STDIN_FILE}.name */

EIF_REFERENCE F1222_11021 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (3016,RTMS_EX_H("stdin",5,1953620846));
}

/* {KL_STDIN_FILE}.last_character */
EIF_CHARACTER_8 F1222_11022 (EIF_REFERENCE Current)
{
	return *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
}


/* {KL_STDIN_FILE}.last_string */
EIF_REFERENCE F1222_11023 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {KL_STDIN_FILE}.end_of_file */
EIF_BOOLEAN F1222_11026 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_);
}


/* {KL_STDIN_FILE}.read_character */
void F1222_11027 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tc1 = *(EIF_CHARACTER_8 *)(RTCW(loc1)+ _CHROFF_1_0_);
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTOUCR(3017,F1222_11036, (Current));
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5737[Dtype(RTCW(tr1))-1261])(tr1);
		if (tb1) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			tr1 = RTOUCR(3017,F1222_11036, (Current));
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5391[Dtype(RTCW(tr1))-1261])(tr1);
			tr1 = RTOUCR(3017,F1222_11036, (Current));
			tc1 = *(EIF_CHARACTER_8 *)(RTCW(tr1) + O5331[Dtype(tr1)-437]);
			*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
			tr1 = RTOUCR(3017,F1222_11036, (Current));
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5737[Dtype(RTCW(tr1))-1261])(tr1);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) tb1;
		}
	}
	RTLE;
}

/* {KL_STDIN_FILE}.read_string */
void F1222_11029 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8303[Dtype(RTCW(tr1))-1180])(tr1);
	if ((EIF_BOOLEAN) (ti4_1 < arg1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F1185_10616(RTCW(tr1), arg1);
	}
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) == NULL)) {
		tr1 = RTOUCR(3017,F1222_11036, (Current));
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5737[Dtype(RTCW(tr1))-1261])(tr1);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F1185_10633(RTCW(tr1), arg1);
			tr1 = RTOUCR(3017,F1222_11036, (Current));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5404[Dtype(RTCW(tr1))-1261])(tr1, arg1);
			tr1 = RTOUCR(3017,F1222_11036, (Current));
			loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + O5332[Dtype(tr1)-437]);
			tb1 = F747_6470(RTCW(loc2));
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
				F1185_10559(RTCW(tr1), loc2, ((EIF_INTEGER_32) 1L), ti4_1, ((EIF_INTEGER_32) 1L));
				loc1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F1179_10272(RTCW(tr1));
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F1185_10633(RTCW(tr1), loc1);
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			F1185_10633(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F1185_10633(RTCW(tr1), arg1);
		loc1 = F1222_11032(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_), ((EIF_INTEGER_32) 1L), arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F1185_10633(RTCW(tr1), loc1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {KL_STDIN_FILE}.read_to_string */
EIF_INTEGER_32 F1222_11032 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLIU(7);
	
	RTGC;
	loc2 = (EIF_INTEGER_32) arg2;
	loc7 = *(EIF_REFERENCE *)(Current);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == arg3) || (EIF_BOOLEAN)(loc7 == NULL))) break;
		loc1++;
		tc1 = *(EIF_CHARACTER_8 *)(RTCW(loc7)+ _CHROFF_1_0_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5674[Dtype(RTCW(arg1))-829])(arg1, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &loc2);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc7));
		loc7 = (EIF_REFERENCE) tr1;
		loc2++;
	}
	RTAR(Current, loc7);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc7;
	if ((EIF_BOOLEAN) (loc1 < arg3)) {
		tr1 = RTOUCR(3017,F1222_11036, (Current));
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5737[Dtype(RTCW(tr1))-1261])(tr1);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = RTOUCR(556,F1187_10637, (Current));
			tr2 = RTOUCR(3018,F1222_11035, (Current));
			tb1 = F46_577(RTCW(tr1), arg1, tr2);
			if (tb1) {
				tr1 = RTOUCR(3017,F1222_11036, (Current));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5404[Dtype(RTCW(tr1))-1261])(tr1, (EIF_INTEGER_32) (arg3 - loc1));
				tr1 = RTOUCR(3017,F1222_11036, (Current));
				loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + O5332[Dtype(tr1)-437]);
				tb1 = F747_6470(RTCW(loc5));
				if ((EIF_BOOLEAN) !tb1) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
					F1185_10559(RTCW(arg1), loc5, ((EIF_INTEGER_32) 1L), ti4_1, loc2);
					F1179_10272(RTCW(arg1));
				}
				Result = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
				Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + Result);
			} else {
				loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg3 - loc1);
				loc6 = RTLNS(eif_new_type(1184, 0x01).id, 1184, _OBJSIZ_1_1_0_3_0_0_0_0_);
				F1183_10471(RTCW(loc6), loc4);
				F1185_10633(RTCW(loc6), loc4);
				tr1 = RTOUCR(3017,F1222_11036, (Current));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5404[Dtype(RTCW(tr1))-1261])(tr1, loc4);
				tr1 = RTOUCR(3017,F1222_11036, (Current));
				loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + O5332[Dtype(tr1)-437]);
				tb1 = F747_6470(RTCW(loc5));
				if ((EIF_BOOLEAN) !tb1) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
					F1185_10559(RTCW(loc6), loc5, ((EIF_INTEGER_32) 1L), ti4_1, ((EIF_INTEGER_32) 1L));
					F1179_10272(RTCW(loc6));
				}
				loc4 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_1_0_2_);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc3 > loc4)) break;
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5908[Dtype(RTCW(loc6))-829])(loc6, loc3));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5674[Dtype(RTCW(arg1))-829])(arg1, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &loc2);
					loc2++;
					loc3++;
				}
				Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + loc4);
			}
		} else {
			Result = (EIF_INTEGER_32) loc1;
		}
		tr1 = RTOUCR(3017,F1222_11036, (Current));
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5737[Dtype(RTCW(tr1))-1261])(tr1);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) tb1;
	} else {
		RTLE;
		return (EIF_INTEGER_32) loc1;
	}
	RTLE;
	return Result;
}

/* {KL_STDIN_FILE}.dummy_string */

EIF_REFERENCE F1222_11035 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (3018,RTMS_EX_H("",0,0));
}

/* {KL_STDIN_FILE}.console */
static EIF_REFERENCE F1222_11036_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(3017)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTOUCR(545,F66_787, (RTCV(RTOUCR(14,F1_24, (Current)))));
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1222_11036 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(3017,F1222_11036_body,(Current));
}

void EIF_Minit533 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
