
#ifndef _C11_ki546_
#define _C11_ki546_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1235_11602(EIF_REFERENCE, EIF_REFERENCE);
extern void F1235_11603(EIF_REFERENCE);
extern void EIF_Minit546(void);
extern char *(*R9313[])();
extern char *(*R9333[])();

#ifdef __cplusplus
}
#endif

#endif
