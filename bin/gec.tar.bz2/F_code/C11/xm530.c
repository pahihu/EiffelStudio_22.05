/*
 * Code for class XM_EIFFEL_PARSER_NAME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm530.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_EIFFEL_PARSER_NAME}.make_namespaces */
void F1219_10976 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1219_10977(Current);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {XM_EIFFEL_PARSER_NAME}.make_no_namespaces */
void F1219_10977 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = RTMS_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = F398_5287(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_EIFFEL_PARSER_NAME}.is_namespace_name */
EIF_BOOLEAN F1219_10981 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 2L))) {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
			tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_NAME}.ns_prefix */
EIF_REFERENCE F1219_10985 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_)) {
		tb1 = F1219_10981(Current);
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current);
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {XM_EIFFEL_PARSER_NAME}.local_part */
EIF_REFERENCE F1219_10986 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_)) {
		RTLE;
		return (EIF_REFERENCE) F1219_10989(Current);
	} else {
		tr1 = RTOUCR(10,F1207_10828, (Current));
		Result = F1198_10712(RTCW(tr1), *(EIF_REFERENCE *)(Current));
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) > ((EIF_INTEGER_32) 1L))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(Result))-1184])(Result, (EIF_CHARACTER_8) ':');
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr1 = F1198_10713(RTCW(tr1), Result, *(EIF_REFERENCE *)(Current + _REFACS_1_));
			Result = (EIF_REFERENCE) tr1;
			if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) > ((EIF_INTEGER_32) 2L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10736[Dtype(RTCW(tr1))-1479])(tr1);
				F1333_13085(RTCW(loc1));
				for (;;) {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5417[Dtype(RTCW(loc1))-539])(loc1);
					if (tb1) break;
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(Result))-1184])(Result, (EIF_CHARACTER_8) ':');
					tr1 = RTOUCR(10,F1207_10828, (Current));
					tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5416[Dtype(RTCW(loc1))-539])(loc1);
					tr1 = F1198_10713(RTCW(tr1), Result, tr2);
					Result = (EIF_REFERENCE) tr1;
					F1333_13086(RTCW(loc1));
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_NAME}.item */
EIF_REFERENCE F1219_10987 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current);
	} else {
		if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 2L))) {
			RTLE;
			return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_1_);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R10820[Dtype(RTCW(tr1))-1512])(tr1, (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 2L)));
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_NAME}.last */
EIF_REFERENCE F1219_10989 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 1L))) {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 2L))) {
			RTLE;
			return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_1_);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10773[Dtype(RTCW(tr1))-1512])(tr1);
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_NAME}.hash_code */
EIF_INTEGER_32 F1219_10990 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = F1219_10987(Current, loc1);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7255[Dtype(RTCW(tr1))-1052])(tr1);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result / ((EIF_INTEGER_32) 3L)) + (EIF_INTEGER_32) (ti4_1 / ((EIF_INTEGER_32) 3L)));
		loc1++;
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_NAME}.can_force_last */
EIF_BOOLEAN F1219_10992 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_)) {
		Result = '\0';
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) < ((EIF_INTEGER_32) 2L))) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			Result = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
		}
	} else {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_NAME}.force_last */
void F1219_10993 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_))++;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 1L))) {
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 2L))) {
			RTAR(Current, arg1);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
		} else {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 3L))) {
				tr1 = F398_5287(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R10796[Dtype(RTCW(tr1))-1512])(tr1, arg1);
		}
	}
	RTLE;
}

/* {XM_EIFFEL_PARSER_NAME}.is_equal */
EIF_BOOLEAN F1219_10995 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_1_0_0_);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ti4_1)) {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 0L))) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 1L))) {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
				Result = F398_5285(Current, *(EIF_REFERENCE *)(Current), tr1);
			} else {
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_) == ((EIF_INTEGER_32) 2L))) {
					Result = '\0';
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
					if (F398_5285(Current, *(EIF_REFERENCE *)(Current), tr1)) {
						tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
						Result = F398_5285(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_), tr1);
					}
				} else {
					Result = '\0';
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
					if (F398_5285(Current, *(EIF_REFERENCE *)(Current), tr1)) {
						tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
						Result = F398_5285(Current, *(EIF_REFERENCE *)(Current + _REFACS_1_), tr1);
					}
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10736[Dtype(RTCW(tr1))-1479])(tr1);
					F1333_13085(RTCW(loc1));
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
					loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10736[Dtype(RTCW(tr1))-1479])(tr1);
					F1333_13085(RTCW(loc2));
					for (;;) {
						tb1 = '\01';
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5417[Dtype(RTCW(loc1))-539])(loc1);
						if (!tb2) {
							tb1 = (EIF_BOOLEAN) !Result;
						}
						if (tb1) break;
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5416[Dtype(RTCW(loc1))-539])(loc1);
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5416[Dtype(RTCW(loc2))-539])(loc2);
						Result = F398_5285(Current, tr1, tr2);
						F1333_13086(RTCW(loc1));
						F1333_13086(RTCW(loc2));
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {XM_EIFFEL_PARSER_NAME}.out */
EIF_REFERENCE F1219_10996 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_1_0_0_);
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		tr1 = RTOUCR(10,F1207_10828, (Current));
		tr2 = F1219_10987(Current, ((EIF_INTEGER_32) 1L));
		Result = F1198_10712(RTCW(tr1), tr2);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr2 = F1219_10987(Current, loc1);
			tr1 = F1198_10713(RTCW(tr1), Result, tr2);
			Result = (EIF_REFERENCE) tr1;
			loc1++;
		}
	} else {
		Result = RTMS_EX_H("",0,0);
	}
	RTLE;
	return Result;
}

void EIF_Minit530 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
