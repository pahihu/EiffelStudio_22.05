/*
 * Code for class UC_UTF8_ROUTINES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uc510.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UC_UTF8_ROUTINES}.valid_utf8 */
EIF_BOOLEAN F1199_10731 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	Result = F1199_10732(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.valid_utf8_substring */
EIF_BOOLEAN F1199_10732 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc6 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc7 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc1 = (EIF_INTEGER_32) arg2;
	loc2 = (EIF_INTEGER_32) arg3;
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc7 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5908[Dtype(RTCW(arg1))-829])(arg1, loc1));
		if (F1199_10735(Current, loc7)) {
			loc4 = F1199_10750(Current, loc7);
			if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 1L))) {
				loc1++;
			} else {
				loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc4) - ((EIF_INTEGER_32) 1L));
				if ((EIF_BOOLEAN) (loc3 > loc2)) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				} else {
					loc5 = F1199_10744(Current, loc7);
					loc1++;
					loc6 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5908[Dtype(RTCW(arg1))-829])(arg1, loc1));
					if ((EIF_BOOLEAN) !F1199_10737(Current, loc6, loc7)) {
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					} else {
						ti4_1 = F1199_10745(Current, loc6);
						loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 * ((EIF_INTEGER_32) 64L)) + ti4_1);
						switch (loc4) {
							case 2L:
								if ((EIF_BOOLEAN) (loc5 <= ((EIF_INTEGER_32) 127L))) {
									Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								}
								break;
							case 3L:
								if ((EIF_BOOLEAN) (loc5 <= ((EIF_INTEGER_32) 31L))) {
									Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								}
								break;
							case 4L:
								if ((EIF_BOOLEAN) (loc5 <= ((EIF_INTEGER_32) 15L))) {
									Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								}
								break;
							default:
								RTEC(EN_WHEN);
						}
						if (Result) {
							loc1++;
							for (;;) {
								if ((EIF_BOOLEAN) (loc1 > loc3)) break;
								tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5908[Dtype(RTCW(arg1))-829])(arg1, loc1));
								if (F1199_10736(Current, tc1)) {
									loc1++;
								} else {
									Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
								}
							}
						}
					}
				}
			}
		} else {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		}
	}
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.is_string_8 */
EIF_BOOLEAN F1199_10733 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5908[Dtype(RTCW(arg1))-829])(arg1, loc1));
		loc3 = F1199_10750(Current, tc1);
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 1L))) {
		} else {
			if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 2L))) {
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5908[Dtype(RTCW(arg1))-829])(arg1, loc1));
				tc2 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5908[Dtype(RTCW(arg1))-829])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L))));
				if ((EIF_BOOLEAN) (F1199_10746(Current, tc1, tc2) > ((EIF_NATURAL_32) 255U))) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				}
			} else {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
			}
		}
		loc1 += loc3;
	}
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.is_string_32 */
EIF_BOOLEAN F1199_10734 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {UC_UTF8_ROUTINES}.is_encoded_first_byte */
EIF_BOOLEAN F1199_10735 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '') || (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_CHARACTER_8) '\302' <= arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\364')));
}

/* {UC_UTF8_ROUTINES}.is_encoded_next_byte */
EIF_BOOLEAN F1199_10736 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_CHARACTER_8) '' < arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\277'));
}

/* {UC_UTF8_ROUTINES}.is_encoded_second_byte */
EIF_BOOLEAN F1199_10737 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 == (EIF_CHARACTER_8) '\340')) {
		return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_CHARACTER_8) '\237' < arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\277'));
	} else {
		if ((EIF_BOOLEAN)(arg2 == (EIF_CHARACTER_8) '\355')) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_CHARACTER_8) '' < arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\237'));
		} else {
			if ((EIF_BOOLEAN)(arg2 == (EIF_CHARACTER_8) '\360')) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_CHARACTER_8) '\217' < arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\277'));
			} else {
				if ((EIF_BOOLEAN)(arg2 == (EIF_CHARACTER_8) '\364')) {
					return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_CHARACTER_8) '' < arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\217'));
				} else {
					return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_CHARACTER_8) '' < arg1) && (EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\277'));
				}
			}
		}
	}
	return Result;
}

/* {UC_UTF8_ROUTINES}.is_endian_detection_character */
EIF_BOOLEAN F1199_10738 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_CHARACTER_8 arg2, EIF_CHARACTER_8 arg3)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	if (F1199_10739(Current, arg1, arg2)) {
		Result = (EIF_BOOLEAN)(arg3 == (EIF_CHARACTER_8) '\277');
	}
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.is_endian_detection_character_start */
EIF_BOOLEAN F1199_10739 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) '\357') && (EIF_BOOLEAN)(arg2 == (EIF_CHARACTER_8) '\273'));
}

/* {UC_UTF8_ROUTINES}.utf8_bom */

EIF_REFERENCE F1199_10742 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (777,RTMS_EX_H("\357\273\277",3,15711167));
}

/* {UC_UTF8_ROUTINES}.encoded_first_value */
EIF_INTEGER_32 F1199_10744 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	Result = (EIF_INTEGER_32) (arg1);
	if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '')) {
	} else {
		if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\337')) {
			Result %= ((EIF_INTEGER_32) 32L);
		} else {
			if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\357')) {
				Result %= ((EIF_INTEGER_32) 16L);
			} else {
				if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\364')) {
					return (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 8L));
				}
			}
		}
	}
	return Result;
}

/* {UC_UTF8_ROUTINES}.encoded_next_value */
EIF_INTEGER_32 F1199_10745 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	Result = (EIF_INTEGER_32) (arg1);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 64L));
	return Result;
}

/* {UC_UTF8_ROUTINES}.two_byte_character_code */
EIF_NATURAL_32 F1199_10746 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	RTGC;
	tu4_1 = (EIF_NATURAL_32) arg1;
	tu4_1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 31L));
	tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 6L));
	tu4_2 = (EIF_NATURAL_32) arg2;
	tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
	Result = eif_bit_or(tu4_1,tu4_2);
	return Result;
}

/* {UC_UTF8_ROUTINES}.three_byte_character_code */
EIF_NATURAL_32 F1199_10747 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_CHARACTER_8 arg2, EIF_CHARACTER_8 arg3)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	RTGC;
	tu4_1 = (EIF_NATURAL_32) arg1;
	tu4_1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 15L));
	tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 12L));
	tu4_2 = (EIF_NATURAL_32) arg2;
	tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
	tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 6L));
	tu4_1 = eif_bit_or(tu4_1,tu4_2);
	tu4_2 = (EIF_NATURAL_32) arg3;
	tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
	Result = eif_bit_or(tu4_1,tu4_2);
	return Result;
}

/* {UC_UTF8_ROUTINES}.four_byte_character_code */
EIF_NATURAL_32 F1199_10748 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_CHARACTER_8 arg2, EIF_CHARACTER_8 arg3, EIF_CHARACTER_8 arg4)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	RTGC;
	tu4_1 = (EIF_NATURAL_32) arg1;
	tu4_1 = eif_bit_and(tu4_1,(EIF_NATURAL_32) ((EIF_INTEGER_32) 7L));
	tu4_1 = eif_bit_shift_left(tu4_1,((EIF_INTEGER_32) 18L));
	tu4_2 = (EIF_NATURAL_32) arg2;
	tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
	tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 12L));
	tu4_1 = eif_bit_or(tu4_1,tu4_2);
	tu4_2 = (EIF_NATURAL_32) arg3;
	tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
	tu4_2 = eif_bit_shift_left(tu4_2,((EIF_INTEGER_32) 6L));
	tu4_1 = eif_bit_or(tu4_1,tu4_2);
	tu4_2 = (EIF_NATURAL_32) arg4;
	tu4_2 = eif_bit_and(tu4_2,(EIF_NATURAL_32) ((EIF_INTEGER_32) 63L));
	Result = eif_bit_or(tu4_1,tu4_2);
	return Result;
}

/* {UC_UTF8_ROUTINES}.encoded_byte_count */
EIF_INTEGER_32 F1199_10750 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '')) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\337')) {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		} else {
			if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '\357')) {
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			} else {
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
			}
		}
	}
	return Result;
}

/* {UC_UTF8_ROUTINES}.substring_byte_count */
EIF_INTEGER_32 F1199_10752 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg2 <= arg3)) {
		tb1 = '\0';
		tr1 = RTOUCR(556,F1187_10637, (Current));
		tr2 = RTOUCR(778,F1199_10789, (Current));
		tb2 = F46_577(RTCW(tr1), arg1, tr2);
		if (tb2) {
			loc4 = arg1;
			loc4 = RTRV(eif_new_type(1184, 0x01),loc4);
			tb1 = EIF_TEST(loc4);
		}
		if (tb1) {
			loc3 = (EIF_INTEGER_32) arg2;
			for (;;) {
				if ((EIF_BOOLEAN) (loc3 > arg3)) break;
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5908[Dtype(loc4)-829])(loc4, loc3));
				Result += F1199_10754(Current, tc1);
				loc3++;
			}
		} else {
			tb1 = '\0';
			tr1 = RTOUCR(556,F1187_10637, (Current));
			tr2 = RTOUCR(779,F1199_10790, (Current));
			tb2 = F46_577(RTCW(tr1), arg1, tr2);
			if (tb2) {
				loc5 = arg1;
				loc5 = RTRV(eif_new_type(2144, 0x01),loc5);
				tb1 = EIF_TEST(loc5);
			}
			if (tb1) {
				tb1 = '\0';
				if ((EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 1L))) {
					ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
					tb1 = (EIF_BOOLEAN)(arg3 == ti4_1);
				}
				if (tb1) {
					Result = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_3_);
				} else {
					loc1 = F2145_27070(loc5, arg2);
					ti4_1 = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_2_);
					if ((EIF_BOOLEAN)(arg3 == ti4_1)) {
						Result = *(EIF_INTEGER_32 *)(loc5+ _LNGOFF_1_1_0_3_);
						Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result - loc1) + ((EIF_INTEGER_32) 1L));
					} else {
						loc2 = F2145_27069(loc5, loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L)));
						Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - loc1);
					}
				}
			} else {
				loc6 = arg1;
				loc6 = RTRV(eif_new_type(2145, 0x01),loc6);
				if (EIF_TEST(loc6)) {
					tb1 = '\0';
					if ((EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 1L))) {
						ti4_1 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_1_1_0_2_);
						tb1 = (EIF_BOOLEAN)(arg3 == ti4_1);
					}
					if (tb1) {
						Result = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_1_1_0_3_);
						RTLE;
						return (EIF_INTEGER_32) Result;
					} else {
						loc1 = F2145_27070(loc6, arg2);
						ti4_1 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_1_1_0_2_);
						if ((EIF_BOOLEAN)(arg3 == ti4_1)) {
							Result = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_1_1_0_3_);
							Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result - loc1) + ((EIF_INTEGER_32) 1L));
						} else {
							loc2 = F2145_27069(loc6, loc1, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L)));
							RTLE;
							return (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - loc1);
						}
					}
				} else {
					loc3 = (EIF_INTEGER_32) arg2;
					for (;;) {
						if ((EIF_BOOLEAN) (loc3 > arg3)) break;
						tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8266[Dtype(RTCW(arg1))-1180])(arg1, loc3);
						Result += F1199_10755(Current, tw1);
						loc3++;
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.character_byte_count */
EIF_INTEGER_32 F1199_10753 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F1199_10754(Current, arg1);
}

/* {UC_UTF8_ROUTINES}.character_8_byte_count */
EIF_INTEGER_32 F1199_10754 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '')) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	}/* NOTREACHED */
	
}

/* {UC_UTF8_ROUTINES}.character_32_byte_count */
EIF_INTEGER_32 F1199_10755 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = (EIF_NATURAL_32) arg1;
	Result = F1199_10757(Current, tu4_1);
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.code_byte_count */
EIF_INTEGER_32 F1199_10756 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 1114111L))) {
		tu4_1 = (EIF_NATURAL_32) arg1;
		Result = F1199_10757(Current, tu4_1);
	} else {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.natural_32_code_byte_count */
EIF_INTEGER_32 F1199_10757 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 128U))) {
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		if ((EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 2048U))) {
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		} else {
			if ((EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 55296U))) {
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
			} else {
				if ((EIF_BOOLEAN) (arg1 <= ((EIF_NATURAL_32) 57343U))) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				} else {
					if ((EIF_BOOLEAN) (arg1 < ((EIF_NATURAL_32) 65536U))) {
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
					} else {
						if ((EIF_BOOLEAN) (arg1 <= ((EIF_NATURAL_32) 1114111U))) {
							return (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
						} else {
							return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						}
					}
				}
			}
		}
	}
	return Result;
}

/* {UC_UTF8_ROUTINES}.unicode_character_count */
EIF_INTEGER_32 F1199_10758 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	Result = F1199_10759(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.unicode_substring_character_count */
EIF_INTEGER_32 F1199_10759 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc2 = (EIF_INTEGER_32) arg3;
	loc1 = (EIF_INTEGER_32) arg2;
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		Result++;
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5908[Dtype(RTCW(arg1))-829])(arg1, loc1));
		loc1 += F1199_10750(Current, tc1);
	}
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.string_to_utf8 */
EIF_REFERENCE F1199_10760 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8302[Dtype(RTCW(arg1))-1180])(arg1);
	Result = F1199_10761(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.substring_to_utf8 */
EIF_REFERENCE F1199_10761 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1184, 0x01).id, 1184, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = F1199_10752(Current, arg1, arg2, arg3);
	F1183_10471(RTCW(Result), ti4_1);
	F1199_10764(Current, Result, arg1, arg2, arg3);
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.to_utf8 */
EIF_REFERENCE F1199_10762 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	loc3 = arg1;
	loc3 = RTRV(eif_new_type(2144, 0x01),loc3);
	if (EIF_TEST(loc3)) {
		tr1 = F2145_27056(loc3);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		Result = RTLNS(eif_new_type(1184, 0x01).id, 1184, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1183_10471(RTCW(Result), loc2);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8477[Dtype(RTCW(arg1))-1184])(arg1, loc1);
			F1199_10765(Current, Result, ti4_1);
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {UC_UTF8_ROUTINES}.append_substring_to_utf8 */
void F1199_10764 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg3 <= arg4)) {
		loc1 = (EIF_INTEGER_32) arg3;
		loc2 = (EIF_INTEGER_32) arg4;
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R8265[Dtype(RTCW(arg2))-1180])(arg2, loc1);
			F1199_10766(Current, arg1, tu4_1);
			loc1++;
		}
	}
	RTLE;
}

/* {UC_UTF8_ROUTINES}.append_code_to_utf8 */
void F1199_10765 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tu4_1 = (EIF_NATURAL_32) arg2;
	F1199_10766(Current, arg1, tu4_1);
	RTLE;
}

/* {UC_UTF8_ROUTINES}.append_natural_32_code_to_utf8 */
void F1199_10766 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_32 arg2)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg2 < ((EIF_NATURAL_32) 128U))) {
		tc1 = (EIF_CHARACTER_8) arg2;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(arg1))-1184])(arg1, tc1);
	} else {
		if ((EIF_BOOLEAN) (arg2 < ((EIF_NATURAL_32) 2048U))) {
			loc4 = (EIF_NATURAL_32) arg2;
			loc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
			loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
			tc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) (loc4 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 192L)));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(arg1))-1184])(arg1, tc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(arg1))-1184])(arg1, loc1);
		} else {
			if ((EIF_BOOLEAN) (arg2 < ((EIF_NATURAL_32) 65536U))) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg2 >= ((EIF_NATURAL_32) 55296U)) && (EIF_BOOLEAN) (arg2 <= ((EIF_NATURAL_32) 57343U)))) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(arg1))-1184])(arg1, (EIF_CHARACTER_8) '\377');
				} else {
					loc4 = (EIF_NATURAL_32) arg2;
					loc2 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					loc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					tc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) (loc4 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 224L)));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(arg1))-1184])(arg1, tc1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(arg1))-1184])(arg1, loc1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(arg1))-1184])(arg1, loc2);
				}
			} else {
				if ((EIF_BOOLEAN) (arg2 <= ((EIF_NATURAL_32) 1114111U))) {
					loc4 = (EIF_NATURAL_32) arg2;
					loc3 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					loc2 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					loc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (loc4 % (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L)) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 128L)));
					loc4 /= (EIF_NATURAL_32) ((EIF_INTEGER_32) 64L);
					tc1 = (EIF_CHARACTER_8) ((EIF_NATURAL_32) (loc4 + (EIF_NATURAL_32) ((EIF_INTEGER_32) 240L)));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(arg1))-1184])(arg1, tc1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(arg1))-1184])(arg1, loc1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(arg1))-1184])(arg1, loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(arg1))-1184])(arg1, loc3);
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(arg1))-1184])(arg1, (EIF_CHARACTER_8) '\377');
				}
			}
		}
	}
	RTLE;
}

/* {UC_UTF8_ROUTINES}.dummy_string */

EIF_REFERENCE F1199_10789 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (778,RTMS_EX_H("",0,0));
}

/* {UC_UTF8_ROUTINES}.dummy_uc_string */
static EIF_REFERENCE F1199_10790_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(779)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(2144, 0x01).id, 2144, _OBJSIZ_1_1_0_6_0_0_0_0_);
	F2145_26966(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1199_10790 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(779,F1199_10790_body,(Current));
}

void EIF_Minit510 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
