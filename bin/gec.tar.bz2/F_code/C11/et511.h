
#ifndef _C11_et511_
#define _C11_et511_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1200_10791(EIF_REFERENCE);
extern EIF_BOOLEAN F1200_10792(EIF_REFERENCE);
extern void F1200_10800(EIF_REFERENCE);
extern void F1200_10801(EIF_REFERENCE);
extern void F1200_10802(EIF_REFERENCE);
extern EIF_REFERENCE F1200_10803(EIF_REFERENCE);
extern EIF_REFERENCE F1200_10804(EIF_REFERENCE);
extern void EIF_Minit511(void);
extern long O8708[];
extern long O8709[];

#ifdef __cplusplus
}
#endif

#endif
