/*
 * Code for class XM_NAMESPACE_RESOLVER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm526.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_NAMESPACE_RESOLVER}.initialize */
void F1215_10930 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(2048, 1).id);
	F2049_21914(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F1215_10946(Current);
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.on_finish */
void F1215_10931 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2633[Dtype(RTCW(tr1))-273])(tr1);
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.on_start */
void F1215_10932 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1215_10930(Current);
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R2632[Dtype(RTCW(tr1))-273])(tr1);
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.on_start_tag */
void F1215_10935 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F2049_21922(RTCW(tr1));
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg3;
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.on_attribute */
void F1215_10936 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,arg3);
	RTLR(3,tr1);
	RTLR(4,arg4);
	RTLIU(5);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN) !F273_3071(Current, arg2)) {
		tb1 = F1215_10941(Current, arg3);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F2049_21915(RTCW(tr1), arg4);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_)) {
			F1215_10947(Current, arg2, arg3, arg4);
		}
	} else {
		tb1 = '\0';
		if ((EIF_BOOLEAN)(arg2 != NULL)) {
			tb1 = F1215_10941(Current, arg2);
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tb1 = F2049_21918(RTCW(tr1), arg2);
			if (tb1) {
				tr1 = RTOUCR(3111,F1215_10954, (Current));
				F275_3093(Current, tr1);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F2049_21916(RTCW(tr1), arg4, arg3);
			}
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_7_0_)) {
				F1215_10947(Current, arg2, arg3, arg4);
			}
		} else {
			F1215_10947(Current, arg2, arg3, arg4);
		}
	}
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.on_start_tag_finish */
void F1215_10937 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,tr2);
	RTLR(5,loc1);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	RTCT0("attached element_local_part as l_element_local_part", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		tb1 = F273_3071(Current, loc3);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tb1 = F2049_21919(RTCW(tr1), loc3);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr2 = F2049_21921(RTCW(tr2), loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2638[Dtype(RTCW(tr1))-273])(tr1, tr2, loc3, loc2);
			F1215_10939(Current);
		} else {
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr2 = RTOUCR(3112,F1215_10953, (Current));
			loc1 = F1198_10712(RTCW(tr1), tr2);
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr2 = RTMS_EX_H(" in tag <",9,992440636);
			tr1 = F1198_10713(RTCW(tr1), loc1, tr2);
			loc1 = (EIF_REFERENCE) tr1;
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr1 = F1198_10713(RTCW(tr1), loc1, loc3);
			loc1 = (EIF_REFERENCE) tr1;
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr2 = RTMS_EX_H(":",1,58);
			tr1 = F1198_10713(RTCW(tr1), loc1, tr2);
			loc1 = (EIF_REFERENCE) tr1;
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr1 = F1198_10713(RTCW(tr1), loc1, loc2);
			loc1 = (EIF_REFERENCE) tr1;
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr2 = RTMS_EX_H(">",1,62);
			tr1 = F1198_10713(RTCW(tr1), loc1, tr2);
			loc1 = (EIF_REFERENCE) tr1;
			F275_3093(Current, loc1);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = F2049_21920(RTCW(tr2));
		tr3 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2638[Dtype(RTCW(tr1))-273])(tr1, tr2, tr3, loc2);
		F1215_10939(Current);
	}
	F275_3098(Current);
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.on_end_tag */
void F1215_10938 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		tb1 = F273_3071(Current, arg2);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F2049_21921(RTCW(tr1), arg2);
		F275_3099(Current, tr1, arg2, arg3);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F2049_21920(RTCW(tr1));
		F275_3099(Current, tr1, arg2, arg3);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F2049_21923(RTCW(tr1));
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.on_delayed_attributes */
void F1215_10939 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTGC;
	for (;;) {
		if (F1215_10949(Current)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc1 = F1526_13752(RTCW(tr1));
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb1 = F273_3071(Current, loc1);
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tb1 = F2049_21919(RTCW(tr1), loc1);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current);
				tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr2 = F2049_21921(RTCW(tr2), loc1);
				tr3 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
				tr3 = F1526_13752(RTCW(tr3));
				tr4 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
				tr4 = F1526_13752(RTCW(tr4));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2639[Dtype(RTCW(tr1))-273])(tr1, tr2, loc1, tr3, tr4);
			} else {
				if (F1215_10942(Current, loc1)) {
					tr1 = *(EIF_REFERENCE *)(Current);
					tr2 = RTOUCR(3109,F458_6126, (Current));
					tr3 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
					tr3 = F1526_13752(RTCW(tr3));
					tr4 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
					tr4 = F1526_13752(RTCW(tr4));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2639[Dtype(RTCW(tr1))-273])(tr1, tr2, loc1, tr3, tr4);
				} else {
					if (F1215_10941(Current, loc1)) {
						tr1 = *(EIF_REFERENCE *)(Current);
						tr2 = RTOUCR(3110,F458_6127, (Current));
						tr3 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
						tr3 = F1526_13752(RTCW(tr3));
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
						tr4 = F1526_13752(RTCW(tr4));
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2639[Dtype(RTCW(tr1))-273])(tr1, tr2, loc1, tr3, tr4);
					} else {
						tr1 = RTOUCR(3112,F1215_10953, (Current));
						F275_3093(Current, tr1);
					}
				}
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = F1215_10943(Current);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			tr3 = F1526_13752(RTCW(tr3));
			tr4 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tr4 = F1526_13752(RTCW(tr4));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2639[Dtype(RTCW(tr1))-273])(tr1, tr2, loc1, tr3, tr4);
		}
		F1215_10948(Current);
	}
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.is_xmlns */
EIF_BOOLEAN F1215_10941 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = RTOUCR(3107,F458_6120, (Current));
		Result = F398_5285(Current, tr1, arg1);
	}
	RTLE;
	return Result;
}

/* {XM_NAMESPACE_RESOLVER}.is_xml */
EIF_BOOLEAN F1215_10942 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = RTOUCR(3108,F458_6121, (Current));
		Result = F398_5285(Current, tr1, arg1);
	}
	RTLE;
	return Result;
}

/* {XM_NAMESPACE_RESOLVER}.unprefixed_attribute_namespace */
EIF_REFERENCE F1215_10943 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) RTOUCR(3106,F458_6119, (Current));
}

/* {XM_NAMESPACE_RESOLVER}.attributes_make */
void F1215_10946 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F398_5291(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = F398_5290(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = F398_5290(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.attributes_force */
void F1215_10947 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1526_13758(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1526_13758(RTCW(tr1), arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1526_13758(RTCW(tr1), arg3);
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.attributes_remove */
void F1215_10948 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	F1526_13761(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1526_13761(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1526_13761(RTCW(tr1));
	RTLE;
}

/* {XM_NAMESPACE_RESOLVER}.attributes_is_empty */
EIF_BOOLEAN F1215_10949 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	Result = F1432_13373(RTCW(tr1));
	RTLE;
	return Result;
}

/* {XM_NAMESPACE_RESOLVER}.undeclared_namespace_error */

EIF_REFERENCE F1215_10953 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (3112,RTMS_EX_H("Undeclared namespace error",26,1792447602));
}

/* {XM_NAMESPACE_RESOLVER}.duplicate_namespace_declaration_error */

EIF_REFERENCE F1215_10954 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (3111,RTMS_EX_H("Namespace declared twice",24,1284969317));
}

void EIF_Minit526 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
