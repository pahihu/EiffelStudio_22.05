/*
 * Code for class AP_OPTION_COMPARATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ap535.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {AP_OPTION_COMPARATOR}.less_than */
EIF_BOOLEAN F1224_11048 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc4);
	RTLR(5,arg2);
	RTLR(6,loc2);
	RTLR(7,Current);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		loc1 = (EIF_REFERENCE) loc3;
	} else {
		tc1 = *(EIF_CHARACTER_8 *)(RTCW(arg1) + O1822[Dtype(arg1)-204]);
		loc1 = eif_out__c1_s1(tc1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc2 = (EIF_REFERENCE) loc4;
	} else {
		tc1 = *(EIF_CHARACTER_8 *)(RTCW(arg2) + O1822[Dtype(arg2)-204]);
		loc2 = eif_out__c1_s1(tc1);
	}
	tr1 = RTOUCR(10,F1207_10828, (Current));
	ti4_1 = F1198_10708(RTCW(tr1), loc1, loc2);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) -1L));
	RTLE;
	return Result;
}

/* {AP_OPTION_COMPARATOR}.attached_less_than */
EIF_BOOLEAN F1224_11049 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc4);
	RTLR(5,arg2);
	RTLR(6,loc2);
	RTLR(7,Current);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		loc1 = (EIF_REFERENCE) loc3;
	} else {
		tc1 = *(EIF_CHARACTER_8 *)(RTCW(arg1) + O1822[Dtype(arg1)-204]);
		loc1 = eif_out__c1_s1(tc1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc2 = (EIF_REFERENCE) loc4;
	} else {
		tc1 = *(EIF_CHARACTER_8 *)(RTCW(arg2) + O1822[Dtype(arg2)-204]);
		loc2 = eif_out__c1_s1(tc1);
	}
	tr1 = RTOUCR(10,F1207_10828, (Current));
	ti4_1 = F1198_10708(RTCW(tr1), loc1, loc2);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) -1L));
	RTLE;
	return Result;
}

void EIF_Minit535 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
