
#ifndef _C11_kl547_
#define _C11_kl547_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1236_11605(EIF_REFERENCE, EIF_REFERENCE);
extern void F1236_11606(EIF_REFERENCE, EIF_CHARACTER_8);
extern void F1236_11607(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1236_11609(EIF_REFERENCE);
extern EIF_REFERENCE F1236_11610(EIF_REFERENCE);
extern void EIF_Minit547(void);

#ifdef __cplusplus
}
#endif

#endif
