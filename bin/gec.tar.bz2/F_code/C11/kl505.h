
#ifndef _C11_kl505_
#define _C11_kl505_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F1187_10637_body(EIF_REFERENCE);
extern EIF_REFERENCE F1187_10637(EIF_REFERENCE);
extern void EIF_Minit505(void);

#ifdef __cplusplus
}
#endif

#endif
