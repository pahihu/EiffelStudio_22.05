
#ifndef _C11_kl508_
#define _C11_kl508_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1190_10678(EIF_REFERENCE, EIF_NATURAL_32, EIF_BOOLEAN);
extern void F1190_10679(EIF_REFERENCE, EIF_NATURAL_32, EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit508(void);
extern void F1183_10471(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R8529[])();

#ifdef __cplusplus
}
#endif

#endif
