/*
 * Code for class ET_ECF_PLATFORM_CONDITION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et529.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ECF_PLATFORM_CONDITION}.make */
void F1218_10971 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {ET_ECF_PLATFORM_CONDITION}.make_excluded */
void F1218_10972 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {ET_ECF_PLATFORM_CONDITION}.is_enabled */
EIF_BOOLEAN F1218_10974 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLIU(8);
	
	RTGC;
	tb1 = RTOUCB(EIF_BOOLEAN,7,F39_460, (RTCV(RTOUCR(8,F461_6141, (Current)))));
	if (tb1) {
		loc1 = RTOUCR(70,F69_936, (Current));
	} else {
		loc1 = RTOUCR(69,F69_934, (Current));
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tc1 = (EIF_CHARACTER_8) ' ';
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5633[Dtype(RTCW(tr1))-738])(tr1, (EIF_REFERENCE) &tc1);
	if (tb1) {
		loc2 = RTLNS(eif_new_type(1263, 0x01).id, 1263, _OBJSIZ_2_2_0_0_0_0_0_0_);
		tr1 = RTOUCR(762,F47_592, (Current));
		F1264_12091(RTCW(loc2), tr1);
		tr1 = F1264_12100(RTCW(loc2), *(EIF_REFERENCE *)(Current));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1085,0xFF01,1197,0xFF01,1184,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNTS(typres0.id, 3, 0);
		}
		tr3 = RTOUCR(10,F1207_10828, (Current));
		((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
		RTAR(tr2,tr3);
		((EIF_TYPED_VALUE *)tr2+2)->it_r = loc1;
		RTAR(tr2,loc1);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1175,0xFF01,0xFFF9,1,1085,0xFF01,1184,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr5= RTLNRF(typres0.id, (EIF_POINTER) __A509_56_2, (EIF_POINTER) _A509_56_2, (EIF_POINTER)(F1198_10706),tr2, 1, 1);
		}
		Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R10711[Dtype(RTCW(tr1))-1512])(tr1, tr5);
	} else {
		tr1 = RTOUCR(10,F1207_10828, (Current));
		Result = F1198_10706(RTCW(tr1), *(EIF_REFERENCE *)(Current), loc1);
	}
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) != Result);
}

void EIF_Minit529 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
