
#ifndef _C11_uc517_
#define _C11_uc517_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1206_10819(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1206_10822(EIF_REFERENCE);
extern void EIF_Minit517(void);
extern void F2145_26973(EIF_REFERENCE, EIF_REFERENCE);
extern void F2145_26966(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
