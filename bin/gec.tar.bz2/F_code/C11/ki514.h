
#ifndef _C11_ki514_
#define _C11_ki514_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1203_10814(EIF_REFERENCE);
extern void EIF_Minit514(void);

#ifdef __cplusplus
}
#endif

#endif
