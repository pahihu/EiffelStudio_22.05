/*
 * Code for class ET_FEATURE_CHECKER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et542.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_FEATURE_CHECKER}.make */
void F1231_11129 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	F1023_8167(Current, arg1);
	tr1 = RTLNSMART(eif_new_type(1034, 1).id);
	F1035_8342(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O8990[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9254[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(1715,F1231_11582, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9248[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(1715,F1231_11582, (Current));
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O13761[Dtype(tr1)-1836]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9249[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8706[Dtype(RTCW(tr1))-1840])(tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1540,0xFF01,1749,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1541_13840(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9251[dtype-1230]) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1540,0xFF01,1540,0xFF01,1860,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1541_13840(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9291[dtype-1230]) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1540,0xFF01,1540,0xFF01,1838,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1541_13840(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9294[dtype-1230]) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1540,0xFF01,1540,0xFF01,1836,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1541_13840(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9297[dtype-1230]) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1540,0xFF01,0xFFF9,3,1085,1838,0xFF01,2026,0xFF01,2022,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1541_13840(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9300[dtype-1230]) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1540,0xFF01,2022,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1541_13840(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9303[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9257[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(5,F396_5268, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9258[dtype-1230]) = (EIF_REFERENCE) tr1;
	F1231_11572(Current, *(EIF_REFERENCE *)(Current + O9257[dtype-1230]));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,2022,0xFF01,1737,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1553_14024(RTCW(tr1), ((EIF_INTEGER_32) 50L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9259[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(9, 1).id);
	F10_109(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9260[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1033, 1).id);
	F1023_8167(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9261[dtype-1230]) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,2022,0xFF01,1867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1553_14024(RTCW(tr1), ((EIF_INTEGER_32) 50L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9262[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(10, 1).id);
	F11_122(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9263[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1249, 1).id);
	F1250_11948(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1249, 1).id);
	F1250_11948(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(259, 1).id);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9268[dtype-1230]) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1540,0xFF01,1249,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1541_13840(RTCW(tr1), ((EIF_INTEGER_32) 40L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9271[dtype-1230]) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1540,0xFF01,2022,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1541_13840(RTCW(tr1), ((EIF_INTEGER_32) 500L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9308[dtype-1230]) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1540,0xFF01,1693,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1541_13840(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9287[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1986, 1).id);
	tr2 = RTOUCR(78,F396_4337, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_1_);
	F1987_19652(RTCW(tr1), tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9310[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + O9310[dtype-1230]);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O12987[Dtype(tr2)-1616]);
	F1944_19225(RTCW(tr1), ti4_1);
	tr1 = RTLNSMART(eif_new_type(1784, 1).id);
	F1785_17453(RTCW(tr1), *(EIF_REFERENCE *)(Current + O9310[dtype-1230]), NULL);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9309[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1003, 1).id);
	F1003_7567(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9122[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1003, 1).id);
	F1003_7567(RTCW(tr1), ((EIF_INTEGER_32) 20L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9123[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1653, 1).id);
	tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
	tr2 = *(EIF_REFERENCE *)(RTCW(tr2));
	F1654_16763(RTCW(tr1), tr2, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9124[dtype-1230]) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1540,0xFF01,1540,0xFF01,139,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1541_13840(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9162[dtype-1230]) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1036, 1).id);
	F1037_8383(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O9158[dtype-1230]) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {ET_FEATURE_CHECKER}.has_implementation_error */
EIF_BOOLEAN F1231_11131 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O9275[dtype-1230])) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2910[Dtype(RTCW(arg1))-1840])(arg1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2906[Dtype(RTCW(tr1))-1755])(tr1);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tb1 = *(EIF_BOOLEAN *)(loc1+ _CHROFF_3_1_);
			RTLE;
			return (EIF_BOOLEAN) tb1;
		}
	} else {
		if (*(EIF_BOOLEAN *)(Current + O9276[dtype-1230])) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2910[Dtype(RTCW(arg1))-1840])(arg1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2907[Dtype(RTCW(tr1))-1755])(tr1);
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				tb1 = *(EIF_BOOLEAN *)(loc2+ _CHROFF_3_1_);
				RTLE;
				return (EIF_BOOLEAN) tb1;
			}
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2910[Dtype(RTCW(arg1))-1840])(arg1);
			Result = *(EIF_BOOLEAN *)(RTCW(tr1) + O8709[Dtype(tr1)-1199]);
		}
	}
	RTLE;
	return Result;
}

/* {ET_FEATURE_CHECKER}.check_feature_validity */
void F1231_11132 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,loc6);
	RTLR(2,arg1);
	RTLR(3,loc7);
	RTLR(4,loc8);
	RTLR(5,arg2);
	RTLR(6,loc2);
	RTLR(7,loc1);
	RTLR(8,loc3);
	RTLR(9,loc5);
	RTLR(10,loc4);
	RTLR(11,tr1);
	RTLR(12,tr2);
	RTLR(13,loc11);
	RTLIU(14);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc6 = *(EIF_REFERENCE *)(RTCW(arg1) + O13761[Dtype(arg1)-1836]);
	loc7 = *(EIF_REFERENCE *)(RTCW(arg1) + O13762[Dtype(arg1)-1836]);
	loc8 = F2024_20433(RTCW(arg2));
	tb1 = F2027_20648(RTCW(loc7));
	if ((EIF_BOOLEAN) !tb1) {
		F1033_8331(Current);
		F2046_21728(RTCV(F1023_8173(Current)));
	} else {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc6) + O8708[Dtype(loc6)-1199]);
		if (tb1) {
			tb1 = *(EIF_BOOLEAN *)(RTCW(loc6) + O8709[Dtype(loc6)-1199]);
			if (tb1) {
				F1033_8331(Current);
			}
		} else {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(loc7 != loc8)) {
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R15310[Dtype(RTCW(arg2))-2024])(arg2);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				F1231_11132(Current, loc6, loc7);
			}
		}
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc2 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
		RTAR(Current, loc6);
		*(EIF_REFERENCE *)(Current + O9249[dtype-1230]) = (EIF_REFERENCE) loc6;
		loc1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + O9248[dtype-1230]) = (EIF_REFERENCE) arg1;
		loc3 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		RTAR(Current, loc8);
		*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) = (EIF_REFERENCE) loc8;
		loc5 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
		RTAR(Current, arg2);
		*(EIF_REFERENCE *)(Current + O9254[dtype-1230]) = (EIF_REFERENCE) arg2;
		loc4 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
		RTAR(Current, loc7);
		*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) = (EIF_REFERENCE) loc7;
		tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tr2 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_10_);
		F2027_20822(RTCW(tr1), tr2);
		tb1 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tb2 = F2027_20786(RTCW(tr1));
		if (!(EIF_BOOLEAN) !tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tb2 = F2027_20788(RTCW(tr1));
			tb1 = tb2;
		}
		if (tb1) {
			F1033_8331(Current);
		} else {
			tb1 = '\0';
			tb2 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tb3 = F2027_20801(RTCW(tr1));
			if (tb3) {
				tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
				tb3 = F2027_20803(RTCW(tr1));
				tb2 = tb3;
			}
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
				tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_30_16_);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				F1033_8331(Current);
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
				tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
				if (tb1) {
					if ((EIF_BOOLEAN)(loc8 == loc7)) {
						tb1 = '\0';
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2906[Dtype(RTCW(loc6))-1755])(loc6);
						loc11 = tr1;
						if (EIF_TEST(loc11)) {
							tb2 = *(EIF_BOOLEAN *)(loc11+ _CHROFF_3_0_);
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) {
							loc9 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9311[dtype-1230])(Current);
							F1231_11134(RTCW(tr1), loc11, loc6, loc6, loc7);
							*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) loc9;
						}
					}
					F1231_11535(Current, arg1);
				}
				loc10 = *(EIF_BOOLEAN *)(Current + O9280[dtype-1230]);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13718[Dtype(RTCW(arg1))-1840])(arg1);
				*(EIF_BOOLEAN *)(Current + O9280[dtype-1230]) = (EIF_BOOLEAN) tb1;
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13071[Dtype(RTCW(arg1))-1646])(arg1, Current);
				*(EIF_BOOLEAN *)(Current + O9280[dtype-1230]) = (EIF_BOOLEAN) loc10;
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9254[dtype-1230]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
					F1200_10800(RTCW(arg1));
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						F1200_10801(RTCW(arg1));
					}
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
		F1466_13433(RTCW(tr1));
		for (;;) {
			tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
			tb1 = F1466_13430(RTCW(tr1));
			if (tb1) break;
			tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
			tr1 = F1452_13404(RTCW(tr1));
			F1231_11572(Current, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
			F1466_13434(RTCW(tr1));
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
		F1545_13953(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
		F10_121(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
		F1466_13433(RTCW(tr1));
		for (;;) {
			tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
			tb2 = F1466_13430(RTCW(tr1));
			if (tb2) break;
			tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
			tr1 = F1452_13404(RTCW(tr1));
			F1231_11572(Current, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
			F1466_13434(RTCW(tr1));
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
		F1545_13953(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
		F11_134(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
		F1250_11973(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
		F1250_11973(RTCW(tr1));
		RTAR(Current, loc3);
		*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) = (EIF_REFERENCE) loc3;
		RTAR(Current, loc5);
		*(EIF_REFERENCE *)(Current + O9254[dtype-1230]) = (EIF_REFERENCE) loc5;
		RTAR(Current, loc4);
		*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) = (EIF_REFERENCE) loc4;
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O9248[dtype-1230]) = (EIF_REFERENCE) loc1;
		RTAR(Current, loc2);
		*(EIF_REFERENCE *)(Current + O9249[dtype-1230]) = (EIF_REFERENCE) loc2;
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_precursor_feature_validity */
void F1231_11133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_BOOLEAN *)(Current + O9279[dtype-1230]);
	*(EIF_BOOLEAN *)(Current + O9279[dtype-1230]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F1231_11132(Current, arg1, arg2);
	*(EIF_BOOLEAN *)(Current + O9279[dtype-1230]) = (EIF_BOOLEAN) loc1;
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_preconditions_validity */
void F1231_11134 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc13 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc17 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(19);
	RTLR(0,Current);
	RTLR(1,loc14);
	RTLR(2,arg2);
	RTLR(3,loc15);
	RTLR(4,loc16);
	RTLR(5,arg4);
	RTLR(6,arg1);
	RTLR(7,loc2);
	RTLR(8,loc1);
	RTLR(9,arg3);
	RTLR(10,loc5);
	RTLR(11,loc3);
	RTLR(12,loc4);
	RTLR(13,tr1);
	RTLR(14,tr2);
	RTLR(15,loc11);
	RTLR(16,loc8);
	RTLR(17,loc18);
	RTLR(18,loc12);
	RTLIU(19);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc14 = *(EIF_REFERENCE *)(RTCW(arg2) + O13761[Dtype(arg2)-1836]);
	loc15 = *(EIF_REFERENCE *)(RTCW(arg2) + O13762[Dtype(arg2)-1836]);
	loc16 = F2024_20433(RTCW(arg4));
	tb1 = F2027_20648(RTCW(loc15));
	if ((EIF_BOOLEAN) !tb1) {
		F1033_8331(Current);
		F2046_21728(RTCV(F1023_8173(Current)));
	} else {
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_0_);
		if (tb1) {
			tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_1_);
			if (tb1) {
				F1033_8331(Current);
			}
		} else {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(loc15 != loc16)) {
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R15310[Dtype(RTCW(arg4))-2024])(arg4);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				F1231_11134(Current, arg1, loc14, loc14, loc15);
			}
		}
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc2 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
		RTAR(Current, loc14);
		*(EIF_REFERENCE *)(Current + O9249[dtype-1230]) = (EIF_REFERENCE) loc14;
		loc1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
		RTAR(Current, arg3);
		*(EIF_REFERENCE *)(Current + O9248[dtype-1230]) = (EIF_REFERENCE) arg3;
		loc5 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
		RTAR(Current, arg4);
		*(EIF_REFERENCE *)(Current + O9254[dtype-1230]) = (EIF_REFERENCE) arg4;
		loc3 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		RTAR(Current, loc16);
		*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) = (EIF_REFERENCE) loc16;
		loc4 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
		RTAR(Current, loc15);
		*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) = (EIF_REFERENCE) loc15;
		loc7 = *(EIF_BOOLEAN *)(Current + O9280[dtype-1230]);
		tb1 = '\0';
		tb2 = '\01';
		tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13712[Dtype(RTCW(arg3))-1840])(arg3);
		if (!tb3) {
			tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13713[Dtype(RTCW(arg3))-1840])(arg3);
			tb2 = tb3;
		}
		if ((EIF_BOOLEAN) !tb2) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13718[Dtype(RTCW(arg3))-1840])(arg3);
			tb1 = tb2;
		}
		*(EIF_BOOLEAN *)(Current + O9280[dtype-1230]) = (EIF_BOOLEAN) tb1;
		loc6 = *(EIF_BOOLEAN *)(Current + O9275[dtype-1230]);
		*(EIF_BOOLEAN *)(Current + O9275[dtype-1230]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tr2 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_10_);
		F2027_20822(RTCW(tr1), tr2);
		tb1 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tb2 = F2027_20786(RTCW(tr1));
		if (!(EIF_BOOLEAN) !tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tb2 = F2027_20788(RTCW(tr1));
			tb1 = tb2;
		}
		if (tb1) {
			F1033_8331(Current);
		} else {
			tr1 = F1231_11526(Current);
			loc11 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
			loc8 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
			loc17 = F10_115(RTCW(tr1));
			loc10 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
			loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc9 > loc10)) break;
				tr1 = F1909_18730(RTCW(arg1), loc9);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13235[Dtype(RTCW(tr1))-1666])(tr1);
				loc18 = tr1;
				if (EIF_TEST(loc18)) {
					tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
					loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc13 || tb1);
					F1231_11290(Current, loc18, loc8, loc11);
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
					} else {
						tb1 = F2022_20365(RTCW(loc8), loc11, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
						if ((EIF_BOOLEAN) !tb1) {
							F1033_8331(Current);
							loc12 = F2022_20345(RTCW(loc8));
							tr1 = F1023_8173(Current);
							F2046_21520(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc18, loc12);
						}
					}
					F899_7060(RTCW(loc8));
					tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
					F1034_8335(RTCW(tr1), loc18, *(EIF_REFERENCE *)(Current + O9260[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
					tb1 = '\01';
					if (!*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
						tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
						tb1 = tb2;
					}
					*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) tb1;
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
					tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
					if (tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
						F260_2862(RTCW(tr1), loc18, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
					}
				}
				loc9++;
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
			F10_119(RTCW(tr1), loc17);
			F1231_11572(Current, loc8);
			*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc13);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9254[dtype-1230]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
				F1911_18753(RTCW(arg1));
				if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
					F1911_18754(RTCW(arg1));
				}
			}
		}
		*(EIF_BOOLEAN *)(Current + O9275[dtype-1230]) = (EIF_BOOLEAN) loc6;
		*(EIF_BOOLEAN *)(Current + O9280[dtype-1230]) = (EIF_BOOLEAN) loc7;
		tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
		F1466_13433(RTCW(tr1));
		for (;;) {
			tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
			tb1 = F1466_13430(RTCW(tr1));
			if (tb1) break;
			tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
			tr1 = F1452_13404(RTCW(tr1));
			F1231_11572(Current, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
			F1466_13434(RTCW(tr1));
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
		F1545_13953(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
		F10_121(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
		F1466_13433(RTCW(tr1));
		for (;;) {
			tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
			tb2 = F1466_13430(RTCW(tr1));
			if (tb2) break;
			tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
			tr1 = F1452_13404(RTCW(tr1));
			F1231_11572(Current, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
			F1466_13434(RTCW(tr1));
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
		F1545_13953(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
		F11_134(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
		F1250_11973(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
		F1250_11973(RTCW(tr1));
		RTAR(Current, loc3);
		*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) = (EIF_REFERENCE) loc3;
		RTAR(Current, loc5);
		*(EIF_REFERENCE *)(Current + O9254[dtype-1230]) = (EIF_REFERENCE) loc5;
		RTAR(Current, loc4);
		*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) = (EIF_REFERENCE) loc4;
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O9248[dtype-1230]) = (EIF_REFERENCE) loc1;
		RTAR(Current, loc2);
		*(EIF_REFERENCE *)(Current + O9249[dtype-1230]) = (EIF_REFERENCE) loc2;
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_postconditions_validity */
void F1231_11135 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc13 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc17 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc18 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(20);
	RTLR(0,Current);
	RTLR(1,loc14);
	RTLR(2,arg2);
	RTLR(3,loc15);
	RTLR(4,loc16);
	RTLR(5,arg4);
	RTLR(6,arg1);
	RTLR(7,loc2);
	RTLR(8,loc1);
	RTLR(9,arg3);
	RTLR(10,loc5);
	RTLR(11,loc3);
	RTLR(12,loc4);
	RTLR(13,tr1);
	RTLR(14,tr2);
	RTLR(15,loc19);
	RTLR(16,loc11);
	RTLR(17,loc8);
	RTLR(18,loc20);
	RTLR(19,loc12);
	RTLIU(20);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc14 = *(EIF_REFERENCE *)(RTCW(arg2) + O13761[Dtype(arg2)-1836]);
	loc15 = *(EIF_REFERENCE *)(RTCW(arg2) + O13762[Dtype(arg2)-1836]);
	loc16 = F2024_20433(RTCW(arg4));
	tb1 = F2027_20648(RTCW(loc15));
	if ((EIF_BOOLEAN) !tb1) {
		F1033_8331(Current);
		F2046_21728(RTCV(F1023_8173(Current)));
	} else {
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_0_);
		if (tb1) {
			tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_1_);
			if (tb1) {
				F1033_8331(Current);
			}
		} else {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(loc15 != loc16)) {
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R15310[Dtype(RTCW(arg4))-2024])(arg4);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				F1231_11135(Current, arg1, loc14, loc14, loc15);
			}
		}
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc2 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
		RTAR(Current, loc14);
		*(EIF_REFERENCE *)(Current + O9249[dtype-1230]) = (EIF_REFERENCE) loc14;
		loc1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
		RTAR(Current, arg3);
		*(EIF_REFERENCE *)(Current + O9248[dtype-1230]) = (EIF_REFERENCE) arg3;
		loc5 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
		RTAR(Current, arg4);
		*(EIF_REFERENCE *)(Current + O9254[dtype-1230]) = (EIF_REFERENCE) arg4;
		loc3 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		RTAR(Current, loc16);
		*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) = (EIF_REFERENCE) loc16;
		loc4 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
		RTAR(Current, loc15);
		*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) = (EIF_REFERENCE) loc15;
		loc7 = *(EIF_BOOLEAN *)(Current + O9280[dtype-1230]);
		tb1 = '\0';
		tb2 = '\01';
		tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13712[Dtype(RTCW(arg3))-1840])(arg3);
		if (!tb3) {
			tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13713[Dtype(RTCW(arg3))-1840])(arg3);
			tb2 = tb3;
		}
		if ((EIF_BOOLEAN) !tb2) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13718[Dtype(RTCW(arg3))-1840])(arg3);
			tb1 = tb2;
		}
		*(EIF_BOOLEAN *)(Current + O9280[dtype-1230]) = (EIF_BOOLEAN) tb1;
		loc6 = *(EIF_BOOLEAN *)(Current + O9276[dtype-1230]);
		*(EIF_BOOLEAN *)(Current + O9276[dtype-1230]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tr2 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_10_);
		F2027_20822(RTCW(tr1), tr2);
		tb1 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tb2 = F2027_20786(RTCW(tr1));
		if (!(EIF_BOOLEAN) !tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tb2 = F2027_20788(RTCW(tr1));
			tb1 = tb2;
		}
		if (tb1) {
			F1033_8331(Current);
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN)(loc16 == loc15)) {
					tb1 = '\0';
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2906[Dtype(RTCW(loc14))-1755])(loc14);
					loc19 = tr1;
					if (EIF_TEST(loc19)) {
						tb2 = *(EIF_BOOLEAN *)(loc19+ _CHROFF_3_0_);
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) {
						loc18 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R9311[dtype-1230])(Current);
						F1231_11134(RTCW(tr1), loc19, loc14, loc14, loc15);
						*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) loc18;
					}
				}
				F1231_11535(Current, loc14);
			}
			tr1 = F1231_11526(Current);
			loc11 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
			loc8 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
			loc17 = F10_115(RTCW(tr1));
			loc10 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_2_0_0_);
			loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc9 > loc10)) break;
				tr1 = F1909_18730(RTCW(arg1), loc9);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13235[Dtype(RTCW(tr1))-1666])(tr1);
				loc20 = tr1;
				if (EIF_TEST(loc20)) {
					tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
					loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc13 || tb1);
					F1231_11290(Current, loc20, loc8, loc11);
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
					} else {
						tb1 = F2022_20365(RTCW(loc8), loc11, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
						if ((EIF_BOOLEAN) !tb1) {
							F1033_8331(Current);
							loc12 = F2022_20345(RTCW(loc8));
							tr1 = F1023_8173(Current);
							F2046_21520(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc20, loc12);
						}
					}
					F899_7060(RTCW(loc8));
					tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
					F1034_8335(RTCW(tr1), loc20, *(EIF_REFERENCE *)(Current + O9260[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
					tb1 = '\01';
					if (!*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
						tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
						tb1 = tb2;
					}
					*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) tb1;
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
					tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
					if (tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
						F260_2862(RTCW(tr1), loc20, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
					}
				}
				loc9++;
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
			F10_119(RTCW(tr1), loc17);
			F1231_11572(Current, loc8);
			*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc13);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9254[dtype-1230]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
				F1912_18770(RTCW(arg1));
				if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
					F1912_18771(RTCW(arg1));
				}
			}
		}
		*(EIF_BOOLEAN *)(Current + O9276[dtype-1230]) = (EIF_BOOLEAN) loc6;
		*(EIF_BOOLEAN *)(Current + O9280[dtype-1230]) = (EIF_BOOLEAN) loc7;
		tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
		F1466_13433(RTCW(tr1));
		for (;;) {
			tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
			tb1 = F1466_13430(RTCW(tr1));
			if (tb1) break;
			tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
			tr1 = F1452_13404(RTCW(tr1));
			F1231_11572(Current, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
			F1466_13434(RTCW(tr1));
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
		F1545_13953(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
		F10_121(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
		F1466_13433(RTCW(tr1));
		for (;;) {
			tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
			tb2 = F1466_13430(RTCW(tr1));
			if (tb2) break;
			tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
			tr1 = F1452_13404(RTCW(tr1));
			F1231_11572(Current, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
			F1466_13434(RTCW(tr1));
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
		F1545_13953(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
		F11_134(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
		F1250_11973(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
		F1250_11973(RTCW(tr1));
		RTAR(Current, loc3);
		*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) = (EIF_REFERENCE) loc3;
		RTAR(Current, loc5);
		*(EIF_REFERENCE *)(Current + O9254[dtype-1230]) = (EIF_REFERENCE) loc5;
		RTAR(Current, loc4);
		*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) = (EIF_REFERENCE) loc4;
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O9248[dtype-1230]) = (EIF_REFERENCE) loc1;
		RTAR(Current, loc2);
		*(EIF_REFERENCE *)(Current + O9249[dtype-1230]) = (EIF_REFERENCE) loc2;
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_invariants_validity */
void F1231_11136 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc12 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc15 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,Current);
	RTLR(1,loc13);
	RTLR(2,arg1);
	RTLR(3,loc14);
	RTLR(4,arg2);
	RTLR(5,loc2);
	RTLR(6,loc1);
	RTLR(7,loc5);
	RTLR(8,loc3);
	RTLR(9,loc4);
	RTLR(10,tr1);
	RTLR(11,tr2);
	RTLR(12,loc10);
	RTLR(13,loc9);
	RTLR(14,loc16);
	RTLR(15,loc11);
	RTLIU(16);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc13 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	loc14 = F2024_20433(RTCW(arg2));
	tb1 = F2027_20648(RTCW(loc13));
	if ((EIF_BOOLEAN) !tb1) {
		F1033_8331(Current);
		F2046_21728(RTCV(F1023_8173(Current)));
	} else {
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_5_0_);
		if (tb1) {
			tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_5_1_);
			if (tb1) {
				F1033_8331(Current);
			}
		} else {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(loc13 != loc14)) {
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R15310[Dtype(RTCW(arg2))-2024])(arg2);
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				F1231_11136(Current, arg1, loc13);
			}
		}
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc2 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + O9249[dtype-1230]) = (EIF_REFERENCE) arg1;
		loc1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + O9248[dtype-1230]) = (EIF_REFERENCE) arg1;
		loc5 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
		RTAR(Current, arg2);
		*(EIF_REFERENCE *)(Current + O9254[dtype-1230]) = (EIF_REFERENCE) arg2;
		loc3 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		RTAR(Current, loc14);
		*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) = (EIF_REFERENCE) loc14;
		loc4 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
		RTAR(Current, loc13);
		*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) = (EIF_REFERENCE) loc13;
		loc6 = *(EIF_BOOLEAN *)(Current + O9277[dtype-1230]);
		*(EIF_BOOLEAN *)(Current + O9277[dtype-1230]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tr2 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_10_);
		F2027_20822(RTCW(tr1), tr2);
		tb1 = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tb2 = F2027_20786(RTCW(tr1));
		if (!(EIF_BOOLEAN) !tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tb2 = F2027_20788(RTCW(tr1));
			tb1 = tb2;
		}
		if (tb1) {
			F1033_8331(Current);
		} else {
			tr1 = F1231_11526(Current);
			loc10 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
			loc9 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
			loc15 = F10_115(RTCW(tr1));
			loc8 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_5_2_0_0_);
			loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc7 > loc8)) break;
				tr1 = F1909_18730(RTCW(arg1), loc7);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13235[Dtype(RTCW(tr1))-1666])(tr1);
				loc16 = tr1;
				if (EIF_TEST(loc16)) {
					tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
					loc12 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc12 || tb1);
					F1231_11290(Current, loc16, loc9, loc10);
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
					} else {
						tb1 = F2022_20365(RTCW(loc9), loc10, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
						if ((EIF_BOOLEAN) !tb1) {
							F1033_8331(Current);
							loc11 = F2022_20345(RTCW(loc9));
							tr1 = F1023_8173(Current);
							F2046_21520(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc16, loc11);
						}
					}
					F899_7060(RTCW(loc9));
					tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
					F1034_8335(RTCW(tr1), loc16, *(EIF_REFERENCE *)(Current + O9260[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
					tb1 = '\01';
					if (!*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
						tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
						tb1 = tb2;
					}
					*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) tb1;
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
					tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
					if (tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
						F260_2862(RTCW(tr1), loc16, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
					}
				}
				loc7++;
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
			F10_119(RTCW(tr1), loc15);
			F1231_11572(Current, loc9);
			*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc12);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
				F1200_10800(RTCW(arg1));
				if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
					F1200_10801(RTCW(arg1));
				}
			}
		}
		*(EIF_BOOLEAN *)(Current + O9277[dtype-1230]) = (EIF_BOOLEAN) loc6;
		tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
		F1466_13433(RTCW(tr1));
		for (;;) {
			tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
			tb1 = F1466_13430(RTCW(tr1));
			if (tb1) break;
			tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
			tr1 = F1452_13404(RTCW(tr1));
			F1231_11572(Current, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
			F1466_13434(RTCW(tr1));
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
		F1545_13953(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
		F10_121(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
		F1466_13433(RTCW(tr1));
		for (;;) {
			tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
			tb2 = F1466_13430(RTCW(tr1));
			if (tb2) break;
			tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
			tr1 = F1452_13404(RTCW(tr1));
			F1231_11572(Current, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
			F1466_13434(RTCW(tr1));
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
		F1545_13953(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
		F11_134(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
		F1250_11973(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
		F1250_11973(RTCW(tr1));
		RTAR(Current, loc3);
		*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) = (EIF_REFERENCE) loc3;
		RTAR(Current, loc5);
		*(EIF_REFERENCE *)(Current + O9254[dtype-1230]) = (EIF_REFERENCE) loc5;
		RTAR(Current, loc4);
		*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) = (EIF_REFERENCE) loc4;
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O9248[dtype-1230]) = (EIF_REFERENCE) loc1;
		RTAR(Current, loc2);
		*(EIF_REFERENCE *)(Current + O9249[dtype-1230]) = (EIF_REFERENCE) loc2;
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_attribute_validity */
void F1231_11137 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1839_17878(RTCW(arg1));
	F1231_11153(Current, loc1, arg1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		{
			/* INLINED CODE (ET_FEATURE_CHECKER.report_result_declaration) */
			/* END INLINED CODE */
		}
		;
		if (*(EIF_BOOLEAN *)(Current + O9279[dtype-1230])) {
		} else {
			F1231_11418(Current, loc1, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
		}
	}
	loc2 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		F1231_11158(Current, loc3, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		F1231_11160(Current, loc4, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || tb1);
	}
	tb1 = F1837_17818(RTCW(arg1));
	if (tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21487(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) loc2;
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_constant_attribute_validity */
void F1231_11138 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc5);
	RTLR(4,tr1);
	RTLR(5,loc6);
	RTLR(6,loc2);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,loc7);
	RTLR(10,loc3);
	RTLR(11,loc8);
	RTLR(12,loc9);
	RTLR(13,loc10);
	RTLR(14,tr4);
	RTLR(15,tr5);
	RTLIU(16);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1839_17878(RTCW(arg1));
	F1231_11153(Current, loc1, arg1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		if (*(EIF_BOOLEAN *)(Current + O9279[dtype-1230])) {
		} else {
			F1231_11418(Current, loc1, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
		}
	}
	loc4 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		F1231_11158(Current, loc5, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc4 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		F1231_11160(Current, loc6, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc4 || tb1);
	}
	if ((EIF_BOOLEAN) !loc4) {
		loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_17_);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13525[Dtype(RTCW(loc2))-1777])(loc2);
		if (tb1) {
			tr1 = F1231_11526(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
			tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
			tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
			tb1 = F1884_18234(RTCW(loc1), tr1, tr2, tr3);
			if ((EIF_BOOLEAN) !tb1) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21447(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
			}
		} else {
			loc7 = loc2;
			loc7 = RTRV(eif_new_type(1933, 0x01),loc7);
			if (EIF_TEST(loc7)) {
				tr1 = *(EIF_REFERENCE *)(loc7 + _REFACS_1_);
				if ((EIF_BOOLEAN)(tr1 != NULL)) {
					loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
					F1231_11216(Current, loc7, loc3);
					tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc4 || tb1);
					F1231_11572(Current, loc3);
				}
				tr1 = F1231_11526(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12752[Dtype(tr1)-1610]);
				tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
				if (tb1) {
					tb1 = F1934_19108(loc7);
					if ((EIF_BOOLEAN) !tb1) {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21449(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1, loc7);
					}
					tr1 = F1231_11526(Current);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12752[Dtype(tr1)-1610]);
					F1934_19121(loc7, tr1);
				} else {
					tr1 = F1231_11526(Current);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12753[Dtype(tr1)-1610]);
					tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
					if (tb1) {
						tb1 = F1934_19109(loc7);
						if ((EIF_BOOLEAN) !tb1) {
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							F2046_21449(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1, loc7);
						}
						tr1 = F1231_11526(Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12753[Dtype(tr1)-1610]);
						F1934_19121(loc7, tr1);
					} else {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21448(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
					}
				}
			} else {
				loc8 = loc2;
				loc8 = RTRV(eif_new_type(1937, 0x01),loc8);
				if (EIF_TEST(loc8)) {
					tr1 = *(EIF_REFERENCE *)(loc8 + _REFACS_3_);
					if ((EIF_BOOLEAN)(tr1 != NULL)) {
						loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
						F1231_11236(Current, loc8, loc3);
						tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc4 || tb1);
						F1231_11572(Current, loc3);
					}
					tr1 = F1231_11526(Current);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12762[Dtype(tr1)-1610]);
					tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
					if (tb1) {
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14471[Dtype(loc8)-1938])(loc8);
						if ((EIF_BOOLEAN) !tb1) {
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							F2046_21451(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1, loc8);
						}
						tr1 = F1231_11526(Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12762[Dtype(tr1)-1610]);
						F1938_19180(loc8, tr1);
					} else {
						tr1 = F1231_11526(Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12763[Dtype(tr1)-1610]);
						tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
						if (tb1) {
							tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14472[Dtype(loc8)-1938])(loc8);
							if ((EIF_BOOLEAN) !tb1) {
								F1033_8331(Current);
								tr1 = F1023_8173(Current);
								F2046_21451(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1, loc8);
							}
							tr1 = F1231_11526(Current);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12763[Dtype(tr1)-1610]);
							F1938_19180(loc8, tr1);
						} else {
							tr1 = F1231_11526(Current);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12764[Dtype(tr1)-1610]);
							tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
							if (tb1) {
								tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14473[Dtype(loc8)-1938])(loc8);
								if ((EIF_BOOLEAN) !tb1) {
									F1033_8331(Current);
									tr1 = F1023_8173(Current);
									F2046_21451(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1, loc8);
								}
								tr1 = F1231_11526(Current);
								tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12764[Dtype(tr1)-1610]);
								F1938_19180(loc8, tr1);
							} else {
								tr1 = F1231_11526(Current);
								tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12765[Dtype(tr1)-1610]);
								tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
								if (tb1) {
									tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14474[Dtype(loc8)-1938])(loc8);
									if ((EIF_BOOLEAN) !tb1) {
										F1033_8331(Current);
										tr1 = F1023_8173(Current);
										F2046_21451(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1, loc8);
									}
									tr1 = F1231_11526(Current);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12765[Dtype(tr1)-1610]);
									F1938_19180(loc8, tr1);
								} else {
									tr1 = F1231_11526(Current);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12769[Dtype(tr1)-1610]);
									tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
									if (tb1) {
										tb1 = F1938_19172(loc8);
										if ((EIF_BOOLEAN) !tb1) {
											F1033_8331(Current);
											tr1 = F1023_8173(Current);
											F2046_21451(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1, loc8);
										}
										tr1 = F1231_11526(Current);
										tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12769[Dtype(tr1)-1610]);
										F1938_19180(loc8, tr1);
									} else {
										tr1 = F1231_11526(Current);
										tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12770[Dtype(tr1)-1610]);
										tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
										if (tb1) {
											tb1 = F1938_19173(loc8);
											if ((EIF_BOOLEAN) !tb1) {
												F1033_8331(Current);
												tr1 = F1023_8173(Current);
												F2046_21451(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1, loc8);
											}
											tr1 = F1231_11526(Current);
											tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12770[Dtype(tr1)-1610]);
											F1938_19180(loc8, tr1);
										} else {
											tr1 = F1231_11526(Current);
											tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12771[Dtype(tr1)-1610]);
											tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
											if (tb1) {
												tb1 = F1938_19174(loc8);
												if ((EIF_BOOLEAN) !tb1) {
													F1033_8331(Current);
													tr1 = F1023_8173(Current);
													F2046_21451(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1, loc8);
												}
												tr1 = F1231_11526(Current);
												tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12771[Dtype(tr1)-1610]);
												F1938_19180(loc8, tr1);
											} else {
												tr1 = F1231_11526(Current);
												tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12772[Dtype(tr1)-1610]);
												tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
												if (tb1) {
													tb1 = F1938_19175(loc8);
													if ((EIF_BOOLEAN) !tb1) {
														F1033_8331(Current);
														tr1 = F1023_8173(Current);
														F2046_21451(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1, loc8);
													}
													tr1 = F1231_11526(Current);
													tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12772[Dtype(tr1)-1610]);
													F1938_19180(loc8, tr1);
												} else {
													F1033_8331(Current);
													tr1 = F1023_8173(Current);
													F2046_21450(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
												}
											}
										}
									}
								}
							}
						}
					}
				} else {
					loc9 = loc2;
					loc9 = RTRV(eif_new_type(1918, 0x01),loc9);
					if (EIF_TEST(loc9)) {
						tr1 = F1231_11526(Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12779[Dtype(tr1)-1610]);
						tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
						if (tb1) {
							tr1 = F1231_11526(Current);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12779[Dtype(tr1)-1610]);
							F1919_18904(loc9, tr1);
						} else {
							tr1 = F1231_11526(Current);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12780[Dtype(tr1)-1610]);
							tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
							if (tb1) {
								tr1 = F1231_11526(Current);
								tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12780[Dtype(tr1)-1610]);
								F1919_18904(loc9, tr1);
							} else {
								F1033_8331(Current);
								tr1 = F1023_8173(Current);
								F2046_21452(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
							}
						}
					} else {
						loc10 = loc2;
						loc10 = RTRV(eif_new_type(1929, 0x01),loc10);
						if (EIF_TEST(loc10)) {
							tr1 = *(EIF_REFERENCE *)(loc10 + _REFACS_1_);
							if ((EIF_BOOLEAN)(tr1 != NULL)) {
								loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
								F1231_11244(Current, loc10, loc3);
								tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
								loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc4 || tb1);
								F1231_11572(Current, loc3);
							}
							tr1 = F1231_11526(Current);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12787[Dtype(tr1)-1610]);
							tr2 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
							tr3 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
							tr4 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
							tr5 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
							tb1 = F2026_20549(RTCW(tr1), loc1, tr2, tr3, tr4, tr5);
							if (tb1) {
								tb1 = F1930_19066(loc10);
								if ((EIF_BOOLEAN) !tb1) {
									F1033_8331(Current);
									tr1 = F1023_8173(Current);
									F2046_21454(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1, loc10);
								}
								tr1 = F1231_11526(Current);
								tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12787[Dtype(tr1)-1610]);
								F1930_19081(loc10, tr1);
							} else {
								tr1 = F1231_11526(Current);
								tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12759[Dtype(tr1)-1610]);
								tr2 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
								tr3 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
								tr4 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
								tr5 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
								tb1 = F2026_20549(RTCW(tr1), loc1, tr2, tr3, tr4, tr5);
								if (tb1) {
									tb1 = F1930_19066(loc10);
									if ((EIF_BOOLEAN) !tb1) {
										F1033_8331(Current);
										tr1 = F1023_8173(Current);
										F2046_21454(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1, loc10);
									}
									tr1 = F1231_11526(Current);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12759[Dtype(tr1)-1610]);
									F1930_19081(loc10, tr1);
								} else {
									tr1 = F1231_11526(Current);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12788[Dtype(tr1)-1610]);
									tr2 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
									tr3 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
									tr4 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
									tr5 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
									tb1 = F2026_20549(RTCW(tr1), loc1, tr2, tr3, tr4, tr5);
									if (tb1) {
										tb1 = F1930_19067(loc10);
										if ((EIF_BOOLEAN) !tb1) {
											F1033_8331(Current);
											tr1 = F1023_8173(Current);
											F2046_21454(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1, loc10);
										}
										tr1 = F1231_11526(Current);
										tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12788[Dtype(tr1)-1610]);
										F1930_19081(loc10, tr1);
									} else {
										tr1 = F1231_11526(Current);
										tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12760[Dtype(tr1)-1610]);
										tr2 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
										tr3 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
										tr4 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
										tr5 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
										tb1 = F2026_20549(RTCW(tr1), loc1, tr2, tr3, tr4, tr5);
										if (tb1) {
											tb1 = F1930_19067(loc10);
											if ((EIF_BOOLEAN) !tb1) {
												F1033_8331(Current);
												tr1 = F1023_8173(Current);
												F2046_21454(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1, loc10);
											}
											tr1 = F1231_11526(Current);
											tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12760[Dtype(tr1)-1610]);
											F1930_19081(loc10, tr1);
										} else {
											tb1 = '\0';
											tr1 = F1231_11526(Current);
											tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12791[Dtype(tr1)-1610]);
											tr1 = F2024_20433(RTCW(tr1));
											tb2 = F2027_20678(RTCW(tr1));
											if (tb2) {
												tr1 = F1231_11526(Current);
												tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12791[Dtype(tr1)-1610]);
												tr2 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
												tr3 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
												tr4 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
												tr5 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
												tb2 = F2026_20549(RTCW(tr1), loc1, tr2, tr3, tr4, tr5);
												tb1 = tb2;
											}
											if (tb1) {
												tr1 = F1231_11526(Current);
												tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12791[Dtype(tr1)-1610]);
												F1930_19081(loc10, tr1);
											} else {
												F1033_8331(Current);
												tr1 = F1023_8173(Current);
												F2046_21453(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
											}
										}
									}
								}
							}
						} else {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
				}
			}
		}
	}
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc4);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_deferred_function_validity */
void F1231_11139 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		F1231_11154(Current, loc3, arg1);
		loc2 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	}
	loc1 = F1839_17878(RTCW(arg1));
	F1231_11153(Current, loc1, arg1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		{
			/* INLINED CODE (ET_FEATURE_CHECKER.report_result_declaration) */
			/* END INLINED CODE */
		}
		;
		if (*(EIF_BOOLEAN *)(Current + O9279[dtype-1230])) {
		} else {
			F1231_11418(Current, loc1, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
		}
	}
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || tb1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		F1231_11158(Current, loc4, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		F1231_11160(Current, loc5, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || tb1);
	}
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) loc2;
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_deferred_procedure_validity */
void F1231_11140 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		F1231_11154(Current, loc2, arg1);
		loc1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		F1231_11158(Current, loc3, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc1 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		F1231_11160(Current, loc4, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc1 || tb1);
	}
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) loc1;
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_do_function_validity */
void F1231_11141 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,loc9);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc10);
	RTLR(6,loc11);
	RTLR(7,loc12);
	RTLR(8,loc2);
	RTLR(9,loc4);
	RTLR(10,loc6);
	RTLR(11,loc5);
	RTLR(12,loc7);
	RTLR(13,loc8);
	RTLIU(14);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		F1231_11154(Current, loc9, arg1);
		loc3 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	}
	loc1 = F1839_17878(RTCW(arg1));
	F1231_11153(Current, loc1, arg1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		{
			/* INLINED CODE (ET_FEATURE_CHECKER.report_result_declaration) */
			/* END INLINED CODE */
		}
		;
		if (*(EIF_BOOLEAN *)(Current + O9279[dtype-1230])) {
		} else {
			F1231_11418(Current, loc1, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
		}
	}
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		F1231_11158(Current, loc10, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc11 = tr1;
	if (EIF_TEST(loc11)) {
		F1231_11160(Current, loc11, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	loc12 = tr1;
	if (EIF_TEST(loc12)) {
		F1231_11156(Current, loc12, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
	}
	if ((EIF_BOOLEAN) !loc3) {
		loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		loc4 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 != NULL) && (EIF_BOOLEAN)(loc2 != NULL))) {
				loc6 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				F1250_11971(RTCW(tr1), loc6);
				loc5 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				F1250_11971(RTCW(tr1), loc5);
			}
		}
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			F1231_11208(Current, loc2);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			tb1 = '\0';
			tb2 = F1884_18220(RTCW(loc1), *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			if ((EIF_BOOLEAN) !tb2) {
				tb2 = F1884_18214(RTCW(loc1), *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				tb1 = '\0';
				tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
				tb2 = F1290_12726(RTCW(tr1));
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
					tb2 = F1250_11952(RTCW(tr1));
					tb1 = tb2;
				}
				if (tb1) {
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
					tb1 = F1250_11952(RTCW(tr1));
					if (tb1) {
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
						tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
						if ((EIF_BOOLEAN) !tb1) {
							loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							F2046_21315(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
						}
					}
				}
			}
		}
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 != NULL) && (EIF_BOOLEAN)(loc6 != NULL))) {
					loc7 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
					loc8 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
					RTAR(Current, loc5);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc5;
					RTAR(Current, loc6);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc6;
				}
			}
			F1231_11209(Current, loc4);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc7 != NULL) && (EIF_BOOLEAN)(loc8 != NULL))) {
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
					RTAR(Current, loc7);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc7;
					RTAR(Current, loc8);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc8;
				}
			}
		}
	}
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) loc3;
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_do_procedure_validity */
void F1231_11142 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,loc8);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc9);
	RTLR(5,loc10);
	RTLR(6,loc11);
	RTLR(7,loc1);
	RTLR(8,loc3);
	RTLR(9,loc5);
	RTLR(10,loc4);
	RTLR(11,loc6);
	RTLR(12,loc7);
	RTLIU(13);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		F1231_11154(Current, loc8, arg1);
		loc2 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		F1231_11158(Current, loc9, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		F1231_11160(Current, loc10, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	loc11 = tr1;
	if (EIF_TEST(loc11)) {
		F1231_11156(Current, loc11, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || tb1);
	}
	if ((EIF_BOOLEAN) !loc2) {
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 != NULL) && (EIF_BOOLEAN)(loc1 != NULL))) {
				loc5 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				F1250_11971(RTCW(tr1), loc5);
				loc4 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				F1250_11971(RTCW(tr1), loc4);
			}
		}
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			F1231_11208(Current, loc1);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || tb1);
		}
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 != NULL) && (EIF_BOOLEAN)(loc5 != NULL))) {
					loc6 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
					loc7 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
					RTAR(Current, loc4);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc4;
					RTAR(Current, loc5);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc5;
				}
			}
			F1231_11209(Current, loc3);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || tb1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc6 != NULL) && (EIF_BOOLEAN)(loc7 != NULL))) {
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
					RTAR(Current, loc6);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc6;
					RTAR(Current, loc7);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc7;
				}
			}
		}
	}
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) loc2;
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_extended_attribute_validity */
void F1231_11147 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc9);
	RTLR(4,tr1);
	RTLR(5,loc10);
	RTLR(6,loc11);
	RTLR(7,loc2);
	RTLR(8,loc4);
	RTLR(9,loc6);
	RTLR(10,loc5);
	RTLR(11,loc7);
	RTLR(12,loc8);
	RTLIU(13);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1839_17878(RTCW(arg1));
	F1231_11153(Current, loc1, arg1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		{
			/* INLINED CODE (ET_FEATURE_CHECKER.report_result_declaration) */
			/* END INLINED CODE */
		}
		;
		if (*(EIF_BOOLEAN *)(Current + O9279[dtype-1230])) {
		} else {
			F1231_11418(Current, loc1, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
		}
	}
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		F1231_11158(Current, loc9, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		F1231_11160(Current, loc10, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
	loc11 = tr1;
	if (EIF_TEST(loc11)) {
		F1231_11156(Current, loc11, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
	}
	if ((EIF_BOOLEAN) !loc3) {
		loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
		loc4 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 != NULL) && (EIF_BOOLEAN)(loc2 != NULL))) {
				loc6 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				F1250_11971(RTCW(tr1), loc6);
				loc5 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				F1250_11971(RTCW(tr1), loc5);
			}
		}
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			F1231_11208(Current, loc2);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				tb2 = F1648_16708(RTCW(loc2));
				tb1 = tb2;
			}
			if (tb1) {
				tb1 = '\0';
				tb2 = F1884_18220(RTCW(loc1), *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
				if ((EIF_BOOLEAN) !tb2) {
					tb2 = F1884_18214(RTCW(loc1), *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) {
					tb1 = '\0';
					tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
					tb2 = F1290_12726(RTCW(tr1));
					if (tb2) {
						tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
						tb2 = F1250_11952(RTCW(tr1));
						tb1 = tb2;
					}
					if (tb1) {
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
						tb1 = F1250_11952(RTCW(tr1));
						if ((EIF_BOOLEAN) !tb1) {
							loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							F2046_21317(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
						}
					}
				}
			}
		}
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 != NULL) && (EIF_BOOLEAN)(loc6 != NULL))) {
					loc7 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
					loc8 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
					RTAR(Current, loc5);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc5;
					RTAR(Current, loc6);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc6;
				}
			}
			F1231_11209(Current, loc4);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc7 != NULL) && (EIF_BOOLEAN)(loc8 != NULL))) {
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
					RTAR(Current, loc7);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc7;
					RTAR(Current, loc8);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc8;
				}
			}
		}
	}
	tb1 = F1837_17818(RTCW(arg1));
	if (tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21487(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) loc3;
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_external_function_validity */
void F1231_11148 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		F1231_11154(Current, loc3, arg1);
		loc2 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	}
	loc1 = F1839_17878(RTCW(arg1));
	F1231_11153(Current, loc1, arg1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		{
			/* INLINED CODE (ET_FEATURE_CHECKER.report_result_declaration) */
			/* END INLINED CODE */
		}
		;
		if (*(EIF_BOOLEAN *)(Current + O9279[dtype-1230])) {
		} else {
			F1231_11418(Current, loc1, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
		}
	}
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || tb1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		F1231_11158(Current, loc4, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		F1231_11160(Current, loc5, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || tb1);
	}
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) loc2;
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_external_procedure_validity */
void F1231_11149 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		F1231_11154(Current, loc2, arg1);
		loc1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		F1231_11158(Current, loc3, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc1 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		F1231_11160(Current, loc4, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc1 || tb1);
	}
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) loc1;
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_once_function_validity */
void F1231_11150 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(15);
	RTLR(0,Current);
	RTLR(1,loc10);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc11);
	RTLR(6,loc12);
	RTLR(7,loc13);
	RTLR(8,tr2);
	RTLR(9,loc2);
	RTLR(10,loc5);
	RTLR(11,loc7);
	RTLR(12,loc6);
	RTLR(13,loc8);
	RTLR(14,loc9);
	RTLIU(15);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		F1231_11154(Current, loc10, arg1);
		loc4 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	}
	loc1 = F1839_17878(RTCW(arg1));
	F1231_11153(Current, loc1, arg1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		{
			/* INLINED CODE (ET_FEATURE_CHECKER.report_result_declaration) */
			/* END INLINED CODE */
		}
		;
		if (*(EIF_BOOLEAN *)(Current + O9279[dtype-1230])) {
		} else {
			F1231_11418(Current, loc1, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
		}
	}
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc4 || tb1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc11 = tr1;
	if (EIF_TEST(loc11)) {
		F1231_11158(Current, loc11, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc4 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc12 = tr1;
	if (EIF_TEST(loc12)) {
		F1231_11160(Current, loc12, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc4 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	loc13 = tr1;
	if (EIF_TEST(loc13)) {
		F1231_11156(Current, loc13, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc4 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_9_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_21_);
	F1231_11168(Current, tr1, tr2);
	loc3 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	if ((EIF_BOOLEAN) !loc4) {
		loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		loc5 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 != NULL) && (EIF_BOOLEAN)(loc2 != NULL))) {
				loc7 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				F1250_11971(RTCW(tr1), loc7);
				loc6 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				F1250_11971(RTCW(tr1), loc6);
			}
		}
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			F1231_11208(Current, loc2);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc4 || tb1);
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			tb1 = '\0';
			tb2 = F1884_18220(RTCW(loc1), *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			if ((EIF_BOOLEAN) !tb2) {
				tb2 = F1884_18214(RTCW(loc1), *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				tb1 = '\0';
				tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
				tb2 = F1290_12726(RTCW(tr1));
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
					tb2 = F1250_11952(RTCW(tr1));
					tb1 = tb2;
				}
				if (tb1) {
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
					tb1 = F1250_11952(RTCW(tr1));
					if (tb1) {
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
						tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
						if ((EIF_BOOLEAN) !tb1) {
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							F2046_21315(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
						}
					}
				}
			}
		}
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc6 != NULL) && (EIF_BOOLEAN)(loc7 != NULL))) {
					loc8 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
					loc9 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
					RTAR(Current, loc6);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc6;
					RTAR(Current, loc7);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc7;
				}
			}
			F1231_11209(Current, loc5);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc4 || tb1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc8 != NULL) && (EIF_BOOLEAN)(loc9 != NULL))) {
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
					RTAR(Current, loc8);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc8;
					RTAR(Current, loc9);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc9;
				}
			}
		}
	}
	tb1 = '\0';
	tb2 = F1837_17818(RTCW(arg1));
	if (tb2) {
		tb2 = F1019_8135(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21488(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
		loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc4 || loc3);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_once_procedure_validity */
void F1231_11151 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,loc9);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc10);
	RTLR(5,loc11);
	RTLR(6,loc12);
	RTLR(7,tr2);
	RTLR(8,loc1);
	RTLR(9,loc4);
	RTLR(10,loc6);
	RTLR(11,loc5);
	RTLR(12,loc7);
	RTLR(13,loc8);
	RTLIU(14);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		F1231_11154(Current, loc9, arg1);
		loc3 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		F1231_11158(Current, loc10, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc11 = tr1;
	if (EIF_TEST(loc11)) {
		F1231_11160(Current, loc11, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	loc12 = tr1;
	if (EIF_TEST(loc12)) {
		F1231_11156(Current, loc12, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_9_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_21_);
	F1231_11168(Current, tr1, tr2);
	loc2 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	if ((EIF_BOOLEAN) !loc3) {
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		loc4 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 != NULL) && (EIF_BOOLEAN)(loc1 != NULL))) {
				loc6 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				F1250_11971(RTCW(tr1), loc6);
				loc5 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				F1250_11971(RTCW(tr1), loc5);
			}
		}
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			F1231_11208(Current, loc1);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
		}
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 != NULL) && (EIF_BOOLEAN)(loc6 != NULL))) {
					loc7 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
					loc8 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
					RTAR(Current, loc5);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc5;
					RTAR(Current, loc6);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc6;
				}
			}
			F1231_11209(Current, loc4);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc7 != NULL) && (EIF_BOOLEAN)(loc8 != NULL))) {
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
					RTAR(Current, loc7);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc7;
					RTAR(Current, loc8);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc8;
				}
			}
		}
	}
	tb1 = '\0';
	tb2 = F1837_17818(RTCW(arg1));
	if (tb2) {
		tb2 = F1019_8135(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21488(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || loc2);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_unique_attribute_validity */
void F1231_11152 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1839_17878(RTCW(arg1));
	F1231_11153(Current, loc1, arg1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		if (*(EIF_BOOLEAN *)(Current + O9279[dtype-1230])) {
		} else {
			F1231_11418(Current, loc1, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
		}
	}
	loc2 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		F1231_11158(Current, loc3, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		F1231_11160(Current, loc4, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || tb1);
	}
	if ((EIF_BOOLEAN) !loc2) {
		tr1 = F1231_11526(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12762[Dtype(tr1)-1610]);
		tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
		if (tb1) {
		} else {
			tr1 = F1231_11526(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12763[Dtype(tr1)-1610]);
			tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
			if (tb1) {
			} else {
				tr1 = F1231_11526(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12764[Dtype(tr1)-1610]);
				tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
				if (tb1) {
				} else {
					tr1 = F1231_11526(Current);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12765[Dtype(tr1)-1610]);
					tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
					if (tb1) {
					} else {
						tr1 = F1231_11526(Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12769[Dtype(tr1)-1610]);
						tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
						if (tb1) {
						} else {
							tr1 = F1231_11526(Current);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12770[Dtype(tr1)-1610]);
							tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
							if (tb1) {
							} else {
								tr1 = F1231_11526(Current);
								tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12771[Dtype(tr1)-1610]);
								tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
								if (tb1) {
								} else {
									tr1 = F1231_11526(Current);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12772[Dtype(tr1)-1610]);
									tb1 = F1884_18234(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
									if (tb1) {
									} else {
										F1033_8331(Current);
										tr1 = F1023_8173(Current);
										F2046_21455(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
									}
								}
							}
						}
					}
				}
			}
		}
	}
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc2);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_query_type_validity */
void F1231_11153 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[Dtype(Current)-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + O13761[Dtype(arg2)-1836]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10398[Dtype(RTCW(tr1))-1840])(tr1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1231_11162(Current, loc1);
	} else {
		F1033_8331(Current);
		F2046_21728(RTCV(F1023_8173(Current)));
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_formal_arguments_validity */
void F1231_11154 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc5);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,loc4);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_0_0_0_);
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + O13761[Dtype(arg2)-1836]);
		loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10399[Dtype(RTCW(tr1))-1840])(tr1);
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc5 == NULL)) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_3_0_0_0_);
			tb1 = (EIF_BOOLEAN)(ti4_1 != loc2);
		}
		if (tb1) {
			F1033_8331(Current);
			F2046_21728(RTCV(F1023_8173(Current)));
		} else {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				loc4 = F1649_16721(RTCW(arg1), loc1);
				loc3 = F1814_17596(RTCW(loc4));
				tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
				loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc6 || tb1);
				tr1 = F1649_16721(RTCW(loc5), loc1);
				tr1 = F1814_17596(RTCW(tr1));
				F1231_11162(Current, tr1);
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9178[dtype-1230])(Current, loc4);
					if (*(EIF_BOOLEAN *)(Current + O9279[dtype-1230])) {
					} else {
						F1231_11417(Current, loc3, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg2);
					}
				}
				loc1++;
			}
		}
	}
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc6);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_inline_agent_formal_arguments_validity */
void F1231_11155 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc11 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(18);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc7);
	RTLR(3,loc8);
	RTLR(4,loc9);
	RTLR(5,tr1);
	RTLR(6,arg2);
	RTLR(7,loc12);
	RTLR(8,loc10);
	RTLR(9,loc13);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLR(12,loc14);
	RTLR(13,loc15);
	RTLR(14,loc16);
	RTLR(15,loc17);
	RTLR(16,loc18);
	RTLR(17,loc6);
	RTLIU(18);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_0_0_0_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc7 = F1649_16721(RTCW(arg1), loc1);
			loc8 = F1814_17595(RTCW(loc7));
			F1987_19680(RTCW(loc8), (EIF_BOOLEAN) 1);
			F1944_19225(RTCW(loc8), loc1);
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc3 >= loc1)) break;
				loc9 = F1649_16721(RTCW(arg1), loc3);
				tr1 = F1814_17595(RTCW(loc9));
				tb1 = F1987_19688(RTCW(tr1), loc8);
				if (tb1) {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					F2046_21458(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc9, loc7, arg2, *(EIF_REFERENCE *)(Current + O9248[dtype-1230]));
				}
				loc3++;
			}
			tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tr1 = F140_1508(RTCW(tr1), loc8);
			loc12 = tr1;
			if (EIF_TEST(loc12)) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21463(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc7, arg2, *(EIF_REFERENCE *)(Current + O9248[dtype-1230]), loc12);
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
			loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc3 > loc5)) break;
				tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
				loc10 = F1541_13846(RTCW(tr1), loc3);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc10) + _REFACS_5_);
				loc13 = tr1;
				if (EIF_TEST(loc13)) {
					loc4 = F1649_16724(loc13, loc8);
					if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = F1649_16721(loc13, loc4);
						F2046_21437(RTCW(tr1), tr2, loc7, arg2, tr3);
					}
				}
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2905[Dtype(RTCW(loc10))-1755])(loc10);
				loc14 = tr1;
				if (EIF_TEST(loc14)) {
					loc4 = F1634_16568(loc14, loc8);
					if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = F1634_16566(loc14, loc4);
						F2046_21438(RTCW(tr1), tr2, loc7, arg2, tr3);
					}
				}
				loc3++;
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2903[Dtype(RTCW(tr1))-1755])(tr1);
			loc15 = tr1;
			if (EIF_TEST(loc15)) {
				loc4 = F1649_16724(loc15, loc8);
				if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr3 = F1649_16721(loc15, loc4);
					F2046_21437(RTCW(tr1), tr2, loc7, arg2, tr3);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2905[Dtype(RTCW(tr1))-1755])(tr1);
			loc16 = tr1;
			if (EIF_TEST(loc16)) {
				loc4 = F1634_16568(loc16, loc8);
				if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr3 = F1634_16566(loc16, loc4);
					F2046_21438(RTCW(tr1), tr2, loc7, arg2, tr3);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
			tr1 = F10_113(RTCW(tr1), loc8);
			loc17 = tr1;
			if (EIF_TEST(loc17)) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21441(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc7, arg2, loc17);
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
			tr1 = F11_126(RTCW(tr1), loc8);
			loc18 = tr1;
			if (EIF_TEST(loc18)) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21443(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc7, arg2, loc18);
			}
			loc6 = F1814_17596(RTCW(loc7));
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc11 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc11 || tb1);
			F1231_11162(Current, loc6);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9183[dtype-1230])(Current, loc7);
				F1231_11422(Current, loc6, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9248[dtype-1230]));
			}
			loc1++;
		}
	} else {
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_0_0_0_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc7 = F1649_16721(RTCW(arg1), loc1);
			loc6 = F1814_17596(RTCW(loc7));
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc11 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc11 || tb1);
			F1231_11162(Current, loc6);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9183[dtype-1230])(Current, loc7);
				F1231_11422(Current, loc6, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9248[dtype-1230]));
			}
			loc1++;
		}
	}
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc11);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_locals_validity */
void F1231_11156 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc5);
	RTLR(3,loc7);
	RTLR(4,loc6);
	RTLR(5,tr1);
	RTLR(6,arg2);
	RTLR(7,loc10);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLR(10,loc11);
	RTLR(11,loc8);
	RTLIU(12);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
		loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc4)) break;
			loc5 = F1634_16566(RTCW(arg1), loc1);
			loc7 = F1810_17562(RTCW(loc5));
			F1987_19676(RTCW(loc7), (EIF_BOOLEAN) 1);
			F1944_19225(RTCW(loc7), loc1);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc2 >= loc1)) break;
				loc6 = F1634_16566(RTCW(arg1), loc2);
				tr1 = F1810_17562(RTCW(loc6));
				tb1 = F1987_19688(RTCW(tr1), loc7);
				if (tb1) {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					F2046_21461(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc6, loc5, arg2);
				}
				loc2++;
			}
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10399[Dtype(RTCW(arg2))-1840])(arg2);
			loc10 = tr1;
			if (EIF_TEST(loc10)) {
				loc3 = F1649_16724(loc10, loc7);
				if ((EIF_BOOLEAN)(loc3 != ((EIF_INTEGER_32) 0L))) {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr3 = F1649_16721(loc10, loc3);
					F2046_21465(RTCW(tr1), tr2, loc5, arg2, tr3);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tr1 = F140_1508(RTCW(tr1), loc7);
			loc11 = tr1;
			if (EIF_TEST(loc11)) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21464(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc5, arg2, loc11);
			}
			loc8 = F1810_17563(RTCW(loc5));
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc9 || tb1);
			F1231_11163(Current, loc8);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9195[dtype-1230])(Current, loc5);
				F1231_11421(Current, loc8, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg2);
			}
			loc1++;
		}
	} else {
		loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc4)) break;
			loc5 = F1634_16566(RTCW(arg1), loc1);
			loc8 = F1810_17563(RTCW(loc5));
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc9 || tb1);
			F1231_11163(Current, loc8);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9195[dtype-1230])(Current, loc5);
				F1231_11421(Current, loc8, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg2);
			}
			loc1++;
		}
	}
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc9);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_inline_agent_locals_validity */
void F1231_11157 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc11 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(20);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc6);
	RTLR(3,loc8);
	RTLR(4,loc7);
	RTLR(5,tr1);
	RTLR(6,arg2);
	RTLR(7,loc12);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLR(10,tr4);
	RTLR(11,loc13);
	RTLR(12,loc9);
	RTLR(13,loc14);
	RTLR(14,loc15);
	RTLR(15,loc16);
	RTLR(16,loc17);
	RTLR(17,loc18);
	RTLR(18,loc19);
	RTLR(19,loc10);
	RTLIU(20);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
		loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			loc6 = F1634_16566(RTCW(arg1), loc1);
			loc8 = F1810_17562(RTCW(loc6));
			F1987_19676(RTCW(loc8), (EIF_BOOLEAN) 1);
			F1944_19225(RTCW(loc8), loc1);
			loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc4 >= loc1)) break;
				loc7 = F1634_16566(RTCW(arg1), loc4);
				tr1 = F1810_17562(RTCW(loc7));
				tb1 = F1987_19688(RTCW(tr1), loc8);
				if (tb1) {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					F2046_21459(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc7, loc6, arg2, *(EIF_REFERENCE *)(Current + O9248[dtype-1230]));
				}
				loc4++;
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_5_);
			loc12 = tr1;
			if (EIF_TEST(loc12)) {
				loc2 = F1649_16724(loc12, loc8);
				if ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 0L))) {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr3 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
					tr4 = F1649_16721(loc12, loc2);
					F2046_21469(RTCW(tr1), tr2, loc6, arg2, tr3, tr4);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tr1 = F140_1508(RTCW(tr1), loc8);
			loc13 = tr1;
			if (EIF_TEST(loc13)) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21467(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc6, arg2, *(EIF_REFERENCE *)(Current + O9248[dtype-1230]), loc13);
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
			loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
			loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc4 > loc5)) break;
				tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
				loc9 = F1541_13846(RTCW(tr1), loc4);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc9) + _REFACS_5_);
				loc14 = tr1;
				if (EIF_TEST(loc14)) {
					loc2 = F1649_16724(loc14, loc8);
					if ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 0L))) {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = F1649_16721(loc14, loc2);
						F2046_21439(RTCW(tr1), tr2, loc6, arg2, tr3);
					}
				}
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2905[Dtype(RTCW(loc9))-1755])(loc9);
				loc15 = tr1;
				if (EIF_TEST(loc15)) {
					loc2 = F1634_16568(loc15, loc8);
					if ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 0L))) {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = F1634_16566(loc15, loc2);
						F2046_21440(RTCW(tr1), tr2, loc6, arg2, tr3);
					}
				}
				loc4++;
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2903[Dtype(RTCW(tr1))-1755])(tr1);
			loc16 = tr1;
			if (EIF_TEST(loc16)) {
				loc2 = F1649_16724(loc16, loc8);
				if ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 0L))) {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr3 = F1649_16721(loc16, loc2);
					F2046_21439(RTCW(tr1), tr2, loc6, arg2, tr3);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2905[Dtype(RTCW(tr1))-1755])(tr1);
			loc17 = tr1;
			if (EIF_TEST(loc17)) {
				loc2 = F1634_16568(loc17, loc8);
				if ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 0L))) {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr3 = F1634_16566(loc17, loc2);
					F2046_21440(RTCW(tr1), tr2, loc6, arg2, tr3);
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
			tr1 = F10_113(RTCW(tr1), loc8);
			loc18 = tr1;
			if (EIF_TEST(loc18)) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21442(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc6, arg2, loc18);
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
			tr1 = F11_126(RTCW(tr1), loc8);
			loc19 = tr1;
			if (EIF_TEST(loc19)) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21444(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc6, arg2, loc19);
			}
			loc10 = F1810_17563(RTCW(loc6));
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc11 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc11 || tb1);
			F1231_11163(Current, loc10);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9184[dtype-1230])(Current, loc6);
				F1231_11423(Current, loc10, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9248[dtype-1230]));
			}
			loc1++;
		}
	} else {
		loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			loc6 = F1634_16566(RTCW(arg1), loc1);
			loc10 = F1810_17563(RTCW(loc6));
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc11 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc11 || tb1);
			F1231_11163(Current, loc10);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9184[dtype-1230])(Current, loc6);
				F1231_11423(Current, loc10, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9248[dtype-1230]));
			}
			loc1++;
		}
	}
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc11);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_object_tests_validity */
void F1231_11158 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,loc6);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,loc5);
	RTLR(7,arg2);
	RTLIU(8);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
		loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_0_0_0_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			loc4 = F903_7078(RTCW(arg1), loc1);
			loc6 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_4_);
			F1987_19677(RTCW(loc6), (EIF_BOOLEAN) 1);
			F1944_19225(RTCW(loc6), loc1);
			tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
			tr2 = RTOUCR(541,F482_6193, (Current));
			tb1 = F1290_12728(RTCW(tr1), tr2);
			if (tb1) {
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc2 >= loc1)) break;
					loc5 = F903_7078(RTCW(arg1), loc2);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_4_);
					tb1 = F1987_19688(RTCW(tr1), loc6);
					if (tb1) {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21509(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc4, loc5, arg2);
					}
					loc2++;
				}
			}
			loc1++;
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_inline_agent_object_tests_validity */
void F1231_11159 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,loc6);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,loc5);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
		loc3 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_0_0_0_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			loc4 = F903_7078(RTCW(arg1), loc1);
			loc6 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_4_);
			F1987_19677(RTCW(loc6), (EIF_BOOLEAN) 1);
			F1944_19225(RTCW(loc6), loc1);
			tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
			tr2 = RTOUCR(541,F482_6193, (Current));
			tb1 = F1290_12728(RTCW(tr1), tr2);
			if (tb1) {
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc2 >= loc1)) break;
					loc5 = F903_7078(RTCW(arg1), loc2);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_4_);
					tb1 = F1987_19688(RTCW(tr1), loc6);
					if (tb1) {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21510(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc4, loc5);
					}
					loc2++;
				}
			}
			loc1++;
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_iteration_components_validity */
void F1231_11160 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,loc4);
	RTLIU(4);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_0_0_0_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc3 = F902_7074(RTCW(arg1), loc1);
			loc4 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_1_);
			F1987_19678(RTCW(loc4), (EIF_BOOLEAN) 1);
			F1944_19225(RTCW(loc4), loc1);
			loc4 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_2_);
			F1987_19678(RTCW(loc4), (EIF_BOOLEAN) 1);
			F1944_19225(RTCW(loc4), loc1);
			loc1++;
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_inline_agent_iteration_components_validity */
void F1231_11161 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,loc4);
	RTLIU(4);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_0_0_0_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc3 = F902_7074(RTCW(arg1), loc1);
			loc4 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_1_);
			F1987_19678(RTCW(loc4), (EIF_BOOLEAN) 1);
			F1944_19225(RTCW(loc4), loc1);
			loc4 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_2_);
			F1987_19678(RTCW(loc4), (EIF_BOOLEAN) 1);
			F1944_19225(RTCW(loc4), loc1);
			loc1++;
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_signature_type_validity */
void F1231_11162 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLIU(8);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if (*(EIF_BOOLEAN *)(Current + O9279[dtype-1230])) {
	} else {
		loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
		tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
			F1035_8343(RTCW(tr1), arg1, loc2, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
			F1035_8343(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1);
		}
		F1231_11572(Current, loc1);
		tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_11_0_);
		if (tb1) {
			F1033_8331(Current);
		} else {
			loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			tb1 = F1884_18214(RTCW(arg1), loc1);
			if (tb1) {
				tr1 = F1884_18203(RTCW(arg1), loc1);
				loc3 = tr1;
				loc3 = RTRV(eif_new_type(2023, 0x01),loc3);
				if (EIF_TEST(loc3)) {
					tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
					tr2 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
					tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13062[Dtype(RTCW(arg1))-1627])(arg1);
					F1035_8344(RTCW(tr1), loc3, tr2, loc1, tr3);
					tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
					tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_11_0_);
					if (tb1) {
						F1033_8331(Current);
					}
				}
			}
			F1231_11572(Current, loc1);
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_local_type_validity */
void F1231_11163 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
	tr2 = F1231_11523(Current);
	tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
	F1035_8343(RTCW(tr1), arg1, tr2, tr3, loc1);
	F1231_11572(Current, loc1);
	tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_11_0_);
	if (tb1) {
		F1033_8331(Current);
	} else {
		loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
		tb1 = F1884_18214(RTCW(arg1), loc1);
		if (tb1) {
			tr1 = F1884_18203(RTCW(arg1), loc1);
			loc2 = tr1;
			loc2 = RTRV(eif_new_type(2023, 0x01),loc2);
			if (EIF_TEST(loc2)) {
				tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
				tr2 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
				tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13062[Dtype(RTCW(arg1))-1627])(arg1);
				F1035_8344(RTCW(tr1), loc2, tr2, loc1, tr3);
				tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
				tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_11_0_);
				if (tb1) {
					F1033_8331(Current);
				}
			}
		}
		F1231_11572(Current, loc1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_type_validity */
void F1231_11164 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
	tr2 = F1231_11523(Current);
	tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
	F1035_8343(RTCW(tr1), arg1, tr2, tr3, loc1);
	F1231_11572(Current, loc1);
	tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_11_0_);
	if (tb1) {
		F1033_8331(Current);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.is_type_valid */
EIF_BOOLEAN F1231_11165 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
	F1035_8355(RTCW(tr1), (EIF_BOOLEAN) 1);
	tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
	tr2 = F1231_11523(Current);
	tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
	F1035_8343(RTCW(tr1), arg1, tr2, tr3, loc1);
	tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
	F1035_8355(RTCW(tr1), (EIF_BOOLEAN) 0);
	F1231_11572(Current, loc1);
	tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_11_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {ET_FEATURE_CHECKER}.check_creation_type_validity */
void F1231_11166 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
	F1035_8344(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1, arg2);
	F1231_11572(Current, loc1);
	tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_11_0_);
	if (tb1) {
		F1033_8331(Current);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_once_keys_validity */
void F1231_11168 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc7);
	RTLR(6,loc6);
	RTLR(7,arg1);
	RTLR(8,loc10);
	RTLR(9,loc3);
	RTLR(10,loc4);
	RTLR(11,loc5);
	RTLIU(12);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		loc1 = *(EIF_REFERENCE *)(Current + O9287[dtype-1230]);
		tr1 = RTOUCR(2754,F396_5255, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		F1644_16668(RTCW(arg2), tr1, loc1);
		loc9 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_4_0_0_1_);
		loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc8 > loc9)) break;
			loc2 = F1541_13846(RTCW(loc1), loc8);
			tr1 = RTOUCR(2755,F396_5257, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R13310[Dtype(RTCW(loc2))-1694])(loc2, tr1);
			if (tb1) {
				loc7 = (EIF_REFERENCE) loc2;
				if ((EIF_BOOLEAN)(loc6 != NULL)) {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					F2046_21517(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc6, loc2);
				}
			} else {
				tr1 = RTOUCR(2756,F396_5258, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R13310[Dtype(RTCW(loc2))-1694])(loc2, tr1);
				if (tb1) {
					loc6 = (EIF_REFERENCE) loc2;
					if ((EIF_BOOLEAN)(loc7 != NULL)) {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21517(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc7, loc2);
					}
				} else {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					F2046_21519(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc2);
				}
			}
			loc8++;
		}
		F1541_13892(RTCW(loc1));
	}
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc9 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_0_0_0_);
		loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc8 > loc9)) break;
			loc10 = F1638_16603(RTCW(arg1), loc8);
			tr1 = RTOUCR(2935,F195_1837, (Current));
			tb1 = F1248_11885(RTCW(tr1), loc10);
			if (tb1) {
				loc3 = (EIF_REFERENCE) loc10;
				if ((EIF_BOOLEAN)(loc4 != NULL)) {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					F2046_21515(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc4, loc10);
				} else {
					if ((EIF_BOOLEAN)(loc5 != NULL)) {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21515(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc5, loc10);
					} else {
						if ((EIF_BOOLEAN)(loc6 != NULL)) {
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							F2046_21516(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc6, loc10);
						} else {
							if ((EIF_BOOLEAN)(loc7 != NULL)) {
								F1033_8331(Current);
								tr1 = F1023_8173(Current);
								F2046_21516(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc7, loc10);
							}
						}
					}
				}
			} else {
				tr1 = RTOUCR(2935,F195_1837, (Current));
				tb1 = F1248_11887(RTCW(tr1), loc10);
				if (tb1) {
					loc4 = (EIF_REFERENCE) loc10;
					if ((EIF_BOOLEAN)(loc3 != NULL)) {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21515(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc3, loc10);
					} else {
						if ((EIF_BOOLEAN)(loc5 != NULL)) {
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							F2046_21515(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc5, loc10);
						} else {
							if ((EIF_BOOLEAN)(loc7 != NULL)) {
								F1033_8331(Current);
								tr1 = F1023_8173(Current);
								F2046_21516(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc7, loc10);
							}
						}
					}
				} else {
					tr1 = RTOUCR(2935,F195_1837, (Current));
					tb1 = F1248_11889(RTCW(tr1), loc10);
					if (tb1) {
						loc5 = (EIF_REFERENCE) loc10;
						if ((EIF_BOOLEAN)(loc3 != NULL)) {
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							F2046_21515(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc3, loc10);
						} else {
							if ((EIF_BOOLEAN)(loc4 != NULL)) {
								F1033_8331(Current);
								tr1 = F1023_8173(Current);
								F2046_21515(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc4, loc10);
							} else {
								if ((EIF_BOOLEAN)(loc6 != NULL)) {
									F1033_8331(Current);
									tr1 = F1023_8173(Current);
									F2046_21516(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc6, loc10);
								}
							}
						}
					} else {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21518(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc10);
					}
				}
			}
			loc8++;
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_across_instruction_validity */
void F1231_11169 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11186(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.check_assigner_instruction_validity */
void F1231_11170 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc16 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(23);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc3);
	RTLR(4,loc2);
	RTLR(5,loc4);
	RTLR(6,loc17);
	RTLR(7,tr1);
	RTLR(8,loc7);
	RTLR(9,loc10);
	RTLR(10,loc14);
	RTLR(11,loc18);
	RTLR(12,loc9);
	RTLR(13,loc19);
	RTLR(14,loc11);
	RTLR(15,loc5);
	RTLR(16,loc6);
	RTLR(17,loc12);
	RTLR(18,loc15);
	RTLR(19,tr2);
	RTLR(20,tr3);
	RTLR(21,tr4);
	RTLR(22,tr5);
	RTLIU(23);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	loc2 = F1231_11568(Current, loc3);
	loc4 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(loc1))-1794])(loc1);
	loc17 = tr1;
	if (EIF_TEST(loc17)) {
		F1231_11258(Current, loc17, loc4, loc2);
		loc7 = *(EIF_REFERENCE *)(loc17 + _REFACS_1_);
	} else {
		F1231_11258(Current, loc1, loc4, loc2);
		loc7 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13378[Dtype(RTCW(loc1))-1748])(loc1);
	}
	F1231_11572(Current, loc4);
	loc10 = eif_boxed_item(loc2,2);
	loc14 = eif_boxed_item(loc2,1);
	F1231_11569(Current, loc2);
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
	} else {
		if ((EIF_BOOLEAN)(loc14 != NULL)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
			loc8 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O14497[Dtype(tr1)-1943]);
			if ((EIF_BOOLEAN)(loc8 == ((EIF_INTEGER_32) 0L))) {
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) != *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
					F1033_8331(Current);
					if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
						F2046_21728(RTCV(F1023_8173(Current)));
					}
				} else {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc14) + O13774[Dtype(loc14)-1838]);
					loc18 = tr1;
					if (EIF_TEST(loc18)) {
						tr1 = F1951_19381(loc18);
						loc8 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O14497[Dtype(tr1)-1943]);
						if ((EIF_BOOLEAN)(loc8 == ((EIF_INTEGER_32) 0L))) {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						} else {
							tr1 = F1951_19381(loc18);
							F1985_19637(RTCW(arg1), tr1);
						}
					} else {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21253(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1, loc14, loc10);
					}
				}
			}
			if ((EIF_BOOLEAN)(loc8 != ((EIF_INTEGER_32) 0L))) {
				loc9 = F2027_20748(RTCW(loc10), loc8);
				if ((EIF_BOOLEAN)(loc9 == NULL)) {
					F1033_8331(Current);
					F2046_21728(RTCV(F1023_8173(Current)));
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
			tb1 = F1290_12726(RTCW(tr1));
			if (tb1) {
				if ((EIF_BOOLEAN)(loc9 == NULL)) {
				} else {
					tb1 = '\01';
					tr1 = *(EIF_REFERENCE *)(RTCW(loc9) + _REFACS_5_);
					loc19 = tr1;
					if (!((EIF_BOOLEAN) !EIF_TEST(loc19))) {
						ti4_1 = *(EIF_INTEGER_32 *)(loc19+ _LNGOFF_3_0_0_0_);
						tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
					}
					if (tb1) {
						F1033_8331(Current);
						F2046_21728(RTCV(F1023_8173(Current)));
					} else {
						tb1 = F2027_20678(RTCW(loc10));
						if (tb1) {
							ti4_1 = F1837_17834(RTCW(loc9));
							tr1 = F1649_16721(loc19, ti4_1);
							loc11 = F1814_17596(RTCW(tr1));
						} else {
							tr1 = F1649_16721(loc19, ((EIF_INTEGER_32) 1L));
							loc11 = F1814_17596(RTCW(tr1));
						}
					}
				}
			} else {
				loc11 = F1839_17878(RTCW(loc14));
			}
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14504[Dtype(RTCW(loc7))-1944])(loc7);
			if (tb1) {
				loc13 = *(EIF_INTEGER_32 *)(RTCW(loc7) + O14497[Dtype(loc7)-1943]);
				F1985_19637(RTCW(arg1), loc7);
				tb1 = F2027_20603(RTCW(loc10));
				if ((EIF_BOOLEAN) !tb1) {
					F1033_8331(Current);
					F2046_21728(RTCV(F1023_8173(Current)));
				} else {
					if ((EIF_BOOLEAN)(loc13 == ((EIF_INTEGER_32) 0L))) {
						F1033_8331(Current);
						F2046_21728(RTCV(F1023_8173(Current)));
					} else {
						ti4_1 = F2023_20402(RTCW(loc3));
						if ((EIF_BOOLEAN) (loc13 > ti4_1)) {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						} else {
							loc11 = F2027_20699(RTCW(loc10), loc13);
						}
					}
				}
			} else {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		}
	}
	loc5 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc6 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	if ((EIF_BOOLEAN)(loc11 == NULL)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12741[Dtype(tr1)-1610]);
		F1231_11290(Current, loc5, loc6, tr1);
		*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		F899_7054(RTCW(loc3), loc11);
		loc12 = (EIF_REFERENCE) loc3;
		loc16 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		F1231_11290(Current, loc5, loc6, loc12);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			tb1 = F2022_20379(RTCW(loc6), loc12, *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
			if ((EIF_BOOLEAN) !tb1) {
				loc15 = F1231_11340(Current, loc5, loc6, loc12);
				if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				} else {
					if ((EIF_BOOLEAN)(loc15 != NULL)) {
						F1985_19635(RTCW(arg1), loc15);
					} else {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
						tr4 = F2022_20345(RTCW(loc6));
						tr5 = F2022_20345(RTCW(loc12));
						F2046_21252(RTCW(tr1), tr2, tr3, arg1, tr4, tr5);
					}
				}
			}
		}
		F899_7057(RTCW(loc3));
		*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc16);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14504[Dtype(RTCW(loc7))-1944])(loc7);
			if (tb1) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9230[dtype-1230])(Current, arg1, loc3);
			} else {
				if ((EIF_BOOLEAN)(loc9 != NULL)) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9214[dtype-1230])(Current, arg1, loc3, loc9);
				}
			}
		}
	}
	F1231_11572(Current, loc6);
	F1231_11572(Current, loc3);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_assignment_validity */
void F1231_11171 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(15);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLR(10,tr4);
	RTLR(11,tr5);
	RTLR(12,loc7);
	RTLR(13,loc8);
	RTLR(14,loc9);
	RTLIU(15);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc2 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	F1231_11289(Current, loc1, loc2);
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		F899_7060(RTCW(loc2));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12741[Dtype(tr1)-1610]);
		F899_7054(RTCW(loc2), tr1);
	}
	loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc4 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	F1231_11290(Current, loc3, loc4, loc2);
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc6);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		tb1 = F2022_20379(RTCW(loc4), loc2, *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
		if ((EIF_BOOLEAN) !tb1) {
			loc5 = F1231_11340(Current, loc3, loc4, loc2);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			} else {
				if ((EIF_BOOLEAN)(loc5 != NULL)) {
					F1963_19499(RTCW(arg1), loc5);
				} else {
					tb1 = '\0';
					tb2 = '\0';
					tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
					tb3 = F1290_12726(RTCW(tr1));
					if (tb3) {
						tb2 = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) != *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
					}
					if (tb2) {
						tb2 = '\01';
						tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tb3 = F2027_20577(RTCW(tr1));
						if (!tb3) {
							tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tb3 = F2027_20605(RTCW(tr1));
							tb2 = tb3;
						}
						tb1 = tb2;
					}
					if (tb1) {
					} else {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
						tr4 = F2022_20345(RTCW(loc4));
						tr5 = F2022_20345(RTCW(loc2));
						F2046_21396(RTCW(tr1), tr2, tr3, arg1, tr4, tr5);
					}
				}
			}
		}
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				loc7 = loc1;
				loc7 = RTRV(eif_new_type(1925, 0x01),loc7);
				if (EIF_TEST(loc7)) {
					tb1 = F2022_20357(RTCW(loc2));
					if ((EIF_BOOLEAN) !tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
						F1250_11963(RTCW(tr1));
					} else {
						tb1 = '\0';
						tr1 = F1231_11523(Current);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2902[Dtype(RTCW(tr1))-1755])(tr1);
						loc8 = tr1;
						if (EIF_TEST(loc8)) {
							tb2 = F1884_18220(loc8, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) {
							tb1 = F1884_18218(loc8, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
							if (tb1) {
								tb1 = F2022_20355(RTCW(loc4));
								if (tb1) {
									tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
									F1250_11963(RTCW(tr1));
								} else {
									tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
									F1250_11968(RTCW(tr1));
								}
							} else {
								tb1 = F2022_20357(RTCW(loc4));
								if ((EIF_BOOLEAN) !tb1) {
									tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
									F1250_11963(RTCW(tr1));
								} else {
									tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
									F1250_11968(RTCW(tr1));
								}
							}
						}
					}
					tb1 = F2022_20355(RTCW(loc2));
					if ((EIF_BOOLEAN) !tb1) {
						tb1 = F2022_20355(RTCW(loc4));
						if (tb1) {
							tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
							F1250_11963(RTCW(tr1));
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
							F1250_11968(RTCW(tr1));
						}
					}
				} else {
					loc9 = loc1;
					loc9 = RTRV(eif_new_type(1986, 0x01),loc9);
					if (EIF_TEST(loc9)) {
						tb1 = F2022_20357(RTCW(loc2));
						if ((EIF_BOOLEAN) !tb1) {
							tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
							F1250_11964(RTCW(tr1), loc9);
						}
						tb1 = F2022_20355(RTCW(loc2));
						if ((EIF_BOOLEAN) !tb1) {
							tb1 = F2022_20355(RTCW(loc4));
							if (tb1) {
								tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
								F1250_11964(RTCW(tr1), loc9);
							} else {
								tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
								F1250_11969(RTCW(tr1), loc9);
							}
						}
					}
				}
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9165[dtype-1230])(Current, arg1);
		}
	}
	F1231_11572(Current, loc4);
	F1231_11572(Current, loc2);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_assignment_attempt_validity */
void F1231_11172 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,loc5);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc2 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	F1231_11289(Current, loc1, loc2);
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		F899_7060(RTCW(loc2));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12741[Dtype(tr1)-1610]);
		F899_7054(RTCW(loc2), tr1);
	} else {
		tb1 = '\0';
		tb2 = '\01';
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb3 = *(EIF_BOOLEAN *)(RTCW(tr1) + O12984[Dtype(tr1)-1616]);
		if (!tb3) {
			tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
			tr2 = RTOUCR(535,F482_6171, (Current));
			tb3 = F1290_12731(RTCW(tr1), tr2);
			tb2 = tb3;
		}
		if ((EIF_BOOLEAN) !tb2) {
			tb2 = F2022_20353(RTCW(loc2));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
				loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				F1033_8331(Current);
				loc5 = F2022_20345(RTCW(loc2));
				tr1 = F1023_8173(Current);
				F2046_21400(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1, loc5);
			} else {
				tb1 = '\01';
				tr1 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
				tb2 = F2027_20578(RTCW(tr1));
				if (!(EIF_BOOLEAN) !tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
					tb2 = F1290_12726(RTCW(tr1));
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) {
					loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					F1033_8331(Current);
					loc5 = F2022_20345(RTCW(loc2));
					tr1 = F1023_8173(Current);
					F2046_21400(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1, loc5);
				}
			}
		}
	}
	loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc4 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	F1231_11290(Current, loc3, loc4, loc2);
	if (loc6) {
		F1033_8331(Current);
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9166[dtype-1230])(Current, arg1);
	}
	F1231_11572(Current, loc4);
	F1231_11572(Current, loc2);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_bang_instruction_validity */
void F1231_11173 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11176(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.check_check_instruction_validity */
void F1231_11174 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc9);
	RTLR(5,loc8);
	RTLR(6,arg1);
	RTLR(7,loc11);
	RTLR(8,loc5);
	RTLR(9,loc12);
	RTLIU(10);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = F1231_11526(Current);
	loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
	loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	*(EIF_BOOLEAN *)(Current + O9278[dtype-1230]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	loc7 = F10_115(RTCW(tr1));
	loc9 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
	loc8 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
	tb1 = '\0';
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb2 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		tb1 = (EIF_BOOLEAN)(tr1 == NULL);
	}
	if (tb1) {
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
		F1250_11971(RTCW(tr1), loc9);
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
		F1250_11971(RTCW(tr1), loc8);
	}
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_0_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = F1909_18730(RTCW(arg1), loc1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13235[Dtype(RTCW(tr1))-1666])(tr1);
		loc11 = tr1;
		if (EIF_TEST(loc11)) {
			F1231_11290(Current, loc11, loc3, loc4);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tb1 = F2022_20365(RTCW(loc3), loc4, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
				if ((EIF_BOOLEAN) !tb1) {
					F1033_8331(Current);
					loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc5 = F2022_20345(RTCW(loc3));
					tr1 = F1023_8173(Current);
					F2046_21520(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc11, loc5);
				}
			}
			F899_7060(RTCW(loc3));
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13403[Dtype(loc11)-1731])(loc11);
			if (tb1) {
				loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
			F1034_8335(RTCW(tr1), loc11, *(EIF_REFERENCE *)(Current + O9260[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
			tb1 = '\01';
			if (!loc6) {
				tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
				tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
				tb1 = tb2;
			}
			loc6 = (EIF_BOOLEAN) tb1;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
				F260_2862(RTCW(tr1), loc11, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
			}
		}
		loc1++;
	}
	*(EIF_BOOLEAN *)(Current + O9278[dtype-1230]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F1231_11572(Current, loc3);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	loc12 = tr1;
	if (EIF_TEST(loc12)) {
		if (loc10) {
			tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
			F1250_11970(RTCW(tr1), (EIF_BOOLEAN) 1);
			tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
			F1250_11970(RTCW(tr1), (EIF_BOOLEAN) 1);
		}
		F1231_11208(Current, loc12);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	} else {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
			F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
			RTAR(Current, loc8);
			*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc8;
			RTAR(Current, loc9);
			*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc9;
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	F10_119(RTCW(tr1), loc7);
	if (loc6) {
		F1033_8331(Current);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_create_instruction_validity */
void F1231_11175 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11176(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.check_creation_instruction_validity */
void F1231_11176 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc12 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc14 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc15 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,Current);
	RTLR(1,loc7);
	RTLR(2,arg1);
	RTLR(3,loc8);
	RTLR(4,loc9);
	RTLR(5,tr1);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLR(9,loc1);
	RTLR(10,loc11);
	RTLR(11,loc10);
	RTLR(12,loc2);
	RTLR(13,loc16);
	RTLR(14,loc17);
	RTLR(15,loc18);
	RTLIU(16);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc7 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	if ((EIF_BOOLEAN)(loc7 != NULL)) {
		loc8 = F1785_17456(RTCW(loc7));
		loc6 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O14497[Dtype(loc8)-1943]);
	} else {
		loc7 = *(EIF_REFERENCE *)(Current + O9309[dtype-1230]);
		loc9 = F1627_16497(RTCW(arg1));
		tr1 = *(EIF_REFERENCE *)(Current + O9310[dtype-1230]);
		ti4_1 = F1286_12618(RTCW(loc9));
		ti4_2 = F1286_12619(RTCW(loc9));
		F1286_12620(RTCW(tr1), ti4_1, ti4_2);
		loc8 = *(EIF_REFERENCE *)(Current + O9310[dtype-1230]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O12987[Dtype(tr1)-1616]);
	}
	loc3 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc4 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13374[Dtype(RTCW(arg1))-1746])(arg1);
	loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	if ((EIF_BOOLEAN)(loc5 != NULL)) {
		F1231_11164(Current, loc5);
	}
	loc15 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	F1231_11289(Current, loc3, loc4);
	F1033_8332(Current, (EIF_BOOLEAN) (loc15 || *(EIF_BOOLEAN *)(Current + O7067[dtype-1032])));
	loc11 = F1231_11337(Current);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			F899_7054(RTCW(loc1), loc5);
		} else {
			tr1 = F899_7045(RTCW(loc4));
			F899_7054(RTCW(loc1), tr1);
		}
		F2023_20412(RTCW(loc1), loc11);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc11)+ _LNGOFF_4_0_0_1_);
		loc12 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
		F1231_11334(Current, loc8, loc11, loc1);
	}
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F1231_11293(Current, loc7);
	} else {
		if ((EIF_BOOLEAN)(loc6 == ((EIF_INTEGER_32) 0L))) {
			loc10 = F1541_13847(RTCW(loc11));
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc10))-1835])(loc10);
			if ((EIF_BOOLEAN)(loc7 == *(EIF_REFERENCE *)(Current + O9309[dtype-1230]))) {
				F1231_11178(Current, arg1, loc7, NULL, loc10, loc12, loc4, loc1);
			} else {
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
					F1033_8331(Current);
					if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
						F2046_21728(RTCV(F1023_8173(Current)));
					}
					F1231_11293(Current, loc7);
				} else {
					tb1 = F2027_20678(RTCW(loc2));
					if (tb1) {
						F1231_11177(Current, arg1, loc7, loc10, loc12, loc4, loc1);
					} else {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1485[Dtype(RTCW(loc10))-1835])(loc10, loc8);
						loc16 = tr1;
						if (EIF_TEST(loc16)) {
							loc6 = *(EIF_INTEGER_32 *)(loc16 + O10400[Dtype(loc16)-1302]);
							F1944_19225(RTCW(loc8), loc6);
							F1231_11178(Current, arg1, loc7, loc16, loc10, loc12, loc4, loc1);
						} else {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1484[Dtype(RTCW(loc10))-1835])(loc10, loc8);
							loc17 = tr1;
							if (EIF_TEST(loc17)) {
								F1033_8331(Current);
								tr1 = F1023_8173(Current);
								F2046_21363(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc8, loc17, loc2);
								F1231_11293(Current, loc7);
							} else {
								F1033_8331(Current);
								tr1 = F1023_8173(Current);
								F2046_21498(RTCW(tr1), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc8, loc2);
								F1231_11293(Current, loc7);
							}
						}
					}
				}
			}
		} else {
			tb1 = F1432_13373(RTCW(loc11));
			if (tb1) {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
				F1231_11293(Current, loc7);
			} else {
				loc14 = *(EIF_INTEGER_32 *)(RTCW(loc11)+ _LNGOFF_4_0_0_1_);
				loc13 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc13 > loc14)) break;
					loc10 = F1541_13846(RTCW(loc11), loc13);
					loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc10))-1835])(loc10);
					tr1 = F2027_20748(RTCW(loc2), loc6);
					loc18 = tr1;
					if (EIF_TEST(loc18)) {
						F1231_11178(Current, arg1, loc7, loc18, loc10, loc12, loc4, loc1);
					} else {
						tb1 = F2027_20576(RTCW(loc2));
						if (tb1) {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						} else {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						loc13 = (EIF_INTEGER_32) loc14;
					}
					loc13++;
				}
			}
		}
	}
	F1231_11572(Current, loc1);
	F1231_11572(Current, loc4);
	F1231_11338(Current, loc11);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_dotnet_creation_procedure_call_instruction_validity */
void F1231_11177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_BOOLEAN arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg3);
	RTLR(3,loc4);
	RTLR(4,arg2);
	RTLR(5,loc5);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,arg6);
	RTLR(9,loc2);
	RTLR(10,arg1);
	RTLR(11,arg5);
	RTLR(12,loc6);
	RTLIU(13);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(arg3))-1835])(arg3);
	loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13531[Dtype(RTCW(arg2))-1780])(arg2);
	loc5 = F1231_11559(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1488[Dtype(RTCW(arg3))-1835])(arg3, loc4, loc5);
	tb1 = F1432_13373(RTCW(loc5));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = F1231_11336(Current, loc4, arg3);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13532[Dtype(RTCW(arg2))-1780])(arg2);
		F1231_11558(Current, loc5, tr1, tr2, arg6, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 1);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			F1231_11293(Current, arg2);
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_4_0_0_1_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
				loc2 = F1541_13847(RTCW(loc5));
				loc3 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O10400[Dtype(loc2)-1302]);
				F1944_19225(RTCW(loc4), loc3);
				F1231_11178(Current, arg1, arg2, loc2, arg3, arg4, arg5, arg6);
			} else {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
				F1231_11293(Current, arg2);
			}
		}
	} else {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1484[Dtype(RTCW(arg3))-1835])(arg3, loc4);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21363(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc4, loc6, loc1);
			F1231_11293(Current, arg2);
		} else {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21498(RTCW(tr1), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc4, loc1);
			F1231_11293(Current, arg2);
		}
	}
	F1231_11560(Current, loc5);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_creation_procedure_call_instruction_validity */
void F1231_11178 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_BOOLEAN arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(24);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg4);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,loc3);
	RTLR(6,arg7);
	RTLR(7,loc4);
	RTLR(8,loc5);
	RTLR(9,tr1);
	RTLR(10,arg6);
	RTLR(11,tr2);
	RTLR(12,tr3);
	RTLR(13,tr4);
	RTLR(14,tr5);
	RTLR(15,loc6);
	RTLR(16,loc9);
	RTLR(17,arg3);
	RTLR(18,arg2);
	RTLR(19,loc10);
	RTLR(20,loc7);
	RTLR(21,loc11);
	RTLR(22,loc12);
	RTLR(23,loc13);
	RTLIU(24);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(arg4))-1835])(arg4);
	loc2 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc3 = F899_7046(RTCW(arg7));
	F899_7057(RTCW(arg7));
	loc4 = F1884_18203(RTCW(loc3), arg7);
	F899_7053(RTCW(arg7), loc3);
	loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13374[Dtype(RTCW(arg1))-1746])(arg1);
	if ((EIF_BOOLEAN)(loc5 != NULL)) {
		tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr3 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
		tb1 = F2022_20380(RTCW(arg7), tr1, arg6, tr2, tr3);
		if ((EIF_BOOLEAN) !tb1) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
			tr4 = F2022_20345(RTCW(arg7));
			tr5 = F2022_20345(RTCW(arg6));
			F2046_21358(RTCW(tr1), tr2, tr3, arg1, tr4, tr5);
		} else {
			F1231_11420(Current, loc3, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9248[dtype-1230]));
		}
		loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13062[Dtype(RTCW(loc5))-1627])(loc5);
	} else {
		loc6 = F1914_18794(RTCW(loc2));
	}
	loc9 = loc4;
	loc9 = RTRV(eif_new_type(2023, 0x01),loc9);
	if (EIF_TEST(loc9)) {
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc5 == NULL)) {
			tb1 = (EIF_BOOLEAN) !F1231_11165(Current, loc9);
		}
		if (tb1) {
			F1033_8331(Current);
		} else {
			loc8 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			F1231_11166(Current, loc9, loc6);
		}
	}
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc8 || tb1);
	if ((EIF_BOOLEAN)(arg3 == NULL)) {
		F1231_11181(Current, arg1, arg2, loc1, arg7);
	} else {
		loc10 = loc4;
		loc10 = RTRV(eif_new_type(1885, 0x01),loc10);
		if (EIF_TEST(loc10)) {
			if (arg5) {
				loc7 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
				F2023_20428(RTCW(loc7), arg7);
				tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
				F1037_8385(RTCW(tr1), arg5, arg4, loc7);
				F1231_11180(Current, arg1, arg2, arg3, loc1, loc10, loc7);
				F1231_11572(Current, loc7);
			} else {
				F1231_11180(Current, arg1, arg2, arg3, loc1, loc10, arg7);
			}
		} else {
			F1231_11179(Current, arg1, arg2, arg3, loc1, arg7);
		}
	}
	F1033_8332(Current, (EIF_BOOLEAN) (loc8 || *(EIF_BOOLEAN *)(Current + O7067[dtype-1032])));
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			loc11 = loc2;
			loc11 = RTRV(eif_new_type(1925, 0x01),loc11);
			if (EIF_TEST(loc11)) {
				tb1 = F2022_20357(RTCW(arg6));
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
					F1250_11963(RTCW(tr1));
				} else {
					tb1 = '\0';
					tr1 = F1231_11523(Current);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2902[Dtype(RTCW(tr1))-1755])(tr1);
					loc12 = tr1;
					if (EIF_TEST(loc12)) {
						tb2 = F1884_18220(loc12, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
						F1250_11963(RTCW(tr1));
					}
				}
				tb1 = F2022_20355(RTCW(arg6));
				if ((EIF_BOOLEAN) !tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
					F1250_11963(RTCW(tr1));
				}
			} else {
				loc13 = loc2;
				loc13 = RTRV(eif_new_type(1986, 0x01),loc13);
				if (EIF_TEST(loc13)) {
					tb1 = F2022_20357(RTCW(arg6));
					if ((EIF_BOOLEAN) !tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
						F1250_11964(RTCW(tr1), loc13);
					}
					tb1 = F2022_20355(RTCW(arg6));
					if ((EIF_BOOLEAN) !tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
						F1250_11964(RTCW(tr1), loc13);
					}
				}
			}
			tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R13938[Dtype(RTCW(loc4))-1885])(loc4, tr1);
			loc4 = (EIF_REFERENCE) tr1;
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9174[dtype-1230])(Current, arg1, loc4, arg3);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_creation_procedure_call_validity */
void F1231_11179 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg2);
	RTLR(3,loc2);
	RTLR(4,arg5);
	RTLR(5,arg3);
	RTLR(6,arg4);
	RTLR(7,tr1);
	RTLIU(8);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13531[Dtype(RTCW(arg2))-1780])(arg2);
	loc2 = F899_7045(RTCW(arg5));
	tb1 = F1837_17837(RTCW(arg3), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg4, *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
	if ((EIF_BOOLEAN) !tb1) {
		tb1 = '\0';
		tb2 = '\0';
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) != *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
			tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tb3 = F2027_20672(RTCW(tr1));
			tb2 = tb3;
		}
		if (tb2) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13940[Dtype(RTCW(loc2))-1885])(loc2);
			tb1 = tb2;
		}
		if (tb1) {
		} else {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21362(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1, arg3, arg4);
		}
	}
	loc3 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	F1231_11296(Current, loc1, arg3, arg4);
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
	F1231_11292(Current, arg2, arg5, arg3, arg4, NULL);
	F1033_8332(Current, (EIF_BOOLEAN) (loc3 || *(EIF_BOOLEAN *)(Current + O7067[dtype-1032])));
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_formal_creation_procedure_call_validity */
void F1231_11180 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg2);
	RTLR(3,arg5);
	RTLR(4,loc6);
	RTLR(5,tr1);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,arg3);
	RTLR(9,arg4);
	RTLR(10,arg6);
	RTLIU(11);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13531[Dtype(RTCW(arg2))-1780])(arg2);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg5) + O13997[Dtype(arg5)-1885]);
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_5_);
	loc6 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc6))) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_3_0_0_0_);
		tb1 = (EIF_BOOLEAN) (loc1 > ti4_1);
	}
	if (tb1) {
		F1033_8331(Current);
		F2046_21728(RTCV(F1023_8173(Current)));
	} else {
		loc3 = F1902_18659(loc6, loc1);
		loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14005[Dtype(RTCW(loc3))-1886])(loc3);
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc4 == NULL)) {
			tb2 = F1906_18689(RTCW(loc4), arg3);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21364(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc2, arg3, arg4, loc3);
		}
		loc5 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		F1231_11297(Current, loc2, arg3, loc3);
	}
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc5 || tb1);
	F1231_11292(Current, arg2, arg6, arg3, arg4, NULL);
	F1033_8332(Current, (EIF_BOOLEAN) (loc5 || *(EIF_BOOLEAN *)(Current + O7067[dtype-1032])));
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_no_creation_procedure_call_validity */
void F1231_11181 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg3) + _REFACS_22_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21359(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1, arg3);
	} else {
		tb1 = F2027_20672(RTCW(arg3));
		if (tb1) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21357(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1, arg3);
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_debug_instruction_validity */
void F1231_11182 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		loc2 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
		loc1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			tr1 = F1231_11539(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
			tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
			F1250_11971(RTCW(tr1), loc2);
			tr1 = F1231_11539(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
			tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
			F1250_11971(RTCW(tr1), loc1);
		}
		F1231_11208(Current, loc3);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
			F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc1;
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc2;
		}
	} else {
		*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_if_instruction_validity */
void F1231_11183 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,loc3);
	RTLR(6,loc8);
	RTLR(7,loc13);
	RTLR(8,loc11);
	RTLR(9,loc15);
	RTLR(10,loc12);
	RTLR(11,loc14);
	RTLR(12,loc16);
	RTLR(13,loc4);
	RTLR(14,loc17);
	RTLR(15,loc18);
	RTLIU(16);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = F1231_11526(Current);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13279[Dtype(RTCW(tr1))-1682])(tr1);
	loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	F1231_11290(Current, loc2, loc3, loc1);
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = F2022_20365(RTCW(loc3), loc1, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
		if ((EIF_BOOLEAN) !tb1) {
			loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F1033_8331(Current);
			loc8 = F2022_20345(RTCW(loc3));
			tr1 = F1023_8173(Current);
			F2046_21520(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc2, loc8);
		}
	}
	F1231_11572(Current, loc3);
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	loc9 = F10_115(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
	F1034_8335(RTCW(tr1), loc2, *(EIF_REFERENCE *)(Current + O9260[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
	tb1 = '\01';
	if (!loc7) {
		tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
		tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
		tb1 = tb2;
	}
	loc7 = (EIF_BOOLEAN) tb1;
	loc13 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
	loc11 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
		F1250_11971(RTCW(tr1), loc13);
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
		F1250_11971(RTCW(tr1), loc11);
		tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
		F260_2862(RTCW(tr1), loc2, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
		tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
		F260_2863(RTCW(tr1), loc2, loc11);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc15 = tr1;
	if (EIF_TEST(loc15)) {
		F1231_11208(Current, loc15);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	F10_119(RTCW(tr1), loc9);
	loc12 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
	loc14 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
	tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
	F1034_8336(RTCW(tr1), loc2, *(EIF_REFERENCE *)(Current + O9260[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
	tb1 = '\01';
	if (!loc7) {
		tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
		tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
		tb1 = tb2;
	}
	loc7 = (EIF_BOOLEAN) tb1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	loc16 = tr1;
	if (EIF_TEST(loc16)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			tr1 = F1231_11539(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
			tr1 = F1231_11539(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
		}
		loc6 = *(EIF_INTEGER_32 *)(loc16+ _LNGOFF_1_0_0_0_);
		loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc5 > loc6)) break;
			loc4 = F1003_7568(loc16, loc5);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				F1250_11971(RTCW(tr1), loc13);
				tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				F1250_11971(RTCW(tr1), loc11);
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4));
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13279[Dtype(RTCW(tr1))-1682])(tr1);
			loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			F1231_11290(Current, loc2, loc3, loc1);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tb1 = F2022_20365(RTCW(loc3), loc1, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
				if ((EIF_BOOLEAN) !tb1) {
					loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					F1033_8331(Current);
					loc8 = F2022_20345(RTCW(loc3));
					tr1 = F1023_8173(Current);
					F2046_21520(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc2, loc8);
				}
			}
			F1231_11572(Current, loc3);
			tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
			loc10 = F10_115(RTCW(tr1));
			tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
			F1034_8335(RTCW(tr1), loc2, *(EIF_REFERENCE *)(Current + O9260[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
			tb1 = '\01';
			if (!loc7) {
				tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
				tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
				tb1 = tb2;
			}
			loc7 = (EIF_BOOLEAN) tb1;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
				F260_2862(RTCW(tr1), loc2, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
				tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
				F260_2863(RTCW(tr1), loc2, loc11);
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_1_);
			loc17 = tr1;
			if (EIF_TEST(loc17)) {
				F1231_11208(Current, loc17);
				if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
					loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
			F10_119(RTCW(tr1), loc10);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				F1250_11972(RTCW(loc12), *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
				F1250_11972(RTCW(loc14), *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
			F1034_8336(RTCW(tr1), loc2, *(EIF_REFERENCE *)(Current + O9260[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
			tb1 = '\01';
			if (!loc7) {
				tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
				tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
				tb1 = tb2;
			}
			loc7 = (EIF_BOOLEAN) tb1;
			loc5++;
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
			F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
		}
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		RTAR(Current, loc13);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc13;
		RTAR(Current, loc11);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc11;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc18 = tr1;
	if (EIF_TEST(loc18)) {
		F1231_11208(Current, loc18);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	F10_119(RTCW(tr1), loc9);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
		F1250_11972(RTCW(tr1), loc12);
		tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
		F1250_11972(RTCW(tr1), loc14);
		F1231_11540(Current, loc12);
		F1231_11540(Current, loc14);
	}
	if (loc7) {
		F1033_8331(Current);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_inspect_instruction_validity */
void F1231_11184 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc17 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc18 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc21 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc24 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc25 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc26 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc27 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc28 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc29 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc30 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc31 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(28);
	RTLR(0,Current);
	RTLR(1,loc10);
	RTLR(2,tr1);
	RTLR(3,loc8);
	RTLR(4,loc1);
	RTLR(5,arg1);
	RTLR(6,tr2);
	RTLR(7,loc11);
	RTLR(8,loc24);
	RTLR(9,loc22);
	RTLR(10,loc26);
	RTLR(11,loc15);
	RTLR(12,loc9);
	RTLR(13,loc2);
	RTLR(14,loc12);
	RTLR(15,loc13);
	RTLR(16,loc14);
	RTLR(17,loc19);
	RTLR(18,loc27);
	RTLR(19,loc20);
	RTLR(20,loc16);
	RTLR(21,loc28);
	RTLR(22,loc29);
	RTLR(23,loc30);
	RTLR(24,loc31);
	RTLR(25,loc23);
	RTLR(26,loc25);
	RTLR(27,loc3);
	RTLIU(28);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	loc10 = *(EIF_REFERENCE *)(RTCW(tr1) + O12741[Dtype(tr1)-1610]);
	loc8 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13279[Dtype(RTCW(tr1))-1682])(tr1);
	F1231_11290(Current, loc1, loc8, loc10);
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tr1 = F1231_11526(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12762[Dtype(tr1)-1610]);
		tr2 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
		tb1 = F2022_20365(RTCW(loc8), tr1, tr2);
		if (tb1) {
		} else {
			tr1 = F1231_11526(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12763[Dtype(tr1)-1610]);
			tr2 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
			tb1 = F2022_20365(RTCW(loc8), tr1, tr2);
			if (tb1) {
			} else {
				tr1 = F1231_11526(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12764[Dtype(tr1)-1610]);
				tr2 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
				tb1 = F2022_20365(RTCW(loc8), tr1, tr2);
				if (tb1) {
				} else {
					tr1 = F1231_11526(Current);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12765[Dtype(tr1)-1610]);
					tr2 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
					tb1 = F2022_20365(RTCW(loc8), tr1, tr2);
					if (tb1) {
					} else {
						tr1 = F1231_11526(Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12769[Dtype(tr1)-1610]);
						tr2 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
						tb1 = F2022_20365(RTCW(loc8), tr1, tr2);
						if (tb1) {
						} else {
							tr1 = F1231_11526(Current);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12770[Dtype(tr1)-1610]);
							tr2 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
							tb1 = F2022_20365(RTCW(loc8), tr1, tr2);
							if (tb1) {
							} else {
								tr1 = F1231_11526(Current);
								tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12771[Dtype(tr1)-1610]);
								tr2 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
								tb1 = F2022_20365(RTCW(loc8), tr1, tr2);
								if (tb1) {
								} else {
									tr1 = F1231_11526(Current);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12772[Dtype(tr1)-1610]);
									tr2 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
									tb1 = F2022_20365(RTCW(loc8), tr1, tr2);
									if (tb1) {
									} else {
										tr1 = F1231_11526(Current);
										tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12752[Dtype(tr1)-1610]);
										tr2 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
										tb1 = F2022_20365(RTCW(loc8), tr1, tr2);
										if (tb1) {
										} else {
											tr1 = F1231_11526(Current);
											tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12753[Dtype(tr1)-1610]);
											tr2 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
											tb1 = F2022_20365(RTCW(loc8), tr1, tr2);
											if (tb1) {
											} else {
												loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
												F1033_8331(Current);
												loc11 = F2022_20345(RTCW(loc8));
												tr1 = F1023_8173(Current);
												F2046_21425(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1, loc11);
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	loc7 = (EIF_BOOLEAN) loc6;
	loc24 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
	loc22 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc26 = tr1;
	if (EIF_TEST(loc26)) {
		loc15 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
		loc9 = RTOUCR(571,F396_4600, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		loc5 = *(EIF_INTEGER_32 *)(loc26+ _LNGOFF_1_0_0_0_);
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc4 > loc5)) break;
			loc2 = F1003_7568(loc26, loc4);
			loc12 = *(EIF_REFERENCE *)(RTCW(loc2));
			loc18 = *(EIF_INTEGER_32 *)(RTCW(loc12)+ _LNGOFF_2_0_0_0_);
			loc17 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc17 > loc18)) break;
				loc13 = F1650_16735(RTCW(loc12), loc17);
				loc14 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13301[Dtype(RTCW(loc13))-1690])(loc13);
				F1231_11290(Current, loc14, loc15, loc8);
				if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
					loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					loc19 = F1231_11185(Current, loc14);
					if ((EIF_BOOLEAN)(loc19 == NULL)) {
						loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21427(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc14);
					} else {
						if ((EIF_BOOLEAN) !loc7) {
							tb1 = F2022_20365(RTCW(loc15), loc9, loc8);
							if (tb1) {
							} else {
								loc27 = loc19;
								loc27 = RTRV(eif_new_type(1937, 0x01),loc27);
								if (EIF_TEST(loc27)) {
									loc21 = *(EIF_INTEGER_32 *)(loc27+ _LNGOFF_5_1_0_1_);
									F1722_17132(loc27, ((EIF_INTEGER_32) 0L));
									loc20 = *(EIF_REFERENCE *)(loc27 + _REFACS_3_);
									F1938_19179(loc27, NULL);
									F899_7060(RTCW(loc15));
									F1231_11290(Current, loc27, loc15, loc8);
									F1938_19179(loc27, loc20);
									F1722_17132(loc27, loc21);
									if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
										loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									} else {
										tb1 = F2022_20365(RTCW(loc15), loc9, loc8);
										if (tb1) {
										} else {
											loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
											F1033_8331(Current);
											loc11 = F2022_20345(RTCW(loc8));
											loc16 = F2022_20345(RTCW(loc15));
											tr1 = F1023_8173(Current);
											F2046_21426(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc14, loc16, loc11);
										}
									}
								} else {
									loc28 = loc19;
									loc28 = RTRV(eif_new_type(1933, 0x01),loc28);
									if (EIF_TEST(loc28)) {
										loc21 = *(EIF_INTEGER_32 *)(loc28 + O13392[Dtype(loc28)-1721]);
										F1722_17132(loc28, ((EIF_INTEGER_32) 0L));
										loc20 = *(EIF_REFERENCE *)(loc28 + _REFACS_1_);
										F1934_19120(loc28, NULL);
										F899_7060(RTCW(loc15));
										F1231_11290(Current, loc28, loc15, loc8);
										F1934_19120(loc28, loc20);
										F1722_17132(loc28, loc21);
										if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
											loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
										} else {
											tb1 = F2022_20365(RTCW(loc15), loc9, loc8);
											if (tb1) {
											} else {
												loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
												F1033_8331(Current);
												loc11 = F2022_20345(RTCW(loc8));
												loc16 = F2022_20345(RTCW(loc15));
												tr1 = F1023_8173(Current);
												F2046_21426(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc14, loc16, loc11);
											}
										}
									} else {
										loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
										F1033_8331(Current);
										loc11 = F2022_20345(RTCW(loc8));
										loc16 = F2022_20345(RTCW(loc15));
										tr1 = F1023_8173(Current);
										F2046_21426(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc14, loc16, loc11);
									}
								}
							}
						}
					}
				}
				F899_7060(RTCW(loc15));
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13300[Dtype(RTCW(loc13))-1690])(loc13);
				if (tb1) {
					loc14 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13302[Dtype(RTCW(loc13))-1690])(loc13);
					F1231_11290(Current, loc14, loc15, loc8);
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						loc19 = F1231_11185(Current, loc14);
						if ((EIF_BOOLEAN)(loc19 == NULL)) {
							loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							F2046_21427(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc14);
						} else {
							if ((EIF_BOOLEAN) !loc7) {
								tb1 = F2022_20365(RTCW(loc15), loc9, loc8);
								if (tb1) {
								} else {
									loc29 = loc19;
									loc29 = RTRV(eif_new_type(1937, 0x01),loc29);
									if (EIF_TEST(loc29)) {
										loc21 = *(EIF_INTEGER_32 *)(loc29+ _LNGOFF_5_1_0_1_);
										F1722_17132(loc29, ((EIF_INTEGER_32) 0L));
										loc20 = *(EIF_REFERENCE *)(loc29 + _REFACS_3_);
										F1938_19179(loc29, NULL);
										F899_7060(RTCW(loc15));
										F1231_11290(Current, loc29, loc15, loc8);
										F1938_19179(loc29, loc20);
										F1722_17132(loc29, loc21);
										if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
											loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
										} else {
											tb1 = F2022_20365(RTCW(loc15), loc9, loc8);
											if (tb1) {
											} else {
												loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
												F1033_8331(Current);
												loc11 = F2022_20345(RTCW(loc8));
												loc16 = F2022_20345(RTCW(loc15));
												tr1 = F1023_8173(Current);
												F2046_21426(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc14, loc16, loc11);
											}
										}
									} else {
										loc30 = loc19;
										loc30 = RTRV(eif_new_type(1933, 0x01),loc30);
										if (EIF_TEST(loc30)) {
											loc21 = *(EIF_INTEGER_32 *)(loc30 + O13392[Dtype(loc30)-1721]);
											F1722_17132(loc30, ((EIF_INTEGER_32) 0L));
											loc20 = *(EIF_REFERENCE *)(loc30 + _REFACS_1_);
											F1934_19120(loc30, NULL);
											F899_7060(RTCW(loc15));
											F1231_11290(Current, loc30, loc15, loc8);
											F1934_19120(loc30, loc20);
											F1722_17132(loc30, loc21);
											if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
												loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
											} else {
												tb1 = F2022_20365(RTCW(loc15), loc9, loc8);
												if (tb1) {
												} else {
													loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
													F1033_8331(Current);
													loc11 = F2022_20345(RTCW(loc8));
													loc16 = F2022_20345(RTCW(loc15));
													tr1 = F1023_8173(Current);
													F2046_21426(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc14, loc16, loc11);
												}
											}
										} else {
											loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
											F1033_8331(Current);
											loc11 = F2022_20345(RTCW(loc8));
											loc16 = F2022_20345(RTCW(loc15));
											tr1 = F1023_8173(Current);
											F2046_21426(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc14, loc16, loc11);
										}
									}
								}
							}
						}
					}
					F899_7060(RTCW(loc15));
				}
				loc17++;
			}
			loc4++;
		}
		F1231_11572(Current, loc15);
		F1231_11572(Current, loc8);
		loc24 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
		loc22 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			tr1 = F1231_11539(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
			tr1 = F1231_11539(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
		}
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc4 > loc5)) break;
			loc2 = F1003_7568(loc26, loc4);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				F1250_11971(RTCW(tr1), loc24);
				tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				F1250_11971(RTCW(tr1), loc22);
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_1_);
			loc31 = tr1;
			if (EIF_TEST(loc31)) {
				F1231_11208(Current, loc31);
				if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
					loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			}
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN)(loc23 == NULL)) {
					loc23 = F1231_11539(Current);
					F1250_11971(RTCW(loc23), *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
				} else {
					F1250_11972(RTCW(loc23), *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
				}
				if ((EIF_BOOLEAN)(loc25 == NULL)) {
					loc25 = F1231_11539(Current);
					F1250_11971(RTCW(loc25), *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
				} else {
					F1250_11972(RTCW(loc25), *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
				}
			}
			loc4++;
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
			F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
		}
	} else {
		F1231_11572(Current, loc8);
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		RTAR(Current, loc24);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc24;
		RTAR(Current, loc22);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc22;
	}
	loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		F1231_11208(Current, loc3);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		if ((EIF_BOOLEAN)(loc23 != NULL)) {
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				F1250_11972(RTCW(tr1), loc23);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				F1250_11971(RTCW(tr1), loc23);
			}
			F1231_11540(Current, loc23);
		}
		if ((EIF_BOOLEAN)(loc25 != NULL)) {
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				F1250_11972(RTCW(tr1), loc25);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				F1250_11971(RTCW(tr1), loc25);
			}
			F1231_11540(Current, loc25);
		}
	}
	if (loc6) {
		F1033_8331(Current);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.choice_constant */
EIF_REFERENCE F1231_11185 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,loc7);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLR(4,loc8);
	RTLR(5,loc1);
	RTLR(6,tr1);
	RTLR(7,loc9);
	RTLR(8,loc10);
	RTLR(9,loc2);
	RTLR(10,loc4);
	RTLR(11,loc3);
	RTLR(12,loc11);
	RTLR(13,loc12);
	RTLIU(14);
	
	RTGC;
	loc5 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc7 = arg1;
	loc7 = RTRV(eif_new_type(1776, 0x01),loc7);
	if (EIF_TEST(loc7)) {
		Result = (EIF_REFERENCE) loc7;
	} else {
		loc8 = arg1;
		loc8 = RTRV(eif_new_type(1986, 0x01),loc8);
		if (EIF_TEST(loc8)) {
			tb1 = F1987_19667(loc8);
			if (tb1) {
			} else {
				tb1 = F1987_19663(loc8);
				if (tb1) {
				} else {
					tb1 = F1987_19664(loc8);
					if (tb1) {
					} else {
						tb1 = F1987_19665(loc8);
						if (tb1) {
						} else {
							loc6 = *(EIF_INTEGER_32 *)(loc8+ _LNGOFF_2_1_0_2_);
							tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							loc1 = F2027_20747(RTCW(tr1), loc6);
						}
					}
				}
			}
		} else {
			tb1 = '\0';
			loc9 = arg1;
			loc9 = RTRV(eif_new_type(1789, 0x01),loc9);
			if (EIF_TEST(loc9)) {
				ti4_1 = F1779_17423(loc9);
				tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
			}
			if (tb1) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13378[Dtype(loc9)-1748])(loc9);
				loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O14497[Dtype(tr1)-1943]);
				tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
				loc1 = F2027_20747(RTCW(tr1), loc6);
			} else {
				loc10 = arg1;
				loc10 = RTRV(eif_new_type(1786, 0x01),loc10);
				if (EIF_TEST(loc10)) {
					loc2 = F1786_17466(loc10);
					loc4 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
					F899_7054(RTCW(loc4), loc2);
					loc3 = F2022_20336(RTCW(loc4));
					tr1 = F1785_17456(loc10);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O14497[Dtype(tr1)-1943]);
					loc1 = F2027_20747(RTCW(loc3), ti4_1);
					F1231_11572(Current, loc4);
				}
			}
		}
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			loc11 = loc1;
			loc11 = RTRV(eif_new_type(1841, 0x01),loc11);
			if (EIF_TEST(loc11)) {
				Result = *(EIF_REFERENCE *)(loc11 + _REFACS_17_);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13526[Dtype(RTCW(Result))-1777])(Result);
				if (tb1) {
					Result = RTOUCR(2936,F1231_11555, (Current));
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13527[Dtype(RTCW(Result))-1777])(Result);
					if (tb1) {
						Result = RTOUCR(2937,F1231_11556, (Current));
					}
				}
			} else {
				loc12 = loc1;
				loc12 = RTRV(eif_new_type(1840, 0x01),loc12);
				if (EIF_TEST(loc12)) {
					Result = RTOUCR(2937,F1231_11556, (Current));
				}
			}
		}
	}
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) loc5;
	RTLE;
	return Result;
}

/* {ET_FEATURE_CHECKER}.check_iteration_instruction_validity */
void F1231_11186 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F1231_11237(Current, arg1);
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	F11_130(RTCW(tr1), arg1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13224[Dtype(RTCW(arg1))-1961])(arg1);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		F1231_11208(Current, loc2);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	F1231_11188(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	F11_131(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
	F1553_14040(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
	tb1 = F1545_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
		tr1 = F1545_13931(RTCW(tr1));
		F1231_11572(Current, tr1);
		tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
		F1545_13952(RTCW(tr1));
	}
	if (loc1) {
		F1033_8331(Current);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_loop_instruction_validity */
void F1231_11187 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		F1231_11208(Current, loc2);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	}
	F1231_11188(Current, arg1);
	if (loc1) {
		F1033_8331(Current);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_loop_component_no_from_validity */
void F1231_11188 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,loc8);
	RTLR(2,loc7);
	RTLR(3,tr1);
	RTLR(4,loc9);
	RTLR(5,arg1);
	RTLR(6,loc10);
	RTLR(7,loc11);
	RTLR(8,loc5);
	RTLR(9,loc1);
	RTLR(10,loc2);
	RTLR(11,loc4);
	RTLR(12,loc12);
	RTLIU(13);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc8 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
	loc7 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
		F1250_11971(RTCW(tr1), loc8);
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
		F1250_11971(RTCW(tr1), loc7);
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13225[Dtype(RTCW(arg1))-1961])(arg1);
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9012[dtype-1230])(Current, loc9);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
			F1250_11971(RTCW(tr1), loc8);
			tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
			F1250_11971(RTCW(tr1), loc7);
		}
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13226[Dtype(RTCW(arg1))-1961])(arg1);
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9013[dtype-1230])(Current, loc10);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
			F1250_11971(RTCW(tr1), loc8);
			tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
			F1250_11971(RTCW(tr1), loc7);
		}
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13227[Dtype(RTCW(arg1))-1961])(arg1);
	loc11 = tr1;
	if (EIF_TEST(loc11)) {
		tr1 = F1231_11526(Current);
		loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13279[Dtype(loc11)-1682])(loc11);
		loc2 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
		F1231_11290(Current, loc1, loc2, loc5);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			tb1 = F2022_20365(RTCW(loc2), loc5, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
			if ((EIF_BOOLEAN) !tb1) {
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				F1033_8331(Current);
				loc4 = F2022_20345(RTCW(loc2));
				tr1 = F1023_8173(Current);
				F2046_21520(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1, loc4);
			}
		}
		F1231_11572(Current, loc2);
	}
	tb1 = '\0';
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13228[Dtype(RTCW(arg1))-1961])(arg1);
	loc12 = tr1;
	if (EIF_TEST(loc12)) {
		tb2 = F1003_7573(loc12);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tb1 = '\0';
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb2 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb2) {
			tb1 = (EIF_BOOLEAN)(loc1 != NULL);
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
			F260_2863(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
		loc6 = F10_115(RTCW(tr1));
		tb1 = '\0';
		tb2 = F1648_16708(loc12);
		if (tb2) {
			tb1 = (EIF_BOOLEAN)(loc1 != NULL);
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
			F1034_8336(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9260[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
			tb1 = '\01';
			if (!loc3) {
				tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
				tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
				tb1 = tb2;
			}
			loc3 = (EIF_BOOLEAN) tb1;
		}
		F1231_11208(Current, loc12);
		tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
		F10_119(RTCW(tr1), loc6);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			tb1 = '\0';
			if ((EIF_BOOLEAN) !loc3) {
				tb2 = F1250_11954(RTCW(loc7), *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				F1231_11188(Current, arg1);
			}
		}
	}
	if (loc3) {
		F1033_8331(Current);
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
		RTAR(Current, loc7);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc7;
		RTAR(Current, loc8);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc8;
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
			F260_2862(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_loop_invariant_validity */
void F1231_11189 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,loc8);
	RTLR(6,loc6);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = F1231_11526(Current);
	loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
	loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	loc7 = F10_115(RTCW(tr1));
	loc5 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc4 > loc5)) break;
		tr1 = F1909_18730(RTCW(arg1), loc4);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13235[Dtype(RTCW(tr1))-1666])(tr1);
		loc8 = tr1;
		if (EIF_TEST(loc8)) {
			F1231_11290(Current, loc8, loc1, loc3);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tb1 = F2022_20365(RTCW(loc1), loc3, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
				if ((EIF_BOOLEAN) !tb1) {
					loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					F1033_8331(Current);
					loc6 = F2022_20345(RTCW(loc1));
					tr1 = F1023_8173(Current);
					F2046_21520(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc8, loc6);
				}
			}
			F899_7060(RTCW(loc1));
			tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
			F1034_8335(RTCW(tr1), loc8, *(EIF_REFERENCE *)(Current + O9260[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
			tb1 = '\01';
			if (!loc2) {
				tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
				tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
				tb1 = tb2;
			}
			loc2 = (EIF_BOOLEAN) tb1;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
				F260_2862(RTCW(tr1), loc8, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
			}
		}
		loc4++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	F10_119(RTCW(tr1), loc7);
	if (loc2) {
		F1033_8331(Current);
	}
	F1231_11572(Current, loc1);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_loop_variant_validity */
void F1231_11190 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	loc2 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	tr1 = F1231_11526(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12761[Dtype(tr1)-1610]);
	F1231_11290(Current, loc1, loc2, tr1);
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tr1 = F1231_11526(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12762[Dtype(tr1)-1610]);
		tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
		tb1 = F2022_20365(RTCW(loc2), tr1, tr2);
		if (tb1) {
		} else {
			tr1 = F1231_11526(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12763[Dtype(tr1)-1610]);
			tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
			tb1 = F2022_20365(RTCW(loc2), tr1, tr2);
			if (tb1) {
			} else {
				tr1 = F1231_11526(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12764[Dtype(tr1)-1610]);
				tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
				tb1 = F2022_20365(RTCW(loc2), tr1, tr2);
				if (tb1) {
				} else {
					tr1 = F1231_11526(Current);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12765[Dtype(tr1)-1610]);
					tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
					tb1 = F2022_20365(RTCW(loc2), tr1, tr2);
					if (tb1) {
					} else {
						tr1 = F1231_11526(Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12769[Dtype(tr1)-1610]);
						tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
						tb1 = F2022_20365(RTCW(loc2), tr1, tr2);
						if (tb1) {
						} else {
							tr1 = F1231_11526(Current);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12770[Dtype(tr1)-1610]);
							tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
							tb1 = F2022_20365(RTCW(loc2), tr1, tr2);
							if (tb1) {
							} else {
								tr1 = F1231_11526(Current);
								tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12771[Dtype(tr1)-1610]);
								tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
								tb1 = F2022_20365(RTCW(loc2), tr1, tr2);
								if (tb1) {
								} else {
									tr1 = F1231_11526(Current);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12772[Dtype(tr1)-1610]);
									tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
									tb1 = F2022_20365(RTCW(loc2), tr1, tr2);
									if (tb1) {
									} else {
										loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
										F1033_8331(Current);
										loc4 = F2022_20345(RTCW(loc2));
										tr1 = F1023_8173(Current);
										F2046_21251(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1, loc4);
									}
								}
							}
						}
					}
				}
			}
		}
	}
	F1231_11572(Current, loc2);
	if (loc3) {
		F1033_8331(Current);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_precursor_instruction_validity */
void F1231_11191 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,loc7);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc8);
	RTLR(5,loc9);
	RTLR(6,loc2);
	RTLR(7,loc3);
	RTLR(8,loc1);
	RTLR(9,loc4);
	RTLR(10,loc10);
	RTLR(11,loc11);
	RTLR(12,loc5);
	RTLIU(13);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
	loc7 = tr1;
	loc7 = RTRV(eif_new_type(1836, 0x01),loc7);
	if ((EIF_BOOLEAN) !EIF_TEST(loc7)) {
		F1033_8331(Current);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
			tr1 = F1023_8173(Current);
			F2046_21264(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
		} else {
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		}
		F1231_11293(Current, arg1);
	} else {
		if (*(EIF_BOOLEAN *)(Current + O9274[dtype-1230])) {
			F1033_8331(Current);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
				tr1 = F1023_8173(Current);
				F2046_21264(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
			} else {
				if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
					F2046_21728(RTCV(F1023_8173(Current)));
				}
			}
			F1231_11293(Current, arg1);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				F1033_8331(Current);
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
					tr1 = F1023_8173(Current);
					F2046_21271(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1, loc8, loc7);
				} else {
					if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
						F2046_21728(RTCV(F1023_8173(Current)));
					}
				}
				F1231_11293(Current, arg1);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8705[Dtype(RTCW(tr1))-1840])(tr1);
				if ((EIF_BOOLEAN)(tr1 == NULL)) {
					F1033_8331(Current);
					if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
						if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					} else {
						tr1 = F1023_8173(Current);
						F2046_21270(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1, loc7);
					}
					F1231_11293(Current, arg1);
				} else {
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
					loc9 = tr1;
					if ((EIF_BOOLEAN) !EIF_TEST(loc9)) {
						F1033_8331(Current);
						F2046_21728(RTCV(F1023_8173(Current)));
						F1231_11293(Current, arg1);
					} else {
						loc2 = (EIF_REFERENCE) loc9;
						tb1 = '\0';
						if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) != *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
							tb2 = F2024_20445(RTCW(loc2));
							tb1 = tb2;
						}
						if (tb1) {
							tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							loc3 = F2027_20707(RTCW(tr1), loc2);
							if ((EIF_BOOLEAN)(loc3 == NULL)) {
								F1033_8331(Current);
								F2046_21728(RTCV(F1023_8173(Current)));
								F1231_11293(Current, arg1);
							} else {
								loc2 = (EIF_REFERENCE) loc3;
							}
						}
						if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
							loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
							loc4 = F2024_20433(RTCW(loc2));
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_1_0_1_);
							tr1 = F2027_20748(RTCW(loc4), ti4_1);
							loc10 = tr1;
							if (EIF_TEST(loc10)) {
								F1231_11192(Current, arg1, loc10, loc4, loc2);
							} else {
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_1_0_1_);
								tr1 = F2027_20747(RTCW(loc4), ti4_1);
								loc11 = tr1;
								if (EIF_TEST(loc11)) {
									if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
										loc5 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
										F1231_11308(Current, arg1, loc11, loc4, loc2, loc5);
										F1231_11572(Current, loc5);
										tb1 = '\0';
										if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
											tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
											tb1 = (EIF_BOOLEAN)(tr1 != NULL);
										}
										if (tb1) {
											loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
										}
									}
									if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) && (EIF_BOOLEAN) !loc6)) {
										F1033_8331(Current);
										tr1 = F1023_8173(Current);
										F2046_21401(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc1, loc11, loc4);
										F1231_11293(Current, arg1);
									}
								} else {
									F1033_8331(Current);
									F2046_21728(RTCV(F1023_8173(Current)));
									F1231_11293(Current, arg1);
								}
							}
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_precursor_procedure_instruction_validity */
void F1231_11192 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,loc1);
	RTLR(6,arg4);
	RTLR(7,arg3);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	tb1 = '\0';
	if (*(EIF_BOOLEAN *)(Current + O9280[dtype-1230])) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13718[Dtype(RTCW(arg2))-1840])(arg2);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
		F2046_21494(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), tr2, arg2);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	F899_7054(RTCW(loc1), arg4);
	F1231_11292(Current, arg1, loc1, arg2, arg3, NULL);
	F1231_11572(Current, loc1);
	F1033_8332(Current, (EIF_BOOLEAN) (loc2 || *(EIF_BOOLEAN *)(Current + O7067[dtype-1032])));
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9210[dtype-1230])(Current, arg1, arg4, arg2);
		tr1 = *(EIF_REFERENCE *)(Current + O9282[dtype-1230]);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			F1578_14121(loc3, arg2);
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_qualified_call_instruction_validity */
void F1231_11193 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLR(4,loc3);
	RTLR(5,tr1);
	RTLR(6,loc7);
	RTLR(7,loc6);
	RTLR(8,loc5);
	RTLR(9,loc12);
	RTLR(10,loc13);
	RTLR(11,loc14);
	RTLR(12,loc15);
	RTLIU(13);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13377[Dtype(RTCW(arg1))-1748])(arg1);
	loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13378[Dtype(RTCW(arg1))-1748])(arg1);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O14497[Dtype(loc3)-1943]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12741[Dtype(tr1)-1610]);
	F1231_11290(Current, loc2, loc1, tr1);
	loc9 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_0_0_0_);
	loc7 = F1231_11337(Current);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F2023_20412(RTCW(loc1), loc7);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_4_0_0_1_);
		loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
		F1231_11334(Current, loc3, loc7, loc1);
	}
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F1231_11293(Current, arg1);
	} else {
		if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
			loc6 = F1541_13847(RTCW(loc7));
			loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc6))-1835])(loc6);
			tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
			F1037_8385(RTCW(tr1), loc8, loc6, loc1);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
				F1033_8331(Current);
				if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
					F2046_21728(RTCV(F1023_8173(Current)));
				}
				F1231_11293(Current, arg1);
			} else {
				tb1 = F2027_20678(RTCW(loc5));
				if (tb1) {
					F1231_11194(Current, arg1, loc6, loc1);
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1485[Dtype(RTCW(loc6))-1835])(loc6, loc3);
					loc12 = tr1;
					if (EIF_TEST(loc12)) {
						loc4 = *(EIF_INTEGER_32 *)(loc12 + O10400[Dtype(loc12)-1302]);
						F1944_19225(RTCW(loc3), loc4);
						F1231_11196(Current, arg1, loc12, loc5, loc1);
					} else {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1484[Dtype(RTCW(loc6))-1835])(loc6, loc3);
						loc13 = tr1;
						if (EIF_TEST(loc13)) {
							loc4 = *(EIF_INTEGER_32 *)(loc13 + O10400[Dtype(loc13)-1302]);
							F1944_19225(RTCW(loc3), loc4);
							F1231_11305(Current, arg1, loc13, loc5, loc1, NULL);
							if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
							} else {
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
								if ((EIF_BOOLEAN)(tr1 == NULL)) {
									F1033_8331(Current);
									tr1 = F1023_8173(Current);
									F2046_21401(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc3, loc13, loc5);
									F1231_11293(Current, arg1);
								}
							}
						} else {
							tb1 = '\0';
							tb2 = F2027_20603(RTCW(loc5));
							if (tb2) {
								loc14 = loc3;
								loc14 = RTRV(eif_new_type(1986, 0x01),loc14);
								tb1 = EIF_TEST(loc14);
							}
							if (tb1) {
								loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1489[Dtype(RTCW(loc6))-1835])(loc6, loc14, loc1);
								if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
									F1987_19681(loc14, (EIF_BOOLEAN) 1);
									F1944_19225(loc14, loc4);
									F1231_11310(Current, arg1, loc5, loc1, NULL);
									if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
									} else {
										tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
										if ((EIF_BOOLEAN)(tr1 == NULL)) {
											F1033_8331(Current);
											tr1 = F1023_8173(Current);
											F2046_21402(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc14, loc5);
											F1231_11293(Current, arg1);
										}
									}
								}
							}
							if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
								F1033_8331(Current);
								tr1 = F1023_8173(Current);
								F2046_21498(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc3, loc5);
								F1231_11293(Current, arg1);
							}
						}
					}
				}
			}
		} else {
			tb1 = F1432_13373(RTCW(loc7));
			if (tb1) {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
				F1231_11293(Current, arg1);
			} else {
				loc11 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_4_0_0_1_);
				loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc10 > loc11)) break;
					loc6 = F1541_13846(RTCW(loc7), loc10);
					loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc6))-1835])(loc6);
					tr1 = F2027_20748(RTCW(loc5), loc4);
					loc15 = tr1;
					if (EIF_TEST(loc15)) {
						tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
						F1037_8385(RTCW(tr1), loc8, loc6, loc1);
						F1231_11196(Current, arg1, loc15, loc5, loc1);
						F899_7059(RTCW(loc1), loc9);
					} else {
						tb1 = F2027_20576(RTCW(loc5));
						if (tb1) {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						} else {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						loc10 = (EIF_INTEGER_32) loc11;
					}
					loc10++;
				}
			}
		}
	}
	F1231_11572(Current, loc1);
	F1231_11338(Current, loc7);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_qualified_dotnet_procedure_call_instruction_validity */
void F1231_11194 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg2);
	RTLR(3,loc3);
	RTLR(4,arg1);
	RTLR(5,loc5);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,arg3);
	RTLR(9,loc2);
	RTLR(10,loc6);
	RTLIU(11);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(arg2))-1835])(arg2);
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13378[Dtype(RTCW(arg1))-1748])(arg1);
	loc5 = F1231_11559(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1488[Dtype(RTCW(arg2))-1835])(arg2, loc3, loc5);
	tb1 = F1432_13373(RTCW(loc5));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = F1231_11336(Current, loc3, arg2);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13379[Dtype(RTCW(arg1))-1748])(arg1);
		F1231_11558(Current, loc5, tr1, tr2, arg3, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			F1231_11293(Current, arg1);
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_4_0_0_1_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
				loc2 = F1541_13847(RTCW(loc5));
				loc4 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O10400[Dtype(loc2)-1302]);
				F1944_19225(RTCW(loc3), loc4);
				F1231_11196(Current, arg1, loc2, loc1, arg3);
			} else {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
				F1231_11293(Current, arg1);
			}
		}
	} else {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1484[Dtype(RTCW(arg2))-1835])(arg2, loc3);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			F1231_11305(Current, arg1, loc6, loc1, arg3, NULL);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
				if ((EIF_BOOLEAN)(tr1 == NULL)) {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					F2046_21401(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc3, loc6, loc1);
					F1231_11293(Current, arg1);
				}
			}
		} else {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21498(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc3, loc1);
			F1231_11293(Current, arg1);
		}
	}
	F1231_11560(Current, loc5);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_qualified_feature_call_instruction_validity */
void F1231_11195 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLR(5,Current);
	RTLR(6,loc2);
	RTLR(7,tr1);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLIU(10);
	
	RTGC;
	loc1 = arg2;
	loc1 = RTRV(eif_new_type(1860, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		F1231_11196(Current, arg1, loc1, arg3, arg4);
	} else {
		loc2 = arg2;
		loc2 = RTRV(eif_new_type(1838, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			tr2 = *(EIF_REFERENCE *)(Current + O6920[Dtype(Current)-1022]);
			tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13378[Dtype(RTCW(arg1))-1748])(arg1);
			F2046_21401(RTCW(tr1), tr2, tr3, loc2, arg3);
			F1231_11293(Current, arg1);
		} else {
			F1033_8331(Current);
			F2046_21728(RTCV(F1023_8173(Current)));
			F1231_11293(Current, arg1);
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_qualified_procedure_call_instruction_validity */
void F1231_11196 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,arg4);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	F1231_11260(Current, arg1, arg2, arg3, arg4, NULL);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9214[dtype-1230])(Current, arg1, arg4, arg2);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_repeat_instruction_validity */
void F1231_11197 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11186(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.check_retry_instruction_validity */
void F1231_11198 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O9274[dtype-1230])) {
		F1033_8331(Current);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		} else {
			tr1 = F1023_8173(Current);
			F2046_21533(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
		}
	} else {
		*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_static_call_instruction_validity */
void F1231_11199 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc3);
	RTLR(3,arg1);
	RTLR(4,loc4);
	RTLR(5,loc7);
	RTLR(6,loc6);
	RTLR(7,loc2);
	RTLR(8,tr1);
	RTLR(9,loc12);
	RTLR(10,loc13);
	RTLR(11,loc14);
	RTLIU(12);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	loc3 = F1786_17466(RTCW(arg1));
	loc4 = F1785_17456(RTCW(arg1));
	loc5 = *(EIF_INTEGER_32 *)(RTCW(loc4) + O14497[Dtype(loc4)-1943]);
	F1231_11164(Current, loc3);
	loc7 = F1231_11337(Current);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F899_7054(RTCW(loc1), loc3);
		loc9 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_0_0_0_);
		F2023_20412(RTCW(loc1), loc7);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_4_0_0_1_);
		loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
		F1231_11334(Current, loc4, loc7, loc1);
	}
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F1231_11293(Current, arg1);
	} else {
		if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 0L))) {
			loc6 = F1541_13847(RTCW(loc7));
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc6))-1835])(loc6);
			tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
			F1037_8385(RTCW(tr1), loc8, loc6, loc1);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
				F1033_8331(Current);
				if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
					F2046_21728(RTCV(F1023_8173(Current)));
				}
				F1231_11293(Current, arg1);
			} else {
				tb1 = F2027_20678(RTCW(loc2));
				if (tb1) {
					F1231_11200(Current, arg1, loc6, loc1);
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1485[Dtype(RTCW(loc6))-1835])(loc6, loc4);
					loc12 = tr1;
					if (EIF_TEST(loc12)) {
						loc5 = *(EIF_INTEGER_32 *)(loc12 + O10400[Dtype(loc12)-1302]);
						F1944_19225(RTCW(loc4), loc5);
						F1231_11201(Current, arg1, loc12, loc2, loc1);
					} else {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1484[Dtype(RTCW(loc6))-1835])(loc6, loc4);
						loc13 = tr1;
						if (EIF_TEST(loc13)) {
							loc5 = *(EIF_INTEGER_32 *)(loc13 + O10400[Dtype(loc13)-1302]);
							F1944_19225(RTCW(loc4), loc5);
							F1231_11309(Current, arg1, loc13, loc2, loc1);
							if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
							} else {
								tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
								if ((EIF_BOOLEAN)(tr1 == NULL)) {
									F1033_8331(Current);
									tr1 = F1023_8173(Current);
									F2046_21401(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc4, loc13, loc2);
									F1231_11293(Current, arg1);
								}
							}
						} else {
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							F2046_21498(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc4, loc2);
							F1231_11293(Current, arg1);
						}
					}
				}
			}
		} else {
			tb1 = F1432_13373(RTCW(loc7));
			if (tb1) {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
				F1231_11293(Current, arg1);
			} else {
				loc11 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_4_0_0_1_);
				loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc10 > loc11)) break;
					loc6 = F1541_13846(RTCW(loc7), loc10);
					loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc6))-1835])(loc6);
					tr1 = F2027_20748(RTCW(loc2), loc5);
					loc14 = tr1;
					if (EIF_TEST(loc14)) {
						tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
						F1037_8385(RTCW(tr1), loc8, loc6, loc1);
						F1231_11201(Current, arg1, loc14, loc2, loc1);
						F899_7059(RTCW(loc1), loc9);
					} else {
						tb1 = F2027_20576(RTCW(loc2));
						if (tb1) {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						} else {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						loc10 = (EIF_INTEGER_32) loc11;
					}
					loc10++;
				}
			}
		}
	}
	F1231_11572(Current, loc1);
	F1231_11338(Current, loc7);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_static_dotnet_procedure_call_instruction_validity */
void F1231_11200 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg2);
	RTLR(3,loc3);
	RTLR(4,arg1);
	RTLR(5,loc5);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,arg3);
	RTLR(9,loc2);
	RTLR(10,loc6);
	RTLIU(11);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(arg2))-1835])(arg2);
	loc3 = F1785_17456(RTCW(arg1));
	loc5 = F1231_11559(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1488[Dtype(RTCW(arg2))-1835])(arg2, loc3, loc5);
	tb1 = F1432_13373(RTCW(loc5));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = F1231_11336(Current, loc3, arg2);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
		F1231_11558(Current, loc5, tr1, tr2, arg3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			F1231_11293(Current, arg1);
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_4_0_0_1_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
				loc2 = F1541_13847(RTCW(loc5));
				loc4 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O10400[Dtype(loc2)-1302]);
				F1944_19225(RTCW(loc3), loc4);
				F1231_11201(Current, arg1, loc2, loc1, arg3);
			} else {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
				F1231_11293(Current, arg1);
			}
		}
	} else {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1484[Dtype(RTCW(arg2))-1835])(arg2, loc3);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			F1231_11309(Current, arg1, loc6, loc1, arg3);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
				if ((EIF_BOOLEAN)(tr1 == NULL)) {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					F2046_21401(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc3, loc6, loc1);
					F1231_11293(Current, arg1);
				}
			}
		} else {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21498(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc3, loc1);
			F1231_11293(Current, arg1);
		}
	}
	F1231_11560(Current, loc5);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_static_procedure_call_instruction_validity */
void F1231_11201 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLR(4,arg2);
	RTLR(5,tr1);
	RTLR(6,arg3);
	RTLR(7,arg4);
	RTLIU(8);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc2 = F1785_17456(RTCW(arg1));
	loc1 = F1786_17466(RTCW(arg1));
	F1231_11419(Current, loc1, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9248[dtype-1230]));
	tb1 = F1837_17835(RTCW(arg2), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
	if ((EIF_BOOLEAN) !tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21499(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc2, arg2, arg3);
	}
	loc3 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	F1231_11294(Current, loc2, arg2, arg3);
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (tb1 || loc3);
	F1231_11292(Current, arg1, arg4, arg2, arg3, NULL);
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (tb1 || loc3);
	F1231_11276(Current, arg1, arg2, arg3);
	F1033_8332(Current, (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc3));
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9224[dtype-1230])(Current, arg1, loc1, arg2);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_unqualified_call_instruction_validity */
void F1231_11202 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc5);
	RTLR(4,loc6);
	RTLR(5,tr1);
	RTLR(6,loc7);
	RTLR(7,loc3);
	RTLR(8,loc8);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13378[Dtype(RTCW(arg1))-1748])(arg1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O14497[Dtype(loc1)-1943]);
	loc5 = loc1;
	loc5 = RTRV(eif_new_type(1986, 0x01),loc5);
	if (EIF_TEST(loc5)) {
		tb1 = F1987_19667(loc5);
		if (tb1) {
			F1231_11203(Current, arg1, loc5);
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			tb1 = F1987_19663(loc5);
			if (tb1) {
				F1231_11205(Current, arg1, loc5);
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tb1 = F1987_19665(loc5);
				if (tb1) {
					F1231_11204(Current, arg1, loc5);
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tb1 = F1987_19664(loc5);
					if (tb1) {
						F1231_11206(Current, arg1, loc5);
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
			}
		}
	}
	if (loc4) {
	} else {
		if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
				F1033_8331(Current);
				if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
					F2046_21728(RTCV(F1023_8173(Current)));
				}
				F1231_11293(Current, arg1);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
				tr1 = F2027_20745(RTCW(tr1), loc1);
				loc6 = tr1;
				if (EIF_TEST(loc6)) {
					loc2 = *(EIF_INTEGER_32 *)(loc6 + O10400[Dtype(loc6)-1302]);
					F1944_19225(RTCW(loc1), loc2);
					F1231_11207(Current, arg1, loc6);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr1 = F2027_20744(RTCW(tr1), loc1);
					loc7 = tr1;
					if (EIF_TEST(loc7)) {
						loc2 = *(EIF_INTEGER_32 *)(loc7 + O10400[Dtype(loc7)-1302]);
						F1944_19225(RTCW(loc1), loc2);
						loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
						F1231_11305(Current, arg1, loc7, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc3, NULL);
						F1231_11572(Current, loc3);
						if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						} else {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
							if ((EIF_BOOLEAN)(tr1 == NULL)) {
								F1033_8331(Current);
								tr1 = F1023_8173(Current);
								F2046_21403(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc1, loc7);
								F1231_11293(Current, arg1);
							}
						}
					} else {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21497(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc1);
						F1231_11293(Current, arg1);
					}
				}
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tr1 = F2027_20748(RTCW(tr1), loc2);
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				F1231_11207(Current, arg1, loc8);
			} else {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
				F1231_11293(Current, arg1);
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_unqualified_formal_argument_call_instruction_validity */
void F1231_11203 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
		F1033_8331(Current);
		if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
			F2046_21728(RTCV(F1023_8173(Current)));
		}
		F1231_11293(Current, arg1);
	} else {
		loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
		F1231_11302(Current, arg1, arg2, loc1);
		F1231_11572(Current, loc1);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13379[Dtype(RTCW(arg1))-1748])(arg1);
				if ((EIF_BOOLEAN)(tr1 != NULL)) {
					F1033_8331(Current);
					tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
					loc2 = tr1;
					if (EIF_TEST(loc2)) {
						tr1 = F1023_8173(Current);
						F2046_21551(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg2, loc2);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
						if (tb1) {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
							tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
							F2046_21550(RTCW(tr1), tr2, arg2, tr3);
						} else {
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
				}
				F1033_8331(Current);
				tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					tr1 = F1023_8173(Current);
					F2046_21561(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg2, loc3);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
					if (tb1) {
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
						tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
						F2046_21560(RTCW(tr1), tr2, arg2, tr3);
					} else {
						F2046_21728(RTCV(F1023_8173(Current)));
					}
				}
				F1231_11293(Current, arg1);
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_unqualified_iteration_cursor_call_instruction_validity */
void F1231_11204 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
		F1033_8331(Current);
		if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
			F2046_21728(RTCV(F1023_8173(Current)));
		}
		F1231_11293(Current, arg1);
	} else {
		loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
		F1231_11304(Current, arg1, arg2, loc1);
		F1231_11572(Current, loc1);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13379[Dtype(RTCW(arg1))-1748])(arg1);
				if ((EIF_BOOLEAN)(tr1 != NULL)) {
					F1033_8331(Current);
					tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
					loc2 = tr1;
					if (EIF_TEST(loc2)) {
						tr1 = F1023_8173(Current);
						F2046_21553(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg2, loc2);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
						if (tb1) {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
							tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
							F2046_21552(RTCW(tr1), tr2, arg2, tr3);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
							tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8703[Dtype(RTCW(tr1))-1840])(tr1);
							if (tb1) {
								tr1 = F1023_8173(Current);
								tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
								tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
								tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8714[Dtype(RTCW(tr3))-1840])(tr3);
								F2046_21554(RTCW(tr1), tr2, arg2, tr3);
							} else {
								F2046_21728(RTCV(F1023_8173(Current)));
							}
						}
					}
				}
				F1033_8331(Current);
				tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					tr1 = F1023_8173(Current);
					F2046_21563(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg2, loc3);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
					if (tb1) {
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
						tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
						F2046_21562(RTCW(tr1), tr2, arg2, tr3);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8703[Dtype(RTCW(tr1))-1840])(tr1);
						if (tb1) {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
							tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8714[Dtype(RTCW(tr3))-1840])(tr3);
							F2046_21564(RTCW(tr1), tr2, arg2, tr3);
						} else {
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
				}
				F1231_11293(Current, arg1);
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_unqualified_local_variable_call_instruction_validity */
void F1231_11205 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
		F1033_8331(Current);
		if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
			F2046_21728(RTCV(F1023_8173(Current)));
		}
		F1231_11293(Current, arg1);
	} else {
		loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
		F1231_11306(Current, arg1, arg2, loc1);
		F1231_11572(Current, loc1);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13379[Dtype(RTCW(arg1))-1748])(arg1);
				if ((EIF_BOOLEAN)(tr1 != NULL)) {
					F1033_8331(Current);
					tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
					loc2 = tr1;
					if (EIF_TEST(loc2)) {
						tr1 = F1023_8173(Current);
						F2046_21556(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg2, loc2);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
						if (tb1) {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
							tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
							F2046_21555(RTCW(tr1), tr2, arg2, tr3);
						} else {
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
				}
				F1033_8331(Current);
				tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					tr1 = F1023_8173(Current);
					F2046_21566(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg2, loc3);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
					if (tb1) {
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
						tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
						F2046_21565(RTCW(tr1), tr2, arg2, tr3);
					} else {
						F2046_21728(RTCV(F1023_8173(Current)));
					}
				}
				F1231_11293(Current, arg1);
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_unqualified_object_test_local_call_instruction_validity */
void F1231_11206 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
		F1033_8331(Current);
		if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
			F2046_21728(RTCV(F1023_8173(Current)));
		}
		F1231_11293(Current, arg1);
	} else {
		loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
		F1231_11307(Current, arg1, arg2, loc1);
		F1231_11572(Current, loc1);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13379[Dtype(RTCW(arg1))-1748])(arg1);
				if ((EIF_BOOLEAN)(tr1 != NULL)) {
					F1033_8331(Current);
					tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
					loc2 = tr1;
					if (EIF_TEST(loc2)) {
						tr1 = F1023_8173(Current);
						F2046_21553(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg2, loc2);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
						if (tb1) {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
							tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
							F2046_21552(RTCW(tr1), tr2, arg2, tr3);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
							tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8703[Dtype(RTCW(tr1))-1840])(tr1);
							if (tb1) {
								tr1 = F1023_8173(Current);
								tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
								tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
								tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8714[Dtype(RTCW(tr3))-1840])(tr3);
								F2046_21554(RTCW(tr1), tr2, arg2, tr3);
							} else {
								F2046_21728(RTCV(F1023_8173(Current)));
							}
						}
					}
				}
				F1033_8331(Current);
				tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					tr1 = F1023_8173(Current);
					F2046_21568(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg2, loc3);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
					if (tb1) {
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
						tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
						F2046_21567(RTCW(tr1), tr2, arg2, tr3);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8703[Dtype(RTCW(tr1))-1840])(tr1);
						if (tb1) {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
							tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8714[Dtype(RTCW(tr3))-1840])(tr3);
							F2046_21569(RTCW(tr1), tr2, arg2, tr3);
						} else {
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
				}
				F1231_11293(Current, arg1);
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_unqualified_procedure_call_instruction_validity */
void F1231_11207 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13378[Dtype(RTCW(arg1))-1748])(arg1);
	tb1 = '\0';
	if (*(EIF_BOOLEAN *)(Current + O9280[dtype-1230])) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13718[Dtype(RTCW(arg2))-1840])(arg2);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21490(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1, arg2);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	F1231_11295(Current, loc1, arg2);
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || tb1);
	loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	F1231_11292(Current, arg1, loc3, arg2, NULL, NULL);
	F1231_11572(Current, loc3);
	F1033_8332(Current, (EIF_BOOLEAN) (loc2 || *(EIF_BOOLEAN *)(Current + O7067[dtype-1032])));
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9233[dtype-1230])(Current, arg1, arg2);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_instructions_validity */
void F1231_11208 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		tr1 = F1003_7568(RTCW(arg1), loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13071[Dtype(RTCW(tr1))-1646])(tr1, Current);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc3 || tb1);
		loc1++;
	}
	if (loc3) {
		F1033_8331(Current);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_rescue_validity */
void F1231_11209 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_BOOLEAN *)(Current + O9274[dtype-1230]);
	*(EIF_BOOLEAN *)(Current + O9274[dtype-1230]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F1231_11208(Current, arg1);
	*(EIF_BOOLEAN *)(Current + O9274[dtype-1230]) = (EIF_BOOLEAN) loc1;
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_across_expression_validity */
void F1231_11210 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11239(Current, arg1, arg2);
}

/* {ET_FEATURE_CHECKER}.check_binary_integer_constant_validity */
void F1231_11211 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11236(Current, arg1, arg2);
}

/* {ET_FEATURE_CHECKER}.check_bracket_expression_validity */
void F1231_11212 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11258(Current, arg1, arg2, NULL);
}

/* {ET_FEATURE_CHECKER}.check_c1_character_constant_validity */
void F1231_11213 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11216(Current, arg1, arg2);
}

/* {ET_FEATURE_CHECKER}.check_c2_character_constant_validity */
void F1231_11214 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11216(Current, arg1, arg2);
}

/* {ET_FEATURE_CHECKER}.check_c3_character_constant_validity */
void F1231_11215 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11216(Current, arg1, arg2);
}

/* {ET_FEATURE_CHECKER}.check_character_constant_validity */
void F1231_11216 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,loc5);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,loc3);
	RTLR(6,tr1);
	RTLR(7,loc1);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLR(10,tr4);
	RTLR(11,arg2);
	RTLIU(12);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc4 = RTOUCR(571,F396_4600, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	loc5 = *(EIF_REFERENCE *)(Current + O9258[dtype-1230]);
	loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13357[Dtype(RTCW(loc2))-1725])(loc2);
		F1231_11164(Current, loc3);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13666[Dtype(RTCW(loc3))-1885])(loc3);
			if ((EIF_BOOLEAN) !tb1) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21528(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
			} else {
				loc4 = (EIF_REFERENCE) loc3;
				loc5 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
			}
		}
	}
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
	} else {
		tr1 = F1231_11526(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12752[Dtype(tr1)-1610]);
		tb1 = F1884_18234(RTCW(tr1), loc4, loc5, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
		if (tb1) {
			tb1 = F1934_19108(RTCW(arg1));
			if (tb1) {
				tr1 = F1231_11526(Current);
				loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12752[Dtype(tr1)-1610]);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9170[dtype-1230])(Current, arg1, loc1);
			} else {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
				tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
				tr4 = F1231_11526(Current);
				tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12752[Dtype(tr4)-1610]);
				F2046_21571(RTCW(tr1), tr2, tr3, arg1, tr4);
			}
		} else {
			tr1 = F1231_11526(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12753[Dtype(tr1)-1610]);
			tb1 = F1884_18234(RTCW(tr1), loc4, loc5, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
			if (tb1) {
				tb1 = F1934_19109(RTCW(arg1));
				if (tb1) {
					tr1 = F1231_11526(Current);
					loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12753[Dtype(tr1)-1610]);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9171[dtype-1230])(Current, arg1, loc1);
				} else {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
					tr4 = F1231_11526(Current);
					tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12753[Dtype(tr4)-1610]);
					F2046_21571(RTCW(tr1), tr2, tr3, arg1, tr4);
				}
			}
		}
	}
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
	} else {
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
		} else {
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21528(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
			} else {
				tb1 = F1934_19108(RTCW(arg1));
				if (tb1) {
					tr1 = F1231_11526(Current);
					loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12752[Dtype(tr1)-1610]);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9170[dtype-1230])(Current, arg1, loc1);
				} else {
					tb1 = F1934_19109(RTCW(arg1));
					if (tb1) {
						tr1 = F1231_11526(Current);
						loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12753[Dtype(tr1)-1610]);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9171[dtype-1230])(Current, arg1, loc1);
					} else {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
						tr4 = F1231_11526(Current);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12753[Dtype(tr4)-1610]);
						F2046_21571(RTCW(tr1), tr2, tr3, arg1, tr4);
					}
				}
			}
		}
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1934_19121(RTCW(arg1), loc1);
		F899_7054(RTCW(arg2), loc1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_convert_builtin_expression_validity */
void F1231_11217 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	F1231_11290(Current, tr1, arg2, *(EIF_REFERENCE *)(Current + O9258[dtype-1230]));
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9172[dtype-1230])(Current, arg1, loc1);
		F2023_20389(RTCW(arg2), *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
		F899_7054(RTCW(arg2), loc1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_convert_from_expression_validity */
void F1231_11218 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11222(Current, arg1, arg2);
}

/* {ET_FEATURE_CHECKER}.check_convert_to_expression_validity */
void F1231_11219 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11258(Current, arg1, arg2, NULL);
}

/* {ET_FEATURE_CHECKER}.check_converted_target_infix_expression_validity */
void F1231_11220 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(20);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc6);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLR(5,arg4);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,arg3);
	RTLR(9,arg2);
	RTLR(10,loc10);
	RTLR(11,tr1);
	RTLR(12,loc11);
	RTLR(13,loc12);
	RTLR(14,loc5);
	RTLR(15,loc7);
	RTLR(16,loc8);
	RTLR(17,tr2);
	RTLR(18,arg5);
	RTLR(19,loc9);
	RTLIU(20);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	loc6 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc2 = F1231_11337(Current);
	F2023_20412(RTCW(arg4), loc2);
	F1231_11334(Current, loc1, loc2, arg4);
	loc3 = F1541_13847(RTCW(loc2));
	loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc3))-1835])(loc3);
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
	} else {
		tb1 = F2022_20367(RTCW(arg4), arg3);
		if (tb1) {
		} else {
			if ((EIF_BOOLEAN)(loc4 == arg2)) {
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1484[Dtype(RTCW(loc3))-1835])(loc3, loc1);
				loc10 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc10)) {
				} else {
					tb1 = F1837_17835(loc10, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
					if ((EIF_BOOLEAN) !tb1) {
					} else {
						tb1 = '\01';
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10399[Dtype(loc10)-1840])(loc10);
						loc11 = tr1;
						if (!((EIF_BOOLEAN) !EIF_TEST(loc11))) {
							ti4_1 = *(EIF_INTEGER_32 *)(loc11+ _LNGOFF_3_0_0_0_);
							tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 1L));
						}
						if (tb1) {
						} else {
							tb1 = '\0';
							tr1 = F1231_11340(Current, loc6, arg3, arg4);
							loc12 = tr1;
							if (EIF_TEST(loc12)) {
								tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
							}
							if (tb1) {
								loc5 = RTLNS(eif_new_type(1731, 0x01).id, 1731, _OBJSIZ_2_0_0_1_0_0_0_0_);
								tr1 = F2022_20345(RTCW(arg4));
								F1732_17169(RTCW(loc5), loc12, tr1);
								ti4_1 = *(EIF_INTEGER_32 *)(loc12 + O13392[Dtype(loc12)-1721]);
								F1722_17132(RTCW(loc5), ti4_1);
								loc7 = F1649_16721(loc11, ((EIF_INTEGER_32) 1L));
								loc8 = (EIF_REFERENCE) loc10;
							} else {
								if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
								} else {
									tb1 = F2022_20379(RTCW(arg3), arg4, *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
									if (tb1) {
										loc5 = RTLNS(eif_new_type(1731, 0x01).id, 1731, _OBJSIZ_2_0_0_1_0_0_0_0_);
										tr1 = F2022_20345(RTCW(arg4));
										F1732_17169(RTCW(loc5), loc6, tr1);
										ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6) + O13392[Dtype(loc6)-1721]);
										F1722_17132(RTCW(loc5), ti4_1);
										loc8 = (EIF_REFERENCE) loc10;
										loc7 = F1649_16721(loc11, ((EIF_INTEGER_32) 1L));
									}
								}
							}
						}
					}
				}
			}
		}
	}
	F1231_11338(Current, loc2);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 == NULL) || (EIF_BOOLEAN)(loc7 == NULL)) || (EIF_BOOLEAN)(loc8 == NULL))) {
	} else {
		tr1 = F1814_17596(RTCW(loc7));
		tr2 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
		tb1 = F2022_20377(RTCW(arg4), tr1, arg4, tr2);
		if (tb1) {
			if ((EIF_BOOLEAN)(arg5 != NULL)) {
				
				eif_put_reference_item(RTCW(arg5),1,loc8);
				
				eif_put_reference_item(RTCW(arg5),2,loc4);
				tr1 = eif_boxed_item(arg5,3);
				F2023_20428(RTCW(tr1), arg4);
			}
			F1767_17368(RTCW(arg1), loc5);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc8) + O10400[Dtype(loc8)-1302]);
			F1944_19225(RTCW(loc1), ti4_1);
			tb1 = F2027_20580(RTCW(loc4));
			if (tb1) {
				F1801_17516(RTCW(arg1), (EIF_BOOLEAN) 1);
			} else {
				tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_0_);
				if (tb1) {
					F1801_17516(RTCW(arg1), (EIF_BOOLEAN) 0);
					loc9 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
					tr1 = F1814_17596(RTCW(loc7));
					F899_7054(RTCW(arg4), tr1);
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
					F1231_11290(Current, tr1, loc9, arg4);
					F899_7057(RTCW(arg4));
					F1231_11572(Current, loc9);
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_create_expression_validity */
void F1231_11221 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11222(Current, arg1, arg2);
}

/* {ET_FEATURE_CHECKER}.check_creation_expression_validity */
void F1231_11222 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,loc6);
	RTLR(2,arg1);
	RTLR(3,loc4);
	RTLR(4,loc5);
	RTLR(5,tr1);
	RTLR(6,loc2);
	RTLR(7,arg2);
	RTLR(8,loc8);
	RTLR(9,loc7);
	RTLR(10,loc1);
	RTLR(11,loc12);
	RTLR(12,loc13);
	RTLR(13,loc14);
	RTLIU(14);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13375[Dtype(RTCW(arg1))-1746])(arg1);
	if ((EIF_BOOLEAN)(loc6 != NULL)) {
		loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13531[Dtype(RTCW(loc6))-1780])(loc6);
		loc3 = *(EIF_INTEGER_32 *)(RTCW(loc4) + O14497[Dtype(loc4)-1943]);
	} else {
		loc6 = *(EIF_REFERENCE *)(Current + O9309[dtype-1230]);
		loc5 = F1627_16497(RTCW(arg1));
		tr1 = *(EIF_REFERENCE *)(Current + O9310[dtype-1230]);
		ti4_1 = F1286_12618(RTCW(loc5));
		ti4_2 = F1286_12619(RTCW(loc5));
		F1286_12620(RTCW(tr1), ti4_1, ti4_2);
		loc4 = *(EIF_REFERENCE *)(Current + O9310[dtype-1230]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O12987[Dtype(tr1)-1616]);
	}
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13374[Dtype(RTCW(arg1))-1746])(arg1);
	F899_7054(RTCW(arg2), loc2);
	F1231_11164(Current, loc2);
	loc8 = F1231_11337(Current);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F2023_20412(RTCW(arg2), loc8);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc8)+ _LNGOFF_4_0_0_1_);
		loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
		F1231_11334(Current, loc4, loc8, arg2);
	}
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F1231_11293(Current, loc6);
	} else {
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
			loc7 = F1541_13847(RTCW(loc8));
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc7))-1835])(loc7);
			if ((EIF_BOOLEAN)(loc6 == *(EIF_REFERENCE *)(Current + O9309[dtype-1230]))) {
				F1231_11224(Current, arg1, loc6, NULL, loc7, loc9, arg2);
			} else {
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
					F1033_8331(Current);
					if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
						F2046_21728(RTCV(F1023_8173(Current)));
					}
					F1231_11293(Current, loc6);
				} else {
					tb1 = F2027_20678(RTCW(loc1));
					if (tb1) {
						F1231_11223(Current, arg1, loc6, loc7, loc9, arg2);
					} else {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1485[Dtype(RTCW(loc7))-1835])(loc7, loc4);
						loc12 = tr1;
						if (EIF_TEST(loc12)) {
							loc3 = *(EIF_INTEGER_32 *)(loc12 + O10400[Dtype(loc12)-1302]);
							F1944_19225(RTCW(loc4), loc3);
							F1231_11224(Current, arg1, loc6, loc12, loc7, loc9, arg2);
						} else {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1484[Dtype(RTCW(loc7))-1835])(loc7, loc4);
							loc13 = tr1;
							if (EIF_TEST(loc13)) {
								F1033_8331(Current);
								tr1 = F1023_8173(Current);
								F2046_21361(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc4, loc13, loc1);
								F1231_11293(Current, loc6);
							} else {
								F1033_8331(Current);
								tr1 = F1023_8173(Current);
								F2046_21498(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc4, loc1);
								F1231_11293(Current, loc6);
							}
						}
					}
				}
			}
		} else {
			tb1 = F1432_13373(RTCW(loc8));
			if (tb1) {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
				F1231_11293(Current, loc6);
			} else {
				loc11 = *(EIF_INTEGER_32 *)(RTCW(loc8)+ _LNGOFF_4_0_0_1_);
				loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc10 > loc11)) break;
					loc7 = F1541_13846(RTCW(loc8), loc10);
					loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc7))-1835])(loc7);
					tr1 = F2027_20748(RTCW(loc1), loc3);
					loc14 = tr1;
					if (EIF_TEST(loc14)) {
						F1231_11224(Current, arg1, loc6, loc14, loc7, loc9, arg2);
					} else {
						tb1 = F2027_20576(RTCW(loc1));
						if (tb1) {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						} else {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						loc10 = (EIF_INTEGER_32) loc11;
					}
					loc10++;
				}
			}
		}
	}
	F1231_11338(Current, loc8);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_dotnet_creation_procedure_call_expression_validity */
void F1231_11223 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_BOOLEAN arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg3);
	RTLR(3,loc4);
	RTLR(4,arg2);
	RTLR(5,loc5);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,arg5);
	RTLR(9,loc2);
	RTLR(10,arg1);
	RTLR(11,loc6);
	RTLIU(12);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(arg3))-1835])(arg3);
	loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13531[Dtype(RTCW(arg2))-1780])(arg2);
	loc5 = F1231_11559(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1488[Dtype(RTCW(arg3))-1835])(arg3, loc4, loc5);
	tb1 = F1432_13373(RTCW(loc5));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = F1231_11336(Current, loc4, arg3);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13532[Dtype(RTCW(arg2))-1780])(arg2);
		F1231_11558(Current, loc5, tr1, tr2, arg5, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 1);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			F1231_11293(Current, arg2);
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_4_0_0_1_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
				loc2 = F1541_13847(RTCW(loc5));
				loc3 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O10400[Dtype(loc2)-1302]);
				F1944_19225(RTCW(loc4), loc3);
				F1231_11224(Current, arg1, arg2, loc2, arg3, arg4, arg5);
			} else {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
				F1231_11293(Current, arg2);
			}
		}
	} else {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1484[Dtype(RTCW(arg3))-1835])(arg3, loc4);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21361(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc4, loc6, loc1);
			F1231_11293(Current, arg2);
		} else {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21498(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc4, loc1);
			F1231_11293(Current, arg2);
		}
	}
	F1231_11560(Current, loc5);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_creation_procedure_call_expression_validity */
void F1231_11224 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_BOOLEAN arg5, EIF_REFERENCE arg6)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,arg4);
	RTLR(3,loc1);
	RTLR(4,arg6);
	RTLR(5,loc2);
	RTLR(6,loc6);
	RTLR(7,arg1);
	RTLR(8,tr1);
	RTLR(9,arg3);
	RTLR(10,arg2);
	RTLR(11,loc7);
	RTLR(12,loc3);
	RTLIU(13);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(arg4))-1835])(arg4);
	loc1 = F899_7046(RTCW(arg6));
	F899_7057(RTCW(arg6));
	loc2 = F1884_18203(RTCW(loc1), arg6);
	F899_7053(RTCW(arg6), loc1);
	F1231_11420(Current, loc1, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9248[dtype-1230]));
	loc6 = loc2;
	loc6 = RTRV(eif_new_type(2023, 0x01),loc6);
	if (EIF_TEST(loc6)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13466[Dtype(RTCW(arg1))-1746])(arg1);
		F1231_11166(Current, loc6, tr1);
		loc4 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	}
	if ((EIF_BOOLEAN)(arg3 == NULL)) {
		F1231_11181(Current, arg1, arg2, loc5, arg6);
	} else {
		loc7 = loc2;
		loc7 = RTRV(eif_new_type(1885, 0x01),loc7);
		if (EIF_TEST(loc7)) {
			if (arg5) {
				loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
				F2023_20428(RTCW(loc3), arg6);
				tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
				F1037_8385(RTCW(tr1), arg5, arg4, loc3);
				F1231_11180(Current, arg1, arg2, arg3, loc5, loc7, loc3);
				F1231_11572(Current, loc3);
			} else {
				F1231_11180(Current, arg1, arg2, arg3, loc5, loc7, arg6);
			}
		} else {
			F1231_11179(Current, arg1, arg2, arg3, loc5, arg6);
		}
	}
	F1033_8332(Current, (EIF_BOOLEAN) (loc4 || *(EIF_BOOLEAN *)(Current + O7067[dtype-1032])));
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			tb1 = F2022_20355(RTCW(arg6));
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = RTOUCR(75,F396_4598, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				F899_7054(RTCW(arg6), tr1);
				tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R13938[Dtype(RTCW(loc2))-1885])(loc2, tr1);
				loc2 = (EIF_REFERENCE) tr1;
			}
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9173[dtype-1230])(Current, arg1, loc2, arg3);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_current_validity */
void F1231_11225 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if (*(EIF_BOOLEAN *)(Current + O9280[dtype-1230])) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21492(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
	} else {
		tb1 = F2022_20355(RTCW(arg2));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = RTOUCR(75,F396_4598, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			F899_7054(RTCW(arg2), tr1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9175[dtype-1230])(Current, arg1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_current_address_validity */
void F1231_11226 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,arg2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if (*(EIF_BOOLEAN *)(Current + O9280[dtype-1230])) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21493(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
	} else {
		tr1 = F1231_11526(Current);
		loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + O12801[Dtype(tr1)-1610]);
		loc1 = *(EIF_REFERENCE *)(RTCW(loc2) + O15311[Dtype(loc2)-2023]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8089[Dtype(RTCW(loc1))-1585])(loc1);
		tb1 = F2027_20648(RTCW(tr1));
		if (tb1) {
			tb1 = F2022_20355(RTCW(arg2));
			if ((EIF_BOOLEAN) !tb1) {
				tr1 = RTOUCR(75,F396_4598, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				F899_7054(RTCW(arg2), tr1);
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9231[dtype-1230])(Current, arg1, loc2, arg2);
			F899_7054(RTCW(arg2), loc2);
		} else {
			tr1 = F1231_11526(Current);
			loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + O12775[Dtype(tr1)-1610]);
			F899_7054(RTCW(arg2), loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9208[dtype-1230])(Current, arg1, loc3);
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_equality_expression_validity */
void F1231_11227 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(15);
	RTLR(0,Current);
	RTLR(1,loc7);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,loc1);
	RTLR(6,arg1);
	RTLR(7,loc2);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLR(10,loc6);
	RTLR(11,loc5);
	RTLR(12,tr4);
	RTLR(13,tr5);
	RTLR(14,arg2);
	RTLIU(15);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	loc7 = *(EIF_REFERENCE *)(RTCW(tr1) + O12741[Dtype(tr1)-1610]);
	loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	loc4 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	F1231_11290(Current, loc1, loc3, loc7);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F1231_11290(Current, loc2, loc4, loc7);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) != *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
			} else {
				tr1 = RTOUCR(764,F396_4661, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr2 = RTOUCR(764,F396_4661, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr3 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
				tb1 = F2022_20380(RTCW(loc3), tr1, loc4, tr2, tr3);
				if (tb1) {
				} else {
					tr1 = RTOUCR(764,F396_4661, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr2 = RTOUCR(764,F396_4661, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr3 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
					tb1 = F2022_20380(RTCW(loc4), tr1, loc3, tr2, tr3);
					if (tb1) {
					} else {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12774[Dtype(tr1)-1610]);
						tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
						tb1 = F2022_20365(RTCW(loc3), tr1, tr2);
						if (tb1) {
						} else {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12774[Dtype(tr1)-1610]);
							tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
							tb1 = F2022_20365(RTCW(loc4), tr1, tr2);
							if (tb1) {
							} else {
								loc6 = F1231_11340(Current, loc2, loc4, loc3);
								loc8 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
								loc5 = F1231_11340(Current, loc1, loc3, loc4);
								*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc8);
								if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
								} else {
									if ((EIF_BOOLEAN)(loc6 != NULL)) {
										if ((EIF_BOOLEAN)(loc5 != NULL)) {
										}
										F1767_17369(RTCW(arg1), loc6);
									} else {
										if ((EIF_BOOLEAN)(loc5 != NULL)) {
											F1767_17368(RTCW(arg1), loc5);
										} else {
											tr1 = F1023_8173(Current);
											tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
											tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
											tr4 = F2022_20345(RTCW(loc3));
											tr5 = F2022_20345(RTCW(loc4));
											F2046_21522(RTCW(tr1), tr2, tr3, arg1, tr4, tr5);
										}
									}
								}
							}
						}
					}
				}
			}
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				tr1 = F1231_11526(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
				F899_7054(RTCW(arg2), tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9176[dtype-1230])(Current, arg1);
			}
		}
	} else {
		F1231_11290(Current, loc2, loc4, loc7);
		F1033_8331(Current);
	}
	F1231_11572(Current, loc4);
	F1231_11572(Current, loc3);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_expression_address_validity */
void F1231_11228 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,arg1);
	RTLR(6,arg2);
	RTLR(7,loc5);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12741[Dtype(tr1)-1610]);
	tr1 = F1231_11526(Current);
	loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + O12801[Dtype(tr1)-1610]);
	loc1 = *(EIF_REFERENCE *)(RTCW(loc2) + O15311[Dtype(loc2)-2023]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8089[Dtype(RTCW(loc1))-1585])(loc1);
	tb1 = F2027_20648(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		F1231_11290(Current, tr1, arg2, loc4);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9231[dtype-1230])(Current, arg1, loc2, arg2);
			F899_7054(RTCW(arg2), loc2);
		}
	} else {
		loc5 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		F1231_11290(Current, tr1, loc5, loc4);
		F1231_11572(Current, loc5);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			tr1 = F1231_11526(Current);
			loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + O12775[Dtype(tr1)-1610]);
			F899_7054(RTCW(arg2), loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9208[dtype-1230])(Current, arg1, loc3);
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_false_constant_validity */
void F1231_11229 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = F1231_11526(Current);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
	F899_7054(RTCW(arg2), loc1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9169[dtype-1230])(Current, arg1, loc1);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_feature_address_validity */
void F1231_11230 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(26);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,loc14);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,loc11);
	RTLR(9,loc10);
	RTLR(10,arg2);
	RTLR(11,loc12);
	RTLR(12,loc15);
	RTLR(13,loc17);
	RTLR(14,loc18);
	RTLR(15,loc7);
	RTLR(16,loc19);
	RTLR(17,loc5);
	RTLR(18,loc6);
	RTLR(19,loc20);
	RTLR(20,loc8);
	RTLR(21,loc9);
	RTLR(22,loc13);
	RTLR(23,loc16);
	RTLR(24,loc21);
	RTLR(25,loc22);
	RTLIU(26);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O14497[Dtype(loc1)-1943]);
	if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
			F1033_8331(Current);
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14503[Dtype(RTCW(loc1))-1944])(loc1);
			if (tb1) {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
			} else {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14500[Dtype(RTCW(loc1))-1944])(loc1);
				if (tb1) {
					F1033_8331(Current);
					F2046_21728(RTCV(F1023_8173(Current)));
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14501[Dtype(RTCW(loc1))-1944])(loc1);
					if (tb1) {
						if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
							F1033_8331(Current);
							if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
								F2046_21728(RTCV(F1023_8173(Current)));
							}
						} else {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14539[Dtype(RTCW(loc1))-1944])(loc1);
							loc2 = F1987_19659(RTCW(tr1));
							tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
							loc14 = F10_112(RTCW(tr1), loc2);
							if ((EIF_BOOLEAN)(loc14 == NULL)) {
								F1033_8331(Current);
								tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
								tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
								if (tb1) {
									tr1 = F1023_8173(Current);
									tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
									tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
									tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
									F2046_21309(RTCW(tr1), tr2, loc2, tr3);
								} else {
									tr1 = F1023_8173(Current);
									F2046_21310(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc2);
								}
							} else {
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9207[dtype-1230])(Current, loc2, loc14);
								tr1 = *(EIF_REFERENCE *)(RTCW(loc14) + _REFACS_4_);
								loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_1_0_2_);
								F1944_19225(RTCW(loc2), loc3);
								tr1 = F1231_11526(Current);
								loc11 = *(EIF_REFERENCE *)(RTCW(tr1) + O12801[Dtype(tr1)-1610]);
								loc10 = *(EIF_REFERENCE *)(RTCW(loc11) + O15311[Dtype(loc11)-2023]);
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8089[Dtype(RTCW(loc10))-1585])(loc10);
								tb1 = F2027_20648(RTCW(tr1));
								if (tb1) {
									tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
									F1553_14040(RTCW(tr1), loc14);
									tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
									tb1 = F1545_13939(RTCW(tr1));
									if ((EIF_BOOLEAN) !tb1) {
										F1033_8331(Current);
									} else {
										tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
										tr1 = F1545_13931(RTCW(tr1));
										F2023_20428(RTCW(arg2), tr1);
										(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9231[dtype-1230])(Current, arg1, loc11, arg2);
										F899_7054(RTCW(arg2), loc11);
									}
								} else {
									tr1 = F1231_11526(Current);
									loc12 = *(EIF_REFERENCE *)(RTCW(tr1) + O12775[Dtype(tr1)-1610]);
									F899_7054(RTCW(arg2), loc12);
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9208[dtype-1230])(Current, arg1, loc12);
								}
								loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							}
						}
					} else {
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14502[Dtype(RTCW(loc1))-1944])(loc1);
						if (tb1) {
							if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
								F1033_8331(Current);
								if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
									F2046_21728(RTCV(F1023_8173(Current)));
								}
							} else {
								loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14540[Dtype(RTCW(loc1))-1944])(loc1);
								tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
								loc15 = F11_125(RTCW(tr1), loc2);
								if ((EIF_BOOLEAN)(loc15 == NULL)) {
									F1033_8331(Current);
									tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
									tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
									if (tb1) {
										tr1 = F1023_8173(Current);
										tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
										tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
										tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
										F2046_21311(RTCW(tr1), tr2, loc2, tr3);
									} else {
										tr1 = F1023_8173(Current);
										F2046_21312(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc2);
									}
								} else {
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9190[dtype-1230])(Current, loc2, loc15);
									tr1 = *(EIF_REFERENCE *)(RTCW(loc15) + _REFACS_1_);
									loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_1_0_2_);
									F1944_19225(RTCW(loc2), loc3);
									tr1 = F1231_11526(Current);
									loc11 = *(EIF_REFERENCE *)(RTCW(tr1) + O12801[Dtype(tr1)-1610]);
									loc10 = *(EIF_REFERENCE *)(RTCW(loc11) + O15311[Dtype(loc11)-2023]);
									tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8089[Dtype(RTCW(loc10))-1585])(loc10);
									tb1 = F2027_20648(RTCW(tr1));
									if (tb1) {
										tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
										F1553_14040(RTCW(tr1), loc15);
										tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
										tb1 = F1545_13939(RTCW(tr1));
										if ((EIF_BOOLEAN) !tb1) {
											F1033_8331(Current);
										} else {
											tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
											tr1 = F1545_13931(RTCW(tr1));
											F2023_20428(RTCW(arg2), tr1);
											(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9231[dtype-1230])(Current, arg1, loc11, arg2);
											F899_7054(RTCW(arg2), loc11);
										}
									} else {
										tr1 = F1231_11526(Current);
										loc12 = *(EIF_REFERENCE *)(RTCW(tr1) + O12775[Dtype(tr1)-1610]);
										F899_7054(RTCW(arg2), loc12);
										(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9208[dtype-1230])(Current, arg1, loc12);
									}
									loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								}
							}
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr1 = F2027_20745(RTCW(tr1), loc1);
							loc17 = tr1;
							if (EIF_TEST(loc17)) {
								loc3 = *(EIF_INTEGER_32 *)(loc17 + O10400[Dtype(loc17)-1302]);
								F1944_19225(RTCW(loc1), loc3);
								F1231_11295(Current, loc1, loc17);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9211[dtype-1230])(Current, arg1, loc17);
								tr1 = F1231_11526(Current);
								loc12 = *(EIF_REFERENCE *)(RTCW(tr1) + O12775[Dtype(tr1)-1610]);
								F899_7054(RTCW(arg2), loc12);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9208[dtype-1230])(Current, arg1, loc12);
								loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
								tr1 = F2027_20744(RTCW(tr1), loc1);
								loc18 = tr1;
								if (EIF_TEST(loc18)) {
									loc3 = *(EIF_INTEGER_32 *)(loc18 + O10400[Dtype(loc18)-1302]);
									F1944_19225(RTCW(loc1), loc3);
									F1231_11295(Current, loc1, loc18);
									tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc18)-1840])(loc18);
									if (tb1) {
										if (*(EIF_BOOLEAN *)(Current + O9280[dtype-1230])) {
											F1033_8331(Current);
											tr1 = F1023_8173(Current);
											F2046_21491(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1, loc18);
										} else {
											(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9167[dtype-1230])(Current, arg1, loc18);
											tr1 = F1231_11526(Current);
											loc11 = *(EIF_REFERENCE *)(RTCW(tr1) + O12801[Dtype(tr1)-1610]);
											loc10 = *(EIF_REFERENCE *)(RTCW(loc11) + O15311[Dtype(loc11)-2023]);
											tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8089[Dtype(RTCW(loc10))-1585])(loc10);
											tb1 = F2027_20648(RTCW(tr1));
											if (tb1) {
												loc7 = F1839_17878(loc18);
												tb1 = '\01';
												tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13941[Dtype(RTCW(loc7))-1885])(loc7);
												if (!tb2) {
													tb1 = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
												}
												if (tb1) {
													F899_7054(RTCW(arg2), loc7);
													(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9231[dtype-1230])(Current, arg1, loc11, arg2);
													F899_7054(RTCW(arg2), loc11);
													loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
												}
											} else {
												tr1 = F1231_11526(Current);
												loc12 = *(EIF_REFERENCE *)(RTCW(tr1) + O12775[Dtype(tr1)-1610]);
												F899_7054(RTCW(arg2), loc12);
												(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9208[dtype-1230])(Current, arg1, loc12);
												loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
											}
										}
									} else {
										(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9179[dtype-1230])(Current, arg1, loc18);
										tr1 = F1231_11526(Current);
										loc12 = *(EIF_REFERENCE *)(RTCW(tr1) + O12775[Dtype(tr1)-1610]);
										F899_7054(RTCW(arg2), loc12);
										(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9208[dtype-1230])(Current, arg1, loc12);
										loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									}
								} else {
									F1033_8331(Current);
									tr1 = F1023_8173(Current);
									F2046_21486(RTCW(tr1), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1);
								}
							}
						}
					}
				}
			}
		}
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) && (EIF_BOOLEAN) !loc4)) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14503[Dtype(RTCW(loc1))-1944])(loc1);
		if (tb1) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) == NULL) && *(EIF_BOOLEAN *)(Current + O9277[dtype-1230]))) {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
				loc19 = tr1;
				if (EIF_TEST(loc19)) {
					loc5 = *(EIF_REFERENCE *)(loc19 + _REFACS_5_);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
					loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2903[Dtype(RTCW(tr1))-1755])(tr1);
				}
				if ((EIF_BOOLEAN)(loc5 == NULL)) {
					F1033_8331(Current);
					F2046_21728(RTCV(F1023_8173(Current)));
				} else {
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 1L))) {
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_3_0_0_0_);
						tb1 = (EIF_BOOLEAN) (loc3 > ti4_1);
					}
					if (tb1) {
						F1033_8331(Current);
						F2046_21728(RTCV(F1023_8173(Current)));
					} else {
						loc6 = F1649_16721(RTCW(loc5), loc3);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14538[Dtype(RTCW(loc1))-1944])(loc1);
						loc2 = F1987_19659(RTCW(tr1));
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE)) R9177[dtype-1230])(Current, loc2, (EIF_BOOLEAN) 0, loc6);
						tr1 = F1231_11526(Current);
						loc11 = *(EIF_REFERENCE *)(RTCW(tr1) + O12801[Dtype(tr1)-1610]);
						loc10 = *(EIF_REFERENCE *)(RTCW(loc11) + O15311[Dtype(loc11)-2023]);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8089[Dtype(RTCW(loc10))-1585])(loc10);
						tb1 = F2027_20648(RTCW(tr1));
						if (tb1) {
							loc7 = F1814_17596(RTCW(loc6));
							F899_7054(RTCW(arg2), loc7);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9231[dtype-1230])(Current, arg1, loc11, arg2);
							F899_7054(RTCW(arg2), loc11);
						} else {
							tr1 = F1231_11526(Current);
							loc12 = *(EIF_REFERENCE *)(RTCW(tr1) + O12775[Dtype(tr1)-1610]);
							F899_7054(RTCW(arg2), loc12);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9208[dtype-1230])(Current, arg1, loc12);
						}
					}
				}
			}
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14500[Dtype(RTCW(loc1))-1944])(loc1);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) == NULL) && (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O9275[dtype-1230]) || *(EIF_BOOLEAN *)(Current + O9276[dtype-1230])))) {
					F1033_8331(Current);
					if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) == *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
						tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
						loc20 = tr1;
						if (EIF_TEST(loc20)) {
							tr1 = F1023_8173(Current);
							F2046_21306(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc1, loc20);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
							tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
							if (tb1) {
								tr1 = F1023_8173(Current);
								tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
								tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
								tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
								F2046_21304(RTCW(tr1), tr2, loc1, tr3);
							} else {
								F2046_21728(RTCV(F1023_8173(Current)));
							}
						}
					} else {
						if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
				} else {
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) == NULL) && *(EIF_BOOLEAN *)(Current + O9277[dtype-1230]))) {
						F1033_8331(Current);
						F2046_21728(RTCV(F1023_8173(Current)));
					} else {
						tr1 = F1231_11523(Current);
						loc8 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2905[Dtype(RTCW(tr1))-1755])(tr1);
						if ((EIF_BOOLEAN)(loc8 == NULL)) {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						} else {
							tb1 = '\01';
							if (!(EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 1L))) {
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc8)+ _LNGOFF_2_0_0_0_);
								tb1 = (EIF_BOOLEAN) (loc3 > ti4_1);
							}
							if (tb1) {
								F1033_8331(Current);
								F2046_21728(RTCV(F1023_8173(Current)));
							} else {
								loc9 = F1634_16566(RTCW(loc8), loc3);
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14537[Dtype(RTCW(loc1))-1944])(loc1);
								loc2 = F1987_19659(RTCW(tr1));
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE)) R9194[dtype-1230])(Current, loc2, (EIF_BOOLEAN) 0, loc9);
								tr1 = F1231_11526(Current);
								loc11 = *(EIF_REFERENCE *)(RTCW(tr1) + O12801[Dtype(tr1)-1610]);
								loc10 = *(EIF_REFERENCE *)(RTCW(loc11) + O15311[Dtype(loc11)-2023]);
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8089[Dtype(RTCW(loc10))-1585])(loc10);
								tb1 = F2027_20648(RTCW(tr1));
								if (tb1) {
									loc7 = F1810_17563(RTCW(loc9));
									F899_7054(RTCW(arg2), loc7);
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9231[dtype-1230])(Current, arg1, loc11, arg2);
									F899_7054(RTCW(arg2), loc11);
								} else {
									tr1 = F1231_11526(Current);
									loc12 = *(EIF_REFERENCE *)(RTCW(tr1) + O12775[Dtype(tr1)-1610]);
									F899_7054(RTCW(arg2), loc12);
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9208[dtype-1230])(Current, arg1, loc12);
								}
							}
						}
					}
				}
			} else {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14501[Dtype(RTCW(loc1))-1944])(loc1);
				if (tb1) {
					loc13 = *(EIF_REFERENCE *)(RTCV(F1231_11523(Current)));
					if ((EIF_BOOLEAN)(loc13 == NULL)) {
						F1033_8331(Current);
						F2046_21728(RTCV(F1023_8173(Current)));
					} else {
						tb1 = '\01';
						if (!(EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 1L))) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_1_0_0_0_);
							tb1 = (EIF_BOOLEAN) (loc3 > ti4_1);
						}
						if (tb1) {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						} else {
							loc14 = F903_7078(RTCW(loc13), loc3);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14539[Dtype(RTCW(loc1))-1944])(loc1);
							loc2 = F1987_19659(RTCW(tr1));
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9207[dtype-1230])(Current, loc2, loc14);
							tr1 = F1231_11526(Current);
							loc11 = *(EIF_REFERENCE *)(RTCW(tr1) + O12801[Dtype(tr1)-1610]);
							loc10 = *(EIF_REFERENCE *)(RTCW(loc11) + O15311[Dtype(loc11)-2023]);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8089[Dtype(RTCW(loc10))-1585])(loc10);
							tb1 = F2027_20648(RTCW(tr1));
							if (tb1) {
								tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
								F1553_14040(RTCW(tr1), loc14);
								tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
								tb1 = F1545_13939(RTCW(tr1));
								if ((EIF_BOOLEAN) !tb1) {
									F1033_8331(Current);
									F2046_21728(RTCV(F1023_8173(Current)));
								} else {
									tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
									tr1 = F1545_13931(RTCW(tr1));
									F2023_20428(RTCW(arg2), tr1);
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9231[dtype-1230])(Current, arg1, loc11, arg2);
									F899_7054(RTCW(arg2), loc11);
								}
							} else {
								tr1 = F1231_11526(Current);
								loc12 = *(EIF_REFERENCE *)(RTCW(tr1) + O12775[Dtype(tr1)-1610]);
								F899_7054(RTCW(arg2), loc12);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9208[dtype-1230])(Current, arg1, loc12);
							}
						}
					}
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14502[Dtype(RTCW(loc1))-1944])(loc1);
					if (tb1) {
						loc16 = *(EIF_REFERENCE *)(RTCV(F1231_11523(Current)) + _REFACS_1_);
						if ((EIF_BOOLEAN)(loc16 == NULL)) {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						} else {
							tb1 = '\01';
							if (!(EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 1L))) {
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc16)+ _LNGOFF_1_0_0_0_);
								tb1 = (EIF_BOOLEAN) (loc3 > ti4_1);
							}
							if (tb1) {
								F1033_8331(Current);
								F2046_21728(RTCV(F1023_8173(Current)));
							} else {
								loc15 = F902_7074(RTCW(loc16), loc3);
								loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14540[Dtype(RTCW(loc1))-1944])(loc1);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9190[dtype-1230])(Current, loc2, loc15);
								tr1 = F1231_11526(Current);
								loc11 = *(EIF_REFERENCE *)(RTCW(tr1) + O12801[Dtype(tr1)-1610]);
								loc10 = *(EIF_REFERENCE *)(RTCW(loc11) + O15311[Dtype(loc11)-2023]);
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8089[Dtype(RTCW(loc10))-1585])(loc10);
								tb1 = F2027_20648(RTCW(tr1));
								if (tb1) {
									tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
									F1553_14040(RTCW(tr1), loc15);
									tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
									tb1 = F1545_13939(RTCW(tr1));
									if ((EIF_BOOLEAN) !tb1) {
										F1033_8331(Current);
										F2046_21728(RTCV(F1023_8173(Current)));
									} else {
										tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
										tr1 = F1545_13931(RTCW(tr1));
										F2023_20428(RTCW(arg2), tr1);
										(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9231[dtype-1230])(Current, arg1, loc11, arg2);
										F899_7054(RTCW(arg2), loc11);
									}
								} else {
									tr1 = F1231_11526(Current);
									loc12 = *(EIF_REFERENCE *)(RTCW(tr1) + O12775[Dtype(tr1)-1610]);
									F899_7054(RTCW(arg2), loc12);
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9208[dtype-1230])(Current, arg1, loc12);
								}
							}
						}
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr1 = F2027_20748(RTCW(tr1), loc3);
						loc21 = tr1;
						if (EIF_TEST(loc21)) {
							F1231_11295(Current, loc1, loc21);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9211[dtype-1230])(Current, arg1, loc21);
							tr1 = F1231_11526(Current);
							loc12 = *(EIF_REFERENCE *)(RTCW(tr1) + O12775[Dtype(tr1)-1610]);
							F899_7054(RTCW(arg2), loc12);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9208[dtype-1230])(Current, arg1, loc12);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr1 = F2027_20747(RTCW(tr1), loc3);
							loc22 = tr1;
							if (EIF_TEST(loc22)) {
								F1231_11295(Current, loc1, loc22);
								tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc22)-1840])(loc22);
								if (tb1) {
									if (*(EIF_BOOLEAN *)(Current + O9280[dtype-1230])) {
										F1033_8331(Current);
										tr1 = F1023_8173(Current);
										F2046_21491(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1, loc22);
									} else {
										(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9167[dtype-1230])(Current, arg1, loc22);
										tr1 = F1231_11526(Current);
										loc11 = *(EIF_REFERENCE *)(RTCW(tr1) + O12801[Dtype(tr1)-1610]);
										loc10 = *(EIF_REFERENCE *)(RTCW(loc11) + O15311[Dtype(loc11)-2023]);
										tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8089[Dtype(RTCW(loc10))-1585])(loc10);
										tb1 = F2027_20648(RTCW(tr1));
										if (tb1) {
											loc7 = F1839_17878(loc22);
											F899_7054(RTCW(arg2), loc7);
											(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9231[dtype-1230])(Current, arg1, loc11, arg2);
											F899_7054(RTCW(arg2), loc11);
										} else {
											tr1 = F1231_11526(Current);
											loc12 = *(EIF_REFERENCE *)(RTCW(tr1) + O12775[Dtype(tr1)-1610]);
											F899_7054(RTCW(arg2), loc12);
											(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9208[dtype-1230])(Current, arg1, loc12);
										}
									}
								} else {
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9179[dtype-1230])(Current, arg1, loc22);
									tr1 = F1231_11526(Current);
									loc12 = *(EIF_REFERENCE *)(RTCW(tr1) + O12775[Dtype(tr1)-1610]);
									F899_7054(RTCW(arg2), loc12);
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9208[dtype-1230])(Current, arg1, loc12);
								}
							} else {
								F1033_8331(Current);
								F2046_21728(RTCV(F1023_8173(Current)));
							}
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_formal_argument_validity */
void F1231_11231 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc6);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,arg2);
	RTLIU(8);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) == NULL) && *(EIF_BOOLEAN *)(Current + O9277[dtype-1230]))) {
		F1033_8331(Current);
		F2046_21728(RTCV(F1023_8173(Current)));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			loc2 = *(EIF_REFERENCE *)(loc6 + _REFACS_5_);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2903[Dtype(RTCW(tr1))-1755])(tr1);
		}
		loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_1_0_2_);
		if ((EIF_BOOLEAN)(loc2 == NULL)) {
			F1033_8331(Current);
			F2046_21728(RTCV(F1023_8173(Current)));
		} else {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_3_0_0_0_);
				tb1 = (EIF_BOOLEAN) (loc1 > ti4_1);
			}
			if (tb1) {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
			} else {
				loc3 = F1649_16721(RTCW(loc2), loc1);
				loc4 = F1814_17596(RTCW(loc3));
				F899_7054(RTCW(arg2), loc4);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
				tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
				if (tb1) {
					tb1 = '\0';
					tb2 = F2022_20355(RTCW(arg2));
					if ((EIF_BOOLEAN) !tb2) {
						tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
						tb2 = F1250_11950(RTCW(tr1), arg1);
						tb1 = tb2;
					}
					if (tb1) {
						tr1 = RTOUCR(75,F396_4598, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F899_7054(RTCW(arg2), tr1);
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE)) R9177[dtype-1230])(Current, arg1, loc5, loc3);
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_hexadecimal_integer_constant_validity */
void F1231_11232 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11236(Current, arg1, arg2);
}

/* {ET_FEATURE_CHECKER}.check_if_expression_validity */
void F1231_11233 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc16 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(15);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,loc3);
	RTLR(6,loc8);
	RTLR(7,loc13);
	RTLR(8,loc11);
	RTLR(9,loc12);
	RTLR(10,loc15);
	RTLR(11,loc14);
	RTLR(12,loc17);
	RTLR(13,loc4);
	RTLR(14,arg2);
	RTLIU(15);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = F1231_11526(Current);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13279[Dtype(RTCW(tr1))-1682])(tr1);
	loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	F1231_11290(Current, loc2, loc3, loc1);
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = F2022_20365(RTCW(loc3), loc1, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
		if ((EIF_BOOLEAN) !tb1) {
			loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F1033_8331(Current);
			loc8 = F2022_20345(RTCW(loc3));
			tr1 = F1023_8173(Current);
			F2046_21520(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc2, loc8);
		}
	}
	F1231_11572(Current, loc3);
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	loc9 = F10_115(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
	F1034_8335(RTCW(tr1), loc2, *(EIF_REFERENCE *)(Current + O9260[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
	tb1 = '\01';
	if (!loc7) {
		tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
		tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
		tb1 = tb2;
	}
	loc7 = (EIF_BOOLEAN) tb1;
	loc13 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
	loc11 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
	loc12 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
		F1250_11971(RTCW(tr1), loc13);
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
		F1250_11971(RTCW(tr1), loc11);
		loc12 = F1231_11539(Current);
		F1250_11971(RTCW(loc12), loc11);
		tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
		F260_2862(RTCW(tr1), loc2, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
		tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
		F260_2863(RTCW(tr1), loc2, loc12);
	}
	loc15 = *(EIF_REFERENCE *)(Current + O9308[dtype-1230]);
	loc16 = *(EIF_INTEGER_32 *)(RTCW(loc15)+ _LNGOFF_4_0_0_1_);
	loc14 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	F1231_11290(Current, tr1, loc14, *(EIF_REFERENCE *)(Current + O9258[dtype-1230]));
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		F1231_11572(Current, loc14);
	} else {
		F1231_11576(Current, loc14, loc15, loc16);
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	F10_119(RTCW(tr1), loc9);
	tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
	F1034_8336(RTCW(tr1), loc2, *(EIF_REFERENCE *)(Current + O9260[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
	tb1 = '\01';
	if (!loc7) {
		tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
		tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
		tb1 = tb2;
	}
	loc7 = (EIF_BOOLEAN) tb1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc17 = tr1;
	if (EIF_TEST(loc17)) {
		loc6 = *(EIF_INTEGER_32 *)(loc17+ _LNGOFF_1_0_0_0_);
		loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc5 > loc6)) break;
			loc4 = F1003_7568(loc17, loc5);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				F1250_11971(RTCW(tr1), loc12);
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4));
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13279[Dtype(RTCW(tr1))-1682])(tr1);
			loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			F1231_11290(Current, loc2, loc3, loc1);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tb1 = F2022_20365(RTCW(loc3), loc1, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
				if ((EIF_BOOLEAN) !tb1) {
					loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					F1033_8331(Current);
					loc8 = F2022_20345(RTCW(loc3));
					tr1 = F1023_8173(Current);
					F2046_21520(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc2, loc8);
				}
			}
			F1231_11572(Current, loc3);
			tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
			loc10 = F10_115(RTCW(tr1));
			tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
			F1034_8335(RTCW(tr1), loc2, *(EIF_REFERENCE *)(Current + O9260[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
			tb1 = '\01';
			if (!loc7) {
				tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
				tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
				tb1 = tb2;
			}
			loc7 = (EIF_BOOLEAN) tb1;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
				F260_2862(RTCW(tr1), loc2, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
				tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
				F260_2863(RTCW(tr1), loc2, loc12);
			}
			loc14 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_2_);
			F1231_11290(Current, tr1, loc14, *(EIF_REFERENCE *)(Current + O9258[dtype-1230]));
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				F1231_11572(Current, loc14);
			} else {
				F1231_11576(Current, loc14, loc15, loc16);
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
			F10_119(RTCW(tr1), loc10);
			tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
			F1034_8336(RTCW(tr1), loc2, *(EIF_REFERENCE *)(Current + O9260[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
			tb1 = '\01';
			if (!loc7) {
				tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
				tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
				tb1 = tb2;
			}
			loc7 = (EIF_BOOLEAN) tb1;
			loc5++;
		}
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
		F1250_11971(RTCW(tr1), loc12);
	}
	loc14 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	F1231_11290(Current, tr1, loc14, *(EIF_REFERENCE *)(Current + O9258[dtype-1230]));
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		F1231_11572(Current, loc14);
	} else {
		F1231_11576(Current, loc14, loc15, loc16);
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	F10_119(RTCW(tr1), loc9);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
		F1231_11540(Current, loc12);
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
		RTAR(Current, loc11);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc11;
		RTAR(Current, loc13);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc13;
	}
	if (loc7) {
		F1033_8331(Current);
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc15)+ _LNGOFF_4_0_0_1_);
		if ((EIF_BOOLEAN)(ti4_1 != (EIF_INTEGER_32) (loc16 + ((EIF_INTEGER_32) 1L)))) {
			loc14 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12740[Dtype(tr1)-1610]);
			F899_7054(RTCW(loc14), tr1);
			F1231_11576(Current, loc14, loc15, loc16);
		}
		tr1 = F1541_13848(RTCW(loc15));
		F2023_20428(RTCW(arg2), tr1);
		tr1 = RTOUCR(571,F396_4600, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9180[dtype-1230])(Current, arg1, tr1, arg2);
	}
	F1231_11577(Current, loc15, loc16);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_infix_cast_expression_validity */
void F1231_11234 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	F1231_11290(Current, tr1, arg2, *(EIF_REFERENCE *)(Current + O9258[dtype-1230]));
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O13392[Dtype(tr1)-1721]);
		F1722_17132(RTCW(arg1), ti4_1);
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		F2023_20389(RTCW(arg2), *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
		F899_7054(RTCW(arg2), loc1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_infix_expression_validity */
void F1231_11235 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	loc2 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[Dtype(Current)-1230]));
	loc1 = F1231_11568(Current, loc2);
	F1231_11258(Current, arg1, arg2, loc1);
	F1231_11569(Current, loc1);
	F1231_11572(Current, loc2);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_integer_constant_validity */
void F1231_11236 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_64 tu8_1;
	EIF_NATURAL_64 tu8_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,loc6);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,loc3);
	RTLR(6,tr1);
	RTLR(7,loc1);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLR(10,tr4);
	RTLR(11,loc4);
	RTLR(12,arg2);
	RTLIU(13);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc5 = RTOUCR(571,F396_4600, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	loc6 = *(EIF_REFERENCE *)(Current + O9258[dtype-1230]);
	loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13357[Dtype(RTCW(loc2))-1725])(loc2);
		F1231_11164(Current, loc3);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13666[Dtype(RTCW(loc3))-1885])(loc3);
			if ((EIF_BOOLEAN) !tb1) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21526(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
			} else {
				loc5 = (EIF_REFERENCE) loc3;
				loc6 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
			}
		}
	}
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
	} else {
		tr1 = F1231_11526(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12762[Dtype(tr1)-1610]);
		tb1 = F1884_18234(RTCW(tr1), loc5, loc6, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
		if (tb1) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14471[Dtype(RTCW(arg1))-1938])(arg1);
			if (tb1) {
				tr1 = F1231_11526(Current);
				loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12762[Dtype(tr1)-1610]);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9186[dtype-1230])(Current, arg1, loc1);
			} else {
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
					tr4 = F1231_11526(Current);
					tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12762[Dtype(tr4)-1610]);
					F2046_21570(RTCW(tr1), tr2, tr3, arg1, tr4);
				}
			}
		} else {
			tr1 = F1231_11526(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12763[Dtype(tr1)-1610]);
			tb1 = F1884_18234(RTCW(tr1), loc5, loc6, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
			if (tb1) {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14472[Dtype(RTCW(arg1))-1938])(arg1);
				if (tb1) {
					tr1 = F1231_11526(Current);
					loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12763[Dtype(tr1)-1610]);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9187[dtype-1230])(Current, arg1, loc1);
				} else {
					if ((EIF_BOOLEAN)(loc3 != NULL)) {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
						tr4 = F1231_11526(Current);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12763[Dtype(tr4)-1610]);
						F2046_21570(RTCW(tr1), tr2, tr3, arg1, tr4);
					}
				}
			} else {
				tr1 = F1231_11526(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12764[Dtype(tr1)-1610]);
				tb1 = F1884_18234(RTCW(tr1), loc5, loc6, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
				if (tb1) {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14473[Dtype(RTCW(arg1))-1938])(arg1);
					if (tb1) {
						tr1 = F1231_11526(Current);
						loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12764[Dtype(tr1)-1610]);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9188[dtype-1230])(Current, arg1, loc1);
					} else {
						if ((EIF_BOOLEAN)(loc3 != NULL)) {
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
							tr4 = F1231_11526(Current);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12764[Dtype(tr4)-1610]);
							F2046_21570(RTCW(tr1), tr2, tr3, arg1, tr4);
						}
					}
				} else {
					tr1 = F1231_11526(Current);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12765[Dtype(tr1)-1610]);
					tb1 = F1884_18234(RTCW(tr1), loc5, loc6, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
					if (tb1) {
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14474[Dtype(RTCW(arg1))-1938])(arg1);
						if (tb1) {
							tr1 = F1231_11526(Current);
							loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12765[Dtype(tr1)-1610]);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9189[dtype-1230])(Current, arg1, loc1);
						} else {
							if ((EIF_BOOLEAN)(loc3 != NULL)) {
								F1033_8331(Current);
								tr1 = F1023_8173(Current);
								tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
								tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
								tr4 = F1231_11526(Current);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12765[Dtype(tr4)-1610]);
								F2046_21570(RTCW(tr1), tr2, tr3, arg1, tr4);
							}
						}
					} else {
						tr1 = F1231_11526(Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12769[Dtype(tr1)-1610]);
						tb1 = F1884_18234(RTCW(tr1), loc5, loc6, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
						if (tb1) {
							tb1 = F1938_19172(RTCW(arg1));
							if (tb1) {
								tr1 = F1231_11526(Current);
								loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12769[Dtype(tr1)-1610]);
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9200[dtype-1230])(Current, arg1, loc1);
							} else {
								if ((EIF_BOOLEAN)(loc3 != NULL)) {
									F1033_8331(Current);
									tr1 = F1023_8173(Current);
									tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
									tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
									tr4 = F1231_11526(Current);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12769[Dtype(tr4)-1610]);
									F2046_21570(RTCW(tr1), tr2, tr3, arg1, tr4);
								}
							}
						} else {
							tr1 = F1231_11526(Current);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12770[Dtype(tr1)-1610]);
							tb1 = F1884_18234(RTCW(tr1), loc5, loc6, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
							if (tb1) {
								tb1 = F1938_19173(RTCW(arg1));
								if (tb1) {
									tr1 = F1231_11526(Current);
									loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12770[Dtype(tr1)-1610]);
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9201[dtype-1230])(Current, arg1, loc1);
								} else {
									if ((EIF_BOOLEAN)(loc3 != NULL)) {
										F1033_8331(Current);
										tr1 = F1023_8173(Current);
										tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
										tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
										tr4 = F1231_11526(Current);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12770[Dtype(tr4)-1610]);
										F2046_21570(RTCW(tr1), tr2, tr3, arg1, tr4);
									}
								}
							} else {
								tr1 = F1231_11526(Current);
								tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12771[Dtype(tr1)-1610]);
								tb1 = F1884_18234(RTCW(tr1), loc5, loc6, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
								if (tb1) {
									tb1 = F1938_19174(RTCW(arg1));
									if (tb1) {
										tr1 = F1231_11526(Current);
										loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12771[Dtype(tr1)-1610]);
										(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9202[dtype-1230])(Current, arg1, loc1);
									} else {
										if ((EIF_BOOLEAN)(loc3 != NULL)) {
											F1033_8331(Current);
											tr1 = F1023_8173(Current);
											tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
											tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
											tr4 = F1231_11526(Current);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12771[Dtype(tr4)-1610]);
											F2046_21570(RTCW(tr1), tr2, tr3, arg1, tr4);
										}
									}
								} else {
									tr1 = F1231_11526(Current);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12772[Dtype(tr1)-1610]);
									tb1 = F1884_18234(RTCW(tr1), loc5, loc6, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
									if (tb1) {
										tb1 = F1938_19175(RTCW(arg1));
										if (tb1) {
											tr1 = F1231_11526(Current);
											loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12772[Dtype(tr1)-1610]);
											(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9203[dtype-1230])(Current, arg1, loc1);
										} else {
											if ((EIF_BOOLEAN)(loc3 != NULL)) {
												F1033_8331(Current);
												tr1 = F1023_8173(Current);
												tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
												tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
												tr4 = F1231_11526(Current);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12772[Dtype(tr4)-1610]);
												F2046_21570(RTCW(tr1), tr2, tr3, arg1, tr4);
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
	} else {
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
		} else {
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21526(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
			} else {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14473[Dtype(RTCW(arg1))-1938])(arg1);
				if (tb1) {
					tb1 = '\0';
					tb2 = '\01';
					tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14468[Dtype(RTCW(arg1))-1938])(arg1);
					if (!tb3) {
						tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14469[Dtype(RTCW(arg1))-1938])(arg1);
						tb2 = tb3;
					}
					if (tb2) {
						tb2 = '\0';
						tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
						if ((EIF_BOOLEAN)(tr1 == NULL)) {
							tu8_1 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_5_1_0_2_0_0_0_);
							tu8_2 = (EIF_NATURAL_64) ((EIF_INTEGER_32) 2147483647L);
							tb2 = (EIF_BOOLEAN) (tu8_1 > tu8_2);
						}
						tb1 = tb2;
					}
					if (tb1) {
						tr1 = F1231_11526(Current);
						loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12765[Dtype(tr1)-1610]);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9189[dtype-1230])(Current, arg1, loc1);
					} else {
						tr1 = F1231_11526(Current);
						loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12764[Dtype(tr1)-1610]);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9188[dtype-1230])(Current, arg1, loc1);
					}
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14474[Dtype(RTCW(arg1))-1938])(arg1);
					if (tb1) {
						tb1 = '\0';
						tb2 = '\01';
						tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14468[Dtype(RTCW(arg1))-1938])(arg1);
						if (!tb3) {
							tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14469[Dtype(RTCW(arg1))-1938])(arg1);
							tb2 = tb3;
						}
						if (tb2) {
							tb2 = '\0';
							tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
							if ((EIF_BOOLEAN)(tr1 == NULL)) {
								tu8_1 = *(EIF_NATURAL_64 *)(RTCW(arg1)+ _I64OFF_5_1_0_2_0_0_0_);
								tu8_2 = (EIF_NATURAL_64) ((EIF_INTEGER_64) RTI64C(9223372036854775807));
								tb2 = (EIF_BOOLEAN) (tu8_1 > tu8_2);
							}
							tb1 = tb2;
						}
						if (tb1) {
							tr1 = F1231_11526(Current);
							loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12772[Dtype(tr1)-1610]);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9203[dtype-1230])(Current, arg1, loc1);
						} else {
							tr1 = F1231_11526(Current);
							loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12765[Dtype(tr1)-1610]);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9189[dtype-1230])(Current, arg1, loc1);
						}
					} else {
						tb1 = F1938_19175(RTCW(arg1));
						if (tb1) {
							tr1 = F1231_11526(Current);
							loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12772[Dtype(tr1)-1610]);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9203[dtype-1230])(Current, arg1, loc1);
						} else {
							F1033_8331(Current);
							loc4 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
							tb1 = '\0';
							if ((EIF_BOOLEAN)(loc4 != NULL)) {
								tb2 = F1917_18869(RTCW(loc4));
								tb1 = tb2;
							}
							if (tb1) {
								tr1 = F1023_8173(Current);
								tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
								tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
								tr4 = F1231_11526(Current);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12765[Dtype(tr4)-1610]);
								F2046_21570(RTCW(tr1), tr2, tr3, arg1, tr4);
							} else {
								tr1 = F1023_8173(Current);
								tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
								tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
								tr4 = F1231_11526(Current);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12772[Dtype(tr4)-1610]);
								F2046_21570(RTCW(tr1), tr2, tr3, arg1, tr4);
							}
						}
					}
				}
			}
		}
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1938_19180(RTCW(arg1), loc1);
		F899_7054(RTCW(arg2), loc1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_iteration_component_header_validity */
void F1231_11237 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc24 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(24);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,loc12);
	RTLR(3,arg1);
	RTLR(4,loc11);
	RTLR(5,tr1);
	RTLR(6,loc13);
	RTLR(7,loc6);
	RTLR(8,loc15);
	RTLR(9,loc16);
	RTLR(10,loc10);
	RTLR(11,loc17);
	RTLR(12,tr2);
	RTLR(13,tr3);
	RTLR(14,loc18);
	RTLR(15,loc19);
	RTLR(16,loc20);
	RTLR(17,loc21);
	RTLR(18,loc22);
	RTLR(19,loc23);
	RTLR(20,loc24);
	RTLR(21,loc14);
	RTLR(22,loc4);
	RTLR(23,loc5);
	RTLIU(24);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	loc12 = *(EIF_REFERENCE *)(RTCW(arg1));
	tr1 = F1231_11526(Current);
	loc11 = *(EIF_REFERENCE *)(RTCW(tr1) + O12767[Dtype(tr1)-1610]);
	F1231_11290(Current, loc12, loc3, loc11);
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = F2022_20377(RTCW(loc3), loc11, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
		if ((EIF_BOOLEAN) !tb1) {
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F1033_8331(Current);
			loc13 = F2022_20345(RTCW(loc3));
			tr1 = F1023_8173(Current);
			F2046_21419(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc12, loc13);
		}
	}
	F1231_11572(Current, loc3);
	loc6 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
		tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tr1 = F140_1508(RTCW(tr1), loc6);
		loc15 = tr1;
		if (EIF_TEST(loc15)) {
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21420(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1, loc15);
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
		loc16 = tr1;
		if (EIF_TEST(loc16)) {
			tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
			F1541_13864(RTCW(tr1), loc16);
			tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
			loc9 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
			loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc7 > loc9)) break;
				tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
				loc10 = F1541_13846(RTCW(tr1), loc7);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc10) + _REFACS_5_);
				loc17 = tr1;
				if (EIF_TEST(loc17)) {
					loc8 = F1649_16724(loc17, loc6);
					if ((EIF_BOOLEAN)(loc8 != ((EIF_INTEGER_32) 0L))) {
						loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = F1649_16721(loc17, loc8);
						F2046_21421(RTCW(tr1), tr2, arg1, tr3);
					}
				}
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2905[Dtype(RTCW(loc10))-1755])(loc10);
				loc18 = tr1;
				if (EIF_TEST(loc18)) {
					loc8 = F1634_16568(loc18, loc6);
					if ((EIF_BOOLEAN)(loc8 != ((EIF_INTEGER_32) 0L))) {
						loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = F1634_16566(loc18, loc8);
						F2046_21422(RTCW(tr1), tr2, arg1, tr3);
					}
				}
				loc7++;
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
			F1541_13879(RTCW(tr1));
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2903[Dtype(RTCW(tr1))-1755])(tr1);
		loc19 = tr1;
		if (EIF_TEST(loc19)) {
			loc8 = F1649_16724(loc19, loc6);
			if ((EIF_BOOLEAN)(loc8 != ((EIF_INTEGER_32) 0L))) {
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
				tr3 = F1649_16721(loc19, loc8);
				F2046_21421(RTCW(tr1), tr2, arg1, tr3);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2905[Dtype(RTCW(tr1))-1755])(tr1);
		loc20 = tr1;
		if (EIF_TEST(loc20)) {
			loc8 = F1634_16568(loc20, loc6);
			if ((EIF_BOOLEAN)(loc8 != ((EIF_INTEGER_32) 0L))) {
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
				tr3 = F1634_16566(loc20, loc8);
				F2046_21422(RTCW(tr1), tr2, arg1, tr3);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
		tr1 = F10_112(RTCW(tr1), loc6);
		loc21 = tr1;
		if (EIF_TEST(loc21)) {
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21423(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1, loc21);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
			tr1 = F10_113(RTCW(tr1), loc6);
			loc22 = tr1;
			if (EIF_TEST(loc22)) {
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21423(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1, loc22);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
		tr1 = F11_125(RTCW(tr1), loc6);
		loc23 = tr1;
		if (EIF_TEST(loc23)) {
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21424(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1, loc23);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
			tr1 = F11_126(RTCW(tr1), loc6);
			loc24 = tr1;
			if (EIF_TEST(loc24)) {
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21424(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1, loc24);
			}
		}
	}
	if ((EIF_BOOLEAN) !loc2) {
		loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		tr1 = F1785_17456(RTCW(tr1));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O12993[Dtype(tr2)-1616]);
		F1944_19225(RTCW(tr1), ti4_1);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12741[Dtype(tr2)-1610]);
		F1231_11290(Current, tr1, loc3, tr2);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F1231_11572(Current, loc3);
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9191[dtype-1230])(Current, tr1, arg1);
			tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
			F1553_14051(RTCW(tr1), loc3, arg1);
			tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
			F11_130(RTCW(tr1), arg1);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
			tr1 = F1785_17456(RTCW(tr1));
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O12995[Dtype(tr2)-1616]);
			F1944_19225(RTCW(tr1), ti4_1);
			tr1 = F1231_11526(Current);
			loc14 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
			loc4 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
			F1231_11290(Current, tr1, loc4, loc14);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tb1 = F2022_20365(RTCW(loc4), loc14, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
				if ((EIF_BOOLEAN) !tb1) {
					loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					F1033_8331(Current);
					loc13 = F2022_20345(RTCW(loc4));
					tr1 = F1023_8173(Current);
					tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
					F2046_21520(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), tr2, loc13);
				}
			}
			F1231_11572(Current, loc4);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
			tr1 = F1785_17456(RTCW(tr1));
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O12996[Dtype(tr2)-1616]);
			F1944_19225(RTCW(tr1), ti4_1);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
			F1231_11193(Current, tr1);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13813[Dtype(RTCW(arg1))-1870])(arg1);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
				tr1 = F1785_17456(RTCW(tr1));
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O12994[Dtype(tr2)-1616]);
				F1944_19225(RTCW(tr1), ti4_1);
				loc5 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
				tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12741[Dtype(tr2)-1610]);
				F1231_11290(Current, tr1, loc5, tr2);
				if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
					loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
				F1553_14051(RTCW(tr1), loc5, arg1);
				F1231_11572(Current, loc3);
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9191[dtype-1230])(Current, loc6, arg1);
			tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
			F11_131(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		}
	}
	if (loc1) {
		F1033_8331(Current);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_iteration_cursor_validity */
void F1231_11238 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,arg2);
	RTLR(7,loc3);
	RTLIU(8);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_1_0_2_);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
			F1033_8331(Current);
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
			loc2 = F11_125(RTCW(tr1), arg1);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				F1033_8331(Current);
				tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
				if (tb1) {
					tr1 = F1023_8173(Current);
					tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
					tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
					F2046_21311(RTCW(tr1), tr2, arg1, tr3);
				} else {
					tr1 = F1023_8173(Current);
					F2046_21312(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
				}
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_1_);
				loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_1_0_2_);
				F1944_19225(RTCW(arg1), loc1);
				tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
				F1553_14040(RTCW(tr1), loc2);
				tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
				tb1 = F1545_13939(RTCW(tr1));
				if ((EIF_BOOLEAN) !tb1) {
					F1033_8331(Current);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
					tr1 = F1545_13931(RTCW(tr1));
					F2023_20428(RTCW(arg2), tr1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9190[dtype-1230])(Current, arg1, loc2);
				}
			}
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCV(F1231_11523(Current)) + _REFACS_1_);
		loc3 = tr1;
		if ((EIF_BOOLEAN) !EIF_TEST(loc3)) {
			F1033_8331(Current);
			F2046_21728(RTCV(F1023_8173(Current)));
		} else {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) {
				ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_1_0_0_0_);
				tb1 = (EIF_BOOLEAN) (loc1 > ti4_1);
			}
			if (tb1) {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
			} else {
				loc2 = F902_7074(loc3, loc1);
				tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
				F1553_14040(RTCW(tr1), loc2);
				tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
				tb1 = F1545_13939(RTCW(tr1));
				if ((EIF_BOOLEAN) !tb1) {
					F1033_8331(Current);
					F2046_21728(RTCV(F1023_8173(Current)));
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
					tr1 = F1545_13931(RTCW(tr1));
					F2023_20428(RTCW(arg2), tr1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9190[dtype-1230])(Current, arg1, loc2);
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_iteration_expression_validity */
void F1231_11239 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc9);
	RTLR(4,loc8);
	RTLR(5,loc10);
	RTLR(6,loc11);
	RTLR(7,loc6);
	RTLR(8,loc12);
	RTLR(9,loc1);
	RTLR(10,loc3);
	RTLR(11,loc5);
	RTLR(12,loc2);
	RTLR(13,arg2);
	RTLIU(14);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F1231_11237(Current, arg1);
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	F11_130(RTCW(tr1), arg1);
	loc9 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
	loc8 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
		F1250_11971(RTCW(tr1), loc9);
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
		F1250_11971(RTCW(tr1), loc8);
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13816[Dtype(RTCW(arg1))-1870])(arg1);
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9012[dtype-1230])(Current, loc10);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
			F1250_11971(RTCW(tr1), loc9);
			tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
			F1250_11971(RTCW(tr1), loc8);
		}
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13817[Dtype(RTCW(arg1))-1870])(arg1);
	loc11 = tr1;
	if (EIF_TEST(loc11)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9013[dtype-1230])(Current, loc11);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
			F1250_11971(RTCW(tr1), loc9);
			tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
			F1250_11971(RTCW(tr1), loc8);
		}
	}
	tr1 = F1231_11526(Current);
	loc6 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13818[Dtype(RTCW(arg1))-1870])(arg1);
	loc12 = tr1;
	if (EIF_TEST(loc12)) {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13279[Dtype(loc12)-1682])(loc12);
		loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
		F1231_11290(Current, loc1, loc3, loc6);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			tb1 = F2022_20365(RTCW(loc3), loc6, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
			if ((EIF_BOOLEAN) !tb1) {
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				F1033_8331(Current);
				loc5 = F2022_20345(RTCW(loc3));
				tr1 = F1023_8173(Current);
				F2046_21520(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1, loc5);
			}
		}
		F1231_11572(Current, loc3);
	}
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13840[Dtype(RTCW(arg1))-1870])(arg1);
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	loc7 = F10_115(RTCW(tr1));
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
			F260_2863(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
		F1034_8336(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9260[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
		tb1 = '\01';
		if (!loc4) {
			tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
			tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
			tb1 = tb2;
		}
		loc4 = (EIF_BOOLEAN) tb1;
	}
	loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	F1231_11290(Current, loc2, loc3, loc6);
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = F2022_20365(RTCW(loc3), loc6, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
		if ((EIF_BOOLEAN) !tb1) {
			loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			F1033_8331(Current);
			loc5 = F2022_20345(RTCW(loc3));
			tr1 = F1023_8173(Current);
			F2046_21520(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc2, loc5);
		}
	}
	F1231_11572(Current, loc3);
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	F10_119(RTCW(tr1), loc7);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	F11_131(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
	F1553_14040(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
	tb1 = F1545_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
		tr1 = F1545_13931(RTCW(tr1));
		F1231_11572(Current, tr1);
		tr1 = *(EIF_REFERENCE *)(Current + O9262[dtype-1230]);
		F1545_13952(RTCW(tr1));
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
		RTAR(Current, loc8);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc8;
		RTAR(Current, loc9);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc9;
	}
	if (loc4) {
		F1033_8331(Current);
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F899_7054(RTCW(arg2), loc6);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9192[dtype-1230])(Current, arg1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_local_variable_validity */
void F1231_11240 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,loc6);
	RTLR(7,loc2);
	RTLR(8,loc3);
	RTLR(9,arg2);
	RTLIU(10);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) == NULL) && (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O9275[dtype-1230]) || *(EIF_BOOLEAN *)(Current + O9276[dtype-1230])))) {
		F1033_8331(Current);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) == *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
			tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
			loc5 = tr1;
			if (EIF_TEST(loc5)) {
				tr1 = F1023_8173(Current);
				F2046_21306(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1, loc5);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
				if (tb1) {
					tr1 = F1023_8173(Current);
					tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
					tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
					F2046_21304(RTCW(tr1), tr2, arg1, tr3);
				} else {
					F2046_21728(RTCV(F1023_8173(Current)));
				}
			}
		} else {
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		}
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) == NULL) && *(EIF_BOOLEAN *)(Current + O9277[dtype-1230]))) {
			F1033_8331(Current);
			F2046_21728(RTCV(F1023_8173(Current)));
		} else {
			loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_1_0_2_);
			tr1 = F1231_11523(Current);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2905[Dtype(RTCW(tr1))-1755])(tr1);
			loc6 = tr1;
			if ((EIF_BOOLEAN) !EIF_TEST(loc6)) {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
			} else {
				tb1 = '\01';
				if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) {
					ti4_1 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_2_0_0_0_);
					tb1 = (EIF_BOOLEAN) (loc1 > ti4_1);
				}
				if (tb1) {
					F1033_8331(Current);
					F2046_21728(RTCV(F1023_8173(Current)));
				} else {
					loc2 = F1634_16566(loc6, loc1);
					loc3 = F1810_17563(RTCW(loc2));
					F899_7054(RTCW(arg2), loc3);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
					tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
					if (tb1) {
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						tb1 = F2022_20355(RTCW(arg2));
						if ((EIF_BOOLEAN) !tb1) {
							tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
							tb1 = F1250_11949(RTCW(tr1), arg1);
							if (tb1) {
								tr1 = RTOUCR(75,F396_4598, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
								F899_7054(RTCW(arg2), tr1);
							} else {
								loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							}
						} else {
							tb1 = '\0';
							tb2 = F2022_20357(RTCW(arg2));
							if ((EIF_BOOLEAN) !tb2) {
								tb2 = F2022_20351(RTCW(arg2));
								tb1 = (EIF_BOOLEAN) !tb2;
							}
							if (tb1) {
								tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
								tb1 = F1290_12726(RTCW(tr1));
								if (tb1) {
									tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
									tb1 = F1250_11949(RTCW(tr1), arg1);
									if ((EIF_BOOLEAN) !tb1) {
										tr1 = RTOUCR(604,F396_4599, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
										F899_7054(RTCW(arg2), tr1);
										loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									}
								} else {
									tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
									tb1 = F1250_11949(RTCW(tr1), arg1);
									if ((EIF_BOOLEAN) !tb1) {
										F1033_8331(Current);
										tr1 = F1023_8173(Current);
										F2046_21313(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1, loc2);
									}
								}
							}
						}
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE)) R9194[dtype-1230])(Current, arg1, loc4, loc2);
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_manifest_array_validity */
void F1231_11241 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1231_11242(Current, arg1, loc1, arg2);
	} else {
		F1231_11243(Current, arg1, arg2);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_typed_manifest_array_validity */
void F1231_11242 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(19);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg2);
	RTLR(3,loc11);
	RTLR(4,arg3);
	RTLR(5,tr1);
	RTLR(6,arg1);
	RTLR(7,loc12);
	RTLR(8,loc2);
	RTLR(9,loc6);
	RTLR(10,loc5);
	RTLR(11,loc7);
	RTLR(12,loc8);
	RTLR(13,loc9);
	RTLR(14,loc13);
	RTLR(15,tr2);
	RTLR(16,tr3);
	RTLR(17,tr4);
	RTLR(18,tr5);
	RTLIU(19);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13357[Dtype(RTCW(arg2))-1725])(arg2);
	F1231_11164(Current, loc1);
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
	} else {
		tb1 = '\01';
		tr1 = F1884_18201(RTCW(loc1), arg3);
		loc11 = tr1;
		loc11 = RTRV(eif_new_type(2025, 0x01),loc11);
		if (!((EIF_BOOLEAN) !EIF_TEST(loc11))) {
			tr1 = F2024_20433(loc11);
			tb2 = F2027_20579(RTCW(tr1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21524(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
		} else {
			tb1 = '\01';
			tr1 = *(EIF_REFERENCE *)(loc11 + O15328[Dtype(loc11)-2025]);
			loc12 = tr1;
			if (!((EIF_BOOLEAN) !EIF_TEST(loc12))) {
				ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14070[Dtype(loc12)-1897])(loc12);
				tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 1L));
			}
			if (tb1) {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
			} else {
				loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R14072[Dtype(loc12)-1897])(loc12, ((EIF_INTEGER_32) 1L));
				loc6 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
				F899_7054(RTCW(loc6), loc2);
				loc5 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
				loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_0_);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc3 > loc4)) break;
					loc7 = F1003_7568(RTCW(arg1), loc3);
					loc8 = F1731_17161(RTCW(loc7));
					F1231_11290(Current, loc8, loc5, loc6);
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tb1 = F2022_20377(RTCW(loc5), loc2, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]), *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
						if ((EIF_BOOLEAN) !tb1) {
							if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
								loc9 = F1231_11340(Current, loc8, loc5, loc6);
								if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
									loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									if ((EIF_BOOLEAN)(loc9 != NULL)) {
										loc13 = loc7;
										loc13 = RTRV(eif_new_type(1684, 0x01),loc13);
										if (EIF_TEST(loc13)) {
											(RTNA((loc13, loc9)));
										} else {
											F1003_7578(RTCW(arg1), loc9, loc3);
										}
									} else {
										loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
										tr1 = F1023_8173(Current);
										tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
										tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
										tr4 = F2022_20345(RTCW(loc5));
										tr5 = F2022_20345(RTCW(loc6));
										F2046_21525(RTCW(tr1), tr2, tr3, loc8, loc3, tr4, tr5);
									}
								}
							}
						}
					}
					F899_7060(RTCW(loc5));
					loc3++;
				}
				F1231_11572(Current, loc5);
				F1231_11572(Current, loc6);
				if (loc10) {
					F1033_8331(Current);
				} else {
					F899_7054(RTCW(arg3), loc1);
					tr1 = RTOUCR(75,F396_4598, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9196[dtype-1230])(Current, arg1, tr1, arg3);
					tr1 = RTOUCR(75,F396_4598, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					F899_7054(RTCW(arg3), tr1);
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_untyped_manifest_array_validity */
void F1231_11243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc12 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc14 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc15 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCDT;
	RTLD;
	
	RTLI(19);
	RTLR(0,Current);
	RTLR(1,loc10);
	RTLR(2,tr1);
	RTLR(3,loc16);
	RTLR(4,loc17);
	RTLR(5,loc11);
	RTLR(6,arg1);
	RTLR(7,arg2);
	RTLR(8,tr2);
	RTLR(9,tr3);
	RTLR(10,loc9);
	RTLR(11,loc7);
	RTLR(12,loc4);
	RTLR(13,loc5);
	RTLR(14,loc3);
	RTLR(15,loc13);
	RTLR(16,loc18);
	RTLR(17,loc19);
	RTLR(18,loc20);
	RTLIU(19);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc12 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	loc10 = *(EIF_REFERENCE *)(RTCW(tr1) + O12741[Dtype(tr1)-1610]);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + O9258[dtype-1230]);
	tr1 = F2022_20345(RTCW(tr1));
	loc16 = tr1;
	loc16 = RTRV(eif_new_type(2025, 0x01),loc16);
	if (EIF_TEST(loc16)) {
		tr1 = F2024_20433(loc16);
		tb2 = F2027_20579(RTCW(tr1));
		tb1 = tb2;
	}
	if (tb1) {
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(loc16 + O15328[Dtype(loc16)-2025]);
		loc17 = tr1;
		if (EIF_TEST(loc17)) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14070[Dtype(loc17)-1897])(loc17);
			tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L));
		}
		if (tb1) {
			loc11 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R14072[Dtype(loc17)-1897])(loc17, ((EIF_INTEGER_32) 1L));
			F899_7054(RTCW(loc11), tr1);
			loc10 = (EIF_REFERENCE) loc11;
		}
	}
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_0_);
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
		tb1 = '\0';
		if ((EIF_BOOLEAN) (loc12 && (EIF_BOOLEAN)(loc11 != NULL))) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12773[Dtype(tr1)-1610]);
			tb2 = F2022_20379(RTCW(tr1), loc11, *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			F2023_20428(RTCW(arg2), loc11);
		} else {
			tb1 = '\0';
			tb2 = '\0';
			if ((EIF_BOOLEAN) (loc12 && (EIF_BOOLEAN)(loc11 == NULL))) {
				tb3 = '\01';
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12748[Dtype(tr1)-1610]);
				tb4 = F2022_20379(RTCW(tr1), *(EIF_REFERENCE *)(Current + O9258[dtype-1230]), *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
				if (!tb4) {
					tb4 = '\0';
					if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
						tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12748[Dtype(tr2)-1610]);
						tr3 = *(EIF_REFERENCE *)(Current + O9258[dtype-1230]);
						tr1 = F1035_8345(RTCW(tr1), tr2, tr3);
						tb4 = (EIF_BOOLEAN)(tr1 != NULL);
					}
					tb3 = tb4;
				}
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				tb2 = '\01';
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12746[Dtype(tr1)-1610]);
				tb3 = F2022_20379(RTCW(tr1), *(EIF_REFERENCE *)(Current + O9258[dtype-1230]), *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
				if (!tb3) {
					tb3 = '\0';
					if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
						tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12746[Dtype(tr2)-1610]);
						tr3 = *(EIF_REFERENCE *)(Current + O9258[dtype-1230]);
						tr1 = F1035_8345(RTCW(tr1), tr2, tr3);
						tb3 = (EIF_BOOLEAN)(tr1 != NULL);
					}
					tb2 = tb3;
				}
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12740[Dtype(tr1)-1610]);
				F899_7054(RTCW(arg2), tr1);
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12773[Dtype(tr1)-1610]);
				F899_7054(RTCW(arg2), tr1);
			}
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		loc9 = *(EIF_REFERENCE *)(RTCW(tr1) + O12749[Dtype(tr1)-1610]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9196[dtype-1230])(Current, arg1, loc9, arg2);
		F899_7054(RTCW(arg2), loc9);
	} else {
		loc7 = *(EIF_REFERENCE *)(Current + O9308[dtype-1230]);
		loc8 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_4_0_0_1_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc4 = F1003_7568(RTCW(arg1), loc1);
			loc5 = F1731_17161(RTCW(loc4));
			loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			F1231_11290(Current, loc5, loc3, loc10);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				F1231_11572(Current, loc3);
			} else {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc12 && (EIF_BOOLEAN)(loc11 != NULL)) && (EIF_BOOLEAN) !loc15)) {
					tb1 = F2022_20379(RTCW(loc3), loc11, *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
					if ((EIF_BOOLEAN) !tb1) {
						if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
							loc13 = F1231_11340(Current, loc5, loc3, loc11);
							if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
								loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								if ((EIF_BOOLEAN)(loc13 != NULL)) {
									loc18 = loc4;
									loc18 = RTRV(eif_new_type(1684, 0x01),loc18);
									if (EIF_TEST(loc18)) {
										(RTNA((loc18, loc13)));
									} else {
										F1003_7578(RTCW(arg1), loc13, loc1);
									}
									loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								}
							}
						} else {
							loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						}
					}
				}
				F1231_11576(Current, loc3, loc7, loc8);
			}
			loc1++;
		}
		if ((EIF_BOOLEAN) (loc15 && loc14)) {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				loc4 = F1003_7568(RTCW(arg1), loc1);
				loc5 = F1731_17161(RTCW(loc4));
				loc19 = loc5;
				loc19 = RTRV(eif_new_type(1768, 0x01),loc19);
				if (EIF_TEST(loc19)) {
					loc5 = *(EIF_REFERENCE *)(loc19);
					loc20 = loc4;
					loc20 = RTRV(eif_new_type(1684, 0x01),loc20);
					if (EIF_TEST(loc20)) {
						(RTNA((loc20, loc5)));
					} else {
						F1003_7578(RTCW(arg1), loc5, loc1);
					}
				}
				loc1++;
			}
		}
		if (loc6) {
			F1033_8331(Current);
		} else {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc12 && (EIF_BOOLEAN)(loc11 != NULL)) && (EIF_BOOLEAN) !loc15)) {
				tb1 = '\0';
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_4_0_0_1_);
				if ((EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)))) {
					tr1 = F1541_13848(RTCW(loc7));
					tb2 = F2022_20379(RTCW(tr1), loc11, *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
					tb1 = tb2;
				}
				if (tb1) {
					tr1 = F1541_13848(RTCW(loc7));
					F2023_20428(RTCW(arg2), tr1);
				} else {
					F2023_20428(RTCW(arg2), loc11);
				}
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_4_0_0_1_);
				if ((EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L)))) {
					tr1 = F1541_13848(RTCW(loc7));
					F2023_20428(RTCW(arg2), tr1);
				} else {
					loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12740[Dtype(tr1)-1610]);
					F899_7054(RTCW(loc3), tr1);
					F1231_11576(Current, loc3, loc7, loc8);
					tr1 = F1541_13848(RTCW(loc7));
					F2023_20428(RTCW(arg2), tr1);
				}
			}
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			loc9 = *(EIF_REFERENCE *)(RTCW(tr1) + O12749[Dtype(tr1)-1610]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9196[dtype-1230])(Current, arg1, loc9, arg2);
			F899_7054(RTCW(arg2), loc9);
		}
		F1231_11577(Current, loc7, loc8);
	}
	if ((EIF_BOOLEAN)(loc11 != NULL)) {
		F1231_11572(Current, loc11);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_manifest_string_validity */
void F1231_11244 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,loc4);
	RTLR(3,loc5);
	RTLR(4,arg1);
	RTLR(5,tr1);
	RTLR(6,loc2);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,tr4);
	RTLR(10,loc1);
	RTLR(11,arg2);
	RTLIU(12);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc3 = RTOUCR(571,F396_4600, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	loc4 = *(EIF_REFERENCE *)(Current + O9258[dtype-1230]);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13357[Dtype(loc5)-1725])(loc5);
		F1231_11164(Current, loc2);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13666[Dtype(RTCW(loc2))-1885])(loc2);
			if ((EIF_BOOLEAN) !tb1) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21529(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
			} else {
				loc3 = (EIF_REFERENCE) loc2;
				loc4 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
			}
		}
	}
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
	} else {
		tr1 = F1231_11526(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12787[Dtype(tr1)-1610]);
		tr2 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr3 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr4 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
		tb1 = F2026_20549(RTCW(tr1), loc3, tr2, loc4, tr3, tr4);
		if (tb1) {
			tb1 = F1930_19066(RTCW(arg1));
			if (tb1) {
				tr1 = F1231_11526(Current);
				loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12787[Dtype(tr1)-1610]);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9225[dtype-1230])(Current, arg1, loc1);
			} else {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
				tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
				tr4 = F1231_11526(Current);
				tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12787[Dtype(tr4)-1610]);
				F2046_21572(RTCW(tr1), tr2, tr3, arg1, tr4);
			}
		} else {
			tr1 = F1231_11526(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12759[Dtype(tr1)-1610]);
			tr2 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tr3 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tr4 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
			tb1 = F2026_20549(RTCW(tr1), loc3, tr2, loc4, tr3, tr4);
			if (tb1) {
				tb1 = F1930_19066(RTCW(arg1));
				if (tb1) {
					tr1 = F1231_11526(Current);
					loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12759[Dtype(tr1)-1610]);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9181[dtype-1230])(Current, arg1, loc1);
				} else {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
					tr4 = F1231_11526(Current);
					tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12759[Dtype(tr4)-1610]);
					F2046_21572(RTCW(tr1), tr2, tr3, arg1, tr4);
				}
			} else {
				tr1 = F1231_11526(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12788[Dtype(tr1)-1610]);
				tr2 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr3 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr4 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
				tb1 = F2026_20549(RTCW(tr1), loc3, tr2, loc4, tr3, tr4);
				if (tb1) {
					tb1 = F1930_19067(RTCW(arg1));
					if (tb1) {
						tr1 = F1231_11526(Current);
						loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12788[Dtype(tr1)-1610]);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9226[dtype-1230])(Current, arg1, loc1);
					} else {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
						tr4 = F1231_11526(Current);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12788[Dtype(tr4)-1610]);
						F2046_21572(RTCW(tr1), tr2, tr3, arg1, tr4);
					}
				} else {
					tr1 = F1231_11526(Current);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12760[Dtype(tr1)-1610]);
					tr2 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr3 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr4 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
					tb1 = F2026_20549(RTCW(tr1), loc3, tr2, loc4, tr3, tr4);
					if (tb1) {
						tb1 = F1930_19067(RTCW(arg1));
						if (tb1) {
							tr1 = F1231_11526(Current);
							loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12788[Dtype(tr1)-1610]);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9182[dtype-1230])(Current, arg1, loc1);
						} else {
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
							tr4 = F1231_11526(Current);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12760[Dtype(tr4)-1610]);
							F2046_21572(RTCW(tr1), tr2, tr3, arg1, tr4);
						}
					}
				}
			}
		}
	}
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
	} else {
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
		} else {
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21529(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
			} else {
				tb1 = F1930_19066(RTCW(arg1));
				if (tb1) {
					tr1 = F1231_11526(Current);
					loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12787[Dtype(tr1)-1610]);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9225[dtype-1230])(Current, arg1, loc1);
				} else {
					tb1 = F1930_19067(RTCW(arg1));
					if (tb1) {
						tr1 = F1231_11526(Current);
						loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12788[Dtype(tr1)-1610]);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9226[dtype-1230])(Current, arg1, loc1);
					} else {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
						tr4 = F1231_11526(Current);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12788[Dtype(tr4)-1610]);
						F2046_21572(RTCW(tr1), tr2, tr3, arg1, tr4);
					}
				}
			}
		}
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1930_19081(RTCW(arg1), loc1);
		F899_7054(RTCW(arg2), loc1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_manifest_tuple_validity */
void F1231_11245 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,loc11);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,loc9);
	RTLR(5,arg1);
	RTLR(6,loc10);
	RTLR(7,arg2);
	RTLR(8,loc8);
	RTLR(9,loc7);
	RTLR(10,loc5);
	RTLR(11,tr2);
	RTLIU(12);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(Current + O9258[dtype-1230]);
	tr1 = F2022_20345(RTCW(tr1));
	loc11 = tr1;
	loc11 = RTRV(eif_new_type(2024, 0x01),loc11);
	if (EIF_TEST(loc11)) {
		loc6 = *(EIF_REFERENCE *)(loc11 + _REFACS_2_);
		if ((EIF_BOOLEAN)(loc6 != NULL)) {
			loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14070[Dtype(RTCW(loc6))-1897])(loc6);
		}
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	loc9 = *(EIF_REFERENCE *)(RTCW(tr1) + O12741[Dtype(tr1)-1610]);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_0_0_0_);
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
		tr1 = F1231_11526(Current);
		loc10 = *(EIF_REFERENCE *)(RTCW(tr1) + O12792[Dtype(tr1)-1610]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9197[dtype-1230])(Current, arg1, loc10, arg2);
		F899_7054(RTCW(arg2), loc10);
	} else {
		if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 1L))) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc6 != NULL) && (EIF_BOOLEAN) (loc3 >= ((EIF_INTEGER_32) 1L)))) {
				loc8 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R14072[Dtype(RTCW(loc6))-1897])(loc6, ((EIF_INTEGER_32) 1L));
				F899_7054(RTCW(loc8), tr1);
				tr1 = F1816_17616(RTCW(arg1), ((EIF_INTEGER_32) 1L));
				F1231_11290(Current, tr1, arg2, loc8);
				F1231_11572(Current, loc8);
			} else {
				tr1 = F1816_17616(RTCW(arg1), ((EIF_INTEGER_32) 1L));
				F1231_11290(Current, tr1, arg2, loc9);
			}
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				tr1 = F1231_11526(Current);
				loc10 = *(EIF_REFERENCE *)(RTCW(tr1) + O12794[Dtype(tr1)-1610]);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9197[dtype-1230])(Current, arg1, loc10, arg2);
				F899_7054(RTCW(arg2), loc10);
			}
		} else {
			loc7 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			loc5 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
			F1901_18643(RTCW(loc5), loc2);
			loc1 = (EIF_INTEGER_32) loc2;
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 <= loc3)) break;
				tr1 = F1816_17616(RTCW(arg1), loc1);
				F1231_11290(Current, tr1, loc7, loc9);
				if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tr1 = F2022_20345(RTCW(loc7));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc5))-1003])(loc5, tr1);
				}
				F899_7060(RTCW(loc7));
				loc1--;
			}
			if ((EIF_BOOLEAN)(loc6 != NULL)) {
				loc8 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
				for (;;) {
					if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) break;
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R14072[Dtype(RTCW(loc6))-1897])(loc6, loc1);
					F899_7054(RTCW(loc8), tr1);
					tr1 = F1816_17616(RTCW(arg1), loc1);
					F1231_11290(Current, tr1, loc7, loc8);
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tr1 = F2022_20345(RTCW(loc7));
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc5))-1003])(loc5, tr1);
					}
					F899_7060(RTCW(loc7));
					F899_7060(RTCW(loc8));
					loc1--;
				}
				F1231_11572(Current, loc8);
			}
			F1231_11572(Current, loc7);
			if (loc4) {
				F1033_8331(Current);
			} else {
				loc10 = RTLNS(eif_new_type(2024, 0x01).id, 2024, _OBJSIZ_4_0_0_0_0_0_0_0_);
				tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr2 = F1231_11526(Current);
				tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12792[Dtype(tr2)-1610]);
				tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_1_);
				F2025_20495(RTCW(loc10), tr1, loc5, tr2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9197[dtype-1230])(Current, arg1, loc10, arg2);
				F899_7054(RTCW(arg2), loc10);
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_manifest_type_validity */
void F1231_11246 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc2);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	F1231_11164(Current, loc1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F899_7054(RTCW(arg2), loc1);
		tr1 = F1231_11526(Current);
		loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + O12800[Dtype(tr1)-1610]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9198[dtype-1230])(Current, arg1, loc2, arg2);
		F899_7054(RTCW(arg2), loc2);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_named_object_test_validity */
void F1231_11247 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(18);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc9);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,arg2);
	RTLR(7,loc3);
	RTLR(8,loc10);
	RTLR(9,loc11);
	RTLR(10,loc7);
	RTLR(11,loc12);
	RTLR(12,tr3);
	RTLR(13,loc13);
	RTLR(14,loc14);
	RTLR(15,loc15);
	RTLR(16,loc16);
	RTLR(17,loc17);
	RTLIU(18);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc2 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13439[Dtype(RTCW(arg1))-1736])(arg1);
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		F1231_11164(Current, loc9);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12741[Dtype(tr2)-1610]);
			F1231_11290(Current, tr1, loc2, tr2);
			*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc1);
		} else {
			F899_7054(RTCW(loc2), loc9);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
			F1231_11290(Current, tr1, arg2, loc2);
			F2023_20389(RTCW(arg2), *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12741[Dtype(tr2)-1610]);
		F1231_11290(Current, tr1, loc2, tr2);
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		tb1 = F2022_20355(RTCW(loc2));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = RTOUCR(75,F396_4598, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			F899_7054(RTCW(loc2), tr1);
		}
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
		F1553_14051(RTCW(tr1), loc2, arg1);
		loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
		loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
		tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tr1 = F140_1508(RTCW(tr1), loc3);
		loc10 = tr1;
		if (EIF_TEST(loc10)) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21503(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1, loc10);
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
		loc11 = tr1;
		if (EIF_TEST(loc11)) {
			tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
			F1541_13864(RTCW(tr1), loc11);
			tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
			loc6 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
			loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc4 > loc6)) break;
				tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
				loc7 = F1541_13846(RTCW(tr1), loc4);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_5_);
				loc12 = tr1;
				if (EIF_TEST(loc12)) {
					loc5 = F1649_16724(loc12, loc3);
					if ((EIF_BOOLEAN)(loc5 != ((EIF_INTEGER_32) 0L))) {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = F1649_16721(loc12, loc5);
						F2046_21504(RTCW(tr1), tr2, arg1, tr3);
					}
				}
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2905[Dtype(RTCW(loc7))-1755])(loc7);
				loc13 = tr1;
				if (EIF_TEST(loc13)) {
					loc5 = F1634_16568(loc13, loc3);
					if ((EIF_BOOLEAN)(loc5 != ((EIF_INTEGER_32) 0L))) {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = F1634_16566(loc13, loc5);
						F2046_21505(RTCW(tr1), tr2, arg1, tr3);
					}
				}
				loc4++;
			}
			tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
			F1541_13879(RTCW(tr1));
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2903[Dtype(RTCW(tr1))-1755])(tr1);
		loc14 = tr1;
		if (EIF_TEST(loc14)) {
			loc5 = F1649_16724(loc14, loc3);
			if ((EIF_BOOLEAN)(loc5 != ((EIF_INTEGER_32) 0L))) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
				tr3 = F1649_16721(loc14, loc5);
				F2046_21504(RTCW(tr1), tr2, arg1, tr3);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2905[Dtype(RTCW(tr1))-1755])(tr1);
		loc15 = tr1;
		if (EIF_TEST(loc15)) {
			loc5 = F1634_16568(loc15, loc3);
			if ((EIF_BOOLEAN)(loc5 != ((EIF_INTEGER_32) 0L))) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
				tr3 = F1634_16566(loc15, loc5);
				F2046_21505(RTCW(tr1), tr2, arg1, tr3);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
		tr1 = F10_112(RTCW(tr1), loc3);
		loc16 = tr1;
		if (EIF_TEST(loc16)) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21506(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1, loc16);
		}
		tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
		tr1 = F11_125(RTCW(tr1), loc3);
		loc17 = tr1;
		if (EIF_TEST(loc17)) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21507(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1, loc17);
		}
		tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
		tr2 = RTOUCR(540,F482_6189, (Current));
		tb1 = F1290_12728(RTCW(tr1), tr2);
		if (tb1) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) == NULL) && *(EIF_BOOLEAN *)(Current + O9275[dtype-1230]))) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21511(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
			}
			if (*(EIF_BOOLEAN *)(Current + O9278[dtype-1230])) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21512(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
			}
		}
	}
	tr1 = F1231_11526(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
	F899_7054(RTCW(arg2), tr1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9199[dtype-1230])(Current, arg1, loc2);
	}
	if ((EIF_BOOLEAN) !loc8) {
		F1231_11572(Current, loc2);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_object_equality_expression_validity */
void F1231_11248 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc7);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc1);
	RTLR(8,loc2);
	RTLR(9,loc8);
	RTLR(10,tr3);
	RTLR(11,loc6);
	RTLR(12,loc5);
	RTLR(13,tr4);
	RTLR(14,tr5);
	RTLR(15,arg2);
	RTLIU(16);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = RTOUCR(773,F1806_17545, (RTCW(arg1)));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2) + O12989[Dtype(tr2)-1616]);
	F1944_19225(RTCW(tr1), ti4_1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	loc7 = *(EIF_REFERENCE *)(RTCW(tr1) + O12741[Dtype(tr1)-1610]);
	loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	loc4 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	F1231_11290(Current, loc1, loc3, loc7);
	loc8 = (EIF_REFERENCE) loc3;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F1231_11290(Current, loc2, loc4, loc7);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) != *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
			} else {
				tr1 = RTOUCR(764,F396_4661, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr2 = RTOUCR(764,F396_4661, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr3 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
				tb1 = F2022_20380(RTCW(loc3), tr1, loc4, tr2, tr3);
				if (tb1) {
				} else {
					tr1 = RTOUCR(764,F396_4661, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr2 = RTOUCR(764,F396_4661, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr3 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
					tb1 = F2022_20380(RTCW(loc4), tr1, loc3, tr2, tr3);
					if (tb1) {
					} else {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12774[Dtype(tr1)-1610]);
						tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
						tb1 = F2022_20365(RTCW(loc3), tr1, tr2);
						if (tb1) {
						} else {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12774[Dtype(tr1)-1610]);
							tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
							tb1 = F2022_20365(RTCW(loc4), tr1, tr2);
							if (tb1) {
							} else {
								loc6 = F1231_11340(Current, loc2, loc4, loc3);
								loc9 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
								loc5 = F1231_11340(Current, loc1, loc3, loc4);
								*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc9);
								if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
								} else {
									if ((EIF_BOOLEAN)(loc6 != NULL)) {
										if ((EIF_BOOLEAN)(loc5 != NULL)) {
										}
										F1767_17369(RTCW(arg1), loc6);
									} else {
										if ((EIF_BOOLEAN)(loc5 != NULL)) {
											F1767_17368(RTCW(arg1), loc5);
											loc8 = (EIF_REFERENCE) loc4;
										} else {
											tr1 = F1023_8173(Current);
											tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
											tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
											tr4 = F2022_20345(RTCW(loc3));
											tr5 = F2022_20345(RTCW(loc4));
											F2046_21523(RTCW(tr1), tr2, tr3, arg1, tr4, tr5);
										}
									}
								}
							}
						}
					}
				}
			}
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				tr1 = F1231_11526(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
				F899_7054(RTCW(arg2), tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9204[dtype-1230])(Current, arg1, loc8);
			}
		}
	} else {
		F1231_11290(Current, loc2, loc4, loc7);
		F1033_8331(Current);
	}
	F1231_11572(Current, loc4);
	F1231_11572(Current, loc3);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_object_test_validity */
void F1231_11249 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc3);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,arg2);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc2 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13439[Dtype(RTCW(arg1))-1736])(arg1);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		F1231_11164(Current, loc3);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12741[Dtype(tr2)-1610]);
			F1231_11290(Current, tr1, loc2, tr2);
			*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc1);
		} else {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9206[dtype-1230])(Current, arg1, loc3, arg2);
			F899_7054(RTCW(loc2), loc3);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
			F1231_11290(Current, tr1, arg2, loc2);
			F2023_20389(RTCW(arg2), *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12741[Dtype(tr2)-1610]);
		F1231_11290(Current, tr1, loc2, tr2);
	}
	F1231_11572(Current, loc2);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		tr1 = F1231_11526(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
		F899_7054(RTCW(arg2), tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9205[dtype-1230])(Current, arg1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_object_test_local_validity */
void F1231_11250 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,arg2);
	RTLR(7,loc3);
	RTLIU(8);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_1_0_2_);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
			F1033_8331(Current);
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
			loc2 = F10_112(RTCW(tr1), arg1);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				F1033_8331(Current);
				tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
				if (tb1) {
					tr1 = F1023_8173(Current);
					tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
					tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
					F2046_21309(RTCW(tr1), tr2, arg1, tr3);
				} else {
					tr1 = F1023_8173(Current);
					F2046_21310(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
				}
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_4_);
				loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_1_0_2_);
				F1944_19225(RTCW(arg1), loc1);
				tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
				F1553_14040(RTCW(tr1), loc2);
				tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
				tb1 = F1545_13939(RTCW(tr1));
				if ((EIF_BOOLEAN) !tb1) {
					F1033_8331(Current);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
					tr1 = F1545_13931(RTCW(tr1));
					F2023_20428(RTCW(arg2), tr1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9207[dtype-1230])(Current, arg1, loc2);
				}
			}
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCV(F1231_11523(Current)));
		loc3 = tr1;
		if ((EIF_BOOLEAN) !EIF_TEST(loc3)) {
			F1033_8331(Current);
			F2046_21728(RTCV(F1023_8173(Current)));
		} else {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) {
				ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_1_0_0_0_);
				tb1 = (EIF_BOOLEAN) (loc1 > ti4_1);
			}
			if (tb1) {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
			} else {
				loc2 = F903_7078(loc3, loc1);
				tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
				F1553_14040(RTCW(tr1), loc2);
				tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
				tb1 = F1545_13939(RTCW(tr1));
				if ((EIF_BOOLEAN) !tb1) {
					F1033_8331(Current);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O9259[dtype-1230]);
					tr1 = F1545_13931(RTCW(tr1));
					F2023_20428(RTCW(arg2), tr1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9207[dtype-1230])(Current, arg1, loc2);
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_octal_integer_constant_validity */
void F1231_11251 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11236(Current, arg1, arg2);
}

/* {ET_FEATURE_CHECKER}.check_old_expression_validity */
void F1231_11252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1));
	F1231_11290(Current, loc1, arg2, *(EIF_REFERENCE *)(Current + O9258[dtype-1230]));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O13392[Dtype(loc1)-1721]);
	F1722_17132(RTCW(arg1), ti4_1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O9276[dtype-1230])) {
		F1033_8331(Current);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) == *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
			tr1 = F1023_8173(Current);
			F2046_21246(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
		} else {
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_once_manifest_string_validity */
void F1231_11253 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	F1231_11290(Current, loc1, arg2, *(EIF_REFERENCE *)(Current + O9258[Dtype(Current)-1230]));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O13392[Dtype(loc1)-1721]);
	F1722_17132(RTCW(arg1), ti4_1);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_parenthesized_expression_validity */
void F1231_11254 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1));
	F1231_11290(Current, loc1, arg2, *(EIF_REFERENCE *)(Current + O9258[Dtype(Current)-1230]));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O13392[Dtype(loc1)-1721]);
	F1722_17132(RTCW(arg1), ti4_1);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_precursor_expression_validity */
void F1231_11255 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc6);
	RTLR(5,loc7);
	RTLR(6,loc2);
	RTLR(7,loc8);
	RTLR(8,loc1);
	RTLR(9,loc3);
	RTLR(10,loc9);
	RTLR(11,arg2);
	RTLR(12,loc10);
	RTLR(13,loc11);
	RTLIU(14);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
	loc5 = tr1;
	loc5 = RTRV(eif_new_type(1836, 0x01),loc5);
	if ((EIF_BOOLEAN) !EIF_TEST(loc5)) {
		F1033_8331(Current);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
			tr1 = F1023_8173(Current);
			F2046_21265(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
		} else {
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		}
		F1231_11293(Current, arg1);
	} else {
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O9275[dtype-1230]) || *(EIF_BOOLEAN *)(Current + O9276[dtype-1230]))) {
			F1033_8331(Current);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
				tr1 = F1023_8173(Current);
				F2046_21265(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
			} else {
				if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
					F2046_21728(RTCV(F1023_8173(Current)));
				}
			}
			F1231_11293(Current, arg1);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
			loc6 = tr1;
			if (EIF_TEST(loc6)) {
				F1033_8331(Current);
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
					tr1 = F1023_8173(Current);
					F2046_21271(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1, loc6, loc5);
				} else {
					if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
						F2046_21728(RTCV(F1023_8173(Current)));
					}
				}
				F1231_11293(Current, arg1);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8705[Dtype(RTCW(tr1))-1840])(tr1);
				if ((EIF_BOOLEAN)(tr1 == NULL)) {
					F1033_8331(Current);
					if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
						if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					} else {
						tr1 = F1023_8173(Current);
						F2046_21270(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1, loc5);
					}
					F1231_11293(Current, arg1);
				} else {
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
					loc7 = tr1;
					if ((EIF_BOOLEAN) !EIF_TEST(loc7)) {
						F1033_8331(Current);
						F2046_21728(RTCV(F1023_8173(Current)));
						F1231_11293(Current, arg1);
					} else {
						loc2 = (EIF_REFERENCE) loc7;
						tb1 = '\0';
						if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) != *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
							tb2 = F2024_20445(RTCW(loc2));
							tb1 = tb2;
						}
						if (tb1) {
							tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr1 = F2027_20707(RTCW(tr1), loc2);
							loc8 = tr1;
							if (EIF_TEST(loc8)) {
								loc2 = (EIF_REFERENCE) loc8;
							} else {
								F1033_8331(Current);
								F2046_21728(RTCV(F1023_8173(Current)));
								F1231_11293(Current, arg1);
							}
						}
						if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
							loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
							loc3 = F2024_20433(RTCW(loc2));
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_1_0_1_);
							tr1 = F2027_20747(RTCW(loc3), ti4_1);
							loc9 = tr1;
							if (EIF_TEST(loc9)) {
								if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
									F1231_11308(Current, arg1, loc9, loc3, loc2, arg2);
									tb1 = '\0';
									if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
										tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
										loc10 = tr1;
										tb1 = EIF_TEST(loc10);
									}
									if (tb1) {
										ti4_1 = *(EIF_INTEGER_32 *)(loc10+ _LNGOFF_3_0_0_0_);
										F1722_17132(RTCW(arg1), ti4_1);
										loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									}
								}
								if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) && (EIF_BOOLEAN) !loc4)) {
									F1231_11256(Current, arg1, loc9, loc3, loc2, arg2);
								}
							} else {
								ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_1_0_1_);
								tr1 = F2027_20748(RTCW(loc3), ti4_1);
								loc11 = tr1;
								if (EIF_TEST(loc11)) {
									F1033_8331(Current);
									tr1 = F1023_8173(Current);
									F2046_21404(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc1, loc11, loc3);
									F1231_11293(Current, arg1);
								} else {
									F1033_8331(Current);
									F2046_21728(RTCV(F1023_8173(Current)));
									F1231_11293(Current, arg1);
								}
							}
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_precursor_query_expression_validity */
void F1231_11256 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,arg4);
	RTLR(7,arg3);
	RTLR(8,loc1);
	RTLR(9,arg5);
	RTLR(10,loc4);
	RTLIU(11);
	
	RTGC;
	tb1 = '\0';
	if (*(EIF_BOOLEAN *)(Current + O9280[dtype-1230])) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13718[Dtype(RTCW(arg2))-1840])(arg2);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
		F2046_21494(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), tr2, arg2);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	loc2 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
	F899_7054(RTCW(loc2), arg4);
	F1231_11292(Current, arg1, loc2, arg2, arg3, NULL);
	F1231_11572(Current, loc2);
	F1033_8332(Current, (EIF_BOOLEAN) (loc3 || *(EIF_BOOLEAN *)(Current + O7067[dtype-1032])));
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc1 = F1839_17878(RTCW(arg2));
		F899_7054(RTCW(arg5), loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9209[dtype-1230])(Current, arg1, arg4, arg2);
		tr1 = *(EIF_REFERENCE *)(Current + O9281[dtype-1230]);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			F1578_14121(loc4, arg2);
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_prefix_expression_validity */
void F1231_11257 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11258(Current, arg1, arg2, NULL);
}

/* {ET_FEATURE_CHECKER}.check_qualified_call_expression_validity */
void F1231_11258 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc14 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(22);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,arg2);
	RTLR(5,tr1);
	RTLR(6,loc6);
	RTLR(7,loc5);
	RTLR(8,loc4);
	RTLR(9,loc16);
	RTLR(10,loc17);
	RTLR(11,arg3);
	RTLR(12,loc18);
	RTLR(13,loc19);
	RTLR(14,loc20);
	RTLR(15,loc21);
	RTLR(16,loc22);
	RTLR(17,loc23);
	RTLR(18,loc15);
	RTLR(19,loc11);
	RTLR(20,loc12);
	RTLR(21,loc13);
	RTLIU(22);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13377[Dtype(RTCW(arg1))-1748])(arg1);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13378[Dtype(RTCW(arg1))-1748])(arg1);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O14497[Dtype(loc2)-1943]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12741[Dtype(tr1)-1610]);
	F1231_11290(Current, loc1, arg2, tr1);
	loc8 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_0_0_0_);
	loc6 = F1231_11337(Current);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F2023_20412(RTCW(arg2), loc6);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_4_0_0_1_);
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
		F1231_11334(Current, loc2, loc6, arg2);
	}
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F1231_11293(Current, arg1);
	} else {
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
			loc5 = F1541_13847(RTCW(loc6));
			loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc5))-1835])(loc5);
			tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
			F1037_8385(RTCW(tr1), loc7, loc5, arg2);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
				F1033_8331(Current);
				if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
					F2046_21728(RTCV(F1023_8173(Current)));
				}
			} else {
				tb1 = F2027_20580(RTCW(loc4));
				if (tb1) {
					loc16 = arg1;
					loc16 = RTRV(eif_new_type(1804, 0x01),loc16);
					if (EIF_TEST(loc16)) {
						F1805_17540(loc16, (EIF_BOOLEAN) 1);
					} else {
						loc17 = arg1;
						loc17 = RTRV(eif_new_type(1800, 0x01),loc17);
						if (EIF_TEST(loc17)) {
							F1801_17516(loc17, (EIF_BOOLEAN) 1);
						}
					}
				}
			}
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				F1231_11293(Current, arg1);
			} else {
				tb1 = F2027_20678(RTCW(loc4));
				if (tb1) {
					F1231_11259(Current, arg1, loc5, arg2, arg3);
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1484[Dtype(RTCW(loc5))-1835])(loc5, loc2);
					loc18 = tr1;
					if (EIF_TEST(loc18)) {
						loc3 = *(EIF_INTEGER_32 *)(loc18 + O10400[Dtype(loc18)-1302]);
						F1944_19225(RTCW(loc2), loc3);
						F1231_11305(Current, arg1, loc18, loc4, arg2, arg3);
						if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						} else {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
							loc19 = tr1;
							if (EIF_TEST(loc19)) {
								ti4_1 = *(EIF_INTEGER_32 *)(loc19+ _LNGOFF_3_0_0_0_);
								F1722_17132(RTCW(arg1), ti4_1);
							} else {
								F1231_11262(Current, arg1, loc18, loc4, arg2, arg3);
							}
						}
					} else {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1485[Dtype(RTCW(loc5))-1835])(loc5, loc2);
						loc20 = tr1;
						if (EIF_TEST(loc20)) {
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							F2046_21404(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc2, loc20, loc4);
							F1231_11293(Current, arg1);
						} else {
							tb1 = '\0';
							tb2 = F2027_20603(RTCW(loc4));
							if (tb2) {
								loc21 = loc2;
								loc21 = RTRV(eif_new_type(1986, 0x01),loc21);
								tb1 = EIF_TEST(loc21);
							}
							if (tb1) {
								loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1489[Dtype(RTCW(loc5))-1835])(loc5, loc21, arg2);
								if ((EIF_BOOLEAN)(loc3 != ((EIF_INTEGER_32) 0L))) {
									F1987_19681(loc21, (EIF_BOOLEAN) 1);
									F1944_19225(loc21, loc3);
									F1231_11310(Current, arg1, loc4, arg2, arg3);
									if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
									} else {
										tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
										loc22 = tr1;
										if (EIF_TEST(loc22)) {
											ti4_1 = *(EIF_INTEGER_32 *)(loc22+ _LNGOFF_3_0_0_0_);
											F1722_17132(RTCW(arg1), ti4_1);
										} else {
											F1231_11263(Current, arg1, loc4, arg2, arg3);
										}
									}
								}
							}
							if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
								F1033_8331(Current);
								tr1 = F1023_8173(Current);
								F2046_21498(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc2, loc4);
								F1231_11293(Current, arg1);
							}
						}
					}
				}
			}
		} else {
			tb1 = F1432_13373(RTCW(loc6));
			if (tb1) {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
				F1231_11293(Current, arg1);
			} else {
				loc10 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_4_0_0_1_);
				loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc9 > loc10)) break;
					loc5 = F1541_13846(RTCW(loc6), loc9);
					loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc5))-1835])(loc5);
					tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
					F1037_8385(RTCW(tr1), loc7, loc5, arg2);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14504[Dtype(RTCW(loc2))-1944])(loc2);
					if (tb1) {
						tb1 = F2027_20603(RTCW(loc4));
						if (tb1) {
							F1231_11263(Current, arg1, loc4, arg2, arg3);
						} else {
							tb1 = F2027_20576(RTCW(loc4));
							if (tb1) {
								F1033_8331(Current);
								F2046_21728(RTCV(F1023_8173(Current)));
							} else {
								F1033_8331(Current);
								F2046_21728(RTCV(F1023_8173(Current)));
							}
						}
					} else {
						tr1 = F2027_20747(RTCW(loc4), loc3);
						loc23 = tr1;
						if (EIF_TEST(loc23)) {
							F1231_11262(Current, arg1, loc23, loc4, arg2, arg3);
							loc15 = (EIF_REFERENCE) loc23;
						} else {
							tb1 = F2027_20576(RTCW(loc4));
							if (tb1) {
								F1033_8331(Current);
								F2046_21728(RTCV(F1023_8173(Current)));
							} else {
								F1033_8331(Current);
								F2046_21728(RTCV(F1023_8173(Current)));
							}
						}
					}
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						loc9 = (EIF_INTEGER_32) loc10;
					} else {
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc11 != NULL) && (EIF_BOOLEAN)(loc12 != NULL))) {
							tb1 = F2022_20367(RTCW(arg2), loc11);
							if ((EIF_BOOLEAN) !tb1) {
								F1033_8331(Current);
								if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc13 != NULL) && (EIF_BOOLEAN)(loc15 != NULL))) {
									tr1 = F1023_8173(Current);
									F2046_21386(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc2, loc13, loc12, loc15, loc5);
								} else {
									tr1 = F1023_8173(Current);
									F2046_21387(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc2, loc3, loc12, loc5);
								}
							}
						} else {
							if ((EIF_BOOLEAN) (loc10 > ((EIF_INTEGER_32) 1L))) {
								loc11 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
								F2023_20428(RTCW(loc11), arg2);
								loc12 = (EIF_REFERENCE) loc5;
								loc13 = (EIF_REFERENCE) loc15;
								loc14 = (EIF_INTEGER_32) loc3;
							}
						}
					}
					if ((EIF_BOOLEAN) (loc9 < loc10)) {
						F899_7059(RTCW(arg2), loc8);
					}
					loc9++;
				}
				if ((EIF_BOOLEAN)(loc11 != NULL)) {
					F1231_11572(Current, loc11);
				}
			}
		}
	}
	F1231_11338(Current, loc6);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_qualified_dotnet_query_call_expression_validity */
void F1231_11259 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg2);
	RTLR(3,loc3);
	RTLR(4,arg1);
	RTLR(5,loc5);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,arg3);
	RTLR(9,loc2);
	RTLR(10,loc6);
	RTLR(11,arg4);
	RTLR(12,loc7);
	RTLIU(13);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(arg2))-1835])(arg2);
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13378[Dtype(RTCW(arg1))-1748])(arg1);
	loc5 = F1231_11562(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1487[Dtype(RTCW(arg2))-1835])(arg2, loc3, loc5);
	tb1 = F1432_13373(RTCW(loc5));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = F1231_11336(Current, loc3, arg2);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13379[Dtype(RTCW(arg1))-1748])(arg1);
		F1231_11558(Current, loc5, tr1, tr2, arg3, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			F1231_11293(Current, arg1);
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_4_0_0_1_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
				loc2 = F1541_13847(RTCW(loc5));
				loc4 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O10400[Dtype(loc2)-1302]);
				F1944_19225(RTCW(loc3), loc4);
				F1231_11305(Current, arg1, loc2, loc1, arg3, NULL);
				if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
					loc6 = tr1;
					if (EIF_TEST(loc6)) {
						ti4_1 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_3_0_0_0_);
						F1722_17132(RTCW(arg1), ti4_1);
					} else {
						F1231_11262(Current, arg1, loc2, loc1, arg3, arg4);
					}
				}
			} else {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
				F1231_11293(Current, arg1);
			}
		}
	} else {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1485[Dtype(RTCW(arg2))-1835])(arg2, loc3);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21404(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc3, loc7, loc1);
			F1231_11293(Current, arg1);
		} else {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21498(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc3, loc1);
			F1231_11293(Current, arg1);
		}
	}
	F1231_11563(Current, loc5);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_qualified_feature_call_validity */
void F1231_11260 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg4);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,arg2);
	RTLR(8,tr4);
	RTLR(9,arg3);
	RTLR(10,arg5);
	RTLIU(11);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13378[Dtype(RTCW(arg1))-1748])(arg1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13018[Dtype(tr1)-1616]);
	if (tb1) {
		tb1 = F2022_20355(RTCW(arg4));
		if ((EIF_BOOLEAN) !tb1) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
			tr4 = F2022_20345(RTCW(arg4));
			F2046_21513(RTCW(tr1), tr2, tr3, loc1, arg2, tr4);
		}
	}
	tb1 = F1837_17835(RTCW(arg2), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
	if ((EIF_BOOLEAN) !tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21499(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1, arg2, arg3);
	}
	loc2 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	F1231_11294(Current, loc1, arg2, arg3);
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (tb1 || loc2);
	F1231_11292(Current, arg1, arg4, arg2, arg3, arg5);
	F1033_8332(Current, (EIF_BOOLEAN) (loc2 || *(EIF_BOOLEAN *)(Current + O7067[dtype-1032])));
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_qualified_feature_call_expression_validity */
void F1231_11261 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(11);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLR(3,arg3);
	RTLR(4,arg4);
	RTLR(5,arg5);
	RTLR(6,Current);
	RTLR(7,loc2);
	RTLR(8,tr1);
	RTLR(9,tr2);
	RTLR(10,tr3);
	RTLIU(11);
	
	RTGC;
	loc1 = arg2;
	loc1 = RTRV(eif_new_type(1838, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		F1231_11262(Current, arg1, loc1, arg3, arg4, arg5);
	} else {
		loc2 = arg2;
		loc2 = RTRV(eif_new_type(1860, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			tr2 = *(EIF_REFERENCE *)(Current + O6920[Dtype(Current)-1022]);
			tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13378[Dtype(RTCW(arg1))-1748])(arg1);
			F2046_21404(RTCW(tr1), tr2, tr3, loc2, arg3);
			F1231_11293(Current, arg1);
		} else {
			F1033_8331(Current);
			F2046_21728(RTCV(F1023_8173(Current)));
			F1231_11293(Current, arg1);
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_qualified_query_call_expression_validity */
void F1231_11262 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc2);
	RTLR(1,arg2);
	RTLR(2,arg5);
	RTLR(3,arg3);
	RTLR(4,tr1);
	RTLR(5,arg4);
	RTLR(6,arg1);
	RTLR(7,Current);
	RTLR(8,loc3);
	RTLIU(9);
	
	RTGC;
	loc2 = (EIF_REFERENCE) arg2;
	if ((EIF_BOOLEAN)(arg5 != NULL)) {
		
		eif_put_reference_item(RTCW(arg5),1,loc2);
		
		eif_put_reference_item(RTCW(arg5),2,arg3);
		tr1 = eif_boxed_item(arg5,3);
		F2023_20428(RTCW(tr1), arg4);
	}
	F1231_11260(Current, arg1, arg2, arg3, arg4, arg5);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		tb1 = '\0';
		tb2 = '\0';
		if ((EIF_BOOLEAN)(arg5 != NULL)) {
			tr1 = eif_boxed_item(arg5,1);
			loc3 = tr1;
			tb2 = EIF_TEST(loc3);
		}
		if (tb2) {
			tb1 = (EIF_BOOLEAN)(loc3 != loc2);
		}
		if (tb1) {
			loc2 = (EIF_REFERENCE) loc3;
			tr1 = eif_boxed_item(arg5,3);
			F2023_20428(RTCW(arg4), tr1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9213[dtype-1230])(Current, arg1, arg4, loc2);
		loc1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		F1231_11265(Current, arg1, loc2, arg4);
		F1033_8332(Current, (EIF_BOOLEAN) (loc1 || *(EIF_BOOLEAN *)(Current + O7067[dtype-1032])));
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_qualified_tuple_label_call_expression_validity */
void F1231_11263 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,arg4);
	RTLR(4,arg2);
	RTLR(5,tr1);
	RTLR(6,arg3);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,tr4);
	RTLR(10,loc2);
	RTLIU(11);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13378[Dtype(RTCW(arg1))-1748])(arg1);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O14497[Dtype(loc1)-1943]);
	if ((EIF_BOOLEAN)(arg4 != NULL)) {
		
		eif_put_reference_item(RTCW(arg4),1,NULL);
		
		eif_put_reference_item(RTCW(arg4),2,arg2);
		tr1 = eif_boxed_item(arg4,3);
		F2023_20428(RTCW(tr1), arg3);
	}
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13018[Dtype(tr1)-1616]);
	if (tb1) {
		tb1 = F2022_20355(RTCW(arg3));
		if ((EIF_BOOLEAN) !tb1) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
			tr4 = F2022_20345(RTCW(arg3));
			F2046_21514(RTCW(tr1), tr2, tr3, loc1, tr4);
		}
	}
	ti4_1 = F1779_17423(RTCW(arg1));
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		F1033_8331(Current);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
			tr1 = F1023_8173(Current);
			F2046_21483(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc1);
		} else {
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		}
		F1231_11293(Current, arg1);
	}
	ti4_1 = F2023_20402(RTCW(arg3));
	if ((EIF_BOOLEAN) (loc3 > ti4_1)) {
		F1033_8331(Current);
		F2046_21728(RTCV(F1023_8173(Current)));
	} else {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			loc2 = F2027_20699(RTCW(arg2), loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9229[dtype-1230])(Current, arg1, arg3);
			F899_7054(RTCW(arg3), loc2);
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_quantifier_expression_validity */
void F1231_11264 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11239(Current, arg1, arg2);
}

/* {ET_FEATURE_CHECKER}.check_query_call_type_validity */
void F1231_11265 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg2);
	RTLR(3,loc5);
	RTLR(4,loc6);
	RTLR(5,arg1);
	RTLR(6,tr1);
	RTLR(7,loc7);
	RTLR(8,loc4);
	RTLR(9,arg3);
	RTLR(10,loc3);
	RTLR(11,loc2);
	RTLR(12,loc8);
	RTLR(13,loc9);
	RTLIU(14);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1839_17878(RTCW(arg2));
	tb1 = '\0';
	loc5 = loc1;
	loc5 = RTRV(eif_new_type(1892, 0x01),loc5);
	if (EIF_TEST(loc5)) {
		tb2 = F1893_18488(loc5);
		tb1 = tb2;
	}
	if (tb1) {
		tb1 = '\0';
		tb2 = '\0';
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13379[Dtype(RTCW(arg1))-1748])(arg1);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2266[Dtype(loc6)-899])(loc6);
			tb2 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L));
		}
		if (tb2) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10399[Dtype(RTCW(arg2))-1840])(arg2);
			loc7 = tr1;
			tb1 = EIF_TEST(loc7);
		}
		if (tb1) {
			loc4 = F2022_20336(RTCW(arg3));
			loc3 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			F2023_20428(RTCW(loc3), arg3);
			tr1 = F1649_16721(loc7, ((EIF_INTEGER_32) 1L));
			tr1 = F1814_17596(RTCW(tr1));
			F899_7054(RTCW(loc3), tr1);
			F899_7060(RTCW(arg3));
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2265[Dtype(loc6)-899])(loc6, ((EIF_INTEGER_32) 1L));
			F1231_11291(Current, loc2, arg3, loc3, arg1, loc4);
			F1231_11572(Current, loc3);
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				loc8 = loc2;
				loc8 = RTRV(eif_new_type(1768, 0x01),loc8);
				if (EIF_TEST(loc8)) {
					tr1 = *(EIF_REFERENCE *)(loc8 + _REFACS_1_);
					loc9 = tr1;
					loc9 = RTRV(eif_new_type(1704, 0x01),loc9);
					if (EIF_TEST(loc9)) {
						F2023_20389(RTCW(arg3), *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
						tr1 = *(EIF_REFERENCE *)(loc9 + _REFACS_2_);
						F899_7054(RTCW(arg3), tr1);
					}
				}
			}
		} else {
			F899_7054(RTCW(arg3), loc1);
		}
	} else {
		F899_7054(RTCW(arg3), loc1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_real_constant_validity */
void F1231_11266 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,loc4);
	RTLR(3,loc5);
	RTLR(4,arg1);
	RTLR(5,tr1);
	RTLR(6,loc2);
	RTLR(7,loc1);
	RTLR(8,arg2);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc3 = RTOUCR(571,F396_4600, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	loc4 = *(EIF_REFERENCE *)(Current + O9258[dtype-1230]);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13357[Dtype(loc5)-1725])(loc5);
		F1231_11164(Current, loc2);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		} else {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13666[Dtype(RTCW(loc2))-1885])(loc2);
			if ((EIF_BOOLEAN) !tb1) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21527(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
			} else {
				loc3 = (EIF_REFERENCE) loc2;
				loc4 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
			}
		}
	}
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
	} else {
		tr1 = F1231_11526(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12779[Dtype(tr1)-1610]);
		tb1 = F1884_18234(RTCW(tr1), loc3, loc4, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
		if (tb1) {
			tr1 = F1231_11526(Current);
			loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12779[Dtype(tr1)-1610]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9218[dtype-1230])(Current, arg1, loc1);
		} else {
			tr1 = F1231_11526(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12780[Dtype(tr1)-1610]);
			tb1 = F1884_18234(RTCW(tr1), loc3, loc4, *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
			if (tb1) {
				tr1 = F1231_11526(Current);
				loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12780[Dtype(tr1)-1610]);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9219[dtype-1230])(Current, arg1, loc1);
			}
		}
	}
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
	} else {
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
		} else {
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				F1033_8331(Current);
				tr1 = F1023_8173(Current);
				F2046_21527(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
			} else {
				tr1 = F1231_11526(Current);
				loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12780[Dtype(tr1)-1610]);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9219[dtype-1230])(Current, arg1, loc1);
			}
		}
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1919_18904(RTCW(arg1), loc1);
		F899_7054(RTCW(arg2), loc1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_regular_integer_constant_validity */
void F1231_11267 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11236(Current, arg1, arg2);
}

/* {ET_FEATURE_CHECKER}.check_regular_manifest_string_validity */
void F1231_11268 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11244(Current, arg1, arg2);
}

/* {ET_FEATURE_CHECKER}.check_regular_real_constant_validity */
void F1231_11269 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11266(Current, arg1, arg2);
}

/* {ET_FEATURE_CHECKER}.check_result_validity */
void F1231_11270 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,tr3);
	RTLR(5,loc3);
	RTLR(6,loc1);
	RTLR(7,loc4);
	RTLR(8,arg2);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) == NULL) && *(EIF_BOOLEAN *)(Current + O9275[dtype-1230]))) {
		F1033_8331(Current);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) == *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
			tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
			if (tb1) {
				tr1 = F1023_8173(Current);
				tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
				tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
				tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
				F2046_21303(RTCW(tr1), tr2, arg1, tr3);
			} else {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		} else {
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		}
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) == NULL) && *(EIF_BOOLEAN *)(Current + O9277[dtype-1230]))) {
			F1033_8331(Current);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) == *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
				tr1 = F1023_8173(Current);
				F2046_21305(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
			} else {
				if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
					F2046_21728(RTCV(F1023_8173(Current)));
				}
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2902[Dtype(loc3)-1755])(loc3);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
				loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2902[Dtype(RTCW(tr1))-1755])(tr1);
			}
			if ((EIF_BOOLEAN)(loc1 == NULL)) {
				F1033_8331(Current);
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) == *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
					tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
					loc4 = tr1;
					if (EIF_TEST(loc4)) {
						tr1 = F1023_8173(Current);
						F2046_21308(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1, loc4);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
						if (tb1) {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
							tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
							F2046_21302(RTCW(tr1), tr2, arg1, tr3);
						} else {
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
				} else {
					if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
						F2046_21728(RTCV(F1023_8173(Current)));
					}
				}
			} else {
				F899_7054(RTCW(arg2), loc1);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
				tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
				if (tb1) {
					loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					tb1 = F2022_20355(RTCW(arg2));
					if ((EIF_BOOLEAN) !tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
						tb1 = F1250_11952(RTCW(tr1));
						if (tb1) {
							tr1 = RTOUCR(75,F396_4598, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
							F899_7054(RTCW(arg2), tr1);
						} else {
							loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
					} else {
						tb1 = '\0';
						if ((EIF_BOOLEAN) !(EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) == NULL) && *(EIF_BOOLEAN *)(Current + O9276[dtype-1230]))) {
							tb2 = '\0';
							tb3 = F2022_20357(RTCW(arg2));
							if ((EIF_BOOLEAN) !tb3) {
								tb3 = F2022_20351(RTCW(arg2));
								tb2 = (EIF_BOOLEAN) !tb3;
							}
							tb1 = tb2;
						}
						if (tb1) {
							tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
							tb1 = F1290_12726(RTCW(tr1));
							if (tb1) {
								tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
								tb1 = F1250_11952(RTCW(tr1));
								if ((EIF_BOOLEAN) !tb1) {
									tr1 = RTOUCR(604,F396_4599, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
									F899_7054(RTCW(arg2), tr1);
									loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								}
							} else {
								tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
								tb1 = F1250_11952(RTCW(tr1));
								if ((EIF_BOOLEAN) !tb1) {
									F1033_8331(Current);
									tr1 = F1023_8173(Current);
									F2046_21314(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
								}
							}
						}
					}
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R9220[dtype-1230])(Current, arg1, loc2);
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_result_address_validity */
void F1231_11271 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,loc5);
	RTLR(7,loc1);
	RTLR(8,loc6);
	RTLR(9,loc3);
	RTLR(10,loc2);
	RTLR(11,arg2);
	RTLR(12,loc4);
	RTLIU(13);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) == NULL) && *(EIF_BOOLEAN *)(Current + O9275[dtype-1230]))) {
		F1033_8331(Current);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) == *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
			tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
			if (tb1) {
				tr1 = F1023_8173(Current);
				tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
				tr3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
				tr4 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
				tr4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr4))-1840])(tr4);
				F2046_21303(RTCW(tr1), tr2, tr3, tr4);
			} else {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		} else {
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		}
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) == NULL) && *(EIF_BOOLEAN *)(Current + O9277[dtype-1230]))) {
			F1033_8331(Current);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) == *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
				tr1 = F1023_8173(Current);
				tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
				F2046_21305(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), tr2);
			} else {
				if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
					F2046_21728(RTCV(F1023_8173(Current)));
				}
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
			loc5 = tr1;
			if (EIF_TEST(loc5)) {
				loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2902[Dtype(loc5)-1755])(loc5);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
				loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2902[Dtype(RTCW(tr1))-1755])(tr1);
			}
			if ((EIF_BOOLEAN)(loc1 == NULL)) {
				F1033_8331(Current);
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) == *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
					tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
					loc6 = tr1;
					if (EIF_TEST(loc6)) {
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
						F2046_21307(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), tr2, loc6);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
						if (tb1) {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
							tr4 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
							tr4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr4))-1840])(tr4);
							F2046_21302(RTCW(tr1), tr2, tr3, tr4);
						} else {
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
				} else {
					if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
						F2046_21728(RTCV(F1023_8173(Current)));
					}
				}
			} else {
				tr1 = F1231_11526(Current);
				loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + O12801[Dtype(tr1)-1610]);
				loc2 = *(EIF_REFERENCE *)(RTCW(loc3) + O15311[Dtype(loc3)-2023]);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8089[Dtype(RTCW(loc2))-1585])(loc2);
				tb1 = F2027_20648(RTCW(tr1));
				if (tb1) {
					F899_7054(RTCW(arg2), loc1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9231[dtype-1230])(Current, arg1, loc3, arg2);
					F899_7054(RTCW(arg2), loc3);
				} else {
					tr1 = F1231_11526(Current);
					loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12775[Dtype(tr1)-1610]);
					F899_7054(RTCW(arg2), loc4);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9208[dtype-1230])(Current, arg1, loc4);
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_special_manifest_string_validity */
void F1231_11272 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11244(Current, arg1, arg2);
}

/* {ET_FEATURE_CHECKER}.check_static_call_expression_validity */
void F1231_11273 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(17);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,loc6);
	RTLR(5,arg2);
	RTLR(6,loc5);
	RTLR(7,loc1);
	RTLR(8,tr1);
	RTLR(9,loc15);
	RTLR(10,loc16);
	RTLR(11,loc17);
	RTLR(12,loc18);
	RTLR(13,loc14);
	RTLR(14,loc11);
	RTLR(15,loc12);
	RTLR(16,loc13);
	RTLIU(17);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc3 = F1785_17456(RTCW(arg1));
	loc4 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O14497[Dtype(loc3)-1943]);
	loc2 = F1786_17466(RTCW(arg1));
	F1231_11164(Current, loc2);
	loc6 = F1231_11337(Current);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F899_7054(RTCW(arg2), loc2);
		loc8 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_0_0_0_);
		F2023_20412(RTCW(arg2), loc6);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_4_0_0_1_);
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
		F1231_11334(Current, loc3, loc6, arg2);
	}
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F1231_11293(Current, arg1);
	} else {
		if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
			loc5 = F1541_13847(RTCW(loc6));
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc5))-1835])(loc5);
			tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
			F1037_8385(RTCW(tr1), loc7, loc5, arg2);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
				F1033_8331(Current);
				if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
					F2046_21728(RTCV(F1023_8173(Current)));
				}
				F1231_11293(Current, arg1);
			} else {
				tb1 = F2027_20678(RTCW(loc1));
				if (tb1) {
					F1231_11274(Current, arg1, loc5, arg2);
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1484[Dtype(RTCW(loc5))-1835])(loc5, loc3);
					loc15 = tr1;
					if (EIF_TEST(loc15)) {
						loc4 = *(EIF_INTEGER_32 *)(loc15 + O10400[Dtype(loc15)-1302]);
						F1944_19225(RTCW(loc3), loc4);
						F1231_11309(Current, arg1, loc15, loc1, arg2);
						if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						} else {
							tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
							loc16 = tr1;
							if (EIF_TEST(loc16)) {
								ti4_1 = *(EIF_INTEGER_32 *)(loc16+ _LNGOFF_3_0_0_0_);
								F1722_17132(RTCW(arg1), ti4_1);
							} else {
								F1231_11275(Current, arg1, loc15, loc1, arg2);
							}
						}
					} else {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1485[Dtype(RTCW(loc5))-1835])(loc5, loc3);
						loc17 = tr1;
						if (EIF_TEST(loc17)) {
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							F2046_21404(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc3, loc17, loc1);
							F1231_11293(Current, arg1);
						} else {
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							F2046_21498(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc3, loc1);
							F1231_11293(Current, arg1);
						}
					}
				}
			}
		} else {
			tb1 = F1432_13373(RTCW(loc6));
			if (tb1) {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
				F1231_11293(Current, arg1);
			} else {
				loc10 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_4_0_0_1_);
				loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc9 > loc10)) break;
					loc5 = F1541_13846(RTCW(loc6), loc9);
					loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc5))-1835])(loc5);
					tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
					F1037_8385(RTCW(tr1), loc7, loc5, arg2);
					tr1 = F2027_20747(RTCW(loc1), loc4);
					loc18 = tr1;
					if (EIF_TEST(loc18)) {
						F1231_11275(Current, arg1, loc18, loc1, arg2);
						loc14 = (EIF_REFERENCE) loc18;
					} else {
						tb1 = F2027_20576(RTCW(loc1));
						if (tb1) {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						} else {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						loc9 = (EIF_INTEGER_32) loc10;
					} else {
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc11 != NULL) && (EIF_BOOLEAN)(loc12 != NULL)) && (EIF_BOOLEAN)(loc13 != NULL)) && (EIF_BOOLEAN)(loc14 != NULL))) {
							tb1 = F2022_20367(RTCW(arg2), loc11);
							if ((EIF_BOOLEAN) !tb1) {
								F1033_8331(Current);
								tr1 = F1023_8173(Current);
								F2046_21386(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc3, loc13, loc12, loc14, loc5);
							}
						} else {
							if ((EIF_BOOLEAN) (loc10 > ((EIF_INTEGER_32) 1L))) {
								loc11 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
								F2023_20428(RTCW(loc11), arg2);
								loc12 = (EIF_REFERENCE) loc5;
								loc13 = (EIF_REFERENCE) loc14;
							}
						}
					}
					if ((EIF_BOOLEAN) (loc9 < loc10)) {
						F899_7059(RTCW(arg2), loc8);
					}
					loc9++;
				}
				if ((EIF_BOOLEAN)(loc11 != NULL)) {
					F1231_11572(Current, loc11);
				}
			}
		}
	}
	F1231_11338(Current, loc6);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_static_dotnet_query_call_expression_validity */
void F1231_11274 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg2);
	RTLR(3,loc3);
	RTLR(4,arg1);
	RTLR(5,loc5);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,arg3);
	RTLR(9,loc2);
	RTLR(10,loc6);
	RTLR(11,loc7);
	RTLIU(12);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(arg2))-1835])(arg2);
	loc3 = F1785_17456(RTCW(arg1));
	loc5 = F1231_11562(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1487[Dtype(RTCW(arg2))-1835])(arg2, loc3, loc5);
	tb1 = F1432_13373(RTCW(loc5));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = F1231_11336(Current, loc3, arg2);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
		F1231_11558(Current, loc5, tr1, tr2, arg3, (EIF_BOOLEAN) 1, (EIF_BOOLEAN) 0);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			F1231_11293(Current, arg1);
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_4_0_0_1_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
				loc2 = F1541_13847(RTCW(loc5));
				loc4 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O10400[Dtype(loc2)-1302]);
				F1944_19225(RTCW(loc3), loc4);
				F1231_11309(Current, arg1, loc2, loc1, arg3);
				if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				} else {
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
					loc6 = tr1;
					if (EIF_TEST(loc6)) {
						ti4_1 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_3_0_0_0_);
						F1722_17132(RTCW(arg1), ti4_1);
					} else {
						F1231_11275(Current, arg1, loc2, loc1, arg3);
					}
				}
			} else {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
				F1231_11293(Current, arg1);
			}
		}
	} else {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1485[Dtype(RTCW(arg2))-1835])(arg2, loc3);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21404(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc3, loc7, loc1);
			F1231_11293(Current, arg1);
		} else {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21498(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc3, loc1);
			F1231_11293(Current, arg1);
		}
	}
	F1231_11563(Current, loc5);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_static_query_call_expression_validity */
void F1231_11275 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLR(4,arg2);
	RTLR(5,tr1);
	RTLR(6,arg3);
	RTLR(7,arg4);
	RTLR(8,loc2);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc3 = F1785_17456(RTCW(arg1));
	loc1 = F1786_17466(RTCW(arg1));
	F1231_11419(Current, loc1, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9248[dtype-1230]));
	tb1 = F1837_17835(RTCW(arg2), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
	if ((EIF_BOOLEAN) !tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21499(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc3, arg2, arg3);
	}
	loc4 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	F1231_11294(Current, loc3, arg2, arg3);
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) (tb1 || loc4);
	F1231_11292(Current, arg1, arg4, arg2, arg3, NULL);
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) (tb1 || loc4);
	F1231_11276(Current, arg1, arg2, arg3);
	F1033_8332(Current, (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc4));
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		loc2 = F1839_17878(RTCW(arg2));
		F899_7054(RTCW(arg4), loc2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9223[dtype-1230])(Current, arg1, loc1, arg2);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_static_feature_validity */
void F1231_11276 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,arg1);
	RTLR(6,tr4);
	RTLR(7,arg3);
	RTLR(8,loc1);
	RTLR(9,loc2);
	RTLR(10,loc3);
	RTLIU(11);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13718[Dtype(RTCW(arg2))-1840])(arg2);
	if ((EIF_BOOLEAN) !tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
		tr4 = F1785_17456(RTCW(arg1));
		F2046_21500(RTCW(tr1), tr2, tr3, tr4, arg2, arg3);
	}
	tr1 = F1786_17466(RTCW(arg1));
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13940[Dtype(RTCW(tr1))-1885])(tr1);
	if (tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
		tr4 = F1786_17466(RTCW(arg1));
		F2046_21502(RTCW(tr1), tr2, tr3, tr4);
	}
	tb1 = F2027_20672(RTCW(arg3));
	if (tb1) {
		tb1 = '\0';
		loc1 = arg2;
		loc1 = RTRV(eif_new_type(1841, 0x01),loc1);
		if (EIF_TEST(loc1)) {
			tb2 = F1842_17907(loc1);
			tb1 = tb2;
		}
		if (tb1) {
		} else {
			tb1 = '\0';
			loc2 = arg2;
			loc2 = RTRV(eif_new_type(1840, 0x01),loc2);
			if (EIF_TEST(loc2)) {
				tb2 = F1841_17887(loc2);
				tb1 = tb2;
			}
			if (tb1) {
			} else {
				tb1 = '\0';
				loc3 = arg2;
				loc3 = RTRV(eif_new_type(1850, 0x01),loc3);
				if (EIF_TEST(loc3)) {
					tb2 = F1851_17953(loc3);
					tb1 = tb2;
				}
				if (tb1) {
				} else {
					F1033_8331(Current);
					tr1 = F1023_8173(Current);
					tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
					tr4 = F1786_17466(RTCW(arg1));
					F2046_21501(RTCW(tr1), tr2, tr3, tr4, arg3);
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_strip_expression_validity */
void F1231_11277 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,loc9);
	RTLR(4,tr1);
	RTLR(5,loc10);
	RTLR(6,loc2);
	RTLR(7,loc11);
	RTLR(8,arg2);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc6 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_0_);
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc4 > loc6)) break;
		loc1 = F1903_18668(RTCW(arg1), loc4);
		loc3 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O14497[Dtype(loc1)-1943]);
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
			loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
				F1033_8331(Current);
				if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
					F2046_21728(RTCV(F1023_8173(Current)));
				}
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
				tr1 = F2027_20744(RTCW(tr1), loc1);
				loc9 = tr1;
				if (EIF_TEST(loc9)) {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc9)-1840])(loc9);
					if ((EIF_BOOLEAN) !tb1) {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21531(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc1, loc9);
					} else {
						loc3 = *(EIF_INTEGER_32 *)(loc9 + O10400[Dtype(loc9)-1302]);
						F1944_19225(RTCW(loc1), loc3);
						loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr1 = F2027_20745(RTCW(tr1), loc1);
					loc10 = tr1;
					if (EIF_TEST(loc10)) {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21531(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc1, loc10);
					} else {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21530(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc1);
					}
				}
				loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc5 >= loc4)) break;
					loc2 = F1903_18668(RTCW(arg1), loc5);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R14586[Dtype(RTCW(loc1))-1951])(loc1, loc2);
					if (tb1) {
						loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21532(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc2, loc1);
					}
					loc5++;
				}
			}
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc7 && (EIF_BOOLEAN) !loc8)) {
			tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tr1 = F2027_20747(RTCW(tr1), loc3);
			loc11 = tr1;
			if ((EIF_BOOLEAN) !EIF_TEST(loc11)) {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
			} else {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc11)-1840])(loc11);
				if ((EIF_BOOLEAN) !tb1) {
					F1033_8331(Current);
					if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
						tr1 = F1023_8173(Current);
						F2046_21531(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc1, loc11);
					} else {
						if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
				}
			}
		}
		loc4++;
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12747[Dtype(tr1)-1610]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9227[dtype-1230])(Current, arg1, tr1, arg2);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12747[Dtype(tr1)-1610]);
		F899_7054(RTCW(arg2), tr1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_true_constant_validity */
void F1231_11278 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = F1231_11526(Current);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
	F899_7054(RTCW(arg2), loc1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9169[dtype-1230])(Current, arg1, loc1);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_underscored_integer_constant_validity */
void F1231_11279 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11236(Current, arg1, arg2);
}

/* {ET_FEATURE_CHECKER}.check_underscored_real_constant_validity */
void F1231_11280 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11266(Current, arg1, arg2);
}

/* {ET_FEATURE_CHECKER}.check_unqualified_call_expression_validity */
void F1231_11281 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc4);
	RTLR(4,arg2);
	RTLR(5,loc5);
	RTLR(6,tr1);
	RTLR(7,loc6);
	RTLR(8,loc7);
	RTLR(9,loc8);
	RTLIU(10);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13378[Dtype(RTCW(arg1))-1748])(arg1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O14497[Dtype(loc1)-1943]);
	loc4 = loc1;
	loc4 = RTRV(eif_new_type(1986, 0x01),loc4);
	if (EIF_TEST(loc4)) {
		tb1 = F1987_19667(loc4);
		if (tb1) {
			F1231_11282(Current, arg1, loc4, arg2);
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			tb1 = F1987_19663(loc4);
			if (tb1) {
				F1231_11284(Current, arg1, loc4, arg2);
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tb1 = F1987_19665(loc4);
				if (tb1) {
					F1231_11283(Current, arg1, loc4, arg2);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tb1 = F1987_19664(loc4);
					if (tb1) {
						F1231_11285(Current, arg1, loc4, arg2);
						loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
			}
		}
	}
	if (loc3) {
	} else {
		if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
				F1033_8331(Current);
				if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
					F2046_21728(RTCV(F1023_8173(Current)));
				}
				F1231_11293(Current, arg1);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
				tr1 = F2027_20744(RTCW(tr1), loc1);
				loc5 = tr1;
				if (EIF_TEST(loc5)) {
					loc2 = *(EIF_INTEGER_32 *)(loc5 + O10400[Dtype(loc5)-1302]);
					F1944_19225(RTCW(loc1), loc2);
					F1231_11305(Current, arg1, loc5, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg2, NULL);
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
					} else {
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
						loc6 = tr1;
						if (EIF_TEST(loc6)) {
							ti4_1 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_3_0_0_0_);
							F1722_17132(RTCW(arg1), ti4_1);
						} else {
							F1231_11286(Current, arg1, loc5, arg2);
						}
					}
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr1 = F2027_20745(RTCW(tr1), loc1);
					loc7 = tr1;
					if (EIF_TEST(loc7)) {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21405(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc1, loc7);
						F1231_11293(Current, arg1);
					} else {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21497(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc1);
						F1231_11293(Current, arg1);
					}
				}
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tr1 = F2027_20747(RTCW(tr1), loc2);
			loc8 = tr1;
			if (EIF_TEST(loc8)) {
				F1231_11286(Current, arg1, loc8, arg2);
			} else {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
				F1231_11293(Current, arg1);
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_unqualified_formal_argument_call_expression_validity */
void F1231_11282 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13379[Dtype(RTCW(arg1))-1748])(arg1);
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		F1231_11231(Current, arg2, arg3);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
			F1033_8331(Current);
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
			F1231_11293(Current, arg1);
		} else {
			F1231_11302(Current, arg1, arg2, arg3);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
				loc1 = tr1;
				if (EIF_TEST(loc1)) {
					ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_3_0_0_0_);
					F1722_17132(RTCW(arg1), ti4_1);
				} else {
					F1033_8331(Current);
					tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
					loc2 = tr1;
					if (EIF_TEST(loc2)) {
						tr1 = F1023_8173(Current);
						F2046_21551(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg2, loc2);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
						if (tb1) {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
							tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
							F2046_21550(RTCW(tr1), tr2, arg2, tr3);
						} else {
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
					F1231_11293(Current, arg1);
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_unqualified_iteration_cursor_call_expression_validity */
void F1231_11283 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13379[Dtype(RTCW(arg1))-1748])(arg1);
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		F1231_11238(Current, arg2, arg3);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
			F1033_8331(Current);
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
			F1231_11293(Current, arg1);
		} else {
			F1231_11304(Current, arg1, arg2, arg3);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
				loc1 = tr1;
				if (EIF_TEST(loc1)) {
					ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_3_0_0_0_);
					F1722_17132(RTCW(arg1), ti4_1);
				} else {
					F1033_8331(Current);
					tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
					loc2 = tr1;
					if (EIF_TEST(loc2)) {
						tr1 = F1023_8173(Current);
						F2046_21553(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg2, loc2);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
						if (tb1) {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
							tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
							F2046_21552(RTCW(tr1), tr2, arg2, tr3);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
							tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8703[Dtype(RTCW(tr1))-1840])(tr1);
							if (tb1) {
								tr1 = F1023_8173(Current);
								tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
								tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
								tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8714[Dtype(RTCW(tr3))-1840])(tr3);
								F2046_21554(RTCW(tr1), tr2, arg2, tr3);
							} else {
								F2046_21728(RTCV(F1023_8173(Current)));
							}
						}
					}
					F1231_11293(Current, arg1);
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_unqualified_local_variable_call_expression_validity */
void F1231_11284 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13379[Dtype(RTCW(arg1))-1748])(arg1);
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		F1231_11240(Current, arg2, arg3);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
			F1033_8331(Current);
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
			F1231_11293(Current, arg1);
		} else {
			F1231_11306(Current, arg1, arg2, arg3);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
				loc1 = tr1;
				if (EIF_TEST(loc1)) {
					ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_3_0_0_0_);
					F1722_17132(RTCW(arg1), ti4_1);
				} else {
					F1033_8331(Current);
					tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
					loc2 = tr1;
					if (EIF_TEST(loc2)) {
						tr1 = F1023_8173(Current);
						F2046_21556(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg2, loc2);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
						if (tb1) {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
							tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
							F2046_21555(RTCW(tr1), tr2, arg2, tr3);
						} else {
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
					F1231_11293(Current, arg1);
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_unqualified_object_test_local_call_expression_validity */
void F1231_11285 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13379[Dtype(RTCW(arg1))-1748])(arg1);
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		F1231_11250(Current, arg2, arg3);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
			F1033_8331(Current);
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
			F1231_11293(Current, arg1);
		} else {
			F1231_11307(Current, arg1, arg2, arg3);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
				loc1 = tr1;
				if (EIF_TEST(loc1)) {
					ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_3_0_0_0_);
					F1722_17132(RTCW(arg1), ti4_1);
				} else {
					F1033_8331(Current);
					tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
					loc2 = tr1;
					if (EIF_TEST(loc2)) {
						tr1 = F1023_8173(Current);
						F2046_21558(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg2, loc2);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
						if (tb1) {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
							tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
							F2046_21557(RTCW(tr1), tr2, arg2, tr3);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
							tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8703[Dtype(RTCW(tr1))-1840])(tr1);
							if (tb1) {
								tr1 = F1023_8173(Current);
								tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
								tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
								tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8714[Dtype(RTCW(tr3))-1840])(tr3);
								F2046_21559(RTCW(tr1), tr2, arg2, tr3);
							} else {
								F2046_21728(RTCV(F1023_8173(Current)));
							}
						}
					}
					F1231_11293(Current, arg1);
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_unqualified_query_call_expression_validity */
void F1231_11286 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13378[Dtype(RTCW(arg1))-1748])(arg1);
	tb1 = '\0';
	if (*(EIF_BOOLEAN *)(Current + O9280[dtype-1230])) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13718[Dtype(RTCW(arg2))-1840])(arg2);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21490(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1, arg2);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	F1231_11295(Current, loc1, arg2);
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 || tb1);
	F1231_11292(Current, arg1, arg3, arg2, NULL, NULL);
	F1033_8332(Current, (EIF_BOOLEAN) (loc2 || *(EIF_BOOLEAN *)(Current + O7067[dtype-1032])));
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9232[dtype-1230])(Current, arg1, arg2);
		loc2 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		F1231_11265(Current, arg1, arg2, arg3);
		F1033_8332(Current, (EIF_BOOLEAN) (loc2 || *(EIF_BOOLEAN *)(Current + O7067[dtype-1032])));
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_verbatim_string_validity */
void F1231_11287 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	F1231_11244(Current, arg1, arg2);
}

/* {ET_FEATURE_CHECKER}.check_void_validity */
void F1231_11288 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12774[Dtype(tr1)-1610]);
	F899_7054(RTCW(arg2), tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9236[dtype-1230])(Current, arg1);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_writable_validity */
void F1231_11289 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(18);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,arg1);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLR(5,loc5);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,arg2);
	RTLR(9,loc6);
	RTLR(10,loc7);
	RTLR(11,loc1);
	RTLR(12,loc8);
	RTLR(13,loc9);
	RTLR(14,loc10);
	RTLR(15,loc11);
	RTLR(16,loc12);
	RTLR(17,loc13);
	RTLIU(18);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc4 = arg1;
	loc4 = RTRV(eif_new_type(1925, 0x01),loc4);
	if (EIF_TEST(loc4)) {
		tr1 = F1231_11523(Current);
		loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2902[Dtype(RTCW(tr1))-1755])(tr1);
		if ((EIF_BOOLEAN)(loc3 == NULL)) {
			F1033_8331(Current);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) == *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
				tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
				loc5 = tr1;
				if (EIF_TEST(loc5)) {
					tr1 = F1023_8173(Current);
					F2046_21308(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc4, loc5);
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
					if (tb1) {
						tr1 = F1023_8173(Current);
						tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
						tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
						F2046_21302(RTCW(tr1), tr2, loc4, tr3);
					} else {
						F2046_21728(RTCV(F1023_8173(Current)));
					}
				}
			} else {
				if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
					F2046_21728(RTCV(F1023_8173(Current)));
				}
			}
		} else {
			F899_7054(RTCW(arg2), loc3);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				tb1 = '\0';
				tb2 = F2022_20357(RTCW(arg2));
				if ((EIF_BOOLEAN) !tb2) {
					tb2 = F2022_20351(RTCW(arg2));
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
					tb1 = F1290_12726(RTCW(tr1));
					if (tb1) {
						tr1 = RTOUCR(604,F396_4599, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F899_7054(RTCW(arg2), tr1);
					}
				}
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9221[dtype-1230])(Current, loc4);
		}
	} else {
		loc6 = arg1;
		loc6 = RTRV(eif_new_type(1986, 0x01),loc6);
		if (EIF_TEST(loc6)) {
			loc2 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_2_1_0_2_);
			tb1 = F1987_19663(loc6);
			if (tb1) {
				tr1 = F1231_11523(Current);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2905[Dtype(RTCW(tr1))-1755])(tr1);
				loc7 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc7)) {
					F1033_8331(Current);
					F2046_21728(RTCV(F1023_8173(Current)));
				} else {
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 1L))) {
						ti4_1 = *(EIF_INTEGER_32 *)(loc7+ _LNGOFF_2_0_0_0_);
						tb1 = (EIF_BOOLEAN) (loc2 > ti4_1);
					}
					if (tb1) {
						F1033_8331(Current);
						F2046_21728(RTCV(F1023_8173(Current)));
					} else {
						loc1 = F1634_16566(loc7, loc2);
						loc3 = F1810_17563(RTCW(loc1));
						F899_7054(RTCW(arg2), loc3);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
						tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
						if (tb1) {
							tb1 = '\0';
							tb2 = F2022_20357(RTCW(arg2));
							if ((EIF_BOOLEAN) !tb2) {
								tb2 = F2022_20351(RTCW(arg2));
								tb1 = (EIF_BOOLEAN) !tb2;
							}
							if (tb1) {
								tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
								tb1 = F1290_12726(RTCW(tr1));
								if (tb1) {
									tr1 = RTOUCR(604,F396_4599, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
									F899_7054(RTCW(arg2), tr1);
								}
							}
						}
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9193[dtype-1230])(Current, loc6, loc1);
					}
				}
			} else {
				if ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 0L))) {
					tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr1 = F2027_20747(RTCW(tr1), loc2);
					loc8 = tr1;
					if ((EIF_BOOLEAN) !EIF_TEST(loc8)) {
						F1033_8331(Current);
						F2046_21728(RTCV(F1023_8173(Current)));
					} else {
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc8)-1840])(loc8);
						if ((EIF_BOOLEAN) !tb1) {
							F1033_8331(Current);
							if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
								tr1 = F1023_8173(Current);
								F2046_21397(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc6, loc8);
							} else {
								if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
									F2046_21728(RTCV(F1023_8173(Current)));
								}
							}
						} else {
							loc3 = F1839_17878(loc8);
							F899_7054(RTCW(arg2), loc3);
							if (*(EIF_BOOLEAN *)(Current + O9280[dtype-1230])) {
								F1033_8331(Current);
								tr1 = F1023_8173(Current);
								F2046_21489(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc6, loc8);
							} else {
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9168[dtype-1230])(Current, arg1, loc8);
							}
						}
					}
				} else {
					if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
						F1033_8331(Current);
						if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
						tr1 = F2027_20744(RTCW(tr1), loc6);
						loc9 = tr1;
						if (EIF_TEST(loc9)) {
							tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc9)-1840])(loc9);
							if (tb1) {
								loc2 = *(EIF_INTEGER_32 *)(loc9 + O10400[Dtype(loc9)-1302]);
								F1944_19225(loc6, loc2);
								loc3 = F1839_17878(loc9);
								F899_7054(RTCW(arg2), loc3);
								if (*(EIF_BOOLEAN *)(Current + O9280[dtype-1230])) {
									F1033_8331(Current);
									tr1 = F1023_8173(Current);
									F2046_21489(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc6, loc9);
								} else {
									(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9168[dtype-1230])(Current, arg1, loc9);
								}
							} else {
								F1033_8331(Current);
								tr1 = F1023_8173(Current);
								F2046_21397(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc6, loc9);
							}
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr1 = F2027_20745(RTCW(tr1), loc6);
							loc10 = tr1;
							if (EIF_TEST(loc10)) {
								F1033_8331(Current);
								tr1 = F1023_8173(Current);
								F2046_21397(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc6, loc10);
							} else {
								F1033_8331(Current);
								tb1 = '\0';
								tr1 = F1231_11523(Current);
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2903[Dtype(RTCW(tr1))-1755])(tr1);
								loc11 = tr1;
								if (EIF_TEST(loc11)) {
									ti4_1 = F1649_16724(loc11, loc6);
									tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
								}
								if (tb1) {
									tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
									loc12 = tr1;
									if (EIF_TEST(loc12)) {
										tr1 = F1023_8173(Current);
										F2046_21399(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc6, loc12);
									} else {
										tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
										tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
										if (tb1) {
											tr1 = F1023_8173(Current);
											tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
											tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
											tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
											F2046_21398(RTCW(tr1), tr2, loc6, tr3);
										} else {
											F2046_21728(RTCV(F1023_8173(Current)));
										}
									}
								} else {
									tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
									loc13 = tr1;
									if (EIF_TEST(loc13)) {
										tr1 = F1023_8173(Current);
										F2046_21301(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc6, loc13);
									} else {
										tr1 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
										tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
										if (tb1) {
											tr1 = F1023_8173(Current);
											tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
											tr3 = *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
											tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr3))-1840])(tr3);
											F2046_21300(RTCW(tr1), tr2, loc6, tr3);
										} else {
											F2046_21728(RTCV(F1023_8173(Current)));
										}
									}
								}
							}
						}
					}
				}
			}
		} else {
			F1033_8331(Current);
			F2046_21728(RTCV(F1023_8173(Current)));
		}
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F1231_11416(Current, arg2, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9248[dtype-1230]));
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_expression_validity */
void F1231_11290 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg3);
	RTLR(3,loc1);
	RTLR(4,arg2);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc2 = *(EIF_REFERENCE *)(Current + O9258[dtype-1230]);
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + O9258[dtype-1230]) = (EIF_REFERENCE) arg3;
	loc1 = *(EIF_REFERENCE *)(Current + O9257[dtype-1230]);
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + O9257[dtype-1230]) = (EIF_REFERENCE) arg2;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13071[Dtype(RTCW(arg1))-1646])(arg1, Current);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F1231_11416(Current, arg2, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9248[dtype-1230]));
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + O9257[dtype-1230]) = (EIF_REFERENCE) loc1;
	RTAR(Current, loc2);
	*(EIF_REFERENCE *)(Current + O9258[dtype-1230]) = (EIF_REFERENCE) loc2;
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_actual_argument_validity */
void F1231_11291 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,arg5);
	RTLR(1,loc7);
	RTLR(2,arg4);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLR(5,Current);
	RTLR(6,tr1);
	RTLR(7,loc4);
	RTLR(8,arg1);
	RTLR(9,arg2);
	RTLR(10,arg3);
	RTLIU(11);
	
	RTGC;
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(arg5 == NULL)) {
		tb2 = F2027_20580(RTCW(arg5));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
	} else {
		tb1 = '\01';
		loc7 = arg4;
		loc7 = RTRV(eif_new_type(1800, 0x01),loc7);
		if (!((EIF_BOOLEAN) !EIF_TEST(loc7))) {
			tb2 = *(EIF_BOOLEAN *)(loc7+ _CHROFF_3_0_);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
		} else {
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13531[Dtype(RTCW(arg4))-1780])(arg4);
			tb1 = '\01';
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14508[Dtype(RTCW(loc2))-1944])(loc2);
			if (!tb2) {
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14514[Dtype(RTCW(loc2))-1944])(loc2);
				tb1 = tb2;
			}
			if (tb1) {
				loc1 = *(EIF_REFERENCE *)(loc7);
				tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
				loc3 = F10_115(RTCW(tr1));
				tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
				F1034_8335(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9260[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
				tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
				loc6 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
				loc4 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
				tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
				if (tb1) {
					tr1 = F1231_11539(Current);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
					tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
					F1250_11971(RTCW(tr1), loc4);
					tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
					F260_2862(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
				}
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14520[Dtype(RTCW(loc2))-1944])(loc2);
				if (tb1) {
					loc1 = *(EIF_REFERENCE *)(loc7);
					tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
					loc3 = F10_115(RTCW(tr1));
					tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
					F1034_8336(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9260[dtype-1230]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
					tr1 = *(EIF_REFERENCE *)(Current + O9261[dtype-1230]);
					loc6 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
					loc4 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
					tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
					if (tb1) {
						tr1 = F1231_11539(Current);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
						tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
						F1250_11971(RTCW(tr1), loc4);
						tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
						F260_2863(RTCW(tr1), loc1, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
					}
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				}
			}
		}
	}
	F1231_11290(Current, arg1, arg2, arg3);
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc6 || *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]));
	if (loc5) {
		tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
		F10_119(RTCW(tr1), loc3);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
			RTAR(Current, loc4);
			*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc4;
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_actual_arguments_validity */
void F1231_11292 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc13 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc14 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc15 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc22 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc24 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc25 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc26 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc27 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc28 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc29 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	RTCDT;
	RTLD;
	
	RTLI(33);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLR(4,loc5);
	RTLR(5,arg3);
	RTLR(6,loc18);
	RTLR(7,loc19);
	RTLR(8,tr1);
	RTLR(9,arg2);
	RTLR(10,arg4);
	RTLR(11,arg5);
	RTLR(12,tr2);
	RTLR(13,tr3);
	RTLR(14,loc20);
	RTLR(15,loc21);
	RTLR(16,loc12);
	RTLR(17,loc11);
	RTLR(18,loc23);
	RTLR(19,loc4);
	RTLR(20,loc3);
	RTLR(21,loc6);
	RTLR(22,loc24);
	RTLR(23,loc25);
	RTLR(24,loc26);
	RTLR(25,loc27);
	RTLR(26,loc17);
	RTLR(27,loc16);
	RTLR(28,loc28);
	RTLR(29,loc29);
	RTLR(30,loc9);
	RTLR(31,loc10);
	RTLR(32,tr4);
	RTLIU(33);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13531[Dtype(RTCW(arg1))-1780])(arg1);
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13532[Dtype(RTCW(arg1))-1780])(arg1);
	loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10399[Dtype(RTCW(arg3))-1840])(arg3);
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(loc1 == NULL)) {
		tb2 = F255_2406(RTCW(loc1));
		tb1 = tb2;
	}
	if (tb1) {
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			tb2 = F1003_7573(RTCW(loc5));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
				tb1 = '\0';
				tb2 = '\0';
				loc18 = arg1;
				loc18 = RTRV(eif_new_type(1781, 0x01),loc18);
				if (EIF_TEST(loc18)) {
					tr1 = *(EIF_REFERENCE *)(loc18);
					loc19 = tr1;
					loc19 = RTRV(eif_new_type(1819, 0x01),loc19);
					tb2 = (EIF_BOOLEAN) !EIF_TEST(loc19);
				}
				if (tb2) {
					tb1 = (EIF_BOOLEAN)(F1231_11341(Current, loc5, arg2) == ((EIF_INTEGER_32) 1L));
				}
				if (tb1) {
					tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_4_0_0_1_0_0_0_0_);
					F1820_17645(RTCW(tr1), NULL, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
					F1782_17434(loc18, tr1);
					F1231_11292(Current, loc18, arg2, arg3, arg4, arg5);
				} else {
					F1033_8331(Current);
					if ((EIF_BOOLEAN)(arg4 != NULL)) {
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14534[Dtype(RTCW(loc2))-1944])(loc2);
						if (tb1) {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14536[Dtype(RTCW(loc2))-1944])(loc2);
							F2046_21272(RTCW(tr1), tr2, tr3, arg3, arg4);
						} else {
							tr1 = F1023_8173(Current);
							F2046_21481(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc2, arg3, arg4);
						}
					} else {
						tr1 = F1023_8173(Current);
						F2046_21482(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc2, arg3);
					}
				}
			} else {
				F1033_8331(Current);
				if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
					F2046_21728(RTCV(F1023_8173(Current)));
				}
			}
		}
	} else {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc5 == NULL)) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_3_0_0_0_);
			ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2266[Dtype(RTCW(loc1))-899])(loc1);
			tb1 = (EIF_BOOLEAN)(ti4_1 != ti4_2);
		}
		if (tb1) {
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
				tb1 = '\0';
				tb2 = '\0';
				tb3 = '\0';
				tb4 = '\0';
				tb5 = '\0';
				if ((EIF_BOOLEAN)(loc5 != NULL)) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_3_0_0_0_);
					ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2266[Dtype(RTCW(loc1))-899])(loc1);
					tb5 = (EIF_BOOLEAN) (ti4_1 <= (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)));
				}
				if (tb5) {
					loc20 = arg1;
					loc20 = RTRV(eif_new_type(1781, 0x01),loc20);
					tb4 = EIF_TEST(loc20);
				}
				if (tb4) {
					tr1 = *(EIF_REFERENCE *)(loc20);
					loc21 = tr1;
					loc21 = RTRV(eif_new_type(1819, 0x01),loc21);
					tb3 = (EIF_BOOLEAN) !EIF_TEST(loc21);
				}
				if (tb3) {
					loc22 = F1231_11341(Current, loc5, arg2);
					tb2 = (EIF_TRUE);
				}
				if (tb2) {
					tb1 = (EIF_BOOLEAN) (loc22 > ((EIF_INTEGER_32) 0L));
				}
				if (tb1) {
					tr1 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_4_0_0_1_0_0_0_0_);
					tr2 = *(EIF_REFERENCE *)(loc20);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_3_0_0_0_);
					F1820_17645(RTCW(tr1), tr2, loc22, ti4_1);
					F1782_17434(loc20, tr1);
					F1231_11292(Current, loc20, arg2, arg3, arg4, arg5);
				} else {
					F1033_8331(Current);
					if ((EIF_BOOLEAN)(arg4 != NULL)) {
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14534[Dtype(RTCW(loc2))-1944])(loc2);
						if (tb1) {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14536[Dtype(RTCW(loc2))-1944])(loc2);
							F2046_21272(RTCW(tr1), tr2, tr3, arg3, arg4);
						} else {
							tr1 = F1023_8173(Current);
							F2046_21481(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc2, arg3, arg4);
						}
					} else {
						tr1 = F1023_8173(Current);
						F2046_21482(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc2, arg3);
					}
				}
			} else {
				F1033_8331(Current);
				if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
					F2046_21728(RTCV(F1023_8173(Current)));
				}
			}
		} else {
			loc14 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			loc12 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			loc11 = (EIF_REFERENCE) arg2;
			loc23 = loc1;
			loc23 = RTRV(eif_new_type(1818, 0x01),loc23);
			if (EIF_TEST(loc23)) {
				loc4 = (EIF_REFERENCE) loc23;
			}
			loc8 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2266[Dtype(RTCW(loc1))-899])(loc1);
			loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc7 > loc8)) break;
				loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2265[Dtype(RTCW(loc1))-899])(loc1, loc7);
				loc6 = F1649_16721(RTCW(loc5), loc7);
				tr1 = F1814_17596(RTCW(loc6));
				F899_7054(RTCW(loc11), tr1);
				F1231_11291(Current, loc3, loc12, loc11, arg1, arg4);
				loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
					loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tb1 = F2022_20379(RTCW(loc12), loc11, *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
					if (tb1) {
					} else {
						if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) != *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
							loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							tb1 = '\0';
							tr1 = F1231_11340(Current, loc3, loc12, loc11);
							loc24 = tr1;
							if (EIF_TEST(loc24)) {
								tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
							}
							if (tb1) {
								if ((EIF_BOOLEAN)(loc4 != NULL)) {
									tr1 = F1003_7568(RTCW(loc4), loc7);
									loc25 = tr1;
									loc25 = RTRV(eif_new_type(1684, 0x01),loc25);
									if (EIF_TEST(loc25)) {
										(RTNA((loc25, loc24)));
									} else {
										F1003_7578(RTCW(loc4), loc24, loc7);
									}
								} else {
									loc26 = arg1;
									loc26 = RTRV(eif_new_type(1800, 0x01),loc26);
									if (EIF_TEST(loc26)) {
										F1767_17369(loc26, loc24);
									} else {
										loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									}
								}
							} else {
								if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
									loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								} else {
									loc27 = arg1;
									loc27 = RTRV(eif_new_type(1800, 0x01),loc27);
									if (EIF_TEST(loc27)) {
										loc17 = (EIF_REFERENCE) arg4;
										RTCT0("qualified_call", EX_CHECK);
										if ((EIF_BOOLEAN)(loc17 != NULL)) {
											RTCK0;
										} else {
											RTCF0;
										}
										F899_7057(RTCW(loc11));
										loc16 = *(EIF_REFERENCE *)(loc27);
										F1231_11220(Current, loc27, loc17, arg2, loc12, arg5);
										tr1 = F1814_17596(RTCW(loc6));
										F899_7054(RTCW(loc11), tr1);
										tr1 = *(EIF_REFERENCE *)(loc27);
										if ((EIF_BOOLEAN)(loc16 == tr1)) {
											loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
										}
									} else {
										if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc14 < ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230])))) {
											F899_7057(RTCW(loc11));
											loc14 = F1231_11341(Current, loc5, arg2);
											tr1 = F1814_17596(RTCW(loc6));
											F899_7054(RTCW(loc11), tr1);
										}
										tb1 = '\0';
										loc28 = arg1;
										loc28 = RTRV(eif_new_type(1781, 0x01),loc28);
										if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc14 == loc7) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) && EIF_TEST(loc28))) {
											tr1 = *(EIF_REFERENCE *)(loc28);
											loc29 = tr1;
											loc29 = RTRV(eif_new_type(1819, 0x01),loc29);
											tb1 = (EIF_BOOLEAN) !EIF_TEST(loc29);
										}
										if (tb1) {
											loc4 = RTLNS(eif_new_type(1819, 0x01).id, 1819, _OBJSIZ_4_0_0_1_0_0_0_0_);
											tr1 = *(EIF_REFERENCE *)(loc28);
											F1820_17645(RTCW(loc4), tr1, loc14, loc8);
											loc1 = (EIF_REFERENCE) loc4;
											F1782_17434(loc28, loc4);
											loc7--;
										} else {
											loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
										}
									}
								}
							}
						}
					}
				}
				if (loc15) {
					loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					F1033_8331(Current);
					loc9 = F2022_20345(RTCW(loc12));
					loc10 = F2022_20345(RTCW(loc11));
					if ((EIF_BOOLEAN)(arg4 != NULL)) {
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14534[Dtype(RTCW(loc2))-1944])(loc2);
						if (tb1) {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
							tr4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14536[Dtype(RTCW(loc2))-1944])(loc2);
							F2046_21273(RTCW(tr1), tr2, tr3, tr4, arg3, arg4, loc7, loc9, loc10);
						} else {
							tr1 = F1023_8173(Current);
							F2046_21484(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc2, arg3, arg4, loc7, loc9, loc10);
						}
					} else {
						tr1 = F1023_8173(Current);
						F2046_21485(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc2, arg3, loc7, loc9, loc10);
					}
				}
				F899_7057(RTCW(loc11));
				F899_7060(RTCW(loc12));
				loc7++;
			}
			F1231_11572(Current, loc12);
			if (loc13) {
				F1033_8331(Current);
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_orphan_actual_arguments_validity */
void F1231_11293 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc5);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13532[Dtype(RTCW(arg1))-1780])(arg1);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		tb2 = F255_2406(loc5);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + O12741[Dtype(tr1)-1610]);
		loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
		loc4 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2266[Dtype(loc5)-899])(loc5);
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc3 > loc4)) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2265[Dtype(loc5)-899])(loc5, loc3);
			F1231_11290(Current, tr1, loc1, loc2);
			F899_7060(RTCW(loc1));
			loc3++;
		}
		F1231_11572(Current, loc1);
	}
	F1033_8331(Current);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_qualified_vape_validity */
void F1231_11294 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,arg1);
	RTLR(7,arg3);
	RTLR(8,tr4);
	RTLR(9,tr5);
	RTLIU(10);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tb1 = '\0';
	if (*(EIF_BOOLEAN *)(Current + O9275[dtype-1230])) {
		tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
		tb1 = tb2;
	}
	if (tb1) {
		loc1 = *(EIF_REFERENCE *)(Current + O9122[dtype-1230]);
		F1003_7583(RTCW(loc1));
		tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8707[Dtype(RTCW(tr1))-1840])(tr1);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg2) + O13759[Dtype(arg2)-1836]);
		F1231_11298(Current, tr1, tr2, loc1);
		loc3 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O6364[Dtype(loc1)-1002]);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc2 > loc3)) break;
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
			tr4 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
			tr4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr4))-1840])(tr4);
			tr5 = F1004_7594(RTCW(loc1), loc2);
			F2046_21248(RTCW(tr1), tr2, tr3, arg1, arg2, arg3, tr4, tr5);
			loc2++;
		}
		F1003_7583(RTCW(loc1));
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_unqualified_vape_validity */
void F1231_11295 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,arg1);
	RTLR(7,tr4);
	RTLR(8,tr5);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tb1 = '\0';
	if (*(EIF_BOOLEAN *)(Current + O9275[dtype-1230])) {
		tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
		tb1 = tb2;
	}
	if (tb1) {
		loc1 = *(EIF_REFERENCE *)(Current + O9122[dtype-1230]);
		F1003_7583(RTCW(loc1));
		tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8707[Dtype(RTCW(tr1))-1840])(tr1);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg2) + O13759[Dtype(arg2)-1836]);
		F1231_11298(Current, tr1, tr2, loc1);
		loc3 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O6364[Dtype(loc1)-1002]);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc2 > loc3)) break;
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
			tr4 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
			tr4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr4))-1840])(tr4);
			tr5 = F1004_7594(RTCW(loc1), loc2);
			F2046_21247(RTCW(tr1), tr2, tr3, arg1, arg2, tr4, tr5);
			loc2++;
		}
		F1003_7583(RTCW(loc1));
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_creation_vape_validity */
void F1231_11296 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLR(5,loc2);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLR(8,arg1);
	RTLR(9,tr4);
	RTLR(10,tr5);
	RTLIU(11);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tb1 = '\0';
	if (*(EIF_BOOLEAN *)(Current + O9275[dtype-1230])) {
		tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
		tb1 = tb2;
	}
	if (tb1) {
		loc1 = *(EIF_REFERENCE *)(Current + O9123[dtype-1230]);
		F1003_7583(RTCW(loc1));
		F1837_17839(RTCW(arg2), loc1, arg3, *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
		loc2 = *(EIF_REFERENCE *)(Current + O9122[dtype-1230]);
		F1003_7583(RTCW(loc2));
		tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8707[Dtype(RTCW(tr1))-1840])(tr1);
		F1231_11298(Current, tr1, loc1, loc2);
		F1003_7583(RTCW(loc1));
		loc4 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O6364[Dtype(loc2)-1002]);
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc3 > loc4)) break;
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
			tr4 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
			tr4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr4))-1840])(tr4);
			tr5 = F1004_7594(RTCW(loc2), loc3);
			F2046_21249(RTCW(tr1), tr2, tr3, arg1, arg2, arg3, tr4, tr5);
			loc3++;
		}
		F1003_7583(RTCW(loc2));
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_formal_parameter_creation_vape_validity */
void F1231_11297 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,arg1);
	RTLR(8,arg2);
	RTLR(9,arg3);
	RTLR(10,tr4);
	RTLR(11,tr5);
	RTLIU(12);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tb1 = '\0';
	if (*(EIF_BOOLEAN *)(Current + O9275[dtype-1230])) {
		tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8702[Dtype(RTCW(tr1))-1840])(tr1);
		tb1 = tb2;
	}
	if (tb1) {
		loc1 = *(EIF_REFERENCE *)(Current + O9123[dtype-1230]);
		F1003_7583(RTCW(loc1));
		loc2 = *(EIF_REFERENCE *)(Current + O9124[dtype-1230]);
		tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		F1654_16764(RTCW(loc2), tr1, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]));
		F1003_7577(RTCW(loc1), loc2);
		loc3 = *(EIF_REFERENCE *)(Current + O9122[dtype-1230]);
		F1003_7583(RTCW(loc3));
		tr1 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8707[Dtype(RTCW(tr1))-1840])(tr1);
		F1231_11298(Current, tr1, loc1, loc3);
		F1003_7583(RTCW(loc1));
		tr1 = RTOUCR(5,F396_5268, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		tr2 = RTOUCR(5,F396_5268, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		F1654_16764(RTCW(loc2), tr1, tr2);
		loc5 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O6364[Dtype(loc3)-1002]);
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc4 > loc5)) break;
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
			tr4 = *(EIF_REFERENCE *)(Current + O9248[dtype-1230]);
			tr4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8713[Dtype(RTCW(tr4))-1840])(tr4);
			tr5 = F1004_7594(RTCW(loc3), loc4);
			F2046_21250(RTCW(tr1), tr2, tr3, arg1, arg2, arg3, tr4, tr5);
			loc4++;
		}
		F1003_7583(RTCW(loc3));
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.add_non_descendant_caller_clients_to */
void F1231_11298 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	loc5 = F1004_7596(RTCW(arg2));
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O6364[Dtype(arg1)-1002]);
	loc3 = (EIF_INTEGER_32) loc4;
	for (;;) {
		if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 1L))) break;
		loc1 = F1004_7594(RTCW(arg1), loc3);
		loc2 = F1654_16767(RTCW(loc1));
		tb1 = F2027_20576(RTCW(loc2));
		if (tb1) {
		} else {
			tb1 = F2027_20607(RTCW(loc2));
			if (tb1) {
			} else {
				tb1 = F1004_7598(RTCW(arg2), loc2, *(EIF_REFERENCE *)(Current + O6923[Dtype(Current)-1022]));
				if (tb1) {
				} else {
					tb1 = '\0';
					tb2 = F2027_20662(RTCW(loc2));
					if ((EIF_BOOLEAN) !tb2) {
						tb1 = (EIF_BOOLEAN) !loc5;
					}
					if (tb1) {
					} else {
						tb1 = F2027_20726(RTCW(loc2));
						if (tb1) {
						} else {
							F1003_7577(RTCW(arg3), loc1);
						}
					}
				}
			}
		}
		loc3--;
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_formal_argument_parenthesis_call_validity */
void F1231_11302 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,arg2);
	RTLR(6,arg3);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1791, 0x01),loc1);
	if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
	} else {
		tb1 = '\01';
		tr1 = *(EIF_REFERENCE *)(loc1);
		loc2 = tr1;
		if (!((EIF_BOOLEAN) !EIF_TEST(loc2))) {
			tb2 = F255_2406(loc2);
			tb1 = tb2;
		}
		if (tb1) {
		} else {
			F1231_11231(Current, arg2, arg3);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				F1231_11293(Current, arg1);
			} else {
				F1231_11303(Current, loc1, arg2, loc2, arg3);
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_identifier_parenthesis_call_validity */
void F1231_11303 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,arg3);
	RTLR(3,loc3);
	RTLR(4,arg4);
	RTLR(5,loc2);
	RTLR(6,arg1);
	RTLR(7,loc1);
	RTLR(8,tr1);
	RTLR(9,loc6);
	RTLR(10,arg2);
	RTLR(11,loc7);
	RTLR(12,loc8);
	RTLIU(13);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc5 = RTLNS(eif_new_type(1944, 0x01).id, 1944, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1917_18826(RTCW(loc5));
	F1231_11311(Current, loc5, arg3);
	loc3 = F1231_11337(Current);
	F2023_20412(RTCW(arg4), loc3);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_4_0_0_1_);
	loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
	F1231_11334(Current, loc5, loc3, arg4);
	loc2 = F1541_13847(RTCW(loc3));
	F1231_11338(Current, loc3);
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F1231_11293(Current, arg1);
	} else {
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc2))-1835])(loc2);
		tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_10_);
		F2027_20822(RTCW(loc1), tr1);
		tb1 = F2027_20787(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			F1033_8331(Current);
			F1231_11293(Current, arg1);
		} else {
			tr1 = F140_1508(RTCW(loc2), loc5);
			loc6 = tr1;
			if (EIF_TEST(loc6)) {
				ti4_1 = *(EIF_INTEGER_32 *)(loc6 + O10400[Dtype(loc6)-1302]);
				F1944_19225(RTCW(loc5), ti4_1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13563[Dtype(RTCW(arg1))-1794])(arg1, arg2, loc5, arg3);
				tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
				F1037_8385(RTCW(tr1), loc4, loc2, arg4);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
				loc7 = tr1;
				loc7 = RTRV(eif_new_type(1982, 0x01),loc7);
				if (EIF_TEST(loc7)) {
					F1231_11195(Current, loc7, loc6, loc1, arg4);
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(RTCW(arg1))-1794])(arg1);
					loc8 = tr1;
					loc8 = RTRV(eif_new_type(1799, 0x01),loc8);
					if (EIF_TEST(loc8)) {
						F1231_11261(Current, loc8, loc6, loc1, arg4, NULL);
					} else {
						F1033_8331(Current);
						F2046_21728(RTCV(F1023_8173(Current)));
						F1231_11293(Current, arg1);
					}
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_iteration_cursor_parenthesis_call_validity */
void F1231_11304 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,arg2);
	RTLR(6,arg3);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1791, 0x01),loc1);
	if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
	} else {
		tb1 = '\01';
		tr1 = *(EIF_REFERENCE *)(loc1);
		loc2 = tr1;
		if (!((EIF_BOOLEAN) !EIF_TEST(loc2))) {
			tb2 = F255_2406(loc2);
			tb1 = tb2;
		}
		if (tb1) {
		} else {
			F1231_11238(Current, arg2, arg3);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				F1231_11293(Current, arg1);
			} else {
				F1231_11303(Current, loc1, arg2, loc2, arg3);
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_query_parenthesis_call_validity */
void F1231_11305 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(19);
	RTLR(0,Current);
	RTLR(1,loc9);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLR(4,arg2);
	RTLR(5,loc6);
	RTLR(6,arg4);
	RTLR(7,tr1);
	RTLR(8,loc4);
	RTLR(9,loc3);
	RTLR(10,loc2);
	RTLR(11,loc10);
	RTLR(12,loc11);
	RTLR(13,loc7);
	RTLR(14,arg3);
	RTLR(15,loc8);
	RTLR(16,loc12);
	RTLR(17,loc13);
	RTLR(18,arg5);
	RTLIU(19);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc9 = arg1;
	loc9 = RTRV(eif_new_type(1791, 0x01),loc9);
	if (EIF_TEST(loc9)) {
		loc1 = *(EIF_REFERENCE *)(loc9);
		tb1 = '\0';
		ti4_1 = F1837_17834(RTCW(arg2));
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
			tb2 = '\0';
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O6364[Dtype(loc1)-1002]);
				tb2 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
			}
			tb1 = tb2;
		}
		if (tb1) {
			loc6 = RTLNS(eif_new_type(1944, 0x01).id, 1944, _OBJSIZ_1_1_0_2_0_0_0_0_);
			F1917_18826(RTCW(loc6));
			F1231_11311(Current, loc6, loc1);
			tr1 = F1839_17878(RTCW(arg2));
			F899_7054(RTCW(arg4), tr1);
			loc4 = F1231_11337(Current);
			F2023_20412(RTCW(arg4), loc4);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_4_0_0_1_);
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
			F1231_11334(Current, loc6, loc4, arg4);
			loc3 = F1541_13847(RTCW(loc4));
			F1231_11338(Current, loc4);
			F899_7057(RTCW(arg4));
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				F1231_11293(Current, arg1);
			} else {
				loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc3))-1835])(loc3);
				tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_10_);
				F2027_20822(RTCW(loc2), tr1);
				tb1 = F2027_20787(RTCW(loc2));
				if ((EIF_BOOLEAN) !tb1) {
					F1033_8331(Current);
					F1231_11293(Current, arg1);
				} else {
					tr1 = F140_1508(RTCW(loc3), loc6);
					loc10 = tr1;
					if (EIF_TEST(loc10)) {
						ti4_1 = *(EIF_INTEGER_32 *)(loc10 + O10400[Dtype(loc10)-1302]);
						F1944_19225(RTCW(loc6), ti4_1);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13377[Dtype(loc9)-1748])(loc9);
						loc11 = tr1;
						if (EIF_TEST(loc11)) {
							loc7 = RTLNS(eif_new_type(1803, 0x01).id, 1803, _OBJSIZ_4_0_0_1_0_0_0_0_);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13378[Dtype(loc9)-1748])(loc9);
							F1798_17504(RTCW(loc7), loc11, tr1, NULL);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13563[Dtype(loc9)-1794])(loc9, loc7, loc6, loc1);
							F1231_11262(Current, loc7, arg2, arg3, arg4, NULL);
						} else {
							loc8 = RTLNS(eif_new_type(1794, 0x01).id, 1794, _OBJSIZ_3_0_0_1_0_0_0_0_);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13378[Dtype(loc9)-1748])(loc9);
							F1794_17486(RTCW(loc8), tr1, NULL);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13563[Dtype(loc9)-1794])(loc9, loc8, loc6, loc1);
							F1231_11286(Current, loc8, arg2, arg4);
						}
						tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
						F1037_8385(RTCW(tr1), loc5, loc3, arg4);
						if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
							F1231_11293(Current, arg1);
						} else {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(loc9)-1794])(loc9);
							loc12 = tr1;
							loc12 = RTRV(eif_new_type(1982, 0x01),loc12);
							if (EIF_TEST(loc12)) {
								F1231_11195(Current, loc12, loc10, loc2, arg4);
							} else {
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(loc9)-1794])(loc9);
								loc13 = tr1;
								loc13 = RTRV(eif_new_type(1799, 0x01),loc13);
								if (EIF_TEST(loc13)) {
									F1231_11261(Current, loc13, loc10, loc2, arg4, arg5);
								} else {
									F1033_8331(Current);
									F2046_21728(RTCV(F1023_8173(Current)));
									F1231_11293(Current, arg1);
								}
							}
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_local_variable_parenthesis_call_validity */
void F1231_11306 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,arg2);
	RTLR(6,arg3);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1791, 0x01),loc1);
	if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
	} else {
		tb1 = '\01';
		tr1 = *(EIF_REFERENCE *)(loc1);
		loc2 = tr1;
		if (!((EIF_BOOLEAN) !EIF_TEST(loc2))) {
			tb2 = F255_2406(loc2);
			tb1 = tb2;
		}
		if (tb1) {
		} else {
			F1231_11240(Current, arg2, arg3);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				F1231_11293(Current, arg1);
			} else {
				F1231_11303(Current, loc1, arg2, loc2, arg3);
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_object_test_local_parenthesis_call_validity */
void F1231_11307 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,arg2);
	RTLR(6,arg3);
	RTLIU(7);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1791, 0x01),loc1);
	if ((EIF_BOOLEAN) !EIF_TEST(loc1)) {
	} else {
		tb1 = '\01';
		tr1 = *(EIF_REFERENCE *)(loc1);
		loc2 = tr1;
		if (!((EIF_BOOLEAN) !EIF_TEST(loc2))) {
			tb2 = F255_2406(loc2);
			tb1 = tb2;
		}
		if (tb1) {
		} else {
			F1231_11250(Current, arg2, arg3);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				F1231_11293(Current, arg1);
			} else {
				F1231_11303(Current, loc1, arg2, loc2, arg3);
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_precursor_parenthesis_call_validity */
void F1231_11308 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc6);
	RTLR(5,arg5);
	RTLR(6,tr1);
	RTLR(7,loc4);
	RTLR(8,loc3);
	RTLR(9,loc2);
	RTLR(10,loc8);
	RTLR(11,loc7);
	RTLR(12,arg3);
	RTLR(13,arg4);
	RTLR(14,loc9);
	RTLR(15,loc10);
	RTLIU(16);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1));
	tb1 = '\0';
	ti4_1 = F1837_17834(RTCW(arg2));
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		tb2 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O6364[Dtype(loc1)-1002]);
			tb2 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
		}
		tb1 = tb2;
	}
	if (tb1) {
		loc6 = RTLNS(eif_new_type(1944, 0x01).id, 1944, _OBJSIZ_1_1_0_2_0_0_0_0_);
		F1917_18826(RTCW(loc6));
		F1231_11311(Current, loc6, loc1);
		tr1 = F1839_17878(RTCW(arg2));
		F899_7054(RTCW(arg5), tr1);
		loc4 = F1231_11337(Current);
		F2023_20412(RTCW(arg5), loc4);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_4_0_0_1_);
		loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
		F1231_11334(Current, loc6, loc4, arg5);
		loc3 = F1541_13847(RTCW(loc4));
		F1231_11338(Current, loc4);
		F899_7057(RTCW(arg5));
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			F1231_11293(Current, arg1);
		} else {
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc3))-1835])(loc3);
			tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_10_);
			F2027_20822(RTCW(loc2), tr1);
			tb1 = F2027_20787(RTCW(loc2));
			if ((EIF_BOOLEAN) !tb1) {
				F1033_8331(Current);
				F1231_11293(Current, arg1);
			} else {
				tr1 = F140_1508(RTCW(loc3), loc6);
				loc8 = tr1;
				if (EIF_TEST(loc8)) {
					loc7 = RTLNS(eif_new_type(1783, 0x01).id, 1783, _OBJSIZ_5_1_0_1_0_0_0_0_);
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
					F1783_17435(RTCW(loc7), tr1, NULL);
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
					F1783_17445(RTCW(loc7), tr1);
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
					F1783_17444(RTCW(loc7), tr1);
					ti4_1 = *(EIF_INTEGER_32 *)(loc8 + O10400[Dtype(loc8)-1302]);
					F1944_19225(RTCW(loc6), ti4_1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13547[Dtype(RTCW(arg1))-1783])(arg1, loc7, loc6, loc1);
					F1231_11256(Current, loc7, arg2, arg3, arg4, arg5);
					tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
					F1037_8385(RTCW(tr1), loc5, loc3, arg5);
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						F1033_8331(Current);
						F1231_11293(Current, arg1);
					} else {
						tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
						loc9 = tr1;
						loc9 = RTRV(eif_new_type(1982, 0x01),loc9);
						if (EIF_TEST(loc9)) {
							F1231_11195(Current, loc9, loc8, loc2, arg5);
						} else {
							tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
							loc10 = tr1;
							loc10 = RTRV(eif_new_type(1799, 0x01),loc10);
							if (EIF_TEST(loc10)) {
								F1231_11261(Current, loc10, loc8, loc2, arg5, NULL);
							} else {
								F1033_8331(Current);
								F2046_21728(RTCV(F1023_8173(Current)));
								F1231_11293(Current, arg1);
							}
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_static_parenthesis_call_validity */
void F1231_11309 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc6);
	RTLR(5,arg4);
	RTLR(6,tr1);
	RTLR(7,loc4);
	RTLR(8,loc3);
	RTLR(9,loc2);
	RTLR(10,loc8);
	RTLR(11,loc7);
	RTLR(12,tr2);
	RTLR(13,arg3);
	RTLR(14,loc9);
	RTLR(15,loc10);
	RTLIU(16);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1));
	tb1 = '\0';
	ti4_1 = F1837_17834(RTCW(arg2));
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		tb2 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O6364[Dtype(loc1)-1002]);
			tb2 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
		}
		tb1 = tb2;
	}
	if (tb1) {
		loc6 = RTLNS(eif_new_type(1944, 0x01).id, 1944, _OBJSIZ_1_1_0_2_0_0_0_0_);
		F1917_18826(RTCW(loc6));
		F1231_11311(Current, loc6, loc1);
		tr1 = F1839_17878(RTCW(arg2));
		F899_7054(RTCW(arg4), tr1);
		loc4 = F1231_11337(Current);
		F2023_20412(RTCW(arg4), loc4);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_4_0_0_1_);
		loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
		F1231_11334(Current, loc6, loc4, arg4);
		loc3 = F1541_13847(RTCW(loc4));
		F1231_11338(Current, loc4);
		F899_7057(RTCW(arg4));
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			F1231_11293(Current, arg1);
		} else {
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc3))-1835])(loc3);
			tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_10_);
			F2027_20822(RTCW(loc2), tr1);
			tb1 = F2027_20787(RTCW(loc2));
			if ((EIF_BOOLEAN) !tb1) {
				F1033_8331(Current);
				F1231_11293(Current, arg1);
			} else {
				tr1 = F140_1508(RTCW(loc3), loc6);
				loc8 = tr1;
				if (EIF_TEST(loc8)) {
					loc7 = RTLNS(eif_new_type(1786, 0x01).id, 1786, _OBJSIZ_5_0_0_1_0_0_0_0_);
					tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
					tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
					F1786_17462(RTCW(loc7), tr1, tr2, NULL);
					ti4_1 = *(EIF_INTEGER_32 *)(loc8 + O10400[Dtype(loc8)-1302]);
					F1944_19225(RTCW(loc6), ti4_1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13561[Dtype(RTCW(arg1))-1786])(arg1, loc7, loc6, loc1);
					F1231_11275(Current, loc7, arg2, arg3, arg4);
					tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
					F1037_8385(RTCW(tr1), loc5, loc3, arg4);
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						F1033_8331(Current);
						F1231_11293(Current, arg1);
					} else {
						tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
						loc9 = tr1;
						loc9 = RTRV(eif_new_type(1982, 0x01),loc9);
						if (EIF_TEST(loc9)) {
							F1231_11195(Current, loc9, loc8, loc2, arg4);
						} else {
							tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
							loc10 = tr1;
							loc10 = RTRV(eif_new_type(1799, 0x01),loc10);
							if (EIF_TEST(loc10)) {
								F1231_11261(Current, loc10, loc8, loc2, arg4, NULL);
							} else {
								F1033_8331(Current);
								F2046_21728(RTCV(F1023_8173(Current)));
								F1231_11293(Current, arg1);
							}
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_tuple_label_parenthesis_call_validity */
void F1231_11310 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(19);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,arg3);
	RTLR(4,loc11);
	RTLR(5,loc4);
	RTLR(6,loc9);
	RTLR(7,loc2);
	RTLR(8,arg2);
	RTLR(9,loc7);
	RTLR(10,loc6);
	RTLR(11,loc5);
	RTLR(12,tr1);
	RTLR(13,loc12);
	RTLR(14,loc10);
	RTLR(15,tr2);
	RTLR(16,loc13);
	RTLR(17,loc14);
	RTLR(18,arg4);
	RTLIU(19);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13378[Dtype(RTCW(arg1))-1748])(arg1);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O14497[Dtype(loc1)-1943]);
	ti4_1 = F2023_20402(RTCW(arg3));
	if ((EIF_BOOLEAN) (loc3 > ti4_1)) {
		F1033_8331(Current);
		F2046_21728(RTCV(F1023_8173(Current)));
		F1231_11293(Current, arg1);
	} else {
		loc11 = arg1;
		loc11 = RTRV(eif_new_type(1797, 0x01),loc11);
		if (EIF_TEST(loc11)) {
			loc4 = *(EIF_REFERENCE *)(loc11);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4) + O6364[Dtype(loc4)-1002]);
				tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
			}
			if (tb1) {
				loc9 = RTLNS(eif_new_type(1944, 0x01).id, 1944, _OBJSIZ_1_1_0_2_0_0_0_0_);
				F1917_18826(RTCW(loc9));
				F1231_11311(Current, loc9, loc4);
				loc2 = F2027_20699(RTCW(arg2), loc3);
				F899_7054(RTCW(arg3), loc2);
				loc7 = F1231_11337(Current);
				F2023_20412(RTCW(arg3), loc7);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_4_0_0_1_);
				loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
				F1231_11334(Current, loc9, loc7, arg3);
				loc6 = F1541_13847(RTCW(loc7));
				F1231_11338(Current, loc7);
				F899_7057(RTCW(arg3));
				if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
					F1231_11293(Current, arg1);
				} else {
					loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc6))-1835])(loc6);
					tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_10_);
					F2027_20822(RTCW(loc5), tr1);
					tb1 = F2027_20787(RTCW(loc5));
					if ((EIF_BOOLEAN) !tb1) {
						F1033_8331(Current);
						F1231_11293(Current, arg1);
					} else {
						tr1 = F140_1508(RTCW(loc6), loc9);
						loc12 = tr1;
						if (EIF_TEST(loc12)) {
							ti4_1 = *(EIF_INTEGER_32 *)(loc12 + O10400[Dtype(loc12)-1302]);
							F1944_19225(RTCW(loc9), ti4_1);
							loc10 = RTLNS(eif_new_type(1803, 0x01).id, 1803, _OBJSIZ_4_0_0_1_0_0_0_0_);
							tr1 = *(EIF_REFERENCE *)(loc11 + O13575[Dtype(loc11)-1797]);
							tr2 = F1785_17456(loc11);
							F1798_17504(RTCW(loc10), tr1, tr2, NULL);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13563[Dtype(loc11)-1794])(loc11, loc10, loc9, loc4);
							F1231_11263(Current, loc10, arg2, arg3, NULL);
							tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
							F1037_8385(RTCW(tr1), loc8, loc6, arg3);
							if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
								F1033_8331(Current);
								F1231_11293(Current, arg1);
							} else {
								tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(loc11)-1794])(loc11);
								loc13 = tr1;
								loc13 = RTRV(eif_new_type(1982, 0x01),loc13);
								if (EIF_TEST(loc13)) {
									F1231_11195(Current, loc13, loc12, loc5, arg3);
								} else {
									tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13562[Dtype(loc11)-1794])(loc11);
									loc14 = tr1;
									loc14 = RTRV(eif_new_type(1799, 0x01),loc14);
									if (EIF_TEST(loc14)) {
										F1231_11261(Current, loc14, loc12, loc5, arg3, arg4);
									} else {
										F1033_8331(Current);
										F2046_21728(RTCV(F1023_8173(Current)));
										F1231_11293(Current, arg1);
									}
								}
							}
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.set_parenthesis_call_position */
void F1231_11311 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
	loc1 = F1914_18794(RTCW(tr1));
	tb1 = F1285_12606(RTCW(loc1));
	if (tb1) {
		tr1 = F1816_17616(RTCW(arg2), ((EIF_INTEGER_32) 1L));
		loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13062[Dtype(RTCW(tr1))-1627])(tr1);
	}
	ti4_1 = F1286_12618(RTCW(loc1));
	ti4_2 = F1286_12619(RTCW(loc1));
	F1286_12620(RTCW(arg1), ti4_1, ti4_2);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_call_agent_validity */
void F1231_11312 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	tb1 = F1749_17325(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		F1231_11313(Current, arg1, arg2);
	} else {
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		loc2 = loc1;
		loc2 = RTRV(eif_new_type(1730, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			F1231_11316(Current, arg1, loc2, arg2);
		} else {
			loc3 = loc1;
			loc3 = RTRV(eif_new_type(1725, 0x01),loc3);
			if (EIF_TEST(loc3)) {
				F1231_11320(Current, arg1, loc3, arg2);
			} else {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_unqualified_call_agent_validity */
void F1231_11313 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,loc4);
	RTLR(6,arg2);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLIU(10);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if (*(EIF_BOOLEAN *)(Current + O9280[dtype-1230])) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21496(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	loc1 = F1749_17320(RTCW(arg1));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O14497[Dtype(loc1)-1943]);
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
			F1033_8331(Current);
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tr2 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_10_);
			F2027_20822(RTCW(tr1), tr2);
			tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tb1 = F2027_20787(RTCW(tr1));
			if ((EIF_BOOLEAN) !tb1) {
				F1033_8331(Current);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
				tr1 = F2027_20745(RTCW(tr1), loc1);
				loc4 = tr1;
				if (EIF_TEST(loc4)) {
					ti4_1 = *(EIF_INTEGER_32 *)(loc4 + O10400[Dtype(loc4)-1302]);
					F1944_19225(RTCW(loc1), ti4_1);
					F1749_17328(RTCW(arg1), (EIF_BOOLEAN) 1);
					F1231_11315(Current, arg1, loc4, arg2);
					F1033_8332(Current, (EIF_BOOLEAN) (loc3 || *(EIF_BOOLEAN *)(Current + O7067[dtype-1032])));
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
					tr1 = F2027_20744(RTCW(tr1), loc1);
					loc5 = tr1;
					if (EIF_TEST(loc5)) {
						ti4_1 = *(EIF_INTEGER_32 *)(loc5 + O10400[Dtype(loc5)-1302]);
						F1944_19225(RTCW(loc1), ti4_1);
						F1749_17328(RTCW(arg1), (EIF_BOOLEAN) 0);
						F1231_11314(Current, arg1, loc5, arg2);
						F1033_8332(Current, (EIF_BOOLEAN) (loc3 || *(EIF_BOOLEAN *)(Current + O7067[dtype-1032])));
					} else {
						F1033_8331(Current);
						tr1 = F1023_8173(Current);
						F2046_21428(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc1);
					}
				}
			}
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tr2 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_10_);
		F2027_20822(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tb1 = F2027_20787(RTCW(tr1));
		if ((EIF_BOOLEAN) !tb1) {
			F1033_8331(Current);
		} else {
			tb1 = F1749_17326(RTCW(arg1));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
				tr1 = F2027_20748(RTCW(tr1), loc2);
				loc6 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc6)) {
					F1033_8331(Current);
					F2046_21728(RTCV(F1023_8173(Current)));
				} else {
					F1231_11315(Current, arg1, loc6, arg2);
					F1033_8332(Current, (EIF_BOOLEAN) (loc3 || *(EIF_BOOLEAN *)(Current + O7067[dtype-1032])));
				}
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
				tr1 = F2027_20747(RTCW(tr1), loc2);
				loc7 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc7)) {
					F1033_8331(Current);
					F2046_21728(RTCV(F1023_8173(Current)));
				} else {
					F1231_11314(Current, arg1, loc7, arg2);
					F1033_8332(Current, (EIF_BOOLEAN) (loc3 || *(EIF_BOOLEAN *)(Current + O7067[dtype-1032])));
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_unqualified_query_call_agent_validity */
void F1231_11314 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc4);
	RTLR(5,loc3);
	RTLR(6,arg3);
	RTLR(7,loc5);
	RTLR(8,tr1);
	RTLR(9,tr2);
	RTLR(10,loc2);
	RTLR(11,loc7);
	RTLR(12,loc8);
	RTLR(13,loc6);
	RTLIU(14);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1749_17320(RTCW(arg1));
	F1231_11295(Current, loc1, arg2);
	loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10399[Dtype(RTCW(arg2))-1840])(arg2);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		F1231_11332(Current, arg1, loc4);
		loc3 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_3_0_0_0_);
		F1901_18643(RTCW(loc3), ti4_1);
	}
	loc9 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	F1231_11333(Current, arg1, loc4, arg2, loc3, arg3);
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc9);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc3 == NULL)) {
			tb2 = F1897_18592(RTCW(loc3));
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = F1231_11526(Current);
			loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + O12792[Dtype(tr1)-1610]);
		} else {
			loc5 = RTLNS(eif_new_type(2024, 0x01).id, 2024, _OBJSIZ_4_0_0_0_0_0_0_0_);
			tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tr2 = F1231_11526(Current);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12792[Dtype(tr2)-1610]);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_1_);
			F2025_20495(RTCW(loc5), tr1, loc3, tr2);
		}
		loc2 = F1839_17878(RTCW(arg2));
		tr1 = F1231_11526(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
		tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
		tb1 = F1884_18234(RTCW(loc2), tr1, tr2, arg3);
		if (tb1) {
			F899_7054(RTCW(arg3), loc5);
			tr1 = F1231_11526(Current);
			loc7 = *(EIF_REFERENCE *)(RTCW(tr1) + O12776[Dtype(tr1)-1610]);
		} else {
			tr1 = F1231_11526(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12758[Dtype(tr1)-1610]);
			loc8 = *(EIF_REFERENCE *)(RTCW(tr1) + O15311[Dtype(tr1)-2023]);
			loc6 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
			F1901_18643(RTCW(loc6), ((EIF_INTEGER_32) 2L));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc6))-1003])(loc6, loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc6))-1003])(loc6, loc5);
			loc7 = RTLNS(eif_new_type(2025, 0x01).id, 2025, _OBJSIZ_4_2_0_0_0_0_0_0_);
			tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tr2 = *(EIF_REFERENCE *)(RTCW(loc8));
			F2026_20529(RTCW(loc7), tr1, tr2, loc6, loc8);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9235[dtype-1230])(Current, arg1, arg2, loc7, arg3);
		F899_7054(RTCW(arg3), loc7);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_unqualified_procedure_call_agent_validity */
void F1231_11315 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLR(6,arg3);
	RTLR(7,loc4);
	RTLR(8,tr1);
	RTLR(9,tr2);
	RTLR(10,loc5);
	RTLIU(11);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1749_17320(RTCW(arg1));
	F1231_11295(Current, loc1, arg2);
	loc3 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_5_);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		F1231_11332(Current, arg1, loc3);
		loc2 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_3_0_0_0_);
		F1901_18643(RTCW(loc2), ti4_1);
	}
	loc6 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	F1231_11333(Current, arg1, loc3, arg2, loc2, arg3);
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc6);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc2 == NULL)) {
			tb2 = F1897_18592(RTCW(loc2));
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = F1231_11526(Current);
			loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12792[Dtype(tr1)-1610]);
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_3_0_0_0_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
				tr1 = F1901_18645(RTCW(loc2), ((EIF_INTEGER_32) 1L));
				F899_7054(RTCW(arg3), tr1);
				tr1 = F1231_11526(Current);
				loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12794[Dtype(tr1)-1610]);
			} else {
				loc4 = RTLNS(eif_new_type(2024, 0x01).id, 2024, _OBJSIZ_4_0_0_0_0_0_0_0_);
				tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr2 = F1231_11526(Current);
				tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12792[Dtype(tr2)-1610]);
				tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_1_);
				F2025_20495(RTCW(loc4), tr1, loc2, tr2);
			}
		}
		F899_7054(RTCW(arg3), loc4);
		tr1 = F1231_11526(Current);
		loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + O12777[Dtype(tr1)-1610]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9234[dtype-1230])(Current, arg1, arg2, loc5, arg3);
		F899_7054(RTCW(arg3), loc5);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_qualified_call_agent_validity */
void F1231_11316 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc15 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(18);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLR(5,tr1);
	RTLR(6,loc6);
	RTLR(7,loc5);
	RTLR(8,loc2);
	RTLR(9,loc16);
	RTLR(10,loc17);
	RTLR(11,loc18);
	RTLR(12,loc19);
	RTLR(13,loc14);
	RTLR(14,loc20);
	RTLR(15,loc11);
	RTLR(16,loc12);
	RTLR(17,loc13);
	RTLIU(18);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1749_17320(RTCW(arg1));
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O14497[Dtype(loc1)-1943]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12741[Dtype(tr1)-1610]);
	F1231_11290(Current, arg2, arg3, tr1);
	loc8 = *(EIF_INTEGER_32 *)(RTCW(arg3)+ _LNGOFF_2_0_0_0_);
	loc6 = F1231_11337(Current);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F2023_20412(RTCW(arg3), loc6);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_4_0_0_1_);
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
		F1231_11334(Current, loc1, loc6, arg3);
	}
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
	} else {
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
			loc5 = F1541_13847(RTCW(loc6));
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc5))-1835])(loc5);
			tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
			F1037_8385(RTCW(tr1), loc7, loc5, arg3);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
				F1033_8331(Current);
				if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
					F2046_21728(RTCV(F1023_8173(Current)));
				}
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1485[Dtype(RTCW(loc5))-1835])(loc5, loc1);
				loc16 = tr1;
				if (EIF_TEST(loc16)) {
					ti4_1 = *(EIF_INTEGER_32 *)(loc16 + O10400[Dtype(loc16)-1302]);
					F1944_19225(RTCW(loc1), ti4_1);
					F1749_17328(RTCW(arg1), (EIF_BOOLEAN) 1);
					F1231_11294(Current, loc1, loc16, loc2);
					loc4 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
					F1231_11318(Current, arg1, loc16, arg3);
					*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc4);
				} else {
					tr1 = F2027_20744(RTCW(loc2), loc1);
					loc17 = tr1;
					if (EIF_TEST(loc17)) {
						ti4_1 = *(EIF_INTEGER_32 *)(loc17 + O10400[Dtype(loc17)-1302]);
						F1944_19225(RTCW(loc1), ti4_1);
						F1749_17328(RTCW(arg1), (EIF_BOOLEAN) 0);
						F1231_11294(Current, loc1, loc17, loc2);
						loc4 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
						F1231_11317(Current, arg1, loc17, arg3);
						*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc4);
					} else {
						tb1 = '\0';
						tb2 = F2027_20603(RTCW(loc2));
						if (tb2) {
							loc18 = loc1;
							loc18 = RTRV(eif_new_type(1986, 0x01),loc18);
							tb1 = EIF_TEST(loc18);
						}
						if (tb1) {
							loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1489[Dtype(RTCW(loc5))-1835])(loc5, loc18, arg3);
							if ((EIF_BOOLEAN)(loc3 != ((EIF_INTEGER_32) 0L))) {
								F1987_19681(loc18, (EIF_BOOLEAN) 1);
								F1944_19225(loc18, loc3);
								F1749_17328(RTCW(arg1), (EIF_BOOLEAN) 0);
								F1231_11319(Current, arg1, loc2, arg3);
							}
						}
						if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							F2046_21429(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc1, loc2);
						}
					}
				}
			}
		} else {
			tb1 = F1432_13373(RTCW(loc6));
			if (tb1) {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
			} else {
				loc10 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_4_0_0_1_);
				loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc9 > loc10)) break;
					loc5 = F1541_13846(RTCW(loc6), loc9);
					loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc5))-1835])(loc5);
					tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
					F1037_8385(RTCW(tr1), loc7, loc5, arg3);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14504[Dtype(RTCW(loc1))-1944])(loc1);
					if (tb1) {
						tb1 = F2027_20603(RTCW(loc2));
						if (tb1) {
							F1231_11319(Current, arg1, loc2, arg3);
						} else {
							tb1 = F2027_20576(RTCW(loc2));
							if (tb1) {
								F1033_8331(Current);
								F2046_21728(RTCV(F1023_8173(Current)));
							} else {
								F1033_8331(Current);
								F2046_21728(RTCV(F1023_8173(Current)));
							}
						}
					} else {
						tb1 = F1749_17326(RTCW(arg1));
						if (tb1) {
							tr1 = F2027_20748(RTCW(loc2), loc3);
							loc19 = tr1;
							if (EIF_TEST(loc19)) {
								F1231_11294(Current, loc1, loc19, loc2);
								loc4 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
								F1231_11318(Current, arg1, loc19, arg3);
								*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc4);
								loc14 = (EIF_REFERENCE) loc19;
							} else {
								tb1 = F2027_20576(RTCW(loc2));
								if (tb1) {
									F1033_8331(Current);
									F2046_21728(RTCV(F1023_8173(Current)));
								} else {
									F1033_8331(Current);
									F2046_21728(RTCV(F1023_8173(Current)));
								}
							}
						} else {
							tr1 = F2027_20747(RTCW(loc2), loc3);
							loc20 = tr1;
							if (EIF_TEST(loc20)) {
								F1231_11294(Current, loc1, loc20, loc2);
								loc4 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
								F1231_11317(Current, arg1, loc20, arg3);
								*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc4);
								loc14 = (EIF_REFERENCE) loc20;
							} else {
								tb1 = F2027_20576(RTCW(loc2));
								if (tb1) {
									F1033_8331(Current);
									F2046_21728(RTCV(F1023_8173(Current)));
								} else {
									F1033_8331(Current);
									F2046_21728(RTCV(F1023_8173(Current)));
								}
							}
						}
					}
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						loc9 = (EIF_INTEGER_32) loc10;
					} else {
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc11 != NULL) && (EIF_BOOLEAN)(loc12 != NULL))) {
							tb1 = F2022_20367(RTCW(arg3), loc11);
							if ((EIF_BOOLEAN) !tb1) {
								F1033_8331(Current);
								if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc13 != NULL) && (EIF_BOOLEAN)(loc14 != NULL))) {
									tr1 = F1023_8173(Current);
									F2046_21388(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1, loc13, loc12, loc14, loc5);
								} else {
									tr1 = F1023_8173(Current);
									F2046_21387(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1, loc3, loc12, loc5);
								}
							}
						} else {
							if ((EIF_BOOLEAN) (loc10 > ((EIF_INTEGER_32) 1L))) {
								loc11 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
								F2023_20428(RTCW(loc11), arg3);
								loc12 = (EIF_REFERENCE) loc5;
								loc13 = (EIF_REFERENCE) loc14;
								loc15 = (EIF_INTEGER_32) loc3;
							}
						}
					}
					if ((EIF_BOOLEAN) (loc9 < loc10)) {
						F899_7059(RTCW(arg3), loc8);
					}
					loc9++;
				}
				if ((EIF_BOOLEAN)(loc11 != NULL)) {
					F1231_11572(Current, loc11);
				}
			}
		}
	}
	F1231_11338(Current, loc6);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_qualified_query_call_agent_validity */
void F1231_11317 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg3);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,arg2);
	RTLR(8,tr4);
	RTLR(9,loc5);
	RTLR(10,loc4);
	RTLR(11,loc6);
	RTLR(12,loc2);
	RTLR(13,loc8);
	RTLR(14,loc9);
	RTLR(15,loc7);
	RTLIU(16);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1749_17320(RTCW(arg1));
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O14497[Dtype(loc1)-1943]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13018[Dtype(tr1)-1616]);
	if (tb1) {
		tb1 = F2022_20355(RTCW(arg3));
		if ((EIF_BOOLEAN) !tb1) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
			tr4 = F2022_20345(RTCW(arg3));
			F2046_21513(RTCW(tr1), tr2, tr3, loc1, arg2, tr4);
		}
	}
	tb1 = F1837_17835(RTCW(arg2), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
	if ((EIF_BOOLEAN) !tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
		tr4 = F2022_20336(RTCW(arg3));
		F2046_21430(RTCW(tr1), tr2, tr3, loc1, arg2, tr4);
	}
	loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10399[Dtype(RTCW(arg2))-1840])(arg2);
	if ((EIF_BOOLEAN)(loc5 != NULL)) {
		F1231_11332(Current, arg1, loc5);
		loc4 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_3_0_0_0_);
		F1901_18643(RTCW(loc4), ti4_1);
	}
	loc10 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	F1231_11333(Current, arg1, loc5, arg2, loc4, arg3);
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc10);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc4 == NULL)) {
			tb2 = F1897_18592(RTCW(loc4));
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = F1231_11526(Current);
			loc6 = *(EIF_REFERENCE *)(RTCW(tr1) + O12792[Dtype(tr1)-1610]);
		} else {
			loc6 = RTLNS(eif_new_type(2024, 0x01).id, 2024, _OBJSIZ_4_0_0_0_0_0_0_0_);
			tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tr2 = F1231_11526(Current);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12792[Dtype(tr2)-1610]);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_1_);
			F2025_20495(RTCW(loc6), tr1, loc4, tr2);
		}
		loc2 = F1839_17878(RTCW(arg2));
		tr1 = F1231_11526(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
		tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
		tb1 = F1884_18234(RTCW(loc2), tr1, tr2, arg3);
		if (tb1) {
			F899_7054(RTCW(arg3), loc6);
			tr1 = F1231_11526(Current);
			loc8 = *(EIF_REFERENCE *)(RTCW(tr1) + O12776[Dtype(tr1)-1610]);
		} else {
			tr1 = F1231_11526(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12758[Dtype(tr1)-1610]);
			loc9 = *(EIF_REFERENCE *)(RTCW(tr1) + O15311[Dtype(tr1)-2023]);
			loc7 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
			F1901_18643(RTCW(loc7), ((EIF_INTEGER_32) 2L));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc7))-1003])(loc7, loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc7))-1003])(loc7, loc6);
			loc8 = RTLNS(eif_new_type(2025, 0x01).id, 2025, _OBJSIZ_4_2_0_0_0_0_0_0_);
			tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tr2 = *(EIF_REFERENCE *)(RTCW(loc9));
			F2026_20529(RTCW(loc8), tr1, tr2, loc7, loc9);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9216[dtype-1230])(Current, arg1, arg2, loc8, arg3);
		F899_7054(RTCW(arg3), loc8);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_qualified_procedure_call_agent_validity */
void F1231_11318 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg3);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,arg2);
	RTLR(8,tr4);
	RTLR(9,loc4);
	RTLR(10,loc3);
	RTLR(11,loc5);
	RTLR(12,loc6);
	RTLIU(13);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1749_17320(RTCW(arg1));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O14497[Dtype(loc1)-1943]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13018[Dtype(tr1)-1616]);
	if (tb1) {
		tb1 = F2022_20355(RTCW(arg3));
		if ((EIF_BOOLEAN) !tb1) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
			tr4 = F2022_20345(RTCW(arg3));
			F2046_21513(RTCW(tr1), tr2, tr3, loc1, arg2, tr4);
		}
	}
	tb1 = F1837_17835(RTCW(arg2), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
	if ((EIF_BOOLEAN) !tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
		tr4 = F2022_20336(RTCW(arg3));
		F2046_21430(RTCW(tr1), tr2, tr3, loc1, arg2, tr4);
	}
	loc4 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_5_);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		F1231_11332(Current, arg1, loc4);
		loc3 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_3_0_0_0_);
		F1901_18643(RTCW(loc3), ti4_1);
	}
	loc7 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	F1231_11333(Current, arg1, loc4, arg2, loc3, arg3);
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc7);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc3 == NULL)) {
			tb2 = F1897_18592(RTCW(loc3));
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = F1231_11526(Current);
			loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + O12792[Dtype(tr1)-1610]);
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_3_0_0_0_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
				tr1 = F1901_18645(RTCW(loc3), ((EIF_INTEGER_32) 1L));
				F899_7054(RTCW(arg3), tr1);
				tr1 = F1231_11526(Current);
				loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + O12794[Dtype(tr1)-1610]);
			} else {
				loc5 = RTLNS(eif_new_type(2024, 0x01).id, 2024, _OBJSIZ_4_0_0_0_0_0_0_0_);
				tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr2 = F1231_11526(Current);
				tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12792[Dtype(tr2)-1610]);
				tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_1_);
				F2025_20495(RTCW(loc5), tr1, loc3, tr2);
			}
		}
		F899_7054(RTCW(arg3), loc5);
		tr1 = F1231_11526(Current);
		loc6 = *(EIF_REFERENCE *)(RTCW(tr1) + O12777[Dtype(tr1)-1610]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9215[dtype-1230])(Current, arg1, arg2, loc6, arg3);
		F899_7054(RTCW(arg3), loc6);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_qualified_tuple_label_call_agent_validity */
void F1231_11319 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg3);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,tr4);
	RTLR(8,loc7);
	RTLR(9,loc3);
	RTLR(10,arg2);
	RTLR(11,loc5);
	RTLR(12,loc6);
	RTLR(13,loc4);
	RTLIU(14);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1749_17320(RTCW(arg1));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O14497[Dtype(loc1)-1943]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13018[Dtype(tr1)-1616]);
	if (tb1) {
		tb1 = F2022_20355(RTCW(arg3));
		if ((EIF_BOOLEAN) !tb1) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
			tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
			tr4 = F2022_20345(RTCW(arg3));
			F2046_21514(RTCW(tr1), tr2, tr3, loc1, tr4);
		}
	}
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		tb2 = F255_2406(loc7);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		F1033_8331(Current);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
			tr1 = F1023_8173(Current);
			F2046_21483(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc1);
		} else {
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		}
	} else {
		ti4_1 = F2023_20402(RTCW(arg3));
		if ((EIF_BOOLEAN) (loc2 > ti4_1)) {
			F1033_8331(Current);
			F2046_21728(RTCV(F1023_8173(Current)));
		} else {
			loc3 = F2027_20699(RTCW(arg2), loc2);
			tr1 = F1231_11526(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
			tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
			tb1 = F1884_18234(RTCW(loc3), tr1, tr2, arg3);
			if (tb1) {
				tr1 = F1231_11526(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12792[Dtype(tr1)-1610]);
				F899_7054(RTCW(arg3), tr1);
				tr1 = F1231_11526(Current);
				loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + O12776[Dtype(tr1)-1610]);
			} else {
				tr1 = F1231_11526(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12758[Dtype(tr1)-1610]);
				loc6 = *(EIF_REFERENCE *)(RTCW(tr1) + O15311[Dtype(tr1)-2023]);
				loc4 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
				F1901_18643(RTCW(loc4), ((EIF_INTEGER_32) 2L));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc4))-1003])(loc4, loc3);
				tr1 = F1231_11526(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12792[Dtype(tr1)-1610]);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc4))-1003])(loc4, tr1);
				loc5 = RTLNS(eif_new_type(2025, 0x01).id, 2025, _OBJSIZ_4_2_0_0_0_0_0_0_);
				tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr2 = *(EIF_REFERENCE *)(RTCW(loc6));
				F2026_20529(RTCW(loc5), tr1, tr2, loc4, loc6);
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9228[dtype-1230])(Current, arg1, loc5, arg3);
			F899_7054(RTCW(arg3), loc5);
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_typed_call_agent_validity */
void F1231_11320 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc15 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc16 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(19);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc4);
	RTLR(4,arg2);
	RTLR(5,loc6);
	RTLR(6,arg3);
	RTLR(7,loc5);
	RTLR(8,loc2);
	RTLR(9,tr1);
	RTLR(10,loc17);
	RTLR(11,loc18);
	RTLR(12,loc19);
	RTLR(13,loc20);
	RTLR(14,loc14);
	RTLR(15,loc21);
	RTLR(16,loc11);
	RTLR(17,loc12);
	RTLR(18,loc13);
	RTLIU(19);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1749_17320(RTCW(arg1));
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O14497[Dtype(loc1)-1943]);
	loc4 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
	F1231_11164(Current, loc4);
	loc6 = F1231_11337(Current);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		F899_7054(RTCW(arg3), loc4);
		loc8 = *(EIF_INTEGER_32 *)(RTCW(arg3)+ _LNGOFF_2_0_0_0_);
		F2023_20412(RTCW(arg3), loc6);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_4_0_0_1_);
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1L));
		F1231_11334(Current, loc1, loc6, arg3);
	}
	if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
	} else {
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
			loc5 = F1541_13847(RTCW(loc6));
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc5))-1835])(loc5);
			tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
			F1037_8385(RTCW(tr1), loc7, loc5, arg3);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) != *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
				F1033_8331(Current);
				if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
					F2046_21728(RTCV(F1023_8173(Current)));
				}
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1485[Dtype(RTCW(loc5))-1835])(loc5, loc1);
				loc17 = tr1;
				if (EIF_TEST(loc17)) {
					ti4_1 = *(EIF_INTEGER_32 *)(loc17 + O10400[Dtype(loc17)-1302]);
					F1944_19225(RTCW(loc1), ti4_1);
					F1749_17328(RTCW(arg1), (EIF_BOOLEAN) 1);
					F1231_11294(Current, loc1, loc17, loc2);
					loc16 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
					F1231_11322(Current, arg1, loc17, arg3);
					*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc16);
				} else {
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R1484[Dtype(RTCW(loc5))-1835])(loc5, loc1);
					loc18 = tr1;
					if (EIF_TEST(loc18)) {
						ti4_1 = *(EIF_INTEGER_32 *)(loc18 + O10400[Dtype(loc18)-1302]);
						F1944_19225(RTCW(loc1), ti4_1);
						F1749_17328(RTCW(arg1), (EIF_BOOLEAN) 0);
						F1231_11294(Current, loc1, loc18, loc2);
						loc16 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
						F1231_11321(Current, arg1, loc18, arg3);
						*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc16);
					} else {
						tb1 = '\0';
						tb2 = F2027_20603(RTCW(loc2));
						if (tb2) {
							loc19 = loc1;
							loc19 = RTRV(eif_new_type(1986, 0x01),loc19);
							tb1 = EIF_TEST(loc19);
						}
						if (tb1) {
							loc3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1489[Dtype(RTCW(loc5))-1835])(loc5, loc19, arg3);
							if ((EIF_BOOLEAN)(loc3 != ((EIF_INTEGER_32) 0L))) {
								F1987_19681(loc19, (EIF_BOOLEAN) 1);
								F1944_19225(loc19, loc3);
								F1749_17328(RTCW(arg1), (EIF_BOOLEAN) 0);
								F1231_11323(Current, arg1, loc2, arg3);
							}
						}
						if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							F2046_21429(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc1, loc2);
						}
					}
				}
			}
		} else {
			tb1 = F1432_13373(RTCW(loc6));
			if (tb1) {
				F1033_8331(Current);
				F2046_21728(RTCV(F1023_8173(Current)));
			} else {
				loc10 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_4_0_0_1_);
				loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc9 > loc10)) break;
					loc5 = F1541_13846(RTCW(loc6), loc9);
					loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(loc5))-1835])(loc5);
					tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
					F1037_8385(RTCW(tr1), loc7, loc5, arg3);
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R14504[Dtype(RTCW(loc1))-1944])(loc1);
					if (tb1) {
						tb1 = F2027_20603(RTCW(loc2));
						if (tb1) {
							F1231_11323(Current, arg1, loc2, arg3);
						} else {
							tb1 = F2027_20576(RTCW(loc2));
							if (tb1) {
								F1033_8331(Current);
								F2046_21728(RTCV(F1023_8173(Current)));
							} else {
								F1033_8331(Current);
								F2046_21728(RTCV(F1023_8173(Current)));
							}
						}
					} else {
						tb1 = F1749_17326(RTCW(arg1));
						if (tb1) {
							tr1 = F2027_20748(RTCW(loc2), loc3);
							loc20 = tr1;
							if (EIF_TEST(loc20)) {
								F1231_11294(Current, loc1, loc20, loc2);
								loc16 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
								F1231_11322(Current, arg1, loc20, arg3);
								*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc16);
								loc14 = (EIF_REFERENCE) loc20;
							} else {
								tb1 = F2027_20576(RTCW(loc2));
								if (tb1) {
									F1033_8331(Current);
									F2046_21728(RTCV(F1023_8173(Current)));
								} else {
									F1033_8331(Current);
									F2046_21728(RTCV(F1023_8173(Current)));
								}
							}
						} else {
							tr1 = F2027_20747(RTCW(loc2), loc3);
							loc21 = tr1;
							if (EIF_TEST(loc21)) {
								F1231_11294(Current, loc1, loc21, loc2);
								loc16 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
								F1231_11321(Current, arg1, loc21, arg3);
								*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc16);
								loc14 = (EIF_REFERENCE) loc21;
							} else {
								tb1 = F2027_20576(RTCW(loc2));
								if (tb1) {
									F1033_8331(Current);
									F2046_21728(RTCV(F1023_8173(Current)));
								} else {
									F1033_8331(Current);
									F2046_21728(RTCV(F1023_8173(Current)));
								}
							}
						}
					}
					if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						loc9 = (EIF_INTEGER_32) loc10;
					} else {
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc11 != NULL) && (EIF_BOOLEAN)(loc12 != NULL))) {
							tb1 = F2022_20367(RTCW(arg3), loc11);
							if ((EIF_BOOLEAN) !tb1) {
								F1033_8331(Current);
								if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc13 != NULL) && (EIF_BOOLEAN)(loc14 != NULL))) {
									tr1 = F1023_8173(Current);
									F2046_21388(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1, loc13, loc12, loc14, loc5);
								} else {
									tr1 = F1023_8173(Current);
									F2046_21387(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), loc1, loc3, loc12, loc5);
								}
							}
						} else {
							if ((EIF_BOOLEAN) (loc10 > ((EIF_INTEGER_32) 1L))) {
								loc11 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
								F2023_20428(RTCW(loc11), arg3);
								loc12 = (EIF_REFERENCE) loc5;
								loc13 = (EIF_REFERENCE) loc14;
								loc15 = (EIF_INTEGER_32) loc3;
							}
						}
					}
					if ((EIF_BOOLEAN) (loc9 < loc10)) {
						F899_7059(RTCW(arg3), loc8);
					}
					loc9++;
				}
				if ((EIF_BOOLEAN)(loc11 != NULL)) {
					F1231_11572(Current, loc11);
				}
			}
		}
	}
	F1231_11338(Current, loc6);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_typed_query_call_agent_validity */
void F1231_11321 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,arg3);
	RTLR(8,tr4);
	RTLR(9,loc5);
	RTLR(10,loc4);
	RTLR(11,loc6);
	RTLR(12,loc2);
	RTLR(13,loc8);
	RTLR(14,loc9);
	RTLR(15,loc7);
	RTLIU(16);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1749_17320(RTCW(arg1));
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O14497[Dtype(loc1)-1943]);
	tb1 = F1837_17835(RTCW(arg2), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
	if ((EIF_BOOLEAN) !tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
		tr4 = F2022_20336(RTCW(arg3));
		F2046_21430(RTCW(tr1), tr2, tr3, loc1, arg2, tr4);
	}
	loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10399[Dtype(RTCW(arg2))-1840])(arg2);
	if ((EIF_BOOLEAN)(loc5 != NULL)) {
		F1231_11332(Current, arg1, loc5);
		loc4 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_3_0_0_0_);
		F1901_18643(RTCW(loc4), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	} else {
		loc4 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
		F1901_18643(RTCW(loc4), ((EIF_INTEGER_32) 1L));
	}
	loc10 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	F1231_11333(Current, arg1, loc5, arg2, loc4, arg3);
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc10);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_3_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
			tr1 = F1231_11526(Current);
			loc6 = *(EIF_REFERENCE *)(RTCW(tr1) + O12794[Dtype(tr1)-1610]);
		} else {
			tr1 = RTOUCR(571,F396_4600, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc4))-1003])(loc4, tr1);
			loc6 = RTLNS(eif_new_type(2024, 0x01).id, 2024, _OBJSIZ_4_0_0_0_0_0_0_0_);
			tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tr2 = F1231_11526(Current);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12792[Dtype(tr2)-1610]);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_1_);
			F2025_20495(RTCW(loc6), tr1, loc4, tr2);
		}
		loc2 = F1839_17878(RTCW(arg2));
		tr1 = F1231_11526(Current);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
		tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
		tb1 = F1884_18234(RTCW(loc2), tr1, tr2, arg3);
		if (tb1) {
			F899_7054(RTCW(arg3), loc6);
			tr1 = F1231_11526(Current);
			loc8 = *(EIF_REFERENCE *)(RTCW(tr1) + O12776[Dtype(tr1)-1610]);
		} else {
			tr1 = F1231_11526(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12758[Dtype(tr1)-1610]);
			loc9 = *(EIF_REFERENCE *)(RTCW(tr1) + O15311[Dtype(tr1)-2023]);
			loc7 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
			F1901_18643(RTCW(loc7), ((EIF_INTEGER_32) 2L));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc7))-1003])(loc7, loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc7))-1003])(loc7, loc6);
			loc8 = RTLNS(eif_new_type(2025, 0x01).id, 2025, _OBJSIZ_4_2_0_0_0_0_0_0_);
			tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tr2 = *(EIF_REFERENCE *)(RTCW(loc9));
			F2026_20529(RTCW(loc8), tr1, tr2, loc7, loc9);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9216[dtype-1230])(Current, arg1, arg2, loc8, arg3);
		F899_7054(RTCW(arg3), loc8);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_typed_procedure_call_agent_validity */
void F1231_11322 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,arg3);
	RTLR(8,tr4);
	RTLR(9,loc4);
	RTLR(10,loc3);
	RTLR(11,loc5);
	RTLR(12,loc6);
	RTLIU(13);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1749_17320(RTCW(arg1));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O14497[Dtype(loc1)-1943]);
	tb1 = F1837_17835(RTCW(arg2), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
	if ((EIF_BOOLEAN) !tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
		tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
		tr4 = F2022_20336(RTCW(arg3));
		F2046_21430(RTCW(tr1), tr2, tr3, loc1, arg2, tr4);
	}
	loc4 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_5_);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		F1231_11332(Current, arg1, loc4);
		loc3 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_3_0_0_0_);
		F1901_18643(RTCW(loc3), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	} else {
		loc3 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
		F1901_18643(RTCW(loc3), ((EIF_INTEGER_32) 1L));
	}
	loc7 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	F1231_11333(Current, arg1, loc4, arg2, loc3, arg3);
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc7);
	if (loc7) {
		F1033_8331(Current);
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_3_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
			tr1 = F1231_11526(Current);
			loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + O12794[Dtype(tr1)-1610]);
		} else {
			tr1 = RTOUCR(571,F396_4600, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc3))-1003])(loc3, tr1);
			loc5 = RTLNS(eif_new_type(2024, 0x01).id, 2024, _OBJSIZ_4_0_0_0_0_0_0_0_);
			tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tr2 = F1231_11526(Current);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12792[Dtype(tr2)-1610]);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_1_);
			F2025_20495(RTCW(loc5), tr1, loc3, tr2);
		}
		F899_7054(RTCW(arg3), loc5);
		tr1 = F1231_11526(Current);
		loc6 = *(EIF_REFERENCE *)(RTCW(tr1) + O12777[Dtype(tr1)-1610]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9215[dtype-1230])(Current, arg1, arg2, loc6, arg3);
		F899_7054(RTCW(arg3), loc6);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_typed_tuple_label_call_agent_validity */
void F1231_11323 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc8);
	RTLR(4,tr1);
	RTLR(5,arg3);
	RTLR(6,loc3);
	RTLR(7,arg2);
	RTLR(8,loc7);
	RTLR(9,tr2);
	RTLR(10,loc5);
	RTLR(11,loc6);
	RTLR(12,loc4);
	RTLIU(13);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = F1749_17320(RTCW(arg1));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O14497[Dtype(loc1)-1943]);
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		tb2 = F255_2406(loc8);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		F1033_8331(Current);
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
			tr1 = F1023_8173(Current);
			F2046_21483(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), loc1);
		} else {
			if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
				F2046_21728(RTCV(F1023_8173(Current)));
			}
		}
	} else {
		ti4_1 = F2023_20402(RTCW(arg3));
		if ((EIF_BOOLEAN) (loc2 > ti4_1)) {
			F1033_8331(Current);
			F2046_21728(RTCV(F1023_8173(Current)));
		} else {
			loc3 = F2027_20699(RTCW(arg2), loc2);
			tr1 = F1231_11526(Current);
			loc7 = *(EIF_REFERENCE *)(RTCW(tr1) + O12794[Dtype(tr1)-1610]);
			tr1 = F1231_11526(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
			tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
			tb1 = F1884_18234(RTCW(loc3), tr1, tr2, arg3);
			if (tb1) {
				F899_7054(RTCW(arg3), loc7);
				tr1 = F1231_11526(Current);
				loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + O12776[Dtype(tr1)-1610]);
			} else {
				tr1 = F1231_11526(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12758[Dtype(tr1)-1610]);
				loc6 = *(EIF_REFERENCE *)(RTCW(tr1) + O15311[Dtype(tr1)-2023]);
				loc4 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
				F1901_18643(RTCW(loc4), ((EIF_INTEGER_32) 2L));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc4))-1003])(loc4, loc3);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc4))-1003])(loc4, loc7);
				loc5 = RTLNS(eif_new_type(2025, 0x01).id, 2025, _OBJSIZ_4_2_0_0_0_0_0_0_);
				tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr2 = *(EIF_REFERENCE *)(RTCW(loc6));
				F2026_20529(RTCW(loc5), tr1, tr2, loc4, loc6);
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9228[dtype-1230])(Current, arg1, loc5, arg3);
			F899_7054(RTCW(arg3), loc5);
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_do_function_inline_agent_validity */
void F1231_11324 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(19);
	RTLR(0,Current);
	RTLR(1,loc13);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,loc6);
	RTLR(6,loc5);
	RTLR(7,loc14);
	RTLR(8,loc1);
	RTLR(9,loc15);
	RTLR(10,loc16);
	RTLR(11,loc17);
	RTLR(12,loc2);
	RTLR(13,loc8);
	RTLR(14,loc10);
	RTLR(15,loc9);
	RTLR(16,loc11);
	RTLR(17,loc12);
	RTLR(18,arg2);
	RTLIU(19);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
	loc13 = tr1;
	if (EIF_TEST(loc13)) {
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		F1541_13864(RTCW(tr1), loc13);
	}
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	tr2 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	ti4_1 = F10_115(RTCW(tr2));
	F10_120(RTCW(tr1), ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	tr2 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	ti4_1 = F11_128(RTCW(tr2));
	F11_133(RTCW(tr1), ti4_1);
	loc6 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
	loc5 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
	}
	if (*(EIF_BOOLEAN *)(Current + O9280[dtype-1230])) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21495(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	loc14 = tr1;
	if (EIF_TEST(loc14)) {
		F1231_11155(Current, loc14, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc7 || tb1);
	}
	loc1 = F1751_17346(RTCW(arg1));
	F1231_11162(Current, loc1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9185[dtype-1230])(Current, loc1);
		F1231_11424(Current, loc1, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9248[dtype-1230]));
	}
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc7 || tb1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc15 = tr1;
	if (EIF_TEST(loc15)) {
		F1231_11159(Current, loc15, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc7 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc16 = tr1;
	if (EIF_TEST(loc16)) {
		F1231_11161(Current, loc16, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc7 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	loc17 = tr1;
	if (EIF_TEST(loc17)) {
		F1231_11157(Current, loc17, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc7 || tb1);
	}
	if ((EIF_BOOLEAN) !loc7) {
		loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		loc8 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc8 != NULL) && (EIF_BOOLEAN)(loc2 != NULL))) {
				loc10 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				F1250_11971(RTCW(tr1), loc10);
				loc9 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				F1250_11971(RTCW(tr1), loc9);
			}
		}
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			F1231_11208(Current, loc2);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc7 || tb1);
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			tb1 = '\0';
			tb2 = F1884_18220(RTCW(loc1), *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			if ((EIF_BOOLEAN) !tb2) {
				tb2 = F1884_18214(RTCW(loc1), *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				tb1 = '\0';
				tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
				tb2 = F1290_12726(RTCW(tr1));
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
					tb2 = F1250_11952(RTCW(tr1));
					tb1 = tb2;
				}
				if (tb1) {
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
					tb1 = F1250_11952(RTCW(tr1));
					if (tb1) {
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
						tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
						if ((EIF_BOOLEAN) !tb1) {
							loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							F2046_21316(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
						}
					}
				}
			}
		}
		if ((EIF_BOOLEAN)(loc8 != NULL)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc9 != NULL) && (EIF_BOOLEAN)(loc10 != NULL))) {
					loc11 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
					loc12 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
					RTAR(Current, loc9);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc9;
					RTAR(Current, loc10);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc10;
				}
			}
			F1231_11209(Current, loc8);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc7 || tb1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc11 != NULL) && (EIF_BOOLEAN)(loc12 != NULL))) {
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
					RTAR(Current, loc11);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc11;
					RTAR(Current, loc12);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc12;
				}
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	F10_120(RTCW(tr1), loc3);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	F11_133(RTCW(tr1), loc4);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
		RTAR(Current, loc6);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc6;
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
		RTAR(Current, loc5);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc5;
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
	tb1 = F1432_13373(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		tr1 = F1541_13848(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		F1541_13879(RTCW(tr1));
	} else {
		*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) NULL;
	}
	F1231_11330(Current, arg1, arg2);
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc7);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_do_procedure_inline_agent_validity */
void F1231_11325 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(18);
	RTLR(0,Current);
	RTLR(1,loc12);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,loc5);
	RTLR(6,loc4);
	RTLR(7,loc13);
	RTLR(8,loc14);
	RTLR(9,loc15);
	RTLR(10,loc16);
	RTLR(11,loc1);
	RTLR(12,loc7);
	RTLR(13,loc9);
	RTLR(14,loc8);
	RTLR(15,loc10);
	RTLR(16,loc11);
	RTLR(17,arg2);
	RTLIU(18);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
	loc12 = tr1;
	if (EIF_TEST(loc12)) {
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		F1541_13864(RTCW(tr1), loc12);
	}
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	tr2 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	ti4_1 = F10_115(RTCW(tr2));
	F10_120(RTCW(tr1), ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	tr2 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	ti4_1 = F11_128(RTCW(tr2));
	F11_133(RTCW(tr1), ti4_1);
	loc5 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
	loc4 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
	}
	if (*(EIF_BOOLEAN *)(Current + O9280[dtype-1230])) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21495(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
		loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	loc13 = tr1;
	if (EIF_TEST(loc13)) {
		F1231_11155(Current, loc13, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc6 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc14 = tr1;
	if (EIF_TEST(loc14)) {
		F1231_11159(Current, loc14, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc6 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc15 = tr1;
	if (EIF_TEST(loc15)) {
		F1231_11161(Current, loc15, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc6 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	loc16 = tr1;
	if (EIF_TEST(loc16)) {
		F1231_11157(Current, loc16, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc6 || tb1);
	}
	if ((EIF_BOOLEAN) !loc6) {
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		loc7 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc7 != NULL) && (EIF_BOOLEAN)(loc1 != NULL))) {
				loc9 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				F1250_11971(RTCW(tr1), loc9);
				loc8 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				F1250_11971(RTCW(tr1), loc8);
			}
		}
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			F1231_11208(Current, loc1);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc6 || tb1);
		}
		if ((EIF_BOOLEAN)(loc7 != NULL)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc8 != NULL) && (EIF_BOOLEAN)(loc9 != NULL))) {
					loc10 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
					loc11 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
					RTAR(Current, loc8);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc8;
					RTAR(Current, loc9);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc9;
				}
			}
			F1231_11209(Current, loc7);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc6 || tb1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc10 != NULL) && (EIF_BOOLEAN)(loc11 != NULL))) {
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
					RTAR(Current, loc10);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc10;
					RTAR(Current, loc11);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc11;
				}
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	F10_120(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	F11_133(RTCW(tr1), loc3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
		RTAR(Current, loc5);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc5;
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
		RTAR(Current, loc4);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc4;
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
	tb1 = F1432_13373(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		tr1 = F1541_13848(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		F1541_13879(RTCW(tr1));
	} else {
		*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) NULL;
	}
	F1231_11331(Current, arg1, arg2);
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc6);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_external_function_inline_agent_validity */
void F1231_11326 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,loc7);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,loc5);
	RTLR(6,loc4);
	RTLR(7,loc8);
	RTLR(8,loc1);
	RTLR(9,loc9);
	RTLR(10,loc10);
	RTLR(11,arg2);
	RTLIU(12);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		F1541_13864(RTCW(tr1), loc7);
	}
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	tr2 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	ti4_1 = F10_115(RTCW(tr2));
	F10_120(RTCW(tr1), ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	tr2 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	ti4_1 = F11_128(RTCW(tr2));
	F11_133(RTCW(tr1), ti4_1);
	loc5 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
	loc4 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
	}
	if (*(EIF_BOOLEAN *)(Current + O9280[dtype-1230])) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21495(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
		loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		F1231_11155(Current, loc8, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc6 || tb1);
	}
	loc1 = F1751_17346(RTCW(arg1));
	F1231_11162(Current, loc1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9185[dtype-1230])(Current, loc1);
		F1231_11424(Current, loc1, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9248[dtype-1230]));
	}
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc6 || tb1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		F1231_11159(Current, loc9, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc6 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		F1231_11161(Current, loc10, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc6 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	F10_120(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	F11_133(RTCW(tr1), loc3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
		RTAR(Current, loc5);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc5;
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
		RTAR(Current, loc4);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc4;
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
	tb1 = F1432_13373(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		tr1 = F1541_13848(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		F1541_13879(RTCW(tr1));
	} else {
		*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) NULL;
	}
	F1231_11330(Current, arg1, arg2);
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc6);
	tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
	tb1 = F1290_12726(RTCW(tr1));
	if (tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21446(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_external_procedure_inline_agent_validity */
void F1231_11327 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(11);
	RTLR(0,Current);
	RTLR(1,loc6);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,loc4);
	RTLR(6,loc3);
	RTLR(7,loc7);
	RTLR(8,loc8);
	RTLR(9,loc9);
	RTLR(10,arg2);
	RTLIU(11);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		F1541_13864(RTCW(tr1), loc6);
	}
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	tr2 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	ti4_1 = F10_115(RTCW(tr2));
	F10_120(RTCW(tr1), ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	tr2 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	ti4_1 = F11_128(RTCW(tr2));
	F11_133(RTCW(tr1), ti4_1);
	loc4 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
	loc3 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
	}
	if (*(EIF_BOOLEAN *)(Current + O9280[dtype-1230])) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21495(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
		loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		F1231_11155(Current, loc7, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc5 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		F1231_11159(Current, loc8, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc5 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		F1231_11161(Current, loc9, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc5 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	F10_120(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	F11_133(RTCW(tr1), loc2);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
		RTAR(Current, loc4);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc4;
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
		RTAR(Current, loc3);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc3;
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
	tb1 = F1432_13373(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		tr1 = F1541_13848(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		F1541_13879(RTCW(tr1));
	} else {
		*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) NULL;
	}
	F1231_11331(Current, arg1, arg2);
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc5);
	tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
	tb1 = F1290_12726(RTCW(tr1));
	if (tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21446(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_once_function_inline_agent_validity */
void F1231_11328 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(19);
	RTLR(0,Current);
	RTLR(1,loc14);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,loc6);
	RTLR(6,loc5);
	RTLR(7,loc15);
	RTLR(8,loc1);
	RTLR(9,loc16);
	RTLR(10,loc17);
	RTLR(11,loc18);
	RTLR(12,loc2);
	RTLR(13,loc9);
	RTLR(14,loc11);
	RTLR(15,loc10);
	RTLR(16,loc12);
	RTLR(17,loc13);
	RTLR(18,arg2);
	RTLIU(19);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
	loc14 = tr1;
	if (EIF_TEST(loc14)) {
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		F1541_13864(RTCW(tr1), loc14);
	}
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	tr2 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	ti4_1 = F10_115(RTCW(tr2));
	F10_120(RTCW(tr1), ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	tr2 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	ti4_1 = F11_128(RTCW(tr2));
	F11_133(RTCW(tr1), ti4_1);
	loc6 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
	loc5 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
	}
	if (*(EIF_BOOLEAN *)(Current + O9280[dtype-1230])) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21495(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
		loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	loc15 = tr1;
	if (EIF_TEST(loc15)) {
		F1231_11155(Current, loc15, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc8 || tb1);
	}
	loc1 = F1751_17346(RTCW(arg1));
	F1231_11162(Current, loc1);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9185[dtype-1230])(Current, loc1);
		F1231_11424(Current, loc1, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9248[dtype-1230]));
	}
	tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc8 || tb1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc16 = tr1;
	if (EIF_TEST(loc16)) {
		F1231_11159(Current, loc16, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc8 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc17 = tr1;
	if (EIF_TEST(loc17)) {
		F1231_11161(Current, loc17, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc8 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	loc18 = tr1;
	if (EIF_TEST(loc18)) {
		F1231_11157(Current, loc18, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc8 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_9_);
	{
		/* INLINED CODE (ET_CLOSURE.first_indexing) */
		tr2 = (EIF_REFERENCE)  0;
		(void) RTCW(arg1);
		/* END INLINED CODE */
	}
	tr2 = tr2;
	F1231_11168(Current, tr1, tr2);
	loc7 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	if ((EIF_BOOLEAN) !loc8) {
		loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		loc9 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc9 != NULL) && (EIF_BOOLEAN)(loc2 != NULL))) {
				loc11 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				F1250_11971(RTCW(tr1), loc11);
				loc10 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				F1250_11971(RTCW(tr1), loc10);
			}
		}
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			F1231_11208(Current, loc2);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc8 || tb1);
		}
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			tb1 = '\0';
			tb2 = F1884_18220(RTCW(loc1), *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
			if ((EIF_BOOLEAN) !tb2) {
				tb2 = F1884_18214(RTCW(loc1), *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				tb1 = '\0';
				tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
				tb2 = F1290_12726(RTCW(tr1));
				if (tb2) {
					tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
					tb2 = F1250_11952(RTCW(tr1));
					tb1 = tb2;
				}
				if (tb1) {
				} else {
					tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
					tb1 = F1250_11952(RTCW(tr1));
					if (tb1) {
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
						tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
						if ((EIF_BOOLEAN) !tb1) {
							loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							F1033_8331(Current);
							tr1 = F1023_8173(Current);
							F2046_21316(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
						}
					}
				}
			}
		}
		if ((EIF_BOOLEAN)(loc9 != NULL)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc10 != NULL) && (EIF_BOOLEAN)(loc11 != NULL))) {
					loc12 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
					loc13 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
					RTAR(Current, loc10);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc10;
					RTAR(Current, loc11);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc11;
				}
			}
			F1231_11209(Current, loc9);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc8 || tb1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc12 != NULL) && (EIF_BOOLEAN)(loc13 != NULL))) {
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
					RTAR(Current, loc12);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc12;
					RTAR(Current, loc13);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc13;
				}
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	F10_120(RTCW(tr1), loc3);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	F11_133(RTCW(tr1), loc4);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
		RTAR(Current, loc6);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc6;
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
		RTAR(Current, loc5);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc5;
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
	tb1 = F1432_13373(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		tr1 = F1541_13848(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		F1541_13879(RTCW(tr1));
	} else {
		*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) NULL;
	}
	F1231_11330(Current, arg1, arg2);
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc8) || loc7);
	tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
	tb1 = F1290_12726(RTCW(tr1));
	if (tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21445(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_once_procedure_inline_agent_validity */
void F1231_11329 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(18);
	RTLR(0,Current);
	RTLR(1,loc13);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,loc5);
	RTLR(6,loc4);
	RTLR(7,loc14);
	RTLR(8,loc15);
	RTLR(9,loc16);
	RTLR(10,loc17);
	RTLR(11,loc1);
	RTLR(12,loc8);
	RTLR(13,loc10);
	RTLR(14,loc9);
	RTLR(15,loc11);
	RTLR(16,loc12);
	RTLR(17,arg2);
	RTLIU(18);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
	loc13 = tr1;
	if (EIF_TEST(loc13)) {
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		F1541_13864(RTCW(tr1), loc13);
	}
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	tr2 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	ti4_1 = F10_115(RTCW(tr2));
	F10_120(RTCW(tr1), ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	tr2 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	ti4_1 = F11_128(RTCW(tr2));
	F11_133(RTCW(tr1), ti4_1);
	loc5 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
	loc4 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = F1231_11539(Current);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
	}
	if (*(EIF_BOOLEAN *)(Current + O9280[dtype-1230])) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21495(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]), arg1);
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	loc14 = tr1;
	if (EIF_TEST(loc14)) {
		F1231_11155(Current, loc14, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc7 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc15 = tr1;
	if (EIF_TEST(loc15)) {
		F1231_11159(Current, loc15, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc7 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc16 = tr1;
	if (EIF_TEST(loc16)) {
		F1231_11161(Current, loc16, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc7 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	loc17 = tr1;
	if (EIF_TEST(loc17)) {
		F1231_11157(Current, loc17, arg1);
		tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
		loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc7 || tb1);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_9_);
	{
		/* INLINED CODE (ET_CLOSURE.first_indexing) */
		tr2 = (EIF_REFERENCE)  0;
		(void) RTCW(arg1);
		/* END INLINED CODE */
	}
	tr2 = tr2;
	F1231_11168(Current, tr1, tr2);
	loc6 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
	if ((EIF_BOOLEAN) !loc7) {
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		loc8 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
		if (tb1) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc8 != NULL) && (EIF_BOOLEAN)(loc1 != NULL))) {
				loc10 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
				F1250_11971(RTCW(tr1), loc10);
				loc9 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				tr1 = F1231_11539(Current);
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				F1250_11971(RTCW(tr1), loc9);
			}
		}
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			F1231_11208(Current, loc1);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc7 || tb1);
		}
		if ((EIF_BOOLEAN)(loc8 != NULL)) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc9 != NULL) && (EIF_BOOLEAN)(loc10 != NULL))) {
					loc11 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
					loc12 = *(EIF_REFERENCE *)(Current + O9266[dtype-1230]);
					RTAR(Current, loc9);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc9;
					RTAR(Current, loc10);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc10;
				}
			}
			F1231_11209(Current, loc8);
			tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
			loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc7 || tb1);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
			tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
			if (tb1) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc11 != NULL) && (EIF_BOOLEAN)(loc12 != NULL))) {
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
					F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
					RTAR(Current, loc11);
					*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc11;
					RTAR(Current, loc12);
					*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc12;
				}
			}
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9260[dtype-1230]);
	F10_120(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + O9263[dtype-1230]);
	F11_133(RTCW(tr1), loc3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6922[dtype-1023])(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9266[dtype-1230]));
		RTAR(Current, loc5);
		*(EIF_REFERENCE *)(Current + O9266[dtype-1230]) = (EIF_REFERENCE) loc5;
		F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
		RTAR(Current, loc4);
		*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc4;
	}
	tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
	tb1 = F1432_13373(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		tr1 = F1541_13848(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + O9251[dtype-1230]);
		F1541_13879(RTCW(tr1));
	} else {
		*(EIF_REFERENCE *)(Current + O9250[dtype-1230]) = (EIF_REFERENCE) NULL;
	}
	F1231_11331(Current, arg1, arg2);
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc7) || loc6);
	tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
	tb1 = F1290_12726(RTCW(tr1));
	if (tb1) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21445(RTCW(tr1), *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), arg1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_query_inline_agent_validity */
void F1231_11330 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,arg2);
	RTLR(5,loc4);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,loc1);
	RTLR(9,loc6);
	RTLR(10,loc7);
	RTLR(11,loc5);
	RTLIU(12);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		F1231_11332(Current, arg1, loc3);
		loc2 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_3_0_0_0_);
		F1901_18643(RTCW(loc2), ti4_1);
	}
	F1231_11333(Current, arg1, loc3, NULL, loc2, arg2);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc2 == NULL)) {
			tb2 = F1897_18592(RTCW(loc2));
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = F1231_11526(Current);
			loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12792[Dtype(tr1)-1610]);
		} else {
			loc4 = RTLNS(eif_new_type(2024, 0x01).id, 2024, _OBJSIZ_4_0_0_0_0_0_0_0_);
			tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tr2 = F1231_11526(Current);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12792[Dtype(tr2)-1610]);
			tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_1_);
			F2025_20495(RTCW(loc4), tr1, loc2, tr2);
		}
		loc1 = F1751_17346(RTCW(arg1));
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			tr1 = F1231_11526(Current);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
			tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
			tb1 = F1884_18234(RTCW(loc1), tr1, tr2, arg2);
			if (tb1) {
				F899_7054(RTCW(arg2), loc4);
				tr1 = F1231_11526(Current);
				loc6 = *(EIF_REFERENCE *)(RTCW(tr1) + O12776[Dtype(tr1)-1610]);
			} else {
				tr1 = F1231_11526(Current);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12758[Dtype(tr1)-1610]);
				loc7 = *(EIF_REFERENCE *)(RTCW(tr1) + O15311[Dtype(tr1)-2023]);
				loc5 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
				F1901_18643(RTCW(loc5), ((EIF_INTEGER_32) 2L));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc5))-1003])(loc5, loc1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc5))-1003])(loc5, loc4);
				loc6 = RTLNS(eif_new_type(2025, 0x01).id, 2025, _OBJSIZ_4_2_0_0_0_0_0_0_);
				tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr2 = *(EIF_REFERENCE *)(RTCW(loc7));
				F2026_20529(RTCW(loc6), tr1, tr2, loc5, loc7);
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9217[dtype-1230])(Current, arg1, loc6, arg2);
			F899_7054(RTCW(arg2), loc6);
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_procedure_inline_agent_validity */
void F1231_11331 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLR(4,arg2);
	RTLR(5,loc3);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,loc4);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		F1231_11332(Current, arg1, loc2);
		loc1 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_3_0_0_0_);
		F1901_18643(RTCW(loc1), ti4_1);
	}
	F1231_11333(Current, arg1, loc2, NULL, loc1, arg2);
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc1 == NULL)) {
			tb2 = F1897_18592(RTCW(loc1));
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = F1231_11526(Current);
			loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + O12792[Dtype(tr1)-1610]);
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_3_0_0_0_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
				tr1 = F1901_18645(RTCW(loc1), ((EIF_INTEGER_32) 1L));
				F899_7054(RTCW(arg2), tr1);
				tr1 = F1231_11526(Current);
				loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + O12794[Dtype(tr1)-1610]);
			} else {
				loc3 = RTLNS(eif_new_type(2024, 0x01).id, 2024, _OBJSIZ_4_0_0_0_0_0_0_0_);
				tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr2 = F1231_11526(Current);
				tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12792[Dtype(tr2)-1610]);
				tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + _REFACS_1_);
				F2025_20495(RTCW(loc3), tr1, loc1, tr2);
			}
		}
		F899_7054(RTCW(arg2), loc3);
		tr1 = F1231_11526(Current);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12777[Dtype(tr1)-1610]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9212[dtype-1230])(Current, arg1, loc4, arg2);
		F899_7054(RTCW(arg2), loc4);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.set_implicit_agent_open_arguments */
void F1231_11332 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O9255[dtype-1230]) == *(EIF_REFERENCE *)(Current + O6920[dtype-1022]))) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O13476[Dtype(arg1)-1747]);
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			tb1 = '\0';
			if ((EIF_BOOLEAN)(arg2 != NULL)) {
				tb2 = F1003_7573(RTCW(arg2));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				loc4 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_0_0_0_);
				loc1 = RTLNS(eif_new_type(899, 0x01).id, 899, _OBJSIZ_1_0_0_1_0_0_0_0_);
				F899_7043(RTCW(loc1), loc4);
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc3 > loc4)) break;
					loc2 = RTLNS(eif_new_type(1729, 0x01).id, 1729, _OBJSIZ_1_0_0_2_0_0_0_0_);
					F1730_17150(RTCW(loc2), arg1, loc3);
					F899_7053(RTCW(loc1), loc2);
					loc3++;
				}
				F1748_17313(RTCW(arg1), loc1);
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_agent_arguments_validity */
void F1231_11333 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc8 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc24 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc25 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(33);
	RTLR(0,Current);
	RTLR(1,loc13);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,arg4);
	RTLR(6,loc1);
	RTLR(7,loc14);
	RTLR(8,arg3);
	RTLR(9,tr2);
	RTLR(10,tr3);
	RTLR(11,arg5);
	RTLR(12,tr4);
	RTLR(13,loc15);
	RTLR(14,loc16);
	RTLR(15,loc17);
	RTLR(16,loc2);
	RTLR(17,loc3);
	RTLR(18,loc7);
	RTLR(19,loc6);
	RTLR(20,loc18);
	RTLR(21,loc11);
	RTLR(22,loc19);
	RTLR(23,loc9);
	RTLR(24,loc10);
	RTLR(25,loc20);
	RTLR(26,tr5);
	RTLR(27,loc21);
	RTLR(28,loc22);
	RTLR(29,loc12);
	RTLR(30,loc23);
	RTLR(31,loc24);
	RTLR(32,loc25);
	RTLIU(33);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O13476[Dtype(arg1)-1747]);
	loc13 = tr1;
	loc13 = RTRV(eif_new_type(1632, 0x01),loc13);
	if ((EIF_BOOLEAN) !EIF_TEST(loc13)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg2 != NULL) && (EIF_BOOLEAN)(arg4 != NULL))) {
			loc5 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_0_0_0_);
			loc4 = (EIF_INTEGER_32) loc5;
			for (;;) {
				if ((EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 1L))) break;
				tr1 = F1649_16721(RTCW(arg2), loc4);
				loc1 = F1814_17596(RTCW(tr1));
				F1003_7577(RTCW(arg4), loc1);
				loc4--;
			}
		}
	} else {
		tb1 = F255_2406(loc13);
		if (tb1) {
			tb1 = '\0';
			if ((EIF_BOOLEAN)(arg2 != NULL)) {
				tb2 = F1003_7573(RTCW(arg2));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				F1033_8331(Current);
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
					loc14 = arg1;
					loc14 = RTRV(eif_new_type(1748, 0x01),loc14);
					if ((EIF_BOOLEAN) (EIF_TEST(loc14) && (EIF_BOOLEAN)(arg3 != NULL))) {
						tb1 = F1749_17325(loc14);
						if (tb1) {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = F1749_17320(loc14);
							tr4 = F2022_20336(RTCW(arg5));
							F2046_21431(RTCW(tr1), tr2, tr3, arg3, tr4);
						} else {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = F1749_17320(loc14);
							F2046_21432(RTCW(tr1), tr2, tr3, arg3);
						}
					} else {
						loc15 = arg1;
						loc15 = RTRV(eif_new_type(1749, 0x01),loc15);
						if (EIF_TEST(loc15)) {
						} else {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
				} else {
					if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
						F2046_21728(RTCV(F1023_8173(Current)));
					}
				}
			}
		} else {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(arg2 == NULL)) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_3_0_0_0_);
				ti4_2 = *(EIF_INTEGER_32 *)(loc13+ _LNGOFF_3_0_0_0_);
				tb1 = (EIF_BOOLEAN)(ti4_1 != ti4_2);
			}
			if (tb1) {
				F1033_8331(Current);
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
					loc16 = arg1;
					loc16 = RTRV(eif_new_type(1748, 0x01),loc16);
					if ((EIF_BOOLEAN) (EIF_TEST(loc16) && (EIF_BOOLEAN)(arg3 != NULL))) {
						tb1 = F1749_17325(loc16);
						if (tb1) {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = F1749_17320(loc16);
							tr4 = F2022_20336(RTCW(arg5));
							F2046_21431(RTCW(tr1), tr2, tr3, arg3, tr4);
						} else {
							tr1 = F1023_8173(Current);
							tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
							tr3 = F1749_17320(loc16);
							F2046_21432(RTCW(tr1), tr2, tr3, arg3);
						}
					} else {
						loc17 = arg1;
						loc17 = RTRV(eif_new_type(1749, 0x01),loc17);
						if (EIF_TEST(loc17)) {
						} else {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
				} else {
					if ((EIF_BOOLEAN) !F1231_11131(Current, *(EIF_REFERENCE *)(Current + O9249[dtype-1230]))) {
						F2046_21728(RTCV(F1023_8173(Current)));
					}
				}
			} else {
				loc2 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
				loc3 = (EIF_REFERENCE) arg5;
				loc5 = *(EIF_INTEGER_32 *)(loc13+ _LNGOFF_3_0_0_0_);
				loc4 = (EIF_INTEGER_32) loc5;
				for (;;) {
					if ((EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 1L))) break;
					tb1 = *(EIF_BOOLEAN *)(Current + O7067[dtype-1032]);
					loc8 = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc8 || tb1);
					loc7 = F1649_16721(RTCW(arg2), loc4);
					loc6 = F1633_16553(loc13, loc4);
					loc18 = loc6;
					loc18 = RTRV(eif_new_type(1730, 0x01),loc18);
					if (EIF_TEST(loc18)) {
						loc1 = F1814_17596(RTCW(loc7));
						F899_7054(RTCW(loc3), loc1);
						F1231_11290(Current, loc18, loc2, loc3);
						if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
						} else {
							tb1 = F2022_20379(RTCW(loc2), loc3, *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
							if ((EIF_BOOLEAN) !tb1) {
								loc11 = F1231_11340(Current, loc18, loc2, loc3);
								if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
								} else {
									if ((EIF_BOOLEAN)(loc11 != NULL)) {
										tr1 = F1003_7568(loc13, loc4);
										loc19 = tr1;
										loc19 = RTRV(eif_new_type(1680, 0x01),loc19);
										if (EIF_TEST(loc19)) {
											(RTNA((loc19, loc11)));
										} else {
											F1003_7578(loc13, loc11, loc4);
										}
									} else {
										F1033_8331(Current);
										loc9 = F2022_20345(RTCW(loc2));
										loc10 = F2022_20345(RTCW(loc3));
										loc20 = arg1;
										loc20 = RTRV(eif_new_type(1748, 0x01),loc20);
										if ((EIF_BOOLEAN) (EIF_TEST(loc20) && (EIF_BOOLEAN)(arg3 != NULL))) {
											tb1 = F1749_17325(loc20);
											if (tb1) {
												F899_7057(RTCW(loc3));
												tr1 = F1023_8173(Current);
												tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
												tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
												tr4 = F1749_17320(loc20);
												tr5 = F2022_20336(RTCW(arg5));
												F2046_21433(RTCW(tr1), tr2, tr3, tr4, arg3, tr5, loc4, loc9, loc10);
												F899_7054(RTCW(loc3), loc1);
											} else {
												tr1 = F1023_8173(Current);
												tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
												tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
												tr4 = F1749_17320(loc20);
												F2046_21434(RTCW(tr1), tr2, tr3, tr4, arg3, loc4, loc9, loc10);
											}
										} else {
											loc21 = arg1;
											loc21 = RTRV(eif_new_type(1749, 0x01),loc21);
											if (EIF_TEST(loc21)) {
											} else {
												F1033_8331(Current);
												F2046_21728(RTCV(F1023_8173(Current)));
											}
										}
									}
								}
							}
						}
						F899_7057(RTCW(loc3));
						F899_7060(RTCW(loc2));
					} else {
						loc22 = loc6;
						loc22 = RTRV(eif_new_type(1728, 0x01),loc22);
						if (EIF_TEST(loc22)) {
							loc12 = *(EIF_REFERENCE *)(loc22 + _REFACS_2_);
							F1231_11164(Current, loc12);
							if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
								tr1 = F1814_17596(RTCW(loc7));
								tr2 = *(EIF_REFERENCE *)(Current + O9254[dtype-1230]);
								tr3 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
								tb1 = F1829_17710(RTCW(loc12), tr1, loc3, tr2, tr3);
								if ((EIF_BOOLEAN) !tb1) {
									F1033_8331(Current);
									loc9 = F1884_18201(RTCW(loc12), *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
									tr1 = F1814_17596(RTCW(loc7));
									loc10 = F1884_18201(RTCW(tr1), loc3);
									loc23 = arg1;
									loc23 = RTRV(eif_new_type(1748, 0x01),loc23);
									if ((EIF_BOOLEAN) (EIF_TEST(loc23) && (EIF_BOOLEAN)(arg3 != NULL))) {
										tb1 = F1749_17325(loc23);
										if (tb1) {
											tr1 = F1023_8173(Current);
											tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
											tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
											tr4 = F1749_17320(loc23);
											tr5 = F2022_20336(RTCW(arg5));
											F2046_21435(RTCW(tr1), tr2, tr3, tr4, arg3, tr5, loc4, loc9, loc10);
										} else {
											tr1 = F1023_8173(Current);
											tr2 = *(EIF_REFERENCE *)(Current + O6920[dtype-1022]);
											tr3 = *(EIF_REFERENCE *)(Current + O9255[dtype-1230]);
											tr4 = F1749_17320(loc23);
											F2046_21436(RTCW(tr1), tr2, tr3, tr4, arg3, loc4, loc9, loc10);
										}
									} else {
										loc24 = arg1;
										loc24 = RTRV(eif_new_type(1749, 0x01),loc24);
										if (EIF_TEST(loc24)) {
										} else {
											F1033_8331(Current);
											F2046_21728(RTCV(F1023_8173(Current)));
										}
									}
								} else {
									if ((EIF_BOOLEAN)(arg4 != NULL)) {
										F1003_7577(RTCW(arg4), loc12);
									}
								}
							}
						} else {
							loc25 = loc6;
							loc25 = RTRV(eif_new_type(1917, 0x01),loc25);
							if (EIF_TEST(loc25)) {
								if ((EIF_BOOLEAN)(arg4 != NULL)) {
									loc1 = F1814_17596(RTCW(loc7));
									F1003_7577(RTCW(arg4), loc1);
								}
							} else {
								F1033_8331(Current);
								F2046_21728(RTCV(F1023_8173(Current)));
							}
						}
					}
					loc4--;
				}
				F1231_11572(Current, loc2);
				*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) || loc8);
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.check_adapted_base_classes_validity */
void F1231_11334 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
	F1037_8384(RTCW(tr1), arg1, arg2, arg3, *(EIF_REFERENCE *)(Current + O6920[dtype-1022]), *(EIF_REFERENCE *)(Current + O9255[dtype-1230]));
	tr1 = *(EIF_REFERENCE *)(Current + O9158[dtype-1230]);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
	if (tb1) {
		F1033_8331(Current);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.adapted_name */
EIF_REFERENCE F1231_11336 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,loc2);
	RTLR(3,arg2);
	RTLR(4,loc3);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	Result = (EIF_REFERENCE) arg1;
	tb1 = '\0';
	loc2 = arg2;
	loc2 = RTRV(eif_new_type(1834, 0x01),loc2);
	if (EIF_TEST(loc2)) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13290[Dtype(loc2)-1833])(loc2);
		loc3 = tr1;
		tb1 = EIF_TEST(loc3);
	}
	if (tb1) {
		loc1 = F1656_16783(loc3, arg1);
		if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
			tr1 = F1656_16781(loc3, loc1);
			Result = *(EIF_REFERENCE *)(RTCW(tr1));
		}
	}
	RTLE;
	return Result;
}

/* {ET_FEATURE_CHECKER}.new_adapted_base_classes */
EIF_REFERENCE F1231_11337 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9162[dtype-1230]);
	tb1 = F1432_13373(RTCW(tr1));
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1540,0xFF01,139,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNS(typres0.id, 1540, _OBJSIZ_4_0_0_2_0_0_0_0_);
		}
		F1541_13840(RTCW(tr1), ((EIF_INTEGER_32) 20L));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O9162[dtype-1230]);
		Result = F1541_13848(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9162[dtype-1230]);
		F1541_13879(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {ET_FEATURE_CHECKER}.free_adapted_base_classes */
void F1231_11338 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1541_13892(RTCW(arg1));
	tr1 = *(EIF_REFERENCE *)(Current + O9162[Dtype(Current)-1230]);
	F1541_13864(RTCW(tr1), arg1);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.convert_expression */
EIF_REFERENCE F1231_11340 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(14);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLR(4,loc1);
	RTLR(5,arg1);
	RTLR(6,loc2);
	RTLR(7,loc6);
	RTLR(8,loc4);
	RTLR(9,loc7);
	RTLR(10,Result);
	RTLR(11,loc5);
	RTLR(12,loc8);
	RTLR(13,loc3);
	RTLIU(14);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O6920[dtype-1022]) == *(EIF_REFERENCE *)(Current + O9255[dtype-1230]))) {
		tr1 = RTOUCR(75,F396_4598, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		F899_7054(RTCW(arg2), tr1);
		tr1 = RTOUCR(75,F396_4598, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		F899_7054(RTCW(arg3), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
		loc1 = F1035_8345(RTCW(tr1), arg2, arg3);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			tr1 = F1023_8169(Current);
			loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13406[Dtype(RTCW(arg1))-1731])(arg1, arg2, arg3, tr1);
		}
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13333[Dtype(RTCW(loc1))-1702])(loc1);
			if (tb1) {
				loc2 = F2022_20336(RTCW(arg3));
				tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_9_);
				F2027_20822(RTCW(loc2), tr1);
				tb1 = '\01';
				tb2 = F2027_20777(RTCW(loc2));
				if (!(EIF_BOOLEAN) !tb2) {
					tb2 = F2027_20779(RTCW(loc2));
					tb1 = tb2;
				}
				if (tb1) {
					F1033_8331(Current);
				} else {
					loc6 = F2022_20345(RTCW(arg3));
					loc4 = RTLNS(eif_new_type(1780, 0x01).id, 1780, _OBJSIZ_4_0_0_1_0_0_0_0_);
					F1781_17425(RTCW(loc4), loc6, loc1, arg1);
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O14497[Dtype(tr1)-1943]);
					tr1 = F2027_20748(RTCW(loc2), ti4_1);
					loc7 = tr1;
					if (EIF_TEST(loc7)) {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_2_);
						F1231_11296(Current, tr1, loc7, loc2);
						if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9173[dtype-1230])(Current, loc4, loc6, loc7);
							Result = (EIF_REFERENCE) loc4;
						}
					} else {
						F1033_8331(Current);
						F2046_21728(RTCV(F1023_8173(Current)));
					}
				}
			} else {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13334[Dtype(RTCW(loc1))-1702])(loc1);
				if (tb1) {
					loc2 = F2022_20336(RTCW(arg2));
					tr1 = *(EIF_REFERENCE *)(Current + O6923[dtype-1022]);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_9_);
					F2027_20822(RTCW(loc2), tr1);
					tb1 = '\01';
					tb2 = F2027_20777(RTCW(loc2));
					if (!(EIF_BOOLEAN) !tb2) {
						tb2 = F2027_20779(RTCW(loc2));
						tb1 = tb2;
					}
					if (tb1) {
						F1033_8331(Current);
					} else {
						loc5 = RTLNS(eif_new_type(1801, 0x01).id, 1801, _OBJSIZ_3_0_0_1_0_0_0_0_);
						F1802_17518(RTCW(loc5), arg1, loc1);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O14497[Dtype(tr1)-1943]);
						tr1 = F2027_20747(RTCW(loc2), ti4_1);
						loc8 = tr1;
						if (EIF_TEST(loc8)) {
							tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_2_);
							F1231_11294(Current, tr1, loc8, loc2);
							if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
								(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9213[dtype-1230])(Current, loc5, arg2, loc8);
								Result = (EIF_REFERENCE) loc5;
							}
						} else {
							F1033_8331(Current);
							F2046_21728(RTCV(F1023_8173(Current)));
						}
					}
				} else {
					loc6 = F2022_20345(RTCW(arg3));
					loc3 = RTLNS(eif_new_type(1769, 0x01).id, 1769, _OBJSIZ_3_0_0_1_0_0_0_0_);
					F1770_17380(RTCW(loc3), loc6, loc1, arg1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R9172[dtype-1230])(Current, loc3, loc6);
					Result = (EIF_REFERENCE) loc3;
				}
			}
		}
		F899_7057(RTCW(arg2));
		F899_7057(RTCW(arg3));
	}
	RTLE;
	return Result;
}

/* {ET_FEATURE_CHECKER}.tuple_argument_position */
EIF_INTEGER_32 F1231_11341 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,loc3);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_3_0_0_0_);
	loc3 = F1231_11337(Current);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		tr1 = F1649_16721(RTCW(arg1), loc1);
		tr1 = F1814_17596(RTCW(tr1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13958[Dtype(RTCW(tr1))-1885])(tr1, loc3, arg2);
		loc5 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_4_0_0_1_);
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc4 > loc5)) break;
			tr1 = F1541_13846(RTCW(loc3), loc4);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1482[Dtype(RTCW(tr1))-1835])(tr1);
			tb1 = F2027_20603(RTCW(tr1));
			if (tb1) {
				loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc4 = (EIF_INTEGER_32) loc5;
			}
			loc4++;
		}
		F1541_13892(RTCW(loc3));
		if (loc6) {
			if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) 0L))) {
				Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				loc1 = (EIF_INTEGER_32) loc2;
			} else {
				Result = (EIF_INTEGER_32) loc1;
			}
		}
		loc1++;
	}
	F1231_11338(Current, loc3);
	RTLE;
	return Result;
}

/* {ET_FEATURE_CHECKER}.report_assignment */
void F1231_11342 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_assignment_attempt */
void F1231_11343 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_attribute_address */
void F1231_11344 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_attribute_assignment_target */
void F1231_11345 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_boolean_constant */
void F1231_11346 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_character_8_constant */
void F1231_11347 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_character_32_constant */
void F1231_11348 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_builtin_conversion */
void F1231_11349 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_creation_expression */
void F1231_11350 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_creation_instruction */
void F1231_11351 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_current */
void F1231_11352 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_equality_expression */
void F1231_11353 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_formal_argument */
void F1231_11354 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_formal_argument_declaration */
void F1231_11355 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_function_address */
void F1231_11356 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_if_expression */
void F1231_11357 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_immutable_string_8_constant */
void F1231_11358 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_immutable_string_32_constant */
void F1231_11359 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_inline_agent_formal_argument_declaration */
void F1231_11360 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_inline_agent_local_variable_declaration */
void F1231_11361 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_inline_agent_result_declaration */
void F1231_11362 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_integer_8_constant */
void F1231_11363 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_integer_16_constant */
void F1231_11364 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_integer_32_constant */
void F1231_11365 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_integer_64_constant */
void F1231_11366 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_iteration_cursor */
void F1231_11367 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_iteration_cursor_declaration */
void F1231_11368 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_iteration_expression */
void F1231_11369 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_local_assignment_target */
void F1231_11370 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_local_variable */
void F1231_11371 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_local_variable_declaration */
void F1231_11372 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_manifest_array */
void F1231_11373 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_manifest_tuple */
void F1231_11374 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_manifest_type */
void F1231_11375 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_named_object_test */
void F1231_11376 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_natural_8_constant */
void F1231_11377 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_natural_16_constant */
void F1231_11378 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_natural_32_constant */
void F1231_11379 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_natural_64_constant */
void F1231_11380 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_object_equality_expression */
void F1231_11381 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_object_test */
void F1231_11382 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_object_test_type */
void F1231_11383 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_object_test_local */
void F1231_11384 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_pointer_expression */
void F1231_11385 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_precursor_expression */
void F1231_11386 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_precursor_instruction */
void F1231_11387 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_procedure_address */
void F1231_11388 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_procedure_inline_agent */
void F1231_11389 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_qualified_call_expression */
void F1231_11390 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_qualified_call_instruction */
void F1231_11391 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_qualified_procedure_call_agent */
void F1231_11392 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_qualified_query_call_agent */
void F1231_11393 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_query_inline_agent */
void F1231_11394 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_real_32_constant */
void F1231_11395 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_real_64_constant */
void F1231_11396 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_result */
void F1231_11397 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_result_assignment_target */
void F1231_11398 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_result_declaration */
void F1231_11399 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_static_call_expression */
void F1231_11400 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_static_call_instruction */
void F1231_11401 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_string_8_constant */
void F1231_11402 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_string_32_constant */
void F1231_11403 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_strip_expression */
void F1231_11404 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_tuple_label_call_agent */
void F1231_11405 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_tuple_label_expression */
void F1231_11406 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_tuple_label_setter */
void F1231_11407 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_typed_pointer_expression */
void F1231_11408 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_unqualified_call_expression */
void F1231_11409 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_unqualified_call_instruction */
void F1231_11410 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_unqualified_procedure_call_agent */
void F1231_11411 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_unqualified_query_call_agent */
void F1231_11412 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.report_void_constant */
void F1231_11413 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {ET_FEATURE_CHECKER}.set_supplier_handler */
void F1231_11415 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O9237[dtype-1230]) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
	F1035_8357(RTCW(tr1), arg1);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.report_expression_supplier */
void F1231_11416 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9237[Dtype(Current)-1230]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1010_7650(loc1, arg1, arg2, arg3);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.report_argument_supplier */
void F1231_11417 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9237[Dtype(Current)-1230]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1010_7651(loc1, arg1, arg2, arg3);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.report_result_supplier */
void F1231_11418 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9237[Dtype(Current)-1230]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1010_7652(loc1, arg1, arg2, arg3);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.report_static_supplier */
void F1231_11419 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9237[Dtype(Current)-1230]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1010_7653(loc1, arg1, arg2, arg3);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.report_create_supplier */
void F1231_11420 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9237[Dtype(Current)-1230]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1010_7654(loc1, arg1, arg2, arg3);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.report_local_supplier */
void F1231_11421 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9237[Dtype(Current)-1230]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1010_7655(loc1, arg1, arg2, arg3);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.report_inline_agent_argument_supplier */
void F1231_11422 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9237[Dtype(Current)-1230]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1010_7656(loc1, arg1, arg2, arg3);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.report_inline_agent_local_supplier */
void F1231_11423 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9237[Dtype(Current)-1230]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1010_7657(loc1, arg1, arg2, arg3);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.report_inline_agent_result_supplier */
void F1231_11424 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9237[Dtype(Current)-1230]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1010_7658(loc1, arg1, arg2, arg3);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.process_across_expression */
void F1231_11425 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11210(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_across_instruction */
void F1231_11426 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11169(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_assigner_instruction */
void F1231_11427 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11170(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_assignment */
void F1231_11428 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11171(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_assignment_attempt */
void F1231_11429 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11172(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_attribute */
void F1231_11430 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11137(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_bang_instruction */
void F1231_11431 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11173(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_binary_integer_constant */
void F1231_11432 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11211(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_bracket_expression */
void F1231_11433 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11212(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_c1_character_constant */
void F1231_11434 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11213(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_c2_character_constant */
void F1231_11435 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11214(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_c3_character_constant */
void F1231_11436 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11215(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_call_agent */
void F1231_11437 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11312(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_check_instruction */
void F1231_11438 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8997[Dtype(Current)-1230])(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_constant_attribute */
void F1231_11439 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11138(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_convert_builtin_expression */
void F1231_11440 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11217(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_convert_from_expression */
void F1231_11441 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11218(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_convert_to_expression */
void F1231_11442 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11219(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_create_expression */
void F1231_11443 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11221(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_create_instruction */
void F1231_11444 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11175(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_current */
void F1231_11445 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11225(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_current_address */
void F1231_11446 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11226(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_debug_instruction */
void F1231_11447 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9005[Dtype(Current)-1230])(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_deferred_function */
void F1231_11448 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11139(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_deferred_procedure */
void F1231_11449 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11140(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_do_function */
void F1231_11450 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11141(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_do_function_inline_agent */
void F1231_11451 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11324(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_do_procedure */
void F1231_11452 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11142(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_do_procedure_inline_agent */
void F1231_11453 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11325(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_equality_expression */
void F1231_11458 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11227(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_expression_address */
void F1231_11459 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11228(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_extended_attribute */
void F1231_11460 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11147(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_external_function */
void F1231_11461 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8971[Dtype(Current)-1230])(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_external_function_inline_agent */
void F1231_11462 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11326(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_external_procedure */
void F1231_11463 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8972[Dtype(Current)-1230])(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_external_procedure_inline_agent */
void F1231_11464 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11327(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_false_constant */
void F1231_11465 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11229(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_feature_address */
void F1231_11466 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11230(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_hexadecimal_integer_constant */
void F1231_11467 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11232(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_identifier */
void F1231_11468 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tb1 = F1987_19667(RTCW(arg1));
	if (tb1) {
		F1231_11231(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[dtype-1230]));
	} else {
		tb1 = F1987_19663(RTCW(arg1));
		if (tb1) {
			F1231_11240(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[dtype-1230]));
		} else {
			tb1 = F1987_19664(RTCW(arg1));
			if (tb1) {
				F1231_11250(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[dtype-1230]));
			} else {
				tb1 = F1987_19665(RTCW(arg1));
				if (tb1) {
					F1231_11238(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[dtype-1230]));
				} else {
					F1033_8331(Current);
					F2046_21728(RTCV(F1023_8173(Current)));
				}
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.process_if_expression */
void F1231_11469 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11233(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_if_instruction */
void F1231_11470 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11183(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_infix_cast_expression */
void F1231_11471 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11234(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_infix_expression */
void F1231_11472 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11235(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_inspect_instruction */
void F1231_11473 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11184(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_loop_instruction */
void F1231_11474 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11187(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_manifest_array */
void F1231_11475 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11241(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_manifest_tuple */
void F1231_11476 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11245(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_manifest_type */
void F1231_11477 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11246(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_named_object_test */
void F1231_11478 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11247(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_object_equality_expression */
void F1231_11479 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11248(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_object_test */
void F1231_11480 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11249(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_octal_integer_constant */
void F1231_11481 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11251(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_old_expression */
void F1231_11482 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11252(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_old_object_test */
void F1231_11483 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11247(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_once_function */
void F1231_11484 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11150(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_once_function_inline_agent */
void F1231_11485 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11328(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_once_manifest_string */
void F1231_11486 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11253(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_once_procedure */
void F1231_11487 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11151(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_once_procedure_inline_agent */
void F1231_11488 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11329(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_parenthesis_expression */
void F1231_11489 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11258(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]), NULL);
}

/* {ET_FEATURE_CHECKER}.process_parenthesis_instruction */
void F1231_11490 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11193(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_parenthesized_expression */
void F1231_11491 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11254(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_precursor_expression */
void F1231_11492 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1231_11258(Current, loc1, *(EIF_REFERENCE *)(Current + O9257[dtype-1230]), NULL);
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_3_0_0_0_);
		F1722_17132(RTCW(arg1), ti4_1);
	} else {
		F1231_11255(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[dtype-1230]));
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.process_precursor_instruction */
void F1231_11493 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1231_11193(Current, loc1);
	} else {
		F1231_11191(Current, arg1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.process_prefix_expression */
void F1231_11494 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11257(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_qualified_call_expression */
void F1231_11495 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1231_11258(Current, loc1, *(EIF_REFERENCE *)(Current + O9257[dtype-1230]), NULL);
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_3_0_0_0_);
		F1722_17132(RTCW(arg1), ti4_1);
	} else {
		F1231_11258(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[dtype-1230]), NULL);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.process_qualified_call_instruction */
void F1231_11496 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1231_11193(Current, loc1);
	} else {
		F1231_11193(Current, arg1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.process_quantifier_expression */
void F1231_11497 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11264(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_regular_integer_constant */
void F1231_11498 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11267(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_regular_manifest_string */
void F1231_11499 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11268(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_regular_real_constant */
void F1231_11500 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11269(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_repeat_instruction */
void F1231_11501 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11197(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_result */
void F1231_11502 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11270(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_result_address */
void F1231_11503 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11271(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_retry_instruction */
void F1231_11504 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11198(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_semicolon_symbol */
void F1231_11505 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O7067[Dtype(Current)-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {ET_FEATURE_CHECKER}.process_special_manifest_string */
void F1231_11506 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11272(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_static_call_expression */
void F1231_11507 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1231_11258(Current, loc1, *(EIF_REFERENCE *)(Current + O9257[dtype-1230]), NULL);
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_3_0_0_0_);
		F1722_17132(RTCW(arg1), ti4_1);
	} else {
		F1231_11273(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[dtype-1230]));
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.process_static_call_instruction */
void F1231_11508 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1231_11193(Current, loc1);
	} else {
		F1231_11199(Current, arg1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.process_strip_expression */
void F1231_11509 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11277(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_true_constant */
void F1231_11510 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11278(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_underscored_integer_constant */
void F1231_11511 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11279(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_underscored_real_constant */
void F1231_11512 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11280(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_unique_attribute */
void F1231_11513 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11152(Current, arg1);
}

/* {ET_FEATURE_CHECKER}.process_unqualified_call_expression */
void F1231_11514 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1231_11258(Current, loc1, *(EIF_REFERENCE *)(Current + O9257[dtype-1230]), NULL);
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_3_0_0_0_);
		F1722_17132(RTCW(arg1), ti4_1);
	} else {
		F1231_11281(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[dtype-1230]));
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.process_unqualified_call_instruction */
void F1231_11515 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1231_11193(Current, loc1);
	} else {
		F1231_11202(Current, arg1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.process_verbatim_string */
void F1231_11516 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11287(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.process_void */
void F1231_11517 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1231_11288(Current, arg1, *(EIF_REFERENCE *)(Current + O9257[Dtype(Current)-1230]));
}

/* {ET_FEATURE_CHECKER}.current_closure_impl */
EIF_REFERENCE F1231_11523 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9250[dtype-1230]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + O9249[dtype-1230]);
	}/* NOTREACHED */
	
}

/* {ET_FEATURE_CHECKER}.current_universe_impl */
EIF_REFERENCE F1231_11526 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9255[Dtype(Current)-1230]);
	Result = F2027_20637(RTCW(tr1));
	RTLE;
	return Result;
}

/* {ET_FEATURE_CHECKER}.build_assertions_attachment_scope */
void F1231_11534 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O6364[Dtype(arg1)-1002]);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = F1909_18730(RTCW(arg1), loc1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13235[Dtype(RTCW(tr1))-1666])(tr1);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			tr1 = *(EIF_REFERENCE *)(Current + O9268[dtype-1230]);
			F260_2862(RTCW(tr1), loc3, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
		}
		loc1++;
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.build_preconditions_attachment_scope */
void F1231_11535 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,loc5);
	RTLR(4,tr1);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,1908,0xFF01,1836,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc4 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
	}
	F1553_14024(RTCW(loc4), ((EIF_INTEGER_32) 30L));
	F1231_11542(Current, arg1, loc4);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2906[Dtype(RTCW(arg1))-1755])(arg1);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		F1553_14051(RTCW(loc4), loc5, arg1);
	}
	loc3 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_11_0_0_8_);
	if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
	} else {
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 1L))) {
			tr1 = F1545_13932(RTCW(loc4));
			F1231_11534(Current, tr1);
		} else {
			loc1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
			tr1 = F1231_11539(Current);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) tr1;
			tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
			F1250_11971(RTCW(tr1), loc1);
			loc2 = F1231_11539(Current);
			F1466_13433(RTCW(loc4));
			tr1 = F1452_13404(RTCW(loc4));
			F1231_11534(Current, tr1);
			F1250_11971(RTCW(loc2), *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
			for (;;) {
				tb1 = F1473_13452(RTCW(loc4));
				if (tb1) break;
				tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
				F1250_11971(RTCW(tr1), loc1);
				tr1 = F1452_13404(RTCW(loc4));
				F1231_11534(Current, tr1);
				F1250_11972(RTCW(loc2), *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
				F1466_13434(RTCW(loc4));
			}
			F1231_11540(Current, *(EIF_REFERENCE *)(Current + O9267[dtype-1230]));
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + O9267[dtype-1230]) = (EIF_REFERENCE) loc1;
			tr1 = F1452_13404(RTCW(loc4));
			F1231_11534(Current, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + O9267[dtype-1230]);
			F1250_11972(RTCW(tr1), loc2);
			F1231_11540(Current, loc2);
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.new_attachment_scope */
EIF_REFERENCE F1231_11539 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9271[dtype-1230]);
	tb1 = F1432_13373(RTCW(tr1));
	if (tb1) {
		tr1 = RTLNS(eif_new_type(1249, 0x01).id, 1249, _OBJSIZ_3_2_0_0_0_0_0_0_);
		F1250_11948(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O9271[dtype-1230]);
		Result = F1541_13848(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9271[dtype-1230]);
		F1541_13879(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {ET_FEATURE_CHECKER}.free_attachment_scope */
void F1231_11540 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9271[Dtype(Current)-1230]);
	F1541_13864(RTCW(tr1), arg1);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.add_precursors_with_preconditions_recursive */
void F1231_11542 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc4);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,Current);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLR(7,loc3);
	RTLR(8,loc7);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O13763[Dtype(arg1)-1836]);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		F1231_11542(Current, loc4, arg2);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2906[Dtype(loc4)-1755])(loc4);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			F1553_14051(RTCW(arg2), loc5, loc4);
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O13699[Dtype(arg1)-1836]);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc2 = *(EIF_INTEGER_32 *)(loc6+ _LNGOFF_1_0_0_0_);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R6361[Dtype(loc6)-1003])(loc6, loc1);
				F1231_11542(Current, loc3, arg2);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2906[Dtype(RTCW(loc3))-1755])(loc3);
				loc7 = tr1;
				if (EIF_TEST(loc7)) {
					F1553_14051(RTCW(arg2), loc7, loc3);
				}
				loc1++;
			}
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.set_precursor_queries */
void F1231_11553 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O9281[Dtype(Current)-1230]) = (EIF_REFERENCE) arg1;
}

/* {ET_FEATURE_CHECKER}.set_precursor_procedures */
void F1231_11554 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O9282[Dtype(Current)-1230]) = (EIF_REFERENCE) arg1;
}

/* {ET_FEATURE_CHECKER}.character_choice_constant */
static EIF_REFERENCE F1231_11555_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2936)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1935, 0x01).id, 1935, _OBJSIZ_3_0_0_3_0_0_0_0_);
	F1936_19130(RTCW(tr1), (EIF_CHARACTER_32) 97U);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1231_11555 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2936,F1231_11555_body,(Current));
}

/* {ET_FEATURE_CHECKER}.integer_choice_constant */
static EIF_REFERENCE F1231_11556_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2937)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1941, 0x01).id, 1941, _OBJSIZ_5_1_0_2_0_0_1_0_);
	tr2 = RTMS_EX_H("1",1,49);
	F1942_19214(RTCW(tr1), tr2, (EIF_NATURAL_64) ((EIF_INTEGER_32) 1L), (EIF_BOOLEAN) 0);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1231_11556 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2937,F1231_11556_body,(Current));
}

/* {ET_FEATURE_CHECKER}.keep_best_overloaded_features */
void F1231_11558 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4, EIF_BOOLEAN arg5, EIF_BOOLEAN arg6)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc14 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc15 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc16 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc17 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc18 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc19 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc20 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc24 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(18);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg3);
	RTLR(3,tr1);
	RTLR(4,loc22);
	RTLR(5,loc1);
	RTLR(6,loc3);
	RTLR(7,loc21);
	RTLR(8,loc9);
	RTLR(9,loc12);
	RTLR(10,loc23);
	RTLR(11,loc10);
	RTLR(12,arg4);
	RTLR(13,loc13);
	RTLR(14,loc24);
	RTLR(15,loc11);
	RTLR(16,loc2);
	RTLR(17,arg2);
	RTLIU(18);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O7067[dtype-1032]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc7 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_1_);
	if ((EIF_BOOLEAN)(arg3 != NULL)) {
		loc5 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2266[Dtype(RTCW(arg3))-899])(arg3);
	}
	if ((EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 1L))) {
		loc6 = (EIF_INTEGER_32) loc7;
		for (;;) {
			if ((EIF_BOOLEAN) (loc6 < ((EIF_INTEGER_32) 1L))) break;
			tr1 = F1541_13846(RTCW(arg1), loc6);
			ti4_1 = F1837_17834(RTCW(tr1));
			if ((EIF_BOOLEAN)(ti4_1 != loc5)) {
				F1541_13880(RTCW(arg1), loc6);
				loc7--;
			} else {
				tb1 = '\0';
				if (arg5) {
					tb2 = '\01';
					tr1 = F1541_13846(RTCW(arg1), loc6);
					loc22 = tr1;
					loc22 = RTRV(eif_new_type(1837, 0x01),loc22);
					if (!((EIF_BOOLEAN) !EIF_TEST(loc22))) {
						tb3 = (RTNA((loc22)), ((EIF_BOOLEAN) 0));
						tb2 = (EIF_BOOLEAN) !tb3;
					}
					tb1 = tb2;
				}
				if (tb1) {
					F1541_13880(RTCW(arg1), loc6);
					loc7--;
				} else {
					if (arg6) {
					}
				}
			}
			loc6--;
		}
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN)(arg3 != NULL)) && (EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 0L)))) {
		loc1 = F1231_11571(Current, *(EIF_REFERENCE *)(Current + O9254[dtype-1230]));
		tr1 = F1023_8169(Current);
		loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + O12741[Dtype(tr1)-1610]);
		loc21 = F1231_11565(Current);
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc4 > loc5)) break;
			loc9 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R2265[Dtype(RTCW(arg3))-899])(arg3, loc4);
			F1231_11290(Current, loc9, loc1, loc3);
			if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
				loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L));
			} else {
				loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				loc16 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc6 = (EIF_INTEGER_32) loc7;
				for (;;) {
					if ((EIF_BOOLEAN) (loc6 < ((EIF_INTEGER_32) 1L))) break;
					loc12 = F1541_13846(RTCW(arg1), loc6);
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10399[Dtype(RTCW(loc12))-1840])(loc12);
					loc23 = tr1;
					if ((EIF_BOOLEAN) !EIF_TEST(loc23)) {
						F1033_8331(Current);
						F2046_21728(RTCV(F1023_8173(Current)));
						F1541_13880(RTCW(arg1), loc6);
						loc7--;
						if ((EIF_BOOLEAN) (loc6 <= loc19)) {
							loc18 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							loc19--;
							loc20--;
						} else {
							if ((EIF_BOOLEAN) (loc6 <= loc20)) {
								loc18 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								loc20--;
							}
						}
					} else {
						tr1 = F1649_16721(loc23, loc4);
						loc10 = F1814_17596(RTCW(tr1));
						tb1 = F2022_20365(RTCW(loc1), loc10, arg4);
						if (tb1) {
							if (loc14) {
								F1541_13864(RTCW(loc21), loc12);
							} else {
								loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								loc16 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								F1541_13892(RTCW(loc21));
								F1541_13864(RTCW(loc21), loc12);
							}
						} else {
							tb1 = F2022_20377(RTCW(loc1), loc10, arg4, *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
							if (tb1) {
								if (loc14) {
								} else {
									if (loc15) {
										loc17 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
										loc8 = *(EIF_INTEGER_32 *)(RTCW(loc21)+ _LNGOFF_4_0_0_1_);
										for (;;) {
											if ((EIF_BOOLEAN) (loc8 < ((EIF_INTEGER_32) 1L))) break;
											loc13 = F1541_13846(RTCW(loc21), loc8);
											tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10399[Dtype(RTCW(loc13))-1840])(loc13);
											loc24 = tr1;
											if ((EIF_BOOLEAN) !EIF_TEST(loc24)) {
												F1033_8331(Current);
												F2046_21728(RTCV(F1023_8173(Current)));
												F1541_13880(RTCW(loc21), loc8);
											} else {
												tr1 = F1649_16721(loc24, loc4);
												loc11 = F1814_17596(RTCW(tr1));
												tb1 = F1884_18234(RTCW(loc11), loc10, arg4, arg4);
												if (tb1) {
													loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
												} else {
													tb1 = F1829_17710(RTCW(loc11), loc10, arg4, arg4, *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
													if (tb1) {
														loc17 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
														loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
													} else {
														tb1 = F1829_17710(RTCW(loc10), loc11, arg4, arg4, *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
														if (tb1) {
															F1541_13880(RTCW(loc21), loc8);
														}
													}
												}
											}
											loc8--;
										}
										if (loc17) {
											F1541_13864(RTCW(loc21), loc12);
										}
									} else {
										loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
										loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
										loc16 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
										F1541_13892(RTCW(loc21));
										F1541_13864(RTCW(loc21), loc12);
									}
								}
							} else {
								loc2 = (EIF_REFERENCE) arg4;
								F899_7054(RTCW(loc2), loc10);
								tr1 = *(EIF_REFERENCE *)(Current + O8990[dtype-1230]);
								tr1 = F1035_8345(RTCW(tr1), loc1, loc2);
								if ((EIF_BOOLEAN)(tr1 != NULL)) {
									if (loc16) {
										F1541_13864(RTCW(loc21), loc12);
									}
								} else {
									F1541_13880(RTCW(arg1), loc6);
									loc7--;
									if ((EIF_BOOLEAN) (loc6 <= loc19)) {
										loc18 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
										loc19--;
										loc20--;
									} else {
										if ((EIF_BOOLEAN) (loc6 <= loc20)) {
											loc18 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
											loc20--;
										}
									}
								}
								F899_7057(RTCW(loc2));
							}
						}
					}
					loc6--;
				}
				if ((EIF_BOOLEAN) !loc18) {
					if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 1L))) {
						loc19 = *(EIF_INTEGER_32 *)(RTCW(loc21)+ _LNGOFF_4_0_0_1_);
						loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						for (;;) {
							if ((EIF_BOOLEAN)(loc20 == loc19)) break;
							tr1 = F1541_13846(RTCW(arg1), loc6);
							tb1 = F1541_13853(RTCW(loc21), tr1);
							if (tb1) {
								loc20++;
								F1503_13546(RTCW(arg1), loc6, loc20);
							}
							loc6++;
						}
					} else {
						loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						for (;;) {
							if ((EIF_BOOLEAN) (loc6 > loc19)) break;
							tr1 = F1541_13846(RTCW(arg1), loc6);
							tb1 = F1541_13853(RTCW(loc21), tr1);
							if (tb1) {
								loc6++;
							} else {
								F1503_13546(RTCW(arg1), loc6, loc19);
								loc19--;
							}
						}
						loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc20 + ((EIF_INTEGER_32) 1L));
						for (;;) {
							if ((EIF_BOOLEAN) (loc6 > loc7)) break;
							tr1 = F1541_13846(RTCW(arg1), loc6);
							tb1 = F1541_13853(RTCW(loc21), tr1);
							if (tb1) {
								loc20++;
								F1503_13546(RTCW(arg1), loc6, loc20);
							}
							loc6++;
						}
					}
				} else {
					loc18 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc19 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					loc20 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				}
				F1541_13892(RTCW(loc21));
			}
			F899_7060(RTCW(loc1));
			loc4++;
		}
		F1231_11566(Current, loc21);
		F1231_11572(Current, loc1);
		if (*(EIF_BOOLEAN *)(Current + O7067[dtype-1032])) {
			F1541_13892(RTCW(arg1));
		} else {
			if ((EIF_BOOLEAN) (loc19 > ((EIF_INTEGER_32) 0L))) {
				F1541_13889(RTCW(arg1), loc19);
			} else {
				if ((EIF_BOOLEAN) (loc20 > ((EIF_INTEGER_32) 0L))) {
					F1541_13889(RTCW(arg1), loc20);
				} else {
					F1541_13892(RTCW(arg1));
				}
			}
		}
	}
	loc7 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_1_);
	if ((EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 1L))) {
		loc19 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc6 > loc7)) break;
			tr1 = F1541_13846(RTCW(arg1), loc6);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O13691[Dtype(tr1)-1836]);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R13652[Dtype(RTCW(tr1))-1825])(tr1, arg2);
			if (tb1) {
				loc19++;
				F1503_13546(RTCW(arg1), loc6, loc19);
			}
			loc6++;
		}
		if ((EIF_BOOLEAN) (loc19 > ((EIF_INTEGER_32) 0L))) {
			F1541_13889(RTCW(arg1), loc19);
		}
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.new_overloaded_procedures */
EIF_REFERENCE F1231_11559 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9291[dtype-1230]);
	tb1 = F1432_13373(RTCW(tr1));
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1540,0xFF01,1860,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNS(typres0.id, 1540, _OBJSIZ_4_0_0_2_0_0_0_0_);
		}
		F1541_13840(RTCW(tr1), ((EIF_INTEGER_32) 20L));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O9291[dtype-1230]);
		Result = F1541_13848(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9291[dtype-1230]);
		F1541_13879(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {ET_FEATURE_CHECKER}.free_overloaded_procedures */
void F1231_11560 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1541_13892(RTCW(arg1));
	tr1 = *(EIF_REFERENCE *)(Current + O9291[Dtype(Current)-1230]);
	F1541_13864(RTCW(tr1), arg1);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.new_overloaded_queries */
EIF_REFERENCE F1231_11562 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9294[dtype-1230]);
	tb1 = F1432_13373(RTCW(tr1));
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1540,0xFF01,1838,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNS(typres0.id, 1540, _OBJSIZ_4_0_0_2_0_0_0_0_);
		}
		F1541_13840(RTCW(tr1), ((EIF_INTEGER_32) 20L));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O9294[dtype-1230]);
		Result = F1541_13848(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9294[dtype-1230]);
		F1541_13879(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {ET_FEATURE_CHECKER}.free_overloaded_queries */
void F1231_11563 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1541_13892(RTCW(arg1));
	tr1 = *(EIF_REFERENCE *)(Current + O9294[Dtype(Current)-1230]);
	F1541_13864(RTCW(tr1), arg1);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.new_overloaded_features */
EIF_REFERENCE F1231_11565 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9297[dtype-1230]);
	tb1 = F1432_13373(RTCW(tr1));
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1540,0xFF01,1836,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNS(typres0.id, 1540, _OBJSIZ_4_0_0_2_0_0_0_0_);
		}
		F1541_13840(RTCW(tr1), ((EIF_INTEGER_32) 20L));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O9297[dtype-1230]);
		Result = F1541_13848(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9297[dtype-1230]);
		F1541_13879(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {ET_FEATURE_CHECKER}.free_overloaded_features */
void F1231_11566 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1541_13892(RTCW(arg1));
	tr1 = *(EIF_REFERENCE *)(Current + O9297[Dtype(Current)-1230]);
	F1541_13864(RTCW(tr1), arg1);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.new_call_info */
EIF_REFERENCE F1231_11568 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,arg1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9300[dtype-1230]);
	tb1 = F1432_13373(RTCW(tr1));
	if (tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,3,1085,1838,0xFF01,2026,0xFF01,2022,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNTS(typres0.id, 4, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = loc1;
		RTAR(tr1,loc1);
		tr2 = RTOUCR(5,F396_5268, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		((EIF_TYPED_VALUE *)tr1+2)->it_r = tr2;
		RTAR(tr1,tr2);
		((EIF_TYPED_VALUE *)tr1+3)->it_r = arg1;
		RTAR(tr1,arg1);
		Result = (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O9300[dtype-1230]);
		Result = F1541_13848(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9300[dtype-1230]);
		F1541_13879(RTCW(tr1));
		
		eif_put_reference_item(RTCW(Result),1,loc1);
		tr1 = RTOUCR(5,F396_5268, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		
		eif_put_reference_item(RTCW(Result),2,tr1);
		
		eif_put_reference_item(RTCW(Result),3,arg1);
	}
	RTLE;
	return Result;
}

/* {ET_FEATURE_CHECKER}.free_call_info */
void F1231_11569 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9300[dtype-1230]);
	F1541_13864(RTCW(tr1), arg1);
	
	eif_put_reference_item(RTCW(arg1),1,NULL);
	tr1 = RTOUCR(5,F396_5268, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	
	eif_put_reference_item(RTCW(arg1),2,tr1);
	tr2 = *(EIF_REFERENCE *)(Current + O9257[dtype-1230]);
	
	eif_put_reference_item(RTCW(arg1),3,tr2);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.new_context */
EIF_REFERENCE F1231_11571 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9303[dtype-1230]);
	tb1 = F1432_13373(RTCW(tr1));
	if (tb1) {
		tr1 = RTLNS(eif_new_type(2022, 0x01).id, 2022, _OBJSIZ_2_0_0_1_0_0_0_0_);
		F2023_20388(RTCW(tr1), arg1, ((EIF_INTEGER_32) 100L));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O9303[dtype-1230]);
		Result = F1541_13848(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + O9303[dtype-1230]);
		F1541_13879(RTCW(tr1));
		F2023_20389(RTCW(Result), arg1);
	}
	RTLE;
	return Result;
}

/* {ET_FEATURE_CHECKER}.free_context */
void F1231_11572 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O9303[Dtype(Current)-1230]);
	F1541_13864(RTCW(tr1), arg1);
	tr1 = RTOUCR(5,F396_5268, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F2023_20389(RTCW(arg1), tr1);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.update_common_ancestor_type_list */
void F1231_11576 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,loc4);
	RTLR(2,arg1);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg3 + ((EIF_INTEGER_32) 1L));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_4_0_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc4 = F1541_13846(RTCW(arg2), loc1);
		tb1 = F2022_20379(RTCW(arg1), loc4, *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
		if (tb1) {
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		} else {
			tb1 = F2022_20379(RTCW(loc4), arg1, *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
			if (tb1) {
				F1231_11572(Current, loc4);
				F1541_13880(RTCW(arg2), loc1);
				loc2--;
			} else {
				tr1 = RTOUCR(604,F396_4599, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				F899_7054(RTCW(loc4), tr1);
				tb1 = F2022_20379(RTCW(arg1), loc4, *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
				if (tb1) {
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				} else {
					F899_7057(RTCW(loc4));
					tr1 = RTOUCR(604,F396_4599, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					F899_7054(RTCW(arg1), tr1);
					tb1 = F2022_20379(RTCW(loc4), arg1, *(EIF_REFERENCE *)(Current + O6923[dtype-1022]));
					if (tb1) {
						F1231_11572(Current, loc4);
						F1541_13880(RTCW(arg2), loc1);
						loc2--;
					} else {
						F899_7057(RTCW(arg1));
						loc1++;
					}
				}
			}
		}
	}
	if (loc3) {
		F1541_13864(RTCW(arg2), arg1);
	} else {
		F1231_11572(Current, arg1);
	}
	RTLE;
}

/* {ET_FEATURE_CHECKER}.free_common_ancestor_types */
void F1231_11577 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = F1541_13846(RTCW(arg1), loc1);
		F1231_11572(Current, tr1);
		loc1++;
	}
	F1541_13889(RTCW(arg1), arg2);
	RTLE;
}

/* {ET_FEATURE_CHECKER}.feature_checker */
EIF_REFERENCE F1231_11581 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

/* {ET_FEATURE_CHECKER}.dummy_feature */
static EIF_REFERENCE F1231_11582_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1715)

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	loc1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr1 = RTMS_EX_H("**dummy**",9,1199116074);
	F1987_19652(RTCW(loc1), tr1);
	tr1 = RTLNS(eif_new_type(1863, 0x01).id, 1863, _OBJSIZ_21_3_0_4_0_0_0_0_);
	F1864_17999(RTCW(tr1), loc1, NULL, *(EIF_REFERENCE *)(Current + O6920[Dtype(Current)-1022]));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1231_11582 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1715,F1231_11582_body,(Current));
}

void EIF_Minit542 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
