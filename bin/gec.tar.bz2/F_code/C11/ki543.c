/*
 * Code for class KI_CHARACTER_OUTPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ki543.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KI_CHARACTER_OUTPUT_STREAM}.put_integer */
void F1232_11585 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_64 ti8_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti8_1 = (EIF_INTEGER_64) arg1;
	F1232_11589(Current, ti8_1);
	RTLE;
}

/* {KI_CHARACTER_OUTPUT_STREAM}.put_integer_64 */
void F1232_11589 (EIF_REFERENCE Current, EIF_INTEGER_64 arg1)
{
	GTCX
	EIF_INTEGER_64 loc1 = (EIF_INTEGER_64) 0;
	EIF_INTEGER_64 loc2 = (EIF_INTEGER_64) 0;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '0');
	} else {
		if ((EIF_BOOLEAN) (arg1 < (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '-');
			loc1 = (EIF_INTEGER_64) (EIF_INTEGER_64) -(EIF_INTEGER_64) (arg1 + (EIF_INTEGER_64) ((EIF_INTEGER_32) 1L));
			loc2 = (EIF_INTEGER_64) (EIF_INTEGER_64) (loc1 / (EIF_INTEGER_64) ((EIF_INTEGER_32) 10L));
			switch ((EIF_INTEGER_64) (loc1 % (EIF_INTEGER_64) ((EIF_INTEGER_32) 10L))) {
				case RTI64C(0):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F1232_11589(Current, loc2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '1');
					break;
				case RTI64C(1):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F1232_11589(Current, loc2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '2');
					break;
				case RTI64C(2):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F1232_11589(Current, loc2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '3');
					break;
				case RTI64C(3):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F1232_11589(Current, loc2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '4');
					break;
				case RTI64C(4):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F1232_11589(Current, loc2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '5');
					break;
				case RTI64C(5):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F1232_11589(Current, loc2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '6');
					break;
				case RTI64C(6):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F1232_11589(Current, loc2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '7');
					break;
				case RTI64C(7):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F1232_11589(Current, loc2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '8');
					break;
				case RTI64C(8):
					if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
						F1232_11589(Current, loc2);
					}
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '9');
					break;
				case RTI64C(9):
					F1232_11589(Current, (EIF_INTEGER_64) (loc2 + (EIF_INTEGER_64) ((EIF_INTEGER_32) 1L)));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '0');
					break;
				default:
					RTEC(EN_WHEN);
			}
		} else {
			loc1 = (EIF_INTEGER_64) arg1;
			loc2 = (EIF_INTEGER_64) (EIF_INTEGER_64) (loc1 / (EIF_INTEGER_64) ((EIF_INTEGER_32) 10L));
			if ((EIF_BOOLEAN)(loc2 != (EIF_INTEGER_64) ((EIF_INTEGER_32) 0L))) {
				F1232_11589(Current, loc2);
			}
			switch ((EIF_INTEGER_64) (loc1 % (EIF_INTEGER_64) ((EIF_INTEGER_32) 10L))) {
				case RTI64C(0):
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '0');
					break;
				case RTI64C(1):
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '1');
					break;
				case RTI64C(2):
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '2');
					break;
				case RTI64C(3):
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '3');
					break;
				case RTI64C(4):
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '4');
					break;
				case RTI64C(5):
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '5');
					break;
				case RTI64C(6):
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '6');
					break;
				case RTI64C(7):
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '7');
					break;
				case RTI64C(8):
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '8');
					break;
				case RTI64C(9):
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '9');
					break;
				default:
					RTEC(EN_WHEN);
			}
		}
	}
	RTLE;
}

/* {KI_CHARACTER_OUTPUT_STREAM}.put_natural_32 */
void F1232_11592 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_NATURAL_64 tu8_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu8_1 = (EIF_NATURAL_64) arg1;
	F1232_11593(Current, tu8_1);
	RTLE;
}

/* {KI_CHARACTER_OUTPUT_STREAM}.put_natural_64 */
void F1232_11593 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	EIF_NATURAL_64 loc1 = (EIF_NATURAL_64) 0;
	EIF_NATURAL_64 loc2 = (EIF_NATURAL_64) 0;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '0');
	} else {
		loc1 = (EIF_NATURAL_64) arg1;
		loc2 = (EIF_NATURAL_64) (EIF_NATURAL_64) (loc1 / (EIF_NATURAL_64) ((EIF_INTEGER_32) 10L));
		if ((EIF_BOOLEAN)(loc2 != (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L))) {
			F1232_11593(Current, loc2);
		}
		switch ((EIF_NATURAL_64) (loc1 % (EIF_NATURAL_64) ((EIF_INTEGER_32) 10L))) {
			case RTU64C(0):
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '0');
				break;
			case RTU64C(1):
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '1');
				break;
			case RTU64C(2):
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '2');
				break;
			case RTU64C(3):
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '3');
				break;
			case RTU64C(4):
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '4');
				break;
			case RTU64C(5):
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '5');
				break;
			case RTU64C(6):
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '6');
				break;
			case RTU64C(7):
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '7');
				break;
			case RTU64C(8):
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '8');
				break;
			case RTU64C(9):
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R1167[dtype-1235])(Current, (EIF_CHARACTER_8) '9');
				break;
			default:
				RTEC(EN_WHEN);
		}
	}
	RTLE;
}

/* {KI_CHARACTER_OUTPUT_STREAM}.append */
void F1232_11595 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1200, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2236[Dtype(loc1)-1210])(loc1);
		if ((EIF_BOOLEAN) !tb1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R8716[Dtype(loc1)-1210])(loc1, ((EIF_INTEGER_32) 512L));
		}
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2236[Dtype(loc1)-1210])(loc1);
			if (tb1) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8718[Dtype(loc1)-1210])(loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R9313[Dtype(Current)-1235])(Current, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R8716[Dtype(loc1)-1210])(loc1, ((EIF_INTEGER_32) 512L));
		}
	} else {
		F105_1185(Current, arg1);
	}
	RTLE;
}

void EIF_Minit543 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
