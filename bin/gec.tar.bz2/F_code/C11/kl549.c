/*
 * Code for class KL_STDOUT_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl549.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STDOUT_FILE}.make */
void F1238_11620 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {KL_STDOUT_FILE}.eol */

EIF_REFERENCE F1238_11622 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1684,RTMS_EX_H("\012",1,10));
}

/* {KL_STDOUT_FILE}.put_character */
void F1238_11624 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(1685,F1238_11627, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5363[Dtype(RTCW(tr1))-1261])(tr1, arg1);
	RTLE;
}

/* {KL_STDOUT_FILE}.put_string */
void F1238_11625 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOUCR(10,F1207_10828, (Current));
	loc1 = F1198_10719(RTCW(tr1), arg1);
	tr1 = RTOUCR(1685,F1238_11627, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5361[Dtype(RTCW(tr1))-1261])(tr1, loc1);
	RTLE;
}

/* {KL_STDOUT_FILE}.console */
static EIF_REFERENCE F1238_11627_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1685)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTOUCR(546,F66_788, (RTCV(RTOUCR(14,F1_24, (Current)))));
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1238_11627 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1685,F1238_11627_body,(Current));
}

void EIF_Minit549 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
