
#ifndef _C11_kl538_
#define _C11_kl538_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1227_11084(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit538(void);
extern EIF_BOOLEAN F1198_10706(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1207_10828(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
