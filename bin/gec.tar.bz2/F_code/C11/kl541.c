/*
 * Code for class KL_SHELL_COMMAND
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl541.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SHELL_COMMAND}.make */
void F1230_11123 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(10,F1207_10828, (Current));
	tr1 = F1198_10719(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {KL_SHELL_COMMAND}.command */
EIF_REFERENCE F1230_11124 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {KL_SHELL_COMMAND}.exit_code */
EIF_INTEGER_32 F1230_11125 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_1_);
}


/* {KL_SHELL_COMMAND}.is_system_code */
EIF_BOOLEAN F1230_11126 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_);
}


/* {KL_SHELL_COMMAND}.execute */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1230_11127 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	RTLD;
	RTXD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,saved_except);
	RTLIU(2);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc1) {
		F432_5876(Current, *(EIF_REFERENCE *)(Current));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_1_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_0_);
		tb1 = RTOUCB(EIF_BOOLEAN,7,F39_460, (RTCV(RTOUCR(8,F461_6141, (Current)))));
		if (tb1) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			if ((EIF_BOOLEAN)((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_1_) % ((EIF_INTEGER_32) 256L)) == ((EIF_INTEGER_32) 0L))) {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_1_)) /= ((EIF_INTEGER_32) 256L);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_1_)) %= ((EIF_INTEGER_32) 256L);
				*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	} else {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_2_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTE_E
	RTXSC;
	if ((EIF_BOOLEAN) !loc1) {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

void EIF_Minit541 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
