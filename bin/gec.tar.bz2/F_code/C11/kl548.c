/*
 * Code for class KL_STDERR_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl548.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_STDERR_FILE}.make */
void F1237_11612 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {KL_STDERR_FILE}.eol */

EIF_REFERENCE F1237_11614 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1702,RTMS_EX_H("\012",1,10));
}

/* {KL_STDERR_FILE}.put_character */
void F1237_11616 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(1703,F1237_11619, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R5363[Dtype(RTCW(tr1))-1261])(tr1, arg1);
	RTLE;
}

/* {KL_STDERR_FILE}.put_string */
void F1237_11617 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOUCR(10,F1207_10828, (Current));
	loc1 = F1198_10719(RTCW(tr1), arg1);
	tr1 = RTOUCR(1703,F1237_11619, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5361[Dtype(RTCW(tr1))-1261])(tr1, loc1);
	RTLE;
}

/* {KL_STDERR_FILE}.console */
static EIF_REFERENCE F1237_11619_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1703)

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTOUCR(547,F66_789, (RTCV(RTOUCR(14,F1_24, (Current)))));
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1237_11619 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1703,F1237_11619_body,(Current));
}

void EIF_Minit548 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
