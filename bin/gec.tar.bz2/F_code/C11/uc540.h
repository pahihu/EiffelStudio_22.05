
#ifndef _C11_uc540_
#define _C11_uc540_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1229_11122(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit540(void);
extern EIF_REFERENCE F1207_10828(EIF_REFERENCE);
extern EIF_BOOLEAN F1198_10705(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
