/*
 * Code for class KL_NULL_TEXT_OUTPUT_STREAM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl547.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_NULL_TEXT_OUTPUT_STREAM}.make */
void F1236_11605 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {KL_NULL_TEXT_OUTPUT_STREAM}.put_character */
void F1236_11606 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	RTGC;
}

/* {KL_NULL_TEXT_OUTPUT_STREAM}.put_string */
void F1236_11607 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {KL_NULL_TEXT_OUTPUT_STREAM}.name */
EIF_REFERENCE F1236_11609 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current);
}


/* {KL_NULL_TEXT_OUTPUT_STREAM}.eol */

EIF_REFERENCE F1236_11610 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2969,RTMS_EX_H("\012",1,10));
}

void EIF_Minit547 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
