/*
 * Code for class ET_STANDALONE_CLOSURE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et511.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_STANDALONE_CLOSURE}.is_feature */
EIF_BOOLEAN F1200_10791 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {ET_STANDALONE_CLOSURE}.is_invariants */
EIF_BOOLEAN F1200_10792 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {ET_STANDALONE_CLOSURE}.set_validity_checked */
void F1200_10800 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O8708[Dtype(Current)-1199]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {ET_STANDALONE_CLOSURE}.set_validity_error */
void F1200_10801 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O8709[Dtype(Current)-1199]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {ET_STANDALONE_CLOSURE}.reset_validity_checked */
void F1200_10802 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O8709[dtype-1199]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current + O8708[dtype-1199]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {ET_STANDALONE_CLOSURE}.as_feature */
EIF_REFERENCE F1200_10803 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	RTCT0("is_feature", EX_CHECK);
		RTCF0;
	return (EIF_REFERENCE) 0;
}

/* {ET_STANDALONE_CLOSURE}.as_invariants */
EIF_REFERENCE F1200_10804 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	RTCT0("is_invariants", EX_CHECK);
		RTCF0;
	return (EIF_REFERENCE) 0;
}

void EIF_Minit511 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
