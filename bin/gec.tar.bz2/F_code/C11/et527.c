/*
 * Code for class ET_ECF_CUSTOM_CONDITION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et527.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ECF_CUSTOM_CONDITION}.make */
void F1216_10955 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg3;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {ET_ECF_CUSTOM_CONDITION}.make_excluded */
void F1216_10956 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg3;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {ET_ECF_CUSTOM_CONDITION}.match_case_insensitive */

EIF_REFERENCE F1216_10961 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (3075,RTMS_EX_H("case-insensitive",16,1969688933));
}

/* {ET_ECF_CUSTOM_CONDITION}.match_wildcard */

EIF_REFERENCE F1216_10962 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (3076,RTMS_EX_H("wildcard",8,1069088100));
}

/* {ET_ECF_CUSTOM_CONDITION}.match_regexp */

EIF_REFERENCE F1216_10963 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (3077,RTMS_EX_H("regexp",6,1959612016));
}

/* {ET_ECF_CUSTOM_CONDITION}.is_enabled */
EIF_BOOLEAN F1216_10964 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc4);
	RTLR(5,tr2);
	RTLR(6,loc2);
	RTLR(7,loc1);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_7_);
	tr1 = F1243_11642(RTCW(tr1), *(EIF_REFERENCE *)(Current));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = tr1;
		if ((EIF_BOOLEAN) !EIF_TEST(loc4)) {
			tr1 = RTOUCR(10,F1207_10828, (Current));
			Result = F1198_10705(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), loc3);
		} else {
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr2 = RTOUCR(3075,F1216_10961, (Current));
			tb1 = F1198_10706(RTCW(tr1), loc4, tr2);
			if (tb1) {
				tr1 = RTOUCR(10,F1207_10828, (Current));
				Result = F1198_10706(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), loc3);
			} else {
				tr1 = RTOUCR(10,F1207_10828, (Current));
				tr2 = RTOUCR(3076,F1216_10962, (Current));
				tb1 = F1198_10706(RTCW(tr1), loc4, tr2);
				if (tb1) {
					loc2 = RTLNS(eif_new_type(2041, 0x01).id, 2041, _OBJSIZ_5_1_0_8_0_0_0_0_);
					F2039_21086(RTCW(loc2), *(EIF_REFERENCE *)(Current + _REFACS_1_));
					tb1 = F2040_21091(RTCW(loc2));
					if (tb1) {
						Result = F2040_21093(RTCW(loc2), loc3);
					}
				} else {
					tr1 = RTOUCR(10,F1207_10828, (Current));
					tr2 = RTOUCR(3077,F1216_10963, (Current));
					tb1 = F1198_10706(RTCW(tr1), loc4, tr2);
					if (tb1) {
						loc1 = RTLNS(eif_new_type(2143, 0x01).id, 2143, _OBJSIZ_12_16_0_23_0_0_2_0_);
						F2143_26920(RTCW(loc1));
						F2143_26923(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
						tb1 = F2142_26833(RTCW(loc1));
						if (tb1) {
							Result = F2037_21052(RTCW(loc1), loc3);
						}
					} else {
						tr1 = RTOUCR(10,F1207_10828, (Current));
						Result = F1198_10705(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), loc3);
					}
				}
			}
		}
	}
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) != Result);
}

void EIF_Minit527 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
