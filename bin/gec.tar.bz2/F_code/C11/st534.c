/*
 * Code for class ST_WORD_WRAPPER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st534.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ST_WORD_WRAPPER}.make */
void F1223_11037 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 79L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {ST_WORD_WRAPPER}.set_maximum_text_width */
void F1223_11043 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {ST_WORD_WRAPPER}.set_new_line_indentation */
void F1223_11044 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) = (EIF_INTEGER_32) arg1;
}

/* {ST_WORD_WRAPPER}.wrapped_string */
EIF_REFERENCE F1223_11045 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc6);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOUCR(10,F1207_10828, (Current));
	loc1 = F1198_10712(RTCW(tr1), arg1);
	F1223_11046(Current, loc1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
	loc6 = RTLNS(eif_new_type(1184, 0x01).id, 1184, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1183_10472(RTCW(loc6), (EIF_CHARACTER_8) ' ', *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_));
	Result = RTLNS(eif_new_type(1184, 0x01).id, 1184, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	F1183_10471(RTCW(Result), ti4_1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc4 > loc2)) break;
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc4 + loc3) <= loc2)) {
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + loc3);
			for (;;) {
				tb1 = '\01';
				if (!(EIF_BOOLEAN)(loc5 == loc4)) {
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5908[Dtype(RTCW(loc1))-829])(loc1, loc5));
					tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) ' ');
				}
				if (tb1) break;
				loc5--;
			}
		} else {
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		}
		if ((EIF_BOOLEAN)(loc5 == loc4)) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_2_))++;
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 + loc3) - ((EIF_INTEGER_32) 1L));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8343[Dtype(RTCW(loc1))-1180])(loc1, loc4, loc5);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8527[Dtype(RTCW(Result))-1184])(Result, tr1);
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8343[Dtype(RTCW(loc1))-1180])(loc1, loc4, (EIF_INTEGER_32) (loc5 - ((EIF_INTEGER_32) 1L)));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8527[Dtype(RTCW(Result))-1184])(Result, tr1);
		}
		loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc4 <= ti4_1)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(Result))-1184])(Result, (EIF_CHARACTER_8) '\012');
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8527[Dtype(RTCW(Result))-1184])(Result, loc6);
		}
		loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 - ti4_1);
	}
	RTLE;
	return Result;
}

/* {ST_WORD_WRAPPER}.canonify_whitespace */
void F1223_11046 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5908[Dtype(RTCW(arg1))-829])(arg1, loc1));
		if (F1223_11047(Current, loc3)) {
			tc1 = (EIF_CHARACTER_8) ' ';
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5674[Dtype(RTCW(arg1))-829])(arg1, (EIF_REFERENCE) &tc1, (EIF_REFERENCE) &loc1);
		}
		loc1++;
	}
	RTLE;
}

/* {ST_WORD_WRAPPER}.is_space */
EIF_BOOLEAN F1223_11047 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) ' ') || (EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) '\011')) || (EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) '\012')) || (EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) '\015'));
}

void EIF_Minit534 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
