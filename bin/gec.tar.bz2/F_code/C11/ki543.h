
#ifndef _C11_ki543_
#define _C11_ki543_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1232_11585(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1232_11589(EIF_REFERENCE, EIF_INTEGER_64);
extern void F1232_11592(EIF_REFERENCE, EIF_NATURAL_32);
extern void F1232_11593(EIF_REFERENCE, EIF_NATURAL_64);
extern void F1232_11595(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit543(void);
extern void F105_1185(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R8716[])();
extern char *(*R8718[])();
extern char *(*R1167[])();
extern char *(*R9313[])();
extern char *(*R2236[])();

#ifdef __cplusplus
}
#endif

#endif
