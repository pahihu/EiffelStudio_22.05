
#ifndef _C11_ki512_
#define _C11_ki512_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1201_10807(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit512(void);
extern char *(*R5674[])();
extern char *(*R2230[])();
extern char *(*R2236[])();
extern char *(*R2239[])();

#ifdef __cplusplus
}
#endif

#endif
