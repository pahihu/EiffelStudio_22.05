
#ifndef _C11_st534_
#define _C11_st534_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1223_11037(EIF_REFERENCE);
extern void F1223_11043(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1223_11044(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1223_11045(EIF_REFERENCE, EIF_REFERENCE);
extern void F1223_11046(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1223_11047(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit534(void);
extern EIF_REFERENCE F1198_10712(EIF_REFERENCE, EIF_REFERENCE);
extern void F1183_10471(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1183_10472(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern EIF_REFERENCE F1207_10828(EIF_REFERENCE);
extern char *(*R8343[])();
extern char *(*R8527[])();
extern char *(*R8529[])();
extern char *(*R5674[])();
extern char *(*R5908[])();

#ifdef __cplusplus
}
#endif

#endif
