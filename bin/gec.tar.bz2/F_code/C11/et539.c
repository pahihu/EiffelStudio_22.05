/*
 * Code for class ET_BUILTIN_FEATURE_CHECKER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et539.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_BUILTIN_FEATURE_CHECKER}.make */
void F1228_11085 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1574,0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,1109,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1559_14024(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	F1023_8167(Current, arg1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_feature_validity */
void F1228_11086 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_3_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc1 = *(EIF_REFERENCE *)(Current);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O13762[Dtype(arg1)-1836]);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13071[Dtype(RTCW(arg1))-1646])(arg1, Current);
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.unknown_builtin_reported */
EIF_BOOLEAN F1228_11087 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1) + O10202[Dtype(tr1)-1289]);
	RTLE;
	return Result;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_external_feature_validity */
void F1228_11088 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOUCR(10,F1207_10828, (Current));
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	tr2 = F1930_19078(RTCW(tr2));
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14405[Dtype(RTCW(tr2))-1930])(tr2);
	tr3 = RTOUCR(2753,F396_5251, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	tb1 = F1198_10706(RTCW(tr1), tr2, tr3);
	if (tb1) {
		F1228_11089(Current, arg1);
	} else {
		tr1 = RTOUCR(10,F1207_10828, (Current));
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
		tr2 = F1930_19078(RTCW(tr2));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14405[Dtype(RTCW(tr2))-1930])(tr2);
		tr3 = RTOUCR(804,F396_5253, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tb1 = F1198_10706(RTCW(tr1), tr2, tr3);
		if (tb1) {
			F1228_11089(Current, arg1);
		} else {
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
			tr2 = F1930_19078(RTCW(tr2));
			tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R14405[Dtype(RTCW(tr2))-1930])(tr2);
			tr3 = RTOUCR(805,F396_5252, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tb1 = F1198_10706(RTCW(tr1), tr2, tr3);
			if (tb1) {
				F1228_11089(Current, arg1);
			}
		}
	}
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_feature_validity */
void F1228_11089 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 tu1_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1));
	tr1 = RTOUCR(568,F396_4208, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	tb1 = F1987_19687(RTCW(loc1), tr1);
	if (tb1) {
		F1228_11090(Current, arg1);
	} else {
		tr1 = RTOUCR(603,F396_4258, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tb1 = F1987_19687(RTCW(loc1), tr1);
		if (tb1) {
			F1228_11114(Current, arg1);
		} else {
			tr1 = RTOUCR(596,F396_4251, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tb1 = F1987_19687(RTCW(loc1), tr1);
			if (tb1) {
				F1228_11112(Current, arg1);
			} else {
				tr1 = RTOUCR(614,F396_4264, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tb1 = F1987_19687(RTCW(loc1), tr1);
				if (tb1) {
					tr1 = F1023_8169(Current);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12752[Dtype(tr1)-1610]);
					tu1_1 = ((EIF_NATURAL_8) 7U);
					F1228_11095(Current, arg1, tr1, tu1_1);
				} else {
					tr1 = RTOUCR(573,F396_4213, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tb1 = F1987_19687(RTCW(loc1), tr1);
					if (tb1) {
						tu1_1 = ((EIF_NATURAL_8) 6U);
						F1228_11094(Current, arg1, tu1_1);
					} else {
						tr1 = RTOUCR(619,F396_4265, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						tb1 = F1987_19687(RTCW(loc1), tr1);
						if (tb1) {
							tr1 = F1023_8169(Current);
							tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12753[Dtype(tr1)-1610]);
							tu1_1 = ((EIF_NATURAL_8) 9U);
							F1228_11095(Current, arg1, tr1, tu1_1);
						} else {
							tr1 = RTOUCR(574,F396_4214, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
							tb1 = F1987_19687(RTCW(loc1), tr1);
							if (tb1) {
								tu1_1 = ((EIF_NATURAL_8) 8U);
								F1228_11094(Current, arg1, tu1_1);
							} else {
								tr1 = RTOUCR(2014,F396_4262, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
								tb1 = F1987_19687(RTCW(loc1), tr1);
								if (tb1) {
									F1228_11093(Current, arg1);
								} else {
									tr1 = RTOUCR(572,F396_4211, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
									tb1 = F1987_19687(RTCW(loc1), tr1);
									if (tb1) {
										F1228_11092(Current, arg1);
									} else {
										tr1 = RTOUCR(2036,F396_4277, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
										tb1 = F1987_19687(RTCW(loc1), tr1);
										if (tb1) {
											F1228_11108(Current, arg1);
										} else {
											tr1 = RTOUCR(590,F396_4244, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
											tb1 = F1987_19687(RTCW(loc1), tr1);
											if (tb1) {
												F1228_11107(Current, arg1);
											} else {
												tr1 = RTOUCR(1955,F396_4209, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
												tb1 = F1987_19687(RTCW(loc1), tr1);
												if (tb1) {
													F1228_11091(Current, arg1);
												} else {
													tr1 = RTOUCR(1962,F396_4215, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
													tb1 = F1987_19687(RTCW(loc1), tr1);
													if (tb1) {
														F1228_11096(Current, arg1);
													} else {
														tr1 = RTOUCR(1986,F396_4235, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
														tb1 = F1987_19687(RTCW(loc1), tr1);
														if (tb1) {
															F1228_11105(Current, arg1);
														} else {
															tr1 = RTOUCR(576,F396_4219, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
															tb1 = F1987_19687(RTCW(loc1), tr1);
															if (tb1) {
																F1228_11097(Current, arg1);
															} else {
																tr1 = RTOUCR(1969,F396_4220, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																tb1 = F1987_19687(RTCW(loc1), tr1);
																if (tb1) {
																	F1228_11098(Current, arg1);
																} else {
																	tr1 = RTOUCR(584,F396_4231, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																	tb1 = F1987_19687(RTCW(loc1), tr1);
																	if (tb1) {
																		F1228_11103(Current, arg1);
																	} else {
																		tr1 = RTOUCR(1971,F396_4222, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																		tb1 = F1987_19687(RTCW(loc1), tr1);
																		if (tb1) {
																			F1228_11100(Current, arg1);
																		} else {
																			tr1 = RTOUCR(1981,F396_4232, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																			tb1 = F1987_19687(RTCW(loc1), tr1);
																			if (tb1) {
																				F1228_11104(Current, arg1);
																			} else {
																				tr1 = RTOUCR(1995,F396_4243, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																				tb1 = F1987_19687(RTCW(loc1), tr1);
																				if (tb1) {
																					F1228_11106(Current, arg1);
																				} else {
																					tr1 = RTOUCR(592,F396_4246, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																					tb1 = F1987_19687(RTCW(loc1), tr1);
																					if (tb1) {
																						F1228_11109(Current, arg1);
																					} else {
																						tr1 = RTOUCR(577,F396_4221, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																						tb1 = F1987_19687(RTCW(loc1), tr1);
																						if (tb1) {
																							F1228_11099(Current, arg1);
																						} else {
																							tr1 = RTOUCR(602,F396_4257, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																							tb1 = F1987_19687(RTCW(loc1), tr1);
																							if (tb1) {
																								F1228_11113(Current, arg1);
																							} else {
																								tr1 = RTOUCR(2021,F396_4268, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																								tb1 = F1987_19687(RTCW(loc1), tr1);
																								if (tb1) {
																									tr1 = F1023_8169(Current);
																									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12762[Dtype(tr1)-1610]);
																									tu1_1 = ((EIF_NATURAL_8) 16U);
																									F1228_11102(Current, arg1, tr1, tu1_1);
																								} else {
																									tr1 = RTOUCR(580,F396_4226, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																									tb1 = F1987_19687(RTCW(loc1), tr1);
																									if (tb1) {
																										tu1_1 = ((EIF_NATURAL_8) 15U);
																										F1228_11101(Current, arg1, tu1_1);
																									} else {
																										tr1 = RTOUCR(2023,F396_4269, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																										tb1 = F1987_19687(RTCW(loc1), tr1);
																										if (tb1) {
																											tr1 = F1023_8169(Current);
																											tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12763[Dtype(tr1)-1610]);
																											tu1_1 = ((EIF_NATURAL_8) 18U);
																											F1228_11102(Current, arg1, tr1, tu1_1);
																										} else {
																											tr1 = RTOUCR(581,F396_4227, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																											tb1 = F1987_19687(RTCW(loc1), tr1);
																											if (tb1) {
																												tu1_1 = ((EIF_NATURAL_8) 17U);
																												F1228_11101(Current, arg1, tu1_1);
																											} else {
																												tr1 = RTOUCR(616,F396_4270, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																												tb1 = F1987_19687(RTCW(loc1), tr1);
																												if (tb1) {
																													tr1 = F1023_8169(Current);
																													tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12764[Dtype(tr1)-1610]);
																													tu1_1 = ((EIF_NATURAL_8) 20U);
																													F1228_11102(Current, arg1, tr1, tu1_1);
																												} else {
																													tr1 = RTOUCR(582,F396_4228, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																													tb1 = F1987_19687(RTCW(loc1), tr1);
																													if (tb1) {
																														tu1_1 = ((EIF_NATURAL_8) 19U);
																														F1228_11101(Current, arg1, tu1_1);
																													} else {
																														tr1 = RTOUCR(2026,F396_4271, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																														tb1 = F1987_19687(RTCW(loc1), tr1);
																														if (tb1) {
																															tr1 = F1023_8169(Current);
																															tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12765[Dtype(tr1)-1610]);
																															tu1_1 = ((EIF_NATURAL_8) 22U);
																															F1228_11102(Current, arg1, tr1, tu1_1);
																														} else {
																															tr1 = RTOUCR(583,F396_4229, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																															tb1 = F1987_19687(RTCW(loc1), tr1);
																															if (tb1) {
																																tu1_1 = ((EIF_NATURAL_8) 21U);
																																F1228_11101(Current, arg1, tu1_1);
																															} else {
																																tr1 = RTOUCR(2029,F396_4273, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																																tb1 = F1987_19687(RTCW(loc1), tr1);
																																if (tb1) {
																																	tr1 = F1023_8169(Current);
																																	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12769[Dtype(tr1)-1610]);
																																	tu1_1 = ((EIF_NATURAL_8) 27U);
																																	F1228_11102(Current, arg1, tr1, tu1_1);
																																} else {
																																	tr1 = RTOUCR(586,F396_4238, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																																	tb1 = F1987_19687(RTCW(loc1), tr1);
																																	if (tb1) {
																																		tu1_1 = ((EIF_NATURAL_8) 26U);
																																		F1228_11101(Current, arg1, tu1_1);
																																	} else {
																																		tr1 = RTOUCR(2031,F396_4274, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																																		tb1 = F1987_19687(RTCW(loc1), tr1);
																																		if (tb1) {
																																			tr1 = F1023_8169(Current);
																																			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12770[Dtype(tr1)-1610]);
																																			tu1_1 = ((EIF_NATURAL_8) 29U);
																																			F1228_11102(Current, arg1, tr1, tu1_1);
																																		} else {
																																			tr1 = RTOUCR(587,F396_4239, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																																			tb1 = F1987_19687(RTCW(loc1), tr1);
																																			if (tb1) {
																																				tu1_1 = ((EIF_NATURAL_8) 28U);
																																				F1228_11101(Current, arg1, tu1_1);
																																			} else {
																																				tr1 = RTOUCR(617,F396_4275, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																																				tb1 = F1987_19687(RTCW(loc1), tr1);
																																				if (tb1) {
																																					tr1 = F1023_8169(Current);
																																					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12771[Dtype(tr1)-1610]);
																																					tu1_1 = ((EIF_NATURAL_8) 31U);
																																					F1228_11102(Current, arg1, tr1, tu1_1);
																																				} else {
																																					tr1 = RTOUCR(588,F396_4240, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																																					tb1 = F1987_19687(RTCW(loc1), tr1);
																																					if (tb1) {
																																						tu1_1 = ((EIF_NATURAL_8) 30U);
																																						F1228_11101(Current, arg1, tu1_1);
																																					} else {
																																						tr1 = RTOUCR(2034,F396_4276, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																																						tb1 = F1987_19687(RTCW(loc1), tr1);
																																						if (tb1) {
																																							tr1 = F1023_8169(Current);
																																							tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12772[Dtype(tr1)-1610]);
																																							tu1_1 = ((EIF_NATURAL_8) 33U);
																																							F1228_11102(Current, arg1, tr1, tu1_1);
																																						} else {
																																							tr1 = RTOUCR(589,F396_4241, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																																							tb1 = F1987_19687(RTCW(loc1), tr1);
																																							if (tb1) {
																																								tu1_1 = ((EIF_NATURAL_8) 32U);
																																								F1228_11101(Current, arg1, tu1_1);
																																							} else {
																																								tr1 = RTOUCR(618,F396_4279, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																																								tb1 = F1987_19687(RTCW(loc1), tr1);
																																								if (tb1) {
																																									tr1 = F1023_8169(Current);
																																									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12779[Dtype(tr1)-1610]);
																																									tu1_1 = ((EIF_NATURAL_8) 39U);
																																									F1228_11111(Current, arg1, tr1, tu1_1);
																																								} else {
																																									tr1 = RTOUCR(593,F396_4248, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																																									tb1 = F1987_19687(RTCW(loc1), tr1);
																																									if (tb1) {
																																										tu1_1 = ((EIF_NATURAL_8) 38U);
																																										F1228_11110(Current, arg1, tu1_1);
																																									} else {
																																										tr1 = RTOUCR(615,F396_4280, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																																										tb1 = F1987_19687(RTCW(loc1), tr1);
																																										if (tb1) {
																																											tr1 = F1023_8169(Current);
																																											tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12780[Dtype(tr1)-1610]);
																																											tu1_1 = ((EIF_NATURAL_8) 41U);
																																											F1228_11111(Current, arg1, tr1, tu1_1);
																																										} else {
																																											tr1 = RTOUCR(594,F396_4249, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
																																											tb1 = F1987_19687(RTCW(loc1), tr1);
																																											if (tb1) {
																																												tu1_1 = ((EIF_NATURAL_8) 40U);
																																												F1228_11110(Current, arg1, tu1_1);
																																											} else {
																																												tu1_1 = ((EIF_NATURAL_8) 1U);
																																												tu1_2 = ((EIF_NATURAL_8) 1U);
																																												F1851_17959(RTCW(arg1), tu1_1, tu1_2);
																																												if (F1228_11087(Current)) {
																																													F1033_8331(Current);
																																													tr1 = F1023_8173(Current);
																																													F2046_21539(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1);
																																												}
																																											}
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_any_feature_validity */
void F1228_11090 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 2U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 13L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = RTOUCR(2125,F396_4328, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12740[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2137,F396_4335, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = RTOUCR(2606,F396_4597, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2196,F396_4372, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12799[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 3U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2200,F396_4374, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12785[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 4U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2279,F396_4415, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTOUCR(2606,F396_4597, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 5U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(688,F396_4419, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTOUCR(2606,F396_4597, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 6U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2484,F396_4530, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12740[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 7U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2560,F396_4570, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTOUCR(2606,F396_4597, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 8U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2562,F396_4571, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = RTOUCR(2606,F396_4597, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 9U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2566,F396_4573, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12785[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 10U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2589,F396_4586, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = RTOUCR(2606,F396_4597, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 11U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(687,F396_4331, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTOUCR(2606,F396_4597, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 12U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2558,F396_4569, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = RTOUCR(2606,F396_4597, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 13U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_arguments_32_feature_validity */
void F1228_11091 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 3U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 3L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = RTOUCR(2045,F396_4285, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2212,F396_4380, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2214,F396_4381, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12760[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 3U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_boolean_feature_validity */
void F1228_11092 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 4U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 7L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = RTOUCR(2127,F396_4329, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2129,F396_4330, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2146,F396_4340, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 5U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2148,F396_4341, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 7U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2150,F396_4342, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 6U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2234,F396_4391, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 3U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2380,F396_4472, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 4U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_boolean_ref_feature_validity */
void F1228_11093 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 5U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 2L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = RTOUCR(473,F396_4446, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2519,F396_4548, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_character_n_feature_validity */
void F1228_11094 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_8 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 4L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, arg2);
		tr1 = RTOUCR(2121,F396_4326, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2366,F396_4465, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12771[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2568,F396_4575, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12752[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 3U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2570,F396_4576, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12753[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 4U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, arg2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_character_n_ref_feature_validity */
void F1228_11095 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_NATURAL_8 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), arg3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 2L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, arg3);
		tr1 = RTOUCR(473,F396_4446, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, NULL, arg2, tu1_1, loc1);
		tr1 = RTOUCR(2519,F396_4548, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(arg2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, arg3, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_com_failure_feature_validity */
void F1228_11096 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 10U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 7L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = RTOUCR(2087,F396_4307, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12764[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2092,F396_4311, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2094,F396_4312, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 3U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2096,F396_4313, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 4U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2116,F396_4323, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12764[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 5U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2133,F396_4333, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 6U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2135,F396_4334, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 7U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_exception_manager_feature_validity */
void F1228_11097 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 11U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 11L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = RTOUCR(2169,F396_4352, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12756[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2275,F396_4413, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12798[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2294,F396_4423, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12798[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 3U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2296,F396_4424, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12798[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 4U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2310,F396_4431, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12798[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 5U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(91,F396_4448, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12756[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 6U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2597,F396_4590, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12797[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 7U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2090,F396_4310, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12798[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 8U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2232,F396_4390, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12798[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 9U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2454,F396_4514, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12755[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 10U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2517,F396_4547, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12798[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 11U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_exception_manager_factory_feature_validity */
void F1228_11098 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 12U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = RTOUCR(2171,F396_4353, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12757[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_function_feature_validity */
void F1228_11099 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,tr2);
	RTLR(6,tr3);
	RTLR(7,tr4);
	RTLR(8,arg1);
	RTLIU(9);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 13U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 2L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc3 = F2027_20699(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		tr1 = *(EIF_REFERENCE *)(Current);
		loc4 = F2027_20699(RTCW(tr1), ((EIF_INTEGER_32) 2L));
		tr1 = RTOUCR(2176,F396_4356, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 8L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 8L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, tr2, loc4, tu1_1, loc1);
		tr1 = RTOUCR(473,F396_4446, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1228_11121(Current, loc3);
		tr4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13369[Dtype(RTCW(tr4))-1885])(tr4);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, tr2, loc4, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_identified_routines_feature_validity */
void F1228_11100 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 14U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 3L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = RTOUCR(2161,F396_4348, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12741[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2163,F396_4349, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12740[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2165,F396_4350, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 3U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_integer_n_feature_validity */
void F1228_11101 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_8 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 30L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, arg2);
		loc2 = *(EIF_REFERENCE *)(Current);
		tr1 = RTOUCR(2047,F396_4286, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12762[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2049,F396_4287, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12763[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2051,F396_4288, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12764[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 3U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2053,F396_4289, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12765[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 4U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2055,F396_4290, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12769[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 5U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2057,F396_4291, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12770[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 6U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2059,F396_4292, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12771[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 7U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2061,F396_4293, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12772[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 8U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2067,F396_4297, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 9U);
		F1228_11120(Current, tr1, tr2, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2069,F396_4298, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 10U);
		F1228_11120(Current, tr1, NULL, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2071,F396_4299, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 11U);
		F1228_11120(Current, tr1, tr2, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2073,F396_4300, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 12U);
		F1228_11120(Current, tr1, tr2, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2075,F396_4301, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 13U);
		F1228_11120(Current, tr1, tr2, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2077,F396_4302, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 14U);
		F1228_11120(Current, tr1, tr2, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2216,F396_4382, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 15U);
		F1228_11120(Current, tr1, NULL, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2265,F396_4407, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 16U);
		F1228_11120(Current, tr1, tr2, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2267,F396_4408, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 17U);
		F1228_11120(Current, tr1, tr2, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2298,F396_4425, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 18U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2350,F396_4456, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 19U);
		F1228_11120(Current, tr1, tr2, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2399,F396_4485, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 20U);
		F1228_11120(Current, tr1, NULL, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2405,F396_4488, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 21U);
		F1228_11120(Current, tr1, tr2, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2416,F396_4494, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12780[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12780[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 22U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2420,F396_4496, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 23U);
		F1228_11120(Current, tr1, tr2, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2452,F396_4513, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12780[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 24U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2568,F396_4575, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12752[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 25U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2570,F396_4576, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12753[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 26U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2572,F396_4577, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12780[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 27U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2576,F396_4579, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12779[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 28U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2579,F396_4581, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12779[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 29U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2581,F396_4582, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12780[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 30U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, arg2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_integer_n_ref_feature_validity */
void F1228_11102 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_NATURAL_8 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), arg3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 2L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, arg3);
		tr1 = RTOUCR(473,F396_4446, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, NULL, arg2, tu1_1, loc1);
		tr1 = RTOUCR(2519,F396_4548, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(arg2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, arg3, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_ise_exception_manager_feature_validity */
void F1228_11103 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 23U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 1L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = RTOUCR(2144,F396_4339, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_ise_runtime_feature_validity */
void F1228_11104 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 24U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 109L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = RTOUCR(2063,F396_4294, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2083,F396_4305, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2085,F396_4306, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 3U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2102,F396_4316, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12752[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 4U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2104,F396_4317, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12752[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 5U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2108,F396_4319, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12753[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 6U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2110,F396_4320, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12753[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 7U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2118,F396_4324, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 8U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2123,F396_4327, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 9U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2142,F396_4338, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 10U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2155,F396_4345, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12740[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 11U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2157,F396_4346, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12764[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 12U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2159,F396_4347, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 13U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2178,F396_4359, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 14U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2180,F396_4361, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 15U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2182,F396_4362, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 16U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2184,F396_4364, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 17U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2186,F396_4366, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 18U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2198,F396_4373, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 19U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2202,F396_4375, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 20U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2204,F396_4376, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 21U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2236,F396_4392, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 22U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2239,F396_4394, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12762[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 23U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2241,F396_4395, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12762[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 24U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2245,F396_4397, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12763[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 25U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2247,F396_4398, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12763[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 26U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2251,F396_4400, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12764[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 27U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2253,F396_4401, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12764[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 28U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2257,F396_4403, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12765[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 29U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2259,F396_4404, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12765[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 30U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2273,F396_4412, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 31U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2277,F396_4414, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 32U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2288,F396_4420, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 33U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2290,F396_4421, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 34U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2292,F396_4422, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 35U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2306,F396_4429, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 36U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2314,F396_4433, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 37U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2316,F396_4434, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 38U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2318,F396_4435, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 39U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2320,F396_4436, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 40U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2322,F396_4437, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 41U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2324,F396_4438, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 42U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2328,F396_4440, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 43U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2330,F396_4441, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 44U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2354,F396_4459, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12769[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 45U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2356,F396_4460, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12769[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 46U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2360,F396_4462, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12770[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 47U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2362,F396_4463, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12770[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 48U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2368,F396_4466, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12771[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 49U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2370,F396_4467, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12771[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 50U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2374,F396_4469, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12772[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 51U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2376,F396_4470, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12772[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 52U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2384,F396_4476, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12740[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 53U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2386,F396_4478, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12783[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 54U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2388,F396_4479, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12792[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 55U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2390,F396_4480, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12796[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 56U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2394,F396_4482, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12772[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 57U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2396,F396_4483, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12782[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 58U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2403,F396_4487, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 59U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2409,F396_4490, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 60U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2411,F396_4491, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 61U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2418,F396_4495, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 62U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2456,F396_4515, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 63U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2458,F396_4516, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 64U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2460,F396_4517, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12779[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 65U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2462,F396_4518, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12779[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 66U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2466,F396_4520, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12780[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 67U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2468,F396_4521, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12780[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 68U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2474,F396_4524, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12741[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 69U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2476,F396_4525, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 3L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 3L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12741[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 70U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2478,F396_4526, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12740[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 71U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2564,F396_4572, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12786[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 72U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2591,F396_4587, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 73U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2595,F396_4589, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 74U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2343,F396_4450, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 75U);
		F1228_11120(Current, tr1, NULL, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2348,F396_4454, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 76U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2486,F396_4531, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 77U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2488,F396_4532, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 78U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2490,F396_4533, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12752[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 79U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2492,F396_4534, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12752[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 80U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2494,F396_4535, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12753[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 81U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2496,F396_4536, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12753[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 82U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2501,F396_4539, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12762[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 83U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2503,F396_4540, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12762[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 84U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2505,F396_4541, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12763[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 85U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2507,F396_4542, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12763[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 86U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2509,F396_4543, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12764[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 87U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2511,F396_4544, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12764[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 88U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2513,F396_4545, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12765[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 89U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2515,F396_4546, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12765[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 90U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2521,F396_4549, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12769[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 91U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2523,F396_4550, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12769[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 92U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2525,F396_4551, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12770[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 93U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2527,F396_4552, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12770[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 94U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2529,F396_4553, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12771[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 95U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2531,F396_4554, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12771[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 96U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2533,F396_4555, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12772[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 97U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2535,F396_4556, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12772[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 98U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2539,F396_4559, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 99U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2541,F396_4560, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 100U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2543,F396_4561, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 101U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2545,F396_4562, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12779[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 102U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2547,F396_4563, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12779[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 103U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2549,F396_4564, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12780[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 104U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2551,F396_4565, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12780[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 105U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2553,F396_4566, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12741[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 106U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2555,F396_4567, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 4L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 4L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12741[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 107U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2599,F396_4592, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 108U);
		F1228_11120(Current, tr1, NULL, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2601,F396_4593, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 109U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_memory_feature_validity */
void F1228_11105 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 25U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 2L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = RTOUCR(2188,F396_4367, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12740[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12782[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2194,F396_4371, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12740[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_platform_feature_validity */
void F1228_11106 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 34U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 16L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = RTOUCR(2079,F396_4303, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2114,F396_4322, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2153,F396_4344, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 3U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2263,F396_4406, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 4U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2269,F396_4410, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 5U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2285,F396_4418, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 6U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2300,F396_4426, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 7U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2312,F396_4432, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 8U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2326,F396_4439, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 9U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2332,F396_4442, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 10U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2334,F396_4443, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 11U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2336,F396_4444, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 12U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2338,F396_4445, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 13U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2407,F396_4489, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 14U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2472,F396_4523, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 15U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2604,F396_4596, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 16U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_pointer_feature_validity */
void F1228_11107 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 35U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 5L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = RTOUCR(2210,F396_4379, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2281,F396_4416, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2401,F396_4486, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12785[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 3U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2405,F396_4488, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 4U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2574,F396_4578, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12764[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 5U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_pointer_ref_feature_validity */
void F1228_11108 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 36U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 2L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = RTOUCR(473,F396_4446, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12775[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2519,F396_4548, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_procedure_feature_validity */
void F1228_11109 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 37U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 2L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc3 = F2027_20699(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		tr1 = RTOUCR(689,F396_4308, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1228_11121(Current, loc3);
		tr4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13369[Dtype(RTCW(tr4))-1885])(tr4);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2174,F396_4355, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 8L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 8L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_real_n_feature_validity */
void F1228_11110 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_8 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 20L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, arg2);
		loc2 = *(EIF_REFERENCE *)(Current);
		tr1 = RTOUCR(2098,F396_4314, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12779[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2100,F396_4315, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12780[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2190,F396_4368, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12779[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 3U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2192,F396_4369, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12780[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 4U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2216,F396_4382, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 5U);
		F1228_11120(Current, tr1, NULL, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2218,F396_4383, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 6U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2220,F396_4384, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 7U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2222,F396_4385, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 8U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2224,F396_4386, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 9U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2226,F396_4387, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 10U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2228,F396_4388, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 11U);
		F1228_11120(Current, tr1, tr2, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2230,F396_4389, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 12U);
		F1228_11120(Current, tr1, tr2, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2298,F396_4425, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 13U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2302,F396_4427, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 14U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2304,F396_4428, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 15U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2308,F396_4430, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 16U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2350,F396_4456, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 17U);
		F1228_11120(Current, tr1, tr2, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2399,F396_4485, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 18U);
		F1228_11120(Current, tr1, NULL, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2401,F396_4486, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12785[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 19U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2405,F396_4488, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 20U);
		F1228_11120(Current, tr1, tr2, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2416,F396_4494, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12780[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12780[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 21U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2420,F396_4496, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 22U);
		F1228_11120(Current, tr1, tr2, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2452,F396_4513, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(loc2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 23U);
		F1228_11120(Current, tr1, tr2, loc2, tu1_1, loc1);
		tr1 = RTOUCR(2572,F396_4577, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12780[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 24U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2583,F396_4583, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12764[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 25U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2585,F396_4584, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12765[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 26U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2587,F396_4585, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12779[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 27U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, arg2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_real_n_ref_feature_validity */
void F1228_11111 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_NATURAL_8 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), arg3);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 5L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, arg3);
		tr1 = RTOUCR(473,F396_4446, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, NULL, arg2, tu1_1, loc1);
		tr1 = RTOUCR(2352,F396_4458, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, NULL, arg2, tu1_1, loc1);
		tr1 = RTOUCR(2382,F396_4473, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 3U);
		F1228_11120(Current, tr1, NULL, arg2, tu1_1, loc1);
		tr1 = RTOUCR(2414,F396_4493, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 4U);
		F1228_11120(Current, tr1, NULL, arg2, tu1_1, loc1);
		tr1 = RTOUCR(2519,F396_4548, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1884_18206(RTCW(arg2));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 5U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, arg3, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_special_feature_validity */
void F1228_11112 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 42U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 10L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc3 = F2027_20699(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		tr1 = RTOUCR(2042,F396_4283, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = RTOUCR(2606,F396_4597, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2065,F396_4295, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12775[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(80,F396_4309, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 3U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(79,F396_4332, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 4U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2167,F396_4351, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 5U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(473,F396_4446, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 6U);
		F1228_11120(Current, tr1, tr2, loc3, tu1_1, loc1);
		tr1 = RTOUCR(653,F396_4354, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13369[Dtype(RTCW(loc3))-1885])(loc3);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 7U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2346,F396_4453, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 8U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(652,F396_4497, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13369[Dtype(RTCW(loc3))-1885])(loc3);
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 9U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2498,F396_4537, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 10U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_tuple_feature_validity */
void F1228_11113 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,arg1);
	RTLIU(7);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 43U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 34L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = RTOUCR(2081,F396_4304, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2106,F396_4318, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12752[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2112,F396_4321, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12753[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 3U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(79,F396_4332, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 4U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2243,F396_4396, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12762[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 5U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2249,F396_4399, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12763[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 6U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2255,F396_4402, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12764[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 7U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2261,F396_4405, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12765[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 8U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2340,F396_4447, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12769[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 9U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2358,F396_4461, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12769[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 10U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2364,F396_4464, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12770[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 11U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2372,F396_4468, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12771[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 12U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2378,F396_4471, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12772[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 13U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2392,F396_4481, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 14U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(85,F396_4492, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 15U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2464,F396_4519, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12779[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 16U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2470,F396_4522, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12780[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 17U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(656,F396_4527, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12742[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 33U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2423,F396_4498, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 18U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2425,F396_4499, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12752[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 19U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2427,F396_4500, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12753[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 20U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2429,F396_4501, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12762[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 21U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2431,F396_4502, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12763[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 22U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2433,F396_4503, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 23U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2435,F396_4504, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12765[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 24U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2437,F396_4505, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12769[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 25U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2439,F396_4506, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12770[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 26U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2441,F396_4507, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12771[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 27U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2443,F396_4508, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12772[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 28U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2445,F396_4509, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 29U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2447,F396_4510, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12778[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 30U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2449,F396_4511, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12754[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 31U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(657,F396_4512, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 2L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 2L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12742[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 32U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
		tr1 = RTOUCR(2537,F396_4557, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tu1_1 = ((EIF_NATURAL_8) 34U);
		F1228_11120(Current, tr1, tr2, NULL, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_builtin_type_feature_validity */
void F1228_11114 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 loc2 = (EIF_NATURAL_8) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTGC;
	loc2 = ((EIF_NATURAL_8) 44U);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1559_14040(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = F1551_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = F1551_13931(RTCW(tr1));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFF01,1950,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
		}
		F1553_14024(RTCW(loc1), ((EIF_INTEGER_32) 9L));
		tr1 = RTOUCR(683,F433_5893, (Current));
		F1553_14042(RTCW(loc1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1559_14051(RTCW(tr1), loc1, loc2);
		tr1 = *(EIF_REFERENCE *)(Current);
		loc3 = F2027_20699(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		tr1 = RTOUCR(2139,F396_4336, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tu1_1 = ((EIF_NATURAL_8) 1U);
		F1228_11120(Current, tr1, NULL, loc3, tu1_1, loc1);
		tr1 = RTOUCR(2206,F396_4377, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		{
			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
			RT_SPECIAL_COUNT(tr3) = 1L;
			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
		}
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
		tr4 = F1884_18206(RTCW(tr4));
		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
		RTAR(tr3,tr4);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
		tr4 = F1023_8169(Current);
		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12796[Dtype(tr4)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 2U);
		F1228_11120(Current, tr1, tr2, tr4, tu1_1, loc1);
		tr1 = RTOUCR(2204,F396_4376, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 3U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2208,F396_4378, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 4U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2271,F396_4411, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 5U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2283,F396_4417, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 6U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2288,F396_4420, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 7U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2482,F396_4529, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12785[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 8U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
		tr1 = RTOUCR(2593,F396_4588, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr2 = F1023_8169(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
		tu1_1 = ((EIF_NATURAL_8) 9U);
		F1228_11120(Current, tr1, NULL, tr2, tu1_1, loc1);
	}
	F1228_11115(Current, arg1, loc2, loc1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_expected_builtin_feature_validity */
void F1228_11115 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_8 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 tu1_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg3);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,Current);
	RTLIU(6);
	
	RTGC;
	tr1 = F1837_17781(RTCW(arg1));
	F1553_14040(RTCW(arg3), tr1);
	tb1 = F1545_13939(RTCW(arg3));
	if (tb1) {
		loc1 = F1545_13931(RTCW(arg3));
		tu1_1 = eif_natural_8_item(RTCW(loc1),3);
		F1851_17959(RTCW(arg1), arg2, tu1_1);
		tr1 = eif_boxed_item(loc1,1);
		tr2 = eif_boxed_item(loc1,2);
		F1228_11116(Current, arg1, tr1, tr2);
	} else {
		tu1_1 = ((EIF_NATURAL_8) 1U);
		tu1_2 = ((EIF_NATURAL_8) 1U);
		F1851_17959(RTCW(arg1), tu1_1, tu1_2);
		if (F1228_11087(Current)) {
			F1033_8331(Current);
			tr1 = F1023_8173(Current);
			F2046_21539(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1);
		}
	}
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.check_signature_validity */
void F1228_11116 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,Current);
	RTLR(6,tr3);
	RTLR(7,tr4);
	RTLR(8,loc2);
	RTLR(9,arg3);
	RTLIU(10);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(arg2 == NULL)) {
		ti4_1 = F830_6899(RTCW(arg2));
		tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		loc5 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_3_0_0_0_);
			loc5 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
		}
	} else {
		loc4 = F830_6899(RTCW(arg2));
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(loc1 == NULL)) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_3_0_0_0_);
			tb1 = (EIF_BOOLEAN)(ti4_1 != loc4);
		}
		if (tb1) {
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc3 > loc4)) break;
				tr1 = F1649_16721(RTCW(loc1), loc3);
				tr1 = F1814_17596(RTCW(tr1));
				tr2 = F830_6892(RTCW(arg2), loc3);
				tr3 = *(EIF_REFERENCE *)(Current);
				tr4 = *(EIF_REFERENCE *)(Current);
				tb1 = F1884_18232(RTCW(tr1), tr2, tr3, tr4);
				if ((EIF_BOOLEAN) !tb1) {
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
				}
				loc3++;
			}
		}
	}
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10398[Dtype(RTCW(arg1))-1840])(arg1);
	if ((EIF_BOOLEAN)(arg3 == NULL)) {
		loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc2 != NULL);
	} else {
		loc5 = '\01';
		if (!(EIF_BOOLEAN)(loc2 == NULL)) {
			tb1 = F1884_18232(RTCW(loc2), arg3, *(EIF_REFERENCE *)(Current), *(EIF_REFERENCE *)(Current));
			loc5 = (EIF_BOOLEAN) !tb1;
		}
	}
	if (loc5) {
		F1033_8331(Current);
		tr1 = F1023_8173(Current);
		F2046_21538(RTCW(tr1), *(EIF_REFERENCE *)(Current), arg1, arg2, arg3);
	}
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.process_external_function */
void F1228_11117 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1228_11088(Current, arg1);
}

/* {ET_BUILTIN_FEATURE_CHECKER}.process_external_procedure */
void F1228_11118 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1228_11088(Current, arg1);
}

/* {ET_BUILTIN_FEATURE_CHECKER}.register_builtin_feature */
void F1228_11120 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_NATURAL_8 arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,3,1085,829,0xFF01,1883,1883,1109,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNTS(typres0.id, 4, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = arg2;
	RTAR(tr1,arg2);
	((EIF_TYPED_VALUE *)tr1+2)->it_r = arg3;
	RTAR(tr1,arg3);
	((EIF_TYPED_VALUE *)tr1+3)->it_n1 = arg4;
	F1553_14051(RTCW(arg5), tr1, arg1);
	RTLE;
}

/* {ET_BUILTIN_FEATURE_CHECKER}.detachable_separate_formal_parameter_type */
EIF_REFERENCE F1228_11121 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	Result = RTLNS(eif_new_type(1885, 0x01).id, 1885, _OBJSIZ_3_0_0_1_0_0_0_0_);
	tr1 = RTOUCR(569,F396_4603, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O13997[Dtype(arg1)-1885]);
	tr3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	F1886_18274(RTCW(Result), tr1, tr2, ti4_1, tr3);
	RTLE;
	return Result;
}

void EIF_Minit539 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
