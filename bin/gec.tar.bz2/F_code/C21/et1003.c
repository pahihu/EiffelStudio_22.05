/*
 * Code for class ET_INFIX_AND_THEN_OPERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1003.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_INFIX_AND_THEN_OPERATOR}.make */
void F1955_19404 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(2628,F396_4656, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(727,F396_4710, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {ET_INFIX_AND_THEN_OPERATOR}.is_infix_and_then */
EIF_BOOLEAN F1955_19406 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {ET_INFIX_AND_THEN_OPERATOR}.name */
EIF_REFERENCE F1955_19407 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOUCR(1649,F396_5246, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	RTLE;
	return Result;
}

/* {ET_INFIX_AND_THEN_OPERATOR}.hash_code */
EIF_INTEGER_32 F1955_19410 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) 'X';
	Result = (EIF_INTEGER_32) (tc1);
	RTLE;
	return Result;
}

/* {ET_INFIX_AND_THEN_OPERATOR}.position */
EIF_REFERENCE F1955_19411 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1914_18794(RTCW(tr1));
	RTLE;
	return Result;
}

/* {ET_INFIX_AND_THEN_OPERATOR}.last_leaf */
EIF_REFERENCE F1955_19413 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_1_);
}

/* {ET_INFIX_AND_THEN_OPERATOR}.set_and_keyword */
void F1955_19414 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

void EIF_Minit1003 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
