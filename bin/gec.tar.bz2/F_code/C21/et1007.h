
#ifndef _C21_et1007_
#define _C21_et1007_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1959_19465(EIF_REFERENCE);
extern void EIF_Minit1007(void);

#ifdef __cplusplus
}
#endif

#endif
