
#ifndef _C21_et1017_
#define _C21_et1017_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1969_19564(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1017(void);
extern char *(*R2460[])();

#ifdef __cplusplus
}
#endif

#endif
