/*
 * Code for class ET_DYNAMIC_SYSTEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1044.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_DYNAMIC_SYSTEM}.make */
void F1996_19858 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLIU(8);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_50_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg2;
	F1996_19859(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12714[Dtype(tr1)-1610]);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_11_0_0_7_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1540,0xFF01,1131,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1541_13840(RTCW(tr1), loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_28_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,1131,0xFF01,1184,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1553_14021(RTCW(tr1), loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_29_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1085,1091,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 1);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_i4 = ((EIF_INTEGER_32) 0L);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1171,0xFF01,0xFFF9,1,1085,0xFF01,2026,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A1075_304_1, (EIF_POINTER) _A1075_304_1, 0, tr2, 0, 1);
	}
	F1611_16252(RTCW(tr1), tr5);
	tr1 = RTLNSMART(eif_new_type(268, 1).id);
	F269_2974(RTCW(tr1), Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_32_) = (EIF_REFERENCE) tr1;
	F1996_19940(Current, *(EIF_REFERENCE *)(Current + _REFACS_32_));
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.make_basic_types */
void F1996_19859 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTOUCR(5,F396_5268, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	tr1 = RTLNSMART(eif_new_type(1131, 1).id);
	F1132_10014(RTCW(tr1), loc1, loc1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_27_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.set_catcall_error_mode */
void F1996_19868 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_50_0_) = (EIF_BOOLEAN) arg1;
}

/* {ET_DYNAMIC_SYSTEM}.set_catcall_warning_mode */
void F1996_19869 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_50_1_) = (EIF_BOOLEAN) arg1;
}

/* {ET_DYNAMIC_SYSTEM}.set_full_class_checking */
void F1996_19870 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_50_2_) = (EIF_BOOLEAN) arg1;
}

/* {ET_DYNAMIC_SYSTEM}.use_all_attributes */
void F1996_19871 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_50_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = F1541_13846(RTCW(loc3), loc1);
		F1132_10047(RTCW(tr1), Current);
		loc1++;
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.dynamic_type */
EIF_REFERENCE F1996_19896 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	loc1 = F1996_19897(Current, arg1, arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		tb1 = '\01';
		tb2 = F1884_18214(RTCW(arg1), arg2);
		if (!tb2) {
			tb2 = F1884_18220(RTCW(arg1), arg2);
			tb1 = tb2;
		}
		if (tb1) {
			RTLE;
			return (EIF_REFERENCE) loc1;
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				RTLE;
				return (EIF_REFERENCE) loc3;
			} else {
				loc2 = RTLNS(eif_new_type(1130, 0x01).id, 1130, _OBJSIZ_4_0_0_0_0_0_0_0_);
				tr1 = RTOUCR(72,F396_4604, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				F1131_10005(RTCW(loc2), loc1, tr1);
				F1132_10031(RTCW(loc1), loc2);
				F1996_19918(Current, loc2);
				RTLE;
				return (EIF_REFERENCE) loc2;
			}
		}
	} else {
		RTLE;
		return (EIF_REFERENCE) loc1;
	}/* NOTREACHED */
	
}

/* {ET_DYNAMIC_SYSTEM}.dynamic_primary_type */
EIF_REFERENCE F1996_19897 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc8);
	RTLR(3,loc3);
	RTLR(4,arg1);
	RTLR(5,arg2);
	RTLR(6,loc2);
	RTLR(7,loc5);
	RTLR(8,loc10);
	RTLR(9,loc4);
	RTLR(10,loc9);
	RTLR(11,Result);
	RTLIU(12);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_50_4_)) {
		loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_50_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
		loc7 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	}
	loc8 = RTOUCR(73,F396_4610, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	loc3 = F1884_18190(RTCW(arg1), arg2);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_30_20_0_1_);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc1 >= ((EIF_INTEGER_32) 1L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		tb1 = (EIF_BOOLEAN) (loc1 <= ti4_1);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
		loc2 = F1541_13846(RTCW(tr1), loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
		if ((EIF_BOOLEAN)(tr1 != loc3)) {
		} else {
			tb1 = '\0';
			tb2 = F2024_20445(RTCW(loc3));
			if ((EIF_BOOLEAN) !tb2) {
				tb2 = F2027_20603(RTCW(loc3));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				tb1 = F1884_18214(RTCW(arg1), arg2);
				tb2 = F1130_9983(RTCW(loc2));
				if ((EIF_BOOLEAN)(tb1 == tb2)) {
					loc5 = (EIF_REFERENCE) loc2;
				} else {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_11_);
					loc10 = tr1;
					if ((EIF_BOOLEAN) !EIF_TEST(loc10)) {
						loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13928[Dtype(RTCW(arg1))-1885])(arg1, loc8, arg2);
						loc5 = F1996_19903(Current, loc4);
					} else {
						loc5 = (EIF_REFERENCE) loc10;
					}
				}
			} else {
				loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13928[Dtype(RTCW(arg1))-1885])(arg1, loc8, arg2);
				loc9 = RTOUCR(74,F1996_19965, (Current));
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R8390[Dtype(RTCW(loc9))-1181])(loc9);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R13992[Dtype(RTCW(loc4))-1885])(loc4, loc9);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
				F1553_14040(RTCW(tr1), loc9);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
				tb1 = F1545_13939(RTCW(tr1));
				if (tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
					loc5 = F1545_13931(RTCW(tr1));
				} else {
					tr1 = RTLNS(eif_new_type(1184, 0x01).id, 1184, _OBJSIZ_1_1_0_3_0_0_0_0_);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc9)+ _LNGOFF_1_1_0_2_);
					F1183_10471(RTCW(tr1), ti4_1);
					loc9 = (EIF_REFERENCE) tr1;
					tr1 = RTOUCR(74,F1996_19965, (Current));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8527[Dtype(RTCW(loc9))-1184])(loc9, tr1);
					loc5 = F1996_19903(Current, loc4);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
					F1553_14051(RTCW(tr1), loc5, loc9);
				}
			}
		}
	}
	if ((EIF_BOOLEAN)(loc5 != NULL)) {
		Result = (EIF_REFERENCE) loc5;
	} else {
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_50_2_)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_11_);
			F2027_20822(RTCW(loc3), tr1);
			tb1 = '\01';
			tb2 = F2027_20801(RTCW(loc3));
			if (!(EIF_BOOLEAN) !tb2) {
				tb2 = F2027_20803(RTCW(loc3));
				tb1 = tb2;
			}
			if (tb1) {
				F1996_19935(Current);
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_10_);
			F2027_20822(RTCW(loc3), tr1);
			tb1 = '\01';
			tb2 = F2027_20786(RTCW(loc3));
			if (!(EIF_BOOLEAN) !tb2) {
				tb2 = F2027_20788(RTCW(loc3));
				tb1 = tb2;
			}
			if (tb1) {
				F1996_19935(Current);
			}
		}
		loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13928[Dtype(RTCW(arg1))-1885])(arg1, loc8, arg2);
		Result = F1996_19903(Current, loc4);
		tb1 = '\01';
		tb2 = F2024_20445(RTCW(loc3));
		if (!tb2) {
			tb2 = F2027_20603(RTCW(loc3));
			tb1 = tb2;
		}
		if (tb1) {
			loc9 = F1884_18266(RTCW(loc4));
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
			F1553_14051(RTCW(tr1), Result, loc9);
		}
	}
	if ((EIF_BOOLEAN) !loc6) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_50_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		F1996_19911(Current, (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 1L)), ti4_1);
	}
	RTLE;
	return Result;
}

/* {ET_DYNAMIC_SYSTEM}.attached_type */
EIF_REFERENCE F1996_19898 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O13017[Dtype(tr1)-1616]);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			RTLE;
			return (EIF_REFERENCE) loc1;
		} else {
			tb1 = F1130_9983(RTCW(arg1));
			if (tb1) {
				RTLE;
				return (EIF_REFERENCE) arg1;
			} else {
				tr1 = RTOUCR(75,F396_4598, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_13_);
				Result = F1996_19896(Current, tr1, tr2);
			}
		}
	} else {
		RTLE;
		return (EIF_REFERENCE) arg1;
	}
	RTLE;
	return Result;
}

/* {ET_DYNAMIC_SYSTEM}.meta_type */
EIF_REFERENCE F1996_19899 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,tr2);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12800[Dtype(tr1)-1610]);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8123[Dtype(RTCW(arg1))-1130])(arg1);
		Result = F1996_19897(Current, tr1, tr2);
		F1130_9998(RTCW(arg1), Result);
	}
	RTLE;
	return Result;
}

/* {ET_DYNAMIC_SYSTEM}.new_dynamic_primary_type */
EIF_REFERENCE F1996_19903 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = (EIF_REFERENCE) arg1;
	loc2 = F2024_20433(RTCW(loc1));
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R15310[Dtype(RTCW(loc1))-2024])(loc1);
	if (tb1) {
		loc1 = (EIF_REFERENCE) loc2;
	}
	tb1 = F2027_20601(RTCW(loc2));
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) F1996_19904(Current, loc1);
	} else {
		tb1 = F2027_20603(RTCW(loc2));
		if (tb1) {
			Result = F1996_19905(Current, loc1);
		} else {
			tb1 = F2027_20604(RTCW(loc2));
			if (tb1) {
				Result = F1996_19906(Current, loc1);
			} else {
				tb1 = F2027_20599(RTCW(loc2));
				if (tb1) {
					Result = F1996_19907(Current, loc1);
				} else {
					tb1 = F2027_20595(RTCW(loc2));
					if (tb1) {
						Result = F1996_19908(Current, loc1);
					} else {
						tb1 = F2027_20598(RTCW(loc2));
						if (tb1) {
							Result = F1996_19909(Current, loc1);
							RTLE;
							return (EIF_REFERENCE) Result;
						} else {
							Result = RTLNS(eif_new_type(1131, 0x01).id, 1131, _OBJSIZ_14_4_0_3_0_0_0_0_);
							F1132_10014(RTCW(Result), loc1, loc2);
							F1996_19910(Current, Result);
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_DYNAMIC_SYSTEM}.new_special_type */
EIF_REFERENCE F1996_19904 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLR(8,Result);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + O12740[Dtype(tr1)-1610]);
	loc1 = F2024_20433(RTCW(arg1));
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R15304[Dtype(RTCW(arg1))-2024])(arg1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14070[Dtype(RTCW(loc2))-1897])(loc2);
		tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L));
	}
	if (tb1) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R14072[Dtype(RTCW(loc2))-1897])(loc2, ((EIF_INTEGER_32) 1L));
		loc3 = F1996_19896(Current, tr1, loc5);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R2557[Dtype(RTCW(tr1))-268])(tr1, loc3);
		Result = RTLNS(eif_new_type(1133, 0x01).id, 1133, _OBJSIZ_15_4_0_3_0_0_0_0_);
		F1134_10072(RTCW(Result), arg1, loc1, loc4);
		F1996_19910(Current, Result);
	} else {
		Result = RTLNS(eif_new_type(1131, 0x01).id, 1131, _OBJSIZ_14_4_0_3_0_0_0_0_);
		F1132_10014(RTCW(Result), arg1, loc1);
		F1996_19910(Current, Result);
	}
	RTLE;
	return Result;
}

/* {ET_DYNAMIC_SYSTEM}.new_tuple_type */
EIF_REFERENCE F1996_19905 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(10);
	RTLR(0,loc8);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,loc2);
	RTLR(6,loc5);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLR(9,Result);
	RTLIU(10);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc8 = *(EIF_REFERENCE *)(RTCW(tr1) + O12740[Dtype(tr1)-1610]);
	loc1 = F2024_20433(RTCW(arg1));
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R15304[Dtype(RTCW(arg1))-2024])(arg1);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		loc7 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14070[Dtype(RTCW(loc2))-1897])(loc2);
		if ((EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 0L))) {
			loc5 = RTLNS(eif_new_type(909, 0x01).id, 909, _OBJSIZ_1_0_0_1_0_0_0_0_);
			F899_7043(RTCW(loc5), loc7);
			loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc6 > loc7)) break;
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R14072[Dtype(RTCW(loc2))-1897])(loc2, loc6);
				loc3 = F1996_19896(Current, tr1, loc8);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
				loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R2557[Dtype(RTCW(tr1))-268])(tr1, loc3);
				F899_7053(RTCW(loc5), loc4);
				loc6++;
			}
		} else {
			loc5 = RTOUCR(76,F1996_19964, (Current));
		}
	} else {
		loc5 = RTOUCR(76,F1996_19964, (Current));
	}
	Result = RTLNS(eif_new_type(1132, 0x01).id, 1132, _OBJSIZ_15_4_0_3_0_0_0_0_);
	F1133_10066(RTCW(Result), arg1, loc1, loc5);
	F1996_19910(Current, Result);
	RTLE;
	return Result;
}

/* {ET_DYNAMIC_SYSTEM}.new_type_type */
EIF_REFERENCE F1996_19906 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(9);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,loc2);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,Result);
	RTLIU(9);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + O12740[Dtype(tr1)-1610]);
	loc1 = F2024_20433(RTCW(arg1));
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R15304[Dtype(RTCW(arg1))-2024])(arg1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14070[Dtype(RTCW(loc2))-1897])(loc2);
		tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L));
	}
	if (tb1) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R14072[Dtype(RTCW(loc2))-1897])(loc2, ((EIF_INTEGER_32) 1L));
		loc4 = F1996_19896(Current, tr1, loc3);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc4));
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			RTLE;
			return (EIF_REFERENCE) loc5;
		} else {
			Result = RTLNS(eif_new_type(1131, 0x01).id, 1131, _OBJSIZ_14_4_0_3_0_0_0_0_);
			F1132_10014(RTCW(Result), arg1, loc1);
			F1996_19910(Current, Result);
			F1130_9998(RTCW(loc4), Result);
		}
	} else {
		Result = RTLNS(eif_new_type(1131, 0x01).id, 1131, _OBJSIZ_14_4_0_3_0_0_0_0_);
		F1132_10014(RTCW(Result), arg1, loc1);
		F1996_19910(Current, Result);
	}
	RTLE;
	return Result;
}

/* {ET_DYNAMIC_SYSTEM}.new_procedure_type */
EIF_REFERENCE F1996_19907 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(11);
	RTLR(0,loc9);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLR(7,loc6);
	RTLR(8,loc4);
	RTLR(9,loc5);
	RTLR(10,Result);
	RTLIU(11);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc9 = *(EIF_REFERENCE *)(RTCW(tr1) + O12740[Dtype(tr1)-1610]);
	loc1 = F2024_20433(RTCW(arg1));
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R15304[Dtype(RTCW(arg1))-2024])(arg1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14070[Dtype(RTCW(loc2))-1897])(loc2);
		tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L));
	}
	if (tb1) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R14072[Dtype(RTCW(loc2))-1897])(loc2, ((EIF_INTEGER_32) 1L));
		loc3 = F1996_19896(Current, tr1, loc9);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8123[Dtype(RTCW(loc3))-1130])(loc3);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R15304[Dtype(RTCW(tr1))-2024])(tr1);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			loc8 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14070[Dtype(RTCW(loc2))-1897])(loc2);
			if ((EIF_BOOLEAN) (loc8 > ((EIF_INTEGER_32) 0L))) {
				loc6 = RTLNS(eif_new_type(909, 0x01).id, 909, _OBJSIZ_1_0_0_1_0_0_0_0_);
				F899_7043(RTCW(loc6), loc8);
				loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc7 > loc8)) break;
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R14072[Dtype(RTCW(loc2))-1897])(loc2, loc7);
					loc4 = F1996_19896(Current, tr1, loc9);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
					loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R2557[Dtype(RTCW(tr1))-268])(tr1, loc4);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R3111[Dtype(RTCW(loc5))-388])(loc5);
					F899_7053(RTCW(loc6), loc5);
					loc7++;
				}
			} else {
				loc6 = RTOUCR(76,F1996_19964, (Current));
			}
		} else {
			loc6 = RTOUCR(76,F1996_19964, (Current));
		}
		Result = RTLNS(eif_new_type(1136, 0x01).id, 1136, _OBJSIZ_16_4_0_3_0_0_0_0_);
		F1137_10086(RTCW(Result), arg1, loc1, loc6);
		F1996_19910(Current, Result);
	} else {
		Result = RTLNS(eif_new_type(1131, 0x01).id, 1131, _OBJSIZ_14_4_0_3_0_0_0_0_);
		F1132_10014(RTCW(Result), arg1, loc1);
		F1996_19910(Current, Result);
	}
	RTLE;
	return Result;
}

/* {ET_DYNAMIC_SYSTEM}.new_function_type */
EIF_REFERENCE F1996_19908 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(13);
	RTLR(0,loc11);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,loc2);
	RTLR(6,loc7);
	RTLR(7,loc8);
	RTLR(8,loc3);
	RTLR(9,loc6);
	RTLR(10,loc4);
	RTLR(11,loc5);
	RTLR(12,Result);
	RTLIU(13);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc11 = *(EIF_REFERENCE *)(RTCW(tr1) + O12740[Dtype(tr1)-1610]);
	loc1 = F2024_20433(RTCW(arg1));
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R15304[Dtype(RTCW(arg1))-2024])(arg1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14070[Dtype(RTCW(loc2))-1897])(loc2);
		tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 2L));
	}
	if (tb1) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R14072[Dtype(RTCW(loc2))-1897])(loc2, ((EIF_INTEGER_32) 2L));
		loc7 = F1996_19896(Current, tr1, loc11);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		loc8 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R2557[Dtype(RTCW(tr1))-268])(tr1, loc7);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R3111[Dtype(RTCW(loc8))-388])(loc8);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R14072[Dtype(RTCW(loc2))-1897])(loc2, ((EIF_INTEGER_32) 1L));
		loc3 = F1996_19896(Current, tr1, loc11);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8123[Dtype(RTCW(loc3))-1130])(loc3);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R15304[Dtype(RTCW(tr1))-2024])(tr1);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			loc10 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14070[Dtype(RTCW(loc2))-1897])(loc2);
			if ((EIF_BOOLEAN) (loc10 > ((EIF_INTEGER_32) 0L))) {
				loc6 = RTLNS(eif_new_type(909, 0x01).id, 909, _OBJSIZ_1_0_0_1_0_0_0_0_);
				F899_7043(RTCW(loc6), loc10);
				loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc9 > loc10)) break;
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R14072[Dtype(RTCW(loc2))-1897])(loc2, loc9);
					loc4 = F1996_19896(Current, tr1, loc11);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
					loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R2557[Dtype(RTCW(tr1))-268])(tr1, loc4);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R3111[Dtype(RTCW(loc5))-388])(loc5);
					F899_7053(RTCW(loc6), loc5);
					loc9++;
				}
			} else {
				loc6 = RTOUCR(76,F1996_19964, (Current));
			}
		} else {
			loc6 = RTOUCR(76,F1996_19964, (Current));
		}
		Result = RTLNS(eif_new_type(1135, 0x01).id, 1135, _OBJSIZ_17_4_0_3_0_0_0_0_);
		F1136_10083(RTCW(Result), arg1, loc1, loc6, loc8);
		F1996_19910(Current, Result);
	} else {
		Result = RTLNS(eif_new_type(1131, 0x01).id, 1131, _OBJSIZ_14_4_0_3_0_0_0_0_);
		F1132_10014(RTCW(Result), arg1, loc1);
		F1996_19910(Current, Result);
	}
	RTLE;
	return Result;
}

/* {ET_DYNAMIC_SYSTEM}.new_predicate_type */
EIF_REFERENCE F1996_19909 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(13);
	RTLR(0,loc11);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,loc2);
	RTLR(6,loc7);
	RTLR(7,loc8);
	RTLR(8,loc3);
	RTLR(9,loc6);
	RTLR(10,loc4);
	RTLR(11,loc5);
	RTLR(12,Result);
	RTLIU(13);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc11 = *(EIF_REFERENCE *)(RTCW(tr1) + O12740[Dtype(tr1)-1610]);
	loc1 = F2024_20433(RTCW(arg1));
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R15304[Dtype(RTCW(arg1))-2024])(arg1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14070[Dtype(RTCW(loc2))-1897])(loc2);
		tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L));
	}
	if (tb1) {
		loc7 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		loc8 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R2557[Dtype(RTCW(tr1))-268])(tr1, loc7);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R14072[Dtype(RTCW(loc2))-1897])(loc2, ((EIF_INTEGER_32) 1L));
		loc3 = F1996_19896(Current, tr1, loc11);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8123[Dtype(RTCW(loc3))-1130])(loc3);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R15304[Dtype(RTCW(tr1))-2024])(tr1);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			loc10 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R14070[Dtype(RTCW(loc2))-1897])(loc2);
			if ((EIF_BOOLEAN) (loc10 > ((EIF_INTEGER_32) 0L))) {
				loc6 = RTLNS(eif_new_type(909, 0x01).id, 909, _OBJSIZ_1_0_0_1_0_0_0_0_);
				F899_7043(RTCW(loc6), loc10);
				loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc9 > loc10)) break;
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R14072[Dtype(RTCW(loc2))-1897])(loc2, loc9);
					loc4 = F1996_19896(Current, tr1, loc11);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
					loc5 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R2557[Dtype(RTCW(tr1))-268])(tr1, loc4);
					F899_7053(RTCW(loc6), loc5);
					loc9++;
				}
			} else {
				loc6 = RTOUCR(76,F1996_19964, (Current));
			}
		} else {
			loc6 = RTOUCR(76,F1996_19964, (Current));
		}
		Result = RTLNS(eif_new_type(1135, 0x01).id, 1135, _OBJSIZ_17_4_0_3_0_0_0_0_);
		F1136_10083(RTCW(Result), arg1, loc1, loc6, loc8);
		F1996_19910(Current, Result);
	} else {
		Result = RTLNS(eif_new_type(1131, 0x01).id, 1131, _OBJSIZ_14_4_0_3_0_0_0_0_);
		F1132_10014(RTCW(Result), arg1, loc1);
		F1996_19910(Current, Result);
	}
	RTLE;
	return Result;
}

/* {ET_DYNAMIC_SYSTEM}.register_dynamic_type */
void F1996_19910 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc3);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
	F1541_13864(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	F1132_10033(RTCW(arg1), ti4_1);
	loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_12_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_30_20_0_1_);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc1 >= ((EIF_INTEGER_32) 1L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		tb1 = (EIF_BOOLEAN) (loc1 <= ti4_1);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
		loc2 = F1541_13846(RTCW(tr1), loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
		if ((EIF_BOOLEAN)(tr1 != loc3)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
			F2027_20633(RTCW(loc3), ti4_1);
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_11_);
			F1132_10062(RTCW(arg1), tr1);
			F1132_10062(RTCW(loc2), arg1);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		F2027_20633(RTCW(loc3), ti4_1);
	}
	F1996_19921(Current, arg1);
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.initialize_dynamic_types */
void F1996_19911 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) arg1;
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > arg2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
		loc2 = F1541_13846(RTCW(tr1), loc1);
		loc3 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_12_);
		tb1 = F2027_20601(RTCW(loc3));
		if (tb1) {
			F1996_19912(Current, loc2);
		} else {
			tb1 = F2027_20579(RTCW(loc3));
			if (tb1) {
				F1996_19913(Current, loc2);
			} else {
				tb1 = F2027_20605(RTCW(loc3));
				if (tb1) {
					F1996_19914(Current, loc2);
				} else {
					tb1 = F2027_20599(RTCW(loc3));
					if (tb1) {
						F1996_19915(Current, loc2);
					} else {
						tb1 = F2027_20595(RTCW(loc3));
						if (tb1) {
							F1996_19916(Current, loc2);
						} else {
							tb1 = F2027_20598(RTCW(loc3));
							if (tb1) {
								F1996_19917(Current, loc2);
							}
						}
					}
				}
			}
		}
		F1996_19918(Current, loc2);
		F1996_19919(Current, loc2);
		F1996_19920(Current, loc2);
		loc1++;
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.initialize_special_type */
void F1996_19912 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1132_10042(RTCW(arg1), loc1, Current);
		F1132_10046(RTCW(arg1), tr1, ((EIF_INTEGER_32) 1L));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_45_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = F1132_10042(RTCW(arg1), loc2, Current);
		F1132_10046(RTCW(arg1), tr1, ((EIF_INTEGER_32) 2L));
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.initialize_array_type */
void F1996_19913 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_41_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1132_10042(RTCW(arg1), loc1, Current);
		F1132_10046(RTCW(arg1), tr1, ((EIF_INTEGER_32) 1L));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = F1132_10042(RTCW(arg1), loc2, Current);
		F1132_10046(RTCW(arg1), tr1, ((EIF_INTEGER_32) 2L));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		tr1 = F1132_10042(RTCW(arg1), loc3, Current);
		F1132_10046(RTCW(arg1), tr1, ((EIF_INTEGER_32) 3L));
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.initialize_typed_pointer_type */
void F1996_19914 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_46_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1132_10042(RTCW(arg1), loc1, Current);
		F1132_10046(RTCW(arg1), tr1, ((EIF_INTEGER_32) 1L));
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.initialize_procedure_type */
void F1996_19915 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLIU(10);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc1 + O10400[Dtype(loc1)-1302]);
		tr1 = F1132_10044(RTCW(arg1), ti4_1, Current);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			F1132_10046(RTCW(arg1), loc2, ((EIF_INTEGER_32) 1L));
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_47_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc3 + O10400[Dtype(loc3)-1302]);
		tr1 = F1132_10044(RTCW(arg1), ti4_1, Current);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			F1132_10046(RTCW(arg1), loc4, ((EIF_INTEGER_32) 2L));
		}
	}
	loc5 = arg1;
	loc5 = RTRV(eif_new_type(1134, 0x01),loc5);
	if (EIF_TEST(loc5)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_49_);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			ti4_1 = *(EIF_INTEGER_32 *)(loc6 + O10400[Dtype(loc6)-1302]);
			tr1 = F1132_10045(RTCW(arg1), ti4_1, Current);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				F1017_8123(loc7, (EIF_BOOLEAN) 1);
				F1135_10082(loc5, loc7);
			}
		}
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.initialize_function_type */
void F1996_19916 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLIU(10);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc1 + O10400[Dtype(loc1)-1302]);
		tr1 = F1132_10044(RTCW(arg1), ti4_1, Current);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			F1132_10046(RTCW(arg1), loc2, ((EIF_INTEGER_32) 1L));
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_47_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc3 + O10400[Dtype(loc3)-1302]);
		tr1 = F1132_10044(RTCW(arg1), ti4_1, Current);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			F1132_10046(RTCW(arg1), loc4, ((EIF_INTEGER_32) 2L));
		}
	}
	loc5 = arg1;
	loc5 = RTRV(eif_new_type(1134, 0x01),loc5);
	if (EIF_TEST(loc5)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_49_);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			ti4_1 = *(EIF_INTEGER_32 *)(loc6 + O10400[Dtype(loc6)-1302]);
			tr1 = F1132_10045(RTCW(arg1), ti4_1, Current);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				F1017_8123(loc7, (EIF_BOOLEAN) 1);
				F1135_10082(loc5, loc7);
			}
		}
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.initialize_predicate_type */
void F1996_19917 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg1);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLIU(10);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc1 + O10400[Dtype(loc1)-1302]);
		tr1 = F1132_10044(RTCW(arg1), ti4_1, Current);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			F1132_10046(RTCW(arg1), loc2, ((EIF_INTEGER_32) 1L));
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_47_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc3 + O10400[Dtype(loc3)-1302]);
		tr1 = F1132_10044(RTCW(arg1), ti4_1, Current);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			F1132_10046(RTCW(arg1), loc4, ((EIF_INTEGER_32) 2L));
		}
	}
	loc5 = arg1;
	loc5 = RTRV(eif_new_type(1134, 0x01),loc5);
	if (EIF_TEST(loc5)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_49_);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			ti4_1 = *(EIF_INTEGER_32 *)(loc6 + O10400[Dtype(loc6)-1302]);
			tr1 = F1132_10045(RTCW(arg1), ti4_1, Current);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				F1017_8123(loc7, (EIF_BOOLEAN) 1);
				F1135_10082(loc5, loc7);
			}
		}
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.propagate_type_of_type_result_type */
void F1996_19918 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_50_5_)) {
			F1996_19922(Current, arg1);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
				F268_2957(RTCW(tr1), loc2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R2567[Dtype(RTCW(tr1))-268])(tr1, loc2, loc1);
			} else {
			}
		}
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.propagate_attribute_type_sets */
void F1996_19919 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_50_3_)) {
		loc1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_50_5_);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_50_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		F1132_10047(RTCW(arg1), Current);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_50_5_) = (EIF_BOOLEAN) loc1;
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.propagate_alive_conforming_descendants */
void F1996_19920 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1) + O8136[Dtype(arg1)-1131]);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		F268_2965(RTCW(tr1), arg1);
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.propagate_conforming_ancestors */
void F1996_19921 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(12);
	RTLR(0,loc9);
	RTLR(1,arg1);
	RTLR(2,loc7);
	RTLR(3,loc4);
	RTLR(4,loc5);
	RTLR(5,loc10);
	RTLR(6,Current);
	RTLR(7,tr1);
	RTLR(8,loc3);
	RTLR(9,loc8);
	RTLR(10,tr2);
	RTLR(11,tr3);
	RTLIU(12);
	
	RTGC;
	loc9 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_12_);
	tb1 = F2027_20576(RTCW(loc9));
	if ((EIF_BOOLEAN) !tb1) {
		loc7 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_13_);
		loc4 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
		F1578_14121(RTCW(loc4), arg1);
		loc5 = *(EIF_REFERENCE *)(RTCW(loc9) + _REFACS_20_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_1_0_0_0_);
		loc10 = (EIF_REFERENCE) loc9;
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc6 = *(EIF_INTEGER_32 *)(RTCW(loc10)+ _LNGOFF_30_20_0_1_);
			tb1 = '\0';
			if ((EIF_BOOLEAN) (loc6 >= ((EIF_INTEGER_32) 1L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
				tb1 = (EIF_BOOLEAN) (loc6 <= ti4_1);
			}
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
				loc3 = F1541_13846(RTCW(tr1), loc6);
				for (;;) {
					if ((EIF_BOOLEAN)(loc3 == NULL)) break;
					tb1 = '\0';
					if ((EIF_BOOLEAN)(loc3 != arg1)) {
						tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_12_);
						tb2 = F2027_20576(RTCW(tr1));
						tb1 = (EIF_BOOLEAN) !tb2;
					}
					if (tb1) {
						loc8 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_13_);
						tr1 = F1132_10025(RTCW(loc3));
						tr2 = F1132_10025(RTCW(arg1));
						tr3 = RTOUCR(77,F396_5281, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13669[Dtype(RTCW(loc7))-1829])(loc7, loc8, tr1, loc8, tr2, loc7, tr3);
						if (tb1) {
							F1578_14121(RTCW(loc4), loc3);
						}
					}
					tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_11_);
					loc3 = (EIF_REFERENCE) tr1;
				}
			}
			loc1++;
			if ((EIF_BOOLEAN) (loc1 <= loc2)) {
				tr1 = F899_7044(RTCW(loc5), loc1);
				loc10 = F2024_20433(RTCW(tr1));
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
			loc3 = F1541_13846(RTCW(tr1), loc1);
			loc10 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_12_);
			tb1 = '\0';
			tb2 = '\0';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc10)+ _LNGOFF_30_20_0_1_);
			if ((EIF_BOOLEAN)(ti4_1 == loc1)) {
				tb3 = F2027_20576(RTCW(loc10));
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			if (tb2) {
				tb2 = '\01';
				if (!(EIF_BOOLEAN)(loc10 == loc9)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc10) + _REFACS_20_);
					tb3 = F906_7084(RTCW(tr1), loc9);
					tb2 = tb3;
				}
				tb1 = tb2;
			}
			if (tb1) {
				for (;;) {
					if ((EIF_BOOLEAN)(loc3 == NULL)) break;
					if ((EIF_BOOLEAN)(loc3 != arg1)) {
						loc8 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_13_);
						tr1 = F1132_10025(RTCW(arg1));
						tr2 = F1132_10025(RTCW(loc3));
						tr3 = RTOUCR(77,F396_5281, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R13669[Dtype(RTCW(loc8))-1829])(loc8, loc7, tr1, loc7, tr2, loc8, tr3);
						if (tb1) {
							tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_2_);
							F1578_14121(RTCW(tr1), arg1);
						}
					}
					tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_11_);
					loc3 = (EIF_REFERENCE) tr1;
				}
			}
			loc1++;
		}
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.create_meta_type */
void F1996_19922 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_50_5_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_50_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc2 = F1996_19899(Current, arg1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_50_5_) = (EIF_BOOLEAN) loc1;
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.is_new_instance_type */
EIF_BOOLEAN F1996_19924 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_13_);
		loc1 = F1884_18264(RTCW(tr1));
		tr1 = RTMS_EX_H("attached ",9,1651281952);
		tr2 = RTMS_EX_H("",0,0);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R8514[Dtype(RTCW(loc1))-1184])(loc1, tr1, tr2);
		tr1 = RTMS_EX_H("[attached] ",11,303665184);
		tr2 = RTMS_EX_H("",0,0);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R8514[Dtype(RTCW(loc1))-1184])(loc1, tr1, tr2);
		tr1 = RTMS_EX_H("detachable ",11,1596642848);
		tr2 = RTMS_EX_H("",0,0);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R8514[Dtype(RTCW(loc1))-1184])(loc1, tr1, tr2);
		tr1 = RTMS_EX_H("[detachable] ",13,1464218656);
		tr2 = RTMS_EX_H("",0,0);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R8514[Dtype(RTCW(loc1))-1184])(loc1, tr1, tr2);
		tb1 = F1578_14110(loc2, loc1);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}/* NOTREACHED */
	
}

/* {ET_DYNAMIC_SYSTEM}.set_new_instance_types */
void F1996_19926 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_30_) = (EIF_REFERENCE) arg1;
}

/* {ET_DYNAMIC_SYSTEM}.compile */
void F1996_19927 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12985[Dtype(tr1)-1616]);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		F1996_19929(Current, arg1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12773[Dtype(tr1)-1610]);
		tr2 = RTOUCR(5,F396_5268, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tr3 = RTOUCR(5,F396_5268, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
		tb1 = F1884_18234(RTCW(loc1), tr1, tr2, tr3);
		if (tb1) {
			F1996_19929(Current, arg1);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12740[Dtype(tr1)-1610]);
			tr2 = RTOUCR(5,F396_5268, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tr3 = RTOUCR(5,F396_5268, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tb1 = F1884_18234(RTCW(loc1), tr1, tr2, tr3);
			if (tb1) {
				F1996_19929(Current, arg1);
			} else {
				F1996_19928(Current, arg1);
			}
		}
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.compile_system */
void F1996_19928 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(12);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,loc3);
	RTLR(7,loc7);
	RTLR(8,loc2);
	RTLR(9,loc4);
	RTLR(10,loc5);
	RTLR(11,loc6);
	RTLIU(12);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_50_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F1996_19939(Current, arg1);
	F1290_12764(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	F1996_19931(Current, arg1);
	tb1 = F1290_12786(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12985[Dtype(tr1)-1616]);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			F1996_19935(Current);
			F2046_21235(RTCV(F1996_19936(Current)));
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12773[Dtype(tr1)-1610]);
			tr2 = RTOUCR(5,F396_5268, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tr3 = RTOUCR(5,F396_5268, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			tb1 = F1884_18234(RTCW(loc1), tr1, tr2, tr3);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + O12986[Dtype(tr1)-1616]);
				if ((EIF_BOOLEAN)(loc3 == NULL)) {
					loc3 = RTOUCR(78,F396_4337, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				}
				F1996_19935(Current);
				tr1 = F1996_19936(Current);
				tr2 = F2024_20433(RTCW(loc1));
				F2046_21238(RTCW(tr1), tr2, loc3);
			} else {
				loc7 = F2024_20433(RTCW(loc1));
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
				F2027_20822(RTCW(loc7), tr1);
				tb1 = F2027_20648(RTCW(loc7));
				if ((EIF_BOOLEAN) !tb1) {
					F1996_19935(Current);
					tr1 = F1996_19936(Current);
					F2046_21236(RTCW(tr1), loc7);
				} else {
					tb1 = '\01';
					tb2 = F2027_20662(RTCW(loc7));
					if (!(EIF_BOOLEAN) !tb2) {
						tb2 = F2027_20664(RTCW(loc7));
						tb1 = tb2;
					}
					if (tb1) {
						F1996_19935(Current);
					} else {
						tb1 = F2024_20445(RTCW(loc7));
						if (tb1) {
							F1996_19935(Current);
							tr1 = F1996_19936(Current);
							F2046_21233(RTCW(tr1), loc7);
						} else {
							loc2 = F1996_19897(Current, loc7, loc7);
							RTAR(Current, loc2);
							*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc2;
							tb1 = F2027_20788(RTCW(loc7));
							if (tb1) {
								F1996_19935(Current);
							} else {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + O12986[Dtype(tr1)-1616]);
								if ((EIF_BOOLEAN)(loc3 != NULL)) {
									loc4 = F2027_20745(RTCW(loc7), loc3);
								} else {
									tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O12987[Dtype(tr1)-1616]);
									if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L))) {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O12987[Dtype(tr1)-1616]);
										loc4 = F2027_20748(RTCW(loc7), ti4_1);
										loc3 = RTOUCR(78,F396_4337, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
									} else {
										loc3 = RTOUCR(78,F396_4337, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
										loc4 = F2027_20745(RTCW(loc7), loc3);
									}
								}
								if ((EIF_BOOLEAN)(loc4 == NULL)) {
									if ((EIF_BOOLEAN)(loc3 != NULL)) {
										loc5 = F2027_20744(RTCW(loc7), loc3);
									} else {
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O12987[Dtype(tr1)-1616]);
										if ((EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L))) {
											tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O12987[Dtype(tr1)-1616]);
											loc5 = F2027_20747(RTCW(loc7), ti4_1);
											loc3 = RTOUCR(78,F396_4337, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
										} else {
											loc3 = RTOUCR(78,F396_4337, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
											loc5 = F2027_20744(RTCW(loc7), loc3);
										}
									}
									if ((EIF_BOOLEAN)(loc5 == NULL)) {
										F1996_19935(Current);
										tr1 = F1996_19936(Current);
										F2046_21237(RTCW(tr1), loc7, loc3);
									} else {
										F1996_19935(Current);
										F2046_21728(RTCV(F1996_19936(Current)));
									}
								} else {
									tr1 = F1837_17781(RTCW(loc4));
									tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12740[Dtype(tr2)-1610]);
									tr2 = F2024_20433(RTCW(tr2));
									tb1 = F2027_20734(RTCW(loc7), tr1, tr2);
									if ((EIF_BOOLEAN) !tb1) {
										F1996_19935(Current);
										tr1 = F1996_19936(Current);
										tr2 = F1837_17781(RTCW(loc4));
										F2046_21238(RTCW(tr1), loc7, tr2);
									} else {
										loc6 = F1132_10043(RTCW(loc2), loc4, Current);
										F1017_8122(RTCW(loc6), (EIF_BOOLEAN) 1);
										RTAR(Current, loc6);
										*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc6;
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
										F268_2957(RTCW(tr1), loc2);
										tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
										F268_2957(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_26_));
										F1996_19933(Current);
									}
								}
							}
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.compile_all */
void F1996_19929 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLR(8,tr6);
	RTLIU(9);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_50_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	F1996_19939(Current, arg1);
	F1290_12761(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_2_));
	loc1 = F1290_12782(RTCW(arg1));
	F1996_19931(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	{
		EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1085,0xFF01,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[4] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1171,0xFF01,0xFFF9,1,1085,0xFF01,2026,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A1044_140_2, (EIF_POINTER) _A1044_140_2, (EIF_POINTER)(F1996_19932),tr2, 1, 1);
	}
	tr6 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_14_);
	F1611_16253(RTCW(tr1), tr5, tr6);
	F1996_19933(Current);
	tr1 = RTMS_EX_H("Degree Dynamic Type Set",23,234353524);
	F1290_12784(RTCW(arg1), loc1, tr1);
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.compile_kernel */
void F1996_19931 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc24 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc25 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc26 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc27 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc28 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc29 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc30 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc31 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc32 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc33 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc34 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc35 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc36 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc37 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc38 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc39 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc40 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc41 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc42 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc43 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc44 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc45 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc46 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc47 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc48 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc49 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc50 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc51 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc52 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc53 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc54 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc55 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc56 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc57 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc58 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc59 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc60 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc61 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc62 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc63 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 tu1_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(69);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc4);
	RTLR(5,loc5);
	RTLR(6,loc8);
	RTLR(7,loc9);
	RTLR(8,tr2);
	RTLR(9,loc10);
	RTLR(10,loc11);
	RTLR(11,loc2);
	RTLR(12,loc3);
	RTLR(13,loc12);
	RTLR(14,loc13);
	RTLR(15,loc6);
	RTLR(16,loc14);
	RTLR(17,loc15);
	RTLR(18,loc16);
	RTLR(19,loc17);
	RTLR(20,loc18);
	RTLR(21,loc19);
	RTLR(22,loc20);
	RTLR(23,loc21);
	RTLR(24,loc22);
	RTLR(25,loc23);
	RTLR(26,loc24);
	RTLR(27,loc25);
	RTLR(28,loc26);
	RTLR(29,loc27);
	RTLR(30,loc28);
	RTLR(31,loc29);
	RTLR(32,loc30);
	RTLR(33,loc31);
	RTLR(34,loc32);
	RTLR(35,loc33);
	RTLR(36,loc34);
	RTLR(37,loc35);
	RTLR(38,loc7);
	RTLR(39,loc36);
	RTLR(40,loc37);
	RTLR(41,loc38);
	RTLR(42,loc39);
	RTLR(43,loc40);
	RTLR(44,loc41);
	RTLR(45,loc42);
	RTLR(46,loc43);
	RTLR(47,loc44);
	RTLR(48,loc45);
	RTLR(49,loc46);
	RTLR(50,loc47);
	RTLR(51,loc48);
	RTLR(52,loc49);
	RTLR(53,loc50);
	RTLR(54,loc51);
	RTLR(55,tr3);
	RTLR(56,tr4);
	RTLR(57,loc52);
	RTLR(58,loc53);
	RTLR(59,loc54);
	RTLR(60,loc55);
	RTLR(61,loc56);
	RTLR(62,loc57);
	RTLR(63,loc58);
	RTLR(64,loc59);
	RTLR(65,loc60);
	RTLR(66,loc61);
	RTLR(67,loc62);
	RTLR(68,loc63);
	RTLIU(69);
	
	RTGC;
	tb1 = F1290_12786(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
		F1541_13892(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12740[Dtype(tr1)-1610]);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12750[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		}
		tr1 = F1996_19897(Current, loc4, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12752[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		}
		tr1 = F1996_19897(Current, loc4, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12753[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		}
		tr1 = F1996_19897(Current, loc4, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12762[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		}
		tr1 = F1996_19897(Current, loc4, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12763[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		}
		tr1 = F1996_19897(Current, loc4, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12764[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		}
		tr1 = F1996_19897(Current, loc4, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12765[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		}
		tr1 = F1996_19897(Current, loc4, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12769[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		}
		tr1 = F1996_19897(Current, loc4, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12770[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		}
		tr1 = F1996_19897(Current, loc4, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12771[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		}
		tr1 = F1996_19897(Current, loc4, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12772[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		}
		tr1 = F1996_19897(Current, loc4, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12779[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		}
		tr1 = F1996_19897(Current, loc4, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12780[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		}
		tr1 = F1996_19897(Current, loc4, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12775[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		}
		tr1 = F1996_19897(Current, loc4, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
		*(EIF_REFERENCE *)(Current + _REFACS_44_) = (EIF_REFERENCE) NULL;
		*(EIF_REFERENCE *)(Current + _REFACS_45_) = (EIF_REFERENCE) NULL;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12782[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(tr1));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_10_);
			F2027_20822(RTCW(loc5), tr1);
			tb1 = '\01';
			tb2 = F2027_20786(RTCW(loc5));
			if (!(EIF_BOOLEAN) !tb2) {
				tb2 = F2027_20788(RTCW(loc5));
				tb1 = tb2;
			}
			if (tb1) {
				F1996_19935(Current);
			} else {
				tr1 = RTOUCR(79,F396_4332, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20744(RTCW(loc5), tr1);
				loc8 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc8)) {
					tr1 = RTOUCR(79,F396_4332, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20745(RTCW(loc5), tr1);
					loc9 = tr1;
					if (EIF_TEST(loc9)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc9);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(79,F396_4332, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tr1 = F1839_17878(loc8);
					tr2 = F2027_20637(RTCW(loc5));
					tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
					tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
					if ((EIF_BOOLEAN) !tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = F2027_20637(RTCW(loc5));
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
						F2046_21542(RTCW(tr1), loc5, loc8, tr2);
					} else {
						RTAR(Current, loc8);
						*(EIF_REFERENCE *)(Current + _REFACS_44_) = (EIF_REFERENCE) loc8;
					}
				}
				tr1 = RTOUCR(80,F396_4309, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20744(RTCW(loc5), tr1);
				loc10 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc10)) {
					tr1 = RTOUCR(80,F396_4309, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20745(RTCW(loc5), tr1);
					loc11 = tr1;
					if (EIF_TEST(loc11)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc11);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(80,F396_4309, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tr1 = F1839_17878(loc10);
					tr2 = F2027_20637(RTCW(loc5));
					tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
					tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
					if ((EIF_BOOLEAN) !tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = F2027_20637(RTCW(loc5));
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
						F2046_21542(RTCW(tr1), loc5, loc10, tr2);
					} else {
						RTAR(Current, loc10);
						*(EIF_REFERENCE *)(Current + _REFACS_45_) = (EIF_REFERENCE) loc10;
					}
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12782[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(tr1));
		loc2 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
		F1901_18643(RTCW(loc2), ((EIF_INTEGER_32) 1L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12752[Dtype(tr1)-1610]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc2))-1003])(loc2, tr1);
		loc3 = RTLNS(eif_new_type(2025, 0x01).id, 2025, _OBJSIZ_4_2_0_0_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc5));
		F2026_20529(RTCW(loc3), NULL, tr1, loc2, loc5);
		tr1 = F1996_19897(Current, loc3, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12782[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(tr1));
		loc2 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
		F1901_18643(RTCW(loc2), ((EIF_INTEGER_32) 1L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12753[Dtype(tr1)-1610]);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R6369[Dtype(RTCW(loc2))-1003])(loc2, tr1);
		loc3 = RTLNS(eif_new_type(2025, 0x01).id, 2025, _OBJSIZ_4_2_0_0_0_0_0_0_);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc5));
		F2026_20529(RTCW(loc3), NULL, tr1, loc2, loc5);
		tr1 = F1996_19897(Current, loc3, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12787[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) tr1;
		} else {
			tr1 = F1996_19897(Current, loc4, loc1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) tr1;
			tb1 = F2027_20788(RTCW(loc5));
			if (tb1) {
				F1996_19935(Current);
			} else {
				tr1 = RTOUCR(81,F396_4284, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20744(RTCW(loc5), tr1);
				loc12 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc12)) {
					tr1 = RTOUCR(81,F396_4284, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20745(RTCW(loc5), tr1);
					loc13 = tr1;
					if (EIF_TEST(loc13)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc13);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(81,F396_4284, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc12)-1840])(loc12);
					if ((EIF_BOOLEAN) !tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc12);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
						loc6 = F1132_10042(RTCW(tr1), loc12, Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc6));
						loc14 = tr1;
						if ((EIF_BOOLEAN) !EIF_TEST(loc14)) {
							F1996_19935(Current);
							F2046_21728(RTCV(F1996_19936(Current)));
						} else {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3112[Dtype(loc14)-388])(loc14);
							if ((EIF_BOOLEAN)(tr1 != F1996_19898(Current, *(EIF_REFERENCE *)(Current + _REFACS_24_)))) {
								F1996_19935(Current);
								tr1 = F1996_19936(Current);
								tr2 = F1996_19898(Current, *(EIF_REFERENCE *)(Current + _REFACS_24_));
								tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8123[Dtype(RTCW(tr2))-1130])(tr2);
								F2046_21542(RTCW(tr1), loc5, loc12, tr2);
							}
						}
					}
				}
				tr1 = RTOUCR(79,F396_4332, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20744(RTCW(loc5), tr1);
				loc15 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc15)) {
					tr1 = RTOUCR(79,F396_4332, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20745(RTCW(loc5), tr1);
					loc16 = tr1;
					if (EIF_TEST(loc16)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc16);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(79,F396_4332, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc15)-1840])(loc15);
					if ((EIF_BOOLEAN) !tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc15);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
						loc6 = F1132_10042(RTCW(tr1), loc15, Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc6));
						loc17 = tr1;
						if ((EIF_BOOLEAN) !EIF_TEST(loc17)) {
							F1996_19935(Current);
							F2046_21728(RTCV(F1996_19936(Current)));
						} else {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3112[Dtype(loc17)-388])(loc17);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8123[Dtype(RTCW(tr1))-1130])(tr1);
							tr2 = F2027_20637(RTCW(loc5));
							tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
							tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
							if ((EIF_BOOLEAN) !tb1) {
								F1996_19935(Current);
								tr1 = F1996_19936(Current);
								tr2 = F2027_20637(RTCW(loc5));
								tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
								F2046_21542(RTCW(tr1), loc5, loc15, tr2);
							}
						}
					}
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12788[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) tr1;
		} else {
			tr1 = F1996_19897(Current, loc4, loc1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) tr1;
			tb1 = F2027_20788(RTCW(loc5));
			if (tb1) {
				F1996_19935(Current);
			} else {
				tr1 = RTOUCR(81,F396_4284, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20744(RTCW(loc5), tr1);
				loc18 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc18)) {
					tr1 = RTOUCR(81,F396_4284, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20745(RTCW(loc5), tr1);
					loc19 = tr1;
					if (EIF_TEST(loc19)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc19);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(81,F396_4284, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc18)-1840])(loc18);
					if ((EIF_BOOLEAN) !tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc18);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
						loc6 = F1132_10042(RTCW(tr1), loc18, Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc6));
						loc20 = tr1;
						if ((EIF_BOOLEAN) !EIF_TEST(loc20)) {
							F1996_19935(Current);
							F2046_21728(RTCV(F1996_19936(Current)));
						} else {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3112[Dtype(loc20)-388])(loc20);
							if ((EIF_BOOLEAN)(tr1 != F1996_19898(Current, *(EIF_REFERENCE *)(Current + _REFACS_25_)))) {
								F1996_19935(Current);
								tr1 = F1996_19936(Current);
								tr2 = F1996_19898(Current, *(EIF_REFERENCE *)(Current + _REFACS_25_));
								tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8123[Dtype(RTCW(tr2))-1130])(tr2);
								F2046_21542(RTCW(tr1), loc5, loc18, tr2);
							}
						}
					}
				}
				tr1 = RTOUCR(79,F396_4332, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20744(RTCW(loc5), tr1);
				loc21 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc21)) {
					tr1 = RTOUCR(79,F396_4332, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20745(RTCW(loc5), tr1);
					loc22 = tr1;
					if (EIF_TEST(loc22)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc22);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(79,F396_4332, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc21)-1840])(loc21);
					if ((EIF_BOOLEAN) !tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc21);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
						loc6 = F1132_10042(RTCW(tr1), loc21, Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc6));
						loc23 = tr1;
						if ((EIF_BOOLEAN) !EIF_TEST(loc23)) {
							F1996_19935(Current);
							F2046_21728(RTCV(F1996_19936(Current)));
						} else {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3112[Dtype(loc23)-388])(loc23);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8123[Dtype(RTCW(tr1))-1130])(tr1);
							tr2 = F2027_20637(RTCW(loc5));
							tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
							tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
							if ((EIF_BOOLEAN) !tb1) {
								F1996_19935(Current);
								tr1 = F1996_19936(Current);
								tr2 = F2027_20637(RTCW(loc5));
								tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
								F2046_21542(RTCW(tr1), loc5, loc21, tr2);
							}
						}
					}
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12759[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
		} else {
			tr1 = F1996_19897(Current, loc4, loc1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
			tb1 = F2027_20788(RTCW(loc5));
			if (tb1) {
				F1996_19935(Current);
			} else {
				tr1 = RTOUCR(81,F396_4284, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20744(RTCW(loc5), tr1);
				loc24 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc24)) {
					tr1 = RTOUCR(81,F396_4284, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20745(RTCW(loc5), tr1);
					loc25 = tr1;
					if (EIF_TEST(loc25)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc25);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(81,F396_4284, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc24)-1840])(loc24);
					if ((EIF_BOOLEAN) !tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc24);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
						loc6 = F1132_10042(RTCW(tr1), loc24, Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc6));
						loc26 = tr1;
						if ((EIF_BOOLEAN) !EIF_TEST(loc26)) {
							F1996_19935(Current);
							F2046_21728(RTCV(F1996_19936(Current)));
						} else {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3112[Dtype(loc26)-388])(loc26);
							if ((EIF_BOOLEAN)(tr1 != F1996_19898(Current, *(EIF_REFERENCE *)(Current + _REFACS_24_)))) {
								F1996_19935(Current);
								tr1 = F1996_19936(Current);
								tr2 = F1996_19898(Current, *(EIF_REFERENCE *)(Current + _REFACS_24_));
								tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8123[Dtype(RTCW(tr2))-1130])(tr2);
								F2046_21542(RTCW(tr1), loc5, loc24, tr2);
							}
						}
					}
				}
				tr1 = RTOUCR(79,F396_4332, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20744(RTCW(loc5), tr1);
				loc27 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc27)) {
					tr1 = RTOUCR(79,F396_4332, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20745(RTCW(loc5), tr1);
					loc28 = tr1;
					if (EIF_TEST(loc28)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc28);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(79,F396_4332, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc27)-1840])(loc27);
					if ((EIF_BOOLEAN) !tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc27);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_22_);
						loc6 = F1132_10042(RTCW(tr1), loc27, Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc6));
						loc29 = tr1;
						if ((EIF_BOOLEAN) !EIF_TEST(loc29)) {
							F1996_19935(Current);
							F2046_21728(RTCV(F1996_19936(Current)));
						} else {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3112[Dtype(loc29)-388])(loc29);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8123[Dtype(RTCW(tr1))-1130])(tr1);
							tr2 = F2027_20637(RTCW(loc5));
							tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
							tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
							if ((EIF_BOOLEAN) !tb1) {
								F1996_19935(Current);
								tr1 = F1996_19936(Current);
								tr2 = F2027_20637(RTCW(loc5));
								tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
								F2046_21542(RTCW(tr1), loc5, loc27, tr2);
							}
						}
					}
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12760[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
		} else {
			tr1 = F1996_19897(Current, loc4, loc1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
			tb1 = F2027_20788(RTCW(loc5));
			if (tb1) {
				F1996_19935(Current);
			} else {
				tr1 = RTOUCR(81,F396_4284, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20744(RTCW(loc5), tr1);
				loc30 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc30)) {
					tr1 = RTOUCR(81,F396_4284, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20745(RTCW(loc5), tr1);
					loc31 = tr1;
					if (EIF_TEST(loc31)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc31);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(81,F396_4284, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc30)-1840])(loc30);
					if ((EIF_BOOLEAN) !tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc30);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
						loc6 = F1132_10042(RTCW(tr1), loc30, Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc6));
						loc32 = tr1;
						if ((EIF_BOOLEAN) !EIF_TEST(loc32)) {
							F1996_19935(Current);
							F2046_21728(RTCV(F1996_19936(Current)));
						} else {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3112[Dtype(loc32)-388])(loc32);
							if ((EIF_BOOLEAN)(tr1 != F1996_19898(Current, *(EIF_REFERENCE *)(Current + _REFACS_25_)))) {
								F1996_19935(Current);
								tr1 = F1996_19936(Current);
								tr2 = F1996_19898(Current, *(EIF_REFERENCE *)(Current + _REFACS_25_));
								tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8123[Dtype(RTCW(tr2))-1130])(tr2);
								F2046_21542(RTCW(tr1), loc5, loc30, tr2);
							}
						}
					}
				}
				tr1 = RTOUCR(79,F396_4332, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20744(RTCW(loc5), tr1);
				loc33 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc33)) {
					tr1 = RTOUCR(79,F396_4332, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20745(RTCW(loc5), tr1);
					loc34 = tr1;
					if (EIF_TEST(loc34)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc34);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(79,F396_4332, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc33)-1840])(loc33);
					if ((EIF_BOOLEAN) !tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc33);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_23_);
						loc6 = F1132_10042(RTCW(tr1), loc33, Current);
						tr1 = *(EIF_REFERENCE *)(RTCW(loc6));
						loc35 = tr1;
						if ((EIF_BOOLEAN) !EIF_TEST(loc35)) {
							F1996_19935(Current);
							F2046_21728(RTCV(F1996_19936(Current)));
						} else {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3112[Dtype(loc35)-388])(loc35);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8123[Dtype(RTCW(tr1))-1130])(tr1);
							tr2 = F2027_20637(RTCW(loc5));
							tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
							tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
							if ((EIF_BOOLEAN) !tb1) {
								F1996_19935(Current);
								tr1 = F1996_19936(Current);
								tr2 = F2027_20637(RTCW(loc5));
								tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
								F2046_21542(RTCW(tr1), loc5, loc33, tr2);
							}
						}
					}
				}
			}
		}
		*(EIF_REFERENCE *)(Current + _REFACS_41_) = (EIF_REFERENCE) NULL;
		*(EIF_REFERENCE *)(Current + _REFACS_42_) = (EIF_REFERENCE) NULL;
		*(EIF_REFERENCE *)(Current + _REFACS_43_) = (EIF_REFERENCE) NULL;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12746[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(tr1));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_10_);
			F2027_20822(RTCW(loc5), tr1);
			tb1 = '\01';
			tb2 = F2027_20786(RTCW(loc5));
			if (!(EIF_BOOLEAN) !tb2) {
				tb2 = F2027_20788(RTCW(loc5));
				tb1 = tb2;
			}
			if (tb1) {
				F1996_19935(Current);
			} else {
				loc7 = RTLNS(eif_new_type(2022, 0x01).id, 2022, _OBJSIZ_2_0_0_1_0_0_0_0_);
				F2023_20388(RTCW(loc7), loc5, ((EIF_INTEGER_32) 1L));
				tr1 = F2027_20699(RTCW(loc5), ((EIF_INTEGER_32) 1L));
				F899_7053(RTCW(loc7), tr1);
				tr1 = RTOUCR(81,F396_4284, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20744(RTCW(loc5), tr1);
				loc36 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc36)) {
					tr1 = RTOUCR(81,F396_4284, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20745(RTCW(loc5), tr1);
					loc37 = tr1;
					if (EIF_TEST(loc37)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc37);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(81,F396_4284, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc36)-1840])(loc36);
					if ((EIF_BOOLEAN) !tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc36);
					} else {
						tr1 = F1839_17878(loc36);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12784[Dtype(tr2)-1610]);
						tb1 = F1884_18234(RTCW(tr1), tr2, loc7, loc5);
						if ((EIF_BOOLEAN) !tb1) {
							F1996_19935(Current);
							tr1 = F1996_19936(Current);
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12782[Dtype(tr2)-1610]);
							tr2 = F2024_20433(RTCW(tr2));
							F2046_21542(RTCW(tr1), loc5, loc36, tr2);
						} else {
							RTAR(Current, loc36);
							*(EIF_REFERENCE *)(Current + _REFACS_41_) = (EIF_REFERENCE) loc36;
						}
					}
				}
				tr1 = RTOUCR(82,F396_4451, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20744(RTCW(loc5), tr1);
				loc38 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc38)) {
					tr1 = RTOUCR(82,F396_4451, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20745(RTCW(loc5), tr1);
					loc39 = tr1;
					if (EIF_TEST(loc39)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc39);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(82,F396_4451, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc38)-1840])(loc38);
					if ((EIF_BOOLEAN) !tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc38);
					} else {
						tr1 = F1839_17878(loc38);
						tr2 = F2027_20637(RTCW(loc5));
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
						tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
						if ((EIF_BOOLEAN) !tb1) {
							F1996_19935(Current);
							tr1 = F1996_19936(Current);
							tr2 = F2027_20637(RTCW(loc5));
							tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
							F2046_21542(RTCW(tr1), loc5, loc38, tr2);
						} else {
							RTAR(Current, loc38);
							*(EIF_REFERENCE *)(Current + _REFACS_42_) = (EIF_REFERENCE) loc38;
						}
					}
				}
				tr1 = RTOUCR(83,F396_4594, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20744(RTCW(loc5), tr1);
				loc40 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc40)) {
					tr1 = RTOUCR(83,F396_4594, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20745(RTCW(loc5), tr1);
					loc41 = tr1;
					if (EIF_TEST(loc41)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc41);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(83,F396_4594, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc40)-1840])(loc40);
					if ((EIF_BOOLEAN) !tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc40);
					} else {
						tr1 = F1839_17878(loc40);
						tr2 = F2027_20637(RTCW(loc5));
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
						tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
						if ((EIF_BOOLEAN) !tb1) {
							F1996_19935(Current);
							tr1 = F1996_19936(Current);
							tr2 = F2027_20637(RTCW(loc5));
							tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
							F2046_21542(RTCW(tr1), loc5, loc40, tr2);
						} else {
							RTAR(Current, loc40);
							*(EIF_REFERENCE *)(Current + _REFACS_43_) = (EIF_REFERENCE) loc40;
						}
					}
				}
			}
		}
		*(EIF_REFERENCE *)(Current + _REFACS_46_) = (EIF_REFERENCE) NULL;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12801[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(tr1));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_10_);
			F2027_20822(RTCW(loc5), tr1);
			tb1 = '\01';
			tb2 = F2027_20786(RTCW(loc5));
			if (!(EIF_BOOLEAN) !tb2) {
				tb2 = F2027_20788(RTCW(loc5));
				tb1 = tb2;
			}
			if (tb1) {
				F1996_19935(Current);
			} else {
				tr1 = RTOUCR(84,F482_6178, (Current));
				tb1 = F1290_12728(RTCW(arg1), tr1);
				if (tb1) {
					tr1 = RTOUCR(85,F396_4492, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20744(RTCW(loc5), tr1);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_46_) = (EIF_REFERENCE) tr1;
				} else {
					tr1 = RTOUCR(86,F396_4580, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20744(RTCW(loc5), tr1);
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_46_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_46_);
				loc42 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc42)) {
					tr1 = RTOUCR(86,F396_4580, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20745(RTCW(loc5), tr1);
					loc43 = tr1;
					if (EIF_TEST(loc43)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc43);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(86,F396_4580, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tr1 = F1839_17878(loc42);
					tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12775[Dtype(tr2)-1610]);
					tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
					if ((EIF_BOOLEAN) !tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12775[Dtype(tr2)-1610]);
						F2046_21542(RTCW(tr1), loc5, loc42, tr2);
						*(EIF_REFERENCE *)(Current + _REFACS_46_) = (EIF_REFERENCE) NULL;
					} else {
						tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc42)-1840])(loc42);
						if ((EIF_BOOLEAN) !tb1) {
							tb1 = '\01';
							loc44 = loc42;
							loc44 = RTRV(eif_new_type(1856, 0x01),loc44);
							if (!((EIF_BOOLEAN) !EIF_TEST(loc44))) {
								tb2 = '\0';
								tu1_1 = *(EIF_NATURAL_8 *)(loc44+ _CHROFF_24_3_);
								tu1_2 = ((EIF_NATURAL_8) 36U);
								if ((EIF_BOOLEAN)(tu1_1 == tu1_2)) {
									tu1_1 = *(EIF_NATURAL_8 *)(loc44+ _CHROFF_24_4_);
									tu1_2 = ((EIF_NATURAL_8) 1U);
									tb2 = (EIF_BOOLEAN)(tu1_1 == tu1_2);
								}
								tb1 = (EIF_BOOLEAN) !tb2;
							}
							if (tb1) {
								F1996_19935(Current);
								tr1 = F1996_19936(Current);
								F2046_21541(RTCW(tr1), loc5, loc42);
								*(EIF_REFERENCE *)(Current + _REFACS_46_) = (EIF_REFERENCE) NULL;
							}
						}
					}
				}
			}
		}
		*(EIF_REFERENCE *)(Current + _REFACS_47_) = (EIF_REFERENCE) NULL;
		*(EIF_REFERENCE *)(Current + _REFACS_48_) = (EIF_REFERENCE) NULL;
		*(EIF_REFERENCE *)(Current + _REFACS_49_) = (EIF_REFERENCE) NULL;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12781[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(tr1));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_10_);
			F2027_20822(RTCW(loc5), tr1);
			tb1 = '\01';
			tb2 = F2027_20786(RTCW(loc5));
			if (!(EIF_BOOLEAN) !tb2) {
				tb2 = F2027_20788(RTCW(loc5));
				tb1 = tb2;
			}
			if (tb1) {
				F1996_19935(Current);
			} else {
				tr1 = RTOUCR(87,F396_4325, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20744(RTCW(loc5), tr1);
				loc45 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc45)) {
					tr1 = RTOUCR(87,F396_4325, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20745(RTCW(loc5), tr1);
					loc46 = tr1;
					if (EIF_TEST(loc46)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc46);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(87,F396_4325, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc45)-1840])(loc45);
					if ((EIF_BOOLEAN) !tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc45);
					} else {
						tr1 = F1839_17878(loc45);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12793[Dtype(tr2)-1610]);
						tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
						if ((EIF_BOOLEAN) !tb1) {
							F1996_19935(Current);
							tr1 = F1996_19936(Current);
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12793[Dtype(tr2)-1610]);
							F2046_21542(RTCW(tr1), loc5, loc45, tr2);
						} else {
							RTAR(Current, loc45);
							*(EIF_REFERENCE *)(Current + _REFACS_47_) = (EIF_REFERENCE) loc45;
						}
					}
				}
				tr1 = RTOUCR(88,F396_4528, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20744(RTCW(loc5), tr1);
				loc47 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc47)) {
					tr1 = RTOUCR(88,F396_4528, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20745(RTCW(loc5), tr1);
					loc48 = tr1;
					if (EIF_TEST(loc48)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc48);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(88,F396_4528, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R13711[Dtype(loc47)-1840])(loc47);
					if ((EIF_BOOLEAN) !tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21541(RTCW(tr1), loc5, loc47);
					} else {
						tr1 = F1839_17878(loc47);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12775[Dtype(tr2)-1610]);
						tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
						if ((EIF_BOOLEAN) !tb1) {
							F1996_19935(Current);
							tr1 = F1996_19936(Current);
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12775[Dtype(tr2)-1610]);
							F2046_21542(RTCW(tr1), loc5, loc47, tr2);
						} else {
							RTAR(Current, loc47);
							*(EIF_REFERENCE *)(Current + _REFACS_48_) = (EIF_REFERENCE) loc47;
						}
					}
				}
				tr1 = RTOUCR(89,F396_4568, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20745(RTCW(loc5), tr1);
				loc49 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc49)) {
					tr1 = RTOUCR(89,F396_4568, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20744(RTCW(loc5), tr1);
					loc50 = tr1;
					if (EIF_TEST(loc50)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21543(RTCW(tr1), loc5, loc50);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(89,F396_4568, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = '\01';
					tr1 = *(EIF_REFERENCE *)(loc49 + _REFACS_5_);
					loc51 = tr1;
					if (!((EIF_BOOLEAN) !EIF_TEST(loc51))) {
						ti4_1 = *(EIF_INTEGER_32 *)(loc51+ _LNGOFF_3_0_0_0_);
						tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 6L));
					}
					if (tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						{
							static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 6L),sizeof(EIF_REFERENCE), EIF_FALSE);
							RT_SPECIAL_COUNT(tr3) = 6L;
							memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
						}
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12792[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
						F2046_21545(RTCW(tr1), loc5, loc49, tr2, NULL);
					} else {
						tr1 = F1649_16721(loc51, ((EIF_INTEGER_32) 1L));
						tr1 = F1814_17596(RTCW(tr1));
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12775[Dtype(tr2)-1610]);
						tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
						if ((EIF_BOOLEAN) !tb1) {
							F1996_19935(Current);
							tr1 = F1996_19936(Current);
							{
								static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 6L),sizeof(EIF_REFERENCE), EIF_FALSE);
								RT_SPECIAL_COUNT(tr3) = 6L;
								memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
							}
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12792[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
							F2046_21545(RTCW(tr1), loc5, loc49, tr2, NULL);
						} else {
							tr1 = F1649_16721(loc51, ((EIF_INTEGER_32) 2L));
							tr1 = F1814_17596(RTCW(tr1));
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
							tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12775[Dtype(tr2)-1610]);
							tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
							if ((EIF_BOOLEAN) !tb1) {
								F1996_19935(Current);
								tr1 = F1996_19936(Current);
								{
									static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
									EIF_TYPE typres0;
									static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
									
									typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
									tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 6L),sizeof(EIF_REFERENCE), EIF_FALSE);
									RT_SPECIAL_COUNT(tr3) = 6L;
									memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
								}
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12792[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
								F2046_21545(RTCW(tr1), loc5, loc49, tr2, NULL);
							} else {
								tr1 = F1649_16721(loc51, ((EIF_INTEGER_32) 3L));
								tr1 = F1814_17596(RTCW(tr1));
								tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
								tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12775[Dtype(tr2)-1610]);
								tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
								if ((EIF_BOOLEAN) !tb1) {
									F1996_19935(Current);
									tr1 = F1996_19936(Current);
									{
										static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
										EIF_TYPE typres0;
										static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
										
										typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
										tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 6L),sizeof(EIF_REFERENCE), EIF_FALSE);
										RT_SPECIAL_COUNT(tr3) = 6L;
										memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
									}
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12792[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
									F2046_21545(RTCW(tr1), loc5, loc49, tr2, NULL);
								} else {
									tr1 = F1649_16721(loc51, ((EIF_INTEGER_32) 4L));
									tr1 = F1814_17596(RTCW(tr1));
									tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
									tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12792[Dtype(tr2)-1610]);
									tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
									if ((EIF_BOOLEAN) !tb1) {
										F1996_19935(Current);
										tr1 = F1996_19936(Current);
										{
											static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
											EIF_TYPE typres0;
											static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
											
											typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
											tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 6L),sizeof(EIF_REFERENCE), EIF_FALSE);
											RT_SPECIAL_COUNT(tr3) = 6L;
											memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
										}
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12792[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
										F2046_21545(RTCW(tr1), loc5, loc49, tr2, NULL);
									} else {
										tr1 = F1649_16721(loc51, ((EIF_INTEGER_32) 5L));
										tr1 = F1814_17596(RTCW(tr1));
										tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
										tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
										tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
										if ((EIF_BOOLEAN) !tb1) {
											F1996_19935(Current);
											tr1 = F1996_19936(Current);
											{
												static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
												EIF_TYPE typres0;
												static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
												
												typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
												tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 6L),sizeof(EIF_REFERENCE), EIF_FALSE);
												RT_SPECIAL_COUNT(tr3) = 6L;
												memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
											}
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12792[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
											F2046_21545(RTCW(tr1), loc5, loc49, tr2, NULL);
										} else {
											tr1 = F1649_16721(loc51, ((EIF_INTEGER_32) 6L));
											tr1 = F1814_17596(RTCW(tr1));
											tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
											tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
											tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
											if ((EIF_BOOLEAN) !tb1) {
												F1996_19935(Current);
												tr1 = F1996_19936(Current);
												{
													static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
													EIF_TYPE typres0;
													static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
													
													typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
													tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 6L),sizeof(EIF_REFERENCE), EIF_FALSE);
													RT_SPECIAL_COUNT(tr3) = 6L;
													memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
												}
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12775[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12792[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
												F2046_21545(RTCW(tr1), loc5, loc49, tr2, NULL);
											} else {
												RTAR(Current, loc49);
												*(EIF_REFERENCE *)(Current + _REFACS_49_) = (EIF_REFERENCE) loc49;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) NULL;
		*(EIF_REFERENCE *)(Current + _REFACS_34_) = (EIF_REFERENCE) NULL;
		*(EIF_REFERENCE *)(Current + _REFACS_35_) = (EIF_REFERENCE) NULL;
		*(EIF_REFERENCE *)(Current + _REFACS_36_) = (EIF_REFERENCE) NULL;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + O12766[Dtype(tr1)-1610]);
		loc5 = F2024_20433(RTCW(loc4));
		tb1 = F2027_20648(RTCW(loc5));
		if ((EIF_BOOLEAN) !tb1) {
			F1996_19935(Current);
			tr1 = F1996_19936(Current);
			F2046_21234(RTCW(tr1), loc5);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) tr1;
		} else {
			tr1 = F1996_19897(Current, loc4, loc1);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) tr1;
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_10_);
			F2027_20822(RTCW(loc5), tr1);
			tb1 = '\01';
			tb2 = F2027_20786(RTCW(loc5));
			if (!(EIF_BOOLEAN) !tb2) {
				tb2 = F2027_20788(RTCW(loc5));
				tb1 = tb2;
			}
			if (tb1) {
				F1996_19935(Current);
			} else {
				tr1 = RTOUCR(90,F396_4393, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20745(RTCW(loc5), tr1);
				loc52 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc52)) {
					tr1 = RTOUCR(90,F396_4393, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20744(RTCW(loc5), tr1);
					loc53 = tr1;
					if (EIF_TEST(loc53)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21543(RTCW(tr1), loc5, loc53);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(90,F396_4393, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = '\0';
					tr1 = *(EIF_REFERENCE *)(loc52 + _REFACS_5_);
					loc54 = tr1;
					if (EIF_TEST(loc54)) {
						ti4_1 = *(EIF_INTEGER_32 *)(loc54+ _LNGOFF_3_0_0_0_);
						tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
					}
					if (tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21545(RTCW(tr1), loc5, loc52, NULL, NULL);
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
						loc6 = F1132_10043(RTCW(tr1), loc52, Current);
						F1017_8123(RTCW(loc6), (EIF_BOOLEAN) 1);
						RTAR(Current, loc6);
						*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) loc6;
					}
				}
				tr1 = RTOUCR(91,F396_4448, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20744(RTCW(loc5), tr1);
				loc55 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc55)) {
					tr1 = RTOUCR(91,F396_4448, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20745(RTCW(loc5), tr1);
					loc56 = tr1;
					if (EIF_TEST(loc56)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21543(RTCW(tr1), loc5, loc56);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(91,F396_4448, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = '\0';
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10399[Dtype(loc55)-1840])(loc55);
					loc57 = tr1;
					if (EIF_TEST(loc57)) {
						ti4_1 = *(EIF_INTEGER_32 *)(loc57+ _LNGOFF_3_0_0_0_);
						tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
					}
					if (tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12756[Dtype(tr2)-1610]);
						F2046_21545(RTCW(tr1), loc5, loc55, NULL, tr2);
					} else {
						tr1 = F1839_17878(loc55);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13369[Dtype(RTCW(tr1))-1885])(tr1);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12756[Dtype(tr2)-1610]);
						tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
						if ((EIF_BOOLEAN) !tb1) {
							F1996_19935(Current);
							tr1 = F1996_19936(Current);
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
							tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12756[Dtype(tr2)-1610]);
							F2046_21545(RTCW(tr1), loc5, loc55, NULL, tr2);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
							loc6 = F1132_10042(RTCW(tr1), loc55, Current);
							F1017_8123(RTCW(loc6), (EIF_BOOLEAN) 1);
							RTAR(Current, loc6);
							*(EIF_REFERENCE *)(Current + _REFACS_34_) = (EIF_REFERENCE) loc6;
						}
					}
				}
				tr1 = RTOUCR(92,F396_4484, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20745(RTCW(loc5), tr1);
				loc58 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc58)) {
					tr1 = RTOUCR(92,F396_4484, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20744(RTCW(loc5), tr1);
					loc59 = tr1;
					if (EIF_TEST(loc59)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21543(RTCW(tr1), loc5, loc59);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(92,F396_4484, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = '\01';
					tr1 = *(EIF_REFERENCE *)(loc58 + _REFACS_5_);
					loc60 = tr1;
					if (!((EIF_BOOLEAN) !EIF_TEST(loc60))) {
						ti4_1 = *(EIF_INTEGER_32 *)(loc60+ _LNGOFF_3_0_0_0_);
						tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 1L));
					}
					if (tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						{
							static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
							RT_SPECIAL_COUNT(tr3) = 1L;
							memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
						}
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12755[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
						F2046_21545(RTCW(tr1), loc5, loc58, tr2, NULL);
					} else {
						tr1 = F1649_16721(loc60, ((EIF_INTEGER_32) 1L));
						tr1 = F1814_17596(RTCW(tr1));
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12755[Dtype(tr2)-1610]);
						tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
						if ((EIF_BOOLEAN) !tb1) {
							F1996_19935(Current);
							tr1 = F1996_19936(Current);
							{
								static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
								RT_SPECIAL_COUNT(tr3) = 1L;
								memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
							}
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12755[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
							F2046_21545(RTCW(tr1), loc5, loc58, tr2, NULL);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
							loc6 = F1132_10043(RTCW(tr1), loc58, Current);
							F1017_8123(RTCW(loc6), (EIF_BOOLEAN) 1);
							RTAR(Current, loc6);
							*(EIF_REFERENCE *)(Current + _REFACS_35_) = (EIF_REFERENCE) loc6;
						}
					}
				}
				tr1 = RTOUCR(93,F396_4538, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
				tr1 = F2027_20745(RTCW(loc5), tr1);
				loc61 = tr1;
				if ((EIF_BOOLEAN) !EIF_TEST(loc61)) {
					tr1 = RTOUCR(93,F396_4538, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
					tr1 = F2027_20744(RTCW(loc5), tr1);
					loc62 = tr1;
					if (EIF_TEST(loc62)) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						F2046_21543(RTCW(tr1), loc5, loc62);
					} else {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						tr2 = RTOUCR(93,F396_4538, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
						F2046_21540(RTCW(tr1), loc5, tr2);
					}
				} else {
					tb1 = '\01';
					tr1 = *(EIF_REFERENCE *)(loc61 + _REFACS_5_);
					loc63 = tr1;
					if (!((EIF_BOOLEAN) !EIF_TEST(loc63))) {
						ti4_1 = *(EIF_INTEGER_32 *)(loc63+ _LNGOFF_3_0_0_0_);
						tb1 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 12L));
					}
					if (tb1) {
						F1996_19935(Current);
						tr1 = F1996_19936(Current);
						{
							static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
							RT_SPECIAL_COUNT(tr3) = 12L;
							memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
						}
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+8) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+9) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+10) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
						tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
						tr4 = F1884_18206(RTCW(tr4));
						*((EIF_REFERENCE *)tr3+11) = (EIF_REFERENCE) tr4;
						RTAR(tr3,tr4);
						tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
						F2046_21545(RTCW(tr1), loc5, loc61, tr2, NULL);
					} else {
						tr1 = F1649_16721(loc63, ((EIF_INTEGER_32) 1L));
						tr1 = F1814_17596(RTCW(tr1));
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
						tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
						tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
						if ((EIF_BOOLEAN) !tb1) {
							F1996_19935(Current);
							tr1 = F1996_19936(Current);
							{
								static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
								RT_SPECIAL_COUNT(tr3) = 12L;
								memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
							}
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+8) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+9) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+10) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
							tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
							tr4 = F1884_18206(RTCW(tr4));
							*((EIF_REFERENCE *)tr3+11) = (EIF_REFERENCE) tr4;
							RTAR(tr3,tr4);
							tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
							F2046_21545(RTCW(tr1), loc5, loc61, tr2, NULL);
						} else {
							tr1 = F1649_16721(loc63, ((EIF_INTEGER_32) 2L));
							tr1 = F1814_17596(RTCW(tr1));
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
							tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
							tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
							tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
							if ((EIF_BOOLEAN) !tb1) {
								F1996_19935(Current);
								tr1 = F1996_19936(Current);
								{
									static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
									EIF_TYPE typres0;
									static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
									
									typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
									tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
									RT_SPECIAL_COUNT(tr3) = 12L;
									memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
								}
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+8) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+9) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+10) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
								tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
								tr4 = F1884_18206(RTCW(tr4));
								*((EIF_REFERENCE *)tr3+11) = (EIF_REFERENCE) tr4;
								RTAR(tr3,tr4);
								tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
								F2046_21545(RTCW(tr1), loc5, loc61, tr2, NULL);
							} else {
								tr1 = F1649_16721(loc63, ((EIF_INTEGER_32) 3L));
								tr1 = F1814_17596(RTCW(tr1));
								tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
								tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
								tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
								tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
								if ((EIF_BOOLEAN) !tb1) {
									F1996_19935(Current);
									tr1 = F1996_19936(Current);
									{
										static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
										EIF_TYPE typres0;
										static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
										
										typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
										tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
										RT_SPECIAL_COUNT(tr3) = 12L;
										memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
									}
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+8) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+9) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+10) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
									tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
									tr4 = F1884_18206(RTCW(tr4));
									*((EIF_REFERENCE *)tr3+11) = (EIF_REFERENCE) tr4;
									RTAR(tr3,tr4);
									tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
									F2046_21545(RTCW(tr1), loc5, loc61, tr2, NULL);
								} else {
									tr1 = F1649_16721(loc63, ((EIF_INTEGER_32) 4L));
									tr1 = F1814_17596(RTCW(tr1));
									tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
									tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
									tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
									tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
									if ((EIF_BOOLEAN) !tb1) {
										F1996_19935(Current);
										tr1 = F1996_19936(Current);
										{
											static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
											EIF_TYPE typres0;
											static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
											
											typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
											tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
											RT_SPECIAL_COUNT(tr3) = 12L;
											memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
										}
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+8) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+9) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+10) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
										tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
										tr4 = F1884_18206(RTCW(tr4));
										*((EIF_REFERENCE *)tr3+11) = (EIF_REFERENCE) tr4;
										RTAR(tr3,tr4);
										tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
										F2046_21545(RTCW(tr1), loc5, loc61, tr2, NULL);
									} else {
										tr1 = F1649_16721(loc63, ((EIF_INTEGER_32) 5L));
										tr1 = F1814_17596(RTCW(tr1));
										tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
										tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
										tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12785[Dtype(tr2)-1610]);
										tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
										if ((EIF_BOOLEAN) !tb1) {
											F1996_19935(Current);
											tr1 = F1996_19936(Current);
											{
												static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
												EIF_TYPE typres0;
												static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
												
												typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
												tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
												RT_SPECIAL_COUNT(tr3) = 12L;
												memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
											}
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+8) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+9) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+10) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
											tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
											tr4 = F1884_18206(RTCW(tr4));
											*((EIF_REFERENCE *)tr3+11) = (EIF_REFERENCE) tr4;
											RTAR(tr3,tr4);
											tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
											F2046_21545(RTCW(tr1), loc5, loc61, tr2, NULL);
										} else {
											tr1 = F1649_16721(loc63, ((EIF_INTEGER_32) 6L));
											tr1 = F1814_17596(RTCW(tr1));
											tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
											tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
											tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12785[Dtype(tr2)-1610]);
											tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
											if ((EIF_BOOLEAN) !tb1) {
												F1996_19935(Current);
												tr1 = F1996_19936(Current);
												{
													static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
													EIF_TYPE typres0;
													static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
													
													typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
													tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
													RT_SPECIAL_COUNT(tr3) = 12L;
													memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
												}
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+8) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+9) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+10) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
												tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
												tr4 = F1884_18206(RTCW(tr4));
												*((EIF_REFERENCE *)tr3+11) = (EIF_REFERENCE) tr4;
												RTAR(tr3,tr4);
												tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
												F2046_21545(RTCW(tr1), loc5, loc61, tr2, NULL);
											} else {
												tr1 = F1649_16721(loc63, ((EIF_INTEGER_32) 7L));
												tr1 = F1814_17596(RTCW(tr1));
												tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
												tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
												tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12785[Dtype(tr2)-1610]);
												tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
												if ((EIF_BOOLEAN) !tb1) {
													F1996_19935(Current);
													tr1 = F1996_19936(Current);
													{
														static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
														EIF_TYPE typres0;
														static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
														
														typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
														tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
														RT_SPECIAL_COUNT(tr3) = 12L;
														memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
													}
													tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
													tr4 = F1884_18206(RTCW(tr4));
													*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
													RTAR(tr3,tr4);
													tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
													tr4 = F1884_18206(RTCW(tr4));
													*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
													RTAR(tr3,tr4);
													tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
													tr4 = F1884_18206(RTCW(tr4));
													*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
													RTAR(tr3,tr4);
													tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
													tr4 = F1884_18206(RTCW(tr4));
													*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
													RTAR(tr3,tr4);
													tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
													tr4 = F1884_18206(RTCW(tr4));
													*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
													RTAR(tr3,tr4);
													tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
													tr4 = F1884_18206(RTCW(tr4));
													*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
													RTAR(tr3,tr4);
													tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
													tr4 = F1884_18206(RTCW(tr4));
													*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
													RTAR(tr3,tr4);
													tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
													tr4 = F1884_18206(RTCW(tr4));
													*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) tr4;
													RTAR(tr3,tr4);
													tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
													tr4 = F1884_18206(RTCW(tr4));
													*((EIF_REFERENCE *)tr3+8) = (EIF_REFERENCE) tr4;
													RTAR(tr3,tr4);
													tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
													tr4 = F1884_18206(RTCW(tr4));
													*((EIF_REFERENCE *)tr3+9) = (EIF_REFERENCE) tr4;
													RTAR(tr3,tr4);
													tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
													tr4 = F1884_18206(RTCW(tr4));
													*((EIF_REFERENCE *)tr3+10) = (EIF_REFERENCE) tr4;
													RTAR(tr3,tr4);
													tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
													tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
													tr4 = F1884_18206(RTCW(tr4));
													*((EIF_REFERENCE *)tr3+11) = (EIF_REFERENCE) tr4;
													RTAR(tr3,tr4);
													tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
													F2046_21545(RTCW(tr1), loc5, loc61, tr2, NULL);
												} else {
													tr1 = F1649_16721(loc63, ((EIF_INTEGER_32) 8L));
													tr1 = F1814_17596(RTCW(tr1));
													tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
													tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
													tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12785[Dtype(tr2)-1610]);
													tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
													if ((EIF_BOOLEAN) !tb1) {
														F1996_19935(Current);
														tr1 = F1996_19936(Current);
														{
															static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
															EIF_TYPE typres0;
															static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
															
															typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
															tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
															RT_SPECIAL_COUNT(tr3) = 12L;
															memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
														}
														tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
														tr4 = F1884_18206(RTCW(tr4));
														*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
														RTAR(tr3,tr4);
														tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
														tr4 = F1884_18206(RTCW(tr4));
														*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
														RTAR(tr3,tr4);
														tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
														tr4 = F1884_18206(RTCW(tr4));
														*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
														RTAR(tr3,tr4);
														tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
														tr4 = F1884_18206(RTCW(tr4));
														*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
														RTAR(tr3,tr4);
														tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
														tr4 = F1884_18206(RTCW(tr4));
														*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
														RTAR(tr3,tr4);
														tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
														tr4 = F1884_18206(RTCW(tr4));
														*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
														RTAR(tr3,tr4);
														tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
														tr4 = F1884_18206(RTCW(tr4));
														*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
														RTAR(tr3,tr4);
														tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
														tr4 = F1884_18206(RTCW(tr4));
														*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) tr4;
														RTAR(tr3,tr4);
														tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
														tr4 = F1884_18206(RTCW(tr4));
														*((EIF_REFERENCE *)tr3+8) = (EIF_REFERENCE) tr4;
														RTAR(tr3,tr4);
														tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
														tr4 = F1884_18206(RTCW(tr4));
														*((EIF_REFERENCE *)tr3+9) = (EIF_REFERENCE) tr4;
														RTAR(tr3,tr4);
														tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
														tr4 = F1884_18206(RTCW(tr4));
														*((EIF_REFERENCE *)tr3+10) = (EIF_REFERENCE) tr4;
														RTAR(tr3,tr4);
														tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
														tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
														tr4 = F1884_18206(RTCW(tr4));
														*((EIF_REFERENCE *)tr3+11) = (EIF_REFERENCE) tr4;
														RTAR(tr3,tr4);
														tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
														F2046_21545(RTCW(tr1), loc5, loc61, tr2, NULL);
													} else {
														tr1 = F1649_16721(loc63, ((EIF_INTEGER_32) 9L));
														tr1 = F1814_17596(RTCW(tr1));
														tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
														tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
														tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12785[Dtype(tr2)-1610]);
														tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
														if ((EIF_BOOLEAN) !tb1) {
															F1996_19935(Current);
															tr1 = F1996_19936(Current);
															{
																static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
																EIF_TYPE typres0;
																static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
																
																typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
																tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
																RT_SPECIAL_COUNT(tr3) = 12L;
																memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
															}
															tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
															tr4 = F1884_18206(RTCW(tr4));
															*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
															RTAR(tr3,tr4);
															tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
															tr4 = F1884_18206(RTCW(tr4));
															*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
															RTAR(tr3,tr4);
															tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
															tr4 = F1884_18206(RTCW(tr4));
															*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
															RTAR(tr3,tr4);
															tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
															tr4 = F1884_18206(RTCW(tr4));
															*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
															RTAR(tr3,tr4);
															tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
															tr4 = F1884_18206(RTCW(tr4));
															*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
															RTAR(tr3,tr4);
															tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
															tr4 = F1884_18206(RTCW(tr4));
															*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
															RTAR(tr3,tr4);
															tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
															tr4 = F1884_18206(RTCW(tr4));
															*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
															RTAR(tr3,tr4);
															tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
															tr4 = F1884_18206(RTCW(tr4));
															*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) tr4;
															RTAR(tr3,tr4);
															tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
															tr4 = F1884_18206(RTCW(tr4));
															*((EIF_REFERENCE *)tr3+8) = (EIF_REFERENCE) tr4;
															RTAR(tr3,tr4);
															tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
															tr4 = F1884_18206(RTCW(tr4));
															*((EIF_REFERENCE *)tr3+9) = (EIF_REFERENCE) tr4;
															RTAR(tr3,tr4);
															tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
															tr4 = F1884_18206(RTCW(tr4));
															*((EIF_REFERENCE *)tr3+10) = (EIF_REFERENCE) tr4;
															RTAR(tr3,tr4);
															tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
															tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
															tr4 = F1884_18206(RTCW(tr4));
															*((EIF_REFERENCE *)tr3+11) = (EIF_REFERENCE) tr4;
															RTAR(tr3,tr4);
															tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
															F2046_21545(RTCW(tr1), loc5, loc61, tr2, NULL);
														} else {
															tr1 = F1649_16721(loc63, ((EIF_INTEGER_32) 10L));
															tr1 = F1814_17596(RTCW(tr1));
															tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
															tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
															tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12785[Dtype(tr2)-1610]);
															tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
															if ((EIF_BOOLEAN) !tb1) {
																F1996_19935(Current);
																tr1 = F1996_19936(Current);
																{
																	static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
																	EIF_TYPE typres0;
																	static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
																	
																	typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
																	tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
																	RT_SPECIAL_COUNT(tr3) = 12L;
																	memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
																}
																tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
																tr4 = F1884_18206(RTCW(tr4));
																*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
																RTAR(tr3,tr4);
																tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
																tr4 = F1884_18206(RTCW(tr4));
																*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
																RTAR(tr3,tr4);
																tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
																tr4 = F1884_18206(RTCW(tr4));
																*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
																RTAR(tr3,tr4);
																tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
																tr4 = F1884_18206(RTCW(tr4));
																*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
																RTAR(tr3,tr4);
																tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																tr4 = F1884_18206(RTCW(tr4));
																*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
																RTAR(tr3,tr4);
																tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																tr4 = F1884_18206(RTCW(tr4));
																*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
																RTAR(tr3,tr4);
																tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																tr4 = F1884_18206(RTCW(tr4));
																*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
																RTAR(tr3,tr4);
																tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																tr4 = F1884_18206(RTCW(tr4));
																*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) tr4;
																RTAR(tr3,tr4);
																tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																tr4 = F1884_18206(RTCW(tr4));
																*((EIF_REFERENCE *)tr3+8) = (EIF_REFERENCE) tr4;
																RTAR(tr3,tr4);
																tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																tr4 = F1884_18206(RTCW(tr4));
																*((EIF_REFERENCE *)tr3+9) = (EIF_REFERENCE) tr4;
																RTAR(tr3,tr4);
																tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
																tr4 = F1884_18206(RTCW(tr4));
																*((EIF_REFERENCE *)tr3+10) = (EIF_REFERENCE) tr4;
																RTAR(tr3,tr4);
																tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
																tr4 = F1884_18206(RTCW(tr4));
																*((EIF_REFERENCE *)tr3+11) = (EIF_REFERENCE) tr4;
																RTAR(tr3,tr4);
																tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
																F2046_21545(RTCW(tr1), loc5, loc61, tr2, NULL);
															} else {
																tr1 = F1649_16721(loc63, ((EIF_INTEGER_32) 11L));
																tr1 = F1814_17596(RTCW(tr1));
																tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
																tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12761[Dtype(tr2)-1610]);
																tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
																if ((EIF_BOOLEAN) !tb1) {
																	F1996_19935(Current);
																	tr1 = F1996_19936(Current);
																	{
																		static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
																		EIF_TYPE typres0;
																		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
																		
																		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
																		tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
																		RT_SPECIAL_COUNT(tr3) = 12L;
																		memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
																	}
																	tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
																	tr4 = F1884_18206(RTCW(tr4));
																	*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
																	RTAR(tr3,tr4);
																	tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
																	tr4 = F1884_18206(RTCW(tr4));
																	*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
																	RTAR(tr3,tr4);
																	tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
																	tr4 = F1884_18206(RTCW(tr4));
																	*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
																	RTAR(tr3,tr4);
																	tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
																	tr4 = F1884_18206(RTCW(tr4));
																	*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
																	RTAR(tr3,tr4);
																	tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																	tr4 = F1884_18206(RTCW(tr4));
																	*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
																	RTAR(tr3,tr4);
																	tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																	tr4 = F1884_18206(RTCW(tr4));
																	*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
																	RTAR(tr3,tr4);
																	tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																	tr4 = F1884_18206(RTCW(tr4));
																	*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
																	RTAR(tr3,tr4);
																	tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																	tr4 = F1884_18206(RTCW(tr4));
																	*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) tr4;
																	RTAR(tr3,tr4);
																	tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																	tr4 = F1884_18206(RTCW(tr4));
																	*((EIF_REFERENCE *)tr3+8) = (EIF_REFERENCE) tr4;
																	RTAR(tr3,tr4);
																	tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																	tr4 = F1884_18206(RTCW(tr4));
																	*((EIF_REFERENCE *)tr3+9) = (EIF_REFERENCE) tr4;
																	RTAR(tr3,tr4);
																	tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
																	tr4 = F1884_18206(RTCW(tr4));
																	*((EIF_REFERENCE *)tr3+10) = (EIF_REFERENCE) tr4;
																	RTAR(tr3,tr4);
																	tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																	tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
																	tr4 = F1884_18206(RTCW(tr4));
																	*((EIF_REFERENCE *)tr3+11) = (EIF_REFERENCE) tr4;
																	RTAR(tr3,tr4);
																	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
																	F2046_21545(RTCW(tr1), loc5, loc61, tr2, NULL);
																} else {
																	tr1 = F1649_16721(loc63, ((EIF_INTEGER_32) 12L));
																	tr1 = F1814_17596(RTCW(tr1));
																	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																	tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O2857[Dtype(tr2)-300]);
																	tr2 = *(EIF_REFERENCE *)(RTCW(tr2) + O12750[Dtype(tr2)-1610]);
																	tb1 = F1884_18234(RTCW(tr1), tr2, loc5, loc5);
																	if ((EIF_BOOLEAN) !tb1) {
																		F1996_19935(Current);
																		tr1 = F1996_19936(Current);
																		{
																			static EIF_TYPE_INDEX typarr0[] = {915,0xFF01,1883,0xFFFF};
																			EIF_TYPE typres0;
																			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
																			
																			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
																			tr3 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 12L),sizeof(EIF_REFERENCE), EIF_FALSE);
																			RT_SPECIAL_COUNT(tr3) = 12L;
																			memset(tr3, 0, RT_SPECIAL_VISIBLE_SIZE(tr3));
																		}
																		tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
																		tr4 = F1884_18206(RTCW(tr4));
																		*((EIF_REFERENCE *)tr3+0) = (EIF_REFERENCE) tr4;
																		RTAR(tr3,tr4);
																		tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
																		tr4 = F1884_18206(RTCW(tr4));
																		*((EIF_REFERENCE *)tr3+1) = (EIF_REFERENCE) tr4;
																		RTAR(tr3,tr4);
																		tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
																		tr4 = F1884_18206(RTCW(tr4));
																		*((EIF_REFERENCE *)tr3+2) = (EIF_REFERENCE) tr4;
																		RTAR(tr3,tr4);
																		tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
																		tr4 = F1884_18206(RTCW(tr4));
																		*((EIF_REFERENCE *)tr3+3) = (EIF_REFERENCE) tr4;
																		RTAR(tr3,tr4);
																		tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																		tr4 = F1884_18206(RTCW(tr4));
																		*((EIF_REFERENCE *)tr3+4) = (EIF_REFERENCE) tr4;
																		RTAR(tr3,tr4);
																		tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																		tr4 = F1884_18206(RTCW(tr4));
																		*((EIF_REFERENCE *)tr3+5) = (EIF_REFERENCE) tr4;
																		RTAR(tr3,tr4);
																		tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																		tr4 = F1884_18206(RTCW(tr4));
																		*((EIF_REFERENCE *)tr3+6) = (EIF_REFERENCE) tr4;
																		RTAR(tr3,tr4);
																		tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																		tr4 = F1884_18206(RTCW(tr4));
																		*((EIF_REFERENCE *)tr3+7) = (EIF_REFERENCE) tr4;
																		RTAR(tr3,tr4);
																		tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																		tr4 = F1884_18206(RTCW(tr4));
																		*((EIF_REFERENCE *)tr3+8) = (EIF_REFERENCE) tr4;
																		RTAR(tr3,tr4);
																		tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12785[Dtype(tr4)-1610]);
																		tr4 = F1884_18206(RTCW(tr4));
																		*((EIF_REFERENCE *)tr3+9) = (EIF_REFERENCE) tr4;
																		RTAR(tr3,tr4);
																		tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12761[Dtype(tr4)-1610]);
																		tr4 = F1884_18206(RTCW(tr4));
																		*((EIF_REFERENCE *)tr3+10) = (EIF_REFERENCE) tr4;
																		RTAR(tr3,tr4);
																		tr4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O2857[Dtype(tr4)-300]);
																		tr4 = *(EIF_REFERENCE *)(RTCW(tr4) + O12750[Dtype(tr4)-1610]);
																		tr4 = F1884_18206(RTCW(tr4));
																		*((EIF_REFERENCE *)tr3+11) = (EIF_REFERENCE) tr4;
																		RTAR(tr3,tr4);
																		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F916_7183)(tr3);
																		F2046_21545(RTCW(tr1), loc5, loc61, tr2, NULL);
																	} else {
																		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
																		loc6 = F1132_10043(RTCW(tr1), loc61, Current);
																		F1017_8123(RTCW(loc6), (EIF_BOOLEAN) 1);
																		RTAR(Current, loc6);
																		*(EIF_REFERENCE *)(Current + _REFACS_36_) = (EIF_REFERENCE) loc6;
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12740[Dtype(tr1)-1610]);
		tr1 = F1996_19897(Current, tr1, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + O12774[Dtype(tr1)-1610]);
		tr1 = F1996_19897(Current, tr1, loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.compile_all_features */
void F1996_19932 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,loc6);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc5);
	RTLR(6,loc3);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTGC;
	tb1 = '\0';
	tb2 = F2027_20801(RTCW(arg1));
	if (tb2) {
		tb2 = F2027_20803(RTCW(arg1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tb1 = '\0';
		tb2 = F2027_20672(RTCW(arg1));
		if ((EIF_BOOLEAN) !tb2) {
			tb2 = F2024_20445(RTCW(arg1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			loc6 = F1996_19897(Current, arg1, arg1);
			loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_25_);
			loc8 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_0_0_1_);
			loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc7 > loc8)) break;
				loc2 = F1006_7636(RTCW(loc1), loc7);
				loc5 = F1132_10042(RTCW(loc6), loc2, Current);
				loc7++;
			}
			loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_26_);
			loc8 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_0_0_1_);
			loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc7 > loc8)) break;
				loc4 = F1007_7638(RTCW(loc3), loc7);
				loc5 = F1132_10043(RTCW(loc6), loc4, Current);
				loc7++;
			}
		}
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.build_dynamic_type_sets */
void F1996_19933 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tb1 = F1290_12786(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		F268_2952(RTCW(loc1), (EIF_BOOLEAN) 1);
		F268_2953(RTCW(loc1), (EIF_BOOLEAN) 1);
		F268_2950(RTCW(loc1), *(EIF_BOOLEAN *)(Current+ _CHROFF_50_0_));
		F268_2951(RTCW(loc1), *(EIF_BOOLEAN *)(Current+ _CHROFF_50_1_));
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R2559[Dtype(RTCW(loc1))-268])(loc1);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1) + O2547[Dtype(loc1)-267]);
		if (tb1) {
			F1996_19935(Current);
		}
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.set_fatal_error */
void F1996_19935 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_50_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {ET_DYNAMIC_SYSTEM}.error_handler */
EIF_REFERENCE F1996_19936 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_12_);
	RTLE;
	return Result;
}

/* {ET_DYNAMIC_SYSTEM}.activate_dynamic_type_set_builder */
void F1996_19939 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_31_) == *(EIF_REFERENCE *)(Current + _REFACS_32_))) {
		tr1 = RTLNS(eif_new_type(1245, 0x01).id, 1245, _OBJSIZ_45_14_0_7_0_0_0_0_);
		F1245_11658(RTCW(tr1), Current, arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_31_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		F268_2950(RTCW(tr1), *(EIF_BOOLEAN *)(Current+ _CHROFF_50_0_));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		F268_2951(RTCW(tr1), *(EIF_BOOLEAN *)(Current+ _CHROFF_50_1_));
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.set_dynamic_type_set_builder */
void F1996_19940 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_31_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
	F268_2950(RTCW(tr1), *(EIF_BOOLEAN *)(Current+ _CHROFF_50_0_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
	F268_2951(RTCW(tr1), *(EIF_BOOLEAN *)(Current+ _CHROFF_50_1_));
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.set_ise_runtime_new_type_instance_of_feature */
void F1996_19949 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
		loc2 = F1541_13846(RTCW(tr1), loc1);
		F1996_19918(Current, loc2);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_1_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			F1996_19918(Current, loc3);
		}
		loc1--;
	}
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.set_ise_runtime_reference_field_feature */
void F1996_19950 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc8);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc5);
	RTLR(6,tr1);
	RTLIU(7);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_38_) = (EIF_REFERENCE) arg1;
	loc8 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_4_0_0_1_);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc3 > loc4)) break;
		loc2 = F1541_13846(RTCW(loc1), loc3);
		loc7 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O8151[Dtype(loc2)-1131]);
		loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc6 > loc7)) break;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_3_);
			loc5 = F899_7044(RTCW(tr1), loc6);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2569[Dtype(RTCW(loc8))-268])(loc8, loc5);
			loc6++;
		}
		loc3++;
	}
	F1996_19871(Current);
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.set_ise_runtime_set_reference_field_feature */
void F1996_19951 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc8);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc5);
	RTLR(6,tr1);
	RTLIU(7);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_39_) = (EIF_REFERENCE) arg1;
	loc8 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_4_0_0_1_);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc3 > loc4)) break;
		loc2 = F1541_13846(RTCW(loc1), loc3);
		loc7 = *(EIF_INTEGER_32 *)(RTCW(loc2) + O8151[Dtype(loc2)-1131]);
		loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc6 > loc7)) break;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_3_);
			loc5 = F899_7044(RTCW(tr1), loc6);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2570[Dtype(RTCW(loc8))-268])(loc8, loc5);
			loc6++;
		}
		loc3++;
	}
	F1996_19871(Current);
	RTLE;
}

/* {ET_DYNAMIC_SYSTEM}.set_ise_runtime_type_conforms_to_feature */
void F1996_19952 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_40_) = (EIF_REFERENCE) arg1;
}

/* {ET_DYNAMIC_SYSTEM}.alive_dynamic_type_count */
EIF_INTEGER_32 F1996_19962 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
		tr1 = F1541_13846(RTCW(tr1), loc1);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O8136[Dtype(tr1)-1131]);
		if (tb1) {
			Result++;
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {ET_DYNAMIC_SYSTEM}.dynamic_feature_count */
EIF_INTEGER_32 F1996_19963 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
		tr1 = F1541_13846(RTCW(tr1), loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_0_);
		Result += ti4_1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
		tr1 = F1541_13846(RTCW(tr1), loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_0_);
		Result += ti4_1;
		loc1++;
	}
	RTLE;
	return Result;
}

/* {ET_DYNAMIC_SYSTEM}.empty_dynamic_type_sets */
static EIF_REFERENCE F1996_19964_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(76)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(909, 0x01).id, 909, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F899_7042(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1996_19964 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(76,F1996_19964_body,(Current));
}

/* {ET_DYNAMIC_SYSTEM}.type_name_buffer */
static EIF_REFERENCE F1996_19965_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(74)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1184, 0x01).id, 1184, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1183_10471(RTCW(tr1), ((EIF_INTEGER_32) 200L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1996_19965 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(74,F1996_19965_body,(Current));
}

void EIF_Minit1044 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
