/*
 * Code for class ET_IDENTIFIER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1035.h"
#include "eif_built_in.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_IDENTIFIER}.make */
void F1987_19652 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = F1987_19695(Current, arg1);
	F1987_19653(Current, arg1, ti4_1);
	RTLE;
}

/* {ET_IDENTIFIER}.make_with_hash_code */
void F1987_19653 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) = (EIF_INTEGER_32) arg2;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	F1286_12617(Current);
	RTLE;
}

/* {ET_IDENTIFIER}.reset */
void F1987_19654 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN) !F1987_19663(Current)) {
		tb1 = (EIF_BOOLEAN) !F1987_19667(Current);
	}
	if (tb1) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		if (F1987_19668(Current)) {
			F1987_19675(Current, (EIF_BOOLEAN) 1);
		}
	}
	RTLE;
}

/* {ET_IDENTIFIER}.lower_name */
EIF_REFERENCE F1987_19655 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5908[Dtype(RTCW(Result))-829])(Result, loc1));
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 >= (EIF_CHARACTER_8) 'A') && (EIF_BOOLEAN) (loc3 <= (EIF_CHARACTER_8) 'Z'))) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8324[Dtype(RTCW(Result))-1180])(Result);
			Result = (EIF_REFERENCE) tr1;
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		} else {
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {ET_IDENTIFIER}.upper_name */
EIF_REFERENCE F1987_19656 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5908[Dtype(RTCW(Result))-829])(Result, loc1));
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 >= (EIF_CHARACTER_8) 'a') && (EIF_BOOLEAN) (loc3 <= (EIF_CHARACTER_8) 'z'))) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8325[Dtype(RTCW(Result))-1184])(Result);
			Result = (EIF_REFERENCE) tr1;
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		} else {
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {ET_IDENTIFIER}.arguments */
EIF_REFERENCE F1987_19657 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {ET_IDENTIFIER}.hash_code */
EIF_INTEGER_32 F1987_19658 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_);
}


/* {ET_IDENTIFIER}.identifier */
EIF_REFERENCE F1987_19659 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

/* {ET_IDENTIFIER}.indexing_term_value */
EIF_REFERENCE F1987_19660 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_1_);
}

/* {ET_IDENTIFIER}.is_feature_name */
EIF_BOOLEAN F1987_19662 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) == (EIF_CHARACTER_8) 'f');
}

/* {ET_IDENTIFIER}.is_local */
EIF_BOOLEAN F1987_19663 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) == (EIF_CHARACTER_8) 'l');
}

/* {ET_IDENTIFIER}.is_object_test_local */
EIF_BOOLEAN F1987_19664 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) == (EIF_CHARACTER_8) 'm');
}

/* {ET_IDENTIFIER}.is_iteration_cursor */
EIF_BOOLEAN F1987_19665 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) == (EIF_CHARACTER_8) 'i');
}

/* {ET_IDENTIFIER}.is_temporary */
EIF_BOOLEAN F1987_19666 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) == (EIF_CHARACTER_8) 'v');
}

/* {ET_IDENTIFIER}.is_argument */
EIF_BOOLEAN F1987_19667 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) == (EIF_CHARACTER_8) 'a');
}

/* {ET_IDENTIFIER}.is_tuple_label */
EIF_BOOLEAN F1987_19668 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) == (EIF_CHARACTER_8) 't');
}

/* {ET_IDENTIFIER}.is_agent_open_operand */
EIF_BOOLEAN F1987_19669 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) == (EIF_CHARACTER_8) 'o');
}

/* {ET_IDENTIFIER}.is_agent_closed_operand */
EIF_BOOLEAN F1987_19670 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) == (EIF_CHARACTER_8) 'c');
}

/* {ET_IDENTIFIER}.is_never_void */
EIF_BOOLEAN F1987_19671 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F1987_19664(Current);
}

/* {ET_IDENTIFIER}.is_instance_free */
EIF_BOOLEAN F1987_19672 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) != (EIF_CHARACTER_8) '\000')) {
		tb1 = (EIF_BOOLEAN) !F1987_19662(Current);
	}
	if (tb1) {
		Result = (EIF_BOOLEAN) !F1987_19668(Current);
	}
	RTLE;
	return Result;
}

/* {ET_IDENTIFIER}.has_indexing_term_value */
EIF_BOOLEAN F1987_19673 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(10,F1207_10828, (Current));
	Result = F1198_10706(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), arg1);
	RTLE;
	return Result;
}

/* {ET_IDENTIFIER}.set_feature_name */
void F1987_19675 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (arg1) {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'f';
	} else {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
	}
	RTLE;
}

/* {ET_IDENTIFIER}.set_local */
void F1987_19676 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (arg1) {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'l';
	} else {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
	}
	RTLE;
}

/* {ET_IDENTIFIER}.set_object_test_local */
void F1987_19677 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (arg1) {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'm';
	} else {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
	}
	RTLE;
}

/* {ET_IDENTIFIER}.set_iteration_cursor */
void F1987_19678 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (arg1) {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'i';
	} else {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
	}
	RTLE;
}

/* {ET_IDENTIFIER}.set_temporary */
void F1987_19679 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (arg1) {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'v';
	} else {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
	}
	RTLE;
}

/* {ET_IDENTIFIER}.set_argument */
void F1987_19680 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (arg1) {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'a';
	} else {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
	}
	RTLE;
}

/* {ET_IDENTIFIER}.set_tuple_label */
void F1987_19681 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (arg1) {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 't';
	} else {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
	}
	RTLE;
}

/* {ET_IDENTIFIER}.set_agent_open_operand */
void F1987_19682 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (arg1) {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'o';
	} else {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
	}
	RTLE;
}

/* {ET_IDENTIFIER}.set_agent_closed_operand */
void F1987_19683 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (arg1) {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) 'c';
	} else {
		*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
	}
	RTLE;
}

/* {ET_IDENTIFIER}.same_call_name */
EIF_BOOLEAN F1987_19685 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		loc2 = arg1;
		loc2 = RTRV(eif_new_type(1986, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_1_0_3_);
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) == ti4_1)) {
				loc1 = *(EIF_REFERENCE *)(loc2 + _REFACS_1_);
				if ((EIF_BOOLEAN)(loc1 == *(EIF_REFERENCE *)(Current + _REFACS_1_))) {
					RTLE;
					return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tr1 = RTOUCR(10,F1207_10828, (Current));
					Result = F1198_10706(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), loc1);
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_IDENTIFIER}.same_feature_name */
EIF_BOOLEAN F1987_19686 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		loc2 = arg1;
		loc2 = RTRV(eif_new_type(1986, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_1_0_3_);
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) == ti4_1)) {
				loc1 = *(EIF_REFERENCE *)(loc2 + _REFACS_1_);
				if ((EIF_BOOLEAN)(loc1 == *(EIF_REFERENCE *)(Current + _REFACS_1_))) {
					RTLE;
					return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tr1 = RTOUCR(10,F1207_10828, (Current));
					Result = F1198_10706(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), loc1);
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_IDENTIFIER}.same_class_name */
EIF_BOOLEAN F1987_19687 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		loc2 = arg1;
		loc2 = RTRV(eif_new_type(1986, 0x01),loc2);
		if (EIF_TEST(loc2)) {
			ti4_1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_2_1_0_3_);
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) == ti4_1)) {
				loc1 = *(EIF_REFERENCE *)(loc2 + _REFACS_1_);
				if ((EIF_BOOLEAN)(loc1 == *(EIF_REFERENCE *)(Current + _REFACS_1_))) {
					RTLE;
					return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tr1 = RTOUCR(10,F1207_10828, (Current));
					Result = F1198_10706(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), loc1);
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_IDENTIFIER}.same_identifier */
EIF_BOOLEAN F1987_19688 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_1_0_3_);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_3_) == ti4_1)) {
			loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			if ((EIF_BOOLEAN)(loc1 == *(EIF_REFERENCE *)(Current + _REFACS_1_))) {
				RTLE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				tr1 = RTOUCR(10,F1207_10828, (Current));
				Result = F1198_10706(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), loc1);
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_IDENTIFIER}.is_equal */
EIF_BOOLEAN F1987_19689 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOUCR(556,F1187_10637, (Current));
	tb1 = F46_577(RTCW(tr1), Current, arg1);
	if (tb1) {
		RTLE;
		return (EIF_BOOLEAN) F1987_19688(Current, arg1);
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {ET_IDENTIFIER}.local_name */
EIF_REFERENCE F1987_19690 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

/* {ET_IDENTIFIER}.argument_name */
EIF_REFERENCE F1987_19691 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

/* {ET_IDENTIFIER}.object_test_local_name */
EIF_REFERENCE F1987_19692 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

/* {ET_IDENTIFIER}.iteration_cursor_name */
EIF_REFERENCE F1987_19693 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

/* {ET_IDENTIFIER}.process */
void F1987_19694 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2380[Dtype(RTCW(arg1))-258])(arg1, Current);
}

/* {ET_IDENTIFIER}.new_hash_code */
EIF_INTEGER_32 F1987_19695 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		ti4_1 = eif_bit_shift_left((EIF_INTEGER_32) (Result % ((EIF_INTEGER_32) 8388593L)),((EIF_INTEGER_32) 8L));
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5908[Dtype(RTCW(arg1))-829])(arg1, loc1));
		tc1 = eif_builtin_CHARACTER_8_as_upper__c1_c1(tc1);
		ti4_2 = (EIF_INTEGER_32) (tc1);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 + ti4_2);
		loc1++;
	}
	if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) -(EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	}
	RTLE;
	return Result;
}

void EIF_Minit1035 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
