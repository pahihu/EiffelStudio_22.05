/*
 * Code for class RX_CASE_MAPPING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "rx1037.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RX_CASE_MAPPING}.make_default */
void F1989_19718 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOUCR(2854,F460_6139, (Current));
	tr1 = F29_281(RTCW(tr1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 256L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(2854,F460_6139, (Current));
	tr1 = F29_281(RTCW(tr1), (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 256L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F1989_19723(Current);
	RTLE;
}

/* {RX_CASE_MAPPING}.make */
void F1989_19719 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	F1989_19718(Current);
	F1989_19724(Current, arg1, arg2);
	RTLE;
}

/* {RX_CASE_MAPPING}.to_lower */
EIF_NATURAL_32 F1989_19720 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 256L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = (EIF_INTEGER_32) arg1;
		/* INLINED CODE (SPECIAL.item) */
		tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (ti4_1));
		/* END INLINED CODE */
		Result = tu4_2;
	} else {
		RTLE;
		return (EIF_NATURAL_32) arg1;
	}
	RTLE;
	return Result;
}

/* {RX_CASE_MAPPING}.flip_case */
EIF_NATURAL_32 F1989_19722 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 < (EIF_NATURAL_32) ((EIF_INTEGER_32) 256L))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = (EIF_INTEGER_32) arg1;
		/* INLINED CODE (SPECIAL.item) */
		tu4_2 = *((EIF_NATURAL_32 *)RTCW(tr1) + (ti4_1));
		/* END INLINED CODE */
		Result = tu4_2;
	} else {
		RTLE;
		return (EIF_NATURAL_32) arg1;
	}
	RTLE;
	return Result;
}

/* {RX_CASE_MAPPING}.clear */
void F1989_19723 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 255L))) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		tu4_1 = (EIF_NATURAL_32) loc1;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_32 *)RTCW(tr1) + (loc1)) = tu4_1;
		/* END INLINED CODE */
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tu4_1 = (EIF_NATURAL_32) loc1;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_32 *)RTCW(tr1) + (loc1)) = tu4_1;
		/* END INLINED CODE */
		;
		loc1++;
	}
	RTLE;
}

/* {RX_CASE_MAPPING}.add */
void F1989_19724 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc4 = (EIF_CHARACTER_8) 0;
	EIF_NATURAL_32 loc5 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc6 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5908[Dtype(RTCW(arg2))-829])(arg2, loc1));
		loc4 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R5908[Dtype(RTCW(arg1))-829])(arg1, loc1));
		loc5 = (EIF_NATURAL_32) loc3;
		loc6 = (EIF_NATURAL_32) loc4;
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = (EIF_INTEGER_32) loc6;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_32 *)RTCW(tr1) + (ti4_1)) = loc5;
		/* END INLINED CODE */
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = (EIF_INTEGER_32) loc6;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_32 *)RTCW(tr1) + (ti4_1)) = loc5;
		/* END INLINED CODE */
		;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = (EIF_INTEGER_32) loc5;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_NATURAL_32 *)RTCW(tr1) + (ti4_1)) = loc6;
		/* END INLINED CODE */
		;
		loc1++;
	}
	RTLE;
}

void EIF_Minit1037 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
