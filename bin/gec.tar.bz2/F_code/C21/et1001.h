
#ifndef _C21_et1001_
#define _C21_et1001_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1953_19389(EIF_REFERENCE);
extern void EIF_Minit1001(void);
extern char *(*R14495[])();

#ifdef __cplusplus
}
#endif

#endif
