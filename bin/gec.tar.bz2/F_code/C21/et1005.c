/*
 * Code for class ET_SYMBOL_OPERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1005.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_SYMBOL_OPERATOR}.is_infix_div */
EIF_BOOLEAN F1957_19430 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'G';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_divide */
EIF_BOOLEAN F1957_19431 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'H';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_ge */
EIF_BOOLEAN F1957_19432 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'I';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_gt */
EIF_BOOLEAN F1957_19433 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'J';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_le */
EIF_BOOLEAN F1957_19434 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'K';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_lt */
EIF_BOOLEAN F1957_19435 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'L';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_minus */
EIF_BOOLEAN F1957_19436 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'M';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_mod */
EIF_BOOLEAN F1957_19437 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'N';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_plus */
EIF_BOOLEAN F1957_19438 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'O';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_power */
EIF_BOOLEAN F1957_19439 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'P';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_times */
EIF_BOOLEAN F1957_19440 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'Q';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_infix_dotdot */
EIF_BOOLEAN F1957_19441 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) 'S';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_prefix_minus */
EIF_BOOLEAN F1957_19443 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) '\\';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.is_prefix_plus */
EIF_BOOLEAN F1957_19444 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	tc2 = (EIF_CHARACTER_8) ']';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.name */
EIF_REFERENCE F1957_19445 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	switch (*(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_)) {
		case (EIF_CHARACTER_8) 'G':
			Result = RTOUCR(1650,F396_5234, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'H':
			Result = RTOUCR(1651,F396_5235, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'I':
			Result = RTOUCR(1652,F396_5236, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'J':
			Result = RTOUCR(1653,F396_5237, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'K':
			Result = RTOUCR(1655,F396_5238, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'L':
			Result = RTOUCR(1656,F396_5239, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'M':
			Result = RTOUCR(1657,F396_5240, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'N':
			Result = RTOUCR(1658,F396_5241, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'O':
			Result = RTOUCR(1661,F396_5242, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'P':
			Result = RTOUCR(1662,F396_5243, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'Q':
			Result = RTOUCR(1663,F396_5244, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'S':
			Result = RTOUCR(1665,F396_5245, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		case (EIF_CHARACTER_8) '\\':
			Result = RTOUCR(1657,F396_5240, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		case (EIF_CHARACTER_8) ']':
			Result = RTOUCR(1661,F396_5242, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		default:
			Result = RTOUCR(1667,F396_5209, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
	}
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.hash_code */
EIF_INTEGER_32 F1957_19446 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_);
	Result = (EIF_INTEGER_32) (tc1);
	RTLE;
	return Result;
}

/* {ET_SYMBOL_OPERATOR}.set_infix_minus */
void F1957_19447 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) 'M';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_SYMBOL_OPERATOR}.set_prefix_minus */
void F1957_19448 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '\\';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_SYMBOL_OPERATOR}.set_infix_plus */
void F1957_19449 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) 'O';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_SYMBOL_OPERATOR}.set_prefix_plus */
void F1957_19450 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) ']';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_1_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

void EIF_Minit1005 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
