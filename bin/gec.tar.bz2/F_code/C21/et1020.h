
#ifndef _C21_et1020_
#define _C21_et1020_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1972_19566(EIF_REFERENCE);
extern EIF_REFERENCE F1972_19568(EIF_REFERENCE);
extern EIF_REFERENCE F1972_19569(EIF_REFERENCE);
extern void EIF_Minit1020(void);
extern char *(*R13374[])();
extern char *(*R13662[])();
extern char *(*R13552[])();
extern char *(*R13233[])();

#ifdef __cplusplus
}
#endif

#endif
