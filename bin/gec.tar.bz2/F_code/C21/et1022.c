/*
 * Code for class ET_BANG_INSTRUCTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1022.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_BANG_INSTRUCTION}.make */
void F1974_19581 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg3;
	tr1 = RTOUCR(774,F396_4628, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(774,F396_4628, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {ET_BANG_INSTRUCTION}.type */
EIF_REFERENCE F1974_19583 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_4_);
}


/* {ET_BANG_INSTRUCTION}.position */
EIF_REFERENCE F1974_19585 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F1914_18794(RTCW(tr1));
	tb1 = F1285_12606(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		Result = F1914_18794(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13062[Dtype(loc1)-1627])(loc1);
			RTLE;
			return (EIF_REFERENCE) Result;
		} else {
			tr1 = *(EIF_REFERENCE *)(Current);
			Result = F1914_18794(RTCW(tr1));
		}
	}
	RTLE;
	return Result;
}

/* {ET_BANG_INSTRUCTION}.last_leaf */
EIF_REFERENCE F1974_19587 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1785_17459(loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = F1914_18797(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {ET_BANG_INSTRUCTION}.set_left_bang */
void F1974_19588 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {ET_BANG_INSTRUCTION}.process */
void F1974_19590 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2294[Dtype(RTCW(arg1))-258])(arg1, Current);
}

void EIF_Minit1022 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
