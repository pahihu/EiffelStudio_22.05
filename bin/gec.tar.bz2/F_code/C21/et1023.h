
#ifndef _C21_et1023_
#define _C21_et1023_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1975_19591(EIF_REFERENCE);
extern void EIF_Minit1023(void);
extern void F1868_18009(EIF_REFERENCE);
extern void F1648_16707(EIF_REFERENCE);
extern char *(*R13224[])();
extern char *(*R13228[])();

#ifdef __cplusplus
}
#endif

#endif
