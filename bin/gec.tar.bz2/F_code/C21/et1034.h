
#ifndef _C21_et1034_
#define _C21_et1034_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1986_19648(EIF_REFERENCE);
extern void EIF_Minit1034(void);

#ifdef __cplusplus
}
#endif

#endif
