/*
 * Code for class XM_DTD_EXTERNAL_ID
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm1036.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_DTD_EXTERNAL_ID}.make */
void F1988_19708 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {XM_DTD_EXTERNAL_ID}.hash_code */
EIF_INTEGER_32 F1988_19713 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7255[Dtype(loc1)-1052])(loc1);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result / ((EIF_INTEGER_32) 3L));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R7255[Dtype(loc2)-1052])(loc2);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + (EIF_INTEGER_32) (ti4_1 / ((EIF_INTEGER_32) 3L)));
	}
	RTLE;
	return Result;
}

/* {XM_DTD_EXTERNAL_ID}.set_system */
void F1988_19715 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {XM_DTD_EXTERNAL_ID}.set_public */
void F1988_19716 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {XM_DTD_EXTERNAL_ID}.out */
EIF_REFERENCE F1988_19717 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = RTOUCR(10,F1207_10828, (Current));
		tr2 = RTMS_EX_H("PUBLIC ",7,910695456);
		Result = F1198_10712(RTCW(tr1), tr2);
		tr1 = RTOUCR(10,F1207_10828, (Current));
		tr1 = F1198_10713(RTCW(tr1), Result, loc1);
		Result = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(Result))-1184])(Result, (EIF_CHARACTER_8) ' ');
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr1 = F1198_10713(RTCW(tr1), Result, loc2);
			Result = (EIF_REFERENCE) tr1;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(Result))-1184])(Result, (EIF_CHARACTER_8) ' ');
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr2 = RTMS_EX_H("SYSTEM",6,1561899853);
			Result = F1198_10712(RTCW(tr1), tr2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(Result))-1184])(Result, (EIF_CHARACTER_8) ' ');
			tr1 = RTOUCR(10,F1207_10828, (Current));
			tr1 = F1198_10713(RTCW(tr1), Result, loc3);
			Result = (EIF_REFERENCE) tr1;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(Result))-1184])(Result, (EIF_CHARACTER_8) ' ');
		} else {
			Result = RTMS_EX_H("",0,0);
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit1036 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
