
#ifndef _C21_et1019_
#define _C21_et1019_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1971_19565(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1019(void);
extern char *(*R2461[])();

#ifdef __cplusplus
}
#endif

#endif
