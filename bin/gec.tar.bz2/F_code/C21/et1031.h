
#ifndef _C21_et1031_
#define _C21_et1031_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1983_19624(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1031(void);
extern char *(*R2435[])();

#ifdef __cplusplus
}
#endif

#endif
