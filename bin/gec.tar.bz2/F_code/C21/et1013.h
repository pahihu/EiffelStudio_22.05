
#ifndef _C21_et1013_
#define _C21_et1013_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1965_19515(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1965_19516(EIF_REFERENCE);
extern EIF_REFERENCE F1965_19518(EIF_REFERENCE);
extern EIF_REFERENCE F1965_19523(EIF_REFERENCE);
extern EIF_REFERENCE F1965_19525(EIF_REFERENCE);
extern void F1965_19526(EIF_REFERENCE, EIF_REFERENCE);
extern void F1965_19527(EIF_REFERENCE, EIF_REFERENCE);
extern void F1965_19529(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1013(void);
extern EIF_REFERENCE F1008_7640(EIF_REFERENCE);
extern EIF_REFERENCE F396_4675(EIF_REFERENCE);
extern void F1640_16625(EIF_REFERENCE);
extern void F1648_16707(EIF_REFERENCE);
extern char *(*R13062[])();
extern char *(*R13279[])();
extern char *(*R2384[])();
extern char *(*R13233[])();

#ifdef __cplusplus
}
#endif

#endif
