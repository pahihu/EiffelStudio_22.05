/*
 * Code for class ET_FREE_OPERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1006.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_FREE_OPERATOR}.make_prefix */
void F1958_19454 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '^';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	F1922_18913(Current, arg1);
	tr1 = RTOUCR(10,F1207_10828, (Current));
	ti4_1 = F1198_10702(RTCW(tr1), arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {ET_FREE_OPERATOR}.is_infix_freeop */
EIF_BOOLEAN F1958_19458 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) 'R';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_FREE_OPERATOR}.name */
EIF_REFERENCE F1958_19459 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(1184, 0x01).id, 1184, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	F1183_10471(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 8L)));
	tr1 = RTOUCR(2915,F1958_19464, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8527[Dtype(RTCW(Result))-1184])(Result, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8527[Dtype(RTCW(Result))-1184])(Result, *(EIF_REFERENCE *)(Current + _REFACS_1_));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R8529[Dtype(RTCW(Result))-1184])(Result, (EIF_CHARACTER_8) '\"');
	RTLE;
	return Result;
}

/* {ET_FREE_OPERATOR}.set_infix */
void F1958_19460 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) 'R';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_FREE_OPERATOR}.set_prefix */
void F1958_19461 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = (EIF_CHARACTER_8) '^';
	*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_) = (EIF_CHARACTER_8) tc1;
	RTLE;
}

/* {ET_FREE_OPERATOR}.alias_double_quote */

EIF_REFERENCE F1958_19464 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2915,RTMS_EX_H("alias \"",7,1277740834));
}

void EIF_Minit1006 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
