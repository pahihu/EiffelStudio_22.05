
#ifndef _C21_et1008_
#define _C21_et1008_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1960_19468(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1960_19469(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1008(void);
extern void F1797_17497(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2464[])();
extern EIF_TYPE_INDEX Y13559[];
extern EIF_TYPE_INDEX *Y13559_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
