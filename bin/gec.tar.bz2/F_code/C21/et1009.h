
#ifndef _C21_et1009_
#define _C21_et1009_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1961_19471(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1961_19472(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1009(void);
extern void F1797_17497(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2441[])();
extern EIF_TYPE_INDEX Y13544[];
extern EIF_TYPE_INDEX *Y13544_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
