
#ifndef _C21_et1029_
#define _C21_et1029_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1981_19621(EIF_REFERENCE);
extern void F1981_19622(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1029(void);
extern void F1794_17487(EIF_REFERENCE);
extern char *(*R2483[])();

#ifdef __cplusplus
}
#endif

#endif
