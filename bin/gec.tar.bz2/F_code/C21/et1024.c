/*
 * Code for class ET_REPEAT_INSTRUCTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1024.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_REPEAT_INSTRUCTION}.make */
void F1976_19592 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOUCR(744,F396_4644, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tr1 = RTOUCR(737,F396_4631, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	tr1 = RTOUCR(735,F396_4629, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) arg3;
	tr1 = RTOUCR(736,F396_4630, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	F1868_18022(Current);
	RTLE;
}

/* {ET_REPEAT_INSTRUCTION}.has_item_cursor */
EIF_BOOLEAN F1976_19593 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {ET_REPEAT_INSTRUCTION}.loop_compound */
EIF_REFERENCE F1976_19597 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_11_);
}


/* {ET_REPEAT_INSTRUCTION}.from_compound */
EIF_REFERENCE F1976_19599 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {ET_REPEAT_INSTRUCTION}.invariant_part */
EIF_REFERENCE F1976_19600 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {ET_REPEAT_INSTRUCTION}.variant_part */
EIF_REFERENCE F1976_19601 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {ET_REPEAT_INSTRUCTION}.until_conditional */
EIF_REFERENCE F1976_19602 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

/* {ET_REPEAT_INSTRUCTION}.position */
EIF_REFERENCE F1976_19603 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr1 = F1914_18794(RTCW(tr1));
	tb1 = F1285_12606(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		Result = F1914_18794(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1914_18794(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {ET_REPEAT_INSTRUCTION}.last_leaf */
EIF_REFERENCE F1976_19605 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_10_);
}

/* {ET_REPEAT_INSTRUCTION}.set_loop_compound */
void F1976_19609 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_11_) = (EIF_REFERENCE) arg1;
}

/* {ET_REPEAT_INSTRUCTION}.set_close_repeat_symbol */
void F1976_19610 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) arg1;
}

/* {ET_REPEAT_INSTRUCTION}.process */
void F1976_19611 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2457[Dtype(RTCW(arg1))-258])(arg1, Current);
}

void EIF_Minit1024 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
