
#ifndef _C21_et1027_
#define _C21_et1027_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1979_19619(EIF_REFERENCE);
extern void F1979_19620(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1027(void);
extern void F1797_17497(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern long O14694[];

#ifdef __cplusplus
}
#endif

#endif
