/*
 * Code for class ET_CALL_INSTRUCTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1027.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_CALL_INSTRUCTION}.parenthesis_call */
EIF_REFERENCE F1979_19619 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O14694[Dtype(Current)-1978]);
}


/* {ET_CALL_INSTRUCTION}.set_parenthesis_call */
void F1979_19620 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(1982, 0).id);
	F1797_17497(RTCW(tr1), arg1, arg2, arg3);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O14694[Dtype(Current)-1978]) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit1027 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
