/*
 * Code for class ET_ECF_CAPABILITIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1043.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ECF_CAPABILITIES}.make */
void F1995_19843 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,1986,0xFF01,1184,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1553_14024(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTOUCR(99,F999_7548, (Current));
	F1553_14042(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,146,0xFF01,1184,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 146, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1085,0xFF01,1197,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	tr2 = RTOUCR(10,F1207_10828, (Current));
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
	RTAR(tr1,tr2);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1174,0xFF01,0xFFF9,1,1085,0xFF01,1184,1091,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A509_52_2, (EIF_POINTER) _A509_52_2, (EIF_POINTER)(F1198_10702),tr1, 1, 1);
	}
	F147_1523(RTCW(loc1), tr4);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1569_14103(RTCW(tr1), loc1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,1184,0xFF01,1184,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1553_14024(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr2 = RTOUCR(99,F999_7548, (Current));
	F1553_14042(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1569_14103(RTCW(tr1), loc1);
	RTLE;
}

/* {ET_ECF_CAPABILITIES}.is_capability_supported */
EIF_BOOLEAN F1995_19844 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,loc1);
	RTLIU(6);
	
	RTGC;
	tr1 = F1995_19846(Current, arg1);
	loc3 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc3)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		tr1 = RTOUCR(10,F1207_10828, (Current));
		tb1 = F1198_10706(RTCW(tr1), loc3, arg2);
		if (tb1) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			tr1 = RTOUCR(100,F1995_19857, (Current));
			F1553_14040(RTCW(tr1), arg1);
			tb1 = F1545_13939(RTCV(RTOUCR(100,F1995_19857, (Current))));
			if (tb1) {
				loc1 = F1545_13931(RTCV(RTOUCR(100,F1995_19857, (Current))));
				F1554_14040(RTCW(loc1), arg2);
				tb1 = F1546_13939(RTCW(loc1));
				if (tb1) {
					loc2 = F1546_13931(RTCW(loc1));
					F1554_14040(RTCW(loc1), loc3);
					tb1 = F1546_13939(RTCW(loc1));
					if (tb1) {
						ti4_1 = F1546_13931(RTCW(loc1));
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN) (loc2 <= ti4_1);
					}
				}
			} else {
				RTLE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_ECF_CAPABILITIES}.use_value */
EIF_REFERENCE F1995_19845 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F1553_14040(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = F1545_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F1545_13931(RTCW(tr1));
		Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			Result = F1995_19845(loc1, arg1);
			RTLE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTLE;
	return Result;
}

/* {ET_ECF_CAPABILITIES}.support_value */
EIF_REFERENCE F1995_19846 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1553_14040(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F1545_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1545_13931(RTCW(tr1));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			Result = F1995_19846(loc1, arg1);
			RTLE;
			return (EIF_REFERENCE) Result;
		}
	}
	RTLE;
	return Result;
}

/* {ET_ECF_CAPABILITIES}.primary_use_value */
EIF_REFERENCE F1995_19847 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	tr1 = F1995_19848(Current, arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {ET_ECF_CAPABILITIES}.primary_use_value_id */
EIF_REFERENCE F1995_19848 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F1553_14040(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = F1545_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		Result = F1545_13931(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {ET_ECF_CAPABILITIES}.primary_support_value */
EIF_REFERENCE F1995_19849 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1553_14040(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F1545_13939(RTCW(tr1));
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		Result = F1545_13931(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {ET_ECF_CAPABILITIES}.set_primary_use_value */
void F1995_19853 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	F1987_19652(RTCW(loc1), arg2);
	F1995_19854(Current, arg1, loc1);
	RTLE;
}

/* {ET_ECF_CAPABILITIES}.set_primary_use_value_id */
void F1995_19854 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	F1553_14051(RTCW(tr1), arg2, arg1);
	RTLE;
}

/* {ET_ECF_CAPABILITIES}.set_primary_support_value */
void F1995_19855 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1553_14051(RTCW(tr1), arg2, arg1);
	RTLE;
}

/* {ET_ECF_CAPABILITIES}.set_secondary_capabilities */
void F1995_19856 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {ET_ECF_CAPABILITIES}.capability_order */
static EIF_REFERENCE F1995_19857_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDD;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(100)
	dftype = Dftype(Current);

	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,1569,1091,0xFF01,1184,0xFF01,1184,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
	}
	F1553_14024(RTCW(tr1), ((EIF_INTEGER_32) 3L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(99,F999_7548, (Current));
	F1553_14042(RTCW(Result), tr1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,146,0xFF01,1184,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 146, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,1085,0xFF01,1197,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	tr2 = RTOUCR(10,F1207_10828, (Current));
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
	RTAR(tr1,tr2);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1174,0xFF01,0xFFF9,1,1085,0xFF01,1184,1091,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A509_52_2, (EIF_POINTER) _A509_52_2, (EIF_POINTER)(F1198_10702),tr1, 1, 1);
	}
	F147_1523(RTCW(loc1), tr4);
	F1569_14103(RTCW(Result), loc1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1569,1091,0xFF01,1184,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc2 = RTLNS(typres0.id, 1569, _OBJSIZ_11_0_0_9_0_0_0_0_);
	}
	F1554_14024(RTCW(loc2), ((EIF_INTEGER_32) 3L));
	tr1 = RTOUCR(99,F999_7548, (Current));
	F1554_14042(RTCW(loc2), tr1);
	F1570_14103(RTCW(loc2), loc1);
	tr1 = RTOUCR(101,F47_587, (Current));
	F1554_14047(RTCW(loc2), ((EIF_INTEGER_32) 1L), tr1);
	tr1 = RTOUCR(102,F47_585, (Current));
	F1554_14047(RTCW(loc2), ((EIF_INTEGER_32) 2L), tr1);
	tr1 = RTOUCR(103,F47_584, (Current));
	F1554_14047(RTCW(loc2), ((EIF_INTEGER_32) 3L), tr1);
	tr1 = RTOUCR(104,F47_581, (Current));
	F1553_14047(RTCW(Result), loc2, tr1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1569,1091,0xFF01,1184,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc2 = RTLNS(typres0.id, 1569, _OBJSIZ_11_0_0_9_0_0_0_0_);
	}
	F1554_14024(RTCW(loc2), ((EIF_INTEGER_32) 3L));
	tr1 = RTOUCR(99,F999_7548, (Current));
	F1554_14042(RTCW(loc2), tr1);
	F1570_14103(RTCW(loc2), loc1);
	tr1 = RTOUCR(105,F47_589, (Current));
	F1554_14047(RTCW(loc2), ((EIF_INTEGER_32) 1L), tr1);
	tr1 = RTOUCR(101,F47_587, (Current));
	F1554_14047(RTCW(loc2), ((EIF_INTEGER_32) 2L), tr1);
	tr1 = RTOUCR(106,F47_588, (Current));
	F1554_14047(RTCW(loc2), ((EIF_INTEGER_32) 3L), tr1);
	tr1 = RTOUCR(107,F47_582, (Current));
	F1553_14047(RTCW(Result), loc2, tr1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1569,1091,0xFF01,1184,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc2 = RTLNS(typres0.id, 1569, _OBJSIZ_11_0_0_9_0_0_0_0_);
	}
	F1554_14024(RTCW(loc2), ((EIF_INTEGER_32) 5L));
	tr1 = RTOUCR(99,F999_7548, (Current));
	F1554_14042(RTCW(loc2), tr1);
	F1570_14103(RTCW(loc2), loc1);
	tr1 = RTOUCR(101,F47_587, (Current));
	F1554_14047(RTCW(loc2), ((EIF_INTEGER_32) 1L), tr1);
	tr1 = RTOUCR(102,F47_585, (Current));
	F1554_14047(RTCW(loc2), ((EIF_INTEGER_32) 2L), tr1);
	tr1 = RTOUCR(108,F47_586, (Current));
	F1554_14047(RTCW(loc2), ((EIF_INTEGER_32) 3L), tr1);
	tr1 = RTOUCR(109,F47_590, (Current));
	F1554_14047(RTCW(loc2), ((EIF_INTEGER_32) 4L), tr1);
	tr1 = RTOUCR(103,F47_584, (Current));
	F1554_14047(RTCW(loc2), ((EIF_INTEGER_32) 5L), tr1);
	tr1 = RTOUCR(110,F47_583, (Current));
	F1553_14047(RTCW(Result), loc2, tr1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1995_19857 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(100,F1995_19857_body,(Current));
}

void EIF_Minit1043 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
