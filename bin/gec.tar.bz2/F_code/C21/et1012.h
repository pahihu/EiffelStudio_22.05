
#ifndef _C21_et1012_
#define _C21_et1012_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1964_19502(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1964_19503(EIF_REFERENCE);
extern EIF_REFERENCE F1964_19505(EIF_REFERENCE);
extern EIF_REFERENCE F1964_19509(EIF_REFERENCE);
extern EIF_REFERENCE F1964_19511(EIF_REFERENCE);
extern void F1964_19512(EIF_REFERENCE, EIF_REFERENCE);
extern void F1964_19514(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1012(void);
extern EIF_REFERENCE F1008_7640(EIF_REFERENCE);
extern EIF_REFERENCE F396_4675(EIF_REFERENCE);
extern void F1628_16505(EIF_REFERENCE);
extern void F1648_16707(EIF_REFERENCE);
extern char *(*R13062[])();
extern char *(*R13279[])();
extern char *(*R13233[])();
extern char *(*R2395[])();

#ifdef __cplusplus
}
#endif

#endif
