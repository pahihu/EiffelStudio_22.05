
#ifndef _C21_et1032_
#define _C21_et1032_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1984_19625(EIF_REFERENCE);
extern void F1984_19626(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1032(void);
extern void F1798_17505(EIF_REFERENCE);
extern char *(*R2446[])();

#ifdef __cplusplus
}
#endif

#endif
