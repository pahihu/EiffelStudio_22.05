/*
 * Code for class ET_KEYWORD_OPERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1004.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_KEYWORD_OPERATOR}.is_infix_and */
EIF_BOOLEAN F1956_19419 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) 'T';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD_OPERATOR}.is_infix_implies */
EIF_BOOLEAN F1956_19420 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) 'U';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD_OPERATOR}.is_infix_or */
EIF_BOOLEAN F1956_19421 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) 'V';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD_OPERATOR}.is_infix_xor */
EIF_BOOLEAN F1956_19422 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) 'W';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD_OPERATOR}.is_prefix_not */
EIF_BOOLEAN F1956_19424 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	tc2 = (EIF_CHARACTER_8) '[';
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == tc2);
	RTLE;
	return Result;
}

/* {ET_KEYWORD_OPERATOR}.name */
EIF_REFERENCE F1956_19425 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	switch (*(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_)) {
		case (EIF_CHARACTER_8) 'T':
			Result = RTOUCR(1648,F396_5230, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'U':
			Result = RTOUCR(1654,F396_5231, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'V':
			Result = RTOUCR(1659,F396_5232, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		case (EIF_CHARACTER_8) 'W':
			Result = RTOUCR(1664,F396_5233, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		case (EIF_CHARACTER_8) '[':
			Result = RTOUCR(1666,F396_5248, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
		default:
			Result = RTOUCR(1667,F396_5209, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
			break;
	}
	RTLE;
	return Result;
}

/* {ET_KEYWORD_OPERATOR}.hash_code */
EIF_INTEGER_32 F1956_19426 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tc1 = *(EIF_CHARACTER_8 *)(Current+ _CHROFF_2_0_);
	Result = (EIF_INTEGER_32) (tc1);
	RTLE;
	return Result;
}

void EIF_Minit1004 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
