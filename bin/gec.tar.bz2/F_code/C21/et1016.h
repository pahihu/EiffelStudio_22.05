
#ifndef _C21_et1016_
#define _C21_et1016_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1968_19554(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1968_19555(EIF_REFERENCE);
extern EIF_REFERENCE F1968_19559(EIF_REFERENCE);
extern EIF_REFERENCE F1968_19561(EIF_REFERENCE);
extern void F1968_19563(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1016(void);
extern EIF_REFERENCE F1008_7640(EIF_REFERENCE);
extern EIF_REFERENCE F396_4627(EIF_REFERENCE);
extern EIF_REFERENCE F1914_18794(EIF_REFERENCE);
extern char *(*R13066[])();
extern char *(*R2290[])();
extern char *(*R13233[])();

#ifdef __cplusplus
}
#endif

#endif
