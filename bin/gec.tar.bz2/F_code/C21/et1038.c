/*
 * Code for class ET_CLASS_CODES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et1038.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_CLASS_CODES}.is_basic */
EIF_BOOLEAN F1990_19727 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (((EIF_NATURAL_8) 1U) <= arg1) && (EIF_BOOLEAN) (arg1 <= ((EIF_NATURAL_8) 51U)));
}

/* {ET_CLASS_CODES}.class_code */
EIF_NATURAL_8 F1990_19729 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTOUCR(3042,F1990_19759, (Current));
	F1557_14040(RTCW(loc1), arg1);
	tb1 = F1549_13939(RTCW(loc1));
	if (tb1) {
		tu1_1 = F1549_13931(RTCW(loc1));
		RTLE;
		return (EIF_NATURAL_8) tu1_1;
	} else {
		RTLE;
		return (EIF_NATURAL_8) ((EIF_NATURAL_8) 0U);
	}/* NOTREACHED */
	
}

/* {ET_CLASS_CODES}.codes_by_name */
static EIF_REFERENCE F1990_19759_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(3042)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1572,1109,0xFF01,1985,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1572, _OBJSIZ_11_0_0_9_0_0_0_0_);
	}
	F1557_14024(RTCW(tr1), ((EIF_INTEGER_32) 28L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(564,F394_3732, (Current));
	F1557_14042(RTCW(Result), tr1);
	tr1 = RTOUCR(572,F396_4211, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 1U), tr1);
	tr1 = RTOUCR(573,F396_4213, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 11U), tr1);
	tr1 = RTOUCR(574,F396_4214, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 12U), tr1);
	tr1 = RTOUCR(580,F396_4226, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 21U), tr1);
	tr1 = RTOUCR(581,F396_4227, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 22U), tr1);
	tr1 = RTOUCR(582,F396_4228, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 23U), tr1);
	tr1 = RTOUCR(583,F396_4229, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 24U), tr1);
	tr1 = RTOUCR(586,F396_4238, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 31U), tr1);
	tr1 = RTOUCR(587,F396_4239, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 32U), tr1);
	tr1 = RTOUCR(588,F396_4240, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 33U), tr1);
	tr1 = RTOUCR(589,F396_4241, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 34U), tr1);
	tr1 = RTOUCR(593,F396_4248, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 41U), tr1);
	tr1 = RTOUCR(594,F396_4249, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 42U), tr1);
	tr1 = RTOUCR(590,F396_4244, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 51U), tr1);
	tr1 = RTOUCR(602,F396_4257, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 61U), tr1);
	tr1 = RTOUCR(577,F396_4221, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 71U), tr1);
	tr1 = RTOUCR(591,F396_4245, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 72U), tr1);
	tr1 = RTOUCR(592,F396_4246, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 73U), tr1);
	tr1 = RTOUCR(595,F396_4250, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 74U), tr1);
	tr1 = RTOUCR(596,F396_4251, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 101U), tr1);
	tr1 = RTOUCR(603,F396_4258, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 102U), tr1);
	tr1 = RTOUCR(605,F396_4259, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 103U), tr1);
	tr1 = RTOUCR(570,F396_4210, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 104U), tr1);
	tr1 = RTOUCR(568,F396_4208, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 105U), tr1);
	tr1 = RTOUCR(600,F396_4255, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 106U), tr1);
	tr1 = RTOUCR(1964,F396_4216, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 107U), tr1);
	tr1 = RTOUCR(585,F396_4233, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 108U), tr1);
	tr1 = RTOUCR(1984,F396_4234, (RTCV(RTOUCR(6,F1008_7640, (Current)))));
	F1557_14051(RTCW(Result), ((EIF_NATURAL_8) 109U), tr1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1990_19759 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(3042,F1990_19759_body,(Current));
}

void EIF_Minit1038 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
