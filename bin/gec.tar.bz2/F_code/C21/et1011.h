
#ifndef _C21_et1011_
#define _C21_et1011_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1963_19491(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1963_19492(EIF_REFERENCE);
extern EIF_REFERENCE F1963_19496(EIF_REFERENCE);
extern EIF_REFERENCE F1963_19498(EIF_REFERENCE);
extern void F1963_19499(EIF_REFERENCE, EIF_REFERENCE);
extern void F1963_19501(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1011(void);
extern EIF_REFERENCE F1008_7640(EIF_REFERENCE);
extern EIF_REFERENCE F396_4626(EIF_REFERENCE);
extern EIF_REFERENCE F1914_18794(EIF_REFERENCE);
extern char *(*R2289[])();
extern char *(*R13066[])();
extern char *(*R13233[])();

#ifdef __cplusplus
}
#endif

#endif
