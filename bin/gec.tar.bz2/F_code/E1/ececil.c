#include "eif_eiffel.h"
#include "eif_rout_obj.h"
#include "eaddress.h"
#include "eoffsets.h"

#ifdef __cplusplus
extern "C" {
#endif

	/* DESCRIPTOR_CACHE c_iconv_close */
void _A8_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_p);
}

	/* DESCRIPTOR_CACHE c_iconv_close */
void __A8_42_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_POINTER), EIF_TYPED_VALUE * closed, EIF_POINTER op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_ECF_FILE_RULES put_last */
void _A31_39_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_ECF_FILE_RULES put_last */
void __A31_39_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_ECF_FILE_RULE is_enabled */
EIF_BOOLEAN _A343_32_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F368_3608)(open [1].it_r, closed [1].it_r);
}

	/* ET_ECF_FILE_RULE is_enabled */
EIF_BOOLEAN __A343_32_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F368_3608)(op_1, closed [1].it_r);
}

	/* ET_ECF_FILE_RULE is_included */
EIF_BOOLEAN _A343_37_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F462_6143)(open [1].it_r, closed [1].it_r);
}

	/* ET_ECF_FILE_RULE is_included */
EIF_BOOLEAN __A343_37_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F462_6143)(op_1, closed [1].it_r);
}

	/* ET_ECF_EXTERNAL_VALUE fill_external_values */
void _A288_39_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3052[Dtype(open [1].it_r) - 371])(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_ECF_EXTERNAL_VALUE fill_external_values */
void __A288_39_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R3052[Dtype(op_1) - 371])(op_1, closed [1].it_r, closed [2].it_r);
}

	/* THREAD thr_get_terminated */
EIF_BOOLEAN A144_51 (EIF_REFERENCE Current)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (Current);
}

	/* THREAD thr_main */
void A144_50 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) F199_1857)(Current, arg1);
}

	/* THREAD thr_set_terminated */
void A144_52 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) F199_1859)(Current, arg1);
}

	/* RX_PCRE_REGULAR_EXPRESSION matches */
EIF_BOOLEAN _A1192_39_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2037_21051)(open [1].it_r, closed [1].it_r);
}

	/* RX_PCRE_REGULAR_EXPRESSION matches */
EIF_BOOLEAN __A1192_39_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2037_21051)(op_1, closed [1].it_r);
}

	/* RX_PCRE_REGULAR_EXPRESSION is_compiled */
EIF_BOOLEAN _A1192_320_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2142_26833)(open [1].it_r);
}

	/* RX_PCRE_REGULAR_EXPRESSION is_compiled */
EIF_BOOLEAN __A1192_320_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2142_26833)(op_1);
}

	/* MISMATCH_INFORMATION wipe_out */
void A382_98 (EIF_REFERENCE Current)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F989_7448)(Current);
}

	/* MISMATCH_INFORMATION internal_put */
void A382_162 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER)) F996_7521)(Current, arg1, arg2);
}

	/* MISMATCH_INFORMATION set_string_versions */
void A382_163 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER)) F996_7522)(Current, arg1, arg2);
}

	/* ET_CLIENT_LIST has_class */
EIF_BOOLEAN _A389_62_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_CLIENT_LIST has_class */
EIF_BOOLEAN __A389_62_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* KL_STRING_ROUTINES same_case_insensitive */
EIF_BOOLEAN _A509_56_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* KL_STRING_ROUTINES same_case_insensitive */
EIF_BOOLEAN __A509_56_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_STRING_ROUTINES case_insensitive_hash_code */
EIF_INTEGER_32 _A509_52_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* KL_STRING_ROUTINES case_insensitive_hash_code */
EIF_INTEGER_32 __A509_52_2 ( EIF_INTEGER_32(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* ET_LIBRARY add_library_recursive */
void _A664_358_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1616_16393)(open [1].it_r, closed [1].it_r);
}

	/* ET_LIBRARY add_library_recursive */
void __A664_358_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1616_16393)(op_1, closed [1].it_r);
}

	/* ET_LIBRARY parse_all */
void _A664_315_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_LIBRARY parse_all */
void __A664_315_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_LIBRARY import_classes */
void _A664_317_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1615_16378)(open [1].it_r);
}

	/* ET_LIBRARY import_classes */
void __A664_317_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1615_16378)(op_1);
}

	/* ET_LIBRARY preparse */
void _A664_359_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1616_16394)(open [1].it_r, closed [1].it_r);
}

	/* ET_LIBRARY preparse */
void __A664_359_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1616_16394)(op_1, closed [1].it_r);
}

	/* ET_LIBRARY add_internal_universe_recursive */
void _A664_341_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1615_16372)(open [1].it_r, closed [1].it_r);
}

	/* ET_LIBRARY add_internal_universe_recursive */
void __A664_341_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1615_16372)(op_1, closed [1].it_r);
}

	/* ET_LIBRARY add_universe_recursive */
void _A664_310_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1615_16371)(open [1].it_r, closed [1].it_r);
}

	/* ET_LIBRARY add_universe_recursive */
void __A664_310_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1615_16371)(op_1, closed [1].it_r);
}

	/* ET_CLASS implementation_checked */
EIF_BOOLEAN _A1075_472_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20801)(open [1].it_r);
}

	/* ET_CLASS implementation_checked */
EIF_BOOLEAN __A1075_472_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20801)(op_1);
}

	/* ET_CLASS interface_checked */
EIF_BOOLEAN _A1075_457_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20786)(open [1].it_r);
}

	/* ET_CLASS interface_checked */
EIF_BOOLEAN __A1075_457_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20786)(op_1);
}

	/* ET_CLASS features_flattened */
EIF_BOOLEAN _A1075_448_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20777)(open [1].it_r);
}

	/* ET_CLASS features_flattened */
EIF_BOOLEAN __A1075_448_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20777)(op_1);
}

	/* ET_CLASS ancestors_built */
EIF_BOOLEAN _A1075_395_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20724)(open [1].it_r);
}

	/* ET_CLASS ancestors_built */
EIF_BOOLEAN __A1075_395_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20724)(op_1);
}

	/* ET_CLASS is_parsed */
EIF_BOOLEAN _A1075_333_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20662)(open [1].it_r);
}

	/* ET_CLASS is_parsed */
EIF_BOOLEAN __A1075_333_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20662)(op_1);
}

	/* ET_CLASS is_marked */
EIF_BOOLEAN _A1075_108_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1129_9978)(open [1].it_r);
}

	/* ET_CLASS is_marked */
EIF_BOOLEAN __A1075_108_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1129_9978)(op_1);
}

	/* ET_CLASS is_in_override_group */
EIF_BOOLEAN _A1075_330_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20659)(open [1].it_r);
}

	/* ET_CLASS is_in_override_group */
EIF_BOOLEAN __A1075_330_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20659)(op_1);
}

	/* ET_CLASS is_in_group_recursive */
EIF_BOOLEAN _A1075_321_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS is_in_group_recursive */
EIF_BOOLEAN __A1075_321_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS is_in_group */
EIF_BOOLEAN _A1075_320_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2027_20649)(open [1].it_r, closed [1].it_r);
}

	/* ET_CLASS is_in_group */
EIF_BOOLEAN __A1075_320_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F2027_20649)(op_1, closed [1].it_r);
}

	/* ET_CLASS add_by_group */
void _A1075_318_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS add_by_group */
void __A1075_318_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS reset_errors */
void _A1075_243_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS reset_errors */
void __A1075_243_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS reset_after_parsed_and_errors */
void _A1075_244_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20573)(open [1].it_r);
}

	/* ET_CLASS reset_after_parsed_and_errors */
void __A1075_244_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20573)(op_1);
}

	/* ET_CLASS reset_after_preparsed */
void _A1075_238_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20567)(open [1].it_r);
}

	/* ET_CLASS reset_after_preparsed */
void __A1075_238_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20567)(op_1);
}

	/* ET_CLASS has_syntax_error */
EIF_BOOLEAN _A1075_335_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20664)(open [1].it_r);
}

	/* ET_CLASS has_syntax_error */
EIF_BOOLEAN __A1075_335_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20664)(op_1);
}

	/* ET_CLASS reset_after_parsed */
void _A1075_239_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20568)(open [1].it_r);
}

	/* ET_CLASS reset_after_parsed */
void __A1075_239_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20568)(op_1);
}

	/* ET_CLASS has_ancestors_error */
EIF_BOOLEAN _A1075_397_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20726)(open [1].it_r);
}

	/* ET_CLASS has_ancestors_error */
EIF_BOOLEAN __A1075_397_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20726)(op_1);
}

	/* ET_CLASS set_ancestors_error */
void _A1075_399_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20728)(open [1].it_r);
}

	/* ET_CLASS set_ancestors_error */
void __A1075_399_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20728)(op_1);
}

	/* ET_CLASS reset_after_ancestors_built */
void _A1075_240_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20569)(open [1].it_r);
}

	/* ET_CLASS reset_after_ancestors_built */
void __A1075_240_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20569)(op_1);
}

	/* ET_CLASS has_flattening_error */
EIF_BOOLEAN _A1075_450_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20779)(open [1].it_r);
}

	/* ET_CLASS has_flattening_error */
EIF_BOOLEAN __A1075_450_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20779)(op_1);
}

	/* ET_CLASS set_flattening_error */
void _A1075_452_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20781)(open [1].it_r);
}

	/* ET_CLASS set_flattening_error */
void __A1075_452_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20781)(op_1);
}

	/* ET_CLASS reset_after_features_flattened */
void _A1075_241_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20570)(open [1].it_r);
}

	/* ET_CLASS reset_after_features_flattened */
void __A1075_241_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20570)(op_1);
}

	/* ET_CLASS has_interface_error */
EIF_BOOLEAN _A1075_459_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20788)(open [1].it_r);
}

	/* ET_CLASS has_interface_error */
EIF_BOOLEAN __A1075_459_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20788)(op_1);
}

	/* ET_CLASS set_interface_error */
void _A1075_461_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20790)(open [1].it_r);
}

	/* ET_CLASS set_interface_error */
void __A1075_461_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20790)(op_1);
}

	/* ET_CLASS reset_after_interface_checked */
void _A1075_242_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20571)(open [1].it_r);
}

	/* ET_CLASS reset_after_interface_checked */
void __A1075_242_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20571)(op_1);
}

	/* ET_CLASS not_implementation_checked */
EIF_BOOLEAN _A1075_99_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1129_9974)(open [1].it_r);
}

	/* ET_CLASS not_implementation_checked */
EIF_BOOLEAN __A1075_99_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1129_9974)(op_1);
}

	/* ET_CLASS has_implementation_error */
EIF_BOOLEAN _A1075_474_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20803)(open [1].it_r);
}

	/* ET_CLASS has_implementation_error */
EIF_BOOLEAN __A1075_474_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20803)(op_1);
}

	/* ET_CLASS set_implementation_error */
void _A1075_476_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20805)(open [1].it_r);
}

	/* ET_CLASS set_implementation_error */
void __A1075_476_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F2027_20805)(op_1);
}

	/* ET_CLASS unmark_ignored_class */
void _A1075_282_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS unmark_ignored_class */
void __A1075_282_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS mark_ignored_class */
void _A1075_281_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS mark_ignored_class */
void __A1075_281_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS set_index */
void _A1075_304_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) F2027_20633)(open [1].it_r, closed [1].it_i4);
}

	/* ET_CLASS set_index */
void __A1075_304_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) F2027_20633)(op_1, closed [1].it_i4);
}

	/* ET_CLASS is_unknown */
EIF_BOOLEAN _A1075_278_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20607)(open [1].it_r);
}

	/* ET_CLASS is_unknown */
EIF_BOOLEAN __A1075_278_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F2027_20607)(op_1);
}

	/* ET_CLASS add_to_conforming_descendants */
void _A1075_387_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS add_to_conforming_descendants */
void __A1075_387_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_CLASS add_to_descendants */
void _A1075_385_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_CLASS add_to_descendants */
void __A1075_385_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_MASTER_CLASS process */
void _A634_164_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1586_14312)(open [1].it_r, closed [1].it_r);
}

	/* ET_MASTER_CLASS process */
void __A634_164_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1586_14312)(op_1, closed [1].it_r);
}

	/* ET_MASTER_CLASS reset_local_modified_class */
void _A634_162_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS reset_local_modified_class */
void __A634_162_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* ET_MASTER_CLASS unmark_overridden */
void _A634_144_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_MASTER_CLASS unmark_overridden */
void __A634_144_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_MASTER_CLASS mark_overridden */
void _A634_143_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_MASTER_CLASS mark_overridden */
void __A634_143_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_MASTER_CLASS local_override_classes_do_if */
void _A634_151_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1586_14299)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS local_override_classes_do_if */
void __A634_151_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1586_14299)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS is_in_universe */
EIF_BOOLEAN _A634_86_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_MASTER_CLASS is_in_universe */
EIF_BOOLEAN __A634_86_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_MASTER_CLASS local_non_override_classes_do_if */
void _A634_152_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1586_14300)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS local_non_override_classes_do_if */
void __A634_152_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1586_14300)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS local_classes_do_all */
void _A634_145_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_MASTER_CLASS local_classes_do_all */
void __A634_145_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_MASTER_CLASS local_classes_do_if */
void _A634_150_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1586_14298)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS local_classes_do_if */
void __A634_150_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1586_14298)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS is_preparsed */
EIF_BOOLEAN _A634_98_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1586_14246)(open [1].it_r);
}

	/* ET_MASTER_CLASS is_preparsed */
EIF_BOOLEAN __A634_98_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1586_14246)(op_1);
}

	/* ET_MASTER_CLASS has_syntax_error */
EIF_BOOLEAN _A634_101_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1586_14249)(open [1].it_r);
}

	/* ET_MASTER_CLASS has_syntax_error */
EIF_BOOLEAN __A634_101_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1586_14249)(op_1);
}

	/* ET_MASTER_CLASS local_classes_do_unless_actual */
void _A634_154_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1586_14302)(open [1].it_r, closed [1].it_r);
}

	/* ET_MASTER_CLASS local_classes_do_unless_actual */
void __A634_154_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1586_14302)(op_1, closed [1].it_r);
}

	/* ET_MASTER_CLASS set_modified */
void _A634_97_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) F1586_14245)(open [1].it_r, closed [1].it_b);
}

	/* ET_MASTER_CLASS set_modified */
void __A634_97_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) F1586_14245)(op_1, closed [1].it_b);
}

	/* ET_MASTER_CLASS remove_unknown_imported_classes */
void _A634_136_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1586_14284)(open [1].it_r);
}

	/* ET_MASTER_CLASS remove_unknown_imported_classes */
void __A634_136_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1586_14284)(op_1);
}

	/* ET_MASTER_CLASS reset_local_modified_classes */
void _A634_161_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1586_14309)(open [1].it_r, closed [1].it_r);
}

	/* ET_MASTER_CLASS reset_local_modified_classes */
void __A634_161_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1586_14309)(op_1, closed [1].it_r);
}

	/* ET_MASTER_CLASS remove_unknown_local_classes */
void _A634_134_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1586_14282)(open [1].it_r);
}

	/* ET_MASTER_CLASS remove_unknown_local_classes */
void __A634_134_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1586_14282)(op_1);
}

	/* ET_MASTER_CLASS local_ignored_classes_do_if */
void _A634_153_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1586_14301)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS local_ignored_classes_do_if */
void __A634_153_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1586_14301)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_MASTER_CLASS has_imported_class */
EIF_BOOLEAN _A634_95_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1586_14243)(open [1].it_r, closed [1].it_r);
}

	/* ET_MASTER_CLASS has_imported_class */
EIF_BOOLEAN __A634_95_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1586_14243)(op_1, closed [1].it_r);
}

	/* DS_ARRAYED_LIST [G#1] force_last */
void _A1404_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_ARRAYED_LIST [NATURAL_32] force_last */
void _A1949_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_n4);
}

	/* DS_ARRAYED_LIST [INTEGER_32] force_last */
void _A1970_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* DS_ARRAYED_LIST [G#1] force_last */
void __A1404_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_ARRAYED_LIST [NATURAL_32] force_last */
void __A1949_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_NATURAL_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_ARRAYED_LIST [INTEGER_32] force_last */
void __A1970_120_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_ARRAYED_LIST [G#1] has_void */
EIF_BOOLEAN _A1404_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* DS_ARRAYED_LIST [NATURAL_32] has_void */
EIF_BOOLEAN _A1949_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* DS_ARRAYED_LIST [INTEGER_32] has_void */
EIF_BOOLEAN _A1970_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* DS_ARRAYED_LIST [G#1] has_void */
EIF_BOOLEAN __A1404_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* DS_ARRAYED_LIST [NATURAL_32] has_void */
EIF_BOOLEAN __A1949_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* DS_ARRAYED_LIST [INTEGER_32] has_void */
EIF_BOOLEAN __A1970_41_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* DS_ARRAYED_LIST [G#1] is_empty */
EIF_BOOLEAN _A1404_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10705[Dtype(open [1].it_r) - 1479])(open [1].it_r);
}

	/* DS_ARRAYED_LIST [NATURAL_32] is_empty */
EIF_BOOLEAN _A1949_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1436_13373)(open [1].it_r);
}

	/* DS_ARRAYED_LIST [INTEGER_32] is_empty */
EIF_BOOLEAN _A1970_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1433_13373)(open [1].it_r);
}

	/* DS_ARRAYED_LIST [G#1] is_empty */
EIF_BOOLEAN __A1404_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R10705[Dtype(op_1) - 1479])(op_1);
}

	/* DS_ARRAYED_LIST [NATURAL_32] is_empty */
EIF_BOOLEAN __A1949_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1436_13373)(op_1);
}

	/* DS_ARRAYED_LIST [INTEGER_32] is_empty */
EIF_BOOLEAN __A1970_31_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1433_13373)(op_1);
}

	/* DS_ARRAYED_LIST [G#1] there_exists */
EIF_BOOLEAN _A1404_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R10711[Dtype(open [1].it_r) - 1512])(open [1].it_r, closed [1].it_r);
}

	/* DS_ARRAYED_LIST [NATURAL_32] there_exists */
EIF_BOOLEAN _A1949_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1506_13567)(open [1].it_r, closed [1].it_r);
}

	/* DS_ARRAYED_LIST [INTEGER_32] there_exists */
EIF_BOOLEAN _A1970_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1505_13567)(open [1].it_r, closed [1].it_r);
}

	/* DS_ARRAYED_LIST [G#1] there_exists */
EIF_BOOLEAN __A1404_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R10711[Dtype(op_1) - 1512])(op_1, closed [1].it_r);
}

	/* DS_ARRAYED_LIST [NATURAL_32] there_exists */
EIF_BOOLEAN __A1949_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1506_13567)(op_1, closed [1].it_r);
}

	/* DS_ARRAYED_LIST [INTEGER_32] there_exists */
EIF_BOOLEAN __A1970_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1505_13567)(op_1, closed [1].it_r);
}

	/* ET_SYSTEM_PROCESSOR process_custom */
void _A594_155 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ET_SYSTEM_PROCESSOR process_custom */
void __A594_155 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ET_SYSTEM_PROCESSOR check_implementation_validity */
void _A594_153 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ET_SYSTEM_PROCESSOR check_implementation_validity */
void __A594_153 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ET_SYSTEM_PROCESSOR parse_marked_classes */
void _A594_148 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ET_SYSTEM_PROCESSOR parse_marked_classes */
void __A594_148 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ET_SYSTEM_PROCESSOR parse_classes */
void _A594_147 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ET_SYSTEM_PROCESSOR parse_classes */
void __A594_147 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r);
}

	/* ET_DOTNET_ASSEMBLY add_dotnet_assembly_recursive */
void _A660_326_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1612_16315)(open [1].it_r, closed [1].it_r);
}

	/* ET_DOTNET_ASSEMBLY add_dotnet_assembly_recursive */
void __A660_326_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1612_16315)(op_1, closed [1].it_r);
}

	/* ET_DOTNET_ASSEMBLY add_universe_recursive */
void _A660_325_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1612_16314)(open [1].it_r, closed [1].it_r);
}

	/* ET_DOTNET_ASSEMBLY add_universe_recursive */
void __A660_325_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1612_16314)(op_1, closed [1].it_r);
}

	/* ET_DOTNET_ASSEMBLY is_consumable */
EIF_BOOLEAN _A660_327_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1612_16316)(open [1].it_r);
}

	/* ET_DOTNET_ASSEMBLY is_consumable */
EIF_BOOLEAN __A660_327_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1612_16316)(op_1);
}

	/* ET_DOTNET_ASSEMBLY parse_all */
void _A660_289_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_DOTNET_ASSEMBLY parse_all */
void __A660_289_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_DOTNET_ASSEMBLY import_classes */
void _A660_329_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1612_16318)(open [1].it_r);
}

	/* ET_DOTNET_ASSEMBLY import_classes */
void __A660_329_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F1612_16318)(op_1);
}

	/* ET_DOTNET_ASSEMBLY preparse */
void _A660_287_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1611_16276)(open [1].it_r, closed [1].it_r);
}

	/* ET_DOTNET_ASSEMBLY preparse */
void __A660_287_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1611_16276)(op_1, closed [1].it_r);
}

	/* ET_C_GENERATOR print_attribute_tuple_item_access */
void _A635_408 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_r, closed [4].it_r, closed [5].it_b);
}

	/* ET_C_GENERATOR print_attribute_tuple_item_access */
void __A635_408 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_i4, closed [3].it_r, closed [4].it_r, closed [5].it_b);
}

	/* ET_C_GENERATOR print_deep_twin_call */
void _A635_549 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* ET_C_GENERATOR print_deep_twin_call */
void __A635_549 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* ET_C_GENERATOR print_attribute_special_indexed_item_access */
void _A635_407 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, closed [5].it_b);
}

	/* ET_C_GENERATOR print_attribute_special_indexed_item_access */
void __A635_407 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, closed [5].it_b);
}

	/* ET_C_GENERATOR print_attribute_access */
void _A635_403 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, closed [5].it_b);
}

	/* ET_C_GENERATOR print_attribute_access */
void __A635_403 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r, closed [5].it_b);
}

	/* ET_C_GENERATOR print_query_call */
void _A635_481 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_b);
}

	/* ET_C_GENERATOR print_query_call */
void __A635_481 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_b);
}

	/* KL_AGENT_ROUTINES [G#1] conjuncted_semistrict */
EIF_BOOLEAN _A2047_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] conjuncted_semistrict */
EIF_BOOLEAN _A2066_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_b, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] conjuncted_semistrict */
EIF_BOOLEAN _A2067_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_c1, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] conjuncted_semistrict */
EIF_BOOLEAN _A2068_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] conjuncted_semistrict */
EIF_BOOLEAN __A2047_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] conjuncted_semistrict */
EIF_BOOLEAN __A2066_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_BOOLEAN op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] conjuncted_semistrict */
EIF_BOOLEAN __A2067_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_CHARACTER_8 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] conjuncted_semistrict */
EIF_BOOLEAN __A2068_36_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] call */
void _A2047_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] call */
void _A2066_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_b, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] call */
void _A2067_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_c1, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] call */
void _A2068_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] call */
void __A2047_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] call */
void __A2066_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_BOOLEAN op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] call */
void __A2067_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_CHARACTER_8 op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] call */
void __A2068_32_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] negated */
EIF_BOOLEAN _A2047_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] negated */
EIF_BOOLEAN _A2066_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_b, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] negated */
EIF_BOOLEAN _A2067_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_c1, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] negated */
EIF_BOOLEAN _A2068_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] negated */
EIF_BOOLEAN __A2047_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] negated */
EIF_BOOLEAN __A2066_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_BOOLEAN op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] negated */
EIF_BOOLEAN __A2067_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_CHARACTER_8 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] negated */
EIF_BOOLEAN __A2068_34_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] conjuncted */
EIF_BOOLEAN _A2047_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] conjuncted */
EIF_BOOLEAN _A2066_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_b, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] conjuncted */
EIF_BOOLEAN _A2067_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_c1, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] conjuncted */
EIF_BOOLEAN _A2068_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [G#1] conjuncted */
EIF_BOOLEAN __A2047_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [BOOLEAN] conjuncted */
EIF_BOOLEAN __A2066_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_BOOLEAN op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [CHARACTER_8] conjuncted */
EIF_BOOLEAN __A2067_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_CHARACTER_8 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* KL_AGENT_ROUTINES [INTEGER_32] conjuncted */
EIF_BOOLEAN __A2068_35_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* UT_COUNTER increment */
void _A22_35 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* UT_COUNTER increment */
void __A22_35 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN _A503_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F747_6470)(open [1].it_r);
}

	/* STRING_8 is_empty */
EIF_BOOLEAN __A503_163_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F747_6470)(op_1);
}

	/* ET_ECF_CLUSTER fill_file_rules */
void _A655_213_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1607_16046)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_ECF_CLUSTER fill_file_rules */
void __A655_213_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1607_16046)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* UT_TRISTATE set_true */
void _A21_38 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r);
}

	/* UT_TRISTATE set_true */
void __A21_38 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	f_ptr (closed [1].it_r);
}

	/* UT_TRISTATE is_true */
EIF_BOOLEAN _A21_35 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r);
}

	/* UT_TRISTATE is_true */
EIF_BOOLEAN __A21_35 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed)
{
	return f_ptr (closed [1].it_r);
}

	/* ET_UNIVERSE fake inline-agent#27382#217#83# of classes_modified_recursive */
EIF_BOOLEAN _A659_282_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1611_27382)(closed [1].it_r, open [1].it_r);
}

	/* ET_UNIVERSE fake inline-agent#27382#217#83# of classes_modified_recursive */
EIF_BOOLEAN __A659_282_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1611_27382)(closed [1].it_r, op_2);
}

	/* ET_UNIVERSE master_classes_do_if */
void _A659_253_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1611_16259)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE master_classes_do_if */
void __A659_253_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1611_16259)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE master_classes_do_if_until */
void _A659_254_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1611_16260)(open [1].it_r, closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* ET_UNIVERSE master_classes_do_if_until */
void __A659_254_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1611_16260)(op_1, closed [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* ET_UNIVERSE master_classes_do_all */
void _A659_251_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1611_16257)(open [1].it_r, closed [1].it_r);
}

	/* ET_UNIVERSE master_classes_do_all */
void __A659_251_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1611_16257)(op_1, closed [1].it_r);
}

	/* ET_UNIVERSE master_classes_do_until */
void _A659_252_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1611_16258)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE master_classes_do_until */
void __A659_252_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1611_16258)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE classes_do_if */
void _A659_243_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R12882[Dtype(open [1].it_r) - 1611])(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE classes_do_if */
void __A659_243_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R12882[Dtype(op_1) - 1611])(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE classes_do_if_until */
void _A659_245_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE classes_do_if_until */
void __A659_245_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE classes_do_unless */
void _A659_244_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE classes_do_unless */
void __A659_244_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE classes_do_all */
void _A659_241_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R12880[Dtype(open [1].it_r) - 1611])(open [1].it_r, closed [1].it_r);
}

	/* ET_UNIVERSE classes_do_all */
void __A659_241_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R12880[Dtype(op_1) - 1611])(op_1, closed [1].it_r);
}

	/* ET_UNIVERSE classes_do_until */
void _A659_242_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1611_16248)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE classes_do_until */
void __A659_242_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1611_16248)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_UNIVERSE insert_in_hash_table */
void _A659_280_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_i4, open [1].it_r);
}

	/* ET_UNIVERSE insert_in_hash_table */
void __A659_280_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_4)
{
	f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_i4, op_4);
}

	/* ET_UNIVERSE add_classes_by_wildcarded_name */
void _A659_80_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE add_classes_by_wildcarded_name */
void __A659_80_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE do_class_by_wildcarded_name */
void _A659_268_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r, closed [3].it_r);
}

	/* ET_UNIVERSE do_class_by_wildcarded_name */
void __A659_268_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r, closed [3].it_r);
}

	/* ET_UNIVERSE do_class_by_name */
void _A659_267_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE do_class_by_name */
void __A659_267_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE do_master_class_by_name */
void _A659_266_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE do_master_class_by_name */
void __A659_266_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE has_class */
EIF_BOOLEAN _A659_71_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_UNIVERSE has_class */
EIF_BOOLEAN __A659_71_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_UNIVERSE has_master_class */
EIF_BOOLEAN _A659_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1611_16075)(open [1].it_r, closed [1].it_r);
}

	/* ET_UNIVERSE has_master_class */
EIF_BOOLEAN __A659_69_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) F1611_16075)(op_1, closed [1].it_r);
}

	/* DS_HASH_TABLE [G#1, G#2] has */
EIF_BOOLEAN _A1380_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_TABLE [INTEGER_32, G#2] has */
EIF_BOOLEAN _A1339_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_TABLE [G#1, INTEGER_32] has */
EIF_BOOLEAN _A1365_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	EIF_BOOLEAN Result;
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(1091, 0x00).id, 1091, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = open [1].it_i4;
	Result = f_ptr (closed [1].it_r, arg1);
	RTLE;
	return Result;
}

	/* DS_HASH_TABLE [INTEGER_32, INTEGER_32] has */
EIF_BOOLEAN _A1700_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* DS_HASH_TABLE [NATURAL_8, G#2] has */
EIF_BOOLEAN _A1986_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_TABLE [BOOLEAN, G#2] has */
EIF_BOOLEAN _A2021_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_TABLE [G#1, NATURAL_8] has */
EIF_BOOLEAN _A2051_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_8), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_n1);
}

	/* DS_HASH_TABLE [NATURAL_64, NATURAL_32] has */
EIF_BOOLEAN _A2073_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_n4);
}

	/* DS_HASH_TABLE [G#1, G#2] has */
EIF_BOOLEAN __A1380_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [INTEGER_32, G#2] has */
EIF_BOOLEAN __A1339_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [G#1, INTEGER_32] has */
EIF_BOOLEAN __A1365_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	EIF_BOOLEAN Result;
	EIF_REFERENCE arg1 = (EIF_REFERENCE) 0;
	GTCX
	RTLD;
	RTLI (2);
	
	RTLR(0,closed [1].it_r);
	RTLR(1,arg1);
	RTLIU(2);
	arg1 = RTLNS(eif_new_type(1091, 0x00).id, 1091, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)arg1 = op_2;
	Result = f_ptr (closed [1].it_r, arg1);
	RTLE;
	return Result;
}

	/* DS_HASH_TABLE [INTEGER_32, INTEGER_32] has */
EIF_BOOLEAN __A1700_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [NATURAL_8, G#2] has */
EIF_BOOLEAN __A1986_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [BOOLEAN, G#2] has */
EIF_BOOLEAN __A2021_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [G#1, NATURAL_8] has */
EIF_BOOLEAN __A2051_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_8), EIF_TYPED_VALUE * closed, EIF_NATURAL_8 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_TABLE [NATURAL_64, NATURAL_32] has */
EIF_BOOLEAN __A2073_140_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_NATURAL_32), EIF_TYPED_VALUE * closed, EIF_NATURAL_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_SET [G#1] force_last */
void _A1394_141_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_SET [INTEGER_32] force_last */
void _A1244_141_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* DS_HASH_SET [G#1] force_last */
void __A1394_141_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_SET [INTEGER_32] force_last */
void __A1244_141_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_SET [G#1] has */
EIF_BOOLEAN _A1394_131_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_SET [INTEGER_32] has */
EIF_BOOLEAN _A1244_131_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* DS_HASH_SET [G#1] has */
EIF_BOOLEAN __A1394_131_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_SET [INTEGER_32] has */
EIF_BOOLEAN __A1244_131_2 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	return f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_SET [G#1] remove */
void _A1394_69_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_HASH_SET [INTEGER_32] remove */
void _A1244_69_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* DS_HASH_SET [G#1] remove */
void __A1394_69_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_HASH_SET [INTEGER_32] remove */
void __A1244_69_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_ANCESTORS_STATUS_CHECKER process_class */
void _A412_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_ANCESTORS_STATUS_CHECKER process_class */
void __A412_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_FLATTENING_STATUS_CHECKER process_class */
void _A411_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_FLATTENING_STATUS_CHECKER process_class */
void __A411_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_INTERFACE_STATUS_CHECKER process_class */
void _A410_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_INTERFACE_STATUS_CHECKER process_class */
void __A410_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_IMPLEMENTATION_STATUS_CHECKER process_class */
void _A409_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_IMPLEMENTATION_STATUS_CHECKER process_class */
void __A409_263_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_ADAPTED_LIBRARY export_classes */
void _A222_43_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F301_3357)(open [1].it_r, closed [1].it_r);
}

	/* ET_ADAPTED_LIBRARY export_classes */
void __A222_43_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F301_3357)(op_1, closed [1].it_r);
}

	/* ET_ADAPTED_LIBRARY propagate_read_only */
void _A222_40_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F301_3354)(open [1].it_r);
}

	/* ET_ADAPTED_LIBRARY propagate_read_only */
void __A222_40_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) F301_3354)(op_1);
}

	/* ET_ADAPTED_DOTNET_ASSEMBLY export_classes */
void _A223_43_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F301_3357)(open [1].it_r, closed [1].it_r);
}

	/* ET_ADAPTED_DOTNET_ASSEMBLY export_classes */
void __A223_43_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F301_3357)(op_1, closed [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE dotnet_assemblies_do_if */
void _A663_309_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1615_16370)(open [1].it_r, closed [1].it_r, closed [2].it_r);
}

	/* ET_INTERNAL_UNIVERSE dotnet_assemblies_do_if */
void __A663_309_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) F1615_16370)(op_1, closed [1].it_r, closed [2].it_r);
}

	/* ET_INTERNAL_UNIVERSE clusters_do_explicit */
void _A663_301_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1615_16362)(open [1].it_r, closed [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE clusters_do_explicit */
void __A663_301_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1615_16362)(op_1, closed [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE add_implicit_subclusters */
void _A663_299_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE add_implicit_subclusters */
void __A663_299_1 ( void(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_INTERNAL_UNIVERSE do_cluster_with_absolute_pathname */
void _A663_312_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE do_cluster_with_absolute_pathname */
void __A663_312_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_INTERNAL_UNIVERSE has_cluster_with_absolute_pathname */
EIF_BOOLEAN _A663_276_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE has_cluster_with_absolute_pathname */
EIF_BOOLEAN __A663_276_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_INTERNAL_UNIVERSE has_cluster_by_name */
EIF_BOOLEAN _A663_274_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE has_cluster_by_name */
EIF_BOOLEAN __A663_274_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_INTERNAL_UNIVERSE has_cluster */
EIF_BOOLEAN _A663_272_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (open [1].it_r);
}

	/* ET_INTERNAL_UNIVERSE has_cluster */
EIF_BOOLEAN __A663_272_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) RTNR) (op_1);
}

	/* ET_DOTNET_ASSEMBLIES put_last */
void _A612_40_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_DOTNET_ASSEMBLIES put_last */
void __A612_40_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_CLUSTER process */
void _A654_171_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1606_16014)(open [1].it_r, closed [1].it_r);
}

	/* ET_CLUSTER process */
void __A654_171_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F1606_16014)(op_1, closed [1].it_r);
}

	/* DS_CELL [G#1] put */
void _A1319_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* DS_CELL [CHARACTER_8] put */
void _A1699_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_c1);
}

	/* DS_CELL [INTEGER_32] put */
void _A1946_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_i4);
}

	/* DS_CELL [BOOLEAN] put */
void _A2123_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_b);
}

	/* DS_CELL [G#1] put */
void __A1319_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_CELL [CHARACTER_8] put */
void __A1699_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_CHARACTER_8), EIF_TYPED_VALUE * closed, EIF_CHARACTER_8 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_CELL [INTEGER_32] put */
void __A1946_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_INTEGER_32), EIF_TYPED_VALUE * closed, EIF_INTEGER_32 op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* DS_CELL [BOOLEAN] put */
void __A2123_34_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_BOOLEAN), EIF_TYPED_VALUE * closed, EIF_BOOLEAN op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_SYSTEM build_scm_write_mapping */
void _A665_421_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_SYSTEM build_scm_write_mapping */
void __A665_421_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_SYSTEM build_scm_read_mapping */
void _A665_417_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_SYSTEM build_scm_read_mapping */
void __A665_417_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_PARENT_LIST has_conforming_parent */
EIF_BOOLEAN _A694_68_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1646_16682)(open [1].it_r);
}

	/* ET_PARENT_LIST has_conforming_parent */
EIF_BOOLEAN __A694_68_1 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	return (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) F1646_16682)(op_1);
}

	/* ET_DYNAMIC_SYSTEM compile_all_features */
void _A1044_140_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_DYNAMIC_SYSTEM compile_all_features */
void __A1044_140_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_EIFFEL_SCANNER_SKELETON add_universe_full_name */
void _A1115_510_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* ET_EIFFEL_SCANNER_SKELETON add_universe_full_name */
void __A1115_510_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* ET_ECF_OPTIONS set_primary_assertion_value */
void _A1041_53_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* ET_ECF_OPTIONS set_primary_assertion_value */
void __A1041_53_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* ET_ECF_TARGET override_all_assertions_in_option */
void _A1135_198_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* ET_ECF_TARGET override_all_assertions_in_option */
void __A1135_198_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* ET_ECF_TARGET override_all_assertions_in_cluster */
void _A1135_196_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* ET_ECF_TARGET override_all_assertions_in_cluster */
void __A1135_196_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* ET_ECF_TARGET override_all_assertions_in_adapted_group */
void _A1135_197_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, closed [2].it_r);
}

	/* ET_ECF_TARGET override_all_assertions_in_adapted_group */
void __A1135_197_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2, closed [2].it_r);
}

	/* ET_ECF_TARGET override_all_assertions */
void _A1135_195_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2087_25152)(open [1].it_r, closed [1].it_r);
}

	/* ET_ECF_TARGET override_all_assertions */
void __A1135_195_1 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_1)
{
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) F2087_25152)(op_1, closed [1].it_r);
}

	/* ET_CLUSTER_DEPENDENCE_CONSTRAINT matches_pathname */
EIF_BOOLEAN _A1184_48_4 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	return f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, open [1].it_r);
}

	/* ET_CLUSTER_DEPENDENCE_CONSTRAINT matches_pathname */
EIF_BOOLEAN __A1184_48_4 ( EIF_BOOLEAN(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_4)
{
	return f_ptr (closed [1].it_r, closed [2].it_r, closed [3].it_r, op_4);
}

	/* ET_ECF_PARSER_SKELETON adapt_options */
void _A1187_367_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_ECF_PARSER_SKELETON adapt_options */
void __A1187_367_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_ECF_PARSER build_library */
void _A1188_380_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r, open [3].it_r, closed [2].it_r, closed [3].it_r);
}

	/* ET_ECF_PARSER build_library */
void __A1188_380_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3, EIF_REFERENCE op_4)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, closed [2].it_r, closed [3].it_r);
}

	/* ET_ECF_PARSER build_system_config */
void _A1188_377_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r, open [3].it_r, closed [2].it_r, closed [3].it_r);
}

	/* ET_ECF_PARSER build_system_config */
void __A1188_377_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3, EIF_REFERENCE op_4)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, closed [2].it_r, closed [3].it_r);
}

	/* ET_ECF_SYSTEM_PARSER override_target */
void _A1189_399_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r);
}

	/* ET_ECF_SYSTEM_PARSER override_target */
void __A1189_399_2 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2)
{
	f_ptr (closed [1].it_r, op_2);
}

	/* ET_ECF_SYSTEM_PARSER build_system */
void _A1189_379_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_TYPED_VALUE * open)
{
	f_ptr (closed [1].it_r, open [1].it_r, open [2].it_r, open [3].it_r, closed [2].it_r, closed [3].it_r, closed [4].it_r);
}

	/* ET_ECF_SYSTEM_PARSER build_system */
void __A1189_379_2_3_4 ( void(*f_ptr) (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE), EIF_TYPED_VALUE * closed, EIF_REFERENCE op_2, EIF_REFERENCE op_3, EIF_REFERENCE op_4)
{
	f_ptr (closed [1].it_r, op_2, op_3, op_4, closed [2].it_r, closed [3].it_r, closed [4].it_r);
}


#ifdef __cplusplus
}
#endif
