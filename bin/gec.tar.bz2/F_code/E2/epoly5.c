#include "epoly5.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R1819[796])();
void R1819_init () {
	R1819[0] = (char *(*)()) F205_1918;
	R1819[4] = (char *(*)()) F209_1951;
	R1819[5] = (char *(*)()) F207_1951;
	R1819[160] = (char *(*)()) F205_1918;
	R1819[794] = (char *(*)()) F208_1951;
	R1819[795] = (char *(*)()) F207_1951;
}

char *(*R1820[796])();
void R1820_init () {
	R1820[0] = (char *(*)()) F206_1943;
	R1820[4] = (char *(*)()) F209_1955;
	R1820[5] = (char *(*)()) F207_1955;
	R1820[160] = (char *(*)()) F206_1943;
	R1820[794] = (char *(*)()) F208_1955;
	R1820[795] = (char *(*)()) F207_1955;
}

char *(*R1827[796])();
void R1827_init () {
	R1827[0] = (char *(*)()) F206_1944;
	R1827[4] = (char *(*)()) F209_1956;
	R1827[5] = (char *(*)()) F207_1956;
	R1827[160] = (char *(*)()) F206_1944;
	R1827[794] = (char *(*)()) F208_1956;
	R1827[795] = (char *(*)()) F207_1956;
}

char *(*R1828[796])();
void R1828_init () {
	R1828[0] = (char *(*)()) F206_1945;
	R1828[4] = (char *(*)()) F209_1957;
	R1828[5] = (char *(*)()) F207_1957;
	R1828[160] = (char *(*)()) F206_1945;
	R1828[794] = (char *(*)()) F208_1957;
	R1828[795] = (char *(*)()) F207_1957;
}

char *(*R1842[796])();
void R1842_init () {
	R1842[0] = (char *(*)()) F206_1946;
	R1842[4] = (char *(*)()) F210_1967;
	R1842[5] = (char *(*)()) F211_1971;
	R1842[160] = (char *(*)()) F366_3602;
	R1842[794] = (char *(*)()) F1000_7558;
	R1842[795] = (char *(*)()) F1001_7564;
}

char *(*R1843[796])();
void R1843_init () {
	R1843[0] = (char *(*)()) F206_1947;
	R1843[4] = (char *(*)()) F210_1966;
	R1843[5] = (char *(*)()) F211_1970;
	R1843[160] = (char *(*)()) F206_1947;
	R1843[794] = (char *(*)()) F1000_7557;
	R1843[795] = (char *(*)()) F211_1970;
}

char *(*R1845[792])();
void R1845_init () {
	R1845[0] = (char *(*)()) F209_1949_1845_1;
	R1845[1] = (char *(*)()) F207_1949;
	R1845[790] = (char *(*)()) F208_1949_1845_1;
	R1845[791] = (char *(*)()) F207_1949;
}
static EIF_REFERENCE F209_1949_1845_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F209_1949(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1091, 0x00).id, 1091, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F208_1949_1845_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F208_1949(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R1848[792])();
void R1848_init () {
	R1848[0] = (char *(*)()) F210_1964;
	R1848[1] = (char *(*)()) F211_1968;
	R1848[790] = (char *(*)()) F1000_7555;
	R1848[791] = (char *(*)()) F211_1968;
}

char *(*R1859[337])();
void R1859_init () {
	R1859[0] = (char *(*)()) F1241_11630;
	R1859[1] = (char *(*)()) F1242_11635;
	R1859[2] = (char *(*)()) F1243_11642;
	R1859[328] = (char *(*)()) F1553_14030;
	R1859[329] = (char *(*)()) F1554_14030_1859_5;
	R1859[330] = (char *(*)()) F1555_14030_1859_5;
	R1859[331] = (char *(*)()) F1556_14030_1859_5;
	R1859[332] = (char *(*)()) F1557_14030_1859_5;
	R1859[333] = (char *(*)()) F1558_14030_1859_5;
	R1859[334] = (char *(*)()) F1559_14030_1859_5;
	R1859[335] = (char *(*)()) F1560_14030_1859_5;
	R1859[336] = (char *(*)()) F1553_14030;
}
static EIF_REFERENCE F1554_14030_1859_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1554_14030(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1091, 0x00).id, 1091, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1555_14030_1859_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1555_14030(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F1556_14030_1859_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1556_14030(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1091, 0x00).id, 1091, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1557_14030_1859_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F1557_14030(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(1109, 0x00).id, 1109, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1558_14030_1859_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1558_14030(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1559_14030_1859_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1559_14030(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_REFERENCE F1560_14030_1859_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1560_14030(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(1100, 0x00).id, 1100, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y1861_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype8[] = {0xFF01,1184,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype9[] = {0xFF01,1184,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype10[] = {0xFF01,1184,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype11[] = {0xFF01,1184,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype32[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype33[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype34[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype35[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype36[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype37[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype38[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype39[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype40[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype41[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype42[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype43[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype44[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype45[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype46[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype47[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype48[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype49[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype50[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype51[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y1861_pgtype52[] = {0xFF01,1184,0xFFFF};
EIF_TYPE_INDEX *Y1861_gen_type [1366];
EIF_TYPE_INDEX Y1861 [1366];
void Y1861_init (void)
{
	egc_routines_types [1861] = Y1861;
	egc_routines_gen_types [1861] = Y1861_gen_type;
	egc_routines_offset [1861] = 211;
	Y1861_gen_type [0] = Y1861_pgtype0;
	Y1861_gen_type [1] = Y1861_pgtype1;
	Y1861_gen_type [2] = Y1861_pgtype2;
	Y1861_gen_type [3] = Y1861_pgtype3;
	Y1861_gen_type [4] = Y1861_pgtype4;
	Y1861_gen_type [5] = Y1861_pgtype5;
	Y1861_gen_type [6] = Y1861_pgtype6;
	Y1861_gen_type [7] = Y1861_pgtype7;
	Y1861_gen_type [1028] = Y1861_pgtype8;
	Y1861_gen_type [1029] = Y1861_pgtype9;
	Y1861_gen_type [1030] = Y1861_pgtype10;
	Y1861_gen_type [1031] = Y1861_pgtype11;
	Y1861_gen_type [1227] = Y1861_pgtype12;
	Y1861_gen_type [1228] = Y1861_pgtype13;
	Y1861_gen_type [1229] = Y1861_pgtype14;
	Y1861_gen_type [1230] = Y1861_pgtype15;
	Y1861_gen_type [1231] = Y1861_pgtype16;
	Y1861_gen_type [1232] = Y1861_pgtype17;
	Y1861_gen_type [1233] = Y1861_pgtype18;
	Y1861_gen_type [1234] = Y1861_pgtype19;
	Y1861_gen_type [1276] = Y1861_pgtype20;
	Y1861_gen_type [1277] = Y1861_pgtype21;
	Y1861_gen_type [1278] = Y1861_pgtype22;
	Y1861_gen_type [1279] = Y1861_pgtype23;
	Y1861_gen_type [1280] = Y1861_pgtype24;
	Y1861_gen_type [1281] = Y1861_pgtype25;
	Y1861_gen_type [1282] = Y1861_pgtype26;
	Y1861_gen_type [1283] = Y1861_pgtype27;
	Y1861_gen_type [1341] = Y1861_pgtype28;
	Y1861_gen_type [1342] = Y1861_pgtype29;
	Y1861_gen_type [1343] = Y1861_pgtype30;
	Y1861_gen_type [1344] = Y1861_pgtype31;
	Y1861_gen_type [1345] = Y1861_pgtype32;
	Y1861_gen_type [1346] = Y1861_pgtype33;
	Y1861_gen_type [1347] = Y1861_pgtype34;
	Y1861_gen_type [1348] = Y1861_pgtype35;
	Y1861_gen_type [1349] = Y1861_pgtype36;
	Y1861_gen_type [1350] = Y1861_pgtype37;
	Y1861_gen_type [1351] = Y1861_pgtype38;
	Y1861_gen_type [1352] = Y1861_pgtype39;
	Y1861_gen_type [1353] = Y1861_pgtype40;
	Y1861_gen_type [1354] = Y1861_pgtype41;
	Y1861_gen_type [1355] = Y1861_pgtype42;
	Y1861_gen_type [1356] = Y1861_pgtype43;
	Y1861_gen_type [1357] = Y1861_pgtype44;
	Y1861_gen_type [1358] = Y1861_pgtype45;
	Y1861_gen_type [1359] = Y1861_pgtype46;
	Y1861_gen_type [1360] = Y1861_pgtype47;
	Y1861_gen_type [1361] = Y1861_pgtype48;
	Y1861_gen_type [1362] = Y1861_pgtype49;
	Y1861_gen_type [1363] = Y1861_pgtype50;
	Y1861_gen_type [1364] = Y1861_pgtype51;
	Y1861_gen_type [1365] = Y1861_pgtype52;
	{long i; for (i = 1028; i < 1032; i++) Y1861[i] = 1184;};
	Y1861[1365] = 1184;
}

char *(*R1863[749])();
void R1863_init () {
	{long i; for (i = 0; i < 3; i++) R1863[i] = (char *(*)()) F388_3701;}
	R1863[520] = (char *(*)()) F899_7044;
	{long i; for (i = 742; i < 746; i++) R1863[i] = (char *(*)()) F1130_9996;}
	{long i; for (i = 747; i < 749; i++) R1863[i] = (char *(*)()) F1130_9996;}
}

char *(*R1865[749])();
void R1865_init () {
	{long i; for (i = 0; i < 3; i++) R1865[i] = (char *(*)()) F388_3702;}
	R1865[520] = (char *(*)()) F907_7090;
	{long i; for (i = 742; i < 746; i++) R1865[i] = (char *(*)()) F1130_9997;}
	{long i; for (i = 747; i < 749; i++) R1865[i] = (char *(*)()) F1130_9997;}
}

char *(*R1866[749])();
void R1866_init () {
	{long i; for (i = 0; i < 3; i++) R1866[i] = (char *(*)()) F388_3703;}
	R1866[520] = (char *(*)()) F899_7048;
	{long i; for (i = 742; i < 746; i++) R1866[i] = (char *(*)()) F1130_9999;}
	{long i; for (i = 747; i < 749; i++) R1866[i] = (char *(*)()) F1130_9999;}
}


#ifdef __cplusplus
}
#endif
