#include "epoly2.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R1587[1897])();
void R1587_init () {
	R1587[0] = (char *(*)()) F164_1643;
	R1587[1] = (char *(*)()) F165_1646;
	{long i; for (i = 3; i < 5; i++) R1587[i] = (char *(*)()) F162_1630;}
	{long i; for (i = 6; i < 8; i++) R1587[i] = (char *(*)()) F162_1630;}
	{long i; for (i = 1052; i < 1055; i++) R1587[i] = (char *(*)()) F162_1630;}
	R1587[1895] = (char *(*)()) F2059_22093;
	R1587[1896] = (char *(*)()) F2060_22100;
}

char *(*R1590[2])();
void R1590_init () {
	R1590[0] = (char *(*)()) F164_1642;
	R1590[1] = (char *(*)()) F165_1645;
}

char *(*R1598[1894])();
void R1598_init () {
	{long i; for (i = 0; i < 2; i++) R1598[i] = (char *(*)()) F166_1648;}
	{long i; for (i = 3; i < 5; i++) R1598[i] = (char *(*)()) F166_1648;}
	{long i; for (i = 1049; i < 1052; i++) R1598[i] = (char *(*)()) F166_1648;}
	R1598[1892] = (char *(*)()) F2059_22092;
	R1598[1893] = (char *(*)()) F2060_22099;
}

char *(*R1660[1909])();
void R1660_init () {
	R1660[0] = (char *(*)()) F174_1724;
	R1660[1908] = (char *(*)()) F192_1811;
}

char *(*R1661[1909])();
void R1661_init () {
	R1661[0] = (char *(*)()) F174_1725;
	R1661[1908] = (char *(*)()) F192_1812;
}

char *(*R1662[1909])();
void R1662_init () {
	R1662[0] = (char *(*)()) F174_1726;
	R1662[1908] = (char *(*)()) F192_1813;
}

char *(*R1663[1909])();
void R1663_init () {
	R1663[0] = (char *(*)()) F174_1727;
	R1663[1908] = (char *(*)()) F192_1814;
}


#ifdef __cplusplus
}
#endif
