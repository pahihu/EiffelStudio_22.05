#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O1011[2];
void O1011_init () {
	O1011[0] = + _LNGOFF_1_0_0_1_;
	O1011[1] = + _LNGOFF_2_0_0_1_;
}

long O1350[4];
void O1350_init () {
	O1350[0] = 0;
	O1350[1] = + _CHROFF_0_0_;
	O1350[2] = 0;
	O1350[3] = + _CHROFF_1_0_;
}

long O1354[2];
void O1354_init () {
	O1354[0] =  + _REFACS_1_;
	O1354[1] = 0;
}

static EIF_TYPE_INDEX Y1391_pgtype0[] = {1540,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1391_pgtype1[] = {1540,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y1391_gen_type [2];
EIF_TYPE_INDEX Y1391 [2];
void Y1391_init (void)
{
	egc_routines_types [1391] = Y1391;
	egc_routines_gen_types [1391] = Y1391_gen_type;
	egc_routines_offset [1391] = 123;
	Y1391_gen_type [0] = Y1391_pgtype0;
	Y1391_gen_type [1] = Y1391_pgtype1;
	{long i; for (i = 0; i < 2; i++) Y1391[i] = 1540;};
}

static EIF_TYPE_INDEX Y1392_pgtype0[] = {1540,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1392_pgtype1[] = {1540,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y1392_gen_type [2];
EIF_TYPE_INDEX Y1392 [2];
void Y1392_init (void)
{
	egc_routines_types [1392] = Y1392;
	egc_routines_gen_types [1392] = Y1392_gen_type;
	egc_routines_offset [1392] = 123;
	Y1392_gen_type [0] = Y1392_pgtype0;
	Y1392_gen_type [1] = Y1392_pgtype1;
	{long i; for (i = 0; i < 2; i++) Y1392[i] = 1540;};
}

static EIF_TYPE_INDEX Y1412_pgtype0[] = {0xFF01,1540,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y1412_pgtype1[] = {0xFF01,1540,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y1412_gen_type [2];
EIF_TYPE_INDEX Y1412 [2];
void Y1412_init (void)
{
	egc_routines_types [1412] = Y1412;
	egc_routines_gen_types [1412] = Y1412_gen_type;
	egc_routines_offset [1412] = 123;
	Y1412_gen_type [0] = Y1412_pgtype0;
	Y1412_gen_type [1] = Y1412_pgtype1;
	{long i; for (i = 0; i < 2; i++) Y1412[i] = 1540;};
}

long O1561[7];
void O1561_init () {
	O1561[0] = 0;
	O1561[1] = + _LNGOFF_0_0_0_0_;
	O1561[2] = + _I64OFF_0_0_0_0_0_0_0_;
	O1561[3] = + _CHROFF_0_0_;
	O1561[4] = + _LNGOFF_0_0_0_0_;
	O1561[5] = 0;
	O1561[6] = + _LNGOFF_1_0_0_0_;
}

static EIF_TYPE_INDEX Y1593_pgtype0[] = {0xFF01,1540,0xFF01,161,0xFFFF};
static EIF_TYPE_INDEX Y1593_pgtype1[] = {0xFF01,1540,0xFF01,165,0xFFFF};
static EIF_TYPE_INDEX Y1593_pgtype2[] = {0xFF01,1540,0xFF01,163,0xFFFF};
EIF_TYPE_INDEX *Y1593_gen_type [3];
EIF_TYPE_INDEX Y1593 [3];
void Y1593_init (void)
{
	egc_routines_types [1593] = Y1593;
	egc_routines_gen_types [1593] = Y1593_gen_type;
	egc_routines_offset [1593] = 162;
	Y1593_gen_type [0] = Y1593_pgtype0;
	Y1593_gen_type [1] = Y1593_pgtype1;
	Y1593_gen_type [2] = Y1593_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y1593[i] = 1540;};
}

static EIF_TYPE_INDEX Y1689_pgtype0[] = {0xFF01,1540,0xFF01,369,0xFFFF};
static EIF_TYPE_INDEX Y1689_pgtype1[] = {0xFF01,1540,0xFF01,370,0xFFFF};
static EIF_TYPE_INDEX Y1689_pgtype2[] = {0xFF01,1540,0xFF01,371,0xFFFF};
static EIF_TYPE_INDEX Y1689_pgtype3[] = {0xFF01,1540,0xFF01,372,0xFFFF};
static EIF_TYPE_INDEX Y1689_pgtype4[] = {0xFF01,1540,0xFF01,1620,0xFFFF};
static EIF_TYPE_INDEX Y1689_pgtype5[] = {0xFF01,1540,0xFF01,1621,0xFFFF};
static EIF_TYPE_INDEX Y1689_pgtype6[] = {0xFF01,1540,0xFF01,1622,0xFFFF};
static EIF_TYPE_INDEX Y1689_pgtype7[] = {0xFF01,1540,0xFF01,1623,0xFFFF};
static EIF_TYPE_INDEX Y1689_pgtype8[] = {0xFF01,1540,0xFF01,1624,0xFFFF};
static EIF_TYPE_INDEX Y1689_pgtype9[] = {0xFF01,1540,0xFF01,1625,0xFFFF};
EIF_TYPE_INDEX *Y1689_gen_type [10];
EIF_TYPE_INDEX Y1689 [10];
void Y1689_init (void)
{
	egc_routines_types [1689] = Y1689;
	egc_routines_gen_types [1689] = Y1689_gen_type;
	egc_routines_offset [1689] = 177;
	Y1689_gen_type [0] = Y1689_pgtype0;
	Y1689_gen_type [1] = Y1689_pgtype1;
	Y1689_gen_type [2] = Y1689_pgtype2;
	Y1689_gen_type [3] = Y1689_pgtype3;
	Y1689_gen_type [4] = Y1689_pgtype4;
	Y1689_gen_type [5] = Y1689_pgtype5;
	Y1689_gen_type [6] = Y1689_pgtype6;
	Y1689_gen_type [7] = Y1689_pgtype7;
	Y1689_gen_type [8] = Y1689_pgtype8;
	Y1689_gen_type [9] = Y1689_pgtype9;
	{long i; for (i = 0; i < 10; i++) Y1689[i] = 1540;};
}

long O1777[1420];
void O1777_init () {
	{long i; for (i = 0; i < 3; i++) O1777[i] =  + _REFACS_4_;}
	{long i; for (i = 1417; i < 1420; i++) O1777[i] =  + _REFACS_11_;}
}

long O1787[1418];
void O1787_init () {
	O1787[0] = + _CHROFF_10_0_;
	O1787[1415] = + _CHROFF_97_0_;
	O1787[1416] = + _CHROFF_99_0_;
	O1787[1417] = + _CHROFF_110_0_;
}

long O1788[1418];
void O1788_init () {
	O1788[0] =  + _REFACS_5_;
	{long i; for (i = 1415; i < 1418; i++) O1788[i] =  + _REFACS_8_;}
}

long O1789[1418];
void O1789_init () {
	O1789[0] =  + _REFACS_6_;
	{long i; for (i = 1415; i < 1418; i++) O1789[i] =  + _REFACS_4_;}
}

long O1790[1418];
void O1790_init () {
	O1790[0] =  + _REFACS_7_;
	{long i; for (i = 1415; i < 1418; i++) O1790[i] =  + _REFACS_5_;}
}

long O1792[1418];
void O1792_init () {
	O1792[0] =  + _REFACS_8_;
	{long i; for (i = 1415; i < 1418; i++) O1792[i] =  + _REFACS_6_;}
}

long O1793[1418];
void O1793_init () {
	O1793[0] =  + _REFACS_9_;
	{long i; for (i = 1415; i < 1418; i++) O1793[i] =  + _REFACS_7_;}
}

long O1821[797];
void O1821_init () {
	{long i; for (i = 0; i < 2; i++) O1821[i] = + _LNGOFF_2_4_0_0_;}
	O1821[2] = + _LNGOFF_4_6_0_0_;
	O1821[3] = + _LNGOFF_3_7_0_0_;
	O1821[4] = + _LNGOFF_3_6_0_0_;
	O1821[5] = + _LNGOFF_4_6_0_0_;
	O1821[6] = + _LNGOFF_5_6_0_0_;
	O1821[161] = + _LNGOFF_2_4_0_0_;
	O1821[795] = + _LNGOFF_4_7_0_0_;
	O1821[796] = + _LNGOFF_6_6_0_0_;
}


#ifdef __cplusplus
}
#endif
