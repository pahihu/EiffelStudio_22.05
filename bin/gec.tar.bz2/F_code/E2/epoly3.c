#include "epoly3.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R1664[1909])();
void R1664_init () {
	R1664[0] = (char *(*)()) F174_1728;
	R1664[1908] = (char *(*)()) F192_1815;
}

char *(*R1665[1909])();
void R1665_init () {
	R1665[0] = (char *(*)()) F174_1729;
	R1665[1908] = (char *(*)()) F192_1816;
}

char *(*R1666[1909])();
void R1666_init () {
	R1666[0] = (char *(*)()) F174_1730;
	R1666[1908] = (char *(*)()) F192_1817;
}

char *(*R1667[1909])();
void R1667_init () {
	R1667[0] = (char *(*)()) F174_1731;
	R1667[1908] = (char *(*)()) F192_1818;
}

static EIF_TYPE_INDEX Y1688_pgtype0[] = {0xFF01,369,0xFFFF};
static EIF_TYPE_INDEX Y1688_pgtype1[] = {0xFF01,370,0xFFFF};
static EIF_TYPE_INDEX Y1688_pgtype2[] = {0xFF01,371,0xFFFF};
static EIF_TYPE_INDEX Y1688_pgtype3[] = {0xFF01,372,0xFFFF};
static EIF_TYPE_INDEX Y1688_pgtype4[] = {0xFF01,1620,0xFFFF};
static EIF_TYPE_INDEX Y1688_pgtype5[] = {0xFF01,1621,0xFFFF};
static EIF_TYPE_INDEX Y1688_pgtype6[] = {0xFF01,1622,0xFFFF};
static EIF_TYPE_INDEX Y1688_pgtype7[] = {0xFF01,1623,0xFFFF};
static EIF_TYPE_INDEX Y1688_pgtype8[] = {0xFF01,1624,0xFFFF};
static EIF_TYPE_INDEX Y1688_pgtype9[] = {0xFF01,1625,0xFFFF};
EIF_TYPE_INDEX *Y1688_gen_type [10];
EIF_TYPE_INDEX Y1688 [10];
void Y1688_init (void)
{
	egc_routines_types [1688] = Y1688;
	egc_routines_gen_types [1688] = Y1688_gen_type;
	egc_routines_offset [1688] = 177;
	Y1688_gen_type [0] = Y1688_pgtype0;
	Y1688_gen_type [1] = Y1688_pgtype1;
	Y1688_gen_type [2] = Y1688_pgtype2;
	Y1688_gen_type [3] = Y1688_pgtype3;
	Y1688_gen_type [4] = Y1688_pgtype4;
	Y1688_gen_type [5] = Y1688_pgtype5;
	Y1688_gen_type [6] = Y1688_pgtype6;
	Y1688_gen_type [7] = Y1688_pgtype7;
	Y1688_gen_type [8] = Y1688_pgtype8;
	Y1688_gen_type [9] = Y1688_pgtype9;
	Y1688[0] = 369;
	Y1688[1] = 370;
	Y1688[2] = 371;
	Y1688[3] = 372;
	Y1688[4] = 1620;
	Y1688[5] = 1621;
	Y1688[6] = 1622;
	Y1688[7] = 1623;
	Y1688[8] = 1624;
	Y1688[9] = 1625;
}

char *(*R1723[14])();
void R1723_init () {
	R1723[0] = (char *(*)()) F1585_14173;
	R1723[8] = (char *(*)()) F1591_15770;
	R1723[13] = (char *(*)()) F1597_15823;
}

char *(*R1726[14])();
void R1726_init () {
	R1726[0] = (char *(*)()) F1585_14178;
	R1726[8] = (char *(*)()) F1592_15800;
	R1726[13] = (char *(*)()) F1597_15826;
}

char *(*R1794[1418])();
void R1794_init () {
	R1794[0] = (char *(*)()) F203_1892;
	{long i; for (i = 1416; i < 1418; i++) R1794[i] = (char *(*)()) F301_3353;}
}

char *(*R1811[796])();
void R1811_init () {
	R1811[0] = (char *(*)()) F205_1910;
	R1811[4] = (char *(*)()) F210_1963;
	R1811[5] = (char *(*)()) F207_1948;
	R1811[160] = (char *(*)()) F205_1910;
	R1811[794] = (char *(*)()) F1000_7550;
	R1811[795] = (char *(*)()) F1001_7559;
}

char *(*R1816[796])();
void R1816_init () {
	R1816[0] = (char *(*)()) F205_1915;
	R1816[4] = (char *(*)()) F209_1950;
	R1816[5] = (char *(*)()) F207_1950;
	R1816[160] = (char *(*)()) F205_1915;
	R1816[794] = (char *(*)()) F208_1950;
	R1816[795] = (char *(*)()) F207_1950;
}


#ifdef __cplusplus
}
#endif
