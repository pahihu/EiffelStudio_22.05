#include "epoly6.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R1868[749])();
void R1868_init () {
	{long i; for (i = 0; i < 3; i++) R1868[i] = (char *(*)()) F388_3698;}
	R1868[520] = (char *(*)()) F907_7091;
	{long i; for (i = 742; i < 746; i++) R1868[i] = (char *(*)()) F1130_9987;}
	{long i; for (i = 747; i < 749; i++) R1868[i] = (char *(*)()) F1130_9987;}
}

char *(*R2015[2])();
void R2015_init () {
	R2015[0] = (char *(*)()) F228_2136;
	R2015[1] = (char *(*)()) F229_2140;
}

char *(*R2017[2])();
void R2017_init () {
	R2017[0] = (char *(*)()) F228_2137;
	R2017[1] = (char *(*)()) F229_2141;
}

char *(*R2222[2])();
void R2222_init () {
	R2222[0] = (char *(*)()) F238_2367;
	R2222[1] = (char *(*)()) F239_2374;
}

char *(*R2230[388])();
void R2230_init () {
	R2230[0] = (char *(*)()) F1211_10861;
	R2230[11] = (char *(*)()) F1222_11027;
	R2230[15] = (char *(*)()) F1226_11077;
	R2230[374] = (char *(*)()) F1585_14194;
	R2230[387] = (char *(*)()) F1597_15828;
}

char *(*R2233[388])();
void R2233_init () {
	R2233[0] = (char *(*)()) F241_2378;
	R2233[11] = (char *(*)()) F241_2378;
	R2233[15] = (char *(*)()) F241_2378;
	R2233[374] = (char *(*)()) F193_1826;
	R2233[387] = (char *(*)()) F193_1826;
}

char *(*R2236[388])();
void R2236_init () {
	R2236[0] = (char *(*)()) F1211_10866;
	R2236[11] = (char *(*)()) F1222_11026;
	R2236[15] = (char *(*)()) F1226_11071;
	R2236[374] = (char *(*)()) F1585_14179;
	R2236[387] = (char *(*)()) F1203_10814;
}

char *(*R2238[388])();
void R2238_init () {
	R2238[0] = (char *(*)()) F1211_10867;
	R2238[11] = (char *(*)()) F1222_11021;
	R2238[15] = (char *(*)()) F1226_11073;
	R2238[374] = (char *(*)()) F1585_14174;
	R2238[387] = (char *(*)()) F1591_15771;
}

char *(*R2239[388])();
void R2239_init () {
	R2239[0] = (char *(*)()) F1211_10868_2239_1;
	R2239[11] = (char *(*)()) F1222_11022_2239_1;
	R2239[15] = (char *(*)()) F1226_11074_2239_1;
	R2239[374] = (char *(*)()) F1585_14175;
	R2239[387] = (char *(*)()) F1598_15845_2239_1;
}
static EIF_REFERENCE F1211_10868_2239_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1211_10868(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1222_11022_2239_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1222_11022(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1226_11074_2239_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1226_11074(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1598_15845_2239_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1598_15845(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R2240[388])();
void R2240_init () {
	R2240[0] = (char *(*)()) F241_2385;
	R2240[11] = (char *(*)()) F241_2385;
	R2240[15] = (char *(*)()) F241_2385;
	R2240[374] = (char *(*)()) F1585_14184;
	R2240[387] = (char *(*)()) F1597_15834;
}

char *(*R2243[12])();
void R2243_init () {
	R2243[0] = (char *(*)()) F242_2387;
	R2243[1] = (char *(*)()) F243_2387_2243_1;
	R2243[2] = (char *(*)()) F244_2387_2243_1;
	R2243[3] = (char *(*)()) F245_2387_2243_1;
	R2243[4] = (char *(*)()) F242_2387;
	R2243[5] = (char *(*)()) F244_2387_2243_1;
	R2243[6] = (char *(*)()) F242_2387;
	R2243[7] = (char *(*)()) F243_2387_2243_1;
	R2243[8] = (char *(*)()) F244_2387_2243_1;
	R2243[9] = (char *(*)()) F245_2387_2243_1;
	R2243[10] = (char *(*)()) F242_2387;
	R2243[11] = (char *(*)()) F244_2387_2243_1;
}
static EIF_REFERENCE F243_2387_2243_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F243_2387(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(1121, 0x00).id, 1121, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F244_2387_2243_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F244_2387(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1091, 0x00).id, 1091, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F245_2387_2243_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F245_2387(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(1124, 0x00).id, 1124, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R2245[12])();
void R2245_init () {
	R2245[0] = (char *(*)()) F242_2389;
	R2245[1] = (char *(*)()) F243_2389_2245_4;
	R2245[2] = (char *(*)()) F244_2389_2245_4;
	R2245[3] = (char *(*)()) F245_2389_2245_4;
	R2245[4] = (char *(*)()) F242_2389;
	R2245[5] = (char *(*)()) F244_2389_2245_4;
	R2245[6] = (char *(*)()) F242_2389;
	R2245[7] = (char *(*)()) F243_2389_2245_4;
	R2245[8] = (char *(*)()) F244_2389_2245_4;
	R2245[9] = (char *(*)()) F245_2389_2245_4;
	R2245[10] = (char *(*)()) F242_2389;
	R2245[11] = (char *(*)()) F244_2389_2245_4;
}
static void F243_2389_2245_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F243_2389(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F244_2389_2245_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F244_2389(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F245_2389_2245_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F245_2389(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R2246[12])();
void R2246_init () {
	R2246[0] = (char *(*)()) F242_2390;
	R2246[1] = (char *(*)()) F243_2390_2246_4;
	R2246[2] = (char *(*)()) F244_2390_2246_4;
	R2246[3] = (char *(*)()) F245_2390_2246_4;
	R2246[4] = (char *(*)()) F242_2390;
	R2246[5] = (char *(*)()) F244_2390_2246_4;
	R2246[6] = (char *(*)()) F242_2390;
	R2246[7] = (char *(*)()) F243_2390_2246_4;
	R2246[8] = (char *(*)()) F244_2390_2246_4;
	R2246[9] = (char *(*)()) F245_2390_2246_4;
	R2246[10] = (char *(*)()) F242_2390;
	R2246[11] = (char *(*)()) F244_2390_2246_4;
}
static void F243_2390_2246_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F243_2390(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F244_2390_2246_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F244_2390(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F245_2390_2246_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F245_2390(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R2249[2])();
void R2249_init () {
	R2249[0] = (char *(*)()) F246_2392;
	R2249[1] = (char *(*)()) F247_2392_2249_1;
}
static EIF_REFERENCE F247_2392_2249_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F247_2392(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(1091, 0x00).id, 1091, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R2253[6])();
void R2253_init () {
	R2253[0] = (char *(*)()) F248_2396;
	R2253[1] = (char *(*)()) F249_2396;
	R2253[2] = (char *(*)()) F250_2396;
	R2253[3] = (char *(*)()) F251_2396;
	R2253[4] = (char *(*)()) F252_2399;
	R2253[5] = (char *(*)()) F253_2399;
}

char *(*R2254[6])();
void R2254_init () {
	R2254[0] = (char *(*)()) F248_2397;
	R2254[1] = (char *(*)()) F249_2397;
	R2254[2] = (char *(*)()) F250_2397;
	R2254[3] = (char *(*)()) F251_2397;
	R2254[4] = (char *(*)()) F248_2397;
	R2254[5] = (char *(*)()) F250_2397;
}

char *(*R2257[2])();
void R2257_init () {
	R2257[0] = (char *(*)()) F252_2401;
	R2257[1] = (char *(*)()) F253_2401;
}

char *(*R2258[2])();
void R2258_init () {
	R2258[0] = (char *(*)()) F252_2402;
	R2258[1] = (char *(*)()) F253_2402;
}

char *(*R2259[2])();
void R2259_init () {
	R2259[0] = (char *(*)()) F252_2403;
	R2259[1] = (char *(*)()) F253_2403;
}

char *(*R2264[1088])();
void R2264_init () {
	R2264[0] = (char *(*)()) F900_7071;
	R2264[733] = (char *(*)()) F255_2408;
	R2264[832] = (char *(*)()) F1732_17175;
	R2264[833] = (char *(*)()) F1733_17190;
	R2264[834] = (char *(*)()) F1734_17209;
	R2264[836] = (char *(*)()) F1722_17129;
	{long i; for (i = 837; i < 840; i++) R2264[i] = (char *(*)()) F1737_17237;}
	R2264[841] = (char *(*)()) F1740_17262;
	R2264[847] = (char *(*)()) F1747_17299;
	R2264[849] = (char *(*)()) F1719_17118;
	{long i; for (i = 856; i < 858; i++) R2264[i] = (char *(*)()) F1750_17341;}
	R2264[860] = (char *(*)()) F1750_17341;
	R2264[862] = (char *(*)()) F1750_17341;
	{long i; for (i = 864; i < 866; i++) R2264[i] = (char *(*)()) F1750_17341;}
	R2264[868] = (char *(*)()) F1767_17367;
	R2264[870] = (char *(*)()) F1769_17379;
	R2264[872] = (char *(*)()) F1722_17129;
	R2264[873] = (char *(*)()) F1773_17397;
	R2264[874] = (char *(*)()) F1774_17402;
	R2264[875] = (char *(*)()) F1722_17129;
	R2264[878] = (char *(*)()) F1722_17129;
	R2264[881] = (char *(*)()) F1769_17379;
	R2264[884] = (char *(*)()) F1784_17450;
	R2264[887] = (char *(*)()) F1722_17129;
	R2264[895] = (char *(*)()) F1719_17118;
	R2264[900] = (char *(*)()) F1719_17118;
	R2264[901] = (char *(*)()) F1767_17367;
	R2264[902] = (char *(*)()) F1769_17379;
	{long i; for (i = 903; i < 905; i++) R2264[i] = (char *(*)()) F1719_17118;}
	R2264[905] = (char *(*)()) F1740_17262;
	R2264[906] = (char *(*)()) F1767_17367;
	{long i; for (i = 917; i < 919; i++) R2264[i] = (char *(*)()) F1816_17622;}
	R2264[919] = (char *(*)()) F255_2408;
	R2264[920] = (char *(*)()) F1820_17647;
	{long i; for (i = 971; i < 973; i++) R2264[i] = (char *(*)()) F1870_18043;}
	R2264[1008] = (char *(*)()) F1908_18721;
	{long i; for (i = 1020; i < 1022; i++) R2264[i] = (char *(*)()) F1722_17129;}
	R2264[1024] = (char *(*)()) F1924_19055;
	{long i; for (i = 1025; i < 1027; i++) R2264[i] = (char *(*)()) F1722_17129;}
	{long i; for (i = 1028; i < 1030; i++) R2264[i] = (char *(*)()) F1722_17129;}
	{long i; for (i = 1031; i < 1034; i++) R2264[i] = (char *(*)()) F1722_17129;}
	{long i; for (i = 1035; i < 1038; i++) R2264[i] = (char *(*)()) F1722_17129;}
	{long i; for (i = 1039; i < 1044; i++) R2264[i] = (char *(*)()) F1722_17129;}
	R2264[1085] = (char *(*)()) F1719_17118;
	R2264[1087] = (char *(*)()) F1987_19672;
}

char *(*R2265[1088])();
void R2265_init () {
	R2265[0] = (char *(*)()) F899_7044;
	R2265[733] = (char *(*)()) F1633_16553;
	{long i; for (i = 832; i < 835; i++) R2265[i] = (char *(*)()) F1731_17160;}
	{long i; for (i = 836; i < 840; i++) R2265[i] = (char *(*)()) F1731_17160;}
	R2265[841] = (char *(*)()) F1731_17160;
	R2265[847] = (char *(*)()) F1731_17160;
	R2265[849] = (char *(*)()) F1731_17160;
	{long i; for (i = 856; i < 858; i++) R2265[i] = (char *(*)()) F1731_17160;}
	R2265[860] = (char *(*)()) F1731_17160;
	R2265[862] = (char *(*)()) F1731_17160;
	{long i; for (i = 864; i < 866; i++) R2265[i] = (char *(*)()) F1731_17160;}
	R2265[868] = (char *(*)()) F1731_17160;
	R2265[870] = (char *(*)()) F1731_17160;
	{long i; for (i = 872; i < 876; i++) R2265[i] = (char *(*)()) F1731_17160;}
	R2265[878] = (char *(*)()) F1731_17160;
	R2265[881] = (char *(*)()) F1731_17160;
	R2265[884] = (char *(*)()) F1731_17160;
	R2265[887] = (char *(*)()) F1731_17160;
	R2265[895] = (char *(*)()) F1731_17160;
	{long i; for (i = 900; i < 907; i++) R2265[i] = (char *(*)()) F1731_17160;}
	{long i; for (i = 917; i < 919; i++) R2265[i] = (char *(*)()) F1731_17160;}
	{long i; for (i = 919; i < 921; i++) R2265[i] = (char *(*)()) F1816_17616;}
	{long i; for (i = 971; i < 973; i++) R2265[i] = (char *(*)()) F1731_17160;}
	R2265[1008] = (char *(*)()) F1731_17160;
	{long i; for (i = 1020; i < 1022; i++) R2265[i] = (char *(*)()) F1731_17160;}
	{long i; for (i = 1024; i < 1027; i++) R2265[i] = (char *(*)()) F1731_17160;}
	{long i; for (i = 1028; i < 1030; i++) R2265[i] = (char *(*)()) F1731_17160;}
	{long i; for (i = 1031; i < 1034; i++) R2265[i] = (char *(*)()) F1731_17160;}
	{long i; for (i = 1035; i < 1038; i++) R2265[i] = (char *(*)()) F1731_17160;}
	{long i; for (i = 1039; i < 1044; i++) R2265[i] = (char *(*)()) F1731_17160;}
	R2265[1085] = (char *(*)()) F1985_19641;
	R2265[1087] = (char *(*)()) F1731_17160;
}

char *(*R2266[1088])();
void R2266_init () {
	R2266[0] = (char *(*)()) F899_7048;
	R2266[733] = (char *(*)()) F1003_7571;
	{long i; for (i = 832; i < 835; i++) R2266[i] = (char *(*)()) F1731_17167;}
	{long i; for (i = 836; i < 840; i++) R2266[i] = (char *(*)()) F1731_17167;}
	R2266[841] = (char *(*)()) F1731_17167;
	R2266[847] = (char *(*)()) F1731_17167;
	R2266[849] = (char *(*)()) F1731_17167;
	{long i; for (i = 856; i < 858; i++) R2266[i] = (char *(*)()) F1731_17167;}
	R2266[860] = (char *(*)()) F1731_17167;
	R2266[862] = (char *(*)()) F1731_17167;
	{long i; for (i = 864; i < 866; i++) R2266[i] = (char *(*)()) F1731_17167;}
	R2266[868] = (char *(*)()) F1731_17167;
	R2266[870] = (char *(*)()) F1731_17167;
	{long i; for (i = 872; i < 876; i++) R2266[i] = (char *(*)()) F1731_17167;}
	R2266[878] = (char *(*)()) F1731_17167;
	R2266[881] = (char *(*)()) F1731_17167;
	R2266[884] = (char *(*)()) F1731_17167;
	R2266[887] = (char *(*)()) F1731_17167;
	R2266[895] = (char *(*)()) F1731_17167;
	{long i; for (i = 900; i < 907; i++) R2266[i] = (char *(*)()) F1731_17167;}
	{long i; for (i = 917; i < 919; i++) R2266[i] = (char *(*)()) F1731_17167;}
	{long i; for (i = 919; i < 921; i++) R2266[i] = (char *(*)()) F1003_7571;}
	{long i; for (i = 971; i < 973; i++) R2266[i] = (char *(*)()) F1731_17167;}
	R2266[1008] = (char *(*)()) F1731_17167;
	{long i; for (i = 1020; i < 1022; i++) R2266[i] = (char *(*)()) F1731_17167;}
	{long i; for (i = 1024; i < 1027; i++) R2266[i] = (char *(*)()) F1731_17167;}
	{long i; for (i = 1028; i < 1030; i++) R2266[i] = (char *(*)()) F1731_17167;}
	{long i; for (i = 1031; i < 1034; i++) R2266[i] = (char *(*)()) F1731_17167;}
	{long i; for (i = 1035; i < 1038; i++) R2266[i] = (char *(*)()) F1731_17167;}
	{long i; for (i = 1039; i < 1044; i++) R2266[i] = (char *(*)()) F1731_17167;}
	R2266[1085] = (char *(*)()) F1985_19642;
	R2266[1087] = (char *(*)()) F1731_17167;
}

char *(*R2268[1826])();
void R2268_init () {
	{long i; for (i = 0; i < 5; i++) R2268[i] = (char *(*)()) F259_2637;}
	R2268[754] = (char *(*)()) F259_2637;
	{long i; for (i = 765; i < 774; i++) R2268[i] = (char *(*)()) F259_2637;}
	{long i; for (i = 775; i < 787; i++) R2268[i] = (char *(*)()) F259_2637;}
	R2268[787] = (char *(*)()) F1046_8509;
	{long i; for (i = 788; i < 793; i++) R2268[i] = (char *(*)()) F259_2637;}
	R2268[969] = (char *(*)()) F259_2637;
	R2268[972] = (char *(*)()) F1231_11425;
	R2268[987] = (char *(*)()) F1231_11425;
	R2268[1328] = (char *(*)()) F1587_15082;
	R2268[1810] = (char *(*)()) F259_2637;
	R2268[1825] = (char *(*)()) F259_2637;
}

char *(*R2269[1826])();
void R2269_init () {
	{long i; for (i = 0; i < 5; i++) R2269[i] = (char *(*)()) F259_2638;}
	R2269[754] = (char *(*)()) F259_2638;
	{long i; for (i = 765; i < 774; i++) R2269[i] = (char *(*)()) F259_2638;}
	{long i; for (i = 775; i < 787; i++) R2269[i] = (char *(*)()) F259_2638;}
	R2269[787] = (char *(*)()) F1046_8510;
	{long i; for (i = 788; i < 793; i++) R2269[i] = (char *(*)()) F259_2638;}
	R2269[969] = (char *(*)()) F259_2638;
	R2269[972] = (char *(*)()) F1231_11426;
	R2269[987] = (char *(*)()) F1231_11426;
	R2269[1328] = (char *(*)()) F1587_15083;
	R2269[1810] = (char *(*)()) F259_2638;
	R2269[1825] = (char *(*)()) F259_2638;
}


#ifdef __cplusplus
}
#endif
