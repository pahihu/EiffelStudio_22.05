
#ifndef _C38_fi1869_
#define _C38_fi1869_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F751_6470(EIF_REFERENCE);
extern void EIF_Minit1869(void);
extern char *(*R5698[])();

#ifdef __cplusplus
}
#endif

#endif
