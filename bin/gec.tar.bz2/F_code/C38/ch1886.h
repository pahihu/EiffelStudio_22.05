
#ifndef _C38_ch1886_
#define _C38_ch1886_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F860_6953(EIF_REFERENCE);
extern void EIF_Minit1886(void);

#ifdef __cplusplus
}
#endif

#endif
