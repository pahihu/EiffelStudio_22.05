
#ifndef _C38_co1868_
#define _C38_co1868_

#ifdef __cplusplus
extern "C" {
#endif

extern void F608_6372(EIF_REFERENCE);
extern void EIF_Minit1868(void);
extern long O5636[];

#ifdef __cplusplus
}
#endif

#endif
