
#ifndef _C38_re1874_
#define _C38_re1874_

#ifdef __cplusplus
extern "C" {
#endif

extern void F537_6258(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F537_6260(EIF_REFERENCE);
extern EIF_INTEGER_32 F537_6261(EIF_REFERENCE);
extern EIF_INTEGER_32 F537_6262(EIF_REFERENCE);
extern EIF_INTEGER_32 F537_6263(EIF_REFERENCE);
extern EIF_BOOLEAN F537_6271(EIF_REFERENCE);
extern EIF_BOOLEAN F537_6272(EIF_REFERENCE);
extern void F537_6277(EIF_REFERENCE);
extern void EIF_Minit1874(void);
extern char *(*R5910[])();
extern char *(*R5909[])();

#ifdef __cplusplus
}
#endif

#endif
