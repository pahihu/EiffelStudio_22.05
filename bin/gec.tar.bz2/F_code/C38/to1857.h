
#ifndef _C38_to1857_
#define _C38_to1857_

#ifdef __cplusplus
extern "C" {
#endif

extern void F424_5706(EIF_REFERENCE, EIF_INTEGER_32);
extern void F424_5707(EIF_REFERENCE, EIF_REAL_64, EIF_INTEGER_32);
extern void F424_5713(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1857(void);
extern void F926_7175(EIF_REFERENCE, EIF_REAL_64, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y5090[];
extern EIF_TYPE_INDEX *Y5090_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
