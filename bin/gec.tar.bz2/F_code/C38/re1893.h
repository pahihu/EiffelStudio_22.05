
#ifndef _C38_re1893_
#define _C38_re1893_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F777_6483(EIF_REFERENCE);
extern void F777_6485(EIF_REFERENCE);
extern void EIF_Minit1893(void);
extern char *(*R5701[])();
extern char *(*R5707[])();

#ifdef __cplusplus
}
#endif

#endif
