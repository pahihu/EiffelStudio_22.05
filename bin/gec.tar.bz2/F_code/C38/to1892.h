
#ifndef _C38_to1892_
#define _C38_to1892_

#ifdef __cplusplus
extern "C" {
#endif

extern void F425_5706(EIF_REFERENCE, EIF_INTEGER_32);
extern void F425_5707(EIF_REFERENCE, EIF_NATURAL_16, EIF_INTEGER_32);
extern void F425_5713(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1892(void);
extern void F927_7175(EIF_REFERENCE, EIF_NATURAL_16, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y5090[];
extern EIF_TYPE_INDEX *Y5090_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
