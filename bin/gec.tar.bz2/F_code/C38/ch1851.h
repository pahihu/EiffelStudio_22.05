
#ifndef _C38_ch1851_
#define _C38_ch1851_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F859_6953(EIF_REFERENCE);
extern void EIF_Minit1851(void);

#ifdef __cplusplus
}
#endif

#endif
