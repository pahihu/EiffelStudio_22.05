
#ifndef _C7_uc325_
#define _C7_uc325_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F426_5714_body(EIF_REFERENCE);
extern EIF_REFERENCE F426_5714(EIF_REFERENCE);
extern void EIF_Minit325(void);

#ifdef __cplusplus
}
#endif

#endif
