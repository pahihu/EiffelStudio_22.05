
#ifndef _C7_xm312_
#define _C7_xm312_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F401_5315(EIF_REFERENCE);
extern void EIF_Minit312(void);
extern void F1553_14026(EIF_REFERENCE);
extern void F1553_14042(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F397_5284(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
