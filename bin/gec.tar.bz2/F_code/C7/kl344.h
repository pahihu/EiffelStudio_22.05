
#ifndef _C7_kl344_
#define _C7_kl344_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F463_6151_body(EIF_REFERENCE);
extern EIF_REFERENCE F463_6151(EIF_REFERENCE);
extern void EIF_Minit344(void);

#ifdef __cplusplus
}
#endif

#endif
