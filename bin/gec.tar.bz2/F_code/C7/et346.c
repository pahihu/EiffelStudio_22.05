/*
 * Code for class ET_DOTNET_SIGNATURE_TESTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et346.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_DOTNET_SIGNATURE_TESTER}.make */
void F472_6154 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {ET_DOTNET_SIGNATURE_TESTER}.test */
EIF_BOOLEAN F472_6155 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(10);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLR(8,loc1);
	RTLR(9,loc2);
	RTLIU(10);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == arg2)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		if ((EIF_BOOLEAN)(arg1 == NULL)) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			if ((EIF_BOOLEAN)(arg2 == NULL)) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
				tr2 = *(EIF_REFERENCE *)(RTCW(arg2));
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R8486[Dtype(RTCW(tr1))-1183])(tr1, tr2);
				if (tb1) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc3 = (RTNA((RTCW(arg1))), ((EIF_REFERENCE) 0));
					loc4 = (RTNA((RTCW(arg2))), ((EIF_REFERENCE) 0));
					loc5 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_11_);
					loc6 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_11_);
					if ((EIF_BOOLEAN)(loc3 == NULL)) {
						if ((EIF_BOOLEAN)(loc4 != NULL)) {
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
					} else {
						if ((EIF_BOOLEAN)(loc4 == NULL)) {
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						} else {
							tb1 = F1884_18232(RTCW(loc3), loc4, loc6, loc5);
							if ((EIF_BOOLEAN) !tb1) {
								Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							}
						}
					}
					loc1 = (RTNA((RTCW(arg1))), ((EIF_REFERENCE) 0));
					loc2 = (RTNA((RTCW(arg2))), ((EIF_REFERENCE) 0));
					tb1 = '\01';
					if (!(EIF_BOOLEAN)(loc1 == NULL)) {
						tb2 = F1003_7573(RTCW(loc1));
						tb1 = tb2;
					}
					if (tb1) {
						tb1 = '\0';
						if ((EIF_BOOLEAN)(loc2 != NULL)) {
							tb2 = F1003_7573(RTCW(loc2));
							tb1 = (EIF_BOOLEAN) !tb2;
						}
						if (tb1) {
							RTLE;
							return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						}
					} else {
						tb1 = '\01';
						if (!(EIF_BOOLEAN)(loc2 == NULL)) {
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_3_0_0_0_);
							ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_3_0_0_0_);
							tb1 = (EIF_BOOLEAN)(ti4_1 != ti4_2);
						}
						if (tb1) {
							RTLE;
							return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						} else {
							loc8 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_3_0_0_0_);
							loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							for (;;) {
								if ((EIF_BOOLEAN) (loc7 > loc8)) break;
								tr1 = F1649_16721(RTCW(loc1), loc7);
								tr1 = F1814_17596(RTCW(tr1));
								tr2 = F1649_16721(RTCW(loc2), loc7);
								tr2 = F1814_17596(RTCW(tr2));
								tb1 = F1884_18232(RTCW(tr1), tr2, loc6, loc5);
								if ((EIF_BOOLEAN) !tb1) {
									Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
								} else {
									loc7++;
								}
							}
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit346 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
