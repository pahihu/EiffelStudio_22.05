
#ifndef _C7_et349_
#define _C7_et349_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F475_6158(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit349(void);
extern EIF_BOOLEAN F1987_19688(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
