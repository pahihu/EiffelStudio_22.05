
#ifndef _C7_io337_
#define _C7_io337_

#ifdef __cplusplus
extern "C" {
#endif

extern void F438_6012(EIF_REFERENCE);
extern void EIF_Minit337(void);
extern void F802_6583(EIF_REFERENCE);
extern EIF_BOOLEAN F802_6555(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
