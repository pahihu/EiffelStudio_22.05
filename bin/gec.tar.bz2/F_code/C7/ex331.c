/*
 * Code for class EXECUTION_ENVIRONMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ex331.h"
#include <eif_system.h>
#include "eif_dir.h"
#include <stdlib.h>
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F432_5884
static EIF_POINTER inline_F432_5884 (EIF_POINTER arg1)
{
	#ifdef EIF_WINDOWS
	return _wgetenv ((EIF_NATIVE_CHAR *) arg1);
#else
	return getenv ((EIF_NATIVE_CHAR *) arg1);
#endif
	;
}
#define INLINE_F432_5884
#endif
#ifndef INLINE_F432_5871
static EIF_NATURAL_32 inline_F432_5871 (void)
{
	#ifdef EIF_WINDOWS
	SYSTEM_INFO SysInfo;
	ZeroMemory (&SysInfo, sizeof (SYSTEM_INFO));
	GetSystemInfo (&SysInfo);
	return (EIF_NATURAL_32) SysInfo.dwNumberOfProcessors;
#elif defined(EIF_MACOSX)
		/* MacOS X < 10.4 */
	int nm [2];
	size_t len = 4;
	uint32_t count;
	nm [0] = CTL_HW; nm [1] = HW_AVAILCPU;
	sysctl (nm, 2, &count, &len, NULL, 0);
	if(count < 1) {
		nm[1] = HW_NCPU;
		sysctl(nm, 2, &count, &len, NULL, 0);
		if (count < 1) {count = 1;}
	}
	return (EIF_NATURAL_32) count;
#else
		/* Linux, Solaris, AIX, Mac OS X >=10.4 (i.e. Tiger onwards), ... */
	return (EIF_NATURAL_32) sysconf(_SC_NPROCESSORS_ONLN);
#endif
	;
}
#define INLINE_F432_5871
#endif
#ifndef INLINE_F432_5885
static EIF_INTEGER_32 inline_F432_5885 (EIF_POINTER arg1)
{
	#ifdef EIF_WINDOWS
	return _wputenv ((EIF_NATIVE_CHAR *) arg1);
#else
	return putenv ((EIF_NATIVE_CHAR *) arg1);
#endif
	;
}
#define INLINE_F432_5885
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EXECUTION_ENVIRONMENT}.current_working_path */
EIF_REFERENCE F432_5858 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc3);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 50L);
	loc3 = RTLNS(eif_new_type(404, 0x01).id, 404, _OBJSIZ_0_1_0_1_0_1_1_0_);
	F405_5357(RTCW(loc3), loc1);
	tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
	loc2 = (EIF_INTEGER_32) eif_dir_current((EIF_FILENAME) tp1, (EIF_INTEGER) loc1);
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) -1L))) {
		Result = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_2_1_0_0_0_0_0_0_);
		tr1 = RTMS_EX_H(".",1,46);
		F1054_8705(RTCW(Result), tr1);
	} else {
		if ((EIF_BOOLEAN) (loc2 > loc1)) {
			loc1 = (EIF_INTEGER_32) loc2;
			F405_5447(RTCW(loc3), loc1);
			tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
			loc2 = (EIF_INTEGER_32) eif_dir_current((EIF_FILENAME) tp1, (EIF_INTEGER) loc1);
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc2 <= loc1))) {
			Result = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_2_1_0_0_0_0_0_0_);
			tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
			F1054_8709(RTCW(Result), tp1);
		} else {
			Result = RTLNS(eif_new_type(1053, 0x01).id, 1053, _OBJSIZ_2_1_0_0_0_0_0_0_);
			tr1 = RTMS_EX_H(".",1,46);
			F1054_8705(RTCW(Result), tr1);
		}
	}
	RTLE;
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.default_shell */
static EIF_REFERENCE F432_5860_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(499)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTMS_EX_H("SHELL",5,1213138508);
	Result = F432_5862(Current, tr1);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN)(Result != NULL)) {
		tr1 = RTLNS(eif_new_type(1181, 0x01).id, 1181, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1177_10174(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
	}
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F432_5860 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(499,F432_5860_body,(Current));
}

/* {EXECUTION_ENVIRONMENT}.item */
EIF_REFERENCE F432_5862 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(427, 0x01).id, 427, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F428_5717(RTCW(loc1), arg1);
	tp1 = F428_5724(RTCW(loc1));
	loc2 = inline_F432_5884(tp1);
	tb1 = !loc2;
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTLNS(eif_new_type(427, 0x01).id, 427, _OBJSIZ_1_0_0_1_0_0_0_0_);
		F428_5719(RTCW(tr1), loc2);
		Result = F428_5722(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.available_cpu_count */
EIF_NATURAL_32 F432_5871 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	Result = inline_F432_5871 ();
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.put */
void F432_5875 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLR(5,tr1);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1181, 0x01).id, 1181, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8302[Dtype(RTCW(arg1))-1180])(arg1);
	ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8302[Dtype(RTCW(arg2))-1180])(arg2);
	F1180_10304(RTCW(loc1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + ((EIF_INTEGER_32) 1L)));
	F1182_10418(RTCW(loc1), arg2);
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '=';
	F1182_10432(RTCW(loc1), tw1);
	F1182_10418(RTCW(loc1), arg1);
	loc2 = RTLNS(eif_new_type(427, 0x01).id, 427, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F428_5717(RTCW(loc2), loc1);
	tr1 = RTOUCR(500,F432_5879, (Current));
	tr2 = RTLNS(eif_new_type(1180, 0x01).id, 1180, _OBJSIZ_1_0_0_4_0_0_0_0_);
	F1181_10357(RTCW(tr2), arg2);
	F989_7441(RTCW(tr1), loc2, tr2);
	tp1 = F428_5724(RTCW(loc2));
	ti4_1 = inline_F432_5885(tp1);
	*(EIF_INTEGER_32 *)(Current + O5251[Dtype(Current)-431]) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {EXECUTION_ENVIRONMENT}.system */
void F432_5876 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8280[Dtype(RTCW(arg1))-1180])(arg1);
	if (tb1) {
		loc1 = RTLNS(eif_new_type(427, 0x01).id, 427, _OBJSIZ_1_0_0_1_0_0_0_0_);
		tr1 = RTOUCR(499,F432_5860, (Current));
		F428_5717(RTCW(loc1), tr1);
	} else {
		loc1 = RTLNS(eif_new_type(427, 0x01).id, 427, _OBJSIZ_1_0_0_1_0_0_0_0_);
		F428_5717(RTCW(loc1), arg1);
	}
	tp1 = F428_5724(RTCW(loc1));
	ti4_1 = F432_5887(Current, tp1);
	*(EIF_INTEGER_32 *)(Current + O5251[Dtype(Current)-431]) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {EXECUTION_ENVIRONMENT}.environ */
static EIF_REFERENCE F432_5879_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(500)

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,988,0xFF01,427,0xFF01,1180,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 988, _OBJSIZ_7_3_0_7_0_0_0_0_);
	}
	F989_7394(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F432_5879 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(500,F432_5879_body,(Current));
}

/* {EXECUTION_ENVIRONMENT}.eif_dir_current */
EIF_INTEGER_32 F432_5883 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_dir_current((EIF_FILENAME) arg1, (EIF_INTEGER) arg2);
	
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.eif_getenv */
EIF_POINTER F432_5884 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F432_5884 ((EIF_POINTER) arg1);
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.eif_putenv */
EIF_INTEGER_32 F432_5885 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F432_5885 ((EIF_POINTER) arg1);
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.system_call */
EIF_INTEGER_32 F432_5887 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	EIF_ENTER_C;Result = (EIF_INTEGER_32) eif_system(arg1);
	
	EIF_EXIT_C;
	RTGC;
	return Result;
}

void EIF_Minit331 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
