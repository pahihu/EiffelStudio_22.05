
#ifndef _C7_et300_
#define _C7_et300_

#ifdef __cplusplus
extern "C" {
#endif

extern void F389_3710(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F389_3712(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit300(void);
extern void F388_3706(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F388_3698(EIF_REFERENCE, EIF_REFERENCE);
extern void F2046_21728(EIF_REFERENCE);
extern EIF_BOOLEAN F1290_12726(EIF_REFERENCE);
extern void F388_3704(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2562[])();
extern char *(*R3114[])();
extern char *(*R8125[])();
extern char *(*R2552[])();
extern char *(*R3107[])();
extern char *(*R6004[])();

#ifdef __cplusplus
}
#endif

#endif
