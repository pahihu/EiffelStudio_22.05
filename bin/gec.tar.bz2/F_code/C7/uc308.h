
#ifndef _C7_uc308_
#define _C7_uc308_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F397_5284_body(EIF_REFERENCE);
extern EIF_REFERENCE F397_5284(EIF_REFERENCE);
extern void EIF_Minit308(void);

#ifdef __cplusplus
}
#endif

#endif
