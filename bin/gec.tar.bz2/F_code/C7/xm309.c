/*
 * Code for class XM_UNICODE_STRUCTURE_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm309.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_UNICODE_STRUCTURE_FACTORY}.same_string */
EIF_BOOLEAN F398_5285 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOUCR(534,F397_5284, (Current));
	Result = F1229_11122(RTCW(tr1), arg1, arg2);
	RTLE;
	return Result;
}

/* {XM_UNICODE_STRUCTURE_FACTORY}.new_string_bilinked_list */
EIF_REFERENCE F398_5287 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1517,0xFF01,1184,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1517, _OBJSIZ_4_0_0_1_0_0_0_0_);
	}
	F1513_13604(RTCW(Result));
	tr1 = RTOUCR(534,F397_5284, (Current));
	F1459_13425(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {XM_UNICODE_STRUCTURE_FACTORY}.new_string_queue */
EIF_REFERENCE F398_5290 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1525,0xFF01,1184,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1525, _OBJSIZ_3_0_0_1_0_0_0_0_);
	}
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_UNICODE_STRUCTURE_FACTORY}.new_detachable_string_queue */
EIF_REFERENCE F398_5291 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1525,1184,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1525, _OBJSIZ_3_0_0_1_0_0_0_0_);
	}
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {XM_UNICODE_STRUCTURE_FACTORY}.new_string_string_table */
EIF_REFERENCE F398_5292 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1568,0xFF01,1184,0xFF01,1184,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1568, _OBJSIZ_11_0_0_9_0_0_0_0_);
	}
	F1553_14026(RTCW(Result));
	tr1 = RTOUCR(534,F397_5284, (Current));
	F1553_14042(RTCW(Result), tr1);
	tr1 = RTOUCR(534,F397_5284, (Current));
	F1459_13425(RTCW(Result), tr1);
	RTLE;
	return Result;
}

void EIF_Minit309 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
