
#ifndef _C7_et347_
#define _C7_et347_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F473_6156(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit347(void);
extern char *(*R14586[])();

#ifdef __cplusplus
}
#endif

#endif
