
#ifndef _C7_ut324_
#define _C7_ut324_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F413_5701_body(EIF_REFERENCE);
extern EIF_REFERENCE F413_5701(EIF_REFERENCE);
static EIF_REFERENCE F413_5704_body(EIF_REFERENCE);
extern EIF_REFERENCE F413_5704(EIF_REFERENCE);
extern void EIF_Minit324(void);

#ifdef __cplusplus
}
#endif

#endif
