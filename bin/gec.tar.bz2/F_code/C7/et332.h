
#ifndef _C7_et332_
#define _C7_et332_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F433_5893_body(EIF_REFERENCE);
extern EIF_REFERENCE F433_5893(EIF_REFERENCE);
extern void EIF_Minit332(void);

#ifdef __cplusplus
}
#endif

#endif
