
#ifndef _C7_kl342_
#define _C7_kl342_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F461_6141_body(EIF_REFERENCE);
extern EIF_REFERENCE F461_6141(EIF_REFERENCE);
extern void EIF_Minit342(void);

#ifdef __cplusplus
}
#endif

#endif
