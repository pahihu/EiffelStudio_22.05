/*
 * Code for class ET_TOKEN_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et307.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_TOKEN_CONSTANTS}.any_class_name */
static EIF_REFERENCE F396_4208_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(568)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1954,F396_4719, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4208 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(568,F396_4208_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.arguments_32_class_name */
static EIF_REFERENCE F396_4209_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1955)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1956,F396_4720, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4209 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1955,F396_4209_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.array_class_name */
static EIF_REFERENCE F396_4210_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(570)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1957,F396_4721, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4210 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(570,F396_4210_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.boolean_class_name */
static EIF_REFERENCE F396_4211_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(572)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1958,F396_4722, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4211 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(572,F396_4211_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.character_class_name */
static EIF_REFERENCE F396_4212_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(448)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1959,F396_4723, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4212 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(448,F396_4212_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.character_8_class_name */
static EIF_REFERENCE F396_4213_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(573)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1960,F396_4724, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4213 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(573,F396_4213_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.character_32_class_name */
static EIF_REFERENCE F396_4214_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(574)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1961,F396_4725, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4214 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(574,F396_4214_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.com_failure_class_name */
static EIF_REFERENCE F396_4215_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1962)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1963,F396_4726, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4215 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1962,F396_4215_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.disposable_class_name */
static EIF_REFERENCE F396_4216_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1964)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1965,F396_4727, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4216 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1964,F396_4216_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.double_class_name */
static EIF_REFERENCE F396_4217_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(465)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1966,F396_4728, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4217 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(465,F396_4217_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.exception_class_name */
static EIF_REFERENCE F396_4218_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(575)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1967,F396_4729, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4218 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(575,F396_4218_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.exception_manager_class_name */
static EIF_REFERENCE F396_4219_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(576)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1968,F396_4730, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4219 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(576,F396_4219_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.exception_manager_factory_class_name */
static EIF_REFERENCE F396_4220_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1969)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1970,F396_4731, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4220 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1969,F396_4220_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.function_class_name */
static EIF_REFERENCE F396_4221_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(577)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(224,F396_4732, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4221 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(577,F396_4221_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.identified_routines_class_name */
static EIF_REFERENCE F396_4222_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1971)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1972,F396_4733, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4222 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1971,F396_4222_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.immutable_string_8_class_name */
static EIF_REFERENCE F396_4223_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(578)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1973,F396_4734, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4223 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(578,F396_4223_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.immutable_string_32_class_name */
static EIF_REFERENCE F396_4224_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(579)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1974,F396_4735, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4224 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(579,F396_4224_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_class_name */
static EIF_REFERENCE F396_4225_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(452)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1975,F396_4736, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4225 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(452,F396_4225_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_8_class_name */
static EIF_REFERENCE F396_4226_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(580)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1976,F396_4737, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4226 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(580,F396_4226_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_16_class_name */
static EIF_REFERENCE F396_4227_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(581)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1977,F396_4738, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4227 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(581,F396_4227_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_32_class_name */
static EIF_REFERENCE F396_4228_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(582)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1978,F396_4739, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4228 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(582,F396_4228_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_64_class_name */
static EIF_REFERENCE F396_4229_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(583)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1979,F396_4740, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4229 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(583,F396_4229_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.ise_exception_manager_class_name */
static EIF_REFERENCE F396_4231_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(584)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1980,F396_4742, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4231 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(584,F396_4231_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.ise_runtime_class_name */
static EIF_REFERENCE F396_4232_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1981)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1982,F396_4743, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4232 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1981,F396_4232_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.iterable_class_name */
static EIF_REFERENCE F396_4233_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(585)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1983,F396_4744, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4233 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(585,F396_4233_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.iteration_cursor_class_name */
static EIF_REFERENCE F396_4234_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1984)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1985,F396_4745, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4234 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1984,F396_4234_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.memory_class_name */
static EIF_REFERENCE F396_4235_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1986)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1987,F396_4746, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4235 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1986,F396_4235_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.native_array_class_name */
static EIF_REFERENCE F396_4236_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(629)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1988,F396_4747, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4236 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(629,F396_4236_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_class_name */
static EIF_REFERENCE F396_4237_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(457)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1989,F396_4748, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4237 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(457,F396_4237_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_8_class_name */
static EIF_REFERENCE F396_4238_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(586)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1990,F396_4749, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4238 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(586,F396_4238_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_16_class_name */
static EIF_REFERENCE F396_4239_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(587)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1991,F396_4750, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4239 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(587,F396_4239_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_32_class_name */
static EIF_REFERENCE F396_4240_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(588)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1992,F396_4751, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4240 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(588,F396_4240_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_64_class_name */
static EIF_REFERENCE F396_4241_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(589)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1993,F396_4752, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4241 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(589,F396_4241_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.none_class_name */
static EIF_REFERENCE F396_4242_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(521)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1994,F396_4753, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4242 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(521,F396_4242_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.platform_class_name */
static EIF_REFERENCE F396_4243_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1995)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1996,F396_4754, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4243 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1995,F396_4243_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.pointer_class_name */
static EIF_REFERENCE F396_4244_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(590)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1997,F396_4755, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4244 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(590,F396_4244_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.predicate_class_name */
static EIF_REFERENCE F396_4245_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(591)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1998,F396_4756, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4245 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(591,F396_4245_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.procedure_class_name */
static EIF_REFERENCE F396_4246_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(592)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(226,F396_4757, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4246 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(592,F396_4246_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.real_class_name */
static EIF_REFERENCE F396_4247_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(463)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(1999,F396_4758, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4247 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(463,F396_4247_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.real_32_class_name */
static EIF_REFERENCE F396_4248_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(593)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2000,F396_4759, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4248 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(593,F396_4248_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.real_64_class_name */
static EIF_REFERENCE F396_4249_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(594)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2001,F396_4760, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4249 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(594,F396_4249_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.routine_class_name */
static EIF_REFERENCE F396_4250_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(595)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2002,F396_4761, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4250 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(595,F396_4250_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.special_class_name */
static EIF_REFERENCE F396_4251_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(596)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2003,F396_4762, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4251 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(596,F396_4251_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.string_class_name */
static EIF_REFERENCE F396_4252_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(597)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2004,F396_4763, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4252 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(597,F396_4252_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.string_8_class_name */
static EIF_REFERENCE F396_4253_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(598)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2005,F396_4764, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4253 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(598,F396_4253_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.string_32_class_name */
static EIF_REFERENCE F396_4254_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(599)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2006,F396_4765, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4254 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(599,F396_4254_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.system_object_class_name */
static EIF_REFERENCE F396_4255_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(600)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2007,F396_4766, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4255 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(600,F396_4255_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.system_string_class_name */
static EIF_REFERENCE F396_4256_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(601)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2008,F396_4767, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4256 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(601,F396_4256_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.tuple_class_name */
static EIF_REFERENCE F396_4257_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(602)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2009,F396_4768, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4257 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(602,F396_4257_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.type_class_name */
static EIF_REFERENCE F396_4258_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(603)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2010,F396_4769, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4258 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(603,F396_4258_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.typed_pointer_class_name */
static EIF_REFERENCE F396_4259_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(605)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2011,F396_4770, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4259 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(605,F396_4259_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.wide_character_class_name */
static EIF_REFERENCE F396_4260_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(450)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2012,F396_4771, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4260 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(450,F396_4260_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.unknown_class_name */
static EIF_REFERENCE F396_4261_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(637)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2013,F396_4772, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4261 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(637,F396_4261_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.boolean_ref_class_name */
static EIF_REFERENCE F396_4262_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2014)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2015,F396_5210, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4262 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2014,F396_4262_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.character_ref_class_name */
static EIF_REFERENCE F396_4263_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(620)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2016,F396_5211, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4263 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(620,F396_4263_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.character_8_ref_class_name */
static EIF_REFERENCE F396_4264_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(614)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2017,F396_5212, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4264 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(614,F396_4264_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.character_32_ref_class_name */
static EIF_REFERENCE F396_4265_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(619)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2018,F396_5213, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4265 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(619,F396_4265_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.double_ref_class_name */
static EIF_REFERENCE F396_4266_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(621)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2019,F396_5214, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4266 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(621,F396_4266_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_ref_class_name */
static EIF_REFERENCE F396_4267_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(622)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2020,F396_5215, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4267 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(622,F396_4267_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_8_ref_class_name */
static EIF_REFERENCE F396_4268_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2021)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2022,F396_5216, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4268 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2021,F396_4268_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_16_ref_class_name */
static EIF_REFERENCE F396_4269_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2023)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2024,F396_5217, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4269 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2023,F396_4269_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_32_ref_class_name */
static EIF_REFERENCE F396_4270_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(616)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2025,F396_5218, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4270 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(616,F396_4270_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_64_ref_class_name */
static EIF_REFERENCE F396_4271_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2026)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2027,F396_5219, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4271 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2026,F396_4271_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_ref_class_name */
static EIF_REFERENCE F396_4272_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(623)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2028,F396_5220, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4272 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(623,F396_4272_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_8_ref_class_name */
static EIF_REFERENCE F396_4273_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2029)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2030,F396_5221, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4273 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2029,F396_4273_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_16_ref_class_name */
static EIF_REFERENCE F396_4274_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2031)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2032,F396_5222, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4274 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2031,F396_4274_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_32_ref_class_name */
static EIF_REFERENCE F396_4275_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(617)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2033,F396_5223, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4275 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(617,F396_4275_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_64_ref_class_name */
static EIF_REFERENCE F396_4276_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2034)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2035,F396_5224, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4276 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2034,F396_4276_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.pointer_ref_class_name */
static EIF_REFERENCE F396_4277_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2036)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2037,F396_5225, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4277 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2036,F396_4277_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.real_ref_class_name */
static EIF_REFERENCE F396_4278_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(624)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2038,F396_5226, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4278 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(624,F396_4278_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.real_32_ref_class_name */
static EIF_REFERENCE F396_4279_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(618)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2039,F396_5227, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4279 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(618,F396_4279_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.real_64_ref_class_name */
static EIF_REFERENCE F396_4280_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(615)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2040,F396_5228, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4280 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(615,F396_4280_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.wide_character_ref_class_name */
static EIF_REFERENCE F396_4281_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(625)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2041,F396_5229, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4281 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(625,F396_4281_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.after_feature_name */
static EIF_REFERENCE F396_4282_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(692)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(767,F396_4773, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4282 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(692,F396_4282_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.aliased_resized_area_feature_name */
static EIF_REFERENCE F396_4283_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2042)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2043,F396_4774, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4283 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2042,F396_4283_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.area_feature_name */
static EIF_REFERENCE F396_4284_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(81)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2044,F396_4775, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4284 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(81,F396_4284_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.argument_count_feature_name */
static EIF_REFERENCE F396_4285_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2045)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2046,F396_4776, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4285 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2045,F396_4285_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.as_integer_8_feature_name */
static EIF_REFERENCE F396_4286_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2047)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2048,F396_4777, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4286 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2047,F396_4286_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.as_integer_16_feature_name */
static EIF_REFERENCE F396_4287_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2049)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2050,F396_4778, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4287 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2049,F396_4287_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.as_integer_32_feature_name */
static EIF_REFERENCE F396_4288_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2051)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2052,F396_4779, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4288 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2051,F396_4288_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.as_integer_64_feature_name */
static EIF_REFERENCE F396_4289_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2053)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2054,F396_4780, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4289 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2053,F396_4289_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.as_natural_8_feature_name */
static EIF_REFERENCE F396_4290_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2055)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2056,F396_4781, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4290 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2055,F396_4290_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.as_natural_16_feature_name */
static EIF_REFERENCE F396_4291_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2057)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2058,F396_4782, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4291 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2057,F396_4291_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.as_natural_32_feature_name */
static EIF_REFERENCE F396_4292_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2059)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2060,F396_4783, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4292 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2059,F396_4292_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.as_natural_64_feature_name */
static EIF_REFERENCE F396_4293_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2061)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2062,F396_4784, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4293 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2061,F396_4293_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.attached_type_feature_name */
static EIF_REFERENCE F396_4294_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2063)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2064,F396_4785, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4294 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2063,F396_4294_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.base_address_feature_name */
static EIF_REFERENCE F396_4295_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2065)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2066,F396_4786, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4295 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2065,F396_4295_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.bit_and_feature_name */
static EIF_REFERENCE F396_4297_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2067)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2068,F396_4788, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4297 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2067,F396_4297_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.bit_not_feature_name */
static EIF_REFERENCE F396_4298_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2069)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2070,F396_4789, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4298 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2069,F396_4298_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.bit_or_feature_name */
static EIF_REFERENCE F396_4299_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2071)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2072,F396_4790, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4299 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2071,F396_4299_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.bit_shift_left_feature_name */
static EIF_REFERENCE F396_4300_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2073)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2074,F396_4791, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4300 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2073,F396_4300_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.bit_shift_right_feature_name */
static EIF_REFERENCE F396_4301_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2075)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2076,F396_4792, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4301 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2075,F396_4301_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.bit_xor_feature_name */
static EIF_REFERENCE F396_4302_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2077)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2078,F396_4793, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4302 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2077,F396_4302_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.boolean_bytes_feature_name */
static EIF_REFERENCE F396_4303_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2079)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2080,F396_4794, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4303 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2079,F396_4303_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.boolean_item_feature_name */
static EIF_REFERENCE F396_4304_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2081)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2082,F396_4797, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4304 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2081,F396_4304_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.boolean_field_feature_name */
static EIF_REFERENCE F396_4305_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2083)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2084,F396_4795, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4305 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2083,F396_4305_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.boolean_field_at_feature_name */
static EIF_REFERENCE F396_4306_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2085)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2086,F396_4796, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4306 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2085,F396_4306_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.c_strlen_feature_name */
static EIF_REFERENCE F396_4307_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2087)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2088,F396_4798, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4307 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2087,F396_4307_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.call_feature_name */
static EIF_REFERENCE F396_4308_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(689)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(227,F396_4799, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4308 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(689,F396_4308_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.capacity_feature_name */
static EIF_REFERENCE F396_4309_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(80)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2089,F396_4800, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4309 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(80,F396_4309_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.catch_feature_name */
static EIF_REFERENCE F396_4310_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2090)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2091,F396_4801, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4310 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2090,F396_4310_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.ccom_hresult_feature_name */
static EIF_REFERENCE F396_4311_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2092)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2093,F396_4802, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4311 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2092,F396_4311_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.ccom_hresult_code_feature_name */
static EIF_REFERENCE F396_4312_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2094)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2095,F396_4803, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4312 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2094,F396_4312_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.ccom_hresult_facility_feature_name */
static EIF_REFERENCE F396_4313_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2096)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2097,F396_4804, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4313 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2096,F396_4313_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.ceiling_real_32_feature_name */
static EIF_REFERENCE F396_4314_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2098)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2099,F396_4805, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4314 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2098,F396_4314_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.ceiling_real_64_feature_name */
static EIF_REFERENCE F396_4315_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2100)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2101,F396_4806, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4315 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2100,F396_4315_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.character_8_field_feature_name */
static EIF_REFERENCE F396_4316_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2102)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2103,F396_4807, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4316 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2102,F396_4316_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.character_8_field_at_feature_name */
static EIF_REFERENCE F396_4317_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2104)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2105,F396_4808, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4317 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2104,F396_4317_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.character_8_item_feature_name */
static EIF_REFERENCE F396_4318_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2106)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2107,F396_4809, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4318 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2106,F396_4318_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.character_32_field_feature_name */
static EIF_REFERENCE F396_4319_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2108)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2109,F396_4810, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4319 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2108,F396_4319_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.character_32_field_at_feature_name */
static EIF_REFERENCE F396_4320_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2110)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2111,F396_4811, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4320 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2110,F396_4320_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.character_32_item_feature_name */
static EIF_REFERENCE F396_4321_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2112)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2113,F396_4812, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4321 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2112,F396_4321_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.character_bytes_feature_name */
static EIF_REFERENCE F396_4322_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2114)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2115,F396_4813, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4322 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2114,F396_4322_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.character_size_feature_name */
static EIF_REFERENCE F396_4323_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2116)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2117,F396_4814, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4323 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2116,F396_4323_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.check_assert_feature_name */
static EIF_REFERENCE F396_4324_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2118)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2119,F396_4815, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4324 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2118,F396_4324_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.closed_operands_feature_name */
static EIF_REFERENCE F396_4325_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(87)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2120,F396_4816, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4325 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(87,F396_4325_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.code_feature_name */
static EIF_REFERENCE F396_4326_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2121)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2122,F396_4817, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4326 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2121,F396_4326_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.compiler_version_feature_name */
static EIF_REFERENCE F396_4327_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2123)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2124,F396_4818, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4327 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2123,F396_4327_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.conforms_to_feature_name */
static EIF_REFERENCE F396_4328_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2125)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2126,F396_4819, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4328 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2125,F396_4328_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.conjuncted_feature_name */
static EIF_REFERENCE F396_4329_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2127)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2128,F396_4820, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4329 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2127,F396_4329_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.conjuncted_semistrict_feature_name */
static EIF_REFERENCE F396_4330_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2129)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2130,F396_4821, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4330 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2129,F396_4330_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.copy_feature_name */
static EIF_REFERENCE F396_4331_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(687)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2131,F396_4822, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4331 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(687,F396_4331_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.count_feature_name */
static EIF_REFERENCE F396_4332_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(79)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2132,F396_4823, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4332 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(79,F396_4332_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.cwin_error_text_feature_name */
static EIF_REFERENCE F396_4333_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2133)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2134,F396_4824, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4333 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2133,F396_4333_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.cwin_local_free_feature_name */
static EIF_REFERENCE F396_4334_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2135)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2136,F396_4825, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4334 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2135,F396_4334_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.deep_twin_feature_name */
static EIF_REFERENCE F396_4335_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2137)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2138,F396_4826, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4335 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2137,F396_4335_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.default_feature_name */
static EIF_REFERENCE F396_4336_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2139)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2140,F396_4827, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4336 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2139,F396_4336_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.default_create_feature_name */
static EIF_REFERENCE F396_4337_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(78)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2141,F396_4828, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4337 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(78,F396_4337_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.detachable_type_feature_name */
static EIF_REFERENCE F396_4338_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2142)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2143,F396_4829, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4338 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2142,F396_4338_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.developer_raise_feature_name */
static EIF_REFERENCE F396_4339_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2144)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2145,F396_4830, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4339 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2144,F396_4339_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.disjuncted_feature_name */
static EIF_REFERENCE F396_4340_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2146)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2147,F396_4831, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4340 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2146,F396_4340_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.disjuncted_exclusive_feature_name */
static EIF_REFERENCE F396_4341_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2148)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2149,F396_4832, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4341 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2148,F396_4341_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.disjuncted_semistrict_feature_name */
static EIF_REFERENCE F396_4342_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2150)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2151,F396_4833, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4342 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2150,F396_4342_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.dispose_feature_name */
static EIF_REFERENCE F396_4343_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(690)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2152,F396_4834, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4343 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(690,F396_4343_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.double_bytes_feature_name */
static EIF_REFERENCE F396_4344_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2153)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2154,F396_4835, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4344 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2153,F396_4344_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.dynamic_type_feature_name */
static EIF_REFERENCE F396_4345_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2155)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2156,F396_4836, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4345 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2155,F396_4345_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.dynamic_type_at_offset_feature_name */
static EIF_REFERENCE F396_4346_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2157)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2158,F396_4837, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4346 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2157,F396_4346_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.eif_gen_param_id_feature_name */
static EIF_REFERENCE F396_4347_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2159)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2160,F396_4838, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4347 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2159,F396_4347_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.eif_id_object_feature_name */
static EIF_REFERENCE F396_4348_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2161)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2162,F396_4839, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4348 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2161,F396_4348_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.eif_object_id_feature_name */
static EIF_REFERENCE F396_4349_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2163)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2164,F396_4840, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4349 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2163,F396_4349_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.eif_object_id_free_feature_name */
static EIF_REFERENCE F396_4350_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2165)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2166,F396_4841, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4350 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2165,F396_4350_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.element_size_feature_name */
static EIF_REFERENCE F396_4351_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2167)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2168,F396_4842, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4351 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2167,F396_4351_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.exception_from_code_feature_name */
static EIF_REFERENCE F396_4352_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2169)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2170,F396_4843, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4352 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2169,F396_4352_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.exception_manager_feature_name */
static EIF_REFERENCE F396_4353_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2171)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2172,F396_4844, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4353 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2171,F396_4353_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.extend_feature_name */
static EIF_REFERENCE F396_4354_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(653)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2173,F396_4845, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4354 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(653,F396_4354_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.fast_call_feature_name */
static EIF_REFERENCE F396_4355_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2174)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2175,F396_4846, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4355 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2174,F396_4355_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.fast_item_feature_name */
static EIF_REFERENCE F396_4356_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2176)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2177,F396_4847, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4356 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2176,F396_4356_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.field_count_of_type_feature_name */
static EIF_REFERENCE F396_4359_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2178)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2179,F396_4850, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4359 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2178,F396_4359_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.field_name_of_type_feature_name */
static EIF_REFERENCE F396_4361_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2180)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2181,F396_4852, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4361 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2180,F396_4361_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.field_offset_of_type_feature_name */
static EIF_REFERENCE F396_4362_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2182)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2183,F396_4853, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4362 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2182,F396_4362_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.field_static_type_of_type_feature_name */
static EIF_REFERENCE F396_4364_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2184)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2185,F396_4855, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4364 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2184,F396_4364_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.field_type_of_type_feature_name */
static EIF_REFERENCE F396_4366_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2186)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2187,F396_4857, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4366 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2186,F396_4366_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.find_referers_feature_name */
static EIF_REFERENCE F396_4367_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2188)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2189,F396_4858, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4367 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2188,F396_4367_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.floor_real_32_feature_name */
static EIF_REFERENCE F396_4368_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2190)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2191,F396_4859, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4368 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2190,F396_4368_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.floor_real_64_feature_name */
static EIF_REFERENCE F396_4369_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2192)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2193,F396_4860, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4369 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2192,F396_4369_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.forth_feature_name */
static EIF_REFERENCE F396_4370_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(693)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(768,F396_4861, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4370 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(693,F396_4370_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.free_feature_name */
static EIF_REFERENCE F396_4371_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2194)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2195,F396_4862, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4371 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2194,F396_4371_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.generating_type_feature_name */
static EIF_REFERENCE F396_4372_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2196)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2197,F396_4863, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4372 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2196,F396_4372_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.generating_type_of_type_feature_name */
static EIF_REFERENCE F396_4373_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2198)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2199,F396_4864, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4373 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2198,F396_4373_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.generator_feature_name */
static EIF_REFERENCE F396_4374_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2200)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2201,F396_4865, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4374 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2200,F396_4374_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.generator_of_type_feature_name */
static EIF_REFERENCE F396_4375_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2202)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2203,F396_4866, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4375 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2202,F396_4375_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.generic_parameter_count_feature_name */
static EIF_REFERENCE F396_4376_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2204)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2205,F396_4867, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4376 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2204,F396_4376_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.generic_parameter_type_feature_name */
static EIF_REFERENCE F396_4377_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2206)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2207,F396_4868, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4377 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2206,F396_4377_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.has_default_feature_name */
static EIF_REFERENCE F396_4378_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2208)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2209,F396_4869, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4378 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2208,F396_4378_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.hash_code_feature_name */
static EIF_REFERENCE F396_4379_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2210)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2211,F396_4870, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4379 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2210,F396_4379_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.i_th_argument_pointer_feature_name */
static EIF_REFERENCE F396_4380_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2212)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2213,F396_4871, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4380 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2212,F396_4380_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.i_th_argument_string_feature_name */
static EIF_REFERENCE F396_4381_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2214)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2215,F396_4872, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4381 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2214,F396_4381_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.identity_feature_name */
static EIF_REFERENCE F396_4382_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2216)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2217,F396_4873, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4382 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2216,F396_4382_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.ieee_is_equal_feature_name */
static EIF_REFERENCE F396_4383_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2218)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2219,F396_4874, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4383 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2218,F396_4383_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.ieee_is_greater_feature_name */
static EIF_REFERENCE F396_4384_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2220)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2221,F396_4875, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4384 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2220,F396_4384_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.ieee_is_greater_equal_feature_name */
static EIF_REFERENCE F396_4385_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2222)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2223,F396_4876, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4385 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2222,F396_4385_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.ieee_is_less_feature_name */
static EIF_REFERENCE F396_4386_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2224)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2225,F396_4877, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4386 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2224,F396_4386_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.ieee_is_less_equal_feature_name */
static EIF_REFERENCE F396_4387_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2226)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2227,F396_4878, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4387 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2226,F396_4387_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.ieee_maximum_number_feature_name */
static EIF_REFERENCE F396_4388_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2228)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2229,F396_4879, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4388 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2228,F396_4388_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.ieee_minimum_number_feature_name */
static EIF_REFERENCE F396_4389_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2230)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2231,F396_4880, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4389 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2230,F396_4389_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.ignore_feature_name */
static EIF_REFERENCE F396_4390_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2232)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2233,F396_4881, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4390 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2232,F396_4390_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implication_feature_name */
static EIF_REFERENCE F396_4391_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2234)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2235,F396_4882, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4391 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2234,F396_4391_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.in_assertion_feature_name */
static EIF_REFERENCE F396_4392_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2236)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2237,F396_4883, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4392 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2236,F396_4392_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.init_exception_manager_feature_name */
static EIF_REFERENCE F396_4393_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(90)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2238,F396_4884, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4393 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(90,F396_4393_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_8_field_feature_name */
static EIF_REFERENCE F396_4394_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2239)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2240,F396_4885, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4394 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2239,F396_4394_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_8_field_at_feature_name */
static EIF_REFERENCE F396_4395_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2241)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2242,F396_4886, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4395 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2241,F396_4395_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_8_item_feature_name */
static EIF_REFERENCE F396_4396_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2243)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2244,F396_4887, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4396 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2243,F396_4396_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_16_field_feature_name */
static EIF_REFERENCE F396_4397_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2245)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2246,F396_4888, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4397 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2245,F396_4397_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_16_field_at_feature_name */
static EIF_REFERENCE F396_4398_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2247)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2248,F396_4889, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4398 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2247,F396_4398_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_16_item_feature_name */
static EIF_REFERENCE F396_4399_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2249)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2250,F396_4890, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4399 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2249,F396_4399_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_32_field_feature_name */
static EIF_REFERENCE F396_4400_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2251)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2252,F396_4891, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4400 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2251,F396_4400_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_32_field_at_feature_name */
static EIF_REFERENCE F396_4401_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2253)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2254,F396_4892, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4401 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2253,F396_4401_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_32_item_feature_name */
static EIF_REFERENCE F396_4402_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2255)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2256,F396_4893, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4402 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2255,F396_4402_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_64_field_feature_name */
static EIF_REFERENCE F396_4403_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2257)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2258,F396_4894, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4403 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2257,F396_4403_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_64_field_at_feature_name */
static EIF_REFERENCE F396_4404_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2259)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2260,F396_4895, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4404 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2259,F396_4404_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_64_item_feature_name */
static EIF_REFERENCE F396_4405_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2261)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2262,F396_4896, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4405 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2261,F396_4405_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_bytes_feature_name */
static EIF_REFERENCE F396_4406_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2263)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2264,F396_4897, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4406 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2263,F396_4406_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_quotient_feature_name */
static EIF_REFERENCE F396_4407_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2265)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2266,F396_4898, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4407 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2265,F396_4407_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.integer_remainder_feature_name */
static EIF_REFERENCE F396_4408_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2267)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2268,F396_4899, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4408 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2267,F396_4408_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_64_bits_feature_name */
static EIF_REFERENCE F396_4410_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2269)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2270,F396_4900, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4410 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2269,F396_4410_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_attached_feature_name */
static EIF_REFERENCE F396_4411_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2271)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2272,F396_4901, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4411 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2271,F396_4411_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_attached_type_feature_name */
static EIF_REFERENCE F396_4412_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2273)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2274,F396_4902, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4412 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2273,F396_4412_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_caught_feature_name */
static EIF_REFERENCE F396_4413_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2275)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2276,F396_4903, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4413 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2275,F396_4413_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_copy_semantics_field_feature_name */
static EIF_REFERENCE F396_4414_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2277)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2278,F396_4904, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4414 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2277,F396_4414_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_deep_equal_feature_name */
static EIF_REFERENCE F396_4415_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2279)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2280,F396_4905, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4415 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2279,F396_4415_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_default_pointer_feature_name */
static EIF_REFERENCE F396_4416_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2281)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2282,F396_4906, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4416 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2281,F396_4416_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_deferred_feature_name */
static EIF_REFERENCE F396_4417_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2283)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2284,F396_4907, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4417 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2283,F396_4417_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_dotnet_feature_name */
static EIF_REFERENCE F396_4418_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2285)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2286,F396_4908, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4418 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2285,F396_4418_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_equal_feature_name */
static EIF_REFERENCE F396_4419_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(688)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2287,F396_4909, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4419 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(688,F396_4419_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_expanded_feature_name */
static EIF_REFERENCE F396_4420_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2288)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2289,F396_4910, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4420 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2288,F396_4420_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_field_expanded_of_type_feature_name */
static EIF_REFERENCE F396_4421_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2290)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2291,F396_4911, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4421 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2290,F396_4421_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_field_transient_of_type_feature_name */
static EIF_REFERENCE F396_4422_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2292)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2293,F396_4912, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4422 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2292,F396_4422_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_ignorable_feature_name */
static EIF_REFERENCE F396_4423_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2294)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2295,F396_4913, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4423 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2294,F396_4423_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_ignored_feature_name */
static EIF_REFERENCE F396_4424_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2296)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2297,F396_4914, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4424 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2296,F396_4424_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_less_feature_name */
static EIF_REFERENCE F396_4425_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2298)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2299,F396_4915, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4425 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2298,F396_4425_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_mac_feature_name */
static EIF_REFERENCE F396_4426_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2300)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2301,F396_4916, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4426 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2300,F396_4426_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_nan_feature_name */
static EIF_REFERENCE F396_4427_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2302)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2303,F396_4917, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4427 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2302,F396_4427_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_negative_infinity_feature_name */
static EIF_REFERENCE F396_4428_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2304)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2305,F396_4918, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4428 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2304,F396_4428_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_object_marked_feature_name */
static EIF_REFERENCE F396_4429_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2306)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2307,F396_4919, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4429 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2306,F396_4429_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_positive_infinity_feature_name */
static EIF_REFERENCE F396_4430_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2308)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2309,F396_4920, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4430 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2308,F396_4430_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_raisable_feature_name */
static EIF_REFERENCE F396_4431_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2310)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2311,F396_4921, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4431 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2310,F396_4431_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_scoop_capable_feature_name */
static EIF_REFERENCE F396_4432_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2312)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2313,F396_4922, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4432 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2312,F396_4432_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_special_feature_name */
static EIF_REFERENCE F396_4433_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2314)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2315,F396_4923, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4433 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2314,F396_4433_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_special_copy_semantics_item_feature_name */
static EIF_REFERENCE F396_4434_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2316)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2317,F396_4924, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4434 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2316,F396_4434_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_special_of_expanded_feature_name */
static EIF_REFERENCE F396_4435_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2318)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2319,F396_4925, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4435 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2318,F396_4435_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_special_of_reference_feature_name */
static EIF_REFERENCE F396_4436_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2320)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2321,F396_4926, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4436 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2320,F396_4436_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_special_of_reference_or_basic_type_feature_name */
static EIF_REFERENCE F396_4437_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2322)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2323,F396_4927, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4437 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2322,F396_4437_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_special_of_reference_type_feature_name */
static EIF_REFERENCE F396_4438_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2324)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2325,F396_4928, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4438 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2324,F396_4438_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_thread_capable_feature_name */
static EIF_REFERENCE F396_4439_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2326)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2327,F396_4929, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4439 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2326,F396_4439_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_tuple_feature_name */
static EIF_REFERENCE F396_4440_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2328)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2329,F396_4930, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4440 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2328,F396_4440_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_tuple_type_feature_name */
static EIF_REFERENCE F396_4441_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2330)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2331,F396_4931, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4441 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2330,F396_4441_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_unix_feature_name */
static EIF_REFERENCE F396_4442_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2332)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2333,F396_4932, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4442 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2332,F396_4442_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_vms_feature_name */
static EIF_REFERENCE F396_4443_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2334)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2335,F396_4933, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4443 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2334,F396_4443_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_vxworks_feature_name */
static EIF_REFERENCE F396_4444_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2336)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2337,F396_4934, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4444 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2336,F396_4444_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_windows_feature_name */
static EIF_REFERENCE F396_4445_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2338)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2339,F396_4935, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4445 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2338,F396_4445_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.item_feature_name */
static EIF_REFERENCE F396_4446_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(473)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(225,F396_4936, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4446 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(473,F396_4446_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.item_code_feature_name */
static EIF_REFERENCE F396_4447_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2340)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2341,F396_4937, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4447 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2340,F396_4447_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.last_exception_feature_name */
static EIF_REFERENCE F396_4448_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(91)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2342,F396_4938, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4448 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(91,F396_4448_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.lock_marking_feature_name */
static EIF_REFERENCE F396_4450_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2343)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2344,F396_4940, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4450 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2343,F396_4450_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.lower_feature_name */
static EIF_REFERENCE F396_4451_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(82)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2345,F396_4941, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4451 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(82,F396_4451_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.make_empty_feature_name */
static EIF_REFERENCE F396_4453_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2346)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2347,F396_4943, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4453 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2346,F396_4453_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.mark_object_feature_name */
static EIF_REFERENCE F396_4454_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2348)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2349,F396_4944, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4454 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2348,F396_4454_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.minus_feature_name */
static EIF_REFERENCE F396_4456_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2350)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2351,F396_4946, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4456 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2350,F396_4456_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.nan_feature_name */
static EIF_REFERENCE F396_4458_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2352)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2353,F396_4948, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4458 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2352,F396_4458_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_8_field_feature_name */
static EIF_REFERENCE F396_4459_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2354)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2355,F396_4949, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4459 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2354,F396_4459_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_8_field_at_feature_name */
static EIF_REFERENCE F396_4460_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2356)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2357,F396_4950, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4460 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2356,F396_4460_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_8_item_feature_name */
static EIF_REFERENCE F396_4461_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2358)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2359,F396_4951, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4461 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2358,F396_4461_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_16_field_feature_name */
static EIF_REFERENCE F396_4462_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2360)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2361,F396_4952, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4462 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2360,F396_4462_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_16_field_at_feature_name */
static EIF_REFERENCE F396_4463_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2362)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2363,F396_4953, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4463 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2362,F396_4463_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_16_item_feature_name */
static EIF_REFERENCE F396_4464_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2364)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2365,F396_4954, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4464 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2364,F396_4464_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_32_code_feature_name */
static EIF_REFERENCE F396_4465_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2366)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2367,F396_4955, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4465 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2366,F396_4465_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_32_field_feature_name */
static EIF_REFERENCE F396_4466_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2368)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2369,F396_4956, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4466 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2368,F396_4466_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_32_field_at_feature_name */
static EIF_REFERENCE F396_4467_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2370)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2371,F396_4957, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4467 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2370,F396_4467_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_32_item_feature_name */
static EIF_REFERENCE F396_4468_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2372)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2373,F396_4958, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4468 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2372,F396_4468_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_64_field_feature_name */
static EIF_REFERENCE F396_4469_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2374)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2375,F396_4959, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4469 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2374,F396_4469_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_64_field_at_feature_name */
static EIF_REFERENCE F396_4470_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2376)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2377,F396_4960, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4470 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2376,F396_4470_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.natural_64_item_feature_name */
static EIF_REFERENCE F396_4471_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2378)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2379,F396_4961, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4471 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2378,F396_4471_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.negated_feature_name */
static EIF_REFERENCE F396_4472_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2380)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2381,F396_4962, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4472 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2380,F396_4472_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.negative_infinity_feature_name */
static EIF_REFERENCE F396_4473_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2382)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2383,F396_4963, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4473 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2382,F396_4473_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.new_cursor_feature_name */
static EIF_REFERENCE F396_4474_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(691)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(766,F396_4964, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4474 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(691,F396_4474_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.new_instance_of_feature_name */
static EIF_REFERENCE F396_4476_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2384)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2385,F396_4966, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4476 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2384,F396_4476_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.new_special_of_reference_instance_of_feature_name */
static EIF_REFERENCE F396_4478_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2386)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2387,F396_4968, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4478 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2386,F396_4478_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.new_tuple_instance_of_feature_name */
static EIF_REFERENCE F396_4479_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2388)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2389,F396_4969, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4479 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2388,F396_4479_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.new_type_instance_of_feature_name */
static EIF_REFERENCE F396_4480_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2390)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2391,F396_4970, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4480 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2390,F396_4480_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.object_comparison_feature_name */
static EIF_REFERENCE F396_4481_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2392)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2393,F396_4971, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4481 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2392,F396_4481_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.object_size_feature_name */
static EIF_REFERENCE F396_4482_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2394)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2395,F396_4972, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4482 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2394,F396_4482_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.once_objects_feature_name */
static EIF_REFERENCE F396_4483_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2396)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2397,F396_4973, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4483 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2396,F396_4483_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.once_raise_feature_name */
static EIF_REFERENCE F396_4484_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(92)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2398,F396_4974, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4484 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(92,F396_4484_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.opposite_feature_name */
static EIF_REFERENCE F396_4485_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2399)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2400,F396_4975, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4485 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2399,F396_4485_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.out_feature_name */
static EIF_REFERENCE F396_4486_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2401)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2402,F396_4976, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4486 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2401,F396_4486_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.persistent_field_count_of_type_feature_name */
static EIF_REFERENCE F396_4487_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2403)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2404,F396_4977, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4487 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2403,F396_4487_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.plus_feature_name */
static EIF_REFERENCE F396_4488_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2405)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2406,F396_4978, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4488 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2405,F396_4488_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.pointer_bytes_feature_name */
static EIF_REFERENCE F396_4489_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2407)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2408,F396_4979, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4489 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2407,F396_4489_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.pointer_field_feature_name */
static EIF_REFERENCE F396_4490_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2409)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2410,F396_4980, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4490 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2409,F396_4490_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.pointer_field_at_feature_name */
static EIF_REFERENCE F396_4491_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2411)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2412,F396_4981, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4491 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2411,F396_4491_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.pointer_item_feature_name */
static EIF_REFERENCE F396_4492_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(85)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2413,F396_4982, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4492 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(85,F396_4492_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.positive_infinity_feature_name */
static EIF_REFERENCE F396_4493_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2414)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2415,F396_4983, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4493 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2414,F396_4493_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.power_feature_name */
static EIF_REFERENCE F396_4494_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2416)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2417,F396_4984, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4494 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2416,F396_4494_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.pre_ecma_mapping_status_feature_name */
static EIF_REFERENCE F396_4495_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2418)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2419,F396_4985, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4495 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2418,F396_4495_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.product_feature_name */
static EIF_REFERENCE F396_4496_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2420)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2421,F396_4986, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4496 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2420,F396_4496_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.put_feature_name */
static EIF_REFERENCE F396_4497_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(652)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2422,F396_4987, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4497 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(652,F396_4497_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.put_boolean_feature_name */
static EIF_REFERENCE F396_4498_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2423)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2424,F396_4988, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4498 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2423,F396_4498_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.put_character_8_feature_name */
static EIF_REFERENCE F396_4499_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2425)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2426,F396_4989, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4499 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2425,F396_4499_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.put_character_32_feature_name */
static EIF_REFERENCE F396_4500_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2427)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2428,F396_4990, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4500 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2427,F396_4500_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.put_integer_8_feature_name */
static EIF_REFERENCE F396_4501_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2429)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2430,F396_4991, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4501 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2429,F396_4501_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.put_integer_16_feature_name */
static EIF_REFERENCE F396_4502_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2431)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2432,F396_4992, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4502 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2431,F396_4502_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.put_integer_32_feature_name */
static EIF_REFERENCE F396_4503_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2433)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2434,F396_4993, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4503 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2433,F396_4503_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.put_integer_64_feature_name */
static EIF_REFERENCE F396_4504_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2435)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2436,F396_4994, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4504 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2435,F396_4504_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.put_natural_8_feature_name */
static EIF_REFERENCE F396_4505_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2437)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2438,F396_4995, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4505 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2437,F396_4505_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.put_natural_16_feature_name */
static EIF_REFERENCE F396_4506_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2439)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2440,F396_4996, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4506 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2439,F396_4506_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.put_natural_32_feature_name */
static EIF_REFERENCE F396_4507_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2441)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2442,F396_4997, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4507 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2441,F396_4507_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.put_natural_64_feature_name */
static EIF_REFERENCE F396_4508_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2443)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2444,F396_4998, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4508 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2443,F396_4508_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.put_pointer_feature_name */
static EIF_REFERENCE F396_4509_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2445)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2446,F396_4999, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4509 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2445,F396_4509_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.put_real_32_feature_name */
static EIF_REFERENCE F396_4510_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2447)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2448,F396_5000, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4510 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2447,F396_4510_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.put_real_64_feature_name */
static EIF_REFERENCE F396_4511_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2449)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2450,F396_5001, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4511 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2449,F396_4511_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.put_reference_feature_name */
static EIF_REFERENCE F396_4512_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(657)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2451,F396_5002, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4512 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(657,F396_4512_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.quotient_feature_name */
static EIF_REFERENCE F396_4513_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2452)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2453,F396_5003, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4513 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2452,F396_4513_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.raise_feature_name */
static EIF_REFERENCE F396_4514_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2454)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2455,F396_5004, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4514 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2454,F396_4514_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.raw_reference_field_at_feature_name */
static EIF_REFERENCE F396_4515_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2456)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2457,F396_5005, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4515 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2456,F396_4515_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.raw_reference_field_at_offset_feature_name */
static EIF_REFERENCE F396_4516_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2458)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2459,F396_5006, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4516 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2458,F396_4516_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.real_32_field_feature_name */
static EIF_REFERENCE F396_4517_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2460)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2461,F396_5007, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4517 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2460,F396_4517_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.real_32_field_at_feature_name */
static EIF_REFERENCE F396_4518_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2462)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2463,F396_5008, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4518 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2462,F396_4518_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.real_32_item_feature_name */
static EIF_REFERENCE F396_4519_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2464)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2465,F396_5009, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4519 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2464,F396_4519_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.real_64_field_feature_name */
static EIF_REFERENCE F396_4520_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2466)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2467,F396_5010, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4520 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2466,F396_4520_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.real_64_field_at_feature_name */
static EIF_REFERENCE F396_4521_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2468)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2469,F396_5011, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4521 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2468,F396_4521_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.real_64_item_feature_name */
static EIF_REFERENCE F396_4522_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2470)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2471,F396_5012, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4522 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2470,F396_4522_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.real_bytes_feature_name */
static EIF_REFERENCE F396_4523_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2472)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2473,F396_5013, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4523 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2472,F396_4523_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.reference_field_feature_name */
static EIF_REFERENCE F396_4524_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2474)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2475,F396_5014, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4524 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2474,F396_4524_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.reference_field_at_feature_name */
static EIF_REFERENCE F396_4525_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2476)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2477,F396_5015, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4525 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2476,F396_4525_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.reference_field_at_offset_feature_name */
static EIF_REFERENCE F396_4526_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2478)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2479,F396_5016, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4526 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2478,F396_4526_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.reference_item_feature_name */
static EIF_REFERENCE F396_4527_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(656)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2480,F396_5017, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4527 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(656,F396_4527_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.rout_disp_feature_name */
static EIF_REFERENCE F396_4528_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(88)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2481,F396_5018, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4528 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(88,F396_4528_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.runtime_name_feature_name */
static EIF_REFERENCE F396_4529_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2482)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2483,F396_5019, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4529 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2482,F396_4529_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.same_type_feature_name */
static EIF_REFERENCE F396_4530_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2484)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2485,F396_5020, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4530 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2484,F396_4530_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_boolean_field_feature_name */
static EIF_REFERENCE F396_4531_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2486)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2487,F396_5021, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4531 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2486,F396_4531_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_boolean_field_at_feature_name */
static EIF_REFERENCE F396_4532_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2488)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2489,F396_5022, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4532 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2488,F396_4532_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_character_8_field_feature_name */
static EIF_REFERENCE F396_4533_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2490)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2491,F396_5023, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4533 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2490,F396_4533_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_character_8_field_at_feature_name */
static EIF_REFERENCE F396_4534_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2492)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2493,F396_5024, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4534 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2492,F396_4534_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_character_32_field_feature_name */
static EIF_REFERENCE F396_4535_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2494)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2495,F396_5025, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4535 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2494,F396_4535_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_character_32_field_at_feature_name */
static EIF_REFERENCE F396_4536_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2496)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2497,F396_5026, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4536 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2496,F396_4536_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_count_feature_name */
static EIF_REFERENCE F396_4537_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2498)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2499,F396_5027, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4537 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2498,F396_4537_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_exception_data_feature_name */
static EIF_REFERENCE F396_4538_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(93)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2500,F396_5028, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4538 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(93,F396_4538_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_integer_8_field_feature_name */
static EIF_REFERENCE F396_4539_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2501)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2502,F396_5029, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4539 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2501,F396_4539_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_integer_8_field_at_feature_name */
static EIF_REFERENCE F396_4540_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2503)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2504,F396_5030, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4540 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2503,F396_4540_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_integer_16_field_feature_name */
static EIF_REFERENCE F396_4541_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2505)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2506,F396_5031, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4541 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2505,F396_4541_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_integer_16_field_at_feature_name */
static EIF_REFERENCE F396_4542_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2507)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2508,F396_5032, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4542 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2507,F396_4542_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_integer_32_field_feature_name */
static EIF_REFERENCE F396_4543_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2509)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2510,F396_5033, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4543 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2509,F396_4543_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_integer_32_field_at_feature_name */
static EIF_REFERENCE F396_4544_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2511)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2512,F396_5034, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4544 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2511,F396_4544_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_integer_64_field_feature_name */
static EIF_REFERENCE F396_4545_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2513)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2514,F396_5035, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4545 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2513,F396_4545_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_integer_64_field_at_feature_name */
static EIF_REFERENCE F396_4546_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2515)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2516,F396_5036, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4546 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2515,F396_4546_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_is_ignored_feature_name */
static EIF_REFERENCE F396_4547_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2517)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2518,F396_5037, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4547 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2517,F396_4547_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_item_feature_name */
static EIF_REFERENCE F396_4548_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2519)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2520,F396_5038, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4548 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2519,F396_4548_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_natural_8_field_feature_name */
static EIF_REFERENCE F396_4549_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2521)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2522,F396_5039, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4549 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2521,F396_4549_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_natural_8_field_at_feature_name */
static EIF_REFERENCE F396_4550_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2523)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2524,F396_5040, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4550 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2523,F396_4550_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_natural_16_field_feature_name */
static EIF_REFERENCE F396_4551_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2525)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2526,F396_5041, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4551 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2525,F396_4551_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_natural_16_field_at_feature_name */
static EIF_REFERENCE F396_4552_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2527)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2528,F396_5042, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4552 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2527,F396_4552_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_natural_32_field_feature_name */
static EIF_REFERENCE F396_4553_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2529)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2530,F396_5043, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4553 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2529,F396_4553_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_natural_32_field_at_feature_name */
static EIF_REFERENCE F396_4554_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2531)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2532,F396_5044, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4554 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2531,F396_4554_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_natural_64_field_feature_name */
static EIF_REFERENCE F396_4555_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2533)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2534,F396_5045, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4555 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2533,F396_4555_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_natural_64_field_at_feature_name */
static EIF_REFERENCE F396_4556_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2535)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2536,F396_5046, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4556 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2535,F396_4556_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_object_comparison_feature_name */
static EIF_REFERENCE F396_4557_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2537)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2538,F396_5047, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4557 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2537,F396_4557_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_pointer_field_feature_name */
static EIF_REFERENCE F396_4559_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2539)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2540,F396_5049, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4559 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2539,F396_4559_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_pointer_field_at_feature_name */
static EIF_REFERENCE F396_4560_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2541)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2542,F396_5050, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4560 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2541,F396_4560_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_pre_ecma_mapping_feature_name */
static EIF_REFERENCE F396_4561_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2543)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2544,F396_5051, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4561 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2543,F396_4561_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_real_32_field_feature_name */
static EIF_REFERENCE F396_4562_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2545)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2546,F396_5052, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4562 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2545,F396_4562_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_real_32_field_at_feature_name */
static EIF_REFERENCE F396_4563_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2547)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2548,F396_5053, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4563 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2547,F396_4563_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_real_64_field_feature_name */
static EIF_REFERENCE F396_4564_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2549)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2550,F396_5054, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4564 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2549,F396_4564_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_real_64_field_at_feature_name */
static EIF_REFERENCE F396_4565_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2551)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2552,F396_5055, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4565 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2551,F396_4565_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_reference_field_feature_name */
static EIF_REFERENCE F396_4566_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2553)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2554,F396_5056, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4566 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2553,F396_4566_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_reference_field_at_feature_name */
static EIF_REFERENCE F396_4567_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2555)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2556,F396_5057, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4567 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2555,F396_4567_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.set_rout_disp_final_feature_name */
static EIF_REFERENCE F396_4568_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(89)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2557,F396_5058, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4568 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(89,F396_4568_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.standard_copy_feature_name */
static EIF_REFERENCE F396_4569_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2558)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2559,F396_5059, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4569 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2558,F396_4569_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.standard_is_equal_feature_name */
static EIF_REFERENCE F396_4570_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2560)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2561,F396_5060, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4570 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2560,F396_4570_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.standard_twin_feature_name */
static EIF_REFERENCE F396_4571_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2562)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2563,F396_5061, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4571 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2562,F396_4571_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.storable_version_of_type_feature_name */
static EIF_REFERENCE F396_4572_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2564)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2565,F396_5062, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4572 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2564,F396_4572_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.tagged_out_feature_name */
static EIF_REFERENCE F396_4573_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2566)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2567,F396_5063, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4573 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2566,F396_4573_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.to_character_8_feature_name */
static EIF_REFERENCE F396_4575_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2568)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2569,F396_5065, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4575 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2568,F396_4575_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.to_character_32_feature_name */
static EIF_REFERENCE F396_4576_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2570)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2571,F396_5066, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4576 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2570,F396_4576_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.to_double_feature_name */
static EIF_REFERENCE F396_4577_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2572)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2573,F396_5067, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4577 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2572,F396_4577_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.to_integer_32_feature_name */
static EIF_REFERENCE F396_4578_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2574)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2575,F396_5068, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4578 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2574,F396_4578_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.to_real_feature_name */
static EIF_REFERENCE F396_4579_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2576)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2577,F396_5070, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4579 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2576,F396_4579_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.to_pointer_feature_name */
static EIF_REFERENCE F396_4580_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(86)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2578,F396_5069, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4580 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(86,F396_4580_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.to_real_32_feature_name */
static EIF_REFERENCE F396_4581_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2579)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2580,F396_5071, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4581 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2579,F396_4581_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.to_real_64_feature_name */
static EIF_REFERENCE F396_4582_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2581)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2582,F396_5072, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4582 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2581,F396_4582_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.truncated_to_integer_feature_name */
static EIF_REFERENCE F396_4583_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2583)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2584,F396_5073, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4583 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2583,F396_4583_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.truncated_to_integer_64_feature_name */
static EIF_REFERENCE F396_4584_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2585)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2586,F396_5074, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4584 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2585,F396_4584_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.truncated_to_real_feature_name */
static EIF_REFERENCE F396_4585_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2587)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2588,F396_5075, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4585 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2587,F396_4585_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.twin_feature_name */
static EIF_REFERENCE F396_4586_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2589)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2590,F396_5076, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4586 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2589,F396_4586_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.type_conforms_to_feature_name */
static EIF_REFERENCE F396_4587_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2591)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2592,F396_5077, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4587 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2591,F396_4587_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.type_id_feature_name */
static EIF_REFERENCE F396_4588_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2593)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2594,F396_5078, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4588 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2593,F396_4588_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.type_id_from_name_feature_name */
static EIF_REFERENCE F396_4589_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2595)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2596,F396_5079, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4589 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2595,F396_4589_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.type_of_code_feature_name */
static EIF_REFERENCE F396_4590_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2597)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2598,F396_5080, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4590 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2597,F396_4590_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.unlock_marking_feature_name */
static EIF_REFERENCE F396_4592_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2599)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2600,F396_5082, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4592 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2599,F396_4592_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.unmark_object_feature_name */
static EIF_REFERENCE F396_4593_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2601)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2602,F396_5083, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4593 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2601,F396_4593_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.upper_feature_name */
static EIF_REFERENCE F396_4594_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(83)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2603,F396_5084, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4594 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(83,F396_4594_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.wide_character_bytes_feature_name */
static EIF_REFERENCE F396_4596_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2604)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2605,F396_5085, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4596 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2604,F396_4596_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.like_current */
static EIF_REFERENCE F396_4597_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2606)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1889, 0x01).id, 1889, _OBJSIZ_3_0_0_0_0_0_0_0_);
	tr2 = RTOUCR(72,F396_4604, (Current));
	F1890_18373(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4597 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2606,F396_4597_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.attached_like_current */
static EIF_REFERENCE F396_4598_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(75)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1889, 0x01).id, 1889, _OBJSIZ_3_0_0_0_0_0_0_0_);
	tr2 = RTOUCR(764,F396_4661, (Current));
	F1890_18373(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4598 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(75,F396_4598_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.detachable_like_current */
static EIF_REFERENCE F396_4599_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(604)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1889, 0x01).id, 1889, _OBJSIZ_3_0_0_0_0_0_0_0_);
	tr2 = RTOUCR(522,F396_4671, (Current));
	F1890_18373(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4599 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(604,F396_4599_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.identity_type */
static EIF_REFERENCE F396_4600_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(571)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1889, 0x01).id, 1889, _OBJSIZ_3_0_0_0_0_0_0_0_);
	F1890_18373(RTCW(tr1), NULL);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4600 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(571,F396_4600_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.like_0 */
static EIF_REFERENCE F396_4601_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(648)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1890, 0x01).id, 1890, _OBJSIZ_3_0_0_1_0_0_0_0_);
	F1891_18419(RTCW(tr1), NULL);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4601 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(648,F396_4601_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.attached_separate_type_mark */
static EIF_REFERENCE F396_4602_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(638)

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1874, 0x01).id, 1874, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTOUCR(764,F396_4661, (Current));
	tr3 = RTOUCR(2607,F396_4707, (Current));
	F1875_18114(RTCW(tr1), tr2, tr3);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4602 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(638,F396_4602_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.detachable_separate_type_mark */
static EIF_REFERENCE F396_4603_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(569)

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1874, 0x01).id, 1874, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTOUCR(522,F396_4671, (Current));
	tr3 = RTOUCR(2607,F396_4707, (Current));
	F1875_18114(RTCW(tr1), tr2, tr3);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4603 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(569,F396_4603_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_attached_type_mark */
static EIF_REFERENCE F396_4604_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(72)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	F1874_18108(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4604 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(72,F396_4604_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_attached_expanded_type_mark */
static EIF_REFERENCE F396_4605_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2608)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	F1874_18108(RTCW(Result), (EIF_BOOLEAN) 1);
	F1874_18111(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4605 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2608,F396_4605_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_attached_reference_type_mark */
static EIF_REFERENCE F396_4606_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2609)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	F1874_18108(RTCW(Result), (EIF_BOOLEAN) 1);
	F1874_18112(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4606 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2609,F396_4606_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_attached_separate_type_mark */
static EIF_REFERENCE F396_4607_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2610)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	F1874_18108(RTCW(Result), (EIF_BOOLEAN) 1);
	F1874_18110(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4607 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2610,F396_4607_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_attached_separate_expanded_type_mark */
static EIF_REFERENCE F396_4608_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2611)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	F1874_18108(RTCW(Result), (EIF_BOOLEAN) 1);
	F1874_18110(RTCW(Result), (EIF_BOOLEAN) 1);
	F1874_18111(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4608 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2611,F396_4608_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_attached_separate_reference_type_mark */
static EIF_REFERENCE F396_4609_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2612)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	F1874_18108(RTCW(Result), (EIF_BOOLEAN) 1);
	F1874_18110(RTCW(Result), (EIF_BOOLEAN) 1);
	F1874_18112(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4609 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2612,F396_4609_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_detachable_type_mark */
static EIF_REFERENCE F396_4610_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(73)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	F1874_18109(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4610 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(73,F396_4610_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_detachable_expanded_type_mark */
static EIF_REFERENCE F396_4611_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2613)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	F1874_18109(RTCW(Result), (EIF_BOOLEAN) 1);
	F1874_18111(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4611 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2613,F396_4611_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_detachable_reference_type_mark */
static EIF_REFERENCE F396_4612_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2614)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	F1874_18109(RTCW(Result), (EIF_BOOLEAN) 1);
	F1874_18112(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4612 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2614,F396_4612_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_detachable_separate_type_mark */
static EIF_REFERENCE F396_4613_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2615)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	F1874_18109(RTCW(Result), (EIF_BOOLEAN) 1);
	F1874_18110(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4613 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2615,F396_4613_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_detachable_separate_expanded_type_mark */
static EIF_REFERENCE F396_4614_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2616)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	F1874_18109(RTCW(Result), (EIF_BOOLEAN) 1);
	F1874_18110(RTCW(Result), (EIF_BOOLEAN) 1);
	F1874_18111(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4614 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2616,F396_4614_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_detachable_separate_reference_type_mark */
static EIF_REFERENCE F396_4615_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2617)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	F1874_18109(RTCW(Result), (EIF_BOOLEAN) 1);
	F1874_18110(RTCW(Result), (EIF_BOOLEAN) 1);
	F1874_18112(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4615 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2617,F396_4615_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_expanded_type_mark */
static EIF_REFERENCE F396_4616_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2618)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	F1874_18111(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4616 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2618,F396_4616_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_reference_type_mark */
static EIF_REFERENCE F396_4617_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2619)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	F1874_18112(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4617 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2619,F396_4617_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_separate_type_mark */
static EIF_REFERENCE F396_4618_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2620)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	F1874_18110(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4618 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2620,F396_4618_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_separate_expanded_type_mark */
static EIF_REFERENCE F396_4619_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2621)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	F1874_18110(RTCW(Result), (EIF_BOOLEAN) 1);
	F1874_18111(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4619 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2621,F396_4619_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_separate_reference_type_mark */
static EIF_REFERENCE F396_4620_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2622)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	F1874_18110(RTCW(Result), (EIF_BOOLEAN) 1);
	F1874_18112(RTCW(Result), (EIF_BOOLEAN) 1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4620 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2622,F396_4620_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_no_type_mark */
static EIF_REFERENCE F396_4621_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2623)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1873, 0x01).id, 1873, _OBJSIZ_0_5_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4621 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2623,F396_4621_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.implicit_type_mark */
EIF_REFERENCE F396_4622 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4, EIF_BOOLEAN arg5)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	if (arg4) {
		if (arg3) {
			if (arg1) {
				RTLE;
				return (EIF_REFERENCE) RTOUCR(2611,F396_4608, (Current));
			} else {
				if (arg2) {
					RTLE;
					return (EIF_REFERENCE) RTOUCR(2612,F396_4609, (Current));
				} else {
					RTLE;
					return (EIF_REFERENCE) RTOUCR(2610,F396_4607, (Current));
				}
			}
		} else {
			if (arg1) {
				Result = RTOUCR(2608,F396_4605, (Current));
			} else {
				if (arg2) {
					Result = RTOUCR(2609,F396_4606, (Current));
					RTLE;
					return (EIF_REFERENCE) Result;
				} else {
					Result = RTOUCR(72,F396_4604, (Current));
					RTLE;
					return (EIF_REFERENCE) Result;
				}
			}
		}
	} else {
		if (arg5) {
			if (arg3) {
				if (arg1) {
					Result = RTOUCR(2616,F396_4614, (Current));
				} else {
					if (arg2) {
						Result = RTOUCR(2617,F396_4615, (Current));
					} else {
						Result = RTOUCR(2615,F396_4613, (Current));
					}
				}
			} else {
				if (arg1) {
					Result = RTOUCR(2613,F396_4611, (Current));
				} else {
					if (arg2) {
						Result = RTOUCR(2614,F396_4612, (Current));
					} else {
						Result = RTOUCR(73,F396_4610, (Current));
					}
				}
			}
		} else {
			if (arg3) {
				if (arg1) {
					Result = RTOUCR(2621,F396_4619, (Current));
				} else {
					if (arg2) {
						Result = RTOUCR(2622,F396_4620, (Current));
					} else {
						Result = RTOUCR(2620,F396_4618, (Current));
					}
				}
			} else {
				if (arg1) {
					Result = RTOUCR(2618,F396_4616, (Current));
				} else {
					if (arg2) {
						Result = RTOUCR(2619,F396_4617, (Current));
						RTLE;
						return (EIF_REFERENCE) Result;
					} else {
						Result = RTOUCR(2623,F396_4621, (Current));
						RTLE;
						return (EIF_REFERENCE) Result;
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {ET_TOKEN_CONSTANTS}.null_leaf */
static EIF_REFERENCE F396_4623_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2624)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1914, 0x01).id, 1914, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F1286_12617(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4623 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2624,F396_4623_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.arrow_symbol */
static EIF_REFERENCE F396_4625_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(732)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18805(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4625 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(732,F396_4625_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.assign_symbol */
static EIF_REFERENCE F396_4626_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(734)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18806(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4626 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(734,F396_4626_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.assign_attempt_symbol */
static EIF_REFERENCE F396_4627_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(733)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18807(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4627 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(733,F396_4627_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.bang_symbol */
static EIF_REFERENCE F396_4628_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(774)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18808(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4628 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(774,F396_4628_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.bar_symbol */
static EIF_REFERENCE F396_4629_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(735)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18809(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4629 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(735,F396_4629_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.close_repeat_symbol */
static EIF_REFERENCE F396_4630_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(736)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18810(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4630 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(736,F396_4630_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.colon_symbol */
static EIF_REFERENCE F396_4631_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(737)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18811(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4631 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(737,F396_4631_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.comma_symbol */
static EIF_REFERENCE F396_4632_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(738)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18812(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4632 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(738,F396_4632_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.dollar_symbol */
static EIF_REFERENCE F396_4633_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(781)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18815(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4633 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(781,F396_4633_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.dot_symbol */
static EIF_REFERENCE F396_4634_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(739)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18816(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4634 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(739,F396_4634_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.dotdot_symbol */
static EIF_REFERENCE F396_4635_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(740)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18817(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4635 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(740,F396_4635_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.for_all_symbol */
static EIF_REFERENCE F396_4637_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(741)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18819(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4637 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(741,F396_4637_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.greater_than_symbol */
static EIF_REFERENCE F396_4638_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2625)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1956, 0x01).id, 1956, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1917_18821(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4638 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2625,F396_4638_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.left_array_symbol */
static EIF_REFERENCE F396_4639_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(770)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18823(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4639 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(770,F396_4639_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.left_brace_symbol */
static EIF_REFERENCE F396_4640_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(742)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18824(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4640 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(742,F396_4640_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.left_bracket_symbol */
static EIF_REFERENCE F396_4641_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(645)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1945, 0x01).id, 1945, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1917_18825(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4641 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(645,F396_4641_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.left_parenthesis_symbol */
static EIF_REFERENCE F396_4642_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(743)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18826(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4642 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(743,F396_4642_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.less_than_symbol */
static EIF_REFERENCE F396_4643_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2626)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1956, 0x01).id, 1956, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1917_18827(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4643 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2626,F396_4643_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.open_repeat_symbol */
static EIF_REFERENCE F396_4644_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(744)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18832(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4644 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(744,F396_4644_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.question_mark_symbol */
static EIF_REFERENCE F396_4645_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2627)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1917, 0x01).id, 1917, _OBJSIZ_1_1_0_2_0_0_0_0_);
	F1917_18835(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4645 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2627,F396_4645_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.right_array_symbol */
static EIF_REFERENCE F396_4646_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(745)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18836(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4646 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(745,F396_4646_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.right_brace_symbol */
static EIF_REFERENCE F396_4647_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(746)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18837(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4647 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(746,F396_4647_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.right_bracket_symbol */
static EIF_REFERENCE F396_4648_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(646)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18838(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4648 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(646,F396_4648_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.right_parenthesis_symbol */
static EIF_REFERENCE F396_4649_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(747)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18839(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4649 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(747,F396_4649_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.semicolon_symbol */
static EIF_REFERENCE F396_4650_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(748)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1970, 0x01).id, 1970, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18840(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4650 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(748,F396_4650_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.there_exists_symbol */
static EIF_REFERENCE F396_4651_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(749)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1916, 0x01).id, 1916, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1917_18841(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4651 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(749,F396_4651_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.across_keyword */
static EIF_REFERENCE F396_4654_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(694)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18917(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4654 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(694,F396_4654_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.agent_keyword */
static EIF_REFERENCE F396_4655_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(775)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1951, 0x01).id, 1951, _OBJSIZ_2_1_0_2_0_0_0_0_);
	F1923_18918(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4655 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(775,F396_4655_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.and_keyword */
static EIF_REFERENCE F396_4656_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2628)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1955, 0x01).id, 1955, _OBJSIZ_2_1_0_2_0_0_0_0_);
	F1923_18921(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4656 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2628,F396_4656_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.alias_keyword */
static EIF_REFERENCE F396_4657_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(695)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18919(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4657 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(695,F396_4657_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.all_keyword */
static EIF_REFERENCE F396_4658_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(832)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18920(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4658 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(832,F396_4658_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.as_keyword */
static EIF_REFERENCE F396_4659_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(696)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18922(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4659 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(696,F396_4659_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.assign_keyword */
static EIF_REFERENCE F396_4660_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(697)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18923(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4660 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(697,F396_4660_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.attached_keyword */
static EIF_REFERENCE F396_4661_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(764)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18924(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4661 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(764,F396_4661_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.attribute_keyword */
static EIF_REFERENCE F396_4662_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(698)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18925(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4662 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(698,F396_4662_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.check_keyword */
static EIF_REFERENCE F396_4663_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(699)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18926(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4663 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(699,F396_4663_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.class_keyword */
static EIF_REFERENCE F396_4664_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(633)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18927(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4664 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(633,F396_4664_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.convert_keyword */
static EIF_REFERENCE F396_4665_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(700)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18928(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4665 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(700,F396_4665_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.create_keyword */
static EIF_REFERENCE F396_4666_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(701)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18929(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4666 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(701,F396_4666_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.creation_keyword */
static EIF_REFERENCE F396_4667_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(702)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18930(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4667 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(702,F396_4667_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.current_keyword */
static EIF_REFERENCE F396_4668_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(113)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1923, 0x01).id, 1923, _OBJSIZ_2_1_0_2_0_0_0_0_);
	F1923_18931(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4668 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(113,F396_4668_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.debug_keyword */
static EIF_REFERENCE F396_4669_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(703)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18932(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4669 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(703,F396_4669_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.deferred_keyword */
static EIF_REFERENCE F396_4670_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(704)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18933(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4670 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(704,F396_4670_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.detachable_keyword */
static EIF_REFERENCE F396_4671_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(522)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18934(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4671 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(522,F396_4671_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.do_keyword */
static EIF_REFERENCE F396_4672_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(705)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18935(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4672 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(705,F396_4672_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.else_keyword */
static EIF_REFERENCE F396_4673_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(706)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18936(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4673 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(706,F396_4673_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.elseif_keyword */
static EIF_REFERENCE F396_4674_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(707)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18937(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4674 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(707,F396_4674_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.end_keyword */
static EIF_REFERENCE F396_4675_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(634)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18938(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4675 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(634,F396_4675_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.ensure_keyword */
static EIF_REFERENCE F396_4676_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1701)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18939(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4676 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1701,F396_4676_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.export_keyword */
static EIF_REFERENCE F396_4678_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(708)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18941(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4678 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(708,F396_4678_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.external_keyword */
static EIF_REFERENCE F396_4679_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(709)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18942(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4679 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(709,F396_4679_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.feature_keyword */
static EIF_REFERENCE F396_4681_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(710)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18944(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4681 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(710,F396_4681_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.from_keyword */
static EIF_REFERENCE F396_4682_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(711)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18945(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4682 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(711,F396_4682_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.if_keyword */
static EIF_REFERENCE F396_4684_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(712)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18947(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4684 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(712,F396_4684_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.indexing_keyword */
static EIF_REFERENCE F396_4685_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(713)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18949(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4685 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(713,F396_4685_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.inherit_keyword */
static EIF_REFERENCE F396_4686_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(714)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18950(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4686 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(714,F396_4686_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.inspect_keyword */
static EIF_REFERENCE F396_4687_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(715)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18951(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4687 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(715,F396_4687_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.invariant_keyword */
static EIF_REFERENCE F396_4688_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(716)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18952(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4688 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(716,F396_4688_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.is_keyword */
static EIF_REFERENCE F396_4689_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(717)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18953(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4689 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(717,F396_4689_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.like_keyword */
static EIF_REFERENCE F396_4690_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(830)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18954(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4690 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(830,F396_4690_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.local_keyword */
static EIF_REFERENCE F396_4691_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(718)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18955(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4691 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(718,F396_4691_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.loop_keyword */
static EIF_REFERENCE F396_4692_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(719)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18956(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4692 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(719,F396_4692_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.note_keyword */
static EIF_REFERENCE F396_4693_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(720)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18958(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4693 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(720,F396_4693_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.obsolete_keyword */
static EIF_REFERENCE F396_4694_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(721)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18959(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4694 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(721,F396_4694_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.old_keyword */
static EIF_REFERENCE F396_4695_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(776)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18960(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4695 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(776,F396_4695_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.once_keyword */
static EIF_REFERENCE F396_4696_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(750)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18961(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4696 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(750,F396_4696_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.or_keyword */
static EIF_REFERENCE F396_4697_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2629)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1955, 0x01).id, 1955, _OBJSIZ_2_1_0_2_0_0_0_0_);
	F1923_18962(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4697 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2629,F396_4697_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.precursor_keyword */
static EIF_REFERENCE F396_4698_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1686)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1946, 0x01).id, 1946, _OBJSIZ_2_1_0_2_0_0_0_0_);
	F1923_18963(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4698 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1686,F396_4698_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.redefine_keyword */
static EIF_REFERENCE F396_4699_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(722)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18964(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4699 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(722,F396_4699_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.rename_keyword */
static EIF_REFERENCE F396_4701_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(723)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18966(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4701 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(723,F396_4701_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.require_keyword */
static EIF_REFERENCE F396_4702_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1704)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18967(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4702 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1704,F396_4702_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.rescue_keyword */
static EIF_REFERENCE F396_4703_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(724)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18968(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4703 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(724,F396_4703_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.result_keyword */
static EIF_REFERENCE F396_4704_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(173)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1925, 0x01).id, 1925, _OBJSIZ_2_1_0_2_0_0_0_0_);
	F1923_18969(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4704 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(173,F396_4704_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.select_keyword */
static EIF_REFERENCE F396_4706_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(725)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18971(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4706 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(725,F396_4706_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.separate_keyword */
static EIF_REFERENCE F396_4707_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2607)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18972(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4707 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2607,F396_4707_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.some_keyword */
static EIF_REFERENCE F396_4708_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(726)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18973(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4708 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(726,F396_4708_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.strip_keyword */
static EIF_REFERENCE F396_4709_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(786)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18974(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4709 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(786,F396_4709_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.then_keyword */
static EIF_REFERENCE F396_4710_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(727)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18975(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4710 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(727,F396_4710_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.true_keyword */
static EIF_REFERENCE F396_4711_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2630)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1928, 0x01).id, 1928, _OBJSIZ_2_1_0_2_0_0_0_0_);
	F1923_18976(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4711 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2630,F396_4711_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.tuple_keyword */
static EIF_REFERENCE F396_4712_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(670)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1986, 0x01).id, 1986, _OBJSIZ_2_1_0_4_0_0_0_0_);
	tr2 = RTOUCR(2009,F396_4768, (Current));
	F1987_19652(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4712 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(670,F396_4712_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.undefine_keyword */
static EIF_REFERENCE F396_4713_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(728)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18977(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4713 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(728,F396_4713_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.unique_keyword */
static EIF_REFERENCE F396_4714_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(769)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18978(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4714 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(769,F396_4714_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.until_keyword */
static EIF_REFERENCE F396_4715_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(729)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18979(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4715 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(729,F396_4715_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.variant_keyword */
static EIF_REFERENCE F396_4716_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(730)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18980(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4716 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(730,F396_4716_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.when_keyword */
static EIF_REFERENCE F396_4718_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(731)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1922, 0x01).id, 1922, _OBJSIZ_2_1_0_1_0_0_0_0_);
	F1923_18982(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_4718 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(731,F396_4718_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_any_name */

EIF_REFERENCE F396_4719 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1954,RTMS_EX_H("ANY",3,4279897));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_arguments_32_name */

EIF_REFERENCE F396_4720 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1956,RTMS_EX_H("ARGUMENTS_32",12,600945458));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_array_name */

EIF_REFERENCE F396_4721 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1957,RTMS_EX_H("ARRAY",5,1381621593));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_boolean_name */

EIF_REFERENCE F396_4722 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1958,RTMS_EX_H("BOOLEAN",7,294744910));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_character_name */

EIF_REFERENCE F396_4723 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1959,RTMS_EX_H("CHARACTER",9,1468138066));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_character_8_name */

EIF_REFERENCE F396_4724 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1960,RTMS_EX_H("CHARACTER_8",11,211000120));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_character_32_name */

EIF_REFERENCE F396_4725 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1961,RTMS_EX_H("CHARACTER_32",12,329034290));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_com_failure_name */

EIF_REFERENCE F396_4726 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1963,RTMS_EX_H("COM_FAILURE",11,1874454085));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_disposable_name */

EIF_REFERENCE F396_4727 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1965,RTMS_EX_H("DISPOSABLE",10,1014173509));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_double_name */

EIF_REFERENCE F396_4728 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1966,RTMS_EX_H("DOUBLE",6,1564708421));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_exception_name */

EIF_REFERENCE F396_4729 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1967,RTMS_EX_H("EXCEPTION",9,707992910));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_exception_manager_name */

EIF_REFERENCE F396_4730 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1968,RTMS_EX_H("EXCEPTION_MANAGER",17,959871570));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_exception_manager_factory_name */

EIF_REFERENCE F396_4731 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1970,RTMS_EX_H("EXCEPTION_MANAGER_FACTORY",25,733518937));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_function_name */

EIF_REFERENCE F396_4732 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (224,RTMS_EX_H("FUNCTION",8,1416392014));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_identified_routines_name */

EIF_REFERENCE F396_4733 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1972,RTMS_EX_H("IDENTIFIED_ROUTINES",19,1677861971));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_immutable_string_8_name */

EIF_REFERENCE F396_4734 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1973,RTMS_EX_H("IMMUTABLE_STRING_8",18,1646309944));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_immutable_string_32_name */

EIF_REFERENCE F396_4735 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1974,RTMS_EX_H("IMMUTABLE_STRING_32",19,549302066));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_integer_name */

EIF_REFERENCE F396_4736 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1975,RTMS_EX_H("INTEGER",7,1551244370));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_integer_8_name */

EIF_REFERENCE F396_4737 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1976,RTMS_EX_H("INTEGER_8",9,656945976));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_integer_16_name */

EIF_REFERENCE F396_4738 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1977,RTMS_EX_H("INTEGER_16",10,674743094));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_integer_32_name */

EIF_REFERENCE F396_4739 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1978,RTMS_EX_H("INTEGER_32",10,674743602));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_integer_64_name */

EIF_REFERENCE F396_4740 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1979,RTMS_EX_H("INTEGER_64",10,674744372));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_internal_name */

EIF_REFERENCE F396_4741 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2631,RTMS_EX_H("INTERNAL",8,19929164));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_ise_exception_manager_name */

EIF_REFERENCE F396_4742 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1980,RTMS_EX_H("ISE_EXCEPTION_MANAGER",21,953096274));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_ise_runtime_name */

EIF_REFERENCE F396_4743 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1982,RTMS_EX_H("ISE_RUNTIME",11,1482758213));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_iterable_name */

EIF_REFERENCE F396_4744 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1983,RTMS_EX_H("ITERABLE",8,576960581));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_iteration_cursor_name */

EIF_REFERENCE F396_4745 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1985,RTMS_EX_H("ITERATION_CURSOR",16,427231058));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_memory_name */

EIF_REFERENCE F396_4746 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1987,RTMS_EX_H("MEMORY",6,1448962137));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_native_array_name */

EIF_REFERENCE F396_4747 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1988,RTMS_EX_H("NATIVE_ARRAY",12,47000921));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_natural_name */

EIF_REFERENCE F396_4748 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1989,RTMS_EX_H("NATURAL",7,16463436));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_natural_8_name */

EIF_REFERENCE F396_4749 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1990,RTMS_EX_H("NATURAL_8",9,912902456));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_natural_16_name */

EIF_REFERENCE F396_4750 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1991,RTMS_EX_H("NATURAL_16",10,1775207734));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_natural_32_name */

EIF_REFERENCE F396_4751 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1992,RTMS_EX_H("NATURAL_32",10,1775208242));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_natural_64_name */

EIF_REFERENCE F396_4752 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1993,RTMS_EX_H("NATURAL_64",10,1775209012));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_none_name */

EIF_REFERENCE F396_4753 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1994,RTMS_EX_H("NONE",4,1313820229));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_platform_name */

EIF_REFERENCE F396_4754 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1996,RTMS_EX_H("PLATFORM",8,923891789));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_pointer_name */

EIF_REFERENCE F396_4755 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1997,RTMS_EX_H("POINTER",7,933228626));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_predicate_name */

EIF_REFERENCE F396_4756 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1998,RTMS_EX_H("PREDICATE",9,2074294341));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_procedure_name */

EIF_REFERENCE F396_4757 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (226,RTMS_EX_H("PROCEDURE",9,681110341));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_real_name */

EIF_REFERENCE F396_4758 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1999,RTMS_EX_H("REAL",4,1380270412));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_real_32_name */

EIF_REFERENCE F396_4759 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2000,RTMS_EX_H("REAL_32",7,1887301170));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_real_64_name */

EIF_REFERENCE F396_4760 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2001,RTMS_EX_H("REAL_64",7,1887301940));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_routine_name */

EIF_REFERENCE F396_4761 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2002,RTMS_EX_H("ROUTINE",7,2039898437));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_special_name */

EIF_REFERENCE F396_4762 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2003,RTMS_EX_H("SPECIAL",7,112362316));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_string_name */

EIF_REFERENCE F396_4763 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2004,RTMS_EX_H("STRING",6,1544365639));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_string_8_name */

EIF_REFERENCE F396_4764 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2005,RTMS_EX_H("STRING_8",8,823190840));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_string_32_name */

EIF_REFERENCE F396_4765 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2006,RTMS_EX_H("STRING_32",9,283832626));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_system_object_name */

EIF_REFERENCE F396_4766 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2007,RTMS_EX_H("SYSTEM_OBJECT",13,1917175636));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_system_string_name */

EIF_REFERENCE F396_4767 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2008,RTMS_EX_H("SYSTEM_STRING",13,2059660871));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_tuple_name */

EIF_REFERENCE F396_4768 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2009,RTMS_EX_H("TUPLE",5,1431970885));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_type_name */

EIF_REFERENCE F396_4769 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2010,RTMS_EX_H("TYPE",4,1415139397));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_typed_pointer_name */

EIF_REFERENCE F396_4770 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2011,RTMS_EX_H("TYPED_POINTER",13,1809478994));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_wide_character_name */

EIF_REFERENCE F396_4771 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2012,RTMS_EX_H("WIDE_CHARACTER",14,1657403218));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_unknown_name */

EIF_REFERENCE F396_4772 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2013,RTMS_EX_H("*UNKNOWN*",9,285110826));
}

/* {ET_TOKEN_CONSTANTS}.after_name */

EIF_REFERENCE F396_4773 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (767,RTMS_EX_H("after",5,1719649138));
}

/* {ET_TOKEN_CONSTANTS}.aliased_resized_area_name */

EIF_REFERENCE F396_4774 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2043,RTMS_EX_H("aliased_resized_area",20,872768097));
}

/* {ET_TOKEN_CONSTANTS}.area_name */

EIF_REFERENCE F396_4775 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2044,RTMS_EX_H("area",4,1634887009));
}

/* {ET_TOKEN_CONSTANTS}.argument_count_name */

EIF_REFERENCE F396_4776 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2046,RTMS_EX_H("argument_count",14,1867308660));
}

/* {ET_TOKEN_CONSTANTS}.as_integer_8_name */

EIF_REFERENCE F396_4777 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2048,RTMS_EX_H("as_integer_8",12,503428664));
}

/* {ET_TOKEN_CONSTANTS}.as_integer_16_name */

EIF_REFERENCE F396_4778 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2050,RTMS_EX_H("as_integer_16",13,28947766));
}

/* {ET_TOKEN_CONSTANTS}.as_integer_32_name */

EIF_REFERENCE F396_4779 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2052,RTMS_EX_H("as_integer_32",13,28948274));
}

/* {ET_TOKEN_CONSTANTS}.as_integer_64_name */

EIF_REFERENCE F396_4780 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2054,RTMS_EX_H("as_integer_64",13,28949044));
}

/* {ET_TOKEN_CONSTANTS}.as_natural_8_name */

EIF_REFERENCE F396_4781 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2056,RTMS_EX_H("as_natural_8",12,759385144));
}

/* {ET_TOKEN_CONSTANTS}.as_natural_16_name */

EIF_REFERENCE F396_4782 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2058,RTMS_EX_H("as_natural_16",13,1129412406));
}

/* {ET_TOKEN_CONSTANTS}.as_natural_32_name */

EIF_REFERENCE F396_4783 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2060,RTMS_EX_H("as_natural_32",13,1129412914));
}

/* {ET_TOKEN_CONSTANTS}.as_natural_64_name */

EIF_REFERENCE F396_4784 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2062,RTMS_EX_H("as_natural_64",13,1129413684));
}

/* {ET_TOKEN_CONSTANTS}.attached_type_name */

EIF_REFERENCE F396_4785 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2064,RTMS_EX_H("attached_type",13,784244837));
}

/* {ET_TOKEN_CONSTANTS}.base_address_name */

EIF_REFERENCE F396_4786 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2066,RTMS_EX_H("base_address",12,346508147));
}

/* {ET_TOKEN_CONSTANTS}.base_class_name_name */

EIF_REFERENCE F396_4787 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2632,RTMS_EX_H("base_class_name",15,498368357));
}

/* {ET_TOKEN_CONSTANTS}.bit_and_name */

EIF_REFERENCE F396_4788 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2068,RTMS_EX_H("bit_and",7,1740529508));
}

/* {ET_TOKEN_CONSTANTS}.bit_not_name */

EIF_REFERENCE F396_4789 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2070,RTMS_EX_H("bit_not",7,1741381748));
}

/* {ET_TOKEN_CONSTANTS}.bit_or_name */

EIF_REFERENCE F396_4790 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2072,RTMS_EX_H("bit_or",6,2145893746));
}

/* {ET_TOKEN_CONSTANTS}.bit_shift_left_name */

EIF_REFERENCE F396_4791 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2074,RTMS_EX_H("bit_shift_left",14,321143412));
}

/* {ET_TOKEN_CONSTANTS}.bit_shift_right_name */

EIF_REFERENCE F396_4792 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2076,RTMS_EX_H("bit_shift_right",15,675698292));
}

/* {ET_TOKEN_CONSTANTS}.bit_xor_name */

EIF_REFERENCE F396_4793 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2078,RTMS_EX_H("bit_xor",7,1742037106));
}

/* {ET_TOKEN_CONSTANTS}.boolean_bytes_name */

EIF_REFERENCE F396_4794 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2080,RTMS_EX_H("boolean_bytes",13,1522318707));
}

/* {ET_TOKEN_CONSTANTS}.boolean_field_name */

EIF_REFERENCE F396_4795 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2084,RTMS_EX_H("boolean_field",13,1252932708));
}

/* {ET_TOKEN_CONSTANTS}.boolean_field_at_name */

EIF_REFERENCE F396_4796 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2086,RTMS_EX_H("boolean_field_at",16,617314164));
}

/* {ET_TOKEN_CONSTANTS}.boolean_item_name */

EIF_REFERENCE F396_4797 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2082,RTMS_EX_H("boolean_item",12,458599277));
}

/* {ET_TOKEN_CONSTANTS}.c_strlen_name */

EIF_REFERENCE F396_4798 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2088,RTMS_EX_H("c_strlen",8,592536174));
}

/* {ET_TOKEN_CONSTANTS}.call_name */

EIF_REFERENCE F396_4799 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (227,RTMS_EX_H("call",4,1667329132));
}

/* {ET_TOKEN_CONSTANTS}.capacity_name */

EIF_REFERENCE F396_4800 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2089,RTMS_EX_H("capacity",8,1341273977));
}

/* {ET_TOKEN_CONSTANTS}.catch_name */

EIF_REFERENCE F396_4801 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2091,RTMS_EX_H("catch",5,1635777896));
}

/* {ET_TOKEN_CONSTANTS}.ccom_hresult_name */

EIF_REFERENCE F396_4802 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2093,RTMS_EX_H("ccom_hresult",12,1606732916));
}

/* {ET_TOKEN_CONSTANTS}.ccom_hresult_code_name */

EIF_REFERENCE F396_4803 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2095,RTMS_EX_H("ccom_hresult_code",17,700617573));
}

/* {ET_TOKEN_CONSTANTS}.ccom_hresult_facility_name */

EIF_REFERENCE F396_4804 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2097,RTMS_EX_H("ccom_hresult_facility",21,372176761));
}

/* {ET_TOKEN_CONSTANTS}.ceiling_real_32_name */

EIF_REFERENCE F396_4805 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2099,RTMS_EX_H("ceiling_real_32",15,1508186930));
}

/* {ET_TOKEN_CONSTANTS}.ceiling_real_64_name */

EIF_REFERENCE F396_4806 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2101,RTMS_EX_H("ceiling_real_64",15,1508187700));
}

/* {ET_TOKEN_CONSTANTS}.character_8_field_name */

EIF_REFERENCE F396_4807 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2103,RTMS_EX_H("character_8_field",17,2132459876));
}

/* {ET_TOKEN_CONSTANTS}.character_8_field_at_name */

EIF_REFERENCE F396_4808 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2105,RTMS_EX_H("character_8_field_at",20,1233371508));
}

/* {ET_TOKEN_CONSTANTS}.character_8_item_name */

EIF_REFERENCE F396_4809 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2107,RTMS_EX_H("character_8_item",16,822744429));
}

/* {ET_TOKEN_CONSTANTS}.character_32_field_name */

EIF_REFERENCE F396_4810 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2109,RTMS_EX_H("character_32_field",18,1474607972));
}

/* {ET_TOKEN_CONSTANTS}.character_32_field_at_name */

EIF_REFERENCE F396_4811 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2111,RTMS_EX_H("character_32_field_at",21,825132660));
}

/* {ET_TOKEN_CONSTANTS}.character_32_item_name */

EIF_REFERENCE F396_4812 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2113,RTMS_EX_H("character_32_item",17,1675811181));
}

/* {ET_TOKEN_CONSTANTS}.character_bytes_name */

EIF_REFERENCE F396_4813 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2115,RTMS_EX_H("character_bytes",15,1111548531));
}

/* {ET_TOKEN_CONSTANTS}.character_size_name */

EIF_REFERENCE F396_4814 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2117,RTMS_EX_H("character_size",14,1790065765));
}

/* {ET_TOKEN_CONSTANTS}.check_assert_name */

EIF_REFERENCE F396_4815 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2119,RTMS_EX_H("check_assert",12,113624692));
}

/* {ET_TOKEN_CONSTANTS}.closed_operands_name */

EIF_REFERENCE F396_4816 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2120,RTMS_EX_H("closed_operands",15,1450932595));
}

/* {ET_TOKEN_CONSTANTS}.code_name */

EIF_REFERENCE F396_4817 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2122,RTMS_EX_H("code",4,1668244581));
}

/* {ET_TOKEN_CONSTANTS}.compiler_version_name */

EIF_REFERENCE F396_4818 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2124,RTMS_EX_H("compiler_version",16,1541048942));
}

/* {ET_TOKEN_CONSTANTS}.conforms_to_name */

EIF_REFERENCE F396_4819 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2126,RTMS_EX_H("conforms_to",11,1809821807));
}

/* {ET_TOKEN_CONSTANTS}.conjuncted_name */

EIF_REFERENCE F396_4820 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2128,RTMS_EX_H("conjuncted",10,1897950564));
}

/* {ET_TOKEN_CONSTANTS}.conjuncted_semistrict_name */

EIF_REFERENCE F396_4821 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2130,RTMS_EX_H("conjuncted_semistrict",21,624337780));
}

/* {ET_TOKEN_CONSTANTS}.copy_name */

EIF_REFERENCE F396_4822 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2131,RTMS_EX_H("copy",4,1668247673));
}

/* {ET_TOKEN_CONSTANTS}.count_name */

EIF_REFERENCE F396_4823 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2132,RTMS_EX_H("count",5,1870727284));
}

/* {ET_TOKEN_CONSTANTS}.cwin_error_text_name */

EIF_REFERENCE F396_4824 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2134,RTMS_EX_H("cwin_error_text",15,967236724));
}

/* {ET_TOKEN_CONSTANTS}.cwin_local_free_name */

EIF_REFERENCE F396_4825 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2136,RTMS_EX_H("cwin_local_free",15,406962021));
}

/* {ET_TOKEN_CONSTANTS}.deep_twin_name */

EIF_REFERENCE F396_4826 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2138,RTMS_EX_H("deep_twin",9,949433454));
}

/* {ET_TOKEN_CONSTANTS}.default_name */

EIF_REFERENCE F396_4827 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2140,RTMS_EX_H("default",7,626575476));
}

/* {ET_TOKEN_CONSTANTS}.default_create_name */

EIF_REFERENCE F396_4828 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2141,RTMS_EX_H("default_create",14,1126490469));
}

/* {ET_TOKEN_CONSTANTS}.detachable_type_name */

EIF_REFERENCE F396_4829 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2143,RTMS_EX_H("detachable_type",15,2061968485));
}

/* {ET_TOKEN_CONSTANTS}.developer_raise_name */

EIF_REFERENCE F396_4830 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2145,RTMS_EX_H("developer_raise",15,94181477));
}

/* {ET_TOKEN_CONSTANTS}.disjuncted_name */

EIF_REFERENCE F396_4831 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2147,RTMS_EX_H("disjuncted",10,1612343908));
}

/* {ET_TOKEN_CONSTANTS}.disjuncted_exclusive_name */

EIF_REFERENCE F396_4832 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2149,RTMS_EX_H("disjuncted_exclusive",20,598845541));
}

/* {ET_TOKEN_CONSTANTS}.disjuncted_semistrict_name */

EIF_REFERENCE F396_4833 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2151,RTMS_EX_H("disjuncted_semistrict",21,1438679412));
}

/* {ET_TOKEN_CONSTANTS}.dispose_name */

EIF_REFERENCE F396_4834 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2152,RTMS_EX_H("dispose",7,885806437));
}

/* {ET_TOKEN_CONSTANTS}.double_bytes_name */

EIF_REFERENCE F396_4835 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2154,RTMS_EX_H("double_bytes",12,1769420147));
}

/* {ET_TOKEN_CONSTANTS}.dynamic_type_name */

EIF_REFERENCE F396_4836 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2156,RTMS_EX_H("dynamic_type",12,1099909733));
}

/* {ET_TOKEN_CONSTANTS}.dynamic_type_at_offset_name */

EIF_REFERENCE F396_4837 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2158,RTMS_EX_H("dynamic_type_at_offset",22,1088263284));
}

/* {ET_TOKEN_CONSTANTS}.eif_gen_param_id_name */

EIF_REFERENCE F396_4838 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2160,RTMS_EX_H("eif_gen_param_id",16,404463716));
}

/* {ET_TOKEN_CONSTANTS}.eif_id_object_name */

EIF_REFERENCE F396_4839 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2162,RTMS_EX_H("eif_id_object",13,1363298932));
}

/* {ET_TOKEN_CONSTANTS}.eif_object_id_name */

EIF_REFERENCE F396_4840 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2164,RTMS_EX_H("eif_object_id",13,958501732));
}

/* {ET_TOKEN_CONSTANTS}.eif_object_id_free_name */

EIF_REFERENCE F396_4841 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2166,RTMS_EX_H("eif_object_id_free",18,1963960165));
}

/* {ET_TOKEN_CONSTANTS}.element_size_name */

EIF_REFERENCE F396_4842 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2168,RTMS_EX_H("element_size",12,1118472549));
}

/* {ET_TOKEN_CONSTANTS}.exception_from_code_name */

EIF_REFERENCE F396_4843 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2170,RTMS_EX_H("exception_from_code",19,1573567077));
}

/* {ET_TOKEN_CONSTANTS}.exception_manager_name */

EIF_REFERENCE F396_4844 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2172,RTMS_EX_H("exception_manager",17,1622101362));
}

/* {ET_TOKEN_CONSTANTS}.extend_name */

EIF_REFERENCE F396_4845 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2173,RTMS_EX_H("extend",6,4820324));
}

/* {ET_TOKEN_CONSTANTS}.fast_call_name */

EIF_REFERENCE F396_4846 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2175,RTMS_EX_H("fast_call",9,1391678572));
}

/* {ET_TOKEN_CONSTANTS}.fast_item_name */

EIF_REFERENCE F396_4847 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2177,RTMS_EX_H("fast_item",9,1493585261));
}

/* {ET_TOKEN_CONSTANTS}.field_name */

EIF_REFERENCE F396_4848 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2633,RTMS_EX_H("field",5,1769037924));
}

/* {ET_TOKEN_CONSTANTS}.field_count_name */

EIF_REFERENCE F396_4849 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2634,RTMS_EX_H("field_count",11,1701141364));
}

/* {ET_TOKEN_CONSTANTS}.field_count_of_type_name */

EIF_REFERENCE F396_4850 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2179,RTMS_EX_H("field_count_of_type",19,1303840101));
}

/* {ET_TOKEN_CONSTANTS}.field_name_name */

EIF_REFERENCE F396_4851 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2635,RTMS_EX_H("field_name",10,752310629));
}

/* {ET_TOKEN_CONSTANTS}.field_name_of_type_name */

EIF_REFERENCE F396_4852 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2181,RTMS_EX_H("field_name_of_type",18,1144447589));
}

/* {ET_TOKEN_CONSTANTS}.field_offset_of_type_name */

EIF_REFERENCE F396_4853 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2183,RTMS_EX_H("field_offset_of_type",20,2120545381));
}

/* {ET_TOKEN_CONSTANTS}.field_static_type_name */

EIF_REFERENCE F396_4854 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2636,RTMS_EX_H("field_static_type",17,452747621));
}

/* {ET_TOKEN_CONSTANTS}.field_static_type_of_type_name */

EIF_REFERENCE F396_4855 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2185,RTMS_EX_H("field_static_type_of_type",25,151498853));
}

/* {ET_TOKEN_CONSTANTS}.field_type_name */

EIF_REFERENCE F396_4856 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2637,RTMS_EX_H("field_type",10,854547557));
}

/* {ET_TOKEN_CONSTANTS}.field_type_of_type_name */

EIF_REFERENCE F396_4857 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2187,RTMS_EX_H("field_type_of_type",18,1391175781));
}

/* {ET_TOKEN_CONSTANTS}.find_referers_name */

EIF_REFERENCE F396_4858 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2189,RTMS_EX_H("find_referers",13,2023236723));
}

/* {ET_TOKEN_CONSTANTS}.floor_real_32_name */

EIF_REFERENCE F396_4859 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2191,RTMS_EX_H("floor_real_32",13,601031986));
}

/* {ET_TOKEN_CONSTANTS}.floor_real_64_name */

EIF_REFERENCE F396_4860 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2193,RTMS_EX_H("floor_real_64",13,601032756));
}

/* {ET_TOKEN_CONSTANTS}.forth_name */

EIF_REFERENCE F396_4861 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (768,RTMS_EX_H("forth",5,1870555240));
}

/* {ET_TOKEN_CONSTANTS}.free_name */

EIF_REFERENCE F396_4862 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2195,RTMS_EX_H("free",4,1718773093));
}

/* {ET_TOKEN_CONSTANTS}.generating_type_name */

EIF_REFERENCE F396_4863 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2197,RTMS_EX_H("generating_type",15,1308449893));
}

/* {ET_TOKEN_CONSTANTS}.generating_type_of_type_name */

EIF_REFERENCE F396_4864 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2199,RTMS_EX_H("generating_type_of_type",23,2019132005));
}

/* {ET_TOKEN_CONSTANTS}.generator_name */

EIF_REFERENCE F396_4865 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2201,RTMS_EX_H("generator",9,1020826226));
}

/* {ET_TOKEN_CONSTANTS}.generator_of_type_name */

EIF_REFERENCE F396_4866 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2203,RTMS_EX_H("generator_of_type",17,1844223077));
}

/* {ET_TOKEN_CONSTANTS}.generic_parameter_count_name */

EIF_REFERENCE F396_4867 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2205,RTMS_EX_H("generic_parameter_count",23,1439717748));
}

/* {ET_TOKEN_CONSTANTS}.generic_parameter_type_name */

EIF_REFERENCE F396_4868 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2207,RTMS_EX_H("generic_parameter_type",22,1138738533));
}

/* {ET_TOKEN_CONSTANTS}.has_default_name */

EIF_REFERENCE F396_4869 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2209,RTMS_EX_H("has_default",11,1777575796));
}

/* {ET_TOKEN_CONSTANTS}.hash_code_name */

EIF_REFERENCE F396_4870 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2211,RTMS_EX_H("hash_code",9,1486965861));
}

/* {ET_TOKEN_CONSTANTS}.i_th_argument_pointer_name */

EIF_REFERENCE F396_4871 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2213,RTMS_EX_H("i_th_argument_pointer",21,1439091570));
}

/* {ET_TOKEN_CONSTANTS}.i_th_argument_string_name */

EIF_REFERENCE F396_4872 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2215,RTMS_EX_H("i_th_argument_string",20,648762215));
}

/* {ET_TOKEN_CONSTANTS}.identity_name */

EIF_REFERENCE F396_4873 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2217,RTMS_EX_H("identity",8,968811641));
}

/* {ET_TOKEN_CONSTANTS}.ieee_is_equal_name */

EIF_REFERENCE F396_4874 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2219,RTMS_EX_H("ieee_is_equal",13,1564915564));
}

/* {ET_TOKEN_CONSTANTS}.ieee_is_greater_name */

EIF_REFERENCE F396_4875 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2221,RTMS_EX_H("ieee_is_greater",15,2122238066));
}

/* {ET_TOKEN_CONSTANTS}.ieee_is_greater_equal_name */

EIF_REFERENCE F396_4876 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2223,RTMS_EX_H("ieee_is_greater_equal",21,244322924));
}

/* {ET_TOKEN_CONSTANTS}.ieee_is_less_name */

EIF_REFERENCE F396_4877 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2225,RTMS_EX_H("ieee_is_less",12,743522419));
}

/* {ET_TOKEN_CONSTANTS}.ieee_is_less_equal_name */

EIF_REFERENCE F396_4878 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2227,RTMS_EX_H("ieee_is_less_equal",18,1146885228));
}

/* {ET_TOKEN_CONSTANTS}.ieee_maximum_number_name */

EIF_REFERENCE F396_4879 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2229,RTMS_EX_H("ieee_maximum_number",19,137407602));
}

/* {ET_TOKEN_CONSTANTS}.ieee_minimum_number_name */

EIF_REFERENCE F396_4880 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2231,RTMS_EX_H("ieee_minimum_number",19,702745970));
}

/* {ET_TOKEN_CONSTANTS}.ignore_name */

EIF_REFERENCE F396_4881 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2233,RTMS_EX_H("ignore",6,2060026981));
}

/* {ET_TOKEN_CONSTANTS}.implication_name */

EIF_REFERENCE F396_4882 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2235,RTMS_EX_H("implication",11,951798382));
}

/* {ET_TOKEN_CONSTANTS}.in_assertion_name */

EIF_REFERENCE F396_4883 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2237,RTMS_EX_H("in_assertion",12,1016899182));
}

/* {ET_TOKEN_CONSTANTS}.init_exception_manager_name */

EIF_REFERENCE F396_4884 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2238,RTMS_EX_H("init_exception_manager",22,1651556722));
}

/* {ET_TOKEN_CONSTANTS}.integer_8_field_name */

EIF_REFERENCE F396_4885 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2240,RTMS_EX_H("integer_8_field",15,1777428324));
}

/* {ET_TOKEN_CONSTANTS}.integer_8_field_at_name */

EIF_REFERENCE F396_4886 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2242,RTMS_EX_H("integer_8_field_at",18,1319823988));
}

/* {ET_TOKEN_CONSTANTS}.integer_8_item_name */

EIF_REFERENCE F396_4887 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2244,RTMS_EX_H("integer_8_item",14,771026029));
}

/* {ET_TOKEN_CONSTANTS}.integer_16_field_name */

EIF_REFERENCE F396_4888 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2246,RTMS_EX_H("integer_16_field",16,646007908));
}

/* {ET_TOKEN_CONSTANTS}.integer_16_field_at_name */

EIF_REFERENCE F396_4889 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2248,RTMS_EX_H("integer_16_field_at",19,1736888436));
}

/* {ET_TOKEN_CONSTANTS}.integer_16_item_name */

EIF_REFERENCE F396_4890 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2250,RTMS_EX_H("integer_16_item",15,322010989));
}

/* {ET_TOKEN_CONSTANTS}.integer_32_field_name */

EIF_REFERENCE F396_4891 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2252,RTMS_EX_H("integer_32_field",16,780682596));
}

/* {ET_TOKEN_CONSTANTS}.integer_32_field_at_name */

EIF_REFERENCE F396_4892 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2254,RTMS_EX_H("integer_32_field_at",19,1482169460));
}

/* {ET_TOKEN_CONSTANTS}.integer_32_item_name */

EIF_REFERENCE F396_4893 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2256,RTMS_EX_H("integer_32_item",15,1320779629));
}

/* {ET_TOKEN_CONSTANTS}.integer_64_field_name */

EIF_REFERENCE F396_4894 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2258,RTMS_EX_H("integer_64_field",16,1788006756));
}

/* {ET_TOKEN_CONSTANTS}.integer_64_field_at_name */

EIF_REFERENCE F396_4895 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2260,RTMS_EX_H("integer_64_field_at",19,1637176948));
}

/* {ET_TOKEN_CONSTANTS}.integer_64_item_name */

EIF_REFERENCE F396_4896 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2262,RTMS_EX_H("integer_64_item",15,687181421));
}

/* {ET_TOKEN_CONSTANTS}.integer_bytes_name */

EIF_REFERENCE F396_4897 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2264,RTMS_EX_H("integer_bytes",13,515756403));
}

/* {ET_TOKEN_CONSTANTS}.integer_quotient_name */

EIF_REFERENCE F396_4898 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2266,RTMS_EX_H("integer_quotient",16,189059956));
}

/* {ET_TOKEN_CONSTANTS}.integer_remainder_name */

EIF_REFERENCE F396_4899 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2268,RTMS_EX_H("integer_remainder",17,316436338));
}

/* {ET_TOKEN_CONSTANTS}.is_64_bits_name */

EIF_REFERENCE F396_4900 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2270,RTMS_EX_H("is_64_bits",10,1985134707));
}

/* {ET_TOKEN_CONSTANTS}.is_attached_name */

EIF_REFERENCE F396_4901 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2272,RTMS_EX_H("is_attached",11,1339041892));
}

/* {ET_TOKEN_CONSTANTS}.is_attached_type_name */

EIF_REFERENCE F396_4902 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2274,RTMS_EX_H("is_attached_type",16,1221887589));
}

/* {ET_TOKEN_CONSTANTS}.is_caught_name */

EIF_REFERENCE F396_4903 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2276,RTMS_EX_H("is_caught",9,365336692));
}

/* {ET_TOKEN_CONSTANTS}.is_copy_semantics_field_name */

EIF_REFERENCE F396_4904 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2278,RTMS_EX_H("is_copy_semantics_field",23,153299300));
}

/* {ET_TOKEN_CONSTANTS}.is_deep_equal_name */

EIF_REFERENCE F396_4905 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2280,RTMS_EX_H("is_deep_equal",13,1449661292));
}

/* {ET_TOKEN_CONSTANTS}.is_default_pointer_name */

EIF_REFERENCE F396_4906 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2282,RTMS_EX_H("is_default_pointer",18,547256434));
}

/* {ET_TOKEN_CONSTANTS}.is_deferred_name */

EIF_REFERENCE F396_4907 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2284,RTMS_EX_H("is_deferred",11,457244516));
}

/* {ET_TOKEN_CONSTANTS}.is_dotnet_name */

EIF_REFERENCE F396_4908 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2286,RTMS_EX_H("is_dotnet",9,351091060));
}

/* {ET_TOKEN_CONSTANTS}.is_equal_name */

EIF_REFERENCE F396_4909 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2287,RTMS_EX_H("is_equal",8,2014703724));
}

/* {ET_TOKEN_CONSTANTS}.is_expanded_name */

EIF_REFERENCE F396_4910 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2289,RTMS_EX_H("is_expanded",11,1382172516));
}

/* {ET_TOKEN_CONSTANTS}.is_field_expanded_of_type_name */

EIF_REFERENCE F396_4911 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2291,RTMS_EX_H("is_field_expanded_of_type",25,299225957));
}

/* {ET_TOKEN_CONSTANTS}.is_field_transient_of_type_name */

EIF_REFERENCE F396_4912 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2293,RTMS_EX_H("is_field_transient_of_type",26,1169240677));
}

/* {ET_TOKEN_CONSTANTS}.is_ignorable_name */

EIF_REFERENCE F396_4913 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2295,RTMS_EX_H("is_ignorable",12,851885157));
}

/* {ET_TOKEN_CONSTANTS}.is_ignored_name */

EIF_REFERENCE F396_4914 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2297,RTMS_EX_H("is_ignored",10,56112740));
}

/* {ET_TOKEN_CONSTANTS}.is_less_name */

EIF_REFERENCE F396_4915 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2299,RTMS_EX_H("is_less",7,1206652019));
}

/* {ET_TOKEN_CONSTANTS}.is_mac_name */

EIF_REFERENCE F396_4916 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2301,RTMS_EX_H("is_mac",6,1808325475));
}

/* {ET_TOKEN_CONSTANTS}.is_nan_name */

EIF_REFERENCE F396_4917 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2303,RTMS_EX_H("is_nan",6,1808391022));
}

/* {ET_TOKEN_CONSTANTS}.is_negative_infinity_name */

EIF_REFERENCE F396_4918 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2305,RTMS_EX_H("is_negative_infinity",20,449346169));
}

/* {ET_TOKEN_CONSTANTS}.is_object_marked_name */

EIF_REFERENCE F396_4919 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2307,RTMS_EX_H("is_object_marked",16,1176367716));
}

/* {ET_TOKEN_CONSTANTS}.is_positive_infinity_name */

EIF_REFERENCE F396_4920 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2309,RTMS_EX_H("is_positive_infinity",20,1653234297));
}

/* {ET_TOKEN_CONSTANTS}.is_raisable_name */

EIF_REFERENCE F396_4921 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2311,RTMS_EX_H("is_raisable",11,314430309));
}

/* {ET_TOKEN_CONSTANTS}.is_scoop_capable_name */

EIF_REFERENCE F396_4922 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2313,RTMS_EX_H("is_scoop_capable",16,1289087845));
}

/* {ET_TOKEN_CONSTANTS}.is_special_name */

EIF_REFERENCE F396_4923 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2315,RTMS_EX_H("is_special",10,610026092));
}

/* {ET_TOKEN_CONSTANTS}.is_special_copy_semantics_item_name */

EIF_REFERENCE F396_4924 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2317,RTMS_EX_H("is_special_copy_semantics_item",30,381246317));
}

/* {ET_TOKEN_CONSTANTS}.is_special_of_expanded_name */

EIF_REFERENCE F396_4925 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2319,RTMS_EX_H("is_special_of_expanded",22,599742820));
}

/* {ET_TOKEN_CONSTANTS}.is_special_of_reference_name */

EIF_REFERENCE F396_4926 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2321,RTMS_EX_H("is_special_of_reference",23,1112545893));
}

/* {ET_TOKEN_CONSTANTS}.is_special_of_reference_or_basic_type_name */

EIF_REFERENCE F396_4927 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2323,RTMS_EX_H("is_special_of_reference_or_basic_type",37,2107801701));
}

/* {ET_TOKEN_CONSTANTS}.is_special_of_reference_type_name */

EIF_REFERENCE F396_4928 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2325,RTMS_EX_H("is_special_of_reference_type",28,1971079781));
}

/* {ET_TOKEN_CONSTANTS}.is_thread_capable_name */

EIF_REFERENCE F396_4929 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2327,RTMS_EX_H("is_thread_capable",17,26037349));
}

/* {ET_TOKEN_CONSTANTS}.is_tuple_name */

EIF_REFERENCE F396_4930 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2329,RTMS_EX_H("is_tuple",8,2081602917));
}

/* {ET_TOKEN_CONSTANTS}.is_tuple_type_name */

EIF_REFERENCE F396_4931 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2331,RTMS_EX_H("is_tuple_type",13,1519168101));
}

/* {ET_TOKEN_CONSTANTS}.is_unix_name */

EIF_REFERENCE F396_4932 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2333,RTMS_EX_H("is_unix",7,1358234232));
}

/* {ET_TOKEN_CONSTANTS}.is_vms_name */

EIF_REFERENCE F396_4933 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2335,RTMS_EX_H("is_vms",6,1808918387));
}

/* {ET_TOKEN_CONSTANTS}.is_vxworks_name */

EIF_REFERENCE F396_4934 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2337,RTMS_EX_H("is_vxworks",10,190281587));
}

/* {ET_TOKEN_CONSTANTS}.is_windows_name */

EIF_REFERENCE F396_4935 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2339,RTMS_EX_H("is_windows",10,479294835));
}

/* {ET_TOKEN_CONSTANTS}.item_name */

EIF_REFERENCE F396_4936 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (225,RTMS_EX_H("item",4,1769235821));
}

/* {ET_TOKEN_CONSTANTS}.item_code_name */

EIF_REFERENCE F396_4937 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2341,RTMS_EX_H("item_code",9,956164965));
}

/* {ET_TOKEN_CONSTANTS}.last_exception_name */

EIF_REFERENCE F396_4938 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2342,RTMS_EX_H("last_exception",14,1064129134));
}

/* {ET_TOKEN_CONSTANTS}.last_result_name */

EIF_REFERENCE F396_4939 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2638,RTMS_EX_H("last_result",11,1768500852));
}

/* {ET_TOKEN_CONSTANTS}.lock_marking_name */

EIF_REFERENCE F396_4940 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2344,RTMS_EX_H("lock_marking",12,1859747943));
}

/* {ET_TOKEN_CONSTANTS}.lower_name */

EIF_REFERENCE F396_4941 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2345,RTMS_EX_H("lower",5,1870925170));
}

/* {ET_TOKEN_CONSTANTS}.make_name */

EIF_REFERENCE F396_4942 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2639,RTMS_EX_H("make",4,1835101029));
}

/* {ET_TOKEN_CONSTANTS}.make_empty_name */

EIF_REFERENCE F396_4943 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2347,RTMS_EX_H("make_empty",10,1497951609));
}

/* {ET_TOKEN_CONSTANTS}.mark_object_name */

EIF_REFERENCE F396_4944 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2349,RTMS_EX_H("mark_object",11,1556389748));
}

/* {ET_TOKEN_CONSTANTS}.max_type_id_name */

EIF_REFERENCE F396_4945 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2640,RTMS_EX_H("max_type_id",11,1675256932));
}

/* {ET_TOKEN_CONSTANTS}.minus_name */

EIF_REFERENCE F396_4946 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2351,RTMS_EX_H("minus",5,1769683827));
}

/* {ET_TOKEN_CONSTANTS}.name_name */

EIF_REFERENCE F396_4947 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2641,RTMS_EX_H("name",4,1851878757));
}

/* {ET_TOKEN_CONSTANTS}.nan_name */

EIF_REFERENCE F396_4948 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2353,RTMS_EX_H("nan",3,7233902));
}

/* {ET_TOKEN_CONSTANTS}.natural_8_field_name */

EIF_REFERENCE F396_4949 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2355,RTMS_EX_H("natural_8_field",15,210441060));
}

/* {ET_TOKEN_CONSTANTS}.natural_8_field_at_name */

EIF_REFERENCE F396_4950 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2357,RTMS_EX_H("natural_8_field_at",18,1554761844));
}

/* {ET_TOKEN_CONSTANTS}.natural_8_item_name */

EIF_REFERENCE F396_4951 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2359,RTMS_EX_H("natural_8_item",14,2006416749));
}

/* {ET_TOKEN_CONSTANTS}.natural_16_field_name */

EIF_REFERENCE F396_4952 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2361,RTMS_EX_H("natural_16_field",16,1075992420));
}

/* {ET_TOKEN_CONSTANTS}.natural_16_field_at_name */

EIF_REFERENCE F396_4953 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2363,RTMS_EX_H("natural_16_field_at",19,1751544948));
}

/* {ET_TOKEN_CONSTANTS}.natural_16_item_name */

EIF_REFERENCE F396_4954 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2365,RTMS_EX_H("natural_16_item",15,902503533));
}

/* {ET_TOKEN_CONSTANTS}.natural_32_code_name */

EIF_REFERENCE F396_4955 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2367,RTMS_EX_H("natural_32_code",15,1800280933));
}

/* {ET_TOKEN_CONSTANTS}.natural_32_field_name */

EIF_REFERENCE F396_4956 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2369,RTMS_EX_H("natural_32_field",16,1210667108));
}

/* {ET_TOKEN_CONSTANTS}.natural_32_field_at_name */

EIF_REFERENCE F396_4957 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2371,RTMS_EX_H("natural_32_field_at",19,1496825972));
}

/* {ET_TOKEN_CONSTANTS}.natural_32_item_name */

EIF_REFERENCE F396_4958 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2373,RTMS_EX_H("natural_32_item",15,1901272173));
}

/* {ET_TOKEN_CONSTANTS}.natural_64_field_name */

EIF_REFERENCE F396_4959 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2375,RTMS_EX_H("natural_64_field",16,70511460));
}

/* {ET_TOKEN_CONSTANTS}.natural_64_field_at_name */

EIF_REFERENCE F396_4960 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2377,RTMS_EX_H("natural_64_field_at",19,1651833460));
}

/* {ET_TOKEN_CONSTANTS}.natural_64_item_name */

EIF_REFERENCE F396_4961 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2379,RTMS_EX_H("natural_64_item",15,1267673965));
}

/* {ET_TOKEN_CONSTANTS}.negated_name */

EIF_REFERENCE F396_4962 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2381,RTMS_EX_H("negated",7,1364720996));
}

/* {ET_TOKEN_CONSTANTS}.negative_infinity_name */

EIF_REFERENCE F396_4963 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2383,RTMS_EX_H("negative_infinity",17,158910329));
}

/* {ET_TOKEN_CONSTANTS}.new_cursor_name */

EIF_REFERENCE F396_4964 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (766,RTMS_EX_H("new_cursor",10,1023431282));
}

/* {ET_TOKEN_CONSTANTS}.new_instance_name */

EIF_REFERENCE F396_4965 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2642,RTMS_EX_H("new_instance",12,2043116389));
}

/* {ET_TOKEN_CONSTANTS}.new_instance_of_name */

EIF_REFERENCE F396_4966 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2385,RTMS_EX_H("new_instance_of",15,717327462));
}

/* {ET_TOKEN_CONSTANTS}.new_special_any_instance_name */

EIF_REFERENCE F396_4967 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2643,RTMS_EX_H("new_special_any_instance",24,899350117));
}

/* {ET_TOKEN_CONSTANTS}.new_special_of_reference_instance_of_name */

EIF_REFERENCE F396_4968 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2387,RTMS_EX_H("new_special_of_reference_instance_of",36,538957158));
}

/* {ET_TOKEN_CONSTANTS}.new_tuple_instance_of_name */

EIF_REFERENCE F396_4969 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2389,RTMS_EX_H("new_tuple_instance_of",21,831925350));
}

/* {ET_TOKEN_CONSTANTS}.new_type_instance_of_name */

EIF_REFERENCE F396_4970 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2391,RTMS_EX_H("new_type_instance_of",20,1543983462));
}

/* {ET_TOKEN_CONSTANTS}.object_comparison_name */

EIF_REFERENCE F396_4971 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2393,RTMS_EX_H("object_comparison",17,2049833582));
}

/* {ET_TOKEN_CONSTANTS}.object_size_name */

EIF_REFERENCE F396_4972 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2395,RTMS_EX_H("object_size",11,1190964325));
}

/* {ET_TOKEN_CONSTANTS}.once_objects_name */

EIF_REFERENCE F396_4973 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2397,RTMS_EX_H("once_objects",12,1272400755));
}

/* {ET_TOKEN_CONSTANTS}.once_raise_name */

EIF_REFERENCE F396_4974 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2398,RTMS_EX_H("once_raise",10,47985509));
}

/* {ET_TOKEN_CONSTANTS}.opposite_name */

EIF_REFERENCE F396_4975 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2400,RTMS_EX_H("opposite",8,572409701));
}

/* {ET_TOKEN_CONSTANTS}.out_name */

EIF_REFERENCE F396_4976 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2402,RTMS_EX_H("out",3,7304564));
}

/* {ET_TOKEN_CONSTANTS}.persistent_field_count_of_type_name */

EIF_REFERENCE F396_4977 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2404,RTMS_EX_H("persistent_field_count_of_type",30,1565939045));
}

/* {ET_TOKEN_CONSTANTS}.plus_name */

EIF_REFERENCE F396_4978 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2406,RTMS_EX_H("plus",4,1886156147));
}

/* {ET_TOKEN_CONSTANTS}.pointer_bytes_name */

EIF_REFERENCE F396_4979 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2408,RTMS_EX_H("pointer_bytes",13,498857075));
}

/* {ET_TOKEN_CONSTANTS}.pointer_field_name */

EIF_REFERENCE F396_4980 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2410,RTMS_EX_H("pointer_field",13,229471076));
}

/* {ET_TOKEN_CONSTANTS}.pointer_field_at_name */

EIF_REFERENCE F396_4981 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2412,RTMS_EX_H("pointer_field_at",16,2125662324));
}

/* {ET_TOKEN_CONSTANTS}.pointer_item_name */

EIF_REFERENCE F396_4982 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2413,RTMS_EX_H("pointer_item",12,1201186157));
}

/* {ET_TOKEN_CONSTANTS}.positive_infinity_name */

EIF_REFERENCE F396_4983 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2415,RTMS_EX_H("positive_infinity",17,1362798457));
}

/* {ET_TOKEN_CONSTANTS}.power_name */

EIF_REFERENCE F396_4984 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2417,RTMS_EX_H("power",5,1870955890));
}

/* {ET_TOKEN_CONSTANTS}.pre_ecma_mapping_status_name */

EIF_REFERENCE F396_4985 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2419,RTMS_EX_H("pre_ecma_mapping_status",23,725803379));
}

/* {ET_TOKEN_CONSTANTS}.product_name */

EIF_REFERENCE F396_4986 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2421,RTMS_EX_H("product",7,299891316));
}

/* {ET_TOKEN_CONSTANTS}.put_name */

EIF_REFERENCE F396_4987 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2422,RTMS_EX_H("put",3,7370100));
}

/* {ET_TOKEN_CONSTANTS}.put_boolean_name */

EIF_REFERENCE F396_4988 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2424,RTMS_EX_H("put_boolean",11,283684206));
}

/* {ET_TOKEN_CONSTANTS}.put_character_8_name */

EIF_REFERENCE F396_4989 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2426,RTMS_EX_H("put_character_8",15,1702953784));
}

/* {ET_TOKEN_CONSTANTS}.put_character_32_name */

EIF_REFERENCE F396_4990 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2428,RTMS_EX_H("put_character_32",16,17766450));
}

/* {ET_TOKEN_CONSTANTS}.put_integer_8_name */

EIF_REFERENCE F396_4991 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2430,RTMS_EX_H("put_integer_8",13,1630823736));
}

/* {ET_TOKEN_CONSTANTS}.put_integer_16_name */

EIF_REFERENCE F396_4992 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2432,RTMS_EX_H("put_integer_16",14,879791926));
}

/* {ET_TOKEN_CONSTANTS}.put_integer_32_name */

EIF_REFERENCE F396_4993 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2434,RTMS_EX_H("put_integer_32",14,879792434));
}

/* {ET_TOKEN_CONSTANTS}.put_integer_64_name */

EIF_REFERENCE F396_4994 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2436,RTMS_EX_H("put_integer_64",14,879793204));
}

/* {ET_TOKEN_CONSTANTS}.put_natural_8_name */

EIF_REFERENCE F396_4995 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2438,RTMS_EX_H("put_natural_8",13,1886780216));
}

/* {ET_TOKEN_CONSTANTS}.put_natural_16_name */

EIF_REFERENCE F396_4996 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2440,RTMS_EX_H("put_natural_16",14,1980256566));
}

/* {ET_TOKEN_CONSTANTS}.put_natural_32_name */

EIF_REFERENCE F396_4997 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2442,RTMS_EX_H("put_natural_32",14,1980257074));
}

/* {ET_TOKEN_CONSTANTS}.put_natural_64_name */

EIF_REFERENCE F396_4998 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2444,RTMS_EX_H("put_natural_64",14,1980257844));
}

/* {ET_TOKEN_CONSTANTS}.put_pointer_name */

EIF_REFERENCE F396_4999 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2446,RTMS_EX_H("put_pointer",11,922167922));
}

/* {ET_TOKEN_CONSTANTS}.put_real_32_name */

EIF_REFERENCE F396_5000 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2448,RTMS_EX_H("put_real_32",11,1874135090));
}

/* {ET_TOKEN_CONSTANTS}.put_real_64_name */

EIF_REFERENCE F396_5001 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2450,RTMS_EX_H("put_real_64",11,1874135860));
}

/* {ET_TOKEN_CONSTANTS}.put_reference_name */

EIF_REFERENCE F396_5002 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2451,RTMS_EX_H("put_reference",13,1555423845));
}

/* {ET_TOKEN_CONSTANTS}.quotient_name */

EIF_REFERENCE F396_5003 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2453,RTMS_EX_H("quotient",8,772009588));
}

/* {ET_TOKEN_CONSTANTS}.raise_name */

EIF_REFERENCE F396_5004 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2455,RTMS_EX_H("raise",5,1635176293));
}

/* {ET_TOKEN_CONSTANTS}.raw_reference_field_at_name */

EIF_REFERENCE F396_5005 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2457,RTMS_EX_H("raw_reference_field_at",22,881538164));
}

/* {ET_TOKEN_CONSTANTS}.raw_reference_field_at_offset_name */

EIF_REFERENCE F396_5006 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2459,RTMS_EX_H("raw_reference_field_at_offset",29,261111668));
}

/* {ET_TOKEN_CONSTANTS}.real_32_field_name */

EIF_REFERENCE F396_5007 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2461,RTMS_EX_H("real_32_field",13,155478884));
}

/* {ET_TOKEN_CONSTANTS}.real_32_field_at_name */

EIF_REFERENCE F396_5008 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2463,RTMS_EX_H("real_32_field_at",16,2053376372));
}

/* {ET_TOKEN_CONSTANTS}.real_32_item_name */

EIF_REFERENCE F396_5009 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2465,RTMS_EX_H("real_32_item",12,194265965));
}

/* {ET_TOKEN_CONSTANTS}.real_64_field_name */

EIF_REFERENCE F396_5010 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2467,RTMS_EX_H("real_64_field",13,1162803044));
}

/* {ET_TOKEN_CONSTANTS}.real_64_field_at_name */

EIF_REFERENCE F396_5011 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2469,RTMS_EX_H("real_64_field_at",16,60904052));
}

/* {ET_TOKEN_CONSTANTS}.real_64_item_name */

EIF_REFERENCE F396_5012 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2471,RTMS_EX_H("real_64_item",12,1708147565));
}

/* {ET_TOKEN_CONSTANTS}.real_bytes_name */

EIF_REFERENCE F396_5013 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2473,RTMS_EX_H("real_bytes",10,1497073523));
}

/* {ET_TOKEN_CONSTANTS}.reference_field_name */

EIF_REFERENCE F396_5014 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2475,RTMS_EX_H("reference_field",15,1663803492));
}

/* {ET_TOKEN_CONSTANTS}.reference_field_at_name */

EIF_REFERENCE F396_5015 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2477,RTMS_EX_H("reference_field_at",18,58558836));
}

/* {ET_TOKEN_CONSTANTS}.reference_field_at_offset_name */

EIF_REFERENCE F396_5016 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2479,RTMS_EX_H("reference_field_at_offset",25,1848547444));
}

/* {ET_TOKEN_CONSTANTS}.reference_item_name */

EIF_REFERENCE F396_5017 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2480,RTMS_EX_H("reference_item",14,1231954797));
}

/* {ET_TOKEN_CONSTANTS}.rout_disp_name */

EIF_REFERENCE F396_5018 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2481,RTMS_EX_H("rout_disp",9,979149424));
}

/* {ET_TOKEN_CONSTANTS}.runtime_name_name */

EIF_REFERENCE F396_5019 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2483,RTMS_EX_H("runtime_name",12,962337381));
}

/* {ET_TOKEN_CONSTANTS}.same_type_name */

EIF_REFERENCE F396_5020 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2485,RTMS_EX_H("same_type",9,1543326053));
}

/* {ET_TOKEN_CONSTANTS}.set_boolean_field_name */

EIF_REFERENCE F396_5021 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2487,RTMS_EX_H("set_boolean_field",17,198024292));
}

/* {ET_TOKEN_CONSTANTS}.set_boolean_field_at_name */

EIF_REFERENCE F396_5022 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2489,RTMS_EX_H("set_boolean_field_at",20,1182258804));
}

/* {ET_TOKEN_CONSTANTS}.set_character_8_field_name */

EIF_REFERENCE F396_5023 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2491,RTMS_EX_H("set_character_8_field",21,729660772));
}

/* {ET_TOKEN_CONSTANTS}.set_character_8_field_at_name */

EIF_REFERENCE F396_5024 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2493,RTMS_EX_H("set_character_8_field_at",24,2098994548));
}

/* {ET_TOKEN_CONSTANTS}.set_character_32_field_name */

EIF_REFERENCE F396_5025 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2495,RTMS_EX_H("set_character_32_field",22,987165284));
}

/* {ET_TOKEN_CONSTANTS}.set_character_32_field_at_name */

EIF_REFERENCE F396_5026 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2497,RTMS_EX_H("set_character_32_field_at",25,1234210676));
}

/* {ET_TOKEN_CONSTANTS}.set_count_name */

EIF_REFERENCE F396_5027 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2499,RTMS_EX_H("set_count",9,676588916));
}

/* {ET_TOKEN_CONSTANTS}.set_exception_data_name */

EIF_REFERENCE F396_5028 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2500,RTMS_EX_H("set_exception_data",18,88175201));
}

/* {ET_TOKEN_CONSTANTS}.set_integer_8_field_name */

EIF_REFERENCE F396_5029 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2502,RTMS_EX_H("set_integer_8_field",19,1116936292));
}

/* {ET_TOKEN_CONSTANTS}.set_integer_8_field_at_name */

EIF_REFERENCE F396_5030 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2504,RTMS_EX_H("set_integer_8_field_at",22,832381300));
}

/* {ET_TOKEN_CONSTANTS}.set_integer_16_field_name */

EIF_REFERENCE F396_5031 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2506,RTMS_EX_H("set_integer_16_field",20,1210952548));
}

/* {ET_TOKEN_CONSTANTS}.set_integer_16_field_at_name */

EIF_REFERENCE F396_5032 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2508,RTMS_EX_H("set_integer_16_field_at",23,1505389172));
}

/* {ET_TOKEN_CONSTANTS}.set_integer_32_field_name */

EIF_REFERENCE F396_5033 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2510,RTMS_EX_H("set_integer_32_field",20,1345627236));
}

/* {ET_TOKEN_CONSTANTS}.set_integer_32_field_at_name */

EIF_REFERENCE F396_5034 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2512,RTMS_EX_H("set_integer_32_field_at",23,1250670196));
}

/* {ET_TOKEN_CONSTANTS}.set_integer_64_field_name */

EIF_REFERENCE F396_5035 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2514,RTMS_EX_H("set_integer_64_field",20,205471588));
}

/* {ET_TOKEN_CONSTANTS}.set_integer_64_field_at_name */

EIF_REFERENCE F396_5036 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2516,RTMS_EX_H("set_integer_64_field_at",23,1405677684));
}

/* {ET_TOKEN_CONSTANTS}.set_is_ignored_name */

EIF_REFERENCE F396_5037 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2518,RTMS_EX_H("set_is_ignored",14,1595767652));
}

/* {ET_TOKEN_CONSTANTS}.set_item_name */

EIF_REFERENCE F396_5038 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2520,RTMS_EX_H("set_item",8,1319975789));
}

/* {ET_TOKEN_CONSTANTS}.set_natural_8_field_name */

EIF_REFERENCE F396_5039 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2522,RTMS_EX_H("set_natural_8_field",19,1697428836));
}

/* {ET_TOKEN_CONSTANTS}.set_natural_8_field_at_name */

EIF_REFERENCE F396_5040 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2524,RTMS_EX_H("set_natural_8_field_at",22,1067319156));
}

/* {ET_TOKEN_CONSTANTS}.set_natural_16_field_name */

EIF_REFERENCE F396_5041 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2526,RTMS_EX_H("set_natural_16_field",20,1640937060));
}

/* {ET_TOKEN_CONSTANTS}.set_natural_16_field_at_name */

EIF_REFERENCE F396_5042 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2528,RTMS_EX_H("set_natural_16_field_at",23,1520045684));
}

/* {ET_TOKEN_CONSTANTS}.set_natural_32_field_name */

EIF_REFERENCE F396_5043 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2530,RTMS_EX_H("set_natural_32_field",20,1775611748));
}

/* {ET_TOKEN_CONSTANTS}.set_natural_32_field_at_name */

EIF_REFERENCE F396_5044 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2532,RTMS_EX_H("set_natural_32_field_at",23,1265326708));
}

/* {ET_TOKEN_CONSTANTS}.set_natural_64_field_name */

EIF_REFERENCE F396_5045 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2534,RTMS_EX_H("set_natural_64_field",20,635456100));
}

/* {ET_TOKEN_CONSTANTS}.set_natural_64_field_at_name */

EIF_REFERENCE F396_5046 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2536,RTMS_EX_H("set_natural_64_field_at",23,1420334196));
}

/* {ET_TOKEN_CONSTANTS}.set_object_comparison_name */

EIF_REFERENCE F396_5047 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2538,RTMS_EX_H("set_object_comparison",21,647034478));
}

/* {ET_TOKEN_CONSTANTS}.set_operands_name */

EIF_REFERENCE F396_5048 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2644,RTMS_EX_H("set_operands",12,932145267));
}

/* {ET_TOKEN_CONSTANTS}.set_pointer_field_name */

EIF_REFERENCE F396_5049 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2540,RTMS_EX_H("set_pointer_field",17,1322042468));
}

/* {ET_TOKEN_CONSTANTS}.set_pointer_field_at_name */

EIF_REFERENCE F396_5050 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2542,RTMS_EX_H("set_pointer_field_at",20,543127156));
}

/* {ET_TOKEN_CONSTANTS}.set_pre_ecma_mapping_name */

EIF_REFERENCE F396_5051 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2544,RTMS_EX_H("set_pre_ecma_mapping",20,1108238439));
}

/* {ET_TOKEN_CONSTANTS}.set_real_32_field_name */

EIF_REFERENCE F396_5052 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2546,RTMS_EX_H("set_real_32_field",17,1248050276));
}

/* {ET_TOKEN_CONSTANTS}.set_real_32_field_at_name */

EIF_REFERENCE F396_5053 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2548,RTMS_EX_H("set_real_32_field_at",20,470841204));
}

/* {ET_TOKEN_CONSTANTS}.set_real_64_field_name */

EIF_REFERENCE F396_5054 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2550,RTMS_EX_H("set_real_64_field",17,107894628));
}

/* {ET_TOKEN_CONSTANTS}.set_real_64_field_at_name */

EIF_REFERENCE F396_5055 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2552,RTMS_EX_H("set_real_64_field_at",20,625848692));
}

/* {ET_TOKEN_CONSTANTS}.set_reference_field_name */

EIF_REFERENCE F396_5056 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2554,RTMS_EX_H("set_reference_field",19,1003311460));
}

/* {ET_TOKEN_CONSTANTS}.set_reference_field_at_name */

EIF_REFERENCE F396_5057 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2556,RTMS_EX_H("set_reference_field_at",22,1718595956));
}

/* {ET_TOKEN_CONSTANTS}.set_rout_disp_final_name */

EIF_REFERENCE F396_5058 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2557,RTMS_EX_H("set_rout_disp_final",19,453060972));
}

/* {ET_TOKEN_CONSTANTS}.standard_copy_name */

EIF_REFERENCE F396_5059 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2559,RTMS_EX_H("standard_copy",13,1144002937));
}

/* {ET_TOKEN_CONSTANTS}.standard_is_equal_name */

EIF_REFERENCE F396_5060 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2561,RTMS_EX_H("standard_is_equal",17,192291436));
}

/* {ET_TOKEN_CONSTANTS}.standard_twin_name */

EIF_REFERENCE F396_5061 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2563,RTMS_EX_H("standard_twin",13,1429738094));
}

/* {ET_TOKEN_CONSTANTS}.storable_version_of_type_name */

EIF_REFERENCE F396_5062 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2565,RTMS_EX_H("storable_version_of_type",24,2111549541));
}

/* {ET_TOKEN_CONSTANTS}.tagged_out_name */

EIF_REFERENCE F396_5063 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2567,RTMS_EX_H("tagged_out",10,602975860));
}

/* {ET_TOKEN_CONSTANTS}.to_character_name */

EIF_REFERENCE F396_5064 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2645,RTMS_EX_H("to_character",12,547272050));
}

/* {ET_TOKEN_CONSTANTS}.to_character_8_name */

EIF_REFERENCE F396_5065 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2569,RTMS_EX_H("to_character_8",14,960819768));
}

/* {ET_TOKEN_CONSTANTS}.to_character_32_name */

EIF_REFERENCE F396_5066 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2571,RTMS_EX_H("to_character_32",15,1157161266));
}

/* {ET_TOKEN_CONSTANTS}.to_double_name */

EIF_REFERENCE F396_5067 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2573,RTMS_EX_H("to_double",9,1014968421));
}

/* {ET_TOKEN_CONSTANTS}.to_integer_32_name */

EIF_REFERENCE F396_5068 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2575,RTMS_EX_H("to_integer_32",13,1153717042));
}

/* {ET_TOKEN_CONSTANTS}.to_pointer_name */

EIF_REFERENCE F396_5069 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2578,RTMS_EX_H("to_pointer",10,1933455986));
}

/* {ET_TOKEN_CONSTANTS}.to_real_name */

EIF_REFERENCE F396_5070 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2577,RTMS_EX_H("to_real",7,393488236));
}

/* {ET_TOKEN_CONSTANTS}.to_real_32_name */

EIF_REFERENCE F396_5071 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2580,RTMS_EX_H("to_real_32",10,737943346));
}

/* {ET_TOKEN_CONSTANTS}.to_real_64_name */

EIF_REFERENCE F396_5072 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2582,RTMS_EX_H("to_real_64",10,737944116));
}

/* {ET_TOKEN_CONSTANTS}.truncated_to_integer_name */

EIF_REFERENCE F396_5073 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2584,RTMS_EX_H("truncated_to_integer",20,953240946));
}

/* {ET_TOKEN_CONSTANTS}.truncated_to_integer_64_name */

EIF_REFERENCE F396_5074 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2586,RTMS_EX_H("truncated_to_integer_64",23,451350068));
}

/* {ET_TOKEN_CONSTANTS}.truncated_to_real_name */

EIF_REFERENCE F396_5075 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2588,RTMS_EX_H("truncated_to_real",17,1270788460));
}

/* {ET_TOKEN_CONSTANTS}.twin_name */

EIF_REFERENCE F396_5076 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2590,RTMS_EX_H("twin",4,1953982830));
}

/* {ET_TOKEN_CONSTANTS}.type_conforms_to_name */

EIF_REFERENCE F396_5077 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2592,RTMS_EX_H("type_conforms_to",16,1087836015));
}

/* {ET_TOKEN_CONSTANTS}.type_id_name */

EIF_REFERENCE F396_5078 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2594,RTMS_EX_H("type_id",7,194784612));
}

/* {ET_TOKEN_CONSTANTS}.type_id_from_name_name */

EIF_REFERENCE F396_5079 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2596,RTMS_EX_H("type_id_from_name",17,1145970021));
}

/* {ET_TOKEN_CONSTANTS}.type_of_code_name */

EIF_REFERENCE F396_5080 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2598,RTMS_EX_H("type_of_code",12,306166117));
}

/* {ET_TOKEN_CONSTANTS}.type_of_type_name */

EIF_REFERENCE F396_5081 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2646,RTMS_EX_H("type_of_type",12,592037221));
}

/* {ET_TOKEN_CONSTANTS}.unlock_marking_name */

EIF_REFERENCE F396_5082 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2600,RTMS_EX_H("unlock_marking",14,708645223));
}

/* {ET_TOKEN_CONSTANTS}.unmark_object_name */

EIF_REFERENCE F396_5083 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2602,RTMS_EX_H("unmark_object",13,201329780));
}

/* {ET_TOKEN_CONSTANTS}.upper_name */

EIF_REFERENCE F396_5084 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2603,RTMS_EX_H("upper",5,1887312754));
}

/* {ET_TOKEN_CONSTANTS}.wide_character_bytes_name */

EIF_REFERENCE F396_5085 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2605,RTMS_EX_H("wide_character_bytes",20,1779390579));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_current_keyword_name */

EIF_REFERENCE F396_5086 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2647,RTMS_EX_H("Current",7,1512684148));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_false_keyword_name */

EIF_REFERENCE F396_5087 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2648,RTMS_EX_H("False",5,1635034981));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_precursor_keyword_name */

EIF_REFERENCE F396_5088 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2649,RTMS_EX_H("Precursor",9,1861055346));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_result_keyword_name */

EIF_REFERENCE F396_5089 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2650,RTMS_EX_H("Result",6,2099069556));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_true_keyword_name */

EIF_REFERENCE F396_5090 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2651,RTMS_EX_H("True",4,1416787301));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_void_keyword_name */

EIF_REFERENCE F396_5091 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2652,RTMS_EX_H("Void",4,1450142052));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_unique_keyword_name */

EIF_REFERENCE F396_5092 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2653,RTMS_EX_H("Unique",6,1937004901));
}

/* {ET_TOKEN_CONSTANTS}.across_keyword_name */

EIF_REFERENCE F396_5093 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2654,RTMS_EX_H("across",6,2111376755));
}

/* {ET_TOKEN_CONSTANTS}.agent_keyword_name */

EIF_REFERENCE F396_5094 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2655,RTMS_EX_H("agent",5,1735445620));
}

/* {ET_TOKEN_CONSTANTS}.alias_keyword_name */

EIF_REFERENCE F396_5095 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2656,RTMS_EX_H("alias",5,1819590515));
}

/* {ET_TOKEN_CONSTANTS}.all_keyword_name */

EIF_REFERENCE F396_5096 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2657,RTMS_EX_H("all",3,6384748));
}

/* {ET_TOKEN_CONSTANTS}.and_keyword_name */

EIF_REFERENCE F396_5097 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2658,RTMS_EX_H("and",3,6385252));
}

/* {ET_TOKEN_CONSTANTS}.as_keyword_name */

EIF_REFERENCE F396_5099 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2659,RTMS_EX_H("as",2,24947));
}

/* {ET_TOKEN_CONSTANTS}.assign_keyword_name */

EIF_REFERENCE F396_5100 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2660,RTMS_EX_H("assign",6,2127880558));
}

/* {ET_TOKEN_CONSTANTS}.attached_keyword_name */

EIF_REFERENCE F396_5101 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (658,RTMS_EX_H("attached",8,174222180));
}

/* {ET_TOKEN_CONSTANTS}.attribute_keyword_name */

EIF_REFERENCE F396_5102 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2661,RTMS_EX_H("attribute",9,1585140837));
}

/* {ET_TOKEN_CONSTANTS}.check_keyword_name */

EIF_REFERENCE F396_5103 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2662,RTMS_EX_H("check",5,1752235371));
}

/* {ET_TOKEN_CONSTANTS}.class_keyword_name */

EIF_REFERENCE F396_5104 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2663,RTMS_EX_H("class",5,1819086195));
}

/* {ET_TOKEN_CONSTANTS}.convert_keyword_name */

EIF_REFERENCE F396_5105 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2664,RTMS_EX_H("convert",7,494255732));
}

/* {ET_TOKEN_CONSTANTS}.create_keyword_name */

EIF_REFERENCE F396_5106 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2665,RTMS_EX_H("create",6,1896403045));
}

/* {ET_TOKEN_CONSTANTS}.creation_keyword_name */

EIF_REFERENCE F396_5107 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2666,RTMS_EX_H("creation",8,1571319406));
}

/* {ET_TOKEN_CONSTANTS}.current_keyword_name */

EIF_REFERENCE F396_5108 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2667,RTMS_EX_H("current",7,438973044));
}

/* {ET_TOKEN_CONSTANTS}.debug_keyword_name */

EIF_REFERENCE F396_5109 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2668,RTMS_EX_H("debug",5,1701719399));
}

/* {ET_TOKEN_CONSTANTS}.deferred_keyword_name */

EIF_REFERENCE F396_5110 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2669,RTMS_EX_H("deferred",8,1439904612));
}

/* {ET_TOKEN_CONSTANTS}.detachable_keyword_name */

EIF_REFERENCE F396_5111 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (660,RTMS_EX_H("detachable",10,1071588197));
}

/* {ET_TOKEN_CONSTANTS}.do_keyword_name */

EIF_REFERENCE F396_5112 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2670,RTMS_EX_H("do",2,25711));
}

/* {ET_TOKEN_CONSTANTS}.else_keyword_name */

EIF_REFERENCE F396_5113 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2671,RTMS_EX_H("else",4,1701606245));
}

/* {ET_TOKEN_CONSTANTS}.elseif_keyword_name */

EIF_REFERENCE F396_5114 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2672,RTMS_EX_H("elseif",6,2135429478));
}

/* {ET_TOKEN_CONSTANTS}.end_keyword_name */

EIF_REFERENCE F396_5115 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2673,RTMS_EX_H("end",3,6647396));
}

/* {ET_TOKEN_CONSTANTS}.ensure_keyword_name */

EIF_REFERENCE F396_5116 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2674,RTMS_EX_H("ensure",6,2136495717));
}

/* {ET_TOKEN_CONSTANTS}.expanded_keyword_name */

EIF_REFERENCE F396_5117 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (665,RTMS_EX_H("expanded",8,217352804));
}

/* {ET_TOKEN_CONSTANTS}.export_keyword_name */

EIF_REFERENCE F396_5118 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2675,RTMS_EX_H("export",6,2085847668));
}

/* {ET_TOKEN_CONSTANTS}.external_keyword_name */

EIF_REFERENCE F396_5119 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2676,RTMS_EX_H("external",8,293011052));
}

/* {ET_TOKEN_CONSTANTS}.false_keyword_name */

EIF_REFERENCE F396_5120 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2677,RTMS_EX_H("false",5,1635280741));
}

/* {ET_TOKEN_CONSTANTS}.feature_keyword_name */

EIF_REFERENCE F396_5121 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2678,RTMS_EX_H("feature",7,1951938661));
}

/* {ET_TOKEN_CONSTANTS}.from_keyword_name */

EIF_REFERENCE F396_5122 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2679,RTMS_EX_H("from",4,1718775661));
}

/* {ET_TOKEN_CONSTANTS}.frozen_keyword_name */

EIF_REFERENCE F396_5123 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2680,RTMS_EX_H("frozen",6,2071708014));
}

/* {ET_TOKEN_CONSTANTS}.if_keyword_name */

EIF_REFERENCE F396_5124 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2681,RTMS_EX_H("if",2,26982));
}

/* {ET_TOKEN_CONSTANTS}.implies_keyword_name */

EIF_REFERENCE F396_5125 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2682,RTMS_EX_H("implies",7,1195244659));
}

/* {ET_TOKEN_CONSTANTS}.indexing_keyword_name */

EIF_REFERENCE F396_5126 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2683,RTMS_EX_H("indexing",8,1772088935));
}

/* {ET_TOKEN_CONSTANTS}.inherit_keyword_name */

EIF_REFERENCE F396_5127 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2684,RTMS_EX_H("inherit",7,1080299636));
}

/* {ET_TOKEN_CONSTANTS}.inspect_keyword_name */

EIF_REFERENCE F396_5128 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2685,RTMS_EX_H("inspect",7,1264079988));
}

/* {ET_TOKEN_CONSTANTS}.invariant_keyword_name */

EIF_REFERENCE F396_5129 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1688,RTMS_EX_H("invariant",9,997544820));
}

/* {ET_TOKEN_CONSTANTS}.is_keyword_name */

EIF_REFERENCE F396_5130 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2686,RTMS_EX_H("is",2,26995));
}

/* {ET_TOKEN_CONSTANTS}.like_keyword_name */

EIF_REFERENCE F396_5131 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2687,RTMS_EX_H("like",4,1818848101));
}

/* {ET_TOKEN_CONSTANTS}.local_keyword_name */

EIF_REFERENCE F396_5132 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2688,RTMS_EX_H("local",5,1869613420));
}

/* {ET_TOKEN_CONSTANTS}.loop_keyword_name */

EIF_REFERENCE F396_5133 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2689,RTMS_EX_H("loop",4,1819242352));
}

/* {ET_TOKEN_CONSTANTS}.not_keyword_name */

EIF_REFERENCE F396_5134 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2690,RTMS_EX_H("not",3,7237492));
}

/* {ET_TOKEN_CONSTANTS}.note_keyword_name */

EIF_REFERENCE F396_5135 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2691,RTMS_EX_H("note",4,1852798053));
}

/* {ET_TOKEN_CONSTANTS}.obsolete_keyword_name */

EIF_REFERENCE F396_5136 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2692,RTMS_EX_H("obsolete",8,2004093797));
}

/* {ET_TOKEN_CONSTANTS}.old_keyword_name */

EIF_REFERENCE F396_5137 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2693,RTMS_EX_H("old",3,7302244));
}

/* {ET_TOKEN_CONSTANTS}.once_keyword_name */

EIF_REFERENCE F396_5138 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2694,RTMS_EX_H("once",4,1869505381));
}

/* {ET_TOKEN_CONSTANTS}.or_keyword_name */

EIF_REFERENCE F396_5139 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2695,RTMS_EX_H("or",2,28530));
}

/* {ET_TOKEN_CONSTANTS}.precursor_keyword_name */

EIF_REFERENCE F396_5141 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (798,RTMS_EX_H("precursor",9,1601012338));
}

/* {ET_TOKEN_CONSTANTS}.redefine_keyword_name */

EIF_REFERENCE F396_5142 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2696,RTMS_EX_H("redefine",8,1237283941));
}

/* {ET_TOKEN_CONSTANTS}.reference_keyword_name */

EIF_REFERENCE F396_5143 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (667,RTMS_EX_H("reference",9,2004772965));
}

/* {ET_TOKEN_CONSTANTS}.rename_keyword_name */

EIF_REFERENCE F396_5144 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2697,RTMS_EX_H("rename",6,2076787557));
}

/* {ET_TOKEN_CONSTANTS}.require_keyword_name */

EIF_REFERENCE F396_5145 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2698,RTMS_EX_H("require",7,1565410661));
}

/* {ET_TOKEN_CONSTANTS}.rescue_keyword_name */

EIF_REFERENCE F396_5146 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2699,RTMS_EX_H("rescue",6,13326949));
}

/* {ET_TOKEN_CONSTANTS}.result_keyword_name */

EIF_REFERENCE F396_5147 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2700,RTMS_EX_H("result",6,14504308));
}

/* {ET_TOKEN_CONSTANTS}.retry_keyword_name */

EIF_REFERENCE F396_5148 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2701,RTMS_EX_H("retry",5,1703005817));
}

/* {ET_TOKEN_CONSTANTS}.select_keyword_name */

EIF_REFERENCE F396_5149 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2702,RTMS_EX_H("select",6,2045458804));
}

/* {ET_TOKEN_CONSTANTS}.separate_keyword_name */

EIF_REFERENCE F396_5150 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (663,RTMS_EX_H("separate",8,1461880421));
}

/* {ET_TOKEN_CONSTANTS}.some_keyword_name */

EIF_REFERENCE F396_5151 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2703,RTMS_EX_H("some",4,1936682341));
}

/* {ET_TOKEN_CONSTANTS}.strip_keyword_name */

EIF_REFERENCE F396_5152 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2704,RTMS_EX_H("strip",5,1954538352));
}

/* {ET_TOKEN_CONSTANTS}.then_keyword_name */

EIF_REFERENCE F396_5153 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2705,RTMS_EX_H("then",4,1952998766));
}

/* {ET_TOKEN_CONSTANTS}.true_keyword_name */

EIF_REFERENCE F396_5154 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2706,RTMS_EX_H("true",4,1953658213));
}

/* {ET_TOKEN_CONSTANTS}.undefine_keyword_name */

EIF_REFERENCE F396_5155 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2707,RTMS_EX_H("undefine",8,1472863845));
}

/* {ET_TOKEN_CONSTANTS}.unique_keyword_name */

EIF_REFERENCE F396_5156 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2708,RTMS_EX_H("unique",6,1999919461));
}

/* {ET_TOKEN_CONSTANTS}.until_keyword_name */

EIF_REFERENCE F396_5157 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2709,RTMS_EX_H("until",5,1854021484));
}

/* {ET_TOKEN_CONSTANTS}.variant_keyword_name */

EIF_REFERENCE F396_5158 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2710,RTMS_EX_H("variant",7,1221488244));
}

/* {ET_TOKEN_CONSTANTS}.void_keyword_name */

EIF_REFERENCE F396_5159 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2711,RTMS_EX_H("void",4,1987012964));
}

/* {ET_TOKEN_CONSTANTS}.when_keyword_name */

EIF_REFERENCE F396_5160 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2712,RTMS_EX_H("when",4,2003330414));
}

/* {ET_TOKEN_CONSTANTS}.xor_keyword_name */

EIF_REFERENCE F396_5161 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2713,RTMS_EX_H("xor",3,7892850));
}

/* {ET_TOKEN_CONSTANTS}.implicit_attached_type_mark_name */

EIF_REFERENCE F396_5162 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (659,RTMS_EX_H("[attached]",10,1318195293));
}

/* {ET_TOKEN_CONSTANTS}.implicit_detachable_type_mark_name */

EIF_REFERENCE F396_5163 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (661,RTMS_EX_H("[detachable]",12,1557609309));
}

/* {ET_TOKEN_CONSTANTS}.implicit_expanded_type_mark_name */

EIF_REFERENCE F396_5164 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (666,RTMS_EX_H("[expanded]",10,1622235997));
}

/* {ET_TOKEN_CONSTANTS}.implicit_reference_type_mark_name */

EIF_REFERENCE F396_5165 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (668,RTMS_EX_H("[reference]",11,603197021));
}

/* {ET_TOKEN_CONSTANTS}.implicit_separate_type_mark_name */

EIF_REFERENCE F396_5166 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (664,RTMS_EX_H("[separate]",10,246814557));
}

/* {ET_TOKEN_CONSTANTS}.no_type_mark_name */

EIF_REFERENCE F396_5167 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (662,RTMS_EX_H("",0,0));
}

/* {ET_TOKEN_CONSTANTS}.arrow_symbol_name */

EIF_REFERENCE F396_5168 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2714,RTMS_EX_H("->",2,11582));
}

/* {ET_TOKEN_CONSTANTS}.assign_symbol_name */

EIF_REFERENCE F396_5169 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2715,RTMS_EX_H(":=",2,14909));
}

/* {ET_TOKEN_CONSTANTS}.assign_attempt_symbol_name */

EIF_REFERENCE F396_5170 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2716,RTMS_EX_H("\?=",2,16189));
}

/* {ET_TOKEN_CONSTANTS}.bang_symbol_name */

EIF_REFERENCE F396_5171 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2717,RTMS_EX_H("!",1,33));
}

/* {ET_TOKEN_CONSTANTS}.bar_symbol_name */
static EIF_REFERENCE F396_5172_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2718)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr2 = RTMS32_EX_H("\246\000\000\000",1,166);
	tr1 = RTLNS(eif_new_type(1198, 0x01).id, 1198, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F1199_10760(RTCW(tr1), tr2);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5172 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2718,F396_5172_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.close_repeat_symbol_name */
static EIF_REFERENCE F396_5174_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2719)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr2 = RTMS32_EX_H("\362\'\000\000",1,10226);
	tr1 = RTLNS(eif_new_type(1198, 0x01).id, 1198, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F1199_10760(RTCW(tr1), tr2);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5174 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2719,F396_5174_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.colon_symbol_name */

EIF_REFERENCE F396_5175 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2720,RTMS_EX_H(":",1,58));
}

/* {ET_TOKEN_CONSTANTS}.comma_symbol_name */

EIF_REFERENCE F396_5176 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2721,RTMS_EX_H(",",1,44));
}

/* {ET_TOKEN_CONSTANTS}.div_symbol_name */

EIF_REFERENCE F396_5177 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2722,RTMS_EX_H("//",2,12079));
}

/* {ET_TOKEN_CONSTANTS}.divide_symbol_name */

EIF_REFERENCE F396_5178 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2723,RTMS_EX_H("/",1,47));
}

/* {ET_TOKEN_CONSTANTS}.dollar_symbol_name */

EIF_REFERENCE F396_5179 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2724,RTMS_EX_H("$",1,36));
}

/* {ET_TOKEN_CONSTANTS}.dot_symbol_name */

EIF_REFERENCE F396_5180 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2725,RTMS_EX_H(".",1,46));
}

/* {ET_TOKEN_CONSTANTS}.dotdot_symbol_name */

EIF_REFERENCE F396_5181 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2726,RTMS_EX_H("..",2,11822));
}

/* {ET_TOKEN_CONSTANTS}.equal_symbol_name */

EIF_REFERENCE F396_5182 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2727,RTMS_EX_H("=",1,61));
}

/* {ET_TOKEN_CONSTANTS}.for_all_symbol_name */
static EIF_REFERENCE F396_5183_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2728)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr2 = RTMS32_EX_H("\000\"\000\000",1,8704);
	tr1 = RTLNS(eif_new_type(1198, 0x01).id, 1198, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F1199_10760(RTCW(tr1), tr2);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5183 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2728,F396_5183_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.ge_symbol_name */

EIF_REFERENCE F396_5184 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2729,RTMS_EX_H(">=",2,15933));
}

/* {ET_TOKEN_CONSTANTS}.gt_symbol_name */

EIF_REFERENCE F396_5185 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2730,RTMS_EX_H(">",1,62));
}

/* {ET_TOKEN_CONSTANTS}.le_symbol_name */

EIF_REFERENCE F396_5186 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2731,RTMS_EX_H("<=",2,15421));
}

/* {ET_TOKEN_CONSTANTS}.left_array_symbol_name */

EIF_REFERENCE F396_5187 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2732,RTMS_EX_H("<<",2,15420));
}

/* {ET_TOKEN_CONSTANTS}.left_brace_symbol_name */

EIF_REFERENCE F396_5188 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2733,RTMS_EX_H("{",1,123));
}

/* {ET_TOKEN_CONSTANTS}.left_bracket_symbol_name */

EIF_REFERENCE F396_5189 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2734,RTMS_EX_H("[",1,91));
}

/* {ET_TOKEN_CONSTANTS}.left_parenthesis_symbol_name */

EIF_REFERENCE F396_5190 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2735,RTMS_EX_H("(",1,40));
}

/* {ET_TOKEN_CONSTANTS}.lt_symbol_name */

EIF_REFERENCE F396_5191 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2736,RTMS_EX_H("<",1,60));
}

/* {ET_TOKEN_CONSTANTS}.minus_symbol_name */

EIF_REFERENCE F396_5192 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2737,RTMS_EX_H("-",1,45));
}

/* {ET_TOKEN_CONSTANTS}.mod_symbol_name */

EIF_REFERENCE F396_5193 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2738,RTMS_EX_H("\\\\",2,23644));
}

/* {ET_TOKEN_CONSTANTS}.not_equal_symbol_name */

EIF_REFERENCE F396_5194 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2739,RTMS_EX_H("/=",2,12093));
}

/* {ET_TOKEN_CONSTANTS}.not_tilde_symbol_name */

EIF_REFERENCE F396_5195 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2740,RTMS_EX_H("/~",2,12158));
}

/* {ET_TOKEN_CONSTANTS}.open_repeat_symbol_name */
static EIF_REFERENCE F396_5196_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2741)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr2 = RTMS32_EX_H("\363\'\000\000",1,10227);
	tr1 = RTLNS(eif_new_type(1198, 0x01).id, 1198, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F1199_10760(RTCW(tr1), tr2);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5196 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2741,F396_5196_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.plus_symbol_name */

EIF_REFERENCE F396_5198 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2742,RTMS_EX_H("+",1,43));
}

/* {ET_TOKEN_CONSTANTS}.power_symbol_name */

EIF_REFERENCE F396_5199 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2743,RTMS_EX_H("^",1,94));
}

/* {ET_TOKEN_CONSTANTS}.question_mark_symbol_name */

EIF_REFERENCE F396_5200 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2744,RTMS_EX_H("\?",1,63));
}

/* {ET_TOKEN_CONSTANTS}.right_array_symbol_name */

EIF_REFERENCE F396_5201 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2745,RTMS_EX_H(">>",2,15934));
}

/* {ET_TOKEN_CONSTANTS}.right_brace_symbol_name */

EIF_REFERENCE F396_5202 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2746,RTMS_EX_H("}",1,125));
}

/* {ET_TOKEN_CONSTANTS}.right_bracket_symbol_name */

EIF_REFERENCE F396_5203 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2747,RTMS_EX_H("]",1,93));
}

/* {ET_TOKEN_CONSTANTS}.right_parenthesis_symbol_name */

EIF_REFERENCE F396_5204 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2748,RTMS_EX_H(")",1,41));
}

/* {ET_TOKEN_CONSTANTS}.semicolon_symbol_name */

EIF_REFERENCE F396_5205 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2749,RTMS_EX_H(";",1,59));
}

/* {ET_TOKEN_CONSTANTS}.there_exists_symbol_name */
static EIF_REFERENCE F396_5206_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2750)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr2 = RTMS32_EX_H("\003\"\000\000",1,8707);
	tr1 = RTLNS(eif_new_type(1198, 0x01).id, 1198, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = F1199_10760(RTCW(tr1), tr2);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5206 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2750,F396_5206_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.tilde_symbol_name */

EIF_REFERENCE F396_5207 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2751,RTMS_EX_H("~",1,126));
}

/* {ET_TOKEN_CONSTANTS}.times_symbol_name */

EIF_REFERENCE F396_5208 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2752,RTMS_EX_H("*",1,42));
}

/* {ET_TOKEN_CONSTANTS}.unknown_name */

EIF_REFERENCE F396_5209 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1667,RTMS_EX_H("***unknown_name***",18,481131562));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_boolean_ref_name */

EIF_REFERENCE F396_5210 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2015,RTMS_EX_H("BOOLEAN_REF",11,1796418374));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_character_ref_name */

EIF_REFERENCE F396_5211 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2016,RTMS_EX_H("CHARACTER_REF",13,483102278));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_character_8_ref_name */

EIF_REFERENCE F396_5212 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2017,RTMS_EX_H("CHARACTER_8_REF",15,732893766));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_character_32_ref_name */

EIF_REFERENCE F396_5213 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2018,RTMS_EX_H("CHARACTER_32_REF",16,998840390));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_double_ref_name */

EIF_REFERENCE F396_5214 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2019,RTMS_EX_H("DOUBLE_REF",10,1262894918));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_integer_ref_name */

EIF_REFERENCE F396_5215 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2020,RTMS_EX_H("INTEGER_REF",11,938014022));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_integer_8_ref_name */

EIF_REFERENCE F396_5216 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2022,RTMS_EX_H("INTEGER_8_REF",13,366774086));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_integer_16_ref_name */

EIF_REFERENCE F396_5217 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2024,RTMS_EX_H("INTEGER_16_REF",14,1757412422));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_integer_32_ref_name */

EIF_REFERENCE F396_5218 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2025,RTMS_EX_H("INTEGER_32_REF",14,1761313862));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_integer_64_ref_name */

EIF_REFERENCE F396_5219 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2027,RTMS_EX_H("INTEGER_64_REF",14,1767227462));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_natural_ref_name */

EIF_REFERENCE F396_5220 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2028,RTMS_EX_H("NATURAL_REF",11,1337107014));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_natural_8_ref_name */

EIF_REFERENCE F396_5221 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2030,RTMS_EX_H("NATURAL_8_REF",13,1168516166));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_natural_16_ref_name */

EIF_REFERENCE F396_5222 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2032,RTMS_EX_H("NATURAL_16_REF",14,845323334));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_natural_32_ref_name */

EIF_REFERENCE F396_5223 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2033,RTMS_EX_H("NATURAL_32_REF",14,849224774));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_natural_64_ref_name */

EIF_REFERENCE F396_5224 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2035,RTMS_EX_H("NATURAL_64_REF",14,855138374));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_pointer_ref_name */

EIF_REFERENCE F396_5225 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2037,RTMS_EX_H("POINTER_REF",11,507475782));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_real_ref_name */

EIF_REFERENCE F396_5226 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2038,RTMS_EX_H("REAL_REF",8,2115659078));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_real_32_ref_name */

EIF_REFERENCE F396_5227 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2039,RTMS_EX_H("REAL_32_REF",11,583508806));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_real_64_ref_name */

EIF_REFERENCE F396_5228 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2040,RTMS_EX_H("REAL_64_REF",11,589422406));
}

/* {ET_TOKEN_CONSTANTS}.capitalized_wide_character_ref_name */

EIF_REFERENCE F396_5229 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2041,RTMS_EX_H("WIDE_CHARACTER_REF",18,195639622));
}

/* {ET_TOKEN_CONSTANTS}.alias_and_name */

EIF_REFERENCE F396_5230 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1648,RTMS_EX_H("alias \"and\"",11,701507106));
}

/* {ET_TOKEN_CONSTANTS}.alias_implies_name */

EIF_REFERENCE F396_5231 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1654,RTMS_EX_H("alias \"implies\"",15,838680098));
}

/* {ET_TOKEN_CONSTANTS}.alias_or_name */

EIF_REFERENCE F396_5232 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1659,RTMS_EX_H("alias \"or\"",10,255316514));
}

/* {ET_TOKEN_CONSTANTS}.alias_xor_name */

EIF_REFERENCE F396_5233 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1664,RTMS_EX_H("alias \"xor\"",11,1087452194));
}

/* {ET_TOKEN_CONSTANTS}.alias_div_name */

EIF_REFERENCE F396_5234 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1650,RTMS_EX_H("alias \"//\"",10,251105058));
}

/* {ET_TOKEN_CONSTANTS}.alias_divide_name */

EIF_REFERENCE F396_5235 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1651,RTMS_EX_H("alias \"/\"",9,1343155746));
}

/* {ET_TOKEN_CONSTANTS}.alias_ge_name */

EIF_REFERENCE F396_5236 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1652,RTMS_EX_H("alias \">=\"",10,252091682));
}

/* {ET_TOKEN_CONSTANTS}.alias_gt_name */

EIF_REFERENCE F396_5237 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1653,RTMS_EX_H("alias \">\"",9,1343159586));
}

/* {ET_TOKEN_CONSTANTS}.alias_le_name */

EIF_REFERENCE F396_5238 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1655,RTMS_EX_H("alias \"<=\"",10,251960610));
}

/* {ET_TOKEN_CONSTANTS}.alias_lt_name */

EIF_REFERENCE F396_5239 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1656,RTMS_EX_H("alias \"<\"",9,1343159074));
}

/* {ET_TOKEN_CONSTANTS}.alias_minus_name */

EIF_REFERENCE F396_5240 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1657,RTMS_EX_H("alias \"-\"",9,1343155234));
}

/* {ET_TOKEN_CONSTANTS}.alias_mod_name */

EIF_REFERENCE F396_5241 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1658,RTMS_EX_H("alias \"\\\\\"",10,254065698));
}

/* {ET_TOKEN_CONSTANTS}.alias_plus_name */

EIF_REFERENCE F396_5242 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1661,RTMS_EX_H("alias \"+\"",9,1343154722));
}

/* {ET_TOKEN_CONSTANTS}.alias_power_name */

EIF_REFERENCE F396_5243 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1662,RTMS_EX_H("alias \"^\"",9,1343167778));
}

/* {ET_TOKEN_CONSTANTS}.alias_times_name */

EIF_REFERENCE F396_5244 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1663,RTMS_EX_H("alias \"*\"",9,1343154466));
}

/* {ET_TOKEN_CONSTANTS}.alias_dotdot_name */

EIF_REFERENCE F396_5245 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1665,RTMS_EX_H("alias \"..\"",10,251039266));
}

/* {ET_TOKEN_CONSTANTS}.alias_and_then_name */

EIF_REFERENCE F396_5246 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1649,RTMS_EX_H("alias \"and then\"",16,1932712994));
}

/* {ET_TOKEN_CONSTANTS}.alias_or_else_name */

EIF_REFERENCE F396_5247 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1660,RTMS_EX_H("alias \"or else\"",15,1103070498));
}

/* {ET_TOKEN_CONSTANTS}.alias_not_name */

EIF_REFERENCE F396_5248 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1666,RTMS_EX_H("alias \"not\"",11,919680546));
}

/* {ET_TOKEN_CONSTANTS}.alias_bracket_name */

EIF_REFERENCE F396_5249 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1646,RTMS_EX_H("alias \"[]\"",10,254000418));
}

/* {ET_TOKEN_CONSTANTS}.alias_parenthesis_name */

EIF_REFERENCE F396_5250 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (1647,RTMS_EX_H("alias \"()\"",10,250644770));
}

/* {ET_TOKEN_CONSTANTS}.builtin_marker */

EIF_REFERENCE F396_5251 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2753,RTMS_EX_H("built_in",8,940850542));
}

/* {ET_TOKEN_CONSTANTS}.static_builtin_marker */

EIF_REFERENCE F396_5252 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (805,RTMS_EX_H("static built_in",15,480397678));
}

/* {ET_TOKEN_CONSTANTS}.builtin_static_marker */

EIF_REFERENCE F396_5253 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (804,RTMS_EX_H("built_in static",15,1846395747));
}

/* {ET_TOKEN_CONSTANTS}.unknown_convert_feature */
static EIF_REFERENCE F396_5254_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(613)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1704, 0x01).id, 1704, _OBJSIZ_3_0_0_0_0_0_0_0_);
	tr2 = RTOUCR(606,F396_5269, (Current));
	F1705_17057(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5254 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(613,F396_5254_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.once_indexing_tag */

EIF_REFERENCE F396_5255 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2754,RTMS_EX_H("once_status",11,1414855283));
}

/* {ET_TOKEN_CONSTANTS}.global_once_indexing_value */

EIF_REFERENCE F396_5257 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2755,RTMS_EX_H("global",6,2072054124));
}

/* {ET_TOKEN_CONSTANTS}.thread_once_indexing_value */

EIF_REFERENCE F396_5258 (EIF_REFERENCE Current)
{
	GTCX
	RTOUC (2756,RTMS_EX_H("thread",6,630884));
}

/* {ET_TOKEN_CONSTANTS}.null_position */
static EIF_REFERENCE F396_5261_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2757)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1285, 0x01).id, 1285, _OBJSIZ_0_0_0_1_0_0_0_0_);
	F1286_12617(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5261 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2757,F396_5261_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.empty_ancestors */
static EIF_REFERENCE F396_5262_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(630)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(905, 0x01).id, 905, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F899_7043(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5262 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(630,F396_5262_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.unknown_parent */
static EIF_REFERENCE F396_5263_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(607)

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1678, 0x01).id, 1678, _OBJSIZ_7_0_0_0_0_0_0_0_);
	tr2 = RTOUCR(606,F396_5269, (Current));
	F1679_16904(RTCW(tr1), tr2, NULL, NULL, NULL, NULL, NULL);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5263 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(607,F396_5263_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.unknown_parents */
static EIF_REFERENCE F396_5264_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(608)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1645, 0x01).id, 1645, _OBJSIZ_3_0_0_1_0_0_0_0_);
	F1646_16679(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(607,F396_5263, (Current));
	F1003_7576(RTCW(Result), tr1);
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5264 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(608,F396_5264_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.empty_queries */
static EIF_REFERENCE F396_5265_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(631)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1005, 0x01).id, 1005, _OBJSIZ_1_0_0_2_0_0_0_0_);
	F1003_7567(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5265 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(631,F396_5265_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.empty_procedures */
static EIF_REFERENCE F396_5266_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(632)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1006, 0x01).id, 1006, _OBJSIZ_1_0_0_2_0_0_0_0_);
	F1003_7567(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5266 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(632,F396_5266_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.empty_clients */
static EIF_REFERENCE F396_5267_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(609)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1003, 0x01).id, 1003, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F1003_7566(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5267 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(609,F396_5267_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.unknown_class */
static EIF_REFERENCE F396_5268_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(5)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(2026, 0x01).id, 2026, _OBJSIZ_30_20_0_6_0_0_0_0_);
	F2027_20565(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTOUCR(635,F396_5272, (Current));
	F2027_20645(RTCW(Result), tr1);
	F2027_20666(RTCW(Result));
	F2027_20728(RTCW(Result));
	F2027_20781(RTCW(Result));
	F2027_20790(RTCW(Result));
	F2027_20805(RTCW(Result));
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5268 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(5,F396_5268_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.unknown_class_type */
static EIF_REFERENCE F396_5269_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(606)

	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(2025, 0x01).id, 2025, _OBJSIZ_4_2_0_0_0_0_0_0_);
	tr2 = RTOUCR(72,F396_4604, (Current));
	tr3 = *(EIF_REFERENCE *)(RTCV(RTOUCR(5,F396_5268, (Current))));
	tr4 = RTOUCR(5,F396_5268, (Current));
	F2026_20528(RTCW(tr1), tr2, tr3, tr4);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5269 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(606,F396_5269_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.unknown_generic_class_type */
static EIF_REFERENCE F396_5270_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(612)

	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLIU(6);
	
	RTEV;
	RTGC;
	RTOTP;
	loc1 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
	F1901_18642(RTCW(loc1));
	tr1 = RTLNS(eif_new_type(2025, 0x01).id, 2025, _OBJSIZ_4_2_0_0_0_0_0_0_);
	tr2 = RTOUCR(72,F396_4604, (Current));
	tr3 = *(EIF_REFERENCE *)(RTCV(RTOUCR(5,F396_5268, (Current))));
	tr4 = RTOUCR(5,F396_5268, (Current));
	F2026_20529(RTCW(tr1), tr2, tr3, loc1, tr4);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5270 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(612,F396_5270_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.unknown_tuple_type */
static EIF_REFERENCE F396_5271_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(610)

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(2024, 0x01).id, 2024, _OBJSIZ_4_0_0_0_0_0_0_0_);
	tr2 = RTOUCR(72,F396_4604, (Current));
	tr3 = RTOUCR(5,F396_5268, (Current));
	F2025_20495(RTCW(tr1), tr2, NULL, tr3);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5271 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(610,F396_5271_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.unknown_group */
static EIF_REFERENCE F396_5272_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(635)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1608, 0x01).id, 1608, _OBJSIZ_3_1_0_0_0_0_0_0_);
	F1609_16054(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5272 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(635,F396_5272_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.unknown_system */
static EIF_REFERENCE F396_5273_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(761)

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1616, 0x01).id, 1616, _OBJSIZ_101_13_0_11_0_0_0_0_);
	tr2 = RTMS_EX_H("*unknown*",9,1968388906);
	F1617_16395(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5273 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(761,F396_5273_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.unknown_library */
static EIF_REFERENCE F396_5274_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1785)

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1615, 0x01).id, 1615, _OBJSIZ_90_4_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("*unknown*",9,1968388906);
	tr3 = RTOUCR(761,F396_5273, (Current));
	F1616_16379(RTCW(tr1), tr2, tr3);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5274 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1785,F396_5274_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.unknown_dotnet_assembly */
static EIF_REFERENCE F396_5275_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1786)

	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1611, 0x01).id, 1611, _OBJSIZ_90_5_0_0_0_0_0_0_);
	tr2 = RTMS_EX_H("*unknown*",9,1968388906);
	tr3 = RTOUCR(761,F396_5273, (Current));
	F1612_16288(RTCW(tr1), tr2, NULL, tr3);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5275 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1786,F396_5275_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.standard_error_handler */
static EIF_REFERENCE F396_5276_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(94)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(2045, 0x01).id, 2045, _OBJSIZ_4_8_0_0_0_0_0_0_);
	F2046_21173(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5276 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(94,F396_5276_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.null_error_handler */
static EIF_REFERENCE F396_5277_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(97)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(2046, 0x01).id, 2046, _OBJSIZ_4_8_0_0_0_0_0_0_);
	F2046_21174(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5277 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(97,F396_5277_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.default_ast_factory */
static EIF_REFERENCE F396_5278_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(95)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1013, 0x01).id, 1013, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5278 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(95,F396_5278_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.empty_actual_parameters */
static EIF_REFERENCE F396_5279_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(611)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1900, 0x01).id, 1900, _OBJSIZ_3_0_0_1_0_0_0_0_);
	F1901_18643(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5279 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(611,F396_5279_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.null_ast_processor */
static EIF_REFERENCE F396_5280_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(96)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(258, 0x01).id, 258, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5280 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(96,F396_5280_body,(Current));
}

/* {ET_TOKEN_CONSTANTS}.null_system_processor */
static EIF_REFERENCE F396_5281_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(77)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1289, 0x01).id, 1289, _OBJSIZ_16_21_0_2_0_0_0_0_);
	F1290_12657(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F396_5281 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(77,F396_5281_body,(Current));
}

void EIF_Minit307 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
