/*
 * Code for class XM_MARKUP_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "xm339.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {XM_MARKUP_CONSTANTS}.default_namespace */
static EIF_REFERENCE F458_6119_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(3106)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS_EX_H("",0,0);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F458_6119 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(3106,F458_6119_body,(Current));
}

/* {XM_MARKUP_CONSTANTS}.xmlns */
static EIF_REFERENCE F458_6120_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(3107)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS_EX_H("xmlns",5,1836744307);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F458_6120 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(3107,F458_6120_body,(Current));
}

/* {XM_MARKUP_CONSTANTS}.xml_prefix */
static EIF_REFERENCE F458_6121_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(3108)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS_EX_H("xml",3,7892332);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F458_6121 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(3108,F458_6121_body,(Current));
}

/* {XM_MARKUP_CONSTANTS}.xml_prefix_namespace */
static EIF_REFERENCE F458_6126_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(3109)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS_EX_H("http://www.w3.org/XML/1998/namespace",36,212418405);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F458_6126 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(3109,F458_6126_body,(Current));
}

/* {XM_MARKUP_CONSTANTS}.xmlns_namespace */
static EIF_REFERENCE F458_6127_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(3110)

	
	RTEV;
	RTGC;
	RTOTP;
	Result = RTMS_EX_H("http://www.w3.org/2000/xmlns/",29,1059754287);
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F458_6127 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(3110,F458_6127_body,(Current));
}

void EIF_Minit339 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
