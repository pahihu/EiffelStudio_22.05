
#ifndef _C7_na326_
#define _C7_na326_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F427_5715(EIF_REFERENCE, EIF_POINTER);
extern EIF_NATURAL_64 F427_5716(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit326(void);

#ifdef __cplusplus
}
#endif

#endif
