/*
 * Code for class ET_ALIAS_NAME_TESTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et345.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ALIAS_NAME_TESTER}.test */
EIF_BOOLEAN F471_6153 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == arg2)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		if ((EIF_BOOLEAN)(arg1 == NULL)) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			if ((EIF_BOOLEAN)(arg2 == NULL)) {
				RTLE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			} else {
				Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R14535[Dtype(RTCW(arg1))-1947])(arg1, arg2);
				RTLE;
				return (EIF_BOOLEAN) Result;
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit345 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
