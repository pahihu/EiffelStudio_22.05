
#ifndef _C7_re319_
#define _C7_re319_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F408_5545(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit319(void);

#ifdef __cplusplus
}
#endif

#endif
