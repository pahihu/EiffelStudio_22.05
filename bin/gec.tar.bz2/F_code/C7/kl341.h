
#ifndef _C7_kl341_
#define _C7_kl341_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F460_6138_body(EIF_REFERENCE);
extern EIF_REFERENCE F460_6138(EIF_REFERENCE);
static EIF_REFERENCE F460_6139_body(EIF_REFERENCE);
extern EIF_REFERENCE F460_6139(EIF_REFERENCE);
extern void EIF_Minit341(void);

#ifdef __cplusplus
}
#endif

#endif
