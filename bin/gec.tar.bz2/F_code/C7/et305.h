
#ifndef _C7_et305_
#define _C7_et305_

#ifdef __cplusplus
extern "C" {
#endif

static EIF_REFERENCE F394_3732_body(EIF_REFERENCE);
extern EIF_REFERENCE F394_3732(EIF_REFERENCE);
extern void EIF_Minit305(void);

#ifdef __cplusplus
}
#endif

#endif
