/*
 * Code for class UT_SHARED_ECF_VERSIONS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ut313.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_2_0 */
static EIF_REFERENCE F402_5317_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1841)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1287, 0x01).id, 1287, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1288_12629(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 2L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F402_5317 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1841,F402_5317_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_4_0 */
static EIF_REFERENCE F402_5319_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1784)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1287, 0x01).id, 1287, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1288_12629(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 4L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F402_5319 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1784,F402_5319_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_5_0 */
static EIF_REFERENCE F402_5320_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1838)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1287, 0x01).id, 1287, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1288_12629(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 5L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F402_5320 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1838,F402_5320_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_9_0 */
static EIF_REFERENCE F402_5324_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1836)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1287, 0x01).id, 1287, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1288_12629(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 9L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F402_5324 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1836,F402_5324_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_11_0 */
static EIF_REFERENCE F402_5326_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1834)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1287, 0x01).id, 1287, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1288_12629(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 11L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F402_5326 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1834,F402_5326_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_13_0 */
static EIF_REFERENCE F402_5328_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(3012)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1287, 0x01).id, 1287, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1288_12629(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 13L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F402_5328 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(3012,F402_5328_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_15_0 */
static EIF_REFERENCE F402_5330_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1832)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1287, 0x01).id, 1287, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1288_12629(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 15L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F402_5330 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1832,F402_5330_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_16_0 */
static EIF_REFERENCE F402_5331_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(3013)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1287, 0x01).id, 1287, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1288_12629(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 16L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F402_5331 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(3013,F402_5331_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_18_0 */
static EIF_REFERENCE F402_5333_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1830)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1287, 0x01).id, 1287, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1288_12629(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 18L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F402_5333 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1830,F402_5333_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_20_0 */
static EIF_REFERENCE F402_5335_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(3014)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1287, 0x01).id, 1287, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1288_12629(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 20L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F402_5335 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(3014,F402_5335_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_1_21_0 */
static EIF_REFERENCE F402_5336_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(1828)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1287, 0x01).id, 1287, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1288_12629(RTCW(tr1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 21L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F402_5336 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(1828,F402_5336_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_last_known */
static EIF_REFERENCE F402_5337_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	
#define Result RTOTRR
	RTOUDR(3015)

	
	RTEV;
	RTOTP;
	Result = RTOUCR(3014,F402_5335, (Current));
	RTOTE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F402_5337 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(3015,F402_5337_body,(Current));
}

/* {UT_SHARED_ECF_VERSIONS}.ecf_latest */
static EIF_REFERENCE F402_5338_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(3008)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(1287, 0x01).id, 1287, _OBJSIZ_0_0_0_4_0_0_0_0_);
	F1288_12633(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F402_5338 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(3008,F402_5338_body,(Current));
}

void EIF_Minit313 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
