
#ifndef _C7_mu315_
#define _C7_mu315_

#ifdef __cplusplus
extern "C" {
#endif

extern void F404_5341(EIF_REFERENCE);
extern EIF_BOOLEAN F404_5343(EIF_REFERENCE);
extern void F404_5344(EIF_REFERENCE);
extern EIF_BOOLEAN F404_5345(EIF_REFERENCE);
extern void F404_5346(EIF_REFERENCE);
extern void F404_5347(EIF_REFERENCE);
extern void F404_5350(EIF_REFERENCE);
extern EIF_POINTER F404_5352(EIF_REFERENCE);
extern void F404_5353(EIF_REFERENCE, EIF_POINTER);
extern void F404_5354(EIF_REFERENCE, EIF_POINTER);
extern EIF_BOOLEAN F404_5355(EIF_REFERENCE, EIF_POINTER);
extern void F404_5356(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit315(void);

#ifdef __cplusplus
}
#endif

#endif
