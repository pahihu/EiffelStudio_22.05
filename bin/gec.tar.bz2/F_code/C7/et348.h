
#ifndef _C7_et348_
#define _C7_et348_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F474_6157(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit348(void);
extern EIF_BOOLEAN F1987_19687(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
