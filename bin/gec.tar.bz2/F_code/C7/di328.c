/*
 * Code for class DIRECTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "di328.h"
#include "eif_dir.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DIRECTORY}.make */
void F429_5738 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F429_5739(Current, arg1);
}

/* {DIRECTORY}.make_with_name */
void F429_5739 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F429_5775(Current, arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {DIRECTORY}.readentry */
void F429_5745 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_2_0_1_0_0_);
	tp1 = (EIF_POINTER) eif_dir_next(tp1);
	*(EIF_POINTER *)(Current+ _PTROFF_6_2_0_1_0_1_) = (EIF_POINTER) tp1;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_6_2_0_1_0_1_) == tp1)) {
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) NULL;
	} else {
		tr1 = RTOUCR(2967,F429_5785, (Current));
		tr1 = F430_5816(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_6_2_0_1_0_1_));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {DIRECTORY}.open_read */
void F429_5748 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F429_5777(Current))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (EIF_POINTER) eif_dir_open((EIF_FILENAME) tp1);
	*(EIF_POINTER *)(Current+ _PTROFF_6_2_0_1_0_0_) = (EIF_POINTER) tp1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	RTLE;
}

/* {DIRECTORY}.close */
void F429_5749 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_6_2_0_1_0_0_);
	eif_dir_close(tp1);
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	*(EIF_POINTER *)(Current+ _PTROFF_6_2_0_1_0_0_) = (EIF_POINTER) tp2;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {DIRECTORY}.last_entry_8 */
EIF_REFERENCE F429_5759 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	{
		/* INLINED CODE (ANY.default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_6_2_0_1_0_1_) != tp1)) {
		tr1 = RTOUCR(2967,F429_5785, (Current));
		Result = F430_5816(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_6_2_0_1_0_1_));
	}
	RTLE;
	return Result;
}

/* {DIRECTORY}.is_closed */
EIF_BOOLEAN F429_5761 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_6_2_0_0_) == ((EIF_INTEGER_32) 1L));
}

/* {DIRECTORY}.exists */
EIF_BOOLEAN F429_5763 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F429_5777(Current))+ _PTROFF_0_1_0_1_0_0_);
	Result = (EIF_BOOLEAN) EIF_TEST(eif_dir_exists((EIF_FILENAME) tp1));
	RTLE;
	return Result;
}

/* {DIRECTORY}.is_readable */
EIF_BOOLEAN F429_5764 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCV(F429_5777(Current))+ _PTROFF_0_1_0_1_0_0_);
	Result = (EIF_BOOLEAN) EIF_TEST(eif_dir_is_readable((EIF_FILENAME) tp1));
	RTLE;
	return Result;
}

/* {DIRECTORY}.dispose */
void F429_5772 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F429_5761(Current)) {
		F429_5749(Current);
	}
	RTLE;
}

/* {DIRECTORY}.set_name */
void F429_5775 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tr1 = RTOUCR(2967,F429_5785, (Current));
	tr1 = F430_5814(RTCW(tr1), arg1, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DIRECTORY}.internal_name_pointer */
EIF_REFERENCE F429_5777 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		RTCT0("internal_name_pointer_set", EX_CHECK);
			RTCF0;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {DIRECTORY}.file_info */
static EIF_REFERENCE F429_5785_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
#define Result RTOTRR
	RTOUDR(2967)

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOTP;
	tr1 = RTLNS(eif_new_type(429, 0x01).id, 429, _OBJSIZ_3_2_0_0_0_0_0_0_);
	F430_5797(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOTE;
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F429_5785 (EIF_REFERENCE Current)
{
	GTCX
	return RTOUCR(2967,F429_5785_body,(Current));
}

/* {DIRECTORY}.dir_open */
EIF_POINTER F429_5787 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) eif_dir_open((EIF_FILENAME) arg1);
	
	return Result;
}

/* {DIRECTORY}.dir_close */
void F429_5789 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	eif_dir_close(arg1);
	
}

/* {DIRECTORY}.eif_dir_next */
EIF_POINTER F429_5790 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) eif_dir_next(arg1);
	
	return Result;
}

/* {DIRECTORY}.eif_dir_exists */
EIF_BOOLEAN F429_5792 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(eif_dir_exists((EIF_FILENAME) arg1));
	
	return Result;
}

/* {DIRECTORY}.eif_dir_is_readable */
EIF_BOOLEAN F429_5793 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(eif_dir_is_readable((EIF_FILENAME) arg1));
	
	return Result;
}

void EIF_Minit328 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
