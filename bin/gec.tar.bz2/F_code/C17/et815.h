
#ifndef _C17_et815_
#define _C17_et815_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1767_17362(EIF_REFERENCE);
extern EIF_REFERENCE F1767_17363(EIF_REFERENCE);
extern EIF_REFERENCE F1767_17364(EIF_REFERENCE);
extern EIF_REFERENCE F1767_17366(EIF_REFERENCE);
extern EIF_BOOLEAN F1767_17367(EIF_REFERENCE);
extern void F1767_17368(EIF_REFERENCE, EIF_REFERENCE);
extern void F1767_17369(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit815(void);
extern char *(*R13062[])();
extern char *(*R13066[])();
extern char *(*R2264[])();

#ifdef __cplusplus
}
#endif

#endif
