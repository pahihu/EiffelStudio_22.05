
#ifndef _C17_et846_
#define _C17_et846_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1798_17504(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1798_17505(EIF_REFERENCE);
extern EIF_REFERENCE F1798_17506(EIF_REFERENCE);
extern EIF_REFERENCE F1798_17507(EIF_REFERENCE);
extern void F1798_17509(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit846(void);
extern void F1785_17454(EIF_REFERENCE);
extern void F1785_17453(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R13062[])();
extern char *(*R13233[])();
extern long O13575[];

#ifdef __cplusplus
}
#endif

#endif
