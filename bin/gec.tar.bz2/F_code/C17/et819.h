
#ifndef _C17_et819_
#define _C17_et819_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1771_17384(EIF_REFERENCE);
extern EIF_BOOLEAN F1771_17386(EIF_REFERENCE);
extern void F1771_17387(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit819(void);
extern EIF_REFERENCE F1914_18794(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
