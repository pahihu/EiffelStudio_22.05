
#ifndef _C17_et836_
#define _C17_et836_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1788_17477(EIF_REFERENCE);
extern void EIF_Minit836(void);

#ifdef __cplusplus
}
#endif

#endif
