
#ifndef _C17_et817_
#define _C17_et817_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1769_17374(EIF_REFERENCE);
extern EIF_REFERENCE F1769_17376(EIF_REFERENCE);
extern EIF_REFERENCE F1769_17378(EIF_REFERENCE);
extern EIF_BOOLEAN F1769_17379(EIF_REFERENCE);
extern void EIF_Minit817(void);
extern char *(*R13062[])();
extern char *(*R13066[])();
extern char *(*R2264[])();

#ifdef __cplusplus
}
#endif

#endif
