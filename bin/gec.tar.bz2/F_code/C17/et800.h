
#ifndef _C17_et800_
#define _C17_et800_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1752_17349(EIF_REFERENCE);
extern void EIF_Minit800(void);
extern EIF_REFERENCE F1633_16558(EIF_REFERENCE);
extern long O13476[];

#ifdef __cplusplus
}
#endif

#endif
