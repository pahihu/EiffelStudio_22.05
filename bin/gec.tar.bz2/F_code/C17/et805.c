/*
 * Code for class ET_EXTERNAL_PROCEDURE_INLINE_AGENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et805.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_EXTERNAL_PROCEDURE_INLINE_AGENT}.make */
void F1757_17354 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,arg1);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg2;
	F1754_17351(Current, arg1, arg3);
	RTLE;
}

/* {ET_EXTERNAL_PROCEDURE_INLINE_AGENT}.process */
void F1757_17355 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2363[Dtype(RTCW(arg1))-258])(arg1, Current);
}

void EIF_Minit805 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
