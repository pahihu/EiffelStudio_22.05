
#ifndef _C17_et843_
#define _C17_et843_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1795_17493(EIF_REFERENCE);
extern void F1795_17494(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit843(void);
extern void F1794_17487(EIF_REFERENCE);
extern char *(*R2482[])();

#ifdef __cplusplus
}
#endif

#endif
