
#ifndef _C17_et802_
#define _C17_et802_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1754_17351(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit802(void);
extern EIF_REFERENCE F1008_7640(EIF_REFERENCE);
extern EIF_REFERENCE F396_4675(EIF_REFERENCE);
extern void F1750_17332(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
