
#ifndef _C17_et814_
#define _C17_et814_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1766_17361(EIF_REFERENCE);
extern void EIF_Minit814(void);

#ifdef __cplusplus
}
#endif

#endif
