
#ifndef _C17_et801_
#define _C17_et801_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1753_17350(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit801(void);
extern EIF_REFERENCE F1008_7640(EIF_REFERENCE);
extern void F1923_18969(EIF_REFERENCE);
extern EIF_REFERENCE F396_4675(EIF_REFERENCE);
extern EIF_INTEGER_32 F1286_12619(EIF_REFERENCE);
extern void F1286_12620(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1750_17332(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1286_12618(EIF_REFERENCE);
extern char *(*R13062[])();
extern long O13496[];
extern long O13497[];

#ifdef __cplusplus
}
#endif

#endif
