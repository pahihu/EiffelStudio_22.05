
#ifndef _C17_et812_
#define _C17_et812_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1764_17359(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit812(void);
extern char *(*R2429[])();

#ifdef __cplusplus
}
#endif

#endif
