
#ifndef _C17_et823_
#define _C17_et823_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1775_17405(EIF_REFERENCE);
extern EIF_REFERENCE F1775_17407(EIF_REFERENCE);
extern void F1775_17409(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit823(void);
extern EIF_REFERENCE F1008_7640(EIF_REFERENCE);
extern EIF_REFERENCE F396_4633(EIF_REFERENCE);
extern EIF_REFERENCE F396_4704(EIF_REFERENCE);
extern char *(*R2459[])();

#ifdef __cplusplus
}
#endif

#endif
