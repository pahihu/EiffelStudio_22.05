/*
 * Code for class ET_UNQUALIFIED_REGULAR_FEATURE_CALL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et842.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_UNQUALIFIED_REGULAR_FEATURE_CALL}.make */
void F1794_17486 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O13568[Dtype(Current)-1793]) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {ET_UNQUALIFIED_REGULAR_FEATURE_CALL}.reset */
void F1794_17487 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O13568[Dtype(Current)-1793]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R13648[Dtype(RTCW(tr1))-1825])(tr1);
	F1782_17432(Current);
	RTLE;
}

/* {ET_UNQUALIFIED_REGULAR_FEATURE_CALL}.name */
EIF_REFERENCE F1794_17488 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O13568[Dtype(Current)-1793]);
}


/* {ET_UNQUALIFIED_REGULAR_FEATURE_CALL}.position */
EIF_REFERENCE F1794_17489 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O13568[Dtype(Current)-1793]);
	Result = F1914_18794(RTCW(tr1));
	RTLE;
	return Result;
}

/* {ET_UNQUALIFIED_REGULAR_FEATURE_CALL}.last_leaf */
EIF_REFERENCE F1794_17491 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = F1816_17621(loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O13568[Dtype(Current)-1793]);
		Result = F1914_18797(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {ET_UNQUALIFIED_REGULAR_FEATURE_CALL}.set_name */
void F1794_17492 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O13568[Dtype(Current)-1793]) = (EIF_REFERENCE) arg1;
}

void EIF_Minit842 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
