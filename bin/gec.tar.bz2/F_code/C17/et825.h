
#ifndef _C17_et825_
#define _C17_et825_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1777_17412(EIF_REFERENCE);
extern EIF_BOOLEAN F1777_17413(EIF_REFERENCE);
extern EIF_BOOLEAN F1777_17414(EIF_REFERENCE);
extern EIF_BOOLEAN F1777_17418(EIF_REFERENCE);
extern void EIF_Minit825(void);

#ifdef __cplusplus
}
#endif

#endif
