
#ifndef _C17_et805_
#define _C17_et805_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1757_17354(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1757_17355(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit805(void);
extern void F1754_17351(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2363[])();

#ifdef __cplusplus
}
#endif

#endif
