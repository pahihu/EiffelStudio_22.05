
#ifndef _C17_et827_
#define _C17_et827_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1779_17423(EIF_REFERENCE);
extern void EIF_Minit827(void);
extern char *(*R13532[])();
extern char *(*R2266[])();

#ifdef __cplusplus
}
#endif

#endif
