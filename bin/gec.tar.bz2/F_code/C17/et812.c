/*
 * Code for class ET_ONCE_PROCEDURE_INLINE_AGENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et812.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_ONCE_PROCEDURE_INLINE_AGENT}.process */
void F1764_17359 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2429[Dtype(RTCW(arg1))-258])(arg1, Current);
}

void EIF_Minit812 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
