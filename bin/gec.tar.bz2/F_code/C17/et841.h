
#ifndef _C17_et841_
#define _C17_et841_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1793_17484(EIF_REFERENCE);
extern void F1793_17485(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit841(void);
extern void F1797_17497(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern long O13564[];

#ifdef __cplusplus
}
#endif

#endif
