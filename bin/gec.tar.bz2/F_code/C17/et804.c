/*
 * Code for class ET_EXTERNAL_FUNCTION_INLINE_AGENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et804.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_EXTERNAL_FUNCTION_INLINE_AGENT}.make */
void F1756_17352 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_REFERENCE arg4)
{
	GTCX
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg3);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg4);
	RTLIU(5);
	
	RTGC;
	RTAR(Current, arg3);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg3;
	F1753_17350(Current, arg1, arg2, arg4);
	RTLE;
}

/* {ET_EXTERNAL_FUNCTION_INLINE_AGENT}.process */
void F1756_17353 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R2361[Dtype(RTCW(arg1))-258])(arg1, Current);
}

void EIF_Minit804 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
