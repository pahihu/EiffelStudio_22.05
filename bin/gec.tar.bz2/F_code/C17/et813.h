
#ifndef _C17_et813_
#define _C17_et813_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1765_17360(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit813(void);
extern char *(*R2426[])();

#ifdef __cplusplus
}
#endif

#endif
