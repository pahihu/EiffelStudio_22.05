
#ifndef _C17_et826_
#define _C17_et826_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1778_17420(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit826(void);
extern char *(*R2418[])();

#ifdef __cplusplus
}
#endif

#endif
