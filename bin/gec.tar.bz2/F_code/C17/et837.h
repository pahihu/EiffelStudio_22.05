
#ifndef _C17_et837_
#define _C17_et837_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1789_17478(EIF_REFERENCE);
extern void EIF_Minit837(void);

#ifdef __cplusplus
}
#endif

#endif
