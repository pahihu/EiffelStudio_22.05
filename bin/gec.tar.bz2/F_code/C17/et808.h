
#ifndef _C17_et808_
#define _C17_et808_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1760_17357(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit808(void);
extern char *(*R2344[])();

#ifdef __cplusplus
}
#endif

#endif
