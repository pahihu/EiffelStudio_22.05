
#ifndef _C17_et832_
#define _C17_et832_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1784_17450(EIF_REFERENCE);
extern void F1784_17451(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1784_17452(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit832(void);
extern void F1797_17497(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2440[])();
extern EIF_TYPE_INDEX Y13544[];
extern EIF_TYPE_INDEX *Y13544_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
