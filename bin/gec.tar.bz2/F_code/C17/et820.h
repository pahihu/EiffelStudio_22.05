
#ifndef _C17_et820_
#define _C17_et820_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1772_17388(EIF_REFERENCE, EIF_REFERENCE);
extern void F1772_17389(EIF_REFERENCE);
extern EIF_REFERENCE F1772_17391(EIF_REFERENCE);
extern void F1772_17392(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit820(void);
extern EIF_REFERENCE F1008_7640(EIF_REFERENCE);
extern EIF_REFERENCE F1914_18797(EIF_REFERENCE);
extern EIF_REFERENCE F396_4633(EIF_REFERENCE);
extern char *(*R2365[])();
extern char *(*R13648[])();

#ifdef __cplusplus
}
#endif

#endif
