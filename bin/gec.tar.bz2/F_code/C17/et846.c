/*
 * Code for class ET_QUALIFIED_REGULAR_FEATURE_CALL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "et846.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ET_QUALIFIED_REGULAR_FEATURE_CALL}.make */
void F1798_17504 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O13575[Dtype(Current)-1797]) = (EIF_REFERENCE) arg1;
	F1785_17453(Current, arg2, arg3);
	RTLE;
}

/* {ET_QUALIFIED_REGULAR_FEATURE_CALL}.reset */
void F1798_17505 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1785_17454(Current);
	tr1 = *(EIF_REFERENCE *)(Current + O13575[Dtype(Current)-1797]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R13233[Dtype(RTCW(tr1))-1666])(tr1);
	RTLE;
}

/* {ET_QUALIFIED_REGULAR_FEATURE_CALL}.target */
EIF_REFERENCE F1798_17506 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O13575[Dtype(Current)-1797]);
}


/* {ET_QUALIFIED_REGULAR_FEATURE_CALL}.position */
EIF_REFERENCE F1798_17507 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O13575[Dtype(Current)-1797]);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13062[Dtype(RTCW(tr1))-1627])(tr1);
	RTLE;
	return Result;
}

/* {ET_QUALIFIED_REGULAR_FEATURE_CALL}.set_target */
void F1798_17509 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O13575[Dtype(Current)-1797]) = (EIF_REFERENCE) arg1;
}

void EIF_Minit846 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
