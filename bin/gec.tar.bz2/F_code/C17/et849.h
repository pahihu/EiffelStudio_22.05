
#ifndef _C17_et849_
#define _C17_et849_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1801_17512(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1801_17513(EIF_REFERENCE);
extern EIF_REFERENCE F1801_17514(EIF_REFERENCE);
extern void F1801_17516(EIF_REFERENCE, EIF_BOOLEAN);
extern void F1801_17517(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit849(void);
extern void F1944_19221(EIF_REFERENCE);
extern char *(*R13233[])();
extern char *(*R2393[])();

#ifdef __cplusplus
}
#endif

#endif
