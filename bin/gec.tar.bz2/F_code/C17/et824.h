
#ifndef _C17_et824_
#define _C17_et824_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1776_17410(EIF_REFERENCE);
extern EIF_REFERENCE F1776_17411(EIF_REFERENCE);
extern void EIF_Minit824(void);

#ifdef __cplusplus
}
#endif

#endif
