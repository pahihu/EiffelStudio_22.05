
#ifndef _C17_et835_
#define _C17_et835_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1787_17473(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1787_17474(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit835(void);
extern void F1797_17497(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2463[])();
extern EIF_TYPE_INDEX Y13559[];
extern EIF_TYPE_INDEX *Y13559_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
