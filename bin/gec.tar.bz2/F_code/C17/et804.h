
#ifndef _C17_et804_
#define _C17_et804_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1756_17352(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1756_17353(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit804(void);
extern void F1753_17350(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R2361[])();

#ifdef __cplusplus
}
#endif

#endif
