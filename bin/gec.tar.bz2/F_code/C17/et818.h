
#ifndef _C17_et818_
#define _C17_et818_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1770_17380(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1770_17382(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit818(void);
extern char *(*R2323[])();

#ifdef __cplusplus
}
#endif

#endif
