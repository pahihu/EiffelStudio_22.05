
#ifndef _C17_et810_
#define _C17_et810_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1762_17358(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit810(void);
extern char *(*R2342[])();

#ifdef __cplusplus
}
#endif

#endif
