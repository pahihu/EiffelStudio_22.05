
#ifndef _C17_et834_
#define _C17_et834_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1786_17462(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1786_17463(EIF_REFERENCE);
extern EIF_REFERENCE F1786_17466(EIF_REFERENCE);
extern EIF_REFERENCE F1786_17468(EIF_REFERENCE);
extern void F1786_17470(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit834(void);
extern void F1785_17454(EIF_REFERENCE);
extern EIF_BOOLEAN F1285_12606(EIF_REFERENCE);
extern EIF_REFERENCE F1914_18794(EIF_REFERENCE);
extern void F1785_17453(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R13062[])();
extern char *(*R13357[])();
extern char *(*R13662[])();

#ifdef __cplusplus
}
#endif

#endif
