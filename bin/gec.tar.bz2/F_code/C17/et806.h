
#ifndef _C17_et806_
#define _C17_et806_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1758_17356(EIF_REFERENCE);
extern void EIF_Minit806(void);
extern void F1750_17333(EIF_REFERENCE);
extern void F1634_16565(EIF_REFERENCE);
extern void F1648_16707(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
