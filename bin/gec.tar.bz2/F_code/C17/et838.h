
#ifndef _C17_et838_
#define _C17_et838_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1790_17479(EIF_REFERENCE);
extern void EIF_Minit838(void);

#ifdef __cplusplus
}
#endif

#endif
