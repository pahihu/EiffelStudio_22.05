
#ifndef _C17_et848_
#define _C17_et848_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1800_17511(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit848(void);
extern char *(*R2434[])();

#ifdef __cplusplus
}
#endif

#endif
