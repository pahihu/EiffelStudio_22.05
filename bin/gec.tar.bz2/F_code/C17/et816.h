
#ifndef _C17_et816_
#define _C17_et816_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1768_17370(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1768_17371(EIF_REFERENCE);
extern void F1768_17373(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit816(void);
extern char *(*R2354[])();
extern char *(*R13233[])();

#ifdef __cplusplus
}
#endif

#endif
