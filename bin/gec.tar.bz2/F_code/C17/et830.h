
#ifndef _C17_et830_
#define _C17_et830_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1782_17432(EIF_REFERENCE);
extern EIF_REFERENCE F1782_17433(EIF_REFERENCE);
extern void F1782_17434(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit830(void);
extern void F1819_17643(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
