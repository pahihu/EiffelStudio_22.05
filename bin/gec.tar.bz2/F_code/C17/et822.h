
#ifndef _C17_et822_
#define _C17_et822_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1774_17399(EIF_REFERENCE);
extern EIF_REFERENCE F1774_17401(EIF_REFERENCE);
extern EIF_BOOLEAN F1774_17402(EIF_REFERENCE);
extern void F1774_17404(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit822(void);
extern EIF_REFERENCE F1008_7640(EIF_REFERENCE);
extern EIF_REFERENCE F396_4633(EIF_REFERENCE);
extern EIF_REFERENCE F396_4668(EIF_REFERENCE);
extern char *(*R2336[])();

#ifdef __cplusplus
}
#endif

#endif
