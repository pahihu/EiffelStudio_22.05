
#ifndef _C34_co1664_
#define _C34_co1664_

#ifdef __cplusplus
extern "C" {
#endif

extern void F604_6372(EIF_REFERENCE);
extern void EIF_Minit1664(void);
extern long O5636[];

#ifdef __cplusplus
}
#endif

#endif
