/*
 * Code for class CONTAINER [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co1664.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F604_6372 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O5636[Dtype(Current)-596]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

void EIF_Minit1664 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
