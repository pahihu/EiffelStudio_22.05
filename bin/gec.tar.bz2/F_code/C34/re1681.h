
#ifndef _C34_re1681_
#define _C34_re1681_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F773_6483(EIF_REFERENCE);
extern void F773_6485(EIF_REFERENCE);
extern void EIF_Minit1681(void);
extern char *(*R5701[])();
extern char *(*R5707[])();

#ifdef __cplusplus
}
#endif

#endif
