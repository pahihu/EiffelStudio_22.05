
#ifndef _C34_ds1699_
#define _C34_ds1699_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F243_2387(EIF_REFERENCE);
extern void F243_2389(EIF_REFERENCE, EIF_CHARACTER_8);
extern void F243_2390(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit1699(void);
extern long O2243[];

#ifdef __cplusplus
}
#endif

#endif
