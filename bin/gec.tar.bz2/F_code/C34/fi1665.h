
#ifndef _C34_fi1665_
#define _C34_fi1665_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F747_6470(EIF_REFERENCE);
extern void EIF_Minit1665(void);
extern char *(*R5698[])();

#ifdef __cplusplus
}
#endif

#endif
