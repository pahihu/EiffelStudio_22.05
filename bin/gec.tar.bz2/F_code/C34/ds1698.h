
#ifndef _C34_ds1698_
#define _C34_ds1698_

#ifdef __cplusplus
extern "C" {
#endif

extern void F249_2396(EIF_REFERENCE, EIF_REFERENCE);
extern void F249_2397(EIF_REFERENCE);
extern void EIF_Minit1698(void);

#ifdef __cplusplus
}
#endif

#endif
