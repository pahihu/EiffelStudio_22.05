/*
 * Code for class DS_LINEAR [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1685.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_LINEAR}.new_iterator */
EIF_REFERENCE F1469_13428 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F1515_13613(Current);
	F1336_13085(RTCW(Result));
	RTLE;
	return Result;
}

/* {DS_LINEAR}.after */
EIF_BOOLEAN F1469_13430 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F1469_13445(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_));
}

/* {DS_LINEAR}.start */
void F1469_13433 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1515_13679(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_));
}

/* {DS_LINEAR}.forth */
void F1469_13434 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1515_13681(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_));
}

/* {DS_LINEAR}.go_after */
void F1469_13436 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1515_13685(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_));
}

/* {DS_LINEAR}.cursor_after */
EIF_BOOLEAN F1469_13445 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	
	
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_1_);
	return (EIF_BOOLEAN) tb1;
}

void EIF_Minit1685 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
