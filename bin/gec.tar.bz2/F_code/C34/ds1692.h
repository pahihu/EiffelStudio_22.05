
#ifndef _C34_ds1692_
#define _C34_ds1692_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1462_13421(EIF_REFERENCE, EIF_REFERENCE);
extern void F1462_13425(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1692(void);

#ifdef __cplusplus
}
#endif

#endif
