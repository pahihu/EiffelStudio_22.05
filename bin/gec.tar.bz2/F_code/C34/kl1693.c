/*
 * Code for class KL_EQUALITY_TESTER [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl1693.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_EQUALITY_TESTER}.test */
EIF_BOOLEAN F467_6152 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == arg2)) {
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		return (EIF_BOOLEAN) (arg1 == arg2);
	}/* NOTREACHED */
	
}

void EIF_Minit1693 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
