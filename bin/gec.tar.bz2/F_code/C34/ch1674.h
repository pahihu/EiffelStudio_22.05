
#ifndef _C34_ch1674_
#define _C34_ch1674_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F856_6953(EIF_REFERENCE);
extern void EIF_Minit1674(void);

#ifdef __cplusplus
}
#endif

#endif
