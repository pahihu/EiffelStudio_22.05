
#ifndef _C34_ds1694_
#define _C34_ds1694_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1336_13082(EIF_REFERENCE);
extern void F1336_13085(EIF_REFERENCE);
extern void F1336_13086(EIF_REFERENCE);
extern void F1336_13088(EIF_REFERENCE);
extern void EIF_Minit1694(void);
extern void F1515_13685(EIF_REFERENCE, EIF_REFERENCE);
extern void F1515_13679(EIF_REFERENCE, EIF_REFERENCE);
extern void F1515_13681(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1515_13676(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
