
#ifndef _C34_kl1690_
#define _C34_kl1690_

#ifdef __cplusplus
extern "C" {
#endif

extern void F846_6945(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1690(void);

#ifdef __cplusplus
}
#endif

#endif
