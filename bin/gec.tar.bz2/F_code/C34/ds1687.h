
#ifndef _C34_ds1687_
#define _C34_ds1687_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1435_13373(EIF_REFERENCE);
extern void EIF_Minit1687(void);
extern char *(*R10704[])();

#ifdef __cplusplus
}
#endif

#endif
