
#ifndef _C34_re1653_
#define _C34_re1653_

#ifdef __cplusplus
extern "C" {
#endif

extern void F533_6258(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F533_6260(EIF_REFERENCE);
extern EIF_INTEGER_32 F533_6261(EIF_REFERENCE);
extern EIF_INTEGER_32 F533_6262(EIF_REFERENCE);
extern EIF_INTEGER_32 F533_6263(EIF_REFERENCE);
extern EIF_BOOLEAN F533_6271(EIF_REFERENCE);
extern EIF_BOOLEAN F533_6272(EIF_REFERENCE);
extern void F533_6277(EIF_REFERENCE);
extern void EIF_Minit1653(void);
extern char *(*R5910[])();
extern char *(*R5909[])();

#ifdef __cplusplus
}
#endif

#endif
