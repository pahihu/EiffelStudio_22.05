
#ifndef _C34_kl1693_
#define _C34_kl1693_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F467_6152(EIF_REFERENCE, EIF_CHARACTER_8, EIF_CHARACTER_8);
extern void EIF_Minit1693(void);

#ifdef __cplusplus
}
#endif

#endif
