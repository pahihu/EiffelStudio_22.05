
#ifndef _C34_to1680_
#define _C34_to1680_

#ifdef __cplusplus
extern "C" {
#endif

extern void F421_5706(EIF_REFERENCE, EIF_INTEGER_32);
extern void F421_5707(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern void F421_5713(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1680(void);
extern void F923_7175(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y5090[];
extern EIF_TYPE_INDEX *Y5090_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
