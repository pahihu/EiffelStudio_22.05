/*
 * Code for class DS_CELL [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1699.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_CELL}.item */
EIF_CHARACTER_8 F243_2387 (EIF_REFERENCE Current)
{
	return *(EIF_CHARACTER_8 *)(Current + O2243[Dtype(Current)-241]);
}


/* {DS_CELL}.put */
void F243_2389 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current + O2243[Dtype(Current)-241]) = (EIF_CHARACTER_8) arg1;
}

/* {DS_CELL}.make */
void F243_2390 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current + O2243[Dtype(Current)-241]) = (EIF_CHARACTER_8) arg1;
}

void EIF_Minit1699 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
