
#ifndef _C20_dy989_
#define _C20_dy989_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F535_4479(EIF_REFERENCE);
extern void F535_4485(EIF_REFERENCE, EIF_POINTER);
extern void F535_4486(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit989(void);
extern EIF_BOOLEAN F293_4189(EIF_REFERENCE);
extern void F591_4803(EIF_REFERENCE);
extern void F591_4780(EIF_REFERENCE);
extern void F591_4786(EIF_REFERENCE, EIF_POINTER);

#ifdef __cplusplus
}
#endif

#endif
