
#ifndef _C20_se990_
#define _C20_se990_

#ifdef __cplusplus
extern "C" {
#endif

extern void F451_4272(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit990(void);
extern void F591_4790(EIF_REFERENCE, EIF_POINTER);

#ifdef __cplusplus
}
#endif

#endif
