
#ifndef _C20_ty981_
#define _C20_ty981_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F736_5289(EIF_REFERENCE);
extern void EIF_Minit981(void);
extern char *(*R4678[])();
extern char *(*R4665[])();
extern char *(*R4087[])();

#ifdef __cplusplus
}
#endif

#endif
