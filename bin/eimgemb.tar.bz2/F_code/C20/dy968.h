
#ifndef _C20_dy968_
#define _C20_dy968_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F362_4225(EIF_REFERENCE);
extern void EIF_Minit968(void);

#ifdef __cplusplus
}
#endif

#endif
