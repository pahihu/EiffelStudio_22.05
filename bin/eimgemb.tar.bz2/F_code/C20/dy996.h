
#ifndef _C20_dy996_
#define _C20_dy996_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F363_4225(EIF_REFERENCE);
extern void EIF_Minit996(void);

#ifdef __cplusplus
}
#endif

#endif
