/*
 * Code for class SEQUENCE [POINTER]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "se990.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SEQUENCE}.force */
void F451_4272 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	F591_4790(Current, arg1);
}

void EIF_Minit990 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
