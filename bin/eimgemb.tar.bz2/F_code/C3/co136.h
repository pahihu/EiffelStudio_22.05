
#ifndef _C3_co136_
#define _C3_co136_

#ifdef __cplusplus
extern "C" {
#endif

extern void F158_3094(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit136(void);
extern void F156_3076(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
