
#ifndef _C3_ev130_
#define _C3_ev130_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F152_3016(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,3019)
static EIF_REFERENCE F152_3019_body(EIF_REFERENCE);
extern EIF_REFERENCE F152_3019(EIF_REFERENCE);
extern void EIF_Minit130(void);
extern void F982_8029(EIF_REFERENCE);
extern EIF_REFERENCE F990_8141(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
