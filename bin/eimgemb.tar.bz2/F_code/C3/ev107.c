/*
 * Code for class EV_SIMPLE_HELP_ENGINE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev107.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SIMPLE_HELP_ENGINE}.help_title */

EIF_REFERENCE F120_2716 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (2716,RTMS_EX_H("Contextual Help",15,712875120));
}

/* {EV_SIMPLE_HELP_ENGINE}.show */
void F120_2717 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1046, 0x00).id, 1046, _OBJSIZ_14_3_0_3_0_0_0_0_);
	F1046_8948(RTCW(loc1), arg1);
	{
		static EIF_TYPE_INDEX typarr0[] = {632,949,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNSP2(typres0.id,EO_REF,((EIF_INTEGER_32) 1L),sizeof(EIF_REFERENCE), EIF_FALSE);
		RT_SPECIAL_COUNT(tr2) = 1L;
		memset(tr2, 0, RT_SPECIAL_VISIBLE_SIZE(tr2));
	}
	tr3 = F119_2701(Current);
	*((EIF_REFERENCE *)tr2+0) = (EIF_REFERENCE) tr3;
	RTAR(tr2,tr3);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) F633_5089)(tr2);
	F1046_8963(RTCW(loc1), tr1);
	tr1 = F119_2701(Current);
	tr1 = F1046_8966(RTCW(loc1), tr1);
	F1044_8933(RTCW(loc1), tr1);
	tr1 = RTOSCF(2716,F120_2716, (Current));
	F1039_8840(RTCW(loc1), tr1);
	F1039_8834(RTCW(loc1));
	F1039_8846(RTCW(loc1));
	RTLE;
}

void EIF_Minit107 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
