/*
 * Code for class CONVERSION_FAILURE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co136.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONVERSION_FAILURE}.make_message */
void F158_3094 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F156_3076(Current, arg1);
}

void EIF_Minit136 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
