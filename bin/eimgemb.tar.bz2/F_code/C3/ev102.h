
#ifndef _C3_ev102_
#define _C3_ev102_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F115_2640(EIF_REFERENCE);
extern void F115_2642(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit102(void);
extern void F602_4849(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
