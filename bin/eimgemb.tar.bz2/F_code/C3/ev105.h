
#ifndef _C3_ev105_
#define _C3_ev105_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F118_2668(EIF_REFERENCE);
extern EIF_REFERENCE F118_2671(EIF_REFERENCE);
static EIF_REFERENCE F118_2672_body(EIF_REFERENCE);
extern EIF_REFERENCE F118_2672(EIF_REFERENCE);
extern EIF_REFERENCE F118_2673(EIF_REFERENCE);
extern EIF_REFERENCE F118_2685(EIF_REFERENCE);
extern void EIF_Minit105(void);
extern void F1164_10685(EIF_REFERENCE, EIF_REFERENCE);
extern void F602_4849(EIF_REFERENCE);
extern long O2654[];
extern long O2657[];
extern long O2659[];
extern long O2671[];

#ifdef __cplusplus
}
#endif

#endif
