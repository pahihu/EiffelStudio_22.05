/*
 * Code for class SYNTAX_STRINGS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sy111.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SYNTAX_STRINGS}.keywords */
static EIF_REFERENCE F124_2751_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2751);
#define Result RTOSR(2751)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {581,901,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 581, _OBJSIZ_5_6_0_7_0_0_0_0_);
	}
	F582_4730(RTCW(tr1), ((EIF_INTEGER_32) 55L));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("across",6,2111376755);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("agent",5,1735445620);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("alias",5,1819590515);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("all",3,6384748);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("and",3,6385252);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("as",2,24947);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("assign",6,2127880558);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("attached",8,174222180);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("attribute",9,1585140837);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("check",5,1752235371);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("class",5,1819086195);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("convert",7,494255732);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("create",6,1896403045);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("current",7,438973044);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("debug",5,1701719399);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("deferred",8,1439904612);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("detachable",10,1071588197);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("do",2,25711);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("else",4,1701606245);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("elseif",6,2135429478);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("end",3,6647396);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("ensure",6,2136495717);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("expanded",8,217352804);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("export",6,2085847668);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("external",8,293011052);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("false",5,1635280741);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("feature",7,1951938661);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("from",4,1718775661);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("frozen",6,2071708014);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("if",2,26982);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("implies",7,1195244659);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("indexing",8,1772088935);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("inherit",7,1080299636);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("inspect",7,1264079988);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("invariant",9,997544820);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("like",4,1818848101);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("local",5,1869613420);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("loop",4,1819242352);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("not",3,7237492);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("note",4,1852798053);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("precursor",9,1601012338);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("redefine",8,1237283941);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("rename",6,2076787557);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("require",7,1565410661);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("rescue",6,13326949);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("result",6,14504308);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("retry",5,1703005817);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("select",6,2045458804);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("separate",8,1461880421);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("some",4,1936682341);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("then",4,1952998766);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("true",4,1953658213);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("undefine",8,1472863845);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("until",5,1854021484);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("variant",7,1221488244);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("void",4,1987012964);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("when",4,2003330414);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	tr1 = RTMS_EX_H("xor",3,7892850);
	F579_4664(RTCW(Result), (EIF_BOOLEAN) 1, tr1);
	RTOSE (2751);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F124_2751 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2751,F124_2751_body,(Current));
}

void EIF_Minit111 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
