
#ifndef _C3_ei149_
#define _C3_ei149_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F171_3130(EIF_REFERENCE);
extern void F171_3132(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit149(void);

#ifdef __cplusplus
}
#endif

#endif
