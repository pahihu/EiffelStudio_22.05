
#ifndef _C3_ex132_
#define _C3_ex132_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,3034)
static EIF_REFERENCE F154_3034_body(EIF_REFERENCE);
extern EIF_REFERENCE F154_3034(EIF_REFERENCE);
extern void EIF_Minit132(void);

#ifdef __cplusplus
}
#endif

#endif
