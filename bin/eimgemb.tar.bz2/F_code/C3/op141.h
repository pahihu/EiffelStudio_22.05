
#ifndef _C3_op141_
#define _C3_op141_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F163_3097(EIF_REFERENCE);
extern void F163_3100(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit141(void);

#ifdef __cplusplus
}
#endif

#endif
