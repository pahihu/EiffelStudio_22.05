
#ifndef _C3_sy111_
#define _C3_sy111_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,2751)
static EIF_REFERENCE F124_2751_body(EIF_REFERENCE);
extern EIF_REFERENCE F124_2751(EIF_REFERENCE);
extern void EIF_Minit111(void);
extern void F579_4664(EIF_REFERENCE, EIF_BOOLEAN, EIF_REFERENCE);
extern void F582_4730(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
