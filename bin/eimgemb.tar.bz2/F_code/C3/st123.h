
#ifndef _C3_st123_
#define _C3_st123_

#ifdef __cplusplus
extern "C" {
#endif

extern void F136_2907(EIF_REFERENCE, EIF_BOOLEAN);
extern void F136_2908(EIF_REFERENCE, EIF_BOOLEAN);
extern void F136_2909(EIF_REFERENCE, EIF_REFERENCE);
extern void F136_2910(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit123(void);
extern void F948_7584(EIF_REFERENCE, EIF_REFERENCE);
extern long O2871[];
extern long O2872[];

#ifdef __cplusplus
}
#endif

#endif
