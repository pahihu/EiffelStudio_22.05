
#ifndef _C3_ev106_
#define _C3_ev106_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F119_2701(EIF_REFERENCE);
extern EIF_REFERENCE F119_2711(EIF_REFERENCE);
extern EIF_REFERENCE F119_2713(EIF_REFERENCE);
extern void EIF_Minit106(void);

#ifdef __cplusplus
}
#endif

#endif
