/*
 * Code for class EV_SHARED_APPLICATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev130.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SHARED_APPLICATION}.ev_application */
EIF_REFERENCE F152_3016 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("attached shared_environment.application as l_app", EX_CHECK);
	tr1 = F990_8141(RTCV(RTOSCF(3019,F152_3019, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc1;
	RTLE;
	return Result;
}

/* {EV_SHARED_APPLICATION}.shared_environment */
static EIF_REFERENCE F152_3019_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (3019);
#define Result RTOSR(3019)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F982_8029(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (3019);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F152_3019 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(3019,F152_3019_body,(Current));
}

void EIF_Minit130 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
