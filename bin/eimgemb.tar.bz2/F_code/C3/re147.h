
#ifndef _C3_re147_
#define _C3_re147_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F169_3128(EIF_REFERENCE);
extern void EIF_Minit147(void);

#ifdef __cplusplus
}
#endif

#endif
