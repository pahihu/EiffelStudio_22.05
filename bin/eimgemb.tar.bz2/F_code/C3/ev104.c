/*
 * Code for class EV_SHARED_TRANSPORT_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev104.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SHARED_TRANSPORT_I}.default_accept_cursor */
static EIF_REFERENCE F117_2648_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2648);
#define Result RTOSR(2648)
	RTOC_NEW(Result);
	Result = RTOSCF(698,F32_698, (RTCV(RTOSCF(2652,F117_2652, (Current)))));
	RTOSE (2648);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F117_2648 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2648,F117_2648_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.default_deny_cursor */
static EIF_REFERENCE F117_2649_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2649);
#define Result RTOSR(2649)
	RTOC_NEW(Result);
	Result = RTOSCF(702,F32_702, (RTCV(RTOSCF(2652,F117_2652, (Current)))));
	RTOSE (2649);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F117_2649 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2649,F117_2649_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.default_pixmaps */
static EIF_REFERENCE F117_2652_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2652);
#define Result RTOSR(2652)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(31, 0x00).id, 31, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2652);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F117_2652 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2652,F117_2652_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.insert_label */
static EIF_REFERENCE F117_2658_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (2658);
#define Result RTOSR(2658)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F982_8029(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	F1027_8681(RTCW(Result), ((EIF_INTEGER_32) 10L), ((EIF_INTEGER_32) 10L));
	loc1 = RTLNS(eif_new_type(1058, 0x00).id, 1058, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F982_8029(RTCW(loc1));
	F1059_9135(RTCW(loc1), ((EIF_INTEGER_32) 2L), ((EIF_INTEGER_32) 2L));
	tr1 = RTLNS(eif_new_type(21, 0x00).id, 21, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = F22_458(RTCW(tr1));
	F999_8317(RTCW(loc1), tr1);
	F1014_8455(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	F1014_8455(RTCW(loc1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	tr1 = RTLNS(eif_new_type(21, 0x00).id, 21, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(435,F22_435, (RTCW(tr1)));
	F999_8317(RTCW(loc1), tr1);
	F1014_8455(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L));
	F1014_8455(RTCW(loc1), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 0L));
	F1009_8409(RTCW(Result), loc1);
	RTOSE (2658);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F117_2658 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2658,F117_2658_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.insert_label_imp */
static EIF_REFERENCE F117_2659_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2659);
#define Result RTOSR(2659)
	RTOC_NEW(Result);
	Result = *(EIF_REFERENCE *)(RTCV(RTOSCF(2658,F117_2658, (Current))) + _REFACS_3_);
	RTOSE (2659);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F117_2659 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2659,F117_2659_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.remove_insert_label */
void F117_2660 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = F1027_8655(RTCV(RTOSCF(2658,F117_2658, (Current))));
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		loc1 = F1027_8655(RTCV(RTOSCF(2658,F117_2658, (Current))));
		loc1 = RTRV(eif_new_type(1034, 0x00), loc1);
		tr1 = RTOSCF(2658,F117_2658, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R7068[Dtype(loc5)-1032])(loc5, tr1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tr1 = RTOSCF(2658,F117_2658, (Current));
			tb2 = (EIF_BOOLEAN) eif_builtin_ANY_same_type__o_b (loc1, tr1);
			tb1 = tb2;
		}
		if (tb1) {
			loc2 = F1027_8655(RTCW(loc1));
			loc2 = RTRV(eif_new_type(1031, 0x00), loc2);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				loc3 = F1025_8606(RTCW(loc2), loc1, ((EIF_INTEGER_32) 1L));
				loc4 = F1032_8759(RTCW(loc2), loc1);
				F1025_8629(RTCW(loc2), loc1);
				F1025_8615(RTCW(loc2), loc3);
				F1025_8624(RTCW(loc2), loc1);
				if ((EIF_BOOLEAN) !loc4) {
					F1032_8766(RTCW(loc2), loc1);
				}
			}
		}
	}
	RTLE;
}

/* {EV_SHARED_TRANSPORT_I}.insert_sep */
static EIF_REFERENCE F117_2661_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2661);
#define Result RTOSR(2661)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1065, 0x00).id, 1065, _OBJSIZ_6_0_0_1_0_0_0_0_);
	F982_8029(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2661);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F117_2661 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2661,F117_2661_body,(Current));
}

/* {EV_SHARED_TRANSPORT_I}.remove_insert_sep */
void F117_2663 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1065_9183(RTCV(RTOSCF(2661,F117_2661, (Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = RTOSCF(2661,F117_2661, (Current));
		F1025_8629(loc1, tr1);
	}
	RTLE;
}

/* {EV_SHARED_TRANSPORT_I}.internal_screen */
static EIF_REFERENCE F117_2665_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (2665);
#define Result RTOSR(2665)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F982_8029(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (2665);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F117_2665 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(2665,F117_2665_body,(Current));
}

void EIF_Minit104 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
