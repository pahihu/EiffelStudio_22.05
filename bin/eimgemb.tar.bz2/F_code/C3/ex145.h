
#ifndef _C3_ex145_
#define _C3_ex145_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F167_3124(EIF_REFERENCE);
extern void EIF_Minit145(void);

#ifdef __cplusplus
}
#endif

#endif
