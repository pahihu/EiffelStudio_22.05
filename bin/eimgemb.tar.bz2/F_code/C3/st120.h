
#ifndef _C3_st120_
#define _C3_st120_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F133_2864(EIF_REFERENCE);
extern EIF_INTEGER_32 F133_2865(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit120(void);
extern EIF_INTEGER_32 F637_5083(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_CHARACTER_32 F635_5083(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R6388[])();
extern char *(*R6192[])();
extern char *(*R6155[])();

#ifdef __cplusplus
}
#endif

#endif
