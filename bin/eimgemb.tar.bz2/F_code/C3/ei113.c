/*
 * Code for class EIFFEL_SYNTAX_CHECKER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ei113.h"
#include <ctype.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EIFFEL_SYNTAX_CHECKER}.is_valid_class_name */
EIF_BOOLEAN F126_2786 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = '\0';
	if (F126_2791(Current, arg1)) {
		tr1 = RTOSCF(2751,F124_2751, (Current));
		tb1 = F579_4626(RTCW(tr1), arg1);
		Result = (EIF_BOOLEAN) !tb1;
	}
	RTLE;
	return Result;
}

/* {EIFFEL_SYNTAX_CHECKER}.is_valid_identifier */
EIF_BOOLEAN F126_2791 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R6170[Dtype(RTCW(arg1))-948])(arg1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tw1 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6156[Dtype(RTCW(arg1))-948])(arg1, ((EIF_INTEGER_32) 1L));
		Result = F126_2805(Current, tw1);
	}
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) !Result) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6192[Dtype(RTCW(arg1))-948])(arg1);
			tb1 = (EIF_BOOLEAN) (loc1 > ti4_1);
		}
		if (tb1) break;
		loc2 = (FUNCTION_CAST(EIF_CHARACTER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R6156[Dtype(RTCW(arg1))-948])(arg1, loc1);
		Result = '\01';
		tb2 = '\01';
		if (!F126_2805(Current, loc2)) {
			tb2 = F126_2806(Current, loc2);
		}
		if (!tb2) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
			Result = (EIF_BOOLEAN)(loc2 == tw1);
		}
		loc1++;
	}
	RTLE;
	return Result;
}

/* {EIFFEL_SYNTAX_CHECKER}.is_alpha */
EIF_BOOLEAN F126_2805 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	tb1 = (arg1 <= 0xFF);
	if (tb1) {
		tc1 = (EIF_CHARACTER_8) arg1;
		tr1 = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)tr1 = tc1;
		tb1 = F897_7223(RTCW(tr1));
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {EIFFEL_SYNTAX_CHECKER}.is_digit */
EIF_BOOLEAN F126_2806 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTGC;
	Result = '\0';
	tb1 = (arg1 <= 0xFF);
	if (tb1) {
		tc1 = (EIF_CHARACTER_8) arg1;
		tb1 = EIF_TEST(isdigit(tc1));
		Result = tb1;
	}
	return Result;
}

void EIF_Minit113 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
