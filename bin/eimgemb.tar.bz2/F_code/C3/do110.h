
#ifndef _C3_do110_
#define _C3_do110_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_64 F123_2738(EIF_REFERENCE, EIF_REAL_64);
extern EIF_REAL_64 F123_2740(EIF_REFERENCE, EIF_REAL_64);
extern EIF_REAL_64 F123_2743(EIF_REFERENCE, EIF_REAL_64);
extern EIF_REAL_64 F123_2746(EIF_REFERENCE, EIF_REAL_64);
extern EIF_REAL_64 F123_2748(EIF_REFERENCE, EIF_REAL_64);
extern void EIF_Minit110(void);

#ifdef __cplusplus
}
#endif

#endif
