
#ifndef _C3_re146_
#define _C3_re146_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F168_3126(EIF_REFERENCE);
extern void EIF_Minit146(void);

#ifdef __cplusplus
}
#endif

#endif
