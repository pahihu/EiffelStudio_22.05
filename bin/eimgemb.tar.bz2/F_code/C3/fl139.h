
#ifndef _C3_fl139_
#define _C3_fl139_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F161_3095(EIF_REFERENCE);
extern void EIF_Minit139(void);

#ifdef __cplusplus
}
#endif

#endif
