
#ifndef _C3_nu121_
#define _C3_nu121_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F134_2868(EIF_REFERENCE);
extern void EIF_Minit121(void);

#ifdef __cplusplus
}
#endif

#endif
