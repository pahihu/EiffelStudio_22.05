
#ifndef _C3_ex133_
#define _C3_ex133_

#ifdef __cplusplus
extern "C" {
#endif

extern void F155_3053(EIF_REFERENCE, EIF_REFERENCE);
extern void F155_3054(EIF_REFERENCE, EIF_REFERENCE);
extern void F155_3055(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit133(void);
extern EIF_REFERENCE F154_3034(EIF_REFERENCE);
extern void F156_3076(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F107_2508(EIF_REFERENCE, EIF_INTEGER_32);
extern void F156_3061(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,3034)

#ifdef __cplusplus
}
#endif

#endif
