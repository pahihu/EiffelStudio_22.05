
#ifndef _C3_de135_
#define _C3_de135_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F157_3092(EIF_REFERENCE);
extern void EIF_Minit135(void);

#ifdef __cplusplus
}
#endif

#endif
