
#ifndef _C3_op142_
#define _C3_op142_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F164_3101(EIF_REFERENCE);
extern void F164_3104(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit142(void);

#ifdef __cplusplus
}
#endif

#endif
