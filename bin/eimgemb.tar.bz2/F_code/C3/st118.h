
#ifndef _C3_st118_
#define _C3_st118_

#ifdef __cplusplus
extern "C" {
#endif

extern void F131_2847(EIF_REFERENCE);
extern EIF_INTEGER_32 F131_2851(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F131_2857(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE);
extern void EIF_Minit118(void);
extern void F637_5098(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F637_5102(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern char *(*R6192[])();
extern char *(*R6155[])();
extern char *(*R2833[])();
extern char *(*R2835[])();

#ifdef __cplusplus
}
#endif

#endif
