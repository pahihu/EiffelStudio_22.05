
#ifndef _C3_st119_
#define _C3_st119_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F132_2860(EIF_REFERENCE);
extern EIF_INTEGER_32 F132_2861(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit119(void);
extern EIF_INTEGER_32 F637_5083(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_CHARACTER_8 F636_5083(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R6192[])();
extern char *(*R6155[])();
extern char *(*R6313[])();

#ifdef __cplusplus
}
#endif

#endif
