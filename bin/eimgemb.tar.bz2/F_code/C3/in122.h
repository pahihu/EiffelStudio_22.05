
#ifndef _C3_in122_
#define _C3_in122_

#ifdef __cplusplus
extern "C" {
#endif

extern void F135_2890(EIF_REFERENCE);
extern EIF_BOOLEAN F135_2891(EIF_REFERENCE, EIF_NATURAL_64, EIF_NATURAL_64, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit122(void);
extern EIF_NATURAL_64 F640_5083(EIF_REFERENCE, EIF_INTEGER_32);
extern void F640_5100(EIF_REFERENCE, EIF_NATURAL_64);

#ifdef __cplusplus
}
#endif

#endif
