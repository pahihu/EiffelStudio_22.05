
#ifndef _C21_dy1036_
#define _C21_dy1036_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F536_4479(EIF_REFERENCE);
extern void F536_4485(EIF_REFERENCE, EIF_NATURAL_64);
extern void F536_4486(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit1036(void);
extern void F592_4786(EIF_REFERENCE, EIF_NATURAL_64);
extern EIF_BOOLEAN F294_4189(EIF_REFERENCE);
extern void F592_4803(EIF_REFERENCE);
extern void F592_4780(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
