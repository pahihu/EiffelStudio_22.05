/*
 * Code for class EV_DYNAMIC_LIST_IMP [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev1045.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DYNAMIC_LIST_IMP}.make */
void F1119_10227 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y8209,Y8209_gen_type,Dftype(Current),1118).id);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4329[Dtype(RTCW(tr1))-584])(tr1, ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O8209[Dtype(Current)-1118]) = (EIF_REFERENCE) tr1;
	F1087_9359(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_DYNAMIC_LIST_IMP}.i_th */
EIF_REFERENCE F1119_10228 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8209[Dtype(Current)-1118]);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4045[Dtype(RTCW(tr1))-503])(tr1, (EIF_REFERENCE) &arg1);
	RTLE;
	return Result;
}

/* {EV_DYNAMIC_LIST_IMP}.count */
EIF_INTEGER_32 F1119_10229 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8209[Dtype(Current)-1118]);
	Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4064[Dtype(RTCW(tr1))-503])(tr1);
	RTLE;
	return Result;
}

void EIF_Minit1045 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
