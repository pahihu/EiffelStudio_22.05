
#ifndef _C21_co1025_
#define _C21_co1025_

#ifdef __cplusplus
extern "C" {
#endif

extern void F267_4030(EIF_REFERENCE);
extern void F267_4031(EIF_REFERENCE);
extern void EIF_Minit1025(void);
extern long O3909[];

#ifdef __cplusplus
}
#endif

#endif
