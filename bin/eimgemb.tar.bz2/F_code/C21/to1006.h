
#ifndef _C21_to1006_
#define _C21_to1006_

#ifdef __cplusplus
extern "C" {
#endif

extern void F225_3810(EIF_REFERENCE, EIF_INTEGER_32);
extern void F225_3811(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern void F225_3817(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1006(void);
extern void F639_5081(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y3696[];
extern EIF_TYPE_INDEX *Y3696_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
