
#ifndef _C21_dy1041_
#define _C21_dy1041_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F364_4225(EIF_REFERENCE);
extern void EIF_Minit1041(void);

#ifdef __cplusplus
}
#endif

#endif
