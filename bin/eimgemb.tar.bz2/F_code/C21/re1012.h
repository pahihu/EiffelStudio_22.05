
#ifndef _C21_re1012_
#define _C21_re1012_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F485_4321(EIF_REFERENCE);
extern void EIF_Minit1012(void);
extern void F749_5295(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4677[])();
extern EIF_TYPE_INDEX Y3861[];
extern EIF_TYPE_INDEX *Y3861_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
