
#ifndef _C21_re1016_
#define _C21_re1016_

#ifdef __cplusplus
extern "C" {
#endif

extern void F749_5295(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F749_5297(EIF_REFERENCE);
extern EIF_INTEGER_32 F749_5298(EIF_REFERENCE);
extern EIF_INTEGER_32 F749_5299(EIF_REFERENCE);
extern EIF_INTEGER_32 F749_5300(EIF_REFERENCE);
extern EIF_BOOLEAN F749_5307(EIF_REFERENCE);
extern EIF_BOOLEAN F749_5308(EIF_REFERENCE);
extern EIF_BOOLEAN F749_5309(EIF_REFERENCE);
extern void F749_5314(EIF_REFERENCE);
extern void F749_5315(EIF_REFERENCE);
extern EIF_REFERENCE F749_5316(EIF_REFERENCE);
extern void EIF_Minit1016(void);
extern char *(*R4091[])();
extern char *(*R4088[])();
extern char *(*R4089[])();

#ifdef __cplusplus
}
#endif

#endif
