
#ifndef _C21_ev1045_
#define _C21_ev1045_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1119_10227(EIF_REFERENCE);
extern EIF_REFERENCE F1119_10228(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1119_10229(EIF_REFERENCE);
extern void EIF_Minit1045(void);
extern void F1087_9359(EIF_REFERENCE, EIF_BOOLEAN);
extern char *(*R4329[])();
extern char *(*R4064[])();
extern char *(*R4045[])();
extern long O8209[];
extern EIF_TYPE_INDEX Y8209[];
extern EIF_TYPE_INDEX *Y8209_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
