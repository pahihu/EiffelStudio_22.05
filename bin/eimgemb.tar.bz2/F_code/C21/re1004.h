
#ifndef _C21_re1004_
#define _C21_re1004_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F439_4265(EIF_REFERENCE);
extern void EIF_Minit1004(void);
extern char *(*R4065[])();

#ifdef __cplusplus
}
#endif

#endif
