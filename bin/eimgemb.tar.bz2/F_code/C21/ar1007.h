
#ifndef _C21_ar1007_
#define _C21_ar1007_

#ifdef __cplusplus
extern "C" {
#endif

extern void F782_5349(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F782_5350(EIF_REFERENCE);
extern EIF_REFERENCE F782_5353(EIF_REFERENCE);
extern EIF_INTEGER_32 F782_5354(EIF_REFERENCE);
extern void EIF_Minit1007(void);
extern EIF_INTEGER_32 F591_4772(EIF_REFERENCE);
extern EIF_REFERENCE F591_4753(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
