
#ifndef _C21_ge1011_
#define _C21_ge1011_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F771_5329(EIF_REFERENCE);
extern EIF_INTEGER_32 F771_5331(EIF_REFERENCE);
extern EIF_BOOLEAN F771_5338(EIF_REFERENCE);
extern void F771_5343(EIF_REFERENCE);
extern void F771_5344(EIF_REFERENCE);
extern void EIF_Minit1011(void);
extern EIF_NATURAL_64 F640_5083(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F783_5354(EIF_REFERENCE);
extern EIF_INTEGER_32 F783_5350(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
