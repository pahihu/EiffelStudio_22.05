
#ifndef _C21_ge1000_
#define _C21_ge1000_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F770_5329(EIF_REFERENCE);
extern EIF_INTEGER_32 F770_5331(EIF_REFERENCE);
extern EIF_BOOLEAN F770_5338(EIF_REFERENCE);
extern void F770_5343(EIF_REFERENCE);
extern void F770_5344(EIF_REFERENCE);
extern void EIF_Minit1000(void);
extern EIF_INTEGER_32 F782_5354(EIF_REFERENCE);
extern EIF_POINTER F639_5083(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F782_5350(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
