
#ifndef _C21_ar1043_
#define _C21_ar1043_

#ifdef __cplusplus
extern "C" {
#endif

extern void F783_5349(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F783_5350(EIF_REFERENCE);
extern EIF_REFERENCE F783_5353(EIF_REFERENCE);
extern EIF_INTEGER_32 F783_5354(EIF_REFERENCE);
extern void EIF_Minit1043(void);
extern EIF_INTEGER_32 F592_4772(EIF_REFERENCE);
extern EIF_REFERENCE F592_4753(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
