
#ifndef _C21_ty1017_
#define _C21_ty1017_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_64 F737_5289(EIF_REFERENCE);
extern void EIF_Minit1017(void);
extern char *(*R4678[])();
extern char *(*R4665[])();
extern char *(*R4087[])();

#ifdef __cplusplus
}
#endif

#endif
