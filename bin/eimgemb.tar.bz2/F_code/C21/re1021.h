
#ifndef _C21_re1021_
#define _C21_re1021_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F440_4265(EIF_REFERENCE);
extern void EIF_Minit1021(void);
extern char *(*R4065[])();

#ifdef __cplusplus
}
#endif

#endif
