
#ifndef _C21_to1044_
#define _C21_to1044_

#ifdef __cplusplus
extern "C" {
#endif

extern void F226_3810(EIF_REFERENCE, EIF_INTEGER_32);
extern void F226_3811(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern void F226_3817(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1044(void);
extern void F640_5081(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y3696[];
extern EIF_TYPE_INDEX *Y3696_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
