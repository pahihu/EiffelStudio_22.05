
#ifndef _C21_bi1038_
#define _C21_bi1038_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F306_4199(EIF_REFERENCE);
extern void F306_4202(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit1038(void);
extern void F294_4185(EIF_REFERENCE, EIF_NATURAL_64);
extern EIF_BOOLEAN F548_4495(EIF_REFERENCE);
extern EIF_BOOLEAN F548_4494(EIF_REFERENCE);
extern void F592_4782(EIF_REFERENCE);
extern EIF_BOOLEAN F416_4259(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
