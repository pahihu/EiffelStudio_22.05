
#ifndef _C21_se1037_
#define _C21_se1037_

#ifdef __cplusplus
extern "C" {
#endif

extern void F452_4272(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit1037(void);
extern void F592_4790(EIF_REFERENCE, EIF_NATURAL_64);

#ifdef __cplusplus
}
#endif

#endif
