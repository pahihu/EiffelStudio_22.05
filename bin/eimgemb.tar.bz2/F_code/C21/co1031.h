
#ifndef _C21_co1031_
#define _C21_co1031_

#ifdef __cplusplus
extern "C" {
#endif

extern void F318_4210(EIF_REFERENCE, EIF_NATURAL_64);
extern void EIF_Minit1031(void);
extern char *(*R3906[])();
extern char *(*R4040[])();

#ifdef __cplusplus
}
#endif

#endif
