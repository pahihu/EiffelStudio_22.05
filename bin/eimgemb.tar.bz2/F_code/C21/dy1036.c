/*
 * Code for class DYNAMIC_CHAIN [NATURAL_64]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "dy1036.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DYNAMIC_CHAIN}.extendible */
EIF_BOOLEAN F536_4479 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {DYNAMIC_CHAIN}.prune */
void F536_4485 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F592_4786(Current, arg1);
	if ((EIF_BOOLEAN) !F294_4189(Current)) {
		F592_4803(Current);
	}
	RTLE;
}

/* {DYNAMIC_CHAIN}.prune_all */
void F536_4486 (EIF_REFERENCE Current, EIF_NATURAL_64 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F592_4780(Current);
	F592_4786(Current, arg1);
	for (;;) {
		if (F294_4189(Current)) break;
		F592_4803(Current);
		F592_4786(Current, arg1);
	}
	RTLE;
}

void EIF_Minit1036 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
