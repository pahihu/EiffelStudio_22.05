
#ifndef _C21_fi1026_
#define _C21_fi1026_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F416_4259(EIF_REFERENCE);
extern void EIF_Minit1026(void);
extern char *(*R4064[])();

#ifdef __cplusplus
}
#endif

#endif
