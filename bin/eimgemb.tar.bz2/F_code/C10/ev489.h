
#ifndef _C10_ev489_
#define _C10_ev489_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1137_10410(EIF_REFERENCE);
extern void F1137_10411(EIF_REFERENCE);
extern void F1137_10412(EIF_REFERENCE);
extern EIF_BOOLEAN F1137_10414(EIF_REFERENCE);
extern EIF_BOOLEAN F1137_10416(EIF_REFERENCE);
extern void EIF_Minit489(void);
extern EIF_BOOLEAN F1087_9344(EIF_REFERENCE);
extern EIF_BOOLEAN F1026_8647(EIF_REFERENCE);
extern char *(*R8349[])();
extern long O8051[];

#ifdef __cplusplus
}
#endif

#endif
