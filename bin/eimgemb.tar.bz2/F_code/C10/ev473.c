/*
 * Code for class EV_DOCKABLE_SOURCE_HINT_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev473.h"
#include <math.h>
#include <ev_gtk.h>
#include "eif_built_in.h"
#include <cairo.h>
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F80_1411
static EIF_POINTER inline_F80_1411 (void)
{
	return gdk_screen_get_default()
	;
}
#define INLINE_F80_1411
#endif
#ifndef INLINE_F80_1409
static EIF_POINTER inline_F80_1409 (EIF_POINTER arg1)
{
	return gdk_screen_get_rgba_visual ((GdkScreen*)arg1);
	;
}
#define INLINE_F80_1409
#endif
#ifndef INLINE_F80_1407
static int inline_F80_1407 (EIF_POINTER arg1)
{
	return gdk_screen_is_composited ((GdkScreen*)arg1);
	;
}
#define INLINE_F80_1407
#endif
#ifndef INLINE_F82_1958
static void inline_F82_1958 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_widget_set_visual ((GtkWidget *)arg1, (GdkVisual *)arg2)
	;
}
#define INLINE_F82_1958
#endif
#ifndef INLINE_F83_1985
static void inline_F83_1985 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_window_set_skip_taskbar_hint ((GtkWindow*) arg1, (gboolean) arg2);
	;
}
#define INLINE_F83_1985
#endif
#ifndef INLINE_F83_2033
static void inline_F83_2033 (EIF_POINTER arg1)
{
	gtk_widget_show_all ((GtkWidget *)arg1)
	;
}
#define INLINE_F83_2033
#endif
#ifndef INLINE_F80_1414
static EIF_POINTER inline_F80_1414 (void)
{
	return gdk_get_default_root_window();
	;
}
#define INLINE_F80_1414
#endif
#ifndef INLINE_F80_1390
static EIF_POINTER inline_F80_1390 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_get_from_window ((GdkWindow *) arg1, (gint) arg2, (gint) arg3, (gint) arg4, (gint) arg5);
	;
}
#define INLINE_F80_1390
#endif
#ifndef INLINE_F80_1240
static void inline_F80_1240 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F80_1240
#endif
#ifndef INLINE_F80_1300
static void inline_F80_1300 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	return gdk_cairo_set_source_pixbuf ((cairo_t *) arg1, (const GdkPixbuf *) arg2, (gdouble) arg3, (gdouble) arg4);
	;
}
#define INLINE_F80_1300
#endif
#ifndef INLINE_F9_212
static void inline_F9_212 (EIF_POINTER arg1)
{
	cairo_paint ((cairo_t*)arg1)
	;
}
#define INLINE_F9_212
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.make */
void F1117_10152 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,loc4);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,loc6);
	RTLR(5,loc7);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	F1087_9359(Current, (EIF_BOOLEAN) 0);
	ti4_1 = (EIF_INTEGER_32) GTK_WINDOW_POPUP;
	loc1 = (EIF_POINTER) gtk_window_new((GtkWindowType) ti4_1);
	F1114_10052(Current, loc1);
	loc4 = RTOSCF(10077,F1114_10077, (Current));
	loc2 = inline_F80_1411();
	loc3 = inline_F80_1409(loc2);
	tb1 = '\0';
	tb2 = !loc3;
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = EIF_TEST (inline_F80_1407(loc2));
	}
	if (tb1) {
		inline_F82_1958(loc1, loc3);
	}
	gtk_widget_set_app_paintable((GtkWidget*) loc1, (gboolean) (EIF_BOOLEAN) 1);
	inline_F83_1985(loc1, (EIF_BOOLEAN) 1);
	gtk_box_set_homogeneous((GtkBox*) loc1, (gboolean) (EIF_BOOLEAN) 1);
	gtk_container_set_border_width((GtkContainer*) loc1, (guint) ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_43_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_0_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4038[Dtype(RTCW(tr1))-564])(tr1, (EIF_REFERENCE) &ti4_1);
	loc5 = RTLNS(eif_new_type(1051, 0x00).id, 1051, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F982_8029(RTCW(loc5));
	RTAR(Current, loc5);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc5;
	tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_3_);
	loc6 = tr1;
	loc6 = RTRV(eif_new_type(1258, 0x00),loc6);
	if (EIF_TEST(loc6)) {
		tp1 = *(EIF_POINTER *)(loc6+ _PTROFF_48_19_10_9_0_0_);
		gtk_container_add((GtkContainer*) loc1, (GtkWidget*) tp1);
	}
	inline_F83_2033(loc1);
	F1087_9359(Current, (EIF_BOOLEAN) 1);
	F1117_10153(Current);
	tr2 = RTMS_EX_H("EV_PND_STYLE",12,2127107909);
	tr1 = RTLNS(eif_new_type(237, 0x00).id, 237, _OBJSIZ_0_0_0_1_0_0_0_0_);
	tr2 = F238_3947(RTCW(tr1), tr2);
	loc7 = tr2;
	if (EIF_TEST(loc7)) {
		tr1 = RTMS_EX_H("-transparent",12,1378668404);
		tb1 = F945_7496(loc7, tr1);
		if (tb1) {
			F1117_10155(Current);
		}
		tr1 = RTMS_EX_H("+screenshot",11,282083188);
		tb1 = F945_7496(loc7, tr1);
		if (tb1) {
			F1117_10156(Current);
		}
		tr1 = RTMS_EX_H("+colors",7,35068275);
		tb1 = F945_7496(loc7, tr1);
		if (tb1) {
			F1117_10157(Current);
		}
		tr1 = RTMS_EX_H("+blinking",9,944402279);
		tb1 = F945_7496(loc7, tr1);
		if (tb1) {
			F1117_10158(Current);
		}
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_mac__b) {
			tr1 = RTMS_EX_H("+transparent",12,2134684020);
			tb1 = F945_7496(loc7, tr1);
			if ((EIF_BOOLEAN) !tb1) {
				F1117_10155(Current);
			}
		}
	} else {
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_mac__b) {
			F1117_10155(Current);
		}
	}
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.initialize_defaults */
void F1117_10153 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 20L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 40L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.disable_transparency */
void F1117_10155 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.enable_screenshot_hack_enabled */
void F1117_10156 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.enable_colors */
void F1117_10157 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_6_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.enable_blinking */
void F1117_10158 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_7_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.set_size */
void F1117_10171 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1116_10123(Current, arg1, arg2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1027_8681(RTCW(tr1), arg1, arg2);
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.get_pixbuf */
void F1117_10172 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc3 = RTLNSMART(eif_new_type(629, 0).id);
	ti4_1 = F1116_10132(Current);
	ti4_2 = F1116_10134(Current);
	ti4_3 = F1116_10124(Current);
	ti4_4 = F1116_10125(Current);
	F630_4980(RTCW(loc3), ti4_1, ti4_2, ti4_3, ti4_4);
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		tr1 = RTLNSMART(eif_new_type(629, 0).id);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_2_);
		ti4_1 = eif_max_int32 ((EIF_INTEGER_32) (ti4_1 - ti4_2),((EIF_INTEGER_32) 1L));
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_1_);
		ti4_3 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_3_);
		ti4_2 = eif_max_int32 ((EIF_INTEGER_32) (ti4_2 - ti4_3),((EIF_INTEGER_32) 1L));
		ti4_3 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_2_);
		ti4_4 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_3_);
		F630_4980(RTCW(tr1), ti4_1, ti4_2, (EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) * ti4_3), (EIF_INTEGER_32) (((EIF_INTEGER_32) 3L) * ti4_4));
		loc3 = (EIF_REFERENCE) tr1;
	}
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(loc2 == NULL)) {
		tb2 = F630_4997(RTCW(loc2), loc3);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		F1117_10173(Current);
		loc1 = inline_F80_1414();
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			loc4 = F1115_10108(Current);
			if (loc4) {
				F1116_10138(Current);
			}
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_1_);
			ti4_3 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_2_);
			ti4_4 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_3_);
			tp1 = inline_F80_1390(loc1, ti4_1, ti4_2, ti4_3, ti4_4);
			*(EIF_POINTER *)(Current+ _PTROFF_10_10_0_9_0_2_) = (EIF_POINTER) tp1;
			if (loc4) {
				F1116_10137(Current);
			}
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) loc3;
		}
	}
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.discard_pixbuf */
void F1117_10173 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_10_10_0_9_0_2_);
	tb1 = !tp1;
	if ((EIF_BOOLEAN) !tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_10_10_0_9_0_2_);
		inline_F80_1240(tp1);
		tp1 = F1_33(Current);
		*(EIF_POINTER *)(Current+ _PTROFF_10_10_0_9_0_2_) = (EIF_POINTER) tp1;
		*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.update */
void F1117_10174 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REAL_64 loc7 = (EIF_REAL_64) 0;
	EIF_REAL_64 loc8 = (EIF_REAL_64) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc10 = (EIF_POINTER) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc13);
	RTLR(1,Current);
	RTLR(2,loc11);
	RTLR(3,loc12);
	RTLR(4,arg1);
	RTLR(5,loc14);
	RTLR(6,tr1);
	RTLR(7,loc15);
	RTLR(8,loc16);
	RTLR(9,loc17);
	RTLIU(10);
	
	RTGC;
	loc13 = RTOSCF(10077,F1114_10077, (Current));
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_4_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_10_5_))) {
		loc9 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_1_);
	} else {
		loc9 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_1_);
		loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc9 / ((EIF_INTEGER_32) 2L));
	}
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_)) += *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_4_);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_4_) > ((EIF_INTEGER_32) 0L))) {
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_) >= loc9)) {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_4_) = (EIF_INTEGER_32) (EIF_INTEGER_32) -*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_4_);
		}
	} else {
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_) <= ((EIF_INTEGER_32) 1L))) {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_4_) = (EIF_INTEGER_32) (EIF_INTEGER_32) -*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_4_);
		}
	}
	loc11 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	if ((EIF_BOOLEAN)(loc11 == NULL)) {
		loc11 = F22_459(RTCV(RTOSCF(10179,F1117_10179, (Current))));
	}
	loc12 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	if ((EIF_BOOLEAN)(loc12 == NULL)) {
		loc12 = F22_458(RTCV(RTOSCF(10179,F1117_10179, (Current))));
	}
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_4_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_10_5_))) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_49_16_0_7_);
		ti4_2 = F1116_10124(Current);
		ti4_3 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_49_16_0_8_);
		ti4_4 = F1116_10125(Current);
		F1116_10128(Current, (EIF_INTEGER_32) (ti4_1 - (EIF_INTEGER_32) (ti4_2 / ((EIF_INTEGER_32) 2L))), (EIF_INTEGER_32) (ti4_3 - (EIF_INTEGER_32) (ti4_4 / ((EIF_INTEGER_32) 2L))));
		F1014_8451(RTCW(arg1));
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		loc14 = tr1;
		loc14 = RTRV(eif_new_type(1258, 0x00),loc14);
		if (EIF_TEST(loc14)) {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_4_)) {
				F1259_12431(loc14, (EIF_REAL_64) 0.0);
			}
			loc10 = *(EIF_POINTER *)(loc14+ _PTROFF_48_19_10_9_0_1_);
		}
		F1014_8453(RTCW(arg1));
		tb1 = '\0';
		tb2 = '\0';
		tb3 = '\0';
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_5_)) {
			tb4 = !loc10;
			tb3 = (EIF_BOOLEAN) !tb4;
		}
		if (tb3) {
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_10_10_0_9_0_2_);
			tb3 = !tp1;
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			loc15 = tr1;
			tb1 = EIF_TEST(loc15);
		}
		if (tb1) {
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_10_10_0_9_0_2_);
			ti4_1 = *(EIF_INTEGER_32 *)(loc15+ _LNGOFF_0_0_0_0_);
			tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) -(EIF_INTEGER_32) (F1116_10132(Current) - ti4_1));
			ti4_1 = *(EIF_INTEGER_32 *)(loc15+ _LNGOFF_0_0_0_1_);
			tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) -(EIF_INTEGER_32) (F1116_10134(Current) - ti4_1));
			inline_F80_1300(loc10, tp1, tr8_1, tr8_2);
			inline_F9_212(loc10);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_);
		loc7 = (EIF_REAL_64) (ti4_1);
		tr8_1 = (EIF_REAL_64) (loc9);
		loc7 = (EIF_REAL_64) (EIF_REAL_64) ((EIF_REAL_64) 0.7 - (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) 0.4 * loc7)) /  (EIF_REAL_64) (tr8_1)));
		F1014_8441(RTCW(arg1), ((EIF_INTEGER_32) 3L));
		ti4_1 = F1014_8433(RTCW(arg1));
		tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1));
		ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (arg4) /  (EIF_REAL_64) (((EIF_INTEGER_32) 3L))) + (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * arg4)) /  (EIF_REAL_64) (((EIF_INTEGER_32) 3L))) * (EIF_REAL_64) ((EIF_REAL_64) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_)) /  (EIF_REAL_64) (loc9)))) - tr8_1);
		loc1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 1L));
		ti4_1 = F1014_8433(RTCW(arg1));
		tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1));
		ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (arg5) /  (EIF_REAL_64) (((EIF_INTEGER_32) 3L))) + (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * arg5)) /  (EIF_REAL_64) (((EIF_INTEGER_32) 3L))) * (EIF_REAL_64) ((EIF_REAL_64) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_)) /  (EIF_REAL_64) (loc9)))) - tr8_1);
		loc2 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 1L));
		loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg4 - loc1) / ((EIF_INTEGER_32) 2L)));
		loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg5 - loc2) / ((EIF_INTEGER_32) 2L)));
		tb1 = '\0';
		ti4_1 = F1014_8433(RTCW(arg1));
		if ((EIF_BOOLEAN) (loc1 > (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1))) {
			ti4_1 = F1014_8433(RTCW(arg1));
			tb1 = (EIF_BOOLEAN) (loc2 > (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1));
		}
		if (tb1) {
			F999_8317(RTCW(arg1), loc12);
			tb1 = !loc10;
			if ((EIF_BOOLEAN) !tb1) {
				tr4_1 = F992_8178(RTCW(loc12));
				tr8_1 = (EIF_REAL_64) (tr4_1);
				tr4_1 = F992_8179(RTCW(loc12));
				tr8_2 = (EIF_REAL_64) (tr4_1);
				tr4_1 = F992_8180(RTCW(loc12));
				tr8_3 = (EIF_REAL_64) (tr4_1);
				cairo_set_source_rgba((cairo_t*) loc10, (double) tr8_1, (double) tr8_2, (double) tr8_3, (double) loc7);
			}
			ti4_1 = F1014_8433(RTCW(arg1));
			ti4_2 = F1014_8433(RTCW(arg1));
			ti4_3 = F1014_8433(RTCW(arg1));
			ti4_4 = F1014_8433(RTCW(arg1));
			F1014_8468(RTCW(arg1), (EIF_INTEGER_32) (loc5 + ti4_1), (EIF_INTEGER_32) (loc6 + ti4_2), (EIF_INTEGER_32) (loc1 - (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_3)), (EIF_INTEGER_32) (loc2 - (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_4)));
		}
		tb1 = !loc10;
		if ((EIF_BOOLEAN) !tb1) {
			tr4_1 = F992_8178(RTCW(loc11));
			tr8_1 = (EIF_REAL_64) (tr4_1);
			tr4_1 = F992_8179(RTCW(loc11));
			tr8_2 = (EIF_REAL_64) (tr4_1);
			tr4_1 = F992_8180(RTCW(loc11));
			tr8_3 = (EIF_REAL_64) (tr4_1);
			cairo_set_source_rgba((cairo_t*) loc10, (double) tr8_1, (double) tr8_2, (double) tr8_3, (double) loc7);
		} else {
			F999_8317(RTCW(arg1), loc11);
		}
		F1014_8468(RTCW(arg1), loc5, loc6, loc1, loc2);
		F1014_8441(RTCW(arg1), ((EIF_INTEGER_32) 2L));
		ti4_1 = F1014_8433(RTCW(arg1));
		tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1));
		ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (arg4) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L))) - (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (arg4) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L))) * (EIF_REAL_64) ((EIF_REAL_64) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_)) /  (EIF_REAL_64) (loc9)))) - tr8_1);
		loc1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 1L));
		ti4_1 = F1014_8433(RTCW(arg1));
		tr8_1 = (EIF_REAL_64) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1));
		ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (arg5) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L))) - (EIF_REAL_64) ((EIF_REAL_64) ((EIF_REAL_64) (arg5) /  (EIF_REAL_64) (((EIF_INTEGER_32) 2L))) * (EIF_REAL_64) ((EIF_REAL_64) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_)) /  (EIF_REAL_64) (loc9)))) - tr8_1);
		loc2 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 1L));
		loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg4 - loc1) / ((EIF_INTEGER_32) 2L)));
		loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1L) + (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg5 - loc2) / ((EIF_INTEGER_32) 2L)));
		loc3 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_49_16_0_9_);
		loc4 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_49_16_0_10_);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_5_);
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_6_);
		loc8 = (EIF_REAL_64) atan((double) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc3 - ti4_1)) /  (EIF_REAL_64) ((EIF_INTEGER_32) (loc4 - ti4_2))));
		if ((EIF_BOOLEAN) (loc3 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_5_))) {
			if ((EIF_BOOLEAN) (loc4 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_6_))) {
				tr8_1 = (EIF_REAL_64) (loc5);
				tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg4 / ((EIF_INTEGER_32) 4L)));
				ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (tr8_1 + (EIF_REAL_64) ((EIF_REAL_64) sin((double) loc8) * tr8_2));
				loc5 = (EIF_INTEGER_32) ti4_1;
				tr8_1 = (EIF_REAL_64) (loc6);
				tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg5 / ((EIF_INTEGER_32) 4L)));
				ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (tr8_1 + (EIF_REAL_64) ((EIF_REAL_64) cos((double) loc8) * tr8_2));
				loc6 = (EIF_INTEGER_32) ti4_1;
			} else {
				tr8_1 = (EIF_REAL_64) (loc5);
				tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg4 / ((EIF_INTEGER_32) 4L)));
				ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (tr8_1 - (EIF_REAL_64) ((EIF_REAL_64) sin((double) loc8) * tr8_2));
				loc5 = (EIF_INTEGER_32) ti4_1;
				tr8_1 = (EIF_REAL_64) (loc6);
				tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg5 / ((EIF_INTEGER_32) 4L)));
				ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (tr8_1 - (EIF_REAL_64) ((EIF_REAL_64) cos((double) loc8) * tr8_2));
				loc6 = (EIF_INTEGER_32) ti4_1;
			}
		} else {
			if ((EIF_BOOLEAN) (loc4 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_6_))) {
				tr8_1 = (EIF_REAL_64) (loc5);
				tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg4 / ((EIF_INTEGER_32) 4L)));
				ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (tr8_1 + (EIF_REAL_64) ((EIF_REAL_64) sin((double) loc8) * tr8_2));
				loc5 = (EIF_INTEGER_32) ti4_1;
				tr8_1 = (EIF_REAL_64) (loc6);
				tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg5 / ((EIF_INTEGER_32) 4L)));
				ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (tr8_1 + (EIF_REAL_64) ((EIF_REAL_64) cos((double) loc8) * tr8_2));
				loc6 = (EIF_INTEGER_32) ti4_1;
			} else {
				tr8_1 = (EIF_REAL_64) (loc5);
				tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg4 / ((EIF_INTEGER_32) 4L)));
				ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (tr8_1 - (EIF_REAL_64) ((EIF_REAL_64) sin((double) loc8) * tr8_2));
				loc5 = (EIF_INTEGER_32) ti4_1;
				tr8_1 = (EIF_REAL_64) (loc6);
				tr8_2 = (EIF_REAL_64) ((EIF_INTEGER_32) (arg5 / ((EIF_INTEGER_32) 4L)));
				ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (tr8_1 - (EIF_REAL_64) ((EIF_REAL_64) cos((double) loc8) * tr8_2));
				loc6 = (EIF_INTEGER_32) ti4_1;
			}
		}
		tb1 = '\0';
		ti4_1 = F1014_8433(RTCW(arg1));
		if ((EIF_BOOLEAN) (loc1 < (EIF_INTEGER_32) (arg4 - (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1)))) {
			ti4_1 = F1014_8433(RTCW(arg1));
			tb1 = (EIF_BOOLEAN) (loc2 < (EIF_INTEGER_32) (arg5 - (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_1)));
		}
		if (tb1) {
			F999_8317(RTCW(arg1), loc12);
			tb1 = !loc10;
			if ((EIF_BOOLEAN) !tb1) {
				tr4_1 = F992_8178(RTCW(loc12));
				tr8_1 = (EIF_REAL_64) (tr4_1);
				tr4_1 = F992_8179(RTCW(loc12));
				tr8_2 = (EIF_REAL_64) (tr4_1);
				tr4_1 = F992_8180(RTCW(loc12));
				tr8_3 = (EIF_REAL_64) (tr4_1);
				cairo_set_source_rgba((cairo_t*) loc10, (double) tr8_1, (double) tr8_2, (double) tr8_3, (double) loc7);
			}
			ti4_1 = F1014_8433(RTCW(arg1));
			ti4_2 = F1014_8433(RTCW(arg1));
			ti4_3 = F1014_8433(RTCW(arg1));
			ti4_4 = F1014_8433(RTCW(arg1));
			F1014_8468(RTCW(arg1), (EIF_INTEGER_32) (loc5 - ti4_1), (EIF_INTEGER_32) (loc6 - ti4_2), (EIF_INTEGER_32) (loc1 + (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_3)), (EIF_INTEGER_32) (loc2 + (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * ti4_4)));
		}
		tb1 = !loc10;
		if ((EIF_BOOLEAN) !tb1) {
			tr4_1 = F992_8178(RTCW(loc11));
			tr8_1 = (EIF_REAL_64) (tr4_1);
			tr4_1 = F992_8179(RTCW(loc11));
			tr8_2 = (EIF_REAL_64) (tr4_1);
			tr4_1 = F992_8180(RTCW(loc11));
			tr8_3 = (EIF_REAL_64) (tr4_1);
			cairo_set_source_rgba((cairo_t*) loc10, (double) tr8_1, (double) tr8_2, (double) tr8_3, (double) loc7);
		} else {
			F999_8317(RTCW(arg1), loc11);
		}
		F1014_8472(RTCW(arg1), loc5, loc6, loc1, loc2);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		loc16 = tr1;
		loc16 = RTRV(eif_new_type(1258, 0x00),loc16);
		if (EIF_TEST(loc16)) {
			tb1 = *(EIF_BOOLEAN *)(loc16+ _CHROFF_48_12_);
			if (tb1) {
				F1259_12432(loc16);
			}
		}
		F1014_8452(RTCW(arg1));
	} else {
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_7_) && (EIF_BOOLEAN)((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_) % ((EIF_INTEGER_32) 2L)) == ((EIF_INTEGER_32) 1L)))) {
			F1116_10138(Current);
		} else {
			F1116_10137(Current);
		}
		loc1 = F1116_10124(Current);
		loc2 = F1116_10125(Current);
		F1014_8451(RTCW(arg1));
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		loc17 = tr1;
		loc17 = RTRV(eif_new_type(1258, 0x00),loc17);
		if (EIF_TEST(loc17)) {
			loc10 = *(EIF_POINTER *)(loc17+ _PTROFF_48_19_10_9_0_1_);
		}
		F999_8318(RTCW(arg1), loc12);
		F1014_8453(RTCW(arg1));
		tb1 = !loc10;
		if ((EIF_BOOLEAN) !tb1) {
			loc7 = (EIF_REAL_64) (((EIF_INTEGER_32) 1L));
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_);
			loc7 = (EIF_REAL_64) (EIF_REAL_64) (loc7 - (EIF_REAL_64) ((EIF_REAL_64) (ti4_1) /  (EIF_REAL_64) (loc9)));
			tr4_1 = F992_8178(RTCW(loc11));
			tr8_1 = (EIF_REAL_64) (tr4_1);
			tr4_1 = F992_8179(RTCW(loc11));
			tr8_2 = (EIF_REAL_64) (tr4_1);
			tr4_1 = F992_8180(RTCW(loc11));
			tr8_3 = (EIF_REAL_64) (tr4_1);
			cairo_set_source_rgba((cairo_t*) loc10, (double) tr8_1, (double) tr8_2, (double) tr8_3, (double) loc7);
			ti4_1 = F1116_10124(Current);
			ti4_2 = F1116_10125(Current);
			F1014_8471(RTCW(arg1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1, ti4_2);
		}
		ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc1 * *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_))) /  (EIF_REAL_64) (loc9));
		loc1 = (EIF_INTEGER_32) ti4_1;
		ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc2 * *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_))) /  (EIF_REAL_64) (loc9));
		loc2 = (EIF_INTEGER_32) ti4_1;
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 2L)) && (EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 2L)))) {
			F1014_8441(RTCW(arg1), ((EIF_INTEGER_32) 1L));
			tb1 = !loc10;
			if ((EIF_BOOLEAN) !tb1) {
				tr4_1 = F992_8178(RTCW(loc11));
				tr8_1 = (EIF_REAL_64) (tr4_1);
				tr4_1 = F992_8179(RTCW(loc11));
				tr8_2 = (EIF_REAL_64) (tr4_1);
				tr4_1 = F992_8180(RTCW(loc11));
				tr8_3 = (EIF_REAL_64) (tr4_1);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_);
				cairo_set_source_rgba((cairo_t*) loc10, (double) tr8_1, (double) tr8_2, (double) tr8_3, (double) (EIF_REAL_64) ((EIF_REAL_64) (ti4_1) /  (EIF_REAL_64) (loc9)));
			} else {
				F999_8317(RTCW(arg1), loc11);
			}
			ti4_1 = F1116_10124(Current);
			ti4_2 = F1116_10125(Current);
			F1014_8472(RTCW(arg1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - loc1) / ((EIF_INTEGER_32) 2L)), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 - loc2) / ((EIF_INTEGER_32) 2L)), loc1, loc2);
		}
		F1014_8452(RTCW(arg1));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_49_16_0_7_);
		ti4_2 = F1116_10124(Current);
		ti4_3 = *(EIF_INTEGER_32 *)(RTCW(loc13)+ _LNGOFF_49_16_0_8_);
		ti4_4 = F1116_10125(Current);
		F1116_10128(Current, (EIF_INTEGER_32) (ti4_1 - (EIF_INTEGER_32) (ti4_2 / ((EIF_INTEGER_32) 2L))), (EIF_INTEGER_32) (ti4_3 - (EIF_INTEGER_32) (ti4_4 / ((EIF_INTEGER_32) 2L))));
	}
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.on_timeout */
void F1117_10175 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		ti4_1 = F1005_8384(loc1);
		ti4_2 = F1005_8385(loc1);
		F1117_10174(Current, loc1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L), ti4_1, ti4_2);
	}
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.user_can_resize */
EIF_BOOLEAN F1117_10176 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.on_key_event */
void F1117_10177 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	
	
	RTGC;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.call_close_request_actions */
void F1117_10178 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.colors */
static EIF_REFERENCE F1117_10179_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10179);
#define Result RTOSR(10179)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(21, 0x00).id, 21, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10179);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1117_10179 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10179,F1117_10179_body,(Current));
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.is_activated */
EIF_BOOLEAN F1117_10180 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_10_8_);
}


/* {EV_DOCKABLE_SOURCE_HINT_IMP}.activate */
void F1117_10188 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg5);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc1);
	RTLR(6,tr2);
	RTLR(7,tr3);
	RTLIU(8);
	
	RTGC;
	loc2 = arg5;
	loc2 = RTRV(eif_new_type(998, 0x00),loc2);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_6_) && EIF_TEST(loc2))) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6775[Dtype(loc2)-1015])(loc2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R6776[Dtype(loc2)-1015])(loc2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) tr1;
		if ((EIF_BOOLEAN) (RTEQ(*(EIF_REFERENCE *)(Current + _REFACS_8_), *(EIF_REFERENCE *)(Current + _REFACS_9_)) || (EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_8_) == NULL) || (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_9_) == NULL)))) {
			*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
			*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) NULL;
		}
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_4_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_10_5_))) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_7_) = (EIF_INTEGER_32) arg3;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_8_) = (EIF_INTEGER_32) arg4;
	} else {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_7_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg3 / ((EIF_INTEGER_32) 3L));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_8_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg4 / ((EIF_INTEGER_32) 3L));
	}
	F1117_10171(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_7_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_8_));
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_10_7_)) {
		F1116_10137(Current);
	}
	tr1 = RTOSCF(10077,F1114_10077, (Current));
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_49_16_0_7_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_5_) = (EIF_INTEGER_32) ti4_1;
		ti4_1 = *(EIF_INTEGER_32 *)(loc3+ _LNGOFF_49_16_0_8_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_6_) = (EIF_INTEGER_32) ti4_1;
	} else {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_5_) = (EIF_INTEGER_32) arg1;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_6_) = (EIF_INTEGER_32) arg2;
	}
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_5_);
	ti4_2 = F1116_10124(Current);
	ti4_3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_6_);
	ti4_4 = F1116_10125(Current);
	F1116_10128(Current, (EIF_INTEGER_32) (ti4_1 - (EIF_INTEGER_32) (ti4_2 / ((EIF_INTEGER_32) 2L))), (EIF_INTEGER_32) (ti4_3 - (EIF_INTEGER_32) (ti4_4 / ((EIF_INTEGER_32) 2L))));
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_5_)) {
		F1117_10172(Current);
	}
	loc1 = RTLNSMART(eif_new_type(984, 0).id);
	F982_8029(RTCW(loc1));
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc1;
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {939,0xFFF9,0,865,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A473_447, (EIF_POINTER) _A473_447, (EIF_POINTER)(F1117_10175),tr2, 1, 0);
	}
	F600_4832(RTCW(tr1), tr3);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_4_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_10_5_))) {
		F985_8094(RTCW(loc1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_2_));
	} else {
		F985_8094(RTCW(loc1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_10_0_2_) * ((EIF_INTEGER_32) 2L)));
	}
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_HINT_IMP}.deactivate */
void F1117_10189 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1116_10138(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F982_8032(loc1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc1;
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_10_5_)) {
		F1117_10173(Current);
	}
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) NULL;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_10_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

void EIF_Minit473 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
