/*
 * Code for class EV_COLORIZABLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev478.h"
#include <ev_gtk.h>
#include "eif_built_in.h"
#include <stdlib.h>
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F81_1523
static EIF_POINTER inline_F81_1523 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_BACKGROUND_COLOR)
	;
}
#define INLINE_F81_1523
#endif
#ifndef INLINE_F81_1546
static void inline_F81_1546 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	gtk_style_context_get (arg1, arg2, arg3, arg4, NULL)
	;
}
#define INLINE_F81_1546
#endif
#ifndef INLINE_F81_1524
static EIF_POINTER inline_F81_1524 (void)
{
	return (EIF_POINTER) (GTK_STYLE_PROPERTY_COLOR)
	;
}
#define INLINE_F81_1524
#endif
#ifndef INLINE_F80_1240
static void inline_F80_1240 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F80_1240
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_COLORIZABLE_IMP}.background_color_internal */
RTEOMS(10262,1);
EIF_REFERENCE F1126_10263 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8246[Dtype(Current)-1125]);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		tr1 = F1087_9345(loc3);
		Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	} else {
		loc1 = F1126_10283(Current);
		tr1 = RTLNS(eif_new_type(82, 0x00).id, 82, _OBJSIZ_0_0_0_0_0_0_0_0_);
		Result = F83_2246(RTCW(tr1), loc1, RTOMS(10262,0));
		if ((EIF_BOOLEAN)(Result == NULL)) {
			loc2 = (EIF_POINTER) calloc (sizeof(GdkRGBA), 1);
			gtk_style_context_save((GtkStyleContext*) loc1);
			ti4_1 = (EIF_INTEGER_32) GTK_STATE_NORMAL;
			gtk_style_context_set_state((GtkStyleContext*) loc1, (GtkStateFlags) ti4_1);
			ti4_1 = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) loc1);
			tp1 = inline_F81_1523();
			inline_F81_1546(loc1, ti4_1, tp1, (EIF_POINTER *) &(loc2));
			Result = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_2_0_0_0_0_0_0_0_);
			tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->red);
			tr4_1 = (EIF_REAL_32) (tr8_1);
			tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->green);
			tr4_2 = (EIF_REAL_32) (tr8_1);
			tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->blue);
			tr4_3 = (EIF_REAL_32) (tr8_1);
			F992_8177(RTCW(Result), tr4_1, tr4_2, tr4_3);
			gdk_rgba_free((GdkRGBA*) loc2);
			gtk_style_context_restore((GtkStyleContext*) loc1);
		}
	}
	RTLE;
	return Result;
}

/* {EV_COLORIZABLE_IMP}.foreground_color_internal */
RTEOMS(10263,1);
EIF_REFERENCE F1126_10264 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8247[dtype-1125]);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		tr1 = F1087_9345(loc3);
		Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	} else {
		loc1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8249[dtype-1176])(Current);
		tr1 = RTLNS(eif_new_type(82, 0x00).id, 82, _OBJSIZ_0_0_0_0_0_0_0_0_);
		Result = F83_2246(RTCW(tr1), loc1, RTOMS(10263,0));
		if ((EIF_BOOLEAN)(Result == NULL)) {
			loc2 = (EIF_POINTER) calloc (sizeof(GdkRGBA), 1);
			gtk_style_context_save((GtkStyleContext*) loc1);
			ti4_1 = (EIF_INTEGER_32) GTK_STATE_NORMAL;
			gtk_style_context_set_state((GtkStyleContext*) loc1, (GtkStateFlags) ti4_1);
			ti4_1 = (EIF_INTEGER_32) gtk_style_context_get_state((GtkStyleContext*) loc1);
			tp1 = inline_F81_1524();
			inline_F81_1546(loc1, ti4_1, tp1, (EIF_POINTER *) &(loc2));
			Result = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_2_0_0_0_0_0_0_0_);
			tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->red);
			tr4_1 = (EIF_REAL_32) (tr8_1);
			tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->green);
			tr4_2 = (EIF_REAL_32) (tr8_1);
			tr8_1 = (EIF_REAL_64) (((GdkRGBA *)loc2)->blue);
			tr4_3 = (EIF_REAL_32) (tr8_1);
			F992_8177(RTCW(Result), tr4_1, tr4_2, tr4_3);
			gdk_rgba_free((GdkRGBA*) loc2);
			gtk_style_context_restore((GtkStyleContext*) loc1);
		}
	}
	RTLE;
	return Result;
}

/* {EV_COLORIZABLE_IMP}.set_background_color */
void F1126_10265 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	RTCT0("has_implementation", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1105, 0),loc1);
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8246[dtype-1125]) != tr1)) {
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8245[dtype-1176])(Current)) {
			tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
			gtk_event_box_set_visible_window((GtkEventBox*) tp1, (gboolean) (EIF_BOOLEAN) 1);
		}
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O8246[dtype-1125]) = (EIF_REFERENCE) loc1;
		F1126_10267(Current, *(EIF_POINTER *)(Current + O8051[dtype-1113]), arg1);
		tb1 = '\0';
		tb2 = '\0';
		loc2 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8243[dtype-1176])(Current);
		if ((EIF_TRUE)) {
			tb3 = !loc2;
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			tb1 = (EIF_BOOLEAN)(loc2 != *(EIF_POINTER *)(Current + O8051[dtype-1113]));
		}
		if (tb1) {
			F1126_10267(Current, loc2, arg1);
		}
	}
	RTLE;
}

/* {EV_COLORIZABLE_IMP}.real_set_default_background_color */
void F1126_10266 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTGC;
	loc1 = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) arg1);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8236[Dtype(Current)-1176])(Current);
	tr2 = RTMS_EX_H(" { background: ",15,1494617120);
	tr1 = F950_7714(RTCW(tr1), tr2);
	tr2 = RTLNS(eif_new_type(82, 0x00).id, 82, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr3 = F83_2248(RTCW(tr2));
	tr1 = F950_7714(RTCW(tr1), tr3);
	tr2 = RTMS_EX_H(";}\012",3,3898634);
	loc3 = F950_7714(RTCW(tr1), tr2);
	loc4 = RTLNS(eif_new_type(198, 0x00).id, 198, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F199_3236(RTCW(loc4), loc3);
	loc2 = (EIF_POINTER) gtk_css_provider_new();
	tu4_1 = (EIF_NATURAL_32) GTK_STYLE_PROVIDER_PRIORITY_APPLICATION;
	gtk_style_context_add_provider((GtkStyleContext*) loc1, (GtkStyleProvider*) loc2, (guint) tu4_1);
	tp1 = F199_3258(RTCW(loc4));
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_css_provider_load_from_data((GtkCssProvider*) loc2, (const gchar*) tp1, (gssize) ((EIF_INTEGER_32) -1L), (GError**) (EIF_POINTER *) &(loc5)))) {
	}
	tb1 = !loc2;
	if ((EIF_BOOLEAN) !tb1) {
		inline_F80_1240(loc2);
	}
	RTLE;
}

/* {EV_COLORIZABLE_IMP}.real_set_background_color */
void F1126_10267 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg2);
	RTLR(1,loc7);
	RTLR(2,loc8);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tb1 = '\0';
	tb2 = !arg1;
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = (EIF_BOOLEAN)(arg2 != NULL);
	}
	if (tb1) {
		loc1 = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) arg1);
		loc7 = RTLNS(eif_new_type(949, 0x00).id, 949, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F948_7582(RTCW(loc7), ((EIF_INTEGER_32) 1024L));
		loc2 = F992_8200(RTCW(arg2));
		loc3 = F992_8201(RTCW(arg2));
		loc4 = F992_8202(RTCW(arg2));
		loc5 = ((EIF_INTEGER_32) 65535L);
		loc8 = RTMS_EX_H("background",10,1679743332);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8236[dtype-1176])(Current);
		tr2 = RTMS_EX_H(" {",2,8315);
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr2 = F1126_10274(Current, loc8, (EIF_REAL_64) ((EIF_REAL_64) (loc2) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) (loc3) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) (loc4) /  (EIF_REAL_64) (loc5)));
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H("}\012",2,32010);
		tr1 = F950_7714(RTCW(tr1), tr2);
		F950_7695(RTCW(loc7), tr1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8236[dtype-1176])(Current);
		tr2 = RTMS_EX_H(":active {",9,1799874939);
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr4_1 = (EIF_REAL_32) (loc2);
		tr2 = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)tr2 = (EIF_REAL_32) (tr4_1 * 0.90912397f);
		ti4_1 = F888_7054(RTCW(tr2));
		ti4_1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 0L));
		tr4_1 = (EIF_REAL_32) (loc3);
		tr2 = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)tr2 = (EIF_REAL_32) (tr4_1 * 0.90912397f);
		ti4_2 = F888_7054(RTCW(tr2));
		ti4_2 = eif_max_int32 (ti4_2,((EIF_INTEGER_32) 0L));
		tr4_1 = (EIF_REAL_32) (loc4);
		tr2 = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)tr2 = (EIF_REAL_32) (tr4_1 * 0.90912397f);
		ti4_3 = F888_7054(RTCW(tr2));
		ti4_3 = eif_max_int32 (ti4_3,((EIF_INTEGER_32) 0L));
		tr2 = F1126_10274(Current, loc8, (EIF_REAL_64) ((EIF_REAL_64) (ti4_1) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) (ti4_2) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) (ti4_3) /  (EIF_REAL_64) (loc5)));
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H("}\012",2,32010);
		tr1 = F950_7714(RTCW(tr1), tr2);
		F950_7695(RTCW(loc7), tr1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8236[dtype-1176])(Current);
		tr2 = RTMS_EX_H(":hover {",8,592401275);
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr4_1 = (EIF_REAL_32) (loc2);
		tr2 = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)tr2 = (EIF_REAL_32) (tr4_1 * 1.0909488000000001f);
		ti4_1 = F888_7054(RTCW(tr2));
		ti4_1 = eif_min_int32 (ti4_1,loc5);
		tr4_1 = (EIF_REAL_32) (loc3);
		tr2 = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)tr2 = (EIF_REAL_32) (tr4_1 * 1.0909488000000001f);
		ti4_2 = F888_7054(RTCW(tr2));
		ti4_2 = eif_min_int32 (ti4_2,loc5);
		tr4_1 = (EIF_REAL_32) (loc4);
		tr2 = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)tr2 = (EIF_REAL_32) (tr4_1 * 1.0909488000000001f);
		ti4_3 = F888_7054(RTCW(tr2));
		ti4_3 = eif_min_int32 (ti4_3,loc5);
		tr2 = F1126_10274(Current, loc8, (EIF_REAL_64) ((EIF_REAL_64) (ti4_1) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) (ti4_2) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) (ti4_3) /  (EIF_REAL_64) (loc5)));
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H("}\012",2,32010);
		tr1 = F950_7714(RTCW(tr1), tr2);
		F950_7695(RTCW(loc7), tr1);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8236[dtype-1176])(Current);
		tr2 = RTMS_EX_H(":selected {",11,263296123);
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr2 = F1126_10274(Current, loc8, (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc5 - loc2)) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc5 - loc3)) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc5 - (EIF_INTEGER_32) (loc4 / ((EIF_INTEGER_32) 2L)))) /  (EIF_REAL_64) (loc5)));
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(";}\012",3,3898634);
		tr1 = F950_7714(RTCW(tr1), tr2);
		F950_7695(RTCW(loc7), tr1);
		ti4_1 = eif_max_int32 (loc2,loc3);
		loc6 = eif_max_int32 (ti4_1,loc4);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8236[dtype-1176])(Current);
		tr2 = RTMS_EX_H(":disabled {",11,1773468539);
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr2 = F1126_10274(Current, loc8, (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc6 + (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 - loc6) / ((EIF_INTEGER_32) 4L)))) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc6 + (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 - loc6) / ((EIF_INTEGER_32) 4L)))) /  (EIF_REAL_64) (loc5)), (EIF_REAL_64) ((EIF_REAL_64) ((EIF_INTEGER_32) (loc6 + (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 - loc6) / ((EIF_INTEGER_32) 4L)))) /  (EIF_REAL_64) (loc5)));
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(";}\012",3,3898634);
		tr1 = F950_7714(RTCW(tr1), tr2);
		F950_7695(RTCW(loc7), tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) R8237[dtype-1176])(Current, loc1, arg2, loc7);
	}
	RTLE;
}

/* {EV_COLORIZABLE_IMP}.set_foreground_color */
void F1126_10268 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	RTCT0("has_implementation", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1105, 0),loc1);
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8247[dtype-1125]) != loc1)) {
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O8247[dtype-1125]) = (EIF_REFERENCE) loc1;
		F1126_10269(Current, *(EIF_POINTER *)(Current + O8051[dtype-1113]), arg1);
		tb1 = '\0';
		tb2 = '\0';
		loc2 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8243[dtype-1176])(Current);
		if ((EIF_TRUE)) {
			tb3 = !loc2;
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			tb1 = (EIF_BOOLEAN)(loc2 != *(EIF_POINTER *)(Current + O8051[dtype-1113]));
		}
		if (tb1) {
			F1126_10269(Current, loc2, arg1);
		}
	}
	RTLE;
}

/* {EV_COLORIZABLE_IMP}.real_set_foreground_color */
void F1126_10269 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,loc6);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	tb1 = '\0';
	tb2 = !arg1;
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = (EIF_BOOLEAN)(arg2 != NULL);
	}
	if (tb1) {
		loc5 = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) arg1);
		loc1 = F992_8200(RTCW(arg2));
		loc2 = F992_8201(RTCW(arg2));
		loc3 = F992_8202(RTCW(arg2));
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 65535L);
		loc6 = F1126_10276(Current, (EIF_REAL_64) ((EIF_REAL_64) (loc1) /  (EIF_REAL_64) (loc4)), (EIF_REAL_64) ((EIF_REAL_64) (loc2) /  (EIF_REAL_64) (loc4)), (EIF_REAL_64) ((EIF_REAL_64) (loc3) /  (EIF_REAL_64) (loc4)));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8236[dtype-1176])(Current);
		tr2 = RTMS_EX_H(", ",2,11296);
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8236[dtype-1176])(Current);
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(":active, ",9,1799877920);
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8236[dtype-1176])(Current);
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(":hover { color:",15,673149498);
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr1 = F950_7714(RTCW(tr1), loc6);
		tr2 = RTMS_EX_H("; }\012",4,991984906);
		tr1 = F950_7714(RTCW(tr1), tr2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) R8238[dtype-1176])(Current, loc5, arg2, tr1);
	}
	RTLE;
}

/* {EV_COLORIZABLE_IMP}.style_element_name */
EIF_REFERENCE F1126_10271 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTMS_EX_H("*",1,42);
	RTLE;
	return Result;
}

/* {EV_COLORIZABLE_IMP}.apply_background_color_to_style_context */
void F1126_10272 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,arg3);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	loc2 = RTLNS(eif_new_type(198, 0x00).id, 198, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F199_3236(RTCW(loc2), arg3);
	loc1 = (EIF_POINTER) gtk_css_provider_new();
	tu4_1 = (EIF_NATURAL_32) GTK_STYLE_PROVIDER_PRIORITY_APPLICATION;
	gtk_style_context_add_provider((GtkStyleContext*) arg1, (GtkStyleProvider*) loc1, (guint) tu4_1);
	tp1 = F199_3258(RTCW(loc2));
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_css_provider_load_from_data((GtkCssProvider*) loc1, (const gchar*) tp1, (gssize) ((EIF_INTEGER_32) -1L), (GError**) (EIF_POINTER *) &(loc3)))) {
		loc4 = RTLNS(eif_new_type(815, 0x00).id, 815, _OBJSIZ_1_1_0_0_0_1_0_0_);
		F209_3552(RTCW(loc4), loc3);
		tr1 = F816_5388(RTCW(loc4));
		F1_27(Current, tr1);
		F816_5390(RTCW(loc4));
	}
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		inline_F80_1240(loc1);
	}
	RTLE;
}

/* {EV_COLORIZABLE_IMP}.apply_foreground_color_to_style_context */
void F1126_10273 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,arg3);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	loc2 = RTLNS(eif_new_type(198, 0x00).id, 198, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F199_3236(RTCW(loc2), arg3);
	loc1 = (EIF_POINTER) gtk_css_provider_new();
	tu4_1 = (EIF_NATURAL_32) GTK_STYLE_PROVIDER_PRIORITY_APPLICATION;
	gtk_style_context_add_provider((GtkStyleContext*) arg1, (GtkStyleProvider*) loc1, (guint) tu4_1);
	tp1 = F199_3258(RTCW(loc2));
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_css_provider_load_from_data((GtkCssProvider*) loc1, (const gchar*) tp1, (gssize) ((EIF_INTEGER_32) -1L), (GError**) (EIF_POINTER *) &(loc3)))) {
		loc4 = RTLNS(eif_new_type(815, 0x00).id, 815, _OBJSIZ_1_1_0_0_0_1_0_0_);
		F209_3552(RTCW(loc4), loc3);
		tr1 = F816_5388(RTCW(loc4));
		F1_27(Current, tr1);
		F816_5390(RTCW(loc4));
	}
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		inline_F80_1240(loc1);
	}
	RTLE;
}

/* {EV_COLORIZABLE_IMP}.new_css_color_style_string */
EIF_REFERENCE F1126_10274 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(949, 0x00).id, 949, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F948_7584(RTCW(Result), arg1);
	F950_7708(RTCW(Result), (EIF_CHARACTER_8) ':');
	tr1 = F1126_10276(Current, arg2, arg3, arg4);
	F950_7695(RTCW(Result), tr1);
	F950_7708(RTCW(Result), (EIF_CHARACTER_8) ';');
	RTLE;
	return Result;
}

/* {EV_COLORIZABLE_IMP}.new_rgb_color_string */
EIF_REFERENCE F1126_10276 (EIF_REFERENCE Current, EIF_REAL_64 arg1, EIF_REAL_64 arg2, EIF_REAL_64 arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(949, 0x00).id, 949, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F948_7582(RTCW(Result), ((EIF_INTEGER_32) 16L));
	tr1 = RTMS_EX_H("rgb(",4,1919377960);
	F950_7695(RTCW(Result), tr1);
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 255L));
	ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (arg1 * tr8_1);
	F950_7698(RTCW(Result), ti4_1);
	F950_7708(RTCW(Result), (EIF_CHARACTER_8) ',');
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 255L));
	ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (arg2 * tr8_1);
	F950_7698(RTCW(Result), ti4_1);
	F950_7708(RTCW(Result), (EIF_CHARACTER_8) ',');
	tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 255L));
	ti4_1 = (EIF_INTEGER_32) (EIF_REAL_64) (arg3 * tr8_1);
	F950_7698(RTCW(Result), ti4_1);
	F950_7708(RTCW(Result), (EIF_CHARACTER_8) ')');
	RTLE;
	return Result;
}

/* {EV_COLORIZABLE_IMP}.background_color_style_context */
EIF_POINTER F1126_10283 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8243[Dtype(Current)-1176])(Current);
	Result = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) tp1);
	RTLE;
	return Result;
}

/* {EV_COLORIZABLE_IMP}.foreground_color_style_context */
EIF_POINTER F1126_10284 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8243[Dtype(Current)-1176])(Current);
	Result = (EIF_POINTER) gtk_widget_get_style_context((GtkWidget*) tp1);
	RTLE;
	return Result;
}

void EIF_Minit478 (void)
{
	GTCX
	RTPOMS(10262,0,"theme_bg_color",14,404494194);
	RTPOMS(10263,0,"theme_fg_color",14,405415794);
}


#ifdef __cplusplus
}
#endif
