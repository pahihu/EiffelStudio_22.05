/*
 * Code for class EV_APPLICATION_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev467.h"
#include "eif_built_in.h"
#include "eif_memory.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_APPLICATION_I}.make */
void F1111_9793 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {584,939,0xFFF9,0,865,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F585_4749(RTCW(tr1), ((EIF_INTEGER_32) 25L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_thread_capable__b) {
		tr1 = RTLNSMART(eif_new_type(819, 0).id);
		F820_5427(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) tr1;
		tr1 = RTLNSMART(eif_new_type(819, 0).id);
		F820_5427(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_34_) = (EIF_REFERENCE) tr1;
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {579,868,868,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F580_4618(RTCW(tr1), ((EIF_INTEGER_32) 8L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_27_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {588,868,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F589_4749(RTCW(tr1), ((EIF_INTEGER_32) 8L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(119, 0x00).id, 119, _OBJSIZ_0_0_0_0_0_0_0_0_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_32_) = (EIF_REFERENCE) tr1;
	loc1 = RTLNS(eif_new_type(1266, 0x00).id, 1266, _OBJSIZ_0_0_0_1_0_0_0_0_);
	F1267_12648(RTCW(loc1), ((EIF_INTEGER_32) 27L));
	tr1 = RTLNSMART(eif_new_type(990, 0).id);
	F991_8155(RTCW(tr1), loc1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_30_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(990, 0).id);
	F991_8155(RTCW(tr1), loc1, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 0, (EIF_BOOLEAN) 1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_31_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {939,0xFFF9,0,865,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2= RTLNRF(typres0.id, (EIF_POINTER) __A467_300, (EIF_POINTER) _A467_300, (EIF_POINTER)(F1111_9890),tr1, 1, 0);
	}
	RTAR(Current, tr2);
	*(EIF_REFERENCE *)(Current + _REFACS_39_) = (EIF_REFERENCE) tr2;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {939,0xFFF9,0,865,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2= RTLNRF(typres0.id, (EIF_POINTER) __A467_243, (EIF_POINTER) _A467_243, (EIF_POINTER)(F1111_9833),tr1, 1, 0);
	}
	RTAR(Current, tr2);
	*(EIF_REFERENCE *)(Current + _REFACS_40_) = (EIF_REFERENCE) tr2;
	F1111_9824(Current, *(EIF_REFERENCE *)(Current + _REFACS_30_));
	F1111_9825(Current, *(EIF_REFERENCE *)(Current + _REFACS_31_));
	tr1 = RTOSCF(9884,F1111_9884, (Current));
	F144_2990(RTCW(tr1), (EIF_BOOLEAN) 1);
	tr1 = F99_2405(Current);
	F603_4886(RTCW(tr1), NULL);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	F1111_9822(Current, (EIF_BOOLEAN) 1);
	F1087_9359(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_APPLICATION_I}.process_event_queue */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1111_9799 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_REFERENCE EIF_VOLATILE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN EIF_VOLATILE loc3 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE EIF_VOLATILE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE EIF_VOLATILE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 EIF_VOLATILE loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr2 = NULL;
	EIF_REFERENCE  EIF_VOLATILE tr3 = NULL;
	EIF_INTEGER_32  EIF_VOLATILE ti4_1;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_BOOLEAN  EIF_VOLATILE tb3;
	RTLD;
	RTXD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,loc5);
	RTLR(7,saved_except);
	RTLIU(8);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
		F1112_9925(Current);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_2_)) {
			*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
		} else {
			if ((EIF_BOOLEAN) (arg1 && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_49_1_))) {
				(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_)) += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
				if ((EIF_BOOLEAN)(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_) == ((EIF_NATURAL_32) 1500U))) {
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_3_)) {
						plsc();
						eif_mem_coalesc();
					}
					*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
				}
			} else {
				*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
			}
		}
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tb1 = '\0';
		tb2 = '\0';
		if ((EIF_BOOLEAN) !F1087_9344(Current)) {
			tb2 = (EIF_BOOLEAN)(loc1 != NULL);
		}
		if (tb2) {
			tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_49_1_);
		}
		if (tb1) {
			if (F1111_9841(Current)) {
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_25_) == NULL)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F585_4770(RTCW(tr1));
					if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						tr1 = F585_4753(RTCW(tr1));
						tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
						loc6 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
					}
				} else {
					tb1 = '\0';
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_0_)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
						tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
					}
					if (tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_1 = F585_4770(RTCW(tr2));
						tr1 = F633_5113(RTCW(tr1), ti4_1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_1 = F585_4770(RTCW(tr2));
						tr1 = (EIF_REFERENCE) eif_builtin_SPECIAL_aliased_resized_area__i4_s (tr1, ti4_1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
					}
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
					tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					tr2 = F585_4753(RTCW(tr2));
					tr3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F585_4770(RTCW(tr3));
					F633_5105(RTCW(tr1), tr2, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1);
					loc6 = *(EIF_REFERENCE *)(Current + _REFACS_25_);
				}
				if ((EIF_BOOLEAN)(loc6 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R4042[Dtype(RTCW(tr1))-573])(tr1);
				}
				F1111_9842(Current);
				loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			if (F1111_9838(Current)) {
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_24_) == NULL)) {
					ti4_1 = F585_4770(RTCW(loc1));
					if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
						tr1 = F585_4753(RTCW(loc1));
						tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
						loc5 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					}
				} else {
					tb1 = '\0';
					if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_0_)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
						ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
						tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
					}
					if (tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
						ti4_1 = F585_4770(RTCW(loc1));
						tr1 = F633_5113(RTCW(tr1), ti4_1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
					} else {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
						ti4_1 = F585_4770(RTCW(loc1));
						tr1 = (EIF_REFERENCE) eif_builtin_SPECIAL_aliased_resized_area__i4_s (tr1, ti4_1);
						RTAR(Current, tr1);
						*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
					}
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
					tr2 = F585_4753(RTCW(loc1));
					ti4_1 = F585_4770(RTCW(loc1));
					F633_5105(RTCW(tr1), tr2, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1);
					loc5 = *(EIF_REFERENCE *)(Current + _REFACS_24_);
				}
				F1111_9839(Current);
				loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			*(EIF_BOOLEAN *)(Current+ _CHROFF_49_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			if ((EIF_BOOLEAN)(loc6 != NULL)) {
				loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				loc8 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc6);
				for (;;) {
					tb1 = '\01';
					if (!(EIF_BOOLEAN)(loc7 == loc8)) {
						tb1 = F1087_9344(Current);
					}
					if (tb1) break;
					tr1 = F633_5083(RTCW(loc6), loc7);
					F1111_9801(Current, tr1);
					loc7++;
				}
				F633_5118(RTCW(loc6));
			}
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				loc8 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (loc5);
				loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				for (;;) {
					tb2 = '\01';
					if (!(EIF_BOOLEAN)(loc7 == loc8)) {
						tb2 = F1087_9344(Current);
					}
					if (tb2) break;
					tr1 = F633_5083(RTCW(loc5), loc7);
					(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_3_0_0_))(
						*(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_4_2_0_3_0_1_),
						*(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_));
					loc7++;
				}
				F633_5118(RTCW(loc5));
			}
			*(EIF_BOOLEAN *)(Current+ _CHROFF_49_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			tb3 = '\0';
			if (arg1) {
				tb3 = (EIF_BOOLEAN) !F1087_9344(Current);
			}
			if (tb3) {
				F1112_9925(Current);
				tb3 = '\0';
				if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_49_1_)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F585_4770(RTCW(tr1));
					tb3 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
				}
				if (tb3) {
					F1112_9923(Current, ((EIF_INTEGER_32) 20L));
				}
			}
		}
	} else {
		if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 1L))) {
			tr1 = F1111_9881(Current);
			F1111_9876(Current, tr1);
		}
	}
	RTE_E
	RTXSC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if (loc3) {
		loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		F1111_9842(Current);
	}
	if (loc2) {
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		F1111_9839(Current);
	}
	if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) 0L))) {
		loc4++;
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_APPLICATION_I}.call_separate_action */
void F1111_9801 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F940_7439(RTCW(arg1), NULL);
}

/* {EV_APPLICATION_I}.clipboard */
EIF_REFERENCE F1111_9815 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_36_) == NULL)) {
		tr1 = RTLNSMART(eif_new_type(988, 0).id);
		F982_8029(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_36_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_36_);
}

/* {EV_APPLICATION_I}.set_invoke_garbage_collection_when_inactive */
void F1111_9822 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_3_) = (EIF_BOOLEAN) arg1;
}

/* {EV_APPLICATION_I}.set_captured_widget */
void F1111_9823 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_29_) = (EIF_REFERENCE) arg1;
}

/* {EV_APPLICATION_I}.set_help_accelerator */
void F1111_9824 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_30_) = (EIF_REFERENCE) arg1;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_39_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
		tr1 = F991_8156(RTCW(tr1));
		tb2 = F585_4761(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_39_));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_30_);
		tr1 = F991_8156(RTCW(tr1));
		F600_4832(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_39_));
	}
	RTLE;
}

/* {EV_APPLICATION_I}.set_contextual_help_accelerator */
void F1111_9825 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_31_) = (EIF_REFERENCE) arg1;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_40_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		tr1 = F991_8156(RTCW(tr1));
		tb2 = F585_4761(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_40_));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		tr1 = F991_8156(RTCW(tr1));
		F600_4832(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_40_));
	}
	RTLE;
}

/* {EV_APPLICATION_I}.set_locked_window */
void F1111_9827 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_28_) = (EIF_REFERENCE) arg1;
}

/* {EV_APPLICATION_I}.enable_contextual_help */
void F1111_9833 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = F1112_9922(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_29_) = (EIF_REFERENCE) loc1;
		tr1 = F976_7984(loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_38_) = (EIF_REFERENCE) tr1;
		tr1 = F976_7984(loc1);
		F600_4844(RTCW(tr1));
		tr1 = F976_7984(loc1);
		tr2 = RTOSCF(9892,F1111_9892, (Current));
		F602_4853(RTCW(tr1), tr2);
		tr1 = F1027_8657(loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_37_) = (EIF_REFERENCE) tr1;
		tr1 = RTLNS(eif_new_type(31, 0x00).id, 31, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr1 = RTOSCF(700,F32_700, (RTCW(tr1)));
		F1027_8678(loc1, tr1);
		F1027_8670(loc1);
	}
	RTLE;
}

/* {EV_APPLICATION_I}.display_help_for_widget */
void F1111_9834 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = F996_8266(RTCW(arg1));
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_32_);
		tr2 = F941_7443(RTCW(loc1), NULL);
		F120_2717(RTCW(tr1), tr2);
	}
	RTLE;
}

/* {EV_APPLICATION_I}.try_idle_lock */
EIF_BOOLEAN F1111_9838 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_33_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
		Result = F820_5431(RTCW(tr1));
	} else {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return Result;
}

/* {EV_APPLICATION_I}.idle_unlock */
void F1111_9839 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_33_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_33_);
		F820_5432(RTCW(tr1));
	}
	RTLE;
}

/* {EV_APPLICATION_I}.kamikaze_lock */
void F1111_9840 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_34_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
		F820_5430(RTCW(tr1));
	}
	RTLE;
}

/* {EV_APPLICATION_I}.try_kamikaze_lock */
EIF_BOOLEAN F1111_9841 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_34_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
		Result = F820_5431(RTCW(tr1));
	} else {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return Result;
}

/* {EV_APPLICATION_I}.kamikaze_unlock */
void F1111_9842 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_34_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_34_);
		F820_5432(RTCW(tr1));
	}
	RTLE;
}

/* {EV_APPLICATION_I}.do_once_on_idle */
void F1111_9845 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	F1111_9840(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F585_4761(RTCW(tr1), arg1);
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4038[Dtype(RTCW(tr1))-564])(tr1, arg1);
	}
	if ((EIF_BOOLEAN) !F1111_9883(Current)) {
		F1111_9882(Current);
	}
	F1111_9842(Current);
	RTLE;
}

/* {EV_APPLICATION_I}.increase_action_sequence_call_counter */
void F1111_9847 (EIF_REFERENCE Current)
{
	GTCX
	
	
	(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_49_16_0_1_)) += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
}

/* {EV_APPLICATION_I}.pnd_screen */
static EIF_REFERENCE F1111_9854_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9854);
#define Result RTOSR(9854)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F982_8029(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	F1014_8449(RTCW(Result));
	tr1 = RTOSCF(434,F22_434, (RTCV(RTOSCF(9855,F1111_9855, (Current)))));
	F999_8317(RTCW(Result), tr1);
	F1014_8477(RTCW(Result));
	RTOSE (9854);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1111_9854 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9854,F1111_9854_body,(Current));
}

/* {EV_APPLICATION_I}.stock_colors */
static EIF_REFERENCE F1111_9855_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (9855);
#define Result RTOSR(9855)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(21, 0x00).id, 21, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9855);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1111_9855 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9855,F1111_9855_body,(Current));
}

/* {EV_APPLICATION_I}.set_x_y_origin */
void F1111_9858 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_7_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_8_) = (EIF_INTEGER_32) arg2;
	RTLE;
}

/* {EV_APPLICATION_I}.draw_rubber_band */
void F1111_9862 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(9854,F1111_9854, (Current));
	F1014_8461(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_7_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_8_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_9_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_10_));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {EV_APPLICATION_I}.erase_rubber_band */
void F1111_9863 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_4_)) {
		tr1 = RTOSCF(9854,F1111_9854, (Current));
		F1014_8461(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_7_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_8_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_9_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_10_));
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

/* {EV_APPLICATION_I}.set_pnd_pointer_coords */
void F1111_9866 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_9_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_10_) = (EIF_INTEGER_32) arg2;
	RTLE;
}

/* {EV_APPLICATION_I}.create_target_menu */
void F1111_9867 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REFERENCE arg5, EIF_REFERENCE arg6, EIF_REFERENCE arg7, EIF_BOOLEAN arg8)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc13 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc20 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc21 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	RTCFDT;
	RTLD;
	
	RTLI(27);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc11);
	RTLR(3,loc3);
	RTLR(4,loc1);
	RTLR(5,loc7);
	RTLR(6,tr1);
	RTLR(7,tr2);
	RTLR(8,tr3);
	RTLR(9,tr4);
	RTLR(10,loc15);
	RTLR(11,loc16);
	RTLR(12,loc17);
	RTLR(13,arg6);
	RTLR(14,loc18);
	RTLR(15,arg7);
	RTLR(16,loc19);
	RTLR(17,loc4);
	RTLR(18,loc6);
	RTLR(19,loc5);
	RTLR(20,loc8);
	RTLR(21,loc9);
	RTLR(22,loc20);
	RTLR(23,arg5);
	RTLR(24,loc14);
	RTLR(25,loc21);
	RTLR(26,loc22);
	RTLIU(27);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_27_);
	loc11 = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_6_1_0_1_0_0_0_0_);
	F982_8029(RTCW(loc11));
	loc3 = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_1_0_0_0_0_);
	loc1 = F580_4632(RTCW(loc2));
	F580_4657(RTCW(loc2));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {943,0xFFF9,2,865,20,20,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A467_308_2_3, (EIF_POINTER) _A467_308_2_3, (EIF_POINTER)(0),tr1, 1, 2);
	}
	loc7 = (EIF_REFERENCE) tr4;
	for (;;) {
		tb1 = F580_4652(RTCW(loc2));
		if (tb1) break;
		tb2 = '\0';
		ti4_1 = F580_4630(RTCW(loc2));
		tr1 = F827_6018(RTCW(loc3), ti4_1);
		loc15 = tr1;
		loc15 = RTRV(eif_new_type(830, 0x00),loc15);
		if (EIF_TEST(loc15)) {
			tb3 = '\01';
			loc16 = loc15;
			loc16 = RTRV(eif_new_type(1022, 0x00),loc16);
			if (!((EIF_BOOLEAN) !EIF_TEST(loc16))) {
				tb4 = F982_8033(loc16);
				tb3 = (EIF_BOOLEAN) !tb4;
			}
			tb2 = tb3;
		}
		if (tb2) {
			tb2 = '\0';
			loc17 = RTCCL(arg6);
			if (EIF_TEST(loc17)) {
				tr1 = F968_7961(loc15);
				tr2 = RTCCL(loc17);
				tb3 = F604_4889(RTCW(tr1), tr2);
				tb2 = tb3;
			}
			if (tb2) {
				tb2 = '\0';
				loc18 = loc15;
				loc18 = RTRV(eif_new_type(1025, 0x00),loc18);
				if (EIF_TEST(loc18)) {
					tb3 = '\0';
					tb4 = F982_8033(loc18);
					if ((EIF_BOOLEAN) !tb4) {
						tb4 = F1026_8647(loc18);
						tb3 = (EIF_BOOLEAN) !tb4;
					}
					tb2 = tb3;
				}
				if ((EIF_BOOLEAN) !tb2) {
					loc13 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc10 && (EIF_BOOLEAN)(arg7 != NULL))) {
						tr1 = RTLNS(eif_new_type(1068, 0x00).id, 1068, _OBJSIZ_6_0_0_1_0_0_0_0_);
						tr2 = RTMS_EX_H("Pick",4,1349084011);
						F1069_9199(RTCW(tr1), tr2, arg7);
						F1025_8620(RTCW(loc11), tr1);
						loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
					tr1 = *(EIF_REFERENCE *)(loc15 + _REFACS_1_);
					loc19 = tr1;
					if (EIF_TEST(loc19)) {
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,0,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr1 = RTLNTS(typres0.id, 2, 0);
						}
						((EIF_TYPED_VALUE *)tr1+1)->it_r = loc17;
						RTAR(tr1,loc17);
						loc4 = F941_7443(loc19, tr1);
					}
					if ((EIF_BOOLEAN)(loc4 != NULL)) {
						(RTNA((RTCW(loc4), loc15)));
						{
							static EIF_TYPE_INDEX typarr0[] = {149,20,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							loc6 = RTLNS(typres0.id, 149, _OBJSIZ_2_0_0_0_0_0_0_0_);
						}
						F150_3007(RTCW(loc6), loc4, loc7);
						if ((EIF_BOOLEAN)(loc5 == NULL)) {
							{
								static EIF_TYPE_INDEX typarr0[] = {273,149,20,0xFFFF};
								EIF_TYPE typres0;
								static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
								
								typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
								loc5 = RTLNS(typres0.id, 273, _OBJSIZ_4_1_0_1_0_0_0_0_);
							}
							F274_4150(RTCW(loc5), loc6);
						} else {
							F274_4162(RTCW(loc5), loc6);
						}
						loc4 = (EIF_REFERENCE) NULL;
					}
				}
			}
		}
		F580_4658(RTCW(loc2));
	}
	if (loc13) {
		{
			static EIF_TYPE_INDEX typarr0[] = {584,20,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc8 = RTLNS(typres0.id, 584, _OBJSIZ_1_1_0_1_0_0_0_0_);
		}
		F585_4749(RTCW(loc8), ((EIF_INTEGER_32) 0L));
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,0,0xFFFF};
				EIF_TYPE typres0;
				typarr0[3] = dftype;
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
			RTAR(tr1,Current);
			
			{
				static EIF_TYPE_INDEX typarr0[] = {939,0xFFF9,3,865,939,0xFFF9,0,865,273,149,20,584,20,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr4= RTLNRF(typres0.id, (EIF_POINTER) __A467_309_2_3_4, (EIF_POINTER) _A467_309_2_3_4, (EIF_POINTER)(0),tr1, 1, 3);
			}
			loc9 = (EIF_REFERENCE) tr4;
			(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(loc9)+ _PTROFF_4_2_0_3_0_0_))(
				*(EIF_POINTER *)(RTCW(loc9)+ _PTROFF_4_2_0_3_0_1_),
				*(EIF_REFERENCE *)(RTCW(loc9) + _REFACS_1_), loc9, loc5, loc8);
		}
		loc12 = F1025_8609(RTCW(loc11));
		tr1 = F1023_8580(RTCW(arg5));
		loc20 = tr1;
		if (EIF_TEST(loc20)) {
			loc14 = (EIF_REFERENCE) RTCCL(arg6);
			RTCT0("l_pebble /= Void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc14 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = RTCCL(loc14);
			(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc20+ _PTROFF_4_2_0_3_0_0_))(
				*(EIF_POINTER *)(loc20+ _PTROFF_4_2_0_3_0_1_),
				*(EIF_REFERENCE *)(loc20 + _REFACS_1_), loc11, loc8, arg5, tr1);
		} else {
			F585_4780(RTCW(loc8));
			for (;;) {
				tb2 = F541_4494(RTCW(loc8));
				if (tb2) break;
				tr1 = F585_4754(RTCW(loc8));
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
				loc21 = tr1;
				if (EIF_TEST(loc21)) {
					loc14 = (EIF_REFERENCE) RTCCL(arg6);
					RTCT0("l_pebble /= Void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc14 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					tr1 = RTLNS(eif_new_type(1068, 0x00).id, 1068, _OBJSIZ_6_0_0_1_0_0_0_0_);
					tr2 = F585_4754(RTCW(loc8));
					tr2 = (RTNA((RTCW(tr2))), ((EIF_REFERENCE) 0));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,865,603,0xFFF9,1,865,0,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr3 = RTLNTS(typres0.id, 3, 0);
					}
					tr4 = F968_7961(loc21);
					((EIF_TYPED_VALUE *)tr3+1)->it_r = tr4;
					RTAR(tr3,tr4);
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,0,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4 = RTLNTS(typres0.id, 2, 0);
					}
					((EIF_TYPED_VALUE *)tr4+1)->it_r = loc14;
					RTAR(tr4,loc14);
					((EIF_TYPED_VALUE *)tr3+2)->it_r = tr4;
					RTAR(tr3,tr4);
					
					{
						static EIF_TYPE_INDEX typarr0[] = {939,0xFFF9,0,865,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr4= RTLNRF(typres0.id, (EIF_POINTER) __A208_180, (EIF_POINTER) _A208_180, (EIF_POINTER)(F604_4887),tr3, 1, 0);
					}
					F1069_9199(RTCW(tr1), tr2, tr4);
					F1025_8620(RTCW(loc11), tr1);
				}
				F585_4782(RTCW(loc8));
			}
		}
		tb3 = '\0';
		tb4 = F982_8033(RTCW(loc11));
		if ((EIF_BOOLEAN) !tb4) {
			ti4_1 = F1025_8609(RTCW(loc11));
			tb3 = (EIF_BOOLEAN) (ti4_1 > loc12);
		}
		if (tb3) {
			F1084_9322(RTCW(loc11), NULL, (EIF_INTEGER_32) (arg3 - ((EIF_INTEGER_32) 3L)), (EIF_INTEGER_32) (arg4 - ((EIF_INTEGER_32) 3L)));
		} else {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg7 != NULL) && (EIF_BOOLEAN) !arg8)) {
				(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(arg7)+ _PTROFF_4_2_0_3_0_0_))(
					*(EIF_POINTER *)(RTCW(arg7)+ _PTROFF_4_2_0_3_0_1_),
					*(EIF_REFERENCE *)(RTCW(arg7) + _REFACS_1_));
			}
		}
	} else {
		tr1 = F1023_8580(RTCW(arg5));
		loc22 = tr1;
		if (EIF_TEST(loc22)) {
			loc11 = RTLNS(eif_new_type(1083, 0x00).id, 1083, _OBJSIZ_6_1_0_1_0_0_0_0_);
			F982_8029(RTCW(loc11));
			{
				static EIF_TYPE_INDEX typarr0[] = {584,20,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr1 = RTLNS(typres0.id, 584, _OBJSIZ_1_1_0_1_0_0_0_0_);
			}
			F585_4749(RTCW(tr1), ((EIF_INTEGER_32) 0L));
			tr2 = RTCCL(arg6);
			(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc22+ _PTROFF_4_2_0_3_0_0_))(
				*(EIF_POINTER *)(loc22+ _PTROFF_4_2_0_3_0_1_),
				*(EIF_REFERENCE *)(loc22 + _REFACS_1_), loc11, tr1, arg5, tr2);
			tb3 = '\0';
			tb4 = '\0';
			tb5 = F982_8033(RTCW(loc11));
			if ((EIF_BOOLEAN) !tb5) {
				ti4_1 = F1025_8609(RTCW(loc11));
				tb4 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
			}
			if (tb4) {
				tb3 = (EIF_BOOLEAN) !F1112_9931(Current);
			}
			if (tb3) {
				F1084_9322(RTCW(loc11), NULL, (EIF_INTEGER_32) (arg3 - ((EIF_INTEGER_32) 3L)), (EIF_INTEGER_32) (arg4 - ((EIF_INTEGER_32) 3L)));
			}
		}
	}
	tb3 = F580_4654(RTCW(loc2), loc1);
	if (tb3) {
		F580_4659(RTCW(loc2), loc1);
	}
	RTLE;
}

/* {EV_APPLICATION_I}.set_tab_navigation_state */
void F1111_9870 (EIF_REFERENCE Current, EIF_NATURAL_8 arg1)
{
	GTCX
	
	
	*(EIF_NATURAL_8 *)(Current+ _CHROFF_49_14_) = (EIF_NATURAL_8) arg1;
}

/* {EV_APPLICATION_I}.call_post_launch_actions */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1111_9875 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_REFERENCE  EIF_VOLATILE tr1 = NULL;
	RTLD;
	RTXD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,saved_except);
	RTLIU(3);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc1) {
		tr1 = F99_2403(Current);
		F603_4886(RTCW(tr1), NULL);
	} else {
		tr1 = F1111_9881(Current);
		F1111_9876(Current, tr1);
	}
	RTE_E
	RTXSC;
	if ((EIF_BOOLEAN) !loc1) {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_APPLICATION_I}.on_exception_action */
void F1111_9876 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,tr2);
	RTLR(5,arg1);
	RTLR(6,loc1);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_28_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		F1039_8845(loc2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		F1027_8671(loc3);
	}
	tb1 = '\0';
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_49_5_) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_8_) != NULL))) {
		tb2 = F409_4259(RTCV(F99_2416(Current)));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tr1 = F99_2416(Current);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,155,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_r = arg1;
		RTAR(tr2,arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4354[Dtype(RTCW(tr1))-601])(tr1, tr2);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	} else {
		loc1 = RTLNSMART(eif_new_type(1043, 0).id);
		F982_8029(RTCW(loc1));
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_35_) = (EIF_REFERENCE) loc1;
		F1111_9877(Current, loc1, arg1);
	}
	RTLE;
}

/* {EV_APPLICATION_I}.raise_default_exception_dialog */
void F1111_9877 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	RTCFDT;
	RTLD;
	
	RTLI(19);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc6);
	RTLR(5,loc4);
	RTLR(6,loc10);
	RTLR(7,loc11);
	RTLR(8,loc9);
	RTLR(9,loc3);
	RTLR(10,arg1);
	RTLR(11,loc5);
	RTLR(12,loc7);
	RTLR(13,Current);
	RTLR(14,tr2);
	RTLR(15,tr3);
	RTLR(16,loc8);
	RTLR(17,loc13);
	RTLR(18,loc12);
	RTLIU(19);
	
	RTGC;
	loc1 = F156_3067(RTCW(arg2));
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc1);
		loc1 = (EIF_REFERENCE) tr1;
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\015';
		F954_7889(RTCW(loc1), tw1);
	}
	loc2 = RTLNS(eif_new_type(1055, 0x00).id, 1055, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F982_8029(RTCW(loc2));
	F1056_9071(RTCW(loc2));
	F1055_9043(RTCW(loc2));
	loc6 = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F982_8029(RTCW(loc6));
	F993_8226(RTCW(loc6), ((EIF_INTEGER_32) 4L));
	F1013_8431(RTCW(loc2), loc6);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1017_8523(RTCW(loc2), loc1);
	} else {
		tr1 = RTMS_EX_H("No trace available.",19,2146208046);
		F1017_8523(RTCW(loc2), tr1);
	}
	loc4 = RTLNS(eif_new_type(1032, 0x00).id, 1032, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F982_8029(RTCW(loc4));
	loc10 = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F982_8029(RTCW(loc10));
	F1032_8762(RTCW(loc10), ((EIF_INTEGER_32) 5L));
	F1032_8764(RTCW(loc10), ((EIF_INTEGER_32) 5L));
	tr1 = RTLNS(eif_new_type(31, 0x00).id, 31, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(693,F32_693, (RTCW(tr1)));
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	F1025_8620(RTCW(loc10), tr1);
	tr1 = F517_4455(RTCW(loc10));
	F1032_8766(RTCW(loc10), tr1);
	tr1 = F517_4455(RTCW(loc10));
	F1027_8681(RTCW(tr1), ((EIF_INTEGER_32) 32L), ((EIF_INTEGER_32) 32L));
	loc11 = RTLNS(eif_new_type(1050, 0x00).id, 1050, _OBJSIZ_5_2_0_1_0_0_0_0_);
	F982_8029(RTCW(loc11));
	F1018_8533(RTCW(loc11));
	tr1 = RTMS_EX_H("The following uncaught exception has occurred:\012\012Click Ignore to continue or Quit to exit the application",104,940859246);
	F1017_8523(RTCW(loc11), tr1);
	F1025_8620(RTCW(loc10), loc11);
	F1025_8620(RTCW(loc4), loc10);
	F1032_8766(RTCW(loc4), loc10);
	loc9 = RTLNS(eif_new_type(1035, 0x00).id, 1035, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F982_8029(RTCW(loc9));
	loc3 = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F982_8029(RTCW(loc3));
	F1028_8696(RTCW(loc9), loc3);
	F1032_8764(RTCW(loc3), ((EIF_INTEGER_32) 5L));
	F1032_8762(RTCW(loc3), ((EIF_INTEGER_32) 5L));
	F1025_8620(RTCW(loc3), loc2);
	tr1 = RTMS_EX_H("Exception Trace",15,1881935717);
	F1017_8523(RTCW(loc9), tr1);
	F1025_8620(RTCW(loc4), loc9);
	F1028_8696(RTCW(arg1), loc4);
	loc5 = RTLNS(eif_new_type(1033, 0x00).id, 1033, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F982_8029(RTCW(loc5));
	F1025_8620(RTCW(loc4), loc5);
	F1032_8766(RTCW(loc4), loc5);
	loc7 = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Ignore",6,1997112421);
	F1017_8521(RTCW(loc7), tr1);
	tr1 = F969_7964(RTCW(loc7));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,1043,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = arg1;
	RTAR(tr2,arg1);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {939,0xFFF9,0,865,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A401_267, (EIF_POINTER) _A401_267, (EIF_POINTER)(F1039_8831),tr2, 1, 0);
	}
	F600_4832(RTCW(tr1), tr3);
	tr1 = RTLNS(eif_new_type(1034, 0x00).id, 1034, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F982_8029(RTCW(tr1));
	F1025_8620(RTCW(loc5), tr1);
	F1025_8620(RTCW(loc5), loc7);
	F1032_8766(RTCW(loc5), loc7);
	loc8 = RTLNS(eif_new_type(1052, 0x00).id, 1052, _OBJSIZ_6_2_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("Quit",4,1366649204);
	F1017_8521(RTCW(loc8), tr1);
	ti4_1 = F1005_8386(RTCW(loc7));
	F1027_8679(RTCW(loc8), ti4_1);
	tr1 = F969_7964(RTCW(loc8));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = Current;
	RTAR(tr2,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {939,0xFFF9,0,865,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A467_68, (EIF_POINTER) _A467_68, (EIF_POINTER)(F1087_9342),tr2, 1, 0);
	}
	F600_4832(RTCW(tr1), tr3);
	F1025_8620(RTCW(loc5), loc8);
	F1032_8766(RTCW(loc5), loc8);
	F1032_8762(RTCW(loc5), ((EIF_INTEGER_32) 5L));
	F1032_8764(RTCW(loc5), ((EIF_INTEGER_32) 5L));
	tr1 = F156_3065(RTCW(arg2));
	loc13 = tr1;
	if (EIF_TEST(loc13)) {
		loc12 = (EIF_REFERENCE) loc13;
	} else {
		loc12 = RTMS_EX_H("",0,0);
	}
	tr1 = RTMS32_EX_H("U\000\000\000n\000\000\000c\000\000\000a\000\000\000u\000\000\000g\000\000\000h\000\000\000t\000\000\000 \000\000\000E\000\000\000x\000\000\000c\000\000\000e\000\000\000p\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000:\000\000\000 \000\000\000",20,182364448);
	tr2 = F945_7511(RTCW(loc12));
	tr1 = F954_7882(tr1, tr2);
	F1039_8840(RTCW(arg1), tr1);
	F1027_8680(RTCW(arg1), ((EIF_INTEGER_32) 350L));
	F1006_8395(RTCW(arg1), ((EIF_INTEGER_32) 500L), ((EIF_INTEGER_32) 300L));
	F1041_8867(RTCW(arg1));
	F1027_8669(RTCW(loc7));
	RTLE;
}

/* {EV_APPLICATION_I}.new_exception */
EIF_REFERENCE F1111_9881 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F107_2498(RTCV(RTOSCF(3034,F154_3034, (Current))));
	RTCT0("l_result /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_APPLICATION_I}.wake_up_gui_thread */
void F1111_9882 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_APPLICATION_I}.is_gui_thread */
EIF_BOOLEAN F1111_9883 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(9884,F1111_9884, (Current));
	Result = *(EIF_BOOLEAN *)(RTCW(tr1) + O2940[Dtype(tr1)-139]);
	RTLE;
	return Result;
}

/* {EV_APPLICATION_I}.is_gui_thread_cell */
static EIF_REFERENCE F1111_9884_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9884);
#define Result RTOSR(9884)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {143,901,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 143, _OBJSIZ_0_1_0_0_0_0_0_0_);
	}
	F144_2990(RTCW(tr1), (EIF_BOOLEAN) 0);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9884);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1111_9884 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9884,F1111_9884_body,(Current));
}

/* {EV_APPLICATION_I}.help_handler */
void F1111_9890 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1112_9922(Current);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1111_9834(Current, loc1);
	}
	RTLE;
}

/* {EV_APPLICATION_I}.contextual_help_procedure */
static EIF_REFERENCE F1111_9892_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	RTCFDD;
	RTLD;
	
	dftype = Dftype(Current);

	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLIU(5);
	
	RTEV;
	RTGC;
	RTOSP (9892);
#define Result RTOSR(9892)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,0,0xFFFF};
		EIF_TYPE typres0;
		typarr0[3] = dftype;
		
		typres0 = eif_compound_id(dftype, typarr0);
		tr1 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
	RTAR(tr1,Current);
	
	{
		static EIF_TYPE_INDEX typarr0[] = {939,0xFFF9,8,865,868,868,868,892,892,892,868,868,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr4= RTLNRF(typres0.id, (EIF_POINTER) __A467_303_2_3_4_5_6_7_8_9, (EIF_POINTER) _A467_303_2_3_4_5_6_7_8_9, (EIF_POINTER)(F1111_9893),tr1, 1, 8);
	}
	Result = (EIF_REFERENCE) tr4;
	RTOSE (9892);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1111_9892 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9892,F1111_9892_body,(Current));
}

/* {EV_APPLICATION_I}.contextual_help */
void F1111_9893 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg3 == ((EIF_INTEGER_32) 1L))) {
		F1111_9894(Current);
		loc1 = F1016_8500(RTCV(RTOSCF(9854,F1111_9854, (Current))));
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			F1111_9834(Current, loc1);
		}
	}
	RTLE;
}

/* {EV_APPLICATION_I}.disable_contextual_help */
void F1111_9894 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_38_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = F976_7984(loc1);
			F517_4475(RTCW(tr1), loc2);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_37_);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			F1027_8678(loc1, loc3);
		}
		F1027_8671(loc1);
	} else {
		
	}
	RTLE;
}

/* {EV_APPLICATION_I}.inline-agent#1 of create_target_menu */
EIF_BOOLEAN F1111_13034 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	tb1 = '\0';
	tr1 = (RTNA((RTCW(arg1))), ((EIF_REFERENCE) 0));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = (RTNA((RTCW(arg2))), ((EIF_REFERENCE) 0));
		loc2 = tr1;
		tb1 = EIF_TEST(loc2);
	}
	if (tb1) {
		tb1 = F952_7777(loc1, loc2);
		RTLE;
		return (EIF_BOOLEAN) tb1;
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {EV_APPLICATION_I}.inline-agent#2 of create_target_menu */
void F1111_13035 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg3);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_2_);
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), arg1, tr1, arg3);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4038[Dtype(RTCW(arg3))-564])(arg3, tr1);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_3_);
		(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_0_))(
			*(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_4_2_0_3_0_1_),
			*(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_), arg1, tr1, arg3);
	}
	RTLE;
}

void EIF_Minit467 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
