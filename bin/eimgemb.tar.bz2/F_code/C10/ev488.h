
#ifndef _C10_ev488_
#define _C10_ev488_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1136_10400(EIF_REFERENCE);
extern void F1136_10402(EIF_REFERENCE);
extern void F1136_10403(EIF_REFERENCE);
extern void EIF_Minit488(void);
extern char *(*R8343[])();
extern char *(*R8344[])();
extern char *(*R8345[])();
extern char *(*R8346[])();
extern char *(*R8347[])();
extern long O8340[];

#ifdef __cplusplus
}
#endif

#endif
