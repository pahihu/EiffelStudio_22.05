/*
 * Code for class EV_ENVIRONMENT_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev457.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ENVIRONMENT_I}.application */
EIF_REFERENCE F1101_9543 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(9555,F1101_9555, (Current));
	tr1 = F1101_9557(Current, tr1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_23_);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {EV_ENVIRONMENT_I}.application_i */
EIF_REFERENCE F1101_9545 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	tr1 = RTOSCF(9555,F1101_9555, (Current));
	tr1 = F1101_9557(Current, tr1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb2 = F1087_9344(loc1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		tr1 = RTOSCF(9555,F1101_9555, (Current));
		Result = F1101_9558(Current, tr1);
	}
	RTLE;
	return Result;
}

/* {EV_ENVIRONMENT_I}.application_cell */
static EIF_REFERENCE F1101_9555_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9555);
#define Result RTOSR(9555)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {139,1110,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 139, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F140_2990(RTCW(tr1), NULL);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9555);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1101_9555 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9555,F1101_9555_body,(Current));
}

/* {EV_ENVIRONMENT_I}.application_cell_item */
EIF_REFERENCE F1101_9557 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	
	
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	return (EIF_REFERENCE) tr1;
}

/* {EV_ENVIRONMENT_I}.new_application_i */
EIF_REFERENCE F1101_9558 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLR(4,loc4);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc3 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc3)) {
		Result = RTLNS(eif_new_type(1111, 0x00).id, 1111, _OBJSIZ_49_16_0_20_0_5_0_0_);
		F1112_9898(RTCW(Result));
		F140_2990(RTCW(arg1), Result);
	} else {
		loc4 = loc3;
		if (EIF_TEST(loc4)) {
			tb1 = F1087_9344(loc4);
			if (tb1) {
				Result = RTLNS(eif_new_type(1111, 0x00).id, 1111, _OBJSIZ_49_16_0_20_0_5_0_0_);
				F1112_9898(RTCW(Result));
				F140_2990(RTCW(arg1), Result);
			} else {
				RTLE;
				return (EIF_REFERENCE) loc4;
			}
		} else {
			RTCT0("is_same_processor", EX_CHECK);
				RTCF0;
		}
	}
	RTLE;
	return Result;
}

/* {EV_ENVIRONMENT_I}.destroy */
void F1101_9559 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1087_9360(Current, (EIF_BOOLEAN) 1);
}

void EIF_Minit457 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
