
#ifndef _C10_ev459_
#define _C10_ev459_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1103_9570(EIF_REFERENCE);
extern void F1103_9571(EIF_REFERENCE);
extern EIF_REFERENCE F1103_9576(EIF_REFERENCE);
extern EIF_INTEGER_32 F1103_9584(EIF_REFERENCE);
extern EIF_INTEGER_32 F1103_9585(EIF_REFERENCE, EIF_INTEGER_32, EIF_BOOLEAN, EIF_BOOLEAN, EIF_BOOLEAN);
extern void EIF_Minit459(void);
extern void F602_4849(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
