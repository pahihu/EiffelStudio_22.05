
#ifndef _C10_ev458_
#define _C10_ev458_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1102_9561(EIF_REFERENCE);
extern void EIF_Minit458(void);
extern void F1087_9359(EIF_REFERENCE, EIF_BOOLEAN);

#ifdef __cplusplus
}
#endif

#endif
