/*
 * Code for class EV_PIXMAPABLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev498.h"
#include <ev_gtk.h>
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F19_422
static EIF_NATURAL_8 inline_F19_422 (void)
{
	return GTK_ORIENTATION_HORIZONTAL
	;
}
#define INLINE_F19_422
#endif
#ifndef INLINE_F82_1959
static EIF_POINTER inline_F82_1959 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F82_1959
#endif
#ifndef INLINE_F80_1389
static EIF_POINTER inline_F80_1389 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_get_from_surface ((cairo_surface_t *) arg1, (gint) arg2, (gint) arg3, (gint) arg4, (gint) arg5);
	;
}
#define INLINE_F80_1389
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PIXMAPABLE_IMP}.pixmapable_imp_initialize */
void F1146_10446 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = inline_F19_422();
	tp1 = inline_F82_1959(tu1_1, ((EIF_INTEGER_32) 0L));
	*(EIF_POINTER *)(Current + O8374[Dtype(Current)-1145]) = (EIF_POINTER) tp1;
	RTLE;
}

/* {EV_PIXMAPABLE_IMP}.set_pixmap */
void F1146_10448 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1259, 0), loc1);
	RTCT0("l_internal_pixmap /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + O8372[Dtype(Current)-1145]) = (EIF_REFERENCE) loc1;
	ti4_1 = F1260_12466(RTCW(loc1));
	ti4_2 = F1260_12467(RTCW(loc1));
	F1146_10450(Current, loc1, ti4_1, ti4_2);
	RTLE;
}

/* {EV_PIXMAPABLE_IMP}.internal_set_pixmap */
void F1146_10450 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	F1146_10451(Current);
	loc2 = *(EIF_REFERENCE *)(Current + O8372[dtype-1145]);
	loc2 = RTRV(eif_new_type(1259, 0), loc2);
	RTCT0("l_internal_pixmap /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tb1 = '\01';
	ti4_1 = F1260_12466(RTCW(loc2));
	if (!(EIF_BOOLEAN)(arg2 != ti4_1)) {
		ti4_1 = F1260_12467(RTCW(loc2));
		tb1 = (EIF_BOOLEAN)(arg3 != ti4_1);
	}
	if (tb1) {
		F1260_12471(RTCW(arg1), arg2, arg3);
	}
	tp1 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_48_18_10_9_0_2_);
	loc3 = inline_F80_1389(tp1, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), arg2, arg3);
	loc1 = (EIF_POINTER) gtk_image_new_from_pixbuf((GdkPixbuf*) loc3);
	gtk_widget_show((GtkWidget*) loc1);
	tp1 = *(EIF_POINTER *)(Current + O8374[dtype-1145]);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) loc1);
	tp1 = *(EIF_POINTER *)(Current + O8374[dtype-1145]);
	gtk_widget_show((GtkWidget*) tp1);
	RTLE;
}

/* {EV_PIXMAPABLE_IMP}.internal_remove_pixmap */
void F1146_10451 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = F1146_10453(Current);
	if ((EIF_BOOLEAN)(loc1 != F1_33(Current))) {
		tp1 = *(EIF_POINTER *)(Current + O8374[Dtype(Current)-1145]);
		gtk_container_remove((GtkContainer*) tp1, (GtkWidget*) loc1);
	}
	RTLE;
}

/* {EV_PIXMAPABLE_IMP}.gtk_pixmap */
EIF_POINTER F1146_10453 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8374[Dtype(Current)-1145]);
	loc1 = (EIF_POINTER) gtk_container_get_children((GtkContainer*) tp1);
	if ((EIF_BOOLEAN)(loc1 != loc2)) {
		Result = (EIF_POINTER) g_list_nth_data((GList*) loc1, (guint) ((EIF_INTEGER_32) 0L));
		g_list_free((GList*) loc1);
	}
	RTLE;
	return Result;
}

void EIF_Minit498 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
