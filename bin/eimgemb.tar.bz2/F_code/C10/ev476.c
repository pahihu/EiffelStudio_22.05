/*
 * Code for class EV_MENU_ITEM_LIST_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev476.h"
#include <ev_gtk.h>
#include <ev_any_imp.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1114_10054
static EIF_REFERENCE inline_F1114_10054 (EIF_POINTER arg1)
{
	return (EIF_REFERENCE) (c_ev_any_imp_get_eif_reference_from_object_id (arg1))
	;
}
#define INLINE_F1114_10054
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_MENU_ITEM_LIST_IMP}.insert_i_th */
void F1124_10243 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER loc6 = (EIF_POINTER) 0;
	EIF_POINTER loc7 = (EIF_POINTER) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc3);
	RTLR(4,loc8);
	RTLR(5,tr1);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLIU(8);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1239, 0x00), loc1);
	RTCT0("an_item_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = *(EIF_INTEGER_32 *)(Current + O8175[dtype-1117]);
	F1124_10244(Current, loc1, arg2);
	loc3 = loc1;
	loc3 = RTRV(eif_new_type(1242, 0x00), loc3);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		
		F1118_10207(Current, (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)));
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O8175[dtype-1117]) == (EIF_INTEGER_32) (F1119_10229(Current) + ((EIF_INTEGER_32) 1L)))) {
				tb2 = '\0';
				tr1 = F1119_10228(Current, *(EIF_INTEGER_32 *)(Current + O8175[dtype-1117]));
				loc8 = tr1;
				if (EIF_TEST(loc8)) {
					tr1 = *(EIF_REFERENCE *)(loc8 + _REFACS_3_);
					tb2 = F1124_10246(Current, tr1);
				}
				tb1 = tb2;
			}
			if (tb1) break;
			loc4 = F1119_10228(Current, *(EIF_INTEGER_32 *)(Current + O8175[dtype-1117]));
			loc4 = RTRV(eif_new_type(1241, 0x00), loc4);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				tp1 = (RTNA((RTCW(loc3))), ((EIF_POINTER) 0));
				(RTNA((RTCW(loc4), tp1)));
				tp1 = (RTNA((RTCW(loc3))), ((EIF_POINTER) 0));
				if ((EIF_BOOLEAN)(tp1 != loc7)) {
					tp1 = *(EIF_POINTER *)(RTCW(loc4)+ _PTROFF_26_8_6_2_0_0_);
					gtk_check_menu_item_set_active((GtkCheckMenuItem*) tp1, (gboolean) (EIF_BOOLEAN) 0);
				}
				tp1 = (RTNA((RTCW(loc4))), ((EIF_POINTER) 0));
				(RTNA((RTCW(loc3), tp1)));
			}
			F1118_10206(Current);
		}
	} else {
		loc4 = loc1;
		loc4 = RTRV(eif_new_type(1241, 0x00), loc4);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			loc3 = F1124_10245(Current, arg2);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				tp1 = (RTNA((RTCW(loc3))), ((EIF_POINTER) 0));
				(RTNA((RTCW(loc4), tp1)));
				tp1 = (RTNA((RTCW(loc3))), ((EIF_POINTER) 0));
				if ((EIF_BOOLEAN)(tp1 != F1_33(Current))) {
					tp1 = *(EIF_POINTER *)(RTCW(loc4)+ _PTROFF_26_8_6_2_0_0_);
					gtk_check_menu_item_set_active((GtkCheckMenuItem*) tp1, (gboolean) (EIF_BOOLEAN) 0);
				}
				tp1 = (RTNA((RTCW(loc4))), ((EIF_POINTER) 0));
				(RTNA((RTCW(loc3), tp1)));
			} else {
				(RTNA((RTCW(loc4), F1124_10250(Current))));
				loc6 = (RTNA((RTCW(loc4))), ((EIF_POINTER) 0));
				if ((EIF_BOOLEAN)(F1124_10250(Current) != F1_33(Current))) {
					tp1 = *(EIF_POINTER *)(RTCW(loc4)+ _PTROFF_26_8_6_2_0_0_);
					gtk_check_menu_item_set_active((GtkCheckMenuItem*) tp1, (gboolean) (EIF_BOOLEAN) 0);
				}
				tp1 = (RTNA((RTCW(loc4))), ((EIF_POINTER) 0));
				F1124_10249(Current, tp1);
			}
		}
	}
	if ((EIF_BOOLEAN) !F1124_10246(Current, loc1)) {
		loc5 = loc1;
		loc5 = RTRV(eif_new_type(1240, 0x00), loc5);
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			tb2 = (RTNA((RTCW(loc5))), ((EIF_BOOLEAN) 0));
			if (tb2) {
				(RTNA((RTCW(loc5))));
			}
		}
	}
	F1118_10207(Current, loc2);
	RTLE;
}

/* {EV_MENU_ITEM_LIST_IMP}.insert_menu_item */
void F1124_10244 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
	tp2 = F1240_11992(RTCW(arg1));
	gtk_menu_shell_insert((GtkMenuShell*) tp1, (GtkWidget*) tp2, (gint) (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
	tr1 = *(EIF_REFERENCE *)(Current + O8209[dtype-1118]);
	F585_4784(RTCW(tr1), arg2);
	tr1 = *(EIF_REFERENCE *)(Current + O8209[dtype-1118]);
	tr2 = F1087_9345(RTCW(arg1));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4185[Dtype(RTCW(tr1))-584])(tr1, tr2);
	F1233_11969(RTCW(arg1), Current);
	RTLE;
}

/* {EV_MENU_ITEM_LIST_IMP}.separator_imp_by_index */
EIF_REFERENCE F1124_10245 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = F1118_10194(Current);
	F1118_10204(Current);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O8175[dtype-1117]) == (EIF_INTEGER_32) (F1119_10229(Current) + ((EIF_INTEGER_32) 1L)))) {
			tb1 = (EIF_BOOLEAN)(arg1 == loc2);
		}
		if (tb1) break;
		loc3 = F1119_10228(Current, *(EIF_INTEGER_32 *)(Current + O8175[dtype-1117]));
		loc3 = RTRV(eif_new_type(1071, 0x00), loc3);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			Result = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_3_);
			Result = RTRV(eif_new_type(1242, 0x00), Result);
		}
		F1118_10206(Current);
		loc2++;
	}
	F1118_10208(Current, loc1);
	RTLE;
	return Result;
}

/* {EV_MENU_ITEM_LIST_IMP}.is_menu_separator_imp */
EIF_BOOLEAN F1124_10246 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1242, 0x00), loc1);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(loc1 != NULL);
}

/* {EV_MENU_ITEM_LIST_IMP}.remove_i_th */
void F1124_10247 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_POINTER loc6 = (EIF_POINTER) 0;
	EIF_POINTER loc7 = (EIF_POINTER) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc8);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8209[dtype-1118]);
	tr1 = F585_4755(RTCW(tr1), arg1);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1232, 0x00), loc1);
	RTCT0("item_imp_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_26_8_6_2_0_4_);
	tp2 = *(EIF_POINTER *)(RTCW(loc1) + O8051[Dtype(loc1)-1113]);
	gtk_container_remove((GtkContainer*) tp1, (GtkWidget*) tp2);
	tr1 = *(EIF_REFERENCE *)(Current + O8209[dtype-1118]);
	F585_4784(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + O8209[dtype-1118]);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4057[Dtype(RTCW(tr1))-564])(tr1);
	F1233_11969(RTCW(loc1), NULL);
	loc2 = loc1;
	loc2 = RTRV(eif_new_type(1241, 0x00), loc2);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tb1 = (RTNA((RTCW(loc2))), ((EIF_BOOLEAN) 0));
		if (tb1) {
			tp1 = (RTNA((RTCW(loc2))), ((EIF_POINTER) 0));
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) g_slist_length((GSList*) tp1) > ((EIF_INTEGER_32) 1L))) {
				tp1 = (RTNA((RTCW(loc2))), ((EIF_POINTER) 0));
				loc6 = (EIF_POINTER) g_slist_nth_data((GSList*) tp1, (guint) ((EIF_INTEGER_32) 0L));
				tp1 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_26_8_6_2_0_0_);
				if ((EIF_BOOLEAN)(loc6 == tp1)) {
					tp1 = (RTNA((RTCW(loc2))), ((EIF_POINTER) 0));
					loc6 = (EIF_POINTER) g_slist_nth_data((GSList*) tp1, (guint) ((EIF_INTEGER_32) 1L));
				}
				loc2 = inline_F1114_10054(loc6);
				loc2 = RTRV(eif_new_type(1241, 0x00), loc2);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					(RTNA((RTCW(loc2))));
				}
			}
		}
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tp1 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_26_8_6_2_0_0_);
			gtk_radio_menu_item_set_group((GtkRadioMenuItem*) tp1, (GSList*) loc7);
		}
	} else {
		loc3 = loc1;
		loc3 = RTRV(eif_new_type(1242, 0x00), loc3);
		loc8 = *(EIF_REFERENCE *)(Current + O7519[dtype-1086]);
		RTCT0("l_interface /= Void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc8 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			ti4_1 = F1025_8609(RTCW(loc8));
			tb1 = (EIF_BOOLEAN) (arg1 <= ti4_1);
		}
		if (tb1) {
			loc3 = F1124_10245(Current, arg1);
			loc4 = F1025_8603(RTCW(loc8));
			F1025_8615(RTCW(loc8), arg1);
			for (;;) {
				tb1 = '\01';
				tb2 = F541_4494(RTCW(loc8));
				if (!tb2) {
					tr1 = F1025_8602(RTCW(loc8));
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
					tb1 = F1124_10246(Current, tr1);
				}
				if (tb1) break;
				tr1 = F1025_8602(RTCW(loc8));
				loc2 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
				loc2 = RTRV(eif_new_type(1241, 0x00), loc2);
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					if ((EIF_BOOLEAN)(loc3 != NULL)) {
						tp1 = (RTNA((RTCW(loc3))), ((EIF_POINTER) 0));
						(RTNA((RTCW(loc2), tp1)));
						tp1 = (RTNA((RTCW(loc2))), ((EIF_POINTER) 0));
						(RTNA((RTCW(loc3), tp1)));
					} else {
						(RTNA((RTCW(loc2), F1124_10250(Current))));
						tp1 = (RTNA((RTCW(loc2))), ((EIF_POINTER) 0));
						F1124_10249(Current, tp1);
					}
					(RTNA((RTCW(loc2))));
				}
				F1025_8614(RTCW(loc8));
			}
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc5 && (EIF_BOOLEAN)(loc3 == NULL))) {
				F1124_10249(Current, loc7);
			}
			F1025_8615(RTCW(loc8), loc4);
		}
	}
	RTLE;
}

/* {EV_MENU_ITEM_LIST_IMP}.radio_group_ref */
EIF_REFERENCE F1124_10248 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		loc1 = RTLNS(eif_new_type(905, 0x00).id, 905, _OBJSIZ_0_0_0_0_0_1_0_0_);
		tr1 = RTCCL(loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_MENU_ITEM_LIST_IMP}.set_radio_group */
void F1124_10249 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1124_10248(Current);
	F906_7369(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_MENU_ITEM_LIST_IMP}.radio_group */
EIF_POINTER F1124_10250 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = *(EIF_POINTER *)(RTCV(F1124_10248(Current))+ _PTROFF_0_0_0_0_0_0_);
	RTLE;
	return Result;
}

void EIF_Minit476 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
