/*
 * Code for class EV_SENSITIVE_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev488.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SENSITIVE_I}.user_is_sensitive */
EIF_BOOLEAN F1136_10400 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\01';
	if (!(EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8346[dtype-1176])(Current)) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8345[dtype-1176])(Current);
	}
	if (tb1) {
		RTLE;
		return (EIF_BOOLEAN) (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8347[dtype-1176])(Current);
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {EV_SENSITIVE_I}.user_enable_sensitive */
void F1136_10402 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O8340[dtype-1135]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R8343[dtype-1176])(Current);
	RTLE;
}

/* {EV_SENSITIVE_I}.user_disable_sensitive */
void F1136_10403 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O8340[dtype-1135]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R8344[dtype-1176])(Current);
	RTLE;
}

void EIF_Minit488 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
