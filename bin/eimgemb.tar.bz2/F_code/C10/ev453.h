
#ifndef _C10_ev453_
#define _C10_ev453_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1097_9500(EIF_REFERENCE);
extern void EIF_Minit453(void);
extern EIF_REFERENCE F1164_10693(EIF_REFERENCE);
extern long O7631[];

#ifdef __cplusplus
}
#endif

#endif
