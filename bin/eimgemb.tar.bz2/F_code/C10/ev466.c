/*
 * Code for class EV_PIXEL_BUFFER_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev466.h"
#include <ev_gtk.h>
#include "ev_c_util.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F80_1375
static EIF_INTEGER_32 inline_F80_1375 (void)
{
	return GDK_COLORSPACE_RGB;
	;
}
#define INLINE_F80_1375
#endif
#ifndef INLINE_F80_1402
static EIF_POINTER inline_F80_1402 (EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	return gdk_pixbuf_new ((GdkColorspace) arg1, (gboolean) arg2, (int) arg3, (int) arg4, (int) arg5);
	;
}
#define INLINE_F80_1402
#endif
#ifndef INLINE_F80_1404
static void inline_F80_1404 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gdk_pixbuf_fill ((GdkPixbuf*)arg1, (guint32) arg2);
	;
}
#define INLINE_F80_1404
#endif
#ifndef INLINE_F80_1398
static EIF_POINTER inline_F80_1398 (EIF_POINTER arg1, EIF_POINTER* arg2)
{
	return gdk_pixbuf_new_from_file ((char*) arg1, (GError**) arg2);
	;
}
#define INLINE_F80_1398
#endif
#ifndef INLINE_F80_1396
static EIF_NATURAL_32 inline_F80_1396 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_n_channels ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F80_1396
#endif
#ifndef INLINE_F80_1397
static EIF_NATURAL_32 inline_F80_1397 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_bits_per_sample ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F80_1397
#endif
#ifndef INLINE_F80_1395
static EIF_NATURAL_32 inline_F80_1395 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_rowstride ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F80_1395
#endif
#ifndef INLINE_F80_1391
static EIF_POINTER inline_F80_1391 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_pixels ((GdkPixbuf*) arg1);
	;
}
#define INLINE_F80_1391
#endif
#ifndef INLINE_F80_1393
static EIF_INTEGER_32 inline_F80_1393 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_width ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F80_1393
#endif
#ifndef INLINE_F80_1394
static EIF_INTEGER_32 inline_F80_1394 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_height ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F80_1394
#endif
#ifndef INLINE_F80_1400
static EIF_POINTER inline_F80_1400 (EIF_POINTER arg1)
{
	return gdk_pixbuf_new_from_xpm_data ((const char**) arg1);
	;
}
#define INLINE_F80_1400
#endif
#ifndef INLINE_F80_1238
static EIF_POINTER inline_F80_1238 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref_sink((gpointer) arg1))
	;
}
#define INLINE_F80_1238
#endif
#ifndef INLINE_F81_1621
static int inline_F81_1621 (EIF_POINTER arg1)
{
	return (int) (gtk_widget_has_screen ((GtkWidget*) arg1))
	;
}
#define INLINE_F81_1621
#endif
#ifndef INLINE_F81_1622
static EIF_POINTER inline_F81_1622 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_widget_get_screen ((GtkWidget*) arg1))
	;
}
#define INLINE_F81_1622
#endif
#ifndef INLINE_F81_1586
static EIF_POINTER inline_F81_1586 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_icon_theme_get_for_screen ((GdkScreen*) arg1))
	;
}
#define INLINE_F81_1586
#endif
#ifndef INLINE_F81_1587
static EIF_POINTER inline_F81_1587 (void)
{
	return gtk_icon_theme_get_default ();
	;
}
#define INLINE_F81_1587
#endif
#ifndef INLINE_F81_1585
static EIF_POINTER inline_F81_1585 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_8 arg3, EIF_INTEGER_8 arg4, EIF_POINTER arg5)
{
	return (EIF_POINTER) (gtk_icon_theme_load_icon ((GtkIconTheme *)arg1,
                          (const gchar *)arg2,
                          (gint)arg3,
                          (GtkIconLookupFlags)arg4,
                          (GError **)arg5))
	;
}
#define INLINE_F81_1585
#endif
#ifndef INLINE_F80_1240
static void inline_F80_1240 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F80_1240
#endif
#ifndef INLINE_F80_1233
static int inline_F80_1233 (EIF_POINTER arg1)
{
	return (int) (GDK_IS_PIXBUF(arg1))
	;
}
#define INLINE_F80_1233
#endif
#ifndef INLINE_F80_1392
static EIF_POINTER inline_F80_1392 (EIF_POINTER arg1)
{
	return gdk_pixbuf_copy ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F80_1392
#endif
#ifndef INLINE_F80_1239
static EIF_POINTER inline_F80_1239 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref((gpointer) arg1))
	;
}
#define INLINE_F80_1239
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PIXEL_BUFFER_IMP}.make_with_size */
void F1110_9764 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) GTK_MAJOR_VERSION >= ((EIF_INTEGER_32) 2L))) {
		ti4_1 = inline_F80_1375();
		tp1 = inline_F80_1402(ti4_1, (EIF_BOOLEAN) 1, ((EIF_INTEGER_32) 8L), arg1, arg2);
		F1110_9786(Current, tp1);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_);
		inline_F80_1404(tp1, ((EIF_INTEGER_32) 0L));
	} else {
		tr1 = RTLNSMART(eif_new_type(1058, 0).id);
		F1059_9121(RTCW(tr1), arg1, arg2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {EV_PIXEL_BUFFER_IMP}.make */
void F1110_9767 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_new_type(820, 0).id);
	tp1 = F1_33(Current);
	F821_5446(RTCW(tr1), tp1, ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	F1087_9359(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_PIXEL_BUFFER_IMP}.set_with_named_path */
void F1110_9768 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,loc5);
	RTLR(4,tr1);
	RTLR(5,Current);
	RTLR(6,loc6);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) GTK_MAJOR_VERSION >= ((EIF_INTEGER_32) 2L))) {
		loc1 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
		F818_5405(RTCW(loc1), arg1);
		tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
		loc3 = inline_F80_1398(tp1, (EIF_POINTER *) &(loc2));
		tb1 = !loc2;
		if ((EIF_BOOLEAN) !tb1) {
			loc4 = RTLNS(eif_new_type(815, 0x00).id, 815, _OBJSIZ_1_1_0_0_0_1_0_0_);
			F209_3552(RTCW(loc4), loc2);
			loc5 = F816_5388(RTCW(loc4));
			F816_5390(RTCW(loc4));
			tr1 = RTLNS(eif_new_type(154, 0x00).id, 154, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F155_3053(RTCW(tr1), loc5);
		} else {
			F1110_9786(Current, loc3);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			F1059_9133(loc6, arg1);
		}
	}
	RTLE;
}

/* {EV_PIXEL_BUFFER_IMP}.get_pixel */
EIF_NATURAL_32 F1110_9775 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_NATURAL_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc5 = (EIF_NATURAL_32) 0;
	EIF_POINTER tp1;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_);
	loc3 = inline_F80_1396(tp1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_);
	loc5 = inline_F80_1397(tp1);
	loc5 = (EIF_NATURAL_32) (EIF_NATURAL_32) (loc5 / (EIF_NATURAL_32) ((EIF_INTEGER_32) 8L));
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_);
	loc4 = inline_F80_1395(tp1);
	loc1 = (EIF_INTEGER_32) (EIF_NATURAL_32) ((EIF_NATURAL_32) (arg2 * loc4) + (EIF_NATURAL_32) ((EIF_NATURAL_32) (arg1 * loc3) * loc5));
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_);
	tp1 = inline_F80_1391(tp1);
	F821_5448(RTCW(loc2), tp1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 4L)));
	tu4_1 = F821_5514(RTCW(loc2), loc1);
	RTLE;
	return (EIF_NATURAL_32) tu4_1;
}

/* {EV_PIXEL_BUFFER_IMP}.width */
EIF_INTEGER_32 F1110_9779 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) GTK_MAJOR_VERSION > ((EIF_INTEGER_32) 1L))) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_);
		RTLE;
		return (EIF_INTEGER_32) inline_F80_1393(tp1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			ti4_1 = F1005_8384(loc1);
			RTLE;
			return (EIF_INTEGER_32) ti4_1;
		}
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_PIXEL_BUFFER_IMP}.height */
EIF_INTEGER_32 F1110_9780 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) GTK_MAJOR_VERSION > ((EIF_INTEGER_32) 1L))) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_);
		RTLE;
		return (EIF_INTEGER_32) inline_F80_1394(tp1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			ti4_1 = F1005_8385(loc1);
			RTLE;
			return (EIF_INTEGER_32) ti4_1;
		}
	}
	RTLE;
	return (EIF_INTEGER_32) 0;
}

/* {EV_PIXEL_BUFFER_IMP}.data_ptr */
EIF_POINTER F1110_9781 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_);
	return (EIF_POINTER) inline_F80_1391(tp1);
}

/* {EV_PIXEL_BUFFER_IMP}.set_from_stock */
void F1110_9782 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = (EIF_REFERENCE) arg1;
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	F1110_9783(Current, tp1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_);
	tb1 = !tp1;
	if (tb1) {
		loc2 = F818_5408(RTCW(loc1));
		F954_7904(RTCW(loc2));
		tb1 = '\01';
		tr1 = RTMS32_EX_H("i\000\000\000n\000\000\000f\000\000\000o\000\000\000r\000\000\000m\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",11,684350830);
		tb2 = F952_7775(RTCW(loc2), tr1);
		if (!tb2) {
			tr1 = RTMS32_EX_H("d\000\000\000i\000\000\000a\000\000\000l\000\000\000o\000\000\000g\000\000\000-\000\000\000i\000\000\000n\000\000\000f\000\000\000o\000\000\000r\000\000\000m\000\000\000a\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",18,1358691950);
			tb2 = F952_7775(RTCW(loc2), tr1);
			tb1 = tb2;
		}
		if (tb1) {
			tp1 = (EIF_POINTER) information_pixmap_xpm();
			tp1 = inline_F80_1400(tp1);
			F1110_9786(Current, tp1);
		} else {
			tr1 = RTMS32_EX_H("d\000\000\000i\000\000\000a\000\000\000l\000\000\000o\000\000\000g\000\000\000-\000\000\000e\000\000\000r\000\000\000r\000\000\000o\000\000\000r\000\000\000",12,1766531442);
			tb1 = F952_7775(RTCW(loc2), tr1);
			if (tb1) {
				tp1 = (EIF_POINTER) error_pixmap_xpm();
				tp1 = inline_F80_1400(tp1);
				F1110_9786(Current, tp1);
			} else {
				tr1 = RTMS32_EX_H("d\000\000\000i\000\000\000a\000\000\000l\000\000\000o\000\000\000g\000\000\000-\000\000\000q\000\000\000u\000\000\000e\000\000\000s\000\000\000t\000\000\000i\000\000\000o\000\000\000n\000\000\000",15,601717614);
				tb1 = F952_7775(RTCW(loc2), tr1);
				if (tb1) {
					tp1 = (EIF_POINTER) question_pixmap_xpm();
					tp1 = inline_F80_1400(tp1);
					F1110_9786(Current, tp1);
				} else {
					tr1 = RTMS32_EX_H("d\000\000\000i\000\000\000a\000\000\000l\000\000\000o\000\000\000g\000\000\000-\000\000\000w\000\000\000a\000\000\000r\000\000\000n\000\000\000i\000\000\000n\000\000\000g\000\000\000",14,1187148903);
					tb1 = F952_7775(RTCW(loc2), tr1);
					if (tb1) {
						tp1 = (EIF_POINTER) warning_pixmap_xpm();
						tp1 = inline_F80_1400(tp1);
						F1110_9786(Current, tp1);
					} else {
						F1110_9764(Current, ((EIF_INTEGER_32) 48L), ((EIF_INTEGER_32) 48L));
					}
				}
			}
		}
	}
	RTLE;
}

/* {EV_PIXEL_BUFFER_IMP}.set_from_stock_id */
void F1110_9783 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc6);
	RTLIU(2);
	
	RTGC;
	tp1 = F1_33(Current);
	loc2 = (EIF_POINTER) gtk_label_new((gchar*) tp1);
	tp1 = inline_F80_1238(loc2);
	loc2 = (EIF_POINTER) tp1;
	if (EIF_TEST (inline_F81_1621(loc2))) {
		loc5 = inline_F81_1622(loc2);
		loc3 = inline_F81_1586(loc5);
	} else {
		loc3 = inline_F81_1587();
	}
	loc1 = inline_F81_1585(loc3, arg1, (EIF_INTEGER_8) ((EIF_INTEGER_32) 48L), (EIF_INTEGER_8) ((EIF_INTEGER_32) 0L), (EIF_POINTER *) &(loc4));
	tb1 = !loc4;
	if ((EIF_BOOLEAN) !tb1) {
		loc6 = RTLNS(eif_new_type(815, 0x00).id, 815, _OBJSIZ_1_1_0_0_0_1_0_0_);
		F209_3552(RTCW(loc6), loc4);
		F816_5390(RTCW(loc6));
	}
	inline_F80_1240(loc2);
	loc2 = F1_33(Current);
	if ((EIF_BOOLEAN)(loc1 != F1_33(Current))) {
		if ((EIF_BOOLEAN) !EIF_TEST (inline_F80_1233(loc1))) {
		}
		tp1 = inline_F80_1392(loc1);
		F1110_9786(Current, tp1);
		inline_F80_1240(loc1);
	}
	RTLE;
}

/* {EV_PIXEL_BUFFER_IMP}.set_gdkpixbuf */
void F1110_9786 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_) != F1_33(Current))) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_);
		inline_F80_1240(tp1);
	}
	if ((EIF_BOOLEAN)(arg1 != F1_33(Current))) {
		loc1 = inline_F80_1239(arg1);
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gdk_pixbuf_get_has_alpha((GdkPixbuf*) arg1))) {
			tp1 = (EIF_POINTER) gdk_pixbuf_add_alpha((GdkPixbuf*) loc1, (gboolean) (EIF_BOOLEAN) 0, (guchar) (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L), (guchar) (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L), (guchar) (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L));
			*(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_) = (EIF_POINTER) tp1;
			inline_F80_1240(arg1);
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_);
			tp1 = inline_F80_1239(tp1);
			*(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_) = (EIF_POINTER) tp1;
		} else {
			*(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_) = (EIF_POINTER) arg1;
		}
	} else {
		tp1 = F1_33(Current);
		*(EIF_POINTER *)(Current+ _PTROFF_4_2_0_0_0_0_) = (EIF_POINTER) tp1;
	}
	RTLE;
}

/* {EV_PIXEL_BUFFER_IMP}.destroy */
void F1110_9789 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1087_9361(Current, (EIF_BOOLEAN) 1);
	tp1 = F1_33(Current);
	F1110_9786(Current, tp1);
	F1087_9360(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_PIXEL_BUFFER_IMP}.dispose */
void F1110_9790 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1_33(Current);
	F1110_9786(Current, tp1);
	RTLE;
}

void EIF_Minit466 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
