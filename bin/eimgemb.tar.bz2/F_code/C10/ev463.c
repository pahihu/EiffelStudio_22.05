/*
 * Code for class EV_FONT_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev463.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FONT_I}.set_values */
void F1107_9666 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REFERENCE arg5)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg5);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != arg5)) {
		F1107_9687(Current, arg5);
		F1108_9720(Current);
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_7_) != arg1)) {
		F1108_9697(Current, arg1);
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_5_) != arg2)) {
		F1108_9699(Current, arg2);
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_4_) != arg3)) {
		F1108_9700(Current, arg3);
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_3_2_0_3_) != arg4)) {
		F1108_9701(Current, arg4);
	}
	RTLE;
}

/* {EV_FONT_I}.copy_font */
void F1107_9683 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	ti4_1 = F993_8218(RTCW(arg1));
	ti4_2 = F993_8220(RTCW(arg1));
	ti4_3 = F993_8221(RTCW(arg1));
	ti4_4 = F993_8222(RTCW(arg1));
	tr1 = F993_8225(RTCW(arg1));
	F1108_9703(Current, ti4_1, ti4_2, ti4_3, ti4_4, tr1);
	RTLE;
}

/* {EV_FONT_I}.copy_preferred_families */
void F1107_9687 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
	F602_4857(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
	F602_4857(RTCW(tr1));
	F600_4844(RTCW(loc1));
	F600_4833(RTCW(loc1), arg1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
	F602_4859(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
	F602_4859(RTCW(tr1));
	RTLE;
}

void EIF_Minit463 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
