/*
 * Code for class EV_ANY_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev470.h"
#include <ev_gtk.h>
#include "eif_built_in.h"
#include <ev_gtk_callback_marshal.h>
#include <ev_any_imp.h>
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F80_1238
static EIF_POINTER inline_F80_1238 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref_sink((gpointer) arg1))
	;
}
#define INLINE_F80_1238
#endif
#ifndef INLINE_F80_1237
static int inline_F80_1237 (EIF_POINTER arg1)
{
	return (int) (g_object_is_floating((gpointer) arg1))
	;
}
#define INLINE_F80_1237
#endif
#ifndef INLINE_F80_1239
static EIF_POINTER inline_F80_1239 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref((gpointer) arg1))
	;
}
#define INLINE_F80_1239
#endif
#ifndef INLINE_F83_2008
static int inline_F83_2008 (EIF_POINTER arg1)
{
	return (int) (GTK_IS_WIDGET(arg1))
	;
}
#define INLINE_F83_2008
#endif
#ifndef INLINE_F80_1236
static EIF_NATURAL_32 inline_F80_1236 (EIF_POINTER arg1)
{
	return (EIF_NATURAL_32) (((GObject*)arg1)->ref_count)
	;
}
#define INLINE_F80_1236
#endif
#ifndef INLINE_F1114_10054
static EIF_REFERENCE inline_F1114_10054 (EIF_POINTER arg1)
{
	return (EIF_REFERENCE) (c_ev_any_imp_get_eif_reference_from_object_id (arg1))
	;
}
#define INLINE_F1114_10054
#endif
#ifndef INLINE_F81_1624
static void inline_F81_1624 (EIF_POINTER arg1)
{
	gtk_widget_destroy((GtkWidget*) arg1)
	;
}
#define INLINE_F81_1624
#endif
#ifndef INLINE_F832_6120
static int inline_F832_6120 (void)
{
	return (int) ((EIF_BOOLEAN) c_ev_gtk_callback_marshal_is_enabled)
	;
}
#define INLINE_F832_6120
#endif
#ifndef INLINE_F832_6121
static void inline_F832_6121 (EIF_BOOLEAN arg1)
{
	c_ev_gtk_callback_marshal_set_is_enabled((int)arg1)
	;
}
#define INLINE_F832_6121
#endif
#ifndef INLINE_F80_1243
static void inline_F80_1243 (EIF_POINTER arg1)
{
	g_object_run_dispose((GObject *) arg1)
	;
}
#define INLINE_F80_1243
#endif
#ifndef INLINE_F80_1240
static void inline_F80_1240 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F80_1240
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ANY_IMP}.c_object */
EIF_POINTER F1114_10050 (EIF_REFERENCE Current)
{
	return *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
}


/* {EV_ANY_IMP}.set_c_object */
void F1114_10052 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8064[dtype-1116])(Current)) {
		loc1 = (EIF_POINTER) gtk_event_box_new();
		tp1 = inline_F80_1238(loc1);
		loc1 = (EIF_POINTER) tp1;
		gtk_container_add((GtkContainer*) loc1, (GtkWidget*) arg1);
		gtk_widget_show((GtkWidget*) arg1);
	} else {
		if (EIF_TEST (inline_F80_1237(arg1))) {
			*(EIF_BOOLEAN *)(Current + O8052[dtype-1113]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc1 = inline_F80_1238(arg1);
		} else {
			
			loc1 = (EIF_POINTER) arg1;
			tp1 = inline_F80_1239(loc1);
			loc1 = (EIF_POINTER) tp1;
		}
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5187[dtype-826]) == ((EIF_INTEGER_32) 0L))) {
		ti4_1 = (EIF_INTEGER_32) eif_builtin_IDENTIFIED_ROUTINES_eif_current_object_id__i4 (Current);
		*(EIF_INTEGER_32 *)(Current + O5187[dtype-826]) = (EIF_INTEGER_32) ti4_1;
	}
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O5187[dtype-826]);
	set_eif_oid_in_c_object((loc1), (ti4_1), ((EIF_POINTER) A470_84));
	*(EIF_POINTER *)(Current + O8051[dtype-1113]) = (EIF_POINTER) loc1;
	tb1 = '\0';
	if (EIF_TEST (inline_F83_2008(loc1))) {
		tb1 = (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_toplevel((GtkWidget*) loc1));
	}
	if (tb1) {
		if ((EIF_BOOLEAN)(inline_F80_1236(loc1) != (EIF_NATURAL_32) ((EIF_INTEGER_32) 2L))) {
			
			tr2 = (EIF_REFERENCE) eif_builtin_ANY_generator__s1 (Current);
			tr3 = RTMS_EX_H(".set_c_object: unexpected ref count for c_object=",49,1740544573);
			tr2 = F950_7714(RTCW(tr2), tr3);
			tr3 = eif_out__p_s1(loc1);
			tr2 = F950_7714(RTCW(tr2), tr3);
			tr3 = RTMS_EX_H(" #",2,8227);
			tr2 = F950_7714(RTCW(tr2), tr3);
			tu4_1 = inline_F80_1236(loc1);
			tr3 = eif_out__u4_s1(tu4_1);
			tr2 = F950_7714(RTCW(tr2), tr3);
			tr3 = RTMS_EX_H(" /= 2 !\012",8,1002112522);
			tr2 = F950_7714(RTCW(tr2), tr3);
			tr1 = RTLNS(eif_new_type(79, 0x00).id, 79, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F80_1234(RTCW(tr1), tr2);
		}
	} else {
		if ((EIF_BOOLEAN)(inline_F80_1236(loc1) != (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L))) {
			
			tr2 = (EIF_REFERENCE) eif_builtin_ANY_generator__s1 (Current);
			tr3 = RTMS_EX_H(".set_c_object: unexpected ref count for c_object=",49,1740544573);
			tr2 = F950_7714(RTCW(tr2), tr3);
			tr3 = eif_out__p_s1(loc1);
			tr2 = F950_7714(RTCW(tr2), tr3);
			tr3 = RTMS_EX_H(" #",2,8227);
			tr2 = F950_7714(RTCW(tr2), tr3);
			tu4_1 = inline_F80_1236(loc1);
			tr3 = eif_out__u4_s1(tu4_1);
			tr2 = F950_7714(RTCW(tr2), tr3);
			tr3 = RTMS_EX_H(" /= 1 !\012",8,985335306);
			tr2 = F950_7714(RTCW(tr2), tr3);
			tr1 = RTLNS(eif_new_type(79, 0x00).id, 79, _OBJSIZ_0_0_0_0_0_0_0_0_);
			F80_1234(RTCW(tr1), tr2);
		}
	}
	RTLE;
}

/* {EV_ANY_IMP}.update_gtk_name */
void F1114_10053 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	
	
	RTGC;
}

/* {EV_ANY_IMP}.eif_object_from_c */
EIF_REFERENCE F1114_10054 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	Result = inline_F1114_10054 ((EIF_POINTER) arg1);
	RTLE;
	return Result;
}

/* {EV_ANY_IMP}.destroy */
void F1114_10055 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1_33(Current);
	F1114_10062(Current, tp1);
	loc1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	tb1 = '\0';
	tb2 = !loc1;
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = EIF_TEST (inline_F83_2008(loc1));
	}
	if (tb1) {
		if ((EIF_BOOLEAN) EIF_TEST(gtk_widget_is_toplevel((GtkWidget*) loc1))) {
			if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((loc1)))) {
			} else {
				
				inline_F81_1624(loc1);
			}
		} else {
			inline_F81_1624(loc1);
		}
	}
	F1087_9360(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_ANY_IMP}.real_signal_connect */
void F1114_10056 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	loc1 = RTOSCF(10077,F1114_10077, (Current));
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	tr2 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F818_5410(RTCW(tr2), arg2);
	F832_6106(RTCW(tr1), arg1, tr2, arg3, (EIF_BOOLEAN) 0);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_1_0_1_);
	F1114_10061(Current, arg1, arg2, ti4_1);
	RTLE;
}

/* {EV_ANY_IMP}.real_signal_connect_after */
void F1114_10057 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLR(4,tr2);
	RTLR(5,arg3);
	RTLIU(6);
	
	RTGC;
	loc1 = RTOSCF(10077,F1114_10077, (Current));
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	tr2 = F1112_10032(RTCW(loc1), arg2);
	F832_6106(RTCW(tr1), arg1, tr2, arg3, (EIF_BOOLEAN) 1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_1_0_1_);
	F1114_10061(Current, arg1, arg2, ti4_1);
	RTLE;
}

/* {EV_ANY_IMP}.record_signal_connection */
void F1114_10061 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg3 > ((EIF_INTEGER_32) 0L))) {
		loc1 = *(EIF_REFERENCE *)(Current + O8063[dtype-1113]);
		if ((EIF_BOOLEAN)(loc1 == NULL)) {
			{
				static EIF_TYPE_INDEX typarr0[] = {584,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					static EIF_TYPE_INDEX typarr2[] = {540,814,0xFFFF};
					EIF_TYPE typres2;
					static EIF_TYPE typcache2 = {INVALID_DTYPE, 0};
					
					typres2 = (typcache2.id != INVALID_DTYPE ? typcache2 : (typcache2 = eif_compound_id(Dftype(Current), typarr2)));
					l_type = eif_final_id(Y4052,Y4052_gen_type,typres2.id,369);
					typarr0[1] = l_type.annotations | 0xFF00;
					typarr0[2] = l_type.id;
				}
				
				typres0 = eif_compound_id(Dftype(Current), typarr0);
				loc1 = RTLNS(typres0.id, 584, _OBJSIZ_1_1_0_1_0_0_0_0_);
			}
			F585_4749(RTCW(loc1), ((EIF_INTEGER_32) 1L));
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + O8063[dtype-1113]) = (EIF_REFERENCE) loc1;
		}
		tr1 = RTLNS(eif_new_type(814, 0x00).id, 814, _OBJSIZ_0_1_0_1_0_1_0_0_);
		F815_5379(RTCW(tr1), arg1, arg3);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4073[Dtype(RTCW(loc1))-564])(loc1, tr1);
	}
	RTLE;
}

/* {EV_ANY_IMP}.disconnect_all_recorded_connections */
void F1114_10062 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8063[dtype-1113]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4018[Dtype(loc1)-564])(loc1);
		for (;;) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4017[Dtype(loc1)-564])(loc1);
			if (tb1) break;
			tb2 = '\0';
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4052[Dtype(loc1)-564])(loc1);
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				tb3 = *(EIF_BOOLEAN *)(loc2+ _CHROFF_0_0_);
				tb2 = tb3;
			}
			if (tb2) {
				tb2 = '\01';
				tb3 = !arg1;
				if (!tb3) {
					tp1 = *(EIF_POINTER *)(loc2+ _PTROFF_0_1_0_1_0_0_);
					tb2 = (EIF_BOOLEAN)(tp1 == arg1);
				}
				if (tb2) {
					F815_5382(loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R4057[Dtype(loc1)-564])(loc1);
				} else {
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R4031[Dtype(loc1)-564])(loc1);
				}
			} else {
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R4057[Dtype(loc1)-564])(loc1);
			}
		}
		tb2 = F409_4259(loc1);
		if (tb2) {
			*(EIF_REFERENCE *)(Current + O8063[dtype-1113]) = (EIF_REFERENCE) NULL;
		} else {
			F1_31(Current);
		}
	}
	RTLE;
}

/* {EV_ANY_IMP}.needs_event_box */
EIF_BOOLEAN F1114_10064 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_ANY_IMP}.dispose */
void F1114_10066 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	tb1 = '\0';
	tb2 = !loc1;
	if ((EIF_BOOLEAN) !tb2) {
		tb1 = EIF_TEST (inline_F83_2008(loc1));
	}
	if (tb1) {
		if ((EIF_BOOLEAN) EIF_TEST(gtk_widget_is_toplevel((GtkWidget*) loc1))) {
			inline_F81_1624(loc1);
		} else {
			inline_F81_1624(loc1);
		}
	}
	F827_6023(Current);
	RTLE;
}

/* {EV_ANY_IMP}.c_object_dispose */
void F1114_10067 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O8065[dtype-1113])) {
		*(EIF_BOOLEAN *)(Current + O8065[dtype-1113]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc2 = EIF_TEST (inline_F832_6120());
		inline_F832_6121((EIF_BOOLEAN) 0);
		loc1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		tb1 = !loc1;
		if ((EIF_BOOLEAN) !tb1) {
			if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((loc1)))) {
				inline_F81_1624(loc1);
			} else {
				if (EIF_TEST (inline_F83_2008(loc1))) {
					inline_F81_1624(loc1);
				} else {
					inline_F80_1243(loc1);
				}
			}
			inline_F80_1240(loc1);
			tp1 = F1_33(Current);
			*(EIF_POINTER *)(Current + O8051[dtype-1113]) = (EIF_POINTER) tp1;
		}
		F1087_9360(Current, (EIF_BOOLEAN) 1);
		inline_F832_6121(loc2);
	}
	RTLE;
}

/* {EV_ANY_IMP}.process_draw_event */
EIF_BOOLEAN F1114_10068 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {EV_ANY_IMP}.process_configure_event */
EIF_BOOLEAN F1114_10070 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {EV_ANY_IMP}.process_button_event */
void F1114_10073 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	
	RTGC;
}

/* {EV_ANY_IMP}.process_scroll_event */
EIF_BOOLEAN F1114_10075 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {EV_ANY_IMP}.visual_widget */
EIF_POINTER F1114_10076 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8064[dtype-1116])(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		RTLE;
		return (EIF_POINTER) (EIF_POINTER) gtk_bin_get_child((GtkBin*) tp1);
	} else {
		RTLE;
		return (EIF_POINTER) *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	}/* NOTREACHED */
	
}

/* {EV_ANY_IMP}.app_implementation */
static EIF_REFERENCE F1114_10077_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (10077);
#define Result RTOSR(10077)
	RTOC_NEW(Result);
	loc1 = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F982_8029(RTCW(loc1));
	RTCT0("attached {EV_APPLICATION_IMP} env.implementation.application_i as l_app_imp", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
	tr1 = F1101_9545(RTCW(tr1));
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1111, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc2;
	RTOSE (10077);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1114_10077 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10077,F1114_10077_body,(Current));
}

void EIF_Minit470 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
