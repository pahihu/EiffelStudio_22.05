/*
 * Code for class EV_COLOR_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev462.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_COLOR_IMP}.make */
void F1106_9631 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (RTOSCF(9627,F1105_9627, (Current)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	F1087_9359(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_COLOR_IMP}.red */
EIF_REAL_32 F1106_9632 (EIF_REFERENCE Current)
{
	return *(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_2_);
}


/* {EV_COLOR_IMP}.green */
EIF_REAL_32 F1106_9633 (EIF_REFERENCE Current)
{
	return *(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_1_);
}


/* {EV_COLOR_IMP}.blue */
EIF_REAL_32 F1106_9634 (EIF_REFERENCE Current)
{
	return *(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_0_);
}


/* {EV_COLOR_IMP}.name */
EIF_REFERENCE F1106_9635 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {EV_COLOR_IMP}.set_red */
void F1106_9636 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_2_) = (EIF_REAL_32) arg1;
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 65535L));
	tr1 = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = (EIF_REAL_32) (arg1 * tr4_1);
	ti4_1 = F888_7054(RTCW(tr1));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {EV_COLOR_IMP}.set_green */
void F1106_9637 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_1_) = (EIF_REAL_32) arg1;
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 65535L));
	tr1 = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = (EIF_REAL_32) (arg1 * tr4_1);
	ti4_1 = F888_7054(RTCW(tr1));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_1_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {EV_COLOR_IMP}.set_blue */
void F1106_9638 (EIF_REFERENCE Current, EIF_REAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_0_) = (EIF_REAL_32) arg1;
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 65535L));
	tr1 = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = (EIF_REAL_32) (arg1 * tr4_1);
	ti4_1 = F888_7054(RTCW(tr1));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {EV_COLOR_IMP}.rgb_24_bit */
EIF_INTEGER_32 F1106_9640 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F1106_9642(Current);
	ti4_1 = F1106_9643(Current);
	ti4_2 = F1106_9644(Current);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (Result * ((EIF_INTEGER_32) 65536L)) + (EIF_INTEGER_32) (ti4_1 * ((EIF_INTEGER_32) 256L))) + ti4_2);
	RTLE;
	return Result;
}

/* {EV_COLOR_IMP}.red_8_bit */
EIF_INTEGER_32 F1106_9642 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 255L));
	tr1 = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = (EIF_REAL_32) (*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_2_) * tr4_1);
	Result = F888_7054(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_COLOR_IMP}.green_8_bit */
EIF_INTEGER_32 F1106_9643 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 255L));
	tr1 = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = (EIF_REAL_32) (*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_1_) * tr4_1);
	Result = F888_7054(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_COLOR_IMP}.blue_8_bit */
EIF_INTEGER_32 F1106_9644 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 255L));
	tr1 = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = (EIF_REAL_32) (*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_0_) * tr4_1);
	Result = F888_7054(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_COLOR_IMP}.set_red_with_8_bit */
void F1106_9645 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	F1106_9651(Current, (EIF_INTEGER_32) (arg1 * ((EIF_INTEGER_32) 257L)));
}

/* {EV_COLOR_IMP}.set_green_with_8_bit */
void F1106_9646 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	F1106_9652(Current, (EIF_INTEGER_32) (arg1 * ((EIF_INTEGER_32) 257L)));
}

/* {EV_COLOR_IMP}.set_blue_with_8_bit */
void F1106_9647 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	F1106_9653(Current, (EIF_INTEGER_32) (arg1 * ((EIF_INTEGER_32) 257L)));
}

/* {EV_COLOR_IMP}.red_16_bit */
EIF_INTEGER_32 F1106_9648 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_);
}


/* {EV_COLOR_IMP}.green_16_bit */
EIF_INTEGER_32 F1106_9649 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_1_);
}


/* {EV_COLOR_IMP}.blue_16_bit */
EIF_INTEGER_32 F1106_9650 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_0_);
}


/* {EV_COLOR_IMP}.set_red_with_16_bit */
void F1106_9651 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REAL_32 tr4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) arg1;
	tr4_1 = (EIF_REAL_32) ((EIF_REAL_64) ((EIF_REAL_64) (arg1) /  (EIF_REAL_64) (((EIF_INTEGER_32) 65535L))));
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_2_) = (EIF_REAL_32) tr4_1;
	RTLE;
}

/* {EV_COLOR_IMP}.set_green_with_16_bit */
void F1106_9652 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REAL_32 tr4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_1_) = (EIF_INTEGER_32) arg1;
	tr4_1 = (EIF_REAL_32) ((EIF_REAL_64) ((EIF_REAL_64) (arg1) /  (EIF_REAL_64) (((EIF_INTEGER_32) 65535L))));
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_1_) = (EIF_REAL_32) tr4_1;
	RTLE;
}

/* {EV_COLOR_IMP}.set_blue_with_16_bit */
void F1106_9653 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REAL_32 tr4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) arg1;
	tr4_1 = (EIF_REAL_32) ((EIF_REAL_64) ((EIF_REAL_64) (arg1) /  (EIF_REAL_64) (((EIF_INTEGER_32) 65535L))));
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_0_) = (EIF_REAL_32) tr4_1;
	RTLE;
}

/* {EV_COLOR_IMP}.set_with_other */
void F1106_9654 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = RTRV(eif_new_type(1105, 0x00), loc1);
	RTCT0("imp_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_1_0_2_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_2_) = (EIF_INTEGER_32) ti4_1;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_1_0_1_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_1_) = (EIF_INTEGER_32) ti4_1;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_1_0_0_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_1_0_0_) = (EIF_INTEGER_32) ti4_1;
	tr4_1 = *(EIF_REAL_32 *)(RTCW(loc1)+ _R32OFF_2_1_0_3_2_);
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_2_) = (EIF_REAL_32) tr4_1;
	tr4_1 = *(EIF_REAL_32 *)(RTCW(loc1)+ _R32OFF_2_1_0_3_1_);
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_1_) = (EIF_REAL_32) tr4_1;
	tr4_1 = *(EIF_REAL_32 *)(RTCW(loc1)+ _R32OFF_2_1_0_3_0_);
	*(EIF_REAL_32 *)(Current+ _R32OFF_2_1_0_3_0_) = (EIF_REAL_32) tr4_1;
	RTLE;
}

/* {EV_COLOR_IMP}.delta */
EIF_REAL_32 F1106_9655 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REAL_32) (EIF_REAL_32) ((EIF_REAL_64) ((EIF_REAL_32) 1.0) /  (EIF_REAL_64) ((EIF_REAL_32) 255.0));
}

/* {EV_COLOR_IMP}.destroy */
void F1106_9656 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1087_9360(Current, (EIF_BOOLEAN) 1);
}

void EIF_Minit462 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
