/*
 * Code for class EV_ENVIRONMENT_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev458.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ENVIRONMENT_IMP}.make */
void F1102_9561 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1087_9359(Current, (EIF_BOOLEAN) 1);
}

void EIF_Minit458 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
