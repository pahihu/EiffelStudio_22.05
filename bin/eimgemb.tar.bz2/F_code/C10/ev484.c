/*
 * Code for class EV_DOCKABLE_SOURCE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev484.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DOCKABLE_SOURCE_IMP}.start_dragable_filter */
void F1132_10358 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_16 ti2_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O8307[dtype-1131])) {
		tr1 = *(EIF_REFERENCE *)(Current + O8098[dtype-1114]);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O8314[dtype-1131]) = (EIF_REFERENCE) tr1;
		ti2_1 = (EIF_INTEGER_16) arg2;
		*(EIF_INTEGER_16 *)(Current + O2640[dtype-116]) = (EIF_INTEGER_16) ti2_1;
		ti2_1 = (EIF_INTEGER_16) arg3;
		*(EIF_INTEGER_16 *)(Current + O2641[dtype-116]) = (EIF_INTEGER_16) ti2_1;
		ti2_1 = (EIF_INTEGER_16) arg8;
		*(EIF_INTEGER_16 *)(Current + O8308[dtype-1131]) = (EIF_INTEGER_16) ti2_1;
		ti2_1 = (EIF_INTEGER_16) arg9;
		*(EIF_INTEGER_16 *)(Current + O8309[dtype-1131]) = (EIF_INTEGER_16) ti2_1;
		*(EIF_BOOLEAN *)(Current + O8307[dtype-1131]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.dragable_motion */
void F1132_10362 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7)
{
	GTCX
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_INTEGER_16 ti2_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O8307[dtype-1131])) {
		tb1 = '\01';
		ti2_1 = *(EIF_INTEGER_16 *)(Current + O8308[dtype-1131]);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		ti4_1 = eif_abs_int32 ((EIF_INTEGER_32) (ti4_1 - arg6));
		if (!(EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 3L))) {
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O8309[dtype-1131]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			ti4_1 = eif_abs_int32 ((EIF_INTEGER_32) (ti4_1 - arg7));
			tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 3L));
		}
		if (tb1) {
			*(EIF_BOOLEAN *)(Current + O8307[dtype-1131]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			F1132_10366(Current, arg1, arg2, ((EIF_INTEGER_32) 1L), arg3, arg4, arg5, arg6, arg7);
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O2640[dtype-116]);
			ti4_1 = (EIF_INTEGER_32) ti2_1;
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O2641[dtype-116]);
			ti4_2 = (EIF_INTEGER_32) ti2_1;
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O2640[dtype-116]);
			ti4_3 = (EIF_INTEGER_32) ti2_1;
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O2641[dtype-116]);
			ti4_4 = (EIF_INTEGER_32) ti2_1;
			F1132_10367(Current, ti4_1, ti4_2, ((EIF_INTEGER_32) 1L), (EIF_REAL_64) 0.0, (EIF_REAL_64) 0.0, (EIF_REAL_64) 0.0, (EIF_INTEGER_32) (arg6 + (EIF_INTEGER_32) (ti4_3 - arg1)), (EIF_INTEGER_32) (arg7 + (EIF_INTEGER_32) (ti4_4 - arg2)));
		}
	} else {
		tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
		F1131_10352(Current, arg1, arg2, tr8_1, tr8_2, (EIF_REAL_64) 0.5, arg6, arg7);
	}
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.start_dragable */
void F1132_10366 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1162_10623(Current);
	tr1 = RTOSCF(10077,F1114_10077, (Current));
	F1112_9999(RTCW(tr1), Current);
	tr1 = F1087_9345(Current);
	F1131_10350(Current, arg7, arg8, tr1);
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.real_start_dragging */
void F1132_10367 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(10345,F1131_10345, (Current));
	F1115_10097(Current, tr1);
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.end_dragable */
void F1132_10369 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (F1131_10324(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + O8314[Dtype(Current)-1131]);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			F1115_10098(Current, loc1);
		} else {
			tr1 = RTOSCF(698,F32_698, (RTCV(RTOSCF(2652,F117_2652, (Current)))));
			F1115_10098(Current, tr1);
		}
		F1162_10624(Current);
		tr1 = RTOSCF(10077,F1114_10077, (Current));
		F1112_9999(RTCW(tr1), NULL);
		F1131_10343(Current);
	}
	F1132_10370(Current);
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.reset_drag_data */
void F1132_10370 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O8307[dtype-1131]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_INTEGER_16 *)(Current + O2640[dtype-116]) = (EIF_INTEGER_16) (EIF_INTEGER_16) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_16 *)(Current + O2641[dtype-116]) = (EIF_INTEGER_16) (EIF_INTEGER_16) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_16 *)(Current + O8308[dtype-1131]) = (EIF_INTEGER_16) (EIF_INTEGER_16) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_16 *)(Current + O8309[dtype-1131]) = (EIF_INTEGER_16) (EIF_INTEGER_16) ((EIF_INTEGER_32) -1L);
	*(EIF_REFERENCE *)(Current + O8314[dtype-1131]) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {EV_DOCKABLE_SOURCE_IMP}.update_buttons */
void F1132_10375 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	RTGC;
}

void EIF_Minit484 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
