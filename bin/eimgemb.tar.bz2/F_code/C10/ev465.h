
#ifndef _C10_ev465_
#define _C10_ev465_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1109_9752(EIF_REFERENCE);
extern void F1109_9753(EIF_REFERENCE);
extern EIF_REFERENCE F1109_9757(EIF_REFERENCE);
extern void EIF_Minit465(void);
extern EIF_REFERENCE F1087_9345(EIF_REFERENCE);
extern void F709_5240(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
