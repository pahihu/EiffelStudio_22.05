/*
 * Code for class EV_POINTER_STYLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev455.h"
#include <ev_gtk.h>
#include "ev_c_util.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F17_359
static EIF_INTEGER_32 inline_F17_359 (void)
{
	return gdk_display_get_default_cursor_size ((GdkDisplay*) gdk_display_get_default());
	;
}
#define INLINE_F17_359
#endif
#ifndef INLINE_F80_1393
static EIF_INTEGER_32 inline_F80_1393 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_width ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F80_1393
#endif
#ifndef INLINE_F80_1394
static EIF_INTEGER_32 inline_F80_1394 (EIF_POINTER arg1)
{
	return gdk_pixbuf_get_height ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F80_1394
#endif
#ifndef INLINE_F80_1239
static EIF_POINTER inline_F80_1239 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (g_object_ref((gpointer) arg1))
	;
}
#define INLINE_F80_1239
#endif
#ifndef INLINE_F80_1240
static void inline_F80_1240 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F80_1240
#endif
#ifndef INLINE_F80_1400
static EIF_POINTER inline_F80_1400 (EIF_POINTER arg1)
{
	return gdk_pixbuf_new_from_xpm_data ((const char**) arg1);
	;
}
#define INLINE_F80_1400
#endif
#ifndef INLINE_F80_1233
static int inline_F80_1233 (EIF_POINTER arg1)
{
	return (int) (GDK_IS_PIXBUF(arg1))
	;
}
#define INLINE_F80_1233
#endif
#ifndef INLINE_F80_1392
static EIF_POINTER inline_F80_1392 (EIF_POINTER arg1)
{
	return gdk_pixbuf_copy ((GdkPixbuf*)arg1);
	;
}
#define INLINE_F80_1392
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_POINTER_STYLE_IMP}.make */
void F1099_9519 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1087_9359(Current, (EIF_BOOLEAN) 1);
}

/* {EV_POINTER_STYLE_IMP}.init_predefined */
void F1099_9521 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) arg1;
	switch (arg1) {
		case 3L:
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 15L);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 15L);
			break;
		case 5L:
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
			break;
		case 6L:
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
			break;
		case 7L:
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
			break;
		case 8L:
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
			break;
		case 9L:
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
			break;
		case 10L:
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
			break;
		case 11L:
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
			break;
		case 12L:
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
			break;
		case 1L:
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
			break;
		case 14L:
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
			break;
		default:
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			break;
	}
	F1099_9523(Current, loc1);
	F1099_9524(Current, loc2);
	RTLE;
}

/* {EV_POINTER_STYLE_IMP}.set_x_hotspot */
void F1099_9523 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) arg1;
}

/* {EV_POINTER_STYLE_IMP}.set_y_hotspot */
void F1099_9524 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_1_) = (EIF_INTEGER_32) arg1;
}

/* {EV_POINTER_STYLE_IMP}.destroy */
void F1099_9525 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1087_9361(Current, (EIF_BOOLEAN) 1);
	tp1 = F1_33(Current);
	F1099_9534(Current, tp1);
	F1087_9360(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_POINTER_STYLE_IMP}.width */
EIF_INTEGER_32 F1099_9526 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_1_1_0_3_0_0_) == F1_33(Current))) {
		ti4_1 = inline_F17_359();
	} else {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_3_0_0_);
		ti4_1 = inline_F80_1393(tp1);
	}
	Result = (EIF_INTEGER_32) ti4_1;
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE_IMP}.height */
EIF_INTEGER_32 F1099_9527 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_1_1_0_3_0_0_) == F1_33(Current))) {
		ti4_1 = inline_F17_359();
	} else {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_3_0_0_);
		ti4_1 = inline_F80_1394(tp1);
	}
	Result = (EIF_INTEGER_32) ti4_1;
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE_IMP}.x_hotspot */
EIF_INTEGER_32 F1099_9528 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
}


/* {EV_POINTER_STYLE_IMP}.y_hotspot */
EIF_INTEGER_32 F1099_9529 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_1_);
}


/* {EV_POINTER_STYLE_IMP}.gdk_cursor_from_pointer_style */
EIF_POINTER F1099_9531 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (EIF_POINTER) gdk_display_get_default();
	RTLE;
	return (EIF_POINTER) F1099_9532(Current, loc1);
}

/* {EV_POINTER_STYLE_IMP}.gdk_cursor_from_pointer_style_for_display */
EIF_POINTER F1099_9532 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_)) {
		case 1L:
			ti4_1 = (EIF_INTEGER_32) GDK_WATCH;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 2L:
			ti4_1 = (EIF_INTEGER_32) GDK_LEFT_PTR;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 3L:
			ti4_1 = (EIF_INTEGER_32) GDK_CROSSHAIR;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 5L:
			ti4_1 = (EIF_INTEGER_32) GDK_XTERM;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 7L:
			ti4_1 = (EIF_INTEGER_32) GDK_FLEUR;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 8L:
			ti4_1 = (EIF_INTEGER_32) GDK_SB_V_DOUBLE_ARROW;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 13L:
			ti4_1 = (EIF_INTEGER_32) GDK_WATCH;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 4L:
			ti4_1 = (EIF_INTEGER_32) GDK_QUESTION_ARROW;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 15L:
			ti4_1 = (EIF_INTEGER_32) GDK_HAND2;
			Result = (EIF_POINTER) gdk_cursor_new_for_display((GdkDisplay *) arg1, (GdkCursorType) ti4_1);
			break;
		case 6L:
			tp1 = (EIF_POINTER) no_cursor_xpm();
			loc1 = F1099_9533(Current, tp1);
			break;
		case 9L:
			tp1 = (EIF_POINTER) sizenwse_cursor_xpm();
			loc1 = F1099_9533(Current, tp1);
			break;
		case 10L:
			tp1 = (EIF_POINTER) sizenesw_cursor_xpm();
			loc1 = F1099_9533(Current, tp1);
			break;
		case 11L:
			tp1 = (EIF_POINTER) sizewe_cursor_xpm();
			loc1 = F1099_9533(Current, tp1);
			break;
		case 12L:
			tp1 = (EIF_POINTER) uparrow_cursor_xpm();
			loc1 = F1099_9533(Current, tp1);
			break;
		case 14L:
			tp1 = (EIF_POINTER) sizewe_cursor_xpm();
			loc1 = F1099_9533(Current, tp1);
			break;
		default:
			loc1 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_3_0_0_);
			tp1 = inline_F80_1239(loc1);
			loc1 = (EIF_POINTER) tp1;
			break;
	}
	tb1 = '\0';
	if ((EIF_BOOLEAN)(Result == F1_33(Current))) {
		tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) != ((EIF_INTEGER_32) 2L));
	}
	if (tb1) {
		
		tp1 = (EIF_POINTER) gdk_display_get_default();
		ti4_1 = F988_8125(RTCV(F1087_9345(Current)));
		ti4_2 = F988_8126(RTCV(F1087_9345(Current)));
		Result = (EIF_POINTER) gdk_cursor_new_from_pixbuf((GdkDisplay*) tp1, (GdkPixbuf*) loc1, (gint) ti4_1, (gint) ti4_2);
		inline_F80_1240(loc1);
	}
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE_IMP}.image_from_xpm_data */
EIF_POINTER F1099_9533 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	return (EIF_POINTER) inline_F80_1400(arg1);
}

/* {EV_POINTER_STYLE_IMP}.set_gdkpixbuf */
void F1099_9534 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_1_1_0_3_0_0_) != F1_33(Current))) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_3_0_0_);
		inline_F80_1240(tp1);
	}
	*(EIF_POINTER *)(Current+ _PTROFF_1_1_0_3_0_0_) = (EIF_POINTER) arg1;
	RTLE;
}

/* {EV_POINTER_STYLE_IMP}.copy_from_pointer_style */
void F1099_9536 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(Dftype(Current), 0),loc1);
	if (EIF_TEST(loc1)) {
		tp1 = *(EIF_POINTER *)(loc1+ _PTROFF_1_1_0_3_0_0_);
		if ((EIF_BOOLEAN)(tp1 != F1_33(Current))) {
			tp1 = *(EIF_POINTER *)(loc1+ _PTROFF_1_1_0_3_0_0_);
			if ((EIF_BOOLEAN) !EIF_TEST (inline_F80_1233(tp1))) {
			}
			tp1 = *(EIF_POINTER *)(loc1+ _PTROFF_1_1_0_3_0_0_);
			tp1 = inline_F80_1392(tp1);
			F1099_9534(Current, tp1);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(loc1+ _LNGOFF_1_1_0_0_);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ti4_1;
	} else {
		
	}
	RTLE;
}

/* {EV_POINTER_STYLE_IMP}.dispose */
void F1099_9538 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1_33(Current);
	F1099_9534(Current, tp1);
	RTLE;
}

void EIF_Minit455 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
