/*
 * Code for class EV_APPLICATION_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev468.h"
#include <stdlib.h>
#include <ev_any_imp.h>
#include <ev_gtk.h>
#include "eif_built_in.h"
#include <string.h>
#include <gmodule.h>
#include "eif_argv.h"
#include "eif_except.h"
#include "eif_helpers.h"
#include "eif_main.h"
#include "eif_misc.h"
#include "ev_c_util.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F80_1212
static void inline_F80_1212 (EIF_POINTER arg1)
{
	return gdk_set_allowed_backends ( (const gchar*) arg1);
	;
}
#define INLINE_F80_1212
#endif
#ifndef INLINE_F76_1153
static int inline_F76_1153 (void)
{
	#ifdef WORKBENCH
	return EIF_TEST(is_debug_mode());
#else
	return EIF_FALSE;
#endif
	;
}
#define INLINE_F76_1153
#endif
#ifndef INLINE_F80_1249
static EIF_POINTER inline_F80_1249 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gdk_display_get_default_screen ((GdkDisplay*) arg1))
	;
}
#define INLINE_F80_1249
#endif
#ifndef INLINE_F80_1408
static EIF_POINTER inline_F80_1408 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gdk_screen_get_system_visual ((GdkScreen*) arg1))
	;
}
#define INLINE_F80_1408
#endif
#ifndef INLINE_F80_1306
static EIF_INTEGER_32 inline_F80_1306 (EIF_POINTER arg1)
{
	return (EIF_INTEGER_32) (gdk_visual_get_depth ((GdkVisual*) arg1))
	;
}
#define INLINE_F80_1306
#endif
#ifndef INLINE_F79_1160
static void inline_F79_1160 (EIF_POINTER arg1)
{
	#ifdef GDK_WINDOWING_X11
	return gdk_x11_display_error_trap_push ((GdkDisplay *)arg1);
#endif
	;
}
#define INLINE_F79_1160
#endif
#ifndef INLINE_F80_1411
static EIF_POINTER inline_F80_1411 (void)
{
	return gdk_screen_get_default()
	;
}
#define INLINE_F80_1411
#endif
#ifndef INLINE_F1112_9904
static int inline_F1112_9904 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	return (FUNCTION_CAST(gboolean, (GdkScreen*)) arg1)((GdkScreen*) arg2);
	;
}
#define INLINE_F1112_9904
#endif
#ifndef INLINE_F80_1251
static EIF_INTEGER_32 inline_F80_1251 (EIF_POINTER arg1)
{
	return gdk_display_get_n_monitors ((GdkDisplay*) arg1)
	;
}
#define INLINE_F80_1251
#endif
#ifndef INLINE_F80_1257
static void inline_F80_1257 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gdk_monitor_get_geometry ((GdkMonitor*) arg1, (GdkRectangle*) arg2)
	;
}
#define INLINE_F80_1257
#endif
#ifndef INLINE_F1112_10041
static void inline_F1112_10041 (EIF_POINTER arg1)
{
	{
				  GdkDisplay *display = gdk_display_get_default ();
				  int num_monitors = gdk_display_get_n_monitors (display);

				  gint x, y, w, h;

				  x = y = G_MAXINT;
				  w = h = G_MININT;

				  for (int i = 0; i < num_monitors; i++)
				    {
				      GdkRectangle rect;
				      GdkMonitor *monitor = gdk_display_get_monitor (display, i);
				      gdk_monitor_get_geometry (monitor, &rect);

				      x = MIN (x, rect.x);
				      y = MIN (y, rect.y);
				      w = MAX (w, rect.x + rect.width);
				      h = MAX (h, rect.y + rect.height);
				    }

				  ((GdkRectangle *)arg1)->width = w - x;
				  ((GdkRectangle *)arg1)->height = h - y;
				}
	;
}
#define INLINE_F1112_10041
#endif
#ifndef INLINE_F80_1240
static void inline_F80_1240 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F80_1240
#endif
#ifndef INLINE_F17_357
static EIF_POINTER inline_F17_357 (void)
{
	return (GdkDevice*) gdk_seat_get_pointer((GdkSeat*) gdk_display_get_default_seat ((GdkDisplay*) gdk_display_get_default()));
	;
}
#define INLINE_F17_357
#endif
#ifndef INLINE_F17_354
static void inline_F17_354 (EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	return gdk_device_get_position ((GdkDevice*) arg1, NULL, (gint*) arg2, (gint*) arg3);
	;
}
#define INLINE_F17_354
#endif
#ifndef INLINE_F76_1152
static void inline_F76_1152 (EIF_BOOLEAN arg1)
{
	#ifdef WORKBENCH
	set_debug_mode (arg1 ? 1 : 0);
#endif
	;
}
#define INLINE_F76_1152
#endif
#ifndef INLINE_F1114_10054
static EIF_REFERENCE inline_F1114_10054 (EIF_POINTER arg1)
{
	return (EIF_REFERENCE) (c_ev_any_imp_get_eif_reference_from_object_id (arg1))
	;
}
#define INLINE_F1114_10054
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_APPLICATION_IMP}.make */
void F1112_9898 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_REFERENCE tr6 = NULL;
	EIF_REFERENCE tr7 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLR(6,tr6);
	RTLR(7,tr7);
	RTLIU(8);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(82, 0x00).id, 82, _OBJSIZ_0_0_0_0_0_0_0_0_);
	if (RTOSCF(1975,F83_1975, (RTCW(tr1)))) {
		tr1 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
		tr2 = RTMS_EX_H("x11",3,7876913);
		F818_5410(RTCW(tr1), tr2);
		tp1 = *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_0_1_0_1_0_0_);
		inline_F80_1212(tp1);
	}
	tr1 = RTMS_EX_H("0",1,48);
	tr2 = RTMS_EX_H("LIBOVERLAY_SCROLLBAR",20,1673493842);
	F238_3960(Current, tr1, tr2);
	tr1 = RTLNSMART(eif_new_type(953, 0).id);
	F952_7748(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_47_) = (EIF_REFERENCE) tr1;
	tb1 = (EIF_BOOLEAN) EIF_TEST(gtk_init_check (&eif_argc, &eif_argv));
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_11_) = (EIF_BOOLEAN) tb1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,865,937,868,868,880,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_48_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(831, 0).id);
	F832_6103(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_42_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {565,868,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F566_4505(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_43_) = (EIF_REFERENCE) tr1;
	tr1 = F945_7511(RTMS_EX_H("",0,0));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_22_) = (EIF_REFERENCE) tr1;
	F1111_9793(Current);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_11_)) {
		F1112_10035(Current);
		tb1 = EIF_TEST (inline_F76_1153());
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_12_) = (EIF_BOOLEAN) tb1;
		enable_ev_gtk_log((EIF_INTEGER) ((EIF_INTEGER_32) 0L));
		gdk_set_show_events((gboolean) (EIF_BOOLEAN) 0);
		tp1 = (EIF_POINTER) gdk_display_get_default();
		tp1 = inline_F80_1249(tp1);
		tp1 = inline_F80_1408(tp1);
		ti4_1 = inline_F80_1306(tp1);
		ti4_1 = eif_min_int32 (ti4_1,((EIF_INTEGER_32) 24L));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_18_) = (EIF_INTEGER_32) ti4_1;
		F828_6025(Current);
		F1112_9998(Current, ((EIF_INTEGER_32) 500L));
		if (RTOSCF(9905,F1112_9905, (Current))) {
			tp1 = (EIF_POINTER) gdk_display_get_default();
			inline_F79_1160(tp1);
		}
		F1112_9900(Current);
		tp1 = (EIF_POINTER) gtk_im_context_simple_new();
		*(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_3_) = (EIF_POINTER) tp1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_42_);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_3_);
		tr2 = RTLNS(eif_new_type(15, 0x00).id, 15, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr3 = RTOSCF(352,F16_352, (RTCW(tr2)));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,0,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr4 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr4+1)->it_r = Current;
		RTAR(tr4,Current);
		
		{
			static EIF_TYPE_INDEX typarr0[] = {942,0xFFF9,1,865,937,937,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr7= RTLNRF(typres0.id, (EIF_POINTER) __A468_425_2, (EIF_POINTER) _A468_425_2, (EIF_POINTER)(F1112_9899),tr4, 1, 1);
		}
		F832_6107(RTCW(tr1), tp1, tr3, tr7);
	} else {
		tr1 = RTMS_EX_H("EiffelVision application could not launch, check DISPLAY environment variable\012",78,1906588938);
		F1_27(Current, tr1);
		esdie(((EIF_INTEGER_32) 0L));
	}
	RTLE;
}

/* {EV_APPLICATION_IMP}.on_char_event */
EIF_POINTER F1112_9899 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_POINTER) g_value_peek_pointer((GValue*) arg1);
	if ((EIF_BOOLEAN)(loc1 != F1_33(Current))) {
		tr1 = RTOSCF(10033,F1112_10033, (Current));
		F818_5412(RTCW(tr1), loc1);
	} else {
		tr1 = RTOSCF(10033,F1112_10033, (Current));
		tr2 = RTMS_EX_H("",0,0);
		F818_5410(RTCW(tr1), tr2);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_47_);
	F954_7892(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_47_);
	tr2 = F818_5408(RTCV(RTOSCF(10033,F1112_10033, (Current))));
	F954_7863(RTCW(tr1), tr2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_3_);
	gtk_im_context_reset((GtkIMContext*) tp1);
	RTLE;
	return (EIF_POINTER) 0;
}

/* {EV_APPLICATION_IMP}.update_screen_meta_data */
void F1112_9900 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_13_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	loc2 = RTOSCF(9903,F1112_9903, (Current));
	if ((EIF_BOOLEAN)(loc2 != F1_33(Current))) {
		tp1 = inline_F80_1411();
		tb1 = EIF_TEST (inline_F1112_9904(loc2, tp1));
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_7_) = (EIF_BOOLEAN) tb1;
	}
	tp1 = (EIF_POINTER) gdk_display_get_default();
	ti4_1 = inline_F80_1251(tp1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_17_) = (EIF_INTEGER_32) ti4_1;
	loc1 = RTOSCF(10031,F1112_10031, (Current));
	tp1 = (EIF_POINTER) gdk_display_get_default();
	tp1 = (EIF_POINTER) gdk_display_get_primary_monitor((GdkDisplay*) tp1);
	*(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_1_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_1_);
	inline_F80_1257(tp1, loc1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_11_) = (EIF_INTEGER_32) (EIF_INTEGER_32) -(EIF_INTEGER_32) (((GdkRectangle *)loc1)->x);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_12_) = (EIF_INTEGER_32) (EIF_INTEGER_32) -(EIF_INTEGER_32) (((GdkRectangle *)loc1)->y);
	ti4_1 = (EIF_INTEGER_32) (((GdkRectangle *)loc1)->width);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_15_) = (EIF_INTEGER_32) ti4_1;
	ti4_1 = (EIF_INTEGER_32) (((GdkRectangle *)loc1)->height);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_16_) = (EIF_INTEGER_32) ti4_1;
	loc3 = (EIF_POINTER) calloc (sizeof(GdkRectangle), 1);
	inline_F1112_10041(loc3);
	ti4_1 = (EIF_INTEGER_32) (((GdkRectangle *)loc3)->width);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_13_) = (EIF_INTEGER_32) ti4_1;
	ti4_1 = (EIF_INTEGER_32) (((GdkRectangle *)loc3)->height);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_14_) = (EIF_INTEGER_32) ti4_1;
	free(loc3);
	RTLE;
}

/* {EV_APPLICATION_IMP}.gdk_screen_is_composited_symbol */
static EIF_POINTER F1112_9903_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9903);
#define Result RTOSR(9903)
	tr1 = RTMS_EX_H("gdk_screen_is_composited",24,1829865316);
	Result = F1112_9929(Current, tr1);
	RTOSE (9903);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_POINTER F1112_9903 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9903,F1112_9903_body,(Current));
}

/* {EV_APPLICATION_IMP}.gdk_screen_is_composited_call */
EIF_BOOLEAN F1112_9904 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = EIF_TEST(inline_F1112_9904 ((EIF_POINTER) arg1, (EIF_POINTER) arg2));
	return Result;
}

/* {EV_APPLICATION_IMP}.is_x11_session */
static EIF_BOOLEAN F1112_9905_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	

	
	RTEV;
	RTOSP (9905);
#define Result RTOSR(9905)
	tr1 = RTLNS(eif_new_type(82, 0x00).id, 82, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = RTOSCF(1974,F83_1974, (RTCW(tr1)));
	RTOSE (9905);
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F1112_9905 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9905,F1112_9905_body,(Current));
}

/* {EV_APPLICATION_IMP}.has_x11_support */
RTEOMS(9905,1);
static EIF_BOOLEAN F1112_9906_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (9906);
#define Result RTOSR(9906)
	Result = RTOSCF(9905,F1112_9905, (Current));
	if (Result) {
		if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_mac__b) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			tr1 = RTLNS(eif_new_type(237, 0x00).id, 237, _OBJSIZ_0_0_0_1_0_0_0_0_);
			tr2 = F238_3947(RTCW(tr1), RTOMS(9905,0));
			loc1 = tr2;
			if (EIF_TEST(loc1)) {
				tr1 = RTMS_EX_H("no",2,28271);
				Result = F945_7494(loc1, tr1);
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
			}
		}
	}
	RTOSE (9906);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F1112_9906 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9906,F1112_9906_body,(Current));
}

/* {EV_APPLICATION_IMP}.call_post_launch_actions */
void F1112_9907 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_11_)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_3_);
		tp2 = F1112_10027(Current);
		gtk_im_context_set_client_window((GtkIMContext*) tp1, (GdkWindow*) tp2);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_3_);
		gtk_im_context_focus_in((GtkIMContext*) tp1);
	}
	F1111_9875(Current);
	RTLE;
}

/* {EV_APPLICATION_IMP}.is_display_remote */
EIF_BOOLEAN F1112_9919 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current+ _CHROFF_49_13_);
}


/* {EV_APPLICATION_IMP}.set_currently_shown_control */
void F1112_9920 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_41_) = (EIF_REFERENCE) arg1;
}

/* {EV_APPLICATION_IMP}.focused_widget */
EIF_REFERENCE F1112_9922 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc5);
	RTLR(6,loc6);
	RTLR(7,Result);
	RTLIU(8);
	
	RTGC;
	loc1 = F1112_9936(Current);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R3860[Dtype(RTCW(loc1))-564])(loc1);
	loc4 = (EIF_REFERENCE) tr1;
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4619[Dtype(loc4)-708])(loc4);
		if (tb1) break;
		if ((EIF_BOOLEAN)(Result != NULL)) break;
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4618[Dtype(loc4)-708])(loc4);
		tb2 = F1027_8665(RTCW(loc2));
		if (tb2) {
			tb2 = F1035_8776(RTCW(loc2));
			if (tb2) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_3_);
				loc5 = tr1;
				loc5 = RTRV(eif_new_type(1190, 0x00),loc5);
				if (EIF_TEST(loc5)) {
					tp1 = *(EIF_POINTER *)(loc5 + O8051[Dtype(loc5)-1113]);
					loc3 = (EIF_POINTER) gtk_window_get_focus((GtkWindow*) tp1);
					tb2 = !loc3;
					if ((EIF_BOOLEAN) !tb2) {
						tr1 = F1112_10022(Current, loc3);
						loc6 = tr1;
						loc6 = RTRV(eif_new_type(1163, 0x00),loc6);
						if (EIF_TEST(loc6)) {
							Result = *(EIF_REFERENCE *)(loc6 + O7519[Dtype(loc6)-1086]);
						}
					}
				} else {
					
				}
			} else {
				Result = (EIF_REFERENCE) loc2;
			}
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4620[Dtype(loc4)-708])(loc4);
	}
	RTLE;
	return Result;
}

/* {EV_APPLICATION_IMP}.wait_for_input */
void F1112_9923 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	F1112_9995(Current, arg1);
}

/* {EV_APPLICATION_IMP}.print_debug_event */
void F1112_9924 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2, EIF_POINTER arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	
	
	RTGC;
}

/* {EV_APPLICATION_IMP}.process_underlying_toolkit_event_queue */
RTEOMS(9924,2);
void F1112_9925 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_POINTER loc13 = (EIF_POINTER) 0;
	EIF_POINTER loc14 = (EIF_POINTER) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc17 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc18 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc19 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc20 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc21 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc22 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc23 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc24 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc25 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc26 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc27 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc28 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc29 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc30 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc31 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc32 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc33 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc34 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc35 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc36 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc37 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc38 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc39 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc40 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc41 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_INTEGER_8 ti1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(24);
	RTLR(0,loc15);
	RTLR(1,Current);
	RTLR(2,loc16);
	RTLR(3,loc30);
	RTLR(4,tr1);
	RTLR(5,loc31);
	RTLR(6,loc32);
	RTLR(7,loc8);
	RTLR(8,loc10);
	RTLR(9,loc9);
	RTLR(10,tr2);
	RTLR(11,loc33);
	RTLR(12,tr3);
	RTLR(13,loc34);
	RTLR(14,loc12);
	RTLR(15,loc11);
	RTLR(16,loc35);
	RTLR(17,loc36);
	RTLR(18,loc37);
	RTLR(19,loc38);
	RTLR(20,loc39);
	RTLR(21,loc40);
	RTLR(22,loc25);
	RTLR(23,loc41);
	RTLIU(24);
	
	RTGC;
	loc15 = RTOSCF(9940,F1112_9940, (Current));
	loc16 = RTOSCF(9941,F1112_9941, (Current));
	for (;;) {
		tb1 = '\01';
		if (!loc17) {
			tb1 = F1087_9344(Current);
		}
		if (tb1) break;
		loc1 = (EIF_POINTER) gdk_event_get();
		tb2 = !loc1;
		if ((EIF_BOOLEAN) !tb2) {
			loc3 = (EIF_POINTER) gtk_get_event_widget((GdkEvent*) loc1);
			ti1_1 = (EIF_INTEGER_8) (((GdkEventAny *)loc1)->send_event);
			loc29 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti1_1 != (EIF_INTEGER_8) ((EIF_INTEGER_32) 0L));
			loc27 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			loc4 = (EIF_POINTER) gtk_grab_get_current();
			tb2 = !loc4;
			if (tb2) {
				loc24 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				loc4 = (EIF_POINTER) loc3;
			} else {
				loc24 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				tb2 = '\0';
				tr1 = F1112_10007(Current);
				loc30 = tr1;
				if (EIF_TEST(loc30)) {
					tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8107[Dtype(loc30)-1116])(loc30);
					tb2 = (EIF_BOOLEAN) !tb3;
				}
				if (tb2) {
					tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
					tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
					tr8_3 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
					F1162_10642(loc30, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), tr8_1, tr8_2, tr8_3, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
				} else {
					tb2 = '\0';
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
					loc31 = tr1;
					if (EIF_TEST(loc31)) {
						tb3 = F1027_8664(loc31);
						tb2 = (EIF_BOOLEAN) !tb3;
					}
					if (tb2) {
						F1027_8671(loc31);
					}
				}
			}
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_8) (((GdkEventAny *)loc1)->type);
			switch (loc2) {
				case 3L:
					loc28 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					*(EIF_BOOLEAN *)(Current+ _CHROFF_49_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->x);
					loc19 = (EIF_INTEGER_32) tr8_1;
					tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->y);
					loc20 = (EIF_INTEGER_32) tr8_1;
					tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->x_root);
					loc21 = (EIF_INTEGER_32) tr8_1;
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_11_);
					loc21 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc21 + ti4_1);
					tr8_1 = (EIF_REAL_64) (((GdkEventMotion *)loc1)->y_root);
					loc22 = (EIF_INTEGER_32) tr8_1;
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_12_);
					loc22 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc22 + ti4_1);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
					tp1 = (EIF_POINTER) (((GdkEventMotion *)loc1)->window);
					
					eif_put_pointer_item(RTCW(tr1),1,tp1);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
					
					eif_put_integer_32_item(RTCW(tr1),2,loc21);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
					
					eif_put_integer_32_item(RTCW(tr1),3,loc22);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
					tu4_1 = (EIF_NATURAL_32) (((GdkEventMotion *)loc1)->state);
					
					eif_put_natural_32_item(RTCW(tr1),4,tu4_1);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
					loc32 = tr1;
					if (EIF_TEST(loc32)) {
						loc8 = *(EIF_REFERENCE *)(loc32 + _REFACS_3_);
						loc8 = RTRV(eif_new_type(1161, 0x00), loc8);
					} else {
						if ((EIF_BOOLEAN)(F1112_10007(Current) != NULL)) {
							loc8 = F1112_10007(Current);
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
							tp2 = eif_pointer_item(RTCW(tr1),1);
							loc8 = F1112_10024(Current, tp2);
							loc8 = RTRV(eif_new_type(1161, 0x00), loc8);
						}
					}
					tb2 = '\0';
					if ((EIF_BOOLEAN)(loc8 != NULL)) {
						tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8107[Dtype(RTCW(loc8))-1116])(loc8);
						tb2 = tb3;
					}
					if (tb2) {
						loc10 = F1115_10111(RTCW(loc8));
						if ((EIF_BOOLEAN)(loc10 != NULL)) {
							tb2 = F1191_11126(RTCW(loc10));
							if ((EIF_BOOLEAN) !tb2) {
								gtk_main_do_event((GdkEvent*) loc1);
								if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_9_) != NULL)) {
									loc9 = loc8;
									loc9 = RTRV(eif_new_type(1163, 0x00), loc9);
									if ((EIF_BOOLEAN)(loc9 != NULL)) {
										tr1 = F1087_9345(RTCW(loc9));
										
										eif_put_reference_item(RTCW(loc16),1,tr1);
										
										eif_put_integer_32_item(RTCW(loc16),2,loc21);
										
										eif_put_integer_32_item(RTCW(loc16),3,loc22);
										tr2 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
										(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4354[Dtype(RTCW(tr2))-601])(tr2, loc16);
										tr2 = RTOSCF(10029,F1112_10029, (Current));
										
										eif_put_reference_item(RTCW(loc16),1,tr2);
									}
								}
								tp2 = *(EIF_POINTER *)(RTCW(loc8) + O8051[Dtype(loc8)-1113]);
								ti4_1 = (EIF_INTEGER_32) gtk_widget_get_state_flags((GtkWidget*) tp2);
								ti4_2 = (EIF_INTEGER_32) GTK_STATE_FLAG_INSENSITIVE;
								ti4_1 = eif_bit_and(ti4_1,ti4_2);
								if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
									tp2 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8075[Dtype(RTCW(loc8))-1116])(loc8);
									if ((EIF_BOOLEAN)((EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp2) != (EIF_POINTER) (((GdkEventMotion *)loc1)->window))) {
										tp2 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8075[Dtype(RTCW(loc8))-1116])(loc8);
										gtk_widget_realize((GtkWidget*) tp2);
										tp2 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8075[Dtype(RTCW(loc8))-1116])(loc8);
										tp2 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp2);
										loc18 = (EIF_INTEGER_32) gdk_window_get_origin((GdkWindow*) tp2, (gint*) (EIF_INTEGER_32 *) &(loc19), (gint*) (EIF_INTEGER_32 *) &(loc20));
										loc19 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc21 - loc19);
										loc20 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc22 - loc20);
									}
									
									eif_put_integer_32_item(RTCW(loc15),1,loc19);
									
									eif_put_integer_32_item(RTCW(loc15),2,loc20);
									
									eif_put_real_64_item(RTCW(loc15),3,(EIF_REAL_64) 0.5);
									
									eif_put_real_64_item(RTCW(loc15),4,(EIF_REAL_64) 0.5);
									
									eif_put_real_64_item(RTCW(loc15),5,(EIF_REAL_64) 0.5);
									
									eif_put_integer_32_item(RTCW(loc15),6,loc21);
									
									eif_put_integer_32_item(RTCW(loc15),7,loc22);
									F1162_10620(RTCW(loc8), loc15);
								}
							}
						} else {
							gtk_main_do_event((GdkEvent*) loc1);
						}
					} else {
						gtk_main_do_event((GdkEvent*) loc1);
					}
					loc9 = (EIF_REFERENCE) NULL;
					loc8 = (EIF_REFERENCE) NULL;
					*(EIF_BOOLEAN *)(Current+ _CHROFF_49_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					if ((EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkEventMotion *)loc1)->is_hint) != ((EIF_INTEGER_32) 0L))) {
						F1112_10013(Current);
					}
					break;
				case 4L:
				case 5L:
				case 6L:
				case 7L:
					loc28 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					F1112_9942(Current, loc1, (EIF_BOOLEAN) 0);
					break;
				case 31L:
					if ((EIF_BOOLEAN) !F1112_10006(Current)) {
						tr3 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
						loc33 = tr3;
						if (EIF_TEST(loc33)) {
							tr8_1 = (EIF_REAL_64) (((GdkEventScroll *)loc1)->x_root);
							ti4_1 = (EIF_INTEGER_32) tr8_1;
							tr8_1 = (EIF_REAL_64) (((GdkEventScroll *)loc1)->y_root);
							ti4_2 = (EIF_INTEGER_32) tr8_1;
							(RTNA((loc33, (EIF_INTEGER_32) GDK_BUTTON_PRESS, ((EIF_INTEGER_32) 2L), (EIF_INTEGER_32) (ti4_1 + *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_11_)), (EIF_INTEGER_32) (ti4_2 + *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_12_)))));
						}
						tp2 = eif_pointer_item(RTCV(F1112_10012(Current)),1);
						if ((EIF_BOOLEAN)(tp2 != F1_33(Current))) {
							tr3 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
							tp2 = eif_pointer_item(RTCW(tr3),1);
							loc9 = F1112_10024(Current, tp2);
							loc9 = RTRV(eif_new_type(1163, 0x00), loc9);
						} else {
							loc9 = (EIF_REFERENCE) NULL;
						}
						if ((EIF_BOOLEAN)(loc9 == NULL)) {
							loc9 = F1112_10022(Current, loc3);
							loc9 = RTRV(eif_new_type(1163, 0x00), loc9);
						}
						if ((EIF_BOOLEAN)(loc9 != NULL)) {
							if ((EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkEventScroll *)loc1)->direction) == (EIF_INTEGER_32) GDK_SCROLL_UP)) {
								loc23 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
							} else {
								loc23 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
							}
							ti4_1 = (EIF_INTEGER_32) GDK_BUTTON_PRESS;
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32)) R8489[Dtype(RTCW(loc9))-1176])(loc9, ti4_1, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc23, (EIF_REAL_64) 0.5, (EIF_REAL_64) 0.5, (EIF_REAL_64) 0.5, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
						}
						loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					}
					loc28 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					break;
				case 20L:
				case 21L:
					break;
				case 16L:
					break;
				case 2L:
					break;
				case 30L:
					break;
				case 12L:
					loc10 = F1112_10022(Current, loc3);
					loc10 = RTRV(eif_new_type(1190, 0x00), loc10);
					if ((EIF_BOOLEAN)(loc10 != NULL)) {
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						gtk_main_do_event((GdkEvent*) loc1);
						ti1_1 = (EIF_INTEGER_8) (((GdkEventFocus *)loc1)->in);
						tr3 = RTLNS(eif_new_type(874, 0x00).id, 874, _OBJSIZ_0_1_0_0_0_0_0_0_);
						*(EIF_INTEGER_8 *)tr3 = ti1_1;
						tb2 = F873_6579(RTCW(tr3));
						F1191_11138(RTCW(loc10), tb2);
						loc10 = (EIF_REFERENCE) NULL;
					}
					break;
				case 13L:
					tr3 = F1112_10022(Current, loc3);
					loc34 = tr3;
					loc34 = RTRV(eif_new_type(1115, 0x00),loc34);
					if (EIF_TEST(loc34)) {
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						gtk_main_do_event((GdkEvent*) loc1);
						ti4_1 = (EIF_INTEGER_32) (((GdkEventConfigure *)loc1)->x);
						ti4_2 = (EIF_INTEGER_32) (((GdkEventConfigure *)loc1)->y);
						ti4_3 = (EIF_INTEGER_32) (((GdkEventConfigure *)loc1)->width);
						ti4_4 = (EIF_INTEGER_32) (((GdkEventConfigure *)loc1)->height);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R8140[Dtype(loc34)-1116])(loc34, ti4_1, ti4_2, ti4_3, ti4_4);
						loc12 = (EIF_REFERENCE) NULL;
					}
					break;
				case 14L:
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					gtk_main_do_event((GdkEvent*) loc1);
					loc9 = F1112_10022(Current, loc3);
					loc9 = RTRV(eif_new_type(1163, 0x00), loc9);
					if ((EIF_BOOLEAN)(loc9 != NULL)) {
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R8550[Dtype(RTCW(loc9))-1176])(loc9);
					}
					loc9 = (EIF_REFERENCE) NULL;
					break;
				case 15L:
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					gtk_main_do_event((GdkEvent*) loc1);
					loc11 = F1112_10022(Current, loc3);
					loc11 = RTRV(eif_new_type(1114, 0x00), loc11);
					if ((EIF_BOOLEAN)(loc11 != NULL)) {
						tr3 = *(EIF_REFERENCE *)(RTCW(loc11) + O7519[Dtype(loc11)-1086]);
						if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_41_) == tr3)) {
							F1112_9920(Current, NULL);
						}
						loc9 = loc11;
						loc9 = RTRV(eif_new_type(1163, 0x00), loc9);
						if ((EIF_BOOLEAN)(loc9 != NULL)) {
							F1164_10719(RTCW(loc9));
							loc9 = (EIF_REFERENCE) NULL;
						}
						loc11 = (EIF_REFERENCE) NULL;
					}
					break;
				case 17L:
					break;
				case 18L:
					break;
				case 19L:
					tr3 = F1112_9922(Current);
					loc35 = tr3;
					if (EIF_TEST(loc35)) {
						loc9 = *(EIF_REFERENCE *)(loc35 + _REFACS_3_);
						loc9 = RTRV(eif_new_type(1163, 0x00), loc9);
					} else {
						tr3 = RTLNS(eif_new_type(1015, 0x00).id, 1015, _OBJSIZ_2_0_0_0_0_0_0_0_);
						F982_8029(RTCW(tr3));
						tr3 = F1016_8500(RTCW(tr3));
						loc36 = tr3;
						if (EIF_TEST(loc36)) {
							loc9 = *(EIF_REFERENCE *)(loc36 + _REFACS_3_);
							loc9 = RTRV(eif_new_type(1163, 0x00), loc9);
						}
					}
					loc37 = loc9;
					loc37 = RTRV(eif_new_type(1222, 0x00),loc37);
					if (EIF_TEST(loc37)) {
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						gtk_main_do_event((GdkEvent*) loc1);
						F1223_11811(loc37);
					}
					loc9 = (EIF_REFERENCE) NULL;
					break;
				case 28L:
					break;
				case 29L:
					break;
				case 32L:
					loc10 = F1112_10022(Current, loc3);
					loc10 = RTRV(eif_new_type(1190, 0x00), loc10);
					if ((EIF_BOOLEAN)(loc10 != NULL)) {
						ti4_1 = (EIF_INTEGER_32) (((GdkEventWindowState *)loc1)->changed_mask);
						ti4_2 = (EIF_INTEGER_32) (((GdkEventWindowState *)loc1)->new_window_state);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R8779[Dtype(RTCW(loc10))-1190])(loc10, ti4_1, ti4_2);
						loc10 = (EIF_REFERENCE) NULL;
					}
					break;
				case 10L:
				case 11L:
					loc13 = (EIF_POINTER) (((GdkEventAny *)loc1)->window);
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					tb2 = '\0';
					tb3 = !loc13;
					if ((EIF_BOOLEAN) !tb3) {
						tb2 = (EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkEventCrossing *)loc1)->mode) == ((EIF_INTEGER_32) 0L));
					}
					if (tb2) {
						gdk_window_get_user_data((GdkWindow*) loc13, (gpointer*) (EIF_POINTER *) &(loc14));
						tb2 = !loc14;
						if ((EIF_BOOLEAN) !tb2) {
							if ((EIF_BOOLEAN) !F1112_10006(Current)) {
								tb2 = '\0';
								tr3 = F1112_10022(Current, loc14);
								loc38 = tr3;
								loc38 = RTRV(eif_new_type(1161, 0x00),loc38);
								if (EIF_TEST(loc38)) {
									tp2 = *(EIF_POINTER *)(loc38 + O8051[Dtype(loc38)-1113]);
									tb2 = (EIF_BOOLEAN)(tp2 == loc14);
								}
								if (tb2) {
									loc10 = F1115_10111(loc38);
									tb2 = '\01';
									if (!(EIF_BOOLEAN)(loc10 == NULL)) {
										tb3 = F1191_11126(RTCW(loc10));
										tb2 = (EIF_BOOLEAN) !tb3;
									}
									if (tb2) {
										loc39 = loc38;
										loc39 = RTRV(eif_new_type(1163, 0x00),loc39);
										if (EIF_TEST(loc39)) {
											ti1_1 = (EIF_INTEGER_8) (((GdkEventAny *)loc1)->type);
											F1164_10691(loc39, (EIF_BOOLEAN)(ti1_1 == ((EIF_INTEGER_8) 10L)));
										}
										loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
									}
									loc11 = (EIF_REFERENCE) NULL;
									loc10 = (EIF_REFERENCE) NULL;
									loc14 = F1_33(Current);
								} else {
									gtk_main_do_event((GdkEvent*) loc1);
									loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								}
							}
						}
					}
					loc13 = F1_33(Current);
					break;
				case 8L:
				case 9L:
					loc28 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					tr3 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
					loc40 = tr3;
					if (EIF_TEST(loc40)) {
						loc11 = (EIF_REFERENCE) loc40;
						loc13 = (EIF_POINTER) (((GdkEventAny *)loc1)->window);
						tp2 = *(EIF_POINTER *)(RTCW(loc11) + O8051[Dtype(loc11)-1113]);
						tp2 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp2);
						(((GdkEventAny *)loc1)->window = (GdkWindow*)(tp2));
					} else {
						if (loc24) {
							loc11 = F1112_10022(Current, loc4);
							loc11 = RTRV(eif_new_type(1114, 0x00), loc11);
						} else {
							loc12 = F1112_10022(Current, loc4);
							loc12 = RTRV(eif_new_type(1115, 0x00), loc12);
							loc11 = (EIF_REFERENCE) loc12;
						}
					}
					if ((EIF_BOOLEAN)(loc11 != NULL)) {
						loc12 = F1115_10110(RTCW(loc11));
						if ((EIF_BOOLEAN)(loc12 != NULL)) {
							loc10 = loc12;
							loc10 = RTRV(eif_new_type(1190, 0x00), loc10);
							tb2 = '\01';
							if (!(EIF_BOOLEAN)(loc10 == NULL)) {
								tb3 = F1191_11126(RTCW(loc10));
								tb2 = (EIF_BOOLEAN) !tb3;
							}
							if (tb2) {
								*(EIF_BOOLEAN *)(Current+ _CHROFF_49_9_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								tr3 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
								tu4_2 = (EIF_NATURAL_32) (((GdkEventKey *)loc1)->state);
								
								eif_put_natural_32_item(RTCW(tr3),4,tu4_2);
								loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
								F1116_10147(RTCW(loc12), loc1);
								*(EIF_BOOLEAN *)(Current+ _CHROFF_49_9_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							}
							loc11 = (EIF_REFERENCE) NULL;
							loc12 = (EIF_REFERENCE) NULL;
							loc10 = (EIF_REFERENCE) NULL;
						}
					}
					tb2 = !loc13;
					if ((EIF_BOOLEAN) !tb2) {
						(((GdkEventAny *)loc1)->window = (GdkWindow*)(loc13));
						loc13 = F1_33(Current);
					}
					break;
				case 0L:
					loc28 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc12 = F1112_10022(Current, loc3);
					loc12 = RTRV(eif_new_type(1115, 0x00), loc12);
					if ((EIF_BOOLEAN)(loc12 != NULL)) {
						(FUNCTION_CAST(void, (EIF_REFERENCE)) R8139[Dtype(RTCW(loc12))-1116])(loc12);
						loc12 = (EIF_REFERENCE) NULL;
					}
					break;
				case 1L:
					break;
				case 22L:
					break;
				case 23L:
					break;
				case 24L:
					break;
				case 25L:
					break;
				case 26L:
					F1112_9943(Current, loc1);
					break;
				case 27L:
					break;
				case -1L:
					break;
				case 33L:
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc25 = RTLNS(eif_new_type(949, 0x00).id, 949, _OBJSIZ_1_1_0_3_0_0_0_0_);
					tp2 = (EIF_POINTER) (((GdkEventSetting *)loc1)->name);
					F948_7585(RTCW(loc25), tp2);
					tb2 = F948_7607(RTCW(loc25), RTOMS(9924,0));
					if (tb2) {
						loc26 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						tb2 = F948_7607(RTCW(loc25), RTOMS(9924,1));
						if (tb2) {
							loc26 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						}
					}
					loc25 = (EIF_REFERENCE) NULL;
					gtk_main_do_event((GdkEvent*) loc1);
					tr3 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
					loc41 = tr3;
					if ((EIF_BOOLEAN) (loc26 && EIF_TEST(loc41))) {
						F603_4886(loc41, NULL);
					}
					loc26 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					break;
				case 34L:
					break;
				case 35L:
					break;
				case 36L:
					break;
				case 37L:
					break;
				case 38L:
					break;
				case 39L:
					break;
				case 40L:
					break;
				case 41L:
					break;
				case 42L:
					break;
				case 43L:
					break;
				case 44L:
					break;
				case 45L:
					break;
				case 46L:
					break;
				case 47L:
					break;
				case 48L:
					break;
				default:
					loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					break;
			}
			if (loc5) {
				if (loc6) {
					gtk_propagate_event((GtkWidget*) loc4, (GdkEvent*) loc1);
				} else {
					tb2 = !loc3;
					if ((EIF_BOOLEAN) !tb2) {
						loc7 = (EIF_BOOLEAN) EIF_TEST(gtk_widget_event((GtkWidget*) loc3, (GdkEvent*) loc1));
					} else {
						gtk_main_do_event((GdkEvent*) loc1);
					}
				}
			}
			gdk_event_free((GdkEvent*) loc1);
		} else {
			if ((EIF_BOOLEAN) EIF_TEST(g_main_context_pending (NULL))) {
				F1112_9926(Current);
			} else {
				loc17 = (EIF_BOOLEAN) EIF_TEST(g_main_context_pending (NULL));
				loc17 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc17;
			}
		}
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_1_) = (EIF_BOOLEAN) loc27;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_2_) = (EIF_BOOLEAN) loc28;
	RTLE;
}

/* {EV_APPLICATION_IMP}.process_gtk_events */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1112_9926 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	RTLD;
	RTXD;
	
	RTLI(1);
	RTLR(0,saved_except);
	RTLIU(1);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc1) {
		g_main_context_dispatch(g_main_context_default());
	}
	RTE_E
	RTXSC;
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_APPLICATION_IMP}.process_pending_events_on_default_context */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1112_9927 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	RTLD;
	RTXD;
	
	RTLI(1);
	RTLR(0,saved_except);
	RTLIU(1);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc2) {
		for (;;) {
			if ((EIF_BOOLEAN) EIF_TEST(g_main_context_pending (NULL))) break;
			loc1 = (EIF_BOOLEAN) EIF_TEST(g_main_context_iteration(NULL, FALSE));
		}
	}
	RTE_E
	RTXSC;
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_APPLICATION_IMP}.symbol_from_symbol_name */
EIF_POINTER F1112_9929 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc1 = F1112_9930(Current);
	if ((EIF_BOOLEAN)(loc1 != F1_33(Current))) {
		loc2 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
		F818_5410(RTCW(loc2), arg1);
		tp1 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_0_1_0_1_0_0_);
		loc3 = (EIF_BOOLEAN) EIF_TEST(g_module_symbol((GModule*) loc1, (gchar*) tp1, (gpointer*) (EIF_POINTER *) &(loc4)));
		if (loc3) {
			RTLE;
			return (EIF_POINTER) loc4;
		}
	}
	RTLE;
	return (EIF_POINTER) 0;
}

/* {EV_APPLICATION_IMP}.main_module */
EIF_POINTER F1112_9930 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) EIF_TEST(g_module_supported())) {
		tp1 = F1_33(Current);
		Result = (EIF_POINTER) g_module_open((gchar*) tp1, (GModuleFlags) ((EIF_INTEGER_32) 0L));
	}
	RTLE;
	return Result;
}

/* {EV_APPLICATION_IMP}.ctrl_pressed */
EIF_BOOLEAN F1112_9931 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = F1112_10011(Current);
	tu4_2 = (EIF_NATURAL_32) GDK_CONTROL_MASK;
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_2 = (EIF_NATURAL_32) GDK_CONTROL_MASK;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == tu4_2);
	RTLE;
	return Result;
}

/* {EV_APPLICATION_IMP}.alt_pressed */
EIF_BOOLEAN F1112_9932 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = F1112_10011(Current);
	tu4_2 = (EIF_NATURAL_32) GDK_MOD1_MASK;
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_2 = (EIF_NATURAL_32) GDK_MOD1_MASK;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == tu4_2);
	RTLE;
	return Result;
}

/* {EV_APPLICATION_IMP}.shift_pressed */
EIF_BOOLEAN F1112_9933 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = F1112_10011(Current);
	tu4_2 = (EIF_NATURAL_32) GDK_SHIFT_MASK;
	tu4_1 = eif_bit_and(tu4_1,tu4_2);
	tu4_2 = (EIF_NATURAL_32) GDK_SHIFT_MASK;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == tu4_2);
	RTLE;
	return Result;
}

/* {EV_APPLICATION_IMP}.windows */
EIF_REFERENCE F1112_9936 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,loc3);
	RTLR(1,loc4);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLR(4,loc1);
	RTLR(5,tr1);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	loc3 = RTLNS(eif_new_type(826, 0x00).id, 826, _OBJSIZ_0_0_0_1_0_0_0_0_);
	{
		static EIF_TYPE_INDEX typarr0[] = {564,1038,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc4 = RTLNS(typres0.id, 564, _OBJSIZ_2_3_0_1_0_0_0_0_);
	}
	F565_4505(RTCW(loc4));
	Result = (EIF_REFERENCE) loc4;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
	loc1 = F566_4511(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
	F566_4524(RTCW(tr1));
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
		tb1 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_2_2_);
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
		ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4052[Dtype(RTCW(tr1))-564])(tr1));
		loc2 = F827_6018(RTCW(loc3), ti4_1);
		loc2 = RTRV(eif_new_type(1190, 0x00), loc2);
		tb2 = '\01';
		if (!(EIF_BOOLEAN)(loc2 == NULL)) {
			tb3 = F1087_9344(RTCW(loc2));
			tb2 = tb3;
		}
		if (tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R4057[Dtype(RTCW(tr1))-564])(tr1);
		} else {
			tr1 = F1087_9345(RTCW(loc2));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4038[Dtype(RTCW(loc4))-564])(loc4, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
			F566_4526(RTCW(tr1));
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
	F566_4530(RTCW(tr1), loc1);
	RTLE;
	return Result;
}

/* {EV_APPLICATION_IMP}.motion_tuple */
static EIF_REFERENCE F1112_9940_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9940);
#define Result RTOSR(9940)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,7,865,868,868,892,892,892,868,868,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNTS(typres0.id, 8, 1);
	}
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9940);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1112_9940 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9940,F1112_9940_body,(Current));
}

/* {EV_APPLICATION_IMP}.app_motion_tuple */
static EIF_REFERENCE F1112_9941_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (9941);
#define Result RTOSR(9941)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,865,1026,868,868,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNTS(typres0.id, 4, 0);
	}
	tr2 = RTOSCF(10028,F1112_10028, (Current));
	((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
	RTAR(tr1,tr2);
	((EIF_TYPED_VALUE *)tr1+2)->it_i4 = ((EIF_INTEGER_32) 0L);
	((EIF_TYPED_VALUE *)tr1+3)->it_i4 = ((EIF_INTEGER_32) 0L);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9941);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1112_9941 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9941,F1112_9941_body,(Current));
}

/* {EV_APPLICATION_IMP}.process_button_event */
void F1112_9942 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,loc10);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,loc7);
	RTLR(8,loc11);
	RTLIU(9);
	
	RTGC;
	tr8_1 = (EIF_REAL_64) (((GdkEventButton *)arg1)->x_root);
	loc8 = (EIF_INTEGER_32) tr8_1;
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_11_);
	loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ti4_1);
	tr8_1 = (EIF_REAL_64) (((GdkEventButton *)arg1)->y_root);
	loc9 = (EIF_INTEGER_32) tr8_1;
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_12_);
	loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc9 + ti4_1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
	tp1 = (EIF_POINTER) (((GdkEventButton *)arg1)->window);
	
	eif_put_pointer_item(RTCW(loc3),1,tp1);
	
	eif_put_integer_32_item(RTCW(loc3),2,loc8);
	
	eif_put_integer_32_item(RTCW(loc3),3,loc9);
	tu4_1 = (EIF_NATURAL_32) (((GdkEventButton *)arg1)->state);
	
	eif_put_natural_32_item(RTCW(loc3),4,tu4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_29_);
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		loc1 = *(EIF_REFERENCE *)(loc10 + _REFACS_3_);
		loc1 = RTRV(eif_new_type(1161, 0x00), loc1);
	} else {
		if ((EIF_BOOLEAN)(F1112_10007(Current) != NULL)) {
			loc1 = F1112_10007(Current);
		} else {
			loc2 = eif_pointer_item(RTCW(loc3),1);
			tb1 = !loc2;
			if ((EIF_BOOLEAN) !tb1) {
				loc1 = F1112_10024(Current, loc2);
				loc1 = RTRV(eif_new_type(1161, 0x00), loc1);
			}
		}
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		loc4 = F1115_10111(RTCW(loc1));
		loc4 = RTRV(eif_new_type(1190, 0x00), loc4);
		loc5 = loc4;
		loc5 = RTRV(eif_new_type(1191, 0x00), loc5);
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			loc7 = loc1;
			loc7 = RTRV(eif_new_type(1219, 0x00), loc7);
		}
		loc6 = '\01';
		tb1 = '\01';
		tb2 = '\0';
		tb3 = '\0';
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 != NULL) && (EIF_BOOLEAN)(loc7 != NULL))) {
			tb3 = (EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkEventButton *)arg1)->button) == ((EIF_INTEGER_32) 3L));
		}
		if (tb3) {
			tb3 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O8432[Dtype(loc1)-1160]);
			if ((EIF_BOOLEAN)(tr1 == NULL)) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O8433[Dtype(loc1)-1160]);
				tb3 = (EIF_BOOLEAN)(tr1 == NULL);
			}
			tb2 = tb3;
		}
		if (!tb2) {
			tp2 = *(EIF_POINTER *)(RTCW(loc1) + O8051[Dtype(loc1)-1113]);
			tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_widget_is_sensitive((GtkWidget*) tp2));
		}
		if (!tb1) {
			tb1 = '\0';
			tb2 = '\0';
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				tb3 = F1191_11126(RTCW(loc4));
				tb2 = tb3;
			}
			if (tb2) {
				tb1 = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_29_) == NULL);
			}
			loc6 = tb1;
		}
	}
	if ((EIF_BOOLEAN)(loc5 == NULL)) {
		loc5 = *(EIF_REFERENCE *)(Current + _REFACS_44_);
	}
	if ((EIF_BOOLEAN)(loc5 != NULL)) {
		(RTNA((RTCW(loc5), (EIF_INTEGER_32) (((GdkEventButton *)arg1)->type), (EIF_INTEGER_32) (((GdkEventButton *)arg1)->button), loc8, loc9)));
	}
	if ((EIF_BOOLEAN) !loc6) {
		tb1 = '\0';
		tb2 = '\0';
		if ((EIF_BOOLEAN)(F1112_10007(Current) == NULL)) {
			tb2 = (EIF_BOOLEAN) !arg2;
		}
		if (tb2) {
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc1 == NULL)) {
				tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8486[Dtype(RTCW(loc1))-1176])(loc1);
				tb2 = (EIF_BOOLEAN) !tb3;
			}
			tb1 = tb2;
		}
		if (tb1) {
			gtk_main_do_event((GdkEvent*) arg1);
		}
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb1 = '\0';
			tb2 = '\0';
			if ((EIF_BOOLEAN) !arg2) {
				tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8486[Dtype(RTCW(loc1))-1176])(loc1);
				tb2 = tb3;
			}
			if (tb2) {
				loc11 = loc1;
				tb1 = EIF_TEST(loc11);
			}
			if (tb1) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_BOOLEAN)) R8072[Dtype(loc11)-1116])(loc11, arg1, arg2);
			} else {
				ti4_1 = (EIF_INTEGER_32) (((GdkEventButton *)arg1)->type);
				tr8_1 = (EIF_REAL_64) (((GdkEventButton *)arg1)->x);
				ti4_2 = (EIF_INTEGER_32) tr8_1;
				tr8_1 = (EIF_REAL_64) (((GdkEventButton *)arg1)->y);
				ti4_3 = (EIF_INTEGER_32) tr8_1;
				ti4_4 = (EIF_INTEGER_32) (((GdkEventButton *)arg1)->button);
				F1162_10638(RTCW(loc1), ti4_1, ti4_2, ti4_3, ti4_4, (EIF_REAL_64) 0.5, (EIF_REAL_64) 0.5, (EIF_REAL_64) 0.5, loc8, loc9);
			}
		}
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_49_8_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {EV_APPLICATION_IMP}.handle_dnd */
void F1112_9943 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_POINTER loc6 = (EIF_POINTER) 0;
	EIF_POINTER loc7 = (EIF_POINTER) 0;
	EIF_NATURAL_32 loc8 = (EIF_NATURAL_32) 0;
	EIF_POINTER loc9 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc15 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc17);
	RTLR(1,loc18);
	RTLR(2,loc13);
	RTLR(3,tr1);
	RTLR(4,loc14);
	RTLR(5,tr2);
	RTLR(6,loc16);
	RTLR(7,Current);
	RTLR(8,tr3);
	RTLIU(9);
	
	RTGC;
	loc1 = (EIF_POINTER) (((GdkEventDND *)arg1)->context);
	loc4 = (EIF_POINTER) gdk_drag_context_get_source_window((GdkDragContext*) loc1);
	loc6 = (EIF_POINTER) gdk_drag_get_selection((GdkDragContext*) loc1);
	loc8 = (EIF_NATURAL_32) (((GdkEventDND *)arg1)->time);
	loc2 = (EIF_POINTER) gdk_drag_context_list_targets((GdkDragContext*) loc1);
	loc17 = RTMS_EX_H("STRING",6,1544365639);
	loc18 = RTMS_EX_H("file://",7,1704345391);
	for (;;) {
		tb1 = !loc2;
		if (tb1) break;
		loc3 = (EIF_POINTER) (((GList *)loc2)->data);
		tb2 = !loc3;
		if ((EIF_BOOLEAN) !tb2) {
			gdk_selection_convert((GdkWindow*) loc4, (GdkAtom) loc6, (GdkAtom) loc3, (guint32) loc8);
			loc12 = (EIF_INTEGER_32) gdk_selection_property_get((GdkWindow*) loc4, (guchar**) (EIF_POINTER *) &(loc9), (GdkAtom*) (EIF_INTEGER_32 *) &(loc10), (gint*) (EIF_INTEGER_32 *) &(loc11));
			tb2 = !loc9;
			if ((EIF_BOOLEAN) !tb2) {
				loc13 = RTLNS(eif_new_type(953, 0x00).id, 953, _OBJSIZ_1_1_0_3_0_0_0_0_);
				tp1 = (EIF_POINTER) gdk_atom_name((GdkAtom) loc3);
				F952_7752(RTCW(loc13), tp1);
				tr1 = F945_7511(RTCW(loc17));
				tb2 = F952_7772(RTCW(loc13), tr1);
				if (tb2) {
					loc13 = RTLNS(eif_new_type(953, 0x00).id, 953, _OBJSIZ_1_1_0_3_0_0_0_0_);
					F952_7752(RTCW(loc13), loc9);
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '\012';
					loc14 = F945_7530(RTCW(loc13), tw1);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R4018[Dtype(RTCW(loc14))-564])(loc14);
					for (;;) {
						tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4029[Dtype(RTCW(loc14))-564])(loc14);
						if (tb2) break;
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4052[Dtype(RTCW(loc14))-564])(loc14);
						ti4_1 = F952_7765(RTCW(tr1), loc18, ((EIF_INTEGER_32) 1L));
						if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4052[Dtype(RTCW(loc14))-564])(loc14);
							tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4052[Dtype(RTCW(loc14))-564])(loc14);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_1_1_0_2_);
							tr1 = F954_7910(RTCW(tr1), ((EIF_INTEGER_32) 8L), ti4_1);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4056[Dtype(RTCW(loc14))-564])(loc14, tr1);
							loc15 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							(FUNCTION_CAST(void, (EIF_REFERENCE)) R4031[Dtype(RTCW(loc14))-564])(loc14);
						} else {
							(FUNCTION_CAST(void, (EIF_REFERENCE)) R4057[Dtype(RTCW(loc14))-564])(loc14);
						}
					}
				}
			}
		}
		tp1 = (EIF_POINTER) (((GList *)loc2)->next);
		loc2 = (EIF_POINTER) tp1;
	}
	if ((EIF_BOOLEAN) (loc15 && (EIF_BOOLEAN)(loc14 != NULL))) {
		loc5 = (EIF_POINTER) gdk_drag_context_get_dest_window((GdkDragContext*) loc1);
		tb3 = !loc5;
		if ((EIF_BOOLEAN) !tb3) {
			gdk_window_get_user_data((GdkWindow*) loc5, (gpointer*) (EIF_POINTER *) &(loc7));
			tb3 = !loc7;
			if ((EIF_BOOLEAN) !tb3) {
				loc16 = F1112_10022(Current, loc7);
				loc16 = RTRV(eif_new_type(1163, 0x00), loc16);
				tb3 = '\0';
				if ((EIF_BOOLEAN)(loc16 != NULL)) {
					tb4 = F1087_9344(RTCW(loc16));
					tb3 = (EIF_BOOLEAN) !tb4;
				}
				if (tb3) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc16) + O2654[Dtype(loc16)-117]);
					if ((EIF_BOOLEAN)(tr1 != NULL)) {
						tr1 = F118_2668(RTCW(loc16));
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,540,953,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr2 = RTLNTS(typres0.id, 2, 0);
						}
						((EIF_TYPED_VALUE *)tr2+1)->it_r = loc14;
						RTAR(tr2,loc14);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4354[Dtype(RTCW(tr1))-601])(tr1, tr2);
					}
					if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) != NULL)) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,865,1026,540,953,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr2 = RTLNTS(typres0.id, 3, 0);
						}
						tr3 = F1087_9345(RTCW(loc16));
						((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
						RTAR(tr2,tr3);
						((EIF_TYPED_VALUE *)tr2+2)->it_r = loc14;
						RTAR(tr2,loc14);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4354[Dtype(RTCW(tr1))-601])(tr1, tr2);
					}
				}
			}
		}
	}
	gdk_drop_finish((GdkDragContext*) loc1, (gboolean) loc15, (guint32) loc8);
	gtk_drag_finish((GdkDragContext*) loc1, (gboolean) loc15, (gboolean) (EIF_BOOLEAN) 0, (guint32) loc8);
	g_free((gpointer) loc9);
	g_free((gpointer) loc2);
	RTLE;
}

/* {EV_APPLICATION_IMP}.sleep */
void F1112_9995 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_64 ti8_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti8_1 = (EIF_INTEGER_64) arg1;
	F238_3963(Current, (EIF_INTEGER_64) (((EIF_INTEGER_64) RTI64C(1000000)) * ti8_1));
	RTLE;
}

/* {EV_APPLICATION_IMP}.destroy */
void F1112_9996 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1087_9344(Current)) {
		if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_2_) != F1_33(Current))) {
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_16_0_20_0_2_);
			inline_F80_1240(tp1);
		}
		F1087_9360(Current, (EIF_BOOLEAN) 1);
		tr1 = F99_2444(Current);
		F603_4886(RTCW(tr1), NULL);
	}
	RTLE;
}

/* {EV_APPLICATION_IMP}.tooltip_delay */
EIF_INTEGER_32 F1112_9997 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_19_);
}


/* {EV_APPLICATION_IMP}.set_tooltip_delay */
void F1112_9998 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_19_) = (EIF_INTEGER_32) arg1;
}

/* {EV_APPLICATION_IMP}.set_docking_source */
void F1112_9999 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_46_) = (EIF_REFERENCE) arg1;
}

/* {EV_APPLICATION_IMP}.on_pick */
void F1112_10000 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_45_) = (EIF_REFERENCE) arg1;
	tr1 = F980_8009(RTCV(F1087_9345(Current)));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,0,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr2 = RTLNTS(typres0.id, 2, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = arg2;
	RTAR(tr2,arg2);
	F604_4887(RTCW(tr1), tr2);
	RTLE;
}

/* {EV_APPLICATION_IMP}.on_drop */
void F1112_10001 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	*(EIF_REFERENCE *)(Current + _REFACS_45_) = (EIF_REFERENCE) NULL;
}

/* {EV_APPLICATION_IMP}.pnd_source_hint */
static EIF_REFERENCE F1112_10002_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10002);
#define Result RTOSR(10002)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(985, 0x00).id, 985, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F982_8029(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10002);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1112_10002 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10002,F1112_10002_body,(Current));
}

/* {EV_APPLICATION_IMP}.activate_docking_source_hint */
void F1112_10003 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) !RTOSCF(9906,F1112_9906, (Current))) {
		tr1 = RTOSCF(10002,F1112_10002, (Current));
		F986_8101(RTCW(tr1), arg1, arg2, ((EIF_INTEGER_32) 50L), ((EIF_INTEGER_32) 50L), arg3);
	}
	RTLE;
}

/* {EV_APPLICATION_IMP}.deactivate_docking_source_hint */
void F1112_10004 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN) !RTOSCF(9906,F1112_9906, (Current))) {
		tb2 = F986_8100(RTCV(RTOSCF(10002,F1112_10002, (Current))));
		tb1 = tb2;
	}
	if (tb1) {
		F986_8102(RTCV(RTOSCF(10002,F1112_10002, (Current))));
	}
	RTLE;
}

/* {EV_APPLICATION_IMP}.is_in_transport */
EIF_BOOLEAN F1112_10006 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	if (!(EIF_BOOLEAN)(F1112_10007(Current) != NULL)) {
		Result = (EIF_BOOLEAN)(F1112_10008(Current) != NULL);
	}
	RTLE;
	return Result;
}

/* {EV_APPLICATION_IMP}.pick_and_drop_source */
EIF_REFERENCE F1112_10007 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_45_);
}

/* {EV_APPLICATION_IMP}.docking_source */
EIF_REFERENCE F1112_10008 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_46_);
}

/* {EV_APPLICATION_IMP}.keyboard_modifier_mask */
EIF_NATURAL_32 F1112_10011 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_9_)) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
	} else {
		loc1 = F1112_10012(Current);
	}
	tu4_1 = eif_natural_32_item(RTCW(loc1),4);
	RTLE;
	return (EIF_NATURAL_32) tu4_1;
}

/* {EV_APPLICATION_IMP}.retrieve_display_data */
EIF_REFERENCE F1112_10012 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_49_8_)) {
		F1112_10013(Current);
	}
	RTLE;
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_48_);
}

/* {EV_APPLICATION_IMP}.update_display_data */
void F1112_10013 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER loc6 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc5 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
	loc6 = inline_F17_357();
	inline_F17_354(loc6, (EIF_INTEGER_32 *) &(loc3), (EIF_INTEGER_32 *) &(loc4));
	loc1 = (EIF_POINTER) gdk_device_get_window_at_position((GdkDevice*) loc6, (gint*) (EIF_INTEGER_32 *) &(loc3), (gint*) (EIF_INTEGER_32 *) &(loc4));
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		tp1 = (EIF_POINTER) gdk_window_get_device_position((GdkWindow*) loc1, (GdkDevice *) loc6, (gint*) (EIF_INTEGER_32 *) &(loc3), (gint*) (EIF_INTEGER_32 *) &(loc4), (GdkModifierType*) (EIF_NATURAL_32 *) &(loc2));
		loc1 = (EIF_POINTER) tp1;
		inline_F17_354(loc6, (EIF_INTEGER_32 *) &(loc3), (EIF_INTEGER_32 *) &(loc4));
		
		eif_put_pointer_item(RTCW(loc5),1,loc1);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_11_);
		
		eif_put_integer_32_item(RTCW(loc5),2,(EIF_INTEGER_32) (loc3 + ti4_1));
		ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_16_0_12_);
		
		eif_put_integer_32_item(RTCW(loc5),3,(EIF_INTEGER_32) (loc4 + ti4_2));
		
		eif_put_natural_32_item(RTCW(loc5),4,loc2);
	}
	RTLE;
}

/* {EV_APPLICATION_IMP}.enable_debugger */
void F1112_10018 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_49_10_)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		tb1 = *(EIF_BOOLEAN *)(Current+ _CHROFF_49_12_);
		inline_F76_1152(tb1);
	}
	RTLE;
}

/* {EV_APPLICATION_IMP}.disable_debugger */
void F1112_10019 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_49_10_)) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tb1 = EIF_TEST (inline_F76_1153());
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_12_) = (EIF_BOOLEAN) tb1;
		F76_1151(Current);
	}
	RTLE;
}

/* {EV_APPLICATION_IMP}.eif_object_from_gtk_object */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
EIF_REFERENCE F1112_10022 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTEX;
	RTED;
	EIF_POINTER EIF_VOLATILE loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN EIF_VOLATILE loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	EIF_POINTER  EIF_VOLATILE tp1;
	EIF_BOOLEAN  EIF_VOLATILE tb1;
	EIF_BOOLEAN  EIF_VOLATILE tb2;
	EIF_BOOLEAN  EIF_VOLATILE tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	RTXD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,saved_except);
	RTLIU(2);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc2) {
		loc1 = (EIF_POINTER) arg1;
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(Result != NULL)) {
				tb2 = !loc1;
				tb1 = tb2;
			}
			if (tb1) break;
			Result = inline_F1114_10054(loc1);
			tp1 = (EIF_POINTER) gtk_widget_get_parent((GtkWidget*) loc1);
			loc1 = (EIF_POINTER) tp1;
		}
		tb2 = '\0';
		if ((EIF_BOOLEAN)(Result != NULL)) {
			tb3 = F1087_9344(RTCW(Result));
			tb2 = tb3;
		}
		if (tb2) {
			Result = (EIF_REFERENCE) NULL;
		}
	} else {
		
	}
	RTE_E
	RTXSC;
	Result = (EIF_REFERENCE) NULL;
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTER;
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
	return Result;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {EV_APPLICATION_IMP}.gtk_widget_imp_at_pointer_position */
EIF_REFERENCE F1112_10023 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = inline_F17_357();
	loc3 = (EIF_POINTER) gdk_device_get_window_at_position((GdkDevice*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) (EIF_INTEGER_32 *) &(loc2));
	tb1 = !loc3;
	if ((EIF_BOOLEAN) !tb1) {
		RTLE;
		return (EIF_REFERENCE) F1112_10024(Current, loc3);
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {EV_APPLICATION_IMP}.gtk_widget_from_gdk_window */
EIF_REFERENCE F1112_10024 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	gdk_window_get_user_data((GdkWindow*) arg1, (gpointer*) (EIF_POINTER *) &(loc1));
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		Result = F1112_10022(Current, loc1);
		RTLE;
		return RTRV(eif_new_type(1114, 0x00), Result);
	}
	RTLE;
	return Result;
}

/* {EV_APPLICATION_IMP}.default_gtk_window */
static EIF_POINTER F1112_10026_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (10026);
#define Result RTOSR(10026)
	tr1 = RTOSCF(10030,F1112_10030, (Current));
	Result = *(EIF_POINTER *)(RTCW(tr1) + O8051[Dtype(tr1)-1113]);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_43_);
	ti4_1 = F827_6017(RTCV(RTOSCF(10030,F1112_10030, (Current))));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4041[Dtype(RTCW(tr1))-503])(tr1, (EIF_REFERENCE) &ti4_1);
	RTOSE (10026);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_POINTER F1112_10026 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10026,F1112_10026_body,(Current));
}

/* {EV_APPLICATION_IMP}.default_gdk_window */
EIF_POINTER F1112_10027 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = RTOSCF(10026,F1112_10026, (Current));
	Result = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
	RTLE;
	return Result;
}

/* {EV_APPLICATION_IMP}.default_widget */
static EIF_REFERENCE F1112_10028_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (10028);
#define Result RTOSR(10028)
	RTOC_NEW(Result);
	RTCT0("attached {EV_WIDGET} default_window as l_widget", EX_CHECK);
	tr1 = RTOSCF(10029,F1112_10029, (Current));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc1;
	RTOSE (10028);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1112_10028 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10028,F1112_10028_body,(Current));
}

/* {EV_APPLICATION_IMP}.default_window */
static EIF_REFERENCE F1112_10029_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10029);
#define Result RTOSR(10029)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1038, 0x00).id, 1038, _OBJSIZ_6_3_0_1_0_0_0_0_);
	F982_8029(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10029);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1112_10029 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10029,F1112_10029_body,(Current));
}

/* {EV_APPLICATION_IMP}.default_window_imp */
static EIF_REFERENCE F1112_10030_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (10030);
#define Result RTOSR(10030)
	RTOC_NEW(Result);
	RTCT0("attached {EV_WINDOW_IMP} default_window.implementation as win", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(10029,F1112_10029, (Current))) + _REFACS_3_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1190, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc1;
	RTOSE (10030);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1112_10030 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10030,F1112_10030_body,(Current));
}

/* {EV_APPLICATION_IMP}.reusable_rectangle_struct */
static EIF_POINTER F1112_10031_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (10031);
#define Result RTOSR(10031)
	Result = (EIF_POINTER) calloc (sizeof(GdkRectangle), 1);
	RTOSE (10031);
	RTEE;
	return Result;
#undef Result
}

EIF_POINTER F1112_10031 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10031,F1112_10031_body,(Current));
}

/* {EV_APPLICATION_IMP}.c_string_from_eiffel_string */
EIF_REFERENCE F1112_10032 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R6192[Dtype(RTCW(arg1))-948])(arg1);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 1000L))) {
		tr1 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
		F818_5410(RTCW(tr1), arg1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		Result = RTOSCF(10033,F1112_10033, (Current));
		F818_5410(RTCW(Result), arg1);
	}
	RTLE;
	return Result;
}

/* {EV_APPLICATION_IMP}.reusable_gtk_c_string */
static EIF_REFERENCE F1112_10033_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (10033);
#define Result RTOSR(10033)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr2 = RTMS_EX_H("",0,0);
	F818_5410(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10033);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1112_10033 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10033,F1112_10033_body,(Current));
}

/* {EV_APPLICATION_IMP}.initialize_threading */
void F1112_10035 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_thread_capable__b) {
		tr1 = RTLNSMART(eif_new_type(819, 0).id);
		F820_5427(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_33_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {EV_APPLICATION_IMP}.enable_ev_gtk_log */
void F1112_10038 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	enable_ev_gtk_log((EIF_INTEGER) arg1);
	
}

/* {EV_APPLICATION_IMP}.gtk_init_check */
EIF_BOOLEAN F1112_10040 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_init_check (&eif_argc, &eif_argv));
	return Result;
}

/* {EV_APPLICATION_IMP}.c_get_screen_geometry */
void F1112_10041 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	inline_F1112_10041 ((EIF_POINTER) arg1);
}

void EIF_Minit468 (void)
{
	GTCX
	RTPOMS(9905,0,"EV_HAS_X11_SUPPORT",18,1084065108);
	RTPOMS(9924,1,"gtk-font-name",13,1067777893);
	RTPOMS(9924,0,"gtk-theme-name",14,97340261);
}


#ifdef __cplusplus
}
#endif
