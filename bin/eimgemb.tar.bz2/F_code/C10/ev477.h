
#ifndef _C10_ev477_
#define _C10_ev477_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1125_10255(EIF_REFERENCE);
extern EIF_REFERENCE F1125_10256(EIF_REFERENCE);
extern void EIF_Minit477(void);
extern char *(*R8228[])();
extern char *(*R8229[])();

#ifdef __cplusplus
}
#endif

#endif
