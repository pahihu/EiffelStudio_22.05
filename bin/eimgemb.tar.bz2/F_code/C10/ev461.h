
#ifndef _C10_ev461_
#define _C10_ev461_

#ifdef __cplusplus
extern "C" {
#endif
RTOSHF (EIF_REFERENCE, 9627)


extern EIF_REFERENCE F1105_9627(EIF_REFERENCE);
extern void EIF_Minit461(void);

#ifdef __cplusplus
}
#endif

#endif
