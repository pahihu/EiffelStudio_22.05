/*
 * Code for class EV_GTK_WINDOW_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev472.h"
#include <stdlib.h>
#include <ev_gtk.h>
#include <string.h>
#include <gdk/gdkkeysyms.h>
#include "eif_helpers.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_WINDOW_IMP}.set_blocking_window */
void F1116_10116 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1087_9344(Current)) {
		if ((EIF_BOOLEAN)(arg1 != NULL)) {
			loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
			loc1 = RTRV(eif_new_type(1190, 0x00), loc1);
			RTCT0("l_internal_blocking_window /= Void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			RTAR(Current, loc1);
			*(EIF_REFERENCE *)(Current + O8118[dtype-1115]) = (EIF_REFERENCE) loc1;
			F1191_11089(RTCW(loc1), Current);
		} else {
			loc1 = *(EIF_REFERENCE *)(Current + O8118[dtype-1115]);
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				F1191_11090(RTCW(loc1), Current);
				*(EIF_REFERENCE *)(Current + O8118[dtype-1115]) = (EIF_REFERENCE) NULL;
			}
		}
	} else {
		*(EIF_REFERENCE *)(Current + O8118[dtype-1115]) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.blocking_window */
EIF_REFERENCE F1116_10117 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + O8118[Dtype(Current)-1115]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb2 = F1087_9344(loc1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(loc1 + O7519[Dtype(loc1)-1086]);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {EV_GTK_WINDOW_IMP}.window_position_enum */
EIF_INTEGER_32 F1116_10118 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(F1116_10117(Current) != NULL)) {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) GTK_WIN_POS_CENTER_ON_PARENT;
	} else {
		RTLE;
		return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8117[Dtype(Current)-1116])(Current);
	}/* NOTREACHED */
	
}

/* {EV_GTK_WINDOW_IMP}.default_window_position */
EIF_INTEGER_32 F1116_10119 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) GTK_WIN_POS_NONE;
}

/* {EV_GTK_WINDOW_IMP}.set_size */
void F1116_10123 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F1115_10085(Current);
	loc1 = eif_max_int32 (arg1,ti4_1);
	ti4_1 = F1115_10086(Current);
	loc2 = eif_max_int32 (arg2,ti4_1);
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	gtk_window_set_default_size((GtkWindow*) tp1, (gint) loc1, (gint) loc2);
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	gtk_window_resize((GtkWindow*) tp1, (gint) loc1, (gint) loc2);
	*(EIF_BOOLEAN *)(Current + O8125[dtype-1115]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	tb1 = '\0';
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8107[dtype-1116])(Current)) {
		tb1 = (EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8136[dtype-1116])(Current);
	}
	if (tb1) {
		F1116_10150(Current);
	}
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.width */
EIF_INTEGER_32 F1116_10124 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\01';
	if (!*(EIF_BOOLEAN *)(Current + O8125[dtype-1115])) {
		tb1 = (EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8107[dtype-1116])(Current);
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		tp2 = F1_33(Current);
		gtk_window_get_default_size((GtkWindow*) tp1, (EIF_INTEGER_32*) (EIF_INTEGER_32 *) &(Result), (EIF_INTEGER_32*) tp2);
		ti4_1 = F1115_10085(Current);
		ti4_1 = eif_max_int32 (Result,ti4_1);
		Result = (EIF_INTEGER_32) ti4_1;
	} else {
		Result = F1115_10104(Current);
		RTLE;
		return (EIF_INTEGER_32) Result;
	}
	RTLE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.height */
EIF_INTEGER_32 F1116_10125 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\01';
	if (!*(EIF_BOOLEAN *)(Current + O8125[dtype-1115])) {
		tb1 = (EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8107[dtype-1116])(Current);
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		tp2 = F1_33(Current);
		gtk_window_get_default_size((GtkWindow*) tp1, (EIF_INTEGER_32*) tp2, (EIF_INTEGER_32*) (EIF_INTEGER_32 *) &(Result));
		ti4_1 = F1115_10086(Current);
		ti4_1 = eif_max_int32 (Result,ti4_1);
		Result = (EIF_INTEGER_32) ti4_1;
	} else {
		Result = F1115_10105(Current);
		RTLE;
		return (EIF_INTEGER_32) Result;
	}
	RTLE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.set_x_position */
void F1116_10126 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F1116_10134(Current);
	F1116_10128(Current, arg1, ti4_1);
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.set_y_position */
void F1116_10127 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F1116_10132(Current);
	F1116_10128(Current, ti4_1, arg1);
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.set_position */
void F1116_10128 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(10077,F1114_10077, (Current)))+ _LNGOFF_49_16_0_11_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(10077,F1114_10077, (Current)))+ _LNGOFF_49_16_0_12_);
	gtk_window_move((GtkWindow*) tp1, (gint) (EIF_INTEGER_32) (arg1 - ti4_1), (gint) (EIF_INTEGER_32) (arg2 - ti4_2));
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.client_width */
EIF_INTEGER_32 F1116_10130 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	gtk_window_get_size((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(Result), (gint*) (EIF_INTEGER_32 *) &(loc1));
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.client_height */
EIF_INTEGER_32 F1116_10131 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	gtk_window_get_size((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) (EIF_INTEGER_32 *) &(Result));
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.x_position */
EIF_INTEGER_32 F1116_10132 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	gtk_window_get_position((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(Result), (gint*) (EIF_INTEGER_32 *) &(loc1));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(10077,F1114_10077, (Current)))+ _LNGOFF_49_16_0_11_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTLE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.screen_x */
EIF_INTEGER_32 F1116_10133 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	gtk_window_get_position((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(Result), (gint*) (EIF_INTEGER_32 *) &(loc1));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(10077,F1114_10077, (Current)))+ _LNGOFF_49_16_0_11_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTLE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.y_position */
EIF_INTEGER_32 F1116_10134 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	gtk_window_get_position((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) (EIF_INTEGER_32 *) &(Result));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(10077,F1114_10077, (Current)))+ _LNGOFF_49_16_0_12_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTLE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.screen_y */
EIF_INTEGER_32 F1116_10135 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	gtk_window_get_position((GtkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) (EIF_INTEGER_32 *) &(Result));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(10077,F1114_10077, (Current)))+ _LNGOFF_49_16_0_12_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTLE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.default_wm_decorations */
EIF_INTEGER_32 F1116_10136 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
}

/* {EV_GTK_WINDOW_IMP}.show */
void F1116_10137 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1115_10108(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		ti4_1 = F1116_10118(Current);
		gtk_window_set_position((GtkWindow*) tp1, (GtkWindowPosition) ti4_1);
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		gtk_widget_show((GtkWidget*) tp1);
	}
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.hide */
void F1116_10138 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (F1115_10108(Current)) {
		tb1 = '\0';
		tb2 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + O8118[dtype-1115]);
		loc5 = tr1;
		if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current + O8131[dtype-1115]) && EIF_TEST(loc5))) {
			tb3 = F1087_9344(loc5);
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			tb2 = F1115_10108(loc5);
			tb1 = tb2;
		}
		if (tb1) {
			F1191_11125(loc5);
		}
		loc1 = F1116_10132(Current);
		loc2 = F1116_10134(Current);
		loc3 = F1116_10124(Current);
		loc4 = F1116_10125(Current);
		*(EIF_BOOLEAN *)(Current + O8131[dtype-1115]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		F1116_10116(Current, NULL);
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		gtk_widget_hide((GtkWidget*) tp1);
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
		gdk_window_hide((GdkWindow*) tp1);
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		gtk_window_set_default_size((GtkWindow*) tp1, (gint) loc3, (gint) loc4);
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		gtk_window_move((GtkWindow*) tp1, (gint) loc1, (gint) loc2);
	}
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.close */
void F1116_10139 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R8129[dtype-1116])(Current);
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	gtk_window_close((GtkWindow*) tp1);
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.show_modal_to_window */
void F1116_10141 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1190, 0x00), loc1);
	RTCT0("l_window_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	*(EIF_BOOLEAN *)(Current + O8131[dtype-1115]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F1191_11124(RTCW(loc1));
	F1116_10142(Current, arg1);
	F1116_10143(Current);
	*(EIF_BOOLEAN *)(Current + O8131[dtype-1115]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tb1 = F1087_9344(RTCW(loc1));
	if ((EIF_BOOLEAN) !tb1) {
		tb1 = F1115_10108(RTCW(loc1));
		if (tb1) {
			tp1 = *(EIF_POINTER *)(RTCW(loc1) + O8051[Dtype(loc1)-1113]);
			tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
			gdk_window_raise((GdkWindow*) tp1);
		}
	}
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.show_relative_to_window */
void F1116_10142 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1116_10116(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R8105[Dtype(Current)-1116])(Current);
	F1116_10116(Current, arg1);
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.block */
void F1116_10143 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = RTOSCF(10077,F1114_10077, (Current));
	for (;;) {
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8135[Dtype(Current)-1116])(Current)) break;
		F1111_9799(RTCW(loc1), (EIF_BOOLEAN) 1);
	}
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.blocking_condition */
EIF_BOOLEAN F1116_10144 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	if (!F1087_9344(Current)) {
		tb1 = (EIF_BOOLEAN) !F1115_10108(Current);
	}
	if (!tb1) {
		tb1 = F1087_9344(RTCV(RTOSCF(10077,F1114_10077, (Current))));
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {EV_GTK_WINDOW_IMP}.process_key_event */
RTEOMS(10146,3);
void F1116_10147 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc12 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_32 loc13 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc17 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc18 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_8 tc1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(16);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,loc8);
	RTLR(4,loc6);
	RTLR(5,loc15);
	RTLR(6,loc16);
	RTLR(7,tr1);
	RTLR(8,tr2);
	RTLR(9,loc2);
	RTLR(10,loc9);
	RTLR(11,loc14);
	RTLR(12,loc10);
	RTLR(13,loc11);
	RTLR(14,loc19);
	RTLR(15,tr3);
	RTLIU(16);
	
	RTGC;
	loc5 = RTOSCF(10077,F1114_10077, (Current));
	loc1 = (EIF_NATURAL_32) (((GdkEventKey *)arg1)->keyval);
	if ((EIF_BOOLEAN) (loc1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
		if ((EIF_BOOLEAN) !F208_3387(Current, loc1)) {
			if ((EIF_BOOLEAN)(loc1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 268828432L))) {
				loc1 = (EIF_NATURAL_32) GDK_KEY_F11;
			} else {
				if ((EIF_BOOLEAN)(loc1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 268828433L))) {
					loc1 = (EIF_NATURAL_32) GDK_KEY_F12;
				} else {
					loc1 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
				}
			}
		}
		if ((EIF_BOOLEAN) (loc1 > (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L))) {
			loc3 = RTLNS(eif_new_type(1266, 0x00).id, 1266, _OBJSIZ_0_0_0_1_0_0_0_0_);
			ti4_1 = F208_3386(Current, loc1);
			F1267_12648(RTCW(loc3), ti4_1);
		}
	}
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) (((GdkEventKey *)arg1)->type) == (EIF_INTEGER_32) GDK_KEY_PRESS)) {
		loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc8 = Current;
		loc8 = RTRV(eif_new_type(1190, 0x00), loc8);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 != NULL) && (EIF_BOOLEAN)(loc8 != NULL))) {
			loc6 = *(EIF_REFERENCE *)(RTCW(loc8) + O8704[Dtype(loc8)-1182]);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc6 != NULL)) {
				tb2 = F409_4259(RTCW(loc6));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				loc15 = F585_4756(RTCW(loc6), ((EIF_INTEGER_32) 1L));
				if ((EIF_BOOLEAN)(loc15 != NULL)) {
					loc16 = *(EIF_REFERENCE *)(RTCW(loc15) + _REFACS_1_);
					loc16 = RTRV(eif_new_type(1103, 0x00), loc16);
					RTCT0("l_accel_imp /= Void", EX_CHECK);
					if ((EIF_BOOLEAN)(loc16 != NULL)) {
						RTCK0;
					} else {
						RTCF0;
					}
					tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + O8700[Dtype(loc8)-1182]);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
					tb1 = F1112_9931(RTCW(loc5));
					tb2 = F1112_9932(RTCW(loc5));
					tb3 = F1112_9933(RTCW(loc5));
					ti4_1 = F1103_9585(RTCW(loc16), ti4_1, tb1, tb2, tb3);
					loc15 = F578_4624(RTCW(tr1), ti4_1);
					if ((EIF_BOOLEAN)(loc15 != NULL)) {
						loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,865,621,0xFFF9,0,865,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr1 = RTLNTS(typres0.id, 3, 0);
						}
						tr2 = F991_8156(RTCW(loc15));
						((EIF_TYPED_VALUE *)tr1+1)->it_r = tr2;
						RTAR(tr1,tr2);
						
						{
							static EIF_TYPE_INDEX typarr0[] = {939,0xFFF9,0,865,0xFFFF};
							EIF_TYPE typres0;
							static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
							
							typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
							tr2= RTLNRF(typres0.id, (EIF_POINTER) __A225_175, (EIF_POINTER) _A225_175, (EIF_POINTER)(F603_4886),tr1, 1, 0);
						}
						F1111_9845(RTCW(loc5), tr2);
					}
				}
			}
		}
		loc2 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_47_);
		F954_7892(RTCW(loc2));
		tp1 = *(EIF_POINTER *)(RTCW(loc5)+ _PTROFF_49_16_0_20_0_3_);
		loc17 = (EIF_BOOLEAN) EIF_TEST(gtk_im_context_filter_keypress((GtkIMContext*) tp1, (GdkEventKey*) arg1));
		if ((EIF_BOOLEAN) !loc7) {
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				tb2 = F945_7464(RTCW(loc2), ((EIF_INTEGER_32) 1L));
				tb1 = tb2;
			}
			if (tb1) {
				loc13 = F954_7831(RTCW(loc2), ((EIF_INTEGER_32) 1L));
				tb1 = '\0';
				tb2 = '\0';
				tb3 = (loc13 <= 0xFF);
				if (tb3) {
					tc1 = (EIF_CHARACTER_8) loc13;
					tr1 = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
					*(EIF_CHARACTER_8 *)tr1 = tc1;
					tb3 = F897_7231(RTCW(tr1));
					tb2 = (EIF_BOOLEAN) !tb3;
				}
				if (tb2) {
					ti4_1 = (EIF_INTEGER_32) (loc13);
					tb1 = (EIF_BOOLEAN) (ti4_1 <= ((EIF_INTEGER_32) 127L));
				}
				if (tb1) {
					loc2 = (EIF_REFERENCE) NULL;
				}
			} else {
				loc2 = (EIF_REFERENCE) NULL;
			}
			tb1 = '\0';
			tb2 = '\0';
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				tr1 = F1267_12657(RTCW(loc3));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
				tb2 = (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 1L));
			}
			if (tb2) {
				tb2 = F1267_12652(RTCW(loc3));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
				switch (ti4_1) {
					case 39L:
						loc2 = (EIF_REFERENCE) RTOMS(10146,0);
						break;
					case 41L:
						loc2 = (EIF_REFERENCE) RTOMS(10146,1);
						break;
					case 43L:
						loc2 = (EIF_REFERENCE) RTOMS(10146,2);
						break;
					default:
						loc2 = (EIF_REFERENCE) NULL;
						break;
				}
			}
		}
	}
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	tp1 = (EIF_POINTER) gtk_window_get_focus((GtkWindow*) tp1);
	loc9 = F1112_10022(RTCW(loc5), tp1);
	loc9 = RTRV(eif_new_type(1163, 0x00), loc9);
	loc14 = (EIF_REFERENCE) Current;
	if ((EIF_BOOLEAN)(loc9 == NULL)) {
		loc9 = RTCCL(loc14);
		loc9 = RTRV(eif_new_type(1163, 0x00), loc9);
		if ((EIF_BOOLEAN)(loc9 == NULL)) {
			loc10 = RTCCL(loc14);
			loc10 = RTRV(eif_new_type(1153, 0x00), loc10);
		}
	}
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN)(loc9 != NULL)) {
		tb3 = F1137_10410(RTCW(loc9));
		tb2 = tb3;
	}
	if (tb2) {
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8514[Dtype(RTCW(loc9))-1176])(loc9);
		tb1 = tb2;
	}
	if (tb1) {
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			loc12 = F1163_10676(RTCW(loc9), loc3);
			if ((EIF_BOOLEAN) !loc12) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
				loc18 = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 43L));
				if (loc18) {
					tb1 = F1112_9933(RTCW(loc5));
					if (tb1) {
						F1111_9870(RTCW(loc5), ((EIF_NATURAL_8) 2U));
					} else {
						F1111_9870(RTCW(loc5), ((EIF_NATURAL_8) 1U));
					}
				}
				loc11 = loc9;
				loc11 = RTRV(eif_new_type(1112, 0x00), loc11);
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc11 != NULL)) {
					tb2 = *(EIF_BOOLEAN *)(RTCW(loc11) + O8984[Dtype(loc11)-1209]);
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) {
					loc12 = '\01';
					tb1 = F1267_12655(RTCW(loc3));
					if (!tb1) {
						loc12 = loc18;
					}
				}
			}
		}
		if ((EIF_BOOLEAN) !loc12) {
			gtk_main_do_event((GdkEvent*) arg1);
		}
		tb1 = '\0';
		tb2 = '\0';
		tb3 = '\0';
		tr1 = F1112_10007(RTCW(loc5));
		loc19 = tr1;
		if (EIF_TEST(loc19)) {
			tb3 = loc4;
		}
		if (tb3) {
			tb2 = (EIF_BOOLEAN)(loc3 != NULL);
		}
		if (tb2) {
			tb2 = '\01';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
			if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 42L))) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_0_0_0_0_);
				tb2 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 96L));
			}
			tb1 = tb2;
		}
		if (tb1) {
			tr8_1 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
			tr8_2 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
			tr8_3 = (EIF_REAL_64) (((EIF_INTEGER_32) 0L));
			F1162_10642(loc19, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), tr8_1, tr8_2, tr8_3, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
		} else {
			if (loc4) {
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_14_);
					tb1 = (EIF_BOOLEAN)(tr1 != NULL);
				}
				if (tb1) {
					tr1 = F99_2430(RTCW(loc5));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,865,1026,1266,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNTS(typres0.id, 3, 0);
					}
					tr3 = F1087_9345(RTCW(loc9));
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					((EIF_TYPED_VALUE *)tr2+2)->it_r = loc3;
					RTAR(tr2,loc3);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4354[Dtype(RTCW(tr1))-601])(tr1, tr2);
				}
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc2 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_15_);
					tb1 = (EIF_BOOLEAN)(tr1 != NULL);
				}
				if (tb1) {
					tr1 = F99_2432(RTCW(loc5));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,865,1026,953,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNTS(typres0.id, 3, 0);
					}
					tr3 = F1087_9345(RTCW(loc9));
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					((EIF_TYPED_VALUE *)tr2+2)->it_r = loc2;
					RTAR(tr2,loc2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4354[Dtype(RTCW(tr1))-601])(tr1, tr2);
				}
			} else {
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_16_);
					tb1 = (EIF_BOOLEAN)(tr1 != NULL);
				}
				if (tb1) {
					tr1 = F99_2434(RTCW(loc5));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,865,1026,1266,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr2 = RTLNTS(typres0.id, 3, 0);
					}
					tr3 = F1087_9345(RTCW(loc9));
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					((EIF_TYPED_VALUE *)tr2+2)->it_r = loc3;
					RTAR(tr2,loc3);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4354[Dtype(RTCW(tr1))-601])(tr1, tr2);
				}
			}
			if ((EIF_BOOLEAN) !loc12) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R8137[dtype-1116])(Current, loc3, loc2, loc4);
			}
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc9 != loc14)) {
				tb2 = F1087_9344(RTCW(loc9));
				tb1 = (EIF_BOOLEAN) !tb2;
			}
			if (tb1) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN)) R8537[Dtype(RTCW(loc9))-1176])(loc9, loc3, loc2, loc4);
			}
		}
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc10 != NULL) && loc4)) {
			F1154_10508(RTCW(loc10), loc3, loc2, loc4);
		}
		gtk_main_do_event((GdkEvent*) arg1);
	}
	if (loc18) {
		F1111_9870(RTCW(loc5), ((EIF_NATURAL_8) 0U));
	}
	RTLE;
}

/* {EV_GTK_WINDOW_IMP}.on_size_allocate */
void F1116_10149 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O8125[Dtype(Current)-1115]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_GTK_WINDOW_IMP}.forbid_resize */
void F1116_10150 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (EIF_POINTER) calloc (sizeof(GdkGeometry), 1);
	loc2 = F1116_10124(Current);
	loc3 = F1116_10125(Current);
	(((GdkGeometry *)loc1)->max_width = (gint)(loc2));
	(((GdkGeometry *)loc1)->max_height = (gint)(loc3));
	(((GdkGeometry *)loc1)->min_width = (gint)(loc2));
	(((GdkGeometry *)loc1)->min_height = (gint)(loc3));
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	tp2 = F1_33(Current);
	ti4_1 = (EIF_INTEGER_32) GDK_HINT_MAX_SIZE;
	ti4_2 = (EIF_INTEGER_32) GDK_HINT_MIN_SIZE;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	gtk_window_set_geometry_hints((GtkWindow*) tp1, (GtkWidget*) tp2, (GdkGeometry*) loc1, (GdkWindowHints) ti4_1);
	free(loc1);
	RTLE;
}

void EIF_Minit472 (void)
{
	GTCX
	RTPOMS32(10146,2,"\011\000\000\000",1,9);
	RTPOMS32(10146,1,"\012\000\000\000",1,10);
	RTPOMS32(10146,0," \000\000\000",1,32);
}


#ifdef __cplusplus
}
#endif
