/*
 * Code for class EV_COLOR_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev461.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_COLOR_I}.default_name */

EIF_REFERENCE F1105_9627 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (9627,RTMS32_EX_H("n\000\000\000o\000\000\000n\000\000\000a\000\000\000m\000\000\000e\000\000\000",6,2069000037));
}

void EIF_Minit461 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
