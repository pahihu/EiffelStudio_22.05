/*
 * Code for class EV_SENSITIVE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev489.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SENSITIVE_IMP}.is_sensitive */
EIF_BOOLEAN F1137_10410 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1087_9344(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_sensitive((GtkWidget*) tp1));
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {EV_SENSITIVE_IMP}.enable_sensitive */
void F1137_10411 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	gtk_widget_set_sensitive((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_EVENT_BOX((tp1)))) {
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		gtk_event_box_set_visible_window((GtkEventBox*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	}
	RTLE;
}

/* {EV_SENSITIVE_IMP}.disable_sensitive */
void F1137_10412 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	gtk_widget_set_sensitive((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_EVENT_BOX((tp1)))) {
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		gtk_event_box_set_visible_window((GtkEventBox*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	}
	RTLE;
}

/* {EV_SENSITIVE_IMP}.has_parent */
EIF_BOOLEAN F1137_10414 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8349[Dtype(Current)-1176])(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 != NULL);
	RTLE;
	return Result;
}

/* {EV_SENSITIVE_IMP}.parent_is_sensitive */
EIF_BOOLEAN F1137_10416 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8349[Dtype(Current)-1176])(Current);
	loc1 = RTRV(eif_new_type(1025, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tb1 = F1026_8647(RTCW(loc1));
		RTLE;
		return (EIF_BOOLEAN) tb1;
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

void EIF_Minit489 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
