/*
 * Code for class EV_GTK_WIDGET_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev471.h"
#include <string.h>
#include <ev_gtk.h>
#include <ev_any_imp.h>
#include "eif_helpers.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F81_1662
static void inline_F81_1662 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	gtk_widget_get_size_request ((GtkWidget*) arg1, (gint*) arg2, (gint*) arg3)
	;
}
#define INLINE_F81_1662
#endif
#ifndef INLINE_F80_1240
static void inline_F80_1240 (EIF_POINTER arg1)
{
	g_object_unref((gpointer) arg1)
	;
}
#define INLINE_F80_1240
#endif
#ifndef INLINE_F1114_10054
static EIF_REFERENCE inline_F1114_10054 (EIF_POINTER arg1)
{
	return (EIF_REFERENCE) (c_ev_any_imp_get_eif_reference_from_object_id (arg1))
	;
}
#define INLINE_F1114_10054
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_WIDGET_IMP}.gdk_events_mask */
static EIF_INTEGER_32 F1115_10078_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	

	
	RTEV;
	RTGC;
	RTOSP (10078);
#define Result RTOSR(10078)
	ti4_1 = (EIF_INTEGER_32) GDK_EXPOSURE_MASK;
	ti4_2 = (EIF_INTEGER_32) GDK_POINTER_MOTION_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_BUTTON_PRESS_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_BUTTON_RELEASE_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_KEY_PRESS_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_KEY_RELEASE_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_ENTER_NOTIFY_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_LEAVE_NOTIFY_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_FOCUS_CHANGE_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_VISIBILITY_NOTIFY_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_POINTER_MOTION_HINT_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_SCROLL_MASK;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	ti4_2 = (EIF_INTEGER_32) GDK_STRUCTURE_MASK;
	Result = eif_bit_or(ti4_1,ti4_2);
	RTOSE (10078);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1115_10078 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10078,F1115_10078_body,(Current));
}

/* {EV_GTK_WIDGET_IMP}.make */
void F1115_10079 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8075[dtype-1116])(Current);
	loc2 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	ti4_1 = RTOSCF(10078,F1115_10078, (Current));
	gtk_widget_add_events((GtkWidget*) loc1, (gint) ti4_1);
	if ((EIF_BOOLEAN)(loc1 != loc2)) {
		ti4_1 = RTOSCF(10078,F1115_10078, (Current));
		gtk_widget_add_events((GtkWidget*) loc2, (gint) ti4_1);
	}
	if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((loc2)))) {
		gtk_widget_realize((GtkWidget*) loc2);
	} else {
		gtk_widget_show((GtkWidget*) loc2);
	}
	F1087_9359(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_GTK_WIDGET_IMP}.screen_x */
EIF_INTEGER_32 F1115_10080 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8107[dtype-1116])(Current)) {
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8075[dtype-1116])(Current);
		tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
		loc2 = (EIF_INTEGER_32) gdk_window_get_origin((GdkWindow*) tp1, (gint*) (EIF_INTEGER_32 *) &(loc1), (gint*) loc3);
		Result = (EIF_INTEGER_32) loc1;
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(10077,F1114_10077, (Current)))+ _LNGOFF_49_16_0_11_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.screen_y */
EIF_INTEGER_32 F1115_10081 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8107[dtype-1116])(Current)) {
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8075[dtype-1116])(Current);
		tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
		loc2 = (EIF_INTEGER_32) gdk_window_get_origin((GdkWindow*) tp1, (gint*) loc3, (gint*) (EIF_INTEGER_32 *) &(loc1));
		Result = (EIF_INTEGER_32) loc1;
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(10077,F1114_10077, (Current)))+ _LNGOFF_49_16_0_12_);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.widget_imp_at_pointer_position */
EIF_REFERENCE F1115_10084 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = F1112_10023(RTCV(RTOSCF(10077,F1114_10077, (Current))));
	RTLE;
	return RTRV(eif_new_type(1163, 0x00), Result);
}

/* {EV_GTK_WIDGET_IMP}.minimum_width */
EIF_INTEGER_32 F1115_10085 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8085[Dtype(Current)-1116])(Current);
}

/* {EV_GTK_WIDGET_IMP}.minimum_height */
EIF_INTEGER_32 F1115_10086 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8086[Dtype(Current)-1116])(Current);
}

/* {EV_GTK_WIDGET_IMP}.real_minimum_width */
EIF_INTEGER_32 F1115_10087 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1087_9344(Current)) {
		Result = F1115_10089(Current);
		loc1 = F1115_10091(Current);
		if ((EIF_BOOLEAN) (loc1 > Result)) {
			Result = (EIF_INTEGER_32) loc1;
		}
		if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
			RTLE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
	}
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.real_minimum_height */
EIF_INTEGER_32 F1115_10088 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1087_9344(Current)) {
		Result = F1115_10090(Current);
		loc1 = F1115_10092(Current);
		if ((EIF_BOOLEAN) (loc1 > Result)) {
			Result = (EIF_INTEGER_32) loc1;
		}
		if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
			RTLE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
	}
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.width_request */
EIF_INTEGER_32 F1115_10089 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	tp2 = F1_33(Current);
	inline_F81_1662(tp1, (EIF_INTEGER_32 *) &(Result), tp2);
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.height_request */
EIF_INTEGER_32 F1115_10090 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	tp2 = F1_33(Current);
	inline_F81_1662(tp1, tp2, (EIF_INTEGER_32 *) &(Result));
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.preferred_minimum_width */
EIF_INTEGER_32 F1115_10091 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = *(EIF_POINTER *)(RTCV(RTOSCF(10095,F1115_10095, (Current)))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	gtk_widget_get_preferred_size((GtkWidget*) tp1, (GtkRequisition*) loc1, (GtkRequisition*) loc2);
	RTLE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (((GtkRequisition *)loc1)->width);
}

/* {EV_GTK_WIDGET_IMP}.preferred_minimum_height */
EIF_INTEGER_32 F1115_10092 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = *(EIF_POINTER *)(RTCV(RTOSCF(10095,F1115_10095, (Current)))+ _PTROFF_0_1_0_1_0_0_);
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	gtk_widget_get_preferred_size((GtkWidget*) tp1, (GtkRequisition*) loc1, (GtkRequisition*) loc2);
	RTLE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (((GtkRequisition *)loc1)->height);
}

/* {EV_GTK_WIDGET_IMP}.reusable_requisition_struct */
static EIF_REFERENCE F1115_10095_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10095);
#define Result RTOSR(10095)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(820, 0x00).id, 820, _OBJSIZ_0_1_0_1_0_1_1_0_);
	ti4_1 = (EIF_INTEGER_32) sizeof(GtkRequisition);
	F821_5443(RTCW(tr1), ti4_1);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10095);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1115_10095 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10095,F1115_10095_body,(Current));
}

/* {EV_GTK_WIDGET_IMP}.event_widget */
EIF_POINTER F1115_10096 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8075[dtype-1116])(Current);
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_widget_get_has_window((GtkWidget*) loc1))) {
		RTLE;
		return (EIF_POINTER) loc1;
	} else {
		RTLE;
		return (EIF_POINTER) *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	}/* NOTREACHED */
	
}

/* {EV_GTK_WIDGET_IMP}.set_pointer_style */
void F1115_10097 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != *(EIF_REFERENCE *)(Current + O8098[dtype-1114]))) {
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8107[dtype-1116])(Current)) {
			F1115_10098(Current, arg1);
		}
		RTAR(Current, arg1);
		*(EIF_REFERENCE *)(Current + O8098[dtype-1114]) = (EIF_REFERENCE) arg1;
	}
	RTLE;
}

/* {EV_GTK_WIDGET_IMP}.internal_set_pointer_style */
void F1115_10098 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != *(EIF_REFERENCE *)(Current + O8097[dtype-1114]))) {
		RTCT0("attached {EV_POINTER_STYLE_IMP} a_cursor.implementation as a_cursor_imp", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1098, 0x00),loc3);
		if (EIF_TEST(loc3)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		loc2 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
		tb1 = !loc2;
		if ((EIF_BOOLEAN) !tb1) {
			loc1 = F1099_9531(loc3);
			gdk_window_set_cursor((GdkWindow*) loc2, (GdkCursor*) loc1);
			inline_F80_1240(loc1);
			RTAR(Current, arg1);
			*(EIF_REFERENCE *)(Current + O8097[dtype-1114]) = (EIF_REFERENCE) arg1;
		}
	}
	RTLE;
}

/* {EV_GTK_WIDGET_IMP}.pointer_style */
EIF_REFERENCE F1115_10100 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O8098[Dtype(Current)-1114]);
}


/* {EV_GTK_WIDGET_IMP}.set_focus */
void F1115_10101 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8101[dtype-1116])(Current)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R8100[dtype-1116])(Current);
	}
	RTLE;
}

/* {EV_GTK_WIDGET_IMP}.internal_set_focus */
void F1115_10102 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	loc4 = RTOSCF(10077,F1114_10077, (Current));
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_29_);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		tb2 = F1112_10006(RTCW(loc4));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		loc3 = F1087_9345(Current);
		if ((EIF_BOOLEAN)(loc3 != loc5)) {
			F1027_8671(loc5);
		}
	}
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((tp1)))) {
		loc1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	} else {
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		loc1 = (EIF_POINTER) gtk_widget_get_toplevel((GtkWidget*) tp1);
		loc2 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8075[dtype-1116])(Current);
		if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_widget_get_can_focus((GtkWidget*) loc2))) {
			loc2 = F1_33(Current);
		}
	}
	gtk_window_set_focus((GtkWindow*) loc1, (GtkWidget*) loc2);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc2 != F1_33(Current))) {
		tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(gtk_widget_is_focus((GtkWidget*) loc2));
	}
	if (tb1) {
		gtk_widget_grab_focus((GtkWidget*) loc2);
	}
	RTLE;
}

/* {EV_GTK_WIDGET_IMP}.has_focus */
EIF_BOOLEAN F1115_10103 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F1115_10113(Current, (EIF_BOOLEAN) 1);
}

/* {EV_GTK_WIDGET_IMP}.width */
EIF_INTEGER_32 F1115_10104 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8085[dtype-1116])(Current);
	tb1 = '\01';
	if (!F1115_10108(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((tp1)));
	}
	if (tb1) {
		ti4_1 = (EIF_INTEGER_32) sizeof(GtkAllocation);
		tp1 = malloc((size_t)ti4_1);
		loc3 = (EIF_POINTER) tp1;
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc3);
		loc2 = (EIF_INTEGER_32) (((GtkAllocation *)loc3)->width);
		tb1 = '\0';
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		if ((EIF_BOOLEAN)((EIF_POINTER) gtk_widget_get_parent((GtkWidget*) tp1) != F1_33(Current))) {
			tb1 = (EIF_BOOLEAN) (loc2 < loc1);
		}
		if (tb1) {
			tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
			gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc3);
			loc2 = (EIF_INTEGER_32) (((GtkAllocation *)loc3)->width);
		}
		free(loc3);
	}
	ti4_1 = eif_max_int32 (loc1,loc2);
	RTLE;
	return (EIF_INTEGER_32) ti4_1;
}

/* {EV_GTK_WIDGET_IMP}.height */
EIF_INTEGER_32 F1115_10105 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8086[dtype-1116])(Current);
	tb1 = '\01';
	if (!F1115_10108(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		tb1 = (EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((tp1)));
	}
	if (tb1) {
		ti4_1 = (EIF_INTEGER_32) sizeof(GtkAllocation);
		tp1 = malloc((size_t)ti4_1);
		loc3 = (EIF_POINTER) tp1;
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc3);
		loc2 = (EIF_INTEGER_32) (((GtkAllocation *)loc3)->height);
		tb1 = '\0';
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		if ((EIF_BOOLEAN)((EIF_POINTER) gtk_widget_get_parent((GtkWidget*) tp1) != F1_33(Current))) {
			tb1 = (EIF_BOOLEAN) (loc2 < loc1);
		}
		if (tb1) {
			tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
			gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc3);
			loc2 = (EIF_INTEGER_32) (((GtkAllocation *)loc3)->height);
		}
		free(loc3);
	}
	ti4_1 = eif_max_int32 (loc1,loc2);
	RTLE;
	return (EIF_INTEGER_32) ti4_1;
}

/* {EV_GTK_WIDGET_IMP}.show */
void F1115_10107 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	gtk_widget_show((GtkWidget*) tp1);
}

/* {EV_GTK_WIDGET_IMP}.is_show_requested */
EIF_BOOLEAN F1115_10108 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	return (EIF_BOOLEAN) (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_visible((GtkWidget*) tp1));
}

/* {EV_GTK_WIDGET_IMP}.is_displayed */
EIF_BOOLEAN F1115_10109 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O8051[dtype-1113]) != F1_33(Current))) {
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_mapped((GtkWidget*) tp1));
	}
	if (Result) {
		loc1 = F1115_10111(Current);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tp1 = *(EIF_POINTER *)(RTCW(loc1) + O8051[Dtype(loc1)-1113]);
			Result = (EIF_BOOLEAN) EIF_TEST(gtk_widget_get_mapped((GtkWidget*) tp1));
		}
	}
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.top_level_gtk_window_imp */
EIF_REFERENCE F1115_10110 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	loc1 = (EIF_POINTER) gtk_widget_get_toplevel((GtkWidget*) tp1);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTLNTY2(eif_new_type(1115, 0x00), 0x00);
		tr2 = inline_F1114_10054(loc1);
		Result = F835_6203(tr1, tr2);
	}
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.top_level_window_imp */
EIF_REFERENCE F1115_10111 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNTY2(eif_new_type(1190, 0x00), 0x00);
	tr2 = F1115_10110(Current);
	Result = F835_6203(tr1, tr2);
	RTLE;
	return Result;
}

/* {EV_GTK_WIDGET_IMP}.top_level_window */
EIF_REFERENCE F1115_10112 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1115_10110(Current);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1190, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1 + O7519[Dtype(loc1)-1086]);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {EV_GTK_WIDGET_IMP}.has_focus_internal */
EIF_BOOLEAN F1115_10113 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	loc1 = (EIF_POINTER) gtk_widget_get_toplevel((GtkWidget*) tp1);
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN)(loc1 != F1_33(Current))) {
		tb2 = (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_toplevel((GtkWidget*) loc1));
	}
	if (tb2) {
		tb2 = '\01';
		if (arg1) {
			tb2 = (EIF_BOOLEAN) EIF_TEST(gtk_window_is_active((GtkWindow*) loc1));
		}
		tb1 = tb2;
	}
	if (tb1) {
		loc2 = (EIF_POINTER) gtk_window_get_focus((GtkWindow*) loc1);
		if ((EIF_BOOLEAN)(loc2 != F1_33(Current))) {
			tr1 = RTOSCF(10077,F1114_10077, (Current));
			loc3 = F1112_10022(RTCW(tr1), loc2);
			loc3 = RTRV(eif_new_type(1163, 0x00), loc3);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				RTLE;
				return (EIF_BOOLEAN) (EIF_BOOLEAN)(loc3 == Current);
			}
		}
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

void EIF_Minit471 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
