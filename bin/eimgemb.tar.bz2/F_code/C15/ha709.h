
#ifndef _C15_ha709_
#define _C15_ha709_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F757_5323(EIF_REFERENCE);
extern EIF_REFERENCE F757_5324(EIF_REFERENCE);
extern EIF_BOOLEAN F757_5326(EIF_REFERENCE);
extern void F757_5327(EIF_REFERENCE);
extern EIF_REFERENCE F757_5328(EIF_REFERENCE);
extern void EIF_Minit709(void);
extern char *(*R4674[])();
extern char *(*R4527[])();
extern char *(*R4257[])();
extern char *(*R4256[])();
extern char *(*R4087[])();
extern long O4265[];
extern long O4266[];

#ifdef __cplusplus
}
#endif

#endif
