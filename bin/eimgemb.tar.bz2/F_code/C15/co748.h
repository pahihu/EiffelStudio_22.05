
#ifndef _C15_co748_
#define _C15_co748_

#ifdef __cplusplus
extern "C" {
#endif

extern void F313_4210(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit748(void);
extern char *(*R3906[])();
extern char *(*R4040[])();

#ifdef __cplusplus
}
#endif

#endif
