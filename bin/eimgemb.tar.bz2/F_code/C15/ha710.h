
#ifndef _C15_ha710_
#define _C15_ha710_

#ifdef __cplusplus
extern "C" {
#endif

extern void F574_4618(EIF_REFERENCE, EIF_INTEGER_32);
extern void F574_4621(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F574_4622(EIF_REFERENCE);
extern EIF_REFERENCE F574_4624(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F574_4626(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F574_4628(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F574_4630(EIF_REFERENCE);
extern EIF_REFERENCE F574_4631(EIF_REFERENCE);
extern EIF_REFERENCE F574_4632(EIF_REFERENCE);
extern EIF_REFERENCE F574_4633(EIF_REFERENCE);
extern EIF_REFERENCE F574_4634(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F574_4635(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F574_4636(EIF_REFERENCE);
extern EIF_INTEGER_32 F574_4639(EIF_REFERENCE);
extern EIF_INTEGER_32 F574_4640(EIF_REFERENCE);
extern EIF_BOOLEAN F574_4641(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F574_4642(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F574_4650(EIF_REFERENCE);
extern EIF_BOOLEAN F574_4651(EIF_REFERENCE);
extern EIF_BOOLEAN F574_4652(EIF_REFERENCE);
extern EIF_BOOLEAN F574_4653(EIF_REFERENCE);
extern EIF_BOOLEAN F574_4654(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F574_4656(EIF_REFERENCE, EIF_INTEGER_32);
extern void F574_4657(EIF_REFERENCE);
extern void F574_4658(EIF_REFERENCE);
extern void F574_4659(EIF_REFERENCE, EIF_REFERENCE);
extern void F574_4660(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F574_4662(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F574_4663(EIF_REFERENCE, EIF_INTEGER_32);
extern void F574_4664(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F574_4665(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F574_4670(EIF_REFERENCE, EIF_REFERENCE);
extern void F574_4671(EIF_REFERENCE, EIF_REFERENCE);
extern void F574_4672(EIF_REFERENCE);
extern EIF_REFERENCE F574_4674(EIF_REFERENCE);
extern void F574_4675(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F574_4676(EIF_REFERENCE, EIF_INTEGER_32);
extern void F574_4677(EIF_REFERENCE);
extern EIF_INTEGER_32 F574_4686(EIF_REFERENCE);
extern EIF_BOOLEAN F574_4687(EIF_REFERENCE);
extern EIF_REFERENCE F574_4694(EIF_REFERENCE);
extern EIF_REFERENCE F574_4695(EIF_REFERENCE);
extern EIF_INTEGER_32 F574_4696(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F574_4697(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F574_4698(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F574_4699(EIF_REFERENCE, EIF_INTEGER_32);
extern void F574_4700(EIF_REFERENCE, EIF_REFERENCE);
extern void F574_4702(EIF_REFERENCE, EIF_REFERENCE);
extern void F574_4703(EIF_REFERENCE, EIF_REFERENCE);
extern void F574_4704(EIF_REFERENCE, EIF_REFERENCE);
extern void F574_4708(EIF_REFERENCE, EIF_REFERENCE);
extern void F574_4714(EIF_REFERENCE);
extern void F574_4727(EIF_REFERENCE);
extern void EIF_Minit710(void);
extern EIF_BOOLEAN F642_5083(EIF_REFERENCE, EIF_INTEGER_32);
extern void F642_5081(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F205_3279(EIF_REFERENCE, EIF_INTEGER_32);
extern void F642_5105(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F637_5098(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_REFERENCE F572_4585(EIF_REFERENCE);
extern void F637_5081(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F572_4584(EIF_REFERENCE);
extern EIF_INTEGER_32 F637_5083(EIF_REFERENCE, EIF_INTEGER_32);
extern void F642_5099(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern void F637_5102(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F642_5098(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32);
extern EIF_INTEGER_32 F642_5092(EIF_REFERENCE);
extern EIF_INTEGER_32 F710_5263(EIF_REFERENCE, EIF_INTEGER_32);
extern void F642_5102(EIF_REFERENCE, EIF_BOOLEAN, EIF_INTEGER_32, EIF_INTEGER_32);
RTOSHF(EIF_REFERENCE,4585)
extern char *(*R4282[])();
extern char *(*R4283[])();
extern char *(*R4284[])();
extern char *(*R4285[])();
extern char *(*R4286[])();
extern char *(*R4051[])();
extern char *(*R4288[])();
extern char *(*R4289[])();
extern char *(*R4677[])();
extern char *(*R4248[])();
extern char *(*R4620[])();
extern char *(*R4038[])();
extern char *(*R4555[])();
extern char *(*R4245[])();
extern char *(*R4290[])();
extern char *(*R4246[])();
extern char *(*R4680[])();
extern char *(*R4294[])();
extern char *(*R4252[])();
extern char *(*R4254[])();
extern char *(*R4527[])();
extern char *(*R4257[])();
extern char *(*R3911[])();
extern char *(*R4251[])();
extern char *(*R4247[])();
extern char *(*R3860[])();
extern char *(*R4542[])();
extern char *(*R4329[])();
extern char *(*R4561[])();
extern char *(*R4263[])();
extern char *(*R4528[])();
extern char *(*R4225[])();
extern char *(*R4300[])();
extern char *(*R4228[])();
extern char *(*R4229[])();
extern char *(*R5287[])();
extern char *(*R4619[])();
extern char *(*R4541[])();
extern char *(*R4256[])();
extern char *(*R4272[])();
extern char *(*R4273[])();
extern char *(*R4662[])();
extern char *(*R4618[])();
extern char *(*R4234[])();
extern char *(*R4235[])();
extern char *(*R4237[])();
extern char *(*R4239[])();
extern char *(*R4313[])();
extern char *(*R4087[])();
extern char *(*R4048[])();
extern long O4229[];
extern long O4270[];
extern long O4271[];
extern long O4274[];
extern long O4275[];
extern long O4279[];
extern long O4238[];
extern long O4315[];
extern long O4280[];
extern long O4281[];
extern long O3909[];
extern long O4265[];
extern long O4266[];
extern long O4267[];
extern long O4268[];
extern long O4269[];
extern EIF_TYPE_INDEX Y4265[];
extern EIF_TYPE_INDEX *Y4265_gen_type [];
extern EIF_TYPE_INDEX Y4266[];
extern EIF_TYPE_INDEX *Y4266_gen_type [];
extern EIF_TYPE_INDEX Y3861[];
extern EIF_TYPE_INDEX *Y3861_gen_type [];
extern EIF_TYPE_INDEX Y4050[];
extern EIF_TYPE_INDEX *Y4050_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
