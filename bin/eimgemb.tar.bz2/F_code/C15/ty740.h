
#ifndef _C15_ty740_
#define _C15_ty740_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F732_5289(EIF_REFERENCE);
extern void EIF_Minit740(void);
extern char *(*R4678[])();
extern char *(*R4665[])();
extern char *(*R4087[])();

#ifdef __cplusplus
}
#endif

#endif
