
#ifndef _C15_dy711_
#define _C15_dy711_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F353_4225(EIF_REFERENCE);
extern void EIF_Minit711(void);

#ifdef __cplusplus
}
#endif

#endif
