/*
 * Code for class LINEAR [CHARACTER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "li727.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LINEAR}.has */
EIF_BOOLEAN F288_4183 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F587_4780(Current);
	if ((EIF_BOOLEAN) !F519_4470(Current)) {
		F587_4786(Current, arg1);
	}
	Result = F288_4189(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {LINEAR}.search */
void F288_4185 (EIF_REFERENCE Current, EIF_CHARACTER_32 arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_)) {
		for (;;) {
			tb1 = '\01';
			if (!F288_4189(Current)) {
				tb1 = (arg1 == F587_4754(Current));
			}
			if (tb1) break;
			F587_4782(Current);
		}
	} else {
		for (;;) {
			tb2 = '\01';
			if (!F288_4189(Current)) {
				tb2 = (EIF_BOOLEAN)(arg1 == F587_4754(Current));
			}
			if (tb2) break;
			F587_4782(Current);
		}
	}
	RTLE;
}

/* {LINEAR}.exhausted */
EIF_BOOLEAN F288_4189 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F519_4470(Current);
}

/* {LINEAR}.off */
EIF_BOOLEAN F288_4191 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	if (!F410_4259(Current)) {
		Result = F543_4494(Current);
	}
	RTLE;
	return Result;
}

/* {LINEAR}.linear_representation */
EIF_REFERENCE F288_4198 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) Current;
}

void EIF_Minit727 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
