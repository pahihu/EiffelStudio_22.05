
#ifndef _C15_fi733_
#define _C15_fi733_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F410_4259(EIF_REFERENCE);
extern void EIF_Minit733(void);
extern char *(*R4064[])();

#ifdef __cplusplus
}
#endif

#endif
