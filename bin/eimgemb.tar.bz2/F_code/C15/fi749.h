
#ifndef _C15_fi749_
#define _C15_fi749_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F411_4259(EIF_REFERENCE);
extern void EIF_Minit749(void);
extern char *(*R4064[])();

#ifdef __cplusplus
}
#endif

#endif
