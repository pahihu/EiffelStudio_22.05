
#ifndef _C15_co732_
#define _C15_co732_

#ifdef __cplusplus
extern "C" {
#endif

extern void F312_4210(EIF_REFERENCE, EIF_CHARACTER_32);
extern void EIF_Minit732(void);
extern char *(*R3906[])();
extern char *(*R4040[])();

#ifdef __cplusplus
}
#endif

#endif
