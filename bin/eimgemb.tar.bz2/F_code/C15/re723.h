
#ifndef _C15_re723_
#define _C15_re723_

#ifdef __cplusplus
extern "C" {
#endif

extern void F743_5295(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F743_5297(EIF_REFERENCE);
extern EIF_INTEGER_32 F743_5298(EIF_REFERENCE);
extern EIF_INTEGER_32 F743_5299(EIF_REFERENCE);
extern EIF_INTEGER_32 F743_5300(EIF_REFERENCE);
extern EIF_BOOLEAN F743_5307(EIF_REFERENCE);
extern EIF_BOOLEAN F743_5308(EIF_REFERENCE);
extern EIF_BOOLEAN F743_5309(EIF_REFERENCE);
extern void F743_5314(EIF_REFERENCE);
extern void F743_5315(EIF_REFERENCE);
extern EIF_REFERENCE F743_5316(EIF_REFERENCE);
extern void EIF_Minit723(void);
extern char *(*R4091[])();
extern char *(*R4088[])();
extern char *(*R4089[])();

#ifdef __cplusplus
}
#endif

#endif
