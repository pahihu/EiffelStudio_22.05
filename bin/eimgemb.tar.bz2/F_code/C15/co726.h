
#ifndef _C15_co726_
#define _C15_co726_

#ifdef __cplusplus
extern "C" {
#endif

extern void F261_4030(EIF_REFERENCE);
extern void F261_4031(EIF_REFERENCE);
extern void EIF_Minit726(void);
extern long O3909[];

#ifdef __cplusplus
}
#endif

#endif
