
#ifndef _C15_ev715_
#define _C15_ev715_

#ifdef __cplusplus
extern "C" {
#endif

extern void F201_3270(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN);
extern EIF_REFERENCE F201_3272(EIF_REFERENCE);
extern void EIF_Minit715(void);

#ifdef __cplusplus
}
#endif

#endif
