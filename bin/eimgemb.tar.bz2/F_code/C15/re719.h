
#ifndef _C15_re719_
#define _C15_re719_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F479_4321(EIF_REFERENCE);
extern void EIF_Minit719(void);
extern void F743_5295(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4677[])();
extern EIF_TYPE_INDEX Y3861[];
extern EIF_TYPE_INDEX *Y3861_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
