/*
 * Code for class CONTAINER [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co742.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CONTAINER}.compare_objects */
void F262_4030 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O3909[Dtype(Current)-259]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {CONTAINER}.compare_references */
void F262_4031 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O3909[Dtype(Current)-259]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

void EIF_Minit742 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
