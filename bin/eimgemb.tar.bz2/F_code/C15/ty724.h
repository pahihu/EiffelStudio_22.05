
#ifndef _C15_ty724_
#define _C15_ty724_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F731_5289(EIF_REFERENCE);
extern void EIF_Minit724(void);
extern char *(*R4678[])();
extern char *(*R4665[])();
extern char *(*R4087[])();

#ifdef __cplusplus
}
#endif

#endif
