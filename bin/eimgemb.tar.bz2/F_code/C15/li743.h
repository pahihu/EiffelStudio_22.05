
#ifndef _C15_li743_
#define _C15_li743_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F289_4183(EIF_REFERENCE, EIF_CHARACTER_8);
extern void F289_4185(EIF_REFERENCE, EIF_CHARACTER_8);
extern EIF_BOOLEAN F289_4189(EIF_REFERENCE);
extern EIF_BOOLEAN F289_4191(EIF_REFERENCE);
extern EIF_REFERENCE F289_4198(EIF_REFERENCE);
extern void EIF_Minit743(void);
extern char *(*R4016[])();
extern char *(*R4017[])();
extern char *(*R4018[])();
extern char *(*R3907[])();
extern char *(*R4024[])();
extern char *(*R4029[])();
extern char *(*R4031[])();
extern long O3909[];

#ifdef __cplusplus
}
#endif

#endif
