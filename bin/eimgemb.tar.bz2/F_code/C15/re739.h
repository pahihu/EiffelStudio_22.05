
#ifndef _C15_re739_
#define _C15_re739_

#ifdef __cplusplus
extern "C" {
#endif

extern void F744_5295(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F744_5297(EIF_REFERENCE);
extern EIF_INTEGER_32 F744_5298(EIF_REFERENCE);
extern EIF_INTEGER_32 F744_5299(EIF_REFERENCE);
extern EIF_INTEGER_32 F744_5300(EIF_REFERENCE);
extern EIF_BOOLEAN F744_5307(EIF_REFERENCE);
extern EIF_BOOLEAN F744_5308(EIF_REFERENCE);
extern EIF_BOOLEAN F744_5309(EIF_REFERENCE);
extern void F744_5314(EIF_REFERENCE);
extern void F744_5315(EIF_REFERENCE);
extern EIF_REFERENCE F744_5316(EIF_REFERENCE);
extern void EIF_Minit739(void);
extern char *(*R4091[])();
extern char *(*R4088[])();
extern char *(*R4089[])();

#ifdef __cplusplus
}
#endif

#endif
