
#ifndef _C15_co742_
#define _C15_co742_

#ifdef __cplusplus
extern "C" {
#endif

extern void F262_4030(EIF_REFERENCE);
extern void F262_4031(EIF_REFERENCE);
extern void EIF_Minit742(void);
extern long O3909[];

#ifdef __cplusplus
}
#endif

#endif
