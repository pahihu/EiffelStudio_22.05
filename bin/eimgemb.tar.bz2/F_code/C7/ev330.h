
#ifndef _C7_ev330_
#define _C7_ev330_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F972_7970(EIF_REFERENCE);
extern void EIF_Minit330(void);
extern EIF_REFERENCE F73_1138(EIF_REFERENCE);
extern char *(*R6491[])();

#ifdef __cplusplus
}
#endif

#endif
