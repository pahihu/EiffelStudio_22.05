
#ifndef _C7_ev333_
#define _C7_ev333_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F975_7980(EIF_REFERENCE);
extern void EIF_Minit333(void);
extern EIF_REFERENCE F86_2282(EIF_REFERENCE);
extern char *(*R6498[])();

#ifdef __cplusplus
}
#endif

#endif
