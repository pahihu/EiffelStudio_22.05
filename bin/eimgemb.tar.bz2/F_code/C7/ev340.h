
#ifndef _C7_ev340_
#define _C7_ev340_

#ifdef __cplusplus
extern "C" {
#endif

extern void F982_8029(EIF_REFERENCE);
extern void F982_8032(EIF_REFERENCE);
extern EIF_BOOLEAN F982_8033(EIF_REFERENCE);
extern void F982_8038(EIF_REFERENCE);
extern void F982_8039(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,8041)
static EIF_REFERENCE F982_8041_body(EIF_REFERENCE);
extern EIF_REFERENCE F982_8041(EIF_REFERENCE);
extern void EIF_Minit340(void);
extern EIF_BOOLEAN F1087_9344(EIF_REFERENCE);
extern void F1087_9342(EIF_REFERENCE);
extern void F1087_9354(EIF_REFERENCE, EIF_INTEGER_8, EIF_BOOLEAN);
extern void F1087_9339(EIF_REFERENCE, EIF_REFERENCE);
extern void F1102_9561(EIF_REFERENCE);
extern char *(*R6557[])();
extern char *(*R6558[])();
extern char *(*R6559[])();
extern long O6555[];

#ifdef __cplusplus
}
#endif

#endif
