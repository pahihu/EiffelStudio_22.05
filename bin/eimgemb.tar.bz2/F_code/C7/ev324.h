
#ifndef _C7_ev324_
#define _C7_ev324_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F966_7951(EIF_REFERENCE);
extern void EIF_Minit324(void);
extern EIF_REFERENCE F67_1122(EIF_REFERENCE);
extern char *(*R6472[])();

#ifdef __cplusplus
}
#endif

#endif
