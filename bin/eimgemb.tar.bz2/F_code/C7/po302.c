/*
 * Code for class reference POINTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "po302.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {POINTER}.hash_code */
EIF_INTEGER_32 F937_7394 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F906_7368(Current);
}

/* {POINTER}.is_default_pointer */
EIF_BOOLEAN F937_7395 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F906_7373(Current);
}

/* {POINTER}.plus */
EIF_POINTER F937_7396 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_POINTER) F906_7374(Current, arg1);
}

/* {POINTER}.out */
EIF_REFERENCE F937_7398 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F906_7385(Current);
}

void EIF_Minit302 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
