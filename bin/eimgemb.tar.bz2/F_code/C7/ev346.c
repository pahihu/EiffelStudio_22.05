/*
 * Code for class EV_POINTER_STYLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev346.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_POINTER_STYLE}.make_predefined */
void F988_8120 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F982_8029(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1099_9521(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_POINTER_STYLE}.set_x_hotspot */
void F988_8123 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1099_9523(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_POINTER_STYLE}.set_y_hotspot */
void F988_8124 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1099_9524(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_POINTER_STYLE}.x_hotspot */
EIF_INTEGER_32 F988_8125 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE}.y_hotspot */
EIF_INTEGER_32 F988_8126 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_1_);
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE}.width */
EIF_INTEGER_32 F988_8127 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1099_9526(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE}.height */
EIF_INTEGER_32 F988_8128 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1099_9527(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE}.copy */
void F988_8129 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) == NULL)) {
		F982_8029(Current);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1099_9536(RTCW(tr1), arg1);
	ti4_1 = F988_8125(RTCW(arg1));
	F988_8123(Current, ti4_1);
	ti4_1 = F988_8126(RTCW(arg1));
	F988_8124(Current, ti4_1);
	RTLE;
}

/* {EV_POINTER_STYLE}.is_equal */
EIF_BOOLEAN F988_8130 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		Result = '\0';
		ti4_1 = F988_8128(RTCW(arg1));
		ti4_2 = F988_8127(RTCW(arg1));
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) (F988_8127(Current) * ti4_1) == (EIF_INTEGER_32) (ti4_2 * F988_8128(Current)))) {
			tb1 = '\0';
			ti4_1 = F988_8125(RTCW(arg1));
			if ((EIF_BOOLEAN)(ti4_1 == F988_8125(Current))) {
				ti4_1 = F988_8126(RTCW(arg1));
				tb1 = (EIF_BOOLEAN)(ti4_1 == F988_8126(Current));
			}
			Result = tb1;
		}
	}
	RTLE;
	return Result;
}

/* {EV_POINTER_STYLE}.create_interface_objects */
void F988_8131 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_POINTER_STYLE}.create_implementation */
void F988_8132 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1098, 0x00).id, 1098, _OBJSIZ_1_1_0_3_0_1_0_0_);
	F1099_9519(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit346 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
