
#ifndef _C7_ev328_
#define _C7_ev328_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F970_7966(EIF_REFERENCE);
extern void EIF_Minit328(void);
extern EIF_REFERENCE F70_1129(EIF_REFERENCE);
extern char *(*R6487[])();

#ifdef __cplusplus
}
#endif

#endif
