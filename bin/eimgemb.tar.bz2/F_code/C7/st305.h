
#ifndef _C7_st305_
#define _C7_st305_

#ifdef __cplusplus
extern "C" {
#endif

extern void F947_7550(EIF_REFERENCE);
extern void F947_7552(EIF_REFERENCE, EIF_NATURAL_32);
extern void F947_7563(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit305(void);
extern char *(*R6192[])();
extern char *(*R6193[])();
extern char *(*R6155[])();
extern char *(*R6281[])();
extern char *(*R6248[])();
extern char *(*R6251[])();
extern long O6245[];
extern long O6246[];

#ifdef __cplusplus
}
#endif

#endif
