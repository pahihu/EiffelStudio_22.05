
#ifndef _C7_ev337_
#define _C7_ev337_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F979_8004(EIF_REFERENCE);
extern void EIF_Minit337(void);
extern EIF_REFERENCE F94_2378(EIF_REFERENCE);
extern long O6555[];

#ifdef __cplusplus
}
#endif

#endif
