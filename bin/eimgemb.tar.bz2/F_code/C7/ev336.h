
#ifndef _C7_ev336_
#define _C7_ev336_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F978_8002(EIF_REFERENCE);
extern void EIF_Minit336(void);
extern EIF_REFERENCE F1223_11792(EIF_REFERENCE);
extern long O6555[];

#ifdef __cplusplus
}
#endif

#endif
