/*
 * Code for class EV_ANY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev340.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ANY}.default_create */
void F982_8029 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6558[dtype-984])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6557[dtype-984])(Current);
	
	tr1 = *(EIF_REFERENCE *)(Current + O6555[dtype-981]);
	F1087_9354(RTCW(tr1), ((EIF_INTEGER_8) 4L), (EIF_BOOLEAN) 1);
	tr1 = *(EIF_REFERENCE *)(Current + O6555[dtype-981]);
	F1087_9339(RTCW(tr1), Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R6559[dtype-984])(Current);
	RTLE;
}

/* {EV_ANY}.destroy */
void F982_8032 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O6555[Dtype(Current)-981]);
	F1087_9342(RTCW(tr1));
	RTLE;
}

/* {EV_ANY}.is_destroyed */
EIF_BOOLEAN F982_8033 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O6555[Dtype(Current)-981]);
	Result = F1087_9344(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_ANY}.initialize */
void F982_8038 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O6555[Dtype(Current)-981]);
	F1087_9354(RTCW(tr1), ((EIF_INTEGER_8) 5L), (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_ANY}.copy */
void F982_8039 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
	RTCT0("can_copy_this_vision2_class", EX_CHECK);
		RTCF0;
}

/* {EV_ANY}.environment_i */
static EIF_REFERENCE F982_8041_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (8041);
#define Result RTOSR(8041)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1101, 0x00).id, 1101, _OBJSIZ_1_1_0_1_0_0_0_0_);
	F1102_9561(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (8041);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F982_8041 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(8041,F982_8041_body,(Current));
}

void EIF_Minit340 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
