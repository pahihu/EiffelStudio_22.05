
#ifndef _C7_ev348_
#define _C7_ev348_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F990_8141(EIF_REFERENCE);
extern void F990_8153(EIF_REFERENCE);
extern void F990_8154(EIF_REFERENCE);
extern void EIF_Minit348(void);
extern EIF_REFERENCE F982_8041(EIF_REFERENCE);
extern EIF_REFERENCE F1101_9543(EIF_REFERENCE);
extern void F1087_9354(EIF_REFERENCE, EIF_INTEGER_8, EIF_BOOLEAN);
extern void F1087_9359(EIF_REFERENCE, EIF_BOOLEAN);
RTOSHF(EIF_REFERENCE,8041)

#ifdef __cplusplus
}
#endif

#endif
