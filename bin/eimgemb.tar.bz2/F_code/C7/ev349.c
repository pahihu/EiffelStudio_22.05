/*
 * Code for class EV_ACCELERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev349.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ACCELERATOR}.make_with_key_combination */
void F991_8155 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2, EIF_BOOLEAN arg3, EIF_BOOLEAN arg4)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F982_8029(Current);
	F991_8162(Current, arg1);
	if (arg2) {
		F991_8167(Current);
	}
	if (arg3) {
		F991_8165(Current);
	}
	if (arg4) {
		F991_8163(Current);
	}
	RTLE;
}

/* {EV_ACCELERATOR}.actions */
EIF_REFERENCE F991_8156 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1103_9576(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.key */
EIF_REFERENCE F991_8158 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_2_);
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.shift_required */
EIF_BOOLEAN F991_8159 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_3_);
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.alt_required */
EIF_BOOLEAN F991_8160 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_2_);
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.control_required */
EIF_BOOLEAN F991_8161 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_1_);
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.set_key */
void F991_8162 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1104_9594(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_ACCELERATOR}.enable_shift_required */
void F991_8163 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1104_9595(RTCW(tr1));
	RTLE;
}

/* {EV_ACCELERATOR}.enable_alt_required */
void F991_8165 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1104_9597(RTCW(tr1));
	RTLE;
}

/* {EV_ACCELERATOR}.enable_control_required */
void F991_8167 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F1104_9599(RTCW(tr1));
	RTLE;
}

/* {EV_ACCELERATOR}.is_equal */
EIF_BOOLEAN F991_8169 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = '\0';
	tr1 = F991_8158(Current);
	tr2 = F991_8158(RTCW(arg1));
	tb3 = (EIF_BOOLEAN) eif_builtin_ANY_is_equal__o_b (tr1, tr2);
	if (tb3) {
		tb3 = F991_8160(RTCW(arg1));
		tb2 = (EIF_BOOLEAN)(F991_8160(Current) == tb3);
	}
	if (tb2) {
		tb2 = F991_8159(RTCW(arg1));
		tb1 = (EIF_BOOLEAN)(F991_8159(Current) == tb2);
	}
	if (tb1) {
		tb1 = F991_8161(RTCW(arg1));
		Result = (EIF_BOOLEAN)(F991_8161(Current) == tb1);
	}
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.text */
EIF_REFERENCE F991_8170 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(953, 0x00).id, 953, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F952_7748(RTCW(Result), ((EIF_INTEGER_32) 0L));
	if (F991_8161(Current)) {
		tr1 = F945_7511(RTMS_EX_H("Ctrl+",5,1954170411));
		F954_7863(RTCW(Result), tr1);
	}
	if (F991_8160(Current)) {
		tr1 = F945_7511(RTMS_EX_H("Alt+",4,1097626667));
		F954_7863(RTCW(Result), tr1);
	}
	if (F991_8159(Current)) {
		tr1 = F945_7511(RTMS_EX_H("Shift+",6,1932305451));
		F954_7863(RTCW(Result), tr1);
	}
	loc1 = F1267_12657(RTCV(F991_8158(Current)));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L))) {
		F954_7905(RTCW(loc1));
	}
	F954_7863(RTCW(Result), loc1);
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.out */
EIF_REFERENCE F991_8171 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F945_7506(RTCV(F991_8170(Current)));
	RTLE;
	return Result;
}

/* {EV_ACCELERATOR}.create_interface_objects */
void F991_8173 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_ACCELERATOR}.create_implementation */
void F991_8174 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1103, 0x00).id, 1103, _OBJSIZ_3_5_0_0_0_0_0_0_);
	F1104_9589(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit349 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
