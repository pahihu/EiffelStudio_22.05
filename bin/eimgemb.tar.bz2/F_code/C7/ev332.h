
#ifndef _C7_ev332_
#define _C7_ev332_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F974_7975(EIF_REFERENCE);
extern void EIF_Minit332(void);
extern EIF_REFERENCE F77_1155(EIF_REFERENCE);
extern char *(*R6496[])();

#ifdef __cplusplus
}
#endif

#endif
