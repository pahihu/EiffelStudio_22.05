
#ifndef _C7_ev339_
#define _C7_ev339_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F981_8028(EIF_REFERENCE);
extern void EIF_Minit339(void);
extern EIF_REFERENCE F115_2640(EIF_REFERENCE);
extern char *(*R6549[])();

#ifdef __cplusplus
}
#endif

#endif
