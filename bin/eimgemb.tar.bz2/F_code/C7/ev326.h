
#ifndef _C7_ev326_
#define _C7_ev326_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F968_7961(EIF_REFERENCE);
extern void EIF_Minit326(void);
extern EIF_BOOLEAN F409_4259(EIF_REFERENCE);
extern void F831_6099(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F89_2303(EIF_REFERENCE);
extern char *(*R6479[])();

#ifdef __cplusplus
}
#endif

#endif
