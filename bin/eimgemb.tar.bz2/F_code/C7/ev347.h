
#ifndef _C7_ev347_
#define _C7_ev347_

#ifdef __cplusplus
extern "C" {
#endif

extern void F989_8136(EIF_REFERENCE, EIF_REFERENCE);
extern void F989_8139(EIF_REFERENCE);
extern void F989_8140(EIF_REFERENCE);
extern void EIF_Minit347(void);
extern void F1152_10490(EIF_REFERENCE, EIF_REFERENCE);
extern void F1152_10487(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
