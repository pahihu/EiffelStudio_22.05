
#ifndef _C7_ev338_
#define _C7_ev338_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F980_8009(EIF_REFERENCE);
extern void EIF_Minit338(void);
extern EIF_REFERENCE F99_2408(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
