
#ifndef _C7_ev343_
#define _C7_ev343_

#ifdef __cplusplus
extern "C" {
#endif

extern void F985_8094(EIF_REFERENCE, EIF_INTEGER_32);
extern void F985_8098(EIF_REFERENCE);
extern void F985_8099(EIF_REFERENCE);
extern void EIF_Minit343(void);
extern void F1093_9465(EIF_REFERENCE);
extern void F602_4849(EIF_REFERENCE);
extern void F1093_9467(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
