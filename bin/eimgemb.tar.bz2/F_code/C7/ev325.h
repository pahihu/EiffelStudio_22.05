
#ifndef _C7_ev325_
#define _C7_ev325_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F967_7954(EIF_REFERENCE);
extern void EIF_Minit325(void);
extern EIF_REFERENCE F75_1144(EIF_REFERENCE);
extern char *(*R6475[])();

#ifdef __cplusplus
}
#endif

#endif
