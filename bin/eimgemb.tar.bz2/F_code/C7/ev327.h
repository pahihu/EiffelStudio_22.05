
#ifndef _C7_ev327_
#define _C7_ev327_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F969_7964(EIF_REFERENCE);
extern void EIF_Minit327(void);
extern EIF_REFERENCE F69_1126(EIF_REFERENCE);
extern long O6555[];

#ifdef __cplusplus
}
#endif

#endif
