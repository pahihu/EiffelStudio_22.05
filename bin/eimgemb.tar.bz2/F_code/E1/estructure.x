#ifndef _estructure_h_
#define _estructure_h_

#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

struct eif_ex_33 {union overhead overhead; char data [1];};
struct eif_ex_261 {union overhead overhead; char data [@OBJSIZ(0,0,0,1,0,0,0,0)];};
struct eif_ex_264 {union overhead overhead; char data [@OBJSIZ(0,0,1,0,0,0,0,0)];};
struct eif_ex_267 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_270 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,0,1,0)];};
struct eif_ex_273 {union overhead overhead; char data [@OBJSIZ(0,0,0,1,0,0,0,0)];};
struct eif_ex_276 {union overhead overhead; char data [@OBJSIZ(0,0,1,0,0,0,0,0)];};
struct eif_ex_279 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_282 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,1,0,0,0)];};
struct eif_ex_285 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,0,0,1)];};
struct eif_ex_288 {union overhead overhead; char data [@OBJSIZ(0,0,0,1,0,0,0,0)];};
struct eif_ex_291 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_294 {union overhead overhead; char data [@OBJSIZ(0,1,0,0,0,0,0,0)];};
struct eif_ex_297 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,0,1,0)];};
struct eif_ex_629 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_681 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_701 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_806 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_825 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_831 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_835 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_839 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_843 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_847 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_875 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_950 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_954 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_958 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_962 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};
struct eif_ex_300 {union overhead overhead; char data [@OBJSIZ(0,0,0,0,0,1,0,0)];};

#ifdef __cplusplus
}
#endif
#endif
