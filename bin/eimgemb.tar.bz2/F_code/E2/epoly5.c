#include "epoly5.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R3913[993])();
void R3913_init () {
	R3913[0] = (char *(*)()) F272_4085;
	R3913[230] = (char *(*)()) F504_4427;
	R3913[231] = (char *(*)()) F505_4427;
	R3913[232] = (char *(*)()) F506_4427;
	R3913[233] = (char *(*)()) F507_4427;
	R3913[234] = (char *(*)()) F508_4427;
	R3913[235] = (char *(*)()) F509_4427;
	R3913[236] = (char *(*)()) F510_4427;
	R3913[237] = (char *(*)()) F511_4427;
	R3913[238] = (char *(*)()) F512_4427;
	R3913[239] = (char *(*)()) F513_4427;
	R3913[240] = (char *(*)()) F514_4427;
	R3913[241] = (char *(*)()) F515_4427;
	R3913[291] = (char *(*)()) F287_4198;
	R3913[292] = (char *(*)()) F292_4198;
	R3913[293] = (char *(*)()) F296_4198;
	R3913[294] = (char *(*)()) F568_4557;
	R3913[295] = (char *(*)()) F569_4557;
	R3913[296] = (char *(*)()) F570_4557;
	R3913[297] = (char *(*)()) F571_4571;
	R3913[300] = (char *(*)()) F574_4674;
	R3913[301] = (char *(*)()) F575_4674;
	R3913[302] = (char *(*)()) F576_4674;
	R3913[303] = (char *(*)()) F577_4674;
	R3913[304] = (char *(*)()) F578_4674;
	R3913[305] = (char *(*)()) F579_4674;
	R3913[306] = (char *(*)()) F580_4674;
	R3913[307] = (char *(*)()) F574_4674;
	R3913[308] = (char *(*)()) F579_4674;
	R3913[309] = (char *(*)()) F575_4674;
	R3913[310] = (char *(*)()) F574_4674;
	R3913[311] = (char *(*)()) F287_4198;
	R3913[312] = (char *(*)()) F290_4198;
	R3913[313] = (char *(*)()) F288_4198;
	R3913[314] = (char *(*)()) F289_4198;
	R3913[315] = (char *(*)()) F292_4198;
	R3913[316] = (char *(*)()) F291_4198;
	R3913[317] = (char *(*)()) F293_4198;
	R3913[318] = (char *(*)()) F294_4198;
	R3913[319] = (char *(*)()) F295_4198;
	R3913[320] = (char *(*)()) F296_4198;
	R3913[321] = (char *(*)()) F297_4198;
	R3913[322] = (char *(*)()) F298_4198;
	{long i; for (i = 328; i < 331; i++) R3913[i] = (char *(*)()) F287_4198;}
	{long i; for (i = 337; i < 340; i++) R3913[i] = (char *(*)()) F287_4198;}
	R3913[341] = (char *(*)()) F287_4198;
	R3913[344] = (char *(*)()) F287_4198;
	{long i; for (i = 346; i < 349; i++) R3913[i] = (char *(*)()) F287_4198;}
	R3913[351] = (char *(*)()) F287_4198;
	R3913[352] = (char *(*)()) F292_4198;
	R3913[353] = (char *(*)()) F287_4198;
	R3913[435] = (char *(*)()) F287_4198;
	R3913[436] = (char *(*)()) F408_4252;
	{long i; for (i = 550; i < 552; i++) R3913[i] = (char *(*)()) F289_4198;}
	R3913[676] = (char *(*)()) F950_7738;
	R3913[680] = (char *(*)()) F954_7906;
	{long i; for (i = 759; i < 761; i++) R3913[i] = (char *(*)()) F287_4198;}
	{long i; for (i = 761; i < 763; i++) R3913[i] = (char *(*)()) F1035_8783;}
	{long i; for (i = 764; i < 766; i++) R3913[i] = (char *(*)()) F1035_8783;}
	{long i; for (i = 768; i < 772; i++) R3913[i] = (char *(*)()) F1035_8783;}
	{long i; for (i = 773; i < 775; i++) R3913[i] = (char *(*)()) F1035_8783;}
	R3913[801] = (char *(*)()) F287_4198;
	R3913[810] = (char *(*)()) F287_4198;
	R3913[992] = (char *(*)()) F289_4198;
}

EIF_TYPE_INDEX *Y3920_gen_type [3];
EIF_TYPE_INDEX Y3920 [3];
void Y3920_init (void)
{
	egc_routines_types [3920] = Y3920;
	egc_routines_gen_types [3920] = Y3920_gen_type;
	egc_routines_offset [3920] = 271;
	{long i; for (i = 0; i < 3; i++) Y3920[i] = 868;};
}

char *(*R4016[702])();
void R4016_init () {
	R4016[0] = (char *(*)()) F565_4507;
	R4016[1] = (char *(*)()) F566_4507_4016_1;
	R4016[2] = (char *(*)()) F567_4507_4016_1;
	R4016[3] = (char *(*)()) F565_4507;
	R4016[4] = (char *(*)()) F567_4507_4016_1;
	R4016[5] = (char *(*)()) F566_4507_4016_1;
	R4016[6] = (char *(*)()) F565_4507;
	R4016[20] = (char *(*)()) F585_4754;
	R4016[21] = (char *(*)()) F586_4754_4016_1;
	R4016[22] = (char *(*)()) F587_4754_4016_1;
	R4016[23] = (char *(*)()) F588_4754_4016_1;
	R4016[24] = (char *(*)()) F589_4754_4016_1;
	R4016[25] = (char *(*)()) F590_4754_4016_1;
	R4016[26] = (char *(*)()) F591_4754_4016_1;
	R4016[27] = (char *(*)()) F592_4754_4016_1;
	R4016[28] = (char *(*)()) F593_4754_4016_1;
	R4016[29] = (char *(*)()) F594_4754_4016_1;
	R4016[30] = (char *(*)()) F595_4754_4016_1;
	R4016[31] = (char *(*)()) F596_4754_4016_1;
	{long i; for (i = 37; i < 40; i++) R4016[i] = (char *(*)()) F585_4754;}
	{long i; for (i = 46; i < 49; i++) R4016[i] = (char *(*)()) F585_4754;}
	R4016[50] = (char *(*)()) F585_4754;
	R4016[53] = (char *(*)()) F585_4754;
	{long i; for (i = 55; i < 58; i++) R4016[i] = (char *(*)()) F585_4754;}
	R4016[60] = (char *(*)()) F585_4754;
	R4016[61] = (char *(*)()) F589_4754_4016_1;
	R4016[62] = (char *(*)()) F585_4754;
	R4016[144] = (char *(*)()) F709_5248;
	R4016[145] = (char *(*)()) F408_4241_4016_1;
	{long i; for (i = 259; i < 261; i++) R4016[i] = (char *(*)()) F823_5645_4016_1;}
	{long i; for (i = 468; i < 470; i++) R4016[i] = (char *(*)()) F1025_8602;}
	R4016[510] = (char *(*)()) F1025_8602;
	R4016[519] = (char *(*)()) F1025_8602;
	R4016[701] = (char *(*)()) F823_5645_4016_1;
}
static EIF_REFERENCE F566_4507_4016_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F566_4507(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F567_4507_4016_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F567_4507(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F586_4754_4016_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F586_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_4754_4016_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F587_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_4754_4016_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F588_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_4754_4016_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F589_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F590_4754_4016_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F590_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F591_4754_4016_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F591_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F592_4754_4016_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F592_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(877, 0x00).id, 877, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F593_4754_4016_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F593_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F594_4754_4016_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F594_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F595_4754_4016_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F595_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F596_4754_4016_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F596_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(892, 0x00).id, 892, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F408_4241_4016_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F408_4241(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F823_5645_4016_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F823_5645(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4017[702])();
void R4017_init () {
	R4017[0] = (char *(*)()) F565_4518;
	R4017[1] = (char *(*)()) F566_4518;
	R4017[2] = (char *(*)()) F567_4518;
	R4017[3] = (char *(*)()) F565_4518;
	R4017[4] = (char *(*)()) F567_4518;
	R4017[5] = (char *(*)()) F566_4518;
	R4017[6] = (char *(*)()) F565_4518;
	R4017[20] = (char *(*)()) F517_4470;
	R4017[21] = (char *(*)()) F518_4470;
	R4017[22] = (char *(*)()) F519_4470;
	R4017[23] = (char *(*)()) F520_4470;
	R4017[24] = (char *(*)()) F521_4470;
	R4017[25] = (char *(*)()) F522_4470;
	R4017[26] = (char *(*)()) F523_4470;
	R4017[27] = (char *(*)()) F524_4470;
	R4017[28] = (char *(*)()) F525_4470;
	R4017[29] = (char *(*)()) F526_4470;
	R4017[30] = (char *(*)()) F527_4470;
	R4017[31] = (char *(*)()) F528_4470;
	{long i; for (i = 37; i < 40; i++) R4017[i] = (char *(*)()) F517_4470;}
	{long i; for (i = 46; i < 49; i++) R4017[i] = (char *(*)()) F517_4470;}
	R4017[50] = (char *(*)()) F517_4470;
	R4017[53] = (char *(*)()) F517_4470;
	{long i; for (i = 55; i < 58; i++) R4017[i] = (char *(*)()) F517_4470;}
	R4017[60] = (char *(*)()) F517_4470;
	R4017[61] = (char *(*)()) F521_4470;
	R4017[62] = (char *(*)()) F517_4470;
	R4017[144] = (char *(*)()) F299_4199;
	R4017[145] = (char *(*)()) F292_4191;
	{long i; for (i = 259; i < 261; i++) R4017[i] = (char *(*)()) F823_5666;}
	{long i; for (i = 468; i < 470; i++) R4017[i] = (char *(*)()) F517_4470;}
	R4017[510] = (char *(*)()) F517_4470;
	R4017[519] = (char *(*)()) F517_4470;
	R4017[701] = (char *(*)()) F823_5666;
}

char *(*R4018[702])();
void R4018_init () {
	R4018[0] = (char *(*)()) F565_4524;
	R4018[1] = (char *(*)()) F566_4524;
	R4018[2] = (char *(*)()) F567_4524;
	R4018[3] = (char *(*)()) F565_4524;
	R4018[4] = (char *(*)()) F567_4524;
	R4018[5] = (char *(*)()) F566_4524;
	R4018[6] = (char *(*)()) F565_4524;
	R4018[20] = (char *(*)()) F585_4780;
	R4018[21] = (char *(*)()) F586_4780;
	R4018[22] = (char *(*)()) F587_4780;
	R4018[23] = (char *(*)()) F588_4780;
	R4018[24] = (char *(*)()) F589_4780;
	R4018[25] = (char *(*)()) F590_4780;
	R4018[26] = (char *(*)()) F591_4780;
	R4018[27] = (char *(*)()) F592_4780;
	R4018[28] = (char *(*)()) F593_4780;
	R4018[29] = (char *(*)()) F594_4780;
	R4018[30] = (char *(*)()) F595_4780;
	R4018[31] = (char *(*)()) F596_4780;
	{long i; for (i = 37; i < 40; i++) R4018[i] = (char *(*)()) F585_4780;}
	{long i; for (i = 46; i < 49; i++) R4018[i] = (char *(*)()) F585_4780;}
	R4018[50] = (char *(*)()) F585_4780;
	R4018[53] = (char *(*)()) F585_4780;
	{long i; for (i = 55; i < 58; i++) R4018[i] = (char *(*)()) F585_4780;}
	R4018[60] = (char *(*)()) F585_4780;
	R4018[61] = (char *(*)()) F589_4780;
	R4018[62] = (char *(*)()) F585_4780;
	R4018[144] = (char *(*)()) F709_5242;
	R4018[145] = (char *(*)()) F408_4249;
	{long i; for (i = 259; i < 261; i++) R4018[i] = (char *(*)()) F823_5721;}
	{long i; for (i = 468; i < 470; i++) R4018[i] = (char *(*)()) F1025_8612;}
	R4018[510] = (char *(*)()) F1025_8612;
	R4018[519] = (char *(*)()) F1025_8612;
	R4018[701] = (char *(*)()) F823_5721;
}

char *(*R4024[702])();
void R4024_init () {
	R4024[0] = (char *(*)()) F299_4202;
	R4024[1] = (char *(*)()) F303_4202_4024_4;
	R4024[2] = (char *(*)()) F308_4202_4024_4;
	R4024[3] = (char *(*)()) F299_4202;
	R4024[4] = (char *(*)()) F308_4202_4024_4;
	R4024[5] = (char *(*)()) F303_4202_4024_4;
	R4024[6] = (char *(*)()) F299_4202;
	R4024[20] = (char *(*)()) F585_4786;
	R4024[21] = (char *(*)()) F586_4786_4024_4;
	R4024[22] = (char *(*)()) F587_4786_4024_4;
	R4024[23] = (char *(*)()) F588_4786_4024_4;
	R4024[24] = (char *(*)()) F589_4786_4024_4;
	R4024[25] = (char *(*)()) F590_4786_4024_4;
	R4024[26] = (char *(*)()) F591_4786_4024_4;
	R4024[27] = (char *(*)()) F592_4786_4024_4;
	R4024[28] = (char *(*)()) F593_4786_4024_4;
	R4024[29] = (char *(*)()) F594_4786_4024_4;
	R4024[30] = (char *(*)()) F595_4786_4024_4;
	R4024[31] = (char *(*)()) F596_4786_4024_4;
	{long i; for (i = 37; i < 40; i++) R4024[i] = (char *(*)()) F585_4786;}
	{long i; for (i = 46; i < 49; i++) R4024[i] = (char *(*)()) F585_4786;}
	R4024[50] = (char *(*)()) F585_4786;
	R4024[53] = (char *(*)()) F585_4786;
	{long i; for (i = 55; i < 58; i++) R4024[i] = (char *(*)()) F585_4786;}
	R4024[60] = (char *(*)()) F585_4786;
	R4024[61] = (char *(*)()) F589_4786_4024_4;
	R4024[62] = (char *(*)()) F585_4786;
	R4024[144] = (char *(*)()) F299_4202;
	R4024[145] = (char *(*)()) F292_4185_4024_4;
	{long i; for (i = 259; i < 261; i++) R4024[i] = (char *(*)()) F302_4202_4024_4;}
	{long i; for (i = 468; i < 470; i++) R4024[i] = (char *(*)()) F299_4202;}
	R4024[510] = (char *(*)()) F299_4202;
	R4024[519] = (char *(*)()) F299_4202;
	R4024[701] = (char *(*)()) F302_4202_4024_4;
}
static void F303_4202_4024_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F303_4202(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F308_4202_4024_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F308_4202(Current, *(EIF_BOOLEAN *)arg1);
}
static void F586_4786_4024_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F586_4786(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F587_4786_4024_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F587_4786(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F588_4786_4024_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F588_4786(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F589_4786_4024_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F589_4786(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F590_4786_4024_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F590_4786(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F591_4786_4024_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F591_4786(Current, *(EIF_POINTER *)arg1);
}
static void F592_4786_4024_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F592_4786(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F593_4786_4024_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F593_4786(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F594_4786_4024_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F594_4786(Current, *(EIF_BOOLEAN *)arg1);
}
static void F595_4786_4024_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F595_4786(Current, *(EIF_REAL_32 *)arg1);
}
static void F596_4786_4024_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F596_4786(Current, *(EIF_REAL_64 *)arg1);
}
static void F292_4185_4024_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F292_4185(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F302_4202_4024_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F302_4202(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4025[520])();
void R4025_init () {
	R4025[0] = (char *(*)()) F565_4510;
	R4025[1] = (char *(*)()) F566_4510;
	R4025[2] = (char *(*)()) F567_4510;
	R4025[3] = (char *(*)()) F565_4510;
	R4025[4] = (char *(*)()) F567_4510;
	R4025[5] = (char *(*)()) F566_4510;
	R4025[6] = (char *(*)()) F565_4510;
	R4025[20] = (char *(*)()) F585_4759;
	R4025[21] = (char *(*)()) F586_4759;
	R4025[22] = (char *(*)()) F587_4759;
	R4025[23] = (char *(*)()) F588_4759;
	R4025[24] = (char *(*)()) F589_4759;
	R4025[25] = (char *(*)()) F590_4759;
	R4025[26] = (char *(*)()) F591_4759;
	R4025[27] = (char *(*)()) F592_4759;
	R4025[28] = (char *(*)()) F593_4759;
	R4025[29] = (char *(*)()) F594_4759;
	R4025[30] = (char *(*)()) F595_4759;
	R4025[31] = (char *(*)()) F596_4759;
	{long i; for (i = 37; i < 40; i++) R4025[i] = (char *(*)()) F585_4759;}
	{long i; for (i = 46; i < 49; i++) R4025[i] = (char *(*)()) F585_4759;}
	R4025[50] = (char *(*)()) F585_4759;
	R4025[53] = (char *(*)()) F585_4759;
	{long i; for (i = 55; i < 58; i++) R4025[i] = (char *(*)()) F585_4759;}
	R4025[60] = (char *(*)()) F585_4759;
	R4025[61] = (char *(*)()) F589_4759;
	R4025[62] = (char *(*)()) F585_4759;
	R4025[145] = (char *(*)()) F408_4240;
	{long i; for (i = 468; i < 470; i++) R4025[i] = (char *(*)()) F1025_8603;}
	R4025[510] = (char *(*)()) F1025_8603;
	R4025[519] = (char *(*)()) F1025_8603;
}

char *(*R4028[702])();
void R4028_init () {
	R4028[0] = (char *(*)()) F287_4189;
	R4028[1] = (char *(*)()) F292_4189;
	R4028[2] = (char *(*)()) F296_4189;
	R4028[3] = (char *(*)()) F287_4189;
	R4028[4] = (char *(*)()) F296_4189;
	R4028[5] = (char *(*)()) F292_4189;
	R4028[6] = (char *(*)()) F287_4189;
	R4028[20] = (char *(*)()) F287_4189;
	R4028[21] = (char *(*)()) F290_4189;
	R4028[22] = (char *(*)()) F288_4189;
	R4028[23] = (char *(*)()) F289_4189;
	R4028[24] = (char *(*)()) F292_4189;
	R4028[25] = (char *(*)()) F291_4189;
	R4028[26] = (char *(*)()) F293_4189;
	R4028[27] = (char *(*)()) F294_4189;
	R4028[28] = (char *(*)()) F295_4189;
	R4028[29] = (char *(*)()) F296_4189;
	R4028[30] = (char *(*)()) F297_4189;
	R4028[31] = (char *(*)()) F298_4189;
	{long i; for (i = 37; i < 40; i++) R4028[i] = (char *(*)()) F287_4189;}
	{long i; for (i = 46; i < 49; i++) R4028[i] = (char *(*)()) F287_4189;}
	R4028[50] = (char *(*)()) F287_4189;
	R4028[53] = (char *(*)()) F287_4189;
	{long i; for (i = 55; i < 58; i++) R4028[i] = (char *(*)()) F287_4189;}
	R4028[60] = (char *(*)()) F287_4189;
	R4028[61] = (char *(*)()) F292_4189;
	R4028[62] = (char *(*)()) F287_4189;
	R4028[144] = (char *(*)()) F287_4189;
	R4028[145] = (char *(*)()) F292_4189;
	{long i; for (i = 259; i < 261; i++) R4028[i] = (char *(*)()) F289_4189;}
	{long i; for (i = 468; i < 470; i++) R4028[i] = (char *(*)()) F287_4189;}
	R4028[510] = (char *(*)()) F287_4189;
	R4028[519] = (char *(*)()) F287_4189;
	R4028[701] = (char *(*)()) F289_4189;
}

char *(*R4029[702])();
void R4029_init () {
	R4029[0] = (char *(*)()) F565_4516;
	R4029[1] = (char *(*)()) F566_4516;
	R4029[2] = (char *(*)()) F567_4516;
	R4029[3] = (char *(*)()) F565_4516;
	R4029[4] = (char *(*)()) F567_4516;
	R4029[5] = (char *(*)()) F566_4516;
	R4029[6] = (char *(*)()) F565_4516;
	R4029[20] = (char *(*)()) F541_4494;
	R4029[21] = (char *(*)()) F542_4494;
	R4029[22] = (char *(*)()) F543_4494;
	R4029[23] = (char *(*)()) F544_4494;
	R4029[24] = (char *(*)()) F545_4494;
	R4029[25] = (char *(*)()) F546_4494;
	R4029[26] = (char *(*)()) F547_4494;
	R4029[27] = (char *(*)()) F548_4494;
	R4029[28] = (char *(*)()) F549_4494;
	R4029[29] = (char *(*)()) F550_4494;
	R4029[30] = (char *(*)()) F551_4494;
	R4029[31] = (char *(*)()) F552_4494;
	{long i; for (i = 37; i < 40; i++) R4029[i] = (char *(*)()) F541_4494;}
	{long i; for (i = 46; i < 49; i++) R4029[i] = (char *(*)()) F541_4494;}
	R4029[50] = (char *(*)()) F541_4494;
	R4029[53] = (char *(*)()) F541_4494;
	{long i; for (i = 55; i < 58; i++) R4029[i] = (char *(*)()) F541_4494;}
	R4029[60] = (char *(*)()) F541_4494;
	R4029[61] = (char *(*)()) F545_4494;
	R4029[62] = (char *(*)()) F541_4494;
	R4029[144] = (char *(*)()) F709_5243;
	R4029[145] = (char *(*)()) F408_4242;
	{long i; for (i = 259; i < 261; i++) R4029[i] = (char *(*)()) F823_5664;}
	{long i; for (i = 468; i < 470; i++) R4029[i] = (char *(*)()) F541_4494;}
	R4029[510] = (char *(*)()) F541_4494;
	R4029[519] = (char *(*)()) F541_4494;
	R4029[701] = (char *(*)()) F823_5664;
}

char *(*R4030[520])();
void R4030_init () {
	R4030[0] = (char *(*)()) F565_4525;
	R4030[1] = (char *(*)()) F566_4525;
	R4030[2] = (char *(*)()) F567_4525;
	R4030[3] = (char *(*)()) F565_4525;
	R4030[4] = (char *(*)()) F567_4525;
	R4030[5] = (char *(*)()) F566_4525;
	R4030[6] = (char *(*)()) F565_4525;
	R4030[20] = (char *(*)()) F585_4781;
	R4030[21] = (char *(*)()) F586_4781;
	R4030[22] = (char *(*)()) F587_4781;
	R4030[23] = (char *(*)()) F588_4781;
	R4030[24] = (char *(*)()) F589_4781;
	R4030[25] = (char *(*)()) F590_4781;
	R4030[26] = (char *(*)()) F591_4781;
	R4030[27] = (char *(*)()) F592_4781;
	R4030[28] = (char *(*)()) F593_4781;
	R4030[29] = (char *(*)()) F594_4781;
	R4030[30] = (char *(*)()) F595_4781;
	R4030[31] = (char *(*)()) F596_4781;
	{long i; for (i = 37; i < 40; i++) R4030[i] = (char *(*)()) F585_4781;}
	{long i; for (i = 46; i < 49; i++) R4030[i] = (char *(*)()) F585_4781;}
	R4030[50] = (char *(*)()) F585_4781;
	R4030[53] = (char *(*)()) F585_4781;
	{long i; for (i = 55; i < 58; i++) R4030[i] = (char *(*)()) F585_4781;}
	R4030[60] = (char *(*)()) F585_4781;
	R4030[61] = (char *(*)()) F589_4781;
	R4030[62] = (char *(*)()) F585_4781;
	{long i; for (i = 468; i < 470; i++) R4030[i] = (char *(*)()) F517_4464;}
	R4030[510] = (char *(*)()) F517_4464;
	R4030[519] = (char *(*)()) F517_4464;
}

char *(*R4031[702])();
void R4031_init () {
	R4031[0] = (char *(*)()) F565_4526;
	R4031[1] = (char *(*)()) F566_4526;
	R4031[2] = (char *(*)()) F567_4526;
	R4031[3] = (char *(*)()) F565_4526;
	R4031[4] = (char *(*)()) F567_4526;
	R4031[5] = (char *(*)()) F566_4526;
	R4031[6] = (char *(*)()) F565_4526;
	R4031[20] = (char *(*)()) F585_4782;
	R4031[21] = (char *(*)()) F586_4782;
	R4031[22] = (char *(*)()) F587_4782;
	R4031[23] = (char *(*)()) F588_4782;
	R4031[24] = (char *(*)()) F589_4782;
	R4031[25] = (char *(*)()) F590_4782;
	R4031[26] = (char *(*)()) F591_4782;
	R4031[27] = (char *(*)()) F592_4782;
	R4031[28] = (char *(*)()) F593_4782;
	R4031[29] = (char *(*)()) F594_4782;
	R4031[30] = (char *(*)()) F595_4782;
	R4031[31] = (char *(*)()) F596_4782;
	{long i; for (i = 37; i < 40; i++) R4031[i] = (char *(*)()) F585_4782;}
	{long i; for (i = 46; i < 49; i++) R4031[i] = (char *(*)()) F585_4782;}
	R4031[50] = (char *(*)()) F585_4782;
	R4031[53] = (char *(*)()) F585_4782;
	{long i; for (i = 55; i < 58; i++) R4031[i] = (char *(*)()) F585_4782;}
	R4031[60] = (char *(*)()) F585_4782;
	R4031[61] = (char *(*)()) F589_4782;
	R4031[62] = (char *(*)()) F585_4782;
	R4031[144] = (char *(*)()) F709_5245;
	R4031[145] = (char *(*)()) F408_4248;
	{long i; for (i = 259; i < 261; i++) R4031[i] = (char *(*)()) F823_5723;}
	{long i; for (i = 468; i < 470; i++) R4031[i] = (char *(*)()) F1025_8614;}
	R4031[510] = (char *(*)()) F1025_8614;
	R4031[519] = (char *(*)()) F1025_8614;
	R4031[701] = (char *(*)()) F823_5723;
}

char *(*R4032[702])();
void R4032_init () {
	R4032[0] = (char *(*)()) F565_4517;
	R4032[1] = (char *(*)()) F566_4517;
	R4032[2] = (char *(*)()) F567_4517;
	R4032[3] = (char *(*)()) F565_4517;
	R4032[4] = (char *(*)()) F567_4517;
	R4032[5] = (char *(*)()) F566_4517;
	R4032[6] = (char *(*)()) F565_4517;
	R4032[20] = (char *(*)()) F541_4495;
	R4032[21] = (char *(*)()) F542_4495;
	R4032[22] = (char *(*)()) F543_4495;
	R4032[23] = (char *(*)()) F544_4495;
	R4032[24] = (char *(*)()) F545_4495;
	R4032[25] = (char *(*)()) F546_4495;
	R4032[26] = (char *(*)()) F547_4495;
	R4032[27] = (char *(*)()) F548_4495;
	R4032[28] = (char *(*)()) F549_4495;
	R4032[29] = (char *(*)()) F550_4495;
	R4032[30] = (char *(*)()) F551_4495;
	R4032[31] = (char *(*)()) F552_4495;
	{long i; for (i = 37; i < 40; i++) R4032[i] = (char *(*)()) F541_4495;}
	{long i; for (i = 46; i < 49; i++) R4032[i] = (char *(*)()) F541_4495;}
	R4032[50] = (char *(*)()) F541_4495;
	R4032[53] = (char *(*)()) F541_4495;
	{long i; for (i = 55; i < 58; i++) R4032[i] = (char *(*)()) F541_4495;}
	R4032[60] = (char *(*)()) F541_4495;
	R4032[61] = (char *(*)()) F545_4495;
	R4032[62] = (char *(*)()) F541_4495;
	R4032[144] = (char *(*)()) F709_5246;
	{long i; for (i = 259; i < 261; i++) R4032[i] = (char *(*)()) F823_5665;}
	{long i; for (i = 468; i < 470; i++) R4032[i] = (char *(*)()) F541_4495;}
	R4032[510] = (char *(*)()) F541_4495;
	R4032[519] = (char *(*)()) F541_4495;
	R4032[701] = (char *(*)()) F823_5665;
}

char *(*R4033[682])();
void R4033_init () {
	R4033[0] = (char *(*)()) F585_4783;
	R4033[1] = (char *(*)()) F586_4783;
	R4033[2] = (char *(*)()) F587_4783;
	R4033[3] = (char *(*)()) F588_4783;
	R4033[4] = (char *(*)()) F589_4783;
	R4033[5] = (char *(*)()) F590_4783;
	R4033[6] = (char *(*)()) F591_4783;
	R4033[7] = (char *(*)()) F592_4783;
	R4033[8] = (char *(*)()) F593_4783;
	R4033[9] = (char *(*)()) F594_4783;
	R4033[10] = (char *(*)()) F595_4783;
	R4033[11] = (char *(*)()) F596_4783;
	{long i; for (i = 17; i < 20; i++) R4033[i] = (char *(*)()) F585_4783;}
	{long i; for (i = 26; i < 29; i++) R4033[i] = (char *(*)()) F585_4783;}
	R4033[30] = (char *(*)()) F585_4783;
	R4033[33] = (char *(*)()) F585_4783;
	{long i; for (i = 35; i < 38; i++) R4033[i] = (char *(*)()) F585_4783;}
	R4033[40] = (char *(*)()) F585_4783;
	R4033[41] = (char *(*)()) F589_4783;
	R4033[42] = (char *(*)()) F585_4783;
	{long i; for (i = 239; i < 241; i++) R4033[i] = (char *(*)()) F823_5724;}
	{long i; for (i = 448; i < 450; i++) R4033[i] = (char *(*)()) F1025_8613;}
	R4033[490] = (char *(*)()) F1025_8613;
	R4033[499] = (char *(*)()) F1025_8613;
	R4033[681] = (char *(*)()) F1266_12594;
}

char *(*R4034[520])();
void R4034_init () {
	R4034[0] = (char *(*)()) F529_4479;
	R4034[1] = (char *(*)()) F533_4479;
	R4034[2] = (char *(*)()) F538_4479;
	R4034[3] = (char *(*)()) F529_4479;
	R4034[4] = (char *(*)()) F538_4479;
	R4034[5] = (char *(*)()) F533_4479;
	R4034[6] = (char *(*)()) F529_4479;
	R4034[20] = (char *(*)()) F529_4479;
	R4034[21] = (char *(*)()) F530_4479;
	R4034[22] = (char *(*)()) F531_4479;
	R4034[23] = (char *(*)()) F532_4479;
	R4034[24] = (char *(*)()) F533_4479;
	R4034[25] = (char *(*)()) F534_4479;
	R4034[26] = (char *(*)()) F535_4479;
	R4034[27] = (char *(*)()) F536_4479;
	R4034[28] = (char *(*)()) F537_4479;
	R4034[29] = (char *(*)()) F538_4479;
	R4034[30] = (char *(*)()) F539_4479;
	R4034[31] = (char *(*)()) F540_4479;
	{long i; for (i = 37; i < 40; i++) R4034[i] = (char *(*)()) F529_4479;}
	{long i; for (i = 46; i < 49; i++) R4034[i] = (char *(*)()) F529_4479;}
	R4034[50] = (char *(*)()) F529_4479;
	R4034[53] = (char *(*)()) F529_4479;
	{long i; for (i = 55; i < 58; i++) R4034[i] = (char *(*)()) F529_4479;}
	R4034[60] = (char *(*)()) F529_4479;
	R4034[61] = (char *(*)()) F533_4479;
	R4034[62] = (char *(*)()) F529_4479;
	{long i; for (i = 468; i < 470; i++) R4034[i] = (char *(*)()) F529_4479;}
	R4034[510] = (char *(*)()) F529_4479;
	R4034[519] = (char *(*)()) F529_4479;
}

char *(*R4035[520])();
void R4035_init () {
	R4035[0] = (char *(*)()) F354_4225;
	R4035[1] = (char *(*)()) F359_4225;
	R4035[2] = (char *(*)()) F367_4225;
	R4035[3] = (char *(*)()) F354_4225;
	R4035[4] = (char *(*)()) F367_4225;
	R4035[5] = (char *(*)()) F359_4225;
	R4035[6] = (char *(*)()) F354_4225;
	R4035[9] = (char *(*)()) F353_4225;
	R4035[10] = (char *(*)()) F358_4225;
	R4035[11] = (char *(*)()) F361_4225;
	R4035[12] = (char *(*)()) F362_4225;
	R4035[13] = (char *(*)()) F354_4225;
	R4035[14] = (char *(*)()) F366_4225;
	R4035[15] = (char *(*)()) F359_4225;
	R4035[16] = (char *(*)()) F353_4225;
	R4035[17] = (char *(*)()) F366_4225;
	R4035[18] = (char *(*)()) F358_4225;
	R4035[19] = (char *(*)()) F353_4225;
	R4035[385] = (char *(*)()) F357_4225;
	R4035[389] = (char *(*)()) F356_4225;
	{long i; for (i = 468; i < 470; i++) R4035[i] = (char *(*)()) F354_4225;}
	{long i; for (i = 470; i < 472; i++) R4035[i] = (char *(*)()) F1035_8777;}
	{long i; for (i = 473; i < 475; i++) R4035[i] = (char *(*)()) F1035_8777;}
	{long i; for (i = 477; i < 481; i++) R4035[i] = (char *(*)()) F1035_8777;}
	{long i; for (i = 482; i < 484; i++) R4035[i] = (char *(*)()) F1035_8777;}
	R4035[510] = (char *(*)()) F354_4225;
	R4035[519] = (char *(*)()) F354_4225;
}

char *(*R4038[702])();
void R4038_init () {
	R4038[0] = (char *(*)()) F565_4532;
	R4038[1] = (char *(*)()) F566_4532_4038_4;
	R4038[2] = (char *(*)()) F567_4532_4038_4;
	R4038[3] = (char *(*)()) F568_4554;
	R4038[4] = (char *(*)()) F569_4554_4038_4;
	R4038[5] = (char *(*)()) F570_4554_4038_4;
	R4038[6] = (char *(*)()) F571_4569;
	R4038[20] = (char *(*)()) F585_4790;
	R4038[21] = (char *(*)()) F586_4790_4038_4;
	R4038[22] = (char *(*)()) F587_4790_4038_4;
	R4038[23] = (char *(*)()) F588_4790_4038_4;
	R4038[24] = (char *(*)()) F589_4790_4038_4;
	R4038[25] = (char *(*)()) F590_4790_4038_4;
	R4038[26] = (char *(*)()) F591_4790_4038_4;
	R4038[27] = (char *(*)()) F592_4790_4038_4;
	R4038[28] = (char *(*)()) F593_4790_4038_4;
	R4038[29] = (char *(*)()) F594_4790_4038_4;
	R4038[30] = (char *(*)()) F595_4790_4038_4;
	R4038[31] = (char *(*)()) F596_4790_4038_4;
	{long i; for (i = 37; i < 40; i++) R4038[i] = (char *(*)()) F600_4832;}
	{long i; for (i = 46; i < 49; i++) R4038[i] = (char *(*)()) F600_4832;}
	R4038[50] = (char *(*)()) F600_4832;
	R4038[53] = (char *(*)()) F600_4832;
	{long i; for (i = 55; i < 58; i++) R4038[i] = (char *(*)()) F600_4832;}
	R4038[60] = (char *(*)()) F600_4832;
	R4038[61] = (char *(*)()) F601_4832_4038_4;
	R4038[62] = (char *(*)()) F600_4832;
	{long i; for (i = 259; i < 261; i++) R4038[i] = (char *(*)()) F823_5730_4038_4;}
	R4038[385] = (char *(*)()) F950_7709_4038_4;
	R4038[389] = (char *(*)()) F954_7877_4038_4;
	{long i; for (i = 468; i < 472; i++) R4038[i] = (char *(*)()) F1028_8719;}
	{long i; for (i = 473; i < 475; i++) R4038[i] = (char *(*)()) F1028_8719;}
	{long i; for (i = 477; i < 481; i++) R4038[i] = (char *(*)()) F1028_8719;}
	{long i; for (i = 482; i < 484; i++) R4038[i] = (char *(*)()) F1028_8719;}
	R4038[510] = (char *(*)()) F1025_8638;
	R4038[519] = (char *(*)()) F1025_8638;
	R4038[701] = (char *(*)()) F823_5730_4038_4;
}
static void F566_4532_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F566_4532(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F567_4532_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F567_4532(Current, *(EIF_BOOLEAN *)arg1);
}
static void F569_4554_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F569_4554(Current, *(EIF_BOOLEAN *)arg1);
}
static void F570_4554_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F570_4554(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F586_4790_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F586_4790(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F587_4790_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F587_4790(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F588_4790_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F588_4790(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F589_4790_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F589_4790(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F590_4790_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F590_4790(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F591_4790_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F591_4790(Current, *(EIF_POINTER *)arg1);
}
static void F592_4790_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F592_4790(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F593_4790_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F593_4790(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F594_4790_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F594_4790(Current, *(EIF_BOOLEAN *)arg1);
}
static void F595_4790_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F595_4790(Current, *(EIF_REAL_32 *)arg1);
}
static void F596_4790_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F596_4790(Current, *(EIF_REAL_64 *)arg1);
}
static void F601_4832_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F601_4832(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F823_5730_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F823_5730(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F950_7709_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F950_7709(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F954_7877_4038_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F954_7877(Current, *(EIF_CHARACTER_32 *)arg1);
}


#ifdef __cplusplus
}
#endif
