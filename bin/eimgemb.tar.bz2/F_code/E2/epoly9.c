#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O8065[147];
void O8065_init () {
	O8065[0] = + _CHROFF_2_1_;
	O8065[1] = + _CHROFF_4_1_;
	O8065[2] = + _CHROFF_5_1_;
	O8065[3] = + _CHROFF_10_1_;
	O8065[15] = + _CHROFF_6_1_;
	O8065[40] = + _CHROFF_8_1_;
	{long i; for (i = 44; i < 47; i++) O8065[i] = + _CHROFF_11_1_;}
	O8065[48] = + _CHROFF_16_2_;
	O8065[50] = + _CHROFF_42_2_;
	O8065[52] = + _CHROFF_46_2_;
	O8065[56] = + _CHROFF_47_2_;
	O8065[57] = + _CHROFF_49_2_;
	O8065[58] = + _CHROFF_47_2_;
	{long i; for (i = 62; i < 65; i++) O8065[i] = + _CHROFF_49_2_;}
	O8065[73] = + _CHROFF_49_2_;
	O8065[74] = + _CHROFF_51_2_;
	{long i; for (i = 75; i < 77; i++) O8065[i] = + _CHROFF_49_2_;}
	{long i; for (i = 77; i < 79; i++) O8065[i] = + _CHROFF_59_2_;}
	O8065[79] = + _CHROFF_65_2_;
	O8065[80] = + _CHROFF_68_2_;
	O8065[96] = + _CHROFF_42_2_;
	O8065[97] = + _CHROFF_44_2_;
	O8065[98] = + _CHROFF_51_2_;
	O8065[99] = + _CHROFF_58_2_;
	O8065[100] = + _CHROFF_44_2_;
	O8065[101] = + _CHROFF_45_2_;
	{long i; for (i = 102; i < 104; i++) O8065[i] = + _CHROFF_46_2_;}
	O8065[104] = + _CHROFF_50_2_;
	O8065[105] = + _CHROFF_51_2_;
	O8065[106] = + _CHROFF_43_2_;
	O8065[107] = + _CHROFF_44_2_;
	O8065[108] = + _CHROFF_51_2_;
	O8065[109] = + _CHROFF_46_2_;
	O8065[110] = + _CHROFF_59_2_;
	{long i; for (i = 119; i < 121; i++) O8065[i] = + _CHROFF_21_2_;}
	{long i; for (i = 126; i < 129; i++) O8065[i] = + _CHROFF_23_2_;}
	O8065[129] = + _CHROFF_24_2_;
	O8065[130] = + _CHROFF_26_2_;
	{long i; for (i = 135; i < 137; i++) O8065[i] = + _CHROFF_29_2_;}
	{long i; for (i = 145; i < 147; i++) O8065[i] = + _CHROFF_48_2_;}
}

long O8097[146];
void O8097_init () {
	{long i; for (i = 0; i < 3; i++) O8097[i] =  + _REFACS_2_;}
	O8097[39] =  + _REFACS_4_;
	{long i; for (i = 43; i < 46; i++) O8097[i] =  + _REFACS_4_;}
	O8097[47] =  + _REFACS_9_;
	O8097[49] =  + _REFACS_27_;
	O8097[51] =  + _REFACS_28_;
	O8097[55] =  + _REFACS_28_;
	O8097[56] =  + _REFACS_29_;
	O8097[57] =  + _REFACS_28_;
	{long i; for (i = 61; i < 64; i++) O8097[i] =  + _REFACS_29_;}
	{long i; for (i = 72; i < 76; i++) O8097[i] =  + _REFACS_29_;}
	{long i; for (i = 76; i < 78; i++) O8097[i] =  + _REFACS_33_;}
	{long i; for (i = 78; i < 80; i++) O8097[i] =  + _REFACS_36_;}
	O8097[95] =  + _REFACS_27_;
	O8097[96] =  + _REFACS_28_;
	O8097[97] =  + _REFACS_29_;
	O8097[98] =  + _REFACS_31_;
	O8097[99] =  + _REFACS_27_;
	{long i; for (i = 100; i < 103; i++) O8097[i] =  + _REFACS_28_;}
	{long i; for (i = 103; i < 105; i++) O8097[i] =  + _REFACS_29_;}
	{long i; for (i = 105; i < 107; i++) O8097[i] =  + _REFACS_28_;}
	O8097[107] =  + _REFACS_31_;
	O8097[108] =  + _REFACS_29_;
	O8097[109] =  + _REFACS_33_;
	{long i; for (i = 118; i < 120; i++) O8097[i] =  + _REFACS_12_;}
	{long i; for (i = 125; i < 129; i++) O8097[i] =  + _REFACS_13_;}
	O8097[129] =  + _REFACS_14_;
	{long i; for (i = 134; i < 136; i++) O8097[i] =  + _REFACS_16_;}
	{long i; for (i = 144; i < 146; i++) O8097[i] =  + _REFACS_28_;}
}

long O8098[146];
void O8098_init () {
	{long i; for (i = 0; i < 3; i++) O8098[i] =  + _REFACS_3_;}
	O8098[39] =  + _REFACS_5_;
	{long i; for (i = 43; i < 46; i++) O8098[i] =  + _REFACS_5_;}
	O8098[47] =  + _REFACS_10_;
	O8098[49] =  + _REFACS_28_;
	O8098[51] =  + _REFACS_29_;
	O8098[55] =  + _REFACS_29_;
	O8098[56] =  + _REFACS_30_;
	O8098[57] =  + _REFACS_29_;
	{long i; for (i = 61; i < 64; i++) O8098[i] =  + _REFACS_30_;}
	{long i; for (i = 72; i < 76; i++) O8098[i] =  + _REFACS_30_;}
	{long i; for (i = 76; i < 78; i++) O8098[i] =  + _REFACS_34_;}
	{long i; for (i = 78; i < 80; i++) O8098[i] =  + _REFACS_37_;}
	O8098[95] =  + _REFACS_28_;
	O8098[96] =  + _REFACS_29_;
	O8098[97] =  + _REFACS_30_;
	O8098[98] =  + _REFACS_32_;
	O8098[99] =  + _REFACS_28_;
	{long i; for (i = 100; i < 103; i++) O8098[i] =  + _REFACS_29_;}
	{long i; for (i = 103; i < 105; i++) O8098[i] =  + _REFACS_30_;}
	{long i; for (i = 105; i < 107; i++) O8098[i] =  + _REFACS_29_;}
	O8098[107] =  + _REFACS_32_;
	O8098[108] =  + _REFACS_30_;
	O8098[109] =  + _REFACS_34_;
	{long i; for (i = 118; i < 120; i++) O8098[i] =  + _REFACS_13_;}
	{long i; for (i = 125; i < 129; i++) O8098[i] =  + _REFACS_14_;}
	O8098[129] =  + _REFACS_15_;
	{long i; for (i = 134; i < 136; i++) O8098[i] =  + _REFACS_17_;}
	{long i; for (i = 144; i < 146; i++) O8098[i] =  + _REFACS_29_;}
}

long O8118[79];
void O8118_init () {
	{long i; for (i = 0; i < 2; i++) O8118[i] =  + _REFACS_4_;}
	O8118[38] =  + _REFACS_6_;
	{long i; for (i = 42; i < 45; i++) O8118[i] =  + _REFACS_6_;}
	{long i; for (i = 75; i < 77; i++) O8118[i] =  + _REFACS_35_;}
	{long i; for (i = 77; i < 79; i++) O8118[i] =  + _REFACS_38_;}
}

long O8125[79];
void O8125_init () {
	O8125[0] = + _CHROFF_5_2_;
	O8125[1] = + _CHROFF_10_2_;
	O8125[38] = + _CHROFF_8_2_;
	{long i; for (i = 42; i < 45; i++) O8125[i] = + _CHROFF_11_2_;}
	{long i; for (i = 75; i < 77; i++) O8125[i] = + _CHROFF_59_3_;}
	O8125[77] = + _CHROFF_65_3_;
	O8125[78] = + _CHROFF_68_3_;
}

long O8131[79];
void O8131_init () {
	O8131[0] = + _CHROFF_5_3_;
	O8131[1] = + _CHROFF_10_3_;
	O8131[38] = + _CHROFF_8_3_;
	{long i; for (i = 42; i < 45; i++) O8131[i] = + _CHROFF_11_3_;}
	{long i; for (i = 75; i < 77; i++) O8131[i] = + _CHROFF_59_4_;}
	O8131[77] = + _CHROFF_65_4_;
	O8131[78] = + _CHROFF_68_4_;
}

long O8175[127];
void O8175_init () {
	O8175[0] = + _LNGOFF_1_1_0_0_;
	O8175[1] = + _LNGOFF_2_1_0_0_;
	{long i; for (i = 2; i < 4; i++) O8175[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 4; i < 6; i++) O8175[i] = + _LNGOFF_2_1_0_0_;}
	O8175[6] = + _LNGOFF_4_1_0_0_;
	O8175[10] = + _LNGOFF_2_1_0_0_;
	O8175[11] = + _LNGOFF_6_3_0_1_;
	O8175[49] = + _LNGOFF_37_9_6_0_;
	O8175[50] = + _LNGOFF_38_9_6_0_;
	O8175[51] = + _LNGOFF_37_9_6_0_;
	O8175[52] = + _LNGOFF_47_12_10_1_;
	O8175[53] = + _LNGOFF_49_12_10_1_;
	O8175[54] = + _LNGOFF_47_12_10_1_;
	{long i; for (i = 55; i < 58; i++) O8175[i] = + _LNGOFF_39_10_6_0_;}
	{long i; for (i = 58; i < 61; i++) O8175[i] = + _LNGOFF_49_13_10_1_;}
	O8175[79] = + _LNGOFF_37_9_6_0_;
	O8175[80] = + _LNGOFF_43_9_6_0_;
	O8175[82] = + _LNGOFF_37_10_6_0_;
	O8175[85] = + _LNGOFF_37_9_6_0_;
	O8175[86] = + _LNGOFF_37_10_6_0_;
	O8175[91] = + _LNGOFF_41_9_6_0_;
	O8175[94] = + _LNGOFF_51_13_10_1_;
	O8175[95] = + _LNGOFF_58_14_10_1_;
	O8175[97] = + _LNGOFF_45_16_10_1_;
	O8175[100] = + _LNGOFF_50_13_10_1_;
	O8175[101] = + _LNGOFF_51_14_10_1_;
	O8175[106] = + _LNGOFF_59_16_10_1_;
	{long i; for (i = 111; i < 113; i++) O8175[i] = + _LNGOFF_20_5_6_0_;}
	{long i; for (i = 113; i < 115; i++) O8175[i] = + _LNGOFF_25_6_6_0_;}
	O8175[121] = + _LNGOFF_18_6_6_0_;
	O8175[126] = + _LNGOFF_26_8_6_1_;
}

long O8209[126];
void O8209_init () {
	O8209[0] =  + _REFACS_1_;
	O8209[4] =  + _REFACS_1_;
	O8209[5] =  + _REFACS_2_;
	O8209[10] =  + _REFACS_3_;
	O8209[51] =  + _REFACS_30_;
	O8209[52] =  + _REFACS_31_;
	O8209[53] =  + _REFACS_30_;
	{long i; for (i = 57; i < 60; i++) O8209[i] =  + _REFACS_31_;}
	O8209[93] =  + _REFACS_31_;
	O8209[94] =  + _REFACS_33_;
	O8209[96] =  + _REFACS_30_;
	{long i; for (i = 99; i < 101; i++) O8209[i] =  + _REFACS_31_;}
	O8209[105] =  + _REFACS_35_;
	{long i; for (i = 112; i < 114; i++) O8209[i] =  + _REFACS_15_;}
	O8209[125] =  + _REFACS_16_;
}

static EIF_TYPE_INDEX Y8209_pgtype0[] = {584,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype1[] = {584,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype2[] = {584,1068,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype3[] = {584,1068,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype4[] = {584,1026,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype5[] = {584,1026,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype6[] = {584,1026,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype7[] = {584,1026,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype8[] = {584,1026,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype9[] = {584,1026,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype10[] = {584,1077,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype11[] = {584,1063,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype12[] = {584,1064,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype13[] = {584,1062,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype14[] = {584,1062,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype15[] = {584,1062,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype16[] = {584,1077,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype17[] = {584,1077,0xFFFF};
static EIF_TYPE_INDEX Y8209_pgtype18[] = {584,1068,0xFFFF};
EIF_TYPE_INDEX *Y8209_gen_type [126];
EIF_TYPE_INDEX Y8209 [126];
void Y8209_init (void)
{
	egc_routines_types [8209] = Y8209;
	egc_routines_gen_types [8209] = Y8209_gen_type;
	egc_routines_offset [8209] = 1118;
	Y8209_gen_type [0] = Y8209_pgtype0;
	Y8209_gen_type [4] = Y8209_pgtype1;
	Y8209_gen_type [5] = Y8209_pgtype2;
	Y8209_gen_type [10] = Y8209_pgtype3;
	Y8209_gen_type [51] = Y8209_pgtype4;
	Y8209_gen_type [52] = Y8209_pgtype5;
	Y8209_gen_type [53] = Y8209_pgtype6;
	Y8209_gen_type [57] = Y8209_pgtype7;
	Y8209_gen_type [58] = Y8209_pgtype8;
	Y8209_gen_type [59] = Y8209_pgtype9;
	Y8209_gen_type [93] = Y8209_pgtype10;
	Y8209_gen_type [94] = Y8209_pgtype11;
	Y8209_gen_type [96] = Y8209_pgtype12;
	Y8209_gen_type [99] = Y8209_pgtype13;
	Y8209_gen_type [100] = Y8209_pgtype14;
	Y8209_gen_type [105] = Y8209_pgtype15;
	Y8209_gen_type [112] = Y8209_pgtype16;
	Y8209_gen_type [113] = Y8209_pgtype17;
	Y8209_gen_type [125] = Y8209_pgtype18;
	Y8209[0] = 584;
	{long i; for (i = 4; i < 6; i++) Y8209[i] = 584;};
	Y8209[10] = 584;
	{long i; for (i = 51; i < 54; i++) Y8209[i] = 584;};
	{long i; for (i = 57; i < 60; i++) Y8209[i] = 584;};
	{long i; for (i = 93; i < 95; i++) Y8209[i] = 584;};
	Y8209[96] = 584;
	{long i; for (i = 99; i < 101; i++) Y8209[i] = 584;};
	Y8209[105] = 584;
	{long i; for (i = 112; i < 114; i++) Y8209[i] = 584;};
	Y8209[125] = 584;
}

long O8246[135];
void O8246_init () {
	O8246[0] =  + _REFACS_1_;
	O8246[38] =  + _REFACS_29_;
	O8246[40] =  + _REFACS_30_;
	O8246[44] =  + _REFACS_31_;
	O8246[45] =  + _REFACS_32_;
	O8246[46] =  + _REFACS_31_;
	{long i; for (i = 50; i < 53; i++) O8246[i] =  + _REFACS_32_;}
	{long i; for (i = 61; i < 65; i++) O8246[i] =  + _REFACS_31_;}
	{long i; for (i = 65; i < 67; i++) O8246[i] =  + _REFACS_36_;}
	{long i; for (i = 67; i < 69; i++) O8246[i] =  + _REFACS_39_;}
	O8246[84] =  + _REFACS_29_;
	O8246[85] =  + _REFACS_30_;
	O8246[86] =  + _REFACS_32_;
	O8246[87] =  + _REFACS_34_;
	O8246[88] =  + _REFACS_29_;
	O8246[89] =  + _REFACS_31_;
	{long i; for (i = 90; i < 92; i++) O8246[i] =  + _REFACS_30_;}
	{long i; for (i = 92; i < 94; i++) O8246[i] =  + _REFACS_32_;}
	{long i; for (i = 94; i < 96; i++) O8246[i] =  + _REFACS_30_;}
	O8246[96] =  + _REFACS_33_;
	O8246[97] =  + _REFACS_31_;
	O8246[98] =  + _REFACS_36_;
	{long i; for (i = 133; i < 135; i++) O8246[i] =  + _REFACS_30_;}
}

long O8247[135];
void O8247_init () {
	O8247[0] =  + _REFACS_2_;
	O8247[38] =  + _REFACS_30_;
	O8247[40] =  + _REFACS_31_;
	O8247[44] =  + _REFACS_32_;
	O8247[45] =  + _REFACS_33_;
	O8247[46] =  + _REFACS_32_;
	{long i; for (i = 50; i < 53; i++) O8247[i] =  + _REFACS_33_;}
	{long i; for (i = 61; i < 65; i++) O8247[i] =  + _REFACS_32_;}
	{long i; for (i = 65; i < 67; i++) O8247[i] =  + _REFACS_37_;}
	{long i; for (i = 67; i < 69; i++) O8247[i] =  + _REFACS_40_;}
	O8247[84] =  + _REFACS_30_;
	O8247[85] =  + _REFACS_31_;
	O8247[86] =  + _REFACS_33_;
	O8247[87] =  + _REFACS_35_;
	O8247[88] =  + _REFACS_30_;
	O8247[89] =  + _REFACS_32_;
	{long i; for (i = 90; i < 92; i++) O8247[i] =  + _REFACS_31_;}
	{long i; for (i = 92; i < 94; i++) O8247[i] =  + _REFACS_33_;}
	{long i; for (i = 94; i < 96; i++) O8247[i] =  + _REFACS_31_;}
	O8247[96] =  + _REFACS_34_;
	O8247[97] =  + _REFACS_32_;
	O8247[98] =  + _REFACS_37_;
	{long i; for (i = 133; i < 135; i++) O8247[i] =  + _REFACS_31_;}
}

long O8274[130];
void O8274_init () {
	{long i; for (i = 0; i < 2; i++) O8274[i] =  + _REFACS_6_;}
	O8274[32] =  + _REFACS_26_;
	O8274[33] =  + _REFACS_31_;
	O8274[34] =  + _REFACS_27_;
	O8274[35] =  + _REFACS_32_;
	O8274[36] =  + _REFACS_27_;
	O8274[37] =  + _REFACS_28_;
	O8274[38] =  + _REFACS_27_;
	O8274[39] =  + _REFACS_33_;
	O8274[40] =  + _REFACS_34_;
	O8274[41] =  + _REFACS_33_;
	{long i; for (i = 42; i < 45; i++) O8274[i] =  + _REFACS_28_;}
	{long i; for (i = 45; i < 48; i++) O8274[i] =  + _REFACS_34_;}
	{long i; for (i = 48; i < 52; i++) O8274[i] =  + _REFACS_28_;}
	{long i; for (i = 52; i < 54; i++) O8274[i] =  + _REFACS_32_;}
	{long i; for (i = 54; i < 56; i++) O8274[i] =  + _REFACS_35_;}
	{long i; for (i = 56; i < 60; i++) O8274[i] =  + _REFACS_33_;}
	{long i; for (i = 60; i < 62; i++) O8274[i] =  + _REFACS_38_;}
	{long i; for (i = 62; i < 64; i++) O8274[i] =  + _REFACS_41_;}
	O8274[64] =  + _REFACS_26_;
	O8274[65] =  + _REFACS_27_;
	O8274[66] =  + _REFACS_28_;
	O8274[67] =  + _REFACS_30_;
	O8274[68] =  + _REFACS_26_;
	{long i; for (i = 69; i < 72; i++) O8274[i] =  + _REFACS_27_;}
	{long i; for (i = 72; i < 74; i++) O8274[i] =  + _REFACS_28_;}
	{long i; for (i = 74; i < 76; i++) O8274[i] =  + _REFACS_27_;}
	O8274[76] =  + _REFACS_30_;
	O8274[77] =  + _REFACS_28_;
	O8274[78] =  + _REFACS_32_;
	O8274[79] =  + _REFACS_31_;
	O8274[80] =  + _REFACS_32_;
	O8274[81] =  + _REFACS_34_;
	O8274[82] =  + _REFACS_36_;
	O8274[83] =  + _REFACS_31_;
	O8274[84] =  + _REFACS_33_;
	{long i; for (i = 85; i < 87; i++) O8274[i] =  + _REFACS_32_;}
	{long i; for (i = 87; i < 89; i++) O8274[i] =  + _REFACS_34_;}
	{long i; for (i = 89; i < 91; i++) O8274[i] =  + _REFACS_32_;}
	O8274[91] =  + _REFACS_35_;
	O8274[92] =  + _REFACS_33_;
	O8274[93] =  + _REFACS_38_;
	{long i; for (i = 116; i < 118; i++) O8274[i] =  + _REFACS_15_;}
	{long i; for (i = 118; i < 120; i++) O8274[i] =  + _REFACS_18_;}
	{long i; for (i = 123; i < 125; i++) O8274[i] =  + _REFACS_27_;}
	{long i; for (i = 128; i < 130; i++) O8274[i] =  + _REFACS_32_;}
}

long O8275[130];
void O8275_init () {
	O8275[0] = + _CHROFF_7_1_;
	O8275[1] = + _CHROFF_8_1_;
	O8275[32] = + _CHROFF_35_1_;
	O8275[33] = + _CHROFF_42_3_;
	O8275[34] = + _CHROFF_37_1_;
	O8275[35] = + _CHROFF_46_3_;
	O8275[36] = + _CHROFF_37_1_;
	O8275[37] = + _CHROFF_38_1_;
	O8275[38] = + _CHROFF_37_1_;
	O8275[39] = + _CHROFF_47_3_;
	O8275[40] = + _CHROFF_49_3_;
	O8275[41] = + _CHROFF_47_3_;
	{long i; for (i = 42; i < 45; i++) O8275[i] = + _CHROFF_39_1_;}
	{long i; for (i = 45; i < 48; i++) O8275[i] = + _CHROFF_49_3_;}
	{long i; for (i = 48; i < 52; i++) O8275[i] = + _CHROFF_39_1_;}
	{long i; for (i = 52; i < 54; i++) O8275[i] = + _CHROFF_47_1_;}
	O8275[54] = + _CHROFF_50_1_;
	O8275[55] = + _CHROFF_53_1_;
	O8275[56] = + _CHROFF_49_3_;
	O8275[57] = + _CHROFF_51_3_;
	{long i; for (i = 58; i < 60; i++) O8275[i] = + _CHROFF_49_3_;}
	{long i; for (i = 60; i < 62; i++) O8275[i] = + _CHROFF_59_5_;}
	O8275[62] = + _CHROFF_65_5_;
	O8275[63] = + _CHROFF_68_5_;
	O8275[64] = + _CHROFF_35_1_;
	{long i; for (i = 65; i < 67; i++) O8275[i] = + _CHROFF_37_1_;}
	O8275[67] = + _CHROFF_43_1_;
	O8275[68] = + _CHROFF_35_1_;
	O8275[69] = + _CHROFF_37_1_;
	{long i; for (i = 70; i < 72; i++) O8275[i] = + _CHROFF_36_1_;}
	{long i; for (i = 72; i < 74; i++) O8275[i] = + _CHROFF_37_1_;}
	{long i; for (i = 74; i < 76; i++) O8275[i] = + _CHROFF_36_1_;}
	O8275[76] = + _CHROFF_40_1_;
	O8275[77] = + _CHROFF_37_1_;
	O8275[78] = + _CHROFF_41_1_;
	O8275[79] = + _CHROFF_42_3_;
	O8275[80] = + _CHROFF_44_3_;
	O8275[81] = + _CHROFF_51_3_;
	O8275[82] = + _CHROFF_58_3_;
	O8275[83] = + _CHROFF_44_3_;
	O8275[84] = + _CHROFF_45_3_;
	{long i; for (i = 85; i < 87; i++) O8275[i] = + _CHROFF_46_3_;}
	O8275[87] = + _CHROFF_50_3_;
	O8275[88] = + _CHROFF_51_3_;
	O8275[89] = + _CHROFF_43_3_;
	O8275[90] = + _CHROFF_44_3_;
	O8275[91] = + _CHROFF_51_3_;
	O8275[92] = + _CHROFF_46_3_;
	O8275[93] = + _CHROFF_59_3_;
	{long i; for (i = 116; i < 118; i++) O8275[i] = + _CHROFF_21_1_;}
	{long i; for (i = 118; i < 120; i++) O8275[i] = + _CHROFF_29_3_;}
	{long i; for (i = 123; i < 125; i++) O8275[i] = + _CHROFF_36_1_;}
	{long i; for (i = 128; i < 130; i++) O8275[i] = + _CHROFF_48_3_;}
}

long O8276[130];
void O8276_init () {
	O8276[0] = + _CHROFF_7_2_;
	O8276[1] = + _CHROFF_8_2_;
	O8276[32] = + _CHROFF_35_2_;
	O8276[33] = + _CHROFF_42_4_;
	O8276[34] = + _CHROFF_37_2_;
	O8276[35] = + _CHROFF_46_4_;
	O8276[36] = + _CHROFF_37_2_;
	O8276[37] = + _CHROFF_38_2_;
	O8276[38] = + _CHROFF_37_2_;
	O8276[39] = + _CHROFF_47_4_;
	O8276[40] = + _CHROFF_49_4_;
	O8276[41] = + _CHROFF_47_4_;
	{long i; for (i = 42; i < 45; i++) O8276[i] = + _CHROFF_39_2_;}
	{long i; for (i = 45; i < 48; i++) O8276[i] = + _CHROFF_49_4_;}
	{long i; for (i = 48; i < 52; i++) O8276[i] = + _CHROFF_39_2_;}
	{long i; for (i = 52; i < 54; i++) O8276[i] = + _CHROFF_47_2_;}
	O8276[54] = + _CHROFF_50_2_;
	O8276[55] = + _CHROFF_53_2_;
	O8276[56] = + _CHROFF_49_4_;
	O8276[57] = + _CHROFF_51_4_;
	{long i; for (i = 58; i < 60; i++) O8276[i] = + _CHROFF_49_4_;}
	{long i; for (i = 60; i < 62; i++) O8276[i] = + _CHROFF_59_6_;}
	O8276[62] = + _CHROFF_65_6_;
	O8276[63] = + _CHROFF_68_6_;
	O8276[64] = + _CHROFF_35_2_;
	{long i; for (i = 65; i < 67; i++) O8276[i] = + _CHROFF_37_2_;}
	O8276[67] = + _CHROFF_43_2_;
	O8276[68] = + _CHROFF_35_2_;
	O8276[69] = + _CHROFF_37_2_;
	{long i; for (i = 70; i < 72; i++) O8276[i] = + _CHROFF_36_2_;}
	{long i; for (i = 72; i < 74; i++) O8276[i] = + _CHROFF_37_2_;}
	{long i; for (i = 74; i < 76; i++) O8276[i] = + _CHROFF_36_2_;}
	O8276[76] = + _CHROFF_40_2_;
	O8276[77] = + _CHROFF_37_2_;
	O8276[78] = + _CHROFF_41_2_;
	O8276[79] = + _CHROFF_42_4_;
	O8276[80] = + _CHROFF_44_4_;
	O8276[81] = + _CHROFF_51_4_;
	O8276[82] = + _CHROFF_58_4_;
	O8276[83] = + _CHROFF_44_4_;
	O8276[84] = + _CHROFF_45_4_;
	{long i; for (i = 85; i < 87; i++) O8276[i] = + _CHROFF_46_4_;}
	O8276[87] = + _CHROFF_50_4_;
	O8276[88] = + _CHROFF_51_4_;
	O8276[89] = + _CHROFF_43_4_;
	O8276[90] = + _CHROFF_44_4_;
	O8276[91] = + _CHROFF_51_4_;
	O8276[92] = + _CHROFF_46_4_;
	O8276[93] = + _CHROFF_59_4_;
	{long i; for (i = 116; i < 118; i++) O8276[i] = + _CHROFF_21_2_;}
	{long i; for (i = 118; i < 120; i++) O8276[i] = + _CHROFF_29_4_;}
	{long i; for (i = 123; i < 125; i++) O8276[i] = + _CHROFF_36_2_;}
	{long i; for (i = 128; i < 130; i++) O8276[i] = + _CHROFF_48_4_;}
}

long O8278[130];
void O8278_init () {
	O8278[0] = + _CHROFF_7_3_;
	O8278[1] = + _CHROFF_8_3_;
	O8278[32] = + _CHROFF_35_3_;
	O8278[33] = + _CHROFF_42_5_;
	O8278[34] = + _CHROFF_37_3_;
	O8278[35] = + _CHROFF_46_5_;
	O8278[36] = + _CHROFF_37_3_;
	O8278[37] = + _CHROFF_38_3_;
	O8278[38] = + _CHROFF_37_3_;
	O8278[39] = + _CHROFF_47_5_;
	O8278[40] = + _CHROFF_49_5_;
	O8278[41] = + _CHROFF_47_5_;
	{long i; for (i = 42; i < 45; i++) O8278[i] = + _CHROFF_39_3_;}
	{long i; for (i = 45; i < 48; i++) O8278[i] = + _CHROFF_49_5_;}
	{long i; for (i = 48; i < 52; i++) O8278[i] = + _CHROFF_39_3_;}
	{long i; for (i = 52; i < 54; i++) O8278[i] = + _CHROFF_47_3_;}
	O8278[54] = + _CHROFF_50_3_;
	O8278[55] = + _CHROFF_53_3_;
	O8278[56] = + _CHROFF_49_5_;
	O8278[57] = + _CHROFF_51_5_;
	{long i; for (i = 58; i < 60; i++) O8278[i] = + _CHROFF_49_5_;}
	{long i; for (i = 60; i < 62; i++) O8278[i] = + _CHROFF_59_7_;}
	O8278[62] = + _CHROFF_65_7_;
	O8278[63] = + _CHROFF_68_7_;
	O8278[64] = + _CHROFF_35_3_;
	{long i; for (i = 65; i < 67; i++) O8278[i] = + _CHROFF_37_3_;}
	O8278[67] = + _CHROFF_43_3_;
	O8278[68] = + _CHROFF_35_3_;
	O8278[69] = + _CHROFF_37_3_;
	{long i; for (i = 70; i < 72; i++) O8278[i] = + _CHROFF_36_3_;}
	{long i; for (i = 72; i < 74; i++) O8278[i] = + _CHROFF_37_3_;}
	{long i; for (i = 74; i < 76; i++) O8278[i] = + _CHROFF_36_3_;}
	O8278[76] = + _CHROFF_40_3_;
	O8278[77] = + _CHROFF_37_3_;
	O8278[78] = + _CHROFF_41_3_;
	O8278[79] = + _CHROFF_42_5_;
	O8278[80] = + _CHROFF_44_5_;
	O8278[81] = + _CHROFF_51_5_;
	O8278[82] = + _CHROFF_58_5_;
	O8278[83] = + _CHROFF_44_5_;
	O8278[84] = + _CHROFF_45_5_;
	{long i; for (i = 85; i < 87; i++) O8278[i] = + _CHROFF_46_5_;}
	O8278[87] = + _CHROFF_50_5_;
	O8278[88] = + _CHROFF_51_5_;
	O8278[89] = + _CHROFF_43_5_;
	O8278[90] = + _CHROFF_44_5_;
	O8278[91] = + _CHROFF_51_5_;
	O8278[92] = + _CHROFF_46_5_;
	O8278[93] = + _CHROFF_59_5_;
	{long i; for (i = 116; i < 118; i++) O8278[i] = + _CHROFF_21_3_;}
	{long i; for (i = 118; i < 120; i++) O8278[i] = + _CHROFF_29_5_;}
	{long i; for (i = 123; i < 125; i++) O8278[i] = + _CHROFF_36_3_;}
	{long i; for (i = 128; i < 130; i++) O8278[i] = + _CHROFF_48_5_;}
}

long O8307[129];
void O8307_init () {
	O8307[0] = + _CHROFF_8_4_;
	O8307[32] = + _CHROFF_42_6_;
	O8307[34] = + _CHROFF_46_6_;
	O8307[38] = + _CHROFF_47_6_;
	O8307[39] = + _CHROFF_49_6_;
	O8307[40] = + _CHROFF_47_6_;
	{long i; for (i = 44; i < 47; i++) O8307[i] = + _CHROFF_49_6_;}
	O8307[55] = + _CHROFF_49_6_;
	O8307[56] = + _CHROFF_51_6_;
	{long i; for (i = 57; i < 59; i++) O8307[i] = + _CHROFF_49_6_;}
	{long i; for (i = 59; i < 61; i++) O8307[i] = + _CHROFF_59_8_;}
	O8307[61] = + _CHROFF_65_8_;
	O8307[62] = + _CHROFF_68_8_;
	O8307[78] = + _CHROFF_42_6_;
	O8307[79] = + _CHROFF_44_6_;
	O8307[80] = + _CHROFF_51_6_;
	O8307[81] = + _CHROFF_58_6_;
	O8307[82] = + _CHROFF_44_6_;
	O8307[83] = + _CHROFF_45_6_;
	{long i; for (i = 84; i < 86; i++) O8307[i] = + _CHROFF_46_6_;}
	O8307[86] = + _CHROFF_50_6_;
	O8307[87] = + _CHROFF_51_6_;
	O8307[88] = + _CHROFF_43_6_;
	O8307[89] = + _CHROFF_44_6_;
	O8307[90] = + _CHROFF_51_6_;
	O8307[91] = + _CHROFF_46_6_;
	O8307[92] = + _CHROFF_59_6_;
	{long i; for (i = 117; i < 119; i++) O8307[i] = + _CHROFF_29_6_;}
	{long i; for (i = 127; i < 129; i++) O8307[i] = + _CHROFF_48_6_;}
}

long O8308[129];
void O8308_init () {
	O8308[0] = + _I16OFF_8_6_4_;
	O8308[32] = + _I16OFF_42_12_4_;
	O8308[34] = + _I16OFF_46_12_4_;
	O8308[38] = + _I16OFF_47_12_4_;
	O8308[39] = + _I16OFF_49_12_4_;
	O8308[40] = + _I16OFF_47_12_4_;
	{long i; for (i = 44; i < 47; i++) O8308[i] = + _I16OFF_49_13_4_;}
	O8308[55] = + _I16OFF_49_13_4_;
	O8308[56] = + _I16OFF_51_13_4_;
	{long i; for (i = 57; i < 59; i++) O8308[i] = + _I16OFF_49_14_4_;}
	O8308[59] = + _I16OFF_59_21_4_;
	O8308[60] = + _I16OFF_59_23_4_;
	O8308[61] = + _I16OFF_65_25_4_;
	O8308[62] = + _I16OFF_68_26_4_;
	O8308[78] = + _I16OFF_42_13_4_;
	O8308[79] = + _I16OFF_44_13_4_;
	O8308[80] = + _I16OFF_51_13_4_;
	O8308[81] = + _I16OFF_58_14_4_;
	O8308[82] = + _I16OFF_44_13_4_;
	O8308[83] = + _I16OFF_45_16_4_;
	{long i; for (i = 84; i < 86; i++) O8308[i] = + _I16OFF_46_14_4_;}
	O8308[86] = + _I16OFF_50_13_4_;
	O8308[87] = + _I16OFF_51_14_4_;
	O8308[88] = + _I16OFF_43_13_4_;
	O8308[89] = + _I16OFF_44_15_4_;
	O8308[90] = + _I16OFF_51_18_4_;
	O8308[91] = + _I16OFF_46_14_4_;
	O8308[92] = + _I16OFF_59_16_4_;
	{long i; for (i = 117; i < 119; i++) O8308[i] = + _I16OFF_29_14_4_;}
	O8308[127] = + _I16OFF_48_19_4_;
	O8308[128] = + _I16OFF_48_18_4_;
}

long O8309[129];
void O8309_init () {
	O8309[0] = + _I16OFF_8_6_5_;
	O8309[32] = + _I16OFF_42_12_5_;
	O8309[34] = + _I16OFF_46_12_5_;
	O8309[38] = + _I16OFF_47_12_5_;
	O8309[39] = + _I16OFF_49_12_5_;
	O8309[40] = + _I16OFF_47_12_5_;
	{long i; for (i = 44; i < 47; i++) O8309[i] = + _I16OFF_49_13_5_;}
	O8309[55] = + _I16OFF_49_13_5_;
	O8309[56] = + _I16OFF_51_13_5_;
	{long i; for (i = 57; i < 59; i++) O8309[i] = + _I16OFF_49_14_5_;}
	O8309[59] = + _I16OFF_59_21_5_;
	O8309[60] = + _I16OFF_59_23_5_;
	O8309[61] = + _I16OFF_65_25_5_;
	O8309[62] = + _I16OFF_68_26_5_;
	O8309[78] = + _I16OFF_42_13_5_;
	O8309[79] = + _I16OFF_44_13_5_;
	O8309[80] = + _I16OFF_51_13_5_;
	O8309[81] = + _I16OFF_58_14_5_;
	O8309[82] = + _I16OFF_44_13_5_;
	O8309[83] = + _I16OFF_45_16_5_;
	{long i; for (i = 84; i < 86; i++) O8309[i] = + _I16OFF_46_14_5_;}
	O8309[86] = + _I16OFF_50_13_5_;
	O8309[87] = + _I16OFF_51_14_5_;
	O8309[88] = + _I16OFF_43_13_5_;
	O8309[89] = + _I16OFF_44_15_5_;
	O8309[90] = + _I16OFF_51_18_5_;
	O8309[91] = + _I16OFF_46_14_5_;
	O8309[92] = + _I16OFF_59_16_5_;
	{long i; for (i = 117; i < 119; i++) O8309[i] = + _I16OFF_29_14_5_;}
	O8309[127] = + _I16OFF_48_19_5_;
	O8309[128] = + _I16OFF_48_18_5_;
}

long O8314[129];
void O8314_init () {
	O8314[0] =  + _REFACS_7_;
	O8314[32] =  + _REFACS_32_;
	O8314[34] =  + _REFACS_33_;
	O8314[38] =  + _REFACS_34_;
	O8314[39] =  + _REFACS_35_;
	O8314[40] =  + _REFACS_34_;
	{long i; for (i = 44; i < 47; i++) O8314[i] =  + _REFACS_35_;}
	{long i; for (i = 55; i < 59; i++) O8314[i] =  + _REFACS_34_;}
	{long i; for (i = 59; i < 61; i++) O8314[i] =  + _REFACS_39_;}
	{long i; for (i = 61; i < 63; i++) O8314[i] =  + _REFACS_42_;}
	O8314[78] =  + _REFACS_32_;
	O8314[79] =  + _REFACS_33_;
	O8314[80] =  + _REFACS_35_;
	O8314[81] =  + _REFACS_37_;
	O8314[82] =  + _REFACS_32_;
	O8314[83] =  + _REFACS_34_;
	{long i; for (i = 84; i < 86; i++) O8314[i] =  + _REFACS_33_;}
	{long i; for (i = 86; i < 88; i++) O8314[i] =  + _REFACS_35_;}
	{long i; for (i = 88; i < 90; i++) O8314[i] =  + _REFACS_33_;}
	O8314[90] =  + _REFACS_36_;
	O8314[91] =  + _REFACS_34_;
	O8314[92] =  + _REFACS_39_;
	{long i; for (i = 117; i < 119; i++) O8314[i] =  + _REFACS_19_;}
	{long i; for (i = 127; i < 129; i++) O8314[i] =  + _REFACS_33_;}
}

long O8340[125];
void O8340_init () {
	{long i; for (i = 0; i < 2; i++) O8340[i] = + _CHROFF_1_0_;}
	O8340[27] = + _CHROFF_35_4_;
	O8340[28] = + _CHROFF_42_7_;
	O8340[29] = + _CHROFF_37_4_;
	O8340[30] = + _CHROFF_46_7_;
	O8340[31] = + _CHROFF_37_4_;
	O8340[32] = + _CHROFF_38_4_;
	O8340[33] = + _CHROFF_37_4_;
	O8340[34] = + _CHROFF_47_7_;
	O8340[35] = + _CHROFF_49_7_;
	O8340[36] = + _CHROFF_47_7_;
	{long i; for (i = 37; i < 40; i++) O8340[i] = + _CHROFF_39_4_;}
	{long i; for (i = 40; i < 43; i++) O8340[i] = + _CHROFF_49_7_;}
	{long i; for (i = 43; i < 47; i++) O8340[i] = + _CHROFF_39_4_;}
	{long i; for (i = 47; i < 49; i++) O8340[i] = + _CHROFF_47_4_;}
	O8340[49] = + _CHROFF_50_4_;
	O8340[50] = + _CHROFF_53_4_;
	O8340[51] = + _CHROFF_49_7_;
	O8340[52] = + _CHROFF_51_7_;
	{long i; for (i = 53; i < 55; i++) O8340[i] = + _CHROFF_49_7_;}
	{long i; for (i = 55; i < 57; i++) O8340[i] = + _CHROFF_59_9_;}
	O8340[57] = + _CHROFF_65_9_;
	O8340[58] = + _CHROFF_68_9_;
	O8340[59] = + _CHROFF_35_4_;
	{long i; for (i = 60; i < 62; i++) O8340[i] = + _CHROFF_37_4_;}
	O8340[62] = + _CHROFF_43_4_;
	O8340[63] = + _CHROFF_35_4_;
	O8340[64] = + _CHROFF_37_4_;
	{long i; for (i = 65; i < 67; i++) O8340[i] = + _CHROFF_36_4_;}
	{long i; for (i = 67; i < 69; i++) O8340[i] = + _CHROFF_37_4_;}
	{long i; for (i = 69; i < 71; i++) O8340[i] = + _CHROFF_36_4_;}
	O8340[71] = + _CHROFF_40_4_;
	O8340[72] = + _CHROFF_37_4_;
	O8340[73] = + _CHROFF_41_4_;
	O8340[74] = + _CHROFF_42_7_;
	O8340[75] = + _CHROFF_44_7_;
	O8340[76] = + _CHROFF_51_7_;
	O8340[77] = + _CHROFF_58_7_;
	O8340[78] = + _CHROFF_44_7_;
	O8340[79] = + _CHROFF_45_7_;
	{long i; for (i = 80; i < 82; i++) O8340[i] = + _CHROFF_46_7_;}
	O8340[82] = + _CHROFF_50_7_;
	O8340[83] = + _CHROFF_51_7_;
	O8340[84] = + _CHROFF_43_7_;
	O8340[85] = + _CHROFF_44_7_;
	O8340[86] = + _CHROFF_51_7_;
	O8340[87] = + _CHROFF_46_7_;
	O8340[88] = + _CHROFF_59_7_;
	{long i; for (i = 99; i < 103; i++) O8340[i] = + _CHROFF_17_1_;}
	O8340[103] = + _CHROFF_18_1_;
	{long i; for (i = 104; i < 107; i++) O8340[i] = + _CHROFF_23_3_;}
	O8340[107] = + _CHROFF_24_3_;
	O8340[108] = + _CHROFF_26_3_;
	{long i; for (i = 111; i < 113; i++) O8340[i] = + _CHROFF_21_4_;}
	{long i; for (i = 113; i < 115; i++) O8340[i] = + _CHROFF_29_7_;}
	{long i; for (i = 118; i < 120; i++) O8340[i] = + _CHROFF_36_4_;}
	{long i; for (i = 123; i < 125; i++) O8340[i] = + _CHROFF_48_7_;}
}

long O8350[78];
void O8350_init () {
	{long i; for (i = 0; i < 2; i++) O8350[i] =  + _REFACS_2_;}
	{long i; for (i = 35; i < 38; i++) O8350[i] =  + _REFACS_29_;}
	{long i; for (i = 38; i < 41; i++) O8350[i] =  + _REFACS_36_;}
	{long i; for (i = 41; i < 45; i++) O8350[i] =  + _REFACS_29_;}
	{long i; for (i = 45; i < 47; i++) O8350[i] =  + _REFACS_33_;}
	{long i; for (i = 47; i < 49; i++) O8350[i] =  + _REFACS_36_;}
	{long i; for (i = 49; i < 53; i++) O8350[i] =  + _REFACS_35_;}
	{long i; for (i = 53; i < 55; i++) O8350[i] =  + _REFACS_40_;}
	{long i; for (i = 55; i < 57; i++) O8350[i] =  + _REFACS_43_;}
	O8350[62] =  + _REFACS_28_;
	O8350[77] =  + _REFACS_35_;
}

long O8351[78];
void O8351_init () {
	{long i; for (i = 0; i < 2; i++) O8351[i] = + _CHROFF_3_0_;}
	{long i; for (i = 35; i < 38; i++) O8351[i] = + _CHROFF_39_5_;}
	{long i; for (i = 38; i < 41; i++) O8351[i] = + _CHROFF_49_8_;}
	{long i; for (i = 41; i < 45; i++) O8351[i] = + _CHROFF_39_5_;}
	{long i; for (i = 45; i < 47; i++) O8351[i] = + _CHROFF_47_5_;}
	O8351[47] = + _CHROFF_50_5_;
	O8351[48] = + _CHROFF_53_5_;
	O8351[49] = + _CHROFF_49_8_;
	O8351[50] = + _CHROFF_51_8_;
	{long i; for (i = 51; i < 53; i++) O8351[i] = + _CHROFF_49_8_;}
	{long i; for (i = 53; i < 55; i++) O8351[i] = + _CHROFF_59_10_;}
	O8351[55] = + _CHROFF_65_10_;
	O8351[56] = + _CHROFF_68_10_;
	O8351[62] = + _CHROFF_37_5_;
	O8351[77] = + _CHROFF_45_8_;
}

long O8372[105];
void O8372_init () {
	O8372[0] =  + _REFACS_1_;
	{long i; for (i = 70; i < 72; i++) O8372[i] =  + _REFACS_34_;}
	{long i; for (i = 87; i < 89; i++) O8372[i] =  + _REFACS_14_;}
	{long i; for (i = 94; i < 98; i++) O8372[i] =  + _REFACS_15_;}
	O8372[98] =  + _REFACS_18_;
	{long i; for (i = 103; i < 105; i++) O8372[i] =  + _REFACS_20_;}
}

long O8374[105];
void O8374_init () {
	O8374[0] = + _PTROFF_2_1_0_0_0_0_;
	{long i; for (i = 70; i < 72; i++) O8374[i] = + _PTROFF_46_14_10_6_0_1_;}
	{long i; for (i = 87; i < 89; i++) O8374[i] = + _PTROFF_21_7_6_1_0_1_;}
	O8374[94] = + _PTROFF_23_8_6_1_0_1_;
	{long i; for (i = 95; i < 97; i++) O8374[i] = + _PTROFF_23_9_6_1_0_1_;}
	O8374[97] = + _PTROFF_24_9_6_1_0_1_;
	O8374[98] = + _PTROFF_26_8_6_2_0_1_;
	{long i; for (i = 103; i < 105; i++) O8374[i] = + _PTROFF_29_14_8_2_0_1_;}
}

long O8379[77];
void O8379_init () {
	O8379[0] =  + _REFACS_1_;
	O8379[23] =  + _REFACS_36_;
	O8379[40] =  + _REFACS_36_;
	O8379[66] =  + _REFACS_33_;
	{long i; for (i = 68; i < 70; i++) O8379[i] =  + _REFACS_35_;}
	O8379[73] =  + _REFACS_34_;
	O8379[74] =  + _REFACS_37_;
	O8379[75] =  + _REFACS_35_;
	O8379[76] =  + _REFACS_40_;
}

long O8388[95];
void O8388_init () {
	O8388[0] = + _PTROFF_2_1_0_0_0_0_;
	O8388[64] = + _PTROFF_44_13_10_6_1_1_;
	{long i; for (i = 66; i < 68; i++) O8388[i] = + _PTROFF_46_14_10_6_0_2_;}
	O8388[90] = + _PTROFF_23_8_6_1_0_2_;
	{long i; for (i = 91; i < 93; i++) O8388[i] = + _PTROFF_23_9_6_1_0_2_;}
	O8388[93] = + _PTROFF_24_9_6_1_0_2_;
	O8388[94] = + _PTROFF_26_8_6_2_0_2_;
}

long O8390[95];
void O8390_init () {
	O8390[0] =  + _REFACS_1_;
	O8390[64] =  + _REFACS_34_;
	{long i; for (i = 66; i < 68; i++) O8390[i] =  + _REFACS_36_;}
	{long i; for (i = 90; i < 94; i++) O8390[i] =  + _REFACS_16_;}
	O8390[94] =  + _REFACS_19_;
}

long O8432[100];
void O8432_init () {
	O8432[0] =  + _REFACS_8_;
	O8432[1] =  + _REFACS_11_;
	O8432[2] =  + _REFACS_27_;
	O8432[3] =  + _REFACS_33_;
	O8432[4] =  + _REFACS_28_;
	O8432[5] =  + _REFACS_34_;
	O8432[6] =  + _REFACS_28_;
	O8432[7] =  + _REFACS_29_;
	O8432[8] =  + _REFACS_28_;
	O8432[9] =  + _REFACS_35_;
	O8432[10] =  + _REFACS_37_;
	O8432[11] =  + _REFACS_35_;
	{long i; for (i = 12; i < 15; i++) O8432[i] =  + _REFACS_30_;}
	{long i; for (i = 15; i < 18; i++) O8432[i] =  + _REFACS_37_;}
	{long i; for (i = 18; i < 22; i++) O8432[i] =  + _REFACS_30_;}
	{long i; for (i = 22; i < 24; i++) O8432[i] =  + _REFACS_34_;}
	{long i; for (i = 24; i < 26; i++) O8432[i] =  + _REFACS_37_;}
	O8432[26] =  + _REFACS_36_;
	O8432[27] =  + _REFACS_37_;
	{long i; for (i = 28; i < 30; i++) O8432[i] =  + _REFACS_36_;}
	{long i; for (i = 30; i < 32; i++) O8432[i] =  + _REFACS_41_;}
	{long i; for (i = 32; i < 34; i++) O8432[i] =  + _REFACS_44_;}
	O8432[34] =  + _REFACS_27_;
	O8432[35] =  + _REFACS_28_;
	O8432[36] =  + _REFACS_29_;
	O8432[37] =  + _REFACS_31_;
	O8432[38] =  + _REFACS_27_;
	O8432[39] =  + _REFACS_29_;
	{long i; for (i = 40; i < 42; i++) O8432[i] =  + _REFACS_28_;}
	{long i; for (i = 42; i < 44; i++) O8432[i] =  + _REFACS_29_;}
	{long i; for (i = 44; i < 46; i++) O8432[i] =  + _REFACS_28_;}
	O8432[46] =  + _REFACS_31_;
	O8432[47] =  + _REFACS_29_;
	{long i; for (i = 48; i < 50; i++) O8432[i] =  + _REFACS_33_;}
	O8432[50] =  + _REFACS_34_;
	O8432[51] =  + _REFACS_36_;
	O8432[52] =  + _REFACS_38_;
	O8432[53] =  + _REFACS_35_;
	O8432[54] =  + _REFACS_36_;
	{long i; for (i = 55; i < 57; i++) O8432[i] =  + _REFACS_37_;}
	{long i; for (i = 57; i < 59; i++) O8432[i] =  + _REFACS_36_;}
	O8432[59] =  + _REFACS_34_;
	O8432[60] =  + _REFACS_35_;
	O8432[61] =  + _REFACS_38_;
	O8432[62] =  + _REFACS_36_;
	O8432[63] =  + _REFACS_41_;
	O8432[64] =  + _REFACS_11_;
	{long i; for (i = 65; i < 67; i++) O8432[i] =  + _REFACS_13_;}
	O8432[67] =  + _REFACS_11_;
	{long i; for (i = 68; i < 70; i++) O8432[i] =  + _REFACS_15_;}
	{long i; for (i = 70; i < 72; i++) O8432[i] =  + _REFACS_16_;}
	{long i; for (i = 72; i < 74; i++) O8432[i] =  + _REFACS_15_;}
	{long i; for (i = 74; i < 78; i++) O8432[i] =  + _REFACS_12_;}
	O8432[78] =  + _REFACS_13_;
	{long i; for (i = 79; i < 83; i++) O8432[i] =  + _REFACS_17_;}
	O8432[83] =  + _REFACS_20_;
	{long i; for (i = 84; i < 86; i++) O8432[i] =  + _REFACS_13_;}
	{long i; for (i = 86; i < 88; i++) O8432[i] =  + _REFACS_16_;}
	{long i; for (i = 88; i < 90; i++) O8432[i] =  + _REFACS_21_;}
	{long i; for (i = 93; i < 95; i++) O8432[i] =  + _REFACS_28_;}
	{long i; for (i = 98; i < 100; i++) O8432[i] =  + _REFACS_34_;}
}

long O8433[100];
void O8433_init () {
	O8433[0] =  + _REFACS_9_;
	O8433[1] =  + _REFACS_12_;
	O8433[2] =  + _REFACS_28_;
	O8433[3] =  + _REFACS_34_;
	O8433[4] =  + _REFACS_29_;
	O8433[5] =  + _REFACS_35_;
	O8433[6] =  + _REFACS_29_;
	O8433[7] =  + _REFACS_30_;
	O8433[8] =  + _REFACS_29_;
	O8433[9] =  + _REFACS_36_;
	O8433[10] =  + _REFACS_38_;
	O8433[11] =  + _REFACS_36_;
	{long i; for (i = 12; i < 15; i++) O8433[i] =  + _REFACS_31_;}
	{long i; for (i = 15; i < 18; i++) O8433[i] =  + _REFACS_38_;}
	{long i; for (i = 18; i < 22; i++) O8433[i] =  + _REFACS_31_;}
	{long i; for (i = 22; i < 24; i++) O8433[i] =  + _REFACS_35_;}
	{long i; for (i = 24; i < 26; i++) O8433[i] =  + _REFACS_38_;}
	O8433[26] =  + _REFACS_37_;
	O8433[27] =  + _REFACS_38_;
	{long i; for (i = 28; i < 30; i++) O8433[i] =  + _REFACS_37_;}
	{long i; for (i = 30; i < 32; i++) O8433[i] =  + _REFACS_42_;}
	{long i; for (i = 32; i < 34; i++) O8433[i] =  + _REFACS_45_;}
	O8433[34] =  + _REFACS_28_;
	O8433[35] =  + _REFACS_29_;
	O8433[36] =  + _REFACS_30_;
	O8433[37] =  + _REFACS_32_;
	O8433[38] =  + _REFACS_28_;
	O8433[39] =  + _REFACS_30_;
	{long i; for (i = 40; i < 42; i++) O8433[i] =  + _REFACS_29_;}
	{long i; for (i = 42; i < 44; i++) O8433[i] =  + _REFACS_30_;}
	{long i; for (i = 44; i < 46; i++) O8433[i] =  + _REFACS_29_;}
	O8433[46] =  + _REFACS_32_;
	O8433[47] =  + _REFACS_30_;
	{long i; for (i = 48; i < 50; i++) O8433[i] =  + _REFACS_34_;}
	O8433[50] =  + _REFACS_35_;
	O8433[51] =  + _REFACS_37_;
	O8433[52] =  + _REFACS_39_;
	O8433[53] =  + _REFACS_36_;
	O8433[54] =  + _REFACS_37_;
	{long i; for (i = 55; i < 57; i++) O8433[i] =  + _REFACS_38_;}
	{long i; for (i = 57; i < 59; i++) O8433[i] =  + _REFACS_37_;}
	O8433[59] =  + _REFACS_35_;
	O8433[60] =  + _REFACS_36_;
	O8433[61] =  + _REFACS_39_;
	O8433[62] =  + _REFACS_37_;
	O8433[63] =  + _REFACS_42_;
	O8433[64] =  + _REFACS_12_;
	{long i; for (i = 65; i < 67; i++) O8433[i] =  + _REFACS_14_;}
	O8433[67] =  + _REFACS_12_;
	{long i; for (i = 68; i < 70; i++) O8433[i] =  + _REFACS_16_;}
	{long i; for (i = 70; i < 72; i++) O8433[i] =  + _REFACS_17_;}
	{long i; for (i = 72; i < 74; i++) O8433[i] =  + _REFACS_16_;}
	{long i; for (i = 74; i < 78; i++) O8433[i] =  + _REFACS_13_;}
	O8433[78] =  + _REFACS_14_;
	{long i; for (i = 79; i < 83; i++) O8433[i] =  + _REFACS_18_;}
	O8433[83] =  + _REFACS_21_;
	{long i; for (i = 84; i < 86; i++) O8433[i] =  + _REFACS_14_;}
	{long i; for (i = 86; i < 88; i++) O8433[i] =  + _REFACS_17_;}
	{long i; for (i = 88; i < 90; i++) O8433[i] =  + _REFACS_22_;}
	{long i; for (i = 93; i < 95; i++) O8433[i] =  + _REFACS_29_;}
	{long i; for (i = 98; i < 100; i++) O8433[i] =  + _REFACS_35_;}
}

long O8435[100];
void O8435_init () {
	O8435[0] =  + _REFACS_10_;
	O8435[1] =  + _REFACS_13_;
	O8435[2] =  + _REFACS_29_;
	O8435[3] =  + _REFACS_35_;
	O8435[4] =  + _REFACS_30_;
	O8435[5] =  + _REFACS_36_;
	O8435[6] =  + _REFACS_30_;
	O8435[7] =  + _REFACS_31_;
	O8435[8] =  + _REFACS_30_;
	O8435[9] =  + _REFACS_37_;
	O8435[10] =  + _REFACS_39_;
	O8435[11] =  + _REFACS_37_;
	{long i; for (i = 12; i < 15; i++) O8435[i] =  + _REFACS_32_;}
	{long i; for (i = 15; i < 18; i++) O8435[i] =  + _REFACS_39_;}
	{long i; for (i = 18; i < 22; i++) O8435[i] =  + _REFACS_32_;}
	{long i; for (i = 22; i < 24; i++) O8435[i] =  + _REFACS_36_;}
	{long i; for (i = 24; i < 26; i++) O8435[i] =  + _REFACS_39_;}
	O8435[26] =  + _REFACS_38_;
	O8435[27] =  + _REFACS_39_;
	{long i; for (i = 28; i < 30; i++) O8435[i] =  + _REFACS_38_;}
	{long i; for (i = 30; i < 32; i++) O8435[i] =  + _REFACS_43_;}
	{long i; for (i = 32; i < 34; i++) O8435[i] =  + _REFACS_46_;}
	O8435[34] =  + _REFACS_29_;
	O8435[35] =  + _REFACS_30_;
	O8435[36] =  + _REFACS_31_;
	O8435[37] =  + _REFACS_33_;
	O8435[38] =  + _REFACS_29_;
	O8435[39] =  + _REFACS_31_;
	{long i; for (i = 40; i < 42; i++) O8435[i] =  + _REFACS_30_;}
	{long i; for (i = 42; i < 44; i++) O8435[i] =  + _REFACS_31_;}
	{long i; for (i = 44; i < 46; i++) O8435[i] =  + _REFACS_30_;}
	O8435[46] =  + _REFACS_33_;
	O8435[47] =  + _REFACS_31_;
	{long i; for (i = 48; i < 50; i++) O8435[i] =  + _REFACS_35_;}
	O8435[50] =  + _REFACS_36_;
	O8435[51] =  + _REFACS_38_;
	O8435[52] =  + _REFACS_40_;
	O8435[53] =  + _REFACS_37_;
	O8435[54] =  + _REFACS_38_;
	{long i; for (i = 55; i < 57; i++) O8435[i] =  + _REFACS_39_;}
	{long i; for (i = 57; i < 59; i++) O8435[i] =  + _REFACS_38_;}
	O8435[59] =  + _REFACS_36_;
	O8435[60] =  + _REFACS_37_;
	O8435[61] =  + _REFACS_40_;
	O8435[62] =  + _REFACS_38_;
	O8435[63] =  + _REFACS_43_;
	O8435[64] =  + _REFACS_13_;
	{long i; for (i = 65; i < 67; i++) O8435[i] =  + _REFACS_15_;}
	O8435[67] =  + _REFACS_13_;
	{long i; for (i = 68; i < 70; i++) O8435[i] =  + _REFACS_17_;}
	{long i; for (i = 70; i < 72; i++) O8435[i] =  + _REFACS_18_;}
	{long i; for (i = 72; i < 74; i++) O8435[i] =  + _REFACS_17_;}
	{long i; for (i = 74; i < 78; i++) O8435[i] =  + _REFACS_14_;}
	O8435[78] =  + _REFACS_15_;
	{long i; for (i = 79; i < 83; i++) O8435[i] =  + _REFACS_19_;}
	O8435[83] =  + _REFACS_22_;
	{long i; for (i = 84; i < 86; i++) O8435[i] =  + _REFACS_15_;}
	{long i; for (i = 86; i < 88; i++) O8435[i] =  + _REFACS_18_;}
	{long i; for (i = 88; i < 90; i++) O8435[i] =  + _REFACS_23_;}
	{long i; for (i = 93; i < 95; i++) O8435[i] =  + _REFACS_30_;}
	{long i; for (i = 98; i < 100; i++) O8435[i] =  + _REFACS_36_;}
}

long O8436[100];
void O8436_init () {
	O8436[0] =  + _REFACS_11_;
	O8436[1] =  + _REFACS_14_;
	O8436[2] =  + _REFACS_30_;
	O8436[3] =  + _REFACS_36_;
	O8436[4] =  + _REFACS_31_;
	O8436[5] =  + _REFACS_37_;
	O8436[6] =  + _REFACS_31_;
	O8436[7] =  + _REFACS_32_;
	O8436[8] =  + _REFACS_31_;
	O8436[9] =  + _REFACS_38_;
	O8436[10] =  + _REFACS_40_;
	O8436[11] =  + _REFACS_38_;
	{long i; for (i = 12; i < 15; i++) O8436[i] =  + _REFACS_33_;}
	{long i; for (i = 15; i < 18; i++) O8436[i] =  + _REFACS_40_;}
	{long i; for (i = 18; i < 22; i++) O8436[i] =  + _REFACS_33_;}
	{long i; for (i = 22; i < 24; i++) O8436[i] =  + _REFACS_37_;}
	{long i; for (i = 24; i < 26; i++) O8436[i] =  + _REFACS_40_;}
	O8436[26] =  + _REFACS_39_;
	O8436[27] =  + _REFACS_40_;
	{long i; for (i = 28; i < 30; i++) O8436[i] =  + _REFACS_39_;}
	{long i; for (i = 30; i < 32; i++) O8436[i] =  + _REFACS_44_;}
	{long i; for (i = 32; i < 34; i++) O8436[i] =  + _REFACS_47_;}
	O8436[34] =  + _REFACS_30_;
	O8436[35] =  + _REFACS_31_;
	O8436[36] =  + _REFACS_32_;
	O8436[37] =  + _REFACS_34_;
	O8436[38] =  + _REFACS_30_;
	O8436[39] =  + _REFACS_32_;
	{long i; for (i = 40; i < 42; i++) O8436[i] =  + _REFACS_31_;}
	{long i; for (i = 42; i < 44; i++) O8436[i] =  + _REFACS_32_;}
	{long i; for (i = 44; i < 46; i++) O8436[i] =  + _REFACS_31_;}
	O8436[46] =  + _REFACS_34_;
	O8436[47] =  + _REFACS_32_;
	{long i; for (i = 48; i < 50; i++) O8436[i] =  + _REFACS_36_;}
	O8436[50] =  + _REFACS_37_;
	O8436[51] =  + _REFACS_39_;
	O8436[52] =  + _REFACS_41_;
	O8436[53] =  + _REFACS_38_;
	O8436[54] =  + _REFACS_39_;
	{long i; for (i = 55; i < 57; i++) O8436[i] =  + _REFACS_40_;}
	{long i; for (i = 57; i < 59; i++) O8436[i] =  + _REFACS_39_;}
	O8436[59] =  + _REFACS_37_;
	O8436[60] =  + _REFACS_38_;
	O8436[61] =  + _REFACS_41_;
	O8436[62] =  + _REFACS_39_;
	O8436[63] =  + _REFACS_44_;
	O8436[64] =  + _REFACS_14_;
	{long i; for (i = 65; i < 67; i++) O8436[i] =  + _REFACS_16_;}
	O8436[67] =  + _REFACS_14_;
	{long i; for (i = 68; i < 70; i++) O8436[i] =  + _REFACS_18_;}
	{long i; for (i = 70; i < 72; i++) O8436[i] =  + _REFACS_19_;}
	{long i; for (i = 72; i < 74; i++) O8436[i] =  + _REFACS_18_;}
	{long i; for (i = 74; i < 78; i++) O8436[i] =  + _REFACS_15_;}
	O8436[78] =  + _REFACS_16_;
	{long i; for (i = 79; i < 83; i++) O8436[i] =  + _REFACS_20_;}
	O8436[83] =  + _REFACS_23_;
	{long i; for (i = 84; i < 86; i++) O8436[i] =  + _REFACS_16_;}
	{long i; for (i = 86; i < 88; i++) O8436[i] =  + _REFACS_19_;}
	{long i; for (i = 88; i < 90; i++) O8436[i] =  + _REFACS_24_;}
	{long i; for (i = 93; i < 95; i++) O8436[i] =  + _REFACS_31_;}
	{long i; for (i = 98; i < 100; i++) O8436[i] =  + _REFACS_37_;}
}

long O8437[100];
void O8437_init () {
	O8437[0] =  + _REFACS_12_;
	O8437[1] =  + _REFACS_15_;
	O8437[2] =  + _REFACS_31_;
	O8437[3] =  + _REFACS_37_;
	O8437[4] =  + _REFACS_32_;
	O8437[5] =  + _REFACS_38_;
	O8437[6] =  + _REFACS_32_;
	O8437[7] =  + _REFACS_33_;
	O8437[8] =  + _REFACS_32_;
	O8437[9] =  + _REFACS_39_;
	O8437[10] =  + _REFACS_41_;
	O8437[11] =  + _REFACS_39_;
	{long i; for (i = 12; i < 15; i++) O8437[i] =  + _REFACS_34_;}
	{long i; for (i = 15; i < 18; i++) O8437[i] =  + _REFACS_41_;}
	{long i; for (i = 18; i < 22; i++) O8437[i] =  + _REFACS_34_;}
	{long i; for (i = 22; i < 24; i++) O8437[i] =  + _REFACS_38_;}
	{long i; for (i = 24; i < 26; i++) O8437[i] =  + _REFACS_41_;}
	O8437[26] =  + _REFACS_40_;
	O8437[27] =  + _REFACS_41_;
	{long i; for (i = 28; i < 30; i++) O8437[i] =  + _REFACS_40_;}
	{long i; for (i = 30; i < 32; i++) O8437[i] =  + _REFACS_45_;}
	{long i; for (i = 32; i < 34; i++) O8437[i] =  + _REFACS_48_;}
	O8437[34] =  + _REFACS_31_;
	O8437[35] =  + _REFACS_32_;
	O8437[36] =  + _REFACS_33_;
	O8437[37] =  + _REFACS_35_;
	O8437[38] =  + _REFACS_31_;
	O8437[39] =  + _REFACS_33_;
	{long i; for (i = 40; i < 42; i++) O8437[i] =  + _REFACS_32_;}
	{long i; for (i = 42; i < 44; i++) O8437[i] =  + _REFACS_33_;}
	{long i; for (i = 44; i < 46; i++) O8437[i] =  + _REFACS_32_;}
	O8437[46] =  + _REFACS_35_;
	O8437[47] =  + _REFACS_33_;
	{long i; for (i = 48; i < 50; i++) O8437[i] =  + _REFACS_37_;}
	O8437[50] =  + _REFACS_38_;
	O8437[51] =  + _REFACS_40_;
	O8437[52] =  + _REFACS_42_;
	O8437[53] =  + _REFACS_39_;
	O8437[54] =  + _REFACS_40_;
	{long i; for (i = 55; i < 57; i++) O8437[i] =  + _REFACS_41_;}
	{long i; for (i = 57; i < 59; i++) O8437[i] =  + _REFACS_40_;}
	O8437[59] =  + _REFACS_38_;
	O8437[60] =  + _REFACS_39_;
	O8437[61] =  + _REFACS_42_;
	O8437[62] =  + _REFACS_40_;
	O8437[63] =  + _REFACS_45_;
	O8437[64] =  + _REFACS_15_;
	{long i; for (i = 65; i < 67; i++) O8437[i] =  + _REFACS_17_;}
	O8437[67] =  + _REFACS_15_;
	{long i; for (i = 68; i < 70; i++) O8437[i] =  + _REFACS_19_;}
	{long i; for (i = 70; i < 72; i++) O8437[i] =  + _REFACS_20_;}
	{long i; for (i = 72; i < 74; i++) O8437[i] =  + _REFACS_19_;}
	{long i; for (i = 74; i < 78; i++) O8437[i] =  + _REFACS_16_;}
	O8437[78] =  + _REFACS_17_;
	{long i; for (i = 79; i < 83; i++) O8437[i] =  + _REFACS_21_;}
	O8437[83] =  + _REFACS_24_;
	{long i; for (i = 84; i < 86; i++) O8437[i] =  + _REFACS_17_;}
	{long i; for (i = 86; i < 88; i++) O8437[i] =  + _REFACS_20_;}
	{long i; for (i = 88; i < 90; i++) O8437[i] =  + _REFACS_25_;}
	{long i; for (i = 93; i < 95; i++) O8437[i] =  + _REFACS_32_;}
	{long i; for (i = 98; i < 100; i++) O8437[i] =  + _REFACS_38_;}
}

long O8457[100];
void O8457_init () {
	O8457[0] = + _CHROFF_13_1_;
	O8457[1] = + _CHROFF_16_3_;
	O8457[2] = + _CHROFF_35_5_;
	O8457[3] = + _CHROFF_42_8_;
	O8457[4] = + _CHROFF_37_5_;
	O8457[5] = + _CHROFF_46_8_;
	O8457[6] = + _CHROFF_37_5_;
	O8457[7] = + _CHROFF_38_5_;
	O8457[8] = + _CHROFF_37_5_;
	O8457[9] = + _CHROFF_47_8_;
	O8457[10] = + _CHROFF_49_8_;
	O8457[11] = + _CHROFF_47_8_;
	{long i; for (i = 12; i < 15; i++) O8457[i] = + _CHROFF_39_6_;}
	{long i; for (i = 15; i < 18; i++) O8457[i] = + _CHROFF_49_9_;}
	{long i; for (i = 18; i < 22; i++) O8457[i] = + _CHROFF_39_6_;}
	{long i; for (i = 22; i < 24; i++) O8457[i] = + _CHROFF_47_6_;}
	O8457[24] = + _CHROFF_50_6_;
	O8457[25] = + _CHROFF_53_6_;
	O8457[26] = + _CHROFF_49_9_;
	O8457[27] = + _CHROFF_51_9_;
	{long i; for (i = 28; i < 30; i++) O8457[i] = + _CHROFF_49_9_;}
	{long i; for (i = 30; i < 32; i++) O8457[i] = + _CHROFF_59_11_;}
	O8457[32] = + _CHROFF_65_11_;
	O8457[33] = + _CHROFF_68_11_;
	O8457[34] = + _CHROFF_35_5_;
	{long i; for (i = 35; i < 37; i++) O8457[i] = + _CHROFF_37_5_;}
	O8457[37] = + _CHROFF_43_5_;
	O8457[38] = + _CHROFF_35_5_;
	O8457[39] = + _CHROFF_37_6_;
	{long i; for (i = 40; i < 42; i++) O8457[i] = + _CHROFF_36_5_;}
	{long i; for (i = 42; i < 44; i++) O8457[i] = + _CHROFF_37_5_;}
	{long i; for (i = 44; i < 46; i++) O8457[i] = + _CHROFF_36_5_;}
	O8457[46] = + _CHROFF_40_5_;
	O8457[47] = + _CHROFF_37_5_;
	O8457[48] = + _CHROFF_41_5_;
	O8457[49] = + _CHROFF_42_8_;
	O8457[50] = + _CHROFF_44_8_;
	O8457[51] = + _CHROFF_51_8_;
	O8457[52] = + _CHROFF_58_8_;
	O8457[53] = + _CHROFF_44_8_;
	O8457[54] = + _CHROFF_45_9_;
	{long i; for (i = 55; i < 57; i++) O8457[i] = + _CHROFF_46_8_;}
	O8457[57] = + _CHROFF_50_8_;
	O8457[58] = + _CHROFF_51_8_;
	O8457[59] = + _CHROFF_43_8_;
	O8457[60] = + _CHROFF_44_8_;
	O8457[61] = + _CHROFF_51_8_;
	O8457[62] = + _CHROFF_46_8_;
	O8457[63] = + _CHROFF_59_8_;
	O8457[64] = + _CHROFF_16_1_;
	O8457[65] = + _CHROFF_18_1_;
	O8457[66] = + _CHROFF_23_1_;
	O8457[67] = + _CHROFF_16_1_;
	{long i; for (i = 68; i < 70; i++) O8457[i] = + _CHROFF_20_1_;}
	{long i; for (i = 70; i < 72; i++) O8457[i] = + _CHROFF_25_1_;}
	{long i; for (i = 72; i < 74; i++) O8457[i] = + _CHROFF_21_3_;}
	{long i; for (i = 74; i < 78; i++) O8457[i] = + _CHROFF_17_2_;}
	O8457[78] = + _CHROFF_18_2_;
	{long i; for (i = 79; i < 82; i++) O8457[i] = + _CHROFF_23_4_;}
	O8457[82] = + _CHROFF_24_4_;
	O8457[83] = + _CHROFF_26_4_;
	O8457[84] = + _CHROFF_19_1_;
	O8457[85] = + _CHROFF_22_1_;
	{long i; for (i = 86; i < 88; i++) O8457[i] = + _CHROFF_21_5_;}
	{long i; for (i = 88; i < 90; i++) O8457[i] = + _CHROFF_29_8_;}
	{long i; for (i = 93; i < 95; i++) O8457[i] = + _CHROFF_36_5_;}
	{long i; for (i = 98; i < 100; i++) O8457[i] = + _CHROFF_48_8_;}
}

long O8462[100];
void O8462_init () {
	O8462[0] = + _I16OFF_13_5_4_;
	O8462[1] = + _I16OFF_16_7_4_;
	O8462[2] = + _I16OFF_35_9_4_;
	O8462[3] = + _I16OFF_42_12_6_;
	O8462[4] = + _I16OFF_37_9_4_;
	O8462[5] = + _I16OFF_46_12_6_;
	O8462[6] = + _I16OFF_37_9_4_;
	O8462[7] = + _I16OFF_38_9_4_;
	O8462[8] = + _I16OFF_37_9_4_;
	O8462[9] = + _I16OFF_47_12_6_;
	O8462[10] = + _I16OFF_49_12_6_;
	O8462[11] = + _I16OFF_47_12_6_;
	{long i; for (i = 12; i < 15; i++) O8462[i] = + _I16OFF_39_10_4_;}
	{long i; for (i = 15; i < 18; i++) O8462[i] = + _I16OFF_49_13_6_;}
	{long i; for (i = 18; i < 22; i++) O8462[i] = + _I16OFF_39_10_4_;}
	O8462[22] = + _I16OFF_47_12_4_;
	O8462[23] = + _I16OFF_47_14_4_;
	O8462[24] = + _I16OFF_50_13_4_;
	O8462[25] = + _I16OFF_53_13_4_;
	O8462[26] = + _I16OFF_49_13_6_;
	O8462[27] = + _I16OFF_51_13_6_;
	{long i; for (i = 28; i < 30; i++) O8462[i] = + _I16OFF_49_14_6_;}
	O8462[30] = + _I16OFF_59_21_6_;
	O8462[31] = + _I16OFF_59_23_6_;
	O8462[32] = + _I16OFF_65_25_6_;
	O8462[33] = + _I16OFF_68_26_6_;
	O8462[34] = + _I16OFF_35_9_4_;
	{long i; for (i = 35; i < 37; i++) O8462[i] = + _I16OFF_37_9_4_;}
	O8462[37] = + _I16OFF_43_9_4_;
	O8462[38] = + _I16OFF_35_9_4_;
	O8462[39] = + _I16OFF_37_10_4_;
	{long i; for (i = 40; i < 42; i++) O8462[i] = + _I16OFF_36_9_4_;}
	O8462[42] = + _I16OFF_37_9_4_;
	O8462[43] = + _I16OFF_37_10_4_;
	{long i; for (i = 44; i < 46; i++) O8462[i] = + _I16OFF_36_9_4_;}
	O8462[46] = + _I16OFF_40_12_4_;
	O8462[47] = + _I16OFF_37_9_4_;
	O8462[48] = + _I16OFF_41_9_4_;
	O8462[49] = + _I16OFF_42_13_6_;
	O8462[50] = + _I16OFF_44_13_6_;
	O8462[51] = + _I16OFF_51_13_6_;
	O8462[52] = + _I16OFF_58_14_6_;
	O8462[53] = + _I16OFF_44_13_6_;
	O8462[54] = + _I16OFF_45_16_6_;
	{long i; for (i = 55; i < 57; i++) O8462[i] = + _I16OFF_46_14_6_;}
	O8462[57] = + _I16OFF_50_13_6_;
	O8462[58] = + _I16OFF_51_14_6_;
	O8462[59] = + _I16OFF_43_13_6_;
	O8462[60] = + _I16OFF_44_15_6_;
	O8462[61] = + _I16OFF_51_18_6_;
	O8462[62] = + _I16OFF_46_14_6_;
	O8462[63] = + _I16OFF_59_16_6_;
	O8462[64] = + _I16OFF_16_5_4_;
	O8462[65] = + _I16OFF_18_5_4_;
	O8462[66] = + _I16OFF_23_5_4_;
	O8462[67] = + _I16OFF_16_5_4_;
	{long i; for (i = 68; i < 70; i++) O8462[i] = + _I16OFF_20_5_4_;}
	{long i; for (i = 70; i < 72; i++) O8462[i] = + _I16OFF_25_6_4_;}
	{long i; for (i = 72; i < 74; i++) O8462[i] = + _I16OFF_21_7_4_;}
	{long i; for (i = 74; i < 78; i++) O8462[i] = + _I16OFF_17_6_4_;}
	O8462[78] = + _I16OFF_18_6_4_;
	O8462[79] = + _I16OFF_23_8_4_;
	{long i; for (i = 80; i < 82; i++) O8462[i] = + _I16OFF_23_9_4_;}
	O8462[82] = + _I16OFF_24_9_4_;
	O8462[83] = + _I16OFF_26_8_4_;
	O8462[84] = + _I16OFF_19_5_4_;
	O8462[85] = + _I16OFF_22_5_4_;
	{long i; for (i = 86; i < 88; i++) O8462[i] = + _I16OFF_21_10_4_;}
	{long i; for (i = 88; i < 90; i++) O8462[i] = + _I16OFF_29_14_6_;}
	O8462[93] = + _I16OFF_36_10_4_;
	O8462[94] = + _I16OFF_36_9_4_;
	O8462[98] = + _I16OFF_48_19_6_;
	O8462[99] = + _I16OFF_48_18_6_;
}

long O8463[100];
void O8463_init () {
	O8463[0] = + _I16OFF_13_5_5_;
	O8463[1] = + _I16OFF_16_7_5_;
	O8463[2] = + _I16OFF_35_9_5_;
	O8463[3] = + _I16OFF_42_12_7_;
	O8463[4] = + _I16OFF_37_9_5_;
	O8463[5] = + _I16OFF_46_12_7_;
	O8463[6] = + _I16OFF_37_9_5_;
	O8463[7] = + _I16OFF_38_9_5_;
	O8463[8] = + _I16OFF_37_9_5_;
	O8463[9] = + _I16OFF_47_12_7_;
	O8463[10] = + _I16OFF_49_12_7_;
	O8463[11] = + _I16OFF_47_12_7_;
	{long i; for (i = 12; i < 15; i++) O8463[i] = + _I16OFF_39_10_5_;}
	{long i; for (i = 15; i < 18; i++) O8463[i] = + _I16OFF_49_13_7_;}
	{long i; for (i = 18; i < 22; i++) O8463[i] = + _I16OFF_39_10_5_;}
	O8463[22] = + _I16OFF_47_12_5_;
	O8463[23] = + _I16OFF_47_14_5_;
	O8463[24] = + _I16OFF_50_13_5_;
	O8463[25] = + _I16OFF_53_13_5_;
	O8463[26] = + _I16OFF_49_13_7_;
	O8463[27] = + _I16OFF_51_13_7_;
	{long i; for (i = 28; i < 30; i++) O8463[i] = + _I16OFF_49_14_7_;}
	O8463[30] = + _I16OFF_59_21_7_;
	O8463[31] = + _I16OFF_59_23_7_;
	O8463[32] = + _I16OFF_65_25_7_;
	O8463[33] = + _I16OFF_68_26_7_;
	O8463[34] = + _I16OFF_35_9_5_;
	{long i; for (i = 35; i < 37; i++) O8463[i] = + _I16OFF_37_9_5_;}
	O8463[37] = + _I16OFF_43_9_5_;
	O8463[38] = + _I16OFF_35_9_5_;
	O8463[39] = + _I16OFF_37_10_5_;
	{long i; for (i = 40; i < 42; i++) O8463[i] = + _I16OFF_36_9_5_;}
	O8463[42] = + _I16OFF_37_9_5_;
	O8463[43] = + _I16OFF_37_10_5_;
	{long i; for (i = 44; i < 46; i++) O8463[i] = + _I16OFF_36_9_5_;}
	O8463[46] = + _I16OFF_40_12_5_;
	O8463[47] = + _I16OFF_37_9_5_;
	O8463[48] = + _I16OFF_41_9_5_;
	O8463[49] = + _I16OFF_42_13_7_;
	O8463[50] = + _I16OFF_44_13_7_;
	O8463[51] = + _I16OFF_51_13_7_;
	O8463[52] = + _I16OFF_58_14_7_;
	O8463[53] = + _I16OFF_44_13_7_;
	O8463[54] = + _I16OFF_45_16_7_;
	{long i; for (i = 55; i < 57; i++) O8463[i] = + _I16OFF_46_14_7_;}
	O8463[57] = + _I16OFF_50_13_7_;
	O8463[58] = + _I16OFF_51_14_7_;
	O8463[59] = + _I16OFF_43_13_7_;
	O8463[60] = + _I16OFF_44_15_7_;
	O8463[61] = + _I16OFF_51_18_7_;
	O8463[62] = + _I16OFF_46_14_7_;
	O8463[63] = + _I16OFF_59_16_7_;
	O8463[64] = + _I16OFF_16_5_5_;
	O8463[65] = + _I16OFF_18_5_5_;
	O8463[66] = + _I16OFF_23_5_5_;
	O8463[67] = + _I16OFF_16_5_5_;
	{long i; for (i = 68; i < 70; i++) O8463[i] = + _I16OFF_20_5_5_;}
	{long i; for (i = 70; i < 72; i++) O8463[i] = + _I16OFF_25_6_5_;}
	{long i; for (i = 72; i < 74; i++) O8463[i] = + _I16OFF_21_7_5_;}
	{long i; for (i = 74; i < 78; i++) O8463[i] = + _I16OFF_17_6_5_;}
	O8463[78] = + _I16OFF_18_6_5_;
	O8463[79] = + _I16OFF_23_8_5_;
	{long i; for (i = 80; i < 82; i++) O8463[i] = + _I16OFF_23_9_5_;}
	O8463[82] = + _I16OFF_24_9_5_;
	O8463[83] = + _I16OFF_26_8_5_;
	O8463[84] = + _I16OFF_19_5_5_;
	O8463[85] = + _I16OFF_22_5_5_;
	{long i; for (i = 86; i < 88; i++) O8463[i] = + _I16OFF_21_10_5_;}
	{long i; for (i = 88; i < 90; i++) O8463[i] = + _I16OFF_29_14_7_;}
	O8463[93] = + _I16OFF_36_10_5_;
	O8463[94] = + _I16OFF_36_9_5_;
	O8463[98] = + _I16OFF_48_19_7_;
	O8463[99] = + _I16OFF_48_18_7_;
}

long O8465[100];
void O8465_init () {
	O8465[0] = + _CHROFF_13_4_;
	O8465[1] = + _CHROFF_16_6_;
	O8465[2] = + _CHROFF_35_8_;
	O8465[3] = + _CHROFF_42_11_;
	O8465[4] = + _CHROFF_37_8_;
	O8465[5] = + _CHROFF_46_11_;
	O8465[6] = + _CHROFF_37_8_;
	O8465[7] = + _CHROFF_38_8_;
	O8465[8] = + _CHROFF_37_8_;
	O8465[9] = + _CHROFF_47_11_;
	O8465[10] = + _CHROFF_49_11_;
	O8465[11] = + _CHROFF_47_11_;
	{long i; for (i = 12; i < 15; i++) O8465[i] = + _CHROFF_39_9_;}
	{long i; for (i = 15; i < 18; i++) O8465[i] = + _CHROFF_49_12_;}
	{long i; for (i = 18; i < 22; i++) O8465[i] = + _CHROFF_39_9_;}
	O8465[22] = + _CHROFF_47_11_;
	O8465[23] = + _CHROFF_47_13_;
	O8465[24] = + _CHROFF_50_12_;
	O8465[25] = + _CHROFF_53_12_;
	O8465[26] = + _CHROFF_49_12_;
	O8465[27] = + _CHROFF_51_12_;
	{long i; for (i = 28; i < 30; i++) O8465[i] = + _CHROFF_49_13_;}
	O8465[30] = + _CHROFF_59_20_;
	O8465[31] = + _CHROFF_59_22_;
	O8465[32] = + _CHROFF_65_24_;
	O8465[33] = + _CHROFF_68_25_;
	O8465[34] = + _CHROFF_35_8_;
	{long i; for (i = 35; i < 37; i++) O8465[i] = + _CHROFF_37_8_;}
	O8465[37] = + _CHROFF_43_8_;
	O8465[38] = + _CHROFF_35_8_;
	O8465[39] = + _CHROFF_37_9_;
	{long i; for (i = 40; i < 42; i++) O8465[i] = + _CHROFF_36_8_;}
	O8465[42] = + _CHROFF_37_8_;
	O8465[43] = + _CHROFF_37_9_;
	{long i; for (i = 44; i < 46; i++) O8465[i] = + _CHROFF_36_8_;}
	O8465[46] = + _CHROFF_40_11_;
	O8465[47] = + _CHROFF_37_8_;
	O8465[48] = + _CHROFF_41_8_;
	O8465[49] = + _CHROFF_42_12_;
	O8465[50] = + _CHROFF_44_12_;
	O8465[51] = + _CHROFF_51_12_;
	O8465[52] = + _CHROFF_58_13_;
	O8465[53] = + _CHROFF_44_12_;
	O8465[54] = + _CHROFF_45_15_;
	{long i; for (i = 55; i < 57; i++) O8465[i] = + _CHROFF_46_13_;}
	O8465[57] = + _CHROFF_50_12_;
	O8465[58] = + _CHROFF_51_13_;
	O8465[59] = + _CHROFF_43_12_;
	O8465[60] = + _CHROFF_44_14_;
	O8465[61] = + _CHROFF_51_17_;
	O8465[62] = + _CHROFF_46_13_;
	O8465[63] = + _CHROFF_59_15_;
	O8465[64] = + _CHROFF_16_4_;
	O8465[65] = + _CHROFF_18_4_;
	O8465[66] = + _CHROFF_23_4_;
	O8465[67] = + _CHROFF_16_4_;
	{long i; for (i = 68; i < 70; i++) O8465[i] = + _CHROFF_20_4_;}
	{long i; for (i = 70; i < 72; i++) O8465[i] = + _CHROFF_25_5_;}
	{long i; for (i = 72; i < 74; i++) O8465[i] = + _CHROFF_21_6_;}
	{long i; for (i = 74; i < 78; i++) O8465[i] = + _CHROFF_17_5_;}
	O8465[78] = + _CHROFF_18_5_;
	O8465[79] = + _CHROFF_23_7_;
	{long i; for (i = 80; i < 82; i++) O8465[i] = + _CHROFF_23_8_;}
	O8465[82] = + _CHROFF_24_8_;
	O8465[83] = + _CHROFF_26_7_;
	O8465[84] = + _CHROFF_19_4_;
	O8465[85] = + _CHROFF_22_4_;
	{long i; for (i = 86; i < 88; i++) O8465[i] = + _CHROFF_21_9_;}
	{long i; for (i = 88; i < 90; i++) O8465[i] = + _CHROFF_29_13_;}
	O8465[93] = + _CHROFF_36_9_;
	O8465[94] = + _CHROFF_36_8_;
	O8465[98] = + _CHROFF_48_16_;
	O8465[99] = + _CHROFF_48_15_;
}

long O8509[98];
void O8509_init () {
	O8509[0] =  + _REFACS_32_;
	O8509[1] =  + _REFACS_38_;
	O8509[2] =  + _REFACS_33_;
	O8509[3] =  + _REFACS_39_;
	O8509[4] =  + _REFACS_33_;
	O8509[5] =  + _REFACS_34_;
	O8509[6] =  + _REFACS_33_;
	O8509[7] =  + _REFACS_40_;
	O8509[8] =  + _REFACS_42_;
	O8509[9] =  + _REFACS_40_;
	{long i; for (i = 10; i < 13; i++) O8509[i] =  + _REFACS_35_;}
	{long i; for (i = 13; i < 16; i++) O8509[i] =  + _REFACS_42_;}
	{long i; for (i = 16; i < 20; i++) O8509[i] =  + _REFACS_35_;}
	{long i; for (i = 20; i < 22; i++) O8509[i] =  + _REFACS_39_;}
	{long i; for (i = 22; i < 24; i++) O8509[i] =  + _REFACS_42_;}
	O8509[24] =  + _REFACS_41_;
	O8509[25] =  + _REFACS_42_;
	{long i; for (i = 26; i < 28; i++) O8509[i] =  + _REFACS_41_;}
	{long i; for (i = 28; i < 30; i++) O8509[i] =  + _REFACS_46_;}
	{long i; for (i = 30; i < 32; i++) O8509[i] =  + _REFACS_49_;}
	O8509[32] =  + _REFACS_32_;
	O8509[33] =  + _REFACS_33_;
	O8509[34] =  + _REFACS_34_;
	O8509[35] =  + _REFACS_36_;
	O8509[36] =  + _REFACS_32_;
	O8509[37] =  + _REFACS_34_;
	{long i; for (i = 38; i < 40; i++) O8509[i] =  + _REFACS_33_;}
	{long i; for (i = 40; i < 42; i++) O8509[i] =  + _REFACS_34_;}
	{long i; for (i = 42; i < 44; i++) O8509[i] =  + _REFACS_33_;}
	O8509[44] =  + _REFACS_36_;
	O8509[45] =  + _REFACS_34_;
	{long i; for (i = 46; i < 48; i++) O8509[i] =  + _REFACS_38_;}
	O8509[48] =  + _REFACS_39_;
	O8509[49] =  + _REFACS_41_;
	O8509[50] =  + _REFACS_43_;
	O8509[51] =  + _REFACS_40_;
	O8509[52] =  + _REFACS_41_;
	{long i; for (i = 53; i < 55; i++) O8509[i] =  + _REFACS_42_;}
	{long i; for (i = 55; i < 57; i++) O8509[i] =  + _REFACS_41_;}
	O8509[57] =  + _REFACS_39_;
	O8509[58] =  + _REFACS_40_;
	O8509[59] =  + _REFACS_43_;
	O8509[60] =  + _REFACS_41_;
	O8509[61] =  + _REFACS_46_;
	{long i; for (i = 91; i < 93; i++) O8509[i] =  + _REFACS_33_;}
	{long i; for (i = 96; i < 98; i++) O8509[i] =  + _REFACS_39_;}
}

long O8510[98];
void O8510_init () {
	O8510[0] =  + _REFACS_33_;
	O8510[1] =  + _REFACS_39_;
	O8510[2] =  + _REFACS_34_;
	O8510[3] =  + _REFACS_40_;
	O8510[4] =  + _REFACS_34_;
	O8510[5] =  + _REFACS_35_;
	O8510[6] =  + _REFACS_34_;
	O8510[7] =  + _REFACS_41_;
	O8510[8] =  + _REFACS_43_;
	O8510[9] =  + _REFACS_41_;
	{long i; for (i = 10; i < 13; i++) O8510[i] =  + _REFACS_36_;}
	{long i; for (i = 13; i < 16; i++) O8510[i] =  + _REFACS_43_;}
	{long i; for (i = 16; i < 20; i++) O8510[i] =  + _REFACS_36_;}
	{long i; for (i = 20; i < 22; i++) O8510[i] =  + _REFACS_40_;}
	{long i; for (i = 22; i < 24; i++) O8510[i] =  + _REFACS_43_;}
	O8510[24] =  + _REFACS_42_;
	O8510[25] =  + _REFACS_43_;
	{long i; for (i = 26; i < 28; i++) O8510[i] =  + _REFACS_42_;}
	{long i; for (i = 28; i < 30; i++) O8510[i] =  + _REFACS_47_;}
	{long i; for (i = 30; i < 32; i++) O8510[i] =  + _REFACS_50_;}
	O8510[32] =  + _REFACS_33_;
	O8510[33] =  + _REFACS_34_;
	O8510[34] =  + _REFACS_35_;
	O8510[35] =  + _REFACS_37_;
	O8510[36] =  + _REFACS_33_;
	O8510[37] =  + _REFACS_35_;
	{long i; for (i = 38; i < 40; i++) O8510[i] =  + _REFACS_34_;}
	{long i; for (i = 40; i < 42; i++) O8510[i] =  + _REFACS_35_;}
	{long i; for (i = 42; i < 44; i++) O8510[i] =  + _REFACS_34_;}
	O8510[44] =  + _REFACS_37_;
	O8510[45] =  + _REFACS_35_;
	{long i; for (i = 46; i < 48; i++) O8510[i] =  + _REFACS_39_;}
	O8510[48] =  + _REFACS_40_;
	O8510[49] =  + _REFACS_42_;
	O8510[50] =  + _REFACS_44_;
	O8510[51] =  + _REFACS_41_;
	O8510[52] =  + _REFACS_42_;
	{long i; for (i = 53; i < 55; i++) O8510[i] =  + _REFACS_43_;}
	{long i; for (i = 55; i < 57; i++) O8510[i] =  + _REFACS_42_;}
	O8510[57] =  + _REFACS_40_;
	O8510[58] =  + _REFACS_41_;
	O8510[59] =  + _REFACS_44_;
	O8510[60] =  + _REFACS_42_;
	O8510[61] =  + _REFACS_47_;
	{long i; for (i = 91; i < 93; i++) O8510[i] =  + _REFACS_34_;}
	{long i; for (i = 96; i < 98; i++) O8510[i] =  + _REFACS_40_;}
}

long O8511[98];
void O8511_init () {
	O8511[0] =  + _REFACS_34_;
	O8511[1] =  + _REFACS_40_;
	O8511[2] =  + _REFACS_35_;
	O8511[3] =  + _REFACS_41_;
	O8511[4] =  + _REFACS_35_;
	O8511[5] =  + _REFACS_36_;
	O8511[6] =  + _REFACS_35_;
	O8511[7] =  + _REFACS_42_;
	O8511[8] =  + _REFACS_44_;
	O8511[9] =  + _REFACS_42_;
	{long i; for (i = 10; i < 13; i++) O8511[i] =  + _REFACS_37_;}
	{long i; for (i = 13; i < 16; i++) O8511[i] =  + _REFACS_44_;}
	{long i; for (i = 16; i < 20; i++) O8511[i] =  + _REFACS_37_;}
	{long i; for (i = 20; i < 22; i++) O8511[i] =  + _REFACS_41_;}
	{long i; for (i = 22; i < 24; i++) O8511[i] =  + _REFACS_44_;}
	O8511[24] =  + _REFACS_43_;
	O8511[25] =  + _REFACS_44_;
	{long i; for (i = 26; i < 28; i++) O8511[i] =  + _REFACS_43_;}
	{long i; for (i = 28; i < 30; i++) O8511[i] =  + _REFACS_48_;}
	{long i; for (i = 30; i < 32; i++) O8511[i] =  + _REFACS_51_;}
	O8511[32] =  + _REFACS_34_;
	O8511[33] =  + _REFACS_35_;
	O8511[34] =  + _REFACS_36_;
	O8511[35] =  + _REFACS_38_;
	O8511[36] =  + _REFACS_34_;
	O8511[37] =  + _REFACS_36_;
	{long i; for (i = 38; i < 40; i++) O8511[i] =  + _REFACS_35_;}
	{long i; for (i = 40; i < 42; i++) O8511[i] =  + _REFACS_36_;}
	{long i; for (i = 42; i < 44; i++) O8511[i] =  + _REFACS_35_;}
	O8511[44] =  + _REFACS_38_;
	O8511[45] =  + _REFACS_36_;
	{long i; for (i = 46; i < 48; i++) O8511[i] =  + _REFACS_40_;}
	O8511[48] =  + _REFACS_41_;
	O8511[49] =  + _REFACS_43_;
	O8511[50] =  + _REFACS_45_;
	O8511[51] =  + _REFACS_42_;
	O8511[52] =  + _REFACS_43_;
	{long i; for (i = 53; i < 55; i++) O8511[i] =  + _REFACS_44_;}
	{long i; for (i = 55; i < 57; i++) O8511[i] =  + _REFACS_43_;}
	O8511[57] =  + _REFACS_41_;
	O8511[58] =  + _REFACS_42_;
	O8511[59] =  + _REFACS_45_;
	O8511[60] =  + _REFACS_43_;
	O8511[61] =  + _REFACS_48_;
	{long i; for (i = 91; i < 93; i++) O8511[i] =  + _REFACS_35_;}
	{long i; for (i = 96; i < 98; i++) O8511[i] =  + _REFACS_41_;}
}

long O8541[97];
void O8541_init () {
	O8541[0] = + _LNGOFF_42_12_10_2_;
	O8541[2] = + _LNGOFF_46_12_10_2_;
	O8541[6] = + _LNGOFF_47_12_10_3_;
	O8541[7] = + _LNGOFF_49_12_10_5_;
	O8541[8] = + _LNGOFF_47_12_10_3_;
	{long i; for (i = 12; i < 15; i++) O8541[i] = + _LNGOFF_49_13_10_3_;}
	O8541[23] = + _LNGOFF_49_13_10_2_;
	O8541[24] = + _LNGOFF_51_13_10_2_;
	{long i; for (i = 25; i < 27; i++) O8541[i] = + _LNGOFF_49_14_10_2_;}
	O8541[27] = + _LNGOFF_59_21_10_2_;
	O8541[28] = + _LNGOFF_59_23_10_2_;
	O8541[29] = + _LNGOFF_65_25_10_2_;
	O8541[30] = + _LNGOFF_68_26_10_2_;
	O8541[46] = + _LNGOFF_42_13_10_2_;
	O8541[47] = + _LNGOFF_44_13_10_2_;
	O8541[48] = + _LNGOFF_51_13_10_5_;
	O8541[49] = + _LNGOFF_58_14_10_5_;
	O8541[50] = + _LNGOFF_44_13_10_2_;
	O8541[51] = + _LNGOFF_45_16_10_3_;
	{long i; for (i = 52; i < 54; i++) O8541[i] = + _LNGOFF_46_14_10_2_;}
	O8541[54] = + _LNGOFF_50_13_10_5_;
	O8541[55] = + _LNGOFF_51_14_10_5_;
	O8541[56] = + _LNGOFF_43_13_10_2_;
	O8541[57] = + _LNGOFF_44_15_10_2_;
	O8541[58] = + _LNGOFF_51_18_10_2_;
	O8541[59] = + _LNGOFF_46_14_10_2_;
	O8541[60] = + _LNGOFF_59_16_10_5_;
	O8541[95] = + _LNGOFF_48_19_10_2_;
	O8541[96] = + _LNGOFF_48_18_10_2_;
}

long O8542[97];
void O8542_init () {
	O8542[0] = + _LNGOFF_42_12_10_3_;
	O8542[2] = + _LNGOFF_46_12_10_3_;
	O8542[6] = + _LNGOFF_47_12_10_4_;
	O8542[7] = + _LNGOFF_49_12_10_6_;
	O8542[8] = + _LNGOFF_47_12_10_4_;
	{long i; for (i = 12; i < 15; i++) O8542[i] = + _LNGOFF_49_13_10_4_;}
	O8542[23] = + _LNGOFF_49_13_10_3_;
	O8542[24] = + _LNGOFF_51_13_10_3_;
	{long i; for (i = 25; i < 27; i++) O8542[i] = + _LNGOFF_49_14_10_3_;}
	O8542[27] = + _LNGOFF_59_21_10_3_;
	O8542[28] = + _LNGOFF_59_23_10_3_;
	O8542[29] = + _LNGOFF_65_25_10_3_;
	O8542[30] = + _LNGOFF_68_26_10_3_;
	O8542[46] = + _LNGOFF_42_13_10_3_;
	O8542[47] = + _LNGOFF_44_13_10_3_;
	O8542[48] = + _LNGOFF_51_13_10_6_;
	O8542[49] = + _LNGOFF_58_14_10_6_;
	O8542[50] = + _LNGOFF_44_13_10_3_;
	O8542[51] = + _LNGOFF_45_16_10_4_;
	{long i; for (i = 52; i < 54; i++) O8542[i] = + _LNGOFF_46_14_10_3_;}
	O8542[54] = + _LNGOFF_50_13_10_6_;
	O8542[55] = + _LNGOFF_51_14_10_6_;
	O8542[56] = + _LNGOFF_43_13_10_3_;
	O8542[57] = + _LNGOFF_44_15_10_3_;
	O8542[58] = + _LNGOFF_51_18_10_3_;
	O8542[59] = + _LNGOFF_46_14_10_3_;
	O8542[60] = + _LNGOFF_59_16_10_6_;
	O8542[95] = + _LNGOFF_48_19_10_3_;
	O8542[96] = + _LNGOFF_48_18_10_3_;
}

long O8543[97];
void O8543_init () {
	O8543[0] = + _LNGOFF_42_12_10_4_;
	O8543[2] = + _LNGOFF_46_12_10_4_;
	O8543[6] = + _LNGOFF_47_12_10_5_;
	O8543[7] = + _LNGOFF_49_12_10_7_;
	O8543[8] = + _LNGOFF_47_12_10_5_;
	{long i; for (i = 12; i < 15; i++) O8543[i] = + _LNGOFF_49_13_10_5_;}
	O8543[23] = + _LNGOFF_49_13_10_4_;
	O8543[24] = + _LNGOFF_51_13_10_4_;
	{long i; for (i = 25; i < 27; i++) O8543[i] = + _LNGOFF_49_14_10_4_;}
	O8543[27] = + _LNGOFF_59_21_10_4_;
	O8543[28] = + _LNGOFF_59_23_10_4_;
	O8543[29] = + _LNGOFF_65_25_10_4_;
	O8543[30] = + _LNGOFF_68_26_10_4_;
	O8543[46] = + _LNGOFF_42_13_10_4_;
	O8543[47] = + _LNGOFF_44_13_10_4_;
	O8543[48] = + _LNGOFF_51_13_10_7_;
	O8543[49] = + _LNGOFF_58_14_10_7_;
	O8543[50] = + _LNGOFF_44_13_10_4_;
	O8543[51] = + _LNGOFF_45_16_10_5_;
	{long i; for (i = 52; i < 54; i++) O8543[i] = + _LNGOFF_46_14_10_4_;}
	O8543[54] = + _LNGOFF_50_13_10_7_;
	O8543[55] = + _LNGOFF_51_14_10_7_;
	O8543[56] = + _LNGOFF_43_13_10_4_;
	O8543[57] = + _LNGOFF_44_15_10_4_;
	O8543[58] = + _LNGOFF_51_18_10_4_;
	O8543[59] = + _LNGOFF_46_14_10_4_;
	O8543[60] = + _LNGOFF_59_16_10_7_;
	O8543[95] = + _LNGOFF_48_19_10_4_;
	O8543[96] = + _LNGOFF_48_18_10_4_;
}

long O8544[97];
void O8544_init () {
	O8544[0] = + _LNGOFF_42_12_10_5_;
	O8544[2] = + _LNGOFF_46_12_10_5_;
	O8544[6] = + _LNGOFF_47_12_10_6_;
	O8544[7] = + _LNGOFF_49_12_10_8_;
	O8544[8] = + _LNGOFF_47_12_10_6_;
	{long i; for (i = 12; i < 15; i++) O8544[i] = + _LNGOFF_49_13_10_6_;}
	O8544[23] = + _LNGOFF_49_13_10_5_;
	O8544[24] = + _LNGOFF_51_13_10_5_;
	{long i; for (i = 25; i < 27; i++) O8544[i] = + _LNGOFF_49_14_10_5_;}
	O8544[27] = + _LNGOFF_59_21_10_5_;
	O8544[28] = + _LNGOFF_59_23_10_5_;
	O8544[29] = + _LNGOFF_65_25_10_5_;
	O8544[30] = + _LNGOFF_68_26_10_5_;
	O8544[46] = + _LNGOFF_42_13_10_5_;
	O8544[47] = + _LNGOFF_44_13_10_5_;
	O8544[48] = + _LNGOFF_51_13_10_8_;
	O8544[49] = + _LNGOFF_58_14_10_8_;
	O8544[50] = + _LNGOFF_44_13_10_5_;
	O8544[51] = + _LNGOFF_45_16_10_6_;
	{long i; for (i = 52; i < 54; i++) O8544[i] = + _LNGOFF_46_14_10_5_;}
	O8544[54] = + _LNGOFF_50_13_10_8_;
	O8544[55] = + _LNGOFF_51_14_10_8_;
	O8544[56] = + _LNGOFF_43_13_10_5_;
	O8544[57] = + _LNGOFF_44_15_10_5_;
	O8544[58] = + _LNGOFF_51_18_10_5_;
	O8544[59] = + _LNGOFF_46_14_10_5_;
	O8544[60] = + _LNGOFF_59_16_10_8_;
	O8544[95] = + _LNGOFF_48_19_10_5_;
	O8544[96] = + _LNGOFF_48_18_10_5_;
}

long O8549[97];
void O8549_init () {
	O8549[0] =  + _REFACS_41_;
	O8549[2] =  + _REFACS_42_;
	O8549[6] =  + _REFACS_43_;
	O8549[7] =  + _REFACS_45_;
	O8549[8] =  + _REFACS_43_;
	{long i; for (i = 12; i < 15; i++) O8549[i] =  + _REFACS_45_;}
	O8549[23] =  + _REFACS_44_;
	O8549[24] =  + _REFACS_45_;
	{long i; for (i = 25; i < 27; i++) O8549[i] =  + _REFACS_44_;}
	{long i; for (i = 27; i < 29; i++) O8549[i] =  + _REFACS_49_;}
	{long i; for (i = 29; i < 31; i++) O8549[i] =  + _REFACS_52_;}
	O8549[46] =  + _REFACS_41_;
	O8549[47] =  + _REFACS_42_;
	O8549[48] =  + _REFACS_44_;
	O8549[49] =  + _REFACS_46_;
	O8549[50] =  + _REFACS_43_;
	O8549[51] =  + _REFACS_44_;
	{long i; for (i = 52; i < 54; i++) O8549[i] =  + _REFACS_45_;}
	{long i; for (i = 54; i < 56; i++) O8549[i] =  + _REFACS_44_;}
	O8549[56] =  + _REFACS_42_;
	O8549[57] =  + _REFACS_43_;
	O8549[58] =  + _REFACS_46_;
	O8549[59] =  + _REFACS_44_;
	O8549[60] =  + _REFACS_49_;
	{long i; for (i = 95; i < 97; i++) O8549[i] =  + _REFACS_42_;}
}

long O8558[97];
void O8558_init () {
	O8558[0] = + _I16OFF_42_12_8_;
	O8558[2] = + _I16OFF_46_12_8_;
	O8558[6] = + _I16OFF_47_12_8_;
	O8558[7] = + _I16OFF_49_12_8_;
	O8558[8] = + _I16OFF_47_12_8_;
	{long i; for (i = 12; i < 15; i++) O8558[i] = + _I16OFF_49_13_8_;}
	O8558[23] = + _I16OFF_49_13_8_;
	O8558[24] = + _I16OFF_51_13_8_;
	{long i; for (i = 25; i < 27; i++) O8558[i] = + _I16OFF_49_14_8_;}
	O8558[27] = + _I16OFF_59_21_8_;
	O8558[28] = + _I16OFF_59_23_8_;
	O8558[29] = + _I16OFF_65_25_8_;
	O8558[30] = + _I16OFF_68_26_8_;
	O8558[46] = + _I16OFF_42_13_8_;
	O8558[47] = + _I16OFF_44_13_8_;
	O8558[48] = + _I16OFF_51_13_8_;
	O8558[49] = + _I16OFF_58_14_8_;
	O8558[50] = + _I16OFF_44_13_8_;
	O8558[51] = + _I16OFF_45_16_8_;
	{long i; for (i = 52; i < 54; i++) O8558[i] = + _I16OFF_46_14_8_;}
	O8558[54] = + _I16OFF_50_13_8_;
	O8558[55] = + _I16OFF_51_14_8_;
	O8558[56] = + _I16OFF_43_13_8_;
	O8558[57] = + _I16OFF_44_15_8_;
	O8558[58] = + _I16OFF_51_18_8_;
	O8558[59] = + _I16OFF_46_14_8_;
	O8558[60] = + _I16OFF_59_16_8_;
	O8558[95] = + _I16OFF_48_19_8_;
	O8558[96] = + _I16OFF_48_18_8_;
}

long O8559[97];
void O8559_init () {
	O8559[0] = + _I16OFF_42_12_9_;
	O8559[2] = + _I16OFF_46_12_9_;
	O8559[6] = + _I16OFF_47_12_9_;
	O8559[7] = + _I16OFF_49_12_9_;
	O8559[8] = + _I16OFF_47_12_9_;
	{long i; for (i = 12; i < 15; i++) O8559[i] = + _I16OFF_49_13_9_;}
	O8559[23] = + _I16OFF_49_13_9_;
	O8559[24] = + _I16OFF_51_13_9_;
	{long i; for (i = 25; i < 27; i++) O8559[i] = + _I16OFF_49_14_9_;}
	O8559[27] = + _I16OFF_59_21_9_;
	O8559[28] = + _I16OFF_59_23_9_;
	O8559[29] = + _I16OFF_65_25_9_;
	O8559[30] = + _I16OFF_68_26_9_;
	O8559[46] = + _I16OFF_42_13_9_;
	O8559[47] = + _I16OFF_44_13_9_;
	O8559[48] = + _I16OFF_51_13_9_;
	O8559[49] = + _I16OFF_58_14_9_;
	O8559[50] = + _I16OFF_44_13_9_;
	O8559[51] = + _I16OFF_45_16_9_;
	{long i; for (i = 52; i < 54; i++) O8559[i] = + _I16OFF_46_14_9_;}
	O8559[54] = + _I16OFF_50_13_9_;
	O8559[55] = + _I16OFF_51_14_9_;
	O8559[56] = + _I16OFF_43_13_9_;
	O8559[57] = + _I16OFF_44_15_9_;
	O8559[58] = + _I16OFF_51_18_9_;
	O8559[59] = + _I16OFF_46_14_9_;
	O8559[60] = + _I16OFF_59_16_9_;
	O8559[95] = + _I16OFF_48_19_9_;
	O8559[96] = + _I16OFF_48_18_9_;
}

long O8587[29];
void O8587_init () {
	O8587[0] =  + _REFACS_44_;
	O8587[4] =  + _REFACS_45_;
	O8587[5] =  + _REFACS_47_;
	O8587[6] =  + _REFACS_45_;
	{long i; for (i = 10; i < 13; i++) O8587[i] =  + _REFACS_47_;}
	O8587[21] =  + _REFACS_46_;
	O8587[22] =  + _REFACS_47_;
	{long i; for (i = 23; i < 25; i++) O8587[i] =  + _REFACS_46_;}
	{long i; for (i = 25; i < 27; i++) O8587[i] =  + _REFACS_51_;}
	{long i; for (i = 27; i < 29; i++) O8587[i] =  + _REFACS_54_;}
}

long O8601[29];
void O8601_init () {
	O8601[0] =  + _REFACS_45_;
	O8601[4] =  + _REFACS_46_;
	O8601[5] =  + _REFACS_48_;
	O8601[6] =  + _REFACS_46_;
	{long i; for (i = 10; i < 13; i++) O8601[i] =  + _REFACS_48_;}
	O8601[21] =  + _REFACS_47_;
	O8601[22] =  + _REFACS_48_;
	{long i; for (i = 23; i < 25; i++) O8601[i] =  + _REFACS_47_;}
	{long i; for (i = 25; i < 27; i++) O8601[i] =  + _REFACS_52_;}
	{long i; for (i = 27; i < 29; i++) O8601[i] =  + _REFACS_55_;}
}

long O8672[12];
void O8672_init () {
	{long i; for (i = 0; i < 2; i++) O8672[i] =  + _REFACS_43_;}
	{long i; for (i = 2; i < 4; i++) O8672[i] =  + _REFACS_46_;}
	{long i; for (i = 8; i < 10; i++) O8672[i] =  + _REFACS_53_;}
	{long i; for (i = 10; i < 12; i++) O8672[i] =  + _REFACS_56_;}
}

long O8673[12];
void O8673_init () {
	{long i; for (i = 0; i < 2; i++) O8673[i] =  + _REFACS_44_;}
	{long i; for (i = 2; i < 4; i++) O8673[i] =  + _REFACS_47_;}
	{long i; for (i = 8; i < 10; i++) O8673[i] =  + _REFACS_54_;}
	{long i; for (i = 10; i < 12; i++) O8673[i] =  + _REFACS_57_;}
}

long O8679[12];
void O8679_init () {
	{long i; for (i = 0; i < 2; i++) O8679[i] = + _CHROFF_47_8_;}
	O8679[2] = + _CHROFF_50_8_;
	O8679[3] = + _CHROFF_53_8_;
	{long i; for (i = 8; i < 10; i++) O8679[i] = + _CHROFF_59_13_;}
	O8679[10] = + _CHROFF_65_13_;
	O8679[11] = + _CHROFF_68_13_;
}

long O8700[12];
void O8700_init () {
	{long i; for (i = 0; i < 2; i++) O8700[i] =  + _REFACS_45_;}
	{long i; for (i = 2; i < 4; i++) O8700[i] =  + _REFACS_48_;}
	{long i; for (i = 8; i < 10; i++) O8700[i] =  + _REFACS_55_;}
	{long i; for (i = 10; i < 12; i++) O8700[i] =  + _REFACS_58_;}
}

long O8703[12];
void O8703_init () {
	{long i; for (i = 0; i < 2; i++) O8703[i] = + _CHROFF_47_9_;}
	O8703[2] = + _CHROFF_50_9_;
	O8703[3] = + _CHROFF_53_9_;
	{long i; for (i = 8; i < 10; i++) O8703[i] = + _CHROFF_59_14_;}
	O8703[10] = + _CHROFF_65_14_;
	O8703[11] = + _CHROFF_68_14_;
}

long O8704[12];
void O8704_init () {
	{long i; for (i = 0; i < 2; i++) O8704[i] =  + _REFACS_46_;}
	{long i; for (i = 2; i < 4; i++) O8704[i] =  + _REFACS_49_;}
	{long i; for (i = 8; i < 10; i++) O8704[i] =  + _REFACS_56_;}
	{long i; for (i = 10; i < 12; i++) O8704[i] =  + _REFACS_59_;}
}

long O8741[8];
void O8741_init () {
	O8741[0] =  + _REFACS_48_;
	O8741[1] =  + _REFACS_49_;
	{long i; for (i = 2; i < 4; i++) O8741[i] =  + _REFACS_48_;}
	{long i; for (i = 4; i < 6; i++) O8741[i] =  + _REFACS_57_;}
	O8741[6] =  + _REFACS_60_;
	O8741[7] =  + _REFACS_63_;
}

long O8767[4];
void O8767_init () {
	O8767[0] = + _CHROFF_59_15_;
	O8767[1] = + _CHROFF_59_17_;
	O8767[2] = + _CHROFF_65_16_;
	O8767[3] = + _CHROFF_68_16_;
}

long O8768[4];
void O8768_init () {
	O8768[0] = + _CHROFF_59_16_;
	O8768[1] = + _CHROFF_59_18_;
	O8768[2] = + _CHROFF_65_17_;
	O8768[3] = + _CHROFF_68_17_;
}

long O8769[4];
void O8769_init () {
	O8769[0] = + _CHROFF_59_17_;
	O8769[1] = + _CHROFF_59_19_;
	O8769[2] = + _CHROFF_65_18_;
	O8769[3] = + _CHROFF_68_18_;
}

long O8771[4];
void O8771_init () {
	O8771[0] = + _CHROFF_59_18_;
	O8771[1] = + _CHROFF_59_20_;
	O8771[2] = + _CHROFF_65_19_;
	O8771[3] = + _CHROFF_68_19_;
}

long O8773[4];
void O8773_init () {
	O8773[0] = + _PTROFF_59_21_10_11_0_1_;
	O8773[1] = + _PTROFF_59_23_10_11_0_1_;
	O8773[2] = + _PTROFF_65_25_10_11_0_1_;
	O8773[3] = + _PTROFF_68_26_10_11_0_1_;
}

long O8775[4];
void O8775_init () {
	O8775[0] = + _LNGOFF_59_21_10_6_;
	O8775[1] = + _LNGOFF_59_23_10_6_;
	O8775[2] = + _LNGOFF_65_25_10_6_;
	O8775[3] = + _LNGOFF_68_26_10_6_;
}

long O8776[4];
void O8776_init () {
	O8776[0] = + _LNGOFF_59_21_10_7_;
	O8776[1] = + _LNGOFF_59_23_10_7_;
	O8776[2] = + _LNGOFF_65_25_10_7_;
	O8776[3] = + _LNGOFF_68_26_10_7_;
}

long O8781[4];
void O8781_init () {
	O8781[0] = + _LNGOFF_59_21_10_8_;
	O8781[1] = + _LNGOFF_59_23_10_8_;
	O8781[2] = + _LNGOFF_65_25_10_8_;
	O8781[3] = + _LNGOFF_68_26_10_8_;
}

long O8796[4];
void O8796_init () {
	O8796[0] = + _PTROFF_59_21_10_11_0_2_;
	O8796[1] = + _PTROFF_59_23_10_11_0_2_;
	O8796[2] = + _PTROFF_65_25_10_11_0_2_;
	O8796[3] = + _PTROFF_68_26_10_11_0_2_;
}

long O8797[4];
void O8797_init () {
	O8797[0] = + _PTROFF_59_21_10_11_0_3_;
	O8797[1] = + _PTROFF_59_23_10_11_0_3_;
	O8797[2] = + _PTROFF_65_25_10_11_0_3_;
	O8797[3] = + _PTROFF_68_26_10_11_0_3_;
}

long O8799[4];
void O8799_init () {
	O8799[0] = + _LNGOFF_59_21_10_9_;
	O8799[1] = + _LNGOFF_59_23_10_9_;
	O8799[2] = + _LNGOFF_65_25_10_9_;
	O8799[3] = + _LNGOFF_68_26_10_9_;
}

long O8800[4];
void O8800_init () {
	O8800[0] = + _LNGOFF_59_21_10_10_;
	O8800[1] = + _LNGOFF_59_23_10_10_;
	O8800[2] = + _LNGOFF_65_25_10_10_;
	O8800[3] = + _LNGOFF_68_26_10_10_;
}

long O8806[2];
void O8806_init () {
	O8806[0] = + _CHROFF_65_20_;
	O8806[1] = + _CHROFF_68_20_;
}

long O8807[2];
void O8807_init () {
	O8807[0] =  + _REFACS_62_;
	O8807[1] =  + _REFACS_65_;
}

long O8810[2];
void O8810_init () {
	O8810[0] = + _CHROFF_65_21_;
	O8810[1] = + _CHROFF_68_21_;
}

long O8811[2];
void O8811_init () {
	O8811[0] = + _CHROFF_65_22_;
	O8811[1] = + _CHROFF_68_22_;
}

long O8984[51];
void O8984_init () {
	O8984[0] = + _CHROFF_42_10_;
	O8984[1] = + _CHROFF_44_10_;
	O8984[2] = + _CHROFF_51_10_;
	O8984[3] = + _CHROFF_58_10_;
	O8984[4] = + _CHROFF_44_10_;
	O8984[5] = + _CHROFF_45_11_;
	{long i; for (i = 6; i < 8; i++) O8984[i] = + _CHROFF_46_10_;}
	O8984[8] = + _CHROFF_50_10_;
	O8984[9] = + _CHROFF_51_11_;
	O8984[10] = + _CHROFF_43_10_;
	O8984[11] = + _CHROFF_44_10_;
	O8984[12] = + _CHROFF_51_13_;
	O8984[13] = + _CHROFF_46_10_;
	O8984[14] = + _CHROFF_59_10_;
	{long i; for (i = 49; i < 51; i++) O8984[i] = + _CHROFF_48_10_;}
}

long O9172[18];
void O9172_init () {
	{long i; for (i = 0; i < 2; i++) O9172[i] =  + _REFACS_20_;}
	{long i; for (i = 7; i < 11; i++) O9172[i] =  + _REFACS_22_;}
	O9172[11] =  + _REFACS_25_;
	{long i; for (i = 16; i < 18; i++) O9172[i] =  + _REFACS_26_;}
}

long O9178[5];
void O9178_init () {
	O9178[0] = + _PTROFF_23_8_6_1_0_3_;
	{long i; for (i = 1; i < 3; i++) O9178[i] = + _PTROFF_23_9_6_1_0_3_;}
	O9178[3] = + _PTROFF_24_9_6_1_0_3_;
	O9178[4] = + _PTROFF_26_8_6_2_0_3_;
}

long O9240[10];
void O9240_init () {
	{long i; for (i = 0; i < 3; i++) O9240[i] = + _LNGOFF_1_1_0_0_;}
	O9240[3] = + _LNGOFF_36_10_6_1_;
	O9240[4] = + _LNGOFF_36_9_6_1_;
	{long i; for (i = 5; i < 7; i++) O9240[i] = + _LNGOFF_6_5_0_0_;}
	O9240[7] = + _LNGOFF_6_7_0_0_;
	O9240[8] = + _LNGOFF_48_19_10_6_;
	O9240[9] = + _LNGOFF_48_18_10_6_;
}

long O9316[5];
void O9316_init () {
	{long i; for (i = 0; i < 2; i++) O9316[i] = + _PTROFF_6_5_0_3_0_0_;}
	O9316[2] = + _PTROFF_6_7_0_5_0_0_;
	O9316[3] = + _PTROFF_48_19_10_9_0_1_;
	O9316[4] = + _PTROFF_48_18_10_9_0_1_;
}

long O9324[5];
void O9324_init () {
	{long i; for (i = 0; i < 2; i++) O9324[i] = + _CHROFF_6_3_;}
	O9324[2] = + _CHROFF_6_5_;
	O9324[3] = + _CHROFF_48_17_;
	O9324[4] = + _CHROFF_48_16_;
}

long O9325[5];
void O9325_init () {
	{long i; for (i = 0; i < 2; i++) O9325[i] = + _CHROFF_6_4_;}
	O9325[2] = + _CHROFF_6_6_;
	O9325[3] = + _CHROFF_48_18_;
	O9325[4] = + _CHROFF_48_17_;
}

long O9329[5];
void O9329_init () {
	{long i; for (i = 0; i < 3; i++) O9329[i] = + _CHROFF_6_0_;}
	O9329[3] = + _CHROFF_48_12_;
	O9329[4] = + _CHROFF_48_11_;
}

long O9330[5];
void O9330_init () {
	O9330[0] = + _R64OFF_6_5_0_3_0_1_0_0_;
	O9330[1] = + _R64OFF_6_5_0_3_0_2_0_0_;
	O9330[2] = + _R64OFF_6_7_0_5_0_5_0_0_;
	O9330[3] = + _R64OFF_48_19_10_9_0_3_0_0_;
	O9330[4] = + _R64OFF_48_18_10_9_0_4_0_0_;
}

long O9349[5];
void O9349_init () {
	{long i; for (i = 0; i < 3; i++) O9349[i] =  + _REFACS_2_;}
	{long i; for (i = 3; i < 5; i++) O9349[i] =  + _REFACS_44_;}
}

long O9350[5];
void O9350_init () {
	{long i; for (i = 0; i < 3; i++) O9350[i] =  + _REFACS_3_;}
	{long i; for (i = 3; i < 5; i++) O9350[i] =  + _REFACS_45_;}
}

long O9354[5];
void O9354_init () {
	{long i; for (i = 0; i < 3; i++) O9354[i] =  + _REFACS_4_;}
	{long i; for (i = 3; i < 5; i++) O9354[i] =  + _REFACS_46_;}
}

long O9355[5];
void O9355_init () {
	{long i; for (i = 0; i < 3; i++) O9355[i] = + _CHROFF_6_1_;}
	O9355[3] = + _CHROFF_48_13_;
	O9355[4] = + _CHROFF_48_12_;
}

long O9356[5];
void O9356_init () {
	{long i; for (i = 0; i < 3; i++) O9356[i] =  + _REFACS_5_;}
	{long i; for (i = 3; i < 5; i++) O9356[i] =  + _REFACS_47_;}
}

long O9357[5];
void O9357_init () {
	{long i; for (i = 0; i < 2; i++) O9357[i] = + _LNGOFF_6_5_0_1_;}
	O9357[2] = + _LNGOFF_6_7_0_1_;
	O9357[3] = + _LNGOFF_48_19_10_7_;
	O9357[4] = + _LNGOFF_48_18_10_7_;
}

long O9358[5];
void O9358_init () {
	{long i; for (i = 0; i < 2; i++) O9358[i] = + _LNGOFF_6_5_0_2_;}
	O9358[2] = + _LNGOFF_6_7_0_2_;
	O9358[3] = + _LNGOFF_48_19_10_8_;
	O9358[4] = + _LNGOFF_48_18_10_8_;
}


#ifdef __cplusplus
}
#endif
