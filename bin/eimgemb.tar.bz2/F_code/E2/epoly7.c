#include "epoly7.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4069[451])();
void R4069_init () {
	R4069[0] = (char *(*)()) F433_4265;
	R4069[1] = (char *(*)()) F434_4265;
	R4069[2] = (char *(*)()) F435_4265;
	R4069[3] = (char *(*)()) F436_4265;
	R4069[4] = (char *(*)()) F437_4265;
	R4069[5] = (char *(*)()) F438_4265;
	R4069[6] = (char *(*)()) F439_4265;
	R4069[7] = (char *(*)()) F440_4265;
	R4069[8] = (char *(*)()) F441_4265;
	R4069[9] = (char *(*)()) F442_4265;
	R4069[10] = (char *(*)()) F443_4265;
	R4069[11] = (char *(*)()) F444_4265;
	R4069[81] = (char *(*)()) F433_4265;
	R4069[82] = (char *(*)()) F434_4265;
	R4069[83] = (char *(*)()) F435_4265;
	R4069[84] = (char *(*)()) F436_4265;
	R4069[85] = (char *(*)()) F437_4265;
	R4069[86] = (char *(*)()) F438_4265;
	R4069[87] = (char *(*)()) F439_4265;
	R4069[88] = (char *(*)()) F440_4265;
	R4069[89] = (char *(*)()) F441_4265;
	R4069[90] = (char *(*)()) F442_4265;
	R4069[91] = (char *(*)()) F443_4265;
	R4069[92] = (char *(*)()) F444_4265;
	{long i; for (i = 98; i < 101; i++) R4069[i] = (char *(*)()) F433_4265;}
	{long i; for (i = 107; i < 110; i++) R4069[i] = (char *(*)()) F433_4265;}
	R4069[111] = (char *(*)()) F433_4265;
	R4069[114] = (char *(*)()) F433_4265;
	{long i; for (i = 116; i < 119; i++) R4069[i] = (char *(*)()) F433_4265;}
	R4069[121] = (char *(*)()) F433_4265;
	R4069[122] = (char *(*)()) F437_4265;
	R4069[123] = (char *(*)()) F433_4265;
	R4069[446] = (char *(*)()) F436_4265;
	R4069[450] = (char *(*)()) F435_4265;
}

char *(*R4071[370])();
void R4071_init () {
	R4071[0] = (char *(*)()) F585_4797;
	R4071[1] = (char *(*)()) F586_4797;
	R4071[2] = (char *(*)()) F587_4797;
	R4071[3] = (char *(*)()) F588_4797;
	R4071[4] = (char *(*)()) F589_4797;
	R4071[5] = (char *(*)()) F590_4797;
	R4071[6] = (char *(*)()) F591_4797;
	R4071[7] = (char *(*)()) F592_4797;
	R4071[8] = (char *(*)()) F593_4797;
	R4071[9] = (char *(*)()) F594_4797;
	R4071[10] = (char *(*)()) F595_4797;
	R4071[11] = (char *(*)()) F596_4797;
	{long i; for (i = 17; i < 20; i++) R4071[i] = (char *(*)()) F585_4797;}
	{long i; for (i = 26; i < 29; i++) R4071[i] = (char *(*)()) F585_4797;}
	R4071[30] = (char *(*)()) F585_4797;
	R4071[33] = (char *(*)()) F585_4797;
	{long i; for (i = 35; i < 38; i++) R4071[i] = (char *(*)()) F585_4797;}
	R4071[40] = (char *(*)()) F585_4797;
	R4071[41] = (char *(*)()) F589_4797;
	R4071[42] = (char *(*)()) F585_4797;
	R4071[365] = (char *(*)()) F950_7728;
	R4071[369] = (char *(*)()) F954_7896;
}

char *(*R4073[702])();
void R4073_init () {
	R4073[0] = (char *(*)()) F445_4272;
	R4073[1] = (char *(*)()) F449_4272_4073_4;
	R4073[2] = (char *(*)()) F454_4272_4073_4;
	R4073[3] = (char *(*)()) F568_4553;
	R4073[4] = (char *(*)()) F569_4553_4073_4;
	R4073[5] = (char *(*)()) F570_4553_4073_4;
	R4073[6] = (char *(*)()) F571_4570;
	R4073[20] = (char *(*)()) F585_4789;
	R4073[21] = (char *(*)()) F586_4789_4073_4;
	R4073[22] = (char *(*)()) F587_4789_4073_4;
	R4073[23] = (char *(*)()) F588_4789_4073_4;
	R4073[24] = (char *(*)()) F589_4789_4073_4;
	R4073[25] = (char *(*)()) F590_4789_4073_4;
	R4073[26] = (char *(*)()) F591_4789_4073_4;
	R4073[27] = (char *(*)()) F592_4789_4073_4;
	R4073[28] = (char *(*)()) F593_4789_4073_4;
	R4073[29] = (char *(*)()) F594_4789_4073_4;
	R4073[30] = (char *(*)()) F595_4789_4073_4;
	R4073[31] = (char *(*)()) F596_4789_4073_4;
	{long i; for (i = 37; i < 40; i++) R4073[i] = (char *(*)()) F585_4789;}
	{long i; for (i = 46; i < 49; i++) R4073[i] = (char *(*)()) F585_4789;}
	R4073[50] = (char *(*)()) F585_4789;
	R4073[53] = (char *(*)()) F585_4789;
	{long i; for (i = 55; i < 58; i++) R4073[i] = (char *(*)()) F585_4789;}
	R4073[60] = (char *(*)()) F585_4789;
	R4073[61] = (char *(*)()) F589_4789_4073_4;
	R4073[62] = (char *(*)()) F585_4789;
	{long i; for (i = 259; i < 261; i++) R4073[i] = (char *(*)()) F448_4272_4073_4;}
	{long i; for (i = 468; i < 470; i++) R4073[i] = (char *(*)()) F445_4272;}
	R4073[510] = (char *(*)()) F445_4272;
	R4073[519] = (char *(*)()) F445_4272;
	R4073[701] = (char *(*)()) F448_4272_4073_4;
}
static void F449_4272_4073_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F449_4272(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F454_4272_4073_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F454_4272(Current, *(EIF_BOOLEAN *)arg1);
}
static void F569_4553_4073_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F569_4553(Current, *(EIF_BOOLEAN *)arg1);
}
static void F570_4553_4073_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F570_4553(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F586_4789_4073_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F586_4789(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F587_4789_4073_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F587_4789(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F588_4789_4073_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F588_4789(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F589_4789_4073_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F589_4789(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F590_4789_4073_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F590_4789(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F591_4789_4073_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F591_4789(Current, *(EIF_POINTER *)arg1);
}
static void F592_4789_4073_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F592_4789(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F593_4789_4073_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F593_4789(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F594_4789_4073_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F594_4789(Current, *(EIF_BOOLEAN *)arg1);
}
static void F595_4789_4073_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F595_4789(Current, *(EIF_REAL_32 *)arg1);
}
static void F596_4789_4073_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F596_4789(Current, *(EIF_REAL_64 *)arg1);
}
static void F448_4272_4073_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F448_4272(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R4087[581])();
void R4087_init () {
	R4087[0] = (char *(*)()) F504_4380;
	R4087[1] = (char *(*)()) F505_4380_4087_74;
	R4087[2] = (char *(*)()) F506_4380_4087_74;
	R4087[3] = (char *(*)()) F507_4380_4087_74;
	R4087[4] = (char *(*)()) F508_4380_4087_74;
	R4087[5] = (char *(*)()) F509_4380_4087_74;
	R4087[6] = (char *(*)()) F510_4380_4087_74;
	R4087[7] = (char *(*)()) F511_4380_4087_74;
	R4087[8] = (char *(*)()) F512_4380_4087_74;
	R4087[9] = (char *(*)()) F513_4380_4087_74;
	R4087[10] = (char *(*)()) F514_4380_4087_74;
	R4087[11] = (char *(*)()) F515_4380_4087_74;
	R4087[61] = (char *(*)()) F517_4459;
	R4087[62] = (char *(*)()) F521_4459_4087_74;
	R4087[63] = (char *(*)()) F526_4459_4087_74;
	R4087[64] = (char *(*)()) F517_4459;
	R4087[65] = (char *(*)()) F526_4459_4087_74;
	R4087[66] = (char *(*)()) F521_4459_4087_74;
	R4087[67] = (char *(*)()) F517_4459;
	R4087[70] = (char *(*)()) F574_4634;
	R4087[71] = (char *(*)()) F575_4634_4087_74;
	R4087[72] = (char *(*)()) F576_4634_4087_74;
	R4087[73] = (char *(*)()) F577_4634_4087_74;
	R4087[74] = (char *(*)()) F578_4634;
	R4087[75] = (char *(*)()) F579_4634_4087_74;
	R4087[76] = (char *(*)()) F580_4634_4087_74;
	R4087[77] = (char *(*)()) F574_4634;
	R4087[78] = (char *(*)()) F579_4634_4087_74;
	R4087[79] = (char *(*)()) F575_4634_4087_74;
	R4087[80] = (char *(*)()) F574_4634;
	R4087[81] = (char *(*)()) F585_4755;
	R4087[82] = (char *(*)()) F586_4755_4087_74;
	R4087[83] = (char *(*)()) F587_4755_4087_74;
	R4087[84] = (char *(*)()) F588_4755_4087_74;
	R4087[85] = (char *(*)()) F589_4755_4087_74;
	R4087[86] = (char *(*)()) F590_4755_4087_74;
	R4087[87] = (char *(*)()) F591_4755_4087_74;
	R4087[88] = (char *(*)()) F592_4755_4087_74;
	R4087[89] = (char *(*)()) F593_4755_4087_74;
	R4087[90] = (char *(*)()) F594_4755_4087_74;
	R4087[91] = (char *(*)()) F595_4755_4087_74;
	R4087[92] = (char *(*)()) F596_4755_4087_74;
	{long i; for (i = 98; i < 101; i++) R4087[i] = (char *(*)()) F585_4755;}
	{long i; for (i = 107; i < 110; i++) R4087[i] = (char *(*)()) F585_4755;}
	R4087[111] = (char *(*)()) F585_4755;
	R4087[114] = (char *(*)()) F585_4755;
	{long i; for (i = 116; i < 119; i++) R4087[i] = (char *(*)()) F585_4755;}
	R4087[121] = (char *(*)()) F585_4755;
	R4087[122] = (char *(*)()) F589_4755_4087_74;
	R4087[123] = (char *(*)()) F585_4755;
	R4087[129] = (char *(*)()) F633_5083;
	R4087[130] = (char *(*)()) F634_5083_4087_74;
	R4087[131] = (char *(*)()) F635_5083_4087_74;
	R4087[132] = (char *(*)()) F636_5083_4087_74;
	R4087[133] = (char *(*)()) F637_5083_4087_74;
	R4087[134] = (char *(*)()) F638_5083_4087_74;
	R4087[135] = (char *(*)()) F639_5083_4087_74;
	R4087[136] = (char *(*)()) F640_5083_4087_74;
	R4087[137] = (char *(*)()) F641_5083_4087_74;
	R4087[138] = (char *(*)()) F642_5083_4087_74;
	R4087[139] = (char *(*)()) F643_5083_4087_74;
	R4087[140] = (char *(*)()) F644_5083_4087_74;
	R4087[362] = (char *(*)()) F866_6219;
	R4087[445] = (char *(*)()) F949_7639_4087_74;
	R4087[446] = (char *(*)()) F950_7661_4087_74;
	R4087[449] = (char *(*)()) F953_7807_4087_74;
	R4087[450] = (char *(*)()) F954_7830_4087_74;
	{long i; for (i = 529; i < 531; i++) R4087[i] = (char *(*)()) F1025_8605;}
	R4087[571] = (char *(*)()) F1025_8605;
	R4087[580] = (char *(*)()) F1025_8605;
}
static EIF_REFERENCE F505_4380_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F505_4380(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F506_4380_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F506_4380(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F507_4380_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F507_4380(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F508_4380_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F508_4380(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F509_4380_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F509_4380(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F510_4380_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F510_4380(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F511_4380_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F511_4380(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(877, 0x00).id, 877, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F512_4380_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F512_4380(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F513_4380_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F513_4380(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F514_4380_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F514_4380(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F515_4380_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F515_4380(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(892, 0x00).id, 892, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F521_4459_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F521_4459(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F526_4459_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F526_4459(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F575_4634_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F575_4634(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F576_4634_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F576_4634(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F577_4634_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F577_4634(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F579_4634_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F579_4634(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_4634_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F580_4634(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F586_4755_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F586_4755(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_4755_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F587_4755(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_4755_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F588_4755(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_4755_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F589_4755(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F590_4755_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F590_4755(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F591_4755_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F591_4755(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F592_4755_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F592_4755(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(877, 0x00).id, 877, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F593_4755_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F593_4755(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F594_4755_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F594_4755(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F595_4755_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F595_4755(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F596_4755_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F596_4755(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(892, 0x00).id, 892, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F634_5083_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F634_5083(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F635_5083_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F635_5083(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F636_5083_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F636_5083(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F637_5083_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F637_5083(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F638_5083_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F638_5083(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F639_5083_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F639_5083(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F640_5083_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F640_5083(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(877, 0x00).id, 877, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F641_5083_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F641_5083(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F642_5083_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F642_5083(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F643_5083_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F643_5083(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F644_5083_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F644_5083(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(892, 0x00).id, 892, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F949_7639_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F949_7639(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F950_7661_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F950_7661(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F953_7807_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F953_7807(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F954_7830_4087_74 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F954_7830(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R4088[581])();
void R4088_init () {
	R4088[0] = (char *(*)()) F504_4385;
	R4088[1] = (char *(*)()) F505_4385;
	R4088[2] = (char *(*)()) F506_4385;
	R4088[3] = (char *(*)()) F507_4385;
	R4088[4] = (char *(*)()) F508_4385;
	R4088[5] = (char *(*)()) F509_4385;
	R4088[6] = (char *(*)()) F510_4385;
	R4088[7] = (char *(*)()) F511_4385;
	R4088[8] = (char *(*)()) F512_4385;
	R4088[9] = (char *(*)()) F513_4385;
	R4088[10] = (char *(*)()) F514_4385;
	R4088[11] = (char *(*)()) F515_4385;
	R4088[61] = (char *(*)()) F517_4462;
	R4088[62] = (char *(*)()) F521_4462;
	R4088[63] = (char *(*)()) F526_4462;
	R4088[64] = (char *(*)()) F517_4462;
	R4088[65] = (char *(*)()) F526_4462;
	R4088[66] = (char *(*)()) F521_4462;
	R4088[67] = (char *(*)()) F517_4462;
	R4088[70] = (char *(*)()) F574_4639;
	R4088[71] = (char *(*)()) F575_4639;
	R4088[72] = (char *(*)()) F576_4639;
	R4088[73] = (char *(*)()) F577_4639;
	R4088[74] = (char *(*)()) F578_4639;
	R4088[75] = (char *(*)()) F579_4639;
	R4088[76] = (char *(*)()) F580_4639;
	R4088[77] = (char *(*)()) F574_4639;
	R4088[78] = (char *(*)()) F579_4639;
	R4088[79] = (char *(*)()) F575_4639;
	R4088[80] = (char *(*)()) F574_4639;
	R4088[81] = (char *(*)()) F517_4462;
	R4088[82] = (char *(*)()) F518_4462;
	R4088[83] = (char *(*)()) F519_4462;
	R4088[84] = (char *(*)()) F520_4462;
	R4088[85] = (char *(*)()) F521_4462;
	R4088[86] = (char *(*)()) F522_4462;
	R4088[87] = (char *(*)()) F523_4462;
	R4088[88] = (char *(*)()) F524_4462;
	R4088[89] = (char *(*)()) F525_4462;
	R4088[90] = (char *(*)()) F526_4462;
	R4088[91] = (char *(*)()) F527_4462;
	R4088[92] = (char *(*)()) F528_4462;
	{long i; for (i = 98; i < 101; i++) R4088[i] = (char *(*)()) F517_4462;}
	{long i; for (i = 107; i < 110; i++) R4088[i] = (char *(*)()) F517_4462;}
	R4088[111] = (char *(*)()) F517_4462;
	R4088[114] = (char *(*)()) F517_4462;
	{long i; for (i = 116; i < 119; i++) R4088[i] = (char *(*)()) F517_4462;}
	R4088[121] = (char *(*)()) F517_4462;
	R4088[122] = (char *(*)()) F521_4462;
	R4088[123] = (char *(*)()) F517_4462;
	R4088[129] = (char *(*)()) F633_5091;
	R4088[130] = (char *(*)()) F634_5091;
	R4088[131] = (char *(*)()) F635_5091;
	R4088[132] = (char *(*)()) F636_5091;
	R4088[133] = (char *(*)()) F637_5091;
	R4088[134] = (char *(*)()) F638_5091;
	R4088[135] = (char *(*)()) F639_5091;
	R4088[136] = (char *(*)()) F640_5091;
	R4088[137] = (char *(*)()) F641_5091;
	R4088[138] = (char *(*)()) F642_5091;
	R4088[139] = (char *(*)()) F643_5091;
	R4088[140] = (char *(*)()) F644_5091;
	R4088[362] = (char *(*)()) F866_6249;
	{long i; for (i = 445; i < 447; i++) R4088[i] = (char *(*)()) F948_7606;}
	{long i; for (i = 449; i < 451; i++) R4088[i] = (char *(*)()) F952_7771;}
	{long i; for (i = 529; i < 531; i++) R4088[i] = (char *(*)()) F517_4462;}
	R4088[571] = (char *(*)()) F517_4462;
	R4088[580] = (char *(*)()) F517_4462;
}

EIF_TYPE_INDEX *Y4088_gen_type [608];
EIF_TYPE_INDEX Y4088 [608];
void Y4088_init (void)
{
	egc_routines_types [4088] = Y4088;
	egc_routines_gen_types [4088] = Y4088_gen_type;
	egc_routines_offset [4088] = 477;
	{long i; for (i = 0; i < 94; i++) Y4088[i] = 868;};
	{long i; for (i = 96; i < 150; i++) Y4088[i] = 868;};
	{long i; for (i = 155; i < 167; i++) Y4088[i] = 868;};
	Y4088[388] = 868;
	{long i; for (i = 470; i < 477; i++) Y4088[i] = 868;};
	Y4088[547] = 868;
	{long i; for (i = 551; i < 557; i++) Y4088[i] = 868;};
	Y4088[586] = 868;
	{long i; for (i = 595; i < 608; i++) Y4088[i] = 868;};
}

char *(*R4089[581])();
void R4089_init () {
	R4089[0] = (char *(*)()) F504_4386;
	R4089[1] = (char *(*)()) F505_4386;
	R4089[2] = (char *(*)()) F506_4386;
	R4089[3] = (char *(*)()) F507_4386;
	R4089[4] = (char *(*)()) F508_4386;
	R4089[5] = (char *(*)()) F509_4386;
	R4089[6] = (char *(*)()) F510_4386;
	R4089[7] = (char *(*)()) F511_4386;
	R4089[8] = (char *(*)()) F512_4386;
	R4089[9] = (char *(*)()) F513_4386;
	R4089[10] = (char *(*)()) F514_4386;
	R4089[11] = (char *(*)()) F515_4386;
	R4089[61] = (char *(*)()) F565_4514;
	R4089[62] = (char *(*)()) F566_4514;
	R4089[63] = (char *(*)()) F567_4514;
	R4089[64] = (char *(*)()) F565_4514;
	R4089[65] = (char *(*)()) F567_4514;
	R4089[66] = (char *(*)()) F566_4514;
	R4089[67] = (char *(*)()) F565_4514;
	R4089[70] = (char *(*)()) F574_4640;
	R4089[71] = (char *(*)()) F575_4640;
	R4089[72] = (char *(*)()) F576_4640;
	R4089[73] = (char *(*)()) F577_4640;
	R4089[74] = (char *(*)()) F578_4640;
	R4089[75] = (char *(*)()) F579_4640;
	R4089[76] = (char *(*)()) F580_4640;
	R4089[77] = (char *(*)()) F574_4640;
	R4089[78] = (char *(*)()) F579_4640;
	R4089[79] = (char *(*)()) F575_4640;
	R4089[80] = (char *(*)()) F574_4640;
	R4089[81] = (char *(*)()) F585_4770;
	R4089[82] = (char *(*)()) F586_4770;
	R4089[83] = (char *(*)()) F587_4770;
	R4089[84] = (char *(*)()) F588_4770;
	R4089[85] = (char *(*)()) F589_4770;
	R4089[86] = (char *(*)()) F590_4770;
	R4089[87] = (char *(*)()) F591_4770;
	R4089[88] = (char *(*)()) F592_4770;
	R4089[89] = (char *(*)()) F593_4770;
	R4089[90] = (char *(*)()) F594_4770;
	R4089[91] = (char *(*)()) F595_4770;
	R4089[92] = (char *(*)()) F596_4770;
	{long i; for (i = 98; i < 101; i++) R4089[i] = (char *(*)()) F585_4770;}
	{long i; for (i = 107; i < 110; i++) R4089[i] = (char *(*)()) F585_4770;}
	R4089[111] = (char *(*)()) F585_4770;
	R4089[114] = (char *(*)()) F585_4770;
	{long i; for (i = 116; i < 119; i++) R4089[i] = (char *(*)()) F585_4770;}
	R4089[121] = (char *(*)()) F585_4770;
	R4089[122] = (char *(*)()) F589_4770;
	R4089[123] = (char *(*)()) F585_4770;
	R4089[129] = (char *(*)()) F633_5092;
	R4089[130] = (char *(*)()) F634_5092;
	R4089[131] = (char *(*)()) F635_5092;
	R4089[132] = (char *(*)()) F636_5092;
	R4089[133] = (char *(*)()) F637_5092;
	R4089[134] = (char *(*)()) F638_5092;
	R4089[135] = (char *(*)()) F639_5092;
	R4089[136] = (char *(*)()) F640_5092;
	R4089[137] = (char *(*)()) F641_5092;
	R4089[138] = (char *(*)()) F642_5092;
	R4089[139] = (char *(*)()) F643_5092;
	R4089[140] = (char *(*)()) F644_5092;
	R4089[362] = (char *(*)()) F866_6248;
	{long i; for (i = 445; i < 447; i++) R4089[i] = (char *(*)()) F948_7604;}
	{long i; for (i = 449; i < 451; i++) R4089[i] = (char *(*)()) F952_7769;}
	{long i; for (i = 529; i < 531; i++) R4089[i] = (char *(*)()) F1025_8609;}
	R4089[571] = (char *(*)()) F1025_8609;
	R4089[580] = (char *(*)()) F1025_8609;
}

char *(*R4091[581])();
void R4091_init () {
	R4091[0] = (char *(*)()) F504_4395;
	R4091[1] = (char *(*)()) F505_4395;
	R4091[2] = (char *(*)()) F506_4395;
	R4091[3] = (char *(*)()) F507_4395;
	R4091[4] = (char *(*)()) F508_4395;
	R4091[5] = (char *(*)()) F509_4395;
	R4091[6] = (char *(*)()) F510_4395;
	R4091[7] = (char *(*)()) F511_4395;
	R4091[8] = (char *(*)()) F512_4395;
	R4091[9] = (char *(*)()) F513_4395;
	R4091[10] = (char *(*)()) F514_4395;
	R4091[11] = (char *(*)()) F515_4395;
	R4091[61] = (char *(*)()) F517_4467;
	R4091[62] = (char *(*)()) F521_4467;
	R4091[63] = (char *(*)()) F526_4467;
	R4091[64] = (char *(*)()) F517_4467;
	R4091[65] = (char *(*)()) F526_4467;
	R4091[66] = (char *(*)()) F521_4467;
	R4091[67] = (char *(*)()) F517_4467;
	R4091[70] = (char *(*)()) F574_4656;
	R4091[71] = (char *(*)()) F575_4656;
	R4091[72] = (char *(*)()) F576_4656;
	R4091[73] = (char *(*)()) F577_4656;
	R4091[74] = (char *(*)()) F578_4656;
	R4091[75] = (char *(*)()) F579_4656;
	R4091[76] = (char *(*)()) F580_4656;
	R4091[77] = (char *(*)()) F574_4656;
	R4091[78] = (char *(*)()) F579_4656;
	R4091[79] = (char *(*)()) F575_4656;
	R4091[80] = (char *(*)()) F574_4656;
	R4091[81] = (char *(*)()) F585_4776;
	R4091[82] = (char *(*)()) F586_4776;
	R4091[83] = (char *(*)()) F587_4776;
	R4091[84] = (char *(*)()) F588_4776;
	R4091[85] = (char *(*)()) F589_4776;
	R4091[86] = (char *(*)()) F590_4776;
	R4091[87] = (char *(*)()) F591_4776;
	R4091[88] = (char *(*)()) F592_4776;
	R4091[89] = (char *(*)()) F593_4776;
	R4091[90] = (char *(*)()) F594_4776;
	R4091[91] = (char *(*)()) F595_4776;
	R4091[92] = (char *(*)()) F596_4776;
	{long i; for (i = 98; i < 101; i++) R4091[i] = (char *(*)()) F585_4776;}
	{long i; for (i = 107; i < 110; i++) R4091[i] = (char *(*)()) F585_4776;}
	R4091[111] = (char *(*)()) F585_4776;
	R4091[114] = (char *(*)()) F585_4776;
	{long i; for (i = 116; i < 119; i++) R4091[i] = (char *(*)()) F585_4776;}
	R4091[121] = (char *(*)()) F585_4776;
	R4091[122] = (char *(*)()) F589_4776;
	R4091[123] = (char *(*)()) F585_4776;
	R4091[129] = (char *(*)()) F633_5097;
	R4091[130] = (char *(*)()) F634_5097;
	R4091[131] = (char *(*)()) F635_5097;
	R4091[132] = (char *(*)()) F636_5097;
	R4091[133] = (char *(*)()) F637_5097;
	R4091[134] = (char *(*)()) F638_5097;
	R4091[135] = (char *(*)()) F639_5097;
	R4091[136] = (char *(*)()) F640_5097;
	R4091[137] = (char *(*)()) F641_5097;
	R4091[138] = (char *(*)()) F642_5097;
	R4091[139] = (char *(*)()) F643_5097;
	R4091[140] = (char *(*)()) F644_5097;
	R4091[362] = (char *(*)()) F866_6246;
	{long i; for (i = 445; i < 447; i++) R4091[i] = (char *(*)()) F945_7464;}
	{long i; for (i = 449; i < 451; i++) R4091[i] = (char *(*)()) F945_7464;}
	{long i; for (i = 529; i < 531; i++) R4091[i] = (char *(*)()) F517_4467;}
	R4091[571] = (char *(*)()) F517_4467;
	R4091[580] = (char *(*)()) F517_4467;
}

char *(*R4118[12])();
void R4118_init () {
	R4118[0] = (char *(*)()) F504_4378;
	R4118[1] = (char *(*)()) F505_4378;
	R4118[2] = (char *(*)()) F506_4378;
	R4118[3] = (char *(*)()) F507_4378;
	R4118[4] = (char *(*)()) F508_4378;
	R4118[5] = (char *(*)()) F509_4378;
	R4118[6] = (char *(*)()) F510_4378;
	R4118[7] = (char *(*)()) F511_4378;
	R4118[8] = (char *(*)()) F512_4378;
	R4118[9] = (char *(*)()) F513_4378;
	R4118[10] = (char *(*)()) F514_4378;
	R4118[11] = (char *(*)()) F515_4378;
}

char *(*R4174[520])();
void R4174_init () {
	R4174[0] = (char *(*)()) F565_4508;
	R4174[1] = (char *(*)()) F566_4508_4174_1;
	R4174[2] = (char *(*)()) F567_4508_4174_1;
	R4174[3] = (char *(*)()) F565_4508;
	R4174[4] = (char *(*)()) F567_4508_4174_1;
	R4174[5] = (char *(*)()) F566_4508_4174_1;
	R4174[6] = (char *(*)()) F565_4508;
	R4174[20] = (char *(*)()) F585_4757;
	R4174[21] = (char *(*)()) F586_4757_4174_1;
	R4174[22] = (char *(*)()) F587_4757_4174_1;
	R4174[23] = (char *(*)()) F588_4757_4174_1;
	R4174[24] = (char *(*)()) F589_4757_4174_1;
	R4174[25] = (char *(*)()) F590_4757_4174_1;
	R4174[26] = (char *(*)()) F591_4757_4174_1;
	R4174[27] = (char *(*)()) F592_4757_4174_1;
	R4174[28] = (char *(*)()) F593_4757_4174_1;
	R4174[29] = (char *(*)()) F594_4757_4174_1;
	R4174[30] = (char *(*)()) F595_4757_4174_1;
	R4174[31] = (char *(*)()) F596_4757_4174_1;
	{long i; for (i = 37; i < 40; i++) R4174[i] = (char *(*)()) F585_4757;}
	{long i; for (i = 46; i < 49; i++) R4174[i] = (char *(*)()) F585_4757;}
	R4174[50] = (char *(*)()) F585_4757;
	R4174[53] = (char *(*)()) F585_4757;
	{long i; for (i = 55; i < 58; i++) R4174[i] = (char *(*)()) F585_4757;}
	R4174[60] = (char *(*)()) F585_4757;
	R4174[61] = (char *(*)()) F589_4757_4174_1;
	R4174[62] = (char *(*)()) F585_4757;
	{long i; for (i = 468; i < 470; i++) R4174[i] = (char *(*)()) F517_4455;}
	R4174[510] = (char *(*)()) F517_4455;
	R4174[519] = (char *(*)()) F517_4455;
}
static EIF_REFERENCE F566_4508_4174_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F566_4508(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F567_4508_4174_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F567_4508(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F586_4757_4174_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F586_4757(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_4757_4174_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F587_4757(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_4757_4174_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F588_4757(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_4757_4174_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F589_4757(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F590_4757_4174_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F590_4757(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F591_4757_4174_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F591_4757(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F592_4757_4174_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F592_4757(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(877, 0x00).id, 877, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F593_4757_4174_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F593_4757(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F594_4757_4174_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F594_4757(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F595_4757_4174_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F595_4757(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F596_4757_4174_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F596_4757(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(892, 0x00).id, 892, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R4175[520])();
void R4175_init () {
	R4175[0] = (char *(*)()) F565_4509;
	R4175[1] = (char *(*)()) F566_4509_4175_1;
	R4175[2] = (char *(*)()) F567_4509_4175_1;
	R4175[3] = (char *(*)()) F565_4509;
	R4175[4] = (char *(*)()) F567_4509_4175_1;
	R4175[5] = (char *(*)()) F566_4509_4175_1;
	R4175[6] = (char *(*)()) F565_4509;
	R4175[20] = (char *(*)()) F585_4758;
	R4175[21] = (char *(*)()) F586_4758_4175_1;
	R4175[22] = (char *(*)()) F587_4758_4175_1;
	R4175[23] = (char *(*)()) F588_4758_4175_1;
	R4175[24] = (char *(*)()) F589_4758_4175_1;
	R4175[25] = (char *(*)()) F590_4758_4175_1;
	R4175[26] = (char *(*)()) F591_4758_4175_1;
	R4175[27] = (char *(*)()) F592_4758_4175_1;
	R4175[28] = (char *(*)()) F593_4758_4175_1;
	R4175[29] = (char *(*)()) F594_4758_4175_1;
	R4175[30] = (char *(*)()) F595_4758_4175_1;
	R4175[31] = (char *(*)()) F596_4758_4175_1;
	{long i; for (i = 37; i < 40; i++) R4175[i] = (char *(*)()) F585_4758;}
	{long i; for (i = 46; i < 49; i++) R4175[i] = (char *(*)()) F585_4758;}
	R4175[50] = (char *(*)()) F585_4758;
	R4175[53] = (char *(*)()) F585_4758;
	{long i; for (i = 55; i < 58; i++) R4175[i] = (char *(*)()) F585_4758;}
	R4175[60] = (char *(*)()) F585_4758;
	R4175[61] = (char *(*)()) F589_4758_4175_1;
	R4175[62] = (char *(*)()) F585_4758;
	{long i; for (i = 468; i < 470; i++) R4175[i] = (char *(*)()) F517_4456;}
	R4175[510] = (char *(*)()) F517_4456;
	R4175[519] = (char *(*)()) F517_4456;
}
static EIF_REFERENCE F566_4509_4175_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F566_4509(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F567_4509_4175_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F567_4509(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F586_4758_4175_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F586_4758(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_4758_4175_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F587_4758(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_4758_4175_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F588_4758(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_4758_4175_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F589_4758(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F590_4758_4175_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F590_4758(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F591_4758_4175_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F591_4758(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F592_4758_4175_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F592_4758(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(877, 0x00).id, 877, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F593_4758_4175_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F593_4758(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F594_4758_4175_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F594_4758(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F595_4758_4175_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F595_4758(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F596_4758_4175_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F596_4758(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(892, 0x00).id, 892, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}

char *(*R4176[7])();
void R4176_init () {
	R4176[0] = (char *(*)()) F565_4528;
	R4176[1] = (char *(*)()) F566_4528;
	R4176[2] = (char *(*)()) F567_4528;
	R4176[3] = (char *(*)()) F565_4528;
	R4176[4] = (char *(*)()) F567_4528;
	R4176[5] = (char *(*)()) F566_4528;
	R4176[6] = (char *(*)()) F565_4528;
}

char *(*R4177[520])();
void R4177_init () {
	R4177[0] = (char *(*)()) F565_4529;
	R4177[1] = (char *(*)()) F566_4529;
	R4177[2] = (char *(*)()) F567_4529;
	R4177[3] = (char *(*)()) F565_4529;
	R4177[4] = (char *(*)()) F567_4529;
	R4177[5] = (char *(*)()) F566_4529;
	R4177[6] = (char *(*)()) F565_4529;
	R4177[20] = (char *(*)()) F585_4784;
	R4177[21] = (char *(*)()) F586_4784;
	R4177[22] = (char *(*)()) F587_4784;
	R4177[23] = (char *(*)()) F588_4784;
	R4177[24] = (char *(*)()) F589_4784;
	R4177[25] = (char *(*)()) F590_4784;
	R4177[26] = (char *(*)()) F591_4784;
	R4177[27] = (char *(*)()) F592_4784;
	R4177[28] = (char *(*)()) F593_4784;
	R4177[29] = (char *(*)()) F594_4784;
	R4177[30] = (char *(*)()) F595_4784;
	R4177[31] = (char *(*)()) F596_4784;
	{long i; for (i = 37; i < 40; i++) R4177[i] = (char *(*)()) F585_4784;}
	{long i; for (i = 46; i < 49; i++) R4177[i] = (char *(*)()) F585_4784;}
	R4177[50] = (char *(*)()) F585_4784;
	R4177[53] = (char *(*)()) F585_4784;
	{long i; for (i = 55; i < 58; i++) R4177[i] = (char *(*)()) F585_4784;}
	R4177[60] = (char *(*)()) F585_4784;
	R4177[61] = (char *(*)()) F589_4784;
	R4177[62] = (char *(*)()) F585_4784;
	{long i; for (i = 468; i < 470; i++) R4177[i] = (char *(*)()) F1025_8615;}
	R4177[510] = (char *(*)()) F1025_8615;
	R4177[519] = (char *(*)()) F1025_8615;
}

char *(*R4178[7])();
void R4178_init () {
	R4178[0] = (char *(*)()) F565_4519;
	R4178[1] = (char *(*)()) F566_4519;
	R4178[2] = (char *(*)()) F567_4519;
	R4178[3] = (char *(*)()) F565_4519;
	R4178[4] = (char *(*)()) F567_4519;
	R4178[5] = (char *(*)()) F566_4519;
	R4178[6] = (char *(*)()) F565_4519;
}

char *(*R4179[7])();
void R4179_init () {
	R4179[0] = (char *(*)()) F565_4520;
	R4179[1] = (char *(*)()) F566_4520;
	R4179[2] = (char *(*)()) F567_4520;
	R4179[3] = (char *(*)()) F565_4520;
	R4179[4] = (char *(*)()) F567_4520;
	R4179[5] = (char *(*)()) F566_4520;
	R4179[6] = (char *(*)()) F565_4520;
}

char *(*R4184[7])();
void R4184_init () {
	R4184[0] = (char *(*)()) F565_4531;
	R4184[1] = (char *(*)()) F566_4531_4184_4;
	R4184[2] = (char *(*)()) F567_4531_4184_4;
	R4184[3] = (char *(*)()) F565_4531;
	R4184[4] = (char *(*)()) F567_4531_4184_4;
	R4184[5] = (char *(*)()) F566_4531_4184_4;
	R4184[6] = (char *(*)()) F565_4531;
}
static void F566_4531_4184_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F566_4531(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F567_4531_4184_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F567_4531(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R4185[43])();
void R4185_init () {
	R4185[0] = (char *(*)()) F585_4791;
	R4185[1] = (char *(*)()) F586_4791_4185_4;
	R4185[2] = (char *(*)()) F587_4791_4185_4;
	R4185[3] = (char *(*)()) F588_4791_4185_4;
	R4185[4] = (char *(*)()) F589_4791_4185_4;
	R4185[5] = (char *(*)()) F590_4791_4185_4;
	R4185[6] = (char *(*)()) F591_4791_4185_4;
	R4185[7] = (char *(*)()) F592_4791_4185_4;
	R4185[8] = (char *(*)()) F593_4791_4185_4;
	R4185[9] = (char *(*)()) F594_4791_4185_4;
	R4185[10] = (char *(*)()) F595_4791_4185_4;
	R4185[11] = (char *(*)()) F596_4791_4185_4;
	{long i; for (i = 17; i < 20; i++) R4185[i] = (char *(*)()) F600_4834;}
	{long i; for (i = 26; i < 29; i++) R4185[i] = (char *(*)()) F600_4834;}
	R4185[30] = (char *(*)()) F600_4834;
	R4185[33] = (char *(*)()) F600_4834;
	{long i; for (i = 35; i < 38; i++) R4185[i] = (char *(*)()) F600_4834;}
	R4185[40] = (char *(*)()) F600_4834;
	R4185[41] = (char *(*)()) F601_4834_4185_4;
	R4185[42] = (char *(*)()) F600_4834;
}
static void F586_4791_4185_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F586_4791(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F587_4791_4185_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F587_4791(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F588_4791_4185_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F588_4791(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F589_4791_4185_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F589_4791(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F590_4791_4185_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F590_4791(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F591_4791_4185_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F591_4791(Current, *(EIF_POINTER *)arg1);
}
static void F592_4791_4185_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F592_4791(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F593_4791_4185_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F593_4791(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F594_4791_4185_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F594_4791(Current, *(EIF_BOOLEAN *)arg1);
}
static void F595_4791_4185_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F595_4791(Current, *(EIF_REAL_32 *)arg1);
}
static void F596_4791_4185_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F596_4791(Current, *(EIF_REAL_64 *)arg1);
}
static void F601_4834_4185_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F601_4834(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4190[7])();
void R4190_init () {
	R4190[0] = (char *(*)()) F565_4540;
	R4190[1] = (char *(*)()) F566_4540;
	R4190[2] = (char *(*)()) F567_4540;
	R4190[3] = (char *(*)()) F565_4540;
	R4190[4] = (char *(*)()) F567_4540;
	R4190[5] = (char *(*)()) F566_4540;
	R4190[6] = (char *(*)()) F565_4540;
}

char *(*R4195[7])();
void R4195_init () {
	R4195[0] = (char *(*)()) F565_4544;
	R4195[1] = (char *(*)()) F566_4544_4195_5;
	R4195[2] = (char *(*)()) F567_4544_4195_5;
	R4195[3] = (char *(*)()) F565_4544;
	R4195[4] = (char *(*)()) F567_4544_4195_5;
	R4195[5] = (char *(*)()) F566_4544_4195_5;
	R4195[6] = (char *(*)()) F565_4544;
}
static EIF_REFERENCE F566_4544_4195_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F566_4544(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F567_4544_4195_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F567_4544(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R4196[7])();
void R4196_init () {
	R4196[0] = (char *(*)()) F565_4545;
	R4196[1] = (char *(*)()) F566_4545;
	R4196[2] = (char *(*)()) F567_4545;
	R4196[3] = (char *(*)()) F565_4545;
	R4196[4] = (char *(*)()) F567_4545;
	R4196[5] = (char *(*)()) F566_4545;
	R4196[6] = (char *(*)()) F565_4545;
}

char *(*R4199[7])();
void R4199_init () {
	R4199[0] = (char *(*)()) F565_4548;
	R4199[1] = (char *(*)()) F566_4548;
	R4199[2] = (char *(*)()) F567_4548;
	R4199[3] = (char *(*)()) F565_4548;
	R4199[4] = (char *(*)()) F567_4548;
	R4199[5] = (char *(*)()) F566_4548;
	R4199[6] = (char *(*)()) F565_4548;
}

char *(*R4200[7])();
void R4200_init () {
	R4200[0] = (char *(*)()) F565_4549;
	R4200[1] = (char *(*)()) F566_4549;
	R4200[2] = (char *(*)()) F567_4549;
	R4200[3] = (char *(*)()) F565_4549;
	R4200[4] = (char *(*)()) F567_4549;
	R4200[5] = (char *(*)()) F566_4549;
	R4200[6] = (char *(*)()) F565_4549;
}

char *(*R4201[7])();
void R4201_init () {
	R4201[0] = (char *(*)()) F565_4550;
	R4201[1] = (char *(*)()) F566_4550;
	R4201[2] = (char *(*)()) F567_4550;
	R4201[3] = (char *(*)()) F565_4550;
	R4201[4] = (char *(*)()) F567_4550;
	R4201[5] = (char *(*)()) F566_4550;
	R4201[6] = (char *(*)()) F565_4550;
}

char *(*R4206[3])();
void R4206_init () {
	R4206[0] = (char *(*)()) F565_4507;
	R4206[1] = (char *(*)()) F567_4507_4206_1;
	R4206[2] = (char *(*)()) F566_4507_4206_1;
}
static EIF_REFERENCE F567_4507_4206_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F567_4507(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F566_4507_4206_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F566_4507(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4207[3])();
void R4207_init () {
	R4207[0] = (char *(*)()) F565_4538;
	R4207[1] = (char *(*)()) F567_4538;
	R4207[2] = (char *(*)()) F566_4538;
}

char *(*R4213[381])();
void R4213_init () {
	R4213[0] = (char *(*)()) F574_4677;
	R4213[1] = (char *(*)()) F575_4677;
	R4213[2] = (char *(*)()) F576_4677;
	R4213[3] = (char *(*)()) F577_4677;
	R4213[4] = (char *(*)()) F578_4677;
	R4213[5] = (char *(*)()) F579_4677;
	R4213[6] = (char *(*)()) F580_4677;
	R4213[7] = (char *(*)()) F574_4677;
	R4213[8] = (char *(*)()) F579_4677;
	R4213[9] = (char *(*)()) F575_4677;
	R4213[10] = (char *(*)()) F574_4677;
	R4213[11] = (char *(*)()) F585_4810;
	R4213[12] = (char *(*)()) F586_4810;
	R4213[13] = (char *(*)()) F587_4810;
	R4213[14] = (char *(*)()) F588_4810;
	R4213[15] = (char *(*)()) F589_4810;
	R4213[16] = (char *(*)()) F590_4810;
	R4213[17] = (char *(*)()) F591_4810;
	R4213[18] = (char *(*)()) F592_4810;
	R4213[19] = (char *(*)()) F593_4810;
	R4213[20] = (char *(*)()) F594_4810;
	R4213[21] = (char *(*)()) F595_4810;
	R4213[22] = (char *(*)()) F596_4810;
	{long i; for (i = 28; i < 31; i++) R4213[i] = (char *(*)()) F585_4810;}
	{long i; for (i = 37; i < 40; i++) R4213[i] = (char *(*)()) F585_4810;}
	R4213[41] = (char *(*)()) F585_4810;
	R4213[44] = (char *(*)()) F585_4810;
	{long i; for (i = 46; i < 49; i++) R4213[i] = (char *(*)()) F585_4810;}
	R4213[51] = (char *(*)()) F585_4810;
	R4213[52] = (char *(*)()) F589_4810;
	R4213[53] = (char *(*)()) F585_4810;
	R4213[292] = (char *(*)()) F866_6327;
	{long i; for (i = 366; i < 371; i++) R4213[i] = (char *(*)()) F939_7418;}
	R4213[376] = (char *(*)()) F950_7745;
	R4213[379] = (char *(*)()) F953_7823;
	R4213[380] = (char *(*)()) F954_7914;
}

char *(*R4225[11])();
void R4225_init () {
	R4225[0] = (char *(*)()) F574_4618;
	R4225[1] = (char *(*)()) F575_4618;
	R4225[2] = (char *(*)()) F576_4618;
	R4225[3] = (char *(*)()) F577_4618;
	R4225[4] = (char *(*)()) F578_4618;
	R4225[5] = (char *(*)()) F579_4618;
	R4225[6] = (char *(*)()) F580_4618;
	R4225[7] = (char *(*)()) F574_4618;
	R4225[8] = (char *(*)()) F579_4618;
	R4225[9] = (char *(*)()) F575_4618;
	R4225[10] = (char *(*)()) F574_4618;
}

char *(*R4228[11])();
void R4228_init () {
	R4228[0] = (char *(*)()) F574_4621;
	R4228[1] = (char *(*)()) F575_4621;
	R4228[2] = (char *(*)()) F576_4621;
	R4228[3] = (char *(*)()) F577_4621;
	R4228[4] = (char *(*)()) F578_4621;
	R4228[5] = (char *(*)()) F579_4621;
	R4228[6] = (char *(*)()) F580_4621;
	R4228[7] = (char *(*)()) F574_4621;
	R4228[8] = (char *(*)()) F579_4621;
	R4228[9] = (char *(*)()) F575_4621;
	R4228[10] = (char *(*)()) F574_4621;
}

char *(*R4229[11])();
void R4229_init () {
	R4229[0] = (char *(*)()) F574_4622;
	R4229[1] = (char *(*)()) F575_4622_4229_1;
	R4229[2] = (char *(*)()) F576_4622_4229_1;
	R4229[3] = (char *(*)()) F577_4622_4229_1;
	R4229[4] = (char *(*)()) F578_4622;
	R4229[5] = (char *(*)()) F579_4622_4229_1;
	R4229[6] = (char *(*)()) F580_4622_4229_1;
	R4229[7] = (char *(*)()) F574_4622;
	R4229[8] = (char *(*)()) F579_4622_4229_1;
	R4229[9] = (char *(*)()) F575_4622_4229_1;
	R4229[10] = (char *(*)()) F574_4622;
}
static EIF_REFERENCE F575_4622_4229_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F575_4622(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F576_4622_4229_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F576_4622(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F577_4622_4229_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F577_4622(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F579_4622_4229_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F579_4622(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_4622_4229_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F580_4622(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4234[11])();
void R4234_init () {
	R4234[0] = (char *(*)()) F574_4630;
	R4234[1] = (char *(*)()) F575_4630_4234_1;
	R4234[2] = (char *(*)()) F576_4630_4234_1;
	R4234[3] = (char *(*)()) F577_4630_4234_1;
	R4234[4] = (char *(*)()) F578_4630;
	R4234[5] = (char *(*)()) F579_4630_4234_1;
	R4234[6] = (char *(*)()) F580_4630_4234_1;
	R4234[7] = (char *(*)()) F574_4630;
	R4234[8] = (char *(*)()) F579_4630_4234_1;
	R4234[9] = (char *(*)()) F575_4630_4234_1;
	R4234[10] = (char *(*)()) F574_4630;
}
static EIF_REFERENCE F575_4630_4234_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F575_4630(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F576_4630_4234_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F576_4630(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F577_4630_4234_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F577_4630(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F579_4630_4234_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F579_4630(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_4630_4234_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F580_4630(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4235[11])();
void R4235_init () {
	R4235[0] = (char *(*)()) F574_4631;
	R4235[1] = (char *(*)()) F575_4631;
	R4235[2] = (char *(*)()) F576_4631_4235_1;
	R4235[3] = (char *(*)()) F577_4631;
	R4235[4] = (char *(*)()) F578_4631_4235_1;
	R4235[5] = (char *(*)()) F579_4631;
	R4235[6] = (char *(*)()) F580_4631_4235_1;
	R4235[7] = (char *(*)()) F574_4631;
	R4235[8] = (char *(*)()) F579_4631;
	R4235[9] = (char *(*)()) F575_4631;
	R4235[10] = (char *(*)()) F574_4631;
}
static EIF_REFERENCE F576_4631_4235_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F576_4631(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F578_4631_4235_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F578_4631(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_4631_4235_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F580_4631(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4237[11])();
void R4237_init () {
	R4237[0] = (char *(*)()) F574_4635;
	R4237[1] = (char *(*)()) F575_4635;
	R4237[2] = (char *(*)()) F576_4635_4237_63;
	R4237[3] = (char *(*)()) F577_4635;
	R4237[4] = (char *(*)()) F578_4635_4237_63;
	R4237[5] = (char *(*)()) F579_4635;
	R4237[6] = (char *(*)()) F580_4635_4237_63;
	R4237[7] = (char *(*)()) F581_4732;
	R4237[8] = (char *(*)()) F582_4732;
	R4237[9] = (char *(*)()) F583_4732;
	R4237[10] = (char *(*)()) F574_4635;
}
static EIF_INTEGER_32 F576_4635_4237_63 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F576_4635(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_INTEGER_32 F578_4635_4237_63 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F578_4635(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F580_4635_4237_63 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F580_4635(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4239[11])();
void R4239_init () {
	R4239[0] = (char *(*)()) F574_4642;
	R4239[1] = (char *(*)()) F575_4642;
	R4239[2] = (char *(*)()) F576_4642_4239_3;
	R4239[3] = (char *(*)()) F577_4642;
	R4239[4] = (char *(*)()) F578_4642_4239_3;
	R4239[5] = (char *(*)()) F579_4642;
	R4239[6] = (char *(*)()) F580_4642_4239_3;
	R4239[7] = (char *(*)()) F581_4734;
	R4239[8] = (char *(*)()) F582_4734;
	R4239[9] = (char *(*)()) F583_4734;
	R4239[10] = (char *(*)()) F574_4642;
}
static EIF_BOOLEAN F576_4642_4239_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F576_4642(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static EIF_BOOLEAN F578_4642_4239_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F578_4642(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F580_4642_4239_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F580_4642(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R4245[11])();
void R4245_init () {
	R4245[0] = (char *(*)()) F574_4650;
	R4245[1] = (char *(*)()) F575_4650;
	R4245[2] = (char *(*)()) F576_4650;
	R4245[3] = (char *(*)()) F577_4650;
	R4245[4] = (char *(*)()) F578_4650;
	R4245[5] = (char *(*)()) F579_4650;
	R4245[6] = (char *(*)()) F580_4650;
	R4245[7] = (char *(*)()) F574_4650;
	R4245[8] = (char *(*)()) F579_4650;
	R4245[9] = (char *(*)()) F575_4650;
	R4245[10] = (char *(*)()) F574_4650;
}

char *(*R4246[11])();
void R4246_init () {
	R4246[0] = (char *(*)()) F574_4651;
	R4246[1] = (char *(*)()) F575_4651;
	R4246[2] = (char *(*)()) F576_4651;
	R4246[3] = (char *(*)()) F577_4651;
	R4246[4] = (char *(*)()) F578_4651;
	R4246[5] = (char *(*)()) F579_4651;
	R4246[6] = (char *(*)()) F580_4651;
	R4246[7] = (char *(*)()) F574_4651;
	R4246[8] = (char *(*)()) F579_4651;
	R4246[9] = (char *(*)()) F575_4651;
	R4246[10] = (char *(*)()) F574_4651;
}

char *(*R4247[11])();
void R4247_init () {
	R4247[0] = (char *(*)()) F574_4652;
	R4247[1] = (char *(*)()) F575_4652;
	R4247[2] = (char *(*)()) F576_4652;
	R4247[3] = (char *(*)()) F577_4652;
	R4247[4] = (char *(*)()) F578_4652;
	R4247[5] = (char *(*)()) F579_4652;
	R4247[6] = (char *(*)()) F580_4652;
	R4247[7] = (char *(*)()) F574_4652;
	R4247[8] = (char *(*)()) F579_4652;
	R4247[9] = (char *(*)()) F575_4652;
	R4247[10] = (char *(*)()) F574_4652;
}

char *(*R4248[11])();
void R4248_init () {
	R4248[0] = (char *(*)()) F574_4653;
	R4248[1] = (char *(*)()) F575_4653;
	R4248[2] = (char *(*)()) F576_4653;
	R4248[3] = (char *(*)()) F577_4653;
	R4248[4] = (char *(*)()) F578_4653;
	R4248[5] = (char *(*)()) F579_4653;
	R4248[6] = (char *(*)()) F580_4653;
	R4248[7] = (char *(*)()) F574_4653;
	R4248[8] = (char *(*)()) F579_4653;
	R4248[9] = (char *(*)()) F575_4653;
	R4248[10] = (char *(*)()) F574_4653;
}

char *(*R4251[11])();
void R4251_init () {
	R4251[0] = (char *(*)()) F574_4657;
	R4251[1] = (char *(*)()) F575_4657;
	R4251[2] = (char *(*)()) F576_4657;
	R4251[3] = (char *(*)()) F577_4657;
	R4251[4] = (char *(*)()) F578_4657;
	R4251[5] = (char *(*)()) F579_4657;
	R4251[6] = (char *(*)()) F580_4657;
	R4251[7] = (char *(*)()) F574_4657;
	R4251[8] = (char *(*)()) F579_4657;
	R4251[9] = (char *(*)()) F575_4657;
	R4251[10] = (char *(*)()) F574_4657;
}

char *(*R4252[11])();
void R4252_init () {
	R4252[0] = (char *(*)()) F574_4658;
	R4252[1] = (char *(*)()) F575_4658;
	R4252[2] = (char *(*)()) F576_4658;
	R4252[3] = (char *(*)()) F577_4658;
	R4252[4] = (char *(*)()) F578_4658;
	R4252[5] = (char *(*)()) F579_4658;
	R4252[6] = (char *(*)()) F580_4658;
	R4252[7] = (char *(*)()) F574_4658;
	R4252[8] = (char *(*)()) F579_4658;
	R4252[9] = (char *(*)()) F575_4658;
	R4252[10] = (char *(*)()) F574_4658;
}

char *(*R4254[11])();
void R4254_init () {
	R4254[0] = (char *(*)()) F574_4660;
	R4254[1] = (char *(*)()) F575_4660;
	R4254[2] = (char *(*)()) F576_4660_4254_4;
	R4254[3] = (char *(*)()) F577_4660;
	R4254[4] = (char *(*)()) F578_4660_4254_4;
	R4254[5] = (char *(*)()) F579_4660;
	R4254[6] = (char *(*)()) F580_4660_4254_4;
	R4254[7] = (char *(*)()) F574_4660;
	R4254[8] = (char *(*)()) F579_4660;
	R4254[9] = (char *(*)()) F575_4660;
	R4254[10] = (char *(*)()) F574_4660;
}
static void F576_4660_4254_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F576_4660(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F578_4660_4254_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F578_4660(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F580_4660_4254_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F580_4660(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4256[11])();
void R4256_init () {
	R4256[0] = (char *(*)()) F574_4662;
	R4256[1] = (char *(*)()) F575_4662;
	R4256[2] = (char *(*)()) F576_4662;
	R4256[3] = (char *(*)()) F577_4662;
	R4256[4] = (char *(*)()) F578_4662;
	R4256[5] = (char *(*)()) F579_4662;
	R4256[6] = (char *(*)()) F580_4662;
	R4256[7] = (char *(*)()) F574_4662;
	R4256[8] = (char *(*)()) F579_4662;
	R4256[9] = (char *(*)()) F575_4662;
	R4256[10] = (char *(*)()) F574_4662;
}

char *(*R4257[11])();
void R4257_init () {
	R4257[0] = (char *(*)()) F574_4663;
	R4257[1] = (char *(*)()) F575_4663;
	R4257[2] = (char *(*)()) F576_4663;
	R4257[3] = (char *(*)()) F577_4663;
	R4257[4] = (char *(*)()) F578_4663;
	R4257[5] = (char *(*)()) F579_4663;
	R4257[6] = (char *(*)()) F580_4663;
	R4257[7] = (char *(*)()) F574_4663;
	R4257[8] = (char *(*)()) F579_4663;
	R4257[9] = (char *(*)()) F575_4663;
	R4257[10] = (char *(*)()) F574_4663;
}

char *(*R4263[11])();
void R4263_init () {
	R4263[0] = (char *(*)()) F574_4676;
	R4263[1] = (char *(*)()) F575_4676;
	R4263[2] = (char *(*)()) F576_4676;
	R4263[3] = (char *(*)()) F577_4676;
	R4263[4] = (char *(*)()) F578_4676;
	R4263[5] = (char *(*)()) F579_4676;
	R4263[6] = (char *(*)()) F580_4676;
	R4263[7] = (char *(*)()) F581_4736;
	R4263[8] = (char *(*)()) F582_4736;
	R4263[9] = (char *(*)()) F583_4736;
	R4263[10] = (char *(*)()) F574_4676;
}

char *(*R4272[11])();
void R4272_init () {
	R4272[0] = (char *(*)()) F574_4686;
	R4272[1] = (char *(*)()) F575_4686;
	R4272[2] = (char *(*)()) F576_4686;
	R4272[3] = (char *(*)()) F577_4686;
	R4272[4] = (char *(*)()) F578_4686;
	R4272[5] = (char *(*)()) F579_4686;
	R4272[6] = (char *(*)()) F580_4686;
	R4272[7] = (char *(*)()) F574_4686;
	R4272[8] = (char *(*)()) F579_4686;
	R4272[9] = (char *(*)()) F575_4686;
	R4272[10] = (char *(*)()) F574_4686;
}

char *(*R4273[11])();
void R4273_init () {
	R4273[0] = (char *(*)()) F574_4687;
	R4273[1] = (char *(*)()) F575_4687;
	R4273[2] = (char *(*)()) F576_4687;
	R4273[3] = (char *(*)()) F577_4687;
	R4273[4] = (char *(*)()) F578_4687;
	R4273[5] = (char *(*)()) F579_4687;
	R4273[6] = (char *(*)()) F580_4687;
	R4273[7] = (char *(*)()) F574_4687;
	R4273[8] = (char *(*)()) F579_4687;
	R4273[9] = (char *(*)()) F575_4687;
	R4273[10] = (char *(*)()) F574_4687;
}

char *(*R4280[11])();
void R4280_init () {
	R4280[0] = (char *(*)()) F574_4694;
	R4280[1] = (char *(*)()) F575_4694_4280_1;
	R4280[2] = (char *(*)()) F576_4694_4280_1;
	R4280[3] = (char *(*)()) F577_4694_4280_1;
	R4280[4] = (char *(*)()) F578_4694;
	R4280[5] = (char *(*)()) F579_4694_4280_1;
	R4280[6] = (char *(*)()) F580_4694_4280_1;
	R4280[7] = (char *(*)()) F574_4694;
	R4280[8] = (char *(*)()) F579_4694_4280_1;
	R4280[9] = (char *(*)()) F575_4694_4280_1;
	R4280[10] = (char *(*)()) F574_4694;
}
static EIF_REFERENCE F575_4694_4280_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F575_4694(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F576_4694_4280_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F576_4694(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F577_4694_4280_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F577_4694(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F579_4694_4280_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F579_4694(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_4694_4280_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F580_4694(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4281[11])();
void R4281_init () {
	R4281[0] = (char *(*)()) F574_4695;
	R4281[1] = (char *(*)()) F575_4695;
	R4281[2] = (char *(*)()) F576_4695_4281_1;
	R4281[3] = (char *(*)()) F577_4695;
	R4281[4] = (char *(*)()) F578_4695_4281_1;
	R4281[5] = (char *(*)()) F579_4695;
	R4281[6] = (char *(*)()) F580_4695_4281_1;
	R4281[7] = (char *(*)()) F574_4695;
	R4281[8] = (char *(*)()) F579_4695;
	R4281[9] = (char *(*)()) F575_4695;
	R4281[10] = (char *(*)()) F574_4695;
}
static EIF_REFERENCE F576_4695_4281_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F576_4695(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F578_4695_4281_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F578_4695(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F580_4695_4281_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F580_4695(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4282[11])();
void R4282_init () {
	R4282[0] = (char *(*)()) F574_4696;
	R4282[1] = (char *(*)()) F575_4696;
	R4282[2] = (char *(*)()) F576_4696;
	R4282[3] = (char *(*)()) F577_4696;
	R4282[4] = (char *(*)()) F578_4696;
	R4282[5] = (char *(*)()) F579_4696;
	R4282[6] = (char *(*)()) F580_4696;
	R4282[7] = (char *(*)()) F574_4696;
	R4282[8] = (char *(*)()) F579_4696;
	R4282[9] = (char *(*)()) F575_4696;
	R4282[10] = (char *(*)()) F574_4696;
}

char *(*R4283[11])();
void R4283_init () {
	R4283[0] = (char *(*)()) F574_4697;
	R4283[1] = (char *(*)()) F575_4697;
	R4283[2] = (char *(*)()) F576_4697;
	R4283[3] = (char *(*)()) F577_4697;
	R4283[4] = (char *(*)()) F578_4697;
	R4283[5] = (char *(*)()) F579_4697;
	R4283[6] = (char *(*)()) F580_4697;
	R4283[7] = (char *(*)()) F574_4697;
	R4283[8] = (char *(*)()) F579_4697;
	R4283[9] = (char *(*)()) F575_4697;
	R4283[10] = (char *(*)()) F574_4697;
}

char *(*R4284[11])();
void R4284_init () {
	R4284[0] = (char *(*)()) F574_4698;
	R4284[1] = (char *(*)()) F575_4698;
	R4284[2] = (char *(*)()) F576_4698;
	R4284[3] = (char *(*)()) F577_4698;
	R4284[4] = (char *(*)()) F578_4698;
	R4284[5] = (char *(*)()) F579_4698;
	R4284[6] = (char *(*)()) F580_4698;
	R4284[7] = (char *(*)()) F574_4698;
	R4284[8] = (char *(*)()) F579_4698;
	R4284[9] = (char *(*)()) F575_4698;
	R4284[10] = (char *(*)()) F574_4698;
}

char *(*R4285[11])();
void R4285_init () {
	R4285[0] = (char *(*)()) F574_4699;
	R4285[1] = (char *(*)()) F575_4699;
	R4285[2] = (char *(*)()) F576_4699;
	R4285[3] = (char *(*)()) F577_4699;
	R4285[4] = (char *(*)()) F578_4699;
	R4285[5] = (char *(*)()) F579_4699;
	R4285[6] = (char *(*)()) F580_4699;
	R4285[7] = (char *(*)()) F574_4699;
	R4285[8] = (char *(*)()) F579_4699;
	R4285[9] = (char *(*)()) F575_4699;
	R4285[10] = (char *(*)()) F574_4699;
}

char *(*R4286[11])();
void R4286_init () {
	R4286[0] = (char *(*)()) F574_4700;
	R4286[1] = (char *(*)()) F575_4700;
	R4286[2] = (char *(*)()) F576_4700;
	R4286[3] = (char *(*)()) F577_4700;
	R4286[4] = (char *(*)()) F578_4700;
	R4286[5] = (char *(*)()) F579_4700;
	R4286[6] = (char *(*)()) F580_4700;
	R4286[7] = (char *(*)()) F574_4700;
	R4286[8] = (char *(*)()) F579_4700;
	R4286[9] = (char *(*)()) F575_4700;
	R4286[10] = (char *(*)()) F574_4700;
}

char *(*R4288[11])();
void R4288_init () {
	R4288[0] = (char *(*)()) F574_4702;
	R4288[1] = (char *(*)()) F575_4702;
	R4288[2] = (char *(*)()) F576_4702;
	R4288[3] = (char *(*)()) F577_4702;
	R4288[4] = (char *(*)()) F578_4702;
	R4288[5] = (char *(*)()) F579_4702;
	R4288[6] = (char *(*)()) F580_4702;
	R4288[7] = (char *(*)()) F574_4702;
	R4288[8] = (char *(*)()) F579_4702;
	R4288[9] = (char *(*)()) F575_4702;
	R4288[10] = (char *(*)()) F574_4702;
}

char *(*R4289[11])();
void R4289_init () {
	R4289[0] = (char *(*)()) F574_4703;
	R4289[1] = (char *(*)()) F575_4703;
	R4289[2] = (char *(*)()) F576_4703;
	R4289[3] = (char *(*)()) F577_4703;
	R4289[4] = (char *(*)()) F578_4703;
	R4289[5] = (char *(*)()) F579_4703;
	R4289[6] = (char *(*)()) F580_4703;
	R4289[7] = (char *(*)()) F574_4703;
	R4289[8] = (char *(*)()) F579_4703;
	R4289[9] = (char *(*)()) F575_4703;
	R4289[10] = (char *(*)()) F574_4703;
}

char *(*R4290[11])();
void R4290_init () {
	R4290[0] = (char *(*)()) F574_4704;
	R4290[1] = (char *(*)()) F575_4704;
	R4290[2] = (char *(*)()) F576_4704;
	R4290[3] = (char *(*)()) F577_4704;
	R4290[4] = (char *(*)()) F578_4704;
	R4290[5] = (char *(*)()) F579_4704;
	R4290[6] = (char *(*)()) F580_4704;
	R4290[7] = (char *(*)()) F574_4704;
	R4290[8] = (char *(*)()) F579_4704;
	R4290[9] = (char *(*)()) F575_4704;
	R4290[10] = (char *(*)()) F574_4704;
}

char *(*R4294[11])();
void R4294_init () {
	R4294[0] = (char *(*)()) F574_4708;
	R4294[1] = (char *(*)()) F575_4708;
	R4294[2] = (char *(*)()) F576_4708_4294_4;
	R4294[3] = (char *(*)()) F577_4708;
	R4294[4] = (char *(*)()) F578_4708_4294_4;
	R4294[5] = (char *(*)()) F579_4708;
	R4294[6] = (char *(*)()) F580_4708_4294_4;
	R4294[7] = (char *(*)()) F574_4708;
	R4294[8] = (char *(*)()) F579_4708;
	R4294[9] = (char *(*)()) F575_4708;
	R4294[10] = (char *(*)()) F574_4708;
}
static void F576_4708_4294_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F576_4708(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F578_4708_4294_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F578_4708(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F580_4708_4294_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F580_4708(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4300[11])();
void R4300_init () {
	R4300[0] = (char *(*)()) F574_4714;
	R4300[1] = (char *(*)()) F575_4714;
	R4300[2] = (char *(*)()) F576_4714;
	R4300[3] = (char *(*)()) F577_4714;
	R4300[4] = (char *(*)()) F578_4714;
	R4300[5] = (char *(*)()) F579_4714;
	R4300[6] = (char *(*)()) F580_4714;
	R4300[7] = (char *(*)()) F574_4714;
	R4300[8] = (char *(*)()) F579_4714;
	R4300[9] = (char *(*)()) F575_4714;
	R4300[10] = (char *(*)()) F574_4714;
}

char *(*R4313[11])();
void R4313_init () {
	R4313[0] = (char *(*)()) F574_4727;
	R4313[1] = (char *(*)()) F575_4727;
	R4313[2] = (char *(*)()) F576_4727;
	R4313[3] = (char *(*)()) F577_4727;
	R4313[4] = (char *(*)()) F578_4727;
	R4313[5] = (char *(*)()) F579_4727;
	R4313[6] = (char *(*)()) F580_4727;
	R4313[7] = (char *(*)()) F574_4727;
	R4313[8] = (char *(*)()) F579_4727;
	R4313[9] = (char *(*)()) F575_4727;
	R4313[10] = (char *(*)()) F574_4727;
}

char *(*R4316[3])();
void R4316_init () {
	R4316[0] = (char *(*)()) F581_4730;
	R4316[1] = (char *(*)()) F582_4730;
	R4316[2] = (char *(*)()) F583_4730;
}

char *(*R4329[43])();
void R4329_init () {
	R4329[0] = (char *(*)()) F585_4749;
	R4329[1] = (char *(*)()) F586_4749;
	R4329[2] = (char *(*)()) F587_4749;
	R4329[3] = (char *(*)()) F588_4749;
	R4329[4] = (char *(*)()) F589_4749;
	R4329[5] = (char *(*)()) F590_4749;
	R4329[6] = (char *(*)()) F591_4749;
	R4329[7] = (char *(*)()) F592_4749;
	R4329[8] = (char *(*)()) F593_4749;
	R4329[9] = (char *(*)()) F594_4749;
	R4329[10] = (char *(*)()) F595_4749;
	R4329[11] = (char *(*)()) F596_4749;
	{long i; for (i = 17; i < 20; i++) R4329[i] = (char *(*)()) F585_4749;}
	{long i; for (i = 26; i < 29; i++) R4329[i] = (char *(*)()) F585_4749;}
	R4329[30] = (char *(*)()) F585_4749;
	R4329[33] = (char *(*)()) F585_4749;
	{long i; for (i = 35; i < 38; i++) R4329[i] = (char *(*)()) F585_4749;}
	R4329[40] = (char *(*)()) F585_4749;
	R4329[41] = (char *(*)()) F589_4749;
	R4329[42] = (char *(*)()) F585_4749;
}

char *(*R4333[43])();
void R4333_init () {
	R4333[0] = (char *(*)()) F585_4753;
	R4333[1] = (char *(*)()) F586_4753;
	R4333[2] = (char *(*)()) F587_4753;
	R4333[3] = (char *(*)()) F588_4753;
	R4333[4] = (char *(*)()) F589_4753;
	R4333[5] = (char *(*)()) F590_4753;
	R4333[6] = (char *(*)()) F591_4753;
	R4333[7] = (char *(*)()) F592_4753;
	R4333[8] = (char *(*)()) F593_4753;
	R4333[9] = (char *(*)()) F594_4753;
	R4333[10] = (char *(*)()) F595_4753;
	R4333[11] = (char *(*)()) F596_4753;
	{long i; for (i = 17; i < 20; i++) R4333[i] = (char *(*)()) F585_4753;}
	{long i; for (i = 26; i < 29; i++) R4333[i] = (char *(*)()) F585_4753;}
	R4333[30] = (char *(*)()) F585_4753;
	R4333[33] = (char *(*)()) F585_4753;
	{long i; for (i = 35; i < 38; i++) R4333[i] = (char *(*)()) F585_4753;}
	R4333[40] = (char *(*)()) F585_4753;
	R4333[41] = (char *(*)()) F589_4753;
	R4333[42] = (char *(*)()) F585_4753;
}

char *(*R4337[43])();
void R4337_init () {
	R4337[0] = (char *(*)()) F585_4772;
	R4337[1] = (char *(*)()) F586_4772;
	R4337[2] = (char *(*)()) F587_4772;
	R4337[3] = (char *(*)()) F588_4772;
	R4337[4] = (char *(*)()) F589_4772;
	R4337[5] = (char *(*)()) F590_4772;
	R4337[6] = (char *(*)()) F591_4772;
	R4337[7] = (char *(*)()) F592_4772;
	R4337[8] = (char *(*)()) F593_4772;
	R4337[9] = (char *(*)()) F594_4772;
	R4337[10] = (char *(*)()) F595_4772;
	R4337[11] = (char *(*)()) F596_4772;
	{long i; for (i = 17; i < 20; i++) R4337[i] = (char *(*)()) F585_4772;}
	{long i; for (i = 26; i < 29; i++) R4337[i] = (char *(*)()) F585_4772;}
	R4337[30] = (char *(*)()) F585_4772;
	R4337[33] = (char *(*)()) F585_4772;
	{long i; for (i = 35; i < 38; i++) R4337[i] = (char *(*)()) F585_4772;}
	R4337[40] = (char *(*)()) F585_4772;
	R4337[41] = (char *(*)()) F589_4772;
	R4337[42] = (char *(*)()) F585_4772;
}

char *(*R4341[43])();
void R4341_init () {
	R4341[0] = (char *(*)()) F585_4813;
	R4341[1] = (char *(*)()) F586_4813_4341_252;
	R4341[2] = (char *(*)()) F587_4813_4341_252;
	R4341[3] = (char *(*)()) F588_4813_4341_252;
	R4341[4] = (char *(*)()) F589_4813_4341_252;
	R4341[5] = (char *(*)()) F590_4813_4341_252;
	R4341[6] = (char *(*)()) F591_4813_4341_252;
	R4341[7] = (char *(*)()) F592_4813_4341_252;
	R4341[8] = (char *(*)()) F593_4813_4341_252;
	R4341[9] = (char *(*)()) F594_4813_4341_252;
	R4341[10] = (char *(*)()) F595_4813_4341_252;
	R4341[11] = (char *(*)()) F596_4813_4341_252;
	{long i; for (i = 17; i < 20; i++) R4341[i] = (char *(*)()) F585_4813;}
	{long i; for (i = 26; i < 29; i++) R4341[i] = (char *(*)()) F585_4813;}
	R4341[30] = (char *(*)()) F585_4813;
	R4341[33] = (char *(*)()) F585_4813;
	{long i; for (i = 35; i < 38; i++) R4341[i] = (char *(*)()) F585_4813;}
	R4341[40] = (char *(*)()) F585_4813;
	R4341[41] = (char *(*)()) F589_4813_4341_252;
	R4341[42] = (char *(*)()) F585_4813;
}
static void F586_4813_4341_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F586_4813(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F587_4813_4341_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F587_4813(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F588_4813_4341_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F588_4813(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F589_4813_4341_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F589_4813(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F590_4813_4341_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F590_4813(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F591_4813_4341_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F591_4813(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F592_4813_4341_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F592_4813(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F593_4813_4341_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F593_4813(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F594_4813_4341_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F594_4813(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F595_4813_4341_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F595_4813(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F596_4813_4341_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F596_4813(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4347[26])();
void R4347_init () {
	{long i; for (i = 0; i < 3; i++) R4347[i] = (char *(*)()) F602_4850;}
	{long i; for (i = 9; i < 12; i++) R4347[i] = (char *(*)()) F602_4850;}
	R4347[13] = (char *(*)()) F602_4850;
	R4347[16] = (char *(*)()) F602_4850;
	{long i; for (i = 18; i < 21; i++) R4347[i] = (char *(*)()) F602_4850;}
	R4347[23] = (char *(*)()) F625_4954;
	R4347[24] = (char *(*)()) F626_4954_4347_252;
	R4347[25] = (char *(*)()) F625_4954;
}
static void F626_4954_4347_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F626_4954(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R4348[26])();
void R4348_init () {
	{long i; for (i = 0; i < 3; i++) R4348[i] = (char *(*)()) F602_4851;}
	{long i; for (i = 9; i < 12; i++) R4348[i] = (char *(*)()) F602_4851;}
	R4348[13] = (char *(*)()) F602_4851;
	R4348[16] = (char *(*)()) F602_4851;
	{long i; for (i = 18; i < 21; i++) R4348[i] = (char *(*)()) F602_4851;}
	R4348[23] = (char *(*)()) F625_4955;
	R4348[24] = (char *(*)()) F626_4955_4348_252;
	R4348[25] = (char *(*)()) F625_4955;
}
static void F626_4955_4348_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F626_4955(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R4352[26])();
void R4352_init () {
	{long i; for (i = 0; i < 3; i++) R4352[i] = (char *(*)()) F600_4847;}
	{long i; for (i = 9; i < 12; i++) R4352[i] = (char *(*)()) F600_4847;}
	R4352[13] = (char *(*)()) F600_4847;
	R4352[16] = (char *(*)()) F600_4847;
	{long i; for (i = 18; i < 21; i++) R4352[i] = (char *(*)()) F600_4847;}
	R4352[23] = (char *(*)()) F600_4847;
	R4352[24] = (char *(*)()) F601_4847_4352_252;
	R4352[25] = (char *(*)()) F600_4847;
}
static void F601_4847_4352_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F601_4847(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R4353[26])();
void R4353_init () {
	{long i; for (i = 0; i < 3; i++) R4353[i] = (char *(*)()) F600_4848;}
	{long i; for (i = 9; i < 12; i++) R4353[i] = (char *(*)()) F600_4848;}
	R4353[13] = (char *(*)()) F600_4848;
	R4353[16] = (char *(*)()) F600_4848;
	{long i; for (i = 18; i < 21; i++) R4353[i] = (char *(*)()) F600_4848;}
	R4353[23] = (char *(*)()) F600_4848;
	R4353[24] = (char *(*)()) F601_4848_4353_252;
	R4353[25] = (char *(*)()) F600_4848;
}
static void F601_4848_4353_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F601_4848(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R4354[21])();
void R4354_init () {
	R4354[0] = (char *(*)()) F602_4852;
	R4354[1] = (char *(*)()) F603_4886;
	R4354[2] = (char *(*)()) F604_4887;
	{long i; for (i = 9; i < 12; i++) R4354[i] = (char *(*)()) F603_4886;}
	R4354[13] = (char *(*)()) F603_4886;
	R4354[16] = (char *(*)()) F603_4886;
	{long i; for (i = 18; i < 21; i++) R4354[i] = (char *(*)()) F603_4886;}
}

static EIF_TYPE_INDEX Y4386_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype2[] = {0xFFF9,1,865,0,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype4[] = {0xFFF9,1,865,868,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype5[] = {0xFFF9,1,865,1063,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype6[] = {0xFFF9,1,865,868,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype7[] = {0xFFF9,1,865,1026,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype8[] = {0xFFF9,1,865,830,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype9[] = {0xFFF9,1,865,1068,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype10[] = {0xFFF9,1,865,999,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype11[] = {0xFFF9,1,865,1266,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype12[] = {0xFFF9,5,865,880,868,868,868,868,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype13[] = {0xFFF9,4,865,868,868,868,868,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype14[] = {0xFFF9,1,865,868,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype15[] = {0xFFF9,1,865,953,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype16[] = {0xFFF9,7,865,868,868,892,892,892,868,868,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype17[] = {0xFFF9,2,865,868,868,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype18[] = {0xFFF9,3,865,868,868,830,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype19[] = {0xFFF9,8,865,868,868,868,892,892,892,868,868,0xFFFF};
static EIF_TYPE_INDEX Y4386_pgtype20[] = {0xFFF9,0,865,0xFFFF};
EIF_TYPE_INDEX *Y4386_gen_type [21];
EIF_TYPE_INDEX Y4386 [21];
void Y4386_init (void)
{
	egc_routines_types [4386] = Y4386;
	egc_routines_gen_types [4386] = Y4386_gen_type;
	egc_routines_offset [4386] = 601;
	Y4386_gen_type [0] = Y4386_pgtype0;
	Y4386_gen_type [1] = Y4386_pgtype1;
	Y4386_gen_type [2] = Y4386_pgtype2;
	Y4386_gen_type [3] = Y4386_pgtype3;
	Y4386_gen_type [4] = Y4386_pgtype4;
	Y4386_gen_type [5] = Y4386_pgtype5;
	Y4386_gen_type [6] = Y4386_pgtype6;
	Y4386_gen_type [7] = Y4386_pgtype7;
	Y4386_gen_type [8] = Y4386_pgtype8;
	Y4386_gen_type [9] = Y4386_pgtype9;
	Y4386_gen_type [10] = Y4386_pgtype10;
	Y4386_gen_type [11] = Y4386_pgtype11;
	Y4386_gen_type [12] = Y4386_pgtype12;
	Y4386_gen_type [13] = Y4386_pgtype13;
	Y4386_gen_type [14] = Y4386_pgtype14;
	Y4386_gen_type [15] = Y4386_pgtype15;
	Y4386_gen_type [16] = Y4386_pgtype16;
	Y4386_gen_type [17] = Y4386_pgtype17;
	Y4386_gen_type [18] = Y4386_pgtype18;
	Y4386_gen_type [19] = Y4386_pgtype19;
	Y4386_gen_type [20] = Y4386_pgtype20;
	Y4386[2] = 865;
	{long i; for (i = 4; i < 21; i++) Y4386[i] = 865;};
}

char *(*R4527[12])();
void R4527_init () {
	R4527[0] = (char *(*)()) F633_5093;
	R4527[1] = (char *(*)()) F634_5093;
	R4527[2] = (char *(*)()) F635_5093;
	R4527[3] = (char *(*)()) F636_5093;
	R4527[4] = (char *(*)()) F637_5093;
	R4527[5] = (char *(*)()) F638_5093;
	R4527[6] = (char *(*)()) F639_5093;
	R4527[7] = (char *(*)()) F640_5093;
	R4527[8] = (char *(*)()) F641_5093;
	R4527[9] = (char *(*)()) F642_5093;
	R4527[10] = (char *(*)()) F643_5093;
	R4527[11] = (char *(*)()) F644_5093;
}

char *(*R4528[12])();
void R4528_init () {
	R4528[0] = (char *(*)()) F633_5094;
	R4528[1] = (char *(*)()) F634_5094;
	R4528[2] = (char *(*)()) F635_5094;
	R4528[3] = (char *(*)()) F636_5094;
	R4528[4] = (char *(*)()) F637_5094;
	R4528[5] = (char *(*)()) F638_5094;
	R4528[6] = (char *(*)()) F639_5094;
	R4528[7] = (char *(*)()) F640_5094;
	R4528[8] = (char *(*)()) F641_5094;
	R4528[9] = (char *(*)()) F642_5094;
	R4528[10] = (char *(*)()) F643_5094;
	R4528[11] = (char *(*)()) F644_5094;
}

char *(*R4530[12])();
void R4530_init () {
	R4530[0] = (char *(*)()) F633_5080;
	R4530[1] = (char *(*)()) F634_5080;
	R4530[2] = (char *(*)()) F635_5080;
	R4530[3] = (char *(*)()) F636_5080;
	R4530[4] = (char *(*)()) F637_5080;
	R4530[5] = (char *(*)()) F638_5080;
	R4530[6] = (char *(*)()) F639_5080;
	R4530[7] = (char *(*)()) F640_5080;
	R4530[8] = (char *(*)()) F641_5080;
	R4530[9] = (char *(*)()) F642_5080;
	R4530[10] = (char *(*)()) F643_5080;
	R4530[11] = (char *(*)()) F644_5080;
}

char *(*R4531[12])();
void R4531_init () {
	R4531[0] = (char *(*)()) F633_5081;
	R4531[1] = (char *(*)()) F634_5081_4531_252;
	R4531[2] = (char *(*)()) F635_5081_4531_252;
	R4531[3] = (char *(*)()) F636_5081_4531_252;
	R4531[4] = (char *(*)()) F637_5081_4531_252;
	R4531[5] = (char *(*)()) F638_5081_4531_252;
	R4531[6] = (char *(*)()) F639_5081_4531_252;
	R4531[7] = (char *(*)()) F640_5081_4531_252;
	R4531[8] = (char *(*)()) F641_5081_4531_252;
	R4531[9] = (char *(*)()) F642_5081_4531_252;
	R4531[10] = (char *(*)()) F643_5081_4531_252;
	R4531[11] = (char *(*)()) F644_5081_4531_252;
}
static void F634_5081_4531_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F634_5081(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F635_5081_4531_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F635_5081(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F636_5081_4531_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F636_5081(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F637_5081_4531_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F637_5081(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F638_5081_4531_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F638_5081(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F639_5081_4531_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F639_5081(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F640_5081_4531_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F640_5081(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F641_5081_4531_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F641_5081(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F642_5081_4531_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F642_5081(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F643_5081_4531_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F643_5081(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F644_5081_4531_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F644_5081(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4540[12])();
void R4540_init () {
	R4540[0] = (char *(*)()) F633_5096;
	R4540[1] = (char *(*)()) F634_5096;
	R4540[2] = (char *(*)()) F635_5096;
	R4540[3] = (char *(*)()) F636_5096;
	R4540[4] = (char *(*)()) F637_5096;
	R4540[5] = (char *(*)()) F638_5096;
	R4540[6] = (char *(*)()) F639_5096;
	R4540[7] = (char *(*)()) F640_5096;
	R4540[8] = (char *(*)()) F641_5096;
	R4540[9] = (char *(*)()) F642_5096;
	R4540[10] = (char *(*)()) F643_5096;
	R4540[11] = (char *(*)()) F644_5096;
}

char *(*R4541[12])();
void R4541_init () {
	R4541[0] = (char *(*)()) F633_5098;
	R4541[1] = (char *(*)()) F634_5098_4541_252;
	R4541[2] = (char *(*)()) F635_5098_4541_252;
	R4541[3] = (char *(*)()) F636_5098_4541_252;
	R4541[4] = (char *(*)()) F637_5098_4541_252;
	R4541[5] = (char *(*)()) F638_5098_4541_252;
	R4541[6] = (char *(*)()) F639_5098_4541_252;
	R4541[7] = (char *(*)()) F640_5098_4541_252;
	R4541[8] = (char *(*)()) F641_5098_4541_252;
	R4541[9] = (char *(*)()) F642_5098_4541_252;
	R4541[10] = (char *(*)()) F643_5098_4541_252;
	R4541[11] = (char *(*)()) F644_5098_4541_252;
}
static void F634_5098_4541_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F634_5098(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F635_5098_4541_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F635_5098(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F636_5098_4541_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F636_5098(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F637_5098_4541_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F637_5098(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F638_5098_4541_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F638_5098(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F639_5098_4541_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F639_5098(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F640_5098_4541_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F640_5098(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F641_5098_4541_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F641_5098(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F642_5098_4541_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F642_5098(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F643_5098_4541_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F643_5098(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F644_5098_4541_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F644_5098(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4542[12])();
void R4542_init () {
	R4542[0] = (char *(*)()) F633_5099;
	R4542[1] = (char *(*)()) F634_5099_4542_252;
	R4542[2] = (char *(*)()) F635_5099_4542_252;
	R4542[3] = (char *(*)()) F636_5099_4542_252;
	R4542[4] = (char *(*)()) F637_5099_4542_252;
	R4542[5] = (char *(*)()) F638_5099_4542_252;
	R4542[6] = (char *(*)()) F639_5099_4542_252;
	R4542[7] = (char *(*)()) F640_5099_4542_252;
	R4542[8] = (char *(*)()) F641_5099_4542_252;
	R4542[9] = (char *(*)()) F642_5099_4542_252;
	R4542[10] = (char *(*)()) F643_5099_4542_252;
	R4542[11] = (char *(*)()) F644_5099_4542_252;
}
static void F634_5099_4542_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F634_5099(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F635_5099_4542_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F635_5099(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F636_5099_4542_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F636_5099(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F637_5099_4542_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F637_5099(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F638_5099_4542_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F638_5099(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F639_5099_4542_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F639_5099(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F640_5099_4542_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F640_5099(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F641_5099_4542_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F641_5099(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F642_5099_4542_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F642_5099(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F643_5099_4542_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F643_5099(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F644_5099_4542_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F644_5099(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R4543[12])();
void R4543_init () {
	R4543[0] = (char *(*)()) F633_5100;
	R4543[1] = (char *(*)()) F634_5100_4543_4;
	R4543[2] = (char *(*)()) F635_5100_4543_4;
	R4543[3] = (char *(*)()) F636_5100_4543_4;
	R4543[4] = (char *(*)()) F637_5100_4543_4;
	R4543[5] = (char *(*)()) F638_5100_4543_4;
	R4543[6] = (char *(*)()) F639_5100_4543_4;
	R4543[7] = (char *(*)()) F640_5100_4543_4;
	R4543[8] = (char *(*)()) F641_5100_4543_4;
	R4543[9] = (char *(*)()) F642_5100_4543_4;
	R4543[10] = (char *(*)()) F643_5100_4543_4;
	R4543[11] = (char *(*)()) F644_5100_4543_4;
}
static void F634_5100_4543_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F634_5100(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F635_5100_4543_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F635_5100(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F636_5100_4543_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F636_5100(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F637_5100_4543_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F637_5100(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F638_5100_4543_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F638_5100(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F639_5100_4543_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F639_5100(Current, *(EIF_POINTER *)arg1);
}
static void F640_5100_4543_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F640_5100(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F641_5100_4543_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F641_5100(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F642_5100_4543_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F642_5100(Current, *(EIF_BOOLEAN *)arg1);
}
static void F643_5100_4543_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F643_5100(Current, *(EIF_REAL_32 *)arg1);
}
static void F644_5100_4543_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F644_5100(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R4545[12])();
void R4545_init () {
	R4545[0] = (char *(*)()) F633_5102;
	R4545[1] = (char *(*)()) F634_5102_4545_256;
	R4545[2] = (char *(*)()) F635_5102_4545_256;
	R4545[3] = (char *(*)()) F636_5102_4545_256;
	R4545[4] = (char *(*)()) F637_5102_4545_256;
	R4545[5] = (char *(*)()) F638_5102_4545_256;
	R4545[6] = (char *(*)()) F639_5102_4545_256;
	R4545[7] = (char *(*)()) F640_5102_4545_256;
	R4545[8] = (char *(*)()) F641_5102_4545_256;
	R4545[9] = (char *(*)()) F642_5102_4545_256;
	R4545[10] = (char *(*)()) F643_5102_4545_256;
	R4545[11] = (char *(*)()) F644_5102_4545_256;
}
static void F634_5102_4545_256 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F634_5102(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}
static void F635_5102_4545_256 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F635_5102(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F636_5102_4545_256 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F636_5102(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F637_5102_4545_256 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F637_5102(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F638_5102_4545_256 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F638_5102(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F639_5102_4545_256 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F639_5102(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F640_5102_4545_256 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F640_5102(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F641_5102_4545_256 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F641_5102(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F642_5102_4545_256 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F642_5102(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F643_5102_4545_256 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F643_5102(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F644_5102_4545_256 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F644_5102(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}

char *(*R4548[12])();
void R4548_init () {
	R4548[0] = (char *(*)()) F633_5105;
	R4548[1] = (char *(*)()) F634_5105;
	R4548[2] = (char *(*)()) F635_5105;
	R4548[3] = (char *(*)()) F636_5105;
	R4548[4] = (char *(*)()) F637_5105;
	R4548[5] = (char *(*)()) F638_5105;
	R4548[6] = (char *(*)()) F639_5105;
	R4548[7] = (char *(*)()) F640_5105;
	R4548[8] = (char *(*)()) F641_5105;
	R4548[9] = (char *(*)()) F642_5105;
	R4548[10] = (char *(*)()) F643_5105;
	R4548[11] = (char *(*)()) F644_5105;
}

char *(*R4549[12])();
void R4549_init () {
	R4549[0] = (char *(*)()) F633_5106;
	R4549[1] = (char *(*)()) F634_5106;
	R4549[2] = (char *(*)()) F635_5106;
	R4549[3] = (char *(*)()) F636_5106;
	R4549[4] = (char *(*)()) F637_5106;
	R4549[5] = (char *(*)()) F638_5106;
	R4549[6] = (char *(*)()) F639_5106;
	R4549[7] = (char *(*)()) F640_5106;
	R4549[8] = (char *(*)()) F641_5106;
	R4549[9] = (char *(*)()) F642_5106;
	R4549[10] = (char *(*)()) F643_5106;
	R4549[11] = (char *(*)()) F644_5106;
}

char *(*R4550[12])();
void R4550_init () {
	R4550[0] = (char *(*)()) F633_5107;
	R4550[1] = (char *(*)()) F634_5107;
	R4550[2] = (char *(*)()) F635_5107;
	R4550[3] = (char *(*)()) F636_5107;
	R4550[4] = (char *(*)()) F637_5107;
	R4550[5] = (char *(*)()) F638_5107;
	R4550[6] = (char *(*)()) F639_5107;
	R4550[7] = (char *(*)()) F640_5107;
	R4550[8] = (char *(*)()) F641_5107;
	R4550[9] = (char *(*)()) F642_5107;
	R4550[10] = (char *(*)()) F643_5107;
	R4550[11] = (char *(*)()) F644_5107;
}

char *(*R4551[12])();
void R4551_init () {
	R4551[0] = (char *(*)()) F633_5108;
	R4551[1] = (char *(*)()) F634_5108;
	R4551[2] = (char *(*)()) F635_5108;
	R4551[3] = (char *(*)()) F636_5108;
	R4551[4] = (char *(*)()) F637_5108;
	R4551[5] = (char *(*)()) F638_5108;
	R4551[6] = (char *(*)()) F639_5108;
	R4551[7] = (char *(*)()) F640_5108;
	R4551[8] = (char *(*)()) F641_5108;
	R4551[9] = (char *(*)()) F642_5108;
	R4551[10] = (char *(*)()) F643_5108;
	R4551[11] = (char *(*)()) F644_5108;
}

char *(*R4552[12])();
void R4552_init () {
	R4552[0] = (char *(*)()) F633_5109;
	R4552[1] = (char *(*)()) F634_5109;
	R4552[2] = (char *(*)()) F635_5109;
	R4552[3] = (char *(*)()) F636_5109;
	R4552[4] = (char *(*)()) F637_5109;
	R4552[5] = (char *(*)()) F638_5109;
	R4552[6] = (char *(*)()) F639_5109;
	R4552[7] = (char *(*)()) F640_5109;
	R4552[8] = (char *(*)()) F641_5109;
	R4552[9] = (char *(*)()) F642_5109;
	R4552[10] = (char *(*)()) F643_5109;
	R4552[11] = (char *(*)()) F644_5109;
}

char *(*R4555[12])();
void R4555_init () {
	R4555[0] = (char *(*)()) F633_5112;
	R4555[1] = (char *(*)()) F634_5112;
	R4555[2] = (char *(*)()) F635_5112;
	R4555[3] = (char *(*)()) F636_5112;
	R4555[4] = (char *(*)()) F637_5112;
	R4555[5] = (char *(*)()) F638_5112;
	R4555[6] = (char *(*)()) F639_5112;
	R4555[7] = (char *(*)()) F640_5112;
	R4555[8] = (char *(*)()) F641_5112;
	R4555[9] = (char *(*)()) F642_5112;
	R4555[10] = (char *(*)()) F643_5112;
	R4555[11] = (char *(*)()) F644_5112;
}

char *(*R4558[12])();
void R4558_init () {
	R4558[0] = (char *(*)()) F633_5115;
	R4558[1] = (char *(*)()) F634_5115;
	R4558[2] = (char *(*)()) F635_5115;
	R4558[3] = (char *(*)()) F636_5115;
	R4558[4] = (char *(*)()) F637_5115;
	R4558[5] = (char *(*)()) F638_5115;
	R4558[6] = (char *(*)()) F639_5115;
	R4558[7] = (char *(*)()) F640_5115;
	R4558[8] = (char *(*)()) F641_5115;
	R4558[9] = (char *(*)()) F642_5115;
	R4558[10] = (char *(*)()) F643_5115;
	R4558[11] = (char *(*)()) F644_5115;
}

char *(*R4561[12])();
void R4561_init () {
	R4561[0] = (char *(*)()) F633_5118;
	R4561[1] = (char *(*)()) F634_5118;
	R4561[2] = (char *(*)()) F635_5118;
	R4561[3] = (char *(*)()) F636_5118;
	R4561[4] = (char *(*)()) F637_5118;
	R4561[5] = (char *(*)()) F638_5118;
	R4561[6] = (char *(*)()) F639_5118;
	R4561[7] = (char *(*)()) F640_5118;
	R4561[8] = (char *(*)()) F641_5118;
	R4561[9] = (char *(*)()) F642_5118;
	R4561[10] = (char *(*)()) F643_5118;
	R4561[11] = (char *(*)()) F644_5118;
}

char *(*R4570[12])();
void R4570_init () {
	R4570[0] = (char *(*)()) F633_5128;
	R4570[1] = (char *(*)()) F634_5128;
	R4570[2] = (char *(*)()) F635_5128;
	R4570[3] = (char *(*)()) F636_5128;
	R4570[4] = (char *(*)()) F637_5128;
	R4570[5] = (char *(*)()) F638_5128;
	R4570[6] = (char *(*)()) F639_5128;
	R4570[7] = (char *(*)()) F640_5128;
	R4570[8] = (char *(*)()) F641_5128;
	R4570[9] = (char *(*)()) F642_5128;
	R4570[10] = (char *(*)()) F643_5128;
	R4570[11] = (char *(*)()) F644_5128;
}

char *(*R4617[38])();
void R4617_init () {
	R4617[0] = (char *(*)()) F868_6428_4617_1;
	R4617[1] = (char *(*)()) F869_6428_4617_1;
	R4617[3] = (char *(*)()) F871_6527_4617_1;
	R4617[4] = (char *(*)()) F872_6527_4617_1;
	R4617[6] = (char *(*)()) F874_6626_4617_1;
	R4617[7] = (char *(*)()) F875_6626_4617_1;
	R4617[21] = (char *(*)()) F889_7083_4617_1;
	R4617[22] = (char *(*)()) F890_7083_4617_1;
	R4617[24] = (char *(*)()) F892_7149_4617_1;
	R4617[25] = (char *(*)()) F893_7149_4617_1;
	R4617[36] = (char *(*)()) F904_7345_4617_1;
	R4617[37] = (char *(*)()) F905_7345_4617_1;
}
static EIF_REFERENCE F868_6428_4617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F868_6428(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F869_6428_4617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F869_6428(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F871_6527_4617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F871_6527(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(871, 0x00).id, 871, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F872_6527_4617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F872_6527(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(871, 0x00).id, 871, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F874_6626_4617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F874_6626(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(874, 0x00).id, 874, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F875_6626_4617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F875_6626(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(874, 0x00).id, 874, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F889_7083_4617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F889_7083(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F890_7083_4617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F890_7083(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F892_7149_4617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F892_7149(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(892, 0x00).id, 892, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F893_7149_4617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F893_7149(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(892, 0x00).id, 892, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F904_7345_4617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F904_7345(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(904, 0x00).id, 904, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F905_7345_4617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F905_7345(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(904, 0x00).id, 904, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}

char *(*R4618[111])();
void R4618_init () {
	R4618[0] = (char *(*)()) F709_5248;
	R4618[1] = (char *(*)()) F408_4241_4618_1;
	R4618[33] = (char *(*)()) F730_5289;
	R4618[34] = (char *(*)()) F731_5289_4618_1;
	R4618[35] = (char *(*)()) F732_5289_4618_1;
	R4618[36] = (char *(*)()) F733_5289_4618_1;
	R4618[37] = (char *(*)()) F734_5289_4618_1;
	R4618[38] = (char *(*)()) F735_5289_4618_1;
	R4618[39] = (char *(*)()) F736_5289_4618_1;
	R4618[40] = (char *(*)()) F737_5289_4618_1;
	R4618[41] = (char *(*)()) F738_5289_4618_1;
	R4618[42] = (char *(*)()) F739_5289_4618_1;
	R4618[43] = (char *(*)()) F740_5289_4618_1;
	R4618[44] = (char *(*)()) F741_5289_4618_1;
	R4618[45] = (char *(*)()) F754_5317;
	R4618[46] = (char *(*)()) F755_5317_4618_1;
	R4618[47] = (char *(*)()) F756_5317_4618_1;
	R4618[48] = (char *(*)()) F757_5323;
	R4618[49] = (char *(*)()) F758_5323_4618_1;
	R4618[50] = (char *(*)()) F759_5323_4618_1;
	R4618[51] = (char *(*)()) F760_5323_4618_1;
	R4618[52] = (char *(*)()) F761_5323;
	R4618[53] = (char *(*)()) F762_5323_4618_1;
	R4618[54] = (char *(*)()) F763_5323_4618_1;
	R4618[67] = (char *(*)()) F764_5329;
	R4618[68] = (char *(*)()) F765_5329_4618_1;
	R4618[69] = (char *(*)()) F766_5329_4618_1;
	R4618[70] = (char *(*)()) F767_5329_4618_1;
	R4618[71] = (char *(*)()) F768_5329_4618_1;
	R4618[72] = (char *(*)()) F769_5329_4618_1;
	R4618[73] = (char *(*)()) F770_5329_4618_1;
	R4618[74] = (char *(*)()) F771_5329_4618_1;
	R4618[75] = (char *(*)()) F772_5329_4618_1;
	R4618[76] = (char *(*)()) F773_5329_4618_1;
	R4618[77] = (char *(*)()) F774_5329_4618_1;
	R4618[78] = (char *(*)()) F775_5329_4618_1;
	R4618[110] = (char *(*)()) F819_5421_4618_1;
}
static EIF_REFERENCE F408_4241_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F408_4241(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F731_5289_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F731_5289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F732_5289_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F732_5289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F733_5289_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F733_5289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F734_5289_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F734_5289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F735_5289_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F735_5289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F736_5289_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F736_5289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F737_5289_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F737_5289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(877, 0x00).id, 877, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F738_5289_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F738_5289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F739_5289_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F739_5289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F740_5289_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F740_5289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F741_5289_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F741_5289(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(892, 0x00).id, 892, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F755_5317_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F755_5317(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F756_5317_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F756_5317(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F758_5323_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F758_5323(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F759_5323_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F759_5323(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F760_5323_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F760_5323(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F762_5323_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F762_5323(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F763_5323_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F763_5323(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F765_5329_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F765_5329(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F766_5329_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F766_5329(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F767_5329_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F767_5329(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F768_5329_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F768_5329(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F769_5329_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F769_5329(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F770_5329_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F770_5329(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F771_5329_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F771_5329(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(877, 0x00).id, 877, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F772_5329_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F772_5329(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F773_5329_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F773_5329(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F774_5329_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F774_5329(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F775_5329_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F775_5329(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(892, 0x00).id, 892, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F819_5421_4618_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F819_5421(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R4619[111])();
void R4619_init () {
	R4619[0] = (char *(*)()) F709_5243;
	R4619[1] = (char *(*)()) F408_4242;
	R4619[33] = (char *(*)()) F742_5307;
	R4619[34] = (char *(*)()) F743_5307;
	R4619[35] = (char *(*)()) F744_5307;
	R4619[36] = (char *(*)()) F745_5307;
	R4619[37] = (char *(*)()) F746_5307;
	R4619[38] = (char *(*)()) F747_5307;
	R4619[39] = (char *(*)()) F748_5307;
	R4619[40] = (char *(*)()) F749_5307;
	R4619[41] = (char *(*)()) F750_5307;
	R4619[42] = (char *(*)()) F751_5307;
	R4619[43] = (char *(*)()) F752_5307;
	R4619[44] = (char *(*)()) F753_5307;
	R4619[45] = (char *(*)()) F754_5318;
	R4619[46] = (char *(*)()) F755_5318;
	R4619[47] = (char *(*)()) F756_5318;
	R4619[48] = (char *(*)()) F757_5326;
	R4619[49] = (char *(*)()) F758_5326;
	R4619[50] = (char *(*)()) F759_5326;
	R4619[51] = (char *(*)()) F760_5326;
	R4619[52] = (char *(*)()) F761_5326;
	R4619[53] = (char *(*)()) F762_5326;
	R4619[54] = (char *(*)()) F763_5326;
	R4619[67] = (char *(*)()) F764_5338;
	R4619[68] = (char *(*)()) F765_5338;
	R4619[69] = (char *(*)()) F766_5338;
	R4619[70] = (char *(*)()) F767_5338;
	R4619[71] = (char *(*)()) F768_5338;
	R4619[72] = (char *(*)()) F769_5338;
	R4619[73] = (char *(*)()) F770_5338;
	R4619[74] = (char *(*)()) F771_5338;
	R4619[75] = (char *(*)()) F772_5338;
	R4619[76] = (char *(*)()) F773_5338;
	R4619[77] = (char *(*)()) F774_5338;
	R4619[78] = (char *(*)()) F775_5338;
	R4619[110] = (char *(*)()) F819_5423;
}

char *(*R4620[111])();
void R4620_init () {
	R4620[0] = (char *(*)()) F709_5245;
	R4620[1] = (char *(*)()) F408_4248;
	R4620[33] = (char *(*)()) F742_5315;
	R4620[34] = (char *(*)()) F743_5315;
	R4620[35] = (char *(*)()) F744_5315;
	R4620[36] = (char *(*)()) F745_5315;
	R4620[37] = (char *(*)()) F746_5315;
	R4620[38] = (char *(*)()) F747_5315;
	R4620[39] = (char *(*)()) F748_5315;
	R4620[40] = (char *(*)()) F749_5315;
	R4620[41] = (char *(*)()) F750_5315;
	R4620[42] = (char *(*)()) F751_5315;
	R4620[43] = (char *(*)()) F752_5315;
	R4620[44] = (char *(*)()) F753_5315;
	R4620[45] = (char *(*)()) F754_5320;
	R4620[46] = (char *(*)()) F755_5320;
	R4620[47] = (char *(*)()) F756_5320;
	R4620[48] = (char *(*)()) F757_5327;
	R4620[49] = (char *(*)()) F758_5327;
	R4620[50] = (char *(*)()) F759_5327;
	R4620[51] = (char *(*)()) F760_5327;
	R4620[52] = (char *(*)()) F761_5327;
	R4620[53] = (char *(*)()) F762_5327;
	R4620[54] = (char *(*)()) F763_5327;
	R4620[67] = (char *(*)()) F764_5344;
	R4620[68] = (char *(*)()) F765_5344;
	R4620[69] = (char *(*)()) F766_5344;
	R4620[70] = (char *(*)()) F767_5344;
	R4620[71] = (char *(*)()) F768_5344;
	R4620[72] = (char *(*)()) F769_5344;
	R4620[73] = (char *(*)()) F770_5344;
	R4620[74] = (char *(*)()) F771_5344;
	R4620[75] = (char *(*)()) F772_5344;
	R4620[76] = (char *(*)()) F773_5344;
	R4620[77] = (char *(*)()) F774_5344;
	R4620[78] = (char *(*)()) F775_5344;
	R4620[110] = (char *(*)()) F819_5424;
}

char *(*R4662[7])();
void R4662_init () {
	R4662[0] = (char *(*)()) F757_5324;
	R4662[1] = (char *(*)()) F758_5324;
	R4662[2] = (char *(*)()) F759_5324_4662_1;
	R4662[3] = (char *(*)()) F760_5324;
	R4662[4] = (char *(*)()) F761_5324_4662_1;
	R4662[5] = (char *(*)()) F762_5324;
	R4662[6] = (char *(*)()) F763_5324_4662_1;
}
static EIF_REFERENCE F759_5324_4662_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F759_5324(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F761_5324_4662_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F761_5324(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F763_5324_4662_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F763_5324(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R4665[46])();
void R4665_init () {
	R4665[0] = (char *(*)()) F742_5297;
	R4665[1] = (char *(*)()) F743_5297;
	R4665[2] = (char *(*)()) F744_5297;
	R4665[3] = (char *(*)()) F745_5297;
	R4665[4] = (char *(*)()) F746_5297;
	R4665[5] = (char *(*)()) F747_5297;
	R4665[6] = (char *(*)()) F748_5297;
	R4665[7] = (char *(*)()) F749_5297;
	R4665[8] = (char *(*)()) F750_5297;
	R4665[9] = (char *(*)()) F751_5297;
	R4665[10] = (char *(*)()) F752_5297;
	R4665[11] = (char *(*)()) F753_5297;
	R4665[12] = (char *(*)()) F742_5297;
	R4665[13] = (char *(*)()) F747_5297;
	R4665[14] = (char *(*)()) F751_5297;
	R4665[15] = (char *(*)()) F742_5297;
	{long i; for (i = 16; i < 18; i++) R4665[i] = (char *(*)()) F747_5297;}
	R4665[18] = (char *(*)()) F748_5297;
	R4665[19] = (char *(*)()) F742_5297;
	R4665[20] = (char *(*)()) F751_5297;
	R4665[21] = (char *(*)()) F747_5297;
	R4665[34] = (char *(*)()) F764_5331;
	R4665[35] = (char *(*)()) F765_5331;
	R4665[36] = (char *(*)()) F766_5331;
	R4665[37] = (char *(*)()) F767_5331;
	R4665[38] = (char *(*)()) F768_5331;
	R4665[39] = (char *(*)()) F769_5331;
	R4665[40] = (char *(*)()) F770_5331;
	R4665[41] = (char *(*)()) F771_5331;
	R4665[42] = (char *(*)()) F772_5331;
	R4665[43] = (char *(*)()) F773_5331;
	R4665[44] = (char *(*)()) F774_5331;
	R4665[45] = (char *(*)()) F775_5331;
}

char *(*R4666[46])();
void R4666_init () {
	R4666[0] = (char *(*)()) F742_5298;
	R4666[1] = (char *(*)()) F743_5298;
	R4666[2] = (char *(*)()) F744_5298;
	R4666[3] = (char *(*)()) F745_5298;
	R4666[4] = (char *(*)()) F746_5298;
	R4666[5] = (char *(*)()) F747_5298;
	R4666[6] = (char *(*)()) F748_5298;
	R4666[7] = (char *(*)()) F749_5298;
	R4666[8] = (char *(*)()) F750_5298;
	R4666[9] = (char *(*)()) F751_5298;
	R4666[10] = (char *(*)()) F752_5298;
	R4666[11] = (char *(*)()) F753_5298;
	R4666[12] = (char *(*)()) F742_5298;
	R4666[13] = (char *(*)()) F747_5298;
	R4666[14] = (char *(*)()) F751_5298;
	R4666[15] = (char *(*)()) F742_5298;
	{long i; for (i = 16; i < 18; i++) R4666[i] = (char *(*)()) F747_5298;}
	R4666[18] = (char *(*)()) F748_5298;
	R4666[19] = (char *(*)()) F742_5298;
	R4666[20] = (char *(*)()) F751_5298;
	R4666[21] = (char *(*)()) F747_5298;
	R4666[34] = (char *(*)()) F776_5350;
	R4666[35] = (char *(*)()) F777_5350;
	R4666[36] = (char *(*)()) F778_5350;
	R4666[37] = (char *(*)()) F779_5350;
	R4666[38] = (char *(*)()) F780_5350;
	R4666[39] = (char *(*)()) F781_5350;
	R4666[40] = (char *(*)()) F782_5350;
	R4666[41] = (char *(*)()) F783_5350;
	R4666[42] = (char *(*)()) F784_5350;
	R4666[43] = (char *(*)()) F785_5350;
	R4666[44] = (char *(*)()) F786_5350;
	R4666[45] = (char *(*)()) F787_5350;
}

char *(*R4674[22])();
void R4674_init () {
	R4674[0] = (char *(*)()) F742_5309;
	R4674[1] = (char *(*)()) F743_5309;
	R4674[2] = (char *(*)()) F744_5309;
	R4674[3] = (char *(*)()) F745_5309;
	R4674[4] = (char *(*)()) F746_5309;
	R4674[5] = (char *(*)()) F747_5309;
	R4674[6] = (char *(*)()) F748_5309;
	R4674[7] = (char *(*)()) F749_5309;
	R4674[8] = (char *(*)()) F750_5309;
	R4674[9] = (char *(*)()) F751_5309;
	R4674[10] = (char *(*)()) F752_5309;
	R4674[11] = (char *(*)()) F753_5309;
	R4674[12] = (char *(*)()) F742_5309;
	R4674[13] = (char *(*)()) F747_5309;
	R4674[14] = (char *(*)()) F751_5309;
	R4674[15] = (char *(*)()) F742_5309;
	{long i; for (i = 16; i < 18; i++) R4674[i] = (char *(*)()) F747_5309;}
	R4674[18] = (char *(*)()) F748_5309;
	R4674[19] = (char *(*)()) F742_5309;
	R4674[20] = (char *(*)()) F751_5309;
	R4674[21] = (char *(*)()) F747_5309;
}

char *(*R4677[46])();
void R4677_init () {
	R4677[0] = (char *(*)()) F742_5314;
	R4677[1] = (char *(*)()) F743_5314;
	R4677[2] = (char *(*)()) F744_5314;
	R4677[3] = (char *(*)()) F745_5314;
	R4677[4] = (char *(*)()) F746_5314;
	R4677[5] = (char *(*)()) F747_5314;
	R4677[6] = (char *(*)()) F748_5314;
	R4677[7] = (char *(*)()) F749_5314;
	R4677[8] = (char *(*)()) F750_5314;
	R4677[9] = (char *(*)()) F751_5314;
	R4677[10] = (char *(*)()) F752_5314;
	R4677[11] = (char *(*)()) F753_5314;
	R4677[12] = (char *(*)()) F754_5319;
	R4677[13] = (char *(*)()) F755_5319;
	R4677[14] = (char *(*)()) F756_5319;
	R4677[15] = (char *(*)()) F742_5314;
	{long i; for (i = 16; i < 18; i++) R4677[i] = (char *(*)()) F747_5314;}
	R4677[18] = (char *(*)()) F748_5314;
	R4677[19] = (char *(*)()) F742_5314;
	R4677[20] = (char *(*)()) F751_5314;
	R4677[21] = (char *(*)()) F747_5314;
	R4677[34] = (char *(*)()) F764_5343;
	R4677[35] = (char *(*)()) F765_5343;
	R4677[36] = (char *(*)()) F766_5343;
	R4677[37] = (char *(*)()) F767_5343;
	R4677[38] = (char *(*)()) F768_5343;
	R4677[39] = (char *(*)()) F769_5343;
	R4677[40] = (char *(*)()) F770_5343;
	R4677[41] = (char *(*)()) F771_5343;
	R4677[42] = (char *(*)()) F772_5343;
	R4677[43] = (char *(*)()) F773_5343;
	R4677[44] = (char *(*)()) F774_5343;
	R4677[45] = (char *(*)()) F775_5343;
}

char *(*R4678[46])();
void R4678_init () {
	R4678[0] = (char *(*)()) F742_5316;
	R4678[1] = (char *(*)()) F743_5316;
	R4678[2] = (char *(*)()) F744_5316;
	R4678[3] = (char *(*)()) F745_5316;
	R4678[4] = (char *(*)()) F746_5316;
	R4678[5] = (char *(*)()) F747_5316;
	R4678[6] = (char *(*)()) F748_5316;
	R4678[7] = (char *(*)()) F749_5316;
	R4678[8] = (char *(*)()) F750_5316;
	R4678[9] = (char *(*)()) F751_5316;
	R4678[10] = (char *(*)()) F752_5316;
	R4678[11] = (char *(*)()) F753_5316;
	R4678[12] = (char *(*)()) F754_5321;
	R4678[13] = (char *(*)()) F755_5321;
	R4678[14] = (char *(*)()) F756_5321;
	R4678[15] = (char *(*)()) F757_5328;
	R4678[16] = (char *(*)()) F758_5328;
	R4678[17] = (char *(*)()) F759_5328;
	R4678[18] = (char *(*)()) F760_5328;
	R4678[19] = (char *(*)()) F761_5328;
	R4678[20] = (char *(*)()) F762_5328;
	R4678[21] = (char *(*)()) F763_5328;
	R4678[34] = (char *(*)()) F776_5353;
	R4678[35] = (char *(*)()) F777_5353;
	R4678[36] = (char *(*)()) F778_5353;
	R4678[37] = (char *(*)()) F779_5353;
	R4678[38] = (char *(*)()) F780_5353;
	R4678[39] = (char *(*)()) F781_5353;
	R4678[40] = (char *(*)()) F782_5353;
	R4678[41] = (char *(*)()) F783_5353;
	R4678[42] = (char *(*)()) F784_5353;
	R4678[43] = (char *(*)()) F785_5353;
	R4678[44] = (char *(*)()) F786_5353;
	R4678[45] = (char *(*)()) F787_5353;
}

char *(*R4680[22])();
void R4680_init () {
	R4680[0] = (char *(*)()) F742_5295;
	R4680[1] = (char *(*)()) F743_5295;
	R4680[2] = (char *(*)()) F744_5295;
	R4680[3] = (char *(*)()) F745_5295;
	R4680[4] = (char *(*)()) F746_5295;
	R4680[5] = (char *(*)()) F747_5295;
	R4680[6] = (char *(*)()) F748_5295;
	R4680[7] = (char *(*)()) F749_5295;
	R4680[8] = (char *(*)()) F750_5295;
	R4680[9] = (char *(*)()) F751_5295;
	R4680[10] = (char *(*)()) F752_5295;
	R4680[11] = (char *(*)()) F753_5295;
	R4680[12] = (char *(*)()) F742_5295;
	R4680[13] = (char *(*)()) F747_5295;
	R4680[14] = (char *(*)()) F751_5295;
	R4680[15] = (char *(*)()) F742_5295;
	{long i; for (i = 16; i < 18; i++) R4680[i] = (char *(*)()) F747_5295;}
	R4680[18] = (char *(*)()) F748_5295;
	R4680[19] = (char *(*)()) F742_5295;
	R4680[20] = (char *(*)()) F751_5295;
	R4680[21] = (char *(*)()) F747_5295;
}

char *(*R4693[12])();
void R4693_init () {
	R4693[0] = (char *(*)()) F776_5354;
	R4693[1] = (char *(*)()) F777_5354;
	R4693[2] = (char *(*)()) F778_5354;
	R4693[3] = (char *(*)()) F779_5354;
	R4693[4] = (char *(*)()) F780_5354;
	R4693[5] = (char *(*)()) F781_5354;
	R4693[6] = (char *(*)()) F782_5354;
	R4693[7] = (char *(*)()) F783_5354;
	R4693[8] = (char *(*)()) F784_5354;
	R4693[9] = (char *(*)()) F785_5354;
	R4693[10] = (char *(*)()) F786_5354;
	R4693[11] = (char *(*)()) F787_5354;
}

char *(*R4695[12])();
void R4695_init () {
	R4695[0] = (char *(*)()) F776_5349;
	R4695[1] = (char *(*)()) F777_5349;
	R4695[2] = (char *(*)()) F778_5349;
	R4695[3] = (char *(*)()) F779_5349;
	R4695[4] = (char *(*)()) F780_5349;
	R4695[5] = (char *(*)()) F781_5349;
	R4695[6] = (char *(*)()) F782_5349;
	R4695[7] = (char *(*)()) F783_5349;
	R4695[8] = (char *(*)()) F784_5349;
	R4695[9] = (char *(*)()) F785_5349;
	R4695[10] = (char *(*)()) F786_5349;
	R4695[11] = (char *(*)()) F787_5349;
}

char *(*R4880[443])();
void R4880_init () {
	{long i; for (i = 0; i < 2; i++) R4880[i] = (char *(*)()) F823_5668;}
	R4880[442] = (char *(*)()) F1266_12591;
}

char *(*R4893[443])();
void R4893_init () {
	{long i; for (i = 0; i < 2; i++) R4893[i] = (char *(*)()) F823_5742;}
	R4893[442] = (char *(*)()) F1266_12614;
}

char *(*R4895[443])();
void R4895_init () {
	{long i; for (i = 0; i < 2; i++) R4895[i] = (char *(*)()) F823_5745;}
	R4895[442] = (char *(*)()) F1266_12612;
}

char *(*R4923[443])();
void R4923_init () {
	{long i; for (i = 0; i < 2; i++) R4923[i] = (char *(*)()) F823_5775;}
	R4923[442] = (char *(*)()) F1266_12609;
}

char *(*R4974[443])();
void R4974_init () {
	{long i; for (i = 0; i < 2; i++) R4974[i] = (char *(*)()) F823_5667;}
	R4974[442] = (char *(*)()) F1266_12590;
}


#ifdef __cplusplus
}
#endif
