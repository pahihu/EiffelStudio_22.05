#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O2661[1143];
void O2661_init () {
	O2661[0] =  + _REFACS_3_;
	{long i; for (i = 1045; i < 1047; i++) O2661[i] =  + _REFACS_12_;}
	{long i; for (i = 1047; i < 1050; i++) O2661[i] =  + _REFACS_13_;}
	O2661[1050] =  + _REFACS_14_;
	{long i; for (i = 1051; i < 1053; i++) O2661[i] =  + _REFACS_13_;}
	O2661[1053] =  + _REFACS_14_;
	O2661[1054] =  + _REFACS_13_;
	{long i; for (i = 1055; i < 1065; i++) O2661[i] =  + _REFACS_14_;}
	{long i; for (i = 1065; i < 1067; i++) O2661[i] =  + _REFACS_18_;}
	{long i; for (i = 1067; i < 1069; i++) O2661[i] =  + _REFACS_21_;}
	{long i; for (i = 1069; i < 1073; i++) O2661[i] =  + _REFACS_14_;}
	{long i; for (i = 1073; i < 1075; i++) O2661[i] =  + _REFACS_18_;}
	{long i; for (i = 1075; i < 1077; i++) O2661[i] =  + _REFACS_21_;}
	O2661[1077] =  + _REFACS_12_;
	O2661[1078] =  + _REFACS_13_;
	O2661[1079] =  + _REFACS_14_;
	O2661[1080] =  + _REFACS_16_;
	O2661[1081] =  + _REFACS_12_;
	{long i; for (i = 1082; i < 1085; i++) O2661[i] =  + _REFACS_13_;}
	{long i; for (i = 1085; i < 1087; i++) O2661[i] =  + _REFACS_14_;}
	{long i; for (i = 1087; i < 1089; i++) O2661[i] =  + _REFACS_13_;}
	O2661[1089] =  + _REFACS_16_;
	O2661[1090] =  + _REFACS_14_;
	O2661[1091] =  + _REFACS_18_;
	O2661[1092] =  + _REFACS_12_;
	O2661[1093] =  + _REFACS_13_;
	O2661[1094] =  + _REFACS_14_;
	O2661[1095] =  + _REFACS_16_;
	O2661[1096] =  + _REFACS_12_;
	{long i; for (i = 1097; i < 1100; i++) O2661[i] =  + _REFACS_13_;}
	{long i; for (i = 1100; i < 1102; i++) O2661[i] =  + _REFACS_14_;}
	{long i; for (i = 1102; i < 1104; i++) O2661[i] =  + _REFACS_13_;}
	O2661[1104] =  + _REFACS_16_;
	O2661[1105] =  + _REFACS_14_;
	O2661[1106] =  + _REFACS_18_;
	{long i; for (i = 1136; i < 1138; i++) O2661[i] =  + _REFACS_13_;}
	{long i; for (i = 1141; i < 1143; i++) O2661[i] =  + _REFACS_13_;}
}

long O2663[1143];
void O2663_init () {
	O2663[0] =  + _REFACS_4_;
	{long i; for (i = 1045; i < 1047; i++) O2663[i] =  + _REFACS_13_;}
	{long i; for (i = 1047; i < 1050; i++) O2663[i] =  + _REFACS_14_;}
	O2663[1050] =  + _REFACS_15_;
	{long i; for (i = 1051; i < 1053; i++) O2663[i] =  + _REFACS_14_;}
	O2663[1053] =  + _REFACS_15_;
	O2663[1054] =  + _REFACS_14_;
	{long i; for (i = 1055; i < 1065; i++) O2663[i] =  + _REFACS_15_;}
	{long i; for (i = 1065; i < 1067; i++) O2663[i] =  + _REFACS_19_;}
	{long i; for (i = 1067; i < 1069; i++) O2663[i] =  + _REFACS_22_;}
	{long i; for (i = 1069; i < 1073; i++) O2663[i] =  + _REFACS_15_;}
	{long i; for (i = 1073; i < 1075; i++) O2663[i] =  + _REFACS_19_;}
	{long i; for (i = 1075; i < 1077; i++) O2663[i] =  + _REFACS_22_;}
	O2663[1077] =  + _REFACS_13_;
	O2663[1078] =  + _REFACS_14_;
	O2663[1079] =  + _REFACS_15_;
	O2663[1080] =  + _REFACS_17_;
	O2663[1081] =  + _REFACS_13_;
	{long i; for (i = 1082; i < 1085; i++) O2663[i] =  + _REFACS_14_;}
	{long i; for (i = 1085; i < 1087; i++) O2663[i] =  + _REFACS_15_;}
	{long i; for (i = 1087; i < 1089; i++) O2663[i] =  + _REFACS_14_;}
	O2663[1089] =  + _REFACS_17_;
	O2663[1090] =  + _REFACS_15_;
	O2663[1091] =  + _REFACS_19_;
	O2663[1092] =  + _REFACS_13_;
	O2663[1093] =  + _REFACS_14_;
	O2663[1094] =  + _REFACS_15_;
	O2663[1095] =  + _REFACS_17_;
	O2663[1096] =  + _REFACS_13_;
	{long i; for (i = 1097; i < 1100; i++) O2663[i] =  + _REFACS_14_;}
	{long i; for (i = 1100; i < 1102; i++) O2663[i] =  + _REFACS_15_;}
	{long i; for (i = 1102; i < 1104; i++) O2663[i] =  + _REFACS_14_;}
	O2663[1104] =  + _REFACS_17_;
	O2663[1105] =  + _REFACS_15_;
	O2663[1106] =  + _REFACS_19_;
	{long i; for (i = 1136; i < 1138; i++) O2663[i] =  + _REFACS_14_;}
	{long i; for (i = 1141; i < 1143; i++) O2663[i] =  + _REFACS_14_;}
}

long O2665[1143];
void O2665_init () {
	O2665[0] =  + _REFACS_5_;
	{long i; for (i = 1045; i < 1047; i++) O2665[i] =  + _REFACS_14_;}
	{long i; for (i = 1047; i < 1050; i++) O2665[i] =  + _REFACS_15_;}
	O2665[1050] =  + _REFACS_16_;
	{long i; for (i = 1051; i < 1053; i++) O2665[i] =  + _REFACS_15_;}
	O2665[1053] =  + _REFACS_16_;
	O2665[1054] =  + _REFACS_15_;
	{long i; for (i = 1055; i < 1065; i++) O2665[i] =  + _REFACS_16_;}
	{long i; for (i = 1065; i < 1067; i++) O2665[i] =  + _REFACS_20_;}
	{long i; for (i = 1067; i < 1069; i++) O2665[i] =  + _REFACS_23_;}
	{long i; for (i = 1069; i < 1073; i++) O2665[i] =  + _REFACS_16_;}
	{long i; for (i = 1073; i < 1075; i++) O2665[i] =  + _REFACS_20_;}
	{long i; for (i = 1075; i < 1077; i++) O2665[i] =  + _REFACS_23_;}
	O2665[1077] =  + _REFACS_14_;
	O2665[1078] =  + _REFACS_15_;
	O2665[1079] =  + _REFACS_16_;
	O2665[1080] =  + _REFACS_18_;
	O2665[1081] =  + _REFACS_14_;
	{long i; for (i = 1082; i < 1085; i++) O2665[i] =  + _REFACS_15_;}
	{long i; for (i = 1085; i < 1087; i++) O2665[i] =  + _REFACS_16_;}
	{long i; for (i = 1087; i < 1089; i++) O2665[i] =  + _REFACS_15_;}
	O2665[1089] =  + _REFACS_18_;
	O2665[1090] =  + _REFACS_16_;
	O2665[1091] =  + _REFACS_20_;
	O2665[1092] =  + _REFACS_14_;
	O2665[1093] =  + _REFACS_15_;
	O2665[1094] =  + _REFACS_16_;
	O2665[1095] =  + _REFACS_18_;
	O2665[1096] =  + _REFACS_14_;
	{long i; for (i = 1097; i < 1100; i++) O2665[i] =  + _REFACS_15_;}
	{long i; for (i = 1100; i < 1102; i++) O2665[i] =  + _REFACS_16_;}
	{long i; for (i = 1102; i < 1104; i++) O2665[i] =  + _REFACS_15_;}
	O2665[1104] =  + _REFACS_18_;
	O2665[1105] =  + _REFACS_16_;
	O2665[1106] =  + _REFACS_20_;
	{long i; for (i = 1136; i < 1138; i++) O2665[i] =  + _REFACS_15_;}
	{long i; for (i = 1141; i < 1143; i++) O2665[i] =  + _REFACS_15_;}
}

long O2667[1143];
void O2667_init () {
	O2667[0] =  + _REFACS_6_;
	{long i; for (i = 1045; i < 1047; i++) O2667[i] =  + _REFACS_15_;}
	{long i; for (i = 1047; i < 1050; i++) O2667[i] =  + _REFACS_16_;}
	O2667[1050] =  + _REFACS_17_;
	{long i; for (i = 1051; i < 1053; i++) O2667[i] =  + _REFACS_16_;}
	O2667[1053] =  + _REFACS_17_;
	O2667[1054] =  + _REFACS_16_;
	{long i; for (i = 1055; i < 1065; i++) O2667[i] =  + _REFACS_17_;}
	{long i; for (i = 1065; i < 1067; i++) O2667[i] =  + _REFACS_21_;}
	{long i; for (i = 1067; i < 1069; i++) O2667[i] =  + _REFACS_24_;}
	{long i; for (i = 1069; i < 1073; i++) O2667[i] =  + _REFACS_17_;}
	{long i; for (i = 1073; i < 1075; i++) O2667[i] =  + _REFACS_21_;}
	{long i; for (i = 1075; i < 1077; i++) O2667[i] =  + _REFACS_24_;}
	O2667[1077] =  + _REFACS_15_;
	O2667[1078] =  + _REFACS_16_;
	O2667[1079] =  + _REFACS_17_;
	O2667[1080] =  + _REFACS_19_;
	O2667[1081] =  + _REFACS_15_;
	{long i; for (i = 1082; i < 1085; i++) O2667[i] =  + _REFACS_16_;}
	{long i; for (i = 1085; i < 1087; i++) O2667[i] =  + _REFACS_17_;}
	{long i; for (i = 1087; i < 1089; i++) O2667[i] =  + _REFACS_16_;}
	O2667[1089] =  + _REFACS_19_;
	O2667[1090] =  + _REFACS_17_;
	O2667[1091] =  + _REFACS_21_;
	O2667[1092] =  + _REFACS_15_;
	O2667[1093] =  + _REFACS_16_;
	O2667[1094] =  + _REFACS_17_;
	O2667[1095] =  + _REFACS_19_;
	O2667[1096] =  + _REFACS_15_;
	{long i; for (i = 1097; i < 1100; i++) O2667[i] =  + _REFACS_16_;}
	{long i; for (i = 1100; i < 1102; i++) O2667[i] =  + _REFACS_17_;}
	{long i; for (i = 1102; i < 1104; i++) O2667[i] =  + _REFACS_16_;}
	O2667[1104] =  + _REFACS_19_;
	O2667[1105] =  + _REFACS_17_;
	O2667[1106] =  + _REFACS_21_;
	{long i; for (i = 1136; i < 1138; i++) O2667[i] =  + _REFACS_16_;}
	{long i; for (i = 1141; i < 1143; i++) O2667[i] =  + _REFACS_16_;}
}

long O2669[1143];
void O2669_init () {
	O2669[0] =  + _REFACS_7_;
	{long i; for (i = 1045; i < 1047; i++) O2669[i] =  + _REFACS_16_;}
	{long i; for (i = 1047; i < 1050; i++) O2669[i] =  + _REFACS_17_;}
	O2669[1050] =  + _REFACS_18_;
	{long i; for (i = 1051; i < 1053; i++) O2669[i] =  + _REFACS_17_;}
	O2669[1053] =  + _REFACS_18_;
	O2669[1054] =  + _REFACS_17_;
	{long i; for (i = 1055; i < 1065; i++) O2669[i] =  + _REFACS_18_;}
	{long i; for (i = 1065; i < 1067; i++) O2669[i] =  + _REFACS_22_;}
	{long i; for (i = 1067; i < 1069; i++) O2669[i] =  + _REFACS_25_;}
	{long i; for (i = 1069; i < 1073; i++) O2669[i] =  + _REFACS_18_;}
	{long i; for (i = 1073; i < 1075; i++) O2669[i] =  + _REFACS_22_;}
	{long i; for (i = 1075; i < 1077; i++) O2669[i] =  + _REFACS_25_;}
	O2669[1077] =  + _REFACS_16_;
	O2669[1078] =  + _REFACS_17_;
	O2669[1079] =  + _REFACS_18_;
	O2669[1080] =  + _REFACS_20_;
	O2669[1081] =  + _REFACS_16_;
	{long i; for (i = 1082; i < 1085; i++) O2669[i] =  + _REFACS_17_;}
	{long i; for (i = 1085; i < 1087; i++) O2669[i] =  + _REFACS_18_;}
	{long i; for (i = 1087; i < 1089; i++) O2669[i] =  + _REFACS_17_;}
	O2669[1089] =  + _REFACS_20_;
	O2669[1090] =  + _REFACS_18_;
	O2669[1091] =  + _REFACS_22_;
	O2669[1092] =  + _REFACS_16_;
	O2669[1093] =  + _REFACS_17_;
	O2669[1094] =  + _REFACS_18_;
	O2669[1095] =  + _REFACS_20_;
	O2669[1096] =  + _REFACS_16_;
	{long i; for (i = 1097; i < 1100; i++) O2669[i] =  + _REFACS_17_;}
	{long i; for (i = 1100; i < 1102; i++) O2669[i] =  + _REFACS_18_;}
	{long i; for (i = 1102; i < 1104; i++) O2669[i] =  + _REFACS_17_;}
	O2669[1104] =  + _REFACS_20_;
	O2669[1105] =  + _REFACS_18_;
	O2669[1106] =  + _REFACS_22_;
	{long i; for (i = 1136; i < 1138; i++) O2669[i] =  + _REFACS_17_;}
	{long i; for (i = 1141; i < 1143; i++) O2669[i] =  + _REFACS_17_;}
}

long O2671[1143];
void O2671_init () {
	O2671[0] =  + _REFACS_8_;
	{long i; for (i = 1045; i < 1047; i++) O2671[i] =  + _REFACS_17_;}
	{long i; for (i = 1047; i < 1050; i++) O2671[i] =  + _REFACS_18_;}
	O2671[1050] =  + _REFACS_19_;
	{long i; for (i = 1051; i < 1053; i++) O2671[i] =  + _REFACS_18_;}
	O2671[1053] =  + _REFACS_19_;
	O2671[1054] =  + _REFACS_18_;
	{long i; for (i = 1055; i < 1065; i++) O2671[i] =  + _REFACS_19_;}
	{long i; for (i = 1065; i < 1067; i++) O2671[i] =  + _REFACS_23_;}
	{long i; for (i = 1067; i < 1069; i++) O2671[i] =  + _REFACS_26_;}
	{long i; for (i = 1069; i < 1073; i++) O2671[i] =  + _REFACS_19_;}
	{long i; for (i = 1073; i < 1075; i++) O2671[i] =  + _REFACS_23_;}
	{long i; for (i = 1075; i < 1077; i++) O2671[i] =  + _REFACS_26_;}
	O2671[1077] =  + _REFACS_17_;
	O2671[1078] =  + _REFACS_18_;
	O2671[1079] =  + _REFACS_19_;
	O2671[1080] =  + _REFACS_21_;
	O2671[1081] =  + _REFACS_17_;
	{long i; for (i = 1082; i < 1085; i++) O2671[i] =  + _REFACS_18_;}
	{long i; for (i = 1085; i < 1087; i++) O2671[i] =  + _REFACS_19_;}
	{long i; for (i = 1087; i < 1089; i++) O2671[i] =  + _REFACS_18_;}
	O2671[1089] =  + _REFACS_21_;
	O2671[1090] =  + _REFACS_19_;
	O2671[1091] =  + _REFACS_23_;
	O2671[1092] =  + _REFACS_17_;
	O2671[1093] =  + _REFACS_18_;
	O2671[1094] =  + _REFACS_19_;
	O2671[1095] =  + _REFACS_21_;
	O2671[1096] =  + _REFACS_17_;
	{long i; for (i = 1097; i < 1100; i++) O2671[i] =  + _REFACS_18_;}
	{long i; for (i = 1100; i < 1102; i++) O2671[i] =  + _REFACS_19_;}
	{long i; for (i = 1102; i < 1104; i++) O2671[i] =  + _REFACS_18_;}
	O2671[1104] =  + _REFACS_21_;
	O2671[1105] =  + _REFACS_19_;
	O2671[1106] =  + _REFACS_23_;
	{long i; for (i = 1136; i < 1138; i++) O2671[i] =  + _REFACS_18_;}
	{long i; for (i = 1141; i < 1143; i++) O2671[i] =  + _REFACS_18_;}
}

long O2673[1143];
void O2673_init () {
	O2673[0] =  + _REFACS_9_;
	{long i; for (i = 1045; i < 1047; i++) O2673[i] =  + _REFACS_18_;}
	{long i; for (i = 1047; i < 1050; i++) O2673[i] =  + _REFACS_19_;}
	O2673[1050] =  + _REFACS_20_;
	{long i; for (i = 1051; i < 1053; i++) O2673[i] =  + _REFACS_19_;}
	O2673[1053] =  + _REFACS_20_;
	O2673[1054] =  + _REFACS_19_;
	{long i; for (i = 1055; i < 1065; i++) O2673[i] =  + _REFACS_20_;}
	{long i; for (i = 1065; i < 1067; i++) O2673[i] =  + _REFACS_24_;}
	{long i; for (i = 1067; i < 1069; i++) O2673[i] =  + _REFACS_27_;}
	{long i; for (i = 1069; i < 1073; i++) O2673[i] =  + _REFACS_20_;}
	{long i; for (i = 1073; i < 1075; i++) O2673[i] =  + _REFACS_24_;}
	{long i; for (i = 1075; i < 1077; i++) O2673[i] =  + _REFACS_27_;}
	O2673[1077] =  + _REFACS_18_;
	O2673[1078] =  + _REFACS_19_;
	O2673[1079] =  + _REFACS_20_;
	O2673[1080] =  + _REFACS_22_;
	O2673[1081] =  + _REFACS_18_;
	{long i; for (i = 1082; i < 1085; i++) O2673[i] =  + _REFACS_19_;}
	{long i; for (i = 1085; i < 1087; i++) O2673[i] =  + _REFACS_20_;}
	{long i; for (i = 1087; i < 1089; i++) O2673[i] =  + _REFACS_19_;}
	O2673[1089] =  + _REFACS_22_;
	O2673[1090] =  + _REFACS_20_;
	O2673[1091] =  + _REFACS_24_;
	O2673[1092] =  + _REFACS_18_;
	O2673[1093] =  + _REFACS_19_;
	O2673[1094] =  + _REFACS_20_;
	O2673[1095] =  + _REFACS_22_;
	O2673[1096] =  + _REFACS_18_;
	{long i; for (i = 1097; i < 1100; i++) O2673[i] =  + _REFACS_19_;}
	{long i; for (i = 1100; i < 1102; i++) O2673[i] =  + _REFACS_20_;}
	{long i; for (i = 1102; i < 1104; i++) O2673[i] =  + _REFACS_19_;}
	O2673[1104] =  + _REFACS_22_;
	O2673[1105] =  + _REFACS_20_;
	O2673[1106] =  + _REFACS_24_;
	{long i; for (i = 1136; i < 1138; i++) O2673[i] =  + _REFACS_19_;}
	{long i; for (i = 1141; i < 1143; i++) O2673[i] =  + _REFACS_19_;}
}

long O2675[1143];
void O2675_init () {
	O2675[0] =  + _REFACS_10_;
	{long i; for (i = 1045; i < 1047; i++) O2675[i] =  + _REFACS_19_;}
	{long i; for (i = 1047; i < 1050; i++) O2675[i] =  + _REFACS_20_;}
	O2675[1050] =  + _REFACS_21_;
	{long i; for (i = 1051; i < 1053; i++) O2675[i] =  + _REFACS_20_;}
	O2675[1053] =  + _REFACS_21_;
	O2675[1054] =  + _REFACS_20_;
	{long i; for (i = 1055; i < 1065; i++) O2675[i] =  + _REFACS_21_;}
	{long i; for (i = 1065; i < 1067; i++) O2675[i] =  + _REFACS_25_;}
	{long i; for (i = 1067; i < 1069; i++) O2675[i] =  + _REFACS_28_;}
	{long i; for (i = 1069; i < 1073; i++) O2675[i] =  + _REFACS_21_;}
	{long i; for (i = 1073; i < 1075; i++) O2675[i] =  + _REFACS_25_;}
	{long i; for (i = 1075; i < 1077; i++) O2675[i] =  + _REFACS_28_;}
	O2675[1077] =  + _REFACS_19_;
	O2675[1078] =  + _REFACS_20_;
	O2675[1079] =  + _REFACS_21_;
	O2675[1080] =  + _REFACS_23_;
	O2675[1081] =  + _REFACS_19_;
	{long i; for (i = 1082; i < 1085; i++) O2675[i] =  + _REFACS_20_;}
	{long i; for (i = 1085; i < 1087; i++) O2675[i] =  + _REFACS_21_;}
	{long i; for (i = 1087; i < 1089; i++) O2675[i] =  + _REFACS_20_;}
	O2675[1089] =  + _REFACS_23_;
	O2675[1090] =  + _REFACS_21_;
	O2675[1091] =  + _REFACS_25_;
	O2675[1092] =  + _REFACS_19_;
	O2675[1093] =  + _REFACS_20_;
	O2675[1094] =  + _REFACS_21_;
	O2675[1095] =  + _REFACS_23_;
	O2675[1096] =  + _REFACS_19_;
	{long i; for (i = 1097; i < 1100; i++) O2675[i] =  + _REFACS_20_;}
	{long i; for (i = 1100; i < 1102; i++) O2675[i] =  + _REFACS_21_;}
	{long i; for (i = 1102; i < 1104; i++) O2675[i] =  + _REFACS_20_;}
	O2675[1104] =  + _REFACS_23_;
	O2675[1105] =  + _REFACS_21_;
	O2675[1106] =  + _REFACS_25_;
	{long i; for (i = 1136; i < 1138; i++) O2675[i] =  + _REFACS_20_;}
	{long i; for (i = 1141; i < 1143; i++) O2675[i] =  + _REFACS_20_;}
}

long O2677[1143];
void O2677_init () {
	O2677[0] =  + _REFACS_11_;
	{long i; for (i = 1045; i < 1047; i++) O2677[i] =  + _REFACS_20_;}
	{long i; for (i = 1047; i < 1050; i++) O2677[i] =  + _REFACS_21_;}
	O2677[1050] =  + _REFACS_22_;
	{long i; for (i = 1051; i < 1053; i++) O2677[i] =  + _REFACS_21_;}
	O2677[1053] =  + _REFACS_22_;
	O2677[1054] =  + _REFACS_21_;
	{long i; for (i = 1055; i < 1065; i++) O2677[i] =  + _REFACS_22_;}
	{long i; for (i = 1065; i < 1067; i++) O2677[i] =  + _REFACS_26_;}
	{long i; for (i = 1067; i < 1069; i++) O2677[i] =  + _REFACS_29_;}
	{long i; for (i = 1069; i < 1073; i++) O2677[i] =  + _REFACS_22_;}
	{long i; for (i = 1073; i < 1075; i++) O2677[i] =  + _REFACS_26_;}
	{long i; for (i = 1075; i < 1077; i++) O2677[i] =  + _REFACS_29_;}
	O2677[1077] =  + _REFACS_20_;
	O2677[1078] =  + _REFACS_21_;
	O2677[1079] =  + _REFACS_22_;
	O2677[1080] =  + _REFACS_24_;
	O2677[1081] =  + _REFACS_20_;
	{long i; for (i = 1082; i < 1085; i++) O2677[i] =  + _REFACS_21_;}
	{long i; for (i = 1085; i < 1087; i++) O2677[i] =  + _REFACS_22_;}
	{long i; for (i = 1087; i < 1089; i++) O2677[i] =  + _REFACS_21_;}
	O2677[1089] =  + _REFACS_24_;
	O2677[1090] =  + _REFACS_22_;
	O2677[1091] =  + _REFACS_26_;
	O2677[1092] =  + _REFACS_20_;
	O2677[1093] =  + _REFACS_21_;
	O2677[1094] =  + _REFACS_22_;
	O2677[1095] =  + _REFACS_24_;
	O2677[1096] =  + _REFACS_20_;
	{long i; for (i = 1097; i < 1100; i++) O2677[i] =  + _REFACS_21_;}
	{long i; for (i = 1100; i < 1102; i++) O2677[i] =  + _REFACS_22_;}
	{long i; for (i = 1102; i < 1104; i++) O2677[i] =  + _REFACS_21_;}
	O2677[1104] =  + _REFACS_24_;
	O2677[1105] =  + _REFACS_22_;
	O2677[1106] =  + _REFACS_26_;
	{long i; for (i = 1136; i < 1138; i++) O2677[i] =  + _REFACS_21_;}
	{long i; for (i = 1141; i < 1143; i++) O2677[i] =  + _REFACS_21_;}
}


#ifdef __cplusplus
}
#endif
