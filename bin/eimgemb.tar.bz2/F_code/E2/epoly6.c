#include "epoly6.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4040[763])();
void R4040_init () {
	R4040[0] = (char *(*)()) F504_4430;
	R4040[1] = (char *(*)()) F505_4430_4040_4;
	R4040[2] = (char *(*)()) F506_4430_4040_4;
	R4040[3] = (char *(*)()) F507_4430_4040_4;
	R4040[4] = (char *(*)()) F508_4430_4040_4;
	R4040[5] = (char *(*)()) F509_4430_4040_4;
	R4040[6] = (char *(*)()) F510_4430_4040_4;
	R4040[7] = (char *(*)()) F511_4430_4040_4;
	R4040[8] = (char *(*)()) F512_4430_4040_4;
	R4040[9] = (char *(*)()) F513_4430_4040_4;
	R4040[10] = (char *(*)()) F514_4430_4040_4;
	R4040[11] = (char *(*)()) F515_4430_4040_4;
	R4040[61] = (char *(*)()) F529_4485;
	R4040[62] = (char *(*)()) F533_4485_4040_4;
	R4040[63] = (char *(*)()) F538_4485_4040_4;
	R4040[64] = (char *(*)()) F529_4485;
	R4040[65] = (char *(*)()) F538_4485_4040_4;
	R4040[66] = (char *(*)()) F533_4485_4040_4;
	R4040[67] = (char *(*)()) F571_4574;
	R4040[70] = (char *(*)()) F574_4671;
	R4040[71] = (char *(*)()) F575_4671_4040_4;
	R4040[72] = (char *(*)()) F576_4671_4040_4;
	R4040[73] = (char *(*)()) F577_4671_4040_4;
	R4040[74] = (char *(*)()) F578_4671;
	R4040[75] = (char *(*)()) F579_4671_4040_4;
	R4040[76] = (char *(*)()) F580_4671_4040_4;
	R4040[77] = (char *(*)()) F574_4671;
	R4040[78] = (char *(*)()) F579_4671_4040_4;
	R4040[79] = (char *(*)()) F575_4671_4040_4;
	R4040[80] = (char *(*)()) F574_4671;
	R4040[81] = (char *(*)()) F585_4802;
	R4040[82] = (char *(*)()) F586_4802_4040_4;
	R4040[83] = (char *(*)()) F587_4802_4040_4;
	R4040[84] = (char *(*)()) F588_4802_4040_4;
	R4040[85] = (char *(*)()) F589_4802_4040_4;
	R4040[86] = (char *(*)()) F590_4802_4040_4;
	R4040[87] = (char *(*)()) F591_4802_4040_4;
	R4040[88] = (char *(*)()) F592_4802_4040_4;
	R4040[89] = (char *(*)()) F593_4802_4040_4;
	R4040[90] = (char *(*)()) F594_4802_4040_4;
	R4040[91] = (char *(*)()) F595_4802_4040_4;
	R4040[92] = (char *(*)()) F596_4802_4040_4;
	{long i; for (i = 98; i < 101; i++) R4040[i] = (char *(*)()) F602_4866;}
	{long i; for (i = 107; i < 110; i++) R4040[i] = (char *(*)()) F602_4866;}
	R4040[111] = (char *(*)()) F602_4866;
	R4040[114] = (char *(*)()) F602_4866;
	{long i; for (i = 116; i < 119; i++) R4040[i] = (char *(*)()) F602_4866;}
	R4040[121] = (char *(*)()) F585_4802;
	R4040[122] = (char *(*)()) F589_4802_4040_4;
	R4040[123] = (char *(*)()) F585_4802;
	R4040[206] = (char *(*)()) F408_4253_4040_4;
	{long i; for (i = 320; i < 322; i++) R4040[i] = (char *(*)()) F823_5851_4040_4;}
	R4040[446] = (char *(*)()) F950_7720_4040_4;
	R4040[450] = (char *(*)()) F954_7888_4040_4;
	{long i; for (i = 529; i < 533; i++) R4040[i] = (char *(*)()) F1028_8720;}
	{long i; for (i = 534; i < 536; i++) R4040[i] = (char *(*)()) F1028_8720;}
	{long i; for (i = 538; i < 542; i++) R4040[i] = (char *(*)()) F1028_8720;}
	{long i; for (i = 543; i < 545; i++) R4040[i] = (char *(*)()) F1028_8720;}
	R4040[571] = (char *(*)()) F529_4485;
	R4040[580] = (char *(*)()) F529_4485;
	R4040[762] = (char *(*)()) F823_5851_4040_4;
}
static void F505_4430_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F505_4430(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F506_4430_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F506_4430(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F507_4430_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F507_4430(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F508_4430_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F508_4430(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F509_4430_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F509_4430(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F510_4430_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F510_4430(Current, *(EIF_POINTER *)arg1);
}
static void F511_4430_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F511_4430(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F512_4430_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F512_4430(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F513_4430_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F513_4430(Current, *(EIF_BOOLEAN *)arg1);
}
static void F514_4430_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F514_4430(Current, *(EIF_REAL_32 *)arg1);
}
static void F515_4430_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F515_4430(Current, *(EIF_REAL_64 *)arg1);
}
static void F533_4485_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F533_4485(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F538_4485_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F538_4485(Current, *(EIF_BOOLEAN *)arg1);
}
static void F575_4671_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F575_4671(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F576_4671_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F576_4671(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F577_4671_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F577_4671(Current, *(EIF_POINTER *)arg1);
}
static void F579_4671_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F579_4671(Current, *(EIF_BOOLEAN *)arg1);
}
static void F580_4671_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F580_4671(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F586_4802_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F586_4802(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F587_4802_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F587_4802(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F588_4802_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F588_4802(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F589_4802_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F589_4802(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F590_4802_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F590_4802(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F591_4802_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F591_4802(Current, *(EIF_POINTER *)arg1);
}
static void F592_4802_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F592_4802(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F593_4802_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F593_4802(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F594_4802_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F594_4802(Current, *(EIF_BOOLEAN *)arg1);
}
static void F595_4802_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F595_4802(Current, *(EIF_REAL_32 *)arg1);
}
static void F596_4802_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F596_4802(Current, *(EIF_REAL_64 *)arg1);
}
static void F408_4253_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F408_4253(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F823_5851_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F823_5851(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F950_7720_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F950_7720(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F954_7888_4040_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F954_7888(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R4041[581])();
void R4041_init () {
	R4041[0] = (char *(*)()) F311_4210;
	R4041[1] = (char *(*)()) F314_4210_4041_4;
	R4041[2] = (char *(*)()) F312_4210_4041_4;
	R4041[3] = (char *(*)()) F313_4210_4041_4;
	R4041[4] = (char *(*)()) F316_4210_4041_4;
	R4041[5] = (char *(*)()) F315_4210_4041_4;
	R4041[6] = (char *(*)()) F317_4210_4041_4;
	R4041[7] = (char *(*)()) F318_4210_4041_4;
	R4041[8] = (char *(*)()) F319_4210_4041_4;
	R4041[9] = (char *(*)()) F320_4210_4041_4;
	R4041[10] = (char *(*)()) F321_4210_4041_4;
	R4041[11] = (char *(*)()) F322_4210_4041_4;
	R4041[61] = (char *(*)()) F529_4486;
	R4041[62] = (char *(*)()) F533_4486_4041_4;
	R4041[63] = (char *(*)()) F538_4486_4041_4;
	R4041[64] = (char *(*)()) F311_4210;
	R4041[65] = (char *(*)()) F320_4210_4041_4;
	R4041[66] = (char *(*)()) F316_4210_4041_4;
	R4041[67] = (char *(*)()) F571_4575;
	R4041[70] = (char *(*)()) F311_4210;
	{long i; for (i = 71; i < 73; i++) R4041[i] = (char *(*)()) F316_4210_4041_4;}
	R4041[73] = (char *(*)()) F317_4210_4041_4;
	R4041[74] = (char *(*)()) F311_4210;
	R4041[75] = (char *(*)()) F320_4210_4041_4;
	R4041[76] = (char *(*)()) F316_4210_4041_4;
	R4041[77] = (char *(*)()) F311_4210;
	R4041[78] = (char *(*)()) F320_4210_4041_4;
	R4041[79] = (char *(*)()) F316_4210_4041_4;
	R4041[80] = (char *(*)()) F311_4210;
	{long i; for (i = 98; i < 101; i++) R4041[i] = (char *(*)()) F600_4842;}
	{long i; for (i = 107; i < 110; i++) R4041[i] = (char *(*)()) F600_4842;}
	R4041[111] = (char *(*)()) F600_4842;
	R4041[114] = (char *(*)()) F600_4842;
	{long i; for (i = 116; i < 119; i++) R4041[i] = (char *(*)()) F600_4842;}
	R4041[121] = (char *(*)()) F600_4842;
	R4041[122] = (char *(*)()) F601_4842_4041_4;
	R4041[123] = (char *(*)()) F600_4842;
	R4041[206] = (char *(*)()) F316_4210_4041_4;
	R4041[450] = (char *(*)()) F954_7889_4041_4;
	{long i; for (i = 529; i < 531; i++) R4041[i] = (char *(*)()) F529_4486;}
	{long i; for (i = 531; i < 533; i++) R4041[i] = (char *(*)()) F311_4210;}
	{long i; for (i = 534; i < 536; i++) R4041[i] = (char *(*)()) F311_4210;}
	{long i; for (i = 538; i < 542; i++) R4041[i] = (char *(*)()) F311_4210;}
	{long i; for (i = 543; i < 545; i++) R4041[i] = (char *(*)()) F311_4210;}
	R4041[571] = (char *(*)()) F529_4486;
	R4041[580] = (char *(*)()) F529_4486;
}
static void F314_4210_4041_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F314_4210(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F312_4210_4041_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F312_4210(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F313_4210_4041_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F313_4210(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F316_4210_4041_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F316_4210(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F315_4210_4041_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F315_4210(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F317_4210_4041_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F317_4210(Current, *(EIF_POINTER *)arg1);
}
static void F318_4210_4041_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F318_4210(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F319_4210_4041_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F319_4210(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F320_4210_4041_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F320_4210(Current, *(EIF_BOOLEAN *)arg1);
}
static void F321_4210_4041_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F321_4210(Current, *(EIF_REAL_32 *)arg1);
}
static void F322_4210_4041_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F322_4210(Current, *(EIF_REAL_64 *)arg1);
}
static void F533_4486_4041_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F533_4486(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F538_4486_4041_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F538_4486(Current, *(EIF_BOOLEAN *)arg1);
}
static void F601_4842_4041_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F601_4842(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F954_7889_4041_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F954_7889(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R4042[511])();
void R4042_init () {
	R4042[0] = (char *(*)()) F574_4672;
	R4042[1] = (char *(*)()) F575_4672;
	R4042[2] = (char *(*)()) F576_4672;
	R4042[3] = (char *(*)()) F577_4672;
	R4042[4] = (char *(*)()) F578_4672;
	R4042[5] = (char *(*)()) F579_4672;
	R4042[6] = (char *(*)()) F580_4672;
	R4042[7] = (char *(*)()) F574_4672;
	R4042[8] = (char *(*)()) F579_4672;
	R4042[9] = (char *(*)()) F575_4672;
	R4042[10] = (char *(*)()) F574_4672;
	R4042[11] = (char *(*)()) F585_4808;
	R4042[12] = (char *(*)()) F586_4808;
	R4042[13] = (char *(*)()) F587_4808;
	R4042[14] = (char *(*)()) F588_4808;
	R4042[15] = (char *(*)()) F589_4808;
	R4042[16] = (char *(*)()) F590_4808;
	R4042[17] = (char *(*)()) F591_4808;
	R4042[18] = (char *(*)()) F592_4808;
	R4042[19] = (char *(*)()) F593_4808;
	R4042[20] = (char *(*)()) F594_4808;
	R4042[21] = (char *(*)()) F595_4808;
	R4042[22] = (char *(*)()) F596_4808;
	{long i; for (i = 28; i < 31; i++) R4042[i] = (char *(*)()) F600_4844;}
	{long i; for (i = 37; i < 40; i++) R4042[i] = (char *(*)()) F600_4844;}
	R4042[41] = (char *(*)()) F600_4844;
	R4042[44] = (char *(*)()) F600_4844;
	{long i; for (i = 46; i < 49; i++) R4042[i] = (char *(*)()) F600_4844;}
	R4042[51] = (char *(*)()) F600_4844;
	R4042[52] = (char *(*)()) F601_4844;
	R4042[53] = (char *(*)()) F600_4844;
	R4042[380] = (char *(*)()) F954_7892;
	{long i; for (i = 459; i < 461; i++) R4042[i] = (char *(*)()) F1025_8633;}
	{long i; for (i = 461; i < 463; i++) R4042[i] = (char *(*)()) F1035_8782;}
	{long i; for (i = 464; i < 466; i++) R4042[i] = (char *(*)()) F1035_8782;}
	{long i; for (i = 468; i < 472; i++) R4042[i] = (char *(*)()) F1035_8782;}
	{long i; for (i = 473; i < 475; i++) R4042[i] = (char *(*)()) F1035_8782;}
	R4042[501] = (char *(*)()) F1025_8633;
	R4042[510] = (char *(*)()) F1025_8633;
}

char *(*R4045[581])();
void R4045_init () {
	R4045[0] = (char *(*)()) F504_4380_4045_5;
	R4045[1] = (char *(*)()) F505_4380_4045_5;
	R4045[2] = (char *(*)()) F506_4380_4045_5;
	R4045[3] = (char *(*)()) F507_4380_4045_5;
	R4045[4] = (char *(*)()) F508_4380_4045_5;
	R4045[5] = (char *(*)()) F509_4380_4045_5;
	R4045[6] = (char *(*)()) F510_4380_4045_5;
	R4045[7] = (char *(*)()) F511_4380_4045_5;
	R4045[8] = (char *(*)()) F512_4380_4045_5;
	R4045[9] = (char *(*)()) F513_4380_4045_5;
	R4045[10] = (char *(*)()) F514_4380_4045_5;
	R4045[11] = (char *(*)()) F515_4380_4045_5;
	R4045[61] = (char *(*)()) F517_4459_4045_5;
	R4045[62] = (char *(*)()) F521_4459_4045_5;
	R4045[63] = (char *(*)()) F526_4459_4045_5;
	R4045[64] = (char *(*)()) F517_4459_4045_5;
	R4045[65] = (char *(*)()) F526_4459_4045_5;
	R4045[66] = (char *(*)()) F521_4459_4045_5;
	R4045[67] = (char *(*)()) F517_4459_4045_5;
	R4045[81] = (char *(*)()) F585_4755_4045_5;
	R4045[82] = (char *(*)()) F586_4755_4045_5;
	R4045[83] = (char *(*)()) F587_4755_4045_5;
	R4045[84] = (char *(*)()) F588_4755_4045_5;
	R4045[85] = (char *(*)()) F589_4755_4045_5;
	R4045[86] = (char *(*)()) F590_4755_4045_5;
	R4045[87] = (char *(*)()) F591_4755_4045_5;
	R4045[88] = (char *(*)()) F592_4755_4045_5;
	R4045[89] = (char *(*)()) F593_4755_4045_5;
	R4045[90] = (char *(*)()) F594_4755_4045_5;
	R4045[91] = (char *(*)()) F595_4755_4045_5;
	R4045[92] = (char *(*)()) F596_4755_4045_5;
	{long i; for (i = 98; i < 101; i++) R4045[i] = (char *(*)()) F585_4755_4045_5;}
	{long i; for (i = 107; i < 110; i++) R4045[i] = (char *(*)()) F585_4755_4045_5;}
	R4045[111] = (char *(*)()) F585_4755_4045_5;
	R4045[114] = (char *(*)()) F585_4755_4045_5;
	{long i; for (i = 116; i < 119; i++) R4045[i] = (char *(*)()) F585_4755_4045_5;}
	R4045[121] = (char *(*)()) F585_4755_4045_5;
	R4045[122] = (char *(*)()) F589_4755_4045_5;
	R4045[123] = (char *(*)()) F585_4755_4045_5;
	R4045[446] = (char *(*)()) F950_7661_4045_5;
	R4045[450] = (char *(*)()) F954_7830_4045_5;
	{long i; for (i = 529; i < 531; i++) R4045[i] = (char *(*)()) F1025_8605_4045_5;}
	R4045[571] = (char *(*)()) F1025_8605_4045_5;
	R4045[580] = (char *(*)()) F1025_8605_4045_5;
}
static EIF_REFERENCE F504_4380_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F504_4380(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F505_4380_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F505_4380(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F506_4380_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F506_4380(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F507_4380_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F507_4380(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F508_4380_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F508_4380(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F509_4380_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F509_4380(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F510_4380_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F510_4380(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F511_4380_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F511_4380(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(877, 0x00).id, 877, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F512_4380_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F512_4380(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F513_4380_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F513_4380(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F514_4380_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F514_4380(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F515_4380_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F515_4380(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(892, 0x00).id, 892, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F517_4459_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F517_4459(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F521_4459_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F521_4459(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F526_4459_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F526_4459(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F585_4755_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F585_4755(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F586_4755_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F586_4755(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_4755_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F587_4755(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_4755_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F588_4755(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_4755_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F589_4755(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F590_4755_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F590_4755(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F591_4755_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F591_4755(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F592_4755_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F592_4755(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(877, 0x00).id, 877, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F593_4755_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F593_4755(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F594_4755_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F594_4755(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F595_4755_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F595_4755(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F596_4755_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F596_4755(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(892, 0x00).id, 892, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F950_7661_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F950_7661(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F954_7830_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F954_7830(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1025_8605_4045_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1025_8605(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4046[581])();
void R4046_init () {
	R4046[0] = (char *(*)()) F504_4381_4046_5;
	R4046[1] = (char *(*)()) F505_4381_4046_5;
	R4046[2] = (char *(*)()) F506_4381_4046_5;
	R4046[3] = (char *(*)()) F507_4381_4046_5;
	R4046[4] = (char *(*)()) F508_4381_4046_5;
	R4046[5] = (char *(*)()) F509_4381_4046_5;
	R4046[6] = (char *(*)()) F510_4381_4046_5;
	R4046[7] = (char *(*)()) F511_4381_4046_5;
	R4046[8] = (char *(*)()) F512_4381_4046_5;
	R4046[9] = (char *(*)()) F513_4381_4046_5;
	R4046[10] = (char *(*)()) F514_4381_4046_5;
	R4046[11] = (char *(*)()) F515_4381_4046_5;
	R4046[61] = (char *(*)()) F517_4460_4046_5;
	R4046[62] = (char *(*)()) F521_4460_4046_5;
	R4046[63] = (char *(*)()) F526_4460_4046_5;
	R4046[64] = (char *(*)()) F517_4460_4046_5;
	R4046[65] = (char *(*)()) F526_4460_4046_5;
	R4046[66] = (char *(*)()) F521_4460_4046_5;
	R4046[67] = (char *(*)()) F517_4460_4046_5;
	R4046[81] = (char *(*)()) F585_4756_4046_5;
	R4046[82] = (char *(*)()) F586_4756_4046_5;
	R4046[83] = (char *(*)()) F587_4756_4046_5;
	R4046[84] = (char *(*)()) F588_4756_4046_5;
	R4046[85] = (char *(*)()) F589_4756_4046_5;
	R4046[86] = (char *(*)()) F590_4756_4046_5;
	R4046[87] = (char *(*)()) F591_4756_4046_5;
	R4046[88] = (char *(*)()) F592_4756_4046_5;
	R4046[89] = (char *(*)()) F593_4756_4046_5;
	R4046[90] = (char *(*)()) F594_4756_4046_5;
	R4046[91] = (char *(*)()) F595_4756_4046_5;
	R4046[92] = (char *(*)()) F596_4756_4046_5;
	{long i; for (i = 98; i < 101; i++) R4046[i] = (char *(*)()) F585_4756_4046_5;}
	{long i; for (i = 107; i < 110; i++) R4046[i] = (char *(*)()) F585_4756_4046_5;}
	R4046[111] = (char *(*)()) F585_4756_4046_5;
	R4046[114] = (char *(*)()) F585_4756_4046_5;
	{long i; for (i = 116; i < 119; i++) R4046[i] = (char *(*)()) F585_4756_4046_5;}
	R4046[121] = (char *(*)()) F585_4756_4046_5;
	R4046[122] = (char *(*)()) F589_4756_4046_5;
	R4046[123] = (char *(*)()) F585_4756_4046_5;
	R4046[450] = (char *(*)()) F954_7831_4046_5;
	{long i; for (i = 529; i < 531; i++) R4046[i] = (char *(*)()) F517_4460_4046_5;}
	R4046[571] = (char *(*)()) F517_4460_4046_5;
	R4046[580] = (char *(*)()) F517_4460_4046_5;
}
static EIF_REFERENCE F504_4381_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F504_4381(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F505_4381_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F505_4381(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F506_4381_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F506_4381(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F507_4381_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F507_4381(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F508_4381_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F508_4381(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F509_4381_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F509_4381(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F510_4381_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F510_4381(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F511_4381_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F511_4381(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(877, 0x00).id, 877, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F512_4381_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F512_4381(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F513_4381_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F513_4381(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F514_4381_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F514_4381(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F515_4381_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F515_4381(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(892, 0x00).id, 892, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F517_4460_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F517_4460(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F521_4460_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F521_4460(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F526_4460_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F526_4460(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F585_4756_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F585_4756(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F586_4756_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F586_4756(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_4756_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F587_4756(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_4756_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F588_4756(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_4756_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F589_4756(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F590_4756_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F590_4756(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F591_4756_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F591_4756(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F592_4756_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F592_4756(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(877, 0x00).id, 877, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F593_4756_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F593_4756(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F594_4756_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F594_4756(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F595_4756_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F595_4756(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F596_4756_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F596_4756(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(892, 0x00).id, 892, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F954_7831_4046_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F954_7831(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}

char *(*R4048[451])();
void R4048_init () {
	R4048[0] = (char *(*)()) F504_4399_4048_13;
	R4048[1] = (char *(*)()) F505_4399_4048_13;
	R4048[2] = (char *(*)()) F506_4399_4048_13;
	R4048[3] = (char *(*)()) F507_4399_4048_13;
	R4048[4] = (char *(*)()) F508_4399_4048_13;
	R4048[5] = (char *(*)()) F509_4399_4048_13;
	R4048[6] = (char *(*)()) F510_4399_4048_13;
	R4048[7] = (char *(*)()) F511_4399_4048_13;
	R4048[8] = (char *(*)()) F512_4399_4048_13;
	R4048[9] = (char *(*)()) F513_4399_4048_13;
	R4048[10] = (char *(*)()) F514_4399_4048_13;
	R4048[11] = (char *(*)()) F515_4399_4048_13;
	R4048[70] = (char *(*)()) F574_4664;
	R4048[71] = (char *(*)()) F575_4664_4048_13;
	R4048[72] = (char *(*)()) F576_4664_4048_13;
	R4048[73] = (char *(*)()) F577_4664_4048_13;
	R4048[74] = (char *(*)()) F578_4664_4048_13;
	R4048[75] = (char *(*)()) F579_4664_4048_13;
	R4048[76] = (char *(*)()) F580_4664_4048_13;
	R4048[77] = (char *(*)()) F574_4664;
	R4048[78] = (char *(*)()) F579_4664_4048_13;
	R4048[79] = (char *(*)()) F575_4664_4048_13;
	R4048[80] = (char *(*)()) F574_4664;
	R4048[81] = (char *(*)()) F585_4788_4048_13;
	R4048[82] = (char *(*)()) F586_4788_4048_13;
	R4048[83] = (char *(*)()) F587_4788_4048_13;
	R4048[84] = (char *(*)()) F588_4788_4048_13;
	R4048[85] = (char *(*)()) F589_4788_4048_13;
	R4048[86] = (char *(*)()) F590_4788_4048_13;
	R4048[87] = (char *(*)()) F591_4788_4048_13;
	R4048[88] = (char *(*)()) F592_4788_4048_13;
	R4048[89] = (char *(*)()) F593_4788_4048_13;
	R4048[90] = (char *(*)()) F594_4788_4048_13;
	R4048[91] = (char *(*)()) F595_4788_4048_13;
	R4048[92] = (char *(*)()) F596_4788_4048_13;
	{long i; for (i = 98; i < 101; i++) R4048[i] = (char *(*)()) F600_4836_4048_13;}
	{long i; for (i = 107; i < 110; i++) R4048[i] = (char *(*)()) F600_4836_4048_13;}
	R4048[111] = (char *(*)()) F600_4836_4048_13;
	R4048[114] = (char *(*)()) F600_4836_4048_13;
	{long i; for (i = 116; i < 119; i++) R4048[i] = (char *(*)()) F600_4836_4048_13;}
	R4048[121] = (char *(*)()) F600_4836_4048_13;
	R4048[122] = (char *(*)()) F601_4836_4048_13;
	R4048[123] = (char *(*)()) F600_4836_4048_13;
	R4048[446] = (char *(*)()) F950_7682_4048_13;
	R4048[450] = (char *(*)()) F954_7850_4048_13;
}
static void F504_4399_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F504_4399(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F505_4399_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F505_4399(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F506_4399_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F506_4399(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F507_4399_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F507_4399(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F508_4399_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F508_4399(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F509_4399_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F509_4399(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F510_4399_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F510_4399(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F511_4399_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F511_4399(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F512_4399_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F512_4399(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F513_4399_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F513_4399(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F514_4399_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F514_4399(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F515_4399_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F515_4399(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F575_4664_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F575_4664(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F576_4664_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F576_4664(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static void F577_4664_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F577_4664(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F578_4664_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F578_4664(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F579_4664_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F579_4664(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F580_4664_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F580_4664(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F585_4788_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F585_4788(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F586_4788_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F586_4788(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F587_4788_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F587_4788(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F588_4788_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F588_4788(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F589_4788_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F589_4788(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F590_4788_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F590_4788(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F591_4788_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F591_4788(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F592_4788_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F592_4788(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F593_4788_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F593_4788(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F594_4788_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F594_4788(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F595_4788_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F595_4788(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F596_4788_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F596_4788(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F600_4836_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F600_4836(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F601_4836_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F601_4836(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F950_7682_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F950_7682(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F954_7850_4048_13 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F954_7850(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y4050_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype30[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype31[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype32[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype33[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype34[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype35[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype36[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype37[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype38[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype39[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype40[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype41[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype42[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype43[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype44[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype45[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype46[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype47[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype48[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype49[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype50[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype51[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype52[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype53[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype54[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype55[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype56[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype57[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype58[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype59[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype60[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype61[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype62[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype63[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype64[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype65[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype66[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype67[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype68[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype69[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype70[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype71[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype72[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype73[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype74[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype75[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype76[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype77[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype78[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype79[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype80[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype81[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype82[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype83[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype84[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype85[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype86[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype87[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype88[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype89[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype90[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype91[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype92[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype93[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype94[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype95[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype96[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype97[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype98[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype99[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype100[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype101[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype102[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype103[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype104[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype105[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype106[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype107[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype108[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype109[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype110[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype111[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype112[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype113[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype114[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype115[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype116[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype117[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype118[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype119[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype120[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype121[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype122[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype123[] = {944,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype124[] = {944,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype125[] = {944,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype126[] = {949,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype127[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype128[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype129[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype130[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype131[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype132[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype133[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype134[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype135[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype136[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype137[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype138[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype139[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype140[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype141[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype142[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype143[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype144[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype145[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype146[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype147[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype148[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype149[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype150[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype151[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype152[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype153[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype154[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype155[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype156[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype157[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype158[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype159[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype160[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype161[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype162[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype163[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype164[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype165[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype166[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype167[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype168[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype169[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype170[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype171[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype172[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype173[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype174[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype175[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype176[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype177[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype178[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype179[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype180[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype181[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype182[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype183[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype184[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype185[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype186[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype187[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype188[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype189[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype190[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype191[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype192[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y4050_pgtype193[] = {868,0xFFFF};
EIF_TYPE_INDEX *Y4050_gen_type [750];
EIF_TYPE_INDEX Y4050 [750];
void Y4050_init (void)
{
	egc_routines_types [4050] = Y4050;
	egc_routines_gen_types [4050] = Y4050_gen_type;
	egc_routines_offset [4050] = 335;
	Y4050_gen_type [0] = Y4050_pgtype0;
	Y4050_gen_type [1] = Y4050_pgtype1;
	Y4050_gen_type [2] = Y4050_pgtype2;
	Y4050_gen_type [3] = Y4050_pgtype3;
	Y4050_gen_type [4] = Y4050_pgtype4;
	Y4050_gen_type [5] = Y4050_pgtype5;
	Y4050_gen_type [6] = Y4050_pgtype6;
	Y4050_gen_type [7] = Y4050_pgtype7;
	Y4050_gen_type [8] = Y4050_pgtype8;
	Y4050_gen_type [9] = Y4050_pgtype9;
	Y4050_gen_type [10] = Y4050_pgtype10;
	Y4050_gen_type [11] = Y4050_pgtype11;
	Y4050_gen_type [12] = Y4050_pgtype12;
	Y4050_gen_type [13] = Y4050_pgtype13;
	Y4050_gen_type [14] = Y4050_pgtype14;
	Y4050_gen_type [15] = Y4050_pgtype15;
	Y4050_gen_type [16] = Y4050_pgtype16;
	Y4050_gen_type [17] = Y4050_pgtype17;
	Y4050_gen_type [18] = Y4050_pgtype18;
	Y4050_gen_type [19] = Y4050_pgtype19;
	Y4050_gen_type [20] = Y4050_pgtype20;
	Y4050_gen_type [21] = Y4050_pgtype21;
	Y4050_gen_type [22] = Y4050_pgtype22;
	Y4050_gen_type [23] = Y4050_pgtype23;
	Y4050_gen_type [24] = Y4050_pgtype24;
	Y4050_gen_type [25] = Y4050_pgtype25;
	Y4050_gen_type [26] = Y4050_pgtype26;
	Y4050_gen_type [27] = Y4050_pgtype27;
	Y4050_gen_type [28] = Y4050_pgtype28;
	Y4050_gen_type [29] = Y4050_pgtype29;
	Y4050_gen_type [30] = Y4050_pgtype30;
	Y4050_gen_type [31] = Y4050_pgtype31;
	Y4050_gen_type [32] = Y4050_pgtype32;
	Y4050_gen_type [33] = Y4050_pgtype33;
	Y4050_gen_type [154] = Y4050_pgtype34;
	Y4050_gen_type [155] = Y4050_pgtype35;
	Y4050_gen_type [156] = Y4050_pgtype36;
	Y4050_gen_type [157] = Y4050_pgtype37;
	Y4050_gen_type [158] = Y4050_pgtype38;
	Y4050_gen_type [159] = Y4050_pgtype39;
	Y4050_gen_type [160] = Y4050_pgtype40;
	Y4050_gen_type [161] = Y4050_pgtype41;
	Y4050_gen_type [162] = Y4050_pgtype42;
	Y4050_gen_type [163] = Y4050_pgtype43;
	Y4050_gen_type [164] = Y4050_pgtype44;
	Y4050_gen_type [165] = Y4050_pgtype45;
	Y4050_gen_type [166] = Y4050_pgtype46;
	Y4050_gen_type [167] = Y4050_pgtype47;
	Y4050_gen_type [168] = Y4050_pgtype48;
	Y4050_gen_type [169] = Y4050_pgtype49;
	Y4050_gen_type [170] = Y4050_pgtype50;
	Y4050_gen_type [171] = Y4050_pgtype51;
	Y4050_gen_type [172] = Y4050_pgtype52;
	Y4050_gen_type [173] = Y4050_pgtype53;
	Y4050_gen_type [174] = Y4050_pgtype54;
	Y4050_gen_type [175] = Y4050_pgtype55;
	Y4050_gen_type [176] = Y4050_pgtype56;
	Y4050_gen_type [177] = Y4050_pgtype57;
	Y4050_gen_type [178] = Y4050_pgtype58;
	Y4050_gen_type [179] = Y4050_pgtype59;
	Y4050_gen_type [180] = Y4050_pgtype60;
	Y4050_gen_type [181] = Y4050_pgtype61;
	Y4050_gen_type [182] = Y4050_pgtype62;
	Y4050_gen_type [183] = Y4050_pgtype63;
	Y4050_gen_type [184] = Y4050_pgtype64;
	Y4050_gen_type [185] = Y4050_pgtype65;
	Y4050_gen_type [186] = Y4050_pgtype66;
	Y4050_gen_type [187] = Y4050_pgtype67;
	Y4050_gen_type [188] = Y4050_pgtype68;
	Y4050_gen_type [189] = Y4050_pgtype69;
	Y4050_gen_type [190] = Y4050_pgtype70;
	Y4050_gen_type [191] = Y4050_pgtype71;
	Y4050_gen_type [192] = Y4050_pgtype72;
	Y4050_gen_type [193] = Y4050_pgtype73;
	Y4050_gen_type [194] = Y4050_pgtype74;
	Y4050_gen_type [195] = Y4050_pgtype75;
	Y4050_gen_type [196] = Y4050_pgtype76;
	Y4050_gen_type [197] = Y4050_pgtype77;
	Y4050_gen_type [198] = Y4050_pgtype78;
	Y4050_gen_type [199] = Y4050_pgtype79;
	Y4050_gen_type [200] = Y4050_pgtype80;
	Y4050_gen_type [201] = Y4050_pgtype81;
	Y4050_gen_type [202] = Y4050_pgtype82;
	Y4050_gen_type [203] = Y4050_pgtype83;
	Y4050_gen_type [204] = Y4050_pgtype84;
	Y4050_gen_type [205] = Y4050_pgtype85;
	Y4050_gen_type [206] = Y4050_pgtype86;
	Y4050_gen_type [207] = Y4050_pgtype87;
	Y4050_gen_type [208] = Y4050_pgtype88;
	Y4050_gen_type [209] = Y4050_pgtype89;
	Y4050_gen_type [210] = Y4050_pgtype90;
	Y4050_gen_type [211] = Y4050_pgtype91;
	Y4050_gen_type [212] = Y4050_pgtype92;
	Y4050_gen_type [213] = Y4050_pgtype93;
	Y4050_gen_type [214] = Y4050_pgtype94;
	Y4050_gen_type [215] = Y4050_pgtype95;
	Y4050_gen_type [216] = Y4050_pgtype96;
	Y4050_gen_type [217] = Y4050_pgtype97;
	Y4050_gen_type [218] = Y4050_pgtype98;
	Y4050_gen_type [219] = Y4050_pgtype99;
	Y4050_gen_type [220] = Y4050_pgtype100;
	Y4050_gen_type [221] = Y4050_pgtype101;
	Y4050_gen_type [222] = Y4050_pgtype102;
	Y4050_gen_type [223] = Y4050_pgtype103;
	Y4050_gen_type [224] = Y4050_pgtype104;
	Y4050_gen_type [225] = Y4050_pgtype105;
	Y4050_gen_type [226] = Y4050_pgtype106;
	Y4050_gen_type [227] = Y4050_pgtype107;
	Y4050_gen_type [228] = Y4050_pgtype108;
	Y4050_gen_type [229] = Y4050_pgtype109;
	Y4050_gen_type [230] = Y4050_pgtype110;
	Y4050_gen_type [231] = Y4050_pgtype111;
	Y4050_gen_type [232] = Y4050_pgtype112;
	Y4050_gen_type [233] = Y4050_pgtype113;
	Y4050_gen_type [234] = Y4050_pgtype114;
	Y4050_gen_type [235] = Y4050_pgtype115;
	Y4050_gen_type [238] = Y4050_pgtype116;
	Y4050_gen_type [239] = Y4050_pgtype117;
	Y4050_gen_type [240] = Y4050_pgtype118;
	Y4050_gen_type [241] = Y4050_pgtype119;
	Y4050_gen_type [242] = Y4050_pgtype120;
	Y4050_gen_type [243] = Y4050_pgtype121;
	Y4050_gen_type [244] = Y4050_pgtype122;
	Y4050_gen_type [245] = Y4050_pgtype123;
	Y4050_gen_type [246] = Y4050_pgtype124;
	Y4050_gen_type [247] = Y4050_pgtype125;
	Y4050_gen_type [248] = Y4050_pgtype126;
	Y4050_gen_type [249] = Y4050_pgtype127;
	Y4050_gen_type [250] = Y4050_pgtype128;
	Y4050_gen_type [251] = Y4050_pgtype129;
	Y4050_gen_type [252] = Y4050_pgtype130;
	Y4050_gen_type [253] = Y4050_pgtype131;
	Y4050_gen_type [254] = Y4050_pgtype132;
	Y4050_gen_type [255] = Y4050_pgtype133;
	Y4050_gen_type [256] = Y4050_pgtype134;
	Y4050_gen_type [257] = Y4050_pgtype135;
	Y4050_gen_type [258] = Y4050_pgtype136;
	Y4050_gen_type [259] = Y4050_pgtype137;
	Y4050_gen_type [260] = Y4050_pgtype138;
	Y4050_gen_type [261] = Y4050_pgtype139;
	Y4050_gen_type [262] = Y4050_pgtype140;
	Y4050_gen_type [263] = Y4050_pgtype141;
	Y4050_gen_type [264] = Y4050_pgtype142;
	Y4050_gen_type [265] = Y4050_pgtype143;
	Y4050_gen_type [266] = Y4050_pgtype144;
	Y4050_gen_type [267] = Y4050_pgtype145;
	Y4050_gen_type [268] = Y4050_pgtype146;
	Y4050_gen_type [269] = Y4050_pgtype147;
	Y4050_gen_type [270] = Y4050_pgtype148;
	Y4050_gen_type [271] = Y4050_pgtype149;
	Y4050_gen_type [272] = Y4050_pgtype150;
	Y4050_gen_type [273] = Y4050_pgtype151;
	Y4050_gen_type [274] = Y4050_pgtype152;
	Y4050_gen_type [275] = Y4050_pgtype153;
	Y4050_gen_type [276] = Y4050_pgtype154;
	Y4050_gen_type [277] = Y4050_pgtype155;
	Y4050_gen_type [278] = Y4050_pgtype156;
	Y4050_gen_type [279] = Y4050_pgtype157;
	Y4050_gen_type [280] = Y4050_pgtype158;
	Y4050_gen_type [281] = Y4050_pgtype159;
	Y4050_gen_type [282] = Y4050_pgtype160;
	Y4050_gen_type [283] = Y4050_pgtype161;
	Y4050_gen_type [284] = Y4050_pgtype162;
	Y4050_gen_type [285] = Y4050_pgtype163;
	Y4050_gen_type [286] = Y4050_pgtype164;
	Y4050_gen_type [287] = Y4050_pgtype165;
	Y4050_gen_type [288] = Y4050_pgtype166;
	Y4050_gen_type [289] = Y4050_pgtype167;
	Y4050_gen_type [290] = Y4050_pgtype168;
	Y4050_gen_type [291] = Y4050_pgtype169;
	Y4050_gen_type [614] = Y4050_pgtype170;
	Y4050_gen_type [615] = Y4050_pgtype171;
	Y4050_gen_type [618] = Y4050_pgtype172;
	Y4050_gen_type [689] = Y4050_pgtype173;
	Y4050_gen_type [693] = Y4050_pgtype174;
	Y4050_gen_type [694] = Y4050_pgtype175;
	Y4050_gen_type [695] = Y4050_pgtype176;
	Y4050_gen_type [696] = Y4050_pgtype177;
	Y4050_gen_type [697] = Y4050_pgtype178;
	Y4050_gen_type [698] = Y4050_pgtype179;
	Y4050_gen_type [728] = Y4050_pgtype180;
	Y4050_gen_type [737] = Y4050_pgtype181;
	Y4050_gen_type [738] = Y4050_pgtype182;
	Y4050_gen_type [739] = Y4050_pgtype183;
	Y4050_gen_type [740] = Y4050_pgtype184;
	Y4050_gen_type [741] = Y4050_pgtype185;
	Y4050_gen_type [742] = Y4050_pgtype186;
	Y4050_gen_type [743] = Y4050_pgtype187;
	Y4050_gen_type [744] = Y4050_pgtype188;
	Y4050_gen_type [745] = Y4050_pgtype189;
	Y4050_gen_type [746] = Y4050_pgtype190;
	Y4050_gen_type [747] = Y4050_pgtype191;
	Y4050_gen_type [748] = Y4050_pgtype192;
	Y4050_gen_type [749] = Y4050_pgtype193;
	{long i; for (i = 154; i < 236; i++) Y4050[i] = 868;};
	{long i; for (i = 245; i < 248; i++) Y4050[i] = 944;};
	Y4050[248] = 949;
	{long i; for (i = 249; i < 292; i++) Y4050[i] = 868;};
	{long i; for (i = 614; i < 616; i++) Y4050[i] = 868;};
	Y4050[618] = 868;
	Y4050[689] = 868;
	{long i; for (i = 693; i < 699; i++) Y4050[i] = 868;};
	Y4050[728] = 868;
	{long i; for (i = 737; i < 750; i++) Y4050[i] = 868;};
}

char *(*R4051[381])();
void R4051_init () {
	R4051[0] = (char *(*)()) F574_4670;
	R4051[1] = (char *(*)()) F575_4670;
	R4051[2] = (char *(*)()) F576_4670_4051_4;
	R4051[3] = (char *(*)()) F577_4670;
	R4051[4] = (char *(*)()) F578_4670_4051_4;
	R4051[5] = (char *(*)()) F579_4670;
	R4051[6] = (char *(*)()) F580_4670_4051_4;
	R4051[7] = (char *(*)()) F574_4670;
	R4051[8] = (char *(*)()) F579_4670;
	R4051[9] = (char *(*)()) F575_4670;
	R4051[10] = (char *(*)()) F574_4670;
	R4051[376] = (char *(*)()) F950_7716_4051_4;
	R4051[380] = (char *(*)()) F954_7884_4051_4;
}
static void F576_4670_4051_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F576_4670(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F578_4670_4051_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F578_4670(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F580_4670_4051_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F580_4670(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F950_7716_4051_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F950_7716(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F954_7884_4051_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F954_7884(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4052[702])();
void R4052_init () {
	R4052[0] = (char *(*)()) F565_4507;
	R4052[1] = (char *(*)()) F566_4507_4052_1;
	R4052[2] = (char *(*)()) F567_4507_4052_1;
	R4052[3] = (char *(*)()) F568_4552;
	R4052[4] = (char *(*)()) F569_4552_4052_1;
	R4052[5] = (char *(*)()) F570_4552_4052_1;
	R4052[6] = (char *(*)()) F571_4567;
	R4052[20] = (char *(*)()) F585_4754;
	R4052[21] = (char *(*)()) F586_4754_4052_1;
	R4052[22] = (char *(*)()) F587_4754_4052_1;
	R4052[23] = (char *(*)()) F588_4754_4052_1;
	R4052[24] = (char *(*)()) F589_4754_4052_1;
	R4052[25] = (char *(*)()) F590_4754_4052_1;
	R4052[26] = (char *(*)()) F591_4754_4052_1;
	R4052[27] = (char *(*)()) F592_4754_4052_1;
	R4052[28] = (char *(*)()) F593_4754_4052_1;
	R4052[29] = (char *(*)()) F594_4754_4052_1;
	R4052[30] = (char *(*)()) F595_4754_4052_1;
	R4052[31] = (char *(*)()) F596_4754_4052_1;
	{long i; for (i = 37; i < 40; i++) R4052[i] = (char *(*)()) F585_4754;}
	{long i; for (i = 46; i < 49; i++) R4052[i] = (char *(*)()) F585_4754;}
	R4052[50] = (char *(*)()) F585_4754;
	R4052[53] = (char *(*)()) F585_4754;
	{long i; for (i = 55; i < 58; i++) R4052[i] = (char *(*)()) F585_4754;}
	R4052[60] = (char *(*)()) F585_4754;
	R4052[61] = (char *(*)()) F589_4754_4052_1;
	R4052[62] = (char *(*)()) F585_4754;
	R4052[145] = (char *(*)()) F408_4241_4052_1;
	{long i; for (i = 259; i < 261; i++) R4052[i] = (char *(*)()) F823_5645_4052_1;}
	{long i; for (i = 468; i < 470; i++) R4052[i] = (char *(*)()) F1025_8602;}
	R4052[510] = (char *(*)()) F1025_8602;
	R4052[519] = (char *(*)()) F1025_8602;
	R4052[701] = (char *(*)()) F823_5645_4052_1;
}
static EIF_REFERENCE F566_4507_4052_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F566_4507(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F567_4507_4052_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F567_4507(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F569_4552_4052_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F569_4552(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F570_4552_4052_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F570_4552(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F586_4754_4052_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F586_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F587_4754_4052_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F587_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F588_4754_4052_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F588_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F589_4754_4052_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F589_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F590_4754_4052_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F590_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F591_4754_4052_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F591_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F592_4754_4052_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F592_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(877, 0x00).id, 877, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F593_4754_4052_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F593_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F594_4754_4052_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F594_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F595_4754_4052_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F595_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F596_4754_4052_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F596_4754(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(892, 0x00).id, 892, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F408_4241_4052_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F408_4241(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F823_5645_4052_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F823_5645(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y4052_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype119[] = {939,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype120[] = {939,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype121[] = {939,0xFFF9,1,865,0,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype122[] = {939,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype123[] = {939,0xFFF9,1,865,868,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype124[] = {939,0xFFF9,1,865,1063,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype125[] = {939,0xFFF9,1,865,868,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype126[] = {939,0xFFF9,1,865,1026,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype127[] = {939,0xFFF9,1,865,830,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype128[] = {939,0xFFF9,1,865,1068,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype129[] = {939,0xFFF9,1,865,999,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype130[] = {939,0xFFF9,1,865,1266,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype131[] = {939,0xFFF9,5,865,880,868,868,868,868,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype132[] = {939,0xFFF9,4,865,868,868,868,868,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype133[] = {939,0xFFF9,1,865,868,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype134[] = {939,0xFFF9,1,865,953,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype135[] = {939,0xFFF9,7,865,868,868,892,892,892,868,868,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype136[] = {939,0xFFF9,2,865,868,868,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype137[] = {939,0xFFF9,3,865,868,868,830,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype138[] = {939,0xFFF9,8,865,868,868,868,892,892,892,868,868,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype139[] = {939,0xFFF9,0,865,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4052_pgtype145[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y4052_gen_type [897];
EIF_TYPE_INDEX Y4052 [897];
void Y4052_init (void)
{
	egc_routines_types [4052] = Y4052;
	egc_routines_gen_types [4052] = Y4052_gen_type;
	egc_routines_offset [4052] = 369;
	Y4052_gen_type [0] = Y4052_pgtype0;
	Y4052_gen_type [1] = Y4052_pgtype1;
	Y4052_gen_type [2] = Y4052_pgtype2;
	Y4052_gen_type [3] = Y4052_pgtype3;
	Y4052_gen_type [4] = Y4052_pgtype4;
	Y4052_gen_type [5] = Y4052_pgtype5;
	Y4052_gen_type [6] = Y4052_pgtype6;
	Y4052_gen_type [7] = Y4052_pgtype7;
	Y4052_gen_type [8] = Y4052_pgtype8;
	Y4052_gen_type [9] = Y4052_pgtype9;
	Y4052_gen_type [10] = Y4052_pgtype10;
	Y4052_gen_type [11] = Y4052_pgtype11;
	Y4052_gen_type [12] = Y4052_pgtype12;
	Y4052_gen_type [13] = Y4052_pgtype13;
	Y4052_gen_type [14] = Y4052_pgtype14;
	Y4052_gen_type [15] = Y4052_pgtype15;
	Y4052_gen_type [16] = Y4052_pgtype16;
	Y4052_gen_type [17] = Y4052_pgtype17;
	Y4052_gen_type [18] = Y4052_pgtype18;
	Y4052_gen_type [19] = Y4052_pgtype19;
	Y4052_gen_type [20] = Y4052_pgtype20;
	Y4052_gen_type [21] = Y4052_pgtype21;
	Y4052_gen_type [22] = Y4052_pgtype22;
	Y4052_gen_type [23] = Y4052_pgtype23;
	Y4052_gen_type [38] = Y4052_pgtype24;
	Y4052_gen_type [75] = Y4052_pgtype25;
	Y4052_gen_type [76] = Y4052_pgtype26;
	Y4052_gen_type [77] = Y4052_pgtype27;
	Y4052_gen_type [78] = Y4052_pgtype28;
	Y4052_gen_type [79] = Y4052_pgtype29;
	Y4052_gen_type [80] = Y4052_pgtype30;
	Y4052_gen_type [81] = Y4052_pgtype31;
	Y4052_gen_type [82] = Y4052_pgtype32;
	Y4052_gen_type [83] = Y4052_pgtype33;
	Y4052_gen_type [84] = Y4052_pgtype34;
	Y4052_gen_type [85] = Y4052_pgtype35;
	Y4052_gen_type [86] = Y4052_pgtype36;
	Y4052_gen_type [87] = Y4052_pgtype37;
	Y4052_gen_type [88] = Y4052_pgtype38;
	Y4052_gen_type [89] = Y4052_pgtype39;
	Y4052_gen_type [90] = Y4052_pgtype40;
	Y4052_gen_type [91] = Y4052_pgtype41;
	Y4052_gen_type [92] = Y4052_pgtype42;
	Y4052_gen_type [93] = Y4052_pgtype43;
	Y4052_gen_type [94] = Y4052_pgtype44;
	Y4052_gen_type [95] = Y4052_pgtype45;
	Y4052_gen_type [147] = Y4052_pgtype46;
	Y4052_gen_type [148] = Y4052_pgtype47;
	Y4052_gen_type [149] = Y4052_pgtype48;
	Y4052_gen_type [150] = Y4052_pgtype49;
	Y4052_gen_type [151] = Y4052_pgtype50;
	Y4052_gen_type [152] = Y4052_pgtype51;
	Y4052_gen_type [153] = Y4052_pgtype52;
	Y4052_gen_type [154] = Y4052_pgtype53;
	Y4052_gen_type [155] = Y4052_pgtype54;
	Y4052_gen_type [156] = Y4052_pgtype55;
	Y4052_gen_type [157] = Y4052_pgtype56;
	Y4052_gen_type [158] = Y4052_pgtype57;
	Y4052_gen_type [159] = Y4052_pgtype58;
	Y4052_gen_type [160] = Y4052_pgtype59;
	Y4052_gen_type [161] = Y4052_pgtype60;
	Y4052_gen_type [162] = Y4052_pgtype61;
	Y4052_gen_type [163] = Y4052_pgtype62;
	Y4052_gen_type [164] = Y4052_pgtype63;
	Y4052_gen_type [165] = Y4052_pgtype64;
	Y4052_gen_type [166] = Y4052_pgtype65;
	Y4052_gen_type [167] = Y4052_pgtype66;
	Y4052_gen_type [168] = Y4052_pgtype67;
	Y4052_gen_type [169] = Y4052_pgtype68;
	Y4052_gen_type [170] = Y4052_pgtype69;
	Y4052_gen_type [171] = Y4052_pgtype70;
	Y4052_gen_type [172] = Y4052_pgtype71;
	Y4052_gen_type [173] = Y4052_pgtype72;
	Y4052_gen_type [174] = Y4052_pgtype73;
	Y4052_gen_type [175] = Y4052_pgtype74;
	Y4052_gen_type [176] = Y4052_pgtype75;
	Y4052_gen_type [177] = Y4052_pgtype76;
	Y4052_gen_type [178] = Y4052_pgtype77;
	Y4052_gen_type [179] = Y4052_pgtype78;
	Y4052_gen_type [180] = Y4052_pgtype79;
	Y4052_gen_type [181] = Y4052_pgtype80;
	Y4052_gen_type [182] = Y4052_pgtype81;
	Y4052_gen_type [183] = Y4052_pgtype82;
	Y4052_gen_type [184] = Y4052_pgtype83;
	Y4052_gen_type [185] = Y4052_pgtype84;
	Y4052_gen_type [186] = Y4052_pgtype85;
	Y4052_gen_type [187] = Y4052_pgtype86;
	Y4052_gen_type [188] = Y4052_pgtype87;
	Y4052_gen_type [189] = Y4052_pgtype88;
	Y4052_gen_type [190] = Y4052_pgtype89;
	Y4052_gen_type [191] = Y4052_pgtype90;
	Y4052_gen_type [192] = Y4052_pgtype91;
	Y4052_gen_type [193] = Y4052_pgtype92;
	Y4052_gen_type [194] = Y4052_pgtype93;
	Y4052_gen_type [195] = Y4052_pgtype94;
	Y4052_gen_type [196] = Y4052_pgtype95;
	Y4052_gen_type [197] = Y4052_pgtype96;
	Y4052_gen_type [198] = Y4052_pgtype97;
	Y4052_gen_type [199] = Y4052_pgtype98;
	Y4052_gen_type [200] = Y4052_pgtype99;
	Y4052_gen_type [201] = Y4052_pgtype100;
	Y4052_gen_type [203] = Y4052_pgtype101;
	Y4052_gen_type [215] = Y4052_pgtype102;
	Y4052_gen_type [216] = Y4052_pgtype103;
	Y4052_gen_type [217] = Y4052_pgtype104;
	Y4052_gen_type [218] = Y4052_pgtype105;
	Y4052_gen_type [219] = Y4052_pgtype106;
	Y4052_gen_type [220] = Y4052_pgtype107;
	Y4052_gen_type [221] = Y4052_pgtype108;
	Y4052_gen_type [222] = Y4052_pgtype109;
	Y4052_gen_type [223] = Y4052_pgtype110;
	Y4052_gen_type [224] = Y4052_pgtype111;
	Y4052_gen_type [225] = Y4052_pgtype112;
	Y4052_gen_type [226] = Y4052_pgtype113;
	Y4052_gen_type [227] = Y4052_pgtype114;
	Y4052_gen_type [228] = Y4052_pgtype115;
	Y4052_gen_type [229] = Y4052_pgtype116;
	Y4052_gen_type [230] = Y4052_pgtype117;
	Y4052_gen_type [231] = Y4052_pgtype118;
	Y4052_gen_type [232] = Y4052_pgtype119;
	Y4052_gen_type [233] = Y4052_pgtype120;
	Y4052_gen_type [234] = Y4052_pgtype121;
	Y4052_gen_type [235] = Y4052_pgtype122;
	Y4052_gen_type [236] = Y4052_pgtype123;
	Y4052_gen_type [237] = Y4052_pgtype124;
	Y4052_gen_type [238] = Y4052_pgtype125;
	Y4052_gen_type [239] = Y4052_pgtype126;
	Y4052_gen_type [240] = Y4052_pgtype127;
	Y4052_gen_type [241] = Y4052_pgtype128;
	Y4052_gen_type [242] = Y4052_pgtype129;
	Y4052_gen_type [243] = Y4052_pgtype130;
	Y4052_gen_type [244] = Y4052_pgtype131;
	Y4052_gen_type [245] = Y4052_pgtype132;
	Y4052_gen_type [246] = Y4052_pgtype133;
	Y4052_gen_type [247] = Y4052_pgtype134;
	Y4052_gen_type [248] = Y4052_pgtype135;
	Y4052_gen_type [249] = Y4052_pgtype136;
	Y4052_gen_type [250] = Y4052_pgtype137;
	Y4052_gen_type [251] = Y4052_pgtype138;
	Y4052_gen_type [252] = Y4052_pgtype139;
	Y4052_gen_type [253] = Y4052_pgtype140;
	Y4052_gen_type [254] = Y4052_pgtype141;
	Y4052_gen_type [255] = Y4052_pgtype142;
	Y4052_gen_type [256] = Y4052_pgtype143;
	Y4052_gen_type [655] = Y4052_pgtype144;
	Y4052_gen_type [703] = Y4052_pgtype145;
	{long i; for (i = 232; i < 253; i++) Y4052[i] = 939;};
	Y4052[257] = 990;
	Y4052[340] = 868;
	{long i; for (i = 453; i < 456; i++) Y4052[i] = 898;};
	{long i; for (i = 659; i < 665; i++) Y4052[i] = 1026;};
	Y4052[694] = 953;
	Y4052[704] = 1063;
	Y4052[705] = 1064;
	{long i; for (i = 706; i < 710; i++) Y4052[i] = 1077;};
	{long i; for (i = 710; i < 713; i++) Y4052[i] = 1062;};
	{long i; for (i = 713; i < 716; i++) Y4052[i] = 1068;};
	Y4052[896] = 898;
}

char *(*R4056[520])();
void R4056_init () {
	R4056[0] = (char *(*)()) F565_4535;
	R4056[1] = (char *(*)()) F566_4535_4056_4;
	R4056[2] = (char *(*)()) F567_4535_4056_4;
	R4056[3] = (char *(*)()) F565_4535;
	R4056[4] = (char *(*)()) F567_4535_4056_4;
	R4056[5] = (char *(*)()) F566_4535_4056_4;
	R4056[6] = (char *(*)()) F565_4535;
	R4056[20] = (char *(*)()) F585_4793;
	R4056[21] = (char *(*)()) F586_4793_4056_4;
	R4056[22] = (char *(*)()) F587_4793_4056_4;
	R4056[23] = (char *(*)()) F588_4793_4056_4;
	R4056[24] = (char *(*)()) F589_4793_4056_4;
	R4056[25] = (char *(*)()) F590_4793_4056_4;
	R4056[26] = (char *(*)()) F591_4793_4056_4;
	R4056[27] = (char *(*)()) F592_4793_4056_4;
	R4056[28] = (char *(*)()) F593_4793_4056_4;
	R4056[29] = (char *(*)()) F594_4793_4056_4;
	R4056[30] = (char *(*)()) F595_4793_4056_4;
	R4056[31] = (char *(*)()) F596_4793_4056_4;
	{long i; for (i = 37; i < 40; i++) R4056[i] = (char *(*)()) F600_4837;}
	{long i; for (i = 46; i < 49; i++) R4056[i] = (char *(*)()) F600_4837;}
	R4056[50] = (char *(*)()) F600_4837;
	R4056[53] = (char *(*)()) F600_4837;
	{long i; for (i = 55; i < 58; i++) R4056[i] = (char *(*)()) F600_4837;}
	R4056[60] = (char *(*)()) F600_4837;
	R4056[61] = (char *(*)()) F601_4837_4056_4;
	R4056[62] = (char *(*)()) F600_4837;
	{long i; for (i = 468; i < 470; i++) R4056[i] = (char *(*)()) F1025_8639;}
	R4056[510] = (char *(*)()) F1025_8639;
	R4056[519] = (char *(*)()) F1025_8639;
}
static void F566_4535_4056_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F566_4535(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F567_4535_4056_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F567_4535(Current, *(EIF_BOOLEAN *)arg1);
}
static void F586_4793_4056_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F586_4793(Current, *(EIF_NATURAL_32 *)arg1);
}
static void F587_4793_4056_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F587_4793(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F588_4793_4056_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F588_4793(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F589_4793_4056_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F589_4793(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F590_4793_4056_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F590_4793(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F591_4793_4056_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F591_4793(Current, *(EIF_POINTER *)arg1);
}
static void F592_4793_4056_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F592_4793(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F593_4793_4056_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F593_4793(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F594_4793_4056_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F594_4793(Current, *(EIF_BOOLEAN *)arg1);
}
static void F595_4793_4056_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F595_4793(Current, *(EIF_REAL_32 *)arg1);
}
static void F596_4793_4056_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F596_4793(Current, *(EIF_REAL_64 *)arg1);
}
static void F601_4837_4056_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F601_4837(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R4057[520])();
void R4057_init () {
	R4057[0] = (char *(*)()) F565_4538;
	R4057[1] = (char *(*)()) F566_4538;
	R4057[2] = (char *(*)()) F567_4538;
	R4057[3] = (char *(*)()) F568_4556;
	R4057[4] = (char *(*)()) F569_4556;
	R4057[5] = (char *(*)()) F570_4556;
	R4057[6] = (char *(*)()) F565_4539;
	R4057[20] = (char *(*)()) F585_4803;
	R4057[21] = (char *(*)()) F586_4803;
	R4057[22] = (char *(*)()) F587_4803;
	R4057[23] = (char *(*)()) F588_4803;
	R4057[24] = (char *(*)()) F589_4803;
	R4057[25] = (char *(*)()) F590_4803;
	R4057[26] = (char *(*)()) F591_4803;
	R4057[27] = (char *(*)()) F592_4803;
	R4057[28] = (char *(*)()) F593_4803;
	R4057[29] = (char *(*)()) F594_4803;
	R4057[30] = (char *(*)()) F595_4803;
	R4057[31] = (char *(*)()) F596_4803;
	{long i; for (i = 37; i < 40; i++) R4057[i] = (char *(*)()) F600_4838;}
	{long i; for (i = 46; i < 49; i++) R4057[i] = (char *(*)()) F600_4838;}
	R4057[50] = (char *(*)()) F600_4838;
	R4057[53] = (char *(*)()) F600_4838;
	{long i; for (i = 55; i < 58; i++) R4057[i] = (char *(*)()) F600_4838;}
	R4057[60] = (char *(*)()) F600_4838;
	R4057[61] = (char *(*)()) F601_4838;
	R4057[62] = (char *(*)()) F600_4838;
	{long i; for (i = 468; i < 470; i++) R4057[i] = (char *(*)()) F1025_8630;}
	R4057[510] = (char *(*)()) F1025_8630;
	R4057[519] = (char *(*)()) F1025_8630;
}

char *(*R4058[520])();
void R4058_init () {
	R4058[0] = (char *(*)()) F565_4511;
	R4058[1] = (char *(*)()) F566_4511;
	R4058[2] = (char *(*)()) F567_4511;
	R4058[3] = (char *(*)()) F565_4511;
	R4058[4] = (char *(*)()) F567_4511;
	R4058[5] = (char *(*)()) F566_4511;
	R4058[6] = (char *(*)()) F565_4511;
	R4058[20] = (char *(*)()) F585_4760;
	R4058[21] = (char *(*)()) F586_4760;
	R4058[22] = (char *(*)()) F587_4760;
	R4058[23] = (char *(*)()) F588_4760;
	R4058[24] = (char *(*)()) F589_4760;
	R4058[25] = (char *(*)()) F590_4760;
	R4058[26] = (char *(*)()) F591_4760;
	R4058[27] = (char *(*)()) F592_4760;
	R4058[28] = (char *(*)()) F593_4760;
	R4058[29] = (char *(*)()) F594_4760;
	R4058[30] = (char *(*)()) F595_4760;
	R4058[31] = (char *(*)()) F596_4760;
	{long i; for (i = 37; i < 40; i++) R4058[i] = (char *(*)()) F585_4760;}
	{long i; for (i = 46; i < 49; i++) R4058[i] = (char *(*)()) F585_4760;}
	R4058[50] = (char *(*)()) F585_4760;
	R4058[53] = (char *(*)()) F585_4760;
	{long i; for (i = 55; i < 58; i++) R4058[i] = (char *(*)()) F585_4760;}
	R4058[60] = (char *(*)()) F585_4760;
	R4058[61] = (char *(*)()) F589_4760;
	R4058[62] = (char *(*)()) F585_4760;
	{long i; for (i = 468; i < 470; i++) R4058[i] = (char *(*)()) F1025_8604;}
	R4058[510] = (char *(*)()) F1025_8604;
	R4058[519] = (char *(*)()) F1025_8604;
}

static EIF_TYPE_INDEX Y4058_pgtype0[] = {201,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype1[] = {202,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype2[] = {203,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype3[] = {201,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype4[] = {203,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype5[] = {202,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype6[] = {201,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype7[] = {200,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype8[] = {200,1026,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype9[] = {200,1026,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype10[] = {200,1026,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype11[] = {200,1026,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype12[] = {200,1026,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype13[] = {200,1026,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype14[] = {200,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype15[] = {200,1063,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype16[] = {200,1064,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype17[] = {200,1077,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype18[] = {200,1077,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype19[] = {200,1077,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype20[] = {200,1077,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype21[] = {200,1062,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype22[] = {200,1062,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype23[] = {200,1062,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype24[] = {200,1068,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype25[] = {200,1068,0xFFFF};
static EIF_TYPE_INDEX Y4058_pgtype26[] = {200,1068,0xFFFF};
EIF_TYPE_INDEX *Y4058_gen_type [704];
EIF_TYPE_INDEX Y4058 [704];
void Y4058_init (void)
{
	egc_routines_types [4058] = Y4058;
	egc_routines_gen_types [4058] = Y4058_gen_type;
	egc_routines_offset [4058] = 381;
	Y4058_gen_type [183] = Y4058_pgtype0;
	Y4058_gen_type [184] = Y4058_pgtype1;
	Y4058_gen_type [185] = Y4058_pgtype2;
	Y4058_gen_type [186] = Y4058_pgtype3;
	Y4058_gen_type [187] = Y4058_pgtype4;
	Y4058_gen_type [188] = Y4058_pgtype5;
	Y4058_gen_type [189] = Y4058_pgtype6;
	Y4058_gen_type [643] = Y4058_pgtype7;
	Y4058_gen_type [647] = Y4058_pgtype8;
	Y4058_gen_type [648] = Y4058_pgtype9;
	Y4058_gen_type [649] = Y4058_pgtype10;
	Y4058_gen_type [650] = Y4058_pgtype11;
	Y4058_gen_type [651] = Y4058_pgtype12;
	Y4058_gen_type [652] = Y4058_pgtype13;
	Y4058_gen_type [691] = Y4058_pgtype14;
	Y4058_gen_type [692] = Y4058_pgtype15;
	Y4058_gen_type [693] = Y4058_pgtype16;
	Y4058_gen_type [694] = Y4058_pgtype17;
	Y4058_gen_type [695] = Y4058_pgtype18;
	Y4058_gen_type [696] = Y4058_pgtype19;
	Y4058_gen_type [697] = Y4058_pgtype20;
	Y4058_gen_type [698] = Y4058_pgtype21;
	Y4058_gen_type [699] = Y4058_pgtype22;
	Y4058_gen_type [700] = Y4058_pgtype23;
	Y4058_gen_type [701] = Y4058_pgtype24;
	Y4058_gen_type [702] = Y4058_pgtype25;
	Y4058_gen_type [703] = Y4058_pgtype26;
	{long i; for (i = 0; i < 12; i++) Y4058[i] = 199;};
	{long i; for (i = 135; i < 183; i++) Y4058[i] = 199;};
	Y4058[183] = 201;
	Y4058[184] = 202;
	Y4058[185] = 203;
	Y4058[186] = 201;
	Y4058[187] = 203;
	Y4058[188] = 202;
	Y4058[189] = 201;
	{long i; for (i = 203; i < 246; i++) Y4058[i] = 205;};
	Y4058[643] = 200;
	{long i; for (i = 647; i < 653; i++) Y4058[i] = 200;};
	Y4058[682] = 205;
	{long i; for (i = 691; i < 704; i++) Y4058[i] = 200;};
}

char *(*R4060[520])();
void R4060_init () {
	R4060[0] = (char *(*)()) F565_4530;
	R4060[1] = (char *(*)()) F566_4530;
	R4060[2] = (char *(*)()) F567_4530;
	R4060[3] = (char *(*)()) F565_4530;
	R4060[4] = (char *(*)()) F567_4530;
	R4060[5] = (char *(*)()) F566_4530;
	R4060[6] = (char *(*)()) F565_4530;
	R4060[20] = (char *(*)()) F585_4785;
	R4060[21] = (char *(*)()) F586_4785;
	R4060[22] = (char *(*)()) F587_4785;
	R4060[23] = (char *(*)()) F588_4785;
	R4060[24] = (char *(*)()) F589_4785;
	R4060[25] = (char *(*)()) F590_4785;
	R4060[26] = (char *(*)()) F591_4785;
	R4060[27] = (char *(*)()) F592_4785;
	R4060[28] = (char *(*)()) F593_4785;
	R4060[29] = (char *(*)()) F594_4785;
	R4060[30] = (char *(*)()) F595_4785;
	R4060[31] = (char *(*)()) F596_4785;
	{long i; for (i = 37; i < 40; i++) R4060[i] = (char *(*)()) F585_4785;}
	{long i; for (i = 46; i < 49; i++) R4060[i] = (char *(*)()) F585_4785;}
	R4060[50] = (char *(*)()) F585_4785;
	R4060[53] = (char *(*)()) F585_4785;
	{long i; for (i = 55; i < 58; i++) R4060[i] = (char *(*)()) F585_4785;}
	R4060[60] = (char *(*)()) F585_4785;
	R4060[61] = (char *(*)()) F589_4785;
	R4060[62] = (char *(*)()) F585_4785;
	{long i; for (i = 468; i < 470; i++) R4060[i] = (char *(*)()) F1025_8616;}
	R4060[510] = (char *(*)()) F1025_8616;
	R4060[519] = (char *(*)()) F1025_8616;
}

char *(*R4064[763])();
void R4064_init () {
	R4064[0] = (char *(*)()) F504_4387;
	R4064[1] = (char *(*)()) F505_4387;
	R4064[2] = (char *(*)()) F506_4387;
	R4064[3] = (char *(*)()) F507_4387;
	R4064[4] = (char *(*)()) F508_4387;
	R4064[5] = (char *(*)()) F509_4387;
	R4064[6] = (char *(*)()) F510_4387;
	R4064[7] = (char *(*)()) F511_4387;
	R4064[8] = (char *(*)()) F512_4387;
	R4064[9] = (char *(*)()) F513_4387;
	R4064[10] = (char *(*)()) F514_4387;
	R4064[11] = (char *(*)()) F515_4387;
	R4064[61] = (char *(*)()) F565_4514;
	R4064[62] = (char *(*)()) F566_4514;
	R4064[63] = (char *(*)()) F567_4514;
	R4064[64] = (char *(*)()) F565_4514;
	R4064[65] = (char *(*)()) F567_4514;
	R4064[66] = (char *(*)()) F566_4514;
	R4064[67] = (char *(*)()) F565_4514;
	R4064[70] = (char *(*)()) F574_4636;
	R4064[71] = (char *(*)()) F575_4636;
	R4064[72] = (char *(*)()) F576_4636;
	R4064[73] = (char *(*)()) F577_4636;
	R4064[74] = (char *(*)()) F578_4636;
	R4064[75] = (char *(*)()) F579_4636;
	R4064[76] = (char *(*)()) F580_4636;
	R4064[77] = (char *(*)()) F574_4636;
	R4064[78] = (char *(*)()) F579_4636;
	R4064[79] = (char *(*)()) F575_4636;
	R4064[80] = (char *(*)()) F574_4636;
	R4064[81] = (char *(*)()) F585_4770;
	R4064[82] = (char *(*)()) F586_4770;
	R4064[83] = (char *(*)()) F587_4770;
	R4064[84] = (char *(*)()) F588_4770;
	R4064[85] = (char *(*)()) F589_4770;
	R4064[86] = (char *(*)()) F590_4770;
	R4064[87] = (char *(*)()) F591_4770;
	R4064[88] = (char *(*)()) F592_4770;
	R4064[89] = (char *(*)()) F593_4770;
	R4064[90] = (char *(*)()) F594_4770;
	R4064[91] = (char *(*)()) F595_4770;
	R4064[92] = (char *(*)()) F596_4770;
	{long i; for (i = 98; i < 101; i++) R4064[i] = (char *(*)()) F585_4770;}
	{long i; for (i = 107; i < 110; i++) R4064[i] = (char *(*)()) F585_4770;}
	R4064[111] = (char *(*)()) F585_4770;
	R4064[114] = (char *(*)()) F585_4770;
	{long i; for (i = 116; i < 119; i++) R4064[i] = (char *(*)()) F585_4770;}
	R4064[121] = (char *(*)()) F585_4770;
	R4064[122] = (char *(*)()) F589_4770;
	R4064[123] = (char *(*)()) F585_4770;
	{long i; for (i = 320; i < 322; i++) R4064[i] = (char *(*)()) F823_5663;}
	R4064[446] = (char *(*)()) F948_7604;
	R4064[450] = (char *(*)()) F952_7769;
	{long i; for (i = 529; i < 531; i++) R4064[i] = (char *(*)()) F1025_8609;}
	R4064[571] = (char *(*)()) F1025_8609;
	R4064[580] = (char *(*)()) F1025_8609;
	R4064[762] = (char *(*)()) F1266_12592;
}

char *(*R4065[451])();
void R4065_init () {
	R4065[0] = (char *(*)()) F504_4388;
	R4065[1] = (char *(*)()) F505_4388;
	R4065[2] = (char *(*)()) F506_4388;
	R4065[3] = (char *(*)()) F507_4388;
	R4065[4] = (char *(*)()) F508_4388;
	R4065[5] = (char *(*)()) F509_4388;
	R4065[6] = (char *(*)()) F510_4388;
	R4065[7] = (char *(*)()) F511_4388;
	R4065[8] = (char *(*)()) F512_4388;
	R4065[9] = (char *(*)()) F513_4388;
	R4065[10] = (char *(*)()) F514_4388;
	R4065[11] = (char *(*)()) F515_4388;
	R4065[81] = (char *(*)()) F585_4771;
	R4065[82] = (char *(*)()) F586_4771;
	R4065[83] = (char *(*)()) F587_4771;
	R4065[84] = (char *(*)()) F588_4771;
	R4065[85] = (char *(*)()) F589_4771;
	R4065[86] = (char *(*)()) F590_4771;
	R4065[87] = (char *(*)()) F591_4771;
	R4065[88] = (char *(*)()) F592_4771;
	R4065[89] = (char *(*)()) F593_4771;
	R4065[90] = (char *(*)()) F594_4771;
	R4065[91] = (char *(*)()) F595_4771;
	R4065[92] = (char *(*)()) F596_4771;
	{long i; for (i = 98; i < 101; i++) R4065[i] = (char *(*)()) F585_4771;}
	{long i; for (i = 107; i < 110; i++) R4065[i] = (char *(*)()) F585_4771;}
	R4065[111] = (char *(*)()) F585_4771;
	R4065[114] = (char *(*)()) F585_4771;
	{long i; for (i = 116; i < 119; i++) R4065[i] = (char *(*)()) F585_4771;}
	R4065[121] = (char *(*)()) F585_4771;
	R4065[122] = (char *(*)()) F589_4771;
	R4065[123] = (char *(*)()) F585_4771;
	R4065[446] = (char *(*)()) F948_7603;
	R4065[450] = (char *(*)()) F952_7768;
}


#ifdef __cplusplus
}
#endif
