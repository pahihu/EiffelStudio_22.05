#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O2679[1143];
void O2679_init () {
	O2679[0] =  + _REFACS_12_;
	{long i; for (i = 1045; i < 1047; i++) O2679[i] =  + _REFACS_21_;}
	{long i; for (i = 1047; i < 1050; i++) O2679[i] =  + _REFACS_22_;}
	O2679[1050] =  + _REFACS_23_;
	{long i; for (i = 1051; i < 1053; i++) O2679[i] =  + _REFACS_22_;}
	O2679[1053] =  + _REFACS_23_;
	O2679[1054] =  + _REFACS_22_;
	{long i; for (i = 1055; i < 1065; i++) O2679[i] =  + _REFACS_23_;}
	{long i; for (i = 1065; i < 1067; i++) O2679[i] =  + _REFACS_27_;}
	{long i; for (i = 1067; i < 1069; i++) O2679[i] =  + _REFACS_30_;}
	{long i; for (i = 1069; i < 1073; i++) O2679[i] =  + _REFACS_23_;}
	{long i; for (i = 1073; i < 1075; i++) O2679[i] =  + _REFACS_27_;}
	{long i; for (i = 1075; i < 1077; i++) O2679[i] =  + _REFACS_30_;}
	O2679[1077] =  + _REFACS_21_;
	O2679[1078] =  + _REFACS_22_;
	O2679[1079] =  + _REFACS_23_;
	O2679[1080] =  + _REFACS_25_;
	O2679[1081] =  + _REFACS_21_;
	{long i; for (i = 1082; i < 1085; i++) O2679[i] =  + _REFACS_22_;}
	{long i; for (i = 1085; i < 1087; i++) O2679[i] =  + _REFACS_23_;}
	{long i; for (i = 1087; i < 1089; i++) O2679[i] =  + _REFACS_22_;}
	O2679[1089] =  + _REFACS_25_;
	O2679[1090] =  + _REFACS_23_;
	O2679[1091] =  + _REFACS_27_;
	O2679[1092] =  + _REFACS_21_;
	O2679[1093] =  + _REFACS_22_;
	O2679[1094] =  + _REFACS_23_;
	O2679[1095] =  + _REFACS_25_;
	O2679[1096] =  + _REFACS_21_;
	{long i; for (i = 1097; i < 1100; i++) O2679[i] =  + _REFACS_22_;}
	{long i; for (i = 1100; i < 1102; i++) O2679[i] =  + _REFACS_23_;}
	{long i; for (i = 1102; i < 1104; i++) O2679[i] =  + _REFACS_22_;}
	O2679[1104] =  + _REFACS_25_;
	O2679[1105] =  + _REFACS_23_;
	O2679[1106] =  + _REFACS_27_;
	{long i; for (i = 1136; i < 1138; i++) O2679[i] =  + _REFACS_22_;}
	{long i; for (i = 1141; i < 1143; i++) O2679[i] =  + _REFACS_22_;}
}

long O2682[1143];
void O2682_init () {
	O2682[0] =  + _REFACS_13_;
	{long i; for (i = 1045; i < 1047; i++) O2682[i] =  + _REFACS_22_;}
	{long i; for (i = 1047; i < 1050; i++) O2682[i] =  + _REFACS_23_;}
	O2682[1050] =  + _REFACS_24_;
	{long i; for (i = 1051; i < 1053; i++) O2682[i] =  + _REFACS_23_;}
	O2682[1053] =  + _REFACS_24_;
	O2682[1054] =  + _REFACS_23_;
	{long i; for (i = 1055; i < 1065; i++) O2682[i] =  + _REFACS_24_;}
	{long i; for (i = 1065; i < 1067; i++) O2682[i] =  + _REFACS_28_;}
	{long i; for (i = 1067; i < 1069; i++) O2682[i] =  + _REFACS_31_;}
	{long i; for (i = 1069; i < 1073; i++) O2682[i] =  + _REFACS_24_;}
	{long i; for (i = 1073; i < 1075; i++) O2682[i] =  + _REFACS_28_;}
	{long i; for (i = 1075; i < 1077; i++) O2682[i] =  + _REFACS_31_;}
	O2682[1077] =  + _REFACS_22_;
	O2682[1078] =  + _REFACS_23_;
	O2682[1079] =  + _REFACS_24_;
	O2682[1080] =  + _REFACS_26_;
	O2682[1081] =  + _REFACS_22_;
	{long i; for (i = 1082; i < 1085; i++) O2682[i] =  + _REFACS_23_;}
	{long i; for (i = 1085; i < 1087; i++) O2682[i] =  + _REFACS_24_;}
	{long i; for (i = 1087; i < 1089; i++) O2682[i] =  + _REFACS_23_;}
	O2682[1089] =  + _REFACS_26_;
	O2682[1090] =  + _REFACS_24_;
	O2682[1091] =  + _REFACS_28_;
	O2682[1092] =  + _REFACS_22_;
	O2682[1093] =  + _REFACS_23_;
	O2682[1094] =  + _REFACS_24_;
	O2682[1095] =  + _REFACS_26_;
	O2682[1096] =  + _REFACS_22_;
	{long i; for (i = 1097; i < 1100; i++) O2682[i] =  + _REFACS_23_;}
	{long i; for (i = 1100; i < 1102; i++) O2682[i] =  + _REFACS_24_;}
	{long i; for (i = 1102; i < 1104; i++) O2682[i] =  + _REFACS_23_;}
	O2682[1104] =  + _REFACS_26_;
	O2682[1105] =  + _REFACS_24_;
	O2682[1106] =  + _REFACS_28_;
	{long i; for (i = 1136; i < 1138; i++) O2682[i] =  + _REFACS_23_;}
	{long i; for (i = 1141; i < 1143; i++) O2682[i] =  + _REFACS_23_;}
}

long O2871[4];
void O2871_init () {
	O2871[0] = + _CHROFF_2_0_;
	O2871[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O2871[i] = + _CHROFF_2_0_;}
}

long O2872[4];
void O2872_init () {
	O2872[0] = + _CHROFF_2_1_;
	O2872[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O2872[i] = + _CHROFF_2_1_;}
}

long O2940[135];
void O2940_init () {
	O2940[0] = 0;
	{long i; for (i = 1; i < 3; i++) O2940[i] = + _LNGOFF_0_0_0_0_;}
	O2940[3] = + _I64OFF_0_0_0_0_0_0_0_;
	O2940[4] = + _CHROFF_0_0_;
	O2940[5] = 0;
	O2940[6] = + _LNGOFF_1_0_0_0_;
	O2940[7] = + _CHROFF_1_0_;
	{long i; for (i = 133; i < 135; i++) O2940[i] = 0;}
}

long O2944[3];
void O2944_init () {
	O2944[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 3; i++) O2944[i] = 0;}
}

static EIF_TYPE_INDEX Y3696_pgtype0[] = {632,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype1[] = {633,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype2[] = {634,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype3[] = {635,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype4[] = {636,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype5[] = {637,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype6[] = {638,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype7[] = {639,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype8[] = {640,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype9[] = {641,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype10[] = {642,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype11[] = {643,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype12[] = {637,886,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype13[] = {637,886,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype14[] = {632,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype15[] = {633,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype16[] = {634,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype17[] = {635,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype18[] = {636,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype19[] = {637,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype20[] = {638,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype21[] = {639,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype22[] = {640,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype23[] = {641,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype24[] = {642,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype25[] = {643,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype26[] = {637,886,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype27[] = {632,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype28[] = {633,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype29[] = {634,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype30[] = {635,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype31[] = {636,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype32[] = {637,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype33[] = {638,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype34[] = {639,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype35[] = {640,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype36[] = {641,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype37[] = {642,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype38[] = {643,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype39[] = {632,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype40[] = {641,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype41[] = {636,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype42[] = {632,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype43[] = {636,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype44[] = {632,939,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype45[] = {632,939,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype46[] = {632,939,0xFFF9,1,865,0,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype47[] = {632,939,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype48[] = {632,939,0xFFF9,1,865,868,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype49[] = {632,939,0xFFF9,1,865,1063,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype50[] = {632,939,0xFFF9,1,865,868,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype51[] = {632,939,0xFFF9,1,865,1026,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype52[] = {632,939,0xFFF9,1,865,830,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype53[] = {632,939,0xFFF9,1,865,1068,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype54[] = {632,939,0xFFF9,1,865,999,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype55[] = {632,939,0xFFF9,1,865,1266,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype56[] = {632,939,0xFFF9,5,865,880,868,868,868,868,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype57[] = {632,939,0xFFF9,4,865,868,868,868,868,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype58[] = {632,939,0xFFF9,1,865,868,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype59[] = {632,939,0xFFF9,1,865,953,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype60[] = {632,939,0xFFF9,7,865,868,868,892,892,892,868,868,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype61[] = {632,939,0xFFF9,2,865,868,868,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype62[] = {632,939,0xFFF9,3,865,868,868,830,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype63[] = {632,939,0xFFF9,8,865,868,868,868,892,892,892,868,868,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype64[] = {632,939,0xFFF9,0,865,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype65[] = {632,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype66[] = {636,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype67[] = {632,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype68[] = {636,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype69[] = {632,990,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype70[] = {635,898,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype71[] = {635,898,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype72[] = {634,895,0xFFFF};
static EIF_TYPE_INDEX Y3696_pgtype73[] = {632,953,0xFFFF};
EIF_TYPE_INDEX *Y3696_gen_type [846];
EIF_TYPE_INDEX Y3696 [846];
void Y3696_init (void)
{
	egc_routines_types [3696] = Y3696;
	egc_routines_gen_types [3696] = Y3696_gen_type;
	egc_routines_offset [3696] = 218;
	Y3696_gen_type [0] = Y3696_pgtype0;
	Y3696_gen_type [1] = Y3696_pgtype1;
	Y3696_gen_type [2] = Y3696_pgtype2;
	Y3696_gen_type [3] = Y3696_pgtype3;
	Y3696_gen_type [4] = Y3696_pgtype4;
	Y3696_gen_type [5] = Y3696_pgtype5;
	Y3696_gen_type [6] = Y3696_pgtype6;
	Y3696_gen_type [7] = Y3696_pgtype7;
	Y3696_gen_type [8] = Y3696_pgtype8;
	Y3696_gen_type [9] = Y3696_pgtype9;
	Y3696_gen_type [10] = Y3696_pgtype10;
	Y3696_gen_type [11] = Y3696_pgtype11;
	Y3696_gen_type [17] = Y3696_pgtype12;
	Y3696_gen_type [18] = Y3696_pgtype13;
	Y3696_gen_type [285] = Y3696_pgtype14;
	Y3696_gen_type [286] = Y3696_pgtype15;
	Y3696_gen_type [287] = Y3696_pgtype16;
	Y3696_gen_type [288] = Y3696_pgtype17;
	Y3696_gen_type [289] = Y3696_pgtype18;
	Y3696_gen_type [290] = Y3696_pgtype19;
	Y3696_gen_type [291] = Y3696_pgtype20;
	Y3696_gen_type [292] = Y3696_pgtype21;
	Y3696_gen_type [293] = Y3696_pgtype22;
	Y3696_gen_type [294] = Y3696_pgtype23;
	Y3696_gen_type [295] = Y3696_pgtype24;
	Y3696_gen_type [296] = Y3696_pgtype25;
	Y3696_gen_type [297] = Y3696_pgtype26;
	Y3696_gen_type [366] = Y3696_pgtype27;
	Y3696_gen_type [367] = Y3696_pgtype28;
	Y3696_gen_type [368] = Y3696_pgtype29;
	Y3696_gen_type [369] = Y3696_pgtype30;
	Y3696_gen_type [370] = Y3696_pgtype31;
	Y3696_gen_type [371] = Y3696_pgtype32;
	Y3696_gen_type [372] = Y3696_pgtype33;
	Y3696_gen_type [373] = Y3696_pgtype34;
	Y3696_gen_type [374] = Y3696_pgtype35;
	Y3696_gen_type [375] = Y3696_pgtype36;
	Y3696_gen_type [376] = Y3696_pgtype37;
	Y3696_gen_type [377] = Y3696_pgtype38;
	Y3696_gen_type [378] = Y3696_pgtype39;
	Y3696_gen_type [379] = Y3696_pgtype40;
	Y3696_gen_type [380] = Y3696_pgtype41;
	Y3696_gen_type [381] = Y3696_pgtype42;
	Y3696_gen_type [382] = Y3696_pgtype43;
	Y3696_gen_type [383] = Y3696_pgtype44;
	Y3696_gen_type [384] = Y3696_pgtype45;
	Y3696_gen_type [385] = Y3696_pgtype46;
	Y3696_gen_type [386] = Y3696_pgtype47;
	Y3696_gen_type [387] = Y3696_pgtype48;
	Y3696_gen_type [388] = Y3696_pgtype49;
	Y3696_gen_type [389] = Y3696_pgtype50;
	Y3696_gen_type [390] = Y3696_pgtype51;
	Y3696_gen_type [391] = Y3696_pgtype52;
	Y3696_gen_type [392] = Y3696_pgtype53;
	Y3696_gen_type [393] = Y3696_pgtype54;
	Y3696_gen_type [394] = Y3696_pgtype55;
	Y3696_gen_type [395] = Y3696_pgtype56;
	Y3696_gen_type [396] = Y3696_pgtype57;
	Y3696_gen_type [397] = Y3696_pgtype58;
	Y3696_gen_type [398] = Y3696_pgtype59;
	Y3696_gen_type [399] = Y3696_pgtype60;
	Y3696_gen_type [400] = Y3696_pgtype61;
	Y3696_gen_type [401] = Y3696_pgtype62;
	Y3696_gen_type [402] = Y3696_pgtype63;
	Y3696_gen_type [403] = Y3696_pgtype64;
	Y3696_gen_type [404] = Y3696_pgtype65;
	Y3696_gen_type [405] = Y3696_pgtype66;
	Y3696_gen_type [406] = Y3696_pgtype67;
	Y3696_gen_type [407] = Y3696_pgtype68;
	Y3696_gen_type [408] = Y3696_pgtype69;
	Y3696_gen_type [731] = Y3696_pgtype70;
	Y3696_gen_type [732] = Y3696_pgtype71;
	Y3696_gen_type [735] = Y3696_pgtype72;
	Y3696_gen_type [845] = Y3696_pgtype73;
	Y3696[0] = 632;
	Y3696[1] = 633;
	Y3696[2] = 634;
	Y3696[3] = 635;
	Y3696[4] = 636;
	Y3696[5] = 637;
	Y3696[6] = 638;
	Y3696[7] = 639;
	Y3696[8] = 640;
	Y3696[9] = 641;
	Y3696[10] = 642;
	Y3696[11] = 643;
	{long i; for (i = 17; i < 19; i++) Y3696[i] = 637;};
	Y3696[285] = 632;
	Y3696[286] = 633;
	Y3696[287] = 634;
	Y3696[288] = 635;
	Y3696[289] = 636;
	Y3696[290] = 637;
	Y3696[291] = 638;
	Y3696[292] = 639;
	Y3696[293] = 640;
	Y3696[294] = 641;
	Y3696[295] = 642;
	Y3696[296] = 643;
	Y3696[297] = 637;
	Y3696[366] = 632;
	Y3696[367] = 633;
	Y3696[368] = 634;
	Y3696[369] = 635;
	Y3696[370] = 636;
	Y3696[371] = 637;
	Y3696[372] = 638;
	Y3696[373] = 639;
	Y3696[374] = 640;
	Y3696[375] = 641;
	Y3696[376] = 642;
	Y3696[377] = 643;
	Y3696[378] = 632;
	Y3696[379] = 641;
	Y3696[380] = 636;
	Y3696[381] = 632;
	Y3696[382] = 636;
	{long i; for (i = 383; i < 405; i++) Y3696[i] = 632;};
	Y3696[405] = 636;
	Y3696[406] = 632;
	Y3696[407] = 636;
	Y3696[408] = 632;
	{long i; for (i = 731; i < 733; i++) Y3696[i] = 635;};
	Y3696[735] = 634;
	Y3696[845] = 632;
}

long O3839[875];
void O3839_init () {
	O3839[0] = + _LNGOFF_0_0_0_0_;
	O3839[590] = + _LNGOFF_1_0_0_0_;
	O3839[864] = + _LNGOFF_1_1_0_0_;
	O3839[874] = + _LNGOFF_49_16_0_2_;
}

long O3909[1007];
void O3909_init () {
	{long i; for (i = 0; i < 12; i++) O3909[i] = + _CHROFF_0_0_;}
	O3909[12] = + _CHROFF_1_0_;
	{long i; for (i = 13; i < 15; i++) O3909[i] = + _CHROFF_4_0_;}
	{long i; for (i = 15; i < 201; i++) O3909[i] = + _CHROFF_0_0_;}
	O3909[201] = + _CHROFF_1_0_;
	{long i; for (i = 202; i < 218; i++) O3909[i] = + _CHROFF_0_0_;}
	{long i; for (i = 230; i < 243; i++) O3909[i] = + _CHROFF_0_0_;}
	{long i; for (i = 243; i < 256; i++) O3909[i] = + _CHROFF_1_0_;}
	O3909[256] = + _CHROFF_2_0_;
	{long i; for (i = 257; i < 305; i++) O3909[i] = + _CHROFF_0_0_;}
	{long i; for (i = 305; i < 312; i++) O3909[i] = + _CHROFF_2_0_;}
	O3909[313] = + _CHROFF_1_0_;
	O3909[314] = + _CHROFF_7_0_;
	O3909[315] = + _CHROFF_5_0_;
	O3909[316] = + _CHROFF_4_0_;
	O3909[317] = + _CHROFF_5_0_;
	O3909[318] = + _CHROFF_6_0_;
	O3909[319] = + _CHROFF_5_0_;
	O3909[320] = + _CHROFF_4_0_;
	O3909[321] = + _CHROFF_7_0_;
	{long i; for (i = 322; i < 324; i++) O3909[i] = + _CHROFF_5_0_;}
	O3909[324] = + _CHROFF_9_0_;
	{long i; for (i = 325; i < 342; i++) O3909[i] = + _CHROFF_1_0_;}
	{long i; for (i = 342; i < 344; i++) O3909[i] = + _CHROFF_9_0_;}
	O3909[344] = + _CHROFF_10_0_;
	{long i; for (i = 345; i < 363; i++) O3909[i] = + _CHROFF_9_0_;}
	{long i; for (i = 363; i < 365; i++) O3909[i] = + _CHROFF_3_0_;}
	{long i; for (i = 365; i < 368; i++) O3909[i] = + _CHROFF_5_0_;}
	O3909[449] = + _CHROFF_2_0_;
	O3909[450] = + _CHROFF_0_0_;
	O3909[563] = + _CHROFF_3_2_;
	O3909[564] = + _CHROFF_4_2_;
	O3909[565] = + _CHROFF_5_2_;
	{long i; for (i = 690; i < 692; i++) O3909[i] = + _CHROFF_1_0_;}
	O3909[694] = + _CHROFF_1_0_;
	O3909[765] = + _CHROFF_3_0_;
	{long i; for (i = 768; i < 782; i++) O3909[i] = + _CHROFF_6_0_;}
	O3909[782] = + _CHROFF_9_0_;
	O3909[783] = + _CHROFF_24_0_;
	O3909[784] = + _CHROFF_6_0_;
	O3909[785] = + _CHROFF_7_0_;
	{long i; for (i = 786; i < 789; i++) O3909[i] = + _CHROFF_14_0_;}
	O3909[804] = + _CHROFF_7_0_;
	O3909[813] = + _CHROFF_3_0_;
	{long i; for (i = 814; i < 816; i++) O3909[i] = + _CHROFF_5_0_;}
	O3909[816] = + _CHROFF_3_0_;
	O3909[817] = + _CHROFF_5_0_;
	{long i; for (i = 818; i < 820; i++) O3909[i] = + _CHROFF_6_0_;}
	{long i; for (i = 820; i < 823; i++) O3909[i] = + _CHROFF_5_0_;}
	O3909[823] = + _CHROFF_3_0_;
	O3909[824] = + _CHROFF_6_0_;
	O3909[825] = + _CHROFF_3_0_;
	O3909[1006] = + _CHROFF_5_2_;
}

static EIF_TYPE_INDEX Y3977_pgtype0[] = {272,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3977_pgtype1[] = {273,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y3977_gen_type [2];
EIF_TYPE_INDEX Y3977 [2];
void Y3977_init (void)
{
	egc_routines_types [3977] = Y3977;
	egc_routines_gen_types [3977] = Y3977_gen_type;
	egc_routines_offset [3977] = 272;
	Y3977_gen_type [0] = Y3977_pgtype0;
	Y3977_gen_type [1] = Y3977_pgtype1;
	Y3977[0] = 272;
	Y3977[1] = 273;
}

EIF_TYPE_INDEX *Y4224_gen_type [1];
EIF_TYPE_INDEX Y4224 [1];
void Y4224_init (void)
{
	egc_routines_types [4224] = Y4224;
	egc_routines_gen_types [4224] = Y4224_gen_type;
	egc_routines_offset [4224] = 572;
	Y4224[0] = 868;
}

long O4229[11];
void O4229_init () {
	O4229[0] = 0;
	O4229[1] = + _LNGOFF_5_3_0_0_;
	O4229[2] = + _LNGOFF_4_3_0_1_;
	O4229[3] = + _PTROFF_5_3_0_7_0_0_;
	O4229[4] = 0;
	O4229[5] = + _CHROFF_5_1_;
	O4229[6] = + _LNGOFF_4_3_0_0_;
	O4229[7] = 0;
	O4229[8] = + _CHROFF_5_1_;
	O4229[9] = + _LNGOFF_5_4_0_0_;
	O4229[10] = 0;
}

long O4238[11];
void O4238_init () {
	O4238[0] = + _LNGOFF_7_3_0_0_;
	O4238[1] = + _LNGOFF_5_3_0_1_;
	O4238[2] = + _LNGOFF_4_3_0_2_;
	O4238[3] = + _LNGOFF_5_3_0_0_;
	O4238[4] = + _LNGOFF_6_3_0_0_;
	O4238[5] = + _LNGOFF_5_5_0_0_;
	O4238[6] = + _LNGOFF_4_3_0_1_;
	O4238[7] = + _LNGOFF_7_4_0_0_;
	O4238[8] = + _LNGOFF_5_6_0_0_;
	O4238[9] = + _LNGOFF_5_4_0_1_;
	O4238[10] = + _LNGOFF_9_3_0_0_;
}

long O4265[11];
void O4265_init () {
	O4265[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 4; i++) O4265[i] = 0;}
	O4265[4] =  + _REFACS_1_;
	{long i; for (i = 5; i < 7; i++) O4265[i] = 0;}
	O4265[7] =  + _REFACS_1_;
	{long i; for (i = 8; i < 10; i++) O4265[i] = 0;}
	O4265[10] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y4265_pgtype0[] = {632,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4265_pgtype1[] = {636,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4265_pgtype2[] = {636,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4265_pgtype3[] = {638,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4265_pgtype4[] = {632,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4265_pgtype5[] = {641,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4265_pgtype6[] = {636,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4265_pgtype7[] = {632,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4265_pgtype8[] = {641,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4265_pgtype9[] = {636,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4265_pgtype10[] = {632,0,0xFFFF};
EIF_TYPE_INDEX *Y4265_gen_type [11];
EIF_TYPE_INDEX Y4265 [11];
void Y4265_init (void)
{
	egc_routines_types [4265] = Y4265;
	egc_routines_gen_types [4265] = Y4265_gen_type;
	egc_routines_offset [4265] = 573;
	Y4265_gen_type [0] = Y4265_pgtype0;
	Y4265_gen_type [1] = Y4265_pgtype1;
	Y4265_gen_type [2] = Y4265_pgtype2;
	Y4265_gen_type [3] = Y4265_pgtype3;
	Y4265_gen_type [4] = Y4265_pgtype4;
	Y4265_gen_type [5] = Y4265_pgtype5;
	Y4265_gen_type [6] = Y4265_pgtype6;
	Y4265_gen_type [7] = Y4265_pgtype7;
	Y4265_gen_type [8] = Y4265_pgtype8;
	Y4265_gen_type [9] = Y4265_pgtype9;
	Y4265_gen_type [10] = Y4265_pgtype10;
	Y4265[0] = 632;
	{long i; for (i = 1; i < 3; i++) Y4265[i] = 636;};
	Y4265[3] = 638;
	Y4265[4] = 632;
	Y4265[5] = 641;
	Y4265[6] = 636;
	Y4265[7] = 632;
	Y4265[8] = 641;
	Y4265[9] = 636;
	Y4265[10] = 632;
}

long O4266[11];
void O4266_init () {
	O4266[0] =  + _REFACS_2_;
	{long i; for (i = 1; i < 4; i++) O4266[i] =  + _REFACS_1_;}
	O4266[4] =  + _REFACS_2_;
	{long i; for (i = 5; i < 7; i++) O4266[i] =  + _REFACS_1_;}
	O4266[7] =  + _REFACS_2_;
	{long i; for (i = 8; i < 10; i++) O4266[i] =  + _REFACS_1_;}
	O4266[10] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y4266_pgtype0[] = {632,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4266_pgtype1[] = {632,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4266_pgtype2[] = {633,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4266_pgtype3[] = {632,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4266_pgtype4[] = {636,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4266_pgtype5[] = {632,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4266_pgtype6[] = {636,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y4266_pgtype7[] = {632,944,0xFFFF};
static EIF_TYPE_INDEX Y4266_pgtype8[] = {632,944,0xFFFF};
static EIF_TYPE_INDEX Y4266_pgtype9[] = {632,944,0xFFFF};
static EIF_TYPE_INDEX Y4266_pgtype10[] = {632,949,0xFFFF};
EIF_TYPE_INDEX *Y4266_gen_type [11];
EIF_TYPE_INDEX Y4266 [11];
void Y4266_init (void)
{
	egc_routines_types [4266] = Y4266;
	egc_routines_gen_types [4266] = Y4266_gen_type;
	egc_routines_offset [4266] = 573;
	Y4266_gen_type [0] = Y4266_pgtype0;
	Y4266_gen_type [1] = Y4266_pgtype1;
	Y4266_gen_type [2] = Y4266_pgtype2;
	Y4266_gen_type [3] = Y4266_pgtype3;
	Y4266_gen_type [4] = Y4266_pgtype4;
	Y4266_gen_type [5] = Y4266_pgtype5;
	Y4266_gen_type [6] = Y4266_pgtype6;
	Y4266_gen_type [7] = Y4266_pgtype7;
	Y4266_gen_type [8] = Y4266_pgtype8;
	Y4266_gen_type [9] = Y4266_pgtype9;
	Y4266_gen_type [10] = Y4266_pgtype10;
	{long i; for (i = 0; i < 2; i++) Y4266[i] = 632;};
	Y4266[2] = 633;
	Y4266[3] = 632;
	Y4266[4] = 636;
	Y4266[5] = 632;
	Y4266[6] = 636;
	{long i; for (i = 7; i < 11; i++) Y4266[i] = 632;};
}

long O4267[11];
void O4267_init () {
	O4267[0] =  + _REFACS_3_;
	{long i; for (i = 1; i < 4; i++) O4267[i] =  + _REFACS_2_;}
	O4267[4] =  + _REFACS_3_;
	{long i; for (i = 5; i < 7; i++) O4267[i] =  + _REFACS_2_;}
	O4267[7] =  + _REFACS_3_;
	{long i; for (i = 8; i < 10; i++) O4267[i] =  + _REFACS_2_;}
	O4267[10] =  + _REFACS_3_;
}

long O4268[11];
void O4268_init () {
	O4268[0] =  + _REFACS_4_;
	{long i; for (i = 1; i < 4; i++) O4268[i] =  + _REFACS_3_;}
	O4268[4] =  + _REFACS_4_;
	{long i; for (i = 5; i < 7; i++) O4268[i] =  + _REFACS_3_;}
	O4268[7] =  + _REFACS_4_;
	{long i; for (i = 8; i < 10; i++) O4268[i] =  + _REFACS_3_;}
	O4268[10] =  + _REFACS_4_;
}

long O4269[11];
void O4269_init () {
	O4269[0] = + _LNGOFF_7_3_0_1_;
	O4269[1] = + _LNGOFF_5_3_0_2_;
	O4269[2] = + _LNGOFF_4_3_0_3_;
	O4269[3] = + _LNGOFF_5_3_0_1_;
	O4269[4] = + _LNGOFF_6_3_0_1_;
	O4269[5] = + _LNGOFF_5_5_0_1_;
	O4269[6] = + _LNGOFF_4_3_0_2_;
	O4269[7] = + _LNGOFF_7_4_0_1_;
	O4269[8] = + _LNGOFF_5_6_0_1_;
	O4269[9] = + _LNGOFF_5_4_0_2_;
	O4269[10] = + _LNGOFF_9_3_0_1_;
}

long O4270[11];
void O4270_init () {
	O4270[0] = + _CHROFF_7_2_;
	O4270[1] = + _CHROFF_5_2_;
	O4270[2] = + _CHROFF_4_2_;
	O4270[3] = + _CHROFF_5_2_;
	O4270[4] = + _CHROFF_6_2_;
	O4270[5] = + _CHROFF_5_3_;
	O4270[6] = + _CHROFF_4_2_;
	O4270[7] = + _CHROFF_7_2_;
	O4270[8] = + _CHROFF_5_3_;
	O4270[9] = + _CHROFF_5_2_;
	O4270[10] = + _CHROFF_9_2_;
}

long O4271[11];
void O4271_init () {
	O4271[0] = + _LNGOFF_7_3_0_2_;
	O4271[1] = + _LNGOFF_5_3_0_3_;
	O4271[2] = + _LNGOFF_4_3_0_4_;
	O4271[3] = + _LNGOFF_5_3_0_2_;
	O4271[4] = + _LNGOFF_6_3_0_2_;
	O4271[5] = + _LNGOFF_5_5_0_2_;
	O4271[6] = + _LNGOFF_4_3_0_3_;
	O4271[7] = + _LNGOFF_7_4_0_2_;
	O4271[8] = + _LNGOFF_5_6_0_2_;
	O4271[9] = + _LNGOFF_5_4_0_3_;
	O4271[10] = + _LNGOFF_9_3_0_2_;
}

long O4274[11];
void O4274_init () {
	O4274[0] = + _LNGOFF_7_3_0_3_;
	O4274[1] = + _LNGOFF_5_3_0_4_;
	O4274[2] = + _LNGOFF_4_3_0_5_;
	O4274[3] = + _LNGOFF_5_3_0_3_;
	O4274[4] = + _LNGOFF_6_3_0_3_;
	O4274[5] = + _LNGOFF_5_5_0_3_;
	O4274[6] = + _LNGOFF_4_3_0_4_;
	O4274[7] = + _LNGOFF_7_4_0_3_;
	O4274[8] = + _LNGOFF_5_6_0_3_;
	O4274[9] = + _LNGOFF_5_4_0_4_;
	O4274[10] = + _LNGOFF_9_3_0_3_;
}

long O4275[11];
void O4275_init () {
	O4275[0] = + _LNGOFF_7_3_0_4_;
	O4275[1] = + _LNGOFF_5_3_0_5_;
	O4275[2] = + _LNGOFF_4_3_0_6_;
	O4275[3] = + _LNGOFF_5_3_0_4_;
	O4275[4] = + _LNGOFF_6_3_0_4_;
	O4275[5] = + _LNGOFF_5_5_0_4_;
	O4275[6] = + _LNGOFF_4_3_0_5_;
	O4275[7] = + _LNGOFF_7_4_0_4_;
	O4275[8] = + _LNGOFF_5_6_0_4_;
	O4275[9] = + _LNGOFF_5_4_0_5_;
	O4275[10] = + _LNGOFF_9_3_0_4_;
}

long O4279[11];
void O4279_init () {
	O4279[0] = + _LNGOFF_7_3_0_5_;
	O4279[1] = + _LNGOFF_5_3_0_6_;
	O4279[2] = + _LNGOFF_4_3_0_7_;
	O4279[3] = + _LNGOFF_5_3_0_5_;
	O4279[4] = + _LNGOFF_6_3_0_5_;
	O4279[5] = + _LNGOFF_5_5_0_5_;
	O4279[6] = + _LNGOFF_4_3_0_6_;
	O4279[7] = + _LNGOFF_7_4_0_5_;
	O4279[8] = + _LNGOFF_5_6_0_5_;
	O4279[9] = + _LNGOFF_5_4_0_6_;
	O4279[10] = + _LNGOFF_9_3_0_5_;
}

long O4280[11];
void O4280_init () {
	O4280[0] =  + _REFACS_5_;
	O4280[1] = + _LNGOFF_5_3_0_7_;
	O4280[2] = + _LNGOFF_4_3_0_8_;
	O4280[3] = + _PTROFF_5_3_0_7_0_1_;
	O4280[4] =  + _REFACS_5_;
	O4280[5] = + _CHROFF_5_4_;
	O4280[6] = + _LNGOFF_4_3_0_7_;
	O4280[7] =  + _REFACS_5_;
	O4280[8] = + _CHROFF_5_4_;
	O4280[9] = + _LNGOFF_5_4_0_7_;
	O4280[10] =  + _REFACS_5_;
}

long O4281[11];
void O4281_init () {
	O4281[0] =  + _REFACS_6_;
	O4281[1] =  + _REFACS_4_;
	O4281[2] = + _LNGOFF_4_3_0_0_;
	O4281[3] =  + _REFACS_4_;
	O4281[4] = + _LNGOFF_6_3_0_6_;
	O4281[5] =  + _REFACS_4_;
	O4281[6] = + _LNGOFF_4_3_0_8_;
	O4281[7] =  + _REFACS_6_;
	{long i; for (i = 8; i < 10; i++) O4281[i] =  + _REFACS_4_;}
	O4281[10] =  + _REFACS_6_;
}

long O4315[11];
void O4315_init () {
	O4315[0] = + _LNGOFF_7_3_0_6_;
	O4315[1] = + _LNGOFF_5_3_0_8_;
	O4315[2] = + _LNGOFF_4_3_0_9_;
	O4315[3] = + _LNGOFF_5_3_0_6_;
	O4315[4] = + _LNGOFF_6_3_0_7_;
	O4315[5] = + _LNGOFF_5_5_0_6_;
	O4315[6] = + _LNGOFF_4_3_0_9_;
	O4315[7] = + _LNGOFF_7_4_0_6_;
	O4315[8] = + _LNGOFF_5_6_0_6_;
	O4315[9] = + _LNGOFF_5_4_0_8_;
	O4315[10] = + _LNGOFF_9_3_0_6_;
}

long O4318[3];
void O4318_init () {
	O4318[0] = + _CHROFF_7_3_;
	O4318[1] = + _CHROFF_5_5_;
	O4318[2] = + _CHROFF_5_3_;
}

long O4343[480];
void O4343_init () {
	{long i; for (i = 0; i < 15; i++) O4343[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 15; i < 17; i++) O4343[i] = + _LNGOFF_1_2_0_0_;}
	{long i; for (i = 17; i < 19; i++) O4343[i] = + _LNGOFF_9_2_0_0_;}
	O4343[19] = + _LNGOFF_10_2_0_0_;
	{long i; for (i = 20; i < 38; i++) O4343[i] = + _LNGOFF_9_2_0_0_;}
	{long i; for (i = 38; i < 40; i++) O4343[i] = + _LNGOFF_3_2_0_0_;}
	{long i; for (i = 40; i < 43; i++) O4343[i] = + _LNGOFF_5_2_0_0_;}
	O4343[479] = + _LNGOFF_7_2_0_0_;
}

long O4351[465];
void O4351_init () {
	{long i; for (i = 0; i < 2; i++) O4351[i] = + _CHROFF_1_1_;}
	{long i; for (i = 2; i < 4; i++) O4351[i] = + _CHROFF_9_1_;}
	O4351[4] = + _CHROFF_10_1_;
	{long i; for (i = 5; i < 23; i++) O4351[i] = + _CHROFF_9_1_;}
	{long i; for (i = 23; i < 25; i++) O4351[i] = + _CHROFF_3_1_;}
	{long i; for (i = 25; i < 28; i++) O4351[i] = + _CHROFF_5_1_;}
	O4351[464] = + _CHROFF_7_1_;
}

long O4363[21];
void O4363_init () {
	{long i; for (i = 0; i < 2; i++) O4363[i] = + _LNGOFF_9_2_0_1_;}
	O4363[2] = + _LNGOFF_10_2_0_1_;
	{long i; for (i = 3; i < 21; i++) O4363[i] = + _LNGOFF_9_2_0_1_;}
}

static EIF_TYPE_INDEX Y4410_pgtype0[] = {601,0xFFF9,1,865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4410_pgtype1[] = {601,0xFFF9,1,865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4410_pgtype2[] = {601,0xFFF9,1,865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4410_pgtype3[] = {601,0xFFF9,1,865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4410_pgtype4[] = {601,0xFFF9,1,865,990,0xFFFF};
EIF_TYPE_INDEX *Y4410_gen_type [5];
EIF_TYPE_INDEX Y4410 [5];
void Y4410_init (void)
{
	egc_routines_types [4410] = Y4410;
	egc_routines_gen_types [4410] = Y4410_gen_type;
	egc_routines_offset [4410] = 622;
	Y4410_gen_type [0] = Y4410_pgtype0;
	Y4410_gen_type [1] = Y4410_pgtype1;
	Y4410_gen_type [2] = Y4410_pgtype2;
	Y4410_gen_type [3] = Y4410_pgtype3;
	Y4410_gen_type [4] = Y4410_pgtype4;
	{long i; for (i = 0; i < 5; i++) Y4410[i] = 601;};
}

static EIF_TYPE_INDEX Y4411_pgtype0[] = {601,0xFFF9,1,865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4411_pgtype1[] = {601,0xFFF9,1,865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4411_pgtype2[] = {601,0xFFF9,1,865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4411_pgtype3[] = {601,0xFFF9,1,865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4411_pgtype4[] = {601,0xFFF9,1,865,990,0xFFFF};
EIF_TYPE_INDEX *Y4411_gen_type [5];
EIF_TYPE_INDEX Y4411 [5];
void Y4411_init (void)
{
	egc_routines_types [4411] = Y4411;
	egc_routines_gen_types [4411] = Y4411_gen_type;
	egc_routines_offset [4411] = 622;
	Y4411_gen_type [0] = Y4411_pgtype0;
	Y4411_gen_type [1] = Y4411_pgtype1;
	Y4411_gen_type [2] = Y4411_pgtype2;
	Y4411_gen_type [3] = Y4411_pgtype3;
	Y4411_gen_type [4] = Y4411_pgtype4;
	{long i; for (i = 0; i < 5; i++) Y4411[i] = 601;};
}

static EIF_TYPE_INDEX Y4412_pgtype0[] = {602,0xFFF9,1,865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4412_pgtype1[] = {602,0xFFF9,1,865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4412_pgtype2[] = {602,0xFFF9,1,865,990,0xFFFF};
EIF_TYPE_INDEX *Y4412_gen_type [3];
EIF_TYPE_INDEX Y4412 [3];
void Y4412_init (void)
{
	egc_routines_types [4412] = Y4412;
	egc_routines_gen_types [4412] = Y4412_gen_type;
	egc_routines_offset [4412] = 624;
	Y4412_gen_type [0] = Y4412_pgtype0;
	Y4412_gen_type [1] = Y4412_pgtype1;
	Y4412_gen_type [2] = Y4412_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y4412[i] = 602;};
}

static EIF_TYPE_INDEX Y4413_pgtype0[] = {602,0xFFF9,1,865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4413_pgtype1[] = {602,0xFFF9,1,865,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y4413_pgtype2[] = {602,0xFFF9,1,865,990,0xFFFF};
EIF_TYPE_INDEX *Y4413_gen_type [3];
EIF_TYPE_INDEX Y4413 [3];
void Y4413_init (void)
{
	egc_routines_types [4413] = Y4413;
	egc_routines_gen_types [4413] = Y4413_gen_type;
	egc_routines_offset [4413] = 624;
	Y4413_gen_type [0] = Y4413_pgtype0;
	Y4413_gen_type [1] = Y4413_pgtype1;
	Y4413_gen_type [2] = Y4413_pgtype2;
	{long i; for (i = 0; i < 3; i++) Y4413[i] = 602;};
}

long O4681[22];
void O4681_init () {
	{long i; for (i = 0; i < 12; i++) O4681[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 12; i < 15; i++) O4681[i] = + _LNGOFF_2_1_0_0_;}
	{long i; for (i = 15; i < 22; i++) O4681[i] = + _LNGOFF_1_1_0_0_;}
}

long O4685[22];
void O4685_init () {
	{long i; for (i = 0; i < 12; i++) O4685[i] = + _CHROFF_1_0_;}
	{long i; for (i = 12; i < 15; i++) O4685[i] = + _CHROFF_2_0_;}
	{long i; for (i = 15; i < 22; i++) O4685[i] = + _CHROFF_1_0_;}
}

long O4686[22];
void O4686_init () {
	{long i; for (i = 0; i < 12; i++) O4686[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 12; i < 15; i++) O4686[i] = + _LNGOFF_2_1_0_1_;}
	{long i; for (i = 15; i < 22; i++) O4686[i] = + _LNGOFF_1_1_0_1_;}
}

long O4687[22];
void O4687_init () {
	{long i; for (i = 0; i < 12; i++) O4687[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 12; i < 15; i++) O4687[i] = + _LNGOFF_2_1_0_2_;}
	{long i; for (i = 15; i < 22; i++) O4687[i] = + _LNGOFF_1_1_0_2_;}
}

long O4688[22];
void O4688_init () {
	{long i; for (i = 0; i < 12; i++) O4688[i] = + _LNGOFF_1_1_0_3_;}
	{long i; for (i = 12; i < 15; i++) O4688[i] = + _LNGOFF_2_1_0_3_;}
	{long i; for (i = 15; i < 22; i++) O4688[i] = + _LNGOFF_1_1_0_3_;}
}

long O4689[22];
void O4689_init () {
	{long i; for (i = 0; i < 12; i++) O4689[i] = + _LNGOFF_1_1_0_4_;}
	{long i; for (i = 12; i < 15; i++) O4689[i] = + _LNGOFF_2_1_0_4_;}
	{long i; for (i = 15; i < 22; i++) O4689[i] = + _LNGOFF_1_1_0_4_;}
}

long O4863[445];
void O4863_init () {
	O4863[0] = + _CHROFF_1_0_;
	O4863[1] = + _CHROFF_3_0_;
	O4863[2] = + _CHROFF_4_0_;
	O4863[3] = + _CHROFF_5_0_;
	O4863[444] = + _CHROFF_5_0_;
}

long O4962[444];
void O4962_init () {
	O4962[0] = + _PTROFF_3_6_2_4_1_0_;
	O4962[1] = + _PTROFF_4_6_2_4_1_0_;
	O4962[2] = + _PTROFF_5_7_2_4_1_0_;
	O4962[443] = + _PTROFF_5_7_2_4_1_0_;
}

long O5101[444];
void O5101_init () {
	O5101[0] = + _LNGOFF_3_6_2_3_;
	O5101[1] = + _LNGOFF_4_6_2_3_;
	O5101[2] = + _LNGOFF_5_7_2_3_;
	O5101[443] = + _LNGOFF_5_7_2_3_;
}

long O5110[444];
void O5110_init () {
	O5110[0] = + _CHROFF_3_3_;
	O5110[1] = + _CHROFF_4_3_;
	O5110[2] = + _CHROFF_5_3_;
	O5110[443] = + _CHROFF_5_3_;
}

long O5187[434];
void O5187_init () {
	O5187[0] = + _LNGOFF_0_0_0_0_;
	O5187[1] = + _LNGOFF_1_0_0_1_;
	{long i; for (i = 2; i < 4; i++) O5187[i] = + _LNGOFF_0_0_0_0_;}
	O5187[4] = + _LNGOFF_2_0_0_0_;
	O5187[5] = + _LNGOFF_0_1_0_0_;
	O5187[180] = + _LNGOFF_2_0_0_0_;
	O5187[196] = + _LNGOFF_4_0_0_0_;
	O5187[200] = + _LNGOFF_5_2_0_0_;
	{long i; for (i = 201; i < 213; i++) O5187[i] = + _LNGOFF_6_3_0_0_;}
	O5187[213] = + _LNGOFF_6_4_0_0_;
	O5187[214] = + _LNGOFF_6_3_0_0_;
	O5187[215] = + _LNGOFF_9_3_0_0_;
	O5187[216] = + _LNGOFF_24_5_0_0_;
	O5187[217] = + _LNGOFF_6_3_0_0_;
	O5187[218] = + _LNGOFF_7_4_0_0_;
	{long i; for (i = 219; i < 222; i++) O5187[i] = + _LNGOFF_14_3_0_0_;}
	{long i; for (i = 222; i < 226; i++) O5187[i] = + _LNGOFF_5_2_0_0_;}
	{long i; for (i = 226; i < 228; i++) O5187[i] = + _LNGOFF_6_2_0_0_;}
	{long i; for (i = 228; i < 232; i++) O5187[i] = + _LNGOFF_5_2_0_0_;}
	O5187[232] = + _LNGOFF_6_3_0_0_;
	{long i; for (i = 233; i < 235; i++) O5187[i] = + _LNGOFF_8_3_0_0_;}
	{long i; for (i = 235; i < 237; i++) O5187[i] = + _LNGOFF_6_0_0_0_;}
	O5187[237] = + _LNGOFF_7_2_0_1_;
	{long i; for (i = 238; i < 246; i++) O5187[i] = + _LNGOFF_6_0_0_0_;}
	{long i; for (i = 247; i < 249; i++) O5187[i] = + _LNGOFF_5_3_0_0_;}
	O5187[250] = + _LNGOFF_5_3_0_0_;
	{long i; for (i = 251; i < 253; i++) O5187[i] = + _LNGOFF_6_1_0_0_;}
	{long i; for (i = 253; i < 256; i++) O5187[i] = + _LNGOFF_5_3_0_0_;}
	O5187[257] = + _LNGOFF_6_1_0_0_;
	O5187[264] = + _LNGOFF_2_4_0_0_;
	O5187[266] = + _LNGOFF_2_2_0_1_;
	O5187[285] = + _LNGOFF_49_16_0_3_;
	O5187[287] = + _LNGOFF_2_3_0_0_;
	O5187[288] = + _LNGOFF_4_3_0_0_;
	O5187[289] = + _LNGOFF_5_5_0_0_;
	O5187[290] = + _LNGOFF_10_10_0_0_;
	O5187[302] = + _LNGOFF_6_3_0_0_;
	O5187[327] = + _LNGOFF_8_5_0_0_;
	{long i; for (i = 331; i < 333; i++) O5187[i] = + _LNGOFF_11_5_0_0_;}
	O5187[333] = + _LNGOFF_11_6_0_0_;
	O5187[335] = + _LNGOFF_16_7_6_0_;
	O5187[337] = + _LNGOFF_42_12_10_0_;
	O5187[339] = + _LNGOFF_46_12_10_0_;
	O5187[343] = + _LNGOFF_47_12_10_0_;
	O5187[344] = + _LNGOFF_49_12_10_0_;
	O5187[345] = + _LNGOFF_47_12_10_0_;
	{long i; for (i = 349; i < 352; i++) O5187[i] = + _LNGOFF_49_13_10_0_;}
	O5187[360] = + _LNGOFF_49_13_10_0_;
	O5187[361] = + _LNGOFF_51_13_10_0_;
	{long i; for (i = 362; i < 364; i++) O5187[i] = + _LNGOFF_49_14_10_0_;}
	O5187[364] = + _LNGOFF_59_21_10_0_;
	O5187[365] = + _LNGOFF_59_23_10_0_;
	O5187[366] = + _LNGOFF_65_25_10_0_;
	O5187[367] = + _LNGOFF_68_26_10_0_;
	O5187[383] = + _LNGOFF_42_13_10_0_;
	O5187[384] = + _LNGOFF_44_13_10_0_;
	O5187[385] = + _LNGOFF_51_13_10_0_;
	O5187[386] = + _LNGOFF_58_14_10_0_;
	O5187[387] = + _LNGOFF_44_13_10_0_;
	O5187[388] = + _LNGOFF_45_16_10_0_;
	{long i; for (i = 389; i < 391; i++) O5187[i] = + _LNGOFF_46_14_10_0_;}
	O5187[391] = + _LNGOFF_50_13_10_0_;
	O5187[392] = + _LNGOFF_51_14_10_0_;
	O5187[393] = + _LNGOFF_43_13_10_0_;
	O5187[394] = + _LNGOFF_44_15_10_0_;
	O5187[395] = + _LNGOFF_51_18_10_0_;
	O5187[396] = + _LNGOFF_46_14_10_0_;
	O5187[397] = + _LNGOFF_59_16_10_0_;
	{long i; for (i = 406; i < 408; i++) O5187[i] = + _LNGOFF_21_7_6_0_;}
	O5187[413] = + _LNGOFF_23_8_6_0_;
	{long i; for (i = 414; i < 416; i++) O5187[i] = + _LNGOFF_23_9_6_0_;}
	O5187[416] = + _LNGOFF_24_9_6_0_;
	O5187[417] = + _LNGOFF_26_8_6_0_;
	{long i; for (i = 422; i < 424; i++) O5187[i] = + _LNGOFF_29_14_8_0_;}
	O5187[432] = + _LNGOFF_48_19_10_0_;
	O5187[433] = + _LNGOFF_48_18_10_0_;
}

long O6118[6];
void O6118_init () {
	{long i; for (i = 0; i < 2; i++) O6118[i] = + _CHROFF_4_0_;}
	O6118[2] = + _CHROFF_5_0_;
	{long i; for (i = 3; i < 6; i++) O6118[i] = + _CHROFF_4_0_;}
}

long O6119[6];
void O6119_init () {
	{long i; for (i = 0; i < 2; i++) O6119[i] = + _LNGOFF_4_2_0_0_;}
	O6119[2] = + _LNGOFF_5_2_0_0_;
	O6119[3] = + _LNGOFF_4_3_0_0_;
	O6119[4] = + _LNGOFF_4_2_0_0_;
	O6119[5] = + _LNGOFF_4_3_0_0_;
}

long O6127[6];
void O6127_init () {
	{long i; for (i = 0; i < 2; i++) O6127[i] = + _PTROFF_4_2_0_3_0_0_;}
	O6127[2] = + _PTROFF_5_2_0_3_0_0_;
	O6127[3] = + _PTROFF_4_3_0_3_0_0_;
	O6127[4] = + _PTROFF_4_2_0_3_0_0_;
	O6127[5] = + _PTROFF_4_3_0_3_0_0_;
}

long O6128[6];
void O6128_init () {
	{long i; for (i = 0; i < 2; i++) O6128[i] = + _PTROFF_4_2_0_3_0_1_;}
	O6128[2] = + _PTROFF_5_2_0_3_0_1_;
	O6128[3] = + _PTROFF_4_3_0_3_0_1_;
	O6128[4] = + _PTROFF_4_2_0_3_0_1_;
	O6128[5] = + _PTROFF_4_3_0_3_0_1_;
}

long O6130[6];
void O6130_init () {
	{long i; for (i = 0; i < 2; i++) O6130[i] = + _PTROFF_4_2_0_3_0_2_;}
	O6130[2] = + _PTROFF_5_2_0_3_0_2_;
	O6130[3] = + _PTROFF_4_3_0_3_0_2_;
	O6130[4] = + _PTROFF_4_2_0_3_0_2_;
	O6130[5] = + _PTROFF_4_3_0_3_0_2_;
}

long O6131[6];
void O6131_init () {
	{long i; for (i = 0; i < 2; i++) O6131[i] = + _LNGOFF_4_2_0_1_;}
	O6131[2] = + _LNGOFF_5_2_0_1_;
	O6131[3] = + _LNGOFF_4_3_0_1_;
	O6131[4] = + _LNGOFF_4_2_0_1_;
	O6131[5] = + _LNGOFF_4_3_0_1_;
}

long O6132[6];
void O6132_init () {
	{long i; for (i = 0; i < 2; i++) O6132[i] = + _CHROFF_4_1_;}
	O6132[2] = + _CHROFF_5_1_;
	{long i; for (i = 3; i < 6; i++) O6132[i] = + _CHROFF_4_1_;}
}

long O6133[6];
void O6133_init () {
	{long i; for (i = 0; i < 2; i++) O6133[i] = + _LNGOFF_4_2_0_2_;}
	O6133[2] = + _LNGOFF_5_2_0_2_;
	O6133[3] = + _LNGOFF_4_3_0_2_;
	O6133[4] = + _LNGOFF_4_2_0_2_;
	O6133[5] = + _LNGOFF_4_3_0_2_;
}

long O6146[4];
void O6146_init () {
	O6146[0] =  + _REFACS_4_;
	O6146[1] = + _CHROFF_4_2_;
	O6146[2] = + _PTROFF_4_2_0_3_0_3_;
	O6146[3] = + _CHROFF_4_2_;
}

long O6245[10];
void O6245_init () {
	{long i; for (i = 0; i < 3; i++) O6245[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O6245[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 5; i < 7; i++) O6245[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 7; i < 9; i++) O6245[i] = + _LNGOFF_1_0_0_0_;}
	O6245[9] = + _LNGOFF_1_1_0_0_;
}

long O6246[10];
void O6246_init () {
	{long i; for (i = 0; i < 3; i++) O6246[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O6246[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 5; i < 7; i++) O6246[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 7; i < 9; i++) O6246[i] = + _LNGOFF_1_0_0_1_;}
	O6246[9] = + _LNGOFF_1_1_0_1_;
}

long O6315[4];
void O6315_init () {
	{long i; for (i = 0; i < 2; i++) O6315[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 4; i++) O6315[i] = + _LNGOFF_1_1_0_2_;}
}

long O6390[3];
void O6390_init () {
	{long i; for (i = 0; i < 2; i++) O6390[i] = + _LNGOFF_1_0_0_2_;}
	O6390[2] = + _LNGOFF_1_1_0_2_;
}

long O6555[105];
void O6555_init () {
	{long i; for (i = 0; i < 41; i++) O6555[i] =  + _REFACS_1_;}
	O6555[41] =  + _REFACS_3_;
	{long i; for (i = 42; i < 45; i++) O6555[i] =  + _REFACS_1_;}
	{long i; for (i = 45; i < 82; i++) O6555[i] =  + _REFACS_3_;}
	O6555[82] =  + _REFACS_4_;
	{long i; for (i = 83; i < 91; i++) O6555[i] =  + _REFACS_3_;}
	O6555[91] =  + _REFACS_1_;
	{long i; for (i = 92; i < 94; i++) O6555[i] =  + _REFACS_3_;}
	O6555[94] =  + _REFACS_1_;
	{long i; for (i = 95; i < 101; i++) O6555[i] =  + _REFACS_3_;}
	O6555[101] =  + _REFACS_1_;
	O6555[102] =  + _REFACS_3_;
	{long i; for (i = 103; i < 105; i++) O6555[i] =  + _REFACS_1_;}
}

long O7033[56];
void O7033_init () {
	O7033[0] = + _CHROFF_5_0_;
	{long i; for (i = 1; i < 15; i++) O7033[i] = + _CHROFF_6_1_;}
	O7033[15] = + _CHROFF_9_1_;
	O7033[16] = + _CHROFF_24_1_;
	O7033[17] = + _CHROFF_6_1_;
	O7033[18] = + _CHROFF_7_1_;
	{long i; for (i = 19; i < 22; i++) O7033[i] = + _CHROFF_14_1_;}
	{long i; for (i = 22; i < 26; i++) O7033[i] = + _CHROFF_5_0_;}
	{long i; for (i = 26; i < 28; i++) O7033[i] = + _CHROFF_6_0_;}
	{long i; for (i = 28; i < 32; i++) O7033[i] = + _CHROFF_5_0_;}
	O7033[32] = + _CHROFF_6_0_;
	{long i; for (i = 33; i < 35; i++) O7033[i] = + _CHROFF_8_0_;}
	{long i; for (i = 47; i < 49; i++) O7033[i] = + _CHROFF_5_1_;}
	O7033[50] = + _CHROFF_5_1_;
	{long i; for (i = 53; i < 56; i++) O7033[i] = + _CHROFF_5_1_;}
}

long O7034[56];
void O7034_init () {
	O7034[0] = + _CHROFF_5_1_;
	{long i; for (i = 1; i < 15; i++) O7034[i] = + _CHROFF_6_2_;}
	O7034[15] = + _CHROFF_9_2_;
	O7034[16] = + _CHROFF_24_2_;
	O7034[17] = + _CHROFF_6_2_;
	O7034[18] = + _CHROFF_7_2_;
	{long i; for (i = 19; i < 22; i++) O7034[i] = + _CHROFF_14_2_;}
	{long i; for (i = 22; i < 26; i++) O7034[i] = + _CHROFF_5_1_;}
	{long i; for (i = 26; i < 28; i++) O7034[i] = + _CHROFF_6_1_;}
	{long i; for (i = 28; i < 32; i++) O7034[i] = + _CHROFF_5_1_;}
	O7034[32] = + _CHROFF_6_1_;
	{long i; for (i = 33; i < 35; i++) O7034[i] = + _CHROFF_8_1_;}
	{long i; for (i = 47; i < 49; i++) O7034[i] = + _CHROFF_5_2_;}
	O7034[50] = + _CHROFF_5_2_;
	{long i; for (i = 53; i < 56; i++) O7034[i] = + _CHROFF_5_2_;}
}

long O7519[176];
void O7519_init () {
	{long i; for (i = 0; i < 24; i++) O7519[i] = 0;}
	O7519[24] =  + _REFACS_22_;
	O7519[25] =  + _REFACS_23_;
	{long i; for (i = 26; i < 35; i++) O7519[i] = 0;}
	O7519[35] =  + _REFACS_1_;
	O7519[36] = 0;
	O7519[37] =  + _REFACS_1_;
	{long i; for (i = 38; i < 41; i++) O7519[i] = 0;}
	{long i; for (i = 41; i < 43; i++) O7519[i] =  + _REFACS_1_;}
	O7519[43] = 0;
	{long i; for (i = 44; i < 46; i++) O7519[i] =  + _REFACS_5_;}
	{long i; for (i = 46; i < 51; i++) O7519[i] = 0;}
	{long i; for (i = 51; i < 53; i++) O7519[i] =  + _REFACS_1_;}
	{long i; for (i = 53; i < 66; i++) O7519[i] = 0;}
	{long i; for (i = 66; i < 74; i++) O7519[i] =  + _REFACS_2_;}
	{long i; for (i = 74; i < 76; i++) O7519[i] =  + _REFACS_7_;}
	{long i; for (i = 76; i < 78; i++) O7519[i] =  + _REFACS_24_;}
	{long i; for (i = 78; i < 81; i++) O7519[i] =  + _REFACS_25_;}
	O7519[81] =  + _REFACS_26_;
	{long i; for (i = 82; i < 84; i++) O7519[i] =  + _REFACS_25_;}
	O7519[84] =  + _REFACS_26_;
	O7519[85] =  + _REFACS_25_;
	{long i; for (i = 86; i < 96; i++) O7519[i] =  + _REFACS_26_;}
	{long i; for (i = 96; i < 98; i++) O7519[i] =  + _REFACS_30_;}
	{long i; for (i = 98; i < 100; i++) O7519[i] =  + _REFACS_33_;}
	{long i; for (i = 100; i < 104; i++) O7519[i] =  + _REFACS_26_;}
	{long i; for (i = 104; i < 106; i++) O7519[i] =  + _REFACS_30_;}
	{long i; for (i = 106; i < 108; i++) O7519[i] =  + _REFACS_33_;}
	O7519[108] =  + _REFACS_24_;
	O7519[109] =  + _REFACS_25_;
	O7519[110] =  + _REFACS_26_;
	O7519[111] =  + _REFACS_28_;
	O7519[112] =  + _REFACS_24_;
	{long i; for (i = 113; i < 116; i++) O7519[i] =  + _REFACS_25_;}
	{long i; for (i = 116; i < 118; i++) O7519[i] =  + _REFACS_26_;}
	{long i; for (i = 118; i < 120; i++) O7519[i] =  + _REFACS_25_;}
	O7519[120] =  + _REFACS_28_;
	O7519[121] =  + _REFACS_26_;
	O7519[122] =  + _REFACS_30_;
	O7519[123] =  + _REFACS_24_;
	O7519[124] =  + _REFACS_25_;
	O7519[125] =  + _REFACS_26_;
	O7519[126] =  + _REFACS_28_;
	O7519[127] =  + _REFACS_24_;
	{long i; for (i = 128; i < 131; i++) O7519[i] =  + _REFACS_25_;}
	{long i; for (i = 131; i < 133; i++) O7519[i] =  + _REFACS_26_;}
	{long i; for (i = 133; i < 135; i++) O7519[i] =  + _REFACS_25_;}
	O7519[135] =  + _REFACS_28_;
	O7519[136] =  + _REFACS_26_;
	O7519[137] =  + _REFACS_30_;
	O7519[138] =  + _REFACS_10_;
	{long i; for (i = 139; i < 141; i++) O7519[i] =  + _REFACS_12_;}
	O7519[141] =  + _REFACS_10_;
	{long i; for (i = 142; i < 146; i++) O7519[i] =  + _REFACS_14_;}
	{long i; for (i = 146; i < 148; i++) O7519[i] =  + _REFACS_10_;}
	{long i; for (i = 148; i < 152; i++) O7519[i] =  + _REFACS_11_;}
	O7519[152] =  + _REFACS_12_;
	{long i; for (i = 153; i < 157; i++) O7519[i] =  + _REFACS_11_;}
	{long i; for (i = 157; i < 160; i++) O7519[i] =  + _REFACS_12_;}
	{long i; for (i = 160; i < 164; i++) O7519[i] =  + _REFACS_14_;}
	{long i; for (i = 164; i < 167; i++) O7519[i] = 0;}
	{long i; for (i = 167; i < 169; i++) O7519[i] =  + _REFACS_25_;}
	{long i; for (i = 169; i < 172; i++) O7519[i] = 0;}
	{long i; for (i = 172; i < 174; i++) O7519[i] =  + _REFACS_25_;}
	{long i; for (i = 174; i < 176; i++) O7519[i] = 0;}
}

static EIF_TYPE_INDEX Y7519_pgtype0[] = {1024,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7519_pgtype1[] = {1024,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7519_pgtype2[] = {1072,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y7519_pgtype3[] = {1072,1077,0xFFFF};
static EIF_TYPE_INDEX Y7519_pgtype4[] = {1072,1068,0xFFFF};
static EIF_TYPE_INDEX Y7519_pgtype5[] = {1072,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y7519_gen_type [176];
EIF_TYPE_INDEX Y7519 [176];
void Y7519_init (void)
{
	egc_routines_types [7519] = Y7519;
	egc_routines_gen_types [7519] = Y7519_gen_type;
	egc_routines_offset [7519] = 1086;
	Y7519_gen_type [31] = Y7519_pgtype0;
	Y7519_gen_type [32] = Y7519_pgtype1;
	Y7519_gen_type [33] = Y7519_pgtype2;
	Y7519_gen_type [34] = Y7519_pgtype3;
	Y7519_gen_type [35] = Y7519_pgtype4;
	Y7519_gen_type [36] = Y7519_pgtype5;
	Y7519[0] = 981;
	{long i; for (i = 1; i < 3; i++) Y7519[i] = 982;};
	{long i; for (i = 3; i < 5; i++) Y7519[i] = 983;};
	{long i; for (i = 5; i < 7; i++) Y7519[i] = 984;};
	Y7519[7] = 985;
	{long i; for (i = 8; i < 10; i++) Y7519[i] = 986;};
	Y7519[10] = 995;
	{long i; for (i = 11; i < 13; i++) Y7519[i] = 987;};
	Y7519[13] = 988;
	{long i; for (i = 14; i < 16; i++) Y7519[i] = 989;};
	{long i; for (i = 16; i < 18; i++) Y7519[i] = 990;};
	{long i; for (i = 18; i < 20; i++) Y7519[i] = 991;};
	{long i; for (i = 20; i < 22; i++) Y7519[i] = 992;};
	{long i; for (i = 22; i < 24; i++) Y7519[i] = 1000;};
	{long i; for (i = 24; i < 26; i++) Y7519[i] = 996;};
	Y7519[26] = 994;
	{long i; for (i = 27; i < 30; i++) Y7519[i] = 981;};
	Y7519[30] = 985;
	{long i; for (i = 31; i < 33; i++) Y7519[i] = 1024;};
	{long i; for (i = 33; i < 37; i++) Y7519[i] = 1072;};
	Y7519[37] = 1082;
	{long i; for (i = 38; i < 40; i++) Y7519[i] = 998;};
	Y7519[40] = 1004;
	{long i; for (i = 41; i < 43; i++) Y7519[i] = 1084;};
	Y7519[43] = 1005;
	{long i; for (i = 44; i < 46; i++) Y7519[i] = 999;};
	Y7519[46] = 1007;
	{long i; for (i = 47; i < 49; i++) Y7519[i] = 1003;};
	{long i; for (i = 49; i < 51; i++) Y7519[i] = 1025;};
	{long i; for (i = 51; i < 53; i++) Y7519[i] = 1006;};
	Y7519[53] = 1010;
	Y7519[54] = 1011;
	{long i; for (i = 55; i < 57; i++) Y7519[i] = 1009;};
	Y7519[57] = 1022;
	{long i; for (i = 58; i < 60; i++) Y7519[i] = 1008;};
	{long i; for (i = 60; i < 62; i++) Y7519[i] = 1012;};
	{long i; for (i = 62; i < 65; i++) Y7519[i] = 1016;};
	Y7519[65] = 988;
	{long i; for (i = 66; i < 71; i++) Y7519[i] = 1018;};
	Y7519[71] = 1019;
	Y7519[72] = 1020;
	Y7519[73] = 1021;
	{long i; for (i = 74; i < 76; i++) Y7519[i] = 1022;};
	{long i; for (i = 76; i < 78; i++) Y7519[i] = 1026;};
	{long i; for (i = 78; i < 80; i++) Y7519[i] = 1027;};
	Y7519[80] = 1028;
	Y7519[81] = 1029;
	Y7519[82] = 1030;
	Y7519[83] = 1028;
	Y7519[84] = 1029;
	Y7519[85] = 1030;
	Y7519[86] = 1031;
	Y7519[87] = 1032;
	Y7519[88] = 1033;
	Y7519[89] = 1031;
	Y7519[90] = 1032;
	Y7519[91] = 1033;
	Y7519[92] = 1034;
	Y7519[93] = 1035;
	{long i; for (i = 94; i < 96; i++) Y7519[i] = 1034;};
	Y7519[96] = 1038;
	Y7519[97] = 1039;
	Y7519[98] = 1040;
	Y7519[99] = 1043;
	Y7519[100] = 1034;
	Y7519[101] = 1035;
	Y7519[102] = 1036;
	Y7519[103] = 1037;
	Y7519[104] = 1038;
	Y7519[105] = 1039;
	Y7519[106] = 1040;
	Y7519[107] = 1043;
	Y7519[108] = 1048;
	Y7519[109] = 1049;
	Y7519[110] = 1076;
	Y7519[111] = 1073;
	Y7519[112] = 1050;
	Y7519[113] = 1074;
	Y7519[114] = 1052;
	Y7519[115] = 1053;
	Y7519[116] = 1079;
	Y7519[117] = 1080;
	Y7519[118] = 1054;
	Y7519[119] = 1055;
	Y7519[120] = 1056;
	Y7519[121] = 1057;
	Y7519[122] = 1081;
	Y7519[123] = 1048;
	Y7519[124] = 1049;
	Y7519[125] = 1076;
	Y7519[126] = 1073;
	Y7519[127] = 1050;
	Y7519[128] = 1074;
	Y7519[129] = 1052;
	Y7519[130] = 1053;
	Y7519[131] = 1079;
	Y7519[132] = 1080;
	Y7519[133] = 1054;
	Y7519[134] = 1055;
	Y7519[135] = 1056;
	Y7519[136] = 1057;
	Y7519[137] = 1081;
	Y7519[138] = 1061;
	{long i; for (i = 139; i < 141; i++) Y7519[i] = 1062;};
	Y7519[141] = 1061;
	Y7519[142] = 1077;
	Y7519[143] = 1078;
	Y7519[144] = 1077;
	Y7519[145] = 1078;
	Y7519[146] = 1061;
	Y7519[147] = 1065;
	Y7519[148] = 1068;
	Y7519[149] = 1069;
	Y7519[150] = 1070;
	Y7519[151] = 1068;
	Y7519[152] = 1083;
	Y7519[153] = 1068;
	Y7519[154] = 1069;
	Y7519[155] = 1070;
	Y7519[156] = 1071;
	Y7519[157] = 1083;
	{long i; for (i = 158; i < 160; i++) Y7519[i] = 1063;};
	Y7519[160] = 1066;
	Y7519[161] = 1067;
	Y7519[162] = 1066;
	Y7519[163] = 1067;
	Y7519[164] = 1013;
	Y7519[165] = 1014;
	Y7519[166] = 1015;
	Y7519[167] = 1051;
	Y7519[168] = 1058;
	Y7519[169] = 1013;
	Y7519[170] = 1014;
	Y7519[171] = 1015;
	Y7519[172] = 1051;
	Y7519[173] = 1058;
	{long i; for (i = 174; i < 176; i++) Y7519[i] = 1085;};
}

long O7520[176];
void O7520_init () {
	{long i; for (i = 0; i < 4; i++) O7520[i] = + _CHROFF_1_0_;}
	O7520[4] = + _CHROFF_2_3_;
	O7520[5] = + _CHROFF_1_1_;
	O7520[6] = + _CHROFF_2_1_;
	{long i; for (i = 7; i < 10; i++) O7520[i] = + _CHROFF_1_0_;}
	O7520[10] = + _CHROFF_2_0_;
	{long i; for (i = 11; i < 16; i++) O7520[i] = + _CHROFF_1_0_;}
	O7520[16] = + _CHROFF_2_1_;
	O7520[17] = + _CHROFF_3_4_;
	O7520[18] = + _CHROFF_1_0_;
	{long i; for (i = 19; i < 21; i++) O7520[i] = + _CHROFF_2_0_;}
	O7520[21] = + _CHROFF_3_1_;
	O7520[22] = + _CHROFF_2_1_;
	O7520[23] = + _CHROFF_4_1_;
	O7520[24] = + _CHROFF_40_8_;
	O7520[25] = + _CHROFF_49_15_;
	O7520[26] = + _CHROFF_1_0_;
	O7520[27] = + _CHROFF_2_2_;
	O7520[28] = + _CHROFF_4_2_;
	O7520[29] = + _CHROFF_5_4_;
	O7520[30] = + _CHROFF_10_9_;
	O7520[31] = + _CHROFF_1_0_;
	O7520[32] = + _CHROFF_2_0_;
	{long i; for (i = 33; i < 35; i++) O7520[i] = + _CHROFF_1_0_;}
	{long i; for (i = 35; i < 37; i++) O7520[i] = + _CHROFF_2_0_;}
	O7520[37] = + _CHROFF_4_0_;
	O7520[38] = + _CHROFF_1_0_;
	O7520[39] = + _CHROFF_3_0_;
	O7520[40] = + _CHROFF_1_0_;
	O7520[41] = + _CHROFF_2_0_;
	O7520[42] = + _CHROFF_6_2_;
	O7520[43] = + _CHROFF_1_0_;
	O7520[44] = + _CHROFF_7_4_;
	O7520[45] = + _CHROFF_8_5_;
	{long i; for (i = 46; i < 49; i++) O7520[i] = + _CHROFF_1_0_;}
	{long i; for (i = 49; i < 51; i++) O7520[i] = + _CHROFF_1_1_;}
	{long i; for (i = 51; i < 53; i++) O7520[i] = + _CHROFF_3_1_;}
	{long i; for (i = 53; i < 59; i++) O7520[i] = + _CHROFF_1_0_;}
	O7520[59] = + _CHROFF_2_0_;
	O7520[60] = + _CHROFF_1_0_;
	O7520[61] = + _CHROFF_2_0_;
	O7520[62] = + _CHROFF_1_0_;
	O7520[63] = + _CHROFF_2_0_;
	{long i; for (i = 64; i < 66; i++) O7520[i] = + _CHROFF_1_0_;}
	O7520[66] = + _CHROFF_3_0_;
	O7520[67] = + _CHROFF_8_4_;
	{long i; for (i = 68; i < 71; i++) O7520[i] = + _CHROFF_4_0_;}
	{long i; for (i = 71; i < 73; i++) O7520[i] = + _CHROFF_11_4_;}
	O7520[73] = + _CHROFF_11_5_;
	O7520[74] = + _CHROFF_13_3_;
	O7520[75] = + _CHROFF_16_5_;
	O7520[76] = + _CHROFF_35_7_;
	O7520[77] = + _CHROFF_42_10_;
	O7520[78] = + _CHROFF_37_7_;
	O7520[79] = + _CHROFF_46_10_;
	O7520[80] = + _CHROFF_37_7_;
	O7520[81] = + _CHROFF_38_7_;
	O7520[82] = + _CHROFF_37_7_;
	O7520[83] = + _CHROFF_47_10_;
	O7520[84] = + _CHROFF_49_10_;
	O7520[85] = + _CHROFF_47_10_;
	{long i; for (i = 86; i < 89; i++) O7520[i] = + _CHROFF_39_8_;}
	{long i; for (i = 89; i < 92; i++) O7520[i] = + _CHROFF_49_11_;}
	{long i; for (i = 92; i < 96; i++) O7520[i] = + _CHROFF_39_8_;}
	O7520[96] = + _CHROFF_47_10_;
	O7520[97] = + _CHROFF_47_12_;
	O7520[98] = + _CHROFF_50_11_;
	O7520[99] = + _CHROFF_53_11_;
	O7520[100] = + _CHROFF_49_11_;
	O7520[101] = + _CHROFF_51_11_;
	{long i; for (i = 102; i < 104; i++) O7520[i] = + _CHROFF_49_12_;}
	O7520[104] = + _CHROFF_59_19_;
	O7520[105] = + _CHROFF_59_21_;
	O7520[106] = + _CHROFF_65_23_;
	O7520[107] = + _CHROFF_68_24_;
	O7520[108] = + _CHROFF_35_7_;
	{long i; for (i = 109; i < 111; i++) O7520[i] = + _CHROFF_37_7_;}
	O7520[111] = + _CHROFF_43_7_;
	O7520[112] = + _CHROFF_35_7_;
	O7520[113] = + _CHROFF_37_8_;
	{long i; for (i = 114; i < 116; i++) O7520[i] = + _CHROFF_36_7_;}
	O7520[116] = + _CHROFF_37_7_;
	O7520[117] = + _CHROFF_37_8_;
	{long i; for (i = 118; i < 120; i++) O7520[i] = + _CHROFF_36_7_;}
	O7520[120] = + _CHROFF_40_10_;
	O7520[121] = + _CHROFF_37_7_;
	O7520[122] = + _CHROFF_41_7_;
	O7520[123] = + _CHROFF_42_11_;
	O7520[124] = + _CHROFF_44_11_;
	O7520[125] = + _CHROFF_51_11_;
	O7520[126] = + _CHROFF_58_12_;
	O7520[127] = + _CHROFF_44_11_;
	O7520[128] = + _CHROFF_45_14_;
	{long i; for (i = 129; i < 131; i++) O7520[i] = + _CHROFF_46_12_;}
	O7520[131] = + _CHROFF_50_11_;
	O7520[132] = + _CHROFF_51_12_;
	O7520[133] = + _CHROFF_43_11_;
	O7520[134] = + _CHROFF_44_13_;
	O7520[135] = + _CHROFF_51_16_;
	O7520[136] = + _CHROFF_46_12_;
	O7520[137] = + _CHROFF_59_14_;
	O7520[138] = + _CHROFF_16_3_;
	O7520[139] = + _CHROFF_18_3_;
	O7520[140] = + _CHROFF_23_3_;
	O7520[141] = + _CHROFF_16_3_;
	{long i; for (i = 142; i < 144; i++) O7520[i] = + _CHROFF_20_3_;}
	{long i; for (i = 144; i < 146; i++) O7520[i] = + _CHROFF_25_4_;}
	{long i; for (i = 146; i < 148; i++) O7520[i] = + _CHROFF_21_5_;}
	{long i; for (i = 148; i < 152; i++) O7520[i] = + _CHROFF_17_4_;}
	O7520[152] = + _CHROFF_18_4_;
	O7520[153] = + _CHROFF_23_6_;
	{long i; for (i = 154; i < 156; i++) O7520[i] = + _CHROFF_23_7_;}
	O7520[156] = + _CHROFF_24_7_;
	O7520[157] = + _CHROFF_26_6_;
	O7520[158] = + _CHROFF_19_3_;
	O7520[159] = + _CHROFF_22_3_;
	{long i; for (i = 160; i < 162; i++) O7520[i] = + _CHROFF_21_8_;}
	{long i; for (i = 162; i < 164; i++) O7520[i] = + _CHROFF_29_12_;}
	{long i; for (i = 164; i < 167; i++) O7520[i] = + _CHROFF_1_0_;}
	O7520[167] = + _CHROFF_36_8_;
	O7520[168] = + _CHROFF_36_7_;
	{long i; for (i = 169; i < 171; i++) O7520[i] = + _CHROFF_6_2_;}
	O7520[171] = + _CHROFF_6_4_;
	O7520[172] = + _CHROFF_48_15_;
	O7520[173] = + _CHROFF_48_14_;
	{long i; for (i = 174; i < 176; i++) O7520[i] = + _CHROFF_3_0_;}
}

long O7631[164];
void O7631_init () {
	O7631[0] =  + _REFACS_1_;
	{long i; for (i = 66; i < 68; i++) O7631[i] =  + _REFACS_25_;}
	{long i; for (i = 68; i < 71; i++) O7631[i] =  + _REFACS_26_;}
	O7631[71] =  + _REFACS_27_;
	{long i; for (i = 72; i < 74; i++) O7631[i] =  + _REFACS_26_;}
	O7631[74] =  + _REFACS_27_;
	O7631[75] =  + _REFACS_26_;
	{long i; for (i = 76; i < 86; i++) O7631[i] =  + _REFACS_27_;}
	{long i; for (i = 86; i < 88; i++) O7631[i] =  + _REFACS_31_;}
	{long i; for (i = 88; i < 90; i++) O7631[i] =  + _REFACS_34_;}
	{long i; for (i = 90; i < 94; i++) O7631[i] =  + _REFACS_27_;}
	{long i; for (i = 94; i < 96; i++) O7631[i] =  + _REFACS_31_;}
	{long i; for (i = 96; i < 98; i++) O7631[i] =  + _REFACS_34_;}
	O7631[98] =  + _REFACS_25_;
	O7631[99] =  + _REFACS_26_;
	O7631[100] =  + _REFACS_27_;
	O7631[101] =  + _REFACS_29_;
	O7631[102] =  + _REFACS_25_;
	{long i; for (i = 103; i < 106; i++) O7631[i] =  + _REFACS_26_;}
	{long i; for (i = 106; i < 108; i++) O7631[i] =  + _REFACS_27_;}
	{long i; for (i = 108; i < 110; i++) O7631[i] =  + _REFACS_26_;}
	O7631[110] =  + _REFACS_29_;
	O7631[111] =  + _REFACS_27_;
	O7631[112] =  + _REFACS_31_;
	O7631[113] =  + _REFACS_25_;
	O7631[114] =  + _REFACS_26_;
	O7631[115] =  + _REFACS_27_;
	O7631[116] =  + _REFACS_29_;
	O7631[117] =  + _REFACS_25_;
	{long i; for (i = 118; i < 121; i++) O7631[i] =  + _REFACS_26_;}
	{long i; for (i = 121; i < 123; i++) O7631[i] =  + _REFACS_27_;}
	{long i; for (i = 123; i < 125; i++) O7631[i] =  + _REFACS_26_;}
	O7631[125] =  + _REFACS_29_;
	O7631[126] =  + _REFACS_27_;
	O7631[127] =  + _REFACS_31_;
	{long i; for (i = 157; i < 159; i++) O7631[i] =  + _REFACS_26_;}
	{long i; for (i = 162; i < 164; i++) O7631[i] =  + _REFACS_26_;}
}

long O8051[147];
void O8051_init () {
	O8051[0] = + _PTROFF_2_3_0_1_0_0_;
	O8051[1] = + _PTROFF_4_3_0_1_0_0_;
	O8051[2] = + _PTROFF_5_5_0_1_0_0_;
	O8051[3] = + _PTROFF_10_10_0_9_0_0_;
	O8051[15] = + _PTROFF_6_3_0_2_0_0_;
	O8051[40] = + _PTROFF_8_5_0_1_0_0_;
	{long i; for (i = 44; i < 46; i++) O8051[i] = + _PTROFF_11_5_0_1_0_0_;}
	O8051[46] = + _PTROFF_11_6_0_1_0_0_;
	O8051[48] = + _PTROFF_16_7_6_1_0_0_;
	O8051[50] = + _PTROFF_42_12_10_6_0_0_;
	O8051[52] = + _PTROFF_46_12_10_6_0_0_;
	O8051[56] = + _PTROFF_47_12_10_7_0_0_;
	O8051[57] = + _PTROFF_49_12_10_10_0_0_;
	O8051[58] = + _PTROFF_47_12_10_7_0_0_;
	{long i; for (i = 62; i < 65; i++) O8051[i] = + _PTROFF_49_13_10_7_0_0_;}
	O8051[73] = + _PTROFF_49_13_10_6_0_0_;
	O8051[74] = + _PTROFF_51_13_10_8_0_0_;
	O8051[75] = + _PTROFF_49_14_10_8_0_0_;
	O8051[76] = + _PTROFF_49_14_10_10_0_0_;
	O8051[77] = + _PTROFF_59_21_10_11_0_0_;
	O8051[78] = + _PTROFF_59_23_10_11_0_0_;
	O8051[79] = + _PTROFF_65_25_10_11_0_0_;
	O8051[80] = + _PTROFF_68_26_10_11_0_0_;
	O8051[96] = + _PTROFF_42_13_10_6_0_0_;
	O8051[97] = + _PTROFF_44_13_10_7_0_0_;
	O8051[98] = + _PTROFF_51_13_10_9_0_0_;
	O8051[99] = + _PTROFF_58_14_10_9_0_0_;
	O8051[100] = + _PTROFF_44_13_10_6_1_0_;
	O8051[101] = + _PTROFF_45_16_10_7_0_0_;
	{long i; for (i = 102; i < 104; i++) O8051[i] = + _PTROFF_46_14_10_6_0_0_;}
	O8051[104] = + _PTROFF_50_13_10_9_0_0_;
	O8051[105] = + _PTROFF_51_14_10_9_0_0_;
	O8051[106] = + _PTROFF_43_13_10_6_0_0_;
	O8051[107] = + _PTROFF_44_15_10_6_0_0_;
	O8051[108] = + _PTROFF_51_18_10_10_0_0_;
	O8051[109] = + _PTROFF_46_14_10_7_0_0_;
	O8051[110] = + _PTROFF_59_16_10_12_0_0_;
	{long i; for (i = 119; i < 121; i++) O8051[i] = + _PTROFF_21_7_6_1_0_0_;}
	O8051[126] = + _PTROFF_23_8_6_1_0_0_;
	{long i; for (i = 127; i < 129; i++) O8051[i] = + _PTROFF_23_9_6_1_0_0_;}
	O8051[129] = + _PTROFF_24_9_6_1_0_0_;
	O8051[130] = + _PTROFF_26_8_6_2_0_0_;
	{long i; for (i = 135; i < 137; i++) O8051[i] = + _PTROFF_29_14_8_2_0_0_;}
	O8051[145] = + _PTROFF_48_19_10_9_0_0_;
	O8051[146] = + _PTROFF_48_18_10_9_0_0_;
}

long O8052[147];
void O8052_init () {
	O8052[0] = + _CHROFF_2_0_;
	O8052[1] = + _CHROFF_4_0_;
	O8052[2] = + _CHROFF_5_0_;
	O8052[3] = + _CHROFF_10_0_;
	O8052[15] = + _CHROFF_6_0_;
	O8052[40] = + _CHROFF_8_0_;
	{long i; for (i = 44; i < 47; i++) O8052[i] = + _CHROFF_11_0_;}
	O8052[48] = + _CHROFF_16_1_;
	O8052[50] = + _CHROFF_42_1_;
	O8052[52] = + _CHROFF_46_1_;
	O8052[56] = + _CHROFF_47_1_;
	O8052[57] = + _CHROFF_49_1_;
	O8052[58] = + _CHROFF_47_1_;
	{long i; for (i = 62; i < 65; i++) O8052[i] = + _CHROFF_49_1_;}
	O8052[73] = + _CHROFF_49_1_;
	O8052[74] = + _CHROFF_51_1_;
	{long i; for (i = 75; i < 77; i++) O8052[i] = + _CHROFF_49_1_;}
	{long i; for (i = 77; i < 79; i++) O8052[i] = + _CHROFF_59_1_;}
	O8052[79] = + _CHROFF_65_1_;
	O8052[80] = + _CHROFF_68_1_;
	O8052[96] = + _CHROFF_42_1_;
	O8052[97] = + _CHROFF_44_1_;
	O8052[98] = + _CHROFF_51_1_;
	O8052[99] = + _CHROFF_58_1_;
	O8052[100] = + _CHROFF_44_1_;
	O8052[101] = + _CHROFF_45_1_;
	{long i; for (i = 102; i < 104; i++) O8052[i] = + _CHROFF_46_1_;}
	O8052[104] = + _CHROFF_50_1_;
	O8052[105] = + _CHROFF_51_1_;
	O8052[106] = + _CHROFF_43_1_;
	O8052[107] = + _CHROFF_44_1_;
	O8052[108] = + _CHROFF_51_1_;
	O8052[109] = + _CHROFF_46_1_;
	O8052[110] = + _CHROFF_59_1_;
	{long i; for (i = 119; i < 121; i++) O8052[i] = + _CHROFF_21_1_;}
	{long i; for (i = 126; i < 129; i++) O8052[i] = + _CHROFF_23_1_;}
	O8052[129] = + _CHROFF_24_1_;
	O8052[130] = + _CHROFF_26_1_;
	{long i; for (i = 135; i < 137; i++) O8052[i] = + _CHROFF_29_1_;}
	{long i; for (i = 145; i < 147; i++) O8052[i] = + _CHROFF_48_1_;}
}

long O8063[147];
void O8063_init () {
	{long i; for (i = 0; i < 4; i++) O8063[i] =  + _REFACS_1_;}
	O8063[15] =  + _REFACS_2_;
	O8063[40] =  + _REFACS_3_;
	{long i; for (i = 44; i < 47; i++) O8063[i] =  + _REFACS_3_;}
	O8063[48] =  + _REFACS_8_;
	O8063[50] =  + _REFACS_26_;
	O8063[52] =  + _REFACS_27_;
	O8063[56] =  + _REFACS_27_;
	O8063[57] =  + _REFACS_28_;
	O8063[58] =  + _REFACS_27_;
	{long i; for (i = 62; i < 65; i++) O8063[i] =  + _REFACS_28_;}
	{long i; for (i = 73; i < 77; i++) O8063[i] =  + _REFACS_28_;}
	{long i; for (i = 77; i < 79; i++) O8063[i] =  + _REFACS_32_;}
	{long i; for (i = 79; i < 81; i++) O8063[i] =  + _REFACS_35_;}
	O8063[96] =  + _REFACS_26_;
	O8063[97] =  + _REFACS_27_;
	O8063[98] =  + _REFACS_28_;
	O8063[99] =  + _REFACS_30_;
	O8063[100] =  + _REFACS_26_;
	{long i; for (i = 101; i < 104; i++) O8063[i] =  + _REFACS_27_;}
	{long i; for (i = 104; i < 106; i++) O8063[i] =  + _REFACS_28_;}
	{long i; for (i = 106; i < 108; i++) O8063[i] =  + _REFACS_27_;}
	O8063[108] =  + _REFACS_30_;
	O8063[109] =  + _REFACS_28_;
	O8063[110] =  + _REFACS_32_;
	{long i; for (i = 119; i < 121; i++) O8063[i] =  + _REFACS_11_;}
	{long i; for (i = 126; i < 130; i++) O8063[i] =  + _REFACS_12_;}
	O8063[130] =  + _REFACS_13_;
	{long i; for (i = 135; i < 137; i++) O8063[i] =  + _REFACS_15_;}
	{long i; for (i = 145; i < 147; i++) O8063[i] =  + _REFACS_27_;}
}


#ifdef __cplusplus
}
#endif
