#include "epoly4.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R28[1271])();
void R28_init () {
	R28[0] = (char *(*)()) F1_25;
	{long i; for (i = 2; i < 7; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 8; i < 16; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 18; i < 23; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 24; i < 29; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 31; i < 34; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 46; i < 48; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 75; i < 80; i++) R28[i] = (char *(*)()) F1_25;}
	R28[98] = (char *(*)()) F1_25;
	{long i; for (i = 103; i < 105; i++) R28[i] = (char *(*)()) F1_25;}
	R28[109] = (char *(*)()) F1_25;
	R28[116] = (char *(*)()) F1_25;
	R28[119] = (char *(*)()) F1_25;
	R28[122] = (char *(*)()) F1_25;
	{long i; for (i = 128; i < 132; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 133; i < 135; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 136; i < 144; i++) R28[i] = (char *(*)()) F1_25;}
	R28[146] = (char *(*)()) F1_25;
	R28[149] = (char *(*)()) F1_25;
	R28[151] = (char *(*)()) F1_25;
	{long i; for (i = 152; i < 155; i++) R28[i] = (char *(*)()) F156_3081;}
	R28[157] = (char *(*)()) F156_3081;
	{long i; for (i = 159; i < 162; i++) R28[i] = (char *(*)()) F156_3081;}
	{long i; for (i = 163; i < 166; i++) R28[i] = (char *(*)()) F156_3081;}
	{long i; for (i = 167; i < 169; i++) R28[i] = (char *(*)()) F156_3081;}
	{long i; for (i = 171; i < 173; i++) R28[i] = (char *(*)()) F156_3081;}
	{long i; for (i = 174; i < 177; i++) R28[i] = (char *(*)()) F156_3081;}
	{long i; for (i = 178; i < 182; i++) R28[i] = (char *(*)()) F156_3081;}
	{long i; for (i = 183; i < 185; i++) R28[i] = (char *(*)()) F156_3081;}
	{long i; for (i = 186; i < 192; i++) R28[i] = (char *(*)()) F156_3081;}
	R28[192] = (char *(*)()) F1_25;
	R28[195] = (char *(*)()) F1_25;
	{long i; for (i = 197; i < 205; i++) R28[i] = (char *(*)()) F1_25;}
	R28[207] = (char *(*)()) F1_25;
	R28[210] = (char *(*)()) F1_25;
	{long i; for (i = 228; i < 230; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 231; i < 233; i++) R28[i] = (char *(*)()) F1_25;}
	R28[234] = (char *(*)()) F1_25;
	R28[270] = (char *(*)()) F1_25;
	{long i; for (i = 500; i < 512; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 561; i < 568; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 570; i < 580; i++) R28[i] = (char *(*)()) F1_25;}
	R28[580] = (char *(*)()) F584_4744;
	{long i; for (i = 581; i < 593; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 598; i < 601; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 607; i < 610; i++) R28[i] = (char *(*)()) F1_25;}
	R28[611] = (char *(*)()) F1_25;
	R28[614] = (char *(*)()) F1_25;
	{long i; for (i = 616; i < 619; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 621; i < 624; i++) R28[i] = (char *(*)()) F1_25;}
	R28[625] = (char *(*)()) F1_25;
	R28[626] = (char *(*)()) F630_5019;
	{long i; for (i = 629; i < 641; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 705; i < 707; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 738; i < 760; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 772; i < 784; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 811; i < 813; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 814; i < 818; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 820; i < 822; i++) R28[i] = (char *(*)()) F1_25;}
	R28[823] = (char *(*)()) F1_25;
	R28[825] = (char *(*)()) F1_25;
	R28[828] = (char *(*)()) F1_25;
	R28[830] = (char *(*)()) F834_6166;
	R28[831] = (char *(*)()) F835_6207;
	R28[832] = (char *(*)()) F836_6207;
	R28[833] = (char *(*)()) F837_6207;
	R28[834] = (char *(*)()) F838_6207;
	R28[835] = (char *(*)()) F839_6207;
	R28[836] = (char *(*)()) F840_6207;
	R28[837] = (char *(*)()) F841_6207;
	R28[838] = (char *(*)()) F842_6207;
	R28[839] = (char *(*)()) F843_6207;
	R28[840] = (char *(*)()) F844_6207;
	R28[841] = (char *(*)()) F845_6207;
	R28[842] = (char *(*)()) F846_6207;
	R28[843] = (char *(*)()) F847_6207;
	R28[844] = (char *(*)()) F848_6207;
	R28[845] = (char *(*)()) F849_6207;
	R28[846] = (char *(*)()) F850_6207;
	R28[847] = (char *(*)()) F851_6207;
	R28[848] = (char *(*)()) F852_6207;
	R28[849] = (char *(*)()) F853_6207;
	R28[850] = (char *(*)()) F854_6207;
	R28[851] = (char *(*)()) F855_6207;
	R28[852] = (char *(*)()) F856_6207;
	R28[853] = (char *(*)()) F857_6207;
	R28[854] = (char *(*)()) F858_6207;
	R28[855] = (char *(*)()) F859_6207;
	R28[856] = (char *(*)()) F860_6207;
	R28[857] = (char *(*)()) F861_6207;
	R28[858] = (char *(*)()) F862_6207;
	R28[859] = (char *(*)()) F863_6207;
	R28[860] = (char *(*)()) F864_6207;
	R28[861] = (char *(*)()) F865_6207;
	R28[862] = (char *(*)()) F1_25;
	{long i; for (i = 864; i < 866; i++) R28[i] = (char *(*)()) F867_6420;}
	{long i; for (i = 867; i < 869; i++) R28[i] = (char *(*)()) F870_6519;}
	{long i; for (i = 870; i < 872; i++) R28[i] = (char *(*)()) F873_6618;}
	{long i; for (i = 873; i < 875; i++) R28[i] = (char *(*)()) F876_6714;}
	{long i; for (i = 876; i < 878; i++) R28[i] = (char *(*)()) F879_6808;}
	{long i; for (i = 879; i < 881; i++) R28[i] = (char *(*)()) F882_6903;}
	{long i; for (i = 882; i < 884; i++) R28[i] = (char *(*)()) F885_6998;}
	R28[885] = (char *(*)()) F889_7091;
	R28[886] = (char *(*)()) F890_7091;
	R28[888] = (char *(*)()) F892_7157;
	R28[889] = (char *(*)()) F893_7157;
	{long i; for (i = 891; i < 893; i++) R28[i] = (char *(*)()) F894_7173;}
	{long i; for (i = 894; i < 896; i++) R28[i] = (char *(*)()) F897_7213;}
	{long i; for (i = 897; i < 899; i++) R28[i] = (char *(*)()) F900_7261;}
	{long i; for (i = 900; i < 902; i++) R28[i] = (char *(*)()) F903_7337;}
	{long i; for (i = 902; i < 933; i++) R28[i] = (char *(*)()) F906_7385;}
	R28[933] = (char *(*)()) F937_7398;
	R28[934] = (char *(*)()) F938_7398;
	{long i; for (i = 936; i < 941; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 945; i < 947; i++) R28[i] = (char *(*)()) F948_7627;}
	{long i; for (i = 949; i < 951; i++) R28[i] = (char *(*)()) F952_7792;}
	{long i; for (i = 981; i < 983; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 984; i < 987; i++) R28[i] = (char *(*)()) F1_25;}
	R28[987] = (char *(*)()) F991_8171;
	R28[988] = (char *(*)()) F992_8206;
	R28[989] = (char *(*)()) F1_25;
	R28[994] = (char *(*)()) F1_25;
	{long i; for (i = 997; i < 1000; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1012] = (char *(*)()) F1_25;
	{long i; for (i = 1017; i < 1019; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1029; i < 1033; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1034; i < 1036; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1038; i < 1042; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1043; i < 1045; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1047; i < 1050; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1052] = (char *(*)()) F1_25;
	{long i; for (i = 1054; i < 1058; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1062; i < 1064; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1065] = (char *(*)()) F1_25;
	R28[1071] = (char *(*)()) F1_25;
	R28[1080] = (char *(*)()) F1_25;
	R28[1089] = (char *(*)()) F1_25;
	R28[1095] = (char *(*)()) F1_25;
	R28[1098] = (char *(*)()) F1_25;
	R28[1100] = (char *(*)()) F1_25;
	R28[1102] = (char *(*)()) F1_25;
	R28[1104] = (char *(*)()) F1_25;
	R28[1106] = (char *(*)()) F1_25;
	R28[1108] = (char *(*)()) F1_25;
	R28[1113] = (char *(*)()) F1_25;
	R28[1148] = (char *(*)()) F1_25;
	{long i; for (i = 1155; i < 1157; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1173; i < 1175; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1183; i < 1185; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1186; i < 1188; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1189; i < 1191; i++) R28[i] = (char *(*)()) F1_25;}
	{long i; for (i = 1210; i < 1213; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1217] = (char *(*)()) F1_25;
	R28[1219] = (char *(*)()) F1_25;
	R28[1230] = (char *(*)()) F1_25;
	R28[1236] = (char *(*)()) F1_25;
	R28[1240] = (char *(*)()) F1_25;
	R28[1245] = (char *(*)()) F1_25;
	{long i; for (i = 1254; i < 1257; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1262] = (char *(*)()) F1_25;
	R28[1263] = (char *(*)()) F1267_12658;
	{long i; for (i = 1265; i < 1267; i++) R28[i] = (char *(*)()) F1_25;}
	R28[1270] = (char *(*)()) F1_25;
}

char *(*R2833[2])();
void R2833_init () {
	R2833[0] = (char *(*)()) F132_2860;
	R2833[1] = (char *(*)()) F133_2864;
}

char *(*R2835[2])();
void R2835_init () {
	R2835[0] = (char *(*)()) F132_2861;
	R2835[1] = (char *(*)()) F133_2865;
}

char *(*R2940[135])();
void R2940_init () {
	R2940[0] = (char *(*)()) F140_2989;
	R2940[1] = (char *(*)()) F141_2989_2940_1;
	R2940[2] = (char *(*)()) F142_2989_2940_1;
	R2940[3] = (char *(*)()) F143_2989_2940_1;
	R2940[4] = (char *(*)()) F144_2989_2940_1;
	R2940[5] = (char *(*)()) F140_2989;
	R2940[6] = (char *(*)()) F142_2989_2940_1;
	R2940[7] = (char *(*)()) F144_2989_2940_1;
	R2940[134] = (char *(*)()) F140_2989;
}
static EIF_REFERENCE F141_2989_2940_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F141_2989(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F142_2989_2940_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F142_2989(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F143_2989_2940_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F143_2989(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(877, 0x00).id, 877, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F144_2989_2940_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F144_2989(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R2941[135])();
void R2941_init () {
	R2941[0] = (char *(*)()) F140_2990;
	R2941[1] = (char *(*)()) F141_2990_2941_4;
	R2941[2] = (char *(*)()) F142_2990_2941_4;
	R2941[3] = (char *(*)()) F143_2990_2941_4;
	R2941[4] = (char *(*)()) F144_2990_2941_4;
	R2941[5] = (char *(*)()) F140_2990;
	R2941[6] = (char *(*)()) F142_2990_2941_4;
	R2941[7] = (char *(*)()) F144_2990_2941_4;
	R2941[134] = (char *(*)()) F140_2990;
}
static void F141_2990_2941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F141_2990(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F142_2990_2941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F142_2990(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F143_2990_2941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F143_2990(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F144_2990_2941_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F144_2990(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R2945[3])();
void R2945_init () {
	R2945[0] = (char *(*)()) F145_2993;
	R2945[1] = (char *(*)()) F146_2993;
	R2945[2] = (char *(*)()) F147_2993;
}

char *(*R2946[3])();
void R2946_init () {
	R2946[0] = (char *(*)()) F145_2994;
	R2946[1] = (char *(*)()) F146_2994;
	R2946[2] = (char *(*)()) F147_2994;
}

char *(*R2947[805])();
void R2947_init () {
	R2947[0] = (char *(*)()) F150_3010;
	R2947[684] = (char *(*)()) F834_6161;
	R2947[718] = (char *(*)()) F868_6422_2947_2;
	R2947[719] = (char *(*)()) F869_6422_2947_2;
	R2947[721] = (char *(*)()) F871_6521_2947_2;
	R2947[722] = (char *(*)()) F872_6521_2947_2;
	R2947[724] = (char *(*)()) F874_6620_2947_2;
	R2947[725] = (char *(*)()) F875_6620_2947_2;
	R2947[727] = (char *(*)()) F877_6715_2947_2;
	R2947[728] = (char *(*)()) F878_6715_2947_2;
	R2947[730] = (char *(*)()) F880_6809_2947_2;
	R2947[731] = (char *(*)()) F881_6809_2947_2;
	R2947[733] = (char *(*)()) F883_6904_2947_2;
	R2947[734] = (char *(*)()) F884_6904_2947_2;
	R2947[736] = (char *(*)()) F886_6999_2947_2;
	R2947[737] = (char *(*)()) F887_6999_2947_2;
	R2947[739] = (char *(*)()) F889_7068_2947_2;
	R2947[740] = (char *(*)()) F890_7068_2947_2;
	R2947[742] = (char *(*)()) F892_7134_2947_2;
	R2947[743] = (char *(*)()) F893_7134_2947_2;
	{long i; for (i = 745; i < 747; i++) R2947[i] = (char *(*)()) F894_7165;}
	{long i; for (i = 748; i < 750; i++) R2947[i] = (char *(*)()) F897_7205;}
	R2947[754] = (char *(*)()) F904_7339_2947_2;
	R2947[755] = (char *(*)()) F905_7339_2947_2;
	{long i; for (i = 799; i < 801; i++) R2947[i] = (char *(*)()) F948_7612;}
	{long i; for (i = 803; i < 805; i++) R2947[i] = (char *(*)()) F952_7777;}
}
static EIF_BOOLEAN F868_6422_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F868_6422(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F869_6422_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F869_6422(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F871_6521_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F871_6521(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F872_6521_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F872_6521(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F874_6620_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F874_6620(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F875_6620_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F875_6620(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F877_6715_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F877_6715(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F878_6715_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F878_6715(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F880_6809_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F880_6809(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F881_6809_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F881_6809(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F883_6904_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F883_6904(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F884_6904_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F884_6904(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F886_6999_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F886_6999(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F887_6999_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F887_6999(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F889_7068_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F889_7068(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F890_7068_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F890_7068(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F892_7134_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F892_7134(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F893_7134_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F893_7134(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F904_7339_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F904_7339(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F905_7339_2947_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F905_7339(Current, *(EIF_INTEGER_64 *)arg1);
}

char *(*R3015[40])();
void R3015_init () {
	R3015[0] = (char *(*)()) F156_3068;
	{long i; for (i = 1; i < 3; i++) R3015[i] = (char *(*)()) F157_3092;}
	R3015[5] = (char *(*)()) F161_3095;
	R3015[7] = (char *(*)()) F163_3097;
	R3015[8] = (char *(*)()) F164_3101;
	R3015[9] = (char *(*)()) F165_3107;
	R3015[11] = (char *(*)()) F167_3124;
	R3015[12] = (char *(*)()) F168_3126;
	R3015[13] = (char *(*)()) F169_3128;
	R3015[15] = (char *(*)()) F171_3130;
	R3015[16] = (char *(*)()) F172_3134;
	R3015[19] = (char *(*)()) F175_3136;
	R3015[20] = (char *(*)()) F176_3138;
	R3015[22] = (char *(*)()) F178_3142;
	R3015[23] = (char *(*)()) F179_3144;
	R3015[24] = (char *(*)()) F180_3150;
	R3015[26] = (char *(*)()) F182_3152;
	R3015[27] = (char *(*)()) F183_3154;
	R3015[28] = (char *(*)()) F184_3158;
	R3015[29] = (char *(*)()) F185_3162;
	R3015[31] = (char *(*)()) F187_3164;
	R3015[32] = (char *(*)()) F188_3166;
	R3015[34] = (char *(*)()) F190_3168;
	R3015[35] = (char *(*)()) F191_3170;
	R3015[36] = (char *(*)()) F192_3172;
	R3015[37] = (char *(*)()) F193_3174;
	R3015[38] = (char *(*)()) F194_3178;
	R3015[39] = (char *(*)()) F195_3180;
}

char *(*R3168[3])();
void R3168_init () {
	R3168[0] = (char *(*)()) F202_3275;
	R3168[1] = (char *(*)()) F203_3275;
	R3168[2] = (char *(*)()) F204_3275;
}

char *(*R3450[606])();
void R3450_init () {
	R3450[0] = (char *(*)()) F211_3560;
	R3450[605] = (char *(*)()) F816_5385;
}

char *(*R3694[719])();
void R3694_init () {
	R3694[0] = (char *(*)()) F224_3810;
	R3694[268] = (char *(*)()) F219_3810;
	R3694[269] = (char *(*)()) F220_3810;
	R3694[270] = (char *(*)()) F221_3810;
	R3694[271] = (char *(*)()) F222_3810;
	R3694[272] = (char *(*)()) F223_3810;
	R3694[273] = (char *(*)()) F224_3810;
	R3694[274] = (char *(*)()) F225_3810;
	R3694[275] = (char *(*)()) F226_3810;
	R3694[276] = (char *(*)()) F227_3810;
	R3694[277] = (char *(*)()) F228_3810;
	R3694[278] = (char *(*)()) F229_3810;
	R3694[279] = (char *(*)()) F230_3810;
	R3694[349] = (char *(*)()) F219_3810;
	R3694[350] = (char *(*)()) F220_3810;
	R3694[351] = (char *(*)()) F221_3810;
	R3694[352] = (char *(*)()) F222_3810;
	R3694[353] = (char *(*)()) F223_3810;
	R3694[354] = (char *(*)()) F224_3810;
	R3694[355] = (char *(*)()) F225_3810;
	R3694[356] = (char *(*)()) F226_3810;
	R3694[357] = (char *(*)()) F227_3810;
	R3694[358] = (char *(*)()) F228_3810;
	R3694[359] = (char *(*)()) F229_3810;
	R3694[360] = (char *(*)()) F230_3810;
	{long i; for (i = 366; i < 369; i++) R3694[i] = (char *(*)()) F219_3810;}
	{long i; for (i = 375; i < 378; i++) R3694[i] = (char *(*)()) F219_3810;}
	R3694[379] = (char *(*)()) F219_3810;
	R3694[382] = (char *(*)()) F219_3810;
	{long i; for (i = 384; i < 387; i++) R3694[i] = (char *(*)()) F219_3810;}
	R3694[389] = (char *(*)()) F219_3810;
	R3694[390] = (char *(*)()) F223_3810;
	R3694[391] = (char *(*)()) F219_3810;
	R3694[714] = (char *(*)()) F222_3810;
	R3694[718] = (char *(*)()) F221_3810;
}

char *(*R3695[719])();
void R3695_init () {
	R3695[0] = (char *(*)()) F224_3811_3695_252;
	R3695[268] = (char *(*)()) F219_3811;
	R3695[269] = (char *(*)()) F220_3811_3695_252;
	R3695[270] = (char *(*)()) F221_3811_3695_252;
	R3695[271] = (char *(*)()) F222_3811_3695_252;
	R3695[272] = (char *(*)()) F223_3811_3695_252;
	R3695[273] = (char *(*)()) F224_3811_3695_252;
	R3695[274] = (char *(*)()) F225_3811_3695_252;
	R3695[275] = (char *(*)()) F226_3811_3695_252;
	R3695[276] = (char *(*)()) F227_3811_3695_252;
	R3695[277] = (char *(*)()) F228_3811_3695_252;
	R3695[278] = (char *(*)()) F229_3811_3695_252;
	R3695[279] = (char *(*)()) F230_3811_3695_252;
	R3695[349] = (char *(*)()) F219_3811;
	R3695[350] = (char *(*)()) F220_3811_3695_252;
	R3695[351] = (char *(*)()) F221_3811_3695_252;
	R3695[352] = (char *(*)()) F222_3811_3695_252;
	R3695[353] = (char *(*)()) F223_3811_3695_252;
	R3695[354] = (char *(*)()) F224_3811_3695_252;
	R3695[355] = (char *(*)()) F225_3811_3695_252;
	R3695[356] = (char *(*)()) F226_3811_3695_252;
	R3695[357] = (char *(*)()) F227_3811_3695_252;
	R3695[358] = (char *(*)()) F228_3811_3695_252;
	R3695[359] = (char *(*)()) F229_3811_3695_252;
	R3695[360] = (char *(*)()) F230_3811_3695_252;
	{long i; for (i = 366; i < 369; i++) R3695[i] = (char *(*)()) F219_3811;}
	{long i; for (i = 375; i < 378; i++) R3695[i] = (char *(*)()) F219_3811;}
	R3695[379] = (char *(*)()) F219_3811;
	R3695[382] = (char *(*)()) F219_3811;
	{long i; for (i = 384; i < 387; i++) R3695[i] = (char *(*)()) F219_3811;}
	R3695[389] = (char *(*)()) F219_3811;
	R3695[390] = (char *(*)()) F223_3811_3695_252;
	R3695[391] = (char *(*)()) F219_3811;
	R3695[714] = (char *(*)()) F222_3811_3695_252;
	R3695[718] = (char *(*)()) F221_3811_3695_252;
}
static void F224_3811_3695_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F224_3811(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F220_3811_3695_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F220_3811(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}
static void F221_3811_3695_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F221_3811(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F222_3811_3695_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F222_3811(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F223_3811_3695_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F223_3811(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F225_3811_3695_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F225_3811(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F226_3811_3695_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F226_3811(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F227_3811_3695_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F227_3811(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F228_3811_3695_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F228_3811(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F229_3811_3695_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F229_3811(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F230_3811_3695_252 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F230_3811(Current, *(EIF_REAL_64 *)arg1, arg2);
}

char *(*R3701[719])();
void R3701_init () {
	R3701[0] = (char *(*)()) F224_3817;
	R3701[268] = (char *(*)()) F219_3817;
	R3701[269] = (char *(*)()) F220_3817;
	R3701[270] = (char *(*)()) F221_3817;
	R3701[271] = (char *(*)()) F222_3817;
	R3701[272] = (char *(*)()) F223_3817;
	R3701[273] = (char *(*)()) F224_3817;
	R3701[274] = (char *(*)()) F225_3817;
	R3701[275] = (char *(*)()) F226_3817;
	R3701[276] = (char *(*)()) F227_3817;
	R3701[277] = (char *(*)()) F228_3817;
	R3701[278] = (char *(*)()) F229_3817;
	R3701[279] = (char *(*)()) F230_3817;
	R3701[349] = (char *(*)()) F219_3817;
	R3701[350] = (char *(*)()) F220_3817;
	R3701[351] = (char *(*)()) F221_3817;
	R3701[352] = (char *(*)()) F222_3817;
	R3701[353] = (char *(*)()) F223_3817;
	R3701[354] = (char *(*)()) F224_3817;
	R3701[355] = (char *(*)()) F225_3817;
	R3701[356] = (char *(*)()) F226_3817;
	R3701[357] = (char *(*)()) F227_3817;
	R3701[358] = (char *(*)()) F228_3817;
	R3701[359] = (char *(*)()) F229_3817;
	R3701[360] = (char *(*)()) F230_3817;
	{long i; for (i = 366; i < 369; i++) R3701[i] = (char *(*)()) F219_3817;}
	{long i; for (i = 375; i < 378; i++) R3701[i] = (char *(*)()) F219_3817;}
	R3701[379] = (char *(*)()) F219_3817;
	R3701[382] = (char *(*)()) F219_3817;
	{long i; for (i = 384; i < 387; i++) R3701[i] = (char *(*)()) F219_3817;}
	R3701[389] = (char *(*)()) F219_3817;
	R3701[390] = (char *(*)()) F223_3817;
	R3701[391] = (char *(*)()) F219_3817;
	R3701[714] = (char *(*)()) F222_3817;
	R3701[718] = (char *(*)()) F221_3817;
}

static EIF_TYPE_INDEX Y3702_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype12[] = {886,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype13[] = {886,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype26[] = {886,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype44[] = {939,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype45[] = {939,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype46[] = {939,0xFFF9,1,865,0,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype47[] = {939,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype48[] = {939,0xFFF9,1,865,868,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype49[] = {939,0xFFF9,1,865,1063,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype50[] = {939,0xFFF9,1,865,868,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype51[] = {939,0xFFF9,1,865,1026,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype52[] = {939,0xFFF9,1,865,830,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype53[] = {939,0xFFF9,1,865,1068,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype54[] = {939,0xFFF9,1,865,999,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype55[] = {939,0xFFF9,1,865,1266,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype56[] = {939,0xFFF9,5,865,880,868,868,868,868,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype57[] = {939,0xFFF9,4,865,868,868,868,868,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype58[] = {939,0xFFF9,1,865,868,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype59[] = {939,0xFFF9,1,865,953,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype60[] = {939,0xFFF9,7,865,868,868,892,892,892,868,868,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype61[] = {939,0xFFF9,2,865,868,868,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype62[] = {939,0xFFF9,3,865,868,868,830,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype63[] = {939,0xFFF9,8,865,868,868,868,892,892,892,868,868,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype64[] = {939,0xFFF9,0,865,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype69[] = {990,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype70[] = {898,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype71[] = {898,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype72[] = {895,0xFFFF};
static EIF_TYPE_INDEX Y3702_pgtype73[] = {953,0xFFFF};
EIF_TYPE_INDEX *Y3702_gen_type [846];
EIF_TYPE_INDEX Y3702 [846];
void Y3702_init (void)
{
	egc_routines_types [3702] = Y3702;
	egc_routines_gen_types [3702] = Y3702_gen_type;
	egc_routines_offset [3702] = 218;
	Y3702_gen_type [0] = Y3702_pgtype0;
	Y3702_gen_type [1] = Y3702_pgtype1;
	Y3702_gen_type [2] = Y3702_pgtype2;
	Y3702_gen_type [3] = Y3702_pgtype3;
	Y3702_gen_type [4] = Y3702_pgtype4;
	Y3702_gen_type [5] = Y3702_pgtype5;
	Y3702_gen_type [6] = Y3702_pgtype6;
	Y3702_gen_type [7] = Y3702_pgtype7;
	Y3702_gen_type [8] = Y3702_pgtype8;
	Y3702_gen_type [9] = Y3702_pgtype9;
	Y3702_gen_type [10] = Y3702_pgtype10;
	Y3702_gen_type [11] = Y3702_pgtype11;
	Y3702_gen_type [17] = Y3702_pgtype12;
	Y3702_gen_type [18] = Y3702_pgtype13;
	Y3702_gen_type [285] = Y3702_pgtype14;
	Y3702_gen_type [286] = Y3702_pgtype15;
	Y3702_gen_type [287] = Y3702_pgtype16;
	Y3702_gen_type [288] = Y3702_pgtype17;
	Y3702_gen_type [289] = Y3702_pgtype18;
	Y3702_gen_type [290] = Y3702_pgtype19;
	Y3702_gen_type [291] = Y3702_pgtype20;
	Y3702_gen_type [292] = Y3702_pgtype21;
	Y3702_gen_type [293] = Y3702_pgtype22;
	Y3702_gen_type [294] = Y3702_pgtype23;
	Y3702_gen_type [295] = Y3702_pgtype24;
	Y3702_gen_type [296] = Y3702_pgtype25;
	Y3702_gen_type [297] = Y3702_pgtype26;
	Y3702_gen_type [366] = Y3702_pgtype27;
	Y3702_gen_type [367] = Y3702_pgtype28;
	Y3702_gen_type [368] = Y3702_pgtype29;
	Y3702_gen_type [369] = Y3702_pgtype30;
	Y3702_gen_type [370] = Y3702_pgtype31;
	Y3702_gen_type [371] = Y3702_pgtype32;
	Y3702_gen_type [372] = Y3702_pgtype33;
	Y3702_gen_type [373] = Y3702_pgtype34;
	Y3702_gen_type [374] = Y3702_pgtype35;
	Y3702_gen_type [375] = Y3702_pgtype36;
	Y3702_gen_type [376] = Y3702_pgtype37;
	Y3702_gen_type [377] = Y3702_pgtype38;
	Y3702_gen_type [378] = Y3702_pgtype39;
	Y3702_gen_type [379] = Y3702_pgtype40;
	Y3702_gen_type [380] = Y3702_pgtype41;
	Y3702_gen_type [381] = Y3702_pgtype42;
	Y3702_gen_type [382] = Y3702_pgtype43;
	Y3702_gen_type [383] = Y3702_pgtype44;
	Y3702_gen_type [384] = Y3702_pgtype45;
	Y3702_gen_type [385] = Y3702_pgtype46;
	Y3702_gen_type [386] = Y3702_pgtype47;
	Y3702_gen_type [387] = Y3702_pgtype48;
	Y3702_gen_type [388] = Y3702_pgtype49;
	Y3702_gen_type [389] = Y3702_pgtype50;
	Y3702_gen_type [390] = Y3702_pgtype51;
	Y3702_gen_type [391] = Y3702_pgtype52;
	Y3702_gen_type [392] = Y3702_pgtype53;
	Y3702_gen_type [393] = Y3702_pgtype54;
	Y3702_gen_type [394] = Y3702_pgtype55;
	Y3702_gen_type [395] = Y3702_pgtype56;
	Y3702_gen_type [396] = Y3702_pgtype57;
	Y3702_gen_type [397] = Y3702_pgtype58;
	Y3702_gen_type [398] = Y3702_pgtype59;
	Y3702_gen_type [399] = Y3702_pgtype60;
	Y3702_gen_type [400] = Y3702_pgtype61;
	Y3702_gen_type [401] = Y3702_pgtype62;
	Y3702_gen_type [402] = Y3702_pgtype63;
	Y3702_gen_type [403] = Y3702_pgtype64;
	Y3702_gen_type [404] = Y3702_pgtype65;
	Y3702_gen_type [405] = Y3702_pgtype66;
	Y3702_gen_type [406] = Y3702_pgtype67;
	Y3702_gen_type [407] = Y3702_pgtype68;
	Y3702_gen_type [408] = Y3702_pgtype69;
	Y3702_gen_type [731] = Y3702_pgtype70;
	Y3702_gen_type [732] = Y3702_pgtype71;
	Y3702_gen_type [735] = Y3702_pgtype72;
	Y3702_gen_type [845] = Y3702_pgtype73;
	{long i; for (i = 17; i < 19; i++) Y3702[i] = 886;};
	Y3702[297] = 886;
	{long i; for (i = 383; i < 404; i++) Y3702[i] = 939;};
	Y3702[408] = 990;
	{long i; for (i = 731; i < 733; i++) Y3702[i] = 898;};
	Y3702[735] = 895;
	Y3702[845] = 953;
}

char *(*R3860[702])();
void R3860_init () {
	R3860[0] = (char *(*)()) F565_4512;
	R3860[1] = (char *(*)()) F566_4512;
	R3860[2] = (char *(*)()) F567_4512;
	R3860[3] = (char *(*)()) F565_4512;
	R3860[4] = (char *(*)()) F567_4512;
	R3860[5] = (char *(*)()) F566_4512;
	R3860[6] = (char *(*)()) F565_4512;
	R3860[9] = (char *(*)()) F574_4633;
	R3860[10] = (char *(*)()) F575_4633;
	R3860[11] = (char *(*)()) F576_4633;
	R3860[12] = (char *(*)()) F577_4633;
	R3860[13] = (char *(*)()) F578_4633;
	R3860[14] = (char *(*)()) F579_4633;
	R3860[15] = (char *(*)()) F580_4633;
	R3860[16] = (char *(*)()) F574_4633;
	R3860[17] = (char *(*)()) F579_4633;
	R3860[18] = (char *(*)()) F575_4633;
	R3860[19] = (char *(*)()) F574_4633;
	R3860[20] = (char *(*)()) F585_4763;
	R3860[21] = (char *(*)()) F586_4763;
	R3860[22] = (char *(*)()) F587_4763;
	R3860[23] = (char *(*)()) F588_4763;
	R3860[24] = (char *(*)()) F589_4763;
	R3860[25] = (char *(*)()) F590_4763;
	R3860[26] = (char *(*)()) F591_4763;
	R3860[27] = (char *(*)()) F592_4763;
	R3860[28] = (char *(*)()) F593_4763;
	R3860[29] = (char *(*)()) F594_4763;
	R3860[30] = (char *(*)()) F595_4763;
	R3860[31] = (char *(*)()) F596_4763;
	{long i; for (i = 37; i < 40; i++) R3860[i] = (char *(*)()) F585_4763;}
	{long i; for (i = 46; i < 49; i++) R3860[i] = (char *(*)()) F585_4763;}
	R3860[50] = (char *(*)()) F585_4763;
	R3860[53] = (char *(*)()) F585_4763;
	{long i; for (i = 55; i < 58; i++) R3860[i] = (char *(*)()) F585_4763;}
	R3860[60] = (char *(*)()) F585_4763;
	R3860[61] = (char *(*)()) F589_4763;
	R3860[62] = (char *(*)()) F585_4763;
	R3860[144] = (char *(*)()) F709_5252;
	R3860[145] = (char *(*)()) F710_5268;
	{long i; for (i = 259; i < 261; i++) R3860[i] = (char *(*)()) F823_5729;}
	R3860[301] = (char *(*)()) F478_4321;
	{long i; for (i = 468; i < 470; i++) R3860[i] = (char *(*)()) F478_4321;}
	R3860[510] = (char *(*)()) F478_4321;
	R3860[519] = (char *(*)()) F478_4321;
	R3860[701] = (char *(*)()) F1266_12595;
}

static EIF_TYPE_INDEX Y3861_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype12[] = {949,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype13[] = {952,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype256[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype260[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype261[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype263[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype264[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype265[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype274[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype275[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype277[] = {886,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype319[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype320[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype321[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype332[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype333[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype334[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype339[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype340[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype343[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype344[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype358[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype362[] = {939,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype363[] = {939,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype364[] = {939,0xFFF9,1,865,0,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype365[] = {939,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype366[] = {939,0xFFF9,1,865,868,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype367[] = {939,0xFFF9,1,865,1063,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype368[] = {939,0xFFF9,1,865,868,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype369[] = {939,0xFFF9,1,865,1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype370[] = {939,0xFFF9,1,865,830,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype371[] = {939,0xFFF9,1,865,1068,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype372[] = {939,0xFFF9,1,865,999,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype373[] = {939,0xFFF9,1,865,1266,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype374[] = {939,0xFFF9,5,865,880,868,868,868,868,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype375[] = {939,0xFFF9,4,865,868,868,868,868,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype376[] = {939,0xFFF9,1,865,868,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype377[] = {939,0xFFF9,1,865,953,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype378[] = {939,0xFFF9,7,865,868,868,892,892,892,868,868,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype379[] = {939,0xFFF9,2,865,868,868,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype380[] = {939,0xFFF9,3,865,868,868,830,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype381[] = {939,0xFFF9,8,865,868,868,868,892,892,892,868,868,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype382[] = {939,0xFFF9,0,865,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype383[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype384[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype385[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype386[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype387[] = {990,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype400[] = {895,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype401[] = {30,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype402[] = {868,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype438[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype446[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype447[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype448[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype449[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype450[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype451[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype452[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype453[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype454[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype455[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype456[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype457[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype458[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype459[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype460[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype461[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype462[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype463[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype464[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype465[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype466[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype467[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype468[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype469[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype470[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype471[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype472[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype473[] = {898,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype474[] = {895,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype475[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype476[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype477[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype478[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype479[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype480[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype481[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype482[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype483[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype484[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype485[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype486[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype487[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype488[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype489[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype490[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype491[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype492[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype493[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype494[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype495[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype496[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype497[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype498[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype499[] = {898,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype500[] = {898,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype501[] = {898,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype502[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype503[] = {898,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype504[] = {898,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype505[] = {898,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype506[] = {898,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype507[] = {895,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype508[] = {895,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype509[] = {895,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype510[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype511[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype512[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype513[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype514[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype515[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype516[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype517[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype518[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype519[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype520[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype521[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype522[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype523[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype524[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype525[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype526[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype527[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype528[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype529[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype530[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype531[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype532[] = {953,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype533[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype534[] = {1063,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype535[] = {1064,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype536[] = {1077,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype537[] = {1077,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype538[] = {1077,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype539[] = {1077,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype540[] = {1062,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype541[] = {1062,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype542[] = {1062,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype543[] = {1068,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype544[] = {1068,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype545[] = {1068,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype546[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3861_pgtype547[] = {898,0xFFFF};
EIF_TYPE_INDEX *Y3861_gen_type [1028];
EIF_TYPE_INDEX Y3861 [1028];
void Y3861_init (void)
{
	egc_routines_types [3861] = Y3861;
	egc_routines_gen_types [3861] = Y3861_gen_type;
	egc_routines_offset [3861] = 238;
	Y3861_gen_type [0] = Y3861_pgtype0;
	Y3861_gen_type [1] = Y3861_pgtype1;
	Y3861_gen_type [2] = Y3861_pgtype2;
	Y3861_gen_type [3] = Y3861_pgtype3;
	Y3861_gen_type [4] = Y3861_pgtype4;
	Y3861_gen_type [5] = Y3861_pgtype5;
	Y3861_gen_type [6] = Y3861_pgtype6;
	Y3861_gen_type [7] = Y3861_pgtype7;
	Y3861_gen_type [8] = Y3861_pgtype8;
	Y3861_gen_type [9] = Y3861_pgtype9;
	Y3861_gen_type [10] = Y3861_pgtype10;
	Y3861_gen_type [11] = Y3861_pgtype11;
	Y3861_gen_type [12] = Y3861_pgtype12;
	Y3861_gen_type [13] = Y3861_pgtype13;
	Y3861_gen_type [14] = Y3861_pgtype14;
	Y3861_gen_type [15] = Y3861_pgtype15;
	Y3861_gen_type [16] = Y3861_pgtype16;
	Y3861_gen_type [17] = Y3861_pgtype17;
	Y3861_gen_type [18] = Y3861_pgtype18;
	Y3861_gen_type [19] = Y3861_pgtype19;
	Y3861_gen_type [20] = Y3861_pgtype20;
	Y3861_gen_type [21] = Y3861_pgtype21;
	Y3861_gen_type [22] = Y3861_pgtype22;
	Y3861_gen_type [23] = Y3861_pgtype23;
	Y3861_gen_type [24] = Y3861_pgtype24;
	Y3861_gen_type [25] = Y3861_pgtype25;
	Y3861_gen_type [26] = Y3861_pgtype26;
	Y3861_gen_type [27] = Y3861_pgtype27;
	Y3861_gen_type [28] = Y3861_pgtype28;
	Y3861_gen_type [29] = Y3861_pgtype29;
	Y3861_gen_type [30] = Y3861_pgtype30;
	Y3861_gen_type [31] = Y3861_pgtype31;
	Y3861_gen_type [32] = Y3861_pgtype32;
	Y3861_gen_type [33] = Y3861_pgtype33;
	Y3861_gen_type [34] = Y3861_pgtype34;
	Y3861_gen_type [35] = Y3861_pgtype35;
	Y3861_gen_type [36] = Y3861_pgtype36;
	Y3861_gen_type [37] = Y3861_pgtype37;
	Y3861_gen_type [38] = Y3861_pgtype38;
	Y3861_gen_type [39] = Y3861_pgtype39;
	Y3861_gen_type [40] = Y3861_pgtype40;
	Y3861_gen_type [41] = Y3861_pgtype41;
	Y3861_gen_type [42] = Y3861_pgtype42;
	Y3861_gen_type [43] = Y3861_pgtype43;
	Y3861_gen_type [44] = Y3861_pgtype44;
	Y3861_gen_type [45] = Y3861_pgtype45;
	Y3861_gen_type [46] = Y3861_pgtype46;
	Y3861_gen_type [47] = Y3861_pgtype47;
	Y3861_gen_type [48] = Y3861_pgtype48;
	Y3861_gen_type [49] = Y3861_pgtype49;
	Y3861_gen_type [50] = Y3861_pgtype50;
	Y3861_gen_type [51] = Y3861_pgtype51;
	Y3861_gen_type [52] = Y3861_pgtype52;
	Y3861_gen_type [53] = Y3861_pgtype53;
	Y3861_gen_type [54] = Y3861_pgtype54;
	Y3861_gen_type [55] = Y3861_pgtype55;
	Y3861_gen_type [56] = Y3861_pgtype56;
	Y3861_gen_type [57] = Y3861_pgtype57;
	Y3861_gen_type [58] = Y3861_pgtype58;
	Y3861_gen_type [59] = Y3861_pgtype59;
	Y3861_gen_type [60] = Y3861_pgtype60;
	Y3861_gen_type [61] = Y3861_pgtype61;
	Y3861_gen_type [62] = Y3861_pgtype62;
	Y3861_gen_type [63] = Y3861_pgtype63;
	Y3861_gen_type [64] = Y3861_pgtype64;
	Y3861_gen_type [65] = Y3861_pgtype65;
	Y3861_gen_type [66] = Y3861_pgtype66;
	Y3861_gen_type [67] = Y3861_pgtype67;
	Y3861_gen_type [68] = Y3861_pgtype68;
	Y3861_gen_type [69] = Y3861_pgtype69;
	Y3861_gen_type [70] = Y3861_pgtype70;
	Y3861_gen_type [71] = Y3861_pgtype71;
	Y3861_gen_type [72] = Y3861_pgtype72;
	Y3861_gen_type [73] = Y3861_pgtype73;
	Y3861_gen_type [74] = Y3861_pgtype74;
	Y3861_gen_type [75] = Y3861_pgtype75;
	Y3861_gen_type [76] = Y3861_pgtype76;
	Y3861_gen_type [77] = Y3861_pgtype77;
	Y3861_gen_type [78] = Y3861_pgtype78;
	Y3861_gen_type [79] = Y3861_pgtype79;
	Y3861_gen_type [80] = Y3861_pgtype80;
	Y3861_gen_type [81] = Y3861_pgtype81;
	Y3861_gen_type [82] = Y3861_pgtype82;
	Y3861_gen_type [83] = Y3861_pgtype83;
	Y3861_gen_type [84] = Y3861_pgtype84;
	Y3861_gen_type [85] = Y3861_pgtype85;
	Y3861_gen_type [86] = Y3861_pgtype86;
	Y3861_gen_type [87] = Y3861_pgtype87;
	Y3861_gen_type [88] = Y3861_pgtype88;
	Y3861_gen_type [89] = Y3861_pgtype89;
	Y3861_gen_type [90] = Y3861_pgtype90;
	Y3861_gen_type [91] = Y3861_pgtype91;
	Y3861_gen_type [92] = Y3861_pgtype92;
	Y3861_gen_type [93] = Y3861_pgtype93;
	Y3861_gen_type [94] = Y3861_pgtype94;
	Y3861_gen_type [95] = Y3861_pgtype95;
	Y3861_gen_type [96] = Y3861_pgtype96;
	Y3861_gen_type [97] = Y3861_pgtype97;
	Y3861_gen_type [98] = Y3861_pgtype98;
	Y3861_gen_type [99] = Y3861_pgtype99;
	Y3861_gen_type [100] = Y3861_pgtype100;
	Y3861_gen_type [101] = Y3861_pgtype101;
	Y3861_gen_type [102] = Y3861_pgtype102;
	Y3861_gen_type [103] = Y3861_pgtype103;
	Y3861_gen_type [104] = Y3861_pgtype104;
	Y3861_gen_type [105] = Y3861_pgtype105;
	Y3861_gen_type [106] = Y3861_pgtype106;
	Y3861_gen_type [107] = Y3861_pgtype107;
	Y3861_gen_type [108] = Y3861_pgtype108;
	Y3861_gen_type [109] = Y3861_pgtype109;
	Y3861_gen_type [110] = Y3861_pgtype110;
	Y3861_gen_type [111] = Y3861_pgtype111;
	Y3861_gen_type [112] = Y3861_pgtype112;
	Y3861_gen_type [113] = Y3861_pgtype113;
	Y3861_gen_type [114] = Y3861_pgtype114;
	Y3861_gen_type [115] = Y3861_pgtype115;
	Y3861_gen_type [116] = Y3861_pgtype116;
	Y3861_gen_type [117] = Y3861_pgtype117;
	Y3861_gen_type [118] = Y3861_pgtype118;
	Y3861_gen_type [119] = Y3861_pgtype119;
	Y3861_gen_type [120] = Y3861_pgtype120;
	Y3861_gen_type [121] = Y3861_pgtype121;
	Y3861_gen_type [122] = Y3861_pgtype122;
	Y3861_gen_type [123] = Y3861_pgtype123;
	Y3861_gen_type [124] = Y3861_pgtype124;
	Y3861_gen_type [125] = Y3861_pgtype125;
	Y3861_gen_type [126] = Y3861_pgtype126;
	Y3861_gen_type [127] = Y3861_pgtype127;
	Y3861_gen_type [128] = Y3861_pgtype128;
	Y3861_gen_type [129] = Y3861_pgtype129;
	Y3861_gen_type [130] = Y3861_pgtype130;
	Y3861_gen_type [131] = Y3861_pgtype131;
	Y3861_gen_type [132] = Y3861_pgtype132;
	Y3861_gen_type [133] = Y3861_pgtype133;
	Y3861_gen_type [134] = Y3861_pgtype134;
	Y3861_gen_type [135] = Y3861_pgtype135;
	Y3861_gen_type [136] = Y3861_pgtype136;
	Y3861_gen_type [137] = Y3861_pgtype137;
	Y3861_gen_type [138] = Y3861_pgtype138;
	Y3861_gen_type [139] = Y3861_pgtype139;
	Y3861_gen_type [140] = Y3861_pgtype140;
	Y3861_gen_type [141] = Y3861_pgtype141;
	Y3861_gen_type [142] = Y3861_pgtype142;
	Y3861_gen_type [143] = Y3861_pgtype143;
	Y3861_gen_type [144] = Y3861_pgtype144;
	Y3861_gen_type [145] = Y3861_pgtype145;
	Y3861_gen_type [146] = Y3861_pgtype146;
	Y3861_gen_type [147] = Y3861_pgtype147;
	Y3861_gen_type [148] = Y3861_pgtype148;
	Y3861_gen_type [149] = Y3861_pgtype149;
	Y3861_gen_type [150] = Y3861_pgtype150;
	Y3861_gen_type [151] = Y3861_pgtype151;
	Y3861_gen_type [152] = Y3861_pgtype152;
	Y3861_gen_type [153] = Y3861_pgtype153;
	Y3861_gen_type [154] = Y3861_pgtype154;
	Y3861_gen_type [155] = Y3861_pgtype155;
	Y3861_gen_type [156] = Y3861_pgtype156;
	Y3861_gen_type [157] = Y3861_pgtype157;
	Y3861_gen_type [158] = Y3861_pgtype158;
	Y3861_gen_type [159] = Y3861_pgtype159;
	Y3861_gen_type [160] = Y3861_pgtype160;
	Y3861_gen_type [161] = Y3861_pgtype161;
	Y3861_gen_type [162] = Y3861_pgtype162;
	Y3861_gen_type [163] = Y3861_pgtype163;
	Y3861_gen_type [164] = Y3861_pgtype164;
	Y3861_gen_type [165] = Y3861_pgtype165;
	Y3861_gen_type [166] = Y3861_pgtype166;
	Y3861_gen_type [167] = Y3861_pgtype167;
	Y3861_gen_type [168] = Y3861_pgtype168;
	Y3861_gen_type [169] = Y3861_pgtype169;
	Y3861_gen_type [170] = Y3861_pgtype170;
	Y3861_gen_type [171] = Y3861_pgtype171;
	Y3861_gen_type [172] = Y3861_pgtype172;
	Y3861_gen_type [173] = Y3861_pgtype173;
	Y3861_gen_type [174] = Y3861_pgtype174;
	Y3861_gen_type [175] = Y3861_pgtype175;
	Y3861_gen_type [176] = Y3861_pgtype176;
	Y3861_gen_type [177] = Y3861_pgtype177;
	Y3861_gen_type [178] = Y3861_pgtype178;
	Y3861_gen_type [179] = Y3861_pgtype179;
	Y3861_gen_type [180] = Y3861_pgtype180;
	Y3861_gen_type [181] = Y3861_pgtype181;
	Y3861_gen_type [182] = Y3861_pgtype182;
	Y3861_gen_type [183] = Y3861_pgtype183;
	Y3861_gen_type [184] = Y3861_pgtype184;
	Y3861_gen_type [185] = Y3861_pgtype185;
	Y3861_gen_type [186] = Y3861_pgtype186;
	Y3861_gen_type [187] = Y3861_pgtype187;
	Y3861_gen_type [188] = Y3861_pgtype188;
	Y3861_gen_type [189] = Y3861_pgtype189;
	Y3861_gen_type [190] = Y3861_pgtype190;
	Y3861_gen_type [191] = Y3861_pgtype191;
	Y3861_gen_type [192] = Y3861_pgtype192;
	Y3861_gen_type [193] = Y3861_pgtype193;
	Y3861_gen_type [194] = Y3861_pgtype194;
	Y3861_gen_type [195] = Y3861_pgtype195;
	Y3861_gen_type [196] = Y3861_pgtype196;
	Y3861_gen_type [197] = Y3861_pgtype197;
	Y3861_gen_type [198] = Y3861_pgtype198;
	Y3861_gen_type [199] = Y3861_pgtype199;
	Y3861_gen_type [200] = Y3861_pgtype200;
	Y3861_gen_type [201] = Y3861_pgtype201;
	Y3861_gen_type [202] = Y3861_pgtype202;
	Y3861_gen_type [203] = Y3861_pgtype203;
	Y3861_gen_type [204] = Y3861_pgtype204;
	Y3861_gen_type [205] = Y3861_pgtype205;
	Y3861_gen_type [206] = Y3861_pgtype206;
	Y3861_gen_type [207] = Y3861_pgtype207;
	Y3861_gen_type [208] = Y3861_pgtype208;
	Y3861_gen_type [209] = Y3861_pgtype209;
	Y3861_gen_type [210] = Y3861_pgtype210;
	Y3861_gen_type [211] = Y3861_pgtype211;
	Y3861_gen_type [212] = Y3861_pgtype212;
	Y3861_gen_type [213] = Y3861_pgtype213;
	Y3861_gen_type [214] = Y3861_pgtype214;
	Y3861_gen_type [215] = Y3861_pgtype215;
	Y3861_gen_type [216] = Y3861_pgtype216;
	Y3861_gen_type [217] = Y3861_pgtype217;
	Y3861_gen_type [218] = Y3861_pgtype218;
	Y3861_gen_type [219] = Y3861_pgtype219;
	Y3861_gen_type [220] = Y3861_pgtype220;
	Y3861_gen_type [221] = Y3861_pgtype221;
	Y3861_gen_type [222] = Y3861_pgtype222;
	Y3861_gen_type [223] = Y3861_pgtype223;
	Y3861_gen_type [224] = Y3861_pgtype224;
	Y3861_gen_type [225] = Y3861_pgtype225;
	Y3861_gen_type [226] = Y3861_pgtype226;
	Y3861_gen_type [227] = Y3861_pgtype227;
	Y3861_gen_type [228] = Y3861_pgtype228;
	Y3861_gen_type [229] = Y3861_pgtype229;
	Y3861_gen_type [230] = Y3861_pgtype230;
	Y3861_gen_type [231] = Y3861_pgtype231;
	Y3861_gen_type [232] = Y3861_pgtype232;
	Y3861_gen_type [233] = Y3861_pgtype233;
	Y3861_gen_type [234] = Y3861_pgtype234;
	Y3861_gen_type [235] = Y3861_pgtype235;
	Y3861_gen_type [236] = Y3861_pgtype236;
	Y3861_gen_type [237] = Y3861_pgtype237;
	Y3861_gen_type [238] = Y3861_pgtype238;
	Y3861_gen_type [239] = Y3861_pgtype239;
	Y3861_gen_type [240] = Y3861_pgtype240;
	Y3861_gen_type [241] = Y3861_pgtype241;
	Y3861_gen_type [242] = Y3861_pgtype242;
	Y3861_gen_type [243] = Y3861_pgtype243;
	Y3861_gen_type [244] = Y3861_pgtype244;
	Y3861_gen_type [245] = Y3861_pgtype245;
	Y3861_gen_type [246] = Y3861_pgtype246;
	Y3861_gen_type [247] = Y3861_pgtype247;
	Y3861_gen_type [248] = Y3861_pgtype248;
	Y3861_gen_type [249] = Y3861_pgtype249;
	Y3861_gen_type [250] = Y3861_pgtype250;
	Y3861_gen_type [251] = Y3861_pgtype251;
	Y3861_gen_type [252] = Y3861_pgtype252;
	Y3861_gen_type [253] = Y3861_pgtype253;
	Y3861_gen_type [254] = Y3861_pgtype254;
	Y3861_gen_type [255] = Y3861_pgtype255;
	Y3861_gen_type [256] = Y3861_pgtype256;
	Y3861_gen_type [257] = Y3861_pgtype257;
	Y3861_gen_type [258] = Y3861_pgtype258;
	Y3861_gen_type [259] = Y3861_pgtype259;
	Y3861_gen_type [260] = Y3861_pgtype260;
	Y3861_gen_type [261] = Y3861_pgtype261;
	Y3861_gen_type [262] = Y3861_pgtype262;
	Y3861_gen_type [263] = Y3861_pgtype263;
	Y3861_gen_type [264] = Y3861_pgtype264;
	Y3861_gen_type [265] = Y3861_pgtype265;
	Y3861_gen_type [266] = Y3861_pgtype266;
	Y3861_gen_type [267] = Y3861_pgtype267;
	Y3861_gen_type [268] = Y3861_pgtype268;
	Y3861_gen_type [269] = Y3861_pgtype269;
	Y3861_gen_type [270] = Y3861_pgtype270;
	Y3861_gen_type [271] = Y3861_pgtype271;
	Y3861_gen_type [272] = Y3861_pgtype272;
	Y3861_gen_type [273] = Y3861_pgtype273;
	Y3861_gen_type [274] = Y3861_pgtype274;
	Y3861_gen_type [275] = Y3861_pgtype275;
	Y3861_gen_type [276] = Y3861_pgtype276;
	Y3861_gen_type [277] = Y3861_pgtype277;
	Y3861_gen_type [278] = Y3861_pgtype278;
	Y3861_gen_type [279] = Y3861_pgtype279;
	Y3861_gen_type [280] = Y3861_pgtype280;
	Y3861_gen_type [281] = Y3861_pgtype281;
	Y3861_gen_type [282] = Y3861_pgtype282;
	Y3861_gen_type [283] = Y3861_pgtype283;
	Y3861_gen_type [284] = Y3861_pgtype284;
	Y3861_gen_type [285] = Y3861_pgtype285;
	Y3861_gen_type [286] = Y3861_pgtype286;
	Y3861_gen_type [287] = Y3861_pgtype287;
	Y3861_gen_type [288] = Y3861_pgtype288;
	Y3861_gen_type [289] = Y3861_pgtype289;
	Y3861_gen_type [290] = Y3861_pgtype290;
	Y3861_gen_type [291] = Y3861_pgtype291;
	Y3861_gen_type [292] = Y3861_pgtype292;
	Y3861_gen_type [293] = Y3861_pgtype293;
	Y3861_gen_type [294] = Y3861_pgtype294;
	Y3861_gen_type [295] = Y3861_pgtype295;
	Y3861_gen_type [296] = Y3861_pgtype296;
	Y3861_gen_type [297] = Y3861_pgtype297;
	Y3861_gen_type [298] = Y3861_pgtype298;
	Y3861_gen_type [299] = Y3861_pgtype299;
	Y3861_gen_type [300] = Y3861_pgtype300;
	Y3861_gen_type [301] = Y3861_pgtype301;
	Y3861_gen_type [302] = Y3861_pgtype302;
	Y3861_gen_type [303] = Y3861_pgtype303;
	Y3861_gen_type [304] = Y3861_pgtype304;
	Y3861_gen_type [305] = Y3861_pgtype305;
	Y3861_gen_type [306] = Y3861_pgtype306;
	Y3861_gen_type [307] = Y3861_pgtype307;
	Y3861_gen_type [308] = Y3861_pgtype308;
	Y3861_gen_type [309] = Y3861_pgtype309;
	Y3861_gen_type [310] = Y3861_pgtype310;
	Y3861_gen_type [311] = Y3861_pgtype311;
	Y3861_gen_type [312] = Y3861_pgtype312;
	Y3861_gen_type [313] = Y3861_pgtype313;
	Y3861_gen_type [314] = Y3861_pgtype314;
	Y3861_gen_type [315] = Y3861_pgtype315;
	Y3861_gen_type [316] = Y3861_pgtype316;
	Y3861_gen_type [317] = Y3861_pgtype317;
	Y3861_gen_type [318] = Y3861_pgtype318;
	Y3861_gen_type [319] = Y3861_pgtype319;
	Y3861_gen_type [320] = Y3861_pgtype320;
	Y3861_gen_type [321] = Y3861_pgtype321;
	Y3861_gen_type [322] = Y3861_pgtype322;
	Y3861_gen_type [323] = Y3861_pgtype323;
	Y3861_gen_type [324] = Y3861_pgtype324;
	Y3861_gen_type [325] = Y3861_pgtype325;
	Y3861_gen_type [326] = Y3861_pgtype326;
	Y3861_gen_type [327] = Y3861_pgtype327;
	Y3861_gen_type [328] = Y3861_pgtype328;
	Y3861_gen_type [329] = Y3861_pgtype329;
	Y3861_gen_type [330] = Y3861_pgtype330;
	Y3861_gen_type [331] = Y3861_pgtype331;
	Y3861_gen_type [332] = Y3861_pgtype332;
	Y3861_gen_type [334] = Y3861_pgtype333;
	Y3861_gen_type [335] = Y3861_pgtype334;
	Y3861_gen_type [336] = Y3861_pgtype335;
	Y3861_gen_type [337] = Y3861_pgtype336;
	Y3861_gen_type [338] = Y3861_pgtype337;
	Y3861_gen_type [339] = Y3861_pgtype338;
	Y3861_gen_type [340] = Y3861_pgtype339;
	Y3861_gen_type [341] = Y3861_pgtype340;
	Y3861_gen_type [342] = Y3861_pgtype341;
	Y3861_gen_type [343] = Y3861_pgtype342;
	Y3861_gen_type [344] = Y3861_pgtype343;
	Y3861_gen_type [345] = Y3861_pgtype344;
	Y3861_gen_type [346] = Y3861_pgtype345;
	Y3861_gen_type [347] = Y3861_pgtype346;
	Y3861_gen_type [348] = Y3861_pgtype347;
	Y3861_gen_type [349] = Y3861_pgtype348;
	Y3861_gen_type [350] = Y3861_pgtype349;
	Y3861_gen_type [351] = Y3861_pgtype350;
	Y3861_gen_type [352] = Y3861_pgtype351;
	Y3861_gen_type [353] = Y3861_pgtype352;
	Y3861_gen_type [354] = Y3861_pgtype353;
	Y3861_gen_type [355] = Y3861_pgtype354;
	Y3861_gen_type [356] = Y3861_pgtype355;
	Y3861_gen_type [357] = Y3861_pgtype356;
	Y3861_gen_type [358] = Y3861_pgtype357;
	Y3861_gen_type [359] = Y3861_pgtype358;
	Y3861_gen_type [360] = Y3861_pgtype359;
	Y3861_gen_type [361] = Y3861_pgtype360;
	Y3861_gen_type [362] = Y3861_pgtype361;
	Y3861_gen_type [363] = Y3861_pgtype362;
	Y3861_gen_type [364] = Y3861_pgtype363;
	Y3861_gen_type [365] = Y3861_pgtype364;
	Y3861_gen_type [366] = Y3861_pgtype365;
	Y3861_gen_type [367] = Y3861_pgtype366;
	Y3861_gen_type [368] = Y3861_pgtype367;
	Y3861_gen_type [369] = Y3861_pgtype368;
	Y3861_gen_type [370] = Y3861_pgtype369;
	Y3861_gen_type [371] = Y3861_pgtype370;
	Y3861_gen_type [372] = Y3861_pgtype371;
	Y3861_gen_type [373] = Y3861_pgtype372;
	Y3861_gen_type [374] = Y3861_pgtype373;
	Y3861_gen_type [375] = Y3861_pgtype374;
	Y3861_gen_type [376] = Y3861_pgtype375;
	Y3861_gen_type [377] = Y3861_pgtype376;
	Y3861_gen_type [378] = Y3861_pgtype377;
	Y3861_gen_type [379] = Y3861_pgtype378;
	Y3861_gen_type [380] = Y3861_pgtype379;
	Y3861_gen_type [381] = Y3861_pgtype380;
	Y3861_gen_type [382] = Y3861_pgtype381;
	Y3861_gen_type [383] = Y3861_pgtype382;
	Y3861_gen_type [384] = Y3861_pgtype383;
	Y3861_gen_type [385] = Y3861_pgtype384;
	Y3861_gen_type [386] = Y3861_pgtype385;
	Y3861_gen_type [387] = Y3861_pgtype386;
	Y3861_gen_type [388] = Y3861_pgtype387;
	Y3861_gen_type [394] = Y3861_pgtype388;
	Y3861_gen_type [395] = Y3861_pgtype389;
	Y3861_gen_type [396] = Y3861_pgtype390;
	Y3861_gen_type [397] = Y3861_pgtype391;
	Y3861_gen_type [398] = Y3861_pgtype392;
	Y3861_gen_type [399] = Y3861_pgtype393;
	Y3861_gen_type [400] = Y3861_pgtype394;
	Y3861_gen_type [401] = Y3861_pgtype395;
	Y3861_gen_type [402] = Y3861_pgtype396;
	Y3861_gen_type [403] = Y3861_pgtype397;
	Y3861_gen_type [404] = Y3861_pgtype398;
	Y3861_gen_type [405] = Y3861_pgtype399;
	Y3861_gen_type [469] = Y3861_pgtype400;
	Y3861_gen_type [470] = Y3861_pgtype401;
	Y3861_gen_type [471] = Y3861_pgtype402;
	Y3861_gen_type [479] = Y3861_pgtype403;
	Y3861_gen_type [480] = Y3861_pgtype404;
	Y3861_gen_type [481] = Y3861_pgtype405;
	Y3861_gen_type [482] = Y3861_pgtype406;
	Y3861_gen_type [483] = Y3861_pgtype407;
	Y3861_gen_type [484] = Y3861_pgtype408;
	Y3861_gen_type [485] = Y3861_pgtype409;
	Y3861_gen_type [486] = Y3861_pgtype410;
	Y3861_gen_type [487] = Y3861_pgtype411;
	Y3861_gen_type [488] = Y3861_pgtype412;
	Y3861_gen_type [489] = Y3861_pgtype413;
	Y3861_gen_type [490] = Y3861_pgtype414;
	Y3861_gen_type [491] = Y3861_pgtype415;
	Y3861_gen_type [492] = Y3861_pgtype416;
	Y3861_gen_type [493] = Y3861_pgtype417;
	Y3861_gen_type [494] = Y3861_pgtype418;
	Y3861_gen_type [495] = Y3861_pgtype419;
	Y3861_gen_type [496] = Y3861_pgtype420;
	Y3861_gen_type [497] = Y3861_pgtype421;
	Y3861_gen_type [498] = Y3861_pgtype422;
	Y3861_gen_type [499] = Y3861_pgtype423;
	Y3861_gen_type [500] = Y3861_pgtype424;
	Y3861_gen_type [501] = Y3861_pgtype425;
	Y3861_gen_type [502] = Y3861_pgtype426;
	Y3861_gen_type [503] = Y3861_pgtype427;
	Y3861_gen_type [504] = Y3861_pgtype428;
	Y3861_gen_type [505] = Y3861_pgtype429;
	Y3861_gen_type [506] = Y3861_pgtype430;
	Y3861_gen_type [507] = Y3861_pgtype431;
	Y3861_gen_type [508] = Y3861_pgtype432;
	Y3861_gen_type [509] = Y3861_pgtype433;
	Y3861_gen_type [510] = Y3861_pgtype434;
	Y3861_gen_type [511] = Y3861_pgtype435;
	Y3861_gen_type [512] = Y3861_pgtype436;
	Y3861_gen_type [513] = Y3861_pgtype437;
	Y3861_gen_type [514] = Y3861_pgtype438;
	Y3861_gen_type [515] = Y3861_pgtype439;
	Y3861_gen_type [516] = Y3861_pgtype440;
	Y3861_gen_type [517] = Y3861_pgtype441;
	Y3861_gen_type [518] = Y3861_pgtype442;
	Y3861_gen_type [519] = Y3861_pgtype443;
	Y3861_gen_type [520] = Y3861_pgtype444;
	Y3861_gen_type [521] = Y3861_pgtype445;
	Y3861_gen_type [522] = Y3861_pgtype446;
	Y3861_gen_type [523] = Y3861_pgtype447;
	Y3861_gen_type [524] = Y3861_pgtype448;
	Y3861_gen_type [525] = Y3861_pgtype449;
	Y3861_gen_type [526] = Y3861_pgtype450;
	Y3861_gen_type [527] = Y3861_pgtype451;
	Y3861_gen_type [528] = Y3861_pgtype452;
	Y3861_gen_type [529] = Y3861_pgtype453;
	Y3861_gen_type [530] = Y3861_pgtype454;
	Y3861_gen_type [531] = Y3861_pgtype455;
	Y3861_gen_type [532] = Y3861_pgtype456;
	Y3861_gen_type [533] = Y3861_pgtype457;
	Y3861_gen_type [534] = Y3861_pgtype458;
	Y3861_gen_type [535] = Y3861_pgtype459;
	Y3861_gen_type [536] = Y3861_pgtype460;
	Y3861_gen_type [537] = Y3861_pgtype461;
	Y3861_gen_type [538] = Y3861_pgtype462;
	Y3861_gen_type [539] = Y3861_pgtype463;
	Y3861_gen_type [540] = Y3861_pgtype464;
	Y3861_gen_type [541] = Y3861_pgtype465;
	Y3861_gen_type [542] = Y3861_pgtype466;
	Y3861_gen_type [543] = Y3861_pgtype467;
	Y3861_gen_type [544] = Y3861_pgtype468;
	Y3861_gen_type [545] = Y3861_pgtype469;
	Y3861_gen_type [546] = Y3861_pgtype470;
	Y3861_gen_type [547] = Y3861_pgtype471;
	Y3861_gen_type [548] = Y3861_pgtype472;
	Y3861_gen_type [549] = Y3861_pgtype473;
	Y3861_gen_type [550] = Y3861_pgtype474;
	Y3861_gen_type [551] = Y3861_pgtype475;
	Y3861_gen_type [552] = Y3861_pgtype476;
	Y3861_gen_type [553] = Y3861_pgtype477;
	Y3861_gen_type [554] = Y3861_pgtype478;
	Y3861_gen_type [555] = Y3861_pgtype479;
	Y3861_gen_type [556] = Y3861_pgtype480;
	Y3861_gen_type [557] = Y3861_pgtype481;
	Y3861_gen_type [558] = Y3861_pgtype482;
	Y3861_gen_type [559] = Y3861_pgtype483;
	Y3861_gen_type [560] = Y3861_pgtype484;
	Y3861_gen_type [561] = Y3861_pgtype485;
	Y3861_gen_type [562] = Y3861_pgtype486;
	Y3861_gen_type [563] = Y3861_pgtype487;
	Y3861_gen_type [564] = Y3861_pgtype488;
	Y3861_gen_type [565] = Y3861_pgtype489;
	Y3861_gen_type [566] = Y3861_pgtype490;
	Y3861_gen_type [567] = Y3861_pgtype491;
	Y3861_gen_type [568] = Y3861_pgtype492;
	Y3861_gen_type [569] = Y3861_pgtype493;
	Y3861_gen_type [570] = Y3861_pgtype494;
	Y3861_gen_type [571] = Y3861_pgtype495;
	Y3861_gen_type [572] = Y3861_pgtype496;
	Y3861_gen_type [573] = Y3861_pgtype497;
	Y3861_gen_type [574] = Y3861_pgtype498;
	Y3861_gen_type [584] = Y3861_pgtype499;
	Y3861_gen_type [585] = Y3861_pgtype500;
	Y3861_gen_type [586] = Y3861_pgtype501;
	Y3861_gen_type [627] = Y3861_pgtype502;
	Y3861_gen_type [709] = Y3861_pgtype503;
	Y3861_gen_type [710] = Y3861_pgtype504;
	Y3861_gen_type [711] = Y3861_pgtype505;
	Y3861_gen_type [712] = Y3861_pgtype506;
	Y3861_gen_type [713] = Y3861_pgtype507;
	Y3861_gen_type [714] = Y3861_pgtype508;
	Y3861_gen_type [715] = Y3861_pgtype509;
	Y3861_gen_type [786] = Y3861_pgtype510;
	Y3861_gen_type [789] = Y3861_pgtype511;
	Y3861_gen_type [790] = Y3861_pgtype512;
	Y3861_gen_type [791] = Y3861_pgtype513;
	Y3861_gen_type [792] = Y3861_pgtype514;
	Y3861_gen_type [793] = Y3861_pgtype515;
	Y3861_gen_type [794] = Y3861_pgtype516;
	Y3861_gen_type [795] = Y3861_pgtype517;
	Y3861_gen_type [796] = Y3861_pgtype518;
	Y3861_gen_type [797] = Y3861_pgtype519;
	Y3861_gen_type [798] = Y3861_pgtype520;
	Y3861_gen_type [799] = Y3861_pgtype521;
	Y3861_gen_type [800] = Y3861_pgtype522;
	Y3861_gen_type [801] = Y3861_pgtype523;
	Y3861_gen_type [802] = Y3861_pgtype524;
	Y3861_gen_type [803] = Y3861_pgtype525;
	Y3861_gen_type [804] = Y3861_pgtype526;
	Y3861_gen_type [805] = Y3861_pgtype527;
	Y3861_gen_type [806] = Y3861_pgtype528;
	Y3861_gen_type [807] = Y3861_pgtype529;
	Y3861_gen_type [808] = Y3861_pgtype530;
	Y3861_gen_type [809] = Y3861_pgtype531;
	Y3861_gen_type [825] = Y3861_pgtype532;
	Y3861_gen_type [834] = Y3861_pgtype533;
	Y3861_gen_type [835] = Y3861_pgtype534;
	Y3861_gen_type [836] = Y3861_pgtype535;
	Y3861_gen_type [837] = Y3861_pgtype536;
	Y3861_gen_type [838] = Y3861_pgtype537;
	Y3861_gen_type [839] = Y3861_pgtype538;
	Y3861_gen_type [840] = Y3861_pgtype539;
	Y3861_gen_type [841] = Y3861_pgtype540;
	Y3861_gen_type [842] = Y3861_pgtype541;
	Y3861_gen_type [843] = Y3861_pgtype542;
	Y3861_gen_type [844] = Y3861_pgtype543;
	Y3861_gen_type [845] = Y3861_pgtype544;
	Y3861_gen_type [846] = Y3861_pgtype545;
	Y3861_gen_type [1026] = Y3861_pgtype546;
	Y3861_gen_type [1027] = Y3861_pgtype547;
	Y3861[12] = 949;
	Y3861[13] = 952;
	{long i; for (i = 263; i < 265; i++) Y3861[i] = 868;};
	Y3861[277] = 886;
	Y3861[345] = 0;
	{long i; for (i = 363; i < 384; i++) Y3861[i] = 939;};
	Y3861[388] = 990;
	Y3861[469] = 895;
	Y3861[470] = 30;
	Y3861[471] = 868;
	Y3861[549] = 898;
	Y3861[550] = 895;
	{long i; for (i = 584; i < 587; i++) Y3861[i] = 898;};
	Y3861[627] = 0;
	{long i; for (i = 709; i < 713; i++) Y3861[i] = 898;};
	{long i; for (i = 713; i < 716; i++) Y3861[i] = 895;};
	{long i; for (i = 789; i < 810; i++) Y3861[i] = 1026;};
	Y3861[825] = 953;
	Y3861[835] = 1063;
	Y3861[836] = 1064;
	{long i; for (i = 837; i < 841; i++) Y3861[i] = 1077;};
	{long i; for (i = 841; i < 844; i++) Y3861[i] = 1062;};
	{long i; for (i = 844; i < 847; i++) Y3861[i] = 1068;};
	Y3861[1027] = 898;
}

char *(*R3906[763])();
void R3906_init () {
	R3906[0] = (char *(*)()) F504_4383;
	R3906[1] = (char *(*)()) F505_4383_3906_2;
	R3906[2] = (char *(*)()) F506_4383_3906_2;
	R3906[3] = (char *(*)()) F507_4383_3906_2;
	R3906[4] = (char *(*)()) F508_4383_3906_2;
	R3906[5] = (char *(*)()) F509_4383_3906_2;
	R3906[6] = (char *(*)()) F510_4383_3906_2;
	R3906[7] = (char *(*)()) F511_4383_3906_2;
	R3906[8] = (char *(*)()) F512_4383_3906_2;
	R3906[9] = (char *(*)()) F513_4383_3906_2;
	R3906[10] = (char *(*)()) F514_4383_3906_2;
	R3906[11] = (char *(*)()) F515_4383_3906_2;
	R3906[61] = (char *(*)()) F517_4457;
	R3906[62] = (char *(*)()) F521_4457_3906_2;
	R3906[63] = (char *(*)()) F526_4457_3906_2;
	R3906[64] = (char *(*)()) F517_4457;
	R3906[65] = (char *(*)()) F526_4457_3906_2;
	R3906[66] = (char *(*)()) F521_4457_3906_2;
	R3906[67] = (char *(*)()) F517_4457;
	R3906[70] = (char *(*)()) F574_4628;
	R3906[71] = (char *(*)()) F575_4628_3906_2;
	R3906[72] = (char *(*)()) F576_4628_3906_2;
	R3906[73] = (char *(*)()) F577_4628_3906_2;
	R3906[74] = (char *(*)()) F578_4628;
	R3906[75] = (char *(*)()) F579_4628_3906_2;
	R3906[76] = (char *(*)()) F580_4628_3906_2;
	R3906[77] = (char *(*)()) F574_4628;
	R3906[78] = (char *(*)()) F579_4628_3906_2;
	R3906[79] = (char *(*)()) F575_4628_3906_2;
	R3906[80] = (char *(*)()) F574_4628;
	R3906[81] = (char *(*)()) F585_4761;
	R3906[82] = (char *(*)()) F586_4761_3906_2;
	R3906[83] = (char *(*)()) F587_4761_3906_2;
	R3906[84] = (char *(*)()) F588_4761_3906_2;
	R3906[85] = (char *(*)()) F589_4761_3906_2;
	R3906[86] = (char *(*)()) F590_4761_3906_2;
	R3906[87] = (char *(*)()) F591_4761_3906_2;
	R3906[88] = (char *(*)()) F592_4761_3906_2;
	R3906[89] = (char *(*)()) F593_4761_3906_2;
	R3906[90] = (char *(*)()) F594_4761_3906_2;
	R3906[91] = (char *(*)()) F595_4761_3906_2;
	R3906[92] = (char *(*)()) F596_4761_3906_2;
	{long i; for (i = 98; i < 101; i++) R3906[i] = (char *(*)()) F585_4761;}
	{long i; for (i = 107; i < 110; i++) R3906[i] = (char *(*)()) F585_4761;}
	R3906[111] = (char *(*)()) F585_4761;
	R3906[114] = (char *(*)()) F585_4761;
	{long i; for (i = 116; i < 119; i++) R3906[i] = (char *(*)()) F585_4761;}
	R3906[121] = (char *(*)()) F585_4761;
	R3906[122] = (char *(*)()) F589_4761_3906_2;
	R3906[123] = (char *(*)()) F585_4761;
	R3906[205] = (char *(*)()) F287_4183;
	R3906[206] = (char *(*)()) F710_5266_3906_2;
	{long i; for (i = 320; i < 322; i++) R3906[i] = (char *(*)()) F289_4183_3906_2;}
	R3906[446] = (char *(*)()) F948_7617_3906_2;
	R3906[450] = (char *(*)()) F952_7782_3906_2;
	{long i; for (i = 529; i < 531; i++) R3906[i] = (char *(*)()) F517_4457;}
	{long i; for (i = 531; i < 533; i++) R3906[i] = (char *(*)()) F1035_8773;}
	R3906[534] = (char *(*)()) F1035_8773;
	R3906[535] = (char *(*)()) F1039_8828;
	{long i; for (i = 538; i < 542; i++) R3906[i] = (char *(*)()) F1039_8828;}
	{long i; for (i = 543; i < 545; i++) R3906[i] = (char *(*)()) F1039_8828;}
	R3906[571] = (char *(*)()) F517_4457;
	R3906[580] = (char *(*)()) F517_4457;
	R3906[762] = (char *(*)()) F289_4183_3906_2;
}
static EIF_BOOLEAN F505_4383_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F505_4383(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F506_4383_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F506_4383(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F507_4383_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F507_4383(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F508_4383_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F508_4383(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F509_4383_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F509_4383(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F510_4383_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F510_4383(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F511_4383_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F511_4383(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F512_4383_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F512_4383(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F513_4383_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F513_4383(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F514_4383_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F514_4383(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F515_4383_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F515_4383(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F521_4457_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F521_4457(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F526_4457_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F526_4457(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F575_4628_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F575_4628(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F576_4628_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F576_4628(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F577_4628_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F577_4628(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F579_4628_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F579_4628(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F580_4628_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F580_4628(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F586_4761_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F586_4761(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F587_4761_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F587_4761(Current, *(EIF_CHARACTER_32 *)arg1);
}
static EIF_BOOLEAN F588_4761_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F588_4761(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F589_4761_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F589_4761(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F590_4761_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F590_4761(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F591_4761_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F591_4761(Current, *(EIF_POINTER *)arg1);
}
static EIF_BOOLEAN F592_4761_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F592_4761(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F593_4761_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F593_4761(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F594_4761_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F594_4761(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F595_4761_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F595_4761(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F596_4761_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F596_4761(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F710_5266_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F710_5266(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F289_4183_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F289_4183(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F948_7617_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F948_7617(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F952_7782_3906_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F952_7782(Current, *(EIF_CHARACTER_32 *)arg1);
}

char *(*R3907[993])();
void R3907_init () {
	R3907[0] = (char *(*)()) F272_4058;
	R3907[230] = (char *(*)()) F409_4259;
	R3907[231] = (char *(*)()) F412_4259;
	R3907[232] = (char *(*)()) F410_4259;
	R3907[233] = (char *(*)()) F411_4259;
	R3907[234] = (char *(*)()) F414_4259;
	R3907[235] = (char *(*)()) F413_4259;
	R3907[236] = (char *(*)()) F415_4259;
	R3907[237] = (char *(*)()) F416_4259;
	R3907[238] = (char *(*)()) F417_4259;
	R3907[239] = (char *(*)()) F418_4259;
	R3907[240] = (char *(*)()) F419_4259;
	R3907[241] = (char *(*)()) F420_4259;
	R3907[291] = (char *(*)()) F409_4259;
	R3907[292] = (char *(*)()) F414_4259;
	R3907[293] = (char *(*)()) F418_4259;
	R3907[294] = (char *(*)()) F409_4259;
	R3907[295] = (char *(*)()) F418_4259;
	R3907[296] = (char *(*)()) F414_4259;
	R3907[297] = (char *(*)()) F409_4259;
	R3907[300] = (char *(*)()) F409_4259;
	{long i; for (i = 301; i < 303; i++) R3907[i] = (char *(*)()) F414_4259;}
	R3907[303] = (char *(*)()) F415_4259;
	R3907[304] = (char *(*)()) F409_4259;
	R3907[305] = (char *(*)()) F418_4259;
	R3907[306] = (char *(*)()) F414_4259;
	R3907[307] = (char *(*)()) F409_4259;
	R3907[308] = (char *(*)()) F418_4259;
	R3907[309] = (char *(*)()) F414_4259;
	{long i; for (i = 310; i < 312; i++) R3907[i] = (char *(*)()) F409_4259;}
	R3907[312] = (char *(*)()) F412_4259;
	R3907[313] = (char *(*)()) F410_4259;
	R3907[314] = (char *(*)()) F411_4259;
	R3907[315] = (char *(*)()) F414_4259;
	R3907[316] = (char *(*)()) F413_4259;
	R3907[317] = (char *(*)()) F415_4259;
	R3907[318] = (char *(*)()) F416_4259;
	R3907[319] = (char *(*)()) F417_4259;
	R3907[320] = (char *(*)()) F418_4259;
	R3907[321] = (char *(*)()) F419_4259;
	R3907[322] = (char *(*)()) F420_4259;
	{long i; for (i = 328; i < 331; i++) R3907[i] = (char *(*)()) F409_4259;}
	{long i; for (i = 337; i < 340; i++) R3907[i] = (char *(*)()) F409_4259;}
	R3907[341] = (char *(*)()) F409_4259;
	R3907[344] = (char *(*)()) F409_4259;
	{long i; for (i = 346; i < 349; i++) R3907[i] = (char *(*)()) F409_4259;}
	R3907[351] = (char *(*)()) F409_4259;
	R3907[352] = (char *(*)()) F414_4259;
	R3907[353] = (char *(*)()) F409_4259;
	R3907[435] = (char *(*)()) F709_5255;
	R3907[436] = (char *(*)()) F406_4237;
	{long i; for (i = 550; i < 552; i++) R3907[i] = (char *(*)()) F411_4259;}
	R3907[676] = (char *(*)()) F411_4259;
	R3907[680] = (char *(*)()) F410_4259;
	{long i; for (i = 759; i < 761; i++) R3907[i] = (char *(*)()) F409_4259;}
	{long i; for (i = 761; i < 763; i++) R3907[i] = (char *(*)()) F1035_8774;}
	{long i; for (i = 764; i < 766; i++) R3907[i] = (char *(*)()) F1035_8774;}
	{long i; for (i = 768; i < 772; i++) R3907[i] = (char *(*)()) F1035_8774;}
	{long i; for (i = 773; i < 775; i++) R3907[i] = (char *(*)()) F1035_8774;}
	R3907[801] = (char *(*)()) F409_4259;
	R3907[810] = (char *(*)()) F409_4259;
	R3907[992] = (char *(*)()) F1266_12624;
}

char *(*R3911[993])();
void R3911_init () {
	R3911[0] = (char *(*)()) F260_4030;
	R3911[230] = (char *(*)()) F260_4030;
	R3911[231] = (char *(*)()) F263_4030;
	R3911[232] = (char *(*)()) F261_4030;
	R3911[233] = (char *(*)()) F262_4030;
	R3911[234] = (char *(*)()) F265_4030;
	R3911[235] = (char *(*)()) F264_4030;
	R3911[236] = (char *(*)()) F266_4030;
	R3911[237] = (char *(*)()) F267_4030;
	R3911[238] = (char *(*)()) F268_4030;
	R3911[239] = (char *(*)()) F269_4030;
	R3911[240] = (char *(*)()) F270_4030;
	R3911[241] = (char *(*)()) F271_4030;
	R3911[291] = (char *(*)()) F260_4030;
	R3911[292] = (char *(*)()) F265_4030;
	R3911[293] = (char *(*)()) F269_4030;
	R3911[294] = (char *(*)()) F260_4030;
	R3911[295] = (char *(*)()) F269_4030;
	R3911[296] = (char *(*)()) F265_4030;
	R3911[297] = (char *(*)()) F260_4030;
	R3911[300] = (char *(*)()) F260_4030;
	{long i; for (i = 301; i < 303; i++) R3911[i] = (char *(*)()) F265_4030;}
	R3911[303] = (char *(*)()) F266_4030;
	R3911[304] = (char *(*)()) F260_4030;
	R3911[305] = (char *(*)()) F269_4030;
	R3911[306] = (char *(*)()) F265_4030;
	R3911[307] = (char *(*)()) F260_4030;
	R3911[308] = (char *(*)()) F269_4030;
	R3911[309] = (char *(*)()) F265_4030;
	{long i; for (i = 310; i < 312; i++) R3911[i] = (char *(*)()) F260_4030;}
	R3911[312] = (char *(*)()) F263_4030;
	R3911[313] = (char *(*)()) F261_4030;
	R3911[314] = (char *(*)()) F262_4030;
	R3911[315] = (char *(*)()) F265_4030;
	R3911[316] = (char *(*)()) F264_4030;
	R3911[317] = (char *(*)()) F266_4030;
	R3911[318] = (char *(*)()) F267_4030;
	R3911[319] = (char *(*)()) F268_4030;
	R3911[320] = (char *(*)()) F269_4030;
	R3911[321] = (char *(*)()) F270_4030;
	R3911[322] = (char *(*)()) F271_4030;
	{long i; for (i = 328; i < 331; i++) R3911[i] = (char *(*)()) F260_4030;}
	{long i; for (i = 337; i < 340; i++) R3911[i] = (char *(*)()) F260_4030;}
	R3911[341] = (char *(*)()) F260_4030;
	R3911[344] = (char *(*)()) F260_4030;
	{long i; for (i = 346; i < 349; i++) R3911[i] = (char *(*)()) F260_4030;}
	R3911[351] = (char *(*)()) F260_4030;
	R3911[352] = (char *(*)()) F265_4030;
	R3911[353] = (char *(*)()) F260_4030;
	R3911[435] = (char *(*)()) F260_4030;
	R3911[436] = (char *(*)()) F265_4030;
	{long i; for (i = 550; i < 552; i++) R3911[i] = (char *(*)()) F262_4030;}
	R3911[676] = (char *(*)()) F262_4030;
	R3911[680] = (char *(*)()) F261_4030;
	{long i; for (i = 759; i < 763; i++) R3911[i] = (char *(*)()) F260_4030;}
	{long i; for (i = 764; i < 766; i++) R3911[i] = (char *(*)()) F260_4030;}
	{long i; for (i = 768; i < 772; i++) R3911[i] = (char *(*)()) F260_4030;}
	{long i; for (i = 773; i < 775; i++) R3911[i] = (char *(*)()) F260_4030;}
	R3911[801] = (char *(*)()) F260_4030;
	R3911[810] = (char *(*)()) F260_4030;
	R3911[992] = (char *(*)()) F262_4030;
}


#ifdef __cplusplus
}
#endif
