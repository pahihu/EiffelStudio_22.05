#include "epoly10.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R5043[443])();
void R5043_init () {
	R5043[0] = (char *(*)()) F824_5908;
	R5043[1] = (char *(*)()) F823_5791;
	R5043[442] = (char *(*)()) F823_5791;
}

char *(*R5044[443])();
void R5044_init () {
	{long i; for (i = 0; i < 2; i++) R5044[i] = (char *(*)()) F823_5792;}
	R5044[442] = (char *(*)()) F1266_12646;
}

char *(*R5127[442])();
void R5127_init () {
	R5127[0] = (char *(*)()) F825_5960;
	R5127[441] = (char *(*)()) F1266_12588;
}

char *(*R5287[159])();
void R5287_init () {
	R5287[0] = (char *(*)()) F834_6151;
	R5287[1] = (char *(*)()) F835_6193;
	R5287[2] = (char *(*)()) F836_6193;
	R5287[3] = (char *(*)()) F837_6193;
	R5287[4] = (char *(*)()) F838_6193;
	R5287[5] = (char *(*)()) F839_6193;
	R5287[6] = (char *(*)()) F840_6193;
	R5287[7] = (char *(*)()) F841_6193;
	R5287[8] = (char *(*)()) F842_6193;
	R5287[9] = (char *(*)()) F843_6193;
	R5287[10] = (char *(*)()) F844_6193;
	R5287[11] = (char *(*)()) F845_6193;
	R5287[12] = (char *(*)()) F846_6193;
	R5287[13] = (char *(*)()) F847_6193;
	R5287[14] = (char *(*)()) F848_6193;
	R5287[15] = (char *(*)()) F849_6193;
	R5287[16] = (char *(*)()) F850_6193;
	R5287[17] = (char *(*)()) F851_6193;
	R5287[18] = (char *(*)()) F852_6193;
	R5287[19] = (char *(*)()) F853_6193;
	R5287[20] = (char *(*)()) F854_6193;
	R5287[21] = (char *(*)()) F855_6193;
	R5287[22] = (char *(*)()) F856_6193;
	R5287[23] = (char *(*)()) F857_6193;
	R5287[24] = (char *(*)()) F858_6193;
	R5287[25] = (char *(*)()) F859_6193;
	R5287[26] = (char *(*)()) F860_6193;
	R5287[27] = (char *(*)()) F861_6193;
	R5287[28] = (char *(*)()) F862_6193;
	R5287[29] = (char *(*)()) F863_6193;
	R5287[30] = (char *(*)()) F864_6193;
	R5287[31] = (char *(*)()) F865_6193;
	R5287[32] = (char *(*)()) F866_6245;
	{long i; for (i = 34; i < 36; i++) R5287[i] = (char *(*)()) F867_6352;}
	{long i; for (i = 37; i < 39; i++) R5287[i] = (char *(*)()) F870_6451;}
	{long i; for (i = 40; i < 42; i++) R5287[i] = (char *(*)()) F873_6550;}
	{long i; for (i = 43; i < 45; i++) R5287[i] = (char *(*)()) F876_6649;}
	{long i; for (i = 46; i < 48; i++) R5287[i] = (char *(*)()) F879_6743;}
	{long i; for (i = 49; i < 51; i++) R5287[i] = (char *(*)()) F882_6837;}
	{long i; for (i = 52; i < 54; i++) R5287[i] = (char *(*)()) F885_6932;}
	{long i; for (i = 55; i < 57; i++) R5287[i] = (char *(*)()) F888_7027;}
	{long i; for (i = 58; i < 60; i++) R5287[i] = (char *(*)()) F891_7093;}
	{long i; for (i = 61; i < 63; i++) R5287[i] = (char *(*)()) F894_7160;}
	{long i; for (i = 64; i < 66; i++) R5287[i] = (char *(*)()) F897_7201;}
	{long i; for (i = 67; i < 69; i++) R5287[i] = (char *(*)()) F900_7249;}
	{long i; for (i = 70; i < 72; i++) R5287[i] = (char *(*)()) F903_7270;}
	{long i; for (i = 72; i < 103; i++) R5287[i] = (char *(*)()) F906_7368;}
	R5287[103] = (char *(*)()) F937_7394;
	R5287[104] = (char *(*)()) F938_7394;
	{long i; for (i = 106; i < 111; i++) R5287[i] = (char *(*)()) F939_7402;}
	{long i; for (i = 115; i < 117; i++) R5287[i] = (char *(*)()) F945_7461;}
	{long i; for (i = 119; i < 121; i++) R5287[i] = (char *(*)()) F945_7461;}
	R5287[158] = (char *(*)()) F992_8209;
}

char *(*R5345[31])();
void R5345_init () {
	R5345[0] = (char *(*)()) F835_6189;
	R5345[1] = (char *(*)()) F836_6189;
	R5345[2] = (char *(*)()) F837_6189;
	R5345[3] = (char *(*)()) F838_6189;
	R5345[4] = (char *(*)()) F839_6189;
	R5345[5] = (char *(*)()) F840_6189;
	R5345[6] = (char *(*)()) F841_6189;
	R5345[7] = (char *(*)()) F842_6189;
	R5345[8] = (char *(*)()) F843_6189;
	R5345[9] = (char *(*)()) F844_6189;
	R5345[10] = (char *(*)()) F845_6189;
	R5345[11] = (char *(*)()) F846_6189;
	R5345[12] = (char *(*)()) F847_6189;
	R5345[13] = (char *(*)()) F848_6189;
	R5345[14] = (char *(*)()) F849_6189;
	R5345[15] = (char *(*)()) F850_6189;
	R5345[16] = (char *(*)()) F851_6189;
	R5345[17] = (char *(*)()) F852_6189;
	R5345[18] = (char *(*)()) F853_6189;
	R5345[19] = (char *(*)()) F854_6189;
	R5345[20] = (char *(*)()) F855_6189;
	R5345[21] = (char *(*)()) F856_6189;
	R5345[22] = (char *(*)()) F857_6189;
	R5345[23] = (char *(*)()) F858_6189;
	R5345[24] = (char *(*)()) F859_6189;
	R5345[25] = (char *(*)()) F860_6189;
	R5345[26] = (char *(*)()) F861_6189;
	R5345[27] = (char *(*)()) F862_6189;
	R5345[28] = (char *(*)()) F863_6189;
	R5345[29] = (char *(*)()) F864_6189;
	R5345[30] = (char *(*)()) F865_6189;
}

char *(*R5346[31])();
void R5346_init () {
	R5346[0] = (char *(*)()) F835_6190;
	R5346[1] = (char *(*)()) F836_6190;
	R5346[2] = (char *(*)()) F837_6190;
	R5346[3] = (char *(*)()) F838_6190;
	R5346[4] = (char *(*)()) F839_6190;
	R5346[5] = (char *(*)()) F840_6190;
	R5346[6] = (char *(*)()) F841_6190;
	R5346[7] = (char *(*)()) F842_6190;
	R5346[8] = (char *(*)()) F843_6190;
	R5346[9] = (char *(*)()) F844_6190;
	R5346[10] = (char *(*)()) F845_6190;
	R5346[11] = (char *(*)()) F846_6190;
	R5346[12] = (char *(*)()) F847_6190;
	R5346[13] = (char *(*)()) F848_6190;
	R5346[14] = (char *(*)()) F849_6190;
	R5346[15] = (char *(*)()) F850_6190;
	R5346[16] = (char *(*)()) F851_6190;
	R5346[17] = (char *(*)()) F852_6190;
	R5346[18] = (char *(*)()) F853_6190;
	R5346[19] = (char *(*)()) F854_6190;
	R5346[20] = (char *(*)()) F855_6190;
	R5346[21] = (char *(*)()) F856_6190;
	R5346[22] = (char *(*)()) F857_6190;
	R5346[23] = (char *(*)()) F858_6190;
	R5346[24] = (char *(*)()) F859_6190;
	R5346[25] = (char *(*)()) F860_6190;
	R5346[26] = (char *(*)()) F861_6190;
	R5346[27] = (char *(*)()) F862_6190;
	R5346[28] = (char *(*)()) F863_6190;
	R5346[29] = (char *(*)()) F864_6190;
	R5346[30] = (char *(*)()) F865_6190;
}

char *(*R5347[31])();
void R5347_init () {
	R5347[0] = (char *(*)()) F835_6191;
	R5347[1] = (char *(*)()) F836_6191;
	R5347[2] = (char *(*)()) F837_6191;
	R5347[3] = (char *(*)()) F838_6191;
	R5347[4] = (char *(*)()) F839_6191;
	R5347[5] = (char *(*)()) F840_6191;
	R5347[6] = (char *(*)()) F841_6191;
	R5347[7] = (char *(*)()) F842_6191;
	R5347[8] = (char *(*)()) F843_6191;
	R5347[9] = (char *(*)()) F844_6191;
	R5347[10] = (char *(*)()) F845_6191;
	R5347[11] = (char *(*)()) F846_6191;
	R5347[12] = (char *(*)()) F847_6191;
	R5347[13] = (char *(*)()) F848_6191;
	R5347[14] = (char *(*)()) F849_6191;
	R5347[15] = (char *(*)()) F850_6191;
	R5347[16] = (char *(*)()) F851_6191;
	R5347[17] = (char *(*)()) F852_6191;
	R5347[18] = (char *(*)()) F853_6191;
	R5347[19] = (char *(*)()) F854_6191;
	R5347[20] = (char *(*)()) F855_6191;
	R5347[21] = (char *(*)()) F856_6191;
	R5347[22] = (char *(*)()) F857_6191;
	R5347[23] = (char *(*)()) F858_6191;
	R5347[24] = (char *(*)()) F859_6191;
	R5347[25] = (char *(*)()) F860_6191;
	R5347[26] = (char *(*)()) F861_6191;
	R5347[27] = (char *(*)()) F862_6191;
	R5347[28] = (char *(*)()) F863_6191;
	R5347[29] = (char *(*)()) F864_6191;
	R5347[30] = (char *(*)()) F865_6191;
}

char *(*R5348[31])();
void R5348_init () {
	R5348[0] = (char *(*)()) F835_6192;
	R5348[1] = (char *(*)()) F836_6192;
	R5348[2] = (char *(*)()) F837_6192;
	R5348[3] = (char *(*)()) F838_6192;
	R5348[4] = (char *(*)()) F839_6192;
	R5348[5] = (char *(*)()) F840_6192;
	R5348[6] = (char *(*)()) F841_6192;
	R5348[7] = (char *(*)()) F842_6192;
	R5348[8] = (char *(*)()) F843_6192;
	R5348[9] = (char *(*)()) F844_6192;
	R5348[10] = (char *(*)()) F845_6192;
	R5348[11] = (char *(*)()) F846_6192;
	R5348[12] = (char *(*)()) F847_6192;
	R5348[13] = (char *(*)()) F848_6192;
	R5348[14] = (char *(*)()) F849_6192;
	R5348[15] = (char *(*)()) F850_6192;
	R5348[16] = (char *(*)()) F851_6192;
	R5348[17] = (char *(*)()) F852_6192;
	R5348[18] = (char *(*)()) F853_6192;
	R5348[19] = (char *(*)()) F854_6192;
	R5348[20] = (char *(*)()) F855_6192;
	R5348[21] = (char *(*)()) F856_6192;
	R5348[22] = (char *(*)()) F857_6192;
	R5348[23] = (char *(*)()) F858_6192;
	R5348[24] = (char *(*)()) F859_6192;
	R5348[25] = (char *(*)()) F860_6192;
	R5348[26] = (char *(*)()) F861_6192;
	R5348[27] = (char *(*)()) F862_6192;
	R5348[28] = (char *(*)()) F863_6192;
	R5348[29] = (char *(*)()) F864_6192;
	R5348[30] = (char *(*)()) F865_6192;
}

char *(*R5353[31])();
void R5353_init () {
	R5353[0] = (char *(*)()) F835_6198;
	R5353[1] = (char *(*)()) F836_6198;
	R5353[2] = (char *(*)()) F837_6198;
	R5353[3] = (char *(*)()) F838_6198;
	R5353[4] = (char *(*)()) F839_6198;
	R5353[5] = (char *(*)()) F840_6198;
	R5353[6] = (char *(*)()) F841_6198;
	R5353[7] = (char *(*)()) F842_6198;
	R5353[8] = (char *(*)()) F843_6198;
	R5353[9] = (char *(*)()) F844_6198;
	R5353[10] = (char *(*)()) F845_6198;
	R5353[11] = (char *(*)()) F846_6198;
	R5353[12] = (char *(*)()) F847_6198;
	R5353[13] = (char *(*)()) F848_6198;
	R5353[14] = (char *(*)()) F849_6198;
	R5353[15] = (char *(*)()) F850_6198;
	R5353[16] = (char *(*)()) F851_6198;
	R5353[17] = (char *(*)()) F852_6198;
	R5353[18] = (char *(*)()) F853_6198;
	R5353[19] = (char *(*)()) F854_6198;
	R5353[20] = (char *(*)()) F855_6198;
	R5353[21] = (char *(*)()) F856_6198;
	R5353[22] = (char *(*)()) F857_6198;
	R5353[23] = (char *(*)()) F858_6198;
	R5353[24] = (char *(*)()) F859_6198;
	R5353[25] = (char *(*)()) F860_6198;
	R5353[26] = (char *(*)()) F861_6198;
	R5353[27] = (char *(*)()) F862_6198;
	R5353[28] = (char *(*)()) F863_6198;
	R5353[29] = (char *(*)()) F864_6198;
	R5353[30] = (char *(*)()) F865_6198;
}

char *(*R5358[31])();
void R5358_init () {
	R5358[0] = (char *(*)()) F835_6206;
	R5358[1] = (char *(*)()) F836_6206_5358_1;
	R5358[2] = (char *(*)()) F837_6206_5358_1;
	R5358[3] = (char *(*)()) F838_6206_5358_1;
	R5358[4] = (char *(*)()) F839_6206_5358_1;
	R5358[5] = (char *(*)()) F840_6206_5358_1;
	R5358[6] = (char *(*)()) F841_6206_5358_1;
	R5358[7] = (char *(*)()) F842_6206_5358_1;
	R5358[8] = (char *(*)()) F843_6206_5358_1;
	R5358[9] = (char *(*)()) F844_6206_5358_1;
	R5358[10] = (char *(*)()) F845_6206_5358_1;
	R5358[11] = (char *(*)()) F846_6206_5358_1;
	R5358[12] = (char *(*)()) F847_6206_5358_1;
	R5358[13] = (char *(*)()) F848_6206_5358_1;
	R5358[14] = (char *(*)()) F849_6206_5358_1;
	R5358[15] = (char *(*)()) F850_6206_5358_1;
	R5358[16] = (char *(*)()) F851_6206_5358_1;
	R5358[17] = (char *(*)()) F852_6206_5358_1;
	R5358[18] = (char *(*)()) F853_6206;
	R5358[19] = (char *(*)()) F854_6206_5358_1;
	R5358[20] = (char *(*)()) F855_6206_5358_1;
	R5358[21] = (char *(*)()) F856_6206_5358_1;
	R5358[22] = (char *(*)()) F857_6206_5358_1;
	R5358[23] = (char *(*)()) F858_6206_5358_1;
	R5358[24] = (char *(*)()) F859_6206_5358_1;
	R5358[25] = (char *(*)()) F860_6206_5358_1;
	R5358[26] = (char *(*)()) F861_6206_5358_1;
	R5358[27] = (char *(*)()) F862_6206_5358_1;
	R5358[28] = (char *(*)()) F863_6206_5358_1;
	R5358[29] = (char *(*)()) F864_6206_5358_1;
	R5358[30] = (char *(*)()) F865_6206_5358_1;
}
static EIF_REFERENCE F836_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F836_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {907,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 907, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F837_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F837_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {909,937,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 909, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F838_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F838_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F839_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F839_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(892, 0x00).id, 892, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F840_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F840_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F841_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F841_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F842_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F842_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(883, 0x00).id, 883, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F843_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F843_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(880, 0x00).id, 880, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F844_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F844_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(877, 0x00).id, 877, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F845_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F845_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(874, 0x00).id, 874, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F846_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F846_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(871, 0x00).id, 871, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F847_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F847_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F848_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F848_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(904, 0x00).id, 904, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F849_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F849_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(898, 0x00).id, 898, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F850_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F850_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(895, 0x00).id, 895, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F851_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F851_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F852_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F852_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {911,877,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 911, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F854_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F854_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {913,898,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 913, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F855_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F855_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {915,889,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 915, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F856_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F856_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {917,892,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 917, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F857_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F857_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {919,871,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 919, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F858_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F858_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {921,883,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 921, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F859_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F859_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {923,880,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 923, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F860_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F860_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {925,886,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 925, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F861_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F861_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {927,868,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 927, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F862_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F862_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {929,901,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 929, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F863_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F863_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {931,904,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 931, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F864_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F864_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {933,874,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 933, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F865_6206_5358_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F865_6206(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {935,895,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 935, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}

char *(*R5368[31])();
void R5368_init () {
	R5368[0] = (char *(*)()) F835_6218;
	R5368[1] = (char *(*)()) F836_6218;
	R5368[2] = (char *(*)()) F837_6218;
	R5368[3] = (char *(*)()) F838_6218;
	R5368[4] = (char *(*)()) F839_6218;
	R5368[5] = (char *(*)()) F840_6218;
	R5368[6] = (char *(*)()) F841_6218;
	R5368[7] = (char *(*)()) F842_6218;
	R5368[8] = (char *(*)()) F843_6218;
	R5368[9] = (char *(*)()) F844_6218;
	R5368[10] = (char *(*)()) F845_6218;
	R5368[11] = (char *(*)()) F846_6218;
	R5368[12] = (char *(*)()) F847_6218;
	R5368[13] = (char *(*)()) F848_6218;
	R5368[14] = (char *(*)()) F849_6218;
	R5368[15] = (char *(*)()) F850_6218;
	R5368[16] = (char *(*)()) F851_6218;
	R5368[17] = (char *(*)()) F852_6218;
	R5368[18] = (char *(*)()) F853_6218;
	R5368[19] = (char *(*)()) F854_6218;
	R5368[20] = (char *(*)()) F855_6218;
	R5368[21] = (char *(*)()) F856_6218;
	R5368[22] = (char *(*)()) F857_6218;
	R5368[23] = (char *(*)()) F858_6218;
	R5368[24] = (char *(*)()) F859_6218;
	R5368[25] = (char *(*)()) F860_6218;
	R5368[26] = (char *(*)()) F861_6218;
	R5368[27] = (char *(*)()) F862_6218;
	R5368[28] = (char *(*)()) F863_6218;
	R5368[29] = (char *(*)()) F864_6218;
	R5368[30] = (char *(*)()) F865_6218;
}

char *(*R5513[2])();
void R5513_init () {
	R5513[0] = (char *(*)()) F868_6433;
	R5513[1] = (char *(*)()) F869_6433;
}

char *(*R5514[2])();
void R5514_init () {
	R5514[0] = (char *(*)()) F868_6434;
	R5514[1] = (char *(*)()) F869_6434;
}

char *(*R5515[2])();
void R5515_init () {
	R5515[0] = (char *(*)()) F868_6435;
	R5515[1] = (char *(*)()) F869_6435;
}

char *(*R5517[2])();
void R5517_init () {
	R5517[0] = (char *(*)()) F868_6437;
	R5517[1] = (char *(*)()) F869_6437;
}

char *(*R5519[2])();
void R5519_init () {
	R5519[0] = (char *(*)()) F868_6439;
	R5519[1] = (char *(*)()) F869_6439;
}

char *(*R5571[2])();
void R5571_init () {
	R5571[0] = (char *(*)()) F871_6534;
	R5571[1] = (char *(*)()) F872_6534;
}

char *(*R5574[2])();
void R5574_init () {
	R5574[0] = (char *(*)()) F871_6537;
	R5574[1] = (char *(*)()) F872_6537;
}

char *(*R5624[2])();
void R5624_init () {
	R5624[0] = (char *(*)()) F874_6630;
	R5624[1] = (char *(*)()) F875_6630;
}

char *(*R5627[2])();
void R5627_init () {
	R5627[0] = (char *(*)()) F874_6633;
	R5627[1] = (char *(*)()) F875_6633;
}

char *(*R5630[2])();
void R5630_init () {
	R5630[0] = (char *(*)()) F874_6636;
	R5630[1] = (char *(*)()) F875_6636;
}

char *(*R5684[2])();
void R5684_init () {
	R5684[0] = (char *(*)()) F877_6730;
	R5684[1] = (char *(*)()) F878_6730;
}

char *(*R5730[2])();
void R5730_init () {
	R5730[0] = (char *(*)()) F880_6818;
	R5730[1] = (char *(*)()) F881_6818;
}

char *(*R5731[2])();
void R5731_init () {
	R5731[0] = (char *(*)()) F880_6819;
	R5731[1] = (char *(*)()) F881_6819;
}

char *(*R5733[2])();
void R5733_init () {
	R5733[0] = (char *(*)()) F880_6821;
	R5733[1] = (char *(*)()) F881_6821;
}

char *(*R5736[2])();
void R5736_init () {
	R5736[0] = (char *(*)()) F880_6824;
	R5736[1] = (char *(*)()) F881_6824;
}

char *(*R5737[2])();
void R5737_init () {
	R5737[0] = (char *(*)()) F880_6825;
	R5737[1] = (char *(*)()) F881_6825;
}

char *(*R5785[2])();
void R5785_init () {
	R5785[0] = (char *(*)()) F883_6915;
	R5785[1] = (char *(*)()) F884_6915;
}

char *(*R5786[2])();
void R5786_init () {
	R5786[0] = (char *(*)()) F883_6916;
	R5786[1] = (char *(*)()) F884_6916;
}

char *(*R5789[2])();
void R5789_init () {
	R5789[0] = (char *(*)()) F883_6919;
	R5789[1] = (char *(*)()) F884_6919;
}

char *(*R5837[2])();
void R5837_init () {
	R5837[0] = (char *(*)()) F886_7009;
	R5837[1] = (char *(*)()) F887_7009;
}

char *(*R5838[2])();
void R5838_init () {
	R5838[0] = (char *(*)()) F886_7010;
	R5838[1] = (char *(*)()) F887_7010;
}

char *(*R5839[2])();
void R5839_init () {
	R5839[0] = (char *(*)()) F886_7011;
	R5839[1] = (char *(*)()) F887_7011;
}

char *(*R5840[2])();
void R5840_init () {
	R5840[0] = (char *(*)()) F886_7012;
	R5840[1] = (char *(*)()) F887_7012;
}

char *(*R5842[2])();
void R5842_init () {
	R5842[0] = (char *(*)()) F886_7014;
	R5842[1] = (char *(*)()) F887_7014;
}

char *(*R5888[2])();
void R5888_init () {
	R5888[0] = (char *(*)()) F889_7072;
	R5888[1] = (char *(*)()) F890_7072;
}

char *(*R5895[2])();
void R5895_init () {
	R5895[0] = (char *(*)()) F889_7076;
	R5895[1] = (char *(*)()) F890_7076;
}

char *(*R5922[2])();
void R5922_init () {
	R5922[0] = (char *(*)()) F892_7138;
	R5922[1] = (char *(*)()) F893_7138;
}

char *(*R5929[2])();
void R5929_init () {
	R5929[0] = (char *(*)()) F892_7142;
	R5929[1] = (char *(*)()) F893_7142;
}

char *(*R5943[2])();
void R5943_init () {
	R5943[0] = (char *(*)()) F895_7196;
	R5943[1] = (char *(*)()) F896_7196;
}

char *(*R6049[2])();
void R6049_init () {
	R6049[0] = (char *(*)()) F904_7352;
	R6049[1] = (char *(*)()) F905_7352;
}

char *(*R6052[2])();
void R6052_init () {
	R6052[0] = (char *(*)()) F904_7355;
	R6052[1] = (char *(*)()) F905_7355;
}

char *(*R6122[5])();
void R6122_init () {
	R6122[0] = (char *(*)()) F940_7439;
	R6122[1] = (char *(*)()) F941_7442;
	R6122[2] = (char *(*)()) F942_7442;
	R6122[3] = (char *(*)()) F943_7442;
	R6122[4] = (char *(*)()) F942_7442;
}

char *(*R6146[4])();
void R6146_init () {
	R6146[0] = (char *(*)()) F941_7441;
	R6146[1] = (char *(*)()) F942_7441_6146_1;
	R6146[2] = (char *(*)()) F943_7441_6146_1;
	R6146[3] = (char *(*)()) F942_7441_6146_1;
}
static EIF_REFERENCE F942_7441_6146_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F942_7441(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F943_7441_6146_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F943_7441(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R6147[4])();
void R6147_init () {
	R6147[0] = (char *(*)()) F941_7443;
	R6147[1] = (char *(*)()) F942_7443_6147_5;
	R6147[2] = (char *(*)()) F943_7443_6147_5;
	R6147[3] = (char *(*)()) F942_7443_6147_5;
}
static EIF_REFERENCE F942_7443_6147_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F942_7443(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F943_7443_6147_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F943_7443(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

char *(*R6151[4])();
void R6151_init () {
	R6151[0] = (char *(*)()) F941_7450;
	R6151[1] = (char *(*)()) F942_7450_6151_596;
	R6151[2] = (char *(*)()) F943_7450_6151_596;
	R6151[3] = (char *(*)()) F942_7450_6151_596;
}
static EIF_REFERENCE F942_7450_6151_596 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F942_7450(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(901, 0x00).id, 901, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F943_7450_6151_596 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4, EIF_INTEGER_32 arg5, EIF_BOOLEAN arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_POINTER arg10)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F943_7450(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(937, 0x00).id, 937, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y6152_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6152_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6152_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y6152_pgtype3[] = {901,0xFFFF};
EIF_TYPE_INDEX *Y6152_gen_type [4];
EIF_TYPE_INDEX Y6152 [4];
void Y6152_init (void)
{
	egc_routines_types [6152] = Y6152;
	egc_routines_gen_types [6152] = Y6152_gen_type;
	egc_routines_offset [6152] = 940;
	Y6152_gen_type [0] = Y6152_pgtype0;
	Y6152_gen_type [1] = Y6152_pgtype1;
	Y6152_gen_type [2] = Y6152_pgtype2;
	Y6152_gen_type [3] = Y6152_pgtype3;
	Y6152[3] = 901;
}

char *(*R6153[6])();
void R6153_init () {
	{long i; for (i = 0; i < 2; i++) R6153[i] = (char *(*)()) F948_7582;}
	{long i; for (i = 4; i < 6; i++) R6153[i] = (char *(*)()) F952_7748;}
}

char *(*R6155[6])();
void R6155_init () {
	R6155[0] = (char *(*)()) F949_7642;
	R6155[1] = (char *(*)()) F950_7664;
	R6155[4] = (char *(*)()) F953_7809;
	R6155[5] = (char *(*)()) F954_7832;
}

char *(*R6156[6])();
void R6156_init () {
	R6156[0] = (char *(*)()) F949_7641;
	R6156[1] = (char *(*)()) F950_7663;
	R6156[4] = (char *(*)()) F953_7807;
	R6156[5] = (char *(*)()) F954_7830;
}

char *(*R6157[6])();
void R6157_init () {
	{long i; for (i = 0; i < 2; i++) R6157[i] = (char *(*)()) F945_7455;}
	{long i; for (i = 4; i < 6; i++) R6157[i] = (char *(*)()) F952_7760;}
}

char *(*R6167[6])();
void R6167_init () {
	{long i; for (i = 0; i < 2; i++) R6167[i] = (char *(*)()) F948_7613;}
	{long i; for (i = 4; i < 6; i++) R6167[i] = (char *(*)()) F952_7778;}
}

char *(*R6169[6])();
void R6169_init () {
	{long i; for (i = 0; i < 2; i++) R6169[i] = (char *(*)()) F948_7615;}
	{long i; for (i = 4; i < 6; i++) R6169[i] = (char *(*)()) F952_7780;}
}

char *(*R6170[6])();
void R6170_init () {
	R6170[0] = (char *(*)()) F949_7651;
	R6170[1] = (char *(*)()) F411_4259;
	R6170[4] = (char *(*)()) F953_7819;
	R6170[5] = (char *(*)()) F410_4259;
}

char *(*R6173[6])();
void R6173_init () {
	{long i; for (i = 0; i < 2; i++) R6173[i] = (char *(*)()) F945_7472;}
	{long i; for (i = 4; i < 6; i++) R6173[i] = (char *(*)()) F952_7782;}
}

char *(*R6192[6])();
void R6192_init () {
	{long i; for (i = 0; i < 2; i++) R6192[i] = (char *(*)()) F948_7604;}
	{long i; for (i = 4; i < 6; i++) R6192[i] = (char *(*)()) F952_7769;}
}

char *(*R6193[6])();
void R6193_init () {
	{long i; for (i = 0; i < 2; i++) R6193[i] = (char *(*)()) F948_7603;}
	{long i; for (i = 4; i < 6; i++) R6193[i] = (char *(*)()) F952_7768;}
}

char *(*R6203[6])();
void R6203_init () {
	{long i; for (i = 0; i < 2; i++) R6203[i] = (char *(*)()) F948_7600;}
	{long i; for (i = 4; i < 6; i++) R6203[i] = (char *(*)()) F952_7765;}
}

char *(*R6233[6])();
void R6233_init () {
	R6233[0] = (char *(*)()) F949_7649;
	R6233[1] = (char *(*)()) F950_7742;
	R6233[4] = (char *(*)()) F953_7816;
	R6233[5] = (char *(*)()) F954_7910;
}

char *(*R6237[6])();
void R6237_init () {
	R6237[0] = (char *(*)()) F949_7653;
	R6237[1] = (char *(*)()) F950_7746;
	R6237[4] = (char *(*)()) F953_7820;
	R6237[5] = (char *(*)()) F954_7913;
}

char *(*R6248[5])();
void R6248_init () {
	R6248[0] = (char *(*)()) F950_7744;
	R6248[4] = (char *(*)()) F954_7912;
}

char *(*R6251[5])();
void R6251_init () {
	R6251[0] = (char *(*)()) F950_7683;
	R6251[4] = (char *(*)()) F954_7851;
}

char *(*R6281[5])();
void R6281_init () {
	R6281[0] = (char *(*)()) F950_7727;
	R6281[4] = (char *(*)()) F954_7895;
}

char *(*R6305[2])();
void R6305_init () {
	R6305[0] = (char *(*)()) F949_7644;
	R6305[1] = (char *(*)()) F950_7714;
}

char *(*R6313[2])();
void R6313_init () {
	R6313[0] = (char *(*)()) F949_7655;
	R6313[1] = (char *(*)()) F948_7634;
}

char *(*R6388[2])();
void R6388_init () {
	R6388[0] = (char *(*)()) F953_7822;
	R6388[1] = (char *(*)()) F952_7799;
}

char *(*R6472[2])();
void R6472_init () {
	R6472[0] = (char *(*)()) F1021_8563;
	R6472[1] = (char *(*)()) F1022_8571;
}

char *(*R6475[19])();
void R6475_init () {
	R6475[0] = (char *(*)()) F1066_9184;
	R6475[1] = (char *(*)()) F1067_9194;
	R6475[3] = (char *(*)()) F1069_9205;
	R6475[18] = (char *(*)()) F1084_9325;
}

char *(*R6479[52])();
void R6479_init () {
	R6479[0] = (char *(*)()) F1033_8769;
	R6479[1] = (char *(*)()) F1034_8771;
	R6479[2] = (char *(*)()) F1035_8784;
	R6479[3] = (char *(*)()) F1036_8792;
	R6479[5] = (char *(*)()) F1038_8816;
	R6479[6] = (char *(*)()) F1039_8849;
	{long i; for (i = 9; i < 11; i++) R6479[i] = (char *(*)()) F1041_8875;}
	{long i; for (i = 11; i < 13; i++) R6479[i] = (char *(*)()) F1044_8940;}
	{long i; for (i = 14; i < 16; i++) R6479[i] = (char *(*)()) F1044_8940;}
	R6479[18] = (char *(*)()) F1051_9008;
	R6479[19] = (char *(*)()) F1052_9019;
	R6479[20] = (char *(*)()) F1053_9027;
	R6479[23] = (char *(*)()) F1056_9081;
	R6479[25] = (char *(*)()) F1058_9119;
	{long i; for (i = 26; i < 29; i++) R6479[i] = (char *(*)()) F1059_9142;}
	R6479[33] = (char *(*)()) F1066_9184;
	R6479[34] = (char *(*)()) F1067_9194;
	R6479[36] = (char *(*)()) F1069_9205;
	R6479[42] = (char *(*)()) F1075_9265;
	R6479[51] = (char *(*)()) F1084_9325;
}

char *(*R6487[16])();
void R6487_init () {
	R6487[0] = (char *(*)()) F1069_9205;
	R6487[15] = (char *(*)()) F1084_9325;
}

char *(*R6491[3])();
void R6491_init () {
	R6491[0] = (char *(*)()) F1056_9081;
	R6491[2] = (char *(*)()) F1058_9119;
}

char *(*R6496[43])();
void R6496_init () {
	R6496[0] = (char *(*)()) F1033_8769;
	R6496[1] = (char *(*)()) F1034_8771;
	R6496[2] = (char *(*)()) F1035_8784;
	R6496[3] = (char *(*)()) F1036_8792;
	R6496[5] = (char *(*)()) F1038_8816;
	R6496[6] = (char *(*)()) F1039_8849;
	{long i; for (i = 9; i < 11; i++) R6496[i] = (char *(*)()) F1041_8875;}
	{long i; for (i = 11; i < 13; i++) R6496[i] = (char *(*)()) F1044_8940;}
	{long i; for (i = 14; i < 16; i++) R6496[i] = (char *(*)()) F1044_8940;}
	R6496[42] = (char *(*)()) F1075_9265;
}

char *(*R6498[10])();
void R6498_init () {
	R6498[0] = (char *(*)()) F1039_8849;
	{long i; for (i = 3; i < 5; i++) R6498[i] = (char *(*)()) F1041_8875;}
	{long i; for (i = 5; i < 7; i++) R6498[i] = (char *(*)()) F1044_8940;}
	{long i; for (i = 8; i < 10; i++) R6498[i] = (char *(*)()) F1044_8940;}
}

char *(*R6503[43])();
void R6503_init () {
	R6503[0] = (char *(*)()) F1033_8769;
	R6503[1] = (char *(*)()) F1034_8771;
	R6503[2] = (char *(*)()) F1035_8784;
	R6503[3] = (char *(*)()) F1036_8792;
	R6503[5] = (char *(*)()) F1038_8816;
	R6503[6] = (char *(*)()) F1039_8849;
	{long i; for (i = 9; i < 11; i++) R6503[i] = (char *(*)()) F1041_8875;}
	{long i; for (i = 11; i < 13; i++) R6503[i] = (char *(*)()) F1044_8940;}
	{long i; for (i = 14; i < 16; i++) R6503[i] = (char *(*)()) F1044_8940;}
	R6503[18] = (char *(*)()) F1051_9008;
	R6503[19] = (char *(*)()) F1052_9019;
	R6503[20] = (char *(*)()) F1053_9027;
	R6503[23] = (char *(*)()) F1056_9081;
	R6503[25] = (char *(*)()) F1058_9119;
	{long i; for (i = 26; i < 29; i++) R6503[i] = (char *(*)()) F1059_9142;}
	R6503[42] = (char *(*)()) F1075_9265;
}

char *(*R6549[10])();
void R6549_init () {
	R6549[0] = (char *(*)()) F1052_9019;
	{long i; for (i = 7; i < 10; i++) R6549[i] = (char *(*)()) F1059_9142;}
}

char *(*R6557[100])();
void R6557_init () {
	R6557[0] = (char *(*)()) F985_8099;
	R6557[1] = (char *(*)()) F986_8104;
	R6557[3] = (char *(*)()) F988_8132;
	R6557[4] = (char *(*)()) F989_8140;
	R6557[5] = (char *(*)()) F990_8154;
	R6557[6] = (char *(*)()) F991_8174;
	R6557[7] = (char *(*)()) F992_8216;
	R6557[8] = (char *(*)()) F993_8247;
	R6557[13] = (char *(*)()) F997_8309;
	{long i; for (i = 16; i < 19; i++) R6557[i] = (char *(*)()) F1001_8361;}
	R6557[31] = (char *(*)()) F1016_8520;
	R6557[36] = (char *(*)()) F1021_8564;
	R6557[37] = (char *(*)()) F1022_8572;
	R6557[48] = (char *(*)()) F1033_8770;
	R6557[49] = (char *(*)()) F1034_8772;
	R6557[50] = (char *(*)()) F1035_8785;
	R6557[51] = (char *(*)()) F1036_8793;
	R6557[53] = (char *(*)()) F1038_8817;
	R6557[54] = (char *(*)()) F1039_8853;
	{long i; for (i = 57; i < 59; i++) R6557[i] = (char *(*)()) F1041_8876;}
	{long i; for (i = 59; i < 61; i++) R6557[i] = (char *(*)()) F1044_8941;}
	{long i; for (i = 62; i < 64; i++) R6557[i] = (char *(*)()) F1044_8941;}
	R6557[66] = (char *(*)()) F1051_9009;
	R6557[67] = (char *(*)()) F1052_9020;
	R6557[68] = (char *(*)()) F1053_9028;
	R6557[71] = (char *(*)()) F1056_9082;
	R6557[73] = (char *(*)()) F1058_9120;
	{long i; for (i = 74; i < 77; i++) R6557[i] = (char *(*)()) F1059_9143;}
	R6557[81] = (char *(*)()) F1066_9185;
	R6557[82] = (char *(*)()) F1067_9195;
	R6557[84] = (char *(*)()) F1069_9206;
	R6557[90] = (char *(*)()) F1075_9255;
	R6557[99] = (char *(*)()) F1084_9326;
}

char *(*R6558[100])();
void R6558_init () {
	R6558[0] = (char *(*)()) F985_8098;
	R6558[1] = (char *(*)()) F986_8105;
	R6558[3] = (char *(*)()) F988_8131;
	R6558[4] = (char *(*)()) F989_8139;
	R6558[5] = (char *(*)()) F990_8153;
	R6558[6] = (char *(*)()) F991_8173;
	R6558[7] = (char *(*)()) F992_8215;
	R6558[8] = (char *(*)()) F993_8246;
	R6558[13] = (char *(*)()) F997_8308;
	{long i; for (i = 16; i < 19; i++) R6558[i] = (char *(*)()) F1001_8360;}
	R6558[31] = (char *(*)()) F1016_8519;
	{long i; for (i = 36; i < 38; i++) R6558[i] = (char *(*)()) F1019_8543;}
	{long i; for (i = 48; i < 52; i++) R6558[i] = (char *(*)()) F831_6100;}
	{long i; for (i = 53; i < 55; i++) R6558[i] = (char *(*)()) F831_6100;}
	{long i; for (i = 57; i < 61; i++) R6558[i] = (char *(*)()) F831_6100;}
	{long i; for (i = 62; i < 64; i++) R6558[i] = (char *(*)()) F1046_8950;}
	{long i; for (i = 66; i < 69; i++) R6558[i] = (char *(*)()) F831_6100;}
	R6558[71] = (char *(*)()) F831_6100;
	{long i; for (i = 73; i < 77; i++) R6558[i] = (char *(*)()) F831_6100;}
	{long i; for (i = 81; i < 83; i++) R6558[i] = (char *(*)()) F831_6100;}
	R6558[84] = (char *(*)()) F831_6100;
	R6558[90] = (char *(*)()) F831_6100;
	R6558[99] = (char *(*)()) F831_6100;
}

char *(*R6559[100])();
void R6559_init () {
	{long i; for (i = 0; i < 2; i++) R6559[i] = (char *(*)()) F982_8038;}
	{long i; for (i = 3; i < 9; i++) R6559[i] = (char *(*)()) F982_8038;}
	R6559[13] = (char *(*)()) F997_8270;
	{long i; for (i = 16; i < 19; i++) R6559[i] = (char *(*)()) F982_8038;}
	R6559[31] = (char *(*)()) F982_8038;
	{long i; for (i = 36; i < 38; i++) R6559[i] = (char *(*)()) F982_8038;}
	{long i; for (i = 48; i < 52; i++) R6559[i] = (char *(*)()) F982_8038;}
	R6559[53] = (char *(*)()) F982_8038;
	R6559[54] = (char *(*)()) F1039_8819;
	R6559[57] = (char *(*)()) F1042_8877;
	R6559[58] = (char *(*)()) F1043_8885;
	{long i; for (i = 59; i < 61; i++) R6559[i] = (char *(*)()) F1044_8927;}
	R6559[62] = (char *(*)()) F1047_8982;
	R6559[63] = (char *(*)()) F1048_8983;
	{long i; for (i = 66; i < 69; i++) R6559[i] = (char *(*)()) F982_8038;}
	R6559[71] = (char *(*)()) F982_8038;
	{long i; for (i = 73; i < 77; i++) R6559[i] = (char *(*)()) F982_8038;}
	{long i; for (i = 81; i < 83; i++) R6559[i] = (char *(*)()) F982_8038;}
	R6559[84] = (char *(*)()) F982_8038;
	R6559[90] = (char *(*)()) F982_8038;
	R6559[99] = (char *(*)()) F982_8038;
}

char *(*R6715[52])();
void R6715_init () {
	{long i; for (i = 0; i < 4; i++) R6715[i] = (char *(*)()) F1027_8655;}
	{long i; for (i = 5; i < 7; i++) R6715[i] = (char *(*)()) F1027_8655;}
	{long i; for (i = 9; i < 13; i++) R6715[i] = (char *(*)()) F1027_8655;}
	{long i; for (i = 14; i < 16; i++) R6715[i] = (char *(*)()) F1027_8655;}
	{long i; for (i = 18; i < 21; i++) R6715[i] = (char *(*)()) F1027_8655;}
	R6715[23] = (char *(*)()) F1027_8655;
	{long i; for (i = 25; i < 29; i++) R6715[i] = (char *(*)()) F1027_8655;}
	R6715[33] = (char *(*)()) F1065_9183;
	R6715[34] = (char *(*)()) F1067_9186;
	R6715[36] = (char *(*)()) F1062_9162;
	R6715[42] = (char *(*)()) F1027_8655;
	R6715[51] = (char *(*)()) F1084_9320;
}

char *(*R6717[52])();
void R6717_init () {
	{long i; for (i = 0; i < 3; i++) R6717[i] = (char *(*)()) F994_8250;}
	R6717[3] = (char *(*)()) F1036_8787;
	{long i; for (i = 5; i < 7; i++) R6717[i] = (char *(*)()) F994_8250;}
	{long i; for (i = 9; i < 13; i++) R6717[i] = (char *(*)()) F994_8250;}
	{long i; for (i = 14; i < 16; i++) R6717[i] = (char *(*)()) F1046_8956;}
	{long i; for (i = 18; i < 20; i++) R6717[i] = (char *(*)()) F994_8250;}
	R6717[20] = (char *(*)()) F1053_9022;
	R6717[23] = (char *(*)()) F994_8250;
	{long i; for (i = 25; i < 29; i++) R6717[i] = (char *(*)()) F994_8250;}
	{long i; for (i = 33; i < 35; i++) R6717[i] = (char *(*)()) F994_8250;}
	R6717[36] = (char *(*)()) F1069_9200;
	R6717[42] = (char *(*)()) F994_8250;
	R6717[51] = (char *(*)()) F1069_9200;
}

char *(*R6775[60])();
void R6775_init () {
	R6775[0] = (char *(*)()) F999_8315;
	{long i; for (i = 17; i < 21; i++) R6775[i] = (char *(*)()) F999_8315;}
	{long i; for (i = 22; i < 24; i++) R6775[i] = (char *(*)()) F999_8315;}
	{long i; for (i = 26; i < 30; i++) R6775[i] = (char *(*)()) F999_8315;}
	{long i; for (i = 31; i < 33; i++) R6775[i] = (char *(*)()) F1046_8954;}
	{long i; for (i = 35; i < 38; i++) R6775[i] = (char *(*)()) F999_8315;}
	R6775[40] = (char *(*)()) F999_8315;
	{long i; for (i = 42; i < 46; i++) R6775[i] = (char *(*)()) F999_8315;}
	R6775[59] = (char *(*)()) F999_8315;
}

char *(*R6776[60])();
void R6776_init () {
	R6776[0] = (char *(*)()) F999_8316;
	{long i; for (i = 17; i < 21; i++) R6776[i] = (char *(*)()) F999_8316;}
	{long i; for (i = 22; i < 24; i++) R6776[i] = (char *(*)()) F999_8316;}
	{long i; for (i = 26; i < 30; i++) R6776[i] = (char *(*)()) F999_8316;}
	{long i; for (i = 31; i < 33; i++) R6776[i] = (char *(*)()) F1046_8955;}
	{long i; for (i = 35; i < 38; i++) R6776[i] = (char *(*)()) F999_8316;}
	R6776[40] = (char *(*)()) F999_8316;
	{long i; for (i = 42; i < 46; i++) R6776[i] = (char *(*)()) F999_8316;}
	R6776[59] = (char *(*)()) F999_8316;
}

char *(*R7065[16])();
void R7065_init () {
	{long i; for (i = 0; i < 2; i++) R7065[i] = (char *(*)()) F1025_8620;}
	{long i; for (i = 2; i < 4; i++) R7065[i] = (char *(*)()) F1028_8696;}
	{long i; for (i = 5; i < 7; i++) R7065[i] = (char *(*)()) F1028_8696;}
	{long i; for (i = 9; i < 13; i++) R7065[i] = (char *(*)()) F1028_8696;}
	{long i; for (i = 14; i < 16; i++) R7065[i] = (char *(*)()) F1028_8696;}
}

char *(*R7068[16])();
void R7068_init () {
	{long i; for (i = 0; i < 2; i++) R7068[i] = (char *(*)()) F1025_8629;}
	{long i; for (i = 2; i < 4; i++) R7068[i] = (char *(*)()) F1035_8781;}
	{long i; for (i = 5; i < 7; i++) R7068[i] = (char *(*)()) F1035_8781;}
	{long i; for (i = 9; i < 13; i++) R7068[i] = (char *(*)()) F1035_8781;}
	{long i; for (i = 14; i < 16; i++) R7068[i] = (char *(*)()) F1035_8781;}
}

char *(*R7516[168])();
void R7516_init () {
	R7516[0] = (char *(*)()) F1093_9472;
	R7516[6] = (char *(*)()) F1099_9525;
	R7516[9] = (char *(*)()) F1101_9559;
	R7516[11] = (char *(*)()) F1104_9602;
	R7516[13] = (char *(*)()) F1106_9656;
	R7516[15] = (char *(*)()) F1108_9739;
	R7516[17] = (char *(*)()) F1110_9789;
	R7516[19] = (char *(*)()) F1112_9996;
	R7516[24] = (char *(*)()) F1114_10055;
	R7516[59] = (char *(*)()) F1152_10493;
	{long i; for (i = 66; i < 68; i++) R7516[i] = (char *(*)()) F1114_10055;}
	{long i; for (i = 84; i < 86; i++) R7516[i] = (char *(*)()) F1166_10775;}
	{long i; for (i = 94; i < 96; i++) R7516[i] = (char *(*)()) F1166_10775;}
	R7516[97] = (char *(*)()) F1166_10775;
	R7516[98] = (char *(*)()) F1191_11108;
	{long i; for (i = 100; i < 102; i++) R7516[i] = (char *(*)()) F1191_11108;}
	{long i; for (i = 121; i < 124; i++) R7516[i] = (char *(*)()) F1164_10716;}
	R7516[128] = (char *(*)()) F1164_10716;
	R7516[130] = (char *(*)()) F1164_10716;
	R7516[141] = (char *(*)()) F1233_11967;
	R7516[147] = (char *(*)()) F1233_11967;
	R7516[151] = (char *(*)()) F1244_12040;
	R7516[156] = (char *(*)()) F1233_11967;
	R7516[165] = (char *(*)()) F1258_12424;
	R7516[166] = (char *(*)()) F1259_12429;
	R7516[167] = (char *(*)()) F1260_12492;
}

char *(*R8064[144])();
void R8064_init () {
	R8064[0] = (char *(*)()) F1114_10064;
	{long i; for (i = 42; i < 44; i++) R8064[i] = (char *(*)()) F1114_10064;}
	{long i; for (i = 60; i < 62; i++) R8064[i] = (char *(*)()) F1176_10887;}
	R8064[70] = (char *(*)()) F1114_10064;
	R8064[71] = (char *(*)()) F1188_11007;
	R8064[73] = (char *(*)()) F1190_11051;
	R8064[74] = (char *(*)()) F1114_10064;
	{long i; for (i = 76; i < 78; i++) R8064[i] = (char *(*)()) F1114_10064;}
	R8064[97] = (char *(*)()) F1214_11543;
	R8064[98] = (char *(*)()) F1215_11545;
	R8064[99] = (char *(*)()) F1216_11570;
	R8064[104] = (char *(*)()) F1114_10064;
	R8064[106] = (char *(*)()) F1223_11776;
	R8064[117] = (char *(*)()) F1234_11972;
	R8064[123] = (char *(*)()) F1240_11988;
	R8064[127] = (char *(*)()) F1240_11988;
	R8064[132] = (char *(*)()) F1249_12105;
	{long i; for (i = 142; i < 144; i++) R8064[i] = (char *(*)()) F1114_10064;}
}

char *(*R8066[144])();
void R8066_init () {
	R8066[0] = (char *(*)()) F1114_10067;
	{long i; for (i = 42; i < 44; i++) R8066[i] = (char *(*)()) F1114_10067;}
	{long i; for (i = 60; i < 62; i++) R8066[i] = (char *(*)()) F1114_10067;}
	{long i; for (i = 70; i < 72; i++) R8066[i] = (char *(*)()) F1114_10067;}
	{long i; for (i = 73; i < 75; i++) R8066[i] = (char *(*)()) F1114_10067;}
	{long i; for (i = 76; i < 78; i++) R8066[i] = (char *(*)()) F1114_10067;}
	{long i; for (i = 97; i < 100; i++) R8066[i] = (char *(*)()) F1114_10067;}
	R8066[104] = (char *(*)()) F1221_11695;
	R8066[106] = (char *(*)()) F1114_10067;
	R8066[117] = (char *(*)()) F1114_10067;
	R8066[123] = (char *(*)()) F1114_10067;
	R8066[127] = (char *(*)()) F1114_10067;
	R8066[132] = (char *(*)()) F1114_10067;
	R8066[142] = (char *(*)()) F1259_12430;
	R8066[143] = (char *(*)()) F1260_12493;
}

char *(*R8067[144])();
void R8067_init () {
	R8067[0] = (char *(*)()) F1114_10068;
	{long i; for (i = 42; i < 44; i++) R8067[i] = (char *(*)()) F1114_10068;}
	{long i; for (i = 60; i < 62; i++) R8067[i] = (char *(*)()) F1114_10068;}
	{long i; for (i = 70; i < 72; i++) R8067[i] = (char *(*)()) F1114_10068;}
	{long i; for (i = 73; i < 75; i++) R8067[i] = (char *(*)()) F1114_10068;}
	{long i; for (i = 76; i < 78; i++) R8067[i] = (char *(*)()) F1114_10068;}
	{long i; for (i = 97; i < 100; i++) R8067[i] = (char *(*)()) F1114_10068;}
	R8067[104] = (char *(*)()) F1114_10068;
	R8067[106] = (char *(*)()) F1114_10068;
	R8067[117] = (char *(*)()) F1114_10068;
	R8067[123] = (char *(*)()) F1114_10068;
	R8067[127] = (char *(*)()) F1114_10068;
	R8067[132] = (char *(*)()) F1114_10068;
	R8067[142] = (char *(*)()) F1259_12443;
	R8067[143] = (char *(*)()) F1260_12477;
}

char *(*R8069[144])();
void R8069_init () {
	R8069[0] = (char *(*)()) F1114_10070;
	{long i; for (i = 42; i < 44; i++) R8069[i] = (char *(*)()) F1114_10070;}
	{long i; for (i = 60; i < 62; i++) R8069[i] = (char *(*)()) F1114_10070;}
	{long i; for (i = 70; i < 72; i++) R8069[i] = (char *(*)()) F1114_10070;}
	{long i; for (i = 73; i < 75; i++) R8069[i] = (char *(*)()) F1114_10070;}
	{long i; for (i = 76; i < 78; i++) R8069[i] = (char *(*)()) F1114_10070;}
	{long i; for (i = 97; i < 100; i++) R8069[i] = (char *(*)()) F1114_10070;}
	R8069[104] = (char *(*)()) F1114_10070;
	R8069[106] = (char *(*)()) F1114_10070;
	R8069[117] = (char *(*)()) F1114_10070;
	R8069[123] = (char *(*)()) F1114_10070;
	R8069[127] = (char *(*)()) F1114_10070;
	R8069[132] = (char *(*)()) F1114_10070;
	R8069[142] = (char *(*)()) F1259_12444;
	R8069[143] = (char *(*)()) F1114_10070;
}

char *(*R8072[144])();
void R8072_init () {
	R8072[0] = (char *(*)()) F1114_10073;
	{long i; for (i = 42; i < 44; i++) R8072[i] = (char *(*)()) F1114_10073;}
	{long i; for (i = 60; i < 62; i++) R8072[i] = (char *(*)()) F1114_10073;}
	{long i; for (i = 70; i < 72; i++) R8072[i] = (char *(*)()) F1114_10073;}
	{long i; for (i = 73; i < 75; i++) R8072[i] = (char *(*)()) F1114_10073;}
	{long i; for (i = 76; i < 78; i++) R8072[i] = (char *(*)()) F1114_10073;}
	{long i; for (i = 97; i < 100; i++) R8072[i] = (char *(*)()) F1114_10073;}
	R8072[104] = (char *(*)()) F1114_10073;
	R8072[106] = (char *(*)()) F1114_10073;
	R8072[117] = (char *(*)()) F1114_10073;
	R8072[123] = (char *(*)()) F1114_10073;
	R8072[127] = (char *(*)()) F1114_10073;
	R8072[132] = (char *(*)()) F1114_10073;
	R8072[142] = (char *(*)()) F1259_12445;
	R8072[143] = (char *(*)()) F1114_10073;
}

char *(*R8074[144])();
void R8074_init () {
	R8074[0] = (char *(*)()) F1114_10075;
	{long i; for (i = 42; i < 44; i++) R8074[i] = (char *(*)()) F1114_10075;}
	{long i; for (i = 60; i < 62; i++) R8074[i] = (char *(*)()) F1114_10075;}
	{long i; for (i = 70; i < 72; i++) R8074[i] = (char *(*)()) F1114_10075;}
	{long i; for (i = 73; i < 75; i++) R8074[i] = (char *(*)()) F1114_10075;}
	{long i; for (i = 76; i < 78; i++) R8074[i] = (char *(*)()) F1114_10075;}
	{long i; for (i = 97; i < 100; i++) R8074[i] = (char *(*)()) F1114_10075;}
	R8074[104] = (char *(*)()) F1114_10075;
	R8074[106] = (char *(*)()) F1114_10075;
	R8074[117] = (char *(*)()) F1114_10075;
	R8074[123] = (char *(*)()) F1114_10075;
	R8074[127] = (char *(*)()) F1114_10075;
	R8074[132] = (char *(*)()) F1114_10075;
	R8074[142] = (char *(*)()) F1259_12446;
	R8074[143] = (char *(*)()) F1114_10075;
}

char *(*R8075[144])();
void R8075_init () {
	R8075[0] = (char *(*)()) F1114_10076;
	{long i; for (i = 42; i < 44; i++) R8075[i] = (char *(*)()) F1114_10076;}
	{long i; for (i = 60; i < 62; i++) R8075[i] = (char *(*)()) F1114_10076;}
	{long i; for (i = 70; i < 72; i++) R8075[i] = (char *(*)()) F1114_10076;}
	R8075[73] = (char *(*)()) F1189_11042;
	R8075[74] = (char *(*)()) F1114_10076;
	{long i; for (i = 76; i < 78; i++) R8075[i] = (char *(*)()) F1114_10076;}
	{long i; for (i = 97; i < 100; i++) R8075[i] = (char *(*)()) F1114_10076;}
	R8075[104] = (char *(*)()) F1221_11694;
	R8075[106] = (char *(*)()) F1223_11816;
	R8075[117] = (char *(*)()) F1114_10076;
	R8075[123] = (char *(*)()) F1114_10076;
	R8075[127] = (char *(*)()) F1114_10076;
	R8075[132] = (char *(*)()) F1114_10076;
	{long i; for (i = 142; i < 144; i++) R8075[i] = (char *(*)()) F1114_10076;}
}

char *(*R8085[144])();
void R8085_init () {
	R8085[0] = (char *(*)()) F1115_10087;
	{long i; for (i = 42; i < 44; i++) R8085[i] = (char *(*)()) F1115_10087;}
	{long i; for (i = 60; i < 62; i++) R8085[i] = (char *(*)()) F1164_10701;}
	{long i; for (i = 70; i < 72; i++) R8085[i] = (char *(*)()) F1164_10701;}
	R8085[73] = (char *(*)()) F1164_10701;
	R8085[74] = (char *(*)()) F1115_10087;
	{long i; for (i = 76; i < 78; i++) R8085[i] = (char *(*)()) F1115_10087;}
	{long i; for (i = 97; i < 100; i++) R8085[i] = (char *(*)()) F1164_10701;}
	R8085[104] = (char *(*)()) F1164_10701;
	R8085[106] = (char *(*)()) F1164_10701;
	R8085[117] = (char *(*)()) F1115_10087;
	R8085[123] = (char *(*)()) F1115_10087;
	R8085[127] = (char *(*)()) F1115_10087;
	R8085[132] = (char *(*)()) F1115_10087;
	{long i; for (i = 142; i < 144; i++) R8085[i] = (char *(*)()) F1164_10701;}
}

char *(*R8086[144])();
void R8086_init () {
	R8086[0] = (char *(*)()) F1115_10088;
	{long i; for (i = 42; i < 44; i++) R8086[i] = (char *(*)()) F1115_10088;}
	{long i; for (i = 60; i < 62; i++) R8086[i] = (char *(*)()) F1164_10702;}
	{long i; for (i = 70; i < 72; i++) R8086[i] = (char *(*)()) F1164_10702;}
	R8086[73] = (char *(*)()) F1164_10702;
	R8086[74] = (char *(*)()) F1115_10088;
	{long i; for (i = 76; i < 78; i++) R8086[i] = (char *(*)()) F1115_10088;}
	{long i; for (i = 97; i < 100; i++) R8086[i] = (char *(*)()) F1164_10702;}
	R8086[104] = (char *(*)()) F1164_10702;
	R8086[106] = (char *(*)()) F1164_10702;
	R8086[117] = (char *(*)()) F1115_10088;
	R8086[123] = (char *(*)()) F1115_10088;
	R8086[127] = (char *(*)()) F1115_10088;
	R8086[132] = (char *(*)()) F1115_10088;
	{long i; for (i = 142; i < 144; i++) R8086[i] = (char *(*)()) F1164_10702;}
}

char *(*R8094[144])();
void R8094_init () {
	R8094[0] = (char *(*)()) F1115_10096;
	{long i; for (i = 42; i < 44; i++) R8094[i] = (char *(*)()) F1115_10096;}
	{long i; for (i = 60; i < 62; i++) R8094[i] = (char *(*)()) F1115_10096;}
	{long i; for (i = 70; i < 72; i++) R8094[i] = (char *(*)()) F1115_10096;}
	{long i; for (i = 73; i < 75; i++) R8094[i] = (char *(*)()) F1115_10096;}
	{long i; for (i = 76; i < 78; i++) R8094[i] = (char *(*)()) F1115_10096;}
	{long i; for (i = 97; i < 99; i++) R8094[i] = (char *(*)()) F1115_10096;}
	R8094[99] = (char *(*)()) F1216_11569;
	R8094[104] = (char *(*)()) F1115_10096;
	R8094[106] = (char *(*)()) F1115_10096;
	R8094[117] = (char *(*)()) F1115_10096;
	R8094[123] = (char *(*)()) F1115_10096;
	R8094[127] = (char *(*)()) F1115_10096;
	R8094[132] = (char *(*)()) F1249_12109;
	{long i; for (i = 142; i < 144; i++) R8094[i] = (char *(*)()) F1115_10096;}
}

char *(*R8100[144])();
void R8100_init () {
	R8100[0] = (char *(*)()) F1115_10102;
	{long i; for (i = 42; i < 44; i++) R8100[i] = (char *(*)()) F1115_10102;}
	{long i; for (i = 60; i < 62; i++) R8100[i] = (char *(*)()) F1115_10102;}
	{long i; for (i = 70; i < 72; i++) R8100[i] = (char *(*)()) F1115_10102;}
	{long i; for (i = 73; i < 75; i++) R8100[i] = (char *(*)()) F1115_10102;}
	{long i; for (i = 76; i < 78; i++) R8100[i] = (char *(*)()) F1115_10102;}
	{long i; for (i = 97; i < 100; i++) R8100[i] = (char *(*)()) F1115_10102;}
	R8100[104] = (char *(*)()) F1115_10102;
	R8100[106] = (char *(*)()) F1115_10102;
	R8100[117] = (char *(*)()) F1115_10102;
	R8100[123] = (char *(*)()) F1115_10102;
	R8100[127] = (char *(*)()) F1115_10102;
	R8100[132] = (char *(*)()) F1115_10102;
	R8100[142] = (char *(*)()) F1259_12455;
	R8100[143] = (char *(*)()) F1115_10102;
}

char *(*R8101[144])();
void R8101_init () {
	R8101[0] = (char *(*)()) F1115_10103;
	{long i; for (i = 42; i < 44; i++) R8101[i] = (char *(*)()) F1115_10103;}
	{long i; for (i = 60; i < 62; i++) R8101[i] = (char *(*)()) F1115_10103;}
	{long i; for (i = 70; i < 72; i++) R8101[i] = (char *(*)()) F1115_10103;}
	R8101[73] = (char *(*)()) F1115_10103;
	R8101[74] = (char *(*)()) F1191_11084;
	{long i; for (i = 76; i < 78; i++) R8101[i] = (char *(*)()) F1191_11084;}
	{long i; for (i = 97; i < 100; i++) R8101[i] = (char *(*)()) F1115_10103;}
	R8101[104] = (char *(*)()) F1115_10103;
	R8101[106] = (char *(*)()) F1115_10103;
	R8101[117] = (char *(*)()) F1115_10103;
	R8101[123] = (char *(*)()) F1115_10103;
	R8101[127] = (char *(*)()) F1115_10103;
	R8101[132] = (char *(*)()) F1115_10103;
	{long i; for (i = 142; i < 144; i++) R8101[i] = (char *(*)()) F1115_10103;}
}

char *(*R8105[144])();
void R8105_init () {
	R8105[0] = (char *(*)()) F1116_10137;
	{long i; for (i = 42; i < 44; i++) R8105[i] = (char *(*)()) F1116_10137;}
	{long i; for (i = 60; i < 62; i++) R8105[i] = (char *(*)()) F1115_10107;}
	{long i; for (i = 70; i < 72; i++) R8105[i] = (char *(*)()) F1115_10107;}
	R8105[73] = (char *(*)()) F1115_10107;
	R8105[74] = (char *(*)()) F1191_11097;
	{long i; for (i = 76; i < 78; i++) R8105[i] = (char *(*)()) F1191_11097;}
	{long i; for (i = 97; i < 100; i++) R8105[i] = (char *(*)()) F1115_10107;}
	R8105[104] = (char *(*)()) F1115_10107;
	R8105[106] = (char *(*)()) F1115_10107;
	R8105[117] = (char *(*)()) F1115_10107;
	R8105[123] = (char *(*)()) F1115_10107;
	R8105[132] = (char *(*)()) F1115_10107;
	{long i; for (i = 142; i < 144; i++) R8105[i] = (char *(*)()) F1115_10107;}
}

char *(*R8107[144])();
void R8107_init () {
	R8107[0] = (char *(*)()) F1115_10109;
	{long i; for (i = 42; i < 44; i++) R8107[i] = (char *(*)()) F1115_10109;}
	{long i; for (i = 60; i < 62; i++) R8107[i] = (char *(*)()) F1115_10109;}
	{long i; for (i = 70; i < 72; i++) R8107[i] = (char *(*)()) F1115_10109;}
	{long i; for (i = 73; i < 75; i++) R8107[i] = (char *(*)()) F1115_10109;}
	{long i; for (i = 76; i < 78; i++) R8107[i] = (char *(*)()) F1193_11172;}
	{long i; for (i = 97; i < 100; i++) R8107[i] = (char *(*)()) F1115_10109;}
	R8107[104] = (char *(*)()) F1115_10109;
	R8107[106] = (char *(*)()) F1115_10109;
	R8107[117] = (char *(*)()) F1115_10109;
	R8107[123] = (char *(*)()) F1115_10109;
	R8107[127] = (char *(*)()) F1115_10109;
	R8107[132] = (char *(*)()) F1115_10109;
	{long i; for (i = 142; i < 144; i++) R8107[i] = (char *(*)()) F1115_10109;}
}

char *(*R8117[78])();
void R8117_init () {
	R8117[0] = (char *(*)()) F1116_10119;
	{long i; for (i = 42; i < 44; i++) R8117[i] = (char *(*)()) F1116_10119;}
	R8117[74] = (char *(*)()) F1116_10119;
	R8117[76] = (char *(*)()) F1116_10119;
	R8117[77] = (char *(*)()) F1194_11190;
}

char *(*R8128[78])();
void R8128_init () {
	R8128[0] = (char *(*)()) F1116_10136;
	R8128[74] = (char *(*)()) F1116_10136;
	{long i; for (i = 76; i < 78; i++) R8128[i] = (char *(*)()) F1193_11180;}
}

char *(*R8129[78])();
void R8129_init () {
	R8129[0] = (char *(*)()) F1116_10138;
	{long i; for (i = 42; i < 44; i++) R8129[i] = (char *(*)()) F1116_10138;}
	R8129[74] = (char *(*)()) F1191_11100;
	{long i; for (i = 76; i < 78; i++) R8129[i] = (char *(*)()) F1191_11100;}
}

char *(*R8135[78])();
void R8135_init () {
	R8135[0] = (char *(*)()) F1116_10144;
	{long i; for (i = 42; i < 44; i++) R8135[i] = (char *(*)()) F1154_10510;}
	R8135[74] = (char *(*)()) F1116_10144;
	{long i; for (i = 76; i < 78; i++) R8135[i] = (char *(*)()) F1116_10144;}
}

char *(*R8136[78])();
void R8136_init () {
	R8136[0] = (char *(*)()) F1117_10176;
	{long i; for (i = 42; i < 44; i++) R8136[i] = (char *(*)()) F1154_10509;}
	R8136[74] = (char *(*)()) F1183_10931;
	{long i; for (i = 76; i < 78; i++) R8136[i] = (char *(*)()) F1183_10931;}
}

char *(*R8137[78])();
void R8137_init () {
	R8137[0] = (char *(*)()) F1117_10177;
	{long i; for (i = 42; i < 44; i++) R8137[i] = (char *(*)()) F1154_10508;}
	R8137[74] = (char *(*)()) F1164_10688;
	{long i; for (i = 76; i < 78; i++) R8137[i] = (char *(*)()) F1164_10688;}
}

char *(*R8139[78])();
void R8139_init () {
	R8139[0] = (char *(*)()) F1117_10178;
	{long i; for (i = 42; i < 44; i++) R8139[i] = (char *(*)()) F1154_10512;}
	R8139[74] = (char *(*)()) F1191_11140;
	R8139[76] = (char *(*)()) F1191_11140;
	R8139[77] = (char *(*)()) F1194_11193;
}

char *(*R8140[78])();
void R8140_init () {
	R8140[0] = (char *(*)()) F1116_10149;
	{long i; for (i = 42; i < 44; i++) R8140[i] = (char *(*)()) F1116_10149;}
	R8140[74] = (char *(*)()) F1191_11120;
	{long i; for (i = 76; i < 78; i++) R8140[i] = (char *(*)()) F1193_11163;}
}

char *(*R8206[68])();
void R8206_init () {
	{long i; for (i = 0; i < 2; i++) R8206[i] = (char *(*)()) F1170_10808;}
	R8206[38] = (char *(*)()) F1215_11560;
	R8206[67] = (char *(*)()) F1124_10243;
}

char *(*R8207[68])();
void R8207_init () {
	{long i; for (i = 0; i < 2; i++) R8207[i] = (char *(*)()) F1170_10809;}
	R8207[38] = (char *(*)()) F1215_11561;
	R8207[67] = (char *(*)()) F1124_10247;
}

static EIF_TYPE_INDEX Y8208_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype3[] = {1077,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype4[] = {1068,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype6[] = {1068,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype7[] = {1068,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype8[] = {1068,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype9[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype10[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype11[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype12[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype13[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype14[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype15[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype16[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype17[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype18[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype19[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype20[] = {1026,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype21[] = {1077,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype22[] = {1063,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype23[] = {1064,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype24[] = {1062,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype25[] = {1062,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype26[] = {1062,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype27[] = {1077,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype28[] = {1063,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype29[] = {1064,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype30[] = {1062,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype31[] = {1062,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype32[] = {1062,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype33[] = {1077,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype34[] = {1077,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype35[] = {1077,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype36[] = {1077,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype37[] = {1068,0xFFFF};
static EIF_TYPE_INDEX Y8208_pgtype38[] = {1068,0xFFFF};
EIF_TYPE_INDEX *Y8208_gen_type [127];
EIF_TYPE_INDEX Y8208 [127];
void Y8208_init (void)
{
	egc_routines_types [8208] = Y8208;
	egc_routines_gen_types [8208] = Y8208_gen_type;
	egc_routines_offset [8208] = 1117;
	Y8208_gen_type [0] = Y8208_pgtype0;
	Y8208_gen_type [1] = Y8208_pgtype1;
	Y8208_gen_type [2] = Y8208_pgtype2;
	Y8208_gen_type [3] = Y8208_pgtype3;
	Y8208_gen_type [4] = Y8208_pgtype4;
	Y8208_gen_type [5] = Y8208_pgtype5;
	Y8208_gen_type [6] = Y8208_pgtype6;
	Y8208_gen_type [10] = Y8208_pgtype7;
	Y8208_gen_type [11] = Y8208_pgtype8;
	Y8208_gen_type [49] = Y8208_pgtype9;
	Y8208_gen_type [50] = Y8208_pgtype10;
	Y8208_gen_type [51] = Y8208_pgtype11;
	Y8208_gen_type [52] = Y8208_pgtype12;
	Y8208_gen_type [53] = Y8208_pgtype13;
	Y8208_gen_type [54] = Y8208_pgtype14;
	Y8208_gen_type [55] = Y8208_pgtype15;
	Y8208_gen_type [56] = Y8208_pgtype16;
	Y8208_gen_type [57] = Y8208_pgtype17;
	Y8208_gen_type [58] = Y8208_pgtype18;
	Y8208_gen_type [59] = Y8208_pgtype19;
	Y8208_gen_type [60] = Y8208_pgtype20;
	Y8208_gen_type [79] = Y8208_pgtype21;
	Y8208_gen_type [80] = Y8208_pgtype22;
	Y8208_gen_type [82] = Y8208_pgtype23;
	Y8208_gen_type [85] = Y8208_pgtype24;
	Y8208_gen_type [86] = Y8208_pgtype25;
	Y8208_gen_type [91] = Y8208_pgtype26;
	Y8208_gen_type [94] = Y8208_pgtype27;
	Y8208_gen_type [95] = Y8208_pgtype28;
	Y8208_gen_type [97] = Y8208_pgtype29;
	Y8208_gen_type [100] = Y8208_pgtype30;
	Y8208_gen_type [101] = Y8208_pgtype31;
	Y8208_gen_type [106] = Y8208_pgtype32;
	Y8208_gen_type [111] = Y8208_pgtype33;
	Y8208_gen_type [112] = Y8208_pgtype34;
	Y8208_gen_type [113] = Y8208_pgtype35;
	Y8208_gen_type [114] = Y8208_pgtype36;
	Y8208_gen_type [121] = Y8208_pgtype37;
	Y8208_gen_type [126] = Y8208_pgtype38;
	Y8208[3] = 1077;
	Y8208[4] = 1068;
	Y8208[6] = 1068;
	{long i; for (i = 10; i < 12; i++) Y8208[i] = 1068;};
	{long i; for (i = 49; i < 61; i++) Y8208[i] = 1026;};
	Y8208[79] = 1077;
	Y8208[80] = 1063;
	Y8208[82] = 1064;
	{long i; for (i = 85; i < 87; i++) Y8208[i] = 1062;};
	Y8208[91] = 1062;
	Y8208[94] = 1077;
	Y8208[95] = 1063;
	Y8208[97] = 1064;
	{long i; for (i = 100; i < 102; i++) Y8208[i] = 1062;};
	Y8208[106] = 1062;
	{long i; for (i = 111; i < 115; i++) Y8208[i] = 1077;};
	Y8208[121] = 1068;
	Y8208[126] = 1068;
}

char *(*R8228[84])();
void R8228_init () {
	{long i; for (i = 0; i < 2; i++) R8228[i] = (char *(*)()) F1126_10264;}
	{long i; for (i = 10; i < 12; i++) R8228[i] = (char *(*)()) F1126_10264;}
	{long i; for (i = 13; i < 15; i++) R8228[i] = (char *(*)()) F1126_10264;}
	{long i; for (i = 16; i < 18; i++) R8228[i] = (char *(*)()) F1126_10264;}
	{long i; for (i = 37; i < 40; i++) R8228[i] = (char *(*)()) F1126_10264;}
	R8228[44] = (char *(*)()) F1126_10264;
	R8228[46] = (char *(*)()) F1126_10264;
	{long i; for (i = 81; i < 84; i++) R8228[i] = (char *(*)()) F1256_12249;}
}

char *(*R8229[84])();
void R8229_init () {
	{long i; for (i = 0; i < 2; i++) R8229[i] = (char *(*)()) F1126_10263;}
	{long i; for (i = 10; i < 12; i++) R8229[i] = (char *(*)()) F1126_10263;}
	{long i; for (i = 13; i < 15; i++) R8229[i] = (char *(*)()) F1126_10263;}
	{long i; for (i = 16; i < 18; i++) R8229[i] = (char *(*)()) F1126_10263;}
	{long i; for (i = 37; i < 40; i++) R8229[i] = (char *(*)()) F1126_10263;}
	R8229[44] = (char *(*)()) F1126_10263;
	R8229[46] = (char *(*)()) F1126_10263;
	{long i; for (i = 81; i < 84; i++) R8229[i] = (char *(*)()) F1256_12250;}
}

char *(*R8230[84])();
void R8230_init () {
	{long i; for (i = 0; i < 2; i++) R8230[i] = (char *(*)()) F1126_10268;}
	{long i; for (i = 10; i < 12; i++) R8230[i] = (char *(*)()) F1126_10268;}
	{long i; for (i = 13; i < 15; i++) R8230[i] = (char *(*)()) F1126_10268;}
	{long i; for (i = 16; i < 18; i++) R8230[i] = (char *(*)()) F1126_10268;}
	{long i; for (i = 37; i < 39; i++) R8230[i] = (char *(*)()) F1126_10268;}
	R8230[39] = (char *(*)()) F1216_11578;
	R8230[44] = (char *(*)()) F1126_10268;
	R8230[46] = (char *(*)()) F1126_10268;
	{long i; for (i = 81; i < 84; i++) R8230[i] = (char *(*)()) F1256_12260;}
}

char *(*R8231[84])();
void R8231_init () {
	{long i; for (i = 0; i < 2; i++) R8231[i] = (char *(*)()) F1126_10265;}
	{long i; for (i = 10; i < 12; i++) R8231[i] = (char *(*)()) F1126_10265;}
	{long i; for (i = 13; i < 15; i++) R8231[i] = (char *(*)()) F1126_10265;}
	{long i; for (i = 16; i < 18; i++) R8231[i] = (char *(*)()) F1126_10265;}
	{long i; for (i = 37; i < 40; i++) R8231[i] = (char *(*)()) F1126_10265;}
	R8231[44] = (char *(*)()) F1126_10265;
	R8231[46] = (char *(*)()) F1126_10265;
	{long i; for (i = 81; i < 84; i++) R8231[i] = (char *(*)()) F1256_12259;}
}

char *(*R8236[84])();
void R8236_init () {
	{long i; for (i = 0; i < 2; i++) R8236[i] = (char *(*)()) F1176_10886;}
	R8236[10] = (char *(*)()) F1126_10271;
	R8236[11] = (char *(*)()) F1188_11019;
	{long i; for (i = 13; i < 15; i++) R8236[i] = (char *(*)()) F1126_10271;}
	{long i; for (i = 16; i < 18; i++) R8236[i] = (char *(*)()) F1126_10271;}
	R8236[37] = (char *(*)()) F1214_11542;
	{long i; for (i = 38; i < 40; i++) R8236[i] = (char *(*)()) F1126_10271;}
	R8236[44] = (char *(*)()) F1126_10271;
	R8236[46] = (char *(*)()) F1223_11813;
	{long i; for (i = 82; i < 84; i++) R8236[i] = (char *(*)()) F1126_10271;}
}

char *(*R8237[84])();
void R8237_init () {
	{long i; for (i = 0; i < 2; i++) R8237[i] = (char *(*)()) F1126_10272;}
	{long i; for (i = 10; i < 12; i++) R8237[i] = (char *(*)()) F1126_10272;}
	{long i; for (i = 13; i < 15; i++) R8237[i] = (char *(*)()) F1126_10272;}
	{long i; for (i = 16; i < 18; i++) R8237[i] = (char *(*)()) F1126_10272;}
	{long i; for (i = 37; i < 40; i++) R8237[i] = (char *(*)()) F1126_10272;}
	R8237[44] = (char *(*)()) F1220_11653;
	R8237[46] = (char *(*)()) F1220_11653;
	{long i; for (i = 82; i < 84; i++) R8237[i] = (char *(*)()) F1126_10272;}
}

char *(*R8238[84])();
void R8238_init () {
	{long i; for (i = 0; i < 2; i++) R8238[i] = (char *(*)()) F1126_10273;}
	{long i; for (i = 10; i < 12; i++) R8238[i] = (char *(*)()) F1126_10273;}
	{long i; for (i = 13; i < 15; i++) R8238[i] = (char *(*)()) F1126_10273;}
	{long i; for (i = 16; i < 18; i++) R8238[i] = (char *(*)()) F1126_10273;}
	{long i; for (i = 37; i < 40; i++) R8238[i] = (char *(*)()) F1126_10273;}
	R8238[44] = (char *(*)()) F1220_11654;
	R8238[46] = (char *(*)()) F1220_11654;
	{long i; for (i = 82; i < 84; i++) R8238[i] = (char *(*)()) F1126_10273;}
}

char *(*R8243[84])();
void R8243_init () {
	{long i; for (i = 0; i < 2; i++) R8243[i] = (char *(*)()) F1114_10076;}
	{long i; for (i = 10; i < 12; i++) R8243[i] = (char *(*)()) F1114_10076;}
	R8243[13] = (char *(*)()) F1189_11042;
	R8243[14] = (char *(*)()) F1114_10076;
	{long i; for (i = 16; i < 18; i++) R8243[i] = (char *(*)()) F1114_10076;}
	{long i; for (i = 37; i < 40; i++) R8243[i] = (char *(*)()) F1114_10076;}
	R8243[44] = (char *(*)()) F1221_11694;
	R8243[46] = (char *(*)()) F1223_11816;
	{long i; for (i = 82; i < 84; i++) R8243[i] = (char *(*)()) F1114_10076;}
}

char *(*R8245[84])();
void R8245_init () {
	{long i; for (i = 0; i < 2; i++) R8245[i] = (char *(*)()) F1176_10887;}
	R8245[10] = (char *(*)()) F1114_10064;
	R8245[11] = (char *(*)()) F1188_11007;
	R8245[13] = (char *(*)()) F1190_11051;
	R8245[14] = (char *(*)()) F1114_10064;
	{long i; for (i = 16; i < 18; i++) R8245[i] = (char *(*)()) F1114_10064;}
	R8245[37] = (char *(*)()) F1214_11543;
	R8245[38] = (char *(*)()) F1215_11545;
	R8245[39] = (char *(*)()) F1216_11570;
	R8245[44] = (char *(*)()) F1114_10064;
	R8245[46] = (char *(*)()) F1223_11776;
	{long i; for (i = 82; i < 84; i++) R8245[i] = (char *(*)()) F1114_10064;}
}

char *(*R8249[84])();
void R8249_init () {
	{long i; for (i = 0; i < 2; i++) R8249[i] = (char *(*)()) F1126_10284;}
	{long i; for (i = 10; i < 12; i++) R8249[i] = (char *(*)()) F1126_10284;}
	{long i; for (i = 13; i < 15; i++) R8249[i] = (char *(*)()) F1126_10284;}
	{long i; for (i = 16; i < 18; i++) R8249[i] = (char *(*)()) F1126_10284;}
	{long i; for (i = 37; i < 39; i++) R8249[i] = (char *(*)()) F1126_10284;}
	R8249[39] = (char *(*)()) F1216_11580;
	R8249[44] = (char *(*)()) F1126_10284;
	R8249[46] = (char *(*)()) F1126_10284;
	{long i; for (i = 82; i < 84; i++) R8249[i] = (char *(*)()) F1126_10284;}
}

char *(*R8255[102])();
void R8255_init () {
	{long i; for (i = 0; i < 2; i++) R8255[i] = (char *(*)()) F1116_10133;}
	{long i; for (i = 18; i < 20; i++) R8255[i] = (char *(*)()) F1115_10080;}
	{long i; for (i = 28; i < 30; i++) R8255[i] = (char *(*)()) F1115_10080;}
	R8255[31] = (char *(*)()) F1115_10080;
	R8255[32] = (char *(*)()) F1116_10133;
	{long i; for (i = 34; i < 36; i++) R8255[i] = (char *(*)()) F1116_10133;}
	{long i; for (i = 55; i < 58; i++) R8255[i] = (char *(*)()) F1115_10080;}
	R8255[62] = (char *(*)()) F1115_10080;
	R8255[64] = (char *(*)()) F1115_10080;
	R8255[75] = (char *(*)()) F1115_10080;
	R8255[81] = (char *(*)()) F1115_10080;
	R8255[85] = (char *(*)()) F1115_10080;
	R8255[90] = (char *(*)()) F1115_10080;
	{long i; for (i = 100; i < 102; i++) R8255[i] = (char *(*)()) F1115_10080;}
}

char *(*R8256[102])();
void R8256_init () {
	{long i; for (i = 0; i < 2; i++) R8256[i] = (char *(*)()) F1116_10135;}
	{long i; for (i = 18; i < 20; i++) R8256[i] = (char *(*)()) F1115_10081;}
	{long i; for (i = 28; i < 30; i++) R8256[i] = (char *(*)()) F1115_10081;}
	R8256[31] = (char *(*)()) F1115_10081;
	R8256[32] = (char *(*)()) F1116_10135;
	{long i; for (i = 34; i < 36; i++) R8256[i] = (char *(*)()) F1116_10135;}
	{long i; for (i = 55; i < 58; i++) R8256[i] = (char *(*)()) F1115_10081;}
	R8256[62] = (char *(*)()) F1115_10081;
	R8256[64] = (char *(*)()) F1115_10081;
	R8256[75] = (char *(*)()) F1115_10081;
	R8256[81] = (char *(*)()) F1115_10081;
	R8256[85] = (char *(*)()) F1115_10081;
	R8256[90] = (char *(*)()) F1115_10081;
	{long i; for (i = 100; i < 102; i++) R8256[i] = (char *(*)()) F1115_10081;}
}

char *(*R8257[102])();
void R8257_init () {
	{long i; for (i = 0; i < 2; i++) R8257[i] = (char *(*)()) F1116_10124;}
	{long i; for (i = 18; i < 20; i++) R8257[i] = (char *(*)()) F1164_10699;}
	{long i; for (i = 28; i < 30; i++) R8257[i] = (char *(*)()) F1164_10699;}
	R8257[31] = (char *(*)()) F1164_10699;
	R8257[32] = (char *(*)()) F1116_10124;
	{long i; for (i = 34; i < 36; i++) R8257[i] = (char *(*)()) F1116_10124;}
	{long i; for (i = 55; i < 58; i++) R8257[i] = (char *(*)()) F1164_10699;}
	R8257[62] = (char *(*)()) F1164_10699;
	R8257[64] = (char *(*)()) F1164_10699;
	R8257[75] = (char *(*)()) F1115_10104;
	R8257[81] = (char *(*)()) F1115_10104;
	R8257[85] = (char *(*)()) F1115_10104;
	R8257[90] = (char *(*)()) F1115_10104;
	R8257[100] = (char *(*)()) F1164_10699;
	R8257[101] = (char *(*)()) F1260_12466;
}

char *(*R8258[102])();
void R8258_init () {
	{long i; for (i = 0; i < 2; i++) R8258[i] = (char *(*)()) F1116_10125;}
	{long i; for (i = 18; i < 20; i++) R8258[i] = (char *(*)()) F1164_10700;}
	{long i; for (i = 28; i < 30; i++) R8258[i] = (char *(*)()) F1164_10700;}
	R8258[31] = (char *(*)()) F1164_10700;
	R8258[32] = (char *(*)()) F1116_10125;
	{long i; for (i = 34; i < 36; i++) R8258[i] = (char *(*)()) F1116_10125;}
	{long i; for (i = 55; i < 58; i++) R8258[i] = (char *(*)()) F1164_10700;}
	R8258[62] = (char *(*)()) F1164_10700;
	R8258[64] = (char *(*)()) F1164_10700;
	R8258[75] = (char *(*)()) F1115_10105;
	R8258[81] = (char *(*)()) F1115_10105;
	R8258[85] = (char *(*)()) F1115_10105;
	R8258[90] = (char *(*)()) F1115_10105;
	R8258[100] = (char *(*)()) F1164_10700;
	R8258[101] = (char *(*)()) F1260_12467;
}

char *(*R8343[84])();
void R8343_init () {
	{long i; for (i = 0; i < 2; i++) R8343[i] = (char *(*)()) F1137_10411;}
	{long i; for (i = 10; i < 12; i++) R8343[i] = (char *(*)()) F1137_10411;}
	{long i; for (i = 13; i < 15; i++) R8343[i] = (char *(*)()) F1137_10411;}
	{long i; for (i = 16; i < 18; i++) R8343[i] = (char *(*)()) F1137_10411;}
	{long i; for (i = 37; i < 40; i++) R8343[i] = (char *(*)()) F1137_10411;}
	R8343[44] = (char *(*)()) F1137_10411;
	R8343[46] = (char *(*)()) F1137_10411;
	R8343[63] = (char *(*)()) F1137_10411;
	R8343[67] = (char *(*)()) F1137_10411;
	R8343[72] = (char *(*)()) F1249_12119;
	{long i; for (i = 82; i < 84; i++) R8343[i] = (char *(*)()) F1137_10411;}
}

char *(*R8344[84])();
void R8344_init () {
	{long i; for (i = 0; i < 2; i++) R8344[i] = (char *(*)()) F1137_10412;}
	{long i; for (i = 10; i < 12; i++) R8344[i] = (char *(*)()) F1137_10412;}
	{long i; for (i = 13; i < 15; i++) R8344[i] = (char *(*)()) F1137_10412;}
	{long i; for (i = 16; i < 18; i++) R8344[i] = (char *(*)()) F1137_10412;}
	{long i; for (i = 37; i < 40; i++) R8344[i] = (char *(*)()) F1137_10412;}
	R8344[44] = (char *(*)()) F1137_10412;
	R8344[46] = (char *(*)()) F1137_10412;
	R8344[63] = (char *(*)()) F1137_10412;
	R8344[67] = (char *(*)()) F1137_10412;
	R8344[72] = (char *(*)()) F1249_12120;
	{long i; for (i = 82; i < 84; i++) R8344[i] = (char *(*)()) F1137_10412;}
}

char *(*R8345[84])();
void R8345_init () {
	{long i; for (i = 0; i < 2; i++) R8345[i] = (char *(*)()) F1137_10416;}
	{long i; for (i = 10; i < 12; i++) R8345[i] = (char *(*)()) F1137_10416;}
	{long i; for (i = 13; i < 15; i++) R8345[i] = (char *(*)()) F1137_10416;}
	{long i; for (i = 16; i < 18; i++) R8345[i] = (char *(*)()) F1137_10416;}
	{long i; for (i = 37; i < 40; i++) R8345[i] = (char *(*)()) F1137_10416;}
	R8345[44] = (char *(*)()) F1137_10416;
	R8345[46] = (char *(*)()) F1137_10416;
	R8345[63] = (char *(*)()) F1137_10416;
	R8345[67] = (char *(*)()) F1137_10416;
	R8345[72] = (char *(*)()) F1249_12123;
	{long i; for (i = 82; i < 84; i++) R8345[i] = (char *(*)()) F1137_10416;}
}

char *(*R8346[84])();
void R8346_init () {
	{long i; for (i = 0; i < 2; i++) R8346[i] = (char *(*)()) F1137_10414;}
	{long i; for (i = 10; i < 12; i++) R8346[i] = (char *(*)()) F1137_10414;}
	{long i; for (i = 13; i < 15; i++) R8346[i] = (char *(*)()) F1137_10414;}
	{long i; for (i = 16; i < 18; i++) R8346[i] = (char *(*)()) F1137_10414;}
	{long i; for (i = 37; i < 40; i++) R8346[i] = (char *(*)()) F1137_10414;}
	R8346[44] = (char *(*)()) F1137_10414;
	R8346[46] = (char *(*)()) F1137_10414;
	R8346[63] = (char *(*)()) F1137_10414;
	R8346[67] = (char *(*)()) F1137_10414;
	R8346[72] = (char *(*)()) F1249_12122;
	{long i; for (i = 82; i < 84; i++) R8346[i] = (char *(*)()) F1137_10414;}
}

char *(*R8347[84])();
void R8347_init () {
	{long i; for (i = 0; i < 2; i++) R8347[i] = (char *(*)()) F1137_10410;}
	{long i; for (i = 10; i < 12; i++) R8347[i] = (char *(*)()) F1137_10410;}
	{long i; for (i = 13; i < 15; i++) R8347[i] = (char *(*)()) F1137_10410;}
	{long i; for (i = 16; i < 18; i++) R8347[i] = (char *(*)()) F1137_10410;}
	{long i; for (i = 37; i < 40; i++) R8347[i] = (char *(*)()) F1137_10410;}
	R8347[44] = (char *(*)()) F1137_10410;
	R8347[46] = (char *(*)()) F1137_10410;
	R8347[63] = (char *(*)()) F1137_10410;
	R8347[67] = (char *(*)()) F1137_10410;
	R8347[72] = (char *(*)()) F1249_12121;
	{long i; for (i = 82; i < 84; i++) R8347[i] = (char *(*)()) F1137_10410;}
}

char *(*R8349[84])();
void R8349_init () {
	{long i; for (i = 0; i < 2; i++) R8349[i] = (char *(*)()) F1164_10693;}
	{long i; for (i = 10; i < 12; i++) R8349[i] = (char *(*)()) F1164_10693;}
	{long i; for (i = 13; i < 15; i++) R8349[i] = (char *(*)()) F1164_10693;}
	{long i; for (i = 16; i < 18; i++) R8349[i] = (char *(*)()) F1164_10693;}
	{long i; for (i = 37; i < 40; i++) R8349[i] = (char *(*)()) F1164_10693;}
	R8349[44] = (char *(*)()) F1164_10693;
	R8349[46] = (char *(*)()) F1164_10693;
	R8349[63] = (char *(*)()) F1225_11842;
	R8349[67] = (char *(*)()) F1239_11980;
	{long i; for (i = 82; i < 84; i++) R8349[i] = (char *(*)()) F1164_10693;}
}

char *(*R8362[47])();
void R8362_init () {
	{long i; for (i = 0; i < 3; i++) R8362[i] = (char *(*)()) F1114_10076;}
	R8362[7] = (char *(*)()) F1221_11694;
	R8362[9] = (char *(*)()) F1223_11816;
	R8362[35] = (char *(*)()) F1114_10076;
	{long i; for (i = 45; i < 47; i++) R8362[i] = (char *(*)()) F1114_10076;}
}

char *(*R8366[73])();
void R8366_init () {
	{long i; for (i = 0; i < 2; i++) R8366[i] = (char *(*)()) F1166_10771;}
	{long i; for (i = 10; i < 12; i++) R8366[i] = (char *(*)()) F1166_10771;}
	{long i; for (i = 13; i < 15; i++) R8366[i] = (char *(*)()) F1166_10771;}
	{long i; for (i = 16; i < 18; i++) R8366[i] = (char *(*)()) F1166_10771;}
	R8366[39] = (char *(*)()) F1146_10448;
	R8366[57] = (char *(*)()) F1146_10448;
	R8366[63] = (char *(*)()) F1146_10448;
	R8366[67] = (char *(*)()) F1146_10448;
	R8366[72] = (char *(*)()) F1249_12115;
}

char *(*R8376[73])();
void R8376_init () {
	R8376[0] = (char *(*)()) F1148_10460;
	R8376[26] = (char *(*)()) F1148_10460;
	R8376[28] = (char *(*)()) F1148_10460;
	R8376[33] = (char *(*)()) F1148_10460;
	R8376[35] = (char *(*)()) F1148_10460;
	{long i; for (i = 70; i < 73; i++) R8376[i] = (char *(*)()) F1256_12258;}
}

char *(*R8377[36])();
void R8377_init () {
	R8377[0] = (char *(*)()) F1114_10076;
	R8377[26] = (char *(*)()) F1114_10076;
	R8377[28] = (char *(*)()) F1114_10076;
	R8377[33] = (char *(*)()) F1221_11694;
	R8377[35] = (char *(*)()) F1223_11816;
}

char *(*R8378[36])();
void R8378_init () {
	R8378[0] = (char *(*)()) F1148_10462;
	R8378[26] = (char *(*)()) F1148_10462;
	R8378[28] = (char *(*)()) F1216_11568;
	R8378[33] = (char *(*)()) F1148_10462;
	R8378[35] = (char *(*)()) F1148_10462;
}

char *(*R8380[62])();
void R8380_init () {
	R8380[0] = (char *(*)()) F1188_11016;
	R8380[26] = (char *(*)()) F1150_10469;
	R8380[28] = (char *(*)()) F1150_10469;
	R8380[33] = (char *(*)()) F1221_11676;
	R8380[35] = (char *(*)()) F1223_11779;
	R8380[52] = (char *(*)()) F1150_10469;
	R8380[56] = (char *(*)()) F1150_10469;
	R8380[61] = (char *(*)()) F1249_12110;
}

char *(*R8381[62])();
void R8381_init () {
	R8381[0] = (char *(*)()) F1188_11017;
	R8381[26] = (char *(*)()) F1150_10474;
	R8381[28] = (char *(*)()) F1150_10474;
	R8381[33] = (char *(*)()) F1221_11686;
	R8381[35] = (char *(*)()) F1223_11781;
	R8381[52] = (char *(*)()) F1240_11991;
	R8381[56] = (char *(*)()) F1240_11991;
	R8381[61] = (char *(*)()) F1249_12114;
}

char *(*R8389[31])();
void R8389_init () {
	R8389[0] = (char *(*)()) F1150_10477;
	R8389[2] = (char *(*)()) F1150_10477;
	R8389[26] = (char *(*)()) F1240_11995;
	R8389[30] = (char *(*)()) F1240_11995;
}

char *(*R8393[36])();
void R8393_init () {
	R8393[0] = (char *(*)()) F1188_11014;
	R8393[26] = (char *(*)()) F1150_10471;
	R8393[28] = (char *(*)()) F1216_11572;
	R8393[35] = (char *(*)()) F1223_11787;
}

char *(*R8394[36])();
void R8394_init () {
	R8394[0] = (char *(*)()) F1188_11012;
	R8394[26] = (char *(*)()) F1150_10472;
	R8394[28] = (char *(*)()) F1216_11573;
	R8394[35] = (char *(*)()) F1223_11785;
}

char *(*R8405[2])();
void R8405_init () {
	R8405[0] = (char *(*)()) F1156_10529;
	R8405[1] = (char *(*)()) F1157_10535;
}

char *(*R8412[2])();
void R8412_init () {
	R8412[0] = (char *(*)()) F1158_10538;
	R8412[1] = (char *(*)()) F1160_10557;
}

char *(*R8428[2])();
void R8428_init () {
	R8428[0] = (char *(*)()) F1159_10554;
	R8428[1] = (char *(*)()) F1160_10562;
}

char *(*R8486[84])();
void R8486_init () {
	{long i; for (i = 0; i < 2; i++) R8486[i] = (char *(*)()) F1162_10619;}
	{long i; for (i = 10; i < 12; i++) R8486[i] = (char *(*)()) F1162_10619;}
	{long i; for (i = 13; i < 15; i++) R8486[i] = (char *(*)()) F1162_10619;}
	{long i; for (i = 16; i < 18; i++) R8486[i] = (char *(*)()) F1162_10619;}
	{long i; for (i = 37; i < 40; i++) R8486[i] = (char *(*)()) F1162_10619;}
	R8486[44] = (char *(*)()) F1162_10619;
	R8486[46] = (char *(*)()) F1162_10619;
	R8486[57] = (char *(*)()) F1162_10619;
	R8486[63] = (char *(*)()) F1162_10619;
	R8486[67] = (char *(*)()) F1162_10619;
	R8486[72] = (char *(*)()) F1162_10619;
	R8486[82] = (char *(*)()) F1259_12447;
	R8486[83] = (char *(*)()) F1162_10619;
}

char *(*R8488[84])();
void R8488_init () {
	{long i; for (i = 0; i < 2; i++) R8488[i] = (char *(*)()) F118_2672;}
	{long i; for (i = 10; i < 12; i++) R8488[i] = (char *(*)()) F118_2672;}
	{long i; for (i = 13; i < 15; i++) R8488[i] = (char *(*)()) F118_2672;}
	{long i; for (i = 16; i < 18; i++) R8488[i] = (char *(*)()) F118_2672;}
	{long i; for (i = 37; i < 40; i++) R8488[i] = (char *(*)()) F118_2672;}
	R8488[44] = (char *(*)()) F118_2672;
	R8488[46] = (char *(*)()) F118_2672;
	R8488[57] = (char *(*)()) F75_1145;
	R8488[63] = (char *(*)()) F75_1145;
	R8488[67] = (char *(*)()) F75_1145;
	R8488[72] = (char *(*)()) F75_1145;
	{long i; for (i = 82; i < 84; i++) R8488[i] = (char *(*)()) F118_2672;}
}

char *(*R8489[84])();
void R8489_init () {
	{long i; for (i = 0; i < 2; i++) R8489[i] = (char *(*)()) F1164_10692;}
	{long i; for (i = 10; i < 12; i++) R8489[i] = (char *(*)()) F1164_10692;}
	{long i; for (i = 13; i < 15; i++) R8489[i] = (char *(*)()) F1164_10692;}
	{long i; for (i = 16; i < 18; i++) R8489[i] = (char *(*)()) F1164_10692;}
	{long i; for (i = 37; i < 40; i++) R8489[i] = (char *(*)()) F1164_10692;}
	R8489[44] = (char *(*)()) F1164_10692;
	R8489[46] = (char *(*)()) F1164_10692;
	R8489[57] = (char *(*)()) F1233_11965;
	R8489[63] = (char *(*)()) F1233_11965;
	R8489[67] = (char *(*)()) F1233_11965;
	R8489[72] = (char *(*)()) F1233_11965;
	R8489[82] = (char *(*)()) F1259_12456;
	R8489[83] = (char *(*)()) F1164_10692;
}

char *(*R8496[84])();
void R8496_init () {
	{long i; for (i = 0; i < 2; i++) R8496[i] = (char *(*)()) F1131_10326;}
	{long i; for (i = 10; i < 12; i++) R8496[i] = (char *(*)()) F1131_10326;}
	{long i; for (i = 13; i < 15; i++) R8496[i] = (char *(*)()) F1131_10326;}
	{long i; for (i = 16; i < 18; i++) R8496[i] = (char *(*)()) F1131_10326;}
	{long i; for (i = 37; i < 40; i++) R8496[i] = (char *(*)()) F1131_10326;}
	R8496[44] = (char *(*)()) F1131_10326;
	R8496[46] = (char *(*)()) F1131_10326;
	R8496[57] = (char *(*)()) F1234_11973;
	R8496[63] = (char *(*)()) F1240_11989;
	R8496[67] = (char *(*)()) F1240_11989;
	R8496[72] = (char *(*)()) F1131_10326;
	{long i; for (i = 82; i < 84; i++) R8496[i] = (char *(*)()) F1131_10326;}
}

char *(*R8513[84])();
void R8513_init () {
	{long i; for (i = 0; i < 2; i++) R8513[i] = (char *(*)()) F1115_10109;}
	{long i; for (i = 10; i < 12; i++) R8513[i] = (char *(*)()) F1115_10109;}
	{long i; for (i = 13; i < 15; i++) R8513[i] = (char *(*)()) F1115_10109;}
	{long i; for (i = 16; i < 18; i++) R8513[i] = (char *(*)()) F1193_11172;}
	{long i; for (i = 37; i < 40; i++) R8513[i] = (char *(*)()) F1115_10109;}
	R8513[44] = (char *(*)()) F1115_10109;
	R8513[46] = (char *(*)()) F1115_10109;
	{long i; for (i = 82; i < 84; i++) R8513[i] = (char *(*)()) F1115_10109;}
}

char *(*R8514[84])();
void R8514_init () {
	{long i; for (i = 0; i < 2; i++) R8514[i] = (char *(*)()) F1115_10103;}
	{long i; for (i = 10; i < 12; i++) R8514[i] = (char *(*)()) F1115_10103;}
	R8514[13] = (char *(*)()) F1115_10103;
	R8514[14] = (char *(*)()) F1191_11084;
	{long i; for (i = 16; i < 18; i++) R8514[i] = (char *(*)()) F1191_11084;}
	{long i; for (i = 37; i < 40; i++) R8514[i] = (char *(*)()) F1115_10103;}
	R8514[44] = (char *(*)()) F1115_10103;
	R8514[46] = (char *(*)()) F1115_10103;
	{long i; for (i = 82; i < 84; i++) R8514[i] = (char *(*)()) F1115_10103;}
}

char *(*R8516[84])();
void R8516_init () {
	{long i; for (i = 0; i < 2; i++) R8516[i] = (char *(*)()) F1164_10694;}
	{long i; for (i = 10; i < 12; i++) R8516[i] = (char *(*)()) F1164_10694;}
	R8516[13] = (char *(*)()) F1164_10694;
	R8516[14] = (char *(*)()) F1191_11100;
	{long i; for (i = 16; i < 18; i++) R8516[i] = (char *(*)()) F1191_11100;}
	{long i; for (i = 37; i < 40; i++) R8516[i] = (char *(*)()) F1164_10694;}
	R8516[44] = (char *(*)()) F1164_10694;
	R8516[46] = (char *(*)()) F1164_10694;
	{long i; for (i = 82; i < 84; i++) R8516[i] = (char *(*)()) F1164_10694;}
}

char *(*R8517[84])();
void R8517_init () {
	{long i; for (i = 0; i < 2; i++) R8517[i] = (char *(*)()) F1115_10107;}
	{long i; for (i = 10; i < 12; i++) R8517[i] = (char *(*)()) F1115_10107;}
	R8517[13] = (char *(*)()) F1115_10107;
	R8517[14] = (char *(*)()) F1191_11097;
	{long i; for (i = 16; i < 18; i++) R8517[i] = (char *(*)()) F1191_11097;}
	{long i; for (i = 37; i < 40; i++) R8517[i] = (char *(*)()) F1115_10107;}
	R8517[44] = (char *(*)()) F1115_10107;
	R8517[46] = (char *(*)()) F1115_10107;
	{long i; for (i = 82; i < 84; i++) R8517[i] = (char *(*)()) F1115_10107;}
}

char *(*R8533[84])();
void R8533_init () {
	{long i; for (i = 0; i < 2; i++) R8533[i] = (char *(*)()) F1167_10785;}
	{long i; for (i = 10; i < 12; i++) R8533[i] = (char *(*)()) F1179_10898;}
	R8533[13] = (char *(*)()) F1179_10898;
	R8533[14] = (char *(*)()) F1183_10958;
	{long i; for (i = 16; i < 18; i++) R8533[i] = (char *(*)()) F1183_10958;}
	R8533[37] = (char *(*)()) F1210_11386;
	R8533[38] = (char *(*)()) F1200_11270;
	R8533[39] = (char *(*)()) F1210_11386;
	R8533[44] = (char *(*)()) F1210_11386;
	R8533[46] = (char *(*)()) F1210_11386;
	{long i; for (i = 82; i < 84; i++) R8533[i] = (char *(*)()) F1210_11386;}
}

char *(*R8537[84])();
void R8537_init () {
	{long i; for (i = 0; i < 2; i++) R8537[i] = (char *(*)()) F1164_10688;}
	{long i; for (i = 10; i < 12; i++) R8537[i] = (char *(*)()) F1164_10688;}
	{long i; for (i = 13; i < 15; i++) R8537[i] = (char *(*)()) F1164_10688;}
	{long i; for (i = 16; i < 18; i++) R8537[i] = (char *(*)()) F1164_10688;}
	{long i; for (i = 37; i < 40; i++) R8537[i] = (char *(*)()) F1164_10688;}
	R8537[44] = (char *(*)()) F1164_10688;
	R8537[46] = (char *(*)()) F1223_11791;
	{long i; for (i = 82; i < 84; i++) R8537[i] = (char *(*)()) F1164_10688;}
}

char *(*R8538[84])();
void R8538_init () {
	{long i; for (i = 0; i < 2; i++) R8538[i] = (char *(*)()) F1164_10689;}
	{long i; for (i = 10; i < 12; i++) R8538[i] = (char *(*)()) F1164_10689;}
	R8538[13] = (char *(*)()) F1190_11071;
	R8538[14] = (char *(*)()) F1191_11120;
	{long i; for (i = 16; i < 18; i++) R8538[i] = (char *(*)()) F1193_11163;}
	{long i; for (i = 37; i < 40; i++) R8538[i] = (char *(*)()) F1164_10689;}
	R8538[44] = (char *(*)()) F1164_10689;
	R8538[46] = (char *(*)()) F1164_10689;
	R8538[82] = (char *(*)()) F1259_12448;
	R8538[83] = (char *(*)()) F1164_10689;
}

char *(*R8539[84])();
void R8539_init () {
	{long i; for (i = 0; i < 2; i++) R8539[i] = (char *(*)()) F1164_10690;}
	{long i; for (i = 10; i < 12; i++) R8539[i] = (char *(*)()) F1164_10690;}
	R8539[13] = (char *(*)()) F1164_10690;
	R8539[14] = (char *(*)()) F1191_11138;
	{long i; for (i = 16; i < 18; i++) R8539[i] = (char *(*)()) F1191_11138;}
	{long i; for (i = 37; i < 39; i++) R8539[i] = (char *(*)()) F1164_10690;}
	R8539[39] = (char *(*)()) F1216_11579;
	R8539[44] = (char *(*)()) F1164_10690;
	R8539[46] = (char *(*)()) F1164_10690;
	{long i; for (i = 82; i < 84; i++) R8539[i] = (char *(*)()) F1164_10690;}
}

char *(*R8548[84])();
void R8548_init () {
	{long i; for (i = 0; i < 2; i++) R8548[i] = (char *(*)()) F1166_10779;}
	{long i; for (i = 10; i < 12; i++) R8548[i] = (char *(*)()) F1166_10779;}
	{long i; for (i = 13; i < 15; i++) R8548[i] = (char *(*)()) F1166_10779;}
	{long i; for (i = 16; i < 18; i++) R8548[i] = (char *(*)()) F1166_10779;}
	R8548[37] = (char *(*)()) F1164_10715;
	R8548[38] = (char *(*)()) F1215_11549;
	R8548[39] = (char *(*)()) F1164_10715;
	R8548[44] = (char *(*)()) F1164_10715;
	R8548[46] = (char *(*)()) F1164_10715;
	{long i; for (i = 82; i < 84; i++) R8548[i] = (char *(*)()) F1164_10715;}
}

char *(*R8550[84])();
void R8550_init () {
	{long i; for (i = 0; i < 2; i++) R8550[i] = (char *(*)()) F1164_10718;}
	{long i; for (i = 10; i < 12; i++) R8550[i] = (char *(*)()) F1164_10718;}
	R8550[13] = (char *(*)()) F1164_10718;
	R8550[14] = (char *(*)()) F1191_11109;
	{long i; for (i = 16; i < 18; i++) R8550[i] = (char *(*)()) F1191_11109;}
	{long i; for (i = 37; i < 40; i++) R8550[i] = (char *(*)()) F1164_10718;}
	R8550[44] = (char *(*)()) F1164_10718;
	R8550[46] = (char *(*)()) F1164_10718;
	{long i; for (i = 82; i < 84; i++) R8550[i] = (char *(*)()) F1164_10718;}
}

char *(*R8552[84])();
void R8552_init () {
	{long i; for (i = 0; i < 2; i++) R8552[i] = (char *(*)()) F1164_10720;}
	{long i; for (i = 10; i < 12; i++) R8552[i] = (char *(*)()) F1164_10720;}
	R8552[13] = (char *(*)()) F1164_10720;
	R8552[14] = (char *(*)()) F1191_11111;
	{long i; for (i = 16; i < 18; i++) R8552[i] = (char *(*)()) F1191_11111;}
	{long i; for (i = 37; i < 40; i++) R8552[i] = (char *(*)()) F1164_10720;}
	R8552[44] = (char *(*)()) F1164_10720;
	R8552[46] = (char *(*)()) F1164_10720;
	{long i; for (i = 82; i < 84; i++) R8552[i] = (char *(*)()) F1164_10720;}
}

char *(*R8553[84])();
void R8553_init () {
	{long i; for (i = 0; i < 2; i++) R8553[i] = (char *(*)()) F1164_10721;}
	{long i; for (i = 10; i < 12; i++) R8553[i] = (char *(*)()) F1164_10721;}
	R8553[13] = (char *(*)()) F1189_11037;
	R8553[14] = (char *(*)()) F1164_10721;
	{long i; for (i = 16; i < 18; i++) R8553[i] = (char *(*)()) F1164_10721;}
	{long i; for (i = 37; i < 40; i++) R8553[i] = (char *(*)()) F1164_10721;}
	R8553[44] = (char *(*)()) F1164_10721;
	R8553[46] = (char *(*)()) F1164_10721;
	{long i; for (i = 82; i < 84; i++) R8553[i] = (char *(*)()) F1164_10721;}
}

char *(*R8560[18])();
void R8560_init () {
	{long i; for (i = 0; i < 2; i++) R8560[i] = (char *(*)()) F1118_10191;}
	{long i; for (i = 10; i < 12; i++) R8560[i] = (char *(*)()) F1165_10729;}
	{long i; for (i = 13; i < 15; i++) R8560[i] = (char *(*)()) F1165_10729;}
	{long i; for (i = 16; i < 18; i++) R8560[i] = (char *(*)()) F1165_10729;}
}

char *(*R8563[18])();
void R8563_init () {
	{long i; for (i = 0; i < 2; i++) R8563[i] = (char *(*)()) F1118_10192;}
	{long i; for (i = 10; i < 12; i++) R8563[i] = (char *(*)()) F1187_11003;}
	{long i; for (i = 13; i < 15; i++) R8563[i] = (char *(*)()) F1187_11003;}
	{long i; for (i = 16; i < 18; i++) R8563[i] = (char *(*)()) F1187_11003;}
}

char *(*R8564[18])();
void R8564_init () {
	{long i; for (i = 0; i < 2; i++) R8564[i] = (char *(*)()) F1166_10758;}
	{long i; for (i = 10; i < 12; i++) R8564[i] = (char *(*)()) F1166_10758;}
	R8564[13] = (char *(*)()) F1166_10758;
	R8564[14] = (char *(*)()) F1116_10130;
	{long i; for (i = 16; i < 18; i++) R8564[i] = (char *(*)()) F1116_10130;}
}

char *(*R8565[18])();
void R8565_init () {
	{long i; for (i = 0; i < 2; i++) R8565[i] = (char *(*)()) F1166_10759;}
	{long i; for (i = 10; i < 12; i++) R8565[i] = (char *(*)()) F1166_10759;}
	R8565[13] = (char *(*)()) F1166_10759;
	R8565[14] = (char *(*)()) F1116_10131;
	{long i; for (i = 16; i < 18; i++) R8565[i] = (char *(*)()) F1116_10131;}
}

char *(*R8567[18])();
void R8567_init () {
	{long i; for (i = 0; i < 2; i++) R8567[i] = (char *(*)()) F1118_10211;}
	{long i; for (i = 10; i < 12; i++) R8567[i] = (char *(*)()) F1179_10897;}
	{long i; for (i = 13; i < 15; i++) R8567[i] = (char *(*)()) F1179_10897;}
	{long i; for (i = 16; i < 18; i++) R8567[i] = (char *(*)()) F1179_10897;}
}

char *(*R8568[18])();
void R8568_init () {
	{long i; for (i = 0; i < 2; i++) R8568[i] = (char *(*)()) F1118_10212;}
	{long i; for (i = 10; i < 12; i++) R8568[i] = (char *(*)()) F1187_11005;}
	{long i; for (i = 13; i < 15; i++) R8568[i] = (char *(*)()) F1187_11005;}
	{long i; for (i = 16; i < 18; i++) R8568[i] = (char *(*)()) F1187_11005;}
}

char *(*R8586[18])();
void R8586_init () {
	{long i; for (i = 0; i < 2; i++) R8586[i] = (char *(*)()) F1166_10757;}
	{long i; for (i = 10; i < 12; i++) R8586[i] = (char *(*)()) F1166_10757;}
	R8586[13] = (char *(*)()) F1189_11041;
	R8586[14] = (char *(*)()) F1191_11141;
	{long i; for (i = 16; i < 18; i++) R8586[i] = (char *(*)()) F1191_11141;}
}

char *(*R8596[18])();
void R8596_init () {
	{long i; for (i = 0; i < 2; i++) R8596[i] = (char *(*)()) F1166_10778;}
	{long i; for (i = 10; i < 12; i++) R8596[i] = (char *(*)()) F1166_10778;}
	R8596[13] = (char *(*)()) F1190_11073;
	R8596[14] = (char *(*)()) F1166_10778;
	{long i; for (i = 16; i < 18; i++) R8596[i] = (char *(*)()) F1166_10778;}
}

char *(*R8597[18])();
void R8597_init () {
	{long i; for (i = 0; i < 2; i++) R8597[i] = (char *(*)()) F1176_10888;}
	{long i; for (i = 10; i < 12; i++) R8597[i] = (char *(*)()) F1166_10780;}
	R8597[13] = (char *(*)()) F1190_11079;
	R8597[14] = (char *(*)()) F1166_10780;
	{long i; for (i = 16; i < 18; i++) R8597[i] = (char *(*)()) F1166_10780;}
}

char *(*R8598[18])();
void R8598_init () {
	{long i; for (i = 0; i < 2; i++) R8598[i] = (char *(*)()) F1176_10889;}
	{long i; for (i = 10; i < 12; i++) R8598[i] = (char *(*)()) F1166_10781;}
	R8598[13] = (char *(*)()) F1189_11039;
	R8598[14] = (char *(*)()) F1166_10781;
	{long i; for (i = 16; i < 18; i++) R8598[i] = (char *(*)()) F1166_10781;}
}

char *(*R8645[2])();
void R8645_init () {
	R8645[0] = (char *(*)()) F1174_10869;
	R8645[1] = (char *(*)()) F1175_10873;
}

char *(*R8646[2])();
void R8646_init () {
	R8646[0] = (char *(*)()) F1174_10870;
	R8646[1] = (char *(*)()) F1175_10874;
}

char *(*R8647[2])();
void R8647_init () {
	R8647[0] = (char *(*)()) F1174_10871;
	R8647[1] = (char *(*)()) F1175_10875;
}

char *(*R8764[4])();
void R8764_init () {
	R8764[0] = (char *(*)()) F1191_11082;
	R8764[2] = (char *(*)()) F1191_11082;
	R8764[3] = (char *(*)()) F1194_11184;
}

char *(*R8777[4])();
void R8777_init () {
	R8777[0] = (char *(*)()) F1191_11118;
	R8777[2] = (char *(*)()) F1191_11118;
	R8777[3] = (char *(*)()) F1194_11191;
}

char *(*R8779[4])();
void R8779_init () {
	R8779[0] = (char *(*)()) F1191_11121;
	{long i; for (i = 2; i < 4; i++) R8779[i] = (char *(*)()) F1193_11164;}
}

char *(*R8906[3])();
void R8906_init () {
	R8906[0] = (char *(*)()) F1221_11667;
	R8906[2] = (char *(*)()) F1223_11799;
}

char *(*R8911[3])();
void R8911_init () {
	R8911[0] = (char *(*)()) F1220_11649;
	R8911[2] = (char *(*)()) F1223_11780;
}

char *(*R8912[3])();
void R8912_init () {
	R8912[0] = (char *(*)()) F1221_11669;
	R8912[2] = (char *(*)()) F1223_11803;
}

char *(*R9072[3])();
void R9072_init () {
	R9072[0] = (char *(*)()) F1221_11696;
	R9072[2] = (char *(*)()) F1223_11811;
}

char *(*R9136[16])();
void R9136_init () {
	R9136[0] = (char *(*)()) F1225_11842;
	R9136[6] = (char *(*)()) F1225_11842;
	R9136[10] = (char *(*)()) F1239_11980;
	R9136[15] = (char *(*)()) F1225_11842;
}

char *(*R9138[16])();
void R9138_init () {
	R9138[0] = (char *(*)()) F1233_11970;
	R9138[6] = (char *(*)()) F1233_11970;
	R9138[10] = (char *(*)()) F1233_11970;
	R9138[15] = (char *(*)()) F1247_12096;
}

char *(*R9182[5])();
void R9182_init () {
	R9182[0] = (char *(*)()) F1240_11996;
	R9182[4] = (char *(*)()) F1244_12037;
}

char *(*R9220[3])();
void R9220_init () {
	R9220[0] = (char *(*)()) F1258_12373;
	R9220[1] = (char *(*)()) F1164_10699;
	R9220[2] = (char *(*)()) F1260_12466;
}

char *(*R9221[3])();
void R9221_init () {
	R9221[0] = (char *(*)()) F1258_12372;
	R9221[1] = (char *(*)()) F1164_10700;
	R9221[2] = (char *(*)()) F1260_12467;
}

char *(*R9228[3])();
void R9228_init () {
	R9228[0] = (char *(*)()) F1258_12417;
	{long i; for (i = 1; i < 3; i++) R9228[i] = (char *(*)()) F1256_12261;}
}

char *(*R9229[3])();
void R9229_init () {
	R9229[0] = (char *(*)()) F1258_12416;
	{long i; for (i = 1; i < 3; i++) R9229[i] = (char *(*)()) F1256_12262;}
}

char *(*R9235[3])();
void R9235_init () {
	R9235[0] = (char *(*)()) F1258_12418;
	{long i; for (i = 1; i < 3; i++) R9235[i] = (char *(*)()) F1256_12269;}
}

char *(*R9236[3])();
void R9236_init () {
	R9236[0] = (char *(*)()) F1258_12419;
	{long i; for (i = 1; i < 3; i++) R9236[i] = (char *(*)()) F1256_12270;}
}

char *(*R9241[3])();
void R9241_init () {
	R9241[0] = (char *(*)()) F1258_12408;
	R9241[1] = (char *(*)()) F1259_12435;
	R9241[2] = (char *(*)()) F1251_12157;
}

char *(*R9242[3])();
void R9242_init () {
	R9242[0] = (char *(*)()) F1258_12409;
	R9242[1] = (char *(*)()) F1259_12436;
	R9242[2] = (char *(*)()) F1260_12483;
}

char *(*R9245[3])();
void R9245_init () {
	R9245[0] = (char *(*)()) F1258_12397;
	{long i; for (i = 1; i < 3; i++) R9245[i] = (char *(*)()) F1256_12277;}
}

char *(*R9246[3])();
void R9246_init () {
	R9246[0] = (char *(*)()) F1258_12400;
	{long i; for (i = 1; i < 3; i++) R9246[i] = (char *(*)()) F1256_12278;}
}

char *(*R9252[3])();
void R9252_init () {
	R9252[0] = (char *(*)()) F1258_12398;
	{long i; for (i = 1; i < 3; i++) R9252[i] = (char *(*)()) F1256_12286;}
}

char *(*R9259[3])();
void R9259_init () {
	R9259[0] = (char *(*)()) F1258_12399;
	{long i; for (i = 1; i < 3; i++) R9259[i] = (char *(*)()) F1256_12295;}
}

char *(*R9262[3])();
void R9262_init () {
	R9262[0] = (char *(*)()) F1258_12404;
	{long i; for (i = 1; i < 3; i++) R9262[i] = (char *(*)()) F1256_12300;}
}

char *(*R9263[3])();
void R9263_init () {
	R9263[0] = (char *(*)()) F1258_12405;
	{long i; for (i = 1; i < 3; i++) R9263[i] = (char *(*)()) F1256_12302;}
}

char *(*R9319[3])();
void R9319_init () {
	R9319[0] = (char *(*)()) F1258_12352;
	R9319[1] = (char *(*)()) F1259_12439;
	R9319[2] = (char *(*)()) F1260_12485;
}

char *(*R9321[3])();
void R9321_init () {
	R9321[0] = (char *(*)()) F1258_12413;
	R9321[1] = (char *(*)()) F1259_12433;
	R9321[2] = (char *(*)()) F1260_12481;
}

char *(*R9322[3])();
void R9322_init () {
	R9322[0] = (char *(*)()) F1258_12414;
	R9322[1] = (char *(*)()) F1259_12434;
	R9322[2] = (char *(*)()) F1260_12482;
}

char *(*R9342[3])();
void R9342_init () {
	{long i; for (i = 0; i < 2; i++) R9342[i] = (char *(*)()) F1256_12309;}
	R9342[2] = (char *(*)()) F1260_12475;
}

char *(*R9344[3])();
void R9344_init () {
	R9344[0] = (char *(*)()) F1258_12378;
	{long i; for (i = 1; i < 3; i++) R9344[i] = (char *(*)()) F1256_12311;}
}

char *(*R9345[3])();
void R9345_init () {
	R9345[0] = (char *(*)()) F1258_12379;
	{long i; for (i = 1; i < 3; i++) R9345[i] = (char *(*)()) F1256_12312;}
}

char *(*R9346[3])();
void R9346_init () {
	R9346[0] = (char *(*)()) F1258_12422;
	{long i; for (i = 1; i < 3; i++) R9346[i] = (char *(*)()) F1256_12313;}
}

char *(*R9513[2])();
void R9513_init () {
	R9513[0] = (char *(*)()) F1269_12675;
	R9513[1] = (char *(*)()) F1270_12683;
}

char *(*R9518[2])();
void R9518_init () {
	R9518[0] = (char *(*)()) F1269_12670;
	R9518[1] = (char *(*)()) F1270_12684;
}

char *(*R9520[2])();
void R9520_init () {
	R9520[0] = (char *(*)()) F1269_12671;
	R9520[1] = (char *(*)()) F1270_12685;
}
char *(*R2[1275])();
void R2_init () {}
char *(*R6[1275])();
void R6_init () {}

char *(*R3[1275])();
void R3_init () {
	R3[814] = (char *(*)()) F815_5384;
	R3[815] = (char *(*)()) F816_5389;
	R3[817] = (char *(*)()) F818_5416;
	R3[818] = (char *(*)()) F819_5425;
	R3[819] = (char *(*)()) F820_5436;
	R3[820] = (char *(*)()) F821_5534;
	{long i; for (i = 823; i < 825; i++) R3[i] = (char *(*)()) F822_5574;}
	R3[826] = (char *(*)()) F827_6023;
	R3[828] = (char *(*)()) F827_6023;
	R3[831] = (char *(*)()) F827_6023;
	{long i; for (i = 1032; i < 1036; i++) R3[i] = (char *(*)()) F827_6023;}
	{long i; for (i = 1037; i < 1039; i++) R3[i] = (char *(*)()) F827_6023;}
	{long i; for (i = 1041; i < 1045; i++) R3[i] = (char *(*)()) F827_6023;}
	{long i; for (i = 1046; i < 1048; i++) R3[i] = (char *(*)()) F827_6023;}
	{long i; for (i = 1050; i < 1053; i++) R3[i] = (char *(*)()) F827_6023;}
	R3[1055] = (char *(*)()) F827_6023;
	{long i; for (i = 1057; i < 1061; i++) R3[i] = (char *(*)()) F827_6023;}
	{long i; for (i = 1065; i < 1067; i++) R3[i] = (char *(*)()) F827_6023;}
	R3[1068] = (char *(*)()) F827_6023;
	R3[1074] = (char *(*)()) F827_6023;
	R3[1083] = (char *(*)()) F827_6023;
	R3[1092] = (char *(*)()) F1093_9473;
	R3[1098] = (char *(*)()) F1099_9538;
	R3[1107] = (char *(*)()) F1108_9740;
	R3[1109] = (char *(*)()) F1110_9790;
	R3[1111] = (char *(*)()) F827_6023;
	R3[1116] = (char *(*)()) F1114_10066;
	{long i; for (i = 1158; i < 1160; i++) R3[i] = (char *(*)()) F1114_10066;}
	{long i; for (i = 1176; i < 1178; i++) R3[i] = (char *(*)()) F1114_10066;}
	{long i; for (i = 1186; i < 1188; i++) R3[i] = (char *(*)()) F1114_10066;}
	{long i; for (i = 1189; i < 1191; i++) R3[i] = (char *(*)()) F1114_10066;}
	{long i; for (i = 1192; i < 1194; i++) R3[i] = (char *(*)()) F1114_10066;}
	{long i; for (i = 1213; i < 1216; i++) R3[i] = (char *(*)()) F1114_10066;}
	R3[1220] = (char *(*)()) F1114_10066;
	R3[1222] = (char *(*)()) F1114_10066;
	R3[1233] = (char *(*)()) F1114_10066;
	R3[1239] = (char *(*)()) F1114_10066;
	R3[1243] = (char *(*)()) F1114_10066;
	R3[1248] = (char *(*)()) F1114_10066;
	{long i; for (i = 1258; i < 1260; i++) R3[i] = (char *(*)()) F1114_10066;}
	R3[1265] = (char *(*)()) F1266_12593;
}

char *(*R4[1275])();
void R4_init () {
	R4[3] = (char *(*)()) F1_15;
	{long i; for (i = 5; i < 10; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 11; i < 19; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 21; i < 26; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 27; i < 32; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 34; i < 37; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 49; i < 51; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 78; i < 83; i++) R4[i] = (char *(*)()) F1_15;}
	R4[101] = (char *(*)()) F1_15;
	{long i; for (i = 106; i < 108; i++) R4[i] = (char *(*)()) F1_15;}
	R4[112] = (char *(*)()) F1_15;
	R4[119] = (char *(*)()) F1_15;
	R4[122] = (char *(*)()) F1_15;
	R4[125] = (char *(*)()) F1_15;
	{long i; for (i = 131; i < 135; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 136; i < 138; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 139; i < 147; i++) R4[i] = (char *(*)()) F1_15;}
	R4[149] = (char *(*)()) F1_15;
	R4[152] = (char *(*)()) F1_15;
	{long i; for (i = 154; i < 158; i++) R4[i] = (char *(*)()) F1_15;}
	R4[160] = (char *(*)()) F1_15;
	{long i; for (i = 162; i < 165; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 166; i < 169; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 170; i < 172; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 174; i < 176; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 177; i < 180; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 181; i < 185; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 186; i < 188; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 189; i < 196; i++) R4[i] = (char *(*)()) F1_15;}
	R4[198] = (char *(*)()) F1_15;
	{long i; for (i = 200; i < 208; i++) R4[i] = (char *(*)()) F1_15;}
	R4[210] = (char *(*)()) F1_15;
	R4[213] = (char *(*)()) F1_15;
	{long i; for (i = 231; i < 233; i++) R4[i] = (char *(*)()) F1_15;}
	R4[234] = (char *(*)()) F1_15;
	R4[235] = (char *(*)()) F236_3925;
	R4[237] = (char *(*)()) F1_15;
	R4[273] = (char *(*)()) F272_4087;
	R4[503] = (char *(*)()) F504_4428;
	R4[504] = (char *(*)()) F505_4428;
	R4[505] = (char *(*)()) F506_4428;
	R4[506] = (char *(*)()) F507_4428;
	R4[507] = (char *(*)()) F508_4428;
	R4[508] = (char *(*)()) F509_4428;
	R4[509] = (char *(*)()) F510_4428;
	R4[510] = (char *(*)()) F511_4428;
	R4[511] = (char *(*)()) F512_4428;
	R4[512] = (char *(*)()) F513_4428;
	R4[513] = (char *(*)()) F514_4428;
	R4[514] = (char *(*)()) F515_4428;
	R4[564] = (char *(*)()) F565_4542;
	R4[565] = (char *(*)()) F566_4542;
	R4[566] = (char *(*)()) F567_4542;
	R4[567] = (char *(*)()) F565_4542;
	R4[568] = (char *(*)()) F567_4542;
	R4[569] = (char *(*)()) F566_4542;
	R4[570] = (char *(*)()) F571_4573;
	R4[573] = (char *(*)()) F574_4675;
	R4[574] = (char *(*)()) F575_4675;
	R4[575] = (char *(*)()) F576_4675;
	R4[576] = (char *(*)()) F577_4675;
	R4[577] = (char *(*)()) F578_4675;
	R4[578] = (char *(*)()) F579_4675;
	R4[579] = (char *(*)()) F580_4675;
	R4[580] = (char *(*)()) F574_4675;
	R4[581] = (char *(*)()) F579_4675;
	R4[582] = (char *(*)()) F575_4675;
	R4[583] = (char *(*)()) F574_4675;
	R4[584] = (char *(*)()) F585_4800;
	R4[585] = (char *(*)()) F586_4800;
	R4[586] = (char *(*)()) F587_4800;
	R4[587] = (char *(*)()) F588_4800;
	R4[588] = (char *(*)()) F589_4800;
	R4[589] = (char *(*)()) F590_4800;
	R4[590] = (char *(*)()) F591_4800;
	R4[591] = (char *(*)()) F592_4800;
	R4[592] = (char *(*)()) F593_4800;
	R4[593] = (char *(*)()) F594_4800;
	R4[594] = (char *(*)()) F595_4800;
	R4[595] = (char *(*)()) F596_4800;
	{long i; for (i = 601; i < 604; i++) R4[i] = (char *(*)()) F585_4800;}
	{long i; for (i = 610; i < 613; i++) R4[i] = (char *(*)()) F585_4800;}
	R4[614] = (char *(*)()) F585_4800;
	R4[617] = (char *(*)()) F585_4800;
	{long i; for (i = 619; i < 622; i++) R4[i] = (char *(*)()) F585_4800;}
	R4[624] = (char *(*)()) F585_4800;
	R4[625] = (char *(*)()) F589_4800;
	R4[626] = (char *(*)()) F585_4800;
	{long i; for (i = 628; i < 630; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 632; i < 644; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 708; i < 710; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 741; i < 763; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 775; i < 787; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 814; i < 816; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 817; i < 820; i++) R4[i] = (char *(*)()) F1_15;}
	R4[820] = (char *(*)()) F821_5453;
	{long i; for (i = 823; i < 825; i++) R4[i] = (char *(*)()) F1_15;}
	R4[826] = (char *(*)()) F827_6022;
	R4[828] = (char *(*)()) F1_15;
	R4[831] = (char *(*)()) F1_15;
	R4[833] = (char *(*)()) F834_6165;
	{long i; for (i = 834; i < 866; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 867; i < 869; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 870; i < 872; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 873; i < 875; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 876; i < 878; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 879; i < 881; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 882; i < 884; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 885; i < 887; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 888; i < 890; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 891; i < 893; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 894; i < 896; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 897; i < 899; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 900; i < 902; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 903; i < 938; i++) R4[i] = (char *(*)()) F1_15;}
	R4[939] = (char *(*)()) F939_7414;
	R4[940] = (char *(*)()) F941_7446;
	R4[941] = (char *(*)()) F942_7446;
	R4[942] = (char *(*)()) F943_7446;
	R4[943] = (char *(*)()) F942_7446;
	R4[948] = (char *(*)()) F949_7638;
	R4[949] = (char *(*)()) F948_7622;
	R4[952] = (char *(*)()) F953_7806;
	R4[953] = (char *(*)()) F952_7787;
	{long i; for (i = 984; i < 986; i++) R4[i] = (char *(*)()) F982_8039;}
	R4[987] = (char *(*)()) F988_8129;
	{long i; for (i = 988; i < 991; i++) R4[i] = (char *(*)()) F982_8039;}
	R4[991] = (char *(*)()) F992_8208;
	R4[992] = (char *(*)()) F993_8243;
	R4[997] = (char *(*)()) F982_8039;
	{long i; for (i = 1000; i < 1003; i++) R4[i] = (char *(*)()) F982_8039;}
	R4[1015] = (char *(*)()) F982_8039;
	{long i; for (i = 1020; i < 1022; i++) R4[i] = (char *(*)()) F982_8039;}
	{long i; for (i = 1032; i < 1036; i++) R4[i] = (char *(*)()) F982_8039;}
	{long i; for (i = 1037; i < 1039; i++) R4[i] = (char *(*)()) F982_8039;}
	{long i; for (i = 1041; i < 1045; i++) R4[i] = (char *(*)()) F982_8039;}
	{long i; for (i = 1046; i < 1048; i++) R4[i] = (char *(*)()) F982_8039;}
	{long i; for (i = 1050; i < 1053; i++) R4[i] = (char *(*)()) F982_8039;}
	R4[1055] = (char *(*)()) F982_8039;
	R4[1057] = (char *(*)()) F982_8039;
	{long i; for (i = 1058; i < 1061; i++) R4[i] = (char *(*)()) F1059_9141;}
	{long i; for (i = 1065; i < 1067; i++) R4[i] = (char *(*)()) F982_8039;}
	R4[1068] = (char *(*)()) F982_8039;
	R4[1074] = (char *(*)()) F982_8039;
	R4[1083] = (char *(*)()) F982_8039;
	R4[1092] = (char *(*)()) F1_15;
	R4[1098] = (char *(*)()) F1_15;
	R4[1101] = (char *(*)()) F1_15;
	R4[1103] = (char *(*)()) F1_15;
	R4[1105] = (char *(*)()) F1_15;
	R4[1107] = (char *(*)()) F1_15;
	R4[1109] = (char *(*)()) F1_15;
	R4[1111] = (char *(*)()) F1_15;
	R4[1116] = (char *(*)()) F1_15;
	R4[1151] = (char *(*)()) F1_15;
	{long i; for (i = 1158; i < 1160; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1176; i < 1178; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1186; i < 1188; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1189; i < 1191; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1192; i < 1194; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1213; i < 1216; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1220] = (char *(*)()) F1_15;
	R4[1222] = (char *(*)()) F1_15;
	R4[1233] = (char *(*)()) F1_15;
	R4[1239] = (char *(*)()) F1_15;
	R4[1243] = (char *(*)()) F1_15;
	R4[1248] = (char *(*)()) F1_15;
	{long i; for (i = 1257; i < 1260; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1265; i < 1267; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1268; i < 1270; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1273] = (char *(*)()) F1_15;
}

char *(*R5[1275])();
void R5_init () {
	R5[3] = (char *(*)()) F1_8;
	{long i; for (i = 5; i < 10; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 11; i < 19; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 21; i < 26; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 27; i < 32; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 34; i < 37; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 49; i < 51; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 78; i < 83; i++) R5[i] = (char *(*)()) F1_8;}
	R5[101] = (char *(*)()) F1_8;
	{long i; for (i = 106; i < 108; i++) R5[i] = (char *(*)()) F1_8;}
	R5[112] = (char *(*)()) F1_8;
	R5[119] = (char *(*)()) F1_8;
	R5[122] = (char *(*)()) F1_8;
	R5[125] = (char *(*)()) F1_8;
	{long i; for (i = 131; i < 135; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 136; i < 138; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 139; i < 147; i++) R5[i] = (char *(*)()) F1_8;}
	R5[149] = (char *(*)()) F149_3003;
	R5[152] = (char *(*)()) F1_8;
	{long i; for (i = 154; i < 158; i++) R5[i] = (char *(*)()) F1_8;}
	R5[160] = (char *(*)()) F1_8;
	{long i; for (i = 162; i < 165; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 166; i < 169; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 170; i < 172; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 174; i < 176; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 177; i < 180; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 181; i < 185; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 186; i < 188; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 189; i < 196; i++) R5[i] = (char *(*)()) F1_8;}
	R5[198] = (char *(*)()) F1_8;
	{long i; for (i = 200; i < 208; i++) R5[i] = (char *(*)()) F1_8;}
	R5[210] = (char *(*)()) F1_8;
	R5[213] = (char *(*)()) F1_8;
	{long i; for (i = 231; i < 233; i++) R5[i] = (char *(*)()) F1_8;}
	R5[234] = (char *(*)()) F235_3875;
	R5[235] = (char *(*)()) F236_3924;
	R5[237] = (char *(*)()) F1_8;
	R5[273] = (char *(*)()) F272_4047;
	R5[503] = (char *(*)()) F504_4390;
	R5[504] = (char *(*)()) F505_4390;
	R5[505] = (char *(*)()) F506_4390;
	R5[506] = (char *(*)()) F507_4390;
	R5[507] = (char *(*)()) F508_4390;
	R5[508] = (char *(*)()) F509_4390;
	R5[509] = (char *(*)()) F510_4390;
	R5[510] = (char *(*)()) F511_4390;
	R5[511] = (char *(*)()) F512_4390;
	R5[512] = (char *(*)()) F513_4390;
	R5[513] = (char *(*)()) F514_4390;
	R5[514] = (char *(*)()) F515_4390;
	R5[564] = (char *(*)()) F541_4493;
	R5[565] = (char *(*)()) F545_4493;
	R5[566] = (char *(*)()) F550_4493;
	R5[567] = (char *(*)()) F541_4493;
	R5[568] = (char *(*)()) F550_4493;
	R5[569] = (char *(*)()) F545_4493;
	R5[570] = (char *(*)()) F541_4493;
	R5[573] = (char *(*)()) F574_4641;
	R5[574] = (char *(*)()) F575_4641;
	R5[575] = (char *(*)()) F576_4641;
	R5[576] = (char *(*)()) F577_4641;
	R5[577] = (char *(*)()) F578_4641;
	R5[578] = (char *(*)()) F579_4641;
	R5[579] = (char *(*)()) F580_4641;
	R5[580] = (char *(*)()) F581_4735;
	R5[581] = (char *(*)()) F582_4735;
	R5[582] = (char *(*)()) F583_4735;
	R5[583] = (char *(*)()) F574_4641;
	R5[584] = (char *(*)()) F585_4773;
	R5[585] = (char *(*)()) F586_4773;
	R5[586] = (char *(*)()) F587_4773;
	R5[587] = (char *(*)()) F588_4773;
	R5[588] = (char *(*)()) F589_4773;
	R5[589] = (char *(*)()) F590_4773;
	R5[590] = (char *(*)()) F591_4773;
	R5[591] = (char *(*)()) F592_4773;
	R5[592] = (char *(*)()) F593_4773;
	R5[593] = (char *(*)()) F594_4773;
	R5[594] = (char *(*)()) F595_4773;
	R5[595] = (char *(*)()) F596_4773;
	{long i; for (i = 601; i < 604; i++) R5[i] = (char *(*)()) F585_4773;}
	{long i; for (i = 610; i < 613; i++) R5[i] = (char *(*)()) F585_4773;}
	R5[614] = (char *(*)()) F585_4773;
	R5[617] = (char *(*)()) F585_4773;
	{long i; for (i = 619; i < 622; i++) R5[i] = (char *(*)()) F585_4773;}
	R5[624] = (char *(*)()) F585_4773;
	R5[625] = (char *(*)()) F589_4773;
	R5[626] = (char *(*)()) F585_4773;
	{long i; for (i = 628; i < 630; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 632; i < 644; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 708; i < 710; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 741; i < 763; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 775; i < 787; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 814; i < 816; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 817; i < 820; i++) R5[i] = (char *(*)()) F1_8;}
	R5[820] = (char *(*)()) F821_5452;
	{long i; for (i = 823; i < 825; i++) R5[i] = (char *(*)()) F1_8;}
	R5[826] = (char *(*)()) F827_6021;
	R5[828] = (char *(*)()) F1_8;
	R5[831] = (char *(*)()) F1_8;
	R5[833] = (char *(*)()) F834_6162;
	R5[834] = (char *(*)()) F835_6199;
	R5[835] = (char *(*)()) F836_6199;
	R5[836] = (char *(*)()) F837_6199;
	R5[837] = (char *(*)()) F838_6199;
	R5[838] = (char *(*)()) F839_6199;
	R5[839] = (char *(*)()) F840_6199;
	R5[840] = (char *(*)()) F841_6199;
	R5[841] = (char *(*)()) F842_6199;
	R5[842] = (char *(*)()) F843_6199;
	R5[843] = (char *(*)()) F844_6199;
	R5[844] = (char *(*)()) F845_6199;
	R5[845] = (char *(*)()) F846_6199;
	R5[846] = (char *(*)()) F847_6199;
	R5[847] = (char *(*)()) F848_6199;
	R5[848] = (char *(*)()) F849_6199;
	R5[849] = (char *(*)()) F850_6199;
	R5[850] = (char *(*)()) F851_6199;
	R5[851] = (char *(*)()) F852_6199;
	R5[852] = (char *(*)()) F853_6199;
	R5[853] = (char *(*)()) F854_6199;
	R5[854] = (char *(*)()) F855_6199;
	R5[855] = (char *(*)()) F856_6199;
	R5[856] = (char *(*)()) F857_6199;
	R5[857] = (char *(*)()) F858_6199;
	R5[858] = (char *(*)()) F859_6199;
	R5[859] = (char *(*)()) F860_6199;
	R5[860] = (char *(*)()) F861_6199;
	R5[861] = (char *(*)()) F862_6199;
	R5[862] = (char *(*)()) F863_6199;
	R5[863] = (char *(*)()) F864_6199;
	R5[864] = (char *(*)()) F865_6199;
	R5[865] = (char *(*)()) F866_6242;
	{long i; for (i = 867; i < 869; i++) R5[i] = (char *(*)()) F867_6360;}
	{long i; for (i = 870; i < 872; i++) R5[i] = (char *(*)()) F870_6459;}
	{long i; for (i = 873; i < 875; i++) R5[i] = (char *(*)()) F873_6558;}
	{long i; for (i = 876; i < 878; i++) R5[i] = (char *(*)()) F876_6657;}
	{long i; for (i = 879; i < 881; i++) R5[i] = (char *(*)()) F879_6751;}
	{long i; for (i = 882; i < 884; i++) R5[i] = (char *(*)()) F882_6845;}
	{long i; for (i = 885; i < 887; i++) R5[i] = (char *(*)()) F885_6940;}
	{long i; for (i = 888; i < 890; i++) R5[i] = (char *(*)()) F888_7039;}
	{long i; for (i = 891; i < 893; i++) R5[i] = (char *(*)()) F891_7105;}
	{long i; for (i = 894; i < 896; i++) R5[i] = (char *(*)()) F894_7166;}
	{long i; for (i = 897; i < 899; i++) R5[i] = (char *(*)()) F897_7206;}
	{long i; for (i = 900; i < 902; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 903; i < 905; i++) R5[i] = (char *(*)()) F903_7278;}
	{long i; for (i = 905; i < 938; i++) R5[i] = (char *(*)()) F906_7370;}
	R5[939] = (char *(*)()) F939_7407;
	R5[940] = (char *(*)()) F941_7445;
	R5[941] = (char *(*)()) F942_7445;
	R5[942] = (char *(*)()) F943_7445;
	R5[943] = (char *(*)()) F942_7445;
	{long i; for (i = 948; i < 950; i++) R5[i] = (char *(*)()) F948_7607;}
	{long i; for (i = 952; i < 954; i++) R5[i] = (char *(*)()) F952_7772;}
	{long i; for (i = 984; i < 986; i++) R5[i] = (char *(*)()) F1_8;}
	R5[987] = (char *(*)()) F988_8130;
	{long i; for (i = 988; i < 990; i++) R5[i] = (char *(*)()) F1_8;}
	R5[990] = (char *(*)()) F991_8169;
	R5[991] = (char *(*)()) F992_8207;
	R5[992] = (char *(*)()) F993_8242;
	R5[997] = (char *(*)()) F1_8;
	{long i; for (i = 1000; i < 1003; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1015] = (char *(*)()) F1_8;
	{long i; for (i = 1020; i < 1022; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1032; i < 1034; i++) R5[i] = (char *(*)()) F541_4493;}
	{long i; for (i = 1034; i < 1036; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1037; i < 1039; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1041; i < 1045; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1046; i < 1048; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1050; i < 1053; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1055] = (char *(*)()) F1_8;
	R5[1057] = (char *(*)()) F1_8;
	{long i; for (i = 1058; i < 1061; i++) R5[i] = (char *(*)()) F1059_9125;}
	{long i; for (i = 1065; i < 1067; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1068] = (char *(*)()) F1_8;
	R5[1074] = (char *(*)()) F541_4493;
	R5[1083] = (char *(*)()) F541_4493;
	R5[1092] = (char *(*)()) F1_8;
	R5[1098] = (char *(*)()) F1_8;
	R5[1101] = (char *(*)()) F1_8;
	R5[1103] = (char *(*)()) F1_8;
	R5[1105] = (char *(*)()) F1_8;
	R5[1107] = (char *(*)()) F1_8;
	R5[1109] = (char *(*)()) F1_8;
	R5[1111] = (char *(*)()) F1_8;
	R5[1116] = (char *(*)()) F1_8;
	R5[1151] = (char *(*)()) F1_8;
	{long i; for (i = 1158; i < 1160; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1176; i < 1178; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1186; i < 1188; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1189; i < 1191; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1192; i < 1194; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1213; i < 1216; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1220] = (char *(*)()) F1_8;
	R5[1222] = (char *(*)()) F1_8;
	R5[1233] = (char *(*)()) F1_8;
	R5[1239] = (char *(*)()) F1_8;
	R5[1243] = (char *(*)()) F1_8;
	R5[1248] = (char *(*)()) F1_8;
	{long i; for (i = 1257; i < 1260; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1265; i < 1267; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1268; i < 1270; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1273] = (char *(*)()) F1_8;
}


#ifdef __cplusplus
}
#endif
