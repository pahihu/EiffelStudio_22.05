
#ifndef _C1_is28_
#define _C1_is28_

#ifdef __cplusplus
extern "C" {
#endif

extern void F29_650(EIF_REFERENCE);
extern EIF_NATURAL_16 F29_652(EIF_REFERENCE, EIF_POINTER);
extern void F29_653(EIF_REFERENCE, EIF_NATURAL_16);
extern void EIF_Minit28(void);

#ifdef __cplusplus
}
#endif

#endif
