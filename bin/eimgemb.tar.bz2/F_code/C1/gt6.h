
#ifndef _C1_gt6_
#define _C1_gt6_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F6_67(EIF_REFERENCE);
extern EIF_INTEGER_32 F6_69(EIF_REFERENCE);
extern void EIF_Minit6(void);

#ifdef __cplusplus
}
#endif

#endif
