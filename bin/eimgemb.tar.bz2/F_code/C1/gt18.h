
#ifndef _C1_gt18_
#define _C1_gt18_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_NATURAL_8 F19_422(EIF_REFERENCE);
extern EIF_NATURAL_8 F19_423(EIF_REFERENCE);
extern void EIF_Minit18(void);

#ifdef __cplusplus
}
#endif

#endif
