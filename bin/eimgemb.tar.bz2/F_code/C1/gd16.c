/*
 * Code for class GDK_HELPERS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gd16.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F17_353
static EIF_POINTER inline_F17_353 (EIF_INTEGER_32* arg1, EIF_INTEGER_32* arg2)
{
	return (GdkWindow*) gdk_device_get_window_at_position((GdkDevice*) gdk_seat_get_pointer((GdkSeat*) gdk_display_get_default_seat ((GdkDisplay*) gdk_display_get_default())), (gint*) arg1, (gint*) arg2);
	;
}
#define INLINE_F17_353
#endif
#ifndef INLINE_F17_354
static void inline_F17_354 (EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	return gdk_device_get_position ((GdkDevice*) arg1, NULL, (gint*) arg2, (gint*) arg3);
	;
}
#define INLINE_F17_354
#endif
#ifndef INLINE_F17_355
static EIF_POINTER inline_F17_355 (void)
{
	return (GdkDisplay*) gdk_display_get_default();
	;
}
#define INLINE_F17_355
#endif
#ifndef INLINE_F17_357
static EIF_POINTER inline_F17_357 (void)
{
	return (GdkDevice*) gdk_seat_get_pointer((GdkSeat*) gdk_display_get_default_seat ((GdkDisplay*) gdk_display_get_default()));
	;
}
#define INLINE_F17_357
#endif
#ifndef INLINE_F17_358
static EIF_POINTER inline_F17_358 (void)
{
	return (GdkScreen*) gdk_display_get_default_screen ((GdkDisplay*) gdk_display_get_default());
	;
}
#define INLINE_F17_358
#endif
#ifndef INLINE_F17_359
static EIF_INTEGER_32 inline_F17_359 (void)
{
	return gdk_display_get_default_cursor_size ((GdkDisplay*) gdk_display_get_default());
	;
}
#define INLINE_F17_359
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GDK_HELPERS}.window_at */
EIF_POINTER F17_353 (EIF_REFERENCE Current, EIF_INTEGER_32* arg1, EIF_INTEGER_32* arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F17_353 ((EIF_INTEGER_32*) arg1, (EIF_INTEGER_32*) arg2);
	return Result;
}

/* {GDK_HELPERS}.device_get_position */
void F17_354 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32* arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	
	
	inline_F17_354 ((EIF_POINTER) arg1, (EIF_INTEGER_32*) arg2, (EIF_INTEGER_32*) arg3);
}

/* {GDK_HELPERS}.default_display */
EIF_POINTER F17_355 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F17_355 ();
	return Result;
}

/* {GDK_HELPERS}.default_device */
EIF_POINTER F17_357 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F17_357 ();
	return Result;
}

/* {GDK_HELPERS}.default_screen */
EIF_POINTER F17_358 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F17_358 ();
	return Result;
}

/* {GDK_HELPERS}.default_cursor_size */
EIF_INTEGER_32 F17_359 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F17_359 ();
	return Result;
}

void EIF_Minit16 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
