/*
 * Code for class CODE_PAGE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co22.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CODE_PAGE_CONSTANTS}.utf7 */

EIF_REFERENCE F23_462 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (462,RTMS_EX_H("UTF-7",5,1414538039));
}

/* {CODE_PAGE_CONSTANTS}.utf8 */

EIF_REFERENCE F23_463 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (463,RTMS_EX_H("UTF-8",5,1414538040));
}

/* {CODE_PAGE_CONSTANTS}.utf16 */

EIF_REFERENCE F23_464 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (464,RTMS_EX_H("UTF-16",6,1345128758));
}

/* {CODE_PAGE_CONSTANTS}.utf32 */

EIF_REFERENCE F23_465 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (465,RTMS_EX_H("UTF-32",6,1345129266));
}

/* {CODE_PAGE_CONSTANTS}.utf16_le */

EIF_REFERENCE F23_466 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (466,RTMS_EX_H("UTF-16LE",8,312185413));
}

/* {CODE_PAGE_CONSTANTS}.utf32_le */

EIF_REFERENCE F23_467 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (467,RTMS_EX_H("UTF-32LE",8,345477701));
}

/* {CODE_PAGE_CONSTANTS}.utf16_be */

EIF_REFERENCE F23_468 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (468,RTMS_EX_H("UTF-16BE",8,312182853));
}

/* {CODE_PAGE_CONSTANTS}.utf32_be */

EIF_REFERENCE F23_469 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (469,RTMS_EX_H("UTF-32BE",8,345475141));
}

void EIF_Minit22 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
