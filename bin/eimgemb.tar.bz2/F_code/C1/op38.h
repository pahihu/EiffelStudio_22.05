
#ifndef _C1_op38_
#define _C1_op38_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_CHARACTER_8,985)
static EIF_CHARACTER_8 F51_985_body(EIF_REFERENCE);
extern EIF_CHARACTER_8 F51_985(EIF_REFERENCE);
extern EIF_BOOLEAN F51_989(EIF_REFERENCE);
extern EIF_CHARACTER_8 F51_990(EIF_REFERENCE);
extern void EIF_Minit38(void);

#ifdef __cplusplus
}
#endif

#endif
