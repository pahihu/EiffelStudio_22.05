/*
 * Code for class GTK_PROPERTIES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt11.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F12_268
static EIF_POINTER inline_F12_268 (void)
{
	static char *v = "justify";
return (EIF_POINTER) v;
	;
}
#define INLINE_F12_268
#endif
#ifndef INLINE_F12_275
static EIF_POINTER inline_F12_275 (void)
{
	static char *v = "gtk-menu-bar-accel";
return (EIF_POINTER) v;
	;
}
#define INLINE_F12_275
#endif
#ifndef INLINE_F12_276
static EIF_POINTER inline_F12_276 (void)
{
	static char *v = "gtk-menu-images";
return (EIF_POINTER) v;
	;
}
#define INLINE_F12_276
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_PROPERTIES}.justify */
EIF_POINTER F12_268 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F12_268 ();
	return Result;
}

/* {GTK_PROPERTIES}.gtk_menu_bar_accel */
EIF_POINTER F12_275 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F12_275 ();
	return Result;
}

/* {GTK_PROPERTIES}.gtk_menu_icons */
EIF_POINTER F12_276 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F12_276 ();
	return Result;
}

void EIF_Minit11 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
