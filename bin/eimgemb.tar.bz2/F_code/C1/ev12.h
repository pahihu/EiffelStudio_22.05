
#ifndef _C1_ev12_
#define _C1_ev12_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F13_279(EIF_REFERENCE);
extern EIF_REFERENCE F13_282(EIF_REFERENCE);
extern EIF_REFERENCE F13_286(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit12(void);
extern void F992_8177(EIF_REFERENCE, EIF_REAL_32, EIF_REAL_32, EIF_REAL_32);
extern void F818_5410(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
