
#ifndef _C1_gd10_
#define _C1_gd10_

#ifdef __cplusplus
extern "C" {
#endif

extern void F10_240(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_REAL_64, EIF_REAL_64);
extern void EIF_Minit10(void);

#ifdef __cplusplus
}
#endif

#endif
