
#ifndef _C1_gd4_
#define _C1_gd4_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F4_63(EIF_REFERENCE);
extern void EIF_Minit4(void);

#ifdef __cplusplus
}
#endif

#endif
