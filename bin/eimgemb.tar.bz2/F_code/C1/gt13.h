
#ifndef _C1_gt13_
#define _C1_gt13_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F14_291(EIF_REFERENCE);
extern EIF_BOOLEAN F14_292(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32, EIF_POINTER*);
extern void EIF_Minit13(void);

#ifdef __cplusplus
}
#endif

#endif
