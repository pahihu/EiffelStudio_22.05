/*
 * Code for class EV_STOCK_PIXMAPS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev31.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STOCK_PIXMAPS}.information_pixmap */
static EIF_REFERENCE F32_692_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (692);
#define Result RTOSR(692)
	RTOC_NEW(Result);
	Result = F232_3822(RTCV(RTOSCF(712,F32_712, (Current))));
	RTOSE (692);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F32_692 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(692,F32_692_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.error_pixmap */
static EIF_REFERENCE F32_693_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (693);
#define Result RTOSR(693)
	RTOC_NEW(Result);
	Result = F232_3823(RTCV(RTOSCF(712,F32_712, (Current))));
	RTOSE (693);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F32_693 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(693,F32_693_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.warning_pixmap */
static EIF_REFERENCE F32_694_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (694);
#define Result RTOSR(694)
	RTOC_NEW(Result);
	Result = F232_3824(RTCV(RTOSCF(712,F32_712, (Current))));
	RTOSE (694);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F32_694 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(694,F32_694_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.default_window_icon */
static EIF_REFERENCE F32_696_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (696);
#define Result RTOSR(696)
	RTOC_NEW(Result);
	Result = F232_3830(RTCV(RTOSCF(712,F32_712, (Current))));
	RTOSE (696);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F32_696 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(696,F32_696_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.busy_cursor */
static EIF_REFERENCE F32_697_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (697);
#define Result RTOSR(697)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(987, 0x00).id, 987, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F988_8120(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (697);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F32_697 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(697,F32_697_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.standard_cursor */
static EIF_REFERENCE F32_698_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (698);
#define Result RTOSR(698)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(987, 0x00).id, 987, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F988_8120(RTCW(tr1), ((EIF_INTEGER_32) 2L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (698);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F32_698 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(698,F32_698_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.help_cursor */
static EIF_REFERENCE F32_700_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (700);
#define Result RTOSR(700)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(987, 0x00).id, 987, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F988_8120(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (700);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F32_700 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(700,F32_700_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.ibeam_cursor */
static EIF_REFERENCE F32_701_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (701);
#define Result RTOSR(701)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(987, 0x00).id, 987, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F988_8120(RTCW(tr1), ((EIF_INTEGER_32) 5L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (701);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F32_701 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(701,F32_701_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.no_cursor */
static EIF_REFERENCE F32_702_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (702);
#define Result RTOSR(702)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(987, 0x00).id, 987, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F988_8120(RTCW(tr1), ((EIF_INTEGER_32) 6L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (702);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F32_702 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(702,F32_702_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.sizeall_cursor */
static EIF_REFERENCE F32_703_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (703);
#define Result RTOSR(703)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(987, 0x00).id, 987, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F988_8120(RTCW(tr1), ((EIF_INTEGER_32) 7L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (703);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F32_703 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(703,F32_703_body,(Current));
}

/* {EV_STOCK_PIXMAPS}.implementation */
static EIF_REFERENCE F32_712_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (712);
#define Result RTOSR(712)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(231, 0x00).id, 231, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (712);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F32_712 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(712,F32_712_body,(Current));
}

void EIF_Minit31 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
