/*
 * Code for class EV_PIXEL_BUFFER_PIXEL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev30.h"
#include "eif_built_in.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PIXEL_BUFFER_PIXEL}.default_create */
void F31_665 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(195, 0x00).id, 195, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tb1 = (EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b;
	if (tb1) {
		*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_0_) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 16L);
		*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_1_) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 8L);
		*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_2_) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L);
		*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_3_) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 24L);
	} else {
		*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_0_) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 24L);
		*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_1_) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 16L);
		*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_2_) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 8L);
		*(EIF_NATURAL_8 *)(Current+ _CHROFF_1_3_) = (EIF_NATURAL_8) (EIF_NATURAL_8) ((EIF_INTEGER_32) 0L);
	}
	RTLE;
}

/* {EV_PIXEL_BUFFER_PIXEL}.red */
EIF_NATURAL_8 F31_666 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_1_4_0_2_);
	tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_1_0_);
	ti4_1 = (EIF_INTEGER_32) tu1_1;
	tu4_1 = eif_bit_shift_right(tu4_1,ti4_1);
	Result = (EIF_NATURAL_8) tu4_1;
	RTLE;
	return Result;
}

/* {EV_PIXEL_BUFFER_PIXEL}.green */
EIF_NATURAL_8 F31_667 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_1_4_0_2_);
	tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_1_1_);
	ti4_1 = (EIF_INTEGER_32) tu1_1;
	tu4_1 = eif_bit_shift_right(tu4_1,ti4_1);
	Result = (EIF_NATURAL_8) tu4_1;
	RTLE;
	return Result;
}

/* {EV_PIXEL_BUFFER_PIXEL}.blue */
EIF_NATURAL_8 F31_668 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_1_4_0_2_);
	tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_1_2_);
	ti4_1 = (EIF_INTEGER_32) tu1_1;
	tu4_1 = eif_bit_shift_right(tu4_1,ti4_1);
	Result = (EIF_NATURAL_8) tu4_1;
	RTLE;
	return Result;
}

/* {EV_PIXEL_BUFFER_PIXEL}.alpha */
EIF_NATURAL_8 F31_669 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_8 tu1_1;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_1_4_0_2_);
	tu1_1 = *(EIF_NATURAL_8 *)(Current+ _CHROFF_1_3_);
	ti4_1 = (EIF_INTEGER_32) tu1_1;
	tu4_1 = eif_bit_shift_right(tu4_1,ti4_1);
	Result = (EIF_NATURAL_8) tu4_1;
	RTLE;
	return Result;
}

/* {EV_PIXEL_BUFFER_PIXEL}.rgba_value */
EIF_NATURAL_32 F31_670 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc2 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_1_4_0_2_);
	if ((EIF_BOOLEAN) eif_builtin_PLATFORM_is_windows__b) {
		loc1 = eif_bit_shift_left(Result,((EIF_INTEGER_32) 8L));
		loc2 = eif_bit_shift_right(Result,((EIF_INTEGER_32) 24L));
		Result = eif_bit_or(loc1,loc2);
		RTLE;
		return (EIF_NATURAL_32) Result;
	}
	RTLE;
	return Result;
}

/* {EV_PIXEL_BUFFER_PIXEL}.set_pixel_buffer */
void F31_677 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) arg1;
}

/* {EV_PIXEL_BUFFER_PIXEL}.sync_with_pixel_buffer_value */
void F31_678 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_NATURAL_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_1_4_0_0_) = (EIF_NATURAL_32) arg1;
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_1_4_0_1_) = (EIF_NATURAL_32) arg2;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tu4_1 = F1110_9775(RTCW(tr1), arg1, arg2);
		*(EIF_NATURAL_32 *)(Current+ _LNGOFF_1_4_0_2_) = (EIF_NATURAL_32) tu4_1;
	}
	RTLE;
}

void EIF_Minit30 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
