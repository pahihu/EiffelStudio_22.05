/*
 * Code for class EV_GTK_EVENT_STRINGS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev15.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_EVENT_STRINGS}.set_focus_event_name */

EIF_REFERENCE F16_306 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (306,RTMS_EX_H("set-focus",9,577130099));
}

/* {EV_GTK_EVENT_STRINGS}.configure_event_name */

EIF_REFERENCE F16_307 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (307,RTMS_EX_H("configure-event",15,1205453684));
}

/* {EV_GTK_EVENT_STRINGS}.map_event_name */

EIF_REFERENCE F16_310 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (310,RTMS_EX_H("map-event",9,474090100));
}

/* {EV_GTK_EVENT_STRINGS}.unmap_event_name */

EIF_REFERENCE F16_311 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (311,RTMS_EX_H("unmap-event",11,77806708));
}

/* {EV_GTK_EVENT_STRINGS}.hide_signal_name */

EIF_REFERENCE F16_312 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (312,RTMS_EX_H("hide",4,1751737445));
}

/* {EV_GTK_EVENT_STRINGS}.size_allocate_event_name */

EIF_REFERENCE F16_316 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (316,RTMS_EX_H("size-allocate",13,769151077));
}

/* {EV_GTK_EVENT_STRINGS}.clicked_event_name */

EIF_REFERENCE F16_319 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (319,RTMS_EX_H("clicked",7,169941860));
}

/* {EV_GTK_EVENT_STRINGS}.draw_event_name */

EIF_REFERENCE F16_321 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (321,RTMS_EX_H("draw",4,1685217655));
}

/* {EV_GTK_EVENT_STRINGS}.commit_event_name */

EIF_REFERENCE F16_322 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (322,RTMS_EX_H("commit",6,2031381364));
}

/* {EV_GTK_EVENT_STRINGS}.changed_event_name */

EIF_REFERENCE F16_323 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (323,RTMS_EX_H("changed",7,346303332));
}

/* {EV_GTK_EVENT_STRINGS}.response_event_name */

EIF_REFERENCE F16_327 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (327,RTMS_EX_H("response",8,1418183525));
}

/* {EV_GTK_EVENT_STRINGS}.scroll_event_name */

EIF_REFERENCE F16_333 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (333,RTMS_EX_H("scroll-event",12,2102824820));
}

/* {EV_GTK_EVENT_STRINGS}.commit_event_string */
static EIF_REFERENCE F16_352_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (352);
#define Result RTOSR(352)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr2 = RTOSCF(322,F16_322, (Current));
	F818_5410(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (352);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F16_352 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(352,F16_352_body,(Current));
}

void EIF_Minit15 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
