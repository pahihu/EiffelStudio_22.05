/*
 * Code for class SYSTEM_ENCODINGS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "sy23.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {SYSTEM_ENCODINGS}.console_encoding */
static EIF_REFERENCE F24_471_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (471);
#define Result RTOSR(471)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(24, 0x00).id, 24, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = F113_2629(RTCV(RTOSCF(476,F24_476, (Current))));
	F25_477(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (471);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F24_471 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(471,F24_471_body,(Current));
}

/* {SYSTEM_ENCODINGS}.utf8 */
static EIF_REFERENCE F24_472_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (472);
#define Result RTOSR(472)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(24, 0x00).id, 24, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(463,F23_463, (Current));
	F25_477(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (472);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F24_472 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(472,F24_472_body,(Current));
}

/* {SYSTEM_ENCODINGS}.utf32 */
static EIF_REFERENCE F24_474_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (474);
#define Result RTOSR(474)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(24, 0x00).id, 24, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr2 = RTOSCF(465,F23_465, (Current));
	F25_477(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (474);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F24_474 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(474,F24_474_body,(Current));
}

/* {SYSTEM_ENCODINGS}.system_encodings_i */
static EIF_REFERENCE F24_476_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (476);
#define Result RTOSR(476)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(112, 0x00).id, 112, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (476);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F24_476 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(476,F24_476_body,(Current));
}

void EIF_Minit23 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
