/*
 * Code for class EV_GTK_ENUMS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev8.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GTK_ENUMS}.gdk_button_press_enum */
EIF_INTEGER_32 F8_90 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_BUTTON_PRESS;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_watch_enum */
EIF_INTEGER_32 F8_104 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_WATCH;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_xterm_enum */
EIF_INTEGER_32 F8_105 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_XTERM;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_crosshair_enum */
EIF_INTEGER_32 F8_106 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_CROSSHAIR;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_question_arrow_enum */
EIF_INTEGER_32 F8_107 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_QUESTION_ARROW;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_left_ptr_enum */
EIF_INTEGER_32 F8_108 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_LEFT_PTR;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_fleur_enum */
EIF_INTEGER_32 F8_109 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_FLEUR;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_size_sb_v_double_arrow_enum */
EIF_INTEGER_32 F8_110 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_SB_V_DOUBLE_ARROW;
	return Result;
}

/* {EV_GTK_ENUMS}.gdk_hand2_enum */
EIF_INTEGER_32 F8_111 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GDK_HAND2;
	return Result;
}

/* {EV_GTK_ENUMS}.gtk_style_provider_priority_application */
EIF_NATURAL_32 F8_112 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	Result = (EIF_NATURAL_32) GTK_STYLE_PROVIDER_PRIORITY_APPLICATION;
	return Result;
}

void EIF_Minit8 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
