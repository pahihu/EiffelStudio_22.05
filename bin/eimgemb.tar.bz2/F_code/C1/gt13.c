/*
 * Code for class GTK_CSS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gt13.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GTK_CSS}.gtk_css_provider_new */
EIF_POINTER F14_291 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) gtk_css_provider_new();
	
	return Result;
}

/* {GTK_CSS}.gtk_css_provider_load_from_data */
EIF_BOOLEAN F14_292 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER* arg4)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(gtk_css_provider_load_from_data((GtkCssProvider*) arg1, (const gchar*) arg2, (gssize) arg3, (GError**) arg4));
	
	return Result;
}

void EIF_Minit13 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
