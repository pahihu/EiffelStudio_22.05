
#ifndef _C1_gt11_
#define _C1_gt11_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F12_268(EIF_REFERENCE);
extern EIF_POINTER F12_275(EIF_REFERENCE);
extern EIF_POINTER F12_276(EIF_REFERENCE);
extern void EIF_Minit11(void);

#ifdef __cplusplus
}
#endif

#endif
