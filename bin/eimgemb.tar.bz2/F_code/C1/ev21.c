/*
 * Code for class EV_STOCK_COLORS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev21.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STOCK_COLORS}.white */
static EIF_REFERENCE F22_434_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (434);
#define Result RTOSR(434)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	tr4_2 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	tr4_3 = (EIF_REAL_32) (((EIF_INTEGER_32) 1L));
	F992_8177(RTCW(tr1), tr4_1, tr4_2, tr4_3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (434);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F22_434 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(434,F22_434_body,(Current));
}

/* {EV_STOCK_COLORS}.black */
static EIF_REFERENCE F22_435_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_REAL_32 tr4_2;
	EIF_REAL_32 tr4_3;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (435);
#define Result RTOSR(435)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_2_0_0_0_0_0_0_0_);
	tr4_1 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	tr4_2 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	tr4_3 = (EIF_REAL_32) (((EIF_INTEGER_32) 0L));
	F992_8177(RTCW(tr1), tr4_1, tr4_2, tr4_3);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (435);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F22_435 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(435,F22_435_body,(Current));
}

/* {EV_STOCK_COLORS}.gray */
static EIF_REFERENCE F22_437_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (437);
#define Result RTOSR(437)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(991, 0x00).id, 991, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F992_8177(RTCW(tr1), (EIF_REAL_32) 0.7, (EIF_REAL_32) 0.7, (EIF_REAL_32) 0.7);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (437);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F22_437 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(437,F22_437_body,(Current));
}

/* {EV_STOCK_COLORS}.default_background_color */
EIF_REFERENCE F22_458 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F13_279(RTCV(RTOSCF(461,F22_461, (Current))));
	RTLE;
	return Result;
}

/* {EV_STOCK_COLORS}.default_foreground_color */
EIF_REFERENCE F22_459 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F13_282(RTCV(RTOSCF(461,F22_461, (Current))));
	RTLE;
	return Result;
}

/* {EV_STOCK_COLORS}.implementation */
static EIF_REFERENCE F22_461_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (461);
#define Result RTOSR(461)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(12, 0x00).id, 12, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (461);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F22_461 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(461,F22_461_body,(Current));
}

void EIF_Minit21 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
