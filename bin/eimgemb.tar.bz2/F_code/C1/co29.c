/*
 * Code for class CODE_PRODUCER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "co29.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CODE_PRODUCER}.build_c_external_data_code */
EIF_REFERENCE F30_654 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_NATURAL_8 tu1_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc4);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,loc5);
	RTLIU(7);
	
	RTGC;
	F1001_8350(RTCW(arg1));
	loc4 = F1001_8351(RTCW(arg1));
	F709_5242(RTCW(loc4));
	ti4_1 = F1001_8356(RTCW(arg1));
	ti4_2 = F1001_8357(RTCW(arg1));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 * ti4_2) / ((EIF_INTEGER_32) 400L)) + ((EIF_INTEGER_32) 1L));
	Result = RTLNS(eif_new_type(949, 0x00).id, 949, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F945_7452(RTCW(Result));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = RTMS_EX_H("feature {NONE} -- Image data",28,370523233);
	tr2 = F30_660(Current);
	tr1 = F950_7714(tr1, tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = F30_660(Current);
	F950_7695(RTCW(Result), tr1);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 80L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_))) break;
		tb1 = F709_5243(RTCW(loc4));
		if (tb1) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_))--;
		} else {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) 0L));
			tr2 = RTMS_EX_H("c_colors_",9,1943838047);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = eif_out__i4_s1(loc1);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = RTMS_EX_H(" (a_ptr: POINTER; a_offset: INTEGER)",36,1560010025);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) 2L));
			tr2 = RTMS_EX_H("-- Fill `a_ptr\' with colors data from `a_offset\'.",49,1570443310);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) -1L));
			tr2 = RTMS_EX_H("external",8,293011052);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) 1L));
			tr2 = RTMS_EX_H("\"C inline\"",10,946545442);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) -1L));
			tr2 = RTMS_EX_H("alias",5,1819590515);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) 1L));
			tr2 = RTMS_EX_H("\"{",2,8827);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) 0L));
			tr2 = RTMS_EX_H("{",1,123);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) 1L));
			tr2 = RTMS_EX_H("#define B(q) \\",14,1023269468);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) 1L));
			tr2 = RTMS_EX_H("#q",2,9073);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) -1L));
			tr2 = RTMS_EX_H("#ifdef EIF_WINDOWS",18,974597715);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) 0L));
			tr2 = RTMS_EX_H("#define A(a,r,g,b) \\",20,1694110300);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) 1L));
			tr2 = RTMS_EX_H("B(\\x##b\\x##g\\x##r\\x##a)",23,134013737);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) -1L));
			tr2 = RTMS_EX_H("#else",5,1701875045);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) 0L));
			tr2 = RTMS_EX_H("#define A(a,r,g,b) \\",20,1694110300);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) 1L));
			tr2 = RTMS_EX_H("B(\\x##r\\x##g\\x##b\\x##a)",23,1419598121);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) -1L));
			tr2 = RTMS_EX_H("#endif",6,1921662822);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) 0L));
			tr2 = RTMS_EX_H("char l_data[] = ",16,66415904);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			for (;;) {
				tb1 = '\01';
				if (!(EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 400L))) {
					tb2 = F709_5243(RTCW(loc4));
					tb1 = tb2;
				}
				if (tb1) break;
				loc5 = F709_5248(RTCW(loc4));
				if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
					tr1 = F30_664(Current, ((EIF_INTEGER_32) 0L));
					F950_7695(RTCW(Result), tr1);
				}
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)((EIF_INTEGER_32) (loc2 % loc3) == ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 0L)))) {
					tr1 = F30_660(Current);
					tr2 = F30_664(Current, ((EIF_INTEGER_32) 0L));
					tr1 = F950_7714(RTCW(tr1), tr2);
					F950_7695(RTCW(Result), tr1);
				}
				tr1 = RTMS_EX_H("A(",2,16680);
				tu1_1 = F31_669(RTCW(loc5));
				tr2 = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
				*(EIF_NATURAL_8 *)tr2 = tu1_1;
				tr2 = F885_6983(RTCW(tr2));
				tr1 = F950_7714(tr1, tr2);
				tr2 = RTMS_EX_H(",",1,44);
				tr1 = F950_7714(RTCW(tr1), tr2);
				tu1_1 = F31_666(RTCW(loc5));
				tr2 = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
				*(EIF_NATURAL_8 *)tr2 = tu1_1;
				tr2 = F885_6983(RTCW(tr2));
				tr1 = F950_7714(RTCW(tr1), tr2);
				tr2 = RTMS_EX_H(",",1,44);
				tr1 = F950_7714(RTCW(tr1), tr2);
				tu1_1 = F31_667(RTCW(loc5));
				tr2 = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
				*(EIF_NATURAL_8 *)tr2 = tu1_1;
				tr2 = F885_6983(RTCW(tr2));
				tr1 = F950_7714(RTCW(tr1), tr2);
				tr2 = RTMS_EX_H(",",1,44);
				tr1 = F950_7714(RTCW(tr1), tr2);
				tu1_1 = F31_668(RTCW(loc5));
				tr2 = RTLNS(eif_new_type(886, 0x00).id, 886, _OBJSIZ_0_1_0_0_0_0_0_0_);
				*(EIF_NATURAL_8 *)tr2 = tu1_1;
				tr2 = F885_6983(RTCW(tr2));
				tr1 = F950_7714(RTCW(tr1), tr2);
				tr2 = RTMS_EX_H(")",1,41);
				tr1 = F950_7714(RTCW(tr1), tr2);
				F950_7695(RTCW(Result), tr1);
				F709_5245(RTCW(loc4));
				loc2++;
			}
			tr1 = RTMS_EX_H(";",1,59);
			tr2 = F30_660(Current);
			tr1 = F950_7714(tr1, tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) 0L));
			tr2 = RTMS_EX_H("memcpy ((EIF_NATURAL_32 *)$a_ptr + $a_offset, &l_data, sizeof l_data - 1);",74,630010683);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) -1L));
			tr2 = RTMS_EX_H("}",1,125);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) 0L));
			tr2 = RTMS_EX_H("}\"",2,32034);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_664(Current, ((EIF_INTEGER_32) -1L));
			tr2 = RTMS_EX_H("end",3,6647396);
			tr1 = F950_7714(RTCW(tr1), tr2);
			tr2 = F30_660(Current);
			tr1 = F950_7714(RTCW(tr1), tr2);
			F950_7695(RTCW(Result), tr1);
			tr1 = F30_660(Current);
			F950_7695(RTCW(Result), tr1);
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {CODE_PRODUCER}.build_colors_code */
EIF_REFERENCE F30_655 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	Result = RTLNS(eif_new_type(949, 0x00).id, 949, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F948_7582(RTCW(Result), ((EIF_INTEGER_32) 200L));
	tr1 = F30_664(Current, ((EIF_INTEGER_32) 0L));
	tr2 = RTMS_EX_H("build_colors (a_ptr: POINTER)",29,1666062889);
	tr1 = F950_7714(RTCW(tr1), tr2);
	tr2 = F30_660(Current);
	tr1 = F950_7714(RTCW(tr1), tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = F30_664(Current, ((EIF_INTEGER_32) 2L));
	tr2 = RTMS_EX_H("-- Build `colors\'.",18,2071010606);
	tr1 = F950_7714(RTCW(tr1), tr2);
	tr2 = F30_660(Current);
	tr1 = F950_7714(RTCW(tr1), tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = F30_664(Current, ((EIF_INTEGER_32) -1L));
	tr2 = RTMS_EX_H("do",2,25711);
	tr1 = F950_7714(RTCW(tr1), tr2);
	tr2 = F30_660(Current);
	tr1 = F950_7714(RTCW(tr1), tr2);
	F950_7695(RTCW(Result), tr1);
	
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_))++;
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_))) break;
		tr1 = F30_664(Current, ((EIF_INTEGER_32) 0L));
		tr2 = RTMS_EX_H("c_colors_",9,1943838047);
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr2 = eif_out__i4_s1(loc1);
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(" (a_ptr, ",9,1320113184);
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr2 = eif_out__i4_s1((EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 400L)));
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr2 = RTMS_EX_H(")",1,41);
		tr1 = F950_7714(RTCW(tr1), tr2);
		tr2 = F30_660(Current);
		tr1 = F950_7714(RTCW(tr1), tr2);
		F950_7695(RTCW(Result), tr1);
		loc1++;
	}
	tr1 = F30_664(Current, ((EIF_INTEGER_32) -1L));
	tr2 = RTMS_EX_H("end",3,6647396);
	tr1 = F950_7714(RTCW(tr1), tr2);
	tr2 = F30_660(Current);
	tr1 = F950_7714(RTCW(tr1), tr2);
	F950_7695(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {CODE_PRODUCER}.build_top_code */
EIF_REFERENCE F30_657 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Result);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	Result = RTLNS(eif_new_type(949, 0x00).id, 949, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F945_7452(RTCW(Result));
	tr1 = RTMS_EX_H("note",4,1852798053);
	tr2 = F30_660(Current);
	tr1 = F950_7714(tr1, tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("\011description: \"Pixel buffer that replaces original image file.%",63,1676100389);
	tr2 = F30_660(Current);
	tr1 = F950_7714(tr1, tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("\011\011%The original version of this class has been generated by Image Eiffel Code.\"",79,1771241250);
	tr2 = F30_660(Current);
	tr1 = F950_7714(tr1, tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = F30_660(Current);
	F950_7695(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("class",5,1819086195);
	tr2 = F30_660(Current);
	tr1 = F950_7714(tr1, tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("\011",1,9);
	tr2 = F950_7731(RTCW(arg1));
	tr1 = F950_7714(tr1, tr2);
	tr2 = F30_660(Current);
	tr1 = F950_7714(RTCW(tr1), tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = F30_660(Current);
	F950_7695(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("inherit",7,1080299636);
	tr2 = F30_660(Current);
	tr1 = F950_7714(tr1, tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("\011EV_PIXEL_BUFFER",16,2024356946);
	tr2 = F30_660(Current);
	tr1 = F950_7714(tr1, tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = F30_660(Current);
	F950_7695(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("create",6,1896403045);
	tr2 = F30_660(Current);
	tr1 = F950_7714(tr1, tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("\011make",5,1835170149);
	tr2 = F30_660(Current);
	tr1 = F950_7714(tr1, tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = F30_660(Current);
	F950_7695(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {CODE_PRODUCER}.build_initialization_code */
EIF_REFERENCE F30_658 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Result);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = RTLNS(eif_new_type(949, 0x00).id, 949, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F945_7452(RTCW(Result));
	tr1 = RTMS_EX_H("feature {NONE} -- Initialization",32,793267822);
	tr2 = F30_660(Current);
	tr1 = F950_7714(tr1, tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = F30_660(Current);
	F950_7695(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("\011make",5,1835170149);
	tr2 = F30_660(Current);
	tr1 = F950_7714(tr1, tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("\011\011\011-- Initialization",20,745898350);
	tr2 = F30_660(Current);
	tr1 = F950_7714(tr1, tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("\011\011do",4,151610479);
	tr2 = F30_660(Current);
	tr1 = F950_7714(tr1, tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("\011\011\011make_with_size (",19,508817960);
	tr2 = eif_out__i4_s1(arg1);
	tr1 = F950_7714(tr1, tr2);
	tr2 = RTMS_EX_H(", ",2,11296);
	tr1 = F950_7714(RTCW(tr1), tr2);
	tr2 = eif_out__i4_s1(arg2);
	tr1 = F950_7714(RTCW(tr1), tr2);
	tr2 = RTMS_EX_H(")",1,41);
	tr1 = F950_7714(RTCW(tr1), tr2);
	tr2 = F30_660(Current);
	tr1 = F950_7714(RTCW(tr1), tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("\011\011\011fill_memory",14,1149491577);
	tr2 = F30_660(Current);
	tr1 = F950_7714(tr1, tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = RTMS_EX_H("\011\011end",5,157711460);
	tr2 = F30_660(Current);
	tr1 = F950_7714(tr1, tr2);
	F950_7695(RTCW(Result), tr1);
	tr1 = F30_660(Current);
	F950_7695(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {CODE_PRODUCER}.build_fill_memory_code */
EIF_REFERENCE F30_659 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	Result = RTLNS(eif_new_type(949, 0x00).id, 949, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = RTMS_EX_H("feature {NONE} -- Image data filling.\012\012\011fill_memory\012\011\011\011-- Fill image data into memory.\012\011\011local\012\011\011\011l_pointer: POINTER\012\011\011do\012\011\011\011if attached {EV_PIXEL_BUFFER_IMP} implementation as l_imp then\012\011\011\011\011l_pointer := l_imp.data_ptr\012\011\011\011\011if not l_pointer.is_default_pointer then\012\011\011\011\011\011build_colors (l_pointer)\012\011\011\011\011\011l_imp.unlock\012\011\011\011\011end\012\011\011\011end\012\011\011end\012",334,1450484490);
	F948_7584(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {CODE_PRODUCER}.new_line */
EIF_REFERENCE F30_660 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTLNS(eif_new_type(949, 0x00).id, 949, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr1 = RTMS_EX_H("\012",1,10);
	F948_7584(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {CODE_PRODUCER}.tab */
EIF_REFERENCE F30_664 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_)) += arg1;
	Result = RTLNS(eif_new_type(949, 0x00).id, 949, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F945_7452(RTCW(Result));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_1_))) break;
		tr1 = RTMS_EX_H("\011",1,9);
		tr1 = F950_7714(RTCW(Result), tr1);
		Result = (EIF_REFERENCE) tr1;
		loc1++;
	}
	RTLE;
	return Result;
}

void EIF_Minit29 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
