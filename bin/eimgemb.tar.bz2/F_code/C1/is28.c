/*
 * Code for class ISE_SCOOP_RUNTIME
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "is28.h"
#include "eif_scoop.h"
#include "eif_macros.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F29_652
static EIF_NATURAL_16 inline_F29_652 (EIF_POINTER arg1)
{
	return RTS_PID(arg1)
	;
}
#define INLINE_F29_652
#endif
#ifndef INLINE_F29_653
static void inline_F29_653 (EIF_NATURAL_16 arg1)
{
	eif_scoop_set_is_impersonation_allowed (arg1, EIF_FALSE)
	;
}
#define INLINE_F29_653
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ISE_SCOOP_RUNTIME}.pin_to_thread */
void F29_650 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_16 tu2_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu2_1 = inline_F29_652(Current);
	inline_F29_653(tu2_1);
	RTLE;
}

/* {ISE_SCOOP_RUNTIME}.c_region_id */
EIF_NATURAL_16 F29_652 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_NATURAL_16 Result = ((EIF_NATURAL_16) 0);
	
	
	
	Result = inline_F29_652 ((EIF_POINTER) arg1);
	return Result;
}

/* {ISE_SCOOP_RUNTIME}.c_disable_impersonation */
void F29_653 (EIF_REFERENCE Current, EIF_NATURAL_16 arg1)
{
	GTCX
	
	
	inline_F29_653 ((EIF_NATURAL_16) arg1);
}

void EIF_Minit28 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
