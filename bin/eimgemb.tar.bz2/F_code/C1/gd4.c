/*
 * Code for class GDK_ENUMS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "gd4.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F4_63
static EIF_INTEGER_32 inline_F4_63 (void)
{
	return GDK_SEAT_CAPABILITY_ALL;
	;
}
#define INLINE_F4_63
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {GDK_ENUMS}.seat_capability_all */
EIF_INTEGER_32 F4_63 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F4_63 ();
	return Result;
}

void EIF_Minit4 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
