
#ifndef _C1_gd16_
#define _C1_gd16_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F17_353(EIF_REFERENCE, EIF_INTEGER_32*, EIF_INTEGER_32*);
extern void F17_354(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32*, EIF_INTEGER_32*);
extern EIF_POINTER F17_355(EIF_REFERENCE);
extern EIF_POINTER F17_357(EIF_REFERENCE);
extern EIF_POINTER F17_358(EIF_REFERENCE);
extern EIF_INTEGER_32 F17_359(EIF_REFERENCE);
extern void EIF_Minit16(void);

#ifdef __cplusplus
}
#endif

#endif
