
#ifndef _C17_co824_
#define _C17_co824_

#ifdef __cplusplus
extern "C" {
#endif

extern void F316_4210(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit824(void);
extern char *(*R3906[])();
extern char *(*R4040[])();

#ifdef __cplusplus
}
#endif

#endif
