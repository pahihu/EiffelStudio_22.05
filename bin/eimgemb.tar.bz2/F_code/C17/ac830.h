
#ifndef _C17_ac830_
#define _C17_ac830_

#ifdef __cplusplus
extern "C" {
#endif

extern void F623_4945(EIF_REFERENCE);
extern void EIF_Minit830(void);
extern void F600_4827(EIF_REFERENCE);
extern void F602_4849(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y4410[];
extern EIF_TYPE_INDEX *Y4410_gen_type [];
extern EIF_TYPE_INDEX Y4411[];
extern EIF_TYPE_INDEX *Y4411_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
