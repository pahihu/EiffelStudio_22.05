
#ifndef _C17_li810_
#define _C17_li810_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F292_4183(EIF_REFERENCE, EIF_INTEGER_32);
extern void F292_4185(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F292_4189(EIF_REFERENCE);
extern EIF_BOOLEAN F292_4191(EIF_REFERENCE);
extern EIF_REFERENCE F292_4198(EIF_REFERENCE);
extern void EIF_Minit810(void);
extern char *(*R4016[])();
extern char *(*R4017[])();
extern char *(*R4018[])();
extern char *(*R3907[])();
extern char *(*R4024[])();
extern char *(*R4029[])();
extern char *(*R4031[])();
extern long O3909[];

#ifdef __cplusplus
}
#endif

#endif
