
#ifndef _C17_fi819_
#define _C17_fi819_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F414_4259(EIF_REFERENCE);
extern void EIF_Minit819(void);
extern char *(*R4064[])();

#ifdef __cplusplus
}
#endif

#endif
