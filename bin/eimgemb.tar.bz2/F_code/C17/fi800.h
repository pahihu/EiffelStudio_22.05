
#ifndef _C17_fi800_
#define _C17_fi800_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F413_4259(EIF_REFERENCE);
extern void EIF_Minit800(void);
extern char *(*R4064[])();

#ifdef __cplusplus
}
#endif

#endif
