
#ifndef _C17_ty818_
#define _C17_ty818_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F735_5289(EIF_REFERENCE);
extern void EIF_Minit818(void);
extern char *(*R4678[])();
extern char *(*R4665[])();
extern char *(*R4087[])();

#ifdef __cplusplus
}
#endif

#endif
