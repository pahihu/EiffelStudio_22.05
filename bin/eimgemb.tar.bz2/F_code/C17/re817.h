
#ifndef _C17_re817_
#define _C17_re817_

#ifdef __cplusplus
extern "C" {
#endif

extern void F747_5295(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F747_5297(EIF_REFERENCE);
extern EIF_INTEGER_32 F747_5298(EIF_REFERENCE);
extern EIF_INTEGER_32 F747_5299(EIF_REFERENCE);
extern EIF_INTEGER_32 F747_5300(EIF_REFERENCE);
extern EIF_BOOLEAN F747_5307(EIF_REFERENCE);
extern EIF_BOOLEAN F747_5308(EIF_REFERENCE);
extern EIF_BOOLEAN F747_5309(EIF_REFERENCE);
extern void F747_5314(EIF_REFERENCE);
extern void F747_5315(EIF_REFERENCE);
extern EIF_REFERENCE F747_5316(EIF_REFERENCE);
extern void EIF_Minit817(void);
extern char *(*R4091[])();
extern char *(*R4088[])();
extern char *(*R4089[])();
extern long O4681[];
extern long O4685[];
extern long O4686[];
extern long O4687[];
extern long O4688[];
extern long O4689[];

#ifdef __cplusplus
}
#endif

#endif
