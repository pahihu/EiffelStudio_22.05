
#ifndef _C17_co805_
#define _C17_co805_

#ifdef __cplusplus
extern "C" {
#endif

extern void F315_4210(EIF_REFERENCE, EIF_NATURAL_8);
extern void EIF_Minit805(void);
extern char *(*R3906[])();
extern char *(*R4040[])();

#ifdef __cplusplus
}
#endif

#endif
