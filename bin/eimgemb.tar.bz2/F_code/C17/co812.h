
#ifndef _C17_co812_
#define _C17_co812_

#ifdef __cplusplus
extern "C" {
#endif

extern void F265_4030(EIF_REFERENCE);
extern void F265_4031(EIF_REFERENCE);
extern void EIF_Minit812(void);
extern long O3909[];

#ifdef __cplusplus
}
#endif

#endif
