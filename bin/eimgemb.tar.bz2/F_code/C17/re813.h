
#ifndef _C17_re813_
#define _C17_re813_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F483_4321(EIF_REFERENCE);
extern void EIF_Minit813(void);
extern void F747_5295(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R4677[])();
extern EIF_TYPE_INDEX Y3861[];
extern EIF_TYPE_INDEX *Y3861_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
