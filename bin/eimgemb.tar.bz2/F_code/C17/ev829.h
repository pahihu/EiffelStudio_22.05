
#ifndef _C17_ev829_
#define _C17_ev829_

#ifdef __cplusplus
extern "C" {
#endif

extern void F625_4952(EIF_REFERENCE);
extern void F625_4954(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F625_4955(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit829(void);
extern void F602_4849(EIF_REFERENCE);
extern void F623_4945(EIF_REFERENCE);
extern char *(*R4354[])();
extern EIF_TYPE_INDEX Y4052[];
extern EIF_TYPE_INDEX *Y4052_gen_type [];
extern EIF_TYPE_INDEX Y4412[];
extern EIF_TYPE_INDEX *Y4412_gen_type [];
extern EIF_TYPE_INDEX Y4413[];
extern EIF_TYPE_INDEX *Y4413_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
