/*
 * Code for class EV_FILE_SAVE_DIALOG_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev511.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FILE_SAVE_DIALOG_IMP}.make */
void F1159_10552 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1158_10537(Current);
	tr1 = RTMS_EX_H("Save As",7,713900403);
	F1154_10507(Current, tr1);
	RTLE;
}

/* {EV_FILE_SAVE_DIALOG_IMP}.file_chooser_action */
EIF_INTEGER_32 F1159_10554 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) GTK_FILE_CHOOSER_ACTION_SAVE;
}

void EIF_Minit511 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
