/*
 * Code for class EV_CLIPBOARD_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev504.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CLIPBOARD_IMP}.make */
RTEOMS(10486,2);
void F1152_10487 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F818_5410(RTCW(loc1), RTOMS(10486,0));
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (EIF_POINTER) gdk_atom_intern((gchar*) tp1, (gint) ((EIF_INTEGER_32) 1L));
	tp1 = (EIF_POINTER) gtk_clipboard_get((GdkAtom) tp1);
	*(EIF_POINTER *)(Current+ _PTROFF_1_1_0_0_0_0_) = (EIF_POINTER) tp1;
	loc1 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F818_5410(RTCW(loc1), RTOMS(10486,1));
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (EIF_POINTER) gdk_atom_intern((gchar*) tp1, (gint) ((EIF_INTEGER_32) 1L));
	tp1 = (EIF_POINTER) gtk_clipboard_get((GdkAtom) tp1);
	*(EIF_POINTER *)(Current+ _PTROFF_1_1_0_0_0_1_) = (EIF_POINTER) tp1;
	F1087_9359(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_CLIPBOARD_IMP}.set_text */
RTEOMS(10489,1);
void F1152_10490 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F818_5410(RTCW(loc1), arg1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_0_0_0_);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_0_1_0_0_);
	gtk_clipboard_set_text((GtkClipboard*) tp1, (gchar*) tp2, (gint) ti4_1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_0_0_1_);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_0_1_0_0_);
	gtk_clipboard_set_text((GtkClipboard*) tp1, (gchar*) tp2, (gint) ti4_1);
	F818_5410(RTCW(loc1), RTOMS(10489,0));
	RTLE;
}

/* {EV_CLIPBOARD_IMP}.destroy */
void F1152_10493 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1087_9360(Current, (EIF_BOOLEAN) 1);
}

void EIF_Minit504 (void)
{
	GTCX
	RTPOMS(10486,1,"PRIMARY",7,921107801);
	RTPOMS(10486,0,"CLIPBOARD",9,1396792132);
	RTPOMS(10489,0,"",0,0);
}


#ifdef __cplusplus
}
#endif
