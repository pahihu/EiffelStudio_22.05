/*
 * Code for class EV_CONTAINER_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev518.h"
#include <ev_gtk.h>
#include "eif_built_in.h"
#include <ev_any_imp.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1114_10054
static EIF_REFERENCE inline_F1114_10054 (EIF_POINTER arg1)
{
	return (EIF_REFERENCE) (c_ev_any_imp_get_eif_reference_from_object_id (arg1))
	;
}
#define INLINE_F1114_10054
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CONTAINER_IMP}.make */
void F1166_10756 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1164_10681(Current);
	tr1 = RTLNSMART(eif_new_type(905, 0).id);
	tr1 = RTCCL(tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O8587[dtype-1165]) = (EIF_REFERENCE) tr1;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8243[dtype-1176])(Current);
	F1126_10266(Current, tp1);
	RTLE;
}

/* {EV_CONTAINER_IMP}.container_widget */
EIF_POINTER F1166_10757 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8243[Dtype(Current)-1176])(Current);
}

/* {EV_CONTAINER_IMP}.client_width */
EIF_INTEGER_32 F1166_10758 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8257[Dtype(Current)-1158])(Current);
}

/* {EV_CONTAINER_IMP}.client_height */
EIF_INTEGER_32 F1166_10759 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8258[Dtype(Current)-1158])(Current);
}

/* {EV_CONTAINER_IMP}.background_pixmap */
EIF_REFERENCE F1166_10760 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O8601[Dtype(Current)-1165]);
}


/* {EV_CONTAINER_IMP}.replace */
void F1166_10761 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8563[dtype-1176])(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = *(EIF_REFERENCE *)(loc2 + _REFACS_3_);
		loc1 = RTRV(eif_new_type(1163, 0x00), loc1);
		
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			F1166_10777(Current, loc1);
			tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8586[dtype-1176])(Current);
			tp2 = *(EIF_POINTER *)(RTCW(loc1) + O8051[Dtype(loc1)-1113]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER)) R8598[dtype-1176])(Current, tp1, tp2);
		}
	}
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
		loc1 = RTRV(eif_new_type(1163, 0x00), loc1);
		
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8586[dtype-1176])(Current);
			tp2 = *(EIF_POINTER *)(RTCW(loc1) + O8051[Dtype(loc1)-1113]);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32)) R8597[dtype-1176])(Current, tp1, tp2, ((EIF_INTEGER_32) 1L));
			F1166_10776(Current, loc1);
		}
	}
	RTLE;
}

/* {EV_CONTAINER_IMP}.set_radio_group */
void F1166_10764 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8587[Dtype(Current)-1165]);
	F906_7369(RTCW(tr1), arg1);
	RTLE;
}

/* {EV_CONTAINER_IMP}.radio_group */
EIF_POINTER F1166_10765 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8587[Dtype(Current)-1165]);
	Result = *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_0_0_0_0_0_0_);
	RTLE;
	return Result;
}

/* {EV_CONTAINER_IMP}.add_radio_button */
void F1166_10768 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1216, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		if ((EIF_BOOLEAN)(F1166_10765(Current) != F1_33(Current))) {
			tp1 = (RTNA((RTCW(loc1))), ((EIF_POINTER) 0));
			tp2 = F1166_10765(Current);
			gtk_radio_button_set_group((GtkRadioButton*) tp1, (GSList*) tp2);
		} else {
			tp1 = (RTNA((RTCW(loc1))), ((EIF_POINTER) 0));
			gtk_toggle_button_set_active((GtkToggleButton*) tp1, (gboolean) (EIF_BOOLEAN) 0);
		}
		tp1 = (RTNA((RTCW(loc1))), ((EIF_POINTER) 0));
		tp1 = (EIF_POINTER) gtk_radio_button_get_group((GtkRadioButton*) tp1);
		F1166_10764(Current, tp1);
	}
	RTLE;
}

/* {EV_CONTAINER_IMP}.remove_radio_button */
void F1166_10769 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc5);
	RTLIU(4);
	
	RTGC;
	loc1 = arg1;
	loc1 = RTRV(eif_new_type(1216, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tp1 = F1166_10765(Current);
		loc2 = (EIF_INTEGER_32) g_slist_length((GSList*) tp1);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
		tp1 = F1166_10765(Current);
		tp2 = (RTNA((RTCW(loc1))), ((EIF_POINTER) 0));
		loc3 = (EIF_INTEGER_32) g_slist_index((GSList*) tp1, (gpointer) tp2);
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc2 - loc3) > ((EIF_INTEGER_32) 0L))) {
			tp1 = F1166_10765(Current);
			loc4 = (EIF_POINTER) g_slist_nth_data((GSList*) tp1, (guint) loc2);
		} else {
			if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
				tp1 = F1166_10765(Current);
				loc4 = (EIF_POINTER) g_slist_nth_data((GSList*) tp1, (guint) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
			}
		}
		tp1 = (RTNA((RTCW(loc1))), ((EIF_POINTER) 0));
		tp2 = F1_33(Current);
		gtk_radio_button_set_group((GtkRadioButton*) tp1, (GSList*) tp2);
		tb1 = !loc4;
		if ((EIF_BOOLEAN) !tb1) {
			tp1 = (EIF_POINTER) gtk_widget_get_parent((GtkWidget*) loc4);
			loc5 = inline_F1114_10054(tp1);
			loc5 = RTRV(eif_new_type(1216, 0x00), loc5);
			RTCT0("an_item_imp_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tp1 = (RTNA((RTCW(loc5))), ((EIF_POINTER) 0));
			F1166_10764(Current, tp1);
		} else {
			tp1 = F1_33(Current);
			F1166_10764(Current, tp1);
		}
		tb1 = (RTNA((RTCW(loc1))), ((EIF_BOOLEAN) 0));
		if (tb1) {
			tb1 = !F1166_10765(Current);
			if ((EIF_BOOLEAN) !tb1) {
				tp1 = F1166_10765(Current);
				tp1 = (EIF_POINTER) (((GSList *)tp1)->data);
				gtk_toggle_button_set_active((GtkToggleButton*) tp1, (gboolean) (EIF_BOOLEAN) 1);
			}
		} else {
			tp1 = (RTNA((RTCW(loc1))), ((EIF_POINTER) 0));
			gtk_toggle_button_set_active((GtkToggleButton*) tp1, (gboolean) (EIF_BOOLEAN) 1);
		}
	}
	RTLE;
}

/* {EV_CONTAINER_IMP}.internal_set_background_pixmap */
void F1166_10770 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc4);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	tr1 = RTLNS(eif_new_type(21, 0x00).id, 21, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tr1 = RTOSCF(437,F22_437, (RTCW(tr1)));
	F1126_10267(Current, tp1, tr1);
	tb1 = '\0';
	tb2 = '\0';
	loc3 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8243[dtype-1176])(Current);
	if ((EIF_TRUE)) {
		tb3 = !loc3;
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN)(loc3 != *(EIF_POINTER *)(Current + O8051[dtype-1113]));
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(21, 0x00).id, 21, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr1 = RTOSCF(437,F22_437, (RTCW(tr1)));
		F1126_10267(Current, loc3, tr1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + O8601[dtype-1165]);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc1 = *(EIF_REFERENCE *)(loc4 + _REFACS_3_);
		loc1 = RTRV(eif_new_type(1259, 0x00), loc1);
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tp1 = F1260_12469(RTCW(loc1));
		loc2 = (EIF_POINTER) gtk_image_new_from_pixbuf((GdkPixbuf*) tp1);
		gtk_widget_show((GtkWidget*) loc2);
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8243[dtype-1176])(Current);
		gtk_container_add((GtkContainer*) tp1, (GtkWidget*) loc2);
	} else {
		
	}
	RTLE;
}

/* {EV_CONTAINER_IMP}.set_background_pixmap */
void F1166_10771 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O8601[Dtype(Current)-1165]) = (EIF_REFERENCE) tr1;
	F1166_10770(Current, arg1);
	RTLE;
}

/* {EV_CONTAINER_IMP}.destroy */
void F1166_10775 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1087_9345(Current);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4035[Dtype(RTCW(tr1))-564])(tr1);
	if (tb1) {
		tr1 = F1087_9345(Current);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4042[Dtype(RTCW(tr1))-573])(tr1);
	}
	F1164_10716(Current);
	RTLE;
}

/* {EV_CONTAINER_IMP}.on_new_item */
void F1166_10776 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1166_10768(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8548[Dtype(RTCW(arg1))-1176])(arg1, Current);
	RTLE;
}

/* {EV_CONTAINER_IMP}.on_removed_item */
void F1166_10777 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8548[Dtype(RTCW(arg1))-1176])(arg1, NULL);
	F1166_10769(Current, arg1);
	RTLE;
}

/* {EV_CONTAINER_IMP}.child_has_resized */
void F1166_10778 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {EV_CONTAINER_IMP}.set_parent_imp */
void F1166_10779 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	F1164_10715(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + O8601[dtype-1165]);
	loc1 = tr1;
	if ((EIF_BOOLEAN) (EIF_TEST(loc1) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8549[dtype-1163]) == NULL))) {
		F1166_10770(Current, loc1);
	}
	RTLE;
}

/* {EV_CONTAINER_IMP}.gtk_insert_i_th */
void F1166_10780 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	gtk_container_add((GtkContainer*) arg1, (GtkWidget*) arg2);
}

/* {EV_CONTAINER_IMP}.gtk_container_remove */
void F1166_10781 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	gtk_container_remove((GtkContainer*) arg1, (GtkWidget*) arg2);
}

void EIF_Minit518 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
