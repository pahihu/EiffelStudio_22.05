/*
 * Code for class EV_DIALOG_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev546.h"
#include <ev_gtk.h>
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DIALOG_IMP}.new_gtk_window */
EIF_POINTER F1194_11184 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) F111_2612(Current);
}

/* {EV_DIALOG_IMP}.make */
void F1194_11185 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1191_11083(Current);
	F1194_11188(Current);
	RTLE;
}

/* {EV_DIALOG_IMP}.enable_closeable */
void F1194_11188 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1194_11192(Current, (EIF_BOOLEAN) 1);
}

/* {EV_DIALOG_IMP}.disable_closeable */
void F1194_11189 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1194_11192(Current, (EIF_BOOLEAN) 0);
}

/* {EV_DIALOG_IMP}.default_window_position */
EIF_INTEGER_32 F1194_11190 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) GTK_WIN_POS_CENTER;
}

/* {EV_DIALOG_IMP}.client_area */
EIF_POINTER F1194_11191 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) F111_2613(Current, *(EIF_POINTER *)(Current+ _PTROFF_68_26_10_11_0_0_));
}

/* {EV_DIALOG_IMP}.set_closeable */
void F1194_11192 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (arg1) {
		loc1 = (EIF_INTEGER_32) GDK_FUNC_CLOSE;
	}
	ti4_1 = (EIF_INTEGER_32) GDK_FUNC_MOVE;
	ti4_1 = eif_bit_or(loc1,ti4_1);
	loc1 = (EIF_INTEGER_32) ti4_1;
	ti4_1 = (EIF_INTEGER_32) GDK_FUNC_RESIZE;
	ti4_1 = eif_bit_or(loc1,ti4_1);
	loc1 = (EIF_INTEGER_32) ti4_1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_68_26_10_11_0_0_);
	tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
	gdk_window_set_functions((GdkWindow*) tp1, (GdkWMFunction) loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_68_23_) = (EIF_BOOLEAN) arg1;
	RTLE;
}

/* {EV_DIALOG_IMP}.call_close_request_actions */
void F1194_11193 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	if ((EIF_BOOLEAN) !F1191_11126(Current)) {
		tb3 = *(EIF_BOOLEAN *)(Current+ _CHROFF_68_23_);
	}
	if (tb3) {
		tb3 = F1112_10006(RTCV(RTOSCF(10077,F1114_10077, (Current))));
		tb2 = (EIF_BOOLEAN) !tb3;
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !F1087_9344(Current);
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(1266, 0x00).id, 1266, _OBJSIZ_0_0_0_1_0_0_0_0_);
		F1267_12648(RTCW(tr1), ((EIF_INTEGER_32) 42L));
		F1186_10994(Current, tr1);
		F1191_11140(Current);
	}
	RTLE;
}

void EIF_Minit546 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
