/*
 * Code for class EV_TEXTABLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev502.h"
#include <ev_gtk.h>
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F83_2175
static void inline_F83_2175 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_xalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F83_2175
#endif
#ifndef INLINE_F83_2176
static void inline_F83_2176 (EIF_POINTER arg1, EIF_REAL_32 arg2)
{
	gtk_label_set_yalign ((GtkLabel*) arg1, (gfloat) arg2)
	;
}
#define INLINE_F83_2176
#endif
#ifndef INLINE_F82_1951
static void inline_F82_1951 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_widget_set_margin_start ((GtkWidget *)arg1, (gint)arg2)
	;
}
#define INLINE_F82_1951
#endif
#ifndef INLINE_F82_1953
static void inline_F82_1953 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_widget_set_margin_end ((GtkWidget *)arg1, (gint)arg2)
	;
}
#define INLINE_F82_1953
#endif
#ifndef INLINE_F83_2084
static EIF_INTEGER_32 inline_F83_2084 (void)
{
	return (EIF_INTEGER_32) (GTK_JUSTIFY_CENTER)
	;
}
#define INLINE_F83_2084
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TEXTABLE_IMP}.textable_imp_initialize */
void F1150_10468 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1_33(Current);
	tp1 = (EIF_POINTER) gtk_label_new((gchar*) tp1);
	*(EIF_POINTER *)(Current + O8388[dtype-1149]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O8388[dtype-1149]);
	inline_F83_2175(tp1, (EIF_REAL_32) 0.0);
	tp1 = *(EIF_POINTER *)(Current + O8388[dtype-1149]);
	inline_F83_2176(tp1, (EIF_REAL_32) 0.5);
	tp1 = *(EIF_POINTER *)(Current + O8388[dtype-1149]);
	inline_F82_1951(tp1, ((EIF_INTEGER_32) 2L));
	tp1 = *(EIF_POINTER *)(Current + O8388[dtype-1149]);
	inline_F82_1953(tp1, ((EIF_INTEGER_32) 2L));
	RTLE;
}

/* {EV_TEXTABLE_IMP}.text */
EIF_REFERENCE F1150_10469 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8390[dtype-1149]);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		tr1 = F945_7511(loc2);
		Result = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	} else {
		tp1 = *(EIF_POINTER *)(Current + O8388[dtype-1149]);
		loc1 = (EIF_POINTER) gtk_label_get_label((GtkLabel*) tp1);
		if ((EIF_BOOLEAN)(loc1 != F1_33(Current))) {
			tr1 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
			F818_5412(RTCW(tr1), loc1);
			Result = F818_5408(RTCW(tr1));
		} else {
			Result = F945_7511(RTMS_EX_H("",0,0));
		}
	}
	RTLE;
	return Result;
}

/* {EV_TEXTABLE_IMP}.align_text_center */
void F1150_10471 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8388[dtype-1149]);
	inline_F83_2175(tp1, (EIF_REAL_32) 0.5);
	tp1 = *(EIF_POINTER *)(Current + O8388[dtype-1149]);
	inline_F83_2176(tp1, (EIF_REAL_32) 0.5);
	tp1 = *(EIF_POINTER *)(Current + O8388[dtype-1149]);
	ti4_1 = inline_F83_2084();
	gtk_label_set_justify((GtkLabel*) tp1, (GtkJustification) ti4_1);
	RTLE;
}

/* {EV_TEXTABLE_IMP}.align_text_left */
void F1150_10472 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8388[dtype-1149]);
	inline_F83_2175(tp1, (EIF_REAL_32) 0.0);
	tp1 = *(EIF_POINTER *)(Current + O8388[dtype-1149]);
	inline_F83_2176(tp1, (EIF_REAL_32) 0.5);
	tp1 = *(EIF_POINTER *)(Current + O8388[dtype-1149]);
	ti4_1 = (EIF_INTEGER_32) GTK_JUSTIFY_LEFT;
	gtk_label_set_justify((GtkLabel*) tp1, (GtkJustification) ti4_1);
	RTLE;
}

/* {EV_TEXTABLE_IMP}.set_text */
void F1150_10474 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8389[dtype-1213])(Current)) {
		loc2 = F945_7511(RTCW(arg1));
		if ((EIF_BOOLEAN)(loc2 == arg1)) {
			tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc2);
			RTAR(Current, tr1);
			*(EIF_REFERENCE *)(Current + O8390[dtype-1149]) = (EIF_REFERENCE) tr1;
		} else {
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + O8390[dtype-1149]) = (EIF_REFERENCE) loc2;
		}
		tr1 = RTOSCF(10077,F1114_10077, (Current));
		tr2 = F1150_10479(Current, arg1);
		loc1 = F1112_10032(RTCW(tr1), tr2);
		tp1 = *(EIF_POINTER *)(Current + O8388[dtype-1149]);
		tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
		gtk_label_set_text_with_mnemonic((GtkLabel*) tp1, (gchar*) tp2);
	} else {
		tr1 = RTOSCF(10077,F1114_10077, (Current));
		loc1 = F1112_10032(RTCW(tr1), arg1);
		*(EIF_REFERENCE *)(Current + O8390[dtype-1149]) = (EIF_REFERENCE) NULL;
		tp1 = *(EIF_POINTER *)(Current + O8388[dtype-1149]);
		tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
		gtk_label_set_text((GtkLabel*) tp1, (gchar*) tp2);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_0_1_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
		tp1 = *(EIF_POINTER *)(Current + O8388[dtype-1149]);
		gtk_widget_hide((GtkWidget*) tp1);
	} else {
		tp1 = *(EIF_POINTER *)(Current + O8388[dtype-1149]);
		gtk_widget_show((GtkWidget*) tp1);
	}
	RTLE;
}

/* {EV_TEXTABLE_IMP}.accelerators_enabled */
EIF_BOOLEAN F1150_10477 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_TEXTABLE_IMP}.u_lined_filter */
EIF_REFERENCE F1150_10479 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc2 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = F945_7511(RTCW(arg1));
	loc1 = *(EIF_INTEGER_32 *)(RTCW(Result)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) break;
		loc2 = F954_7830(RTCW(Result), loc1);
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
		if ((EIF_BOOLEAN)(loc2 == tw1)) {
			if ((EIF_BOOLEAN)(Result == arg1)) {
				tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (Result);
				Result = (EIF_REFERENCE) tr1;
			}
			if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 1L))) {
				loc2 = F954_7830(RTCW(Result), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '&';
				if ((EIF_BOOLEAN)(loc2 == tw1)) {
					F954_7884(RTCW(Result), loc1);
					loc1--;
				} else {
					tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
					F954_7850(RTCW(Result), tw1, loc1);
				}
			} else {
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				F954_7850(RTCW(Result), tw1, loc1);
			}
		} else {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
			if ((EIF_BOOLEAN)(loc2 == tw1)) {
				if ((EIF_BOOLEAN)(Result == arg1)) {
					tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (Result);
					Result = (EIF_REFERENCE) tr1;
				}
				tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '_';
				F954_7881(RTCW(Result), tw1, loc1);
			}
		}
		loc1--;
	}
	RTLE;
	return Result;
}

void EIF_Minit502 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
