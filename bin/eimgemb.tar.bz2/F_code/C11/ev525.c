/*
 * Code for class EV_BOX_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev525.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_BOX_I}.insertion_position */
EIF_INTEGER_32 F1173_10867 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	loc1 = F1118_10194(Current);
	loc2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8645[dtype-1176])(Current);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 0L))) {
		tb1 = (EIF_BOOLEAN) (loc2 <= (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8647[dtype-1176])(Current));
	}
	if (tb1) {
		tb1 = '\01';
		tb2 = '\01';
		if (!(EIF_BOOLEAN) (loc2 >= (EIF_INTEGER_32) ((FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8647[dtype-1176])(Current) - F1176_10878(Current)))) {
			tb2 = (EIF_BOOLEAN)(F1119_10229(Current) == ((EIF_INTEGER_32) 0L));
		}
		if (!tb2) {
			tb2 = '\0';
			if ((EIF_BOOLEAN)(F1119_10229(Current) == ((EIF_INTEGER_32) 1L))) {
				tr1 = F1119_10228(Current, ((EIF_INTEGER_32) 1L));
				tb2 = (EIF_BOOLEAN)(tr1 == RTOSCF(2658,F117_2658, (Current)));
			}
			tb1 = tb2;
		}
		if (tb1) {
			Result = F1119_10229(Current);
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
		} else {
			if ((EIF_BOOLEAN) (loc2 < F1176_10878(Current))) {
				RTLE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			} else {
				F1118_10204(Current);
				loc4 = F1176_10878(Current);
				for (;;) {
					if ((EIF_BOOLEAN)(Result != ((EIF_INTEGER_32) -1L))) break;
					loc3 += (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8646[dtype-1176])(Current);
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_13_10_1_) == ((EIF_INTEGER_32) 1L))) {
						loc3 += F1176_10878(Current);
					} else {
						loc3 += F1176_10879(Current);
					}
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 >= loc4) && (EIF_BOOLEAN) (loc2 <= loc3))) {
						loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 - loc4) / ((EIF_INTEGER_32) 2L));
						loc6 = F1176_10879(Current);
						loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc4 + loc5) + (EIF_INTEGER_32) (loc6 / ((EIF_INTEGER_32) 2L)));
						if ((EIF_BOOLEAN) (loc2 > loc6)) {
							Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_13_10_1_);
							Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
						} else {
							Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_13_10_1_);
						}
					}
					loc4 = (EIF_INTEGER_32) loc3;
					F1118_10206(Current);
				}
				F1118_10208(Current, loc1);
			}
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit525 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
