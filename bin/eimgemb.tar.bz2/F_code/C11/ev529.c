/*
 * Code for class EV_VERTICAL_BOX_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev529.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F19_423
static EIF_NATURAL_8 inline_F19_423 (void)
{
	return GTK_ORIENTATION_VERTICAL
	;
}
#define INLINE_F19_423
#endif
#ifndef INLINE_F82_1959
static EIF_POINTER inline_F82_1959 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F82_1959
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_VERTICAL_BOX_IMP}.make */
void F1177_10892 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu1_1 = inline_F19_423();
	loc1 = inline_F82_1959(tu1_1, ((EIF_INTEGER_32) 0L));
	gtk_box_set_homogeneous((GtkBox*) loc1, (gboolean) EIF_FALSE);
	F1114_10052(Current, loc1);
	F1170_10807(Current);
	RTLE;
}

void EIF_Minit529 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
