/*
 * Code for class EV_PICK_AND_DROPABLE_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev513.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PICK_AND_DROPABLE_I}.reset_pebble_function */
void F1161_10577 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8433[dtype-1160]) != NULL)) {
		*(EIF_REFERENCE *)(Current + O8432[dtype-1160]) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_I}.mode_is_pick_and_drop */
EIF_BOOLEAN F1161_10590 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_8 *)(Current + O8465[dtype-1160]) == ((EIF_INTEGER_8) 0L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_8 *)(Current + O8465[dtype-1160]) == ((EIF_INTEGER_8) 3L)));
}

/* {EV_PICK_AND_DROPABLE_I}.mode_is_drag_and_drop */
EIF_BOOLEAN F1161_10591 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_8 *)(Current + O8465[Dtype(Current)-1160]) == ((EIF_INTEGER_8) 1L));
}

/* {EV_PICK_AND_DROPABLE_I}.mode_is_target_menu */
EIF_BOOLEAN F1161_10592 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_8 *)(Current + O8465[Dtype(Current)-1160]) == ((EIF_INTEGER_8) 2L));
}

/* {EV_PICK_AND_DROPABLE_I}.mode_is_configurable_target_menu */
EIF_BOOLEAN F1161_10593 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_8 *)(Current + O8465[Dtype(Current)-1160]) == ((EIF_INTEGER_8) 3L));
}

/* {EV_PICK_AND_DROPABLE_I}.execute */
void F1161_10604 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REAL_64 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_16 ti2_1;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	F1162_10631(Current);
	ti2_1 = (EIF_INTEGER_16) arg6;
	*(EIF_INTEGER_16 *)(Current + O2651[dtype-116]) = (EIF_INTEGER_16) ti2_1;
	ti2_1 = (EIF_INTEGER_16) arg7;
	*(EIF_INTEGER_16 *)(Current + O2652[dtype-116]) = (EIF_INTEGER_16) ti2_1;
	tr1 = F1161_10616(Current);
	F1111_9866(RTCW(tr1), arg6, arg7);
	F1162_10630(Current);
	loc1 = F1161_10606(Current);
	loc2 = loc1;
	loc2 = RTRV(eif_new_type(1022, 0x00), loc2);
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(10617,F1161_10617, (Current))) + _REFACS_1_);
	loc3 = F1101_9545(RTCW(tr1));
	loc3 = RTRV(eif_new_type(1111, 0x00), loc3);
	RTCT0("application /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_6_);
	if ((EIF_BOOLEAN)(tr1 != NULL)) {
		tr1 = F99_2414(RTCW(loc3));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,865,868,868,1022,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 4, 0);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_i4 = arg1;
		((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg2;
		((EIF_TYPED_VALUE *)tr2+3)->it_r = loc2;
		RTAR(tr2,loc2);
		F603_4886(RTCW(tr1), tr2);
	}
	F1161_10605(Current, loc1);
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_I}.update_pointer_style */
void F1161_10605 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + O8432[dtype-1160]);
	loc1 = RTCCL(tr1);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && EIF_TEST(loc1))) {
		tr1 = F968_7961(RTCW(arg1));
		tr2 = RTCCL(loc1);
		tb2 = F604_4889(RTCW(tr1), tr2);
		tb1 = tb2;
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + O8436[dtype-1160]);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			F1115_10098(Current, loc2);
		} else {
			tr1 = RTOSCF(2648,F117_2648, (Current));
			F1115_10098(Current, tr1);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O8437[dtype-1160]);
		loc3 = tr1;
		if (EIF_TEST(loc3)) {
			F1115_10098(Current, loc3);
		} else {
			tr1 = RTOSCF(2649,F117_2649, (Current));
			F1115_10098(Current, tr1);
		}
	}
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_I}.pointed_target */
EIF_REFERENCE F1161_10606 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_16 ti2_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	loc1 = F1162_10644(Current);
	Result = (EIF_REFERENCE) loc1;
	loc2 = loc1;
	loc2 = RTRV(eif_new_type(1026, 0x00), loc2);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_3_);
		loc3 = *(EIF_REFERENCE *)(RTCW(tr1) + O8509[Dtype(tr1)-1162]);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O2651[dtype-116]);
			loc4 = (EIF_INTEGER_32) ti2_1;
			ti4_1 = F1005_8382(RTCW(loc2));
			loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - ti4_1);
			ti2_1 = *(EIF_INTEGER_16 *)(Current + O2652[dtype-116]);
			loc5 = (EIF_INTEGER_32) ti2_1;
			ti4_1 = F1005_8383(RTCW(loc2));
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - ti4_1);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,865,868,868,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
				tr1 = RTLNTS(typres0.id, 3, 1);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_i4 = loc4;
			((EIF_TYPED_VALUE *)tr1+2)->it_i4 = loc5;
			Result = F941_7443(RTCW(loc3), tr1);
		}
	}
	RTLE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_I}.call_pebble_function */
void F1161_10610 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8433[dtype-1160]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,865,868,868,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 1);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg1;
		((EIF_TYPED_VALUE *)tr1+2)->it_i4 = arg2;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R6147[Dtype(loc1)-940])(loc1, tr1);
		tr1 = RTCCL(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O8432[dtype-1160]) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_I}.modify_widget_appearance */
void F1161_10611 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc2 = F1112_9936(RTCV(F1161_10616(Current)));
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R4018[Dtype(RTCW(loc2))-564])(loc2);
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4017[Dtype(RTCW(loc2))-564])(loc2);
		if (tb1) break;
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4016[Dtype(RTCW(loc2))-564])(loc2);
		loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
		loc1 = RTRV(eif_new_type(1190, 0x00), loc1);
		RTCT0("window_implementation_not_void", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1183_10958(RTCW(loc1), arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4031[Dtype(RTCW(loc2))-564])(loc2);
	}
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_I}.application_implementation */
EIF_REFERENCE F1161_10616 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(10617,F1161_10617, (Current))) + _REFACS_1_);
	Result = F1101_9545(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_I}.environment */
static EIF_REFERENCE F1161_10617_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10617);
#define Result RTOSR(10617)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F982_8029(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10617);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1161_10617 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10617,F1161_10617_body,(Current));
}

void EIF_Minit513 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
