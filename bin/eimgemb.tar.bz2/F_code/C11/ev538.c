/*
 * Code for class EV_DIALOG_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev538.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DIALOG_I}.default_push_button */
EIF_REFERENCE F1186_10983 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_60_);
}

/* {EV_DIALOG_I}.default_cancel_button */
EIF_REFERENCE F1186_10984 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_61_);
}

/* {EV_DIALOG_I}.current_push_button */
EIF_REFERENCE F1186_10985 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_62_) != NULL)) {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_62_);
	} else {
		RTLE;
		return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_60_);
	}/* NOTREACHED */
	
}

/* {EV_DIALOG_I}.set_default_push_button */
void F1186_10986 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_62_) == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_60_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			F1053_9025(loc1);
		}
		F1053_9024(RTCW(arg1));
	} else {
		
	}
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_60_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {EV_DIALOG_I}.remove_default_push_button */
void F1186_10987 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_62_) == NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_60_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			F1053_9025(loc1);
		}
	} else {
		
	}
	*(EIF_REFERENCE *)(Current + _REFACS_60_) = (EIF_REFERENCE) NULL;
	RTLE;
}

/* {EV_DIALOG_I}.set_default_cancel_button */
void F1186_10988 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_61_) = (EIF_REFERENCE) arg1;
	F1194_11188(Current);
	RTLE;
}

/* {EV_DIALOG_I}.remove_default_cancel_button */
void F1186_10989 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + _REFACS_61_) = (EIF_REFERENCE) NULL;
	F1194_11189(Current);
	RTLE;
}

/* {EV_DIALOG_I}.dialog_key_press_action */
void F1186_10994 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(RTCV(F152_3016(Current)) + _REFACS_1_);
	tb1 = '\0';
	tb2 = '\0';
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_29_);
		tb2 = (EIF_BOOLEAN)(tr1 == NULL);
	}
	if (tb2) {
		tr1 = F1112_10007(RTCW(loc2));
		tb1 = (EIF_BOOLEAN)(tr1 == NULL);
	}
	if (tb1) {
		loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 42L))) {
			tr1 = F1186_10984(Current);
			loc3 = tr1;
			tb1 = EIF_TEST(loc3);
		}
		if (tb1) {
			tb1 = F1026_8647(loc3);
			if (tb1) {
				tr1 = F969_7964(loc3);
				F603_4886(RTCW(tr1), NULL);
			}
		} else {
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 41L))) {
				tr1 = F1186_10985(Current);
				loc4 = tr1;
				tb1 = EIF_TEST(loc4);
			}
			if (tb1) {
				tb1 = '\0';
				tb2 = F1026_8647(loc4);
				if (tb2) {
					tb2 = F1027_8665(loc4);
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) {
					tr1 = F969_7964(loc4);
					F603_4886(RTCW(tr1), NULL);
				}
			}
		}
	}
	RTLE;
}

/* {EV_DIALOG_I}.set_current_push_button */
void F1186_10998 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = F1186_10985(Current);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		F1053_9025(loc1);
	}
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tb1 = F1053_9023(RTCW(arg1));
		if ((EIF_BOOLEAN) !tb1) {
			F1053_9024(RTCW(arg1));
		}
		if ((EIF_BOOLEAN)(arg1 != *(EIF_REFERENCE *)(Current + _REFACS_60_))) {
			RTAR(Current, arg1);
			*(EIF_REFERENCE *)(Current + _REFACS_62_) = (EIF_REFERENCE) arg1;
		} else {
			*(EIF_REFERENCE *)(Current + _REFACS_62_) = (EIF_REFERENCE) NULL;
		}
	} else {
		*(EIF_REFERENCE *)(Current + _REFACS_62_) = (EIF_REFERENCE) NULL;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_60_);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			F1053_9024(loc2);
		}
	}
	RTLE;
}

void EIF_Minit538 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
