
#ifndef _C11_ev511_
#define _C11_ev511_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1159_10552(EIF_REFERENCE);
extern EIF_INTEGER_32 F1159_10554(EIF_REFERENCE);
extern void EIF_Minit511(void);
extern void F1154_10507(EIF_REFERENCE, EIF_REFERENCE);
extern void F1158_10537(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
