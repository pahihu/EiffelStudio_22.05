
#ifndef _C11_ev539_
#define _C11_ev539_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1187_11001(EIF_REFERENCE);
extern EIF_REFERENCE F1187_11003(EIF_REFERENCE);
extern void F1187_11005(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit539(void);
extern void F1166_10761(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_POINTER F1_33(EIF_REFERENCE);
extern void F1166_10756(EIF_REFERENCE);
extern void F1114_10052(EIF_REFERENCE, EIF_POINTER);
extern long O8741[];
extern long O8051[];

#ifdef __cplusplus
}
#endif

#endif
