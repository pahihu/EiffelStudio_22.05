/*
 * Code for class EV_VIEWPORT_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev541.h"
#include <string.h>
#include <ev_gtk.h>
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F81_1664
static void inline_F81_1664 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_widget_size_allocate ((GtkWidget*) arg1, (GtkAllocation*) arg2)
	;
}
#define INLINE_F81_1664
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_VIEWPORT_IMP}.make */
void F1189_11023 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_0_) == F1_33(Current))) {
		tp1 = F1_33(Current);
		tp2 = F1_33(Current);
		tp1 = (EIF_POINTER) gtk_layout_new((GtkAdjustment*) tp1, (GtkAdjustment*) tp2);
		*(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_1_) = (EIF_POINTER) tp1;
		F1114_10052(Current, *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_1_));
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_1_);
		gtk_layout_set_size((GtkLayout*) tp1, (guint) (EIF_INTEGER_32) (((EIF_INTEGER_32) 16384L) * ((EIF_INTEGER_32) 2L)), (guint) (EIF_INTEGER_32) (((EIF_INTEGER_32) 16384L) * ((EIF_INTEGER_32) 2L)));
		*(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_2_) = (EIF_POINTER) *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_1_);
		F1189_11040(Current);
	}
	F1187_11001(Current);
	RTLE;
}

/* {EV_VIEWPORT_IMP}.set_item_size */
void F1189_11033 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc8);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc9);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		tr1 = *(EIF_REFERENCE *)(loc8 + _REFACS_3_);
		loc9 = tr1;
		loc9 = RTRV(eif_new_type(1163, 0x00),loc9);
		tb1 = EIF_TEST(loc9);
	}
	if (tb1) {
		loc2 = *(EIF_POINTER *)(loc9 + O8051[Dtype(loc9)-1113]);
		loc1 = (EIF_POINTER) gtk_widget_get_parent((GtkWidget*) loc2);
		ti4_1 = (EIF_INTEGER_32) sizeof(GtkAllocation);
		tp1 = malloc((size_t)ti4_1);
		loc3 = (EIF_POINTER) tp1;
		gtk_widget_get_allocation((GtkWidget*) loc1, (GtkAllocation*) loc3);
		
		
		ti4_1 = F1115_10091(loc9);
		loc4 = eif_max_int32 (arg1,ti4_1);
		ti4_1 = F1115_10092(loc9);
		loc5 = eif_max_int32 (arg2,ti4_1);
		tr1 = RTLNS(eif_new_type(80, 0x00).id, 80, _OBJSIZ_0_0_0_0_0_0_0_0_);
		F81_1659(RTCW(tr1), loc1, loc4, loc5);
		loc6 = *(EIF_BOOLEAN *)(Current+ _CHROFF_49_11_);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_11_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		tb1 = '\01';
		if (!(EIF_BOOLEAN)((EIF_INTEGER_32) (((GtkAllocation *)loc3)->width) != loc4)) {
			tb1 = (EIF_BOOLEAN)((EIF_INTEGER_32) (((GtkAllocation *)loc3)->height) != loc5);
		}
		if (tb1) {
			(((GtkAllocation *)loc3)->width = (gint)(loc4));
			(((GtkAllocation *)loc3)->height = (gint)(loc5));
			inline_F81_1664(loc1, loc3);
		} else {
		}
		free(loc3);
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_1_);
		gtk_container_check_resize((GtkContainer*) tp1);
		*(EIF_BOOLEAN *)(Current+ _CHROFF_49_11_) = (EIF_BOOLEAN) loc6;
	} else {
		
	}
	RTLE;
}

/* {EV_VIEWPORT_IMP}.on_size_allocate */
void F1189_11034 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1190_11072(Current, arg3, arg4);
	F1164_10689(Current, arg1, arg2, arg3, arg4);
	RTLE;
}

/* {EV_VIEWPORT_IMP}.internal_x_y_offset */
EIF_INTEGER_32 F1189_11037 (EIF_REFERENCE Current)
{
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 16384L);
}

/* {EV_VIEWPORT_IMP}.gtk_container_remove */
void F1189_11039 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (EIF_POINTER) gtk_widget_get_parent((GtkWidget*) arg2);
	gtk_container_remove((GtkContainer*) loc1, (GtkWidget*) arg2);
	gtk_container_remove((GtkContainer*) arg1, (GtkWidget*) loc1);
	F1189_11040(Current);
	RTLE;
}

/* {EV_VIEWPORT_IMP}.reset_offset_to_origin */
void F1189_11040 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_14_10_6_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_14_10_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	F1181_10910(Current, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {EV_VIEWPORT_IMP}.container_widget */
EIF_POINTER F1189_11041 (EIF_REFERENCE Current)
{
	return *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_2_);
}


/* {EV_VIEWPORT_IMP}.visual_widget */
EIF_POINTER F1189_11042 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_1_);
}

void EIF_Minit541 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
