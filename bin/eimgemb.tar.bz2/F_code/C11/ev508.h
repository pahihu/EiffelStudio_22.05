
#ifndef _C11_ev508_
#define _C11_ev508_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1156_10529(EIF_REFERENCE);
extern void EIF_Minit508(void);
extern EIF_REFERENCE F66_1109(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,1109)

#ifdef __cplusplus
}
#endif

#endif
