/*
 * Code for class EV_WIDGET_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev516.h"
#include <ev_gtk.h>
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WIDGET_IMP}.make */
void F1164_10681 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1115_10079(Current);
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	gtk_widget_set_redraw_on_allocate((GtkWidget*) tp1, (gboolean) (EIF_BOOLEAN) 0);
	F1087_9359(Current, (EIF_BOOLEAN) 1);
	F1164_10686(Current, *(EIF_POINTER *)(Current + O8051[dtype-1113]));
	F1164_10687(Current, *(EIF_POINTER *)(Current + O8051[dtype-1113]));
	RTLE;
}

/* {EV_WIDGET_IMP}.init_file_drop_actions */
void F1164_10685 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

/* {EV_WIDGET_IMP}.init_gtk_allocate_event_signal_connection */
void F1164_10686 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,tr4);
	RTLR(6,tr5);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN) !(EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((arg1)))) {
		loc1 = RTOSCF(10077,F1114_10077, (Current));
		tr1 = RTOSCF(316,F16_316, (Current));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,865,831,868,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2 = RTLNTS(typres0.id, 3, 0);
		}
		tr3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
		((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
		RTAR(tr2,tr3);
		ti4_1 = *(EIF_INTEGER_32 *)(Current + O5187[Dtype(Current)-826]);
		((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {939,0xFFF9,1,865,937,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr5= RTLNRF(typres0.id, (EIF_POINTER) __A257_333_3, (EIF_POINTER) _A257_333_3, (EIF_POINTER)(F830_6075),tr2, 1, 1);
		}
		F1114_10056(Current, arg1, tr1, tr5);
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.init_gtk_mapping_signal_connection */
void F1164_10687 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	loc1 = RTOSCF(10077,F1114_10077, (Current));
	tr1 = RTOSCF(310,F16_310, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,865,831,937,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {939,0xFFF9,0,865,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A257_326, (EIF_POINTER) _A257_326, (EIF_POINTER)(F830_6068),tr2, 1, 0);
	}
	F1114_10057(Current, arg1, tr1, tr3);
	tr1 = RTOSCF(311,F16_311, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,865,831,937,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {939,0xFFF9,0,865,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A257_327, (EIF_POINTER) _A257_327, (EIF_POINTER)(F830_6069),tr2, 1, 0);
	}
	F1114_10057(Current, arg1, tr1, tr3);
	tr1 = RTOSCF(312,F16_312, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,865,831,937,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = arg1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {939,0xFFF9,0,865,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3= RTLNRF(typres0.id, (EIF_POINTER) __A257_328, (EIF_POINTER) _A257_328, (EIF_POINTER)(F830_6070),tr2, 1, 0);
	}
	F1114_10057(Current, arg1, tr1, tr3);
	RTLE;
}

/* {EV_WIDGET_IMP}.on_key_event */
void F1164_10688 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,arg2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	if (arg3) {
		tr1 = *(EIF_REFERENCE *)(Current + O2671[dtype-117]);
		loc1 = tr1;
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && EIF_TEST(loc1))) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,1266,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
			RTAR(tr1,arg1);
			F603_4886(loc1, tr1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + O2673[dtype-117]);
		loc2 = tr1;
		if ((EIF_BOOLEAN) (EIF_TEST(loc2) && (EIF_BOOLEAN)(arg2 != NULL))) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,953,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = arg2;
			RTAR(tr1,arg2);
			(RTNA((loc2, tr1)));
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O2675[dtype-117]);
		loc3 = tr1;
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg1 != NULL) && EIF_TEST(loc3))) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,1266,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr1 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
			RTAR(tr1,arg1);
			F603_4886(loc3, tr1);
		}
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.on_size_allocate */
void F1164_10689 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_16 ti2_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc5);
	RTLR(2,tr1);
	RTLR(3,loc6);
	RTLR(4,loc7);
	RTLIU(5);
	
	RTGC;
	tb1 = '\01';
	ti2_1 = *(EIF_INTEGER_16 *)(Current + O8558[dtype-1163]);
	ti4_1 = (EIF_INTEGER_32) ti2_1;
	if (!(EIF_BOOLEAN)(arg3 != ti4_1)) {
		ti2_1 = *(EIF_INTEGER_16 *)(Current + O8559[dtype-1163]);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		tb1 = (EIF_BOOLEAN)(arg4 != ti4_1);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + O8549[dtype-1163]);
		loc5 = tr1;
		if (EIF_TEST(loc5)) {
			loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8553[Dtype(loc5)-1176])(loc5);
		}
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - loc1);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - loc1);
		ti2_1 = (EIF_INTEGER_16) arg3;
		*(EIF_INTEGER_16 *)(Current + O8558[dtype-1163]) = (EIF_INTEGER_16) ti2_1;
		ti2_1 = (EIF_INTEGER_16) arg4;
		*(EIF_INTEGER_16 *)(Current + O8559[dtype-1163]) = (EIF_INTEGER_16) ti2_1;
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + O2682[dtype-117]);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			tb2 = F409_4259(loc6);
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(10077,F1114_10077, (Current))) + _REFACS_42_);
			tr1 = F832_6105(RTCW(tr1), loc2, loc3, arg3, arg4);
			F603_4886(loc6, tr1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + O8549[dtype-1163]);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8596[Dtype(loc7)-1176])(loc7, Current);
		}
	} else {
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.on_focus_changed */
void F1164_10690 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	if (arg1) {
		tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(10077,F1114_10077, (Current))) + _REFACS_17_);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F99_2436(RTCV(RTOSCF(10077,F1114_10077, (Current))));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					l_type = eif_final_id(Y7519,Y7519_gen_type,dftype,1086);
					typarr0[3] = l_type.annotations | 0xFF00;
					typarr0[4] = l_type.id;
				}
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F1087_9345(Current);
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4354[Dtype(RTCW(tr1))-601])(tr1, tr2);
		}
		tr1 = *(EIF_REFERENCE *)(Current + O2677[dtype-117]);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			F603_4886(loc1, NULL);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(10077,F1114_10077, (Current))) + _REFACS_18_);
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = F99_2438(RTCV(RTOSCF(10077,F1114_10077, (Current))));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,0,0,0xFFFF};
				EIF_TYPE typres0;
				{
					EIF_TYPE l_type;
					l_type = eif_final_id(Y7519,Y7519_gen_type,dftype,1086);
					typarr0[3] = l_type.annotations | 0xFF00;
					typarr0[4] = l_type.id;
				}
				
				typres0 = eif_compound_id(dftype, typarr0);
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			tr3 = F1087_9345(Current);
			((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
			RTAR(tr2,tr3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4354[Dtype(RTCW(tr1))-601])(tr1, tr2);
		}
		tr1 = *(EIF_REFERENCE *)(Current + O2679[dtype-117]);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			F603_4886(loc2, NULL);
		}
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.on_pointer_enter_leave */
void F1164_10691 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	if (arg1) {
		tr1 = *(EIF_REFERENCE *)(Current + O2665[dtype-117]);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			F603_4886(loc1, NULL);
		}
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O2669[dtype-117]);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			F603_4886(loc2, NULL);
		}
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.call_button_event_actions */
void F1164_10692 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,tr3);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLIU(10);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,8,865,868,868,868,892,892,892,868,868,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNTS(typres0.id, 9, 1);
	}
	((EIF_TYPED_VALUE *)tr1+1)->it_i4 = arg2;
	((EIF_TYPED_VALUE *)tr1+2)->it_i4 = arg3;
	((EIF_TYPED_VALUE *)tr1+3)->it_i4 = arg4;
	((EIF_TYPED_VALUE *)tr1+4)->it_r8 = arg5;
	((EIF_TYPED_VALUE *)tr1+5)->it_r8 = arg6;
	((EIF_TYPED_VALUE *)tr1+6)->it_r8 = arg7;
	((EIF_TYPED_VALUE *)tr1+7)->it_i4 = arg8;
	((EIF_TYPED_VALUE *)tr1+8)->it_i4 = arg9;
	loc1 = (EIF_REFERENCE) tr1;
	if ((EIF_BOOLEAN)(arg1 != (EIF_INTEGER_32) GDK_BUTTON_RELEASE)) {
		if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_PRESS)) {
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_2BUTTON_PRESS)) {
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			} else {
				if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_3BUTTON_PRESS)) {
					loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				}
			}
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 4L)) && (EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L)))) {
			tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(10077,F1114_10077, (Current))) + _REFACS_13_);
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				tr1 = F99_2428(RTCV(RTOSCF(10077,F1114_10077, (Current))));
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,865,0,0,868,0xFFFF};
					EIF_TYPE typres0;
					{
						EIF_TYPE l_type;
						l_type = eif_final_id(Y7519,Y7519_gen_type,dftype,1086);
						typarr0[3] = l_type.annotations | 0xFF00;
						typarr0[4] = l_type.id;
					}
					
					typres0 = eif_compound_id(dftype, typarr0);
					tr2 = RTLNTS(typres0.id, 3, 0);
				}
				tr3 = F1087_9345(Current);
				((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
				RTAR(tr2,tr3);
				((EIF_TYPED_VALUE *)tr2+2)->it_i4 = loc2;
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4354[Dtype(RTCW(tr1))-601])(tr1, tr2);
			}
			tr1 = *(EIF_REFERENCE *)(Current + O2667[dtype-117]);
			loc3 = tr1;
			if (EIF_TEST(loc3)) {
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,868,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					tr1 = RTLNTS(typres0.id, 2, 1);
				}
				((EIF_TYPED_VALUE *)tr1+1)->it_i4 = loc2;
				(RTNA((loc3, tr1)));
			}
		} else {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 5L)) && (EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L)))) {
				tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(10077,F1114_10077, (Current))) + _REFACS_13_);
				if ((EIF_BOOLEAN)(tr1 != NULL)) {
					tr1 = F99_2428(RTCV(RTOSCF(10077,F1114_10077, (Current))));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,865,0,0,868,0xFFFF};
						EIF_TYPE typres0;
						{
							EIF_TYPE l_type;
							l_type = eif_final_id(Y7519,Y7519_gen_type,dftype,1086);
							typarr0[3] = l_type.annotations | 0xFF00;
							typarr0[4] = l_type.id;
						}
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr2 = RTLNTS(typres0.id, 3, 0);
					}
					tr3 = F1087_9345(Current);
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					((EIF_TYPED_VALUE *)tr2+2)->it_i4 = (EIF_INTEGER_32) -loc2;
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4354[Dtype(RTCW(tr1))-601])(tr1, tr2);
				}
				tr1 = *(EIF_REFERENCE *)(Current + O2667[dtype-117]);
				loc4 = tr1;
				if (EIF_TEST(loc4)) {
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,868,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
						tr1 = RTLNTS(typres0.id, 2, 1);
					}
					((EIF_TYPED_VALUE *)tr1+1)->it_i4 = (EIF_INTEGER_32) -loc2;
					(RTNA((loc4, tr1)));
				}
			}
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg4 >= ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN) (arg4 <= ((EIF_INTEGER_32) 3L)))) {
			if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_PRESS)) {
				tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(10077,F1114_10077, (Current))) + _REFACS_10_);
				if ((EIF_BOOLEAN)(tr1 != NULL)) {
					tr1 = F99_2422(RTCV(RTOSCF(10077,F1114_10077, (Current))));
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,865,0,0,868,868,868,0xFFFF};
						EIF_TYPE typres0;
						{
							EIF_TYPE l_type;
							l_type = eif_final_id(Y7519,Y7519_gen_type,dftype,1086);
							typarr0[3] = l_type.annotations | 0xFF00;
							typarr0[4] = l_type.id;
						}
						
						typres0 = eif_compound_id(dftype, typarr0);
						tr2 = RTLNTS(typres0.id, 5, 0);
					}
					tr3 = F1087_9345(Current);
					((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
					RTAR(tr2,tr3);
					((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg4;
					((EIF_TYPED_VALUE *)tr2+3)->it_i4 = arg8;
					((EIF_TYPED_VALUE *)tr2+4)->it_i4 = arg9;
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4354[Dtype(RTCW(tr1))-601])(tr1, tr2);
				}
				tr1 = *(EIF_REFERENCE *)(Current + O2659[dtype-117]);
				loc5 = tr1;
				if (EIF_TEST(loc5)) {
					F603_4886(loc5, loc1);
				}
			} else {
				if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_2BUTTON_PRESS)) {
					tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(10077,F1114_10077, (Current))) + _REFACS_11_);
					if ((EIF_BOOLEAN)(tr1 != NULL)) {
						tr1 = F99_2424(RTCV(RTOSCF(10077,F1114_10077, (Current))));
						{
							static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,865,0,0,868,868,868,0xFFFF};
							EIF_TYPE typres0;
							{
								EIF_TYPE l_type;
								l_type = eif_final_id(Y7519,Y7519_gen_type,dftype,1086);
								typarr0[3] = l_type.annotations | 0xFF00;
								typarr0[4] = l_type.id;
							}
							
							typres0 = eif_compound_id(dftype, typarr0);
							tr2 = RTLNTS(typres0.id, 5, 0);
						}
						tr3 = F1087_9345(Current);
						((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
						RTAR(tr2,tr3);
						((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg4;
						((EIF_TYPED_VALUE *)tr2+3)->it_i4 = arg8;
						((EIF_TYPED_VALUE *)tr2+4)->it_i4 = arg9;
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4354[Dtype(RTCW(tr1))-601])(tr1, tr2);
					}
					tr1 = *(EIF_REFERENCE *)(Current + O2661[dtype-117]);
					loc6 = tr1;
					if (EIF_TEST(loc6)) {
						F603_4886(loc6, loc1);
					}
				}
			}
		}
	} else {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg4 >= ((EIF_INTEGER_32) 1L)) && (EIF_BOOLEAN) (arg4 <= ((EIF_INTEGER_32) 3L)))) {
			tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(10077,F1114_10077, (Current))) + _REFACS_12_);
			if ((EIF_BOOLEAN)(tr1 != NULL)) {
				tr1 = F99_2426(RTCV(RTOSCF(10077,F1114_10077, (Current))));
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFFF9,4,865,0,0,868,868,868,0xFFFF};
					EIF_TYPE typres0;
					{
						EIF_TYPE l_type;
						l_type = eif_final_id(Y7519,Y7519_gen_type,dftype,1086);
						typarr0[3] = l_type.annotations | 0xFF00;
						typarr0[4] = l_type.id;
					}
					
					typres0 = eif_compound_id(dftype, typarr0);
					tr2 = RTLNTS(typres0.id, 5, 0);
				}
				tr3 = F1087_9345(Current);
				((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
				RTAR(tr2,tr3);
				((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg4;
				((EIF_TYPED_VALUE *)tr2+3)->it_i4 = arg8;
				((EIF_TYPED_VALUE *)tr2+4)->it_i4 = arg9;
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4354[Dtype(RTCW(tr1))-601])(tr1, tr2);
			}
			tr1 = *(EIF_REFERENCE *)(Current + O2663[dtype-117]);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				F603_4886(loc7, loc1);
			}
		}
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.parent */
EIF_REFERENCE F1164_10693 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8549[Dtype(Current)-1163]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1 + O7519[Dtype(loc1)-1086]);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {EV_WIDGET_IMP}.hide */
void F1164_10694 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8257[dtype-1158])(Current);
	*(EIF_INTEGER_32 *)(Current + O8541[dtype-1163]) = (EIF_INTEGER_32) ti4_1;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8258[dtype-1158])(Current);
	*(EIF_INTEGER_32 *)(Current + O8542[dtype-1163]) = (EIF_INTEGER_32) ti4_1;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8085[dtype-1116])(Current);
	*(EIF_INTEGER_32 *)(Current + O8543[dtype-1163]) = (EIF_INTEGER_32) ti4_1;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8086[dtype-1116])(Current);
	*(EIF_INTEGER_32 *)(Current + O8544[dtype-1163]) = (EIF_INTEGER_32) ti4_1;
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	gtk_widget_hide((GtkWidget*) tp1);
	RTLE;
}

/* {EV_WIDGET_IMP}.width */
EIF_INTEGER_32 F1164_10699 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F1115_10104(Current);
	if ((EIF_BOOLEAN) !F1115_10108(Current)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (Result <= ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O8541[dtype-1163]) > ((EIF_INTEGER_32) 0L)))) {
			Result = *(EIF_INTEGER_32 *)(Current + O8541[dtype-1163]);
			RTLE;
			return (EIF_INTEGER_32) Result;
		}
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_IMP}.height */
EIF_INTEGER_32 F1164_10700 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F1115_10105(Current);
	if ((EIF_BOOLEAN) !F1115_10108(Current)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (Result <= ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O8542[dtype-1163]) > ((EIF_INTEGER_32) 0L)))) {
			Result = *(EIF_INTEGER_32 *)(Current + O8542[dtype-1163]);
			RTLE;
			return (EIF_INTEGER_32) Result;
		}
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_IMP}.real_minimum_width */
EIF_INTEGER_32 F1164_10701 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F1115_10087(Current);
	if ((EIF_BOOLEAN) !F1115_10108(Current)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (Result <= ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O8543[dtype-1163]) > ((EIF_INTEGER_32) 0L)))) {
			Result = *(EIF_INTEGER_32 *)(Current + O8543[dtype-1163]);
			RTLE;
			return (EIF_INTEGER_32) Result;
		}
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_IMP}.real_minimum_height */
EIF_INTEGER_32 F1164_10702 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F1115_10088(Current);
	if ((EIF_BOOLEAN) !F1115_10108(Current)) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (Result <= ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O8544[dtype-1163]) > ((EIF_INTEGER_32) 0L)))) {
			Result = *(EIF_INTEGER_32 *)(Current + O8544[dtype-1163]);
			RTLE;
			return (EIF_INTEGER_32) Result;
		}
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_IMP}.set_minimum_width */
void F1164_10703 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8086[dtype-1116])(Current);
	tr1 = RTLNS(eif_new_type(80, 0x00).id, 80, _OBJSIZ_0_0_0_0_0_0_0_0_);
	F81_1659(RTCW(tr1), tp1, arg1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + O8549[dtype-1163]);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1188, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		ti4_1 = F1115_10091(Current);
		ti4_1 = eif_max_int32 (arg1,ti4_1);
		F1181_10911(loc2, ti4_1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O8549[dtype-1163]);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1171, 0x00),loc3);
		if (EIF_TEST(loc3)) {
			ti4_1 = F1115_10091(Current);
			ti4_1 = eif_max_int32 (arg1,ti4_1);
			(RTNA((loc3, F1087_9345(Current), ti4_1)));
		}
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.set_minimum_height */
void F1164_10704 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8085[dtype-1116])(Current);
	tr1 = RTLNS(eif_new_type(80, 0x00).id, 80, _OBJSIZ_0_0_0_0_0_0_0_0_);
	F81_1659(RTCW(tr1), tp1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + O8549[dtype-1163]);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1188, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		ti4_1 = F1115_10092(Current);
		ti4_1 = eif_max_int32 (arg1,ti4_1);
		F1181_10912(loc2, ti4_1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O8549[dtype-1163]);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1171, 0x00),loc3);
		if (EIF_TEST(loc3)) {
			ti4_1 = F1115_10092(Current);
			ti4_1 = eif_max_int32 (arg1,ti4_1);
			(RTNA((loc3, F1087_9345(Current), ti4_1)));
		}
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.set_minimum_size */
void F1164_10705 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(80, 0x00).id, 80, _OBJSIZ_0_0_0_0_0_0_0_0_);
	F81_1659(RTCW(tr1), *(EIF_POINTER *)(Current + O8051[dtype-1113]), arg1, arg2);
	tr1 = *(EIF_REFERENCE *)(Current + O8549[dtype-1163]);
	loc2 = tr1;
	loc2 = RTRV(eif_new_type(1188, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		ti4_1 = F1115_10091(Current);
		ti4_1 = eif_max_int32 (arg1,ti4_1);
		ti4_2 = F1115_10092(Current);
		ti4_2 = eif_max_int32 (arg2,ti4_2);
		F1189_11033(loc2, ti4_1, ti4_2);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O8549[dtype-1163]);
		loc3 = tr1;
		loc3 = RTRV(eif_new_type(1171, 0x00),loc3);
		if (EIF_TEST(loc3)) {
			ti4_1 = F1115_10091(Current);
			ti4_1 = eif_max_int32 (arg1,ti4_1);
			ti4_2 = F1115_10092(Current);
			ti4_2 = eif_max_int32 (arg2,ti4_2);
			(RTNA((loc3, F1087_9345(Current), ti4_1, ti4_2)));
		}
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.process_pending_events */
void F1164_10714 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1112_9927(RTCV(RTOSCF(10077,F1114_10077, (Current))));
	RTLE;
}

/* {EV_WIDGET_IMP}.set_parent_imp */
void F1164_10715 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O8549[Dtype(Current)-1163]) = (EIF_REFERENCE) arg1;
}

/* {EV_WIDGET_IMP}.destroy */
void F1164_10716 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1087_9344(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		loc1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
		if ((EIF_BOOLEAN)(loc1 != F1_33(Current))) {
			tp1 = F1_33(Current);
			gdk_window_set_cursor((GdkWindow*) loc1, (GdkCursor*) tp1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + O8549[dtype-1163]);
		loc2 = tr1;
		if (EIF_TEST(loc2)) {
			tr1 = F1087_9345(loc2);
			tr2 = F1087_9345(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4041[Dtype(RTCW(tr1))-503])(tr1, tr2);
		}
		F1114_10055(Current);
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.on_widget_mapped */
void F1164_10718 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8098[dtype-1114]);
	loc1 = tr1;
	if ((EIF_BOOLEAN) (EIF_TEST(loc1) && (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8097[dtype-1114]) != loc1))) {
		F1115_10098(Current, loc1);
	}
	RTLE;
}

/* {EV_WIDGET_IMP}.on_widget_unmapped */
void F1164_10719 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_REFERENCE *)(Current + O8097[Dtype(Current)-1114]) = (EIF_REFERENCE) NULL;
}

/* {EV_WIDGET_IMP}.on_widget_hidden */
void F1164_10720 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_REFERENCE *)(Current + O8097[Dtype(Current)-1114]) = (EIF_REFERENCE) NULL;
}

/* {EV_WIDGET_IMP}.internal_x_y_offset */
EIF_INTEGER_32 F1164_10721 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
}

void EIF_Minit516 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
