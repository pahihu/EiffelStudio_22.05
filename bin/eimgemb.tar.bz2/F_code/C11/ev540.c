/*
 * Code for class EV_FRAME_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev540.h"
#include <ev_gtk.h>
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F83_2084
static EIF_INTEGER_32 inline_F83_2084 (void)
{
	return (EIF_INTEGER_32) (GTK_JUSTIFY_CENTER)
	;
}
#define INLINE_F83_2084
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FRAME_IMP}.needs_event_box */
EIF_BOOLEAN F1188_11007 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_FRAME_IMP}.make */
void F1188_11009 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1_33(Current);
	tp1 = (EIF_POINTER) gtk_frame_new((gchar*) tp1);
	F1114_10052(Current, tp1);
	tp1 = F1166_10757(Current);
	tp2 = F1_33(Current);
	gtk_frame_set_label((GtkFrame*) tp1, (gchar*) tp2);
	F1188_11011(Current, ((EIF_INTEGER_32) 3L));
	F1188_11012(Current);
	F1187_11001(Current);
	RTLE;
}

/* {EV_FRAME_IMP}.set_style */
void F1188_11011 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	switch (arg1) {
		case 1L:
			loc1 = (EIF_INTEGER_32) GTK_SHADOW_IN;
			break;
		case 2L:
			loc1 = (EIF_INTEGER_32) GTK_SHADOW_OUT;
			break;
		case 3L:
			loc1 = (EIF_INTEGER_32) GTK_SHADOW_ETCHED_IN;
			break;
		case 4L:
			loc1 = (EIF_INTEGER_32) GTK_SHADOW_ETCHED_OUT;
			break;
		default:
			
			break;
	}
	tp1 = F1166_10757(Current);
	gtk_frame_set_shadow_type((GtkFrame*) tp1, (GtkShadowType) loc1);
	RTLE;
}

/* {EV_FRAME_IMP}.align_text_left */
void F1188_11012 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1166_10757(Current);
	gtk_frame_set_label_align((GtkFrame*) tp1, (gfloat) (EIF_REAL_32) 0.0, (gfloat) (EIF_REAL_32) 0.5);
	ti4_1 = (EIF_INTEGER_32) GTK_JUSTIFY_LEFT;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_51_13_10_7_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {EV_FRAME_IMP}.align_text_center */
void F1188_11014 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1166_10757(Current);
	gtk_frame_set_label_align((GtkFrame*) tp1, (gfloat) (EIF_REAL_32) 0.5, (gfloat) (EIF_REAL_32) 0.5);
	ti4_1 = inline_F83_2084();
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_51_13_10_7_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {EV_FRAME_IMP}.text */
EIF_REFERENCE F1188_11016 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_50_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		Result = F945_7511(RTMS_EX_H("",0,0));
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + _REFACS_50_) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_FRAME_IMP}.set_text */
void F1188_11017 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = F945_7511(RTCW(arg1));
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (tr1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_50_) = (EIF_REFERENCE) tr1;
	loc1 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F818_5410(RTCW(loc1), arg1);
	tp1 = F1166_10757(Current);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	gtk_frame_set_label((GtkFrame*) tp1, (gchar*) tp2);
	RTLE;
}

/* {EV_FRAME_IMP}.style_element_name */
EIF_REFERENCE F1188_11019 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTMS_EX_H("frame",5,1919770981);
	RTLE;
	return Result;
}

void EIF_Minit540 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
