/*
 * Code for class EV_HORIZONTAL_BOX_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev527.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_HORIZONTAL_BOX_I}.pointer_offset */
EIF_INTEGER_32 F1175_10873 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(9854,F1111_9854, (RTCV(F1161_10616(Current))));
	tr1 = F1016_8498(RTCW(tr1));
	Result = F629_4969(RTCW(tr1));
	ti4_1 = F1115_10080(Current);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result - ti4_1);
	RTLE;
	return Result;
}

/* {EV_HORIZONTAL_BOX_I}.docking_dimension_of_current_item */
EIF_INTEGER_32 F1175_10874 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1025_8602(RTCV(F1087_9345(Current)));
	Result = F1005_8384(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_HORIZONTAL_BOX_I}.docking_dimension_of_current */
EIF_INTEGER_32 F1175_10875 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F1164_10699(Current);
}

void EIF_Minit527 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
