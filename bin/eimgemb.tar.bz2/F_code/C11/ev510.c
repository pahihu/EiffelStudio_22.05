/*
 * Code for class EV_FILE_DIALOG_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev510.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F81_1926
static EIF_POINTER inline_F81_1926 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	return (EIF_POINTER) (gtk_file_chooser_dialog_new ((gchar*) arg1, (GtkWindow*) arg2, (GtkFileChooserAction) arg3, NULL, NULL))
	;
}
#define INLINE_F81_1926
#endif
#ifndef INLINE_F81_1910
static EIF_POINTER inline_F81_1910 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	return (EIF_POINTER) (gtk_dialog_add_button ((GtkDialog*) arg1, (gchar*) arg2, (gint) arg3))
	;
}
#define INLINE_F81_1910
#endif
#ifndef INLINE_F81_1931
static void inline_F81_1931 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_file_chooser_set_local_only ((GtkFileChooser*) arg1, (gboolean) arg2)
	;
}
#define INLINE_F81_1931
#endif
#ifndef INLINE_F81_1912
static void inline_F81_1912 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	gtk_dialog_set_default_response ((GtkDialog*) arg1, (gint) arg2)
	;
}
#define INLINE_F81_1912
#endif
#ifndef INLINE_F81_1928
static EIF_POINTER inline_F81_1928 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_file_chooser_get_filename ((GtkFileChooser*) arg1))
	;
}
#define INLINE_F81_1928
#endif
#ifndef INLINE_F81_1930
static void inline_F81_1930 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_file_chooser_set_filename ((GtkFileChooser*) arg1, (gchar*) arg2)
	;
}
#define INLINE_F81_1930
#endif
#ifndef INLINE_F81_1923
static void inline_F81_1923 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_file_chooser_set_current_name ((GtkFileChooser*) arg1, (gchar*) arg2)
	;
}
#define INLINE_F81_1923
#endif
#ifndef INLINE_F81_1918
static void inline_F81_1918 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_file_chooser_remove_filter ((GtkFileChooser*) arg1, (GtkFileFilter*) arg2)
	;
}
#define INLINE_F81_1918
#endif
#ifndef INLINE_F81_1915
static void inline_F81_1915 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_file_filter_set_name ((GtkFileFilter*) arg1, (gchar*) arg2)
	;
}
#define INLINE_F81_1915
#endif
#ifndef INLINE_F81_1914
static void inline_F81_1914 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_file_filter_add_pattern ((GtkFileFilter*) arg1, (gchar*) arg2)
	;
}
#define INLINE_F81_1914
#endif
#ifndef INLINE_F81_1917
static void inline_F81_1917 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_file_chooser_add_filter ((GtkFileChooser*) arg1, (GtkFileFilter*) arg2)
	;
}
#define INLINE_F81_1917
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FILE_DIALOG_IMP}.make */
void F1158_10537 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
	tr1 = RTMS_EX_H("Select file",11,1098209125);
	F818_5410(RTCW(loc1), tr1);
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	tp2 = F1_33(Current);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8428[dtype-1158])(Current);
	tp1 = inline_F81_1926(tp1, tp2, ti4_1);
	F1114_10052(Current, tp1);
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	tr1 = RTLNS(eif_new_type(80, 0x00).id, 80, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tp2 = F81_1682(RTCW(tr1));
	ti4_1 = (EIF_INTEGER_32) GTK_RESPONSE_OK;
	loc2 = inline_F81_1910(tp1, tp2, ti4_1);
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	tr1 = RTLNS(eif_new_type(80, 0x00).id, 80, _OBJSIZ_0_0_0_0_0_0_0_0_);
	tp2 = F81_1692(RTCW(tr1));
	ti4_1 = (EIF_INTEGER_32) GTK_RESPONSE_CANCEL;
	loc2 = inline_F81_1910(tp1, tp2, ti4_1);
	{
		static EIF_TYPE_INDEX typarr0[] = {584,0xFFF9,2,865,944,944,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F585_4749(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	F1154_10503(Current);
	F1087_9359(Current, (EIF_BOOLEAN) 0);
	tr1 = RTMS32_EX_H("*\000\000\000.\000\000\000*\000\000\000",3,2764330);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) tr1;
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	inline_F81_1931(tp1, (EIF_BOOLEAN) 1);
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	ti4_1 = (EIF_INTEGER_32) GTK_RESPONSE_ACCEPT;
	inline_F81_1912(tp1, ti4_1);
	F1154_10511(Current);
	tr1 = F238_3943(RTCV(RTOSCF(10077,F1114_10077, (Current))));
	F1158_10544(Current, tr1);
	F1087_9359(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_FILE_DIALOG_IMP}.full_file_path */
EIF_REFERENCE F1158_10538 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	if (F1154_10513(Current)) {
		tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
		loc1 = inline_F81_1928(tp1);
		if ((EIF_BOOLEAN)(loc1 != F1_33(Current))) {
			Result = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F834_6133(RTCW(Result), loc1);
			g_free((gpointer) loc1);
		} else {
			Result = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F834_6127(RTCW(Result));
			RTLE;
			return (EIF_REFERENCE) Result;
		}
	} else {
		Result = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F834_6127(RTCW(Result));
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_FILE_DIALOG_IMP}.filter */
EIF_REFERENCE F1158_10539 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_10_);
}


/* {EV_FILE_DIALOG_IMP}.start_path */
EIF_REFERENCE F1158_10541 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_9_);
}


/* {EV_FILE_DIALOG_IMP}.set_full_file_path */
void F1158_10543 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F818_5405(RTCW(loc1), arg1);
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	inline_F81_1930(tp1, tp2);
	tr1 = F834_6145(RTCW(arg1));
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
		F818_5405(RTCW(loc1), loc2);
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
		inline_F81_1923(tp1, tp2);
	}
	RTLE;
}

/* {EV_FILE_DIALOG_IMP}.set_start_path */
void F1158_10544 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) arg1;
	loc1 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F818_5405(RTCW(loc1), arg1);
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	gtk_file_chooser_set_current_folder((GtkFileChooser*) tp1, (gchar*) tp2);
	RTLE;
}

/* {EV_FILE_DIALOG_IMP}.on_ok */
void F1158_10545 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	loc3 = inline_F81_1928(tp1);
	tb1 = !loc3;
	if ((EIF_BOOLEAN) !tb1) {
		loc1 = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_2_1_0_0_0_0_0_0_);
		F834_6133(RTCW(loc1), loc3);
		loc2 = RTLNS(eif_new_type(823, 0x00).id, 823, _OBJSIZ_4_6_2_4_1_1_2_1_);
		F823_5634(RTCW(loc2), loc1);
		tb1 = '\01';
		tb2 = F823_5668(RTCW(loc2));
		if (!(EIF_BOOLEAN) !tb2) {
			tb2 = F823_5677(RTCW(loc2));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			F1154_10517(Current);
		}
		g_free((gpointer) loc3);
	}
	RTLE;
}

/* {EV_FILE_DIALOG_IMP}.remove_file_filters */
void F1158_10546 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	loc1 = (EIF_POINTER) gtk_file_chooser_list_filters((GtkFileChooser*) tp1);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		loc2 = (EIF_POINTER) g_slist_nth_data((GSList*) loc1, (guint) loc3);
		for (;;) {
			tb1 = !loc2;
			if (tb1) break;
			tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
			inline_F81_1918(tp1, loc2);
			loc3++;
			loc2 = (EIF_POINTER) g_slist_nth_data((GSList*) loc1, (guint) loc3);
		}
		g_slist_free((GSList*) loc1);
	}
	RTLE;
}

/* {EV_FILE_DIALOG_IMP}.show_modal_to_window */
void F1158_10547 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,loc1);
	RTLR(5,loc5);
	RTLR(6,tr2);
	RTLR(7,arg1);
	RTLIU(8);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tb1 = F409_4259(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		F1158_10546(Current);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	F585_4780(RTCW(tr1));
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tb1 = F517_4470(RTCW(tr1));
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr1 = F585_4754(RTCW(tr1));
		loc2 = F866_6219(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		loc2 = RTRV(eif_new_type(944, 0x00), loc2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		tr1 = F585_4754(RTCW(tr1));
		loc3 = F866_6219(RTCW(tr1), ((EIF_INTEGER_32) 2L));
		loc3 = RTRV(eif_new_type(944, 0x00), loc3);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tr1 = F945_7512(RTCW(loc2));
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ';';
			loc1 = F945_7530(RTCW(tr1), tw1);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				loc4 = (EIF_POINTER) gtk_file_filter_new();
				loc5 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
				F818_5410(RTCW(loc5), loc3);
				tp1 = *(EIF_POINTER *)(RTCW(loc5)+ _PTROFF_0_1_0_1_0_0_);
				inline_F81_1915(loc4, tp1);
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R4018[Dtype(RTCW(loc1))-564])(loc1);
				for (;;) {
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R4017[Dtype(RTCW(loc1))-564])(loc1);
					if (tb2) break;
					tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4052[Dtype(RTCW(loc1))-564])(loc1);
					tr2 = RTMS_EX_H("*.*",3,2764330);
					tb3 = F945_7497(RTCW(tr1), tr2);
					if (tb3) {
						loc5 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
						tr1 = RTMS_EX_H("*",1,42);
						F818_5410(RTCW(loc5), tr1);
					} else {
						loc5 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
						tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4052[Dtype(RTCW(loc1))-564])(loc1);
						F818_5410(RTCW(loc5), tr1);
					}
					tp1 = *(EIF_POINTER *)(RTCW(loc5)+ _PTROFF_0_1_0_1_0_0_);
					inline_F81_1914(loc4, tp1);
					(FUNCTION_CAST(void, (EIF_REFERENCE)) R4031[Dtype(RTCW(loc1))-564])(loc1);
				}
				tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
				inline_F81_1917(tp1, loc4);
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		F585_4782(RTCW(tr1));
	}
	F1154_10506(Current, arg1);
	RTLE;
}

void EIF_Minit510 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
