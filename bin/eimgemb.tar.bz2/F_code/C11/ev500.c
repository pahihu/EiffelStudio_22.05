/*
 * Code for class EV_FONTABLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev500.h"
#include <ev_gtk.h>
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F18_415
static EIF_POINTER inline_F18_415 (void)
{
	return pango_attr_list_new();
	;
}
#define INLINE_F18_415
#endif
#ifndef INLINE_F18_418
static EIF_POINTER inline_F18_418 (EIF_POINTER arg1)
{
	return pango_attr_font_desc_new ((const PangoFontDescription *)arg1);
	;
}
#define INLINE_F18_418
#endif
#ifndef INLINE_F18_419
static void inline_F18_419 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	pango_attr_list_insert ((PangoAttrList *)arg1, (PangoAttribute *)arg2);
	;
}
#define INLINE_F18_419
#endif
#ifndef INLINE_F83_2178
static void inline_F83_2178 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_label_set_attributes ((GtkLabel *)arg1, (PangoAttrList *)arg2);
	;
}
#define INLINE_F83_2178
#endif
#ifndef INLINE_F18_420
static void inline_F18_420 (EIF_POINTER arg1)
{
	pango_attr_list_unref ((PangoAttrList *)arg1);
	;
}
#define INLINE_F18_420
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FONTABLE_IMP}.font */
EIF_REFERENCE F1148_10459 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + O8379[Dtype(Current)-1147]);
	if ((EIF_BOOLEAN)(loc1 == NULL)) {
		tr1 = RTLNS(eif_new_type(992, 0x00).id, 992, _OBJSIZ_2_0_0_0_0_0_0_0_);
		F982_8029(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {EV_FONTABLE_IMP}.set_font */
void F1148_10460 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,loc4);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8379[dtype-1147]) != arg1)) {
		loc1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O8379[dtype-1147]) = (EIF_REFERENCE) loc1;
		RTCT0("attached {EV_FONT_IMP} l_private_font.implementation as font_imp", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		loc4 = tr1;
		loc4 = RTRV(eif_new_type(1107, 0x00),loc4);
		if (EIF_TEST(loc4)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8378[dtype-1187])(Current);
		if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_LABEL((tp1)))) {
			loc2 = inline_F18_415();
			tp1 = *(EIF_POINTER *)(loc4+ _PTROFF_3_2_0_8_0_0_);
			loc3 = inline_F18_418(tp1);
			inline_F18_419(loc2, loc3);
			tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8378[dtype-1187])(Current);
			inline_F83_2178(tp1, loc2);
			inline_F18_420(loc2);
		} else {
		}
	}
	RTLE;
}

/* {EV_FONTABLE_IMP}.fontable_widget */
EIF_POINTER F1148_10462 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8377[Dtype(Current)-1187])(Current);
}

void EIF_Minit500 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
