/*
 * Code for class EV_VERTICAL_BOX_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev526.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_VERTICAL_BOX_I}.pointer_offset */
EIF_INTEGER_32 F1174_10869 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(9854,F1111_9854, (RTCV(F1161_10616(Current))));
	tr1 = F1016_8498(RTCW(tr1));
	Result = F629_4971(RTCW(tr1));
	ti4_1 = F1115_10081(Current);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result - ti4_1);
	RTLE;
	return Result;
}

/* {EV_VERTICAL_BOX_I}.docking_dimension_of_current_item */
EIF_INTEGER_32 F1174_10870 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1025_8602(RTCV(F1087_9345(Current)));
	Result = F1005_8385(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_VERTICAL_BOX_I}.docking_dimension_of_current */
EIF_INTEGER_32 F1174_10871 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F1164_10700(Current);
}

void EIF_Minit526 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
