/*
 * Code for class EV_PICK_AND_DROPABLE_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev514.h"
#include <ev_gtk.h>
#include "eif_built_in.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F83_2134
static void inline_F83_2134 (EIF_POINTER arg1)
{
	gtk_menu_shell_cancel((GtkMenuShell*)arg1);
	;
}
#define INLINE_F83_2134
#endif
#ifndef INLINE_F83_2019
static EIF_POINTER inline_F83_2019 (EIF_POINTER arg1)
{
	return gtk_widget_get_display ((GtkWidget *)arg1)
	;
}
#define INLINE_F83_2019
#endif
#ifndef INLINE_F4_63
static EIF_INTEGER_32 inline_F4_63 (void)
{
	return GDK_SEAT_CAPABILITY_ALL;
	;
}
#define INLINE_F4_63
#endif
#ifndef INLINE_F80_1256
static void inline_F80_1256 (EIF_POINTER arg1)
{
	gdk_display_flush ((GdkDisplay *)arg1);
	;
}
#define INLINE_F80_1256
#endif
#ifndef INLINE_F17_357
static EIF_POINTER inline_F17_357 (void)
{
	return (GdkDevice*) gdk_seat_get_pointer((GdkSeat*) gdk_display_get_default_seat ((GdkDisplay*) gdk_display_get_default()));
	;
}
#define INLINE_F17_357
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PICK_AND_DROPABLE_IMP}.button_actions_handled_by_signals */
EIF_BOOLEAN F1162_10619 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {EV_PICK_AND_DROPABLE_IMP}.on_pointer_motion */
void F1162_10620 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_16 loc5 = (EIF_INTEGER_16) 0;
	EIF_INTEGER_16 loc6 = (EIF_INTEGER_16) 0;
	EIF_INTEGER_16 loc7 = (EIF_INTEGER_16) 0;
	EIF_INTEGER_16 loc8 = (EIF_INTEGER_16) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLR(5,loc9);
	RTLIU(6);
	
	RTGC;
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	loc4 = (EIF_REFERENCE) Current;
	loc1 = Current;
	loc1 = RTRV(eif_new_type(1131, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tb1 = '\0';
		if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8496[dtype-1176])(Current)) {
			tb2 = '\01';
			tb3 = *(EIF_BOOLEAN *)(RTCW(loc1) + O8307[Dtype(loc1)-1131]);
			if (!tb3) {
				tr1 = F1112_10008(RTCV(RTOSCF(10077,F1114_10077, (Current))));
				tb2 = (EIF_BOOLEAN)(tr1 == loc1);
			}
			tb1 = tb2;
		}
		if (tb1) {
			loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			ti4_1 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 1L));
			ti4_2 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 2L));
			tr8_1 = F866_6228(RTCW(arg1), ((EIF_INTEGER_32) 3L));
			tr8_2 = F866_6228(RTCW(arg1), ((EIF_INTEGER_32) 4L));
			tr8_3 = F866_6228(RTCW(arg1), ((EIF_INTEGER_32) 5L));
			ti4_3 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 6L));
			ti4_4 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 7L));
			F1132_10362(RTCW(loc1), ti4_1, ti4_2, tr8_1, tr8_2, tr8_3, ti4_3, ti4_4);
		} else {
			tb1 = '\0';
			tb2 = '\0';
			tb3 = *(EIF_BOOLEAN *)(RTCW(loc1) + O8307[Dtype(loc1)-1131]);
			if (tb3) {
				tb2 = F1161_10591(Current);
			}
			if (tb2) {
				tr1 = F1112_10007(RTCV(RTOSCF(10077,F1114_10077, (Current))));
				tb1 = (EIF_BOOLEAN)(tr1 == NULL);
			}
			if (tb1) {
				loc5 = *(EIF_INTEGER_16 *)(RTCW(loc1) + O2640[Dtype(loc1)-116]);
				loc6 = *(EIF_INTEGER_16 *)(RTCW(loc1) + O2641[Dtype(loc1)-116]);
				tb1 = '\01';
				ti4_1 = (EIF_INTEGER_32) loc5;
				ti4_2 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 1L));
				ti4_1 = eif_abs_int32 ((EIF_INTEGER_32) (ti4_1 - ti4_2));
				ti4_2 = ((EIF_INTEGER_32) 3L);
				if (!(EIF_BOOLEAN) (ti4_1 > ti4_2)) {
					ti4_1 = (EIF_INTEGER_32) loc6;
					ti4_2 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 2L));
					ti4_1 = eif_abs_int32 ((EIF_INTEGER_32) (ti4_1 - ti4_2));
					ti4_2 = ((EIF_INTEGER_32) 3L);
					tb1 = (EIF_BOOLEAN) (ti4_1 > ti4_2);
				}
				if (tb1) {
					loc7 = *(EIF_INTEGER_16 *)(RTCW(loc1) + O8308[Dtype(loc1)-1131]);
					loc8 = *(EIF_INTEGER_16 *)(RTCW(loc1) + O8309[Dtype(loc1)-1131]);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					F1132_10370(RTCW(loc1));
					ti4_1 = (EIF_INTEGER_32) loc5;
					ti4_2 = (EIF_INTEGER_32) loc6;
					ti4_3 = (EIF_INTEGER_32) loc7;
					ti4_4 = (EIF_INTEGER_32) loc8;
					F1162_10639(Current, ti4_1, ti4_2, ((EIF_INTEGER_32) 1L), (EIF_BOOLEAN) 1, (EIF_REAL_64) 0.0, (EIF_REAL_64) 0.0, (EIF_REAL_64) 0.0, ti4_3, ti4_4, (EIF_BOOLEAN) 0);
				}
			}
		}
		tr1 = F1112_10008(RTCV(RTOSCF(10077,F1114_10077, (Current))));
		if ((EIF_BOOLEAN)(tr1 == loc1)) {
			loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
	}
	tb1 = '\0';
	if (loc3) {
		tr1 = F1112_10007(RTCV(RTOSCF(10077,F1114_10077, (Current))));
		tb1 = (EIF_BOOLEAN)(tr1 == loc4);
	}
	if (tb1) {
		ti4_1 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 1L));
		ti4_2 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 2L));
		tr8_1 = F866_6228(RTCW(arg1), ((EIF_INTEGER_32) 3L));
		tr8_2 = F866_6228(RTCW(arg1), ((EIF_INTEGER_32) 4L));
		tr8_3 = F866_6228(RTCW(arg1), ((EIF_INTEGER_32) 5L));
		ti4_3 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 6L));
		ti4_4 = (EIF_INTEGER_32) eif_builtin_TUPLE_integer_32_item__i4_i4 (arg1, ((EIF_INTEGER_32) 7L));
		F1161_10604(Current, ti4_1, ti4_2, tr8_1, tr8_2, tr8_3, ti4_3, ti4_4);
		loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	tb1 = '\0';
	if (loc2) {
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8488[dtype-1176])(Current);
		loc9 = tr1;
		tb1 = EIF_TEST(loc9);
	}
	if (tb1) {
		F603_4886(loc9, arg1);
	}
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.enable_capture */
void F1162_10623 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1162_10625(Current)) {
		loc2 = (EIF_POINTER) gtk_grab_get_current();
		if ((EIF_BOOLEAN)(loc2 != F1_33(Current))) {
			if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_MENU((loc2)))) {
				inline_F83_2134(loc2);
			}
		}
		if ((EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8101[dtype-1116])(Current)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R8100[dtype-1116])(Current);
		}
		loc1 = *(EIF_REFERENCE *)(Current + O7519[dtype-1086]);
		loc1 = RTRV(eif_new_type(1026, 0x00), loc1);
		
		tr1 = RTOSCF(10077,F1114_10077, (Current));
		F1111_9823(RTCW(tr1), loc1);
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8094[dtype-1116])(Current);
		gtk_grab_add((GtkWidget*) tp1);
		tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(10077,F1114_10077, (Current))) + _REFACS_44_);
		if ((EIF_BOOLEAN)(tr1 != F1115_10111(Current))) {
			F1162_10626(Current);
		}
		F1112_10019(RTCV(RTOSCF(10077,F1114_10077, (Current))));
	}
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.disable_capture */
void F1162_10624 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if (F1162_10625(Current)) {
		tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8094[Dtype(Current)-1116])(Current);
		gtk_grab_remove((GtkWidget*) tp1);
		tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(10077,F1114_10077, (Current))) + _REFACS_44_);
		if ((EIF_BOOLEAN)(tr1 != F1115_10111(Current))) {
			F1162_10627(Current);
		}
		tr1 = RTOSCF(10077,F1114_10077, (Current));
		F1111_9823(RTCW(tr1), NULL);
	}
	F1112_10018(RTCV(RTOSCF(10077,F1114_10077, (Current))));
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.has_capture */
EIF_BOOLEAN F1162_10625 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(10077,F1114_10077, (Current))) + _REFACS_29_);
	if (!(EIF_BOOLEAN)(tr1 == *(EIF_REFERENCE *)(Current + O7519[Dtype(Current)-1086]))) {
		tr1 = F1112_10007(RTCV(RTOSCF(10077,F1114_10077, (Current))));
		Result = (EIF_BOOLEAN)(tr1 == Current);
	}
	RTLE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_IMP}.grab_keyboard_and_mouse */
void F1162_10626 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER loc4 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8094[dtype-1116])(Current);
	loc2 = inline_F83_2019(tp1);
	loc3 = (EIF_POINTER) gdk_display_get_default_seat((GdkDisplay*) loc2);
	F1112_10019(RTCV(RTOSCF(10077,F1114_10077, (Current))));
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8094[dtype-1116])(Current);
	tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
	ti4_1 = inline_F4_63();
	loc1 = (EIF_INTEGER_32) gdk_seat_grab((GdkSeat*) loc3, (GdkWindow*) tp1, (GdkSeatCapabilities) ti4_1, (gboolean) (EIF_BOOLEAN) 1, (GdkCursor*) loc4, (const GdkEvent*) loc4, (GdkSeatGrabPrepareFunc) loc4, (gpointer) loc4);
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.release_keyboard_and_mouse */
void F1162_10627 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8094[Dtype(Current)-1116])(Current);
	loc1 = inline_F83_2019(tp1);
	loc2 = (EIF_POINTER) gdk_display_get_default_seat((GdkDisplay*) loc1);
	gdk_seat_ungrab((GdkSeat*) loc2);
	F1112_10018(RTCV(RTOSCF(10077,F1114_10077, (Current))));
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.activate_docking_source_hint */
void F1162_10628 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg3);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(10077,F1114_10077, (Current));
	F1112_10003(RTCW(tr1), arg1, arg2, arg3);
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.deactivate_docking_source_hint */
void F1162_10629 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1112_10004(RTCV(RTOSCF(10077,F1114_10077, (Current))));
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.draw_rubber_band */
void F1162_10630 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1111_9862(RTCV(RTOSCF(10077,F1114_10077, (Current))));
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.erase_rubber_band */
void F1162_10631 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1111_9863(RTCV(RTOSCF(10077,F1114_10077, (Current))));
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.enable_transport */
void F1162_10632 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O8457[Dtype(Current)-1160]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_PICK_AND_DROPABLE_IMP}.pre_pick_steps */
void F1162_10634 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_16 ti2_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8094[dtype-1116])(Current);
	tp1 = inline_F83_2019(tp1);
	inline_F80_1256(tp1);
	tr1 = F1161_10606(Current);
	F1161_10605(Current, tr1);
	loc1 = *(EIF_REFERENCE *)(Current + O8432[dtype-1160]);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = RTOSCF(10077,F1114_10077, (Current));
		tr2 = RTCCL(loc1);
		F1112_10000(RTCW(tr1), Current, tr2);
	}
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O2300[dtype-88]) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + O2300[dtype-88]);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,865,868,868,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr2 = RTLNTS(typres0.id, 3, 1);
		}
		((EIF_TYPED_VALUE *)tr2+1)->it_i4 = arg1;
		((EIF_TYPED_VALUE *)tr2+2)->it_i4 = arg2;
		(RTNA((RTCW(tr1), tr2)));
	}
	ti2_1 = (EIF_INTEGER_16) arg3;
	*(EIF_INTEGER_16 *)(Current + O2651[dtype-116]) = (EIF_INTEGER_16) ti2_1;
	ti2_1 = (EIF_INTEGER_16) arg4;
	*(EIF_INTEGER_16 *)(Current + O2652[dtype-116]) = (EIF_INTEGER_16) ti2_1;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_INTEGER_16 *)(Current + O8462[dtype-1160]) == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN)(*(EIF_INTEGER_16 *)(Current + O8463[dtype-1160]) == (EIF_INTEGER_16) ((EIF_INTEGER_32) 0L)))) {
		tr1 = RTOSCF(10077,F1114_10077, (Current));
		F1111_9858(RTCW(tr1), arg3, arg4);
	} else {
		ti2_1 = *(EIF_INTEGER_16 *)(Current + O8462[dtype-1160]);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		if ((EIF_BOOLEAN) (ti4_1 > (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8257[dtype-1158])(Current))) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8257[dtype-1158])(Current);
			ti2_1 = (EIF_INTEGER_16) ti4_1;
			*(EIF_INTEGER_16 *)(Current + O8462[dtype-1160]) = (EIF_INTEGER_16) ti2_1;
		}
		ti2_1 = *(EIF_INTEGER_16 *)(Current + O8463[dtype-1160]);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		if ((EIF_BOOLEAN) (ti4_1 > (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8258[dtype-1158])(Current))) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8258[dtype-1158])(Current);
			ti2_1 = (EIF_INTEGER_16) ti4_1;
			*(EIF_INTEGER_16 *)(Current + O8463[dtype-1160]) = (EIF_INTEGER_16) ti2_1;
		}
		tr1 = RTOSCF(10077,F1114_10077, (Current));
		ti2_1 = *(EIF_INTEGER_16 *)(Current + O8462[dtype-1160]);
		ti4_1 = (EIF_INTEGER_32) ti2_1;
		ti2_1 = *(EIF_INTEGER_16 *)(Current + O8463[dtype-1160]);
		ti4_2 = (EIF_INTEGER_32) ti2_1;
		F1111_9858(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + (EIF_INTEGER_32) (arg3 - arg1)), (EIF_INTEGER_32) (ti4_2 + (EIF_INTEGER_32) (arg4 - arg2)));
	}
	F1161_10611(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.able_to_transport */
EIF_BOOLEAN F1162_10637 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	tb1 = '\0';
	tb2 = '\0';
	if (F1161_10591(Current)) {
		tb2 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L));
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8496[Dtype(Current)-1176])(Current);
	}
	if (!tb1) {
		tb1 = '\0';
		tb2 = '\0';
		if (F1161_10590(Current)) {
			tb2 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 3L));
		}
		if (tb2) {
			tb1 = (EIF_BOOLEAN) !F1161_10593(Current);
		}
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_IMP}.on_mouse_button_event */
void F1162_10638 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc4);
	RTLR(4,tr1);
	RTLR(5,loc5);
	RTLIU(6);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) GDK_BUTTON_RELEASE;
	loc6 = (EIF_BOOLEAN) (EIF_BOOLEAN)(arg1 != ti4_1);
	loc1 = RTOSCF(10077,F1114_10077, (Current));
	loc3 = F1112_10006(RTCW(loc1));
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) !loc3;
	loc2 = F1115_10111(Current);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tb1 = F1112_10006(RTCW(loc1));
		if ((EIF_BOOLEAN) !tb1) {
			if ((EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 1L))) {
				loc4 = Current;
				loc4 = RTRV(eif_new_type(1131, 0x00), loc4);
				tb1 = '\0';
				tb2 = '\0';
				if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_PRESS)) {
					tb2 = (EIF_BOOLEAN)(loc4 != NULL);
				}
				if (tb2) {
					tb2 = '\01';
					if (!(FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8496[dtype-1176])(Current)) {
						tb2 = F1162_10637(Current, arg4);
					}
					tb1 = tb2;
				}
				if (tb1) {
					F1132_10358(RTCW(loc4), arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
				}
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc4 != NULL)) {
					tb1 = (EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_RELEASE);
				}
				if (tb1) {
					F1132_10369(RTCW(loc4), arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
				}
			} else {
				tb1 = '\01';
				tb2 = '\0';
				if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_RELEASE)) {
					tb3 = '\0';
					tb4 = '\0';
					if (F1161_10590(Current)) {
						tb4 = (EIF_BOOLEAN)(arg4 == ((EIF_INTEGER_32) 3L));
					}
					if (tb4) {
						tb3 = (EIF_BOOLEAN) !F1161_10593(Current);
					}
					tb2 = tb3;
				}
				if (!tb2) {
					tb1 = F1162_10641(Current, arg4, loc6);
				}
				if (tb1) {
					F1162_10639(Current, arg2, arg3, arg4, loc6, arg5, arg6, arg7, arg8, arg9, (EIF_BOOLEAN) 0);
					tr1 = *(EIF_REFERENCE *)(Current + O8432[dtype-1160]);
					loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == NULL);
				}
			}
		} else {
			loc5 = (EIF_REFERENCE) Current;
			loc4 = loc5;
			loc4 = RTRV(eif_new_type(1131, 0x00), loc4);
			tb1 = '\0';
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				tb1 = (EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_RELEASE);
			}
			if (tb1) {
				F1132_10369(RTCW(loc4), arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
			}
			tb1 = '\0';
			if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GDK_BUTTON_RELEASE)) {
				tr1 = F1112_10007(RTCW(loc1));
				tb1 = (EIF_BOOLEAN)(tr1 == loc5);
			}
			if (tb1) {
				F1162_10642(Current, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
			}
		}
		if (loc3) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REAL_64, EIF_REAL_64, EIF_REAL_64, EIF_INTEGER_32, EIF_INTEGER_32)) R8489[dtype-1176])(Current, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
		}
	}
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.start_transport */
void F1162_10639 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_BOOLEAN arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_REAL_64 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_BOOLEAN arg10)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	F1161_10610(Current, arg1, arg2, arg8, arg9);
	loc2 = *(EIF_REFERENCE *)(Current + O8432[Dtype(Current)-1160]);
	F1161_10577(Current);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,6,865,0,0,868,868,868,868,0xFFFF};
			EIF_TYPE typres0;
			typarr0[3] = dftype;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr1 = RTLNTS(typres0.id, 7, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = Current;
		RTAR(tr1,Current);
		((EIF_TYPED_VALUE *)tr1+2)->it_r = loc2;
		RTAR(tr1,loc2);
		((EIF_TYPED_VALUE *)tr1+3)->it_i4 = arg1;
		((EIF_TYPED_VALUE *)tr1+4)->it_i4 = arg2;
		((EIF_TYPED_VALUE *)tr1+5)->it_i4 = arg8;
		((EIF_TYPED_VALUE *)tr1+6)->it_i4 = arg9;
		
		{
			static EIF_TYPE_INDEX typarr0[] = {939,0xFFF9,0,865,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr2= RTLNRF(typres0.id, (EIF_POINTER) __A514_232, (EIF_POINTER) _A514_232, (EIF_POINTER)(0),tr1, 1, 0);
		}
		loc1 = (EIF_REFERENCE) tr2;
	}
	if (F1162_10641(Current, arg3, arg4)) {
		tr1 = RTOSCF(10077,F1114_10077, (Current));
		tr2 = F1162_10640(Current);
		tr3 = RTCCL(loc2);
		F1111_9867(RTCW(tr1), arg1, arg2, arg8, arg9, tr2, tr3, loc1, arg10);
	} else {
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_4_2_0_3_0_0_))(
				*(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_4_2_0_3_0_1_),
				*(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_));
		}
	}
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.pebble_source */
EIF_REFERENCE F1162_10640 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1087_9345(Current);
}

/* {EV_PICK_AND_DROPABLE_IMP}.ready_for_pnd_menu */
EIF_BOOLEAN F1162_10641 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = '\01';
	if (!F1161_10592(Current)) {
		tb2 = F1161_10593(Current);
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 3L));
	}
	if (tb1) {
		Result = (EIF_BOOLEAN) !arg2;
	}
	RTLE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_IMP}.end_transport */
void F1162_10642 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_REAL_64 arg4, EIF_REAL_64 arg5, EIF_REAL_64 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER loc5 = (EIF_POINTER) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,loc6);
	RTLR(3,tr1);
	RTLR(4,loc4);
	RTLR(5,loc2);
	RTLR(6,loc1);
	RTLR(7,loc7);
	RTLR(8,tr2);
	RTLIU(9);
	
	RTGC;
	F1162_10624(Current);
	loc3 = RTOSCF(10077,F1114_10077, (Current));
	F1162_10629(Current);
	F1162_10631(Current);
	F1161_10611(Current, (EIF_BOOLEAN) 0);
	if ((EIF_BOOLEAN) !F1087_9344(Current)) {
		tr1 = *(EIF_REFERENCE *)(Current + O8098[dtype-1114]);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			F1115_10098(Current, loc6);
		} else {
			tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
			loc5 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
			if ((EIF_BOOLEAN)(loc5 != F1_33(Current))) {
				tp1 = F1_33(Current);
				gdk_window_set_cursor((GdkWindow*) loc5, (GdkCursor*) tp1);
			}
		}
	}
	loc4 = *(EIF_REFERENCE *)(Current + O8432[dtype-1160]);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		tr1 = RTCCL(loc4);
		F1112_10001(RTCW(loc3), tr1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = loc4;
		RTAR(tr1,loc4);
		loc2 = (EIF_REFERENCE) tr1;
		tb1 = '\01';
		if (!F1162_10637(Current, arg3)) {
			tb1 = F1162_10641(Current, arg3, (EIF_BOOLEAN) 0);
		}
		if (tb1) {
			loc1 = F1161_10606(Current);
			tb1 = '\0';
			loc7 = loc1;
			if (EIF_TEST(loc7)) {
				tr1 = F968_7961(loc7);
				tr2 = RTCCL(loc4);
				tb2 = F604_4889(RTCW(tr1), tr2);
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = F968_7961(loc7);
				F604_4887(RTCW(tr1), loc2);
				tr1 = F99_2410(RTCW(loc3));
				F604_4887(RTCW(tr1), loc2);
			} else {
				tr1 = F99_2412(RTCW(loc3));
				F604_4887(RTCW(tr1), loc2);
			}
		} else {
			tr1 = F99_2412(RTCW(loc3));
			F604_4887(RTCW(tr1), loc2);
		}
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O2302[dtype-88]) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + O2302[dtype-88]);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFFF9,1,865,830,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				tr2 = RTLNTS(typres0.id, 2, 0);
			}
			((EIF_TYPED_VALUE *)tr2+1)->it_r = loc1;
			RTAR(tr2,loc1);
			(RTNA((RTCW(tr1), tr2)));
		}
	}
	F1162_10632(Current);
	F1162_10643(Current, arg3);
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.post_drop_steps */
void F1162_10643 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(10077,F1114_10077, (Current));
	F1111_9858(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	F1161_10577(Current);
	RTLE;
}

/* {EV_PICK_AND_DROPABLE_IMP}.real_pointed_target */
EIF_REFERENCE F1162_10644 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc4);
	RTLR(4,tr2);
	RTLR(5,Result);
	RTLR(6,loc5);
	RTLR(7,loc6);
	RTLIU(8);
	
	RTGC;
	loc7 = RTOSCF(10077,F1114_10077, (Current));
	tb1 = *(EIF_BOOLEAN *)(RTCW(loc7)+ _CHROFF_49_8_);
	if (tb1) {
	} else {
		F1112_10013(RTCW(loc7));
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_48_);
	loc1 = eif_pointer_item(RTCW(tr1),1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_48_);
	loc2 = eif_integer_32_item(RTCW(tr1),2);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_48_);
	loc3 = eif_integer_32_item(RTCW(tr1),3);
	if ((EIF_BOOLEAN)(loc1 != F1_33(Current))) {
		loc4 = F1112_10024(RTCW(loc7), loc1);
		loc4 = RTRV(eif_new_type(1161, 0x00), loc4);
		tb1 = '\0';
		tb2 = '\0';
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tp1 = *(EIF_POINTER *)(RTCW(loc4) + O8051[Dtype(loc4)-1113]);
			tb2 = (EIF_BOOLEAN) EIF_TEST(gtk_widget_is_sensitive((GtkWidget*) tp1));
		}
		if (tb2) {
			tb2 = F1087_9344(RTCW(loc4));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_27_);
			tr2 = F1087_9345(RTCW(loc4));
			ti4_1 = F827_6017(RTCW(tr2));
			tb1 = F580_4626(RTCW(tr1), ti4_1);
			if (tb1) {
				Result = *(EIF_REFERENCE *)(RTCW(loc4) + O7519[Dtype(loc4)-1086]);
			}
			loc5 = loc4;
			loc5 = RTRV(eif_new_type(196, 0x00), loc5);
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				tp1 = *(EIF_POINTER *)(RTCW(loc4) + O8051[Dtype(loc4)-1113]);
				tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
				tp2 = inline_F17_357();
				tp3 = F1_33(Current);
				loc1 = (EIF_POINTER) gdk_window_get_device_position((GdkWindow*) tp1, (GdkDevice *) tp2, (gint*) (EIF_INTEGER_32 *) &(loc2), (gint*) (EIF_INTEGER_32 *) &(loc3), (GdkModifierType*) tp3);
				loc6 = F1215_11557(RTCW(loc5), loc2, loc3);
				tb1 = '\0';
				if ((EIF_BOOLEAN)(loc6 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc7) + _REFACS_27_);
					tr2 = F1087_9345(RTCW(loc6));
					ti4_1 = F827_6017(RTCW(tr2));
					tb2 = F580_4626(RTCW(tr1), ti4_1);
					tb1 = tb2;
				}
				if (tb1) {
					Result = *(EIF_REFERENCE *)(RTCW(loc6) + O7519[Dtype(loc6)-1086]);
					RTLE;
					return (EIF_REFERENCE) Result;
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {EV_PICK_AND_DROPABLE_IMP}.inline-agent#1 of start_transport */
void F1162_13043 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	tr1 = RTCCL(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O8432[dtype-1160]) = (EIF_REFERENCE) tr1;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		F1162_10623(Current);
		F1162_10634(Current, arg2, arg3, arg4, arg5);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O2306[dtype-88]) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + O2306[dtype-88]);
			tr2 = RTCCL(arg1);
			tb2 = F604_4889(RTCW(tr1), tr2);
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + O8436[dtype-1160]);
			loc1 = tr1;
			if (EIF_TEST(loc1)) {
				F1115_10098(Current, loc1);
			} else {
				tr1 = RTOSCF(2648,F117_2648, (Current));
				F1115_10098(Current, tr1);
			}
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + O8437[dtype-1160]);
			loc2 = tr1;
			if (EIF_TEST(loc2)) {
				F1115_10098(Current, loc2);
			} else {
				tr1 = RTOSCF(2649,F117_2649, (Current));
				F1115_10098(Current, tr1);
			}
		}
	}
	tr1 = F1162_10640(Current);
	F1162_10628(Current, arg4, arg5, tr1);
	RTLE;
}

void EIF_Minit514 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
