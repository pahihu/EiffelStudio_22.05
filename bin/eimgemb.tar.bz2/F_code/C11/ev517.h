
#ifndef _C11_ev517_
#define _C11_ev517_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1165_10729(EIF_REFERENCE);
extern void EIF_Minit517(void);
extern char *(*R8563[])();

#ifdef __cplusplus
}
#endif

#endif
