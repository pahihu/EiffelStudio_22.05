
#ifndef _C11_ev519_
#define _C11_ev519_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1167_10785(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit519(void);
extern void F1118_10208(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1118_10194(EIF_REFERENCE);
extern void F1118_10206(EIF_REFERENCE);
extern EIF_BOOLEAN F1118_10197(EIF_REFERENCE);
extern EIF_REFERENCE F1118_10192(EIF_REFERENCE);
extern void F1118_10204(EIF_REFERENCE);
extern char *(*R8533[])();

#ifdef __cplusplus
}
#endif

#endif
