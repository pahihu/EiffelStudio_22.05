/*
 * Code for class EV_CELL_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev539.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_CELL_IMP}.make */
void F1187_11001 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]) == F1_33(Current))) {
		tp1 = (EIF_POINTER) gtk_event_box_new();
		F1114_10052(Current, tp1);
	}
	F1166_10756(Current);
	RTLE;
}

/* {EV_CELL_IMP}.item */
EIF_REFERENCE F1187_11003 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O8741[Dtype(Current)-1186]);
}


/* {EV_CELL_IMP}.replace */
void F1187_11005 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1166_10761(Current, arg1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O8741[Dtype(Current)-1186]) = (EIF_REFERENCE) arg1;
	RTLE;
}

void EIF_Minit539 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
