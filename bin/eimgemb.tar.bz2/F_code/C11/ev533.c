/*
 * Code for class EV_VIEWPORT_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev533.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_VIEWPORT_I}.set_offset */
void F1181_10910 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1190_11058(Current, arg1);
	F1190_11059(Current, arg2);
	RTLE;
}

/* {EV_VIEWPORT_I}.set_item_width */
void F1181_10911 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F1005_8385(RTCV(F1165_10729(Current)));
	ti4_1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 1L));
	F1189_11033(Current, arg1, ti4_1);
	RTLE;
}

/* {EV_VIEWPORT_I}.set_item_height */
void F1181_10912 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F1005_8384(RTCV(F1165_10729(Current)));
	ti4_1 = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 1L));
	F1189_11033(Current, ti4_1, arg1);
	RTLE;
}

void EIF_Minit533 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
