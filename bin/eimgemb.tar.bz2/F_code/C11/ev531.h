
#ifndef _C11_ev531_
#define _C11_ev531_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1179_10897(EIF_REFERENCE, EIF_REFERENCE);
extern void F1179_10898(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit531(void);
extern void F1187_11005(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R8533[])();
extern long O8741[];

#ifdef __cplusplus
}
#endif

#endif
