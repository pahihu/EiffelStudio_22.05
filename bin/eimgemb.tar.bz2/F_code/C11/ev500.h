
#ifndef _C11_ev500_
#define _C11_ev500_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1148_10459(EIF_REFERENCE);
extern void F1148_10460(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_POINTER F1148_10462(EIF_REFERENCE);
extern void EIF_Minit500(void);
extern void F982_8029(EIF_REFERENCE);
extern char *(*R8377[])();
extern char *(*R8378[])();
extern long O8379[];

#ifdef __cplusplus
}
#endif

#endif
