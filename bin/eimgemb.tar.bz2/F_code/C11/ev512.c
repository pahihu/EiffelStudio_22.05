/*
 * Code for class EV_FILE_OPEN_DIALOG_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev512.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F81_1929
static EIF_POINTER inline_F81_1929 (EIF_POINTER arg1)
{
	return (EIF_POINTER) (gtk_file_chooser_get_filenames ((GtkFileChooser*) arg1))
	;
}
#define INLINE_F81_1929
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FILE_OPEN_DIALOG_IMP}.make */
void F1160_10555 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1158_10537(Current);
	tr1 = RTMS_EX_H("Open",4,1332766062);
	F1154_10507(Current, tr1);
	RTLE;
}

/* {EV_FILE_OPEN_DIALOG_IMP}.full_file_path */
EIF_REFERENCE F1160_10557 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = F1160_10559(Current);
	tb1 = F409_4259(RTCW(loc1));
	if ((EIF_BOOLEAN) !tb1) {
		loc2 = F585_4757(RTCW(loc1));
	}
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		loc2 = F1158_10538(Current);
	}
	
	RTLE;
	return (EIF_REFERENCE) loc2;
}

/* {EV_FILE_OPEN_DIALOG_IMP}.file_paths */
EIF_REFERENCE F1160_10559 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc3);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {584,833,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 584, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F585_4749(RTCW(Result), ((EIF_INTEGER_32) 1L));
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		tr1 = F1157_10535(Current);
		tb2 = F952_7772(loc3, tr1);
		tb1 = tb2;
	}
	if (tb1) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_11_6_0_1_0_0_);
		loc1 = inline_F81_1929(tp1);
	}
	if ((EIF_BOOLEAN)(loc1 != F1_33(Current))) {
		for (;;) {
			if ((EIF_BOOLEAN)(loc1 == F1_33(Current))) break;
			loc2 = (EIF_POINTER) (((GSList *)loc1)->data);
			tr1 = RTLNS(eif_new_type(833, 0x00).id, 833, _OBJSIZ_2_1_0_0_0_0_0_0_);
			F834_6133(RTCW(tr1), loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4038[Dtype(RTCW(Result))-564])(Result, tr1);
			g_free((gpointer) loc2);
			tp1 = (EIF_POINTER) (((GSList *)loc1)->next);
			loc1 = (EIF_POINTER) tp1;
		}
		g_slist_free((GSList*) loc1);
	}
	RTLE;
	return Result;
}

/* {EV_FILE_OPEN_DIALOG_IMP}.file_chooser_action */
EIF_INTEGER_32 F1160_10562 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) GTK_FILE_CHOOSER_ACTION_OPEN;
}

void EIF_Minit512 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
