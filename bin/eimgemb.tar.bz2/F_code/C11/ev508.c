/*
 * Code for class EV_FILE_SAVE_DIALOG_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev508.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_FILE_SAVE_DIALOG_I}.internal_accept */
EIF_REFERENCE F1156_10529 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) RTOSCF(1109,F66_1109, (Current));
}

void EIF_Minit508 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
