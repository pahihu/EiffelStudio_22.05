/*
 * Code for class EV_SCROLLABLE_AREA_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev542.h"
#include <string.h>
#include <ev_gtk.h>
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F19_422
static EIF_NATURAL_8 inline_F19_422 (void)
{
	return GTK_ORIENTATION_HORIZONTAL
	;
}
#define INLINE_F19_422
#endif
#ifndef INLINE_F82_1959
static EIF_POINTER inline_F82_1959 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F82_1959
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SCROLLABLE_AREA_IMP}.make */
void F1190_11050 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_NATURAL_8 tu1_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tp1 = F1_33(Current);
	tp2 = F1_33(Current);
	tp1 = (EIF_POINTER) gtk_scrolled_window_new((GtkAdjustment*) tp1, (GtkAdjustment*) tp2);
	*(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_4_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_4_);
	ti4_1 = (EIF_INTEGER_32) GTK_SHADOW_NONE;
	gtk_scrolled_window_set_shadow_type((GtkScrolledWindow*) tp1, (GtkShadowType) ti4_1);
	F1114_10052(Current, *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_4_));
	ti4_1 = (EIF_INTEGER_32) GTK_POLICY_AUTOMATIC;
	ti4_2 = (EIF_INTEGER_32) GTK_POLICY_AUTOMATIC;
	F1190_11078(Current, ti4_1, ti4_2);
	tp1 = F1_33(Current);
	tp2 = F1_33(Current);
	tp1 = (EIF_POINTER) gtk_viewport_new((GtkAdjustment*) tp1, (GtkAdjustment*) tp2);
	*(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_1_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_1_);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_4_);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_1_);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) tp2);
	F1190_11060(Current, ((EIF_INTEGER_32) 10L));
	F1190_11061(Current, ((EIF_INTEGER_32) 10L));
	tp1 = (EIF_POINTER) gtk_fixed_new();
	*(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_3_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_3_);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_1_);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_3_);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) tp2);
	tu1_1 = inline_F19_422();
	tp1 = inline_F82_1959(tu1_1, ((EIF_INTEGER_32) 0L));
	*(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_2_) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_2_);
	gtk_box_set_homogeneous((GtkBox*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_2_);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_3_);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_2_);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) tp2);
	tr1 = RTLNS(eif_new_type(80, 0x00).id, 80, _OBJSIZ_0_0_0_0_0_0_0_0_);
	F81_1659(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_4_), ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 1L));
	F1189_11023(Current);
	RTLE;
}

/* {EV_SCROLLABLE_AREA_IMP}.needs_event_box */
EIF_BOOLEAN F1190_11051 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_TRUE;
}

/* {EV_SCROLLABLE_AREA_IMP}.horizontal_step */
EIF_INTEGER_32 F1190_11052 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tp1 = F1190_11074(Current);
	tr4_1 = (EIF_REAL_32) gtk_adjustment_get_step_increment((GtkAdjustment*) tp1);
	tr1 = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = tr4_1;
	Result = F888_7054(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_SCROLLABLE_AREA_IMP}.vertical_step */
EIF_INTEGER_32 F1190_11053 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REAL_32 tr4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tp1 = F1190_11075(Current);
	tr4_1 = (EIF_REAL_32) gtk_adjustment_get_step_increment((GtkAdjustment*) tp1);
	tr1 = RTLNS(eif_new_type(889, 0x00).id, 889, _OBJSIZ_0_0_0_0_1_0_0_0_);
	*(EIF_REAL_32 *)tr1 = tr4_1;
	Result = F888_7054(RTCW(tr1));
	RTLE;
	return Result;
}

/* {EV_SCROLLABLE_AREA_IMP}.set_x_offset */
void F1190_11058 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1190_11074(Current);
	F1190_11066(Current, tp1, arg1);
	RTLE;
}

/* {EV_SCROLLABLE_AREA_IMP}.set_y_offset */
void F1190_11059 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1190_11075(Current);
	F1190_11066(Current, tp1, arg1);
	RTLE;
}

/* {EV_SCROLLABLE_AREA_IMP}.set_horizontal_step */
void F1190_11060 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REAL_32 tr4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(F1190_11052(Current) != arg1)) {
		tp1 = F1190_11074(Current);
		tr4_1 = (EIF_REAL_32) (arg1);
		gtk_adjustment_set_step_increment((GtkAdjustment*) tp1, (gdouble) tr4_1);
	}
	RTLE;
}

/* {EV_SCROLLABLE_AREA_IMP}.set_vertical_step */
void F1190_11061 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REAL_32 tr4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(F1190_11053(Current) != arg1)) {
		tp1 = F1190_11075(Current);
		tr4_1 = (EIF_REAL_32) (arg1);
		gtk_adjustment_set_step_increment((GtkAdjustment*) tp1, (gdouble) tr4_1);
	}
	RTLE;
}

/* {EV_SCROLLABLE_AREA_IMP}.show_horizontal_scroll_bar */
void F1190_11062 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) GTK_POLICY_ALWAYS;
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_14_10_9_);
	F1190_11078(Current, ti4_1, ti4_2);
	RTLE;
}

/* {EV_SCROLLABLE_AREA_IMP}.show_vertical_scroll_bar */
void F1190_11064 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_14_10_8_);
	ti4_2 = (EIF_INTEGER_32) GTK_POLICY_ALWAYS;
	F1190_11078(Current, ti4_1, ti4_2);
	RTLE;
}

/* {EV_SCROLLABLE_AREA_IMP}.hide_vertical_scroll_bar */
void F1190_11065 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_14_10_8_);
	ti4_2 = (EIF_INTEGER_32) GTK_POLICY_NEVER;
	F1190_11078(Current, ti4_1, ti4_2);
	RTLE;
}

/* {EV_SCROLLABLE_AREA_IMP}.internal_set_value_from_adjustment */
void F1190_11066 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REAL_32 tr4_1;
	
	
	RTGC;
	tr4_1 = (EIF_REAL_32) (arg2);
	if ((EIF_BOOLEAN) eif_is_greater_real_32 ((EIF_REAL_32) gtk_adjustment_get_lower((GtkAdjustment*) arg1), tr4_1)) {
		tr4_1 = (EIF_REAL_32) (arg2);
		gtk_adjustment_set_lower((GtkAdjustment*) arg1, (gdouble) tr4_1);
	} else {
		tr4_1 = (EIF_REAL_32) (arg2);
		if ((EIF_BOOLEAN) eif_is_less_real_32 ((EIF_REAL_32) gtk_adjustment_get_upper((GtkAdjustment*) arg1), tr4_1)) {
			tr4_1 = (EIF_REAL_32) (arg2);
			gtk_adjustment_set_upper((GtkAdjustment*) arg1, (gdouble) tr4_1);
		}
	}
	tr4_1 = (EIF_REAL_32) (arg2);
	gtk_adjustment_set_value((GtkAdjustment*) arg1, (gfloat) tr4_1);
}

/* {EV_SCROLLABLE_AREA_IMP}.fixed_width */
EIF_INTEGER_32 F1190_11068 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) sizeof(GtkAllocation);
	tp1 = malloc((size_t)ti4_1);
	loc1 = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_3_);
	gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc1);
	ti4_1 = (EIF_INTEGER_32) (((GtkAllocation *)loc1)->width);
	Result = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 0L));
	free(loc1);
	RTLE;
	return Result;
}

/* {EV_SCROLLABLE_AREA_IMP}.fixed_height */
EIF_INTEGER_32 F1190_11069 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) sizeof(GtkAllocation);
	tp1 = malloc((size_t)ti4_1);
	loc1 = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_3_);
	gtk_widget_get_allocation((GtkWidget*) tp1, (GtkAllocation*) loc1);
	ti4_1 = (EIF_INTEGER_32) (((GtkAllocation *)loc1)->height);
	Result = eif_max_int32 (ti4_1,((EIF_INTEGER_32) 0L));
	free(loc1);
	RTLE;
	return Result;
}

/* {EV_SCROLLABLE_AREA_IMP}.on_size_allocate */
void F1190_11071 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	F1189_11034(Current, arg1, arg2, arg3, arg4);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_48_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_3_);
		loc2 = tr1;
		loc2 = RTRV(eif_new_type(1163, 0x00),loc2);
		if (EIF_TEST(loc2)) {
			
			tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_2_);
			if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((tp1)))) {
				tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_2_);
				ti4_1 = F1190_11068(Current);
				ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8257[Dtype(loc2)-1158])(loc2);
				ti4_1 = eif_max_int32 ((EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - ti4_2) / ((EIF_INTEGER_32) 2L)),((EIF_INTEGER_32) 0L));
				ti4_2 = F1190_11069(Current);
				ti4_3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8258[Dtype(loc2)-1158])(loc2);
				ti4_2 = eif_max_int32 ((EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 - ti4_3) / ((EIF_INTEGER_32) 2L)),((EIF_INTEGER_32) 0L));
				gtk_window_move((GtkWindow*) tp1, (gint) ti4_1, (gint) ti4_2);
			}
		} else {
			
		}
	}
	RTLE;
}

/* {EV_SCROLLABLE_AREA_IMP}.update_viewport_item_size */
void F1190_11072 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	RTGC;
}

/* {EV_SCROLLABLE_AREA_IMP}.child_has_resized */
void F1190_11073 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_2_);
	if ((EIF_BOOLEAN) EIF_TEST(GTK_IS_WINDOW((tp1)))) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_2_);
		ti4_1 = F1190_11068(Current);
		ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8257[Dtype(RTCW(arg1))-1158])(arg1);
		ti4_1 = eif_max_int32 ((EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - ti4_2) / ((EIF_INTEGER_32) 2L)),((EIF_INTEGER_32) 0L));
		ti4_2 = F1190_11069(Current);
		ti4_3 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8258[Dtype(RTCW(arg1))-1158])(arg1);
		ti4_2 = eif_max_int32 ((EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_2 - ti4_3) / ((EIF_INTEGER_32) 2L)),((EIF_INTEGER_32) 0L));
		gtk_window_move((GtkWindow*) tp1, (gint) ti4_1, (gint) ti4_2);
	}
	RTLE;
}

/* {EV_SCROLLABLE_AREA_IMP}.horizontal_adjustment */
EIF_POINTER F1190_11074 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_4_);
	return (EIF_POINTER) (EIF_POINTER) gtk_scrolled_window_get_hadjustment((GtkScrolledWindow*) tp1);
}

/* {EV_SCROLLABLE_AREA_IMP}.vertical_adjustment */
EIF_POINTER F1190_11075 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_4_);
	return (EIF_POINTER) (EIF_POINTER) gtk_scrolled_window_get_vadjustment((GtkScrolledWindow*) tp1);
}

/* {EV_SCROLLABLE_AREA_IMP}.set_scrolling_policy */
void F1190_11078 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_4_);
	gtk_scrolled_window_set_policy((GtkScrolledWindow*) tp1, (GtkPolicyType) arg1, (GtkPolicyType) arg2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_14_10_8_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_14_10_9_) = (EIF_INTEGER_32) arg2;
	RTLE;
}

/* {EV_SCROLLABLE_AREA_IMP}.gtk_insert_i_th */
void F1190_11079 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (EIF_POINTER) gtk_event_box_new();
	gtk_event_box_set_visible_window((GtkEventBox*) loc1, (gboolean) (EIF_BOOLEAN) 0);
	gtk_widget_show((GtkWidget*) loc1);
	gtk_container_add((GtkContainer*) loc1, (GtkWidget*) arg2);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_49_14_10_10_0_2_);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) loc1);
	RTLE;
}

void EIF_Minit542 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
