/*
 * Code for class EV_STANDARD_DIALOG_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev506.h"
#include <ev_gtk.h>
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_STANDARD_DIALOG_IMP}.make */
void F1154_10503 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLR(4,tr4);
	RTLR(5,tr5);
	RTLIU(6);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	tr1 = RTOSCF(327,F16_327, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,865,831,937,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	tr3 = *(EIF_REFERENCE *)(RTCV(RTOSCF(10077,F1114_10077, (Current))) + _REFACS_42_);
	((EIF_TYPED_VALUE *)tr2+1)->it_r = tr3;
	RTAR(tr2,tr3);
	tp2 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	((EIF_TYPED_VALUE *)tr2+2)->it_p = tp2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {942,0xFFF9,1,865,937,937,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A257_339_3, (EIF_POINTER) _A257_339_3, (EIF_POINTER)(F830_6081),tr2, 1, 1);
	}
	F1114_10056(Current, tp1, tr1, tr5);
	F1115_10079(Current);
	RTLE;
}

/* {EV_STANDARD_DIALOG_IMP}.selected_button */
EIF_REFERENCE F1154_10505 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_7_);
}


/* {EV_STANDARD_DIALOG_IMP}.show_modal_to_window */
void F1154_10506 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
	F1116_10141(Current, arg1);
	if (F1154_10513(Current)) {
		tr1 = F67_1122(Current);
		F603_4886(RTCW(tr1), NULL);
	} else {
		tr1 = F67_1124(Current);
		F603_4886(RTCW(tr1), NULL);
	}
	RTLE;
}

/* {EV_STANDARD_DIALOG_IMP}.set_title */
void F1154_10507 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F818_5410(RTCW(loc1), arg1);
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	gtk_window_set_title((GtkWindow*) tp1, (gchar*) tp2);
	RTLE;
}

/* {EV_STANDARD_DIALOG_IMP}.on_key_event */
void F1154_10508 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_BOOLEAN arg3)
{
	GTCX
	
	
	RTGC;
}

/* {EV_STANDARD_DIALOG_IMP}.user_can_resize */
EIF_BOOLEAN F1154_10509 (EIF_REFERENCE Current)
{
	return (EIF_BOOLEAN) EIF_FALSE;
}

/* {EV_STANDARD_DIALOG_IMP}.blocking_condition */
EIF_BOOLEAN F1154_10510 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	tb1 = '\01';
	if (!F1087_9344(Current)) {
		tb1 = (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) != NULL);
	}
	if (!tb1) {
		tb1 = F1087_9344(RTCV(RTOSCF(10077,F1114_10077, (Current))));
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {EV_STANDARD_DIALOG_IMP}.enable_closeable */
void F1154_10511 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) GDK_FUNC_CLOSE;
	ti4_1 = (EIF_INTEGER_32) GDK_FUNC_MOVE;
	ti4_1 = eif_bit_or(loc1,ti4_1);
	loc1 = (EIF_INTEGER_32) ti4_1;
	ti4_1 = (EIF_INTEGER_32) GDK_FUNC_RESIZE;
	ti4_1 = eif_bit_or(loc1,ti4_1);
	loc1 = (EIF_INTEGER_32) ti4_1;
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
	gdk_window_set_functions((GdkWindow*) tp1, (GdkWMFunction) loc1);
	RTLE;
}

/* {EV_STANDARD_DIALOG_IMP}.call_close_request_actions */
void F1154_10512 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1154_10518(Current);
}

/* {EV_STANDARD_DIALOG_IMP}.user_clicked_ok */
EIF_BOOLEAN F1154_10513 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8405[Dtype(Current)-1158])(Current);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == tr2);
	RTLE;
	return Result;
}

/* {EV_STANDARD_DIALOG_IMP}.on_response */
void F1154_10516 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == (EIF_INTEGER_32) GTK_RESPONSE_OK)) {
		F1158_10545(Current);
	} else {
		F1154_10518(Current);
	}
	RTLE;
}

/* {EV_STANDARD_DIALOG_IMP}.on_ok */
void F1154_10517 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8405[Dtype(Current)-1158])(Current);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	F1116_10138(Current);
	RTLE;
}

/* {EV_STANDARD_DIALOG_IMP}.on_cancel */
void F1154_10518 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(1111,F66_1111, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	F1116_10138(Current);
	RTLE;
}

void EIF_Minit506 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
