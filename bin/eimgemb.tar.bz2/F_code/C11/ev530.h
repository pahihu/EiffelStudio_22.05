
#ifndef _C11_ev530_
#define _C11_ev530_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1178_10895(EIF_REFERENCE);
extern void EIF_Minit530(void);
extern void F1170_10807(EIF_REFERENCE);
extern void F1114_10052(EIF_REFERENCE, EIF_POINTER);

#ifdef __cplusplus
}
#endif

#endif
