/*
 * Code for class EV_WIDGET_LIST_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev519.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WIDGET_LIST_I}.update_for_pick_and_drop */
void F1167_10785 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = F1118_10194(Current);
	F1118_10204(Current);
	for (;;) {
		if (F1118_10197(Current)) break;
		tr1 = *(EIF_REFERENCE *)(RTCV(F1118_10192(Current)) + _REFACS_3_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) R8533[Dtype(RTCW(tr1))-1176])(tr1, arg1);
		F1118_10206(Current);
	}
	F1118_10208(Current, loc1);
	RTLE;
}

void EIF_Minit519 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
