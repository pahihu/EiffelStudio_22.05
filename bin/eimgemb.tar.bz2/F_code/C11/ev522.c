/*
 * Code for class EV_WIDGET_LIST_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev522.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WIDGET_LIST_IMP}.make */
void F1170_10807 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1166_10756(Current);
	F1119_10227(Current);
	RTLE;
}

/* {EV_WIDGET_LIST_IMP}.insert_i_th */
void F1170_10808 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1163, 0x00), loc1);
	RTCT0("v_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tp1 = F1170_10810(Current);
		tp2 = *(EIF_POINTER *)(RTCW(loc1) + O8051[Dtype(loc1)-1113]);
		F1176_10888(Current, tp1, tp2, (EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		F585_4784(RTCW(tr1), arg2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4185[Dtype(RTCW(tr1))-584])(tr1, arg1);
		F1166_10776(Current, loc1);
	}
	RTLE;
}

/* {EV_WIDGET_LIST_IMP}.remove_i_th */
void F1170_10809 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_13_10_1_);
	tr1 = F1119_10228(Current, arg1);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1163, 0x00), loc1);
	
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		F585_4784(RTCW(tr1), arg1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_31_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R4057[Dtype(RTCW(tr1))-564])(tr1);
		F1166_10777(Current, loc1);
		tp1 = F1170_10810(Current);
		tp2 = *(EIF_POINTER *)(RTCW(loc1) + O8051[Dtype(loc1)-1113]);
		F1176_10889(Current, tp1, tp2);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_49_13_10_1_) = (EIF_INTEGER_32) loc2;
	}
	RTLE;
}

/* {EV_WIDGET_LIST_IMP}.list_widget */
EIF_POINTER F1170_10810 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) F1166_10757(Current);
}

void EIF_Minit522 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
