
#ifndef _C11_ev504_
#define _C11_ev504_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1152_10487(EIF_REFERENCE);
extern void F1152_10490(EIF_REFERENCE, EIF_REFERENCE);
extern void F1152_10493(EIF_REFERENCE);
extern void EIF_Minit504(void);
extern void F1087_9360(EIF_REFERENCE, EIF_BOOLEAN);
extern void F818_5410(EIF_REFERENCE, EIF_REFERENCE);
extern void F1087_9359(EIF_REFERENCE, EIF_BOOLEAN);

#ifdef __cplusplus
}
#endif

#endif
