/*
 * Code for class EV_BOX_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev528.h"
#include <ev_gtk.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_BOX_IMP}.border_width */
EIF_INTEGER_32 F1176_10878 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1166_10757(Current);
	Result = (EIF_INTEGER_32) gtk_container_get_border_width((GtkContainer*) tp1);
	RTLE;
	return Result;
}

/* {EV_BOX_IMP}.padding */
EIF_INTEGER_32 F1176_10879 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1166_10757(Current);
	Result = (EIF_INTEGER_32) gtk_box_get_spacing((GtkBox*) tp1);
	RTLE;
	return Result;
}

/* {EV_BOX_IMP}.is_item_expanded */
EIF_BOOLEAN F1176_10880 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc5);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc5 = tr1;
	loc5 = RTRV(eif_new_type(1163, 0x00),loc5);
	if (EIF_TEST(loc5)) {
		tp1 = F1166_10757(Current);
		tp2 = *(EIF_POINTER *)(loc5 + O8051[Dtype(loc5)-1113]);
		gtk_box_query_child_packing((GtkBox*) tp1, (GtkWidget*) tp2, (gboolean*) (EIF_INTEGER_32 *) &(loc2), (gboolean*) (EIF_INTEGER_32 *) &(loc1), (guint*) (EIF_INTEGER_32 *) &(loc3), (GtkPackType*) (EIF_INTEGER_32 *) &(loc4));
	} else {
		
	}
	tr1 = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = loc2;
	tb1 = F867_6381(RTCW(tr1));
	RTLE;
	return (EIF_BOOLEAN) tb1;
}

/* {EV_BOX_IMP}.set_homogeneous */
void F1176_10881 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1166_10757(Current);
	gtk_box_set_homogeneous((GtkBox*) tp1, (gboolean) arg1);
	RTLE;
}

/* {EV_BOX_IMP}.set_border_width */
void F1176_10882 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1166_10757(Current);
	gtk_container_set_border_width((GtkContainer*) tp1, (guint) arg1);
	RTLE;
}

/* {EV_BOX_IMP}.set_padding */
void F1176_10883 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = F1166_10757(Current);
	gtk_box_set_spacing((GtkBox*) tp1, (gint) arg1);
	RTLE;
}

/* {EV_BOX_IMP}.set_child_expandable */
void F1176_10884 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	RTCT0("attached {EV_WIDGET_IMP} child.implementation as wid_imp", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1163, 0x00),loc1);
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = F1166_10757(Current);
	tp2 = *(EIF_POINTER *)(loc1 + O8051[Dtype(loc1)-1113]);
	F1176_10885(Current, tp1, tp2, arg2);
	loc2 = Current;
	loc2 = RTRV(eif_new_type(1176, 0x00),loc2);
	if (EIF_TEST(loc2)) {
		tp1 = *(EIF_POINTER *)(loc1 + O8051[Dtype(loc1)-1113]);
		gtk_widget_set_vexpand((GtkWidget*) tp1, (gboolean) arg2);
	} else {
		tp1 = *(EIF_POINTER *)(loc1 + O8051[Dtype(loc1)-1113]);
		gtk_widget_set_hexpand((GtkWidget*) tp1, (gboolean) arg2);
	}
	RTLE;
}

/* {EV_BOX_IMP}.set_child_expandable_internal */
void F1176_10885 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_BOOLEAN arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	gtk_box_query_child_packing((GtkBox*) arg1, (GtkWidget*) arg2, (gboolean*) (EIF_INTEGER_32 *) &(loc1), (gboolean*) (EIF_INTEGER_32 *) &(loc2), (guint*) (EIF_INTEGER_32 *) &(loc3), (GtkPackType*) (EIF_INTEGER_32 *) &(loc4));
	tr1 = RTLNS(eif_new_type(868, 0x00).id, 868, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_INTEGER_32 *)tr1 = loc2;
	tb1 = F867_6381(RTCW(tr1));
	gtk_box_set_child_packing((GtkBox*) arg1, (GtkWidget*) arg2, (gboolean) arg3, (gboolean) tb1, (guint) loc3, (GtkPackType) loc4);
	RTLE;
}

/* {EV_BOX_IMP}.style_element_name */
EIF_REFERENCE F1176_10886 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Result);
	RTLIU(1);
	
	RTGC;
	Result = RTMS_EX_H("box",3,6451064);
	RTLE;
	return Result;
}

/* {EV_BOX_IMP}.needs_event_box */
EIF_BOOLEAN F1176_10887 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {EV_BOX_IMP}.gtk_insert_i_th */
void F1176_10888 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	gtk_box_pack_start((GtkBox*) arg1, (GtkWidget*) arg2, (gboolean) (EIF_BOOLEAN) 1, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 0L));
	if ((EIF_BOOLEAN) (arg3 < F1119_10229(Current))) {
		gtk_box_reorder_child((GtkBox*) arg1, (GtkWidget*) arg2, (gint) arg3);
	}
	RTLE;
}

/* {EV_BOX_IMP}.gtk_container_remove */
void F1176_10889 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1166_10781(Current, arg1, arg2);
	gtk_widget_set_vexpand((GtkWidget*) arg2, (gboolean) (EIF_BOOLEAN) 1);
	gtk_widget_set_hexpand((GtkWidget*) arg2, (gboolean) (EIF_BOOLEAN) 1);
	RTLE;
}

void EIF_Minit528 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
