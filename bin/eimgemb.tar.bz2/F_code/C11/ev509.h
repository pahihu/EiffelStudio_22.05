
#ifndef _C11_ev509_
#define _C11_ev509_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1157_10535(EIF_REFERENCE);
extern void EIF_Minit509(void);
extern EIF_REFERENCE F66_1108(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,1108)

#ifdef __cplusplus
}
#endif

#endif
