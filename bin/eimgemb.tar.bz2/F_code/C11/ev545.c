/*
 * Code for class EV_TITLED_WINDOW_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev545.h"
#include <ev_gtk.h>
#include "eif_built_in.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F81_1570
static void inline_F81_1570 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	gtk_window_set_icon ((GtkWindow*) arg1, (GdkPixbuf*) arg2)
	;
}
#define INLINE_F81_1570
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_TITLED_WINDOW_IMP}.on_size_allocate */
void F1193_11163 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1191_11120(Current, arg1, arg2, arg3, arg4);
	if (*(EIF_BOOLEAN *)(Current + O8806[dtype-1192])) {
		*(EIF_BOOLEAN *)(Current + O8806[dtype-1192]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_12_) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
			F603_4886(RTCW(tr1), NULL);
		}
	}
	RTLE;
}

/* {EV_TITLED_WINDOW_IMP}.call_window_state_event */
void F1193_11164 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) GDK_WINDOW_STATE_ICONIFIED;
	ti4_1 = eif_bit_and(arg1,ti4_1);
	if ((EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) GDK_WINDOW_STATE_ICONIFIED)) {
		ti4_1 = (EIF_INTEGER_32) GDK_WINDOW_STATE_ICONIFIED;
		ti4_1 = eif_bit_and(arg2,ti4_1);
		if ((EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) GDK_WINDOW_STATE_ICONIFIED)) {
			*(EIF_BOOLEAN *)(Current + O8811[dtype-1192]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			*(EIF_BOOLEAN *)(Current + O8810[dtype-1192]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_13_) != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
				F603_4886(RTCW(tr1), NULL);
			}
		} else {
			ti4_1 = (EIF_INTEGER_32) GDK_WINDOW_STATE_MAXIMIZED;
			ti4_1 = eif_bit_and(arg2,ti4_1);
			if ((EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) GDK_WINDOW_STATE_MAXIMIZED)) {
				*(EIF_BOOLEAN *)(Current + O8810[dtype-1192]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				*(EIF_BOOLEAN *)(Current + O8811[dtype-1192]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_12_) != NULL)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
					F603_4886(RTCW(tr1), NULL);
				}
			} else {
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	} else {
		ti4_1 = (EIF_INTEGER_32) GDK_WINDOW_STATE_MAXIMIZED;
		ti4_1 = eif_bit_and(arg1,ti4_1);
		if ((EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) GDK_WINDOW_STATE_MAXIMIZED)) {
			ti4_1 = (EIF_INTEGER_32) GDK_WINDOW_STATE_MAXIMIZED;
			ti4_1 = eif_bit_and(arg2,ti4_1);
			if ((EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) GDK_WINDOW_STATE_MAXIMIZED)) {
				*(EIF_BOOLEAN *)(Current + O8810[dtype-1192]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				*(EIF_BOOLEAN *)(Current + O8811[dtype-1192]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				*(EIF_BOOLEAN *)(Current + O8806[dtype-1192]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			} else {
				loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			}
		}
	}
	if (loc1) {
		*(EIF_BOOLEAN *)(Current + O8811[dtype-1192]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		*(EIF_BOOLEAN *)(Current + O8810[dtype-1192]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_14_) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
			F603_4886(RTCW(tr1), NULL);
		}
	}
	F1191_11121(Current, arg1, arg2);
	RTLE;
}

/* {EV_TITLED_WINDOW_IMP}.is_minimized */
EIF_BOOLEAN F1193_11170 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O8811[Dtype(Current)-1192]);
}


/* {EV_TITLED_WINDOW_IMP}.is_maximized */
EIF_BOOLEAN F1193_11171 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O8810[Dtype(Current)-1192]);
}


/* {EV_TITLED_WINDOW_IMP}.is_displayed */
EIF_BOOLEAN F1193_11172 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	if (F1115_10109(Current)) {
		Result = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O8811[Dtype(Current)-1192]);
	}
	RTLE;
	return Result;
}

/* {EV_TITLED_WINDOW_IMP}.raise */
void F1193_11173 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1115_10108(Current)) {
		F1191_11097(Current);
	} else {
		if (*(EIF_BOOLEAN *)(Current + O8811[dtype-1192])) {
			F1193_11177(Current);
		}
	}
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
	gdk_window_raise((GdkWindow*) tp1);
	RTLE;
}

/* {EV_TITLED_WINDOW_IMP}.restore */
void F1193_11177 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O8810[dtype-1192])) {
		*(EIF_BOOLEAN *)(Current + O8810[dtype-1192]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		gtk_window_unmaximize((GtkWindow*) tp1);
	} else {
		if (*(EIF_BOOLEAN *)(Current + O8811[dtype-1192])) {
			*(EIF_BOOLEAN *)(Current + O8811[dtype-1192]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
			gtk_window_deiconify((GtkWindow*) tp1);
		}
	}
	RTLE;
}

/* {EV_TITLED_WINDOW_IMP}.set_icon_pixmap */
void F1193_11179 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = (EIF_REFERENCE) eif_builtin_ANY_twin__o (arg1);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1259, 0x00), loc1);
	RTCT0("icon_implementation_exists", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_25_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O8807[dtype-1192]) = (EIF_REFERENCE) tr1;
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	tp2 = F1260_12469(RTCW(loc1));
	inline_F81_1570(tp1, tp2);
	RTLE;
}

/* {EV_TITLED_WINDOW_IMP}.default_wm_decorations */
EIF_INTEGER_32 F1193_11180 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) GDK_DECOR_ALL;
}

void EIF_Minit545 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
