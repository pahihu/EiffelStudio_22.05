
#ifndef _C11_ev529_
#define _C11_ev529_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1177_10892(EIF_REFERENCE);
extern void EIF_Minit529(void);
extern void F1170_10807(EIF_REFERENCE);
extern void F1114_10052(EIF_REFERENCE, EIF_POINTER);

#ifdef __cplusplus
}
#endif

#endif
