
#ifndef _C11_ev535_
#define _C11_ev535_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1183_10931(EIF_REFERENCE);
extern EIF_BOOLEAN F1183_10932(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1183_10935(EIF_REFERENCE);
extern void F1183_10948(EIF_REFERENCE);
extern void F1183_10949(EIF_REFERENCE);
extern void F1183_10958(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit535(void);
extern void F982_8029(EIF_REFERENCE);
extern void F1167_10785(EIF_REFERENCE, EIF_BOOLEAN);
extern void F627_4958(EIF_REFERENCE);
extern void F260_4030(EIF_REFERENCE);
extern EIF_REFERENCE F1101_9545(EIF_REFERENCE);
extern void F1111_9827(EIF_REFERENCE, EIF_REFERENCE);
extern void F1179_10898(EIF_REFERENCE, EIF_BOOLEAN);
extern long O8741[];
extern long O8704[];
extern long O8672[];
extern long O8673[];
extern long O8679[];
extern long O7519[];

#ifdef __cplusplus
}
#endif

#endif
