/*
 * Code for class EV_WINDOW_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev535.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WINDOW_I}.user_can_resize */
EIF_BOOLEAN F1183_10931 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O8679[Dtype(Current)-1182]);
}


/* {EV_WINDOW_I}.has */
EIF_BOOLEAN F1183_10932 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8741[dtype-1186]) == arg1) || (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8673[dtype-1182]) == arg1)) || (EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8672[dtype-1182]) == arg1));
	}
	RTLE;
	return (EIF_BOOLEAN) 0;
}

/* {EV_WINDOW_I}.accelerator_list */
EIF_REFERENCE F1183_10935 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O8704[dtype-1182]) == NULL)) {
		tr1 = RTLNSMART(eif_new_type(626, 0).id);
		F627_4958(RTCW(tr1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O8704[dtype-1182]) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + O8704[dtype-1182]);
		F260_4030(RTCW(tr1));
	}
	RTLE;
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + O8704[dtype-1182]);
}

/* {EV_WINDOW_I}.lock_update */
void F1183_10948 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F982_8029(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	tr1 = F1101_9545(RTCW(tr1));
	F1111_9827(RTCW(tr1), *(EIF_REFERENCE *)(Current + O7519[Dtype(Current)-1086]));
	RTLE;
}

/* {EV_WINDOW_I}.unlock_update */
void F1183_10949 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(989, 0x00).id, 989, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F982_8029(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	tr1 = F1101_9545(RTCW(tr1));
	F1111_9827(RTCW(tr1), NULL);
	RTLE;
}

/* {EV_WINDOW_I}.update_for_pick_and_drop */
void F1183_10958 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1179_10898(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + O8672[dtype-1182]);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	F1167_10785(RTCW(tr1), arg1);
	tr1 = *(EIF_REFERENCE *)(Current + O8673[dtype-1182]);
	tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	F1167_10785(RTCW(tr1), arg1);
	RTLE;
}

void EIF_Minit535 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
