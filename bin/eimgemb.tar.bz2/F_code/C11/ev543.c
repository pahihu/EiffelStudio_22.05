/*
 * Code for class EV_WINDOW_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev543.h"
#include <string.h>
#include <ev_gtk.h>
#include <stdlib.h>
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F12_275
static EIF_POINTER inline_F12_275 (void)
{
	static char *v = "gtk-menu-bar-accel";
return (EIF_POINTER) v;
	;
}
#define INLINE_F12_275
#endif
#ifndef INLINE_F81_1828
static void inline_F81_1828 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3)
{
	g_object_set ((gpointer) arg1, (gchar*) arg2, (gpointer) arg3, NULL)
	;
}
#define INLINE_F81_1828
#endif
#ifndef INLINE_F19_423
static EIF_NATURAL_8 inline_F19_423 (void)
{
	return GTK_ORIENTATION_VERTICAL
	;
}
#define INLINE_F19_423
#endif
#ifndef INLINE_F82_1959
static EIF_POINTER inline_F82_1959 (EIF_NATURAL_8 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (gtk_box_new ((GtkOrientation)arg1, (gint)arg2))
	;
}
#define INLINE_F82_1959
#endif
#ifndef INLINE_F19_422
static EIF_NATURAL_8 inline_F19_422 (void)
{
	return GTK_ORIENTATION_HORIZONTAL
	;
}
#define INLINE_F19_422
#endif
#ifndef INLINE_F81_1551
static void inline_F81_1551 (EIF_POINTER arg1, EIF_BOOLEAN arg2)
{
	gtk_window_set_accept_focus((GtkWindow*)arg1, (gboolean) arg2)
	;
}
#define INLINE_F81_1551
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WINDOW_IMP}.new_gtk_window */
EIF_POINTER F1191_11082 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) GTK_WINDOW_TOPLEVEL;
	Result = (EIF_POINTER) gtk_window_new((GtkWindowType) ti4_1);
	return Result;
}

/* {EV_WINDOW_IMP}.make */
void F1191_11083 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_REFERENCE tr4 = NULL;
	EIF_REFERENCE tr5 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,tr4);
	RTLR(7,tr5);
	RTLIU(8);
	
	RTGC;
	F1087_9359(Current, (EIF_BOOLEAN) 0);
	loc1 = RTOSCF(10077,F1114_10077, (Current));
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8764[dtype-1190])(Current);
	F1114_10052(Current, tp1);
	loc3 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	{
		static EIF_TYPE_INDEX typarr0[] = {577,990,868,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F578_4618(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O8700[dtype-1182]) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1032, 0).id);
	F982_8029(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O8672[dtype-1182]) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1032, 0).id);
	F982_8029(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O8673[dtype-1182]) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current + O8800[dtype-1190]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 32000L);
	*(EIF_INTEGER_32 *)(Current + O8799[dtype-1190]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 32000L);
	loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_42_);
	F1191_11119(Current);
	tr1 = RTOSCF(306,F16_306, (Current));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,865,831,868,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = loc2;
	RTAR(tr2,loc2);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O5187[dtype-826]);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = ti4_1;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {939,0xFFF9,1,865,937,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr5= RTLNRF(typres0.id, (EIF_POINTER) __A257_334_3, (EIF_POINTER) _A257_334_3, (EIF_POINTER)(F830_6076),tr2, 1, 1);
	}
	F1114_10057(Current, loc3, tr1, tr5);
	gtk_window_set_default_size((GtkWindow*) loc3, (gint) ((EIF_INTEGER_32) 1L), (gint) ((EIF_INTEGER_32) 1L));
	F1187_11001(Current);
	tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) loc3);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8128[dtype-1116])(Current);
	gdk_window_set_decorations((GdkWindow*) tp1, (GdkWMDecoration) ti4_1);
	*(EIF_BOOLEAN *)(Current + O8703[dtype-1182]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O8125[dtype-1115]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O8679[dtype-1182]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	F1087_9359(Current, (EIF_BOOLEAN) 1);
	RTLE;
}

/* {EV_WINDOW_IMP}.has_focus */
EIF_BOOLEAN F1191_11084 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current + O8771[Dtype(Current)-1190]);
}

/* {EV_WINDOW_IMP}.maximum_width */
EIF_INTEGER_32 F1191_11085 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O8800[Dtype(Current)-1190]);
}


/* {EV_WINDOW_IMP}.maximum_height */
EIF_INTEGER_32 F1191_11086 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O8799[Dtype(Current)-1190]);
}


/* {EV_WINDOW_IMP}.title */
EIF_REFERENCE F1191_11087 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	loc1 = (EIF_POINTER) gtk_window_get_title((GtkWindow*) tp1);
	tb1 = !loc1;
	if ((EIF_BOOLEAN) !tb1) {
		loc2 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
		F818_5412(RTCW(loc2), loc1);
		Result = F818_5408(RTCW(loc2));
		tr1 = RTMS_EX_H("\011",1,9);
		tb1 = F945_7497(RTCW(Result), tr1);
		if (tb1) {
			Result = RTLNS(eif_new_type(953, 0x00).id, 953, _OBJSIZ_1_1_0_3_0_0_0_0_);
			F945_7452(RTCW(Result));
			RTLE;
			return (EIF_REFERENCE) Result;
		}
	} else {
		Result = RTLNS(eif_new_type(953, 0x00).id, 953, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F945_7452(RTCW(Result));
		RTLE;
		return (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_WINDOW_IMP}.add_transient_child */
void F1191_11089 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg1) + O8051[Dtype(arg1)-1113]);
	tp2 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	gtk_window_set_transient_for((GtkWindow*) tp1, (GtkWindow*) tp2);
	RTLE;
}

/* {EV_WINDOW_IMP}.remove_transient_child */
void F1191_11090 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg1) + O8051[Dtype(arg1)-1113]);
	tp2 = F1_33(Current);
	gtk_window_set_transient_for((GtkWindow*) tp1, (GtkWindow*) tp2);
	RTLE;
}

/* {EV_WINDOW_IMP}.internal_enable_border */
void F1191_11092 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8128[dtype-1116])(Current);
	ti4_2 = (EIF_INTEGER_32) GDK_DECOR_BORDER;
	loc1 = eif_bit_or(ti4_1,ti4_2);
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	tp1 = (EIF_POINTER) gtk_widget_get_window((GtkWidget*) tp1);
	gdk_window_set_decorations((GdkWindow*) tp1, (GdkWMDecoration) loc1);
	RTLE;
}

/* {EV_WINDOW_IMP}.disable_user_resize */
void F1191_11094 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O8767[dtype-1190]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current + O8679[dtype-1182]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8513[dtype-1176])(Current)) {
		F1116_10150(Current);
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.allow_resize */
void F1191_11096 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = (EIF_POINTER) calloc (sizeof(GdkGeometry), 1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O8800[dtype-1190]);
	(((GdkGeometry *)loc1)->max_width = (gint)(ti4_1));
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O8799[dtype-1190]);
	(((GdkGeometry *)loc1)->max_height = (gint)(ti4_1));
	ti4_1 = F1115_10085(Current);
	(((GdkGeometry *)loc1)->min_width = (gint)(ti4_1));
	ti4_1 = F1115_10086(Current);
	(((GdkGeometry *)loc1)->min_height = (gint)(ti4_1));
	tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
	tp2 = F1_33(Current);
	ti4_1 = (EIF_INTEGER_32) GDK_HINT_MAX_SIZE;
	ti4_2 = (EIF_INTEGER_32) GDK_HINT_MIN_SIZE;
	ti4_1 = eif_bit_or(ti4_1,ti4_2);
	gtk_window_set_geometry_hints((GtkWindow*) tp1, (GtkWidget*) tp2, (GdkGeometry*) loc1, (GdkWindowHints) ti4_1);
	free(loc1);
	F1191_11092(Current);
	RTLE;
}

/* {EV_WINDOW_IMP}.show */
void F1191_11097 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1115_10108(Current)) {
		*(EIF_BOOLEAN *)(Current + O8768[dtype-1190]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		if (*(EIF_BOOLEAN *)(Current + O8767[dtype-1190])) {
			if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O8679[dtype-1182])) {
				F1116_10150(Current);
			} else {
				F1191_11096(Current);
			}
		}
		F1116_10137(Current);
	}
	if ((EIF_BOOLEAN)(F1116_10117(Current) != NULL)) {
		F1116_10116(Current, NULL);
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.hide */
void F1191_11100 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if (F1115_10108(Current)) {
		*(EIF_BOOLEAN *)(Current + O8769[dtype-1190]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		F1162_10624(Current);
		F1116_10138(Current);
		if (*(EIF_BOOLEAN *)(Current + O8767[dtype-1190])) {
			F1191_11096(Current);
		}
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.set_title */
void F1191_11103 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = F945_7511(RTCW(arg1));
	tb1 = F410_4259(RTCW(loc1));
	if (tb1) {
		loc1 = F945_7511(RTMS_EX_H("\011",1,9));
	}
	loc2 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F818_5410(RTCW(loc2), loc1);
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	tp2 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_0_1_0_1_0_0_);
	gtk_window_set_title((GtkWindow*) tp1, (gchar*) tp2);
	RTLE;
}

/* {EV_WINDOW_IMP}.connect_accelerator */
RTEOMS(11105,4);
void F1191_11106 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = RTRV(eif_new_type(1103, 0x00), loc1);
	RTCT0("acc_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = *(EIF_REFERENCE *)(Current + O8700[Dtype(Current)-1182]);
	ti4_1 = F1103_9584(RTCW(loc1));
	F578_4664(RTCW(tr1), arg1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 36L))) {
		loc3 = (EIF_REFERENCE) RTOMS(11105,0);
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 37L))) {
			loc3 = (EIF_REFERENCE) RTOMS(11105,1);
		} else {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_0_0_0_0_);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 38L))) {
				loc3 = (EIF_REFERENCE) RTOMS(11105,2);
			}
		}
	}
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		loc2 = RTLNS(eif_new_type(817, 0x00).id, 817, _OBJSIZ_0_1_0_1_0_1_0_0_);
		tr1 = F950_7714(RTOMS(11105,3), loc3);
		F818_5410(RTCW(loc2), tr1);
		tp1 = RTOSCF(6043,F828_6043, (RTCV(RTOSCF(10077,F1114_10077, (Current)))));
		tp2 = inline_F12_275();
		tp3 = *(EIF_POINTER *)(RTCW(loc2)+ _PTROFF_0_1_0_1_0_0_);
		inline_F81_1828(tp1, tp2, tp3);
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.disconnect_accelerator */
void F1191_11107 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = RTRV(eif_new_type(1103, 0x00), loc1);
	RTCT0("acc_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = *(EIF_REFERENCE *)(Current + O8700[Dtype(Current)-1182]);
	ti4_1 = F1103_9584(RTCW(loc1));
	F578_4670(RTCW(tr1), ti4_1);
	RTLE;
}

/* {EV_WINDOW_IMP}.destroy */
void F1191_11108 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1162_10624(Current);
	F1191_11100(Current);
	F1116_10139(Current);
	F1166_10775(Current);
	RTLE;
}

/* {EV_WINDOW_IMP}.on_widget_mapped */
void F1191_11109 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1164_10718(Current);
	F1191_11110(Current);
	RTLE;
}

/* {EV_WINDOW_IMP}.process_show_actions */
void F1191_11110 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_6_) != NULL) && *(EIF_BOOLEAN *)(Current + O8768[dtype-1190]))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		F603_4886(RTCW(tr1), NULL);
	}
	*(EIF_BOOLEAN *)(Current + O8768[dtype-1190]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {EV_WINDOW_IMP}.on_widget_hidden */
void F1191_11111 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1164_10720(Current);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_7_) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		F603_4886(RTCW(tr1), NULL);
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.set_focused_widget */
void F1191_11115 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tp1 = *(EIF_POINTER *)(RTCW(arg1) + O8051[Dtype(arg1)-1113]);
		*(EIF_POINTER *)(Current + O8773[dtype-1190]) = (EIF_POINTER) tp1;
	} else {
		tp1 = F1_33(Current);
		*(EIF_POINTER *)(Current + O8773[dtype-1190]) = (EIF_POINTER) tp1;
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.client_area */
EIF_POINTER F1191_11118 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_POINTER) *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
}

/* {EV_WINDOW_IMP}.initialize_client_area */
void F1191_11119 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_8 tu1_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tu1_1 = inline_F19_423();
	tp1 = inline_F82_1959(tu1_1, ((EIF_INTEGER_32) 0L));
	*(EIF_POINTER *)(Current + O8796[dtype-1190]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O8796[dtype-1190]);
	gtk_widget_show((GtkWidget*) tp1);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R8777[dtype-1190])(Current);
	tp2 = *(EIF_POINTER *)(Current + O8796[dtype-1190]);
	gtk_container_add((GtkContainer*) tp1, (GtkWidget*) tp2);
	tu1_1 = inline_F19_422();
	tp1 = inline_F82_1959(tu1_1, ((EIF_INTEGER_32) 0L));
	*(EIF_POINTER *)(Current + O8797[dtype-1190]) = (EIF_POINTER) tp1;
	tp1 = *(EIF_POINTER *)(Current + O8797[dtype-1190]);
	gtk_box_set_homogeneous((GtkBox*) tp1, (gboolean) (EIF_BOOLEAN) 1);
	tp1 = *(EIF_POINTER *)(Current + O8797[dtype-1190]);
	gtk_widget_show((GtkWidget*) tp1);
	tr1 = *(EIF_REFERENCE *)(Current + O8672[dtype-1182]);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1176, 0x00), loc1);
	RTCT0("bar_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = *(EIF_POINTER *)(Current + O8796[dtype-1190]);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_49_13_10_7_0_0_);
	gtk_box_pack_start((GtkBox*) tp1, (GtkWidget*) tp2, (gboolean) (EIF_BOOLEAN) 0, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 0L));
	tp1 = *(EIF_POINTER *)(Current + O8796[dtype-1190]);
	tp2 = *(EIF_POINTER *)(Current + O8797[dtype-1190]);
	gtk_box_pack_start((GtkBox*) tp1, (GtkWidget*) tp2, (gboolean) (EIF_BOOLEAN) 1, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + O8673[dtype-1182]);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1176, 0x00), loc1);
	RTCT0("bar_imp /= Void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tp1 = *(EIF_POINTER *)(Current + O8796[dtype-1190]);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_49_13_10_7_0_0_);
	gtk_box_pack_start((GtkBox*) tp1, (GtkWidget*) tp2, (gboolean) (EIF_BOOLEAN) 0, (gboolean) (EIF_BOOLEAN) 1, (guint) ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(10077,F1114_10077, (Current))) + _REFACS_43_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O5187[dtype-826]);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4038[Dtype(RTCW(tr1))-564])(tr1, (EIF_REFERENCE) &ti4_1);
	RTLE;
}

/* {EV_WINDOW_IMP}.on_size_allocate */
void F1191_11120 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc3 = F1116_10130(Current);
	loc4 = F1116_10131(Current);
	loc1 = F1116_10132(Current);
	loc2 = F1116_10134(Current);
	F1116_10149(Current, loc1, loc2, loc3, loc4);
	F1164_10689(Current, loc1, loc2, loc3, loc4);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != *(EIF_INTEGER_32 *)(Current + O8775[dtype-1190])) || (EIF_BOOLEAN)(loc2 != *(EIF_INTEGER_32 *)(Current + O8776[dtype-1190])))) {
		*(EIF_INTEGER_32 *)(Current + O8775[dtype-1190]) = (EIF_INTEGER_32) loc1;
		*(EIF_INTEGER_32 *)(Current + O8776[dtype-1190]) = (EIF_INTEGER_32) loc2;
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_5_) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			tr2 = *(EIF_REFERENCE *)(RTCV(RTOSCF(10077,F1114_10077, (Current))) + _REFACS_42_);
			tr2 = F832_6105(RTCW(tr2), loc1, loc2, loc3, loc4);
			F603_4886(RTCW(tr1), tr2);
		}
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.call_window_state_event */
void F1191_11121 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	RTGC;
}

/* {EV_WINDOW_IMP}.on_set_focus_event */
void F1191_11122 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(10077,F1114_10077, (Current));
	loc2 = F1112_10022(RTCW(tr1), arg1);
	loc2 = RTRV(eif_new_type(1163, 0x00), loc2);
	tr1 = RTOSCF(10077,F1114_10077, (Current));
	loc1 = F1112_10022(RTCW(tr1), *(EIF_POINTER *)(Current + O8773[Dtype(Current)-1190]));
	loc1 = RTRV(eif_new_type(1163, 0x00), loc1);
	F1191_11115(Current, loc2);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) R8539[Dtype(RTCW(loc2))-1176])(loc2, (EIF_BOOLEAN) 1);
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && (EIF_BOOLEAN)(loc1 != loc2))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_BOOLEAN)) R8539[Dtype(RTCW(loc1))-1176])(loc1, (EIF_BOOLEAN) 0);
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.increase_modal_window_count */
void F1191_11124 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O8781[dtype-1190]) == ((EIF_INTEGER_32) 0L))) {
		F1191_11128(Current);
	}
	(*(EIF_INTEGER_32 *)(Current + O8781[dtype-1190]))++;
	RTLE;
}

/* {EV_WINDOW_IMP}.decrease_modal_window_count */
void F1191_11125 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current + O8781[dtype-1190]))--;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O8781[dtype-1190]) == ((EIF_INTEGER_32) 0L))) {
		F1191_11127(Current);
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.has_modal_window */
EIF_BOOLEAN F1191_11126 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O8781[Dtype(Current)-1190]) > ((EIF_INTEGER_32) 0L));
}

/* {EV_WINDOW_IMP}.allow_window_manager_focus */
void F1191_11127 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	inline_F81_1551(tp1, (EIF_BOOLEAN) 1);
}

/* {EV_WINDOW_IMP}.disallow_window_manager_focus */
void F1191_11128 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current + O8051[Dtype(Current)-1113]);
	inline_F81_1551(tp1, (EIF_BOOLEAN) 0);
}

/* {EV_WINDOW_IMP}.on_focus_changed */
void F1191_11138 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O8771[dtype-1190]) = (EIF_BOOLEAN) arg1;
	F1164_10690(Current, arg1);
	if (arg1) {
		tp1 = *(EIF_POINTER *)(Current + O8051[dtype-1113]);
		loc1 = (EIF_POINTER) gtk_window_get_focus((GtkWindow*) tp1);
		if ((EIF_BOOLEAN)(loc1 != *(EIF_POINTER *)(Current + O8051[dtype-1113]))) {
			F1191_11122(Current, loc1);
		} else {
			F1_31(Current);
		}
	} else {
		tp1 = F1_33(Current);
		F1191_11122(Current, tp1);
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.call_close_request_actions */
void F1191_11140 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\0';
	tb2 = '\0';
	tb3 = '\0';
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_4_) != NULL)) {
		tb4 = F1112_10006(RTCV(RTOSCF(10077,F1114_10077, (Current))));
		tb3 = (EIF_BOOLEAN) !tb4;
	}
	if (tb3) {
		tb2 = (EIF_BOOLEAN) !F1191_11126(Current);
	}
	if (tb2) {
		tb1 = (EIF_BOOLEAN) !F1087_9344(Current);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		F603_4886(RTCW(tr1), NULL);
	}
	RTLE;
}

/* {EV_WINDOW_IMP}.container_widget */
EIF_POINTER F1191_11141 (EIF_REFERENCE Current)
{
	return *(EIF_POINTER *)(Current + O8797[Dtype(Current)-1190]);
}


void EIF_Minit543 (void)
{
	GTCX
	RTPOMS(11105,3,"<Shift><Control><Mod1><Mod2><Mod3><Mod4><Mod5>",46,1367187518);
	RTPOMS(11105,2,"F12",3,4600114);
	RTPOMS(11105,1,"F11",3,4600113);
	RTPOMS(11105,0,"F10",3,4600112);
}


#ifdef __cplusplus
}
#endif
