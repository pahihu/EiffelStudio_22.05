
#ifndef _C20_co985_
#define _C20_co985_

#ifdef __cplusplus
extern "C" {
#endif

extern void F465_3121(EIF_REFERENCE);
extern void EIF_Minit985(void);
extern long O2805[];

#ifdef __cplusplus
}
#endif

#endif
