
#ifndef _C20_re976_
#define _C20_re976_

#ifdef __cplusplus
extern "C" {
#endif

extern void F396_3034(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F396_3036(EIF_REFERENCE);
extern EIF_INTEGER_32 F396_3037(EIF_REFERENCE);
extern EIF_INTEGER_32 F396_3038(EIF_REFERENCE);
extern EIF_INTEGER_32 F396_3039(EIF_REFERENCE);
extern EIF_BOOLEAN F396_3047(EIF_REFERENCE);
extern EIF_BOOLEAN F396_3048(EIF_REFERENCE);
extern void F396_3053(EIF_REFERENCE);
extern void EIF_Minit976(void);
extern char *(*R3078[])();
extern char *(*R3079[])();

#ifdef __cplusplus
}
#endif

#endif
