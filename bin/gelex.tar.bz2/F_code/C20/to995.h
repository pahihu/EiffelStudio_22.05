
#ifndef _C20_to995_
#define _C20_to995_

#ifdef __cplusplus
extern "C" {
#endif

extern void F256_2420(EIF_REFERENCE, EIF_INTEGER_32);
extern void F256_2421(EIF_REFERENCE, EIF_NATURAL_16, EIF_INTEGER_32);
extern void F256_2427(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit995(void);
extern void F685_3597(EIF_REFERENCE, EIF_NATURAL_16, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2242[];
extern EIF_TYPE_INDEX *Y2242_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
