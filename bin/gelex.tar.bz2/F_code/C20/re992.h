
#ifndef _C20_re992_
#define _C20_re992_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F634_3232(EIF_REFERENCE);
extern void EIF_Minit992(void);
extern EIF_INTEGER_32 F710_3698(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
