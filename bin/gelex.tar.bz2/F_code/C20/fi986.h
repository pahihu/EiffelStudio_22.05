
#ifndef _C20_fi986_
#define _C20_fi986_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F608_3219(EIF_REFERENCE);
extern void EIF_Minit986(void);
extern EIF_INTEGER_32 F710_3697(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
