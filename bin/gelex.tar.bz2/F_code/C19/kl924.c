/*
 * Code for class KL_COMPARABLE_COMPARATOR [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl924.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_COMPARABLE_COMPARATOR}.make */
void F235_2150 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {KL_COMPARABLE_COMPARATOR}.attached_less_than */
EIF_BOOLEAN F235_2151 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTCCL(arg2);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R1634[Dtype(RTCW(arg1))-162])(arg1, tr1);
	RTLE;
	return Result;
}

void EIF_Minit924 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
