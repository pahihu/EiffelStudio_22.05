
#ifndef _C19_lx926_
#define _C19_lx926_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1077_7230(EIF_REFERENCE);
extern void F1077_7231(EIF_REFERENCE, EIF_REFERENCE);
extern void F1077_7232(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1077_7233(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1077_7234(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit926(void);

#ifdef __cplusplus
}
#endif

#endif
