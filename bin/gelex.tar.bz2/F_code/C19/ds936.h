
#ifndef _C19_ds936_
#define _C19_ds936_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1037_6776(EIF_REFERENCE);
extern void F1037_6788(EIF_REFERENCE);
extern void EIF_Minit936(void);
extern void F1147_7545(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1147_7567(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
