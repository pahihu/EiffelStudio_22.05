
#ifndef _C19_ds945_
#define _C19_ds945_

#ifdef __cplusplus
extern "C" {
#endif

extern void F76_961(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit945(void);
extern EIF_INTEGER_32 F703_3690(EIF_REFERENCE, EIF_INTEGER_32);
extern void F703_3711(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F703_3709(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F703_3685(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern char *(*R5699[])();
extern char *(*R5692[])();
extern char *(*R1356[])();
extern char *(*R5700[])();

#ifdef __cplusplus
}
#endif

#endif
