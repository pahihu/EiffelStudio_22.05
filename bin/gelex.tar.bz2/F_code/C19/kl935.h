
#ifndef _C19_kl935_
#define _C19_kl935_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F131_1386(EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN);
extern EIF_BOOLEAN F131_1387(EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN);
extern void EIF_Minit935(void);

#ifdef __cplusplus
}
#endif

#endif
