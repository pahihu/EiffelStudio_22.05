
#ifndef _C19_ds940_
#define _C19_ds940_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1116_7329(EIF_REFERENCE);
extern void EIF_Minit940(void);
extern EIF_BOOLEAN F1147_7569(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
