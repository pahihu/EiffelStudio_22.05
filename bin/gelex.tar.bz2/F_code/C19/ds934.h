
#ifndef _C19_ds934_
#define _C19_ds934_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1094_7280(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit934(void);

#ifdef __cplusplus
}
#endif

#endif
