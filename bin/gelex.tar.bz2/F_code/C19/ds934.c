/*
 * Code for class DS_SORTABLE [BOOLEAN]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds934.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SORTABLE}.sort */
void F1094_7280 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	(RTNA((RTCW(arg1), Current)));
}

void EIF_Minit934 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
