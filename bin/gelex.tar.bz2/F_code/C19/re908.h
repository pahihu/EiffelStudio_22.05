
#ifndef _C19_re908_
#define _C19_re908_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F633_3232(EIF_REFERENCE);
extern void EIF_Minit908(void);
extern EIF_INTEGER_32 F709_3698(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
