
#ifndef _C19_co901_
#define _C19_co901_

#ifdef __cplusplus
extern "C" {
#endif

extern void F464_3121(EIF_REFERENCE);
extern void EIF_Minit901(void);
extern long O2805[];

#ifdef __cplusplus
}
#endif

#endif
