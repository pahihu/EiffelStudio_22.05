/*
 * Code for class KL_PART_COMPARATOR [BOOLEAN]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl935.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_PART_COMPARATOR}.less_than */
EIF_BOOLEAN F131_1386 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (RTNA((Current, arg1, arg2)), ((EIF_BOOLEAN) 0));
}

/* {KL_PART_COMPARATOR}.detachable_less_than */
EIF_BOOLEAN F131_1387 (EIF_REFERENCE Current, EIF_BOOLEAN arg1, EIF_BOOLEAN arg2)
{
	GTCX
	
	
	RTGC;
	if (EIF_FALSE) {
		return (EIF_BOOLEAN) EIF_TRUE;
	} else {
		if (EIF_FALSE) {
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			return (EIF_BOOLEAN) (RTNA((Current, arg1, arg2)), ((EIF_BOOLEAN) 0));
		}
	}/* NOTREACHED */
	
}

void EIF_Minit935 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
