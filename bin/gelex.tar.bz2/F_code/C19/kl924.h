
#ifndef _C19_kl924_
#define _C19_kl924_

#ifdef __cplusplus
extern "C" {
#endif

extern void F235_2150(EIF_REFERENCE);
extern EIF_BOOLEAN F235_2151(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit924(void);
extern char *(*R1634[])();

#ifdef __cplusplus
}
#endif

#endif
