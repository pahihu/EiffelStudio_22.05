
#ifndef _C19_fi902_
#define _C19_fi902_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F607_3219(EIF_REFERENCE);
extern void EIF_Minit902(void);
extern EIF_INTEGER_32 F709_3697(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
