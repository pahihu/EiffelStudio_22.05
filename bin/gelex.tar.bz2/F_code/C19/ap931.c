/*
 * Code for class AP_OPTION_WITH_PARAMETER [BOOLEAN]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ap931.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {AP_OPTION_WITH_PARAMETER}.initialize */
void F119_1347 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F116_1309(Current);
	tr1 = RTMS_EX_H("arg",3,6386279);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current + O1334[Dtype(Current)-117]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {AP_OPTION_WITH_PARAMETER}.default_parameter */
EIF_BOOLEAN F119_1348 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O1326[Dtype(Current)-117]);
}


/* {AP_OPTION_WITH_PARAMETER}.example */
EIF_REFERENCE F119_1349 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Result);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	Result = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F913_5751(RTCW(Result), ((EIF_INTEGER_32) 20L));
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, (EIF_CHARACTER_8) '[');
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, (EIF_CHARACTER_8) '-');
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_4_1_)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, *(EIF_CHARACTER_8 *)(Current+ _CHROFF_4_0_));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, (EIF_CHARACTER_8) ' ');
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(Result))-914])(Result, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	} else {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, (EIF_CHARACTER_8) '-');
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(Result))-914])(Result, loc1);
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O1334[dtype-117])) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, (EIF_CHARACTER_8) '[');
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, (EIF_CHARACTER_8) '=');
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(Result))-914])(Result, *(EIF_REFERENCE *)(Current + _REFACS_2_));
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O1334[dtype-117])) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, (EIF_CHARACTER_8) ']');
		}
	}
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_4_3_)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, (EIF_CHARACTER_8) ']');
	}
	RTLE;
	return Result;
}

/* {AP_OPTION_WITH_PARAMETER}.names */
EIF_REFERENCE F119_1350 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	Result = F116_1317(Current);
	if (F116_1321(Current)) {
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O1334[dtype-117])) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, (EIF_CHARACTER_8) '[');
		}
		tr1 = eif_out__c1_s1((EIF_CHARACTER_8) '=');
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(Result))-914])(Result, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(Result))-914])(Result, *(EIF_REFERENCE *)(Current + _REFACS_2_));
		if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O1334[dtype-117])) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, (EIF_CHARACTER_8) ']');
		}
	} else {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, (EIF_CHARACTER_8) ' ');
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(Result))-914])(Result, *(EIF_REFERENCE *)(Current + _REFACS_2_));
	}
	RTLE;
	return Result;
}

/* {AP_OPTION_WITH_PARAMETER}.parameter */
EIF_BOOLEAN F119_1352 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tb1 = F1084_7250(RTCW(loc1));
	if ((EIF_BOOLEAN) !tb1) {
		tb1 = F1147_7504(RTCW(loc1));
		RTLE;
		return (EIF_BOOLEAN) tb1;
	} else {
		RTLE;
		return (EIF_BOOLEAN) *(EIF_BOOLEAN *)(Current + O1326[Dtype(Current)-117]);
	}/* NOTREACHED */
	
}

/* {AP_OPTION_WITH_PARAMETER}.occurrences */
EIF_INTEGER_32 F119_1354 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_0_);
	RTLE;
	return Result;
}

/* {AP_OPTION_WITH_PARAMETER}.allows_parameter */
EIF_BOOLEAN F119_1355 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {AP_OPTION_WITH_PARAMETER}.needs_parameter */
EIF_BOOLEAN F119_1356 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O1334[Dtype(Current)-117]);
}


/* {AP_OPTION_WITH_PARAMETER}.set_parameter_description */
void F119_1358 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {AP_OPTION_WITH_PARAMETER}.set_parameter_optional */
void F119_1360 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O1334[dtype-117]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	*(EIF_BOOLEAN *)(Current + O1326[dtype-117]) = (EIF_BOOLEAN) arg1;
	RTLE;
}

void EIF_Minit931 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
