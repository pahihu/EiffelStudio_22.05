
#ifndef _C3_lo143_
#define _C3_lo143_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F214_2021(EIF_REFERENCE);
extern void EIF_Minit143(void);

#ifdef __cplusplus
}
#endif

#endif
