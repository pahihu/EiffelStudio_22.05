
#ifndef _C3_ex107_
#define _C3_ex107_

#ifdef __cplusplus
extern "C" {
#endif

extern void F178_1905(EIF_REFERENCE, EIF_REFERENCE);
extern void F178_1906(EIF_REFERENCE, EIF_REFERENCE);
extern void F178_1907(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit107(void);
extern EIF_REFERENCE F99_1097(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F177_1886(EIF_REFERENCE);
extern void F180_1929(EIF_REFERENCE, EIF_REFERENCE);
extern void F180_1914(EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,1886)

#ifdef __cplusplus
}
#endif

#endif
