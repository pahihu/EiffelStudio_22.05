
#ifndef _C3_de110_
#define _C3_de110_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F181_1945(EIF_REFERENCE);
extern void EIF_Minit110(void);

#ifdef __cplusplus
}
#endif

#endif
