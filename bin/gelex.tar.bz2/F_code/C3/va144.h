
#ifndef _C3_va144_
#define _C3_va144_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F215_2023(EIF_REFERENCE);
extern void EIF_Minit144(void);

#ifdef __cplusplus
}
#endif

#endif
