
#ifndef _C3_ol125_
#define _C3_ol125_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F196_1987(EIF_REFERENCE);
extern void EIF_Minit125(void);

#ifdef __cplusplus
}
#endif

#endif
