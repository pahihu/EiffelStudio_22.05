
#ifndef _C3_ba136_
#define _C3_ba136_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F207_2007(EIF_REFERENCE);
extern void EIF_Minit136(void);

#ifdef __cplusplus
}
#endif

#endif
