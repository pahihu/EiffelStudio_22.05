
#ifndef _C3_kl108_
#define _C3_kl108_

#ifdef __cplusplus
extern "C" {
#endif

extern void F179_1912(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit108(void);

#ifdef __cplusplus
}
#endif

#endif
