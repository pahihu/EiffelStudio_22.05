
#ifndef _C3_se132_
#define _C3_se132_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F203_2001(EIF_REFERENCE);
extern void EIF_Minit132(void);

#ifdef __cplusplus
}
#endif

#endif
