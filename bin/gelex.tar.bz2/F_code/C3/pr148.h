
#ifndef _C3_pr148_
#define _C3_pr148_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F219_2033(EIF_REFERENCE);
extern void EIF_Minit148(void);

#ifdef __cplusplus
}
#endif

#endif
