
#ifndef _C3_fl114_
#define _C3_fl114_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F185_1948(EIF_REFERENCE);
extern void EIF_Minit114(void);

#ifdef __cplusplus
}
#endif

#endif
