
#ifndef _C3_re122_
#define _C3_re122_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F193_1981(EIF_REFERENCE);
extern void EIF_Minit122(void);

#ifdef __cplusplus
}
#endif

#endif
