
#ifndef _C3_mi133_
#define _C3_mi133_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F204_2003(EIF_REFERENCE);
extern void EIF_Minit133(void);

#ifdef __cplusplus
}
#endif

#endif
