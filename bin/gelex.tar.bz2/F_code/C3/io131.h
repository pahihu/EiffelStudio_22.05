
#ifndef _C3_io131_
#define _C3_io131_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F202_1995(EIF_REFERENCE);
extern void F202_1998(EIF_REFERENCE, EIF_INTEGER_32);
extern void F202_1999(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit131(void);

#ifdef __cplusplus
}
#endif

#endif
