
#ifndef _C3_ei124_
#define _C3_ei124_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F195_1983(EIF_REFERENCE);
extern void F195_1985(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit124(void);

#ifdef __cplusplus
}
#endif

#endif
