
#ifndef _C3_ch145_
#define _C3_ch145_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F216_2025(EIF_REFERENCE);
extern void EIF_Minit145(void);

#ifdef __cplusplus
}
#endif

#endif
