
#ifndef _C3_ex128_
#define _C3_ex128_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F199_1989(EIF_REFERENCE);
extern void EIF_Minit128(void);

#ifdef __cplusplus
}
#endif

#endif
