
#ifndef _C3_ex106_
#define _C3_ex106_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,1886)
static EIF_REFERENCE F177_1886_body(EIF_REFERENCE);
extern EIF_REFERENCE F177_1886(EIF_REFERENCE);
extern void EIF_Minit106(void);

#ifdef __cplusplus
}
#endif

#endif
