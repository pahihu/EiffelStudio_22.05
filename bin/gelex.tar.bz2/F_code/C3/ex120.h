
#ifndef _C3_ex120_
#define _C3_ex120_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F191_1977(EIF_REFERENCE);
extern void EIF_Minit120(void);

#ifdef __cplusplus
}
#endif

#endif
