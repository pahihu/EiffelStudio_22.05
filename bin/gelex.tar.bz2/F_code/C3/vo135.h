
#ifndef _C3_vo135_
#define _C3_vo135_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F206_2005(EIF_REFERENCE);
extern void EIF_Minit135(void);

#ifdef __cplusplus
}
#endif

#endif
