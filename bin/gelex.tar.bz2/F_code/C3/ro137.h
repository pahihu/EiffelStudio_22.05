
#ifndef _C3_ro137_
#define _C3_ro137_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F208_2011(EIF_REFERENCE);
extern void F208_2013(EIF_REFERENCE, EIF_REFERENCE);
extern void F208_2014(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit137(void);

#ifdef __cplusplus
}
#endif

#endif
