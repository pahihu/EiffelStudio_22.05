
#ifndef _C3_re121_
#define _C3_re121_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F192_1979(EIF_REFERENCE);
extern void EIF_Minit121(void);

#ifdef __cplusplus
}
#endif

#endif
