
#ifndef _C3_no129_
#define _C3_no129_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F200_1991(EIF_REFERENCE);
extern void F200_1993(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit129(void);

#ifdef __cplusplus
}
#endif

#endif
