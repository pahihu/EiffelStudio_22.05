
#ifndef _C3_op116_
#define _C3_op116_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F187_1950(EIF_REFERENCE);
extern void F187_1953(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit116(void);

#ifdef __cplusplus
}
#endif

#endif
