/*
 * Code for class YY_UNICODE_FILE_BUFFER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy102.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_UNICODE_FILE_BUFFER}.has_utf8_enconding */
EIF_BOOLEAN F171_1871 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_7_) == ((EIF_INTEGER_32) 1L));
}

/* {YY_UNICODE_FILE_BUFFER}.fill */
void F171_1875 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_CHARACTER_8 tc3;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) && (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_))) {
		F171_1877(Current);
		loc3 = *(EIF_REFERENCE *)(Current);
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_)) {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_7_) == ((EIF_INTEGER_32) 1L))) {
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				loc2 = F270_2648(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
			} else {
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_7_) == ((EIF_INTEGER_32) 2L))) {
					loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					loc2 = F270_2647(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
				} else {
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_6_) == ((EIF_INTEGER_32) 1L))) {
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						loc2 = F270_2648(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
					} else {
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						loc2 = F270_2647(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
					}
				}
			}
		} else {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_7_) == ((EIF_INTEGER_32) 1L))) {
				loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_1_);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
				loc2 = F270_2648(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
			} else {
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_7_) == ((EIF_INTEGER_32) 2L))) {
					loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_1_);
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
					loc2 = F270_2647(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
				} else {
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_6_) == ((EIF_INTEGER_32) 1L))) {
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_);
						loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
						loc2 = F270_2648(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), loc4, loc1);
						if ((EIF_BOOLEAN) (loc2 >= loc1)) {
							tc1 = F270_2626(RTCW(loc3), loc4);
							tw1 = (EIF_CHARACTER_32) tc1;
							tr1 = RTLNS(eif_new_type(66, 0x01).id, 66, _OBJSIZ_0_0_0_0_0_0_0_0_);
							if ((EIF_BOOLEAN)(tw1 == RTOSCF(878,F67_878, (RTCW(tr1))))) {
								*(EIF_BOOLEAN *)(Current+ _CHROFF_2_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
								loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_1_);
								ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_);
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
								loc2 = F270_2648(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
							}
						}
					} else {
						loc1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(6109,F938_6109, (Current)))+ _LNGOFF_1_1_0_2_);
						loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_);
						loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
						loc2 = F270_2647(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), loc4, loc1);
						for (;;) {
							tb1 = '\01';
							if (!(EIF_BOOLEAN) (loc2 >= loc1)) {
								tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
								tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1349[Dtype(RTCW(tr1))-946])(tr1);
								tb1 = tb2;
							}
							if (tb1) break;
							ti4_1 = F270_2647(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (loc4 + loc2), (EIF_INTEGER_32) (loc1 - loc2));
							loc2 += ti4_1;
						}
						tb2 = '\0';
						if ((EIF_BOOLEAN) (loc2 >= loc1)) {
							tc1 = F270_2626(RTCW(loc3), loc4);
							tc1 = (EIF_CHARACTER_8) tc1;
							tc2 = F270_2626(RTCW(loc3), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
							tc2 = (EIF_CHARACTER_8) tc2;
							tc3 = F270_2626(RTCW(loc3), (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 2L)));
							tc3 = (EIF_CHARACTER_8) tc3;
							tr1 = RTLNS(eif_new_type(937, 0x01).id, 937, _OBJSIZ_0_0_0_0_0_0_0_0_);
							tb2 = F938_6105(RTCW(tr1), tc1, tc2, tc3);
						}
						if (tb2) {
							*(EIF_BOOLEAN *)(Current+ _CHROFF_2_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_1_);
							ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_);
							loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ti4_1);
							loc2 = F270_2648(RTCW(loc3), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_) + ((EIF_INTEGER_32) 1L)), loc1);
						} else {
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
						}
					}
				}
			}
		}
		if ((EIF_BOOLEAN) (loc2 < loc1)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1349[Dtype(RTCW(tr1))-946])(tr1);
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_3_) = (EIF_BOOLEAN) tb2;
		}
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_)) += loc2;
		if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		F270_2638(RTCW(loc3), (EIF_CHARACTER_8) '\000', (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_) + ((EIF_INTEGER_32) 1L)));
		F270_2638(RTCW(loc3), (EIF_CHARACTER_8) '\000', (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_) + ((EIF_INTEGER_32) 2L)));
	} else {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_2_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	RTLE;
}

/* {YY_UNICODE_FILE_BUFFER}.flush */
void F171_1876 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F166_1822(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_7_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_2_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {YY_UNICODE_FILE_BUFFER}.compact_left */
void F171_1877 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_7_) == ((EIF_INTEGER_32) 1L))) {
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_7_) == ((EIF_INTEGER_32) 2L))) {
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			if (*(EIF_BOOLEAN *)(Current+ _CHROFF_2_2_)) {
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			} else {
				loc2 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(6109,F938_6109, (Current)))+ _LNGOFF_1_1_0_2_);
			}
		}
	}
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_1_);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_5_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - ti4_1) + ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 + loc2) > loc3)) {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_1_) == ((EIF_INTEGER_32) 0L))) {
			ti4_1 = RTOSCF(1828,F166_1828, (Current));
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_1_) = (EIF_INTEGER_32) ti4_1;
		} else {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_1_)) *= ((EIF_INTEGER_32) 2L);
		}
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_1_) < (EIF_INTEGER_32) (loc3 + loc2))) {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_1_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + loc2);
		}
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = F270_2634(RTCW(tr1));
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_1_) + ((EIF_INTEGER_32) 2L)) > ti4_1)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			F270_2651(RTCW(tr1), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_1_) + ((EIF_INTEGER_32) 2L)));
		}
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_5_) != ((EIF_INTEGER_32) 1L))) {
		tr1 = *(EIF_REFERENCE *)(Current);
		F270_2649(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_5_), ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 2L)));
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_5_0_0_) = (EIF_INTEGER_32) loc1;
	}
	RTLE;
}

void EIF_Minit102 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
