
#ifndef _C3_cr140_
#define _C3_cr140_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F211_2017(EIF_REFERENCE);
extern void EIF_Minit140(void);

#ifdef __cplusplus
}
#endif

#endif
