
#ifndef _C3_vo138_
#define _C3_vo138_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F209_2015(EIF_REFERENCE);
extern void EIF_Minit138(void);

#ifdef __cplusplus
}
#endif

#endif
