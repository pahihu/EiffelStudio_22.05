
#ifndef _C3_ad141_
#define _C3_ad141_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F212_2019(EIF_REFERENCE);
extern void EIF_Minit141(void);

#ifdef __cplusplus
}
#endif

#endif
