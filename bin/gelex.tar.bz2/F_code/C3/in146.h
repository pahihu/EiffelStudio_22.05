
#ifndef _C3_in146_
#define _C3_in146_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F217_2027(EIF_REFERENCE);
extern void F217_2028(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit146(void);

#ifdef __cplusplus
}
#endif

#endif
