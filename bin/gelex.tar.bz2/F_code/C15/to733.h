
#ifndef _C15_to733_
#define _C15_to733_

#ifdef __cplusplus
extern "C" {
#endif

extern void F252_2420(EIF_REFERENCE, EIF_INTEGER_32);
extern void F252_2421(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern void F252_2427(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit733(void);
extern void F681_3597(EIF_REFERENCE, EIF_CHARACTER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2242[];
extern EIF_TYPE_INDEX *Y2242_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
