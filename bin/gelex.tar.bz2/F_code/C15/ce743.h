
#ifndef _C15_ce743_
#define _C15_ce743_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F101_1147(EIF_REFERENCE);
extern void F101_1148(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit743(void);
extern long O1134[];

#ifdef __cplusplus
}
#endif

#endif
