
#ifndef _C15_fi719_
#define _C15_fi719_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F605_3219(EIF_REFERENCE);
extern void EIF_Minit719(void);
extern char *(*R2867[])();

#ifdef __cplusplus
}
#endif

#endif
