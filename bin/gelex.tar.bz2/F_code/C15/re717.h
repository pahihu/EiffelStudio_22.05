
#ifndef _C15_re717_
#define _C15_re717_

#ifdef __cplusplus
extern "C" {
#endif

extern void F393_3034(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F393_3036(EIF_REFERENCE);
extern EIF_INTEGER_32 F393_3037(EIF_REFERENCE);
extern EIF_INTEGER_32 F393_3038(EIF_REFERENCE);
extern EIF_INTEGER_32 F393_3039(EIF_REFERENCE);
extern EIF_BOOLEAN F393_3047(EIF_REFERENCE);
extern EIF_BOOLEAN F393_3048(EIF_REFERENCE);
extern void F393_3053(EIF_REFERENCE);
extern void EIF_Minit717(void);
extern char *(*R3078[])();
extern char *(*R3079[])();

#ifdef __cplusplus
}
#endif

#endif
