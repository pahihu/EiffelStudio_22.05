
#ifndef _C15_co714_
#define _C15_co714_

#ifdef __cplusplus
extern "C" {
#endif

extern void F462_3121(EIF_REFERENCE);
extern void EIF_Minit714(void);
extern long O2805[];

#ifdef __cplusplus
}
#endif

#endif
