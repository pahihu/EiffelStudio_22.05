
#ifndef _C15_re725_
#define _C15_re725_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F630_3232(EIF_REFERENCE);
extern void EIF_Minit725(void);
extern char *(*R2870[])();

#ifdef __cplusplus
}
#endif

#endif
