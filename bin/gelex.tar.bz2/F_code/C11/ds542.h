
#ifndef _C11_ds542_
#define _C11_ds542_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1101_7298(EIF_REFERENCE, EIF_REFERENCE);
extern void F1101_7302(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit542(void);

#ifdef __cplusplus
}
#endif

#endif
