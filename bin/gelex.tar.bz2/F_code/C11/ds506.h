
#ifndef _C11_ds506_
#define _C11_ds506_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1114_7329(EIF_REFERENCE);
extern void EIF_Minit506(void);
extern char *(*R5647[])();
extern char *(*R5609[])();

#ifdef __cplusplus
}
#endif

#endif
