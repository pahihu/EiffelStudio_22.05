
#ifndef _C11_kl547_
#define _C11_kl547_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F128_1386(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F128_1387(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit547(void);
extern char *(*R1357[])();
extern char *(*R1358[])();

#ifdef __cplusplus
}
#endif

#endif
