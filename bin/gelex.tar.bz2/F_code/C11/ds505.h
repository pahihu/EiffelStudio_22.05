
#ifndef _C11_ds505_
#define _C11_ds505_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F991_6718(EIF_REFERENCE);
extern void F991_6721(EIF_REFERENCE);
extern void F991_6722(EIF_REFERENCE);
extern void F991_6723(EIF_REFERENCE, EIF_INTEGER_32);
extern void F991_6724(EIF_REFERENCE);
extern void EIF_Minit505(void);
extern char *(*R5639[])();
extern char *(*R5186[])();
extern char *(*R5634[])();
extern char *(*R5636[])();
extern char *(*R5637[])();
extern char *(*R5638[])();

#ifdef __cplusplus
}
#endif

#endif
