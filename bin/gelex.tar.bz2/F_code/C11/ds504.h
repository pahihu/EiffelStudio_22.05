
#ifndef _C11_ds504_
#define _C11_ds504_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1108_7305(EIF_REFERENCE);
extern EIF_BOOLEAN F1108_7307(EIF_REFERENCE);
extern void F1108_7310(EIF_REFERENCE);
extern void F1108_7311(EIF_REFERENCE);
extern EIF_BOOLEAN F1108_7322(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit504(void);
extern void F991_6721(EIF_REFERENCE);
extern char *(*R5603[])();
extern char *(*R5609[])();
extern char *(*R2689[])();
extern char *(*R5636[])();
extern char *(*R5637[])();

#ifdef __cplusplus
}
#endif

#endif
