
#ifndef _C11_co524_
#define _C11_co524_

#ifdef __cplusplus
extern "C" {
#endif

extern void F459_3121(EIF_REFERENCE);
extern void EIF_Minit524(void);
extern long O2805[];

#ifdef __cplusplus
}
#endif

#endif
