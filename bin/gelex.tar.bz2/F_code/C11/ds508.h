
#ifndef _C11_ds508_
#define _C11_ds508_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1138_7438(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit508(void);
extern char *(*R5692[])();
extern char *(*R5699[])();

#ifdef __cplusplus
}
#endif

#endif
