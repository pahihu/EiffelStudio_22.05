
#ifndef _C11_kl548_
#define _C11_kl548_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F939_6159(EIF_REFERENCE, EIF_INTEGER_32);
extern void F939_6164(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F939_6166(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit548(void);
extern char *(*R3170[])();
extern char *(*R3180[])();
extern char *(*R3142[])();
extern char *(*R3145[])();
extern char *(*R3156[])();

#ifdef __cplusplus
}
#endif

#endif
