
#ifndef _C11_ds546_
#define _C11_ds546_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1091_7280(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit546(void);
extern char *(*R951[])();

#ifdef __cplusplus
}
#endif

#endif
