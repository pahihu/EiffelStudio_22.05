
#ifndef _C11_kl544_
#define _C11_kl544_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F226_2144(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit544(void);

#ifdef __cplusplus
}
#endif

#endif
