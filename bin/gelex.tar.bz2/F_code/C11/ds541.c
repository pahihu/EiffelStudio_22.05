/*
 * Code for class DS_LINKED_LIST [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds541.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_LINKED_LIST}.make */
void F1145_7496 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5603[dtype-1144])(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5608[dtype-1144])(Current, tr1);
	RTLE;
}

/* {DS_LINKED_LIST}.item */
EIF_REFERENCE F1145_7502 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc2 == arg1)) break;
		RTCT0("valid_index", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1626[Dtype(loc1)-153]);
		loc1 = (EIF_REFERENCE) tr1;
		loc2++;
	}
	RTCT0("valid_index", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1617[Dtype(RTCW(loc1))-152])(loc1);
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.first */
EIF_REFERENCE F1145_7503 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("not_empty", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1617[Dtype(loc1)-152])(loc1);
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.last */
EIF_REFERENCE F1145_7504 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0("not_empty", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1617[Dtype(loc1)-152])(loc1);
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.new_cursor */
EIF_REFERENCE F1145_7505 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1039,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y5580,Y5580_gen_type,Dftype(Current),1080);
			typarr0[2] = l_type.annotations | 0xFF00;
			typarr0[3] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 1039, _OBJSIZ_3_2_0_0_0_0_0_0_);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5249[Dtype(RTCW(tr1))-1039])(tr1, Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {DS_LINKED_LIST}.count */
EIF_INTEGER_32 F1145_7506 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O5761[Dtype(Current)-1144]);
}


/* {DS_LINKED_LIST}.has */
EIF_BOOLEAN F1145_7508 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,arg1);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		for (;;) {
			if ((EIF_BOOLEAN)(loc1 == NULL)) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1617[Dtype(RTCW(loc1))-152])(loc1);
			tr2 = RTCCL(tr1);
			tr3 = RTCCL(arg1);
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1979[Dtype(loc2)-225])(loc2, tr2, tr3);
			if (tb1) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_REFERENCE) NULL;
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1626[Dtype(loc1)-153]);
				loc1 = (EIF_REFERENCE) tr1;
			}
		}
	} else {
		for (;;) {
			if ((EIF_BOOLEAN)(loc1 == NULL)) break;
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1617[Dtype(RTCW(loc1))-152])(loc1);
			if (RTCEQ(tr1, arg1)) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_REFERENCE) NULL;
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1626[Dtype(loc1)-153]);
				loc1 = (EIF_REFERENCE) tr1;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.copy */
void F1145_7518 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLR(7,loc2);
	RTLIU(8);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		loc4 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5759[dtype-1144])(Current);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5606[dtype-1144])(Current, loc4);
		}
		if (tb1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5608[dtype-1144])(Current, loc4);
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5603[dtype-1144])(Current);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5608[dtype-1144])(Current, tr1);
		}
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			loc3 = RTLNSMART(eif_final_id(Y5753,Y5753_gen_type,dftype,1144).id);
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1617[Dtype(RTCW(loc1))-152])(loc1);
			tr2 = RTCCL(tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1620[Dtype(RTCW(loc3))-152])(loc3, tr2);
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc3;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1626[Dtype(loc1)-153]);
			loc1 = (EIF_REFERENCE) tr1;
			for (;;) {
				if ((EIF_BOOLEAN)(loc1 == NULL)) break;
				loc2 = RTLNSMART(eif_final_id(Y5753,Y5753_gen_type,dftype,1144).id);
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1617[Dtype(RTCW(loc1))-152])(loc1);
				tr2 = RTCCL(tr1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1620[Dtype(RTCW(loc2))-152])(loc2, tr2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1627[Dtype(RTCW(loc3))-153])(loc3, loc2);
				loc3 = (EIF_REFERENCE) loc2;
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1626[Dtype(loc1)-153]);
				loc1 = (EIF_REFERENCE) tr1;
			}
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc3;
		}
	}
	RTLE;
}

/* {DS_LINKED_LIST}.is_equal */
EIF_BOOLEAN F1145_7519 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		tr1 = RTOSCF(5994,F932_5994, (Current));
		tb2 = F16_120(RTCW(tr1), Current, arg1);
		if (tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O5761[Dtype(arg1)-1144]);
			tb1 = (EIF_BOOLEAN)(ti4_1 == *(EIF_INTEGER_32 *)(Current + O5761[Dtype(Current)-1144]));
		}
		if (tb1) {
			loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == NULL) || (EIF_BOOLEAN)(loc2 == NULL))) break;
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1617[Dtype(RTCW(loc1))-152])(loc1);
				tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1617[Dtype(RTCW(loc2))-152])(loc2);
				if (!RTCEQ(tr1, tr2)) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc1 = (EIF_REFERENCE) NULL;
				} else {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1626[Dtype(loc1)-153]);
					loc1 = (EIF_REFERENCE) tr1;
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + O1626[Dtype(loc2)-153]);
					loc2 = (EIF_REFERENCE) tr1;
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.put_first */
void F1145_7520 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = RTLNSMART(eif_final_id(Y5753,Y5753_gen_type,dftype,1144).id);
		tr1 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1620[Dtype(RTCW(loc1))-152])(loc1, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1627[Dtype(RTCW(loc1))-153])(loc1, loc2);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
		(*(EIF_INTEGER_32 *)(Current + O5761[dtype-1144]))++;
	} else {
		tr1 = RTLNSMART(eif_final_id(Y5753,Y5753_gen_type,dftype,1144).id);
		tr2 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1620[Dtype(RTCW(tr1))-152])(tr1, tr2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		*(EIF_INTEGER_32 *)(Current + O5761[dtype-1144]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.put_last */
void F1145_7522 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = RTLNSMART(eif_final_id(Y5753,Y5753_gen_type,dftype,1144).id);
		tr1 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1620[Dtype(RTCW(loc1))-152])(loc1, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1627[Dtype(loc2)-153])(loc2, loc1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
		(*(EIF_INTEGER_32 *)(Current + O5761[dtype-1144]))++;
	} else {
		tr1 = RTLNSMART(eif_final_id(Y5753,Y5753_gen_type,dftype,1144).id);
		tr2 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1620[Dtype(RTCW(tr1))-152])(tr1, tr2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		*(EIF_INTEGER_32 *)(Current + O5761[dtype-1144]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.force_last */
void F1145_7523 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = RTLNSMART(eif_final_id(Y5753,Y5753_gen_type,dftype,1144).id);
		tr1 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1620[Dtype(RTCW(loc1))-152])(loc1, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1627[Dtype(loc2)-153])(loc2, loc1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
		(*(EIF_INTEGER_32 *)(Current + O5761[dtype-1144]))++;
	} else {
		tr1 = RTLNSMART(eif_final_id(Y5753,Y5753_gen_type,dftype,1144).id);
		tr2 = RTCCL(arg1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1620[Dtype(RTCW(tr1))-152])(tr1, tr2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		*(EIF_INTEGER_32 *)(Current + O5761[dtype-1144]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.replace */
void F1145_7524 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc2 == arg2)) break;
		RTCT0("valid_index", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1626[Dtype(loc1)-153]);
		loc1 = (EIF_REFERENCE) tr1;
		loc2++;
	}
	RTCT0("valid_index", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tr1 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1619[Dtype(RTCW(loc1))-152])(loc1, tr1);
	RTLE;
}

/* {DS_LINKED_LIST}.swap */
void F1145_7531 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,loc6);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != arg2)) {
		if ((EIF_BOOLEAN) (arg1 < arg2)) {
			loc1 = (EIF_INTEGER_32) arg1;
			loc2 = (EIF_INTEGER_32) arg2;
		} else {
			loc1 = (EIF_INTEGER_32) arg2;
			loc2 = (EIF_INTEGER_32) arg1;
		}
		loc4 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN)(loc3 == loc1)) break;
			RTCT0("valid_i", EX_CHECK);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + O1626[Dtype(loc4)-153]);
			loc4 = (EIF_REFERENCE) tr1;
			loc3++;
		}
		loc5 = (EIF_REFERENCE) loc4;
		for (;;) {
			if ((EIF_BOOLEAN)(loc3 == loc2)) break;
			RTCT0("valid_j", EX_CHECK);
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc5) + O1626[Dtype(loc5)-153]);
			loc5 = (EIF_REFERENCE) tr1;
			loc3++;
		}
		RTCT0("valid_i_and_j", EX_CHECK);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 != NULL) && (EIF_BOOLEAN)(loc5 != NULL))) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1617[Dtype(RTCW(loc4))-152])(loc4);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1617[Dtype(RTCW(loc5))-152])(loc5);
		tr2 = RTCCL(tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1619[Dtype(RTCW(loc4))-152])(loc4, tr2);
		tr1 = RTCCL(loc6);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1619[Dtype(RTCW(loc5))-152])(loc5, tr1);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.remove_first */
void F1145_7542 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5761[dtype-1144]) == ((EIF_INTEGER_32) 1L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5573[dtype-1144])(Current);
	} else {
		RTCT0("two_or_more_items", EX_CHECK);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = *(EIF_REFERENCE *)(loc1 + O1626[Dtype(loc1)-153]);
			loc2 = tr1;
			tb1 = EIF_TEST(loc2);
		}
		if (tb1) {
			RTCK0;
		} else {
			RTCF0;
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5758[dtype-1144])(Current, loc1, loc2);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5755[dtype-1144])(Current, loc2);
		(*(EIF_INTEGER_32 *)(Current + O5761[dtype-1144]))--;
	}
	RTLE;
}

/* {DS_LINKED_LIST}.remove_last */
void F1145_7543 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5761[dtype-1144]) == ((EIF_INTEGER_32) 1L))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5573[dtype-1144])(Current);
	} else {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5757[dtype-1144])(Current);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = *(EIF_INTEGER_32 *)(Current + O5761[dtype-1144]);
		for (;;) {
			if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 2L))) break;
			RTCT0("two_or_more_items", EX_CHECK);
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1626[Dtype(loc1)-153]);
			loc1 = (EIF_REFERENCE) tr1;
			loc2--;
		}
		RTCT0("two_or_more_items", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5756[dtype-1144])(Current, loc1);
		(*(EIF_INTEGER_32 *)(Current + O5761[dtype-1144]))--;
	}
	RTLE;
}

/* {DS_LINKED_LIST}.remove_at_cursor */
void F1145_7545 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5199[Dtype(RTCW(arg1))-1019])(arg1);
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5705[dtype-1144])(Current);
	} else {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5203[Dtype(RTCW(arg1))-1019])(arg1);
		if (tb1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5706[dtype-1144])(Current);
		} else {
			RTCT0("not_off_and_not_last", EX_CHECK);
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			loc1 = tr1;
			if (EIF_TEST(loc1)) {
				tr1 = *(EIF_REFERENCE *)(loc1 + O1626[Dtype(loc1)-153]);
				loc2 = tr1;
				tb1 = EIF_TEST(loc2);
			}
			if (tb1) {
				RTCK0;
			} else {
				RTCF0;
			}
			if ((EIF_BOOLEAN)(loc2 == *(EIF_REFERENCE *)(Current + _REFACS_2_))) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5756[dtype-1144])(Current, loc1);
			} else {
				RTCT0("before_second_to_last", EX_CHECK);
				tr1 = *(EIF_REFERENCE *)(loc2 + O1626[Dtype(loc2)-153]);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					RTCK0;
				} else {
					RTCF0;
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1627[Dtype(loc1)-153])(loc1, loc3);
			}
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1617[Dtype(loc2)-152])(loc2);
			tr2 = RTCCL(tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1619[Dtype(loc1)-152])(loc1, tr2);
			(*(EIF_INTEGER_32 *)(Current + O5761[dtype-1144]))--;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R5758[dtype-1144])(Current, loc2, loc1);
		}
	}
	RTLE;
}

/* {DS_LINKED_LIST}.wipe_out */
void F1145_7556 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5759[dtype-1144])(Current);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	*(EIF_INTEGER_32 *)(Current + O5761[dtype-1144]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {DS_LINKED_LIST}.set_first_cell */
void F1145_7559 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {DS_LINKED_LIST}.set_last_cell */
void F1145_7560 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R1628[Dtype(RTCW(arg1))-153])(arg1);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {DS_LINKED_LIST}.set_internal_cursor */
void F1145_7561 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {DS_LINKED_LIST}.internal_cursor */
EIF_REFERENCE F1145_7562 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {DS_LINKED_LIST}.move_last_cursors_after */
void F1145_7563 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
	if ((EIF_BOOLEAN)(tr1 == loc4)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5252[Dtype(RTCW(loc1))-1039])(loc1);
	}
	loc3 = (EIF_REFERENCE) loc1;
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
	loc1 = (EIF_REFERENCE) tr1;
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		if ((EIF_BOOLEAN)(tr1 == loc4)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R5252[Dtype(RTCW(loc1))-1039])(loc1);
			loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5192[Dtype(RTCW(loc3))-1019])(loc3, loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5192[Dtype(RTCW(loc1))-1019])(loc1, NULL);
			loc1 = (EIF_REFERENCE) loc2;
		} else {
			loc3 = (EIF_REFERENCE) loc1;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			loc1 = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

/* {DS_LINKED_LIST}.move_all_cursors */
void F1145_7564 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		if ((EIF_BOOLEAN)(tr1 == arg1)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5251[Dtype(RTCW(loc1))-1039])(loc1, arg2);
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		loc1 = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {DS_LINKED_LIST}.move_all_cursors_after */
void F1145_7565 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5252[Dtype(RTCW(loc1))-1039])(loc1);
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5192[Dtype(RTCW(loc1))-1019])(loc1, NULL);
		loc1 = (EIF_REFERENCE) loc2;
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_item */
EIF_REFERENCE F1145_7566 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	RTCT0("not_off", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1617[Dtype(loc1)-152])(loc1);
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.cursor_index */
EIF_INTEGER_32 F1145_7567 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_1_);
	if (tb1) {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5761[Dtype(Current)-1144]) + ((EIF_INTEGER_32) 1L));
	} else {
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_0_);
		if ((EIF_BOOLEAN) !tb1) {
			loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN)(loc1 == loc2)) break;
				RTCT0("valid_cursor", EX_CHECK);
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1626[Dtype(loc1)-153]);
				loc1 = (EIF_REFERENCE) tr1;
				Result++;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.cursor_is_first */
EIF_BOOLEAN F1145_7568 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && (EIF_BOOLEAN)(loc1 == *(EIF_REFERENCE *)(Current + _REFACS_1_)));
}

/* {DS_LINKED_LIST}.cursor_is_last */
EIF_BOOLEAN F1145_7569 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && (EIF_BOOLEAN)(loc1 == *(EIF_REFERENCE *)(Current + _REFACS_2_)));
}

/* {DS_LINKED_LIST}.cursor_same_position */
EIF_BOOLEAN F1145_7570 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
	if ((EIF_BOOLEAN)(tr1 == tr2)) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_0_);
		tb3 = *(EIF_BOOLEAN *)(RTCW(arg2)+ _CHROFF_3_0_);
		tb1 = (EIF_BOOLEAN)(tb2 == tb3);
	}
	if (tb1) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_1_);
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg2)+ _CHROFF_3_1_);
		Result = (EIF_BOOLEAN)(tb1 == tb2);
	}
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.cursor_start */
void F1145_7571 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5611[dtype-1144])(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == NULL);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN)) R5254[Dtype(RTCW(arg1))-1039])(arg1, *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_BOOLEAN) 0, loc2);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc2 && loc1)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5614[dtype-1144])(Current, arg1);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_forth */
void F1145_7573 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc3 = *(EIF_REFERENCE *)(loc4 + O1626[Dtype(loc4)-153]);
	} else {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	}
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc3 == NULL);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN)) R5254[Dtype(RTCW(arg1))-1039])(arg1, loc3, (EIF_BOOLEAN) 0, loc2);
	if (loc2) {
		if ((EIF_BOOLEAN) !loc1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5615[dtype-1144])(Current, arg1);
		}
	} else {
		if (loc1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5614[dtype-1144])(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_search_forth */
void F1145_7575 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,tr2);
	RTLR(6,arg2);
	RTLR(7,tr3);
	RTLIU(8);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc1 == NULL);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(loc1 == NULL)) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1617[Dtype(RTCW(loc1))-152])(loc1);
				tr2 = RTCCL(tr1);
				tr3 = RTCCL(arg2);
				tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1979[Dtype(loc4)-225])(loc4, tr2, tr3);
				tb1 = tb2;
			}
			if (tb1) break;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1626[Dtype(loc1)-153]);
			loc1 = (EIF_REFERENCE) tr1;
		}
	} else {
		for (;;) {
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc1 == NULL)) {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1617[Dtype(RTCW(loc1))-152])(loc1);
				tb2 = RTCEQ(tr1, arg2);
			}
			if (tb2) break;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + O1626[Dtype(loc1)-153]);
			loc1 = (EIF_REFERENCE) tr1;
		}
	}
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc1 == NULL);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN)) R5254[Dtype(RTCW(arg1))-1039])(arg1, loc1, (EIF_BOOLEAN) 0, loc3);
	if (loc3) {
		if ((EIF_BOOLEAN) !loc2) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5615[dtype-1144])(Current, arg1);
		}
	} else {
		if (loc2) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5614[dtype-1144])(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_go_after */
void F1145_7577 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5611[dtype-1144])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R5252[Dtype(RTCW(arg1))-1039])(arg1);
	if ((EIF_BOOLEAN) !loc1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5615[dtype-1144])(Current, arg1);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_go_to */
void F1145_7579 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5611[dtype-1144])(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg2)+ _CHROFF_3_0_);
	tb2 = *(EIF_BOOLEAN *)(RTCW(arg2)+ _CHROFF_3_1_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN, EIF_BOOLEAN)) R5254[Dtype(RTCW(arg1))-1039])(arg1, tr1, tb1, tb2);
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R5187[Dtype(RTCW(arg1))-1019])(arg1);
	if ((EIF_BOOLEAN) !tb1) {
		if (loc1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5614[dtype-1144])(Current, arg1);
		}
	} else {
		if ((EIF_BOOLEAN) !loc1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5615[dtype-1144])(Current, arg1);
		}
	}
	RTLE;
}

void EIF_Minit541 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
