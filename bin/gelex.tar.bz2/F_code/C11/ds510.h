
#ifndef _C11_ds510_
#define _C11_ds510_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1154_7612(EIF_REFERENCE);
extern EIF_INTEGER_32 F1154_7614(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit510(void);
extern char *(*R5571[])();
extern char *(*R5774[])();

#ifdef __cplusplus
}
#endif

#endif
