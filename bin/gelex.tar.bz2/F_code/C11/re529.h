
#ifndef _C11_re529_
#define _C11_re529_

#ifdef __cplusplus
extern "C" {
#endif

extern void F390_3034(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F390_3036(EIF_REFERENCE);
extern EIF_INTEGER_32 F390_3037(EIF_REFERENCE);
extern EIF_INTEGER_32 F390_3038(EIF_REFERENCE);
extern EIF_INTEGER_32 F390_3039(EIF_REFERENCE);
extern EIF_BOOLEAN F390_3047(EIF_REFERENCE);
extern EIF_BOOLEAN F390_3048(EIF_REFERENCE);
extern void F390_3053(EIF_REFERENCE);
extern void EIF_Minit529(void);
extern char *(*R3078[])();
extern char *(*R3079[])();

#ifdef __cplusplus
}
#endif

#endif
