
#ifndef _C11_ds507_
#define _C11_ds507_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F999_6729(EIF_REFERENCE);
extern EIF_BOOLEAN F999_6731(EIF_REFERENCE);
extern void EIF_Minit507(void);
extern char *(*R5647[])();
extern char *(*R5186[])();
extern char *(*R2689[])();
extern char *(*R5204[])();

#ifdef __cplusplus
}
#endif

#endif
