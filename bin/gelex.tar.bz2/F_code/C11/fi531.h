
#ifndef _C11_fi531_
#define _C11_fi531_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F602_3219(EIF_REFERENCE);
extern void EIF_Minit531(void);
extern char *(*R2867[])();

#ifdef __cplusplus
}
#endif

#endif
