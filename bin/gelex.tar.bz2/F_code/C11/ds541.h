
#ifndef _C11_ds541_
#define _C11_ds541_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1145_7496(EIF_REFERENCE);
extern EIF_REFERENCE F1145_7502(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1145_7503(EIF_REFERENCE);
extern EIF_REFERENCE F1145_7504(EIF_REFERENCE);
extern EIF_REFERENCE F1145_7505(EIF_REFERENCE);
extern EIF_INTEGER_32 F1145_7506(EIF_REFERENCE);
extern EIF_BOOLEAN F1145_7508(EIF_REFERENCE, EIF_REFERENCE);
extern void F1145_7518(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1145_7519(EIF_REFERENCE, EIF_REFERENCE);
extern void F1145_7520(EIF_REFERENCE, EIF_REFERENCE);
extern void F1145_7522(EIF_REFERENCE, EIF_REFERENCE);
extern void F1145_7523(EIF_REFERENCE, EIF_REFERENCE);
extern void F1145_7524(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F1145_7531(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1145_7542(EIF_REFERENCE);
extern void F1145_7543(EIF_REFERENCE);
extern void F1145_7545(EIF_REFERENCE, EIF_REFERENCE);
extern void F1145_7556(EIF_REFERENCE);
extern void F1145_7559(EIF_REFERENCE, EIF_REFERENCE);
extern void F1145_7560(EIF_REFERENCE, EIF_REFERENCE);
extern void F1145_7561(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1145_7562(EIF_REFERENCE);
extern void F1145_7563(EIF_REFERENCE);
extern void F1145_7564(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1145_7565(EIF_REFERENCE);
extern EIF_REFERENCE F1145_7566(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1145_7567(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1145_7568(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1145_7569(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1145_7570(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1145_7571(EIF_REFERENCE, EIF_REFERENCE);
extern void F1145_7573(EIF_REFERENCE, EIF_REFERENCE);
extern void F1145_7575(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1145_7577(EIF_REFERENCE, EIF_REFERENCE);
extern void F1145_7579(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit541(void);
extern EIF_REFERENCE F932_5994(EIF_REFERENCE);
extern EIF_BOOLEAN F16_120(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,5994)
extern char *(*R5755[])();
extern char *(*R5756[])();
extern char *(*R5757[])();
extern char *(*R5758[])();
extern char *(*R5759[])();
extern char *(*R5251[])();
extern char *(*R5252[])();
extern char *(*R5254[])();
extern char *(*R5603[])();
extern char *(*R1619[])();
extern char *(*R5606[])();
extern char *(*R5608[])();
extern char *(*R5573[])();
extern char *(*R5187[])();
extern char *(*R1620[])();
extern char *(*R1979[])();
extern char *(*R5611[])();
extern char *(*R1627[])();
extern char *(*R1628[])();
extern char *(*R5615[])();
extern char *(*R5192[])();
extern char *(*R5199[])();
extern char *(*R5614[])();
extern char *(*R1617[])();
extern char *(*R5705[])();
extern char *(*R5706[])();
extern char *(*R5203[])();
extern char *(*R5249[])();
extern long O5761[];
extern long O1626[];
extern EIF_TYPE_INDEX Y5580[];
extern EIF_TYPE_INDEX *Y5580_gen_type [];
extern EIF_TYPE_INDEX Y5753[];
extern EIF_TYPE_INDEX *Y5753_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
