
#ifndef _C11_ds543_
#define _C11_ds543_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1081_7250(EIF_REFERENCE);
extern void EIF_Minit543(void);
extern char *(*R5571[])();

#ifdef __cplusplus
}
#endif

#endif
