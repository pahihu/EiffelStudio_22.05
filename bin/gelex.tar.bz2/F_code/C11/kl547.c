/*
 * Code for class KL_PART_COMPARATOR [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl547.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_PART_COMPARATOR}.less_than */
EIF_BOOLEAN F128_1386 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,tr2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	tr1 = RTCCL(arg1);
	tr2 = RTCCL(arg2);
	Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1357[Dtype(Current)-234])(Current, tr1, tr2);
	RTLE;
	return Result;
}

/* {KL_PART_COMPARATOR}.detachable_less_than */
EIF_BOOLEAN F128_1387 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == NULL)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN)(arg2 != NULL);
	} else {
		if ((EIF_BOOLEAN)(arg2 == NULL)) {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		} else {
			tr1 = RTCCL(arg1);
			tr2 = RTCCL(arg2);
			Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1358[Dtype(Current)-234])(Current, tr1, tr2);
		}
	}
	RTLE;
	return Result;
}

void EIF_Minit547 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
