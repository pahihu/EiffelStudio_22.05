
#ifndef _C10_kl453_
#define _C10_kl453_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F227_2144(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit453(void);

#ifdef __cplusplus
}
#endif

#endif
