
#ifndef _C10_kl465_
#define _C10_kl465_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F129_1386(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_BOOLEAN F129_1387(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit465(void);
extern EIF_BOOLEAN F236_2151(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
