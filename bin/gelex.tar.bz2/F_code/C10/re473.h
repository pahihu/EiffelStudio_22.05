
#ifndef _C10_re473_
#define _C10_re473_

#ifdef __cplusplus
extern "C" {
#endif

extern void F389_3034(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F389_3036(EIF_REFERENCE);
extern EIF_INTEGER_32 F389_3037(EIF_REFERENCE);
extern EIF_INTEGER_32 F389_3038(EIF_REFERENCE);
extern EIF_INTEGER_32 F389_3039(EIF_REFERENCE);
extern EIF_BOOLEAN F389_3047(EIF_REFERENCE);
extern EIF_BOOLEAN F389_3048(EIF_REFERENCE);
extern void F389_3053(EIF_REFERENCE);
extern void EIF_Minit473(void);
extern char *(*R3078[])();
extern char *(*R3079[])();

#ifdef __cplusplus
}
#endif

#endif
