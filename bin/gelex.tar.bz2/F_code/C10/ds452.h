
#ifndef _C10_ds452_
#define _C10_ds452_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1082_7250(EIF_REFERENCE);
extern void EIF_Minit452(void);
extern char *(*R5571[])();

#ifdef __cplusplus
}
#endif

#endif
