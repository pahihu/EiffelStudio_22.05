
#ifndef _C10_re491_
#define _C10_re491_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F627_3232(EIF_REFERENCE);
extern void EIF_Minit491(void);
extern EIF_INTEGER_32 F703_3698(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
