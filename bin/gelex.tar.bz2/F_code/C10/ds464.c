/*
 * Code for class DS_SORTABLE [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds464.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SORTABLE}.sort */
void F1092_7280 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F75_955(RTCW(arg1), Current);
}

void EIF_Minit464 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
