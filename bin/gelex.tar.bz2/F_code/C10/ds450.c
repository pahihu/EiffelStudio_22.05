/*
 * Code for class DS_ARRAYED_LIST [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds450.h"
#include "eif_built_in.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_ARRAYED_LIST}.make */
void F1160_7647 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y5794,Y5794_gen_type,Dftype(Current),1158).id);
	F1_29(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F21_267(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) arg1;
	tr1 = F1160_7656(Current);
	F1160_7705(Current, tr1);
	RTLE;
}

/* {DS_ARRAYED_LIST}.item */
EIF_INTEGER_32 F1160_7653 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L))));
	/* END INLINED CODE */
	Result = ti4_3;
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.first */
EIF_INTEGER_32 F1160_7654 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (((EIF_INTEGER_32) 0L)));
	/* END INLINED CODE */
	Result = ti4_2;
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.last */
EIF_INTEGER_32 F1160_7655 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) - ((EIF_INTEGER_32) 1L))));
	/* END INLINED CODE */
	Result = ti4_3;
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.new_cursor */
EIF_REFERENCE F1160_7656 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1038,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y5580,Y5580_gen_type,Dftype(Current),1080);
			typarr0[2] = l_type.annotations | 0xFF00;
			typarr0[3] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 1038, _OBJSIZ_2_0_0_1_0_0_0_0_);
	}
	F1039_6794(RTCW(tr1), Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {DS_ARRAYED_LIST}.count */
EIF_INTEGER_32 F1160_7657 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
}


/* {DS_ARRAYED_LIST}.capacity */
EIF_INTEGER_32 F1160_7658 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_);
}


/* {DS_ARRAYED_LIST}.has */
EIF_BOOLEAN F1160_7660 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			/* INLINED CODE (SPECIAL.item) */
			ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc1));
			/* END INLINED CODE */
			ti4_1 = ti4_2;
			tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1979[Dtype(loc2)-225])(loc2, (EIF_REFERENCE) &ti4_1, (EIF_REFERENCE) &arg1);
			if (tb1) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			} else {
				loc1--;
			}
		}
	} else {
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			/* INLINED CODE (SPECIAL.item) */
			ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc1));
			/* END INLINED CODE */
			ti4_1 = ti4_2;
			if ((EIF_BOOLEAN)(ti4_1 == arg1)) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			} else {
				loc1--;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.extendible */
EIF_BOOLEAN F1160_7661 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) >= (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) + arg1));
}

/* {DS_ARRAYED_LIST}.copy */
void F1160_7662 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1160_7707(Current);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			tb1 = F1096_7285(Current, loc1);
		}
		if (tb1) {
			F1160_7705(Current, loc1);
		} else {
			tr1 = F1160_7656(Current);
			F1160_7705(Current, tr1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (tr2);
		tr1 = F678_3629(RTCW(tr1), ti4_1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.is_equal */
EIF_BOOLEAN F1160_7663 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		tr1 = RTOSCF(5994,F932_5994, (Current));
		tb2 = F16_120(RTCW(tr1), Current, arg1);
		if (tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_1_);
			tb1 = (EIF_BOOLEAN)(ti4_1 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
		}
		if (tb1) {
			loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc1 > loc2))) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc1));
				/* END INLINED CODE */
				ti4_1 = ti4_2;
				/* INLINED CODE (SPECIAL.item) */
				ti4_3 = *((EIF_INTEGER_32 *)RTCW(loc3) + (loc1));
				/* END INLINED CODE */
				ti4_2 = ti4_3;
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
				loc1++;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.replace */
void F1160_7664 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)))) = arg1;
	/* END INLINED CODE */
	;
	RTLE;
}

/* {DS_ARRAYED_LIST}.put_first */
void F1160_7665 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	F1160_7667(Current, arg1, ((EIF_INTEGER_32) 1L));
}

/* {DS_ARRAYED_LIST}.put_last */
void F1160_7666 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F21_272(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))++;
	RTLE;
}

/* {DS_ARRAYED_LIST}.put */
void F1160_7667 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 == (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) + ((EIF_INTEGER_32) 1L)))) {
		F1160_7666(Current, arg1);
	} else {
		F1160_7702(Current, arg2, ((EIF_INTEGER_32) 1L));
		F1160_7710(Current, arg2, ((EIF_INTEGER_32) 1L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (arg2 - ((EIF_INTEGER_32) 1L)))) = arg1;
		/* END INLINED CODE */
		;
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.force_first */
void F1160_7670 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1160_7661(Current, ((EIF_INTEGER_32) 1L))) {
		ti4_1 = F1154_7614(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) + ((EIF_INTEGER_32) 1L)));
		F1160_7700(Current, ti4_1);
	}
	F1160_7667(Current, arg1, ((EIF_INTEGER_32) 1L));
	RTLE;
}

/* {DS_ARRAYED_LIST}.force_last */
void F1160_7671 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1160_7661(Current, ((EIF_INTEGER_32) 1L))) {
		ti4_1 = F1154_7614(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) + ((EIF_INTEGER_32) 1L)));
		F1160_7700(Current, ti4_1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F21_272(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))++;
	RTLE;
}

/* {DS_ARRAYED_LIST}.force */
void F1160_7672 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) !F1160_7661(Current, ((EIF_INTEGER_32) 1L))) {
		ti4_1 = F1154_7614(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) + ((EIF_INTEGER_32) 1L)));
		F1160_7700(Current, ti4_1);
	}
	F1160_7667(Current, arg1, arg2);
	RTLE;
}

/* {DS_ARRAYED_LIST}.extend_last */
void F1160_7676 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R5603[Dtype(RTCW(arg1))-1144])(arg1);
	F991_6721(RTCW(loc2));
	for (;;) {
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R2689[Dtype(RTCW(loc2))-401])(loc2);
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = (eif_optimize_return = 1, *(EIF_INTEGER_32 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R2688[Dtype(RTCW(loc2))-401])(loc2));
		F21_272(RTCW(tr1), tr2, ti4_1, loc1);
		loc1++;
		F991_6722(RTCW(loc2));
	}
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5571[Dtype(RTCW(arg1))-1144])(arg1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_)) += ti4_1;
	RTLE;
}

/* {DS_ARRAYED_LIST}.append_last */
void F1160_7681 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R5571[Dtype(RTCW(arg1))-1144])(arg1);
	if ((EIF_BOOLEAN) !F1160_7661(Current, loc1)) {
		ti4_1 = F1154_7614(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) + loc1));
		F1160_7700(Current, ti4_1);
	}
	F1160_7676(Current, arg1);
	RTLE;
}

/* {DS_ARRAYED_LIST}.remove_last */
void F1160_7686 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1160_7708(Current);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))--;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F678_3625(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	RTLE;
}

/* {DS_ARRAYED_LIST}.remove */
void F1160_7687 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))) {
		F1160_7686(Current);
	} else {
		F1160_7709(Current, (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)));
		F1160_7703(Current, (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)), ((EIF_INTEGER_32) 1L));
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		F678_3625(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.remove_at_cursor */
void F1160_7688 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = F1035_6776(RTCW(arg1));
	F1160_7687(Current, ti4_1);
	RTLE;
}

/* {DS_ARRAYED_LIST}.keep_first */
void F1160_7696 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1160_7707(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) = (EIF_INTEGER_32) arg1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F678_3625(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	RTLE;
}

/* {DS_ARRAYED_LIST}.wipe_out */
void F1160_7699 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1160_7707(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F678_3625(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {DS_ARRAYED_LIST}.resize */
void F1160_7700 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = F21_275(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) arg1;
	RTLE;
}

/* {DS_ARRAYED_LIST}.move_right */
void F1160_7702 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,tr3);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))) {
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + arg2) - ((EIF_INTEGER_32) 2L));
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			/* INLINED CODE (SPECIAL.item) */
			ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr3) + ((EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L))));
			/* END INLINED CODE */
			ti4_1 = ti4_3;
			F21_272(RTCW(tr1), tr2, ti4_1, loc1);
			loc1++;
		}
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + arg2) - ((EIF_INTEGER_32) 1L));
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			/* INLINED CODE (SPECIAL.item) */
			ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr3) + ((EIF_INTEGER_32) (loc1 - arg2)));
			/* END INLINED CODE */
			ti4_1 = ti4_3;
			F21_272(RTCW(tr1), tr2, ti4_1, loc1);
			loc1++;
		}
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg1 + arg2) - ((EIF_INTEGER_32) 1L));
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < loc2)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			/* INLINED CODE (SPECIAL.item) */
			ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr2) + ((EIF_INTEGER_32) (loc1 - arg2)));
			/* END INLINED CODE */
			ti4_1 = ti4_3;
			/* INLINED CODE (SPECIAL.put) */
			*((EIF_INTEGER_32 *)RTCW(tr1) + (loc1)) = ti4_1;
			/* END INLINED CODE */
			;
			loc1--;
		}
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_)) += arg2;
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.move_left */
void F1160_7703 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L));
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		/* INLINED CODE (SPECIAL.item) */
		ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr2) + (loc1));
		/* END INLINED CODE */
		ti4_1 = ti4_2;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 - arg2))) = ti4_1;
		/* END INLINED CODE */
		;
		loc1++;
	}
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_)) -= arg2;
	RTLE;
}

/* {DS_ARRAYED_LIST}.set_internal_cursor */
void F1160_7705 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {DS_ARRAYED_LIST}.internal_cursor */
EIF_REFERENCE F1160_7706 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {DS_ARRAYED_LIST}.move_all_cursors_after */
void F1160_7707 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		F1039_6801(RTCW(loc1));
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		F976_6710(RTCW(loc1), NULL);
		loc1 = (EIF_REFERENCE) loc2;
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.move_last_cursors_after */
void F1160_7708 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_0_0_0_);
	if ((EIF_BOOLEAN)(ti4_1 == loc1)) {
		F1039_6801(RTCW(loc2));
	}
	loc4 = (EIF_REFERENCE) loc2;
	tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
	loc2 = (EIF_REFERENCE) tr1;
	for (;;) {
		if ((EIF_BOOLEAN)(loc2 == NULL)) break;
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_1 == loc1)) {
			F1039_6801(RTCW(loc2));
			loc3 = *(EIF_REFERENCE *)(RTCW(loc2));
			F976_6710(RTCW(loc4), loc3);
			F976_6710(RTCW(loc2), NULL);
			loc2 = (EIF_REFERENCE) loc3;
		} else {
			loc4 = (EIF_REFERENCE) loc2;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
			loc2 = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.move_cursors_left */
void F1160_7709 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc2 == NULL)) break;
		loc1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_2_0_0_0_);
		if ((EIF_BOOLEAN) (loc1 >= (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)))) {
			F1039_6800(RTCW(loc2), (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
		loc2 = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.move_cursors_right */
void F1160_7710 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_2_0_0_0_);
		if ((EIF_BOOLEAN) (loc2 >= (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 1L)))) {
			F1039_6800(RTCW(loc1), (EIF_INTEGER_32) (loc2 + arg2));
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		loc1 = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.cursor_item */
EIF_INTEGER_32 F1160_7711 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (ti4_1));
	/* END INLINED CODE */
	Result = ti4_3;
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.cursor_index */
EIF_INTEGER_32 F1160_7712 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_1 = ((EIF_INTEGER_32) -2L);
	if ((EIF_BOOLEAN)(Result == ti4_1)) {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	}
	RTLE;
	return (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
}

/* {DS_ARRAYED_LIST}.cursor_is_first */
EIF_BOOLEAN F1160_7713 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN) !F1082_7250(Current)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		Result = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
	}
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.cursor_is_last */
EIF_BOOLEAN F1160_7714 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	if ((EIF_BOOLEAN) !F1082_7250(Current)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
		Result = (EIF_BOOLEAN)(ti4_1 == (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) - ((EIF_INTEGER_32) 1L)));
	}
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.cursor_same_position */
EIF_BOOLEAN F1160_7715 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_0_0_0_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	RTLE;
	return Result;
}

/* {DS_ARRAYED_LIST}.cursor_start */
void F1160_7716 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F999_6731(RTCW(arg1));
	if (F1082_7250(Current)) {
		F1039_6801(RTCW(arg1));
	} else {
		F1039_6800(RTCW(arg1), ((EIF_INTEGER_32) 0L));
		if (loc1) {
			F1096_7293(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.cursor_forth */
void F1160_7718 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) -1L));
	loc2++;
	if ((EIF_BOOLEAN) (loc2 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_))) {
		loc2 = ((EIF_INTEGER_32) -2L);
		if ((EIF_BOOLEAN) !loc1) {
			F1096_7294(Current, arg1);
		}
	} else {
		if (loc1) {
			F1096_7293(Current, arg1);
		}
	}
	F1039_6800(RTCW(arg1), loc2);
	RTLE;
}

/* {DS_ARRAYED_LIST}.cursor_search_forth */
void F1160_7720 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc3 = F999_6731(RTCW(arg1));
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_2_0_0_0_);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	ti4_1 = ((EIF_INTEGER_32) -2L);
	if ((EIF_BOOLEAN)(loc1 == ti4_1)) {
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		loc4 = tr1;
		if (EIF_TEST(loc4)) {
			for (;;) {
				tb1 = '\01';
				if (!(EIF_BOOLEAN) (loc1 > loc2)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					/* INLINED CODE (SPECIAL.item) */
					ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc1));
					/* END INLINED CODE */
					ti4_1 = ti4_2;
					tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE)) R1979[Dtype(loc4)-225])(loc4, (EIF_REFERENCE) &ti4_1, (EIF_REFERENCE) &arg2);
					tb1 = tb2;
				}
				if (tb1) break;
				loc1++;
			}
		} else {
			for (;;) {
				tb2 = '\01';
				if (!(EIF_BOOLEAN) (loc1 > loc2)) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					/* INLINED CODE (SPECIAL.item) */
					ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc1));
					/* END INLINED CODE */
					ti4_1 = ti4_2;
					tb2 = (EIF_BOOLEAN)(ti4_1 == arg2);
				}
				if (tb2) break;
				loc1++;
			}
		}
	}
	if ((EIF_BOOLEAN) (loc1 > loc2)) {
		F1039_6801(RTCW(arg1));
		if ((EIF_BOOLEAN) !loc3) {
			F1096_7294(Current, arg1);
		}
	} else {
		F1039_6800(RTCW(arg1), loc1);
		if (loc3) {
			F1096_7293(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.cursor_go_after */
void F1160_7722 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F999_6731(RTCW(arg1));
	F1039_6801(RTCW(arg1));
	if ((EIF_BOOLEAN) !loc1) {
		F1096_7294(Current, arg1);
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.cursor_go_to */
void F1160_7724 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = F999_6731(RTCW(arg1));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_0_0_0_);
	F1039_6800(RTCW(arg1), ti4_1);
	tb1 = F999_6731(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		if (loc1) {
			F1096_7293(Current, arg1);
		}
	} else {
		if ((EIF_BOOLEAN) !loc1) {
			F1096_7294(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.correct_mismatch */
void F1160_7726 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(3863,F772_3863, (Current))) + _REFACS_7_);
	loc2 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc2))) {
		tb2 = F914_5820(loc2);
		tb1 = tb2;
	}
	if (tb1) {
		F1160_7727(Current);
	} else {
		tb1 = F907_5485(loc2);
		if (tb1) {
			loc1 = F907_5519(loc2);
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 20130823L))) {
				F1160_7727(Current);
			} else {
				F772_3862(Current);
			}
		} else {
			F772_3862(Current);
		}
	}
	RTLE;
}

/* {DS_ARRAYED_LIST}.correct_mismatch_20130823 */
void F1160_7727 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	/* INLINED CODE (SPECIAL.overlapping_move) */
	memmove((EIF_INTEGER_32 *)RTCW(tr1) + (((EIF_INTEGER_32) 0L)),(EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) 1L), (rt_uint_ptr)sizeof(EIF_INTEGER_32) * (rt_uint_ptr)*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	RT_SPECIAL_COUNT(tr1) = eif_max_int32(RT_SPECIAL_COUNT(tr1), ((EIF_INTEGER_32) 0L) + *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	/* END INLINED CODE */
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	F678_3625(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (tr1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

void EIF_Minit450 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
