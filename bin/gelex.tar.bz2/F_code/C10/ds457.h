
#ifndef _C10_ds457_
#define _C10_ds457_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F976_6701(EIF_REFERENCE);
extern EIF_BOOLEAN F976_6704(EIF_REFERENCE, EIF_REFERENCE);
extern void F976_6706(EIF_REFERENCE, EIF_REFERENCE);
extern void F976_6707(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F976_6708(EIF_REFERENCE, EIF_REFERENCE);
extern void F976_6710(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit457(void);
extern void F1096_7293(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F932_5994(EIF_REFERENCE);
extern void F1096_7294(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F16_120(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,5994)
extern char *(*R5186[])();
extern char *(*R5187[])();
extern char *(*R5188[])();
extern char *(*R5610[])();
extern char *(*R5612[])();
extern char *(*R5613[])();

#ifdef __cplusplus
}
#endif

#endif
