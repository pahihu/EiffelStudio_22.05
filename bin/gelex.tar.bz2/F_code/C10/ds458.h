
#ifndef _C10_ds458_
#define _C10_ds458_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1096_7281(EIF_REFERENCE);
extern EIF_BOOLEAN F1096_7283(EIF_REFERENCE);
extern EIF_BOOLEAN F1096_7285(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1096_7290(EIF_REFERENCE, EIF_REFERENCE);
extern void F1096_7293(EIF_REFERENCE, EIF_REFERENCE);
extern void F1096_7294(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit458(void);
extern void F976_6710(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5609[])();
extern char *(*R5186[])();
extern char *(*R5187[])();
extern char *(*R5610[])();

#ifdef __cplusplus
}
#endif

#endif
