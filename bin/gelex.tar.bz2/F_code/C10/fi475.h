
#ifndef _C10_fi475_
#define _C10_fi475_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F601_3219(EIF_REFERENCE);
extern void EIF_Minit475(void);
extern char *(*R2867[])();

#ifdef __cplusplus
}
#endif

#endif
