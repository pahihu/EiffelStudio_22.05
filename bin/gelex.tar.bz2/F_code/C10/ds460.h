
#ifndef _C10_ds460_
#define _C10_ds460_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1035_6776(EIF_REFERENCE);
extern void F1035_6788(EIF_REFERENCE);
extern void EIF_Minit460(void);
extern char *(*R5186[])();
extern char *(*R5737[])();
extern char *(*R5747[])();

#ifdef __cplusplus
}
#endif

#endif
