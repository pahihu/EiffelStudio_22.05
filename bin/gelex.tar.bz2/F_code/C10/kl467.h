
#ifndef _C10_kl467_
#define _C10_kl467_

#ifdef __cplusplus
extern "C" {
#endif

extern void F715_3743(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit467(void);

#ifdef __cplusplus
}
#endif

#endif
