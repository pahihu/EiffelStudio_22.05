
#ifndef _C10_co470_
#define _C10_co470_

#ifdef __cplusplus
extern "C" {
#endif

extern void F458_3121(EIF_REFERENCE);
extern void EIF_Minit470(void);
extern long O2805[];

#ifdef __cplusplus
}
#endif

#endif
