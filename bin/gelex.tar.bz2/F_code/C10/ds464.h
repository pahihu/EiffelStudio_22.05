
#ifndef _C10_ds464_
#define _C10_ds464_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1092_7280(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit464(void);
extern void F75_955(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
