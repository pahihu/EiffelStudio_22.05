
#ifndef _C10_ds451_
#define _C10_ds451_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1102_7298(EIF_REFERENCE, EIF_REFERENCE);
extern void F1102_7302(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit451(void);

#ifdef __cplusplus
}
#endif

#endif
