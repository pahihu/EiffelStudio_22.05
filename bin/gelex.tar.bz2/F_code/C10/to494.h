
#ifndef _C10_to494_
#define _C10_to494_

#ifdef __cplusplus
extern "C" {
#endif

extern void F249_2420(EIF_REFERENCE, EIF_INTEGER_32);
extern void F249_2421(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F249_2427(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit494(void);
extern void F678_3597(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2242[];
extern EIF_TYPE_INDEX *Y2242_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
