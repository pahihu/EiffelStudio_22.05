
#ifndef _C1_do48_
#define _C1_do48_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REAL_64 F87_997(EIF_REFERENCE, EIF_REAL_64);
extern void EIF_Minit48(void);

#ifdef __cplusplus
}
#endif

#endif
