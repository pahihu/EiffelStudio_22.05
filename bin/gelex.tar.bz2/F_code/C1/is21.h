
#ifndef _C1_is21_
#define _C1_is21_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F30_360(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F30_365(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F30_367(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F30_375(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit21(void);

#ifdef __cplusplus
}
#endif

#endif
