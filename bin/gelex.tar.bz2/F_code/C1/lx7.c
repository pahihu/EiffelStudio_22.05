/*
 * Code for class LX_ACTION_FACTORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx7.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_ACTION_FACTORY}.make */
void F7_75 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {LX_ACTION_FACTORY}.new_action */
EIF_REFERENCE F7_76 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(108, 0x01).id, 108, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F109_1156(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

void EIF_Minit7 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
