/*
 * Code for class UT_ARRAY_FORMATTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ut8.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UT_ARRAY_FORMATTER}.put_integer_array */
void F8_77 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(81,F8_81, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc1 = (EIF_INTEGER_32) arg3;
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > arg4)) break;
		loc4++;
		if ((EIF_BOOLEAN) (loc4 > ((EIF_INTEGER_32) 10L))) {
			F927_5969(RTCW(arg1));
			loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc3++;
			if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 10L))) {
				F927_5969(RTCW(arg1));
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			}
			tr1 = RTOSCF(81,F8_81, (Current));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
		}
		loc2 = F703_3690(RTCW(arg2), loc1);
		tr1 = eif_out__i4_s1(loc2);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
		switch (ti4_1) {
			case 1L:
				tr1 = RTOSCF(80,F8_80, (Current));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
				break;
			case 2L:
				tr1 = RTOSCF(79,F8_79, (Current));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
				break;
			case 3L:
				tr1 = RTOSCF(78,F8_78, (Current));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
				break;
			default:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) ' ');
				break;
		}
		F924_5951(RTCW(arg1), loc2);
		if ((EIF_BOOLEAN) (loc1 < arg4)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) ',');
		}
		loc1++;
	}
	RTLE;
}

/* {UT_ARRAY_FORMATTER}.two_spaces */

EIF_REFERENCE F8_78 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (78,RTMS_EX_H("  ",2,8224));
}

/* {UT_ARRAY_FORMATTER}.three_spaces */

EIF_REFERENCE F8_79 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (79,RTMS_EX_H("   ",3,2105376));
}

/* {UT_ARRAY_FORMATTER}.four_spaces */

EIF_REFERENCE F8_80 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (80,RTMS_EX_H("    ",4,538976288));
}

/* {UT_ARRAY_FORMATTER}.indentation */

EIF_REFERENCE F8_81 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (81,RTMS_EX_H("\011\011\011",3,592137));
}

void EIF_Minit8 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
