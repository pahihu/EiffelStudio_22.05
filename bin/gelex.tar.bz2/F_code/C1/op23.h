
#ifndef _C1_op23_
#define _C1_op23_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F44_553(EIF_REFERENCE);
extern void EIF_Minit23(void);

#ifdef __cplusplus
}
#endif

#endif
