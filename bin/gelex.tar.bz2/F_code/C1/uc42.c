/*
 * Code for class UC_UNICODE_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uc42.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UC_UNICODE_CONSTANTS}.bom_character */
static EIF_CHARACTER_32 F67_878_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (878);
#define Result RTOSR(878)
	Result = (EIF_CHARACTER_32) ((EIF_INTEGER_32) 65279L);
	RTOSE (878);
	RTEE;
	return Result;
#undef Result
}

EIF_CHARACTER_32 F67_878 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(878,F67_878_body,(Current));
}

void EIF_Minit42 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
