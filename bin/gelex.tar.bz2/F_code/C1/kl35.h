
#ifndef _C1_kl35_
#define _C1_kl35_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,825)
static EIF_REFERENCE F60_825_body(EIF_REFERENCE);
extern EIF_REFERENCE F60_825(EIF_REFERENCE);
extern void EIF_Minit35(void);

#ifdef __cplusplus
}
#endif

#endif
