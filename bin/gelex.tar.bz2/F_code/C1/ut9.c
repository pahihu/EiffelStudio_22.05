/*
 * Code for class UT_BOOLEAN_FORMATTER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ut9.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UT_BOOLEAN_FORMATTER}.put_eiffel_boolean */
void F9_86 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (arg2) {
		tr1 = RTOSCF(87,F9_87, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	} else {
		tr1 = RTOSCF(88,F9_88, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	}
	RTLE;
}

/* {UT_BOOLEAN_FORMATTER}.true_string */

EIF_REFERENCE F9_87 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (87,RTMS_EX_H("true",4,1953658213));
}

/* {UT_BOOLEAN_FORMATTER}.false_string */

EIF_REFERENCE F9_88 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (88,RTMS_EX_H("false",5,1635280741));
}

void EIF_Minit9 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
