
#ifndef _C1_uc42_
#define _C1_uc42_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_CHARACTER_32,878)
static EIF_CHARACTER_32 F67_878_body(EIF_REFERENCE);
extern EIF_CHARACTER_32 F67_878(EIF_REFERENCE);
extern void EIF_Minit42(void);

#ifdef __cplusplus
}
#endif

#endif
