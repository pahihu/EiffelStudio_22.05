
#ifndef _C1_lx7_
#define _C1_lx7_

#ifdef __cplusplus
extern "C" {
#endif

extern void F7_75(EIF_REFERENCE);
extern EIF_REFERENCE F7_76(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit7(void);
extern void F109_1156(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
