
#ifndef _C1_uc43_
#define _C1_uc43_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,940)
static EIF_REFERENCE F68_940_body(EIF_REFERENCE);
extern EIF_REFERENCE F68_940(EIF_REFERENCE);
extern void EIF_Minit43(void);

#ifdef __cplusplus
}
#endif

#endif
