
#ifndef _C1_lx26_
#define _C1_lx26_

#ifdef __cplusplus
extern "C" {
#endif

extern void F47_638(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit26(void);

#ifdef __cplusplus
}
#endif

#endif
