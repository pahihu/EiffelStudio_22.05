
#ifndef _C1_ut9_
#define _C1_ut9_

#ifdef __cplusplus
extern "C" {
#endif

extern void F9_86(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);RTOSHF (EIF_REFERENCE, 87)


extern EIF_REFERENCE F9_87(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 88)


extern EIF_REFERENCE F9_88(EIF_REFERENCE);
extern void EIF_Minit9(void);
extern char *(*R4567[])();

#ifdef __cplusplus
}
#endif

#endif
