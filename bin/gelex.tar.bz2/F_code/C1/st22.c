/*
 * Code for class STD_FILES
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "st22.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {STD_FILES}.input */
static EIF_REFERENCE F43_469_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (469);
#define Result RTOSR(469)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(953, 0x01).id, 953, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stdin",5,1953620846);
	F954_6239(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (469);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_469 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(469,F43_469_body,(Current));
}

/* {STD_FILES}.output */
static EIF_REFERENCE F43_470_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (470);
#define Result RTOSR(470)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(953, 0x01).id, 953, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stdout",6,1912016244);
	F954_6240(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (470);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_470 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(470,F43_470_body,(Current));
}

/* {STD_FILES}.error */
static EIF_REFERENCE F43_471_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (471);
#define Result RTOSR(471)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(953, 0x01).id, 953, _OBJSIZ_5_7_2_4_1_1_2_1_);
	tr2 = RTMS_EX_H("stderr",6,1911360114);
	F954_6241(RTCW(tr1), tr2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (471);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F43_471 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(471,F43_471_body,(Current));
}

/* {STD_FILES}.set_output_default */
void F43_497 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(470,F43_470, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

void EIF_Minit22 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
