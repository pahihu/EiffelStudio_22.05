/*
 * Code for class LX_DESCRIPTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx25.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_DESCRIPTION}.make */
void F46_567 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_4_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_5_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_22_0_1_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 1114111L) - ((EIF_INTEGER_32) 2048L));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_22_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 200L);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_18_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_10_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,162,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1159_7647(RTCW(tr1), ((EIF_INTEGER_32) 250L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,162,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1159_7647(RTCW(tr1), ((EIF_INTEGER_32) 40L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,914,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1159_7647(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1160, 1).id);
	F1161_7728(RTCW(tr1), ((EIF_INTEGER_32) 40L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {LX_DESCRIPTION}.set_array_size */
void F46_594 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_22_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {LX_DESCRIPTION}.set_backing_up_report */
void F46_595 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_0_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_case_insensitive */
void F46_597 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_1_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_maximum_symbol */
void F46_598 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_22_0_1_) = (EIF_INTEGER_32) arg1;
}

/* {LX_DESCRIPTION}.set_utf8_mode */
void F46_599 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_2_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_debug_mode */
void F46_600 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_3_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_equiv_classes_used */
void F46_601 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_4_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_meta_equiv_classes_used */
void F46_602 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_5_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_full_table */
void F46_603 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_6_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_no_default_rule */
void F46_604 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_7_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_no_warning */
void F46_605 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_8_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_actions_separated */
void F46_606 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_9_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_inspect_used */
void F46_607 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_10_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_reject_used */
void F46_608 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_11_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_line_used */
void F46_609 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_12_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_position_used */
void F46_610 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_13_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_pre_action_used */
void F46_611 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_14_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_post_action_used */
void F46_612 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_15_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_pre_eof_action_used */
void F46_613 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_16_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_post_eof_action_used */
void F46_614 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_17_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_line_pragma */
void F46_615 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_18_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_input_filename */
void F46_616 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {LX_DESCRIPTION}.set_output_filename */
void F46_617 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
}

/* {LX_DESCRIPTION}.set_equiv_classes */
void F46_630 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) arg1;
}

/* {LX_DESCRIPTION}.set_bol_needed */
void F46_631 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_19_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_variable_trail_context */
void F46_632 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_20_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_has_utf8_enconding */
void F46_633 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_21_) = (EIF_BOOLEAN) arg1;
}

/* {LX_DESCRIPTION}.set_eiffel_code */
void F46_634 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) arg1;
}

void EIF_Minit25 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
