
#ifndef _C1_kl40_
#define _C1_kl40_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,871)
static EIF_REFERENCE F65_871_body(EIF_REFERENCE);
extern EIF_REFERENCE F65_871(EIF_REFERENCE);
extern void EIF_Minit40(void);

#ifdef __cplusplus
}
#endif

#endif
