/*
 * Code for class KL_OPERATING_SYSTEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl3.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_OPERATING_SYSTEM}.is_windows */
static EIF_BOOLEAN F3_54_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	RTLD;
	

	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc3);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTEV;
	RTGC;
	RTOSP (54);
#define Result RTOSR(54)
	tr1 = RTMS_EX_H("GOBO_OS",7,715786835);
	loc2 = F3_58(Current, tr1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		tr1 = RTMS_EX_H("windows",7,1657536371);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc2))-2])(loc2, tr1);
		if (tb1) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	} else {
		tr1 = RTMS_EX_H("OS",2,20307);
		loc3 = F3_58(Current, tr1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			tr1 = RTMS_EX_H("Windows_NT",10,121334100);
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc3))-2])(loc3, tr1);
			tb1 = tb2;
		}
		if (tb1) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		} else {
			loc1 = F3_57(Current);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 3L))) {
				tb1 = '\0';
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(loc1))-676])(loc1, ((EIF_INTEGER_32) 2L)));
				if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) ':')) {
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(loc1))-676])(loc1, ((EIF_INTEGER_32) 3L)));
					tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\\');
				}
				if (tb1) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					tb1 = '\0';
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(loc1))-676])(loc1, ((EIF_INTEGER_32) 1L)));
					if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\\')) {
						tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(loc1))-676])(loc1, ((EIF_INTEGER_32) 2L)));
						tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '\\');
					}
					if (tb1) {
						Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
			}
		}
	}
	RTOSE (54);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F3_54 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(54,F3_54_body,(Current));
}

/* {KL_OPERATING_SYSTEM}.is_unix */
static EIF_BOOLEAN F3_55_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	

	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTEV;
	RTGC;
	RTOSP (55);
#define Result RTOSR(55)
	tr1 = RTMS_EX_H("GOBO_OS",7,715786835);
	loc2 = F3_58(Current, tr1);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_1_1_0_2_);
		tb1 = (EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L));
	}
	if (tb1) {
		tr1 = RTMS_EX_H("unix",4,1970170232);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc2))-2])(loc2, tr1);
		if (tb1) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
	} else {
		loc1 = F3_57(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(loc1))-676])(loc1, ((EIF_INTEGER_32) 1L)));
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '/');
		}
	}
	RTOSE (55);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_BOOLEAN F3_55 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(55,F3_55_body,(Current));
}

/* {KL_OPERATING_SYSTEM}.current_working_directory */
EIF_REFERENCE F3_57 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = F261_2432(RTCV(RTOSCF(59,F3_59, (Current))));
	Result = F796_4136(RTCW(tr1));
	RTLE;
	return Result;
}

/* {KL_OPERATING_SYSTEM}.variable_value */
EIF_REFERENCE F3_58 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOSCF(59,F3_59, (Current));
	tr1 = F261_2436(RTCW(tr1), arg1);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		tb1 = F910_5616(loc1);
		if (tb1) {
			tr1 = F907_5507(loc1);
			RTLE;
			return (EIF_REFERENCE) tr1;
		} else {
			tr1 = RTLNS(eif_new_type(937, 0x01).id, 937, _OBJSIZ_0_0_0_0_0_0_0_0_);
			Result = F938_6127(RTCW(tr1), loc1);
		}
	}
	RTLE;
	return Result;
}

/* {KL_OPERATING_SYSTEM}.execution_environment */
static EIF_REFERENCE F3_59_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (59);
#define Result RTOSR(59)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(260, 0x01).id, 260, _OBJSIZ_0_0_0_1_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (59);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F3_59 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(59,F3_59_body,(Current));
}

void EIF_Minit3 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
