
#ifndef _C1_lx27_
#define _C1_lx27_

#ifdef __cplusplus
extern "C" {
#endif

extern void F48_643(EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit27(void);

#ifdef __cplusplus
}
#endif

#endif
