
#ifndef _C1_lx24_
#define _C1_lx24_

#ifdef __cplusplus
extern "C" {
#endif

extern void F45_556(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_BOOLEAN);
extern void F45_563(EIF_REFERENCE, EIF_BOOLEAN);
extern void F45_564(EIF_REFERENCE, EIF_REFERENCE);
extern void F45_565(EIF_REFERENCE, EIF_REFERENCE);
extern void F45_566(EIF_REFERENCE, EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit24(void);
extern void F1159_7671(EIF_REFERENCE, EIF_REFERENCE);
extern void F1159_7647(EIF_REFERENCE, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
