/*
 * Code for class KL_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl309.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_FILE}.make */
void F1049_6904 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + O5332[Dtype(Current)-1048]) = (EIF_REFERENCE) arg1;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
		tr1 = RTOSCF(5917,F917_5917, (Current));
		tr1 = F936_6067(RTCW(tr1), arg1);
		F662_3244(Current, tr1);
	} else {
		tr1 = RTOSCF(6918,F1049_6918, (Current));
		F662_3244(Current, tr1);
	}
	RTLE;
}

/* {KL_FILE}.name */
EIF_REFERENCE F1049_6905 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + O5332[Dtype(Current)-1048]);
}


/* {KL_FILE}.is_closed */
EIF_BOOLEAN F1049_6910 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F662_3304(Current);
}

/* {KL_FILE}.close */
#undef EIF_VOLATILE
#define EIF_VOLATILE volatile
void F1049_6912 (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	RTED;
	EIF_BOOLEAN EIF_VOLATILE loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE EIF_VOLATILE saved_except = (EIF_REFERENCE) 0;
	RTLD;
	RTXD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,saved_except);
	RTLIU(2);
	RTXSLS;
	
	RTEV;
	RTGC;
	RTE_T
	if ((EIF_BOOLEAN) !loc1) {
		F662_3332(Current);
	}
	RTE_E
	RTXSC;
	if ((EIF_BOOLEAN) !loc1) {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		RTER;
	}
	/* NOTREACHED */
	RTE_EE
	RTEOK;
	RTLE;
}
#undef EIF_VOLATILE
#define EIF_VOLATILE

/* {KL_FILE}.empty_name */

EIF_REFERENCE F1049_6918 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6918,RTMS_EX_H("empty_name",10,696498789));
}

void EIF_Minit309 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
