/*
 * Code for class KL_UNIX_FILE_SYSTEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl345.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_UNIX_FILE_SYSTEM}.is_root_directory */
EIF_BOOLEAN F1189_8127 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, loc1));
			if ((EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '/')) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
			} else {
				loc1++;
			}
		}
	}
	RTLE;
	return Result;
}

/* {KL_UNIX_FILE_SYSTEM}.basename */
EIF_REFERENCE F1189_8132 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (F1189_8127(Current, arg1)) {
		RTLE;
		return (EIF_REFERENCE) RTOSCF(8139,F1189_8139, (Current));
	} else {
		loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) {
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, loc1));
				tb1 = (EIF_BOOLEAN)(tc1 != (EIF_CHARACTER_8) '/');
			}
			if (tb1) break;
			loc1--;
		}
		loc2 = (EIF_INTEGER_32) loc1;
		for (;;) {
			tb2 = '\01';
			if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) {
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, loc1));
				tb2 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '/');
			}
			if (tb2) break;
			loc1--;
		}
		tb3 = '\0';
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			tb3 = (EIF_BOOLEAN)(loc2 == ti4_1);
		}
		if (tb3) {
			RTLE;
			return (EIF_REFERENCE) arg1;
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4338[Dtype(RTCW(arg1))-910])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), loc2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}/* NOTREACHED */
	
}

/* {KL_UNIX_FILE_SYSTEM}.root_directory */
static EIF_REFERENCE F1189_8139_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (8139);
#define Result RTOSR(8139)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("/",1,47);
	RTOSE (8139);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1189_8139 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(8139,F1189_8139_body,(Current));
}

void EIF_Minit345 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
