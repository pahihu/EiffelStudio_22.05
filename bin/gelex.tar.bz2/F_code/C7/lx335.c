/*
 * Code for class LX_FULL_DFA
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx335.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_FULL_DFA}.make */
void F1076_7219 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F1074_7139(Current, arg1);
	F1074_7140(Current);
	F1076_7225(Current);
	RTLE;
}

/* {LX_FULL_DFA}.print_backing_up_report */
void F1076_7221 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1074_7143(Current, arg1);
	switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_8_)) {
		case 0L:
			tr1 = RTMS_EX_H("No backing up.\012",15,1577112330);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			break;
		case 1L:
			F924_5951(RTCW(arg1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_8_));
			tr1 = RTMS_EX_H(" backing up (non-accepting) state.\012",35,1440045322);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			break;
		default:
			F924_5951(RTCW(arg1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_8_));
			tr1 = RTMS_EX_H(" backing up (non-accepting) states.\012",36,1437086474);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			break;
	}
	RTLE;
}

/* {LX_FULL_DFA}.print_build_tables */
void F1076_7222 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("\011yy_build_tables\012\011\011\011-- Build scanner tables.\012\011\011do\012",50,1458749450);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTOSCF(7177,F1074_7177, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTMS_EX_H("yy_nxt := yy_nxt_template\012",26,1686686218);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL)) {
		tr1 = RTOSCF(7177,F1074_7177, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
		tr1 = RTMS_EX_H("yy_ec := yy_ec_template\012",24,98572554);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	}
	tr1 = RTOSCF(7177,F1074_7177, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTMS_EX_H("yy_accept := yy_accept_template\012",32,1795444234);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTMS_EX_H("\011\011end\012",6,1719497226);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	RTLE;
}

/* {LX_FULL_DFA}.print_eiffel_tables */
void F1076_7223 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = RTMS_EX_H("yy_nxt_template",15,1515781477);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1074_7158(Current, tr1, tr2, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
		tr1 = RTMS_EX_H("yy_ec_template",14,225934181);
		F1074_7158(Current, tr1, loc1, arg1);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
	tr1 = RTMS_EX_H("yy_accept_template",18,184292709);
	tr2 = *(EIF_REFERENCE *)(Current);
	F1074_7158(Current, tr1, tr2, arg1);
	RTLE;
}

/* {LX_FULL_DFA}.print_constants */
void F1076_7224 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("\011yyNull_equiv_class: INTEGER = ",31,103596064);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	F924_5951(RTCW(arg1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_2_));
	tr1 = RTMS_EX_H("\012\011\011\011-- Equivalence code for NULL character\012\012\011yyMax_symbol_equiv_class: INTEGER = ",81,1148189216);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	F924_5951(RTCW(arg1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_3_));
	tr1 = RTMS_EX_H("\012\011\011\011-- All symbols greater than this symbol will have\012\011\011\011-- the same equivalence class as this symbol\012\012\011yyNb_rows: INTEGER = ",125,2071241248);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	F924_5951(RTCW(arg1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_4_));
	tr1 = RTMS_EX_H("\012\011\011\011-- Number of rows in `yy_nxt\'\012\012\011yyBacking_up: BOOLEAN = ",60,1124942880);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTOSCF(2134,F222_2134, (Current));
	F9_86(RTCW(tr1), arg1, *(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_));
	tr1 = RTMS_EX_H("\012\011\011\011-- Does current scanner back up\?\012\011\011\011-- (i.e. does it have non-accepting states)\012\012",85,236275466);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	F1074_7156(Current, arg1);
	RTLE;
}

/* {LX_FULL_DFA}.build */
void F1076_7225 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_8_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = RTLNSMART(eif_new_type(96, 0).id);
	F97_1070(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_6_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_7_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_5_))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc2 = F1159_7653(RTCW(tr1), loc1);
		F1073_7134(Current, loc2);
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc2 = F1159_7653(RTCW(tr1), loc1);
	F1073_7134(Current, loc2);
	loc1++;
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc2 = F1159_7653(RTCW(tr1), loc1);
		F1073_7134(Current, loc2);
		tb1 = F1070_7081(RTCW(loc2));
		if ((EIF_BOOLEAN) !tb1) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_8_))++;
		}
		loc1++;
	}
	*(EIF_BOOLEAN *)(Current+ _CHROFF_11_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_8_) > ((EIF_INTEGER_32) 0L));
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
	F1076_7226(Current);
	F1076_7227(Current);
	RTLE;
}

/* {LX_FULL_DFA}.build_nxt_table */
void F1076_7226 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLR(4,loc7);
	RTLR(5,loc6);
	RTLIU(6);
	
	RTGC;
	loc9 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_6_);
	loc10 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_7_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_4_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc10 + ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN)(loc9 == ((EIF_INTEGER_32) 0L))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_4_))++;
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,702,834,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 702, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	F703_3685(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_4_) * (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L))) - ((EIF_INTEGER_32) 1L)));
	loc8 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_5_);
	loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_11_12_0_4_);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		if ((EIF_BOOLEAN) (loc2 > ti4_1)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc5 = F1159_7653(RTCW(tr1), loc2);
		loc7 = *(EIF_REFERENCE *)(RTCW(loc5) + _REFACS_3_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_4_0_0_0_);
		if ((EIF_BOOLEAN)(ti4_2 == loc8)) {
			F703_3709(RTCW(loc1), (EIF_INTEGER_32) -loc8, loc3);
		} else {
			F703_3709(RTCW(loc1), loc8, loc3);
		}
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc3++;
		for (;;) {
			if ((EIF_BOOLEAN) (loc4 > loc10)) break;
			if ((EIF_BOOLEAN) (loc4 >= loc9)) {
				loc6 = F1067_7040(RTCW(loc7), loc4);
				if ((EIF_BOOLEAN)(loc6 != NULL)) {
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_4_0_0_0_);
					F703_3709(RTCW(loc1), ti4_2, loc3);
				} else {
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_4_0_0_0_);
					F703_3709(RTCW(loc1), (EIF_INTEGER_32) -ti4_2, loc3);
				}
			}
			loc4++;
			loc3++;
		}
		if ((EIF_BOOLEAN)(loc9 == ((EIF_INTEGER_32) 0L))) {
			loc6 = F1067_7040(RTCW(loc7), loc9);
			if ((EIF_BOOLEAN)(loc6 != NULL)) {
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_4_0_0_0_);
				F703_3709(RTCW(loc1), ti4_2, loc3);
			} else {
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_4_0_0_0_);
				F703_3709(RTCW(loc1), (EIF_INTEGER_32) -ti4_2, loc3);
			}
		}
		loc3++;
		loc2++;
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) loc1;
	RTLE;
}

/* {LX_FULL_DFA}.build_accept_table */
void F1076_7227 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc4);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,702,834,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 702, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F703_3685(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc3);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc4 = F1159_7653(RTCW(tr1), loc2);
		tb1 = F1070_7081(RTCW(loc4));
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_1_);
			tr1 = F1159_7654(RTCW(tr1));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_2_0_0_);
			F703_3709(RTCW(loc1), ti4_1, loc2);
		} else {
			F703_3709(RTCW(loc1), ((EIF_INTEGER_32) 0L), loc2);
		}
		loc2++;
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc1;
	RTLE;
}

void EIF_Minit335 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
