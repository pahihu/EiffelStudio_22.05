/*
 * Code for class YY_COMPRESSED_SCANNER_SKELETON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "yy300.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {YY_COMPRESSED_SCANNER_SKELETON}.yy_initialize */
void F970_6557 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	F968_6466(Current);
	tr1 = RTOSCF(2620,F268_2620, (Current));
	tr2 = *(EIF_REFERENCE *)(Current);
	tr2 = *(EIF_REFERENCE *)(RTCW(tr2));
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1013[Dtype(RTCW(tr2))-269])(tr2);
	tr1 = F21_267(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {YY_COMPRESSED_SCANNER_SKELETON}.read_token */
void F970_6559 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc9 = (EIF_NATURAL_32) 0;
	EIF_BOOLEAN loc10 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc14 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc15);
	RTLR(3,loc16);
	RTLR(4,loc17);
	RTLR(5,tr2);
	RTLR(6,loc18);
	RTLR(7,loc19);
	RTLIU(8);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -2L);
	loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_2_) != ((EIF_INTEGER_32) -2L))) break;
		switch (loc7) {
			case 1L:
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_64_1_)) {
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_9_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_4_) - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_5_));
					*(EIF_BOOLEAN *)(Current+ _CHROFF_64_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				} else {
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_9_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_15_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_6_);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_14_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_7_);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_13_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_8_);
				}
				loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_4_);
				loc2 = (EIF_INTEGER_32) loc1;
				loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_3_);
				ti4_1 = F968_6508(Current);
				loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ti4_1);
				tr1 = RTOSCF(2620,F268_2620, (Current));
				F21_272(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_13_), loc3, ((EIF_INTEGER_32) 0L));
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_16_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
				break;
			case 2L:
				loc15 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc16 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
				loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				for (;;) {
					if (loc14) break;
					if ((EIF_BOOLEAN)(loc15 != NULL)) {
						/* INLINED CODE (SPECIAL.item) */
						tc2 = *((EIF_CHARACTER_8 *)RTCW(loc15) + (loc1));
						/* END INLINED CODE */
						tc1 = tc2;
						loc8 = (EIF_INTEGER_32) (tc1);
					} else {
						if ((EIF_BOOLEAN)(loc16 != NULL)) {
							/* INLINED CODE (SPECIAL.item) */
							tw2 = *((EIF_CHARACTER_32 *)RTCW(loc16) + (loc1));
							/* END INLINED CODE */
							tw1 = tw2;
							loc9 = (EIF_NATURAL_32) tw1;
						} else {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
							loc9 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R1023[Dtype(RTCW(tr1))-269])(tr1, loc1);
						}
						if ((EIF_BOOLEAN) (loc9 < ((EIF_NATURAL_32) 55296U))) {
							loc8 = (EIF_INTEGER_32) loc9;
						} else {
							if ((EIF_BOOLEAN) (loc9 <= ((EIF_NATURAL_32) 57343U))) {
								loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
							} else {
								if ((EIF_BOOLEAN) (loc9 > ((EIF_NATURAL_32) 1114111U))) {
									loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
								} else {
									loc8 = (EIF_INTEGER_32) loc9;
									loc8 -= ((EIF_INTEGER_32) 2048L);
								}
							}
						}
						if ((EIF_BOOLEAN) (loc8 > ((EIF_INTEGER_32) 12289L))) {
							loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12289L);
						}
					}
					if ((EIF_BOOLEAN) (loc8 >= ((EIF_INTEGER_32) 0L))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
						loc17 = tr1;
						if (EIF_TEST(loc17)) {
							/* INLINED CODE (SPECIAL.item) */
							ti4_2 = *((EIF_INTEGER_32 *)loc17 + (loc8));
							/* END INLINED CODE */
							ti4_1 = ti4_2;
							loc8 = (EIF_INTEGER_32) ti4_1;
						}
						for (;;) {
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
							tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
							/* INLINED CODE (SPECIAL.item) */
							ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr2) + (loc3));
							/* END INLINED CODE */
							ti4_1 = ti4_2;
							/* INLINED CODE (SPECIAL.item) */
							ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_1 + loc8)));
							/* END INLINED CODE */
							ti4_1 = ti4_3;
							if ((EIF_BOOLEAN)(ti4_1 == loc3)) break;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
							/* INLINED CODE (SPECIAL.item) */
							ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
							/* END INLINED CODE */
							ti4_2 = ti4_3;
							loc3 = (EIF_INTEGER_32) ti4_2;
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
							loc18 = tr1;
							if ((EIF_BOOLEAN) (EIF_TEST(loc18) && (EIF_BOOLEAN) (loc3 >= ((EIF_INTEGER_32) 648L)))) {
								/* INLINED CODE (SPECIAL.item) */
								ti4_3 = *((EIF_INTEGER_32 *)loc18 + (loc8));
								/* END INLINED CODE */
								ti4_2 = ti4_3;
								loc8 = (EIF_INTEGER_32) ti4_2;
							}
						}
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
						tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr2) + (loc3));
						/* END INLINED CODE */
						ti4_2 = ti4_3;
						/* INLINED CODE (SPECIAL.item) */
						ti4_4 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_2 + loc8)));
						/* END INLINED CODE */
						ti4_2 = ti4_4;
						loc3 = (EIF_INTEGER_32) ti4_2;
					} else {
						loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 647L);
						F971_6633(Current, loc9);
						if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_2_) == ((EIF_INTEGER_32) -2L))) {
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -3L);
						}
					}
					tr1 = RTOSCF(2620,F268_2620, (Current));
					F21_272(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_13_), loc3, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_16_));
					(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_16_))++;
					loc1++;
					loc14 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 647L));
				}
				loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
				break;
			case 3L:
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_16_))--;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
				/* INLINED CODE (SPECIAL.item) */
				ti4_4 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_16_)));
				/* END INLINED CODE */
				loc3 = ti4_4;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
				/* INLINED CODE (SPECIAL.item) */
				ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
				/* END INLINED CODE */
				ti4_2 = ti4_3;
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_18_) = (EIF_INTEGER_32) ti4_2;
				loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
				break;
			case 5L:
				RTCT0("yy_acclist_not_void", EX_CHECK);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_12_);
				loc19 = tr1;
				if (EIF_TEST(loc19)) {
					RTCK0;
				} else {
					RTCF0;
				}
				loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
				for (;;) {
					if (loc10) break;
					tb1 = '\0';
					if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_18_) != ((EIF_INTEGER_32) 0L))) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_4 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L))));
						/* END INLINED CODE */
						ti4_2 = ti4_4;
						tb1 = (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_18_) < ti4_2);
					}
					if (tb1) {
						/* INLINED CODE (SPECIAL.item) */
						ti4_4 = *((EIF_INTEGER_32 *)loc19 + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_18_)));
						/* END INLINED CODE */
						loc6 = ti4_4;
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc6 < (EIF_INTEGER_32) -((EIF_INTEGER_32) 144L)) || (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_19_) != ((EIF_INTEGER_32) 0L)))) {
							if ((EIF_BOOLEAN)(loc6 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_19_))) {
								*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_19_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) -loc6 - ((EIF_INTEGER_32) 144L));
								loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_18_))++;
							}
						} else {
							if ((EIF_BOOLEAN) (loc6 < ((EIF_INTEGER_32) 0L))) {
								*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_19_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 - ((EIF_INTEGER_32) 144L));
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_18_))++;
							} else {
								*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_17_) = (EIF_INTEGER_32) loc1;
								*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_21_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_16_);
								*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_20_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_18_);
								loc10 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							}
						}
					} else {
						loc1--;
						(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_16_))--;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_4 = *((EIF_INTEGER_32 *)RTCW(tr1) + (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_16_)));
						/* END INLINED CODE */
						loc3 = ti4_4;
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
						/* INLINED CODE (SPECIAL.item) */
						ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (loc3));
						/* END INLINED CODE */
						ti4_2 = ti4_3;
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_18_) = (EIF_INTEGER_32) ti4_2;
					}
				}
				loc11 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_6_);
				loc12 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_7_);
				loc13 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_8_);
				loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
				break;
			case 4L:
				loc2 -= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_9_);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_5_) = (EIF_INTEGER_32) loc2;
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_4_) = (EIF_INTEGER_32) loc1;
				loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				if ((EIF_BOOLEAN)(loc6 == ((EIF_INTEGER_32) 0L))) {
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					tr1 = RTMS_EX_H("fatal scanner internal error: no action found",45,1022935396);
					F967_6458(Current, tr1);
				} else {
					if ((EIF_BOOLEAN)(loc6 == ((EIF_INTEGER_32) 145L))) {
						loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 - loc2) - ((EIF_INTEGER_32) 1L));
						tr1 = *(EIF_REFERENCE *)(Current);
						ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1) + O1721[Dtype(tr1)-165]);
						if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_4_) <= (EIF_INTEGER_32) (ti4_2 + ((EIF_INTEGER_32) 1L)))) {
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_4_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + loc5);
							loc3 = F970_6571(Current);
							loc4 = F970_6572(Current, loc3);
							loc2 += *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_9_);
							if ((EIF_BOOLEAN)(loc4 != ((EIF_INTEGER_32) 0L))) {
								loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_4_);
								loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
								*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_4_) = (EIF_INTEGER_32) loc1;
								loc3 = (EIF_INTEGER_32) loc4;
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
							} else {
								loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_4_);
								(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_16_))--;
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
							}
						} else {
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_4_))--;
							F968_6501(Current);
							tr1 = *(EIF_REFERENCE *)(Current);
							tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O1732[Dtype(tr1)-165]);
							if (tb1) {
								loc3 = F970_6571(Current);
								loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_4_);
								loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_5_);
								ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_9_);
								loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ti4_2);
								loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
							} else {
								if ((EIF_BOOLEAN)((EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_4_) - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_5_)) - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_9_)) != ((EIF_INTEGER_32) 0L))) {
									loc3 = F970_6571(Current);
									loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_4_);
									loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_5_);
									ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_9_);
									loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ti4_2);
									loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
								} else {
									if (F967_6433(Current)) {
										loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_5_);
										loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_4_);
										F1199_8279(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_3_) - ((EIF_INTEGER_32) 1L)) / ((EIF_INTEGER_32) 2L)));
									}
								}
							}
						}
					} else {
						F1199_8278(Current, loc6);
						if (*(EIF_BOOLEAN *)(Current+ _CHROFF_64_2_)) {
							*(EIF_BOOLEAN *)(Current+ _CHROFF_64_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_6_) = (EIF_INTEGER_32) loc11;
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_7_) = (EIF_INTEGER_32) loc12;
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_8_) = (EIF_INTEGER_32) loc13;
							loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_17_);
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_18_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_20_);
							*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_16_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_21_);
							tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
							/* INLINED CODE (SPECIAL.item) */
							ti4_4 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_16_) - ((EIF_INTEGER_32) 1L))));
							/* END INLINED CODE */
							loc3 = ti4_4;
							(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_18_))++;
							loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 5L);
						}
					}
				}
				break;
			default:
				RTEC(EN_WHEN);
		}
	}
	RTLE;
}

/* {YY_COMPRESSED_SCANNER_SKELETON}.yy_set_content */
void F970_6569 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1029[Dtype(RTCW(arg1))-269])(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1030[Dtype(RTCW(arg1))-269])(arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	loc1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1013[Dtype(RTCW(arg1))-269])(arg1);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_13_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (tr1);
	if ((EIF_BOOLEAN) (ti4_1 < loc1)) {
		tr1 = RTOSCF(2620,F268_2620, (Current));
		tr1 = F21_275(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_13_), loc1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_13_) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {YY_COMPRESSED_SCANNER_SKELETON}.yy_previous_state */
EIF_INTEGER_32 F970_6571 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_CHARACTER_32 tw1;
	EIF_CHARACTER_32 tw2;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc5);
	RTLR(3,loc6);
	RTLR(4,loc7);
	RTLR(5,tr2);
	RTLR(6,loc8);
	RTLIU(7);
	
	RTGC;
	Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_3_);
	ti4_1 = F968_6508(Current);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O1727[Dtype(tr1)-165]);
	if (tb1) {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_3_);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	} else {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_3_);
	}
	tr1 = RTOSCF(2620,F268_2620, (Current));
	F21_272(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_13_), Result, ((EIF_INTEGER_32) 0L));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_16_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc5 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc6 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_5_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_9_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ti4_1);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_4_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 >= loc2)) break;
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			/* INLINED CODE (SPECIAL.item) */
			tc2 = *((EIF_CHARACTER_8 *)RTCW(loc5) + (loc1));
			/* END INLINED CODE */
			tc1 = tc2;
			loc3 = (EIF_INTEGER_32) (tc1);
		} else {
			if ((EIF_BOOLEAN)(loc6 != NULL)) {
				/* INLINED CODE (SPECIAL.item) */
				tw2 = *((EIF_CHARACTER_32 *)RTCW(loc6) + (loc1));
				/* END INLINED CODE */
				tw1 = tw2;
				loc4 = (EIF_NATURAL_32) tw1;
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				loc4 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R1023[Dtype(RTCW(tr1))-269])(tr1, loc1);
			}
			if ((EIF_BOOLEAN) (loc4 < ((EIF_NATURAL_32) 55296U))) {
				loc3 = (EIF_INTEGER_32) loc4;
			} else {
				loc3 = (EIF_INTEGER_32) loc4;
				loc3 -= ((EIF_INTEGER_32) 2048L);
			}
			if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 12289L))) {
				loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12289L);
			}
		}
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
			loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
		} else {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
			loc7 = tr1;
			if (EIF_TEST(loc7)) {
				/* INLINED CODE (SPECIAL.item) */
				ti4_2 = *((EIF_INTEGER_32 *)loc7 + (loc3));
				/* END INLINED CODE */
				ti4_1 = ti4_2;
				loc3 = (EIF_INTEGER_32) ti4_1;
			}
		}
		for (;;) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			/* INLINED CODE (SPECIAL.item) */
			ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr2) + (Result));
			/* END INLINED CODE */
			ti4_1 = ti4_2;
			/* INLINED CODE (SPECIAL.item) */
			ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_1 + loc3)));
			/* END INLINED CODE */
			ti4_1 = ti4_3;
			if ((EIF_BOOLEAN)(ti4_1 == Result)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			/* INLINED CODE (SPECIAL.item) */
			ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (Result));
			/* END INLINED CODE */
			ti4_2 = ti4_3;
			Result = (EIF_INTEGER_32) ti4_2;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
			loc8 = tr1;
			if ((EIF_BOOLEAN) (EIF_TEST(loc8) && (EIF_BOOLEAN) (Result >= ((EIF_INTEGER_32) 648L)))) {
				/* INLINED CODE (SPECIAL.item) */
				ti4_3 = *((EIF_INTEGER_32 *)loc8 + (loc3));
				/* END INLINED CODE */
				ti4_2 = ti4_3;
				loc3 = (EIF_INTEGER_32) ti4_2;
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		/* INLINED CODE (SPECIAL.item) */
		ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr2) + (Result));
		/* END INLINED CODE */
		ti4_2 = ti4_3;
		/* INLINED CODE (SPECIAL.item) */
		ti4_4 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_2 + loc3)));
		/* END INLINED CODE */
		ti4_2 = ti4_4;
		Result = (EIF_INTEGER_32) ti4_2;
		tr1 = RTOSCF(2620,F268_2620, (Current));
		F21_272(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_13_), Result, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_16_));
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_16_))++;
		loc1++;
	}
	RTLE;
	return Result;
}

/* {YY_COMPRESSED_SCANNER_SKELETON}.yy_null_trans_state */
EIF_INTEGER_32 F970_6572 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	Result = (EIF_INTEGER_32) arg1;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 60L);
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		/* INLINED CODE (SPECIAL.item) */
		ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr2) + (Result));
		/* END INLINED CODE */
		ti4_1 = ti4_2;
		/* INLINED CODE (SPECIAL.item) */
		ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_1 + loc1)));
		/* END INLINED CODE */
		ti4_1 = ti4_3;
		if ((EIF_BOOLEAN)(ti4_1 == Result)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		/* INLINED CODE (SPECIAL.item) */
		ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr1) + (Result));
		/* END INLINED CODE */
		ti4_2 = ti4_3;
		Result = (EIF_INTEGER_32) ti4_2;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
		loc3 = tr1;
		if ((EIF_BOOLEAN) (EIF_TEST(loc3) && (EIF_BOOLEAN) (Result >= ((EIF_INTEGER_32) 648L)))) {
			/* INLINED CODE (SPECIAL.item) */
			ti4_3 = *((EIF_INTEGER_32 *)loc3 + (loc1));
			/* END INLINED CODE */
			ti4_2 = ti4_3;
			loc1 = (EIF_INTEGER_32) ti4_2;
		}
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_3 = *((EIF_INTEGER_32 *)RTCW(tr2) + (Result));
	/* END INLINED CODE */
	ti4_2 = ti4_3;
	/* INLINED CODE (SPECIAL.item) */
	ti4_4 = *((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_2 + loc1)));
	/* END INLINED CODE */
	ti4_2 = ti4_4;
	Result = (EIF_INTEGER_32) ti4_2;
	tr1 = RTOSCF(2620,F268_2620, (Current));
	F21_272(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_13_), Result, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_16_));
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_16_))++;
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(Result == ((EIF_INTEGER_32) 647L));
	if (loc2) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	RTLE;
	return Result;
}

void EIF_Minit300 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
