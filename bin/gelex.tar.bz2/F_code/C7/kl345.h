
#ifndef _C7_kl345_
#define _C7_kl345_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1189_8127(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1189_8132(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,8139)
static EIF_REFERENCE F1189_8139_body(EIF_REFERENCE);
extern EIF_REFERENCE F1189_8139(EIF_REFERENCE);
extern void EIF_Minit345(void);
extern char *(*R4338[])();
extern char *(*R3077[])();

#ifdef __cplusplus
}
#endif

#endif
