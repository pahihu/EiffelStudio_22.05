
#ifndef _C7_ap337_
#define _C7_ap337_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1150_7585(EIF_REFERENCE, EIF_REFERENCE);
extern void F1150_7588(EIF_REFERENCE, EIF_REFERENCE);
extern void F1150_7589(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit337(void);
extern void F1145_7496(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
