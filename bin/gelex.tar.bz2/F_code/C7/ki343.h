
#ifndef _C7_ki343_
#define _C7_ki343_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1187_8039(EIF_REFERENCE);
extern void EIF_Minit343(void);

#ifdef __cplusplus
}
#endif

#endif
