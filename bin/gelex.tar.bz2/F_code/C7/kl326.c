/*
 * Code for class KL_CLONABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl326.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_CLONABLE}.cloned_object */
EIF_REFERENCE F1066_7036 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1_14(Current);
}

void EIF_Minit326 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
