
#ifndef _C7_ap308_
#define _C7_ap308_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1048_6902(EIF_REFERENCE);
extern void EIF_Minit308(void);
extern void F116_1330(EIF_REFERENCE, EIF_REFERENCE);
extern void F1150_7585(EIF_REFERENCE, EIF_REFERENCE);
extern void F1047_6861(EIF_REFERENCE);
extern EIF_REFERENCE F115_1299(EIF_REFERENCE);
extern EIF_REFERENCE F115_1298(EIF_REFERENCE);
extern void F116_1310(EIF_REFERENCE, EIF_CHARACTER_8, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,1299)
RTOSHF(EIF_REFERENCE,1298)
extern char *(*R5663[])();

#ifdef __cplusplus
}
#endif

#endif
