/*
 * Code for class LX_NFA
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx331.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_NFA}.make_symbol */
void F1072_7092 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) arg2;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1159_7647(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	loc2 = RTLNSMART(eif_final_id(Y5434,Y5434_gen_type,dftype,1070).id);
	F1069_7054(RTCW(loc2), arg2);
	loc3 = RTLNSMART(eif_final_id(Y5434,Y5434_gen_type,dftype,1070).id);
	F1069_7054(RTCW(loc3), arg2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1077,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 1077, _OBJSIZ_1_0_0_1_0_0_0_0_);
	}
	F1078_7236(RTCW(loc1), arg1, loc3);
	F1069_7066(RTCW(loc2), loc1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1159_7665(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1159_7666(RTCW(tr1), loc3);
	RTLE;
}

/* {LX_NFA}.make_epsilon */
void F1072_7093 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) arg1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1159_7647(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	loc2 = RTLNSMART(eif_final_id(Y5434,Y5434_gen_type,dftype,1070).id);
	F1069_7054(RTCW(loc2), arg1);
	loc3 = RTLNSMART(eif_final_id(Y5434,Y5434_gen_type,dftype,1070).id);
	F1069_7054(RTCW(loc3), arg1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1079,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 1079, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F1077_7231(RTCW(loc1), loc3);
	F1069_7066(RTCW(loc2), loc1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1159_7665(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1159_7666(RTCW(tr1), loc3);
	RTLE;
}

/* {LX_NFA}.make_symbol_class */
void F1072_7094 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,loc1);
	RTLR(5,arg1);
	RTLIU(6);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_) = (EIF_BOOLEAN) arg2;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1159_7647(RTCW(tr1), ((EIF_INTEGER_32) 100L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	loc2 = RTLNSMART(eif_final_id(Y5434,Y5434_gen_type,dftype,1070).id);
	F1069_7054(RTCW(loc2), arg2);
	loc3 = RTLNSMART(eif_final_id(Y5434,Y5434_gen_type,dftype,1070).id);
	F1069_7054(RTCW(loc3), arg2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1078,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 1078, _OBJSIZ_2_0_0_0_0_0_0_0_);
	}
	F1079_7242(RTCW(loc1), arg1, loc3);
	F1069_7066(RTCW(loc2), loc1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1159_7665(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1159_7666(RTCW(tr1), loc3);
	RTLE;
}

/* {LX_NFA}.start_state */
EIF_REFERENCE F1072_7095 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1159_7654(RTCW(tr1));
	RTLE;
	return Result;
}

/* {LX_NFA}.final_state */
EIF_REFERENCE F1072_7096 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1159_7655(RTCW(tr1));
	RTLE;
	return Result;
}

/* {LX_NFA}.has */
EIF_BOOLEAN F1072_7098 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	Result = F1159_7660(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {LX_NFA}.copy */
void F1072_7100 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,tr2);
	RTLR(6,loc2);
	RTLR(7,loc6);
	RTLR(8,loc7);
	RTLIU(9);
	
	RTGC;
	eif_builtin_ANY_standard_copy__o_ (Current, arg1);
	loc1 = *(EIF_REFERENCE *)(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_4_0_0_0_);
	F1159_7647(RTCW(tr1), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	loc5 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_4_0_0_1_);
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc4 > loc5)) break;
		loc3 = F1159_7653(RTCW(loc1), loc4);
		F1069_7068(RTCW(loc3), loc4);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = F1066_7036(RTCW(loc3));
		F1159_7666(RTCW(tr1), tr2);
		loc4++;
	}
	loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc4 > loc5)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		loc2 = F1159_7653(RTCW(tr1), loc4);
		loc6 = *(EIF_REFERENCE *)(RTCW(loc2));
		if ((EIF_BOOLEAN)(loc6 != NULL)) {
			tr1 = F1066_7036(RTCW(loc6));
			loc6 = (EIF_REFERENCE) tr1;
			loc3 = *(EIF_REFERENCE *)(RTCW(loc6));
			tr1 = *(EIF_REFERENCE *)(Current);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_3_1_0_0_);
			tr1 = F1159_7653(RTCW(tr1), ti4_1);
			F1077_7232(RTCW(loc6), tr1);
			F1069_7066(RTCW(loc2), loc6);
		}
		loc7 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_1_);
		if ((EIF_BOOLEAN)(loc7 != NULL)) {
			tr1 = F1066_7036(RTCW(loc7));
			loc7 = (EIF_REFERENCE) tr1;
			loc3 = *(EIF_REFERENCE *)(RTCW(loc7));
			tr1 = *(EIF_REFERENCE *)(Current);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_3_1_0_0_);
			tr1 = F1159_7653(RTCW(tr1), ti4_1);
			F1077_7232(RTCW(loc7), tr1);
			F1069_7067(RTCW(loc2), loc7);
		}
		loc4++;
	}
	RTLE;
}

/* {LX_NFA}.is_equal */
EIF_BOOLEAN F1072_7101 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(5994,F932_5994, (Current));
	tb1 = F16_120(RTCW(tr1), Current, arg1);
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ti4_2);
	}
	RTLE;
	return Result;
}

/* {LX_NFA}.set_accepted_rule */
void F1072_7102 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tr1 = F1072_7096(Current);
	F1069_7069(RTCW(tr1), arg1);
	RTLE;
}

/* {LX_NFA}.set_beginning_as_normal */
void F1072_7103 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1069_7070(RTCV(F1072_7095(Current)));
	RTLE;
}

/* {LX_NFA}.build_concatenation */
void F1072_7104 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1079,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 1079, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	tr1 = F1072_7095(RTCW(arg1));
	F1077_7231(RTCW(loc1), tr1);
	tr1 = F1072_7096(Current);
	F1069_7066(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
	F1159_7681(RTCW(tr1), tr2);
	RTLE;
}

/* {LX_NFA}.build_union */
void F1072_7105 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLR(5,loc1);
	RTLR(6,loc4);
	RTLR(7,tr2);
	RTLIU(8);
	
	RTGC;
	loc2 = F1072_7095(Current);
	loc3 = F1072_7095(RTCW(arg1));
	tr1 = *(EIF_REFERENCE *)(RTCW(loc2) + _REFACS_1_);
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1079,0xFF01,1068,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1079, _OBJSIZ_1_0_0_0_0_0_0_0_);
		}
		F1077_7231(RTCW(loc1), loc3);
		F1069_7067(RTCW(loc2), loc1);
	} else {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_1_);
		if ((EIF_BOOLEAN)(tr1 == NULL)) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1079,0xFF01,1068,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc1 = RTLNS(typres0.id, 1079, _OBJSIZ_1_0_0_0_0_0_0_0_);
			}
			F1077_7231(RTCW(loc1), loc2);
			F1069_7067(RTCW(loc3), loc1);
			tr1 = *(EIF_REFERENCE *)(Current);
			F1159_7664(RTCW(tr1), loc3, ((EIF_INTEGER_32) 1L));
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			F1159_7664(RTCW(tr1), loc2, ((EIF_INTEGER_32) 1L));
		} else {
			loc4 = RTLNSMART(eif_final_id(Y5434,Y5434_gen_type,dftype,1070).id);
			F1069_7054(RTCW(loc4), *(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1079,0xFF01,1068,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc1 = RTLNS(typres0.id, 1079, _OBJSIZ_1_0_0_0_0_0_0_0_);
			}
			F1077_7231(RTCW(loc1), loc2);
			F1069_7066(RTCW(loc4), loc1);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1079,0xFF01,1068,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc1 = RTLNS(typres0.id, 1079, _OBJSIZ_1_0_0_0_0_0_0_0_);
			}
			F1077_7231(RTCW(loc1), loc3);
			F1069_7067(RTCW(loc4), loc1);
			tr1 = *(EIF_REFERENCE *)(Current);
			F1159_7664(RTCW(tr1), loc4, ((EIF_INTEGER_32) 1L));
			loc4 = F1072_7096(Current);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = *(EIF_REFERENCE *)(Current);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_4_0_0_1_);
			F1159_7664(RTCW(tr1), loc2, ti4_1);
			tr1 = *(EIF_REFERENCE *)(Current);
			F1159_7671(RTCW(tr1), loc4);
		}
	}
	loc2 = F1072_7096(Current);
	loc3 = F1072_7096(RTCW(arg1));
	tb1 = F1069_7060(RTCW(loc3));
	if ((EIF_BOOLEAN) !tb1) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1079,0xFF01,1068,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1079, _OBJSIZ_1_0_0_0_0_0_0_0_);
		}
		F1077_7231(RTCW(loc1), loc3);
		F1069_7066(RTCW(loc2), loc1);
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
		F1159_7681(RTCW(tr1), tr2);
	} else {
		tb1 = F1069_7060(RTCW(loc2));
		if ((EIF_BOOLEAN) !tb1) {
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1079,0xFF01,1068,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc1 = RTLNS(typres0.id, 1079, _OBJSIZ_1_0_0_0_0_0_0_0_);
			}
			F1077_7231(RTCW(loc1), loc2);
			F1069_7066(RTCW(loc3), loc1);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = *(EIF_REFERENCE *)(Current);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_4_0_0_1_);
			F1159_7664(RTCW(tr1), loc3, ti4_1);
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_4_0_0_1_);
			F1159_7664(RTCW(tr1), loc2, ti4_1);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
			F1159_7681(RTCW(tr1), tr2);
		} else {
			loc4 = RTLNSMART(eif_final_id(Y5434,Y5434_gen_type,dftype,1070).id);
			F1069_7054(RTCW(loc4), *(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_));
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1079,0xFF01,1068,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc1 = RTLNS(typres0.id, 1079, _OBJSIZ_1_0_0_0_0_0_0_0_);
			}
			F1077_7231(RTCW(loc1), loc4);
			F1069_7066(RTCW(loc2), loc1);
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1079,0xFF01,1068,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc1 = RTLNS(typres0.id, 1079, _OBJSIZ_1_0_0_0_0_0_0_0_);
			}
			F1077_7231(RTCW(loc1), loc4);
			F1069_7066(RTCW(loc3), loc1);
			tr1 = *(EIF_REFERENCE *)(Current);
			tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
			F1159_7681(RTCW(tr1), tr2);
			tr1 = *(EIF_REFERENCE *)(Current);
			F1159_7671(RTCW(tr1), loc4);
		}
	}
	RTLE;
}

/* {LX_NFA}.build_optional */
void F1072_7106 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCV(F1072_7095(Current)) + _REFACS_1_);
	if ((EIF_BOOLEAN)(tr1 == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1079,0xFF01,1068,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1079, _OBJSIZ_1_0_0_0_0_0_0_0_);
		}
		tr1 = F1072_7096(Current);
		F1077_7231(RTCW(loc1), tr1);
		tr1 = F1072_7095(Current);
		F1069_7067(RTCW(tr1), loc1);
	} else {
		loc2 = F1072_7095(Current);
		loc3 = F1072_7096(Current);
		loc4 = RTLNSMART(eif_final_id(Y5434,Y5434_gen_type,dftype,1070).id);
		F1069_7054(RTCW(loc4), *(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1079,0xFF01,1068,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1079, _OBJSIZ_1_0_0_0_0_0_0_0_);
		}
		F1077_7231(RTCW(loc1), loc2);
		F1069_7066(RTCW(loc4), loc1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1079,0xFF01,1068,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc1 = RTLNS(typres0.id, 1079, _OBJSIZ_1_0_0_0_0_0_0_0_);
		}
		F1077_7231(RTCW(loc1), loc3);
		F1069_7067(RTCW(loc4), loc1);
		tr1 = *(EIF_REFERENCE *)(Current);
		F1159_7664(RTCW(tr1), loc4, ((EIF_INTEGER_32) 1L));
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_4_0_0_1_);
		F1159_7664(RTCW(tr1), loc2, ti4_1);
		tr1 = *(EIF_REFERENCE *)(Current);
		F1159_7671(RTCW(tr1), loc3);
	}
	RTLE;
}

/* {LX_NFA}.build_closure */
void F1072_7107 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1072_7108(Current);
	F1072_7106(Current);
	RTLE;
}

/* {LX_NFA}.build_positive_closure */
void F1072_7108 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc3);
	RTLR(3,loc1);
	RTLR(4,loc4);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	loc2 = F1072_7095(Current);
	loc3 = F1072_7096(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1079,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 1079, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F1077_7231(RTCW(loc1), loc2);
	F1069_7066(RTCW(loc3), loc1);
	loc4 = RTLNSMART(eif_final_id(Y5434,Y5434_gen_type,dftype,1070).id);
	F1069_7054(RTCW(loc4), *(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1079,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 1079, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F1077_7231(RTCW(loc1), loc2);
	F1069_7066(RTCW(loc4), loc1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1159_7664(RTCW(tr1), loc4, ((EIF_INTEGER_32) 1L));
	loc4 = RTLNSMART(eif_final_id(Y5434,Y5434_gen_type,dftype,1070).id);
	F1069_7054(RTCW(loc4), *(EIF_BOOLEAN *)(Current+ _CHROFF_1_0_));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1079,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 1079, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F1077_7231(RTCW(loc1), loc4);
	F1069_7067(RTCW(loc3), loc1);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1159_7671(RTCW(tr1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current);
	F1159_7671(RTCW(tr1), loc4);
	RTLE;
}

/* {LX_NFA}.build_iteration */
void F1072_7109 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != ((EIF_INTEGER_32) 1L))) {
		loc2 = F1066_7036(Current);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 >= arg1)) break;
			tr1 = F1066_7036(Current);
			F1072_7104(RTCW(loc2), tr1);
			loc1++;
		}
		F1072_7104(Current, loc2);
	}
	RTLE;
}

/* {LX_NFA}.build_unbounded_iteration */
void F1072_7110 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1066_7036(Current);
	F1072_7107(RTCW(loc1));
	F1072_7109(Current, arg1);
	F1072_7104(Current, loc1);
	RTLE;
}

/* {LX_NFA}.build_bounded_iteration */
void F1072_7111 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc2);
	RTLR(2,loc3);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == arg2)) {
		F1072_7109(Current, arg1);
	} else {
		loc2 = F1066_7036(Current);
		F1072_7106(RTCW(loc2));
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L));
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 >= arg2)) break;
			loc3 = F1066_7036(Current);
			F1072_7104(RTCW(loc3), loc2);
			F1072_7106(RTCW(loc3));
			loc2 = (EIF_REFERENCE) loc3;
			loc1++;
		}
		F1072_7109(Current, arg1);
		F1072_7104(Current, loc2);
	}
	RTLE;
}

void EIF_Minit331 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
