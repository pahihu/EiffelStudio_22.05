
#ifndef _C7_kl311_
#define _C7_kl311_

#ifdef __cplusplus
extern "C" {
#endif
RTOSHF (EIF_REFERENCE, 6950)


extern EIF_REFERENCE F1051_6950(EIF_REFERENCE);
extern void F1051_6951(EIF_REFERENCE);
extern void EIF_Minit311(void);
extern void F662_3316(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
