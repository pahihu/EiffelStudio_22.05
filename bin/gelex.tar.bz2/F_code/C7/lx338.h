
#ifndef _C7_lx338_
#define _C7_lx338_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1152_7606(EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE);
extern void F1152_7607(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit338(void);
extern void F48_643(EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE);
extern void F1145_7520(EIF_REFERENCE, EIF_REFERENCE);
extern void F1151_7595(EIF_REFERENCE);
extern EIF_REFERENCE F1040_6809(EIF_REFERENCE);
extern void F1034_6788(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
