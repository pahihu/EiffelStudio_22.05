
#ifndef _C7_kl316_
#define _C7_kl316_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F1056_6979(EIF_REFERENCE);
extern EIF_REFERENCE F1056_6980(EIF_REFERENCE);
extern void F1056_6984(EIF_REFERENCE);
extern void EIF_Minit316(void);
extern void F662_3315(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
