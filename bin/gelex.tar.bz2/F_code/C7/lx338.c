/*
 * Code for class LX_PROTO_QUEUE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx338.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_PROTO_QUEUE}.put */
void F1152_7606 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,arg2);
	RTLR(2,arg3);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(47, 0x01).id, 47, _OBJSIZ_2_0_0_1_0_0_0_0_);
	F48_643(RTCW(loc1), arg1, arg2, arg3);
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) >= ((EIF_INTEGER_32) 50L))) {
		F1151_7595(Current);
	}
	F1145_7520(Current, loc1);
	RTLE;
}

/* {LX_PROTO_QUEUE}.move_to_front */
void F1152_7607 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = F1040_6809(RTCW(arg1));
	F1034_6788(RTCW(arg1));
	F1145_7520(Current, loc1);
	RTLE;
}

void EIF_Minit338 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
