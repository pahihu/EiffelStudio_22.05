/*
 * Code for class AP_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ap308.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {AP_PARSER}.make */
void F1048_6902 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	F1047_6861(Current);
	tr1 = RTLNSMART(eif_new_type(224, 1).id);
	tr2 = RTOSCF(1299,F115_1299, (Current));
	F116_1310(RTCW(tr1), (EIF_CHARACTER_8) 'h', tr2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr2 = RTOSCF(1298,F115_1298, (Current));
	F116_1330(RTCW(tr1), tr2);
	loc1 = RTLNS(eif_new_type(1149, 0x01).id, 1149, _OBJSIZ_6_0_0_1_0_0_0_0_);
	F1150_7585(RTCW(loc1), *(EIF_REFERENCE *)(Current + _REFACS_8_));
	tr1 = *(EIF_REFERENCE *)(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5663[Dtype(RTCW(tr1))-1144])(tr1, loc1);
	RTLE;
}

void EIF_Minit308 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
