/*
 * Code for class LX_TEMPLATE_LIST
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx336.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_TEMPLATE_LIST}.make */
void F1149_7581 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F1145_7496(Current);
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {LX_TEMPLATE_LIST}.equiv_template */
EIF_REFERENCE F1149_7583 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc4 = tr1;
	if ((EIF_BOOLEAN) !EIF_TEST(loc4)) {
		RTLE;
		return (EIF_REFERENCE) arg1;
	} else {
		Result = RTLNSMART(eif_final_id(Y5624,Y5624_gen_type,Dftype(Current),1106).id);
		ti4_1 = F96_1056(loc4);
		ti4_2 = F96_1057(loc4);
		F1067_7037(RTCW(Result), ti4_1, ti4_2);
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
		loc2 = F1181_7972(RTCW(tr1));
		F990_6721(RTCW(loc2));
		for (;;) {
			tb1 = F1013_6749(RTCW(loc2));
			if (tb1) break;
			loc1 = F1023_6768(RTCW(loc2));
			tb2 = F96_1060(loc4, loc1);
			if (tb2) {
				ti4_1 = F96_1052(loc4, loc1);
				loc1 = (EIF_INTEGER_32) ti4_1;
				tr1 = F975_6701(RTCW(loc2));
				F1067_7049(RTCW(Result), tr1, loc1);
			}
			F990_6722(RTCW(loc2));
		}
	}
	RTLE;
	return Result;
}

/* {LX_TEMPLATE_LIST}.put */
void F1149_7584 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,loc7);
	RTLR(5,loc6);
	RTLR(6,loc8);
	RTLR(7,tr1);
	RTLR(8,arg2);
	RTLIU(9);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_0_0_3_);
	loc5 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_0_0_4_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1066,0xFF01,1069,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc2 = RTLNS(typres0.id, 1066, _OBJSIZ_1_0_0_5_0_0_0_0_);
	}
	F1067_7037(RTCW(loc2), loc4, loc5);
	loc7 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	if ((EIF_BOOLEAN)(loc7 != NULL)) {
		loc6 = RTLNS(eif_new_type(796, 0x01).id, 796, _OBJSIZ_1_2_0_2_0_0_4_0_);
		F797_4158(RTCW(loc6), loc4, loc5);
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
	loc8 = F1181_7972(RTCW(tr1));
	F990_6721(RTCW(loc8));
	for (;;) {
		tb1 = F1013_6749(RTCW(loc8));
		if (tb1) break;
		loc3 = F1023_6768(RTCW(loc8));
		F1067_7049(RTCW(loc2), arg2, loc3);
		if ((EIF_BOOLEAN)(loc6 != NULL)) {
			F797_4170(RTCW(loc6), loc3);
		}
		F990_6722(RTCW(loc8));
	}
	F1145_7522(Current, loc2);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc7 != NULL) && (EIF_BOOLEAN)(loc6 != NULL))) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1068[Dtype(RTCW(loc7))-95])(loc7, loc6);
	}
	RTLE;
}

void EIF_Minit336 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
