/*
 * Code for class KL_WINDOWS_FILE_SYSTEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl346.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_WINDOWS_FILE_SYSTEM}.make */
void F1190_8149 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {KL_WINDOWS_FILE_SYSTEM}.is_root_directory */
EIF_BOOLEAN F1190_8155 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_CHARACTER_8 loc5 = (EIF_CHARACTER_8) 0;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 4L))) {
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, ((EIF_INTEGER_32) 1L)));
		tb1 = F1190_8176(Current, tc1);
	}
	if (tb1) {
		tb1 = '\0';
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, ((EIF_INTEGER_32) 2L)));
		if (F1190_8176(Current, tc1)) {
			tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, ((EIF_INTEGER_32) 3L)));
			tb1 = (EIF_BOOLEAN) !F1190_8176(Current, tc1);
		}
		if (tb1) {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > loc2) || loc4)) break;
				loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, loc1));
				if (F1190_8176(Current, loc5)) {
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				} else {
					loc1++;
				}
			}
			if (loc4) {
				tb1 = '\0';
				if ((EIF_BOOLEAN) (loc1 < loc2)) {
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L))));
					tb1 = (EIF_BOOLEAN) !F1190_8176(Current, tc1);
				}
				if (tb1) {
					loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc1++;
					for (;;) {
						if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > loc2) || loc4)) break;
						loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, loc1));
						if (F1190_8176(Current, loc5)) {
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							loc1++;
						}
					}
					if (loc4) {
						loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
						loc1++;
						for (;;) {
							if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > loc2) || loc4)) break;
							loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, loc1));
							if ((EIF_BOOLEAN) !F1190_8176(Current, loc5)) {
								loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							} else {
								loc1++;
							}
						}
						RTLE;
						return (EIF_BOOLEAN) (EIF_BOOLEAN) !loc4;
					} else {
						RTLE;
						return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
			}
		}
	} else {
		if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 3L))) {
			loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, ((EIF_INTEGER_32) 1L)));
			tb1 = '\0';
			if ((EIF_BOOLEAN) !F1190_8176(Current, loc5)) {
				tb1 = (EIF_BOOLEAN)(loc5 != (EIF_CHARACTER_8) ':');
			}
			if (tb1) {
				loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
				for (;;) {
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc1 > loc2) || loc3) || loc4)) break;
					loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, loc1));
					if (F1190_8176(Current, loc5)) {
						loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						if ((EIF_BOOLEAN)(loc5 == (EIF_CHARACTER_8) ':')) {
							loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						} else {
							loc1++;
						}
					}
				}
				if ((EIF_BOOLEAN) (loc4 && (EIF_BOOLEAN)((EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)) == loc2))) {
					loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, loc2));
					Result = F1190_8176(Current, loc5);
				}
			}
		} else {
			if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 1L))) {
				loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, ((EIF_INTEGER_32) 1L)));
				Result = F1190_8176(Current, loc5);
				RTLE;
				return (EIF_BOOLEAN) Result;
			}
		}
	}
	RTLE;
	return Result;
}

/* {KL_WINDOWS_FILE_SYSTEM}.basename */
EIF_REFERENCE F1190_8160 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (F1190_8155(Current, arg1)) {
		RTLE;
		return (EIF_REFERENCE) RTOSCF(8167,F1190_8167, (Current));
	} else {
		loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) {
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, loc1));
				tb1 = (EIF_BOOLEAN) !F1190_8176(Current, tc1);
			}
			if (tb1) break;
			loc1--;
		}
		loc2 = (EIF_INTEGER_32) loc1;
		for (;;) {
			tb2 = '\01';
			if (!(EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) {
				tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, loc1));
				tb2 = F1190_8176(Current, tc1);
			}
			if (tb2) break;
			loc1--;
		}
		tb3 = '\0';
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			tb3 = (EIF_BOOLEAN)(loc2 == ti4_1);
		}
		if (tb3) {
			RTLE;
			return (EIF_REFERENCE) arg1;
		} else {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4338[Dtype(RTCW(arg1))-910])(arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), loc2);
			RTLE;
			return (EIF_REFERENCE) tr1;
		}
	}/* NOTREACHED */
	
}

/* {KL_WINDOWS_FILE_SYSTEM}.root_directory */
static EIF_REFERENCE F1190_8167_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTGC;
	RTOSP (8167);
#define Result RTOSR(8167)
	RTOC_NEW(Result);
	Result = RTMS_EX_H("\\",1,92);
	RTOSE (8167);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1190_8167 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(8167,F1190_8167_body,(Current));
}

/* {KL_WINDOWS_FILE_SYSTEM}.is_directory_separator */
EIF_BOOLEAN F1190_8176 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	if (!(EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) '\\')) {
		Result = (EIF_BOOLEAN)(arg1 == RTOSCF(8178,F1190_8178, (Current)));
	}
	RTLE;
	return Result;
}

/* {KL_WINDOWS_FILE_SYSTEM}.secondary_directory_separator */
static EIF_CHARACTER_8 F1190_8178_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (8178);
#define Result RTOSR(8178)
	Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '/';
	RTOSE (8178);
	RTEE;
	return Result;
#undef Result
}

EIF_CHARACTER_8 F1190_8178 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(8178,F1190_8178_body,(Current));
}

void EIF_Minit346 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
