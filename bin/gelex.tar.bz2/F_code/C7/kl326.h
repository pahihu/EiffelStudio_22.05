
#ifndef _C7_kl326_
#define _C7_kl326_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1066_7036(EIF_REFERENCE);
extern void EIF_Minit326(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
