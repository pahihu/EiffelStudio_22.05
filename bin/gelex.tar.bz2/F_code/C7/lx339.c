/*
 * Code for class LX_START_CONDITIONS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx339.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_START_CONDITIONS}.make_with_initial */
void F1161_7728 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1159_7647(Current, arg1);
	loc1 = RTLNS(eif_new_type(44, 0x01).id, 44, _OBJSIZ_3_2_0_1_0_0_0_0_);
	tr1 = RTMS_EX_H("INITIAL",7,1802948172);
	F45_556(RTCW(loc1), tr1, ((EIF_INTEGER_32) 0L), (EIF_BOOLEAN) 0);
	F1159_7665(Current, loc1);
	RTLE;
}

/* {LX_START_CONDITIONS}.has_start_condition */
EIF_BOOLEAN F1161_7729 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4319[Dtype(RTCW(arg1))-910])(arg1);
	for (;;) {
		if ((EIF_BOOLEAN) (Result || (EIF_BOOLEAN) (loc1 > loc2))) break;
		tr1 = F1159_7653(Current, loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4319[Dtype(RTCW(tr1))-910])(tr1);
		Result = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc3))-2])(loc3, tr1);
		loc1++;
	}
	RTLE;
	return Result;
}

/* {LX_START_CONDITIONS}.start_condition */
EIF_REFERENCE F1161_7730 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,arg1);
	RTLR(3,loc4);
	RTLR(4,tr1);
	RTLR(5,Result);
	RTLIU(6);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4319[Dtype(RTCW(arg1))-910])(arg1);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 != NULL) || (EIF_BOOLEAN) (loc1 > loc2))) break;
		loc4 = F1159_7653(Current, loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc4));
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4319[Dtype(RTCW(tr1))-910])(tr1);
		tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R11[Dtype(RTCW(loc3))-2])(loc3, tr1);
		if ((EIF_BOOLEAN) !tb1) {
			loc4 = (EIF_REFERENCE) NULL;
			loc1++;
		}
	}
	RTCT0("has_start_condition", EX_CHECK);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc4;
	RTLE;
	return Result;
}

/* {LX_START_CONDITIONS}.names */
EIF_REFERENCE F1161_7731 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
		tr1 = RTOSCF(3844,F770_3844, (Current));
		Result = F939_6159(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,701,0xFF01,914,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 701, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		tr1 = *(EIF_REFERENCE *)(RTCV(F1159_7654(Current)));
		F702_3685(RTCW(Result), tr1, ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L)));
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = F1159_7653(Current, loc1);
			tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
			F702_3709(RTCW(Result), tr1, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)));
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {LX_START_CONDITIONS}.force_new_start_condition */
void F1161_7732 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(44, 0x01).id, 44, _OBJSIZ_3_2_0_1_0_0_0_0_);
	F45_556(RTCW(loc1), arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_), arg2);
	F1159_7671(Current, loc1);
	RTLE;
}

/* {LX_START_CONDITIONS}.append_start_conditions */
void F1161_7733 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc3);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = F1159_7653(RTCW(arg1), loc1);
		if ((EIF_BOOLEAN) !F1159_7660(Current, loc3)) {
			F1159_7671(Current, loc3);
		}
		loc1++;
	}
	RTLE;
}

/* {LX_START_CONDITIONS}.append_non_eof_start_conditions */
void F1161_7734 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,loc3);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = F1159_7653(RTCW(arg1), loc1);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_1_);
		if ((EIF_BOOLEAN) !tb1) {
			F1159_7671(Current, loc3);
		}
		loc1++;
	}
	RTLE;
}

/* {LX_START_CONDITIONS}.add_nfa_to_all */
void F1161_7735 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = F1159_7653(Current, loc1);
		F45_566(RTCW(tr1), arg1, arg2);
		loc1++;
	}
	RTLE;
}

/* {LX_START_CONDITIONS}.add_nfa_to_non_exclusive */
void F1161_7736 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc3);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = F1159_7653(Current, loc1);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_3_0_);
		if ((EIF_BOOLEAN) !tb1) {
			F45_566(RTCW(loc3), arg1, arg2);
		}
		loc1++;
	}
	RTLE;
}

void EIF_Minit339 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
