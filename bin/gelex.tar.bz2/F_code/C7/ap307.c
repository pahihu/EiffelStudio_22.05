/*
 * Code for class AP_BASIC_PARSER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ap307.h"
#include "eif_helpers.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {AP_BASIC_PARSER}.make */
void F1047_6861 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,115,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 1158, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	F1159_7647(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,1149,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 1158, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	F1159_7647(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,914,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 1158, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	F1159_7647(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(1192, 1).id);
	F1192_8181(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(1306,F115_1306, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = RTOSCF(1305,F115_1305, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {AP_BASIC_PARSER}.all_options */
EIF_REFERENCE F1047_6869 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,115,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1158, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	F1159_7647(RTCW(Result), ((EIF_INTEGER_32) 0L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1107_7310(RTCW(tr1));
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tb1 = F1107_7307(RTCW(tr1));
		if (tb1) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr1 = F1095_7281(RTCW(tr1));
		tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5616[Dtype(RTCW(Result))-1144])(Result, tr1);
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
			tr1 = F1095_7281(RTCW(tr1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5663[Dtype(RTCW(Result))-1144])(Result, tr1);
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1107_7311(RTCW(tr1));
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	F1107_7310(RTCW(tr1));
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tb2 = F1107_7307(RTCW(tr1));
		if (tb2) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		loc1 = F1095_7281(RTCW(tr1));
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
		tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5616[Dtype(RTCW(Result))-1144])(Result, tr1);
		if ((EIF_BOOLEAN) !tb3) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_4_);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5663[Dtype(RTCW(Result))-1144])(Result, tr1);
		}
		F1107_7310(RTCW(loc1));
		for (;;) {
			tb3 = F1107_7307(RTCW(loc1));
			if (tb3) break;
			tr1 = F1095_7281(RTCW(loc1));
			tb4 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_REFERENCE)) R5616[Dtype(RTCW(Result))-1144])(Result, tr1);
			if ((EIF_BOOLEAN) !tb4) {
				tr1 = F1095_7281(RTCW(loc1));
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5663[Dtype(RTCW(Result))-1144])(Result, tr1);
			}
			F1107_7311(RTCW(loc1));
		}
		tr1 = *(EIF_REFERENCE *)(Current);
		F1107_7311(RTCW(tr1));
	}
	RTLE;
	return Result;
}

/* {AP_BASIC_PARSER}.set_application_description */
void F1047_6870 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {AP_BASIC_PARSER}.set_parameters_description */
void F1047_6872 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) arg1;
}

/* {AP_BASIC_PARSER}.parse_arguments */
void F1047_6875 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc3 = F357_3002(RTCV(RTOSCF(2137,F223_2137, (Current))));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,914,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 1158, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	F1159_7647(RTCW(loc1), loc3);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		tr1 = RTOSCF(2137,F223_2137, (Current));
		tr1 = F357_2984(RTCW(tr1), loc2);
		F1159_7672(RTCW(loc1), tr1, loc2);
		loc2++;
	}
	F1047_6877(Current, loc1);
	RTLE;
}

/* {AP_BASIC_PARSER}.parse_list */
void F1047_6877 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1047_6901(Current);
	F1107_7310(RTCW(arg1));
	for (;;) {
		tb1 = F1107_7307(RTCW(arg1));
		if (tb1) break;
		F1047_6898(Current, arg1);
	}
	F1047_6897(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_3_0_);
	if (tb2) {
		F1047_6878(Current);
	}
	RTLE;
}

/* {AP_BASIC_PARSER}.final_error_action */
void F1047_6878 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTOSCF(1304,F115_1304, (Current));
	F1193_8205(RTCW(tr1), tr2);
	tr1 = RTOSCF(2138,F224_2138, (Current));
	F179_1912(RTCW(tr1), ((EIF_INTEGER_32) 1L));
	RTLE;
}

/* {AP_BASIC_PARSER}.full_help_text */
EIF_REFERENCE F1047_6884 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,loc4);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLR(4,tr1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	loc3 = RTLNS(eif_new_type(920, 0x01).id, 920, _OBJSIZ_0_0_0_0_0_0_0_0_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,75,0xFF01,115,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc4 = RTLNS(typres0.id, 75, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F74_947(RTCW(loc4), loc3);
	Result = F1047_6885(Current);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F602_3219(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = RTOSCF(6891,F1047_6891, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(Result))-914])(Result, tr1);
		tr1 = RTOSCF(6889,F1047_6889, (Current));
		F920_5927(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		tr1 = RTOSCF(6889,F1047_6889, (Current));
		tr1 = F920_5928(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_1_));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(Result))-914])(Result, tr1);
		tr1 = RTOSCF(6892,F1047_6892, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(Result))-914])(Result, tr1);
	}
	tr1 = RTOSCF(6893,F1047_6893, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(Result))-914])(Result, tr1);
	loc2 = F1047_6869(Current);
	F74_955(RTCW(loc4), loc2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	F1107_7310(RTCW(loc2));
	for (;;) {
		tb1 = F1107_7307(RTCW(loc2));
		if (tb1) break;
		tr1 = F1095_7281(RTCW(loc2));
		tb2 = *(EIF_BOOLEAN *)(RTCW(tr1) + O1306[Dtype(tr1)-115]);
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = F1095_7281(RTCW(loc2));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1300[Dtype(RTCW(tr1))-116])(tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
			ti4_1 = eif_max_int32 (ti4_1,loc1);
			loc1 = (EIF_INTEGER_32) ti4_1;
		}
		F1107_7311(RTCW(loc2));
	}
	ti4_1 = eif_min_int32 (loc1,((EIF_INTEGER_32) 25L));
	loc1 = (EIF_INTEGER_32) ti4_1;
	F1107_7310(RTCW(loc2));
	for (;;) {
		tb2 = F1107_7307(RTCW(loc2));
		if (tb2) break;
		tr1 = F1095_7281(RTCW(loc2));
		tb3 = *(EIF_BOOLEAN *)(RTCW(tr1) + O1306[Dtype(tr1)-115]);
		if ((EIF_BOOLEAN) !tb3) {
			if (loc5) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, (EIF_CHARACTER_8) '\012');
			}
			tr1 = F1095_7281(RTCW(loc2));
			tr1 = F1047_6888(Current, tr1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(Result))-914])(Result, tr1);
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		}
		F1107_7311(RTCW(loc2));
	}
	RTLE;
	return Result;
}

/* {AP_BASIC_PARSER}.full_usage_instruction */
EIF_REFERENCE F1047_6885 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	Result = F1047_6886(Current);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, (EIF_CHARACTER_8) '\012');
	loc1 = *(EIF_REFERENCE *)(Current);
	F1107_7310(RTCW(loc1));
	for (;;) {
		tb1 = F1107_7307(RTCW(loc1));
		if (tb1) break;
		tr1 = F1095_7281(RTCW(loc1));
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
		tb2 = *(EIF_BOOLEAN *)(RTCW(tr1) + O1306[Dtype(tr1)-115]);
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = F1095_7281(RTCW(loc1));
			tr1 = F1047_6887(Current, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(Result))-914])(Result, tr1);
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, (EIF_CHARACTER_8) '\012');
		F1107_7311(RTCW(loc1));
	}
	RTLE;
	return Result;
}

/* {AP_BASIC_PARSER}.usage_instruction */
EIF_REFERENCE F1047_6886 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,loc3);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLR(5,loc4);
	RTLR(6,tr2);
	RTLR(7,Result);
	RTLIU(8);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F907_5454(RTCW(loc1));
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	F1107_7310(RTCW(loc3));
	for (;;) {
		tb1 = F1107_7307(RTCW(loc3));
		if (tb1) break;
		loc2 = F1095_7281(RTCW(loc3));
		tb2 = *(EIF_BOOLEAN *)(RTCW(loc2) + O1306[Dtype(loc2)-115]);
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1297[Dtype(RTCW(loc2))-116])(loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(loc1))-914])(loc1, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(loc1))-914])(loc1, (EIF_CHARACTER_8) ' ');
		}
		F1107_7311(RTCW(loc3));
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(loc1))-914])(loc1, *(EIF_REFERENCE *)(Current + _REFACS_5_));
	tr1 = RTOSCF(6825,F1045_6825, (Current));
	tr2 = *(EIF_REFERENCE *)(RTCV(RTOSCF(2137,F223_2137, (Current))));
	loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R6011[Dtype(RTCW(tr1))-1188])(tr1, tr2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4376[Dtype(RTCW(loc4))-914])(loc4, ((EIF_INTEGER_32) 40L));
	Result = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F913_5751(RTCW(Result), ((EIF_INTEGER_32) 20L));
	tr1 = RTOSCF(6890,F1047_6890, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(Result))-914])(Result, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(Result))-914])(Result, loc4);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, (EIF_CHARACTER_8) ' ');
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(Result))-914])(Result, loc1);
	tr1 = RTOSCF(6889,F1047_6889, (Current));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(6890,F1047_6890, (Current)))+ _LNGOFF_1_1_0_2_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_1_1_0_2_);
	F920_5927(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + ((EIF_INTEGER_32) 1L)));
	tr1 = RTOSCF(6889,F1047_6889, (Current));
	tr1 = F920_5928(RTCW(tr1), Result);
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

/* {AP_BASIC_PARSER}.alternative_usage_instruction */
EIF_REFERENCE F1047_6887 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(8);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLR(4,loc3);
	RTLR(5,Current);
	RTLR(6,tr2);
	RTLR(7,Result);
	RTLIU(8);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F907_5454(RTCW(loc1));
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1297[Dtype(RTCW(tr1))-116])(tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(loc1))-914])(loc1, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(loc1))-914])(loc1, (EIF_CHARACTER_8) ' ');
	F1107_7310(RTCW(arg1));
	for (;;) {
		tb1 = F1107_7307(RTCW(arg1));
		if (tb1) break;
		loc2 = F1095_7281(RTCW(arg1));
		tb2 = *(EIF_BOOLEAN *)(RTCW(loc2) + O1306[Dtype(loc2)-115]);
		if ((EIF_BOOLEAN) !tb2) {
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1297[Dtype(RTCW(loc2))-116])(loc2);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(loc1))-914])(loc1, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(loc1))-914])(loc1, (EIF_CHARACTER_8) ' ');
		}
		F1107_7311(RTCW(arg1));
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(loc1))-914])(loc1, tr1);
	tr1 = RTOSCF(6825,F1045_6825, (Current));
	tr2 = *(EIF_REFERENCE *)(RTCV(RTOSCF(2137,F223_2137, (Current))));
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R6011[Dtype(RTCW(tr1))-1188])(tr1, tr2);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R4376[Dtype(RTCW(loc3))-914])(loc3, ((EIF_INTEGER_32) 40L));
	Result = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(6890,F1047_6890, (Current)))+ _LNGOFF_1_1_0_2_);
	F913_5752(RTCW(Result), (EIF_CHARACTER_8) ' ', ti4_1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(Result))-914])(Result, loc3);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, (EIF_CHARACTER_8) ' ');
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(Result))-914])(Result, loc1);
	tr1 = RTOSCF(6889,F1047_6889, (Current));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(6890,F1047_6890, (Current)))+ _LNGOFF_1_1_0_2_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_1_1_0_2_);
	F920_5927(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + ti4_2) + ((EIF_INTEGER_32) 1L)));
	tr1 = RTOSCF(6889,F1047_6889, (Current));
	tr1 = F920_5928(RTCW(tr1), Result);
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

/* {AP_BASIC_PARSER}.option_help_text */
EIF_REFERENCE F1047_6888 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLR(6,Result);
	RTLIU(7);
	
	RTGC;
	tr1 = RTOSCF(6889,F1047_6889, (Current));
	F920_5927(RTCW(tr1), arg2);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1300[Dtype(RTCW(arg1))-116])(arg1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN) (arg2 <= ti4_1)) {
		loc1 = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F913_5752(RTCW(loc1), (EIF_CHARACTER_8) ' ', arg2);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1300[Dtype(RTCW(arg1))-116])(arg1);
		tr2 = RTMS_EX_H("\012",1,10);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4486[Dtype(RTCW(tr1))-914])(tr1, tr2);
		tr2 = RTOSCF(6889,F1047_6889, (Current));
		tr3 = *(EIF_REFERENCE *)(RTCW(arg1));
		tr3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4486[Dtype(RTCW(loc1))-914])(loc1, tr3);
		tr2 = F920_5928(RTCW(tr2), tr3);
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4486[Dtype(RTCW(tr1))-914])(tr1, tr2);
	} else {
		loc1 = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1300[Dtype(RTCW(arg1))-116])(arg1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
		F913_5752(RTCW(loc1), (EIF_CHARACTER_8) ' ', (EIF_INTEGER_32) (arg2 - ti4_1));
		tr1 = RTOSCF(6889,F1047_6889, (Current));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1300[Dtype(RTCW(arg1))-116])(arg1);
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4486[Dtype(RTCW(tr2))-914])(tr2, loc1);
		tr3 = *(EIF_REFERENCE *)(RTCW(arg1));
		tr2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4486[Dtype(RTCW(tr2))-914])(tr2, tr3);
		Result = F920_5928(RTCW(tr1), tr2);
	}
	RTLE;
	return Result;
}

/* {AP_BASIC_PARSER}.wrapper */
static EIF_REFERENCE F1047_6889_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6889);
#define Result RTOSR(6889)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(919, 0x01).id, 919, _OBJSIZ_0_0_0_3_0_0_0_0_);
	F920_5920(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	F920_5926(RTCW(Result), ((EIF_INTEGER_32) 79L));
	RTOSE (6889);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1047_6889 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6889,F1047_6889_body,(Current));
}

/* {AP_BASIC_PARSER}.usage_header */

EIF_REFERENCE F1047_6890 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6890,RTMS_EX_H("usage: ",7,720124960));
}

/* {AP_BASIC_PARSER}.text_before_description */

EIF_REFERENCE F1047_6891 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6891,RTMS_EX_H("\012",1,10));
}

/* {AP_BASIC_PARSER}.text_below_description */

EIF_REFERENCE F1047_6892 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6892,RTMS_EX_H("\012",1,10));
}

/* {AP_BASIC_PARSER}.text_before_options */

EIF_REFERENCE F1047_6893 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6893,RTMS_EX_H("\012Options:\012",10,1377425418));
}

/* {AP_BASIC_PARSER}.check_options_after_parsing */
void F1047_6897 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	RTCT0("current_options_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	F1107_7310(RTCW(loc3));
	for (;;) {
		tb1 = F1107_7307(RTCW(loc3));
		if (tb1) break;
		loc1 = F1095_7281(RTCW(loc3));
		tb2 = '\0';
		tb3 = *(EIF_BOOLEAN *)(RTCW(loc1) + O1307[Dtype(loc1)-115]);
		if (tb3) {
			tb3 = F116_1329(RTCW(loc1));
			tb2 = (EIF_BOOLEAN) !tb3;
		}
		if (tb2) {
			loc2 = RTLNS(eif_new_type(1235, 0x01).id, 1235, _OBJSIZ_3_0_0_0_0_0_0_0_);
			F1236_8719(RTCW(loc2), loc1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1192_8183(RTCW(tr1), loc2);
		}
		tb2 = '\0';
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O1302[Dtype(loc1)-115]);
		if ((EIF_BOOLEAN) (ti4_1 > ((EIF_INTEGER_32) 0L))) {
			ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R1301[Dtype(RTCW(loc1))-116])(loc1);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O1302[Dtype(loc1)-115]);
			tb2 = (EIF_BOOLEAN) (ti4_1 > ti4_2);
		}
		if (tb2) {
			loc2 = RTLNS(eif_new_type(1235, 0x01).id, 1235, _OBJSIZ_3_0_0_0_0_0_0_0_);
			F1236_8721(RTCW(loc2), loc1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1192_8183(RTCW(tr1), loc2);
		}
		F1107_7311(RTCW(loc3));
	}
	RTLE;
}

/* {AP_BASIC_PARSER}.parse_argument */
void F1047_6898 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = F1095_7281(RTCW(arg1));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
	tb1 = '\0';
	if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 2L))) {
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(loc1))-676])(loc1, ((EIF_INTEGER_32) 1L)));
		tb1 = (EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '-');
	}
	if (tb1) {
		tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(loc1))-676])(loc1, ((EIF_INTEGER_32) 2L)));
		if ((EIF_BOOLEAN)(tc1 == (EIF_CHARACTER_8) '-')) {
			if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 2L))) {
				F1107_7311(RTCW(arg1));
				for (;;) {
					tb1 = F1107_7307(RTCW(arg1));
					if (tb1) break;
					tr1 = F1095_7281(RTCW(arg1));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5663[Dtype(RTCW(loc3))-1144])(loc3, tr1);
					F1107_7311(RTCW(arg1));
				}
			} else {
				F1047_6899(Current, arg1);
			}
		} else {
			F1047_6900(Current, arg1);
		}
	} else {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5663[Dtype(RTCW(loc3))-1144])(loc3, loc1);
		F1107_7311(RTCW(arg1));
	}
	RTLE;
}

/* {AP_BASIC_PARSER}.parse_long */
void F1047_6899 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTLD;
	
	RTLI(12);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,loc6);
	RTLR(4,Current);
	RTLR(5,loc3);
	RTLR(6,tr1);
	RTLR(7,loc4);
	RTLR(8,loc9);
	RTLR(9,loc8);
	RTLR(10,loc10);
	RTLR(11,loc7);
	RTLIU(12);
	
	RTGC;
	loc1 = F1095_7281(RTCW(arg1));
	loc5 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32)) R4474[Dtype(RTCW(loc1))-913])(loc1, (EIF_CHARACTER_8) '=', ((EIF_INTEGER_32) 3L));
	if ((EIF_BOOLEAN) (loc5 > ((EIF_INTEGER_32) 0L))) {
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4338[Dtype(RTCW(loc1))-910])(loc1, ((EIF_INTEGER_32) 3L), (EIF_INTEGER_32) (loc5 - ((EIF_INTEGER_32) 1L)));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4338[Dtype(RTCW(loc1))-910])(loc1, (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L)), ti4_1);
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4338[Dtype(RTCW(loc1))-910])(loc1, ((EIF_INTEGER_32) 3L), ti4_1);
	}
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_9_0_)) {
		loc3 = (EIF_REFERENCE) NULL;
		tr1 = *(EIF_REFERENCE *)(Current);
		F1107_7310(RTCW(tr1));
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(loc3 != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current);
				tb2 = F1107_7307(RTCW(tr1));
				tb1 = tb2;
			}
			if (tb1) break;
			tr1 = *(EIF_REFERENCE *)(Current);
			tr1 = F1095_7281(RTCW(tr1));
			loc4 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_1_);
			loc9 = tr1;
			if (EIF_TEST(loc9)) {
				tr1 = RTOSCF(5917,F917_5917, (Current));
				tb2 = F936_6053(RTCW(tr1), loc9, loc2);
				if (tb2) {
					loc3 = (EIF_REFERENCE) loc4;
					tr1 = *(EIF_REFERENCE *)(Current);
					tr1 = F1095_7281(RTCW(tr1));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
				}
			}
			tr1 = *(EIF_REFERENCE *)(Current);
			F1107_7311(RTCW(tr1));
		}
		*(EIF_BOOLEAN *)(Current+ _CHROFF_9_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	}
	loc8 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 == NULL) && (EIF_BOOLEAN)(loc8 != NULL))) {
		F1107_7310(RTCW(loc8));
		for (;;) {
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc3 != NULL)) {
				tb3 = F1107_7307(RTCW(loc8));
				tb2 = tb3;
			}
			if (tb2) break;
			loc4 = F1095_7281(RTCW(loc8));
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_1_);
			loc10 = tr1;
			if (EIF_TEST(loc10)) {
				tr1 = RTOSCF(5917,F917_5917, (Current));
				tb3 = F936_6053(RTCW(tr1), loc10, loc2);
				if (tb3) {
					loc3 = (EIF_REFERENCE) loc4;
				}
			}
			F1107_7311(RTCW(loc8));
		}
	}
	if ((EIF_BOOLEAN)(loc3 == NULL)) {
		loc7 = RTLNS(eif_new_type(1235, 0x01).id, 1235, _OBJSIZ_3_0_0_0_0_0_0_0_);
		F1236_8722(RTCW(loc7), loc2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F1192_8183(RTCW(tr1), loc7);
	} else {
		tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1309[Dtype(RTCW(loc3))-116])(loc3);
		if (tb3) {
			if ((EIF_BOOLEAN)(loc6 == NULL)) {
				F1107_7311(RTCW(arg1));
				tb3 = F1095_7283(RTCW(arg1));
				if (tb3) {
					loc7 = RTLNS(eif_new_type(1235, 0x01).id, 1235, _OBJSIZ_3_0_0_0_0_0_0_0_);
					F1236_8720(RTCW(loc7), loc3);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					F1192_8183(RTCW(tr1), loc7);
				} else {
					loc6 = F1095_7281(RTCW(arg1));
				}
			}
			if ((EIF_BOOLEAN)(loc6 != NULL)) {
				RTAR(Current, loc6);
				*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc6;
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1323[Dtype(RTCW(loc3))-116])(loc3, Current);
			}
		} else {
			tb3 = '\01';
			if (!(EIF_BOOLEAN)(loc6 == NULL)) {
				tb4 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1308[Dtype(RTCW(loc3))-116])(loc3);
				tb3 = tb4;
			}
			if (tb3) {
				RTAR(Current, loc6);
				*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc6;
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1323[Dtype(RTCW(loc3))-116])(loc3, Current);
			} else {
				loc7 = RTLNS(eif_new_type(1235, 0x01).id, 1235, _OBJSIZ_3_0_0_0_0_0_0_0_);
				F1236_8723(RTCW(loc7), loc3, loc6);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1192_8183(RTCW(tr1), loc7);
			}
		}
	}
	tb3 = F1107_7307(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb3) {
		F1107_7311(RTCW(arg1));
	}
	RTLE;
}

/* {AP_BASIC_PARSER}.parse_short */
void F1047_6900 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc5);
	RTLR(6,loc8);
	RTLR(7,loc7);
	RTLR(8,loc6);
	RTLIU(9);
	
	RTGC;
	loc1 = F1095_7281(RTCW(arg1));
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	for (;;) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
		if ((EIF_BOOLEAN) (loc2 > ti4_1)) break;
		loc3 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(loc1))-676])(loc1, loc2));
		loc4 = (EIF_REFERENCE) NULL;
		if (*(EIF_BOOLEAN *)(Current+ _CHROFF_9_0_)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			F1107_7310(RTCW(tr1));
			for (;;) {
				tb1 = '\01';
				if (!(EIF_BOOLEAN)(loc4 != NULL)) {
					tr1 = *(EIF_REFERENCE *)(Current);
					tb2 = F1107_7307(RTCW(tr1));
					tb1 = tb2;
				}
				if (tb1) break;
				tr1 = *(EIF_REFERENCE *)(Current);
				tr1 = F1095_7281(RTCW(tr1));
				loc5 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_4_);
				tb2 = '\0';
				tb3 = *(EIF_BOOLEAN *)(RTCW(loc5) + O1305[Dtype(loc5)-115]);
				if (tb3) {
					tc1 = *(EIF_CHARACTER_8 *)(RTCW(loc5) + O1303[Dtype(loc5)-115]);
					tb2 = (EIF_BOOLEAN)(tc1 == loc3);
				}
				if (tb2) {
					loc4 = (EIF_REFERENCE) loc5;
					tr1 = *(EIF_REFERENCE *)(Current);
					tr1 = F1095_7281(RTCW(tr1));
					RTAR(Current, tr1);
					*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
				}
				tr1 = *(EIF_REFERENCE *)(Current);
				F1107_7311(RTCW(tr1));
			}
			*(EIF_BOOLEAN *)(Current+ _CHROFF_9_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
		loc8 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 == NULL) && (EIF_BOOLEAN)(loc8 != NULL))) {
			F1107_7310(RTCW(loc8));
			for (;;) {
				tb2 = '\01';
				if (!(EIF_BOOLEAN)(loc4 != NULL)) {
					tb3 = F1107_7307(RTCW(loc8));
					tb2 = tb3;
				}
				if (tb2) break;
				loc5 = F1095_7281(RTCW(loc8));
				tb3 = '\0';
				tb4 = *(EIF_BOOLEAN *)(RTCW(loc5) + O1305[Dtype(loc5)-115]);
				if (tb4) {
					tc1 = *(EIF_CHARACTER_8 *)(RTCW(loc5) + O1303[Dtype(loc5)-115]);
					tb3 = (EIF_BOOLEAN)(tc1 == loc3);
				}
				if (tb3) {
					loc4 = (EIF_REFERENCE) loc5;
				}
				F1107_7311(RTCW(loc8));
			}
		}
		if ((EIF_BOOLEAN)(loc4 == NULL)) {
			loc7 = RTLNS(eif_new_type(1235, 0x01).id, 1235, _OBJSIZ_3_0_0_0_0_0_0_0_);
			tr1 = eif_out__c1_s1(loc3);
			F1236_8722(RTCW(loc7), tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			F1192_8183(RTCW(tr1), loc7);
		} else {
			tb3 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R1309[Dtype(RTCW(loc4))-116])(loc4);
			if (tb3) {
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				if ((EIF_BOOLEAN)(loc2 == ti4_2)) {
					F1107_7311(RTCW(arg1));
					tb3 = F1095_7283(RTCW(arg1));
					if ((EIF_BOOLEAN) !tb3) {
						loc6 = F1095_7281(RTCW(arg1));
					}
				} else {
					ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
					loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4338[Dtype(RTCW(loc1))-910])(loc1, (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)), ti4_2);
					loc2 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				}
				if ((EIF_BOOLEAN)(loc6 == NULL)) {
					loc7 = RTLNS(eif_new_type(1235, 0x01).id, 1235, _OBJSIZ_3_0_0_0_0_0_0_0_);
					F1236_8720(RTCW(loc7), loc4);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					F1192_8183(RTCW(tr1), loc7);
				} else {
					RTAR(Current, loc6);
					*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc6;
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1323[Dtype(RTCW(loc4))-116])(loc4, Current);
				}
			} else {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R1323[Dtype(RTCW(loc4))-116])(loc4, Current);
			}
		}
		loc2++;
	}
	tb3 = F1107_7307(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb3) {
		F1107_7311(RTCW(arg1));
	}
	RTLE;
}

/* {AP_BASIC_PARSER}.reset_parser */
void F1047_6901 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	F1193_8204(RTCW(tr1));
	loc1 = F1047_6869(Current);
	F1107_7310(RTCW(loc1));
	for (;;) {
		tb1 = F1107_7307(RTCW(loc1));
		if (tb1) break;
		tr1 = F1095_7281(RTCW(loc1));
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R1324[Dtype(RTCW(tr1))-116])(tr1);
		F1107_7311(RTCW(loc1));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,914,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1158, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	F1159_7647(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_9_0_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

void EIF_Minit307 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
