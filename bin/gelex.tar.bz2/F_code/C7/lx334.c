/*
 * Code for class LX_COMPRESSED_DFA
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx334.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_COMPRESSED_DFA}.make */
void F1075_7180 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_9_11_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_20_2_) = (EIF_BOOLEAN) tb1;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_9_20_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_20_3_) = (EIF_BOOLEAN) tb1;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_9_5_);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_20_13_) = (EIF_BOOLEAN) tb1;
	F1074_7139(Current, arg1);
	F1074_7140(Current);
	F1075_7187(Current);
	RTLE;
}

/* {LX_COMPRESSED_DFA}.print_backing_up_report */
void F1075_7182 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	F1074_7143(Current, arg1);
	tr1 = RTMS_EX_H("Compressed tables always back up.",33,1542497326);
	F927_5968(RTCW(arg1), tr1);
	RTLE;
}

/* {LX_COMPRESSED_DFA}.dangerous_variable_trail_rules */
EIF_REFERENCE F1075_7183 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLR(3,loc4);
	RTLR(4,loc7);
	RTLR(5,loc6);
	RTLR(6,loc5);
	RTLIU(7);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,162,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		Result = RTLNS(typres0.id, 1158, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = F702_3697(RTCW(tr1));
	F1159_7647(RTCW(Result), ti4_1);
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_20_3_)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
			loc4 = F1159_7653(RTCW(tr1), loc1);
			tb1 = F1070_7082(RTCW(loc4));
			if (tb1) {
				loc7 = *(EIF_REFERENCE *)(RTCW(loc4) + _REFACS_2_);
				loc6 = *(EIF_REFERENCE *)(RTCW(loc4));
				loc2 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_4_0_0_1_);
				for (;;) {
					if ((EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 1L))) break;
					loc5 = F1159_7653(RTCW(loc6), loc2);
					tb1 = *(EIF_BOOLEAN *)(RTCW(loc5)+ _CHROFF_3_0_);
					if (tb1) {
						loc3 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_4_0_0_1_);
						for (;;) {
							tb1 = '\01';
							if (!(EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 1L))) {
								tb2 = '\0';
								tr1 = F1159_7653(RTCW(loc7), loc3);
								tb3 = F1159_7660(RTCW(Result), tr1);
								if ((EIF_BOOLEAN) !tb3) {
									tr1 = F1159_7653(RTCW(loc7), loc3);
									tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
									tb3 = F1072_7098(RTCW(tr1), loc5);
									tb2 = tb3;
								}
								tb1 = tb2;
							}
							if (tb1) break;
							loc3--;
						}
						if ((EIF_BOOLEAN) (loc3 >= ((EIF_INTEGER_32) 1L))) {
							tr1 = F1159_7653(RTCW(loc7), loc3);
							F1159_7666(RTCW(Result), tr1);
						}
					}
					loc2--;
				}
			}
			loc1--;
		}
	}
	tr1 = RTOSCF(7218,F1075_7218, (Current));
	F1091_7280(RTCW(Result), tr1);
	RTLE;
	return Result;
}

/* {LX_COMPRESSED_DFA}.print_build_tables */
void F1075_7184 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("\011yy_build_tables\012\011\011\011-- Build scanner tables.\012\011\011do\012",50,1458749450);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTOSCF(7177,F1074_7177, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTMS_EX_H("yy_nxt := yy_nxt_template\012",26,1686686218);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTOSCF(7177,F1074_7177, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTMS_EX_H("yy_chk := yy_chk_template\012",26,1918825226);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTOSCF(7177,F1074_7177, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTMS_EX_H("yy_base := yy_base_template\012",28,1586599690);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTOSCF(7177,F1074_7177, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTMS_EX_H("yy_def := yy_def_template\012",26,1357078538);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) != NULL)) {
		tr1 = RTOSCF(7177,F1074_7177, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
		tr1 = RTMS_EX_H("yy_ec := yy_ec_template\012",24,98572554);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	}
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_10_) != NULL)) {
		tr1 = RTOSCF(7177,F1074_7177, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
		tr1 = RTMS_EX_H("yy_meta := yy_meta_template\012",28,2099191050);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	}
	tr1 = RTOSCF(7177,F1074_7177, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTMS_EX_H("yy_accept := yy_accept_template\012",32,1795444234);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_9_) != NULL)) {
		tr1 = RTOSCF(7177,F1074_7177, (Current));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
		tr1 = RTMS_EX_H("yy_acclist := yy_acclist_template\012",34,932227338);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	}
	tr1 = RTMS_EX_H("\011\011end\012",6,1719497226);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	RTLE;
}

/* {LX_COMPRESSED_DFA}.print_eiffel_tables */
void F1075_7185 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	tr1 = RTMS_EX_H("yy_nxt_template",15,1515781477);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	F1074_7158(Current, tr1, tr2, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
	tr1 = RTMS_EX_H("yy_chk_template",15,664094053);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	F1074_7158(Current, tr1, tr2, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
	tr1 = RTMS_EX_H("yy_base_template",16,657959525);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F1074_7158(Current, tr1, tr2, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
	tr1 = RTMS_EX_H("yy_def_template",15,2077151333);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	F1074_7158(Current, tr1, tr2, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
		tr1 = RTMS_EX_H("yy_ec_template",14,225934181);
		F1074_7158(Current, tr1, loc1, arg1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_10_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
		tr1 = RTMS_EX_H("yy_meta_template",16,1711774565);
		F1074_7158(Current, tr1, loc2, arg1);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
	tr1 = RTMS_EX_H("yy_accept_template",18,184292709);
	tr2 = *(EIF_REFERENCE *)(Current);
	F1074_7158(Current, tr1, tr2, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
		tr1 = RTMS_EX_H("yy_acclist_template",19,112732773);
		F1074_7158(Current, tr1, loc3, arg1);
	}
	RTLE;
}

/* {LX_COMPRESSED_DFA}.print_constants */
void F1075_7186 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("\011yyJam_base: INTEGER = ",23,1298637600);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	F924_5951(RTCW(arg1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_5_));
	tr1 = RTMS_EX_H("\012\011\011\011-- Position in `yy_nxt\'/`yy_chk\' tables\012\011\011\011-- where default jam table starts\012\012\011yyJam_state: INTEGER = ",106,1382905632);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	F924_5951(RTCW(arg1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_4_));
	tr1 = RTMS_EX_H("\012\011\011\011-- State id corresponding to jam state\012\012\011yyTemplate_mark: INTEGER = ",72,331346464);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	F924_5951(RTCW(arg1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_6_));
	tr1 = RTMS_EX_H("\012\011\011\011-- Mark between normal states and templates\012\012\011yyNull_equiv_class: INTEGER = ",80,61880608);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	F924_5951(RTCW(arg1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_2_));
	tr1 = RTMS_EX_H("\012\011\011\011-- Equivalence code for NULL character\012\012\011yyMax_symbol_equiv_class: INTEGER = ",81,1148189216);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	F924_5951(RTCW(arg1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_3_));
	tr1 = RTMS_EX_H("\012\011\011\011-- All symbols greater than this symbol will have\012\011\011\011-- the same equivalence class as this symbol\012\012\011yyReject_used: BOOLEAN = ",129,1799038752);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTOSCF(2134,F222_2134, (Current));
	F9_86(RTCW(tr1), arg1, *(EIF_BOOLEAN *)(Current+ _CHROFF_20_2_));
	tr1 = RTMS_EX_H("\012\011\011\011-- Is `reject\' called\?\012\012\011yyVariable_trail_context: BOOLEAN = ",65,94467104);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTOSCF(2134,F222_2134, (Current));
	F9_86(RTCW(tr1), arg1, *(EIF_BOOLEAN *)(Current+ _CHROFF_20_3_));
	tr1 = RTMS_EX_H("\012\011\011\011-- Is there a regular expression with\012\011\011\011-- both leading and trailing parts having\012\011\011\011-- variable length\?\012\012\011yyReject_or_variable_trail_context: BOOLEAN = ",158,1505299488);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTOSCF(2134,F222_2134, (Current));
	F9_86(RTCW(tr1), arg1, (EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_20_2_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_20_3_)));
	tr1 = RTMS_EX_H("\012\011\011\011-- Is `reject\' called or is there a\012\011\011\011-- regular expression with both leading\012\011\011\011-- and trailing parts having variable length\?\012\012",133,1192085514);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	F1074_7156(Current, arg1);
	RTLE;
}

/* {LX_COMPRESSED_DFA}.build */
void F1075_7187 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc4);
	RTLR(3,tr2);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_12_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_13_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_14_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	tr1 = RTLNSMART(eif_new_type(1151, 0).id);
	F1145_7496(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,46,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc4 = RTLNS(typres0.id, 1158, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	F1159_7647(RTCW(loc4), ((EIF_INTEGER_32) 500L));
	RTAR(Current, loc4);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) loc4;
	if (*(EIF_BOOLEAN *)(Current+ _CHROFF_20_13_)) {
		tr1 = RTLNSMART(eif_new_type(95, 0).id);
		F96_1050(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_8_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_9_));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	}
	tr1 = RTLNSMART(eif_new_type(1148, 0).id);
	F1149_7581(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_16_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(96, 0).id);
	F97_1070(RTCW(tr1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_8_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_9_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,702,834,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F703_3685(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 2000L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,702,834,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F703_3685(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 2000L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,702,834,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_4_0_0_0_);
	F703_3685(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,702,834,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_4_0_0_0_);
	F703_3685(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) tr1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_10_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_7_))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		loc2 = F1159_7653(RTCW(tr1), loc1);
		F1073_7134(Current, loc2);
		F1075_7192(Current, loc2);
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	loc2 = F1159_7653(RTCW(tr1), loc1);
	F1073_7134(Current, loc2);
	loc3 = RTLNS(eif_new_type(46, 0x01).id, 46, _OBJSIZ_0_0_0_4_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_4_0_0_0_);
	F47_638(RTCW(loc3), ti4_1, ((EIF_INTEGER_32) -32766L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	F1159_7666(RTCW(loc4), loc3);
	loc1++;
	for (;;) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		if ((EIF_BOOLEAN) (loc1 > ti4_1)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
		loc2 = F1159_7653(RTCW(tr1), loc1);
		F1073_7134(Current, loc2);
		tb1 = F1070_7081(RTCW(loc2));
		if ((EIF_BOOLEAN) !tb1) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_10_))++;
		}
		F1075_7192(Current, loc2);
		loc1++;
	}
	F1075_7195(Current);
	F1075_7196(Current);
	F1075_7197(Current);
	*(EIF_REFERENCE *)(Current + _REFACS_12_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) NULL;
	F1075_7188(Current);
	F1075_7189(Current);
	F1075_7190(Current);
	RTLE;
}

/* {LX_COMPRESSED_DFA}.build_nxt_chk_tables */
void F1075_7188 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_13_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,702,834,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 702, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F703_3685(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc4);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,702,834,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc2 = RTLNS(typres0.id, 702, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F703_3685(RTCW(loc2), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc4);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc3 > loc4)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		ti4_1 = F703_3690(RTCW(tr1), loc3);
		F703_3709(RTCW(loc1), ti4_1, loc3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		ti4_1 = F703_3690(RTCW(tr1), loc3);
		F703_3709(RTCW(loc2), ti4_1, loc3);
		loc3++;
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) loc1;
	RTAR(Current, loc2);
	*(EIF_REFERENCE *)(Current + _REFACS_6_) = (EIF_REFERENCE) loc2;
	RTLE;
}

/* {LX_COMPRESSED_DFA}.build_base_def_tables */
void F1075_7189 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_14_);
	loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ti4_1);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,702,834,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 702, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F703_3685(RTCW(loc1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc4);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,702,834,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc2 = RTLNS(typres0.id, 702, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F703_3685(RTCW(loc2), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc4);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc3 > loc4)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
		ti4_1 = F703_3690(RTCW(tr1), loc3);
		F703_3709(RTCW(loc1), ti4_1, loc3);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
		ti4_1 = F703_3690(RTCW(tr1), loc3);
		F703_3709(RTCW(loc2), ti4_1, loc3);
		loc3++;
	}
	RTAR(Current, loc1);
	*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc1;
	RTAR(Current, loc2);
	*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) loc2;
	RTLE;
}

/* {LX_COMPRESSED_DFA}.build_accept_tables */
void F1075_7190 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc9);
	RTLR(3,loc8);
	RTLR(4,loc10);
	RTLR(5,loc6);
	RTLR(6,loc7);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	if ((EIF_BOOLEAN) (*(EIF_BOOLEAN *)(Current+ _CHROFF_20_2_) || *(EIF_BOOLEAN *)(Current+ _CHROFF_20_3_))) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,702,834,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc9 = RTLNS(typres0.id, 702, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		F703_3685(RTCW(loc9), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 2L)));
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
			loc8 = F1159_7653(RTCW(tr1), loc1);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_1_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
			loc2 += ti4_1;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_2_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
			loc2 += ti4_1;
			loc1++;
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,702,834,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc10 = RTLNS(typres0.id, 702, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		ti4_1 = eif_max_int32 (loc2,((EIF_INTEGER_32) 1L));
		F703_3685(RTCW(loc10), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1);
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			F703_3709(RTCW(loc9), loc2, loc1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
			loc8 = F1159_7653(RTCW(tr1), loc1);
			loc6 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_1_);
			loc5 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_4_0_0_1_);
			loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc4 > loc5)) break;
				loc7 = F1159_7653(RTCW(loc6), loc4);
				tb1 = '\0';
				if (*(EIF_BOOLEAN *)(Current+ _CHROFF_20_3_)) {
					tb2 = F163_1720(RTCW(loc7));
					tb1 = tb2;
				}
				if (tb1) {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_2_2_0_0_);
					F703_3709(RTCW(loc10), (EIF_INTEGER_32) -ti4_1, loc2);
				} else {
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_2_2_0_0_);
					F703_3709(RTCW(loc10), ti4_1, loc2);
				}
				loc2++;
				loc4++;
			}
			loc6 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_2_);
			loc5 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_4_0_0_1_);
			loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc4 > loc5)) break;
				loc7 = F1159_7653(RTCW(loc6), loc4);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_2_2_0_0_);
				F703_3709(RTCW(loc10), (EIF_INTEGER_32) ((EIF_INTEGER_32) -ti4_1 - *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_0_)), loc2);
				loc2++;
				loc4++;
			}
			loc1++;
		}
		F703_3709(RTCW(loc9), loc2, loc1);
		F703_3709(RTCW(loc9), loc2, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)));
		RTAR(Current, loc9);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc9;
		RTAR(Current, loc10);
		*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) loc10;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,702,834,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc9 = RTLNS(typres0.id, 702, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		F703_3685(RTCW(loc9), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L)));
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
			loc8 = F1159_7653(RTCW(tr1), loc1);
			tb1 = F1070_7081(RTCW(loc8));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc8) + _REFACS_1_);
				tr1 = F1159_7654(RTCW(tr1));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_2_0_0_);
				F703_3709(RTCW(loc9), ti4_1, loc1);
			} else {
				F703_3709(RTCW(loc9), ((EIF_INTEGER_32) 0L), loc1);
			}
			loc1++;
		}
		F703_3709(RTCW(loc9), ((EIF_INTEGER_32) 0L), loc1);
		RTAR(Current, loc9);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) loc9;
		*(EIF_REFERENCE *)(Current + _REFACS_9_) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {LX_COMPRESSED_DFA}.resize */
void F1075_7191 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	F1159_7700(RTCW(tr1), arg1);
	tr1 = RTOSCF(3841,F770_3841, (Current));
	F940_6166(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_7_), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), arg1);
	tr1 = RTOSCF(3841,F770_3841, (Current));
	F940_6166(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_8_), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), arg1);
	RTLE;
}

/* {LX_COMPRESSED_DFA}.put_state */
void F1075_7192 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc18 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc19 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc20 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc21 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc22 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc23 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(19);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc22);
	RTLR(4,tr1);
	RTLR(5,loc9);
	RTLR(6,loc10);
	RTLR(7,loc11);
	RTLR(8,loc2);
	RTLR(9,loc12);
	RTLR(10,loc17);
	RTLR(11,loc14);
	RTLR(12,loc16);
	RTLR(13,loc18);
	RTLR(14,tr2);
	RTLR(15,loc15);
	RTLR(16,loc19);
	RTLR(17,loc23);
	RTLR(18,loc3);
	RTLIU(19);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc4 = F1067_7047(RTCW(loc1));
	loc5 = F1067_7048(RTCW(loc1));
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc4 * ((EIF_INTEGER_32) 100L)) < (EIF_INTEGER_32) (loc5 * ((EIF_INTEGER_32) 15L)))) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_0_);
		F1075_7193(Current, ti4_1, ((EIF_INTEGER_32) -32766L), loc1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_9_));
	} else {
		RTCT0("protos_not_void", EX_CHECK);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
		loc22 = tr1;
		if (EIF_TEST(loc22)) {
			RTCK0;
		} else {
			RTCF0;
		}
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,1069,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc9 = RTLNS(typres0.id, 1158, _OBJSIZ_4_0_0_2_0_0_0_0_);
		}
		F1159_7647(RTCW(loc9), loc4);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1159,834,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc10 = RTLNS(typres0.id, 1159, _OBJSIZ_4_0_0_2_0_0_0_0_);
		}
		F1160_7647(RTCW(loc10), loc4);
		loc11 = F1159_7656(RTCW(loc9));
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		loc2 = F1181_7972(RTCW(tr1));
		F990_6721(RTCW(loc2));
		for (;;) {
			tb1 = F1013_6749(RTCW(loc2));
			if (tb1) break;
			loc12 = F975_6701(RTCW(loc2));
			F990_6721(RTCW(loc11));
			F990_6723(RTCW(loc11), loc12);
			tb2 = F1038_6796(RTCW(loc11));
			if ((EIF_BOOLEAN) !tb2) {
				loc7 = F1034_6776(RTCW(loc11));
				ti4_1 = F1160_7653(RTCW(loc10), loc7);
				F1160_7664(RTCW(loc10), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)), loc7);
			} else {
				F1159_7666(RTCW(loc9), loc12);
				F1160_7666(RTCW(loc10), ((EIF_INTEGER_32) 1L));
			}
			F990_6722(RTCW(loc2));
		}
		F990_6724(RTCW(loc11));
		loc12 = RTOSCF(7206,F1075_7206, (Current));
		loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		loc8 = *(EIF_INTEGER_32 *)(RTCW(loc9)+ _LNGOFF_4_0_0_1_);
		for (;;) {
			if ((EIF_BOOLEAN) (loc6 > loc8)) break;
			ti4_1 = F1160_7653(RTCW(loc10), loc6);
			if ((EIF_BOOLEAN) (loc13 < ti4_1)) {
				loc12 = F1159_7653(RTCW(loc9), loc6);
				loc13 = F1160_7653(RTCW(loc10), loc6);
			}
			loc6++;
		}
		loc17 = F1151_7590(loc22);
		tb2 = F1081_7250(loc22);
		if ((EIF_BOOLEAN) !tb2) {
			loc14 = F1145_7503(loc22);
			F990_6721(RTCW(loc17));
		}
		loc20 = (EIF_INTEGER_32) loc4;
		loc16 = F1151_7590(loc22);
		F990_6721(RTCW(loc16));
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc13 * ((EIF_INTEGER_32) 100L)) > (EIF_INTEGER_32) (loc4 * ((EIF_INTEGER_32) 50L)))) {
			for (;;) {
				tb2 = '\01';
				tb3 = *(EIF_BOOLEAN *)(RTCW(loc16)+ _CHROFF_3_1_);
				if (!tb3) {
					tr1 = F1040_6809(RTCW(loc16));
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
					tb2 = (EIF_BOOLEAN)(tr1 == loc12);
				}
				if (tb2) break;
				F990_6722(RTCW(loc16));
			}
			tb3 = *(EIF_BOOLEAN *)(RTCW(loc16)+ _CHROFF_3_1_);
			if ((EIF_BOOLEAN) !tb3) {
				loc14 = F1040_6809(RTCW(loc16));
				F975_6706(RTCW(loc17), loc16);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc14));
				tr2 = RTOSCF(7206,F1075_7206, (Current));
				loc18 = F1067_7041(RTCW(loc1), tr1, tr2);
				loc20 = F1067_7047(RTCW(loc18));
			}
		} else {
			loc12 = RTOSCF(7206,F1075_7206, (Current));
			tb3 = F1081_7250(loc22);
			if ((EIF_BOOLEAN) !tb3) {
				loc14 = F1145_7503(loc22);
				F975_6706(RTCW(loc17), loc16);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc14));
				tr2 = RTOSCF(7206,F1075_7206, (Current));
				loc18 = F1067_7041(RTCW(loc1), tr1, tr2);
				loc20 = F1067_7047(RTCW(loc18));
			}
		}
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc20 * ((EIF_INTEGER_32) 100L)) > (EIF_INTEGER_32) (loc4 * ((EIF_INTEGER_32) 10L)))) {
			for (;;) {
				tb3 = *(EIF_BOOLEAN *)(RTCW(loc16)+ _CHROFF_3_1_);
				if (tb3) break;
				loc15 = F1040_6809(RTCW(loc16));
				tr1 = *(EIF_REFERENCE *)(RTCW(loc15));
				tr2 = RTOSCF(7206,F1075_7206, (Current));
				loc19 = F1067_7041(RTCW(loc1), tr1, tr2);
				ti4_1 = F1067_7047(RTCW(loc19));
				if ((EIF_BOOLEAN) (ti4_1 < loc20)) {
					loc14 = (EIF_REFERENCE) loc15;
					F975_6706(RTCW(loc17), loc16);
					loc18 = (EIF_REFERENCE) loc19;
					loc20 = F1067_7047(RTCW(loc18));
				}
				F990_6722(RTCW(loc16));
			}
		} else {
			F990_6724(RTCW(loc16));
		}
		if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc20 * ((EIF_INTEGER_32) 100L)) > (EIF_INTEGER_32) (loc4 * ((EIF_INTEGER_32) 50L)))) {
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc13 * ((EIF_INTEGER_32) 100L)) >= (EIF_INTEGER_32) (loc4 * ((EIF_INTEGER_32) 60L)))) {
				RTCT0("templates_not_void", EX_CHECK);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
				loc23 = tr1;
				if (EIF_TEST(loc23)) {
					RTCK0;
				} else {
					RTCF0;
				}
				F1149_7584(loc23, arg1, loc12);
				loc3 = F1145_7504(loc23);
				loc21 = *(EIF_INTEGER_32 *)(loc23+ _LNGOFF_5_0_0_0_);
				loc21 = (EIF_INTEGER_32) (EIF_INTEGER_32) -loc21;
				F1152_7606(loc22, loc21, loc3, loc12);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_0_);
				tr1 = RTOSCF(7206,F1075_7206, (Current));
				tr1 = F1067_7041(RTCW(loc1), loc3, tr1);
				ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_9_);
				F1075_7193(Current, ti4_1, loc21, tr1, ti4_2);
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_0_);
				tr1 = F1066_7036(RTCW(loc1));
				F1152_7606(loc22, ti4_1, tr1, loc12);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_0_);
				F1075_7193(Current, ti4_1, ((EIF_INTEGER_32) -32766L), loc1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_9_));
			}
		} else {
			RTCT0("proto /= Void and difference /= Void", EX_CHECK);
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc14 != NULL) && (EIF_BOOLEAN)(loc18 != NULL))) {
				RTCK0;
			} else {
				RTCF0;
			}
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_0_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc14)+ _LNGOFF_2_0_0_0_);
			F1075_7193(Current, ti4_1, ti4_2, loc18, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_9_));
			F1152_7607(loc22, loc17);
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc20 * ((EIF_INTEGER_32) 100L)) >= (EIF_INTEGER_32) (loc4 * ((EIF_INTEGER_32) 20L)))) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_0_);
				tr1 = F1066_7036(RTCW(loc1));
				F1152_7606(loc22, ti4_1, tr1, loc12);
			}
		}
		F990_6724(RTCW(loc17));
	}
	RTLE;
}

/* {LX_COMPRESSED_DFA}.put_entry */
void F1075_7193 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc15);
	RTLR(1,Current);
	RTLR(2,arg3);
	RTLR(3,tr1);
	RTLR(4,loc16);
	RTLR(5,loc12);
	RTLR(6,loc11);
	RTLR(7,loc10);
	RTLR(8,loc14);
	RTLIU(9);
	
	RTGC;
	RTCT0("transitions_not_void", EX_CHECK);
	loc15 = arg3;
	if ((EIF_TRUE)) {
		RTCK0;
	} else {
		RTCF0;
	}
	ti4_1 = F1067_7047(RTCW(arg3));
	switch (ti4_1) {
		case 0L:
			if ((EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) -32766L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				F703_3709(RTCW(tr1), ((EIF_INTEGER_32) -32766L), arg1);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
				F703_3709(RTCW(tr1), ((EIF_INTEGER_32) 0L), arg1);
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			F703_3709(RTCW(tr1), arg2, arg1);
			break;
		case 1L:
			RTCT0("singletons_not_void", EX_CHECK);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
			loc16 = tr1;
			if (EIF_TEST(loc16)) {
				RTCK0;
			} else {
				RTCF0;
			}
			loc13 = *(EIF_INTEGER_32 *)(loc15+ _LNGOFF_1_0_0_0_);
			if ((EIF_BOOLEAN)(loc13 == ((EIF_INTEGER_32) 0L))) {
				loc13 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg4 + ((EIF_INTEGER_32) 1L));
			}
			loc12 = RTLNS(eif_new_type(46, 0x01).id, 46, _OBJSIZ_0_0_0_4_0_0_0_0_);
			tr1 = *(EIF_REFERENCE *)(loc15);
			tr1 = F1163_7739(RTCW(tr1));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_0_);
			F47_638(RTCW(loc12), arg1, arg2, loc13, ti4_1);
			tb1 = F1153_7612(loc16);
			if ((EIF_BOOLEAN) !tb1) {
				F1159_7666(loc16, loc12);
			} else {
				F1075_7194(Current, loc12);
			}
			break;
		default:
			loc11 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
			loc10 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
			loc5 = *(EIF_INTEGER_32 *)(loc15+ _LNGOFF_1_0_0_0_);
			if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 0L))) {
				loc5 = *(EIF_INTEGER_32 *)(loc15+ _LNGOFF_1_0_0_1_);
				loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg4 + ((EIF_INTEGER_32) 1L));
			} else {
				loc6 = *(EIF_INTEGER_32 *)(loc15+ _LNGOFF_1_0_0_2_);
			}
			tr1 = *(EIF_REFERENCE *)(loc15);
			loc14 = F1181_7972(RTCW(tr1));
			loc3 = F1067_7047(loc15);
			loc4 = F1067_7048(loc15);
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc3 * ((EIF_INTEGER_32) 100L)) <= (EIF_INTEGER_32) (loc4 * ((EIF_INTEGER_32) 15L)))) {
				loc7 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_12_);
				for (;;) {
					if ((EIF_BOOLEAN) (loc7 >= loc5)) break;
					loc7++;
					for (;;) {
						ti4_1 = F703_3690(RTCW(loc10), loc7);
						if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) break;
						loc7++;
					}
				}
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc7 + loc6) - loc5) + ((EIF_INTEGER_32) 1L));
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc11)+ _LNGOFF_1_1_0_0_);
				if ((EIF_BOOLEAN) (loc2 >= ti4_2)) {
					loc2 += ((EIF_INTEGER_32) 2000L);
					tr1 = RTOSCF(3841,F770_3841, (Current));
					F940_6166(RTCW(tr1), loc11, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc2);
					tr1 = RTOSCF(3841,F770_3841, (Current));
					F940_6166(RTCW(tr1), loc10, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc2);
				}
				F990_6721(RTCW(loc14));
				for (;;) {
					tb1 = F1013_6749(RTCW(loc14));
					if (tb1) break;
					loc13 = F1023_6768(RTCW(loc14));
					if ((EIF_BOOLEAN)(loc13 == ((EIF_INTEGER_32) 0L))) {
						loc13 = (EIF_INTEGER_32) loc6;
					}
					ti4_2 = F703_3690(RTCW(loc10), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc7 + loc13) - loc5));
					if ((EIF_BOOLEAN)(ti4_2 != ((EIF_INTEGER_32) 0L))) {
						loc7++;
						loc2 = *(EIF_INTEGER_32 *)(RTCW(loc11)+ _LNGOFF_1_1_0_0_);
						for (;;) {
							tb2 = '\01';
							if (!(EIF_BOOLEAN) (loc7 > loc2)) {
								ti4_2 = F703_3690(RTCW(loc10), loc7);
								tb2 = (EIF_BOOLEAN)(ti4_2 == ((EIF_INTEGER_32) 0L));
							}
							if (tb2) break;
							loc7++;
						}
						loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc7 + loc6) - loc5) + ((EIF_INTEGER_32) 1L));
						ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc11)+ _LNGOFF_1_1_0_0_);
						if ((EIF_BOOLEAN) (loc2 >= ti4_2)) {
							loc2 += ((EIF_INTEGER_32) 2000L);
							tr1 = RTOSCF(3841,F770_3841, (Current));
							F940_6166(RTCW(tr1), loc11, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc2);
							tr1 = RTOSCF(3841,F770_3841, (Current));
							F940_6166(RTCW(tr1), loc10, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc2);
						}
						F990_6721(RTCW(loc14));
					} else {
						F990_6722(RTCW(loc14));
					}
				}
			} else {
				loc7 = eif_max_int32 (loc5,(EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_13_) + ((EIF_INTEGER_32) 1L)));
			}
			loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 - loc5);
			loc9 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + loc6);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc9 + ((EIF_INTEGER_32) 1L));
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(loc11)+ _LNGOFF_1_1_0_0_);
			if ((EIF_BOOLEAN) (loc2 >= ti4_2)) {
				loc2 += ((EIF_INTEGER_32) 2000L);
				tr1 = RTOSCF(3841,F770_3841, (Current));
				F940_6166(RTCW(tr1), loc11, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc2);
				tr1 = RTOSCF(3841,F770_3841, (Current));
				F940_6166(RTCW(tr1), loc10, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc2);
			}
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
			F703_3709(RTCW(tr1), loc8, arg1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
			F703_3709(RTCW(tr1), arg2, arg1);
			F990_6721(RTCW(loc14));
			for (;;) {
				tb3 = F1013_6749(RTCW(loc14));
				if (tb3) break;
				loc13 = F1023_6768(RTCW(loc14));
				if ((EIF_BOOLEAN)(loc13 == ((EIF_INTEGER_32) 0L))) {
					loc13 = (EIF_INTEGER_32) loc6;
				}
				tr1 = F975_6701(RTCW(loc14));
				ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_0_);
				F703_3709(RTCW(loc11), ti4_2, (EIF_INTEGER_32) (loc8 + loc13));
				F703_3709(RTCW(loc10), arg1, (EIF_INTEGER_32) (loc8 + loc13));
				F990_6722(RTCW(loc14));
			}
			if ((EIF_BOOLEAN)(loc7 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_12_))) {
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 1L));
				for (;;) {
					ti4_2 = F703_3690(RTCW(loc10), loc1);
					if ((EIF_BOOLEAN)(ti4_2 == ((EIF_INTEGER_32) 0L))) break;
					loc1++;
				}
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_12_) = (EIF_INTEGER_32) loc1;
			}
			ti4_3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_13_);
			ti4_3 = eif_max_int32 (ti4_3,loc9);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_13_) = (EIF_INTEGER_32) ti4_3;
			break;
	}
	RTLE;
}

/* {LX_COMPRESSED_DFA}.put_singleton */
void F1075_7194 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_1_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_0_);
	loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_12_);
	if ((EIF_BOOLEAN) (loc5 < loc1)) {
		loc5 = (EIF_INTEGER_32) loc1;
	}
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
	for (;;) {
		tb1 = '\01';
		if (!(EIF_BOOLEAN) (loc5 > loc3)) {
			ti4_1 = F703_3690(RTCW(loc4), loc5);
			tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
		}
		if (tb1) break;
		loc5++;
	}
	if ((EIF_BOOLEAN) (loc5 > loc3)) {
		loc3 += ((EIF_INTEGER_32) 2000L);
		tr1 = RTOSCF(3841,F770_3841, (Current));
		F940_6166(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_5_), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc3);
		tr1 = RTOSCF(3841,F770_3841, (Current));
		F940_6166(RTCW(tr1), loc4, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc3);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	F703_3709(RTCW(tr1), (EIF_INTEGER_32) (loc5 - loc1), loc2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_3_);
	F703_3709(RTCW(tr1), ti4_1, loc2);
	F703_3709(RTCW(loc4), loc2, loc5);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_0_0_0_2_);
	F703_3709(RTCW(tr1), ti4_1, loc5);
	if ((EIF_BOOLEAN) (loc5 > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_13_))) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_13_) = (EIF_INTEGER_32) loc5;
	}
	if ((EIF_BOOLEAN)(loc5 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_12_))) {
		loc5++;
		for (;;) {
			ti4_1 = F703_3690(RTCW(loc4), loc5);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) break;
			loc5++;
		}
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_12_) = (EIF_INTEGER_32) loc5;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
		loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_12_) > loc3)) {
			loc3 += ((EIF_INTEGER_32) 2000L);
			tr1 = RTOSCF(3841,F770_3841, (Current));
			F940_6166(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_5_), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc3);
			tr1 = RTOSCF(3841,F770_3841, (Current));
			F940_6166(RTCW(tr1), loc4, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc3);
		}
	}
	RTLE;
}

/* {LX_COMPRESSED_DFA}.put_templates */
void F1075_7195 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(7);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc8);
	RTLR(3,loc6);
	RTLR(4,loc9);
	RTLR(5,loc1);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_6_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_16_);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		F96_1064(loc8);
		loc6 = F96_1068(loc8, ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_9_) + ((EIF_INTEGER_32) 1L)));
		loc7 = *(EIF_INTEGER_32 *)(loc8 + O1061[Dtype(loc8)-95]);
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_8_) == ((EIF_INTEGER_32) 0L))) {
			loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_8_);
			loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_9_);
			for (;;) {
				if ((EIF_BOOLEAN) (loc3 > loc4)) break;
				ti4_1 = F703_3690(RTCW(loc6), loc3);
				if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
					F703_3709(RTCW(loc6), (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 1L)), loc3);
				}
				loc3++;
			}
			ti4_1 = F703_3690(RTCW(loc6), ((EIF_INTEGER_32) 0L));
			F703_3709(RTCW(loc6), ti4_1, (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L)));
			F703_3709(RTCW(loc6), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
		}
		RTAR(Current, loc6);
		*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) loc6;
	} else {
		loc7 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_9_);
		*(EIF_REFERENCE *)(Current + _REFACS_10_) = (EIF_REFERENCE) NULL;
	}
	RTCT0("templates_not_void", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_18_);
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		RTCK0;
	} else {
		RTCF0;
	}
	ti4_1 = *(EIF_INTEGER_32 *)(loc9+ _LNGOFF_5_0_0_0_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_14_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	loc5 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_14_);
	loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_0_);
	if ((EIF_BOOLEAN) (ti4_1 < loc5)) {
		tr1 = RTOSCF(3841,F770_3841, (Current));
		F940_6166(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_7_), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc5);
		tr1 = RTOSCF(3841,F770_3841, (Current));
		F940_6166(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_8_), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc5);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 2L));
	loc1 = F1145_7505(loc9);
	F990_6721(RTCW(loc1));
	for (;;) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc1)+ _CHROFF_3_1_);
		if (tb1) break;
		tr1 = F1040_6809(RTCW(loc1));
		loc2 = F1149_7583(loc9, tr1);
		F1075_7193(Current, loc3, ((EIF_INTEGER_32) -32766L), loc2, loc7);
		loc3++;
		F990_6722(RTCW(loc1));
	}
	RTLE;
}

/* {LX_COMPRESSED_DFA}.put_singletons */
void F1075_7196 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTCT0("singletons_not_void", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc1 = *(EIF_INTEGER_32 *)(loc2+ _LNGOFF_4_0_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) break;
		tr1 = F1159_7653(loc2, loc1);
		F1075_7194(Current, tr1);
		loc1--;
	}
	RTLE;
}

/* {LX_COMPRESSED_DFA}.put_jam_state */
void F1075_7197 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc8);
	RTLR(3,loc9);
	RTLR(4,loc10);
	RTLR(5,loc11);
	RTLIU(6);
	
	RTGC;
	loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_7_);
	loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_4_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_5_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_13_) + ((EIF_INTEGER_32) 1L));
	loc7 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_4_);
	loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_5_);
	loc8 = *(EIF_REFERENCE *)(Current + _REFACS_7_);
	loc9 = *(EIF_REFERENCE *)(Current + _REFACS_8_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		ti4_1 = F703_3690(RTCW(loc8), loc1);
		if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) -32766L))) {
			F703_3709(RTCW(loc8), loc6, loc1);
		}
		loc4 = F703_3690(RTCW(loc9), loc1);
		if ((EIF_BOOLEAN)(loc4 == ((EIF_INTEGER_32) -32766L))) {
			F703_3709(RTCW(loc9), loc7, loc1);
		} else {
			if ((EIF_BOOLEAN) (loc4 < ((EIF_INTEGER_32) 0L))) {
				F703_3709(RTCW(loc9), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 - loc4) + ((EIF_INTEGER_32) 1L)), loc1);
			}
		}
		loc1++;
	}
	F703_3709(RTCW(loc8), loc6, loc7);
	F703_3709(RTCW(loc9), ((EIF_INTEGER_32) 0L), loc7);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_11_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_14_);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ti4_1);
	loc1++;
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		F703_3709(RTCW(loc9), loc7, loc1);
		loc1++;
	}
	loc10 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	loc11 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_13_);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_9_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_8_);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 + ti4_1) - ti4_2) + ((EIF_INTEGER_32) 2L));
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc10)+ _LNGOFF_1_1_0_0_);
	if ((EIF_BOOLEAN) (loc3 > ti4_1)) {
		tr1 = RTOSCF(3841,F770_3841, (Current));
		F940_6166(RTCW(tr1), loc10, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc3);
		tr1 = RTOSCF(3841,F770_3841, (Current));
		F940_6166(RTCW(tr1), loc11, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc3);
	}
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_13_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tb1 = '\01';
		ti4_1 = F703_3690(RTCW(loc11), loc1);
		if (!(EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
			ti4_1 = F703_3690(RTCW(loc10), loc1);
			tb1 = (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
		}
		if (tb1) {
			F703_3709(RTCW(loc10), loc7, loc1);
		}
		loc1++;
	}
	F703_3709(RTCW(loc10), loc5, loc6);
	F703_3709(RTCW(loc11), loc7, loc6);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc3)) break;
		F703_3709(RTCW(loc10), loc7, loc1);
		F703_3709(RTCW(loc11), loc7, loc1);
		loc1++;
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_13_) = (EIF_INTEGER_32) loc3;
	RTLE;
}

/* {LX_COMPRESSED_DFA}.null_state */
static EIF_REFERENCE F1075_7206_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (7206);
#define Result RTOSR(7206)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc1 = RTLNS(typres0.id, 1158, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	F1159_7647(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	tr1 = RTLNS(eif_new_type(1069, 0x01).id, 1069, _OBJSIZ_4_0_0_2_0_0_0_0_);
	F1070_7071(RTCW(tr1), loc1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_8_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_20_14_0_9_));
	Result = (EIF_REFERENCE) tr1;
	F1070_7080(RTCW(Result), ((EIF_INTEGER_32) 0L));
	RTOSE (7206);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1075_7206 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(7206,F1075_7206_body,(Current));
}

/* {LX_COMPRESSED_DFA}.rule_sorter */
static EIF_REFERENCE F1075_7218_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDD;
	RTLD;
	
	dftype = Dftype(Current);

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (7218);
#define Result RTOSR(7218)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,234,0xFF01,162,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 234, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,76,0xFF01,162,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 76, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F74_947(RTCW(tr1), loc1);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (7218);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1075_7218 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(7218,F1075_7218_body,(Current));
}

void EIF_Minit334 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
