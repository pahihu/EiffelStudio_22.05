/*
 * Code for class KL_SHARED_FILE_SYSTEM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl305.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_SHARED_FILE_SYSTEM}.file_system */
static EIF_REFERENCE F1045_6825_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_BOOLEAN tb1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6825);
#define Result RTOSR(6825)
	RTOC_NEW(Result);
	tb1 = RTOSCF(54,F3_54, (RTCV(RTOSCF(825,F60_825, (Current)))));
	if (tb1) {
		Result = RTOSCF(6826,F1045_6826, (Current));
	} else {
		tb1 = RTOSCF(55,F3_55, (RTCV(RTOSCF(825,F60_825, (Current)))));
		if (tb1) {
			Result = RTOSCF(6828,F1045_6828, (Current));
		} else {
			Result = RTOSCF(6828,F1045_6828, (Current));
		}
	}
	RTOSE (6825);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1045_6825 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6825,F1045_6825_body,(Current));
}

/* {KL_SHARED_FILE_SYSTEM}.windows_file_system */
static EIF_REFERENCE F1045_6826_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6826);
#define Result RTOSR(6826)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1189, 0x01).id, 1189, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6826);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1045_6826 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6826,F1045_6826_body,(Current));
}

/* {KL_SHARED_FILE_SYSTEM}.unix_file_system */
static EIF_REFERENCE F1045_6828_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (6828);
#define Result RTOSR(6828)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1188, 0x01).id, 1188, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (6828);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1045_6828 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(6828,F1045_6828_body,(Current));
}

void EIF_Minit305 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
