/*
 * Code for class LX_DFA
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx332.h"
#include "eif_helpers.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_DFA}.initialize */
void F1073_7122 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O5466[dtype-1072]) = (EIF_INTEGER_32) arg2;
	*(EIF_INTEGER_32 *)(Current + O5467[dtype-1072]) = (EIF_INTEGER_32) arg3;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_1_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,1069,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	ti4_1 = eif_max_int32 ((EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * loc2) + ((EIF_INTEGER_32) 1L)),((EIF_INTEGER_32) 1000L));
	F1159_7647(RTCW(tr1), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O5469[dtype-1072]) = (EIF_REFERENCE) tr1;
	F1073_7132(Current, arg1);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = F1159_7653(RTCW(arg1), loc1);
		F1073_7133(Current, tr1);
		loc1++;
	}
	*(EIF_INTEGER_32 *)(Current + O5465[dtype-1072]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * loc2);
	RTLE;
}

/* {LX_DFA}.set_nfa_state_ids */
void F1073_7132 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc11 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc12 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc13 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc5);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,tr1);
	RTLR(7,loc4);
	RTLIU(8);
	
	RTGC;
	loc13 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1180,0xFF01,1071,834,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc5 = RTLNS(typres0.id, 1180, _OBJSIZ_11_0_0_9_0_0_0_0_);
	}
	F1173_7892(RTCW(loc5), ((EIF_INTEGER_32) 100L));
	loc7 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_1_);
	loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc6 > loc7)) break;
		loc1 = F1159_7653(RTCW(arg1), loc6);
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		loc9 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_4_0_0_1_);
		loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc8 > loc9)) break;
			loc3 = F1159_7653(RTCW(loc2), loc8);
			tr1 = F1072_7095(RTCW(loc3));
			loc12 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_1_0_0_);
			tb1 = '\01';
			tb2 = F1173_7908(RTCW(loc5), loc12);
			if (!(EIF_BOOLEAN) !tb2) {
				tr1 = F1173_7900(RTCW(loc5), loc12);
				tb1 = (EIF_BOOLEAN)(tr1 != loc3);
			}
			if (tb1) {
				F1173_7920(RTCW(loc5), loc3, loc13);
				loc4 = *(EIF_REFERENCE *)(RTCW(loc3));
				loc11 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_4_0_0_1_);
				loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc10 > loc11)) break;
					tr1 = F1159_7653(RTCW(loc4), loc10);
					F1069_7068(RTCW(tr1), loc13);
					loc13++;
					loc10++;
				}
			}
			loc8++;
		}
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_2_);
		loc9 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_4_0_0_1_);
		loc8 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc8 > loc9)) break;
			loc3 = F1159_7653(RTCW(loc2), loc8);
			tr1 = F1072_7095(RTCW(loc3));
			loc12 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_3_1_0_0_);
			tb1 = '\01';
			tb2 = F1173_7908(RTCW(loc5), loc12);
			if (!(EIF_BOOLEAN) !tb2) {
				tr1 = F1173_7900(RTCW(loc5), loc12);
				tb1 = (EIF_BOOLEAN)(tr1 != loc3);
			}
			if (tb1) {
				F1173_7920(RTCW(loc5), loc3, loc13);
				loc4 = *(EIF_REFERENCE *)(RTCW(loc3));
				loc11 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_4_0_0_1_);
				loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				for (;;) {
					if ((EIF_BOOLEAN) (loc10 > loc11)) break;
					tr1 = F1159_7653(RTCW(loc4), loc10);
					F1069_7068(RTCW(tr1), loc13);
					loc13++;
					loc10++;
				}
			}
			loc8++;
		}
		loc6++;
	}
	RTLE;
}

/* {LX_DFA}.put_start_condition */
void F1073_7133 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,loc3);
	RTLR(4,Current);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLR(7,tr1);
	RTLR(8,loc6);
	RTLIU(9);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	loc8 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_4_0_0_1_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc3 = RTLNS(typres0.id, 1158, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	F1159_7647(RTCW(loc3), loc8);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc4 = RTLNS(typres0.id, 1158, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_4_0_0_1_);
	F1159_7647(RTCW(loc4), (EIF_INTEGER_32) (loc8 + ti4_1));
	loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc7 > loc8)) break;
		tr1 = F1159_7653(RTCW(loc1), loc7);
		loc5 = F1072_7095(RTCW(tr1));
		F1159_7666(RTCW(loc3), loc5);
		F1159_7666(RTCW(loc4), loc5);
		loc7++;
	}
	loc8 = *(EIF_INTEGER_32 *)(RTCW(loc2)+ _LNGOFF_4_0_0_1_);
	loc7 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc7 > loc8)) break;
		tr1 = F1159_7653(RTCW(loc2), loc7);
		tr1 = F1072_7095(RTCW(tr1));
		F1159_7666(RTCW(loc4), tr1);
		loc7++;
	}
	loc6 = RTLNS(eif_new_type(1069, 0x01).id, 1069, _OBJSIZ_4_0_0_2_0_0_0_0_);
	F1070_7071(RTCW(loc6), loc3, *(EIF_INTEGER_32 *)(Current + O5466[dtype-1072]), *(EIF_INTEGER_32 *)(Current + O5467[dtype-1072]));
	tr1 = *(EIF_REFERENCE *)(Current + O5469[dtype-1072]);
	F1159_7666(RTCW(tr1), loc6);
	tr1 = *(EIF_REFERENCE *)(Current + O5469[dtype-1072]);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	F1070_7080(RTCW(loc6), ti4_1);
	loc6 = RTLNS(eif_new_type(1069, 0x01).id, 1069, _OBJSIZ_4_0_0_2_0_0_0_0_);
	F1070_7071(RTCW(loc6), loc4, *(EIF_INTEGER_32 *)(Current + O5466[dtype-1072]), *(EIF_INTEGER_32 *)(Current + O5467[dtype-1072]));
	tr1 = *(EIF_REFERENCE *)(Current + O5469[dtype-1072]);
	F1159_7666(RTCW(tr1), loc6);
	tr1 = *(EIF_REFERENCE *)(Current + O5469[dtype-1072]);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	F1070_7080(RTCW(loc6), ti4_1);
	RTLE;
}

/* {LX_DFA}.build_transitions */
void F1073_7134 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc7);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,loc6);
	RTLR(5,loc5);
	RTLR(6,loc4);
	RTLR(7,loc8);
	RTLIU(8);
	
	RTGC;
	RTCT0("paritions_not_void", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + O5471[dtype-1072]);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc2 = F96_1055(loc7);
	tr1 = *(EIF_REFERENCE *)(Current + O5469[dtype-1072]);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + O5469[dtype-1072]);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (ti4_1 - ti4_2) < loc2)) {
		tr1 = *(EIF_REFERENCE *)(Current + O5469[dtype-1072]);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_0_);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R5476[dtype-1074])(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 + loc2) + ((EIF_INTEGER_32) 1000L)));
	}
	F97_1071(loc7);
	F1070_7086(RTCW(arg1), loc7);
	loc6 = *(EIF_REFERENCE *)(loc7 + _REFACS_1_);
	loc5 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = *(EIF_INTEGER_32 *)(Current + O5466[dtype-1072]);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > *(EIF_INTEGER_32 *)(Current + O5467[dtype-1072]))) break;
		tb1 = F1167_7833(RTCW(loc6), loc1);
		if (tb1) {
			tb1 = F96_1060(loc7, loc1);
			if (tb1) {
				tr1 = F1070_7085(RTCW(arg1), loc1);
				loc4 = F1073_7135(Current, tr1);
			} else {
				loc3 = F96_1053(loc7, loc1);
				RTCT0("attached transitions.target (previous) as l_target", EX_CHECK);
				tr1 = F1067_7040(RTCW(loc5), loc3);
				loc8 = tr1;
				if (EIF_TEST(loc8)) {
					RTCK0;
				} else {
					RTCF0;
				}
				loc4 = (EIF_REFERENCE) loc8;
			}
			F1067_7049(RTCW(loc5), loc4, loc1);
		}
		loc1++;
	}
	RTLE;
}

/* {LX_DFA}.new_state */
EIF_REFERENCE F1073_7135 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc3);
	RTLR(3,arg1);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O5465[dtype-1072]);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + O5469[dtype-1072]);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 != NULL) || (EIF_BOOLEAN) (loc1 > loc2))) break;
		tr1 = *(EIF_REFERENCE *)(Current + O5469[dtype-1072]);
		loc3 = F1159_7653(RTCW(tr1), loc1);
		tb1 = F1070_7084(RTCW(loc3), arg1);
		if ((EIF_BOOLEAN) !tb1) {
			loc3 = (EIF_REFERENCE) NULL;
			loc1++;
		}
	}
	if ((EIF_BOOLEAN)(loc3 == NULL)) {
		Result = (EIF_REFERENCE) arg1;
		tr1 = *(EIF_REFERENCE *)(Current + O5469[dtype-1072]);
		F1159_7666(RTCW(tr1), arg1);
		tr1 = *(EIF_REFERENCE *)(Current + O5469[dtype-1072]);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		F1070_7080(RTCW(arg1), ti4_1);
	} else {
		RTLE;
		return (EIF_REFERENCE) loc3;
	}
	RTLE;
	return Result;
}

/* {LX_DFA}.resize */
void F1073_7136 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O5469[Dtype(Current)-1072]);
	F1159_7700(RTCW(tr1), arg1);
	RTLE;
}

void EIF_Minit332 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
