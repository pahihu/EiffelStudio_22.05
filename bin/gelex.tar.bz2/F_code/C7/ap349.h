
#ifndef _C7_ap349_
#define _C7_ap349_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1193_8204(EIF_REFERENCE);
extern void F1193_8205(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit349(void);
extern void F1192_8186(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
