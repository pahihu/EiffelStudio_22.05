/*
 * Code for class LX_LEX_SCANNER_SKELETON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx301.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_LEX_SCANNER_SKELETON}.make_from_description */
void F971_6595 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_14_) = (EIF_REFERENCE) arg1;
	tr1 = RTOSCF(6450,F967_6450, (Current));
	F968_6465(Current, tr1);
	tr1 = RTMS_EX_H("",0,0);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_23_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(911, 1).id);
	F910_5584(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_24_) = (EIF_REFERENCE) tr1;
	tr1 = RTLNSMART(eif_new_type(796, 1).id);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	ti4_1 = ((EIF_INTEGER_32) 0L);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_9_22_0_1_);
	F797_4158(RTCW(tr1), ti4_1, ti4_2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_25_) = (EIF_REFERENCE) tr1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_15_) = (EIF_REFERENCE) arg2;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1179,0xFF01,911,0xFF01,914,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1172_7895(RTCW(tr1), ((EIF_INTEGER_32) 101L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_20_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
	tr2 = RTOSCF(2152,F237_2152, (Current));
	F1172_7913(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1169,0xFF01,796,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1166_7828(RTCW(tr1), ((EIF_INTEGER_32) 101L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_16_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1179,0xFF01,796,0xFF01,911,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1172_7895(RTCW(tr1), ((EIF_INTEGER_32) 101L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_17_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	tr2 = RTOSCF(2154,F237_2154, (Current));
	F1172_7913(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1169,0xFF01,796,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1162_7737(RTCW(tr1), ((EIF_INTEGER_32) 101L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_18_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1179,0xFF01,796,0xFF01,911,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1172_7895(RTCW(tr1), ((EIF_INTEGER_32) 101L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_19_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	tr2 = RTOSCF(2154,F237_2154, (Current));
	F1172_7913(RTCW(tr1), tr2);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1157,867,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1158_7615(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_21_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_9_2_);
	F1158_7628(RTCW(tr1), tb1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_64_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	tr1 = RTOSCF(6621,F971_6621, (Current));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_26_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.filename */
EIF_REFERENCE F971_6602 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(168, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		tr1 = *(EIF_REFERENCE *)(loc1 + _REFACS_1_);
		Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R1351[Dtype(RTCW(tr1))-946])(tr1);
	} else {
		Result = RTMS_EX_H("string",6,2146502247);
	}
	RTLE;
	return Result;
}

/* {LX_LEX_SCANNER_SKELETON}.character_class_with_name */
EIF_REFERENCE F971_6607 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
	tb1 = F1158_7620(RTCW(tr1));
	if (tb1) {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_19_);
	} else {
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_17_);
	}
	F1172_7911(RTCW(loc1), arg1);
	tb1 = F1162_7746(RTCW(loc1));
	if (tb1) {
		tr1 = F1162_7738(RTCW(loc1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {LX_LEX_SCANNER_SKELETON}.eiffel_more */
void F971_6618 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F968_6478(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_26_) = (EIF_INTEGER_32) ti4_1;
	F968_6492(Current);
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.eiffel_no_verbatim_marker */

EIF_REFERENCE F971_6621 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (6621,RTMS32_EX_H("",0,0));
}

/* {LX_LEX_SCANNER_SKELETON}.is_eiffel_verbatim_string_closer */
EIF_BOOLEAN F971_6622 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 loc6 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_2_);
	loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg2 - arg1) + ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN) (loc5 > loc4)) {
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 - loc4);
		loc6 = F968_6473(Current, loc3);
		tb1 = '\0';
		tb2 = '\01';
		tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ']';
		if (!(EIF_BOOLEAN)(loc6 == tw1)) {
			tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '}';
			tb2 = (EIF_BOOLEAN)(loc6 == tw1);
		}
		if (tb2) {
			tw1 = *(EIF_CHARACTER_32 *)(Current+ _LNGOFF_64_8_0_1_);
			tw1 = (EIF_CHARACTER_32) (((EIF_NATURAL_32) tw1) + (EIF_NATURAL_32) ((EIF_INTEGER_32) 2L));
			tb1 = (EIF_BOOLEAN)(loc6 == tw1);
		}
		if (tb1) {
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc4)) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_26_);
				loc6 = F912_5666(RTCW(tr1), loc1);
				if ((EIF_BOOLEAN)(loc6 == F968_6473(Current, loc2))) {
					loc1++;
					loc2++;
				} else {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
				}
			}
			if (Result) {
				loc2 = (EIF_INTEGER_32) arg1;
				for (;;) {
					if ((EIF_BOOLEAN)(loc2 == loc3)) break;
					tw1 = F968_6473(Current, loc2);
					tu4_1 = (EIF_NATURAL_32) tw1;
					switch (tu4_1) {
						case 9U:
						case 10U:
						case 11U:
						case 12U:
						case 13U:
						case 32U:
						case 160U:
						case 5760U:
						case 8192U:
						case 8193U:
						case 8194U:
						case 8195U:
						case 8196U:
						case 8197U:
						case 8198U:
						case 8199U:
						case 8200U:
						case 8201U:
						case 8202U:
						case 8239U:
						case 8287U:
						case 12288U:
							loc2++;
							break;
						default:
							Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
							loc2 = (EIF_INTEGER_32) loc3;
							break;
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {LX_LEX_SCANNER_SKELETON}.put_back_string */
void F971_6623 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 1L))) break;
		tw1 = F912_5666(RTCW(arg1), loc1);
		F968_6495(Current, tw1);
		loc1--;
	}
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.add_new_start_condition */
void F971_6624 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_BOOLEAN arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_3_);
	tb1 = F1161_7729(RTCW(loc1), arg1);
	if (tb1) {
		F971_6646(Current, arg1);
	} else {
		F1161_7732(RTCW(loc1), arg1, arg2);
	}
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.process_character */
void F971_6625 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
	tb2 = *(EIF_BOOLEAN *)(RTCW(tr1)+ _CHROFF_9_2_);
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_21_);
		tb2 = F1158_7620(RTCW(tr1));
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 255L))) {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_25_) = (EIF_INTEGER_32) arg1;
		} else {
			tr1 = F971_6632(Current);
			F971_6638(Current, tr1);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_25_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
	} else {
		if ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 55296L))) {
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_25_) = (EIF_INTEGER_32) arg1;
		} else {
			if ((EIF_BOOLEAN) (arg1 <= ((EIF_INTEGER_32) 57343L))) {
				tr1 = F971_6632(Current);
				F971_6639(Current, tr1);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_25_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			} else {
				if ((EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 1114111L))) {
					tr1 = F971_6632(Current);
					F971_6639(Current, tr1);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_25_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
				} else {
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_25_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 - ((EIF_INTEGER_32) 2048L));
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_14_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_9_22_0_1_);
		if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_25_) > ti4_1)) {
			tr1 = F971_6632(Current);
			F971_6638(Current, tr1);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_25_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		}
	}
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.process_escaped_character */
void F971_6626 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = F968_6472(Current, ((EIF_INTEGER_32) 2L));
	switch (loc1) {
		case (EIF_CHARACTER_8) 'b':
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 8L);
			break;
		case (EIF_CHARACTER_8) 'f':
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 12L);
			break;
		case (EIF_CHARACTER_8) 'n':
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 10L);
			break;
		case (EIF_CHARACTER_8) 'r':
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
			break;
		case (EIF_CHARACTER_8) 't':
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 9L);
			break;
		case (EIF_CHARACTER_8) 'a':
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 7L);
			break;
		case (EIF_CHARACTER_8) 'v':
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 13L);
			break;
		default:
			loc2 = (EIF_INTEGER_32) (loc1);
			break;
	}
	F971_6625(Current, loc2);
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.process_octal_character */
void F971_6627 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc3 = F968_6478(Current);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc2 > loc3)) break;
		tc1 = F968_6472(Current, loc2);
		ti4_1 = (EIF_INTEGER_32) (tc1);
		loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 * ((EIF_INTEGER_32) 8L)) + ti4_1) - ((EIF_INTEGER_32) 48L));
		loc2++;
	}
	F971_6625(Current, loc1);
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.process_hexadecimal_character */
void F971_6628 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc4 = F968_6478(Current);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	if ((EIF_BOOLEAN)(F968_6472(Current, loc3) == (EIF_CHARACTER_8) '{')) {
		loc3++;
		loc4--;
	}
	for (;;) {
		if ((EIF_BOOLEAN) (loc3 > loc4)) break;
		loc2 *= ((EIF_INTEGER_32) 16L);
		loc1 = F968_6472(Current, loc3);
		switch (loc1) {
			case (EIF_CHARACTER_8) '0':
			case (EIF_CHARACTER_8) '1':
			case (EIF_CHARACTER_8) '2':
			case (EIF_CHARACTER_8) '3':
			case (EIF_CHARACTER_8) '4':
			case (EIF_CHARACTER_8) '5':
			case (EIF_CHARACTER_8) '6':
			case (EIF_CHARACTER_8) '7':
			case (EIF_CHARACTER_8) '8':
			case (EIF_CHARACTER_8) '9':
				ti4_1 = (EIF_INTEGER_32) (loc1);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + ti4_1) - ((EIF_INTEGER_32) 48L));
				break;
			case (EIF_CHARACTER_8) 'a':
			case (EIF_CHARACTER_8) 'b':
			case (EIF_CHARACTER_8) 'c':
			case (EIF_CHARACTER_8) 'd':
			case (EIF_CHARACTER_8) 'e':
			case (EIF_CHARACTER_8) 'f':
				ti4_1 = (EIF_INTEGER_32) (loc1);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + ti4_1) - ((EIF_INTEGER_32) 97L)) + ((EIF_INTEGER_32) 10L));
				break;
			case (EIF_CHARACTER_8) 'A':
			case (EIF_CHARACTER_8) 'B':
			case (EIF_CHARACTER_8) 'C':
			case (EIF_CHARACTER_8) 'D':
			case (EIF_CHARACTER_8) 'E':
			case (EIF_CHARACTER_8) 'F':
				ti4_1 = (EIF_INTEGER_32) (loc1);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + ti4_1) - ((EIF_INTEGER_32) 65L)) + ((EIF_INTEGER_32) 10L));
				break;
			default:
				RTEC(EN_WHEN);
		}
		loc3++;
	}
	F971_6625(Current, loc2);
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.process_unicode_character */
void F971_6629 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc4 = F968_6478(Current);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
	if ((EIF_BOOLEAN)(F968_6472(Current, loc3) == (EIF_CHARACTER_8) '{')) {
		loc3++;
		loc4--;
	}
	for (;;) {
		if ((EIF_BOOLEAN) (loc3 > loc4)) break;
		loc2 *= ((EIF_INTEGER_32) 16L);
		loc1 = F968_6472(Current, loc3);
		switch (loc1) {
			case (EIF_CHARACTER_8) '0':
			case (EIF_CHARACTER_8) '1':
			case (EIF_CHARACTER_8) '2':
			case (EIF_CHARACTER_8) '3':
			case (EIF_CHARACTER_8) '4':
			case (EIF_CHARACTER_8) '5':
			case (EIF_CHARACTER_8) '6':
			case (EIF_CHARACTER_8) '7':
			case (EIF_CHARACTER_8) '8':
			case (EIF_CHARACTER_8) '9':
				ti4_1 = (EIF_INTEGER_32) (loc1);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + ti4_1) - ((EIF_INTEGER_32) 48L));
				break;
			case (EIF_CHARACTER_8) 'a':
			case (EIF_CHARACTER_8) 'b':
			case (EIF_CHARACTER_8) 'c':
			case (EIF_CHARACTER_8) 'd':
			case (EIF_CHARACTER_8) 'e':
			case (EIF_CHARACTER_8) 'f':
				ti4_1 = (EIF_INTEGER_32) (loc1);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + ti4_1) - ((EIF_INTEGER_32) 97L)) + ((EIF_INTEGER_32) 10L));
				break;
			case (EIF_CHARACTER_8) 'A':
			case (EIF_CHARACTER_8) 'B':
			case (EIF_CHARACTER_8) 'C':
			case (EIF_CHARACTER_8) 'D':
			case (EIF_CHARACTER_8) 'E':
			case (EIF_CHARACTER_8) 'F':
				ti4_1 = (EIF_INTEGER_32) (loc1);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 + ti4_1) - ((EIF_INTEGER_32) 65L)) + ((EIF_INTEGER_32) 10L));
				break;
			default:
				RTEC(EN_WHEN);
		}
		loc3++;
	}
	F971_6625(Current, loc2);
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.process_single_character */
void F971_6630 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 loc1 = (EIF_NATURAL_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tw1 = F968_6473(Current, ((EIF_INTEGER_32) 1L));
	loc1 = (EIF_NATURAL_32) tw1;
	if ((EIF_BOOLEAN) (loc1 <= ((EIF_NATURAL_32) 1114111U))) {
		ti4_1 = (EIF_INTEGER_32) loc1;
		F971_6625(Current, ti4_1);
	} else {
		tr1 = F971_6632(Current);
		F971_6639(Current, tr1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_25_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.process_name_definition */
void F971_6631 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_32 tw1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLR(5,arg2);
	RTLIU(6);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	F913_5751(RTCW(loc1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(loc1))-914])(loc1, (EIF_CHARACTER_8) '{');
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R4319[Dtype(RTCW(arg1))-910])(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(loc1))-914])(loc1, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(loc1))-914])(loc1, (EIF_CHARACTER_8) '}');
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
	tb1 = F1172_7908(RTCW(tr1), loc1);
	if (tb1) {
		F971_6645(Current, arg1);
	}
	loc2 = RTLNS(eif_new_type(911, 0x01).id, 911, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
	F910_5584(RTCW(loc2), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 2L)));
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) '(';
	F912_5712(RTCW(loc2), tw1);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_2_);
	loc3 = (EIF_INTEGER_32) loc4;
	for (;;) {
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 1L)) || loc5)) break;
		tw1 = F912_5666(RTCW(arg2), loc3);
		switch (tw1) {
			case (EIF_CHARACTER_8) '\011':
			case (EIF_CHARACTER_8) '\012':
			case (EIF_CHARACTER_8) '\015':
			case (EIF_CHARACTER_8) ' ':
				loc3--;
				break;
			default:
				loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				break;
		}
	}
	if ((EIF_BOOLEAN) (loc3 >= ((EIF_INTEGER_32) 1L))) {
		if ((EIF_BOOLEAN) (loc3 < loc4)) {
			tr1 = F912_5746(RTCW(arg2), ((EIF_INTEGER_32) 1L), loc3);
			F912_5701(RTCW(loc2), tr1);
		} else {
			F912_5701(RTCW(loc2), arg2);
		}
	}
	tw1 = (EIF_CHARACTER_32) (EIF_CHARACTER_8) ')';
	F912_5712(RTCW(loc2), tw1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_20_);
	F1172_7920(RTCW(tr1), loc2, loc1);
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.character_text */
EIF_REFERENCE F971_6632 (EIF_REFERENCE Current)
{
	GTCX
	EIF_CHARACTER_32 loc1 = (EIF_CHARACTER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(F968_6478(Current) == ((EIF_INTEGER_32) 1L))) {
		RTLE;
		return (EIF_REFERENCE) F968_6469(Current);
	} else {
		loc1 = F968_6473(Current, ((EIF_INTEGER_32) 1L));
		tb1 = (loc1 <= 0xFF);
		if (tb1) {
			RTLE;
			return (EIF_REFERENCE) F968_6469(Current);
		} else {
			tr1 = RTMS_EX_H("\\x{",3,6060155);
			tu4_1 = (EIF_NATURAL_32) loc1;
			tr2 = RTLNS(eif_new_type(846, 0x00).id, 846, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_NATURAL_32 *)tr2 = tu4_1;
			tr2 = F845_4893(RTCW(tr2));
			tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4486[Dtype(tr1)-914])(tr1, tr2);
			tr2 = RTMS_EX_H("}",1,125);
			Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4486[Dtype(RTCW(tr1))-914])(tr1, tr2);
		}
	}
	RTLE;
	return Result;
}

/* {LX_LEX_SCANNER_SKELETON}.report_invalid_unicode_character_error */
void F971_6633 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,tr2);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("\\u{",3,6059387);
	tr2 = RTLNS(eif_new_type(846, 0x00).id, 846, _OBJSIZ_0_0_0_1_0_0_0_0_);
	*(EIF_NATURAL_32 *)tr2 = arg1;
	tr2 = F845_4893(RTCW(tr2));
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4486[Dtype(tr1)-914])(tr1, tr2);
	tr2 = RTMS_EX_H("}",1,125);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE)) R4486[Dtype(RTCW(tr1))-914])(tr1, tr2);
	F971_6639(Current, tr1);
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.report_bad_character_error */
void F971_6634 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1220, 0x01).id, 1220, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F971_6602(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_);
	F1221_8673(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1192_8183(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_64_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.report_bad_character_class_error */
void F971_6635 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1219, 0x01).id, 1219, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F971_6602(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_);
	F1220_8670(RTCW(loc1), tr1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1192_8183(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_64_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.report_bad_character_in_brackets_error */
void F971_6636 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1218, 0x01).id, 1218, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F971_6602(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_);
	F1219_8667(RTCW(loc1), tr1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1192_8183(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_64_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.report_bad_start_condition_error */
void F971_6637 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1217, 0x01).id, 1217, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F971_6602(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_);
	F1218_8664(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1192_8183(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_64_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.report_character_out_of_range_error */
void F971_6638 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1216, 0x01).id, 1216, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F971_6602(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_);
	F1217_8661(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1192_8183(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_64_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.report_invalid_character_error */
void F971_6639 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1215, 0x01).id, 1215, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F971_6602(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_);
	F1216_8658(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1192_8183(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_64_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.report_integer_too_large_error */
void F971_6640 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1214, 0x01).id, 1214, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F971_6602(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_);
	F1215_8655(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1192_8183(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_64_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.report_directive_expected_error */
void F971_6641 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1213, 0x01).id, 1213, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F971_6602(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_);
	F1214_8652(RTCW(loc1), tr1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1192_8183(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_64_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.report_incomplete_name_definition_error */
void F971_6642 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1212, 0x01).id, 1212, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F971_6602(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_);
	F1213_8649(RTCW(loc1), tr1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1192_8183(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_64_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.report_missing_bracket_error */
void F971_6643 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1204, 0x01).id, 1204, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F971_6602(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_);
	F1205_8625(RTCW(loc1), tr1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1192_8183(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_64_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.report_missing_quote_error */
void F971_6644 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1211, 0x01).id, 1211, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F971_6602(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_);
	F1212_8646(RTCW(loc1), tr1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1192_8183(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_64_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.report_name_defined_twice_error */
void F971_6645 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1210, 0x01).id, 1210, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F971_6602(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_);
	F1211_8643(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1192_8183(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_64_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.report_start_condition_declared_twice_error */
void F971_6646 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1209, 0x01).id, 1209, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F971_6602(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_);
	F1210_8640(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1192_8183(RTCW(tr1), loc1);
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.report_start_condition_expected_error */
void F971_6647 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1208, 0x01).id, 1208, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F971_6602(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_);
	F1209_8637(RTCW(loc1), tr1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1192_8183(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_64_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.report_undefined_definition_error */
void F971_6648 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1207, 0x01).id, 1207, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F971_6602(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_);
	F1208_8634(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1192_8183(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_64_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.report_unrecognized_directive_error */
void F971_6649 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1206, 0x01).id, 1206, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F971_6602(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_);
	F1207_8631(RTCW(loc1), tr1, ti4_1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1192_8183(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_64_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {LX_LEX_SCANNER_SKELETON}.report_unrecognized_option_error */
void F971_6650 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = RTLNS(eif_new_type(1205, 0x01).id, 1205, _OBJSIZ_1_0_0_0_0_0_0_0_);
	tr1 = F971_6602(Current);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_64_8_0_22_);
	F1206_8628(RTCW(loc1), tr1, ti4_1, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_15_);
	F1192_8183(RTCW(tr1), loc1);
	*(EIF_BOOLEAN *)(Current+ _CHROFF_64_3_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

void EIF_Minit301 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
