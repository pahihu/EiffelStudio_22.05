/*
 * Code for class LX_DFA_STATE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx329.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_DFA_STATE}.make */
void F1070_7071 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc3);
	RTLR(4,loc5);
	RTLR(5,loc4);
	RTLR(6,loc6);
	RTLR(7,loc7);
	RTLR(8,tr2);
	RTLIU(9);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_1_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1159_7647(RTCW(tr1), loc2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1066,0xFF01,1069,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1067_7037(RTCW(tr1), arg2, arg3);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,162,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1159_7647(RTCW(tr1), loc2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,162,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1159_7647(RTCW(tr1), loc2);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = F1159_7653(RTCW(arg1), loc1);
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
		if ((EIF_BOOLEAN)(tr1 != NULL)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
			loc5 = tr1;
			{
				static EIF_TYPE_INDEX typarr0[] = {0xFF01,1079,0xFF01,1068,0xFFFF};
				EIF_TYPE typres0;
				static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
				
				typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
				loc5 = RTRV(typres0,loc5);
			}
			if ((EIF_BOOLEAN) !EIF_TEST(loc5)) {
				tr1 = *(EIF_REFERENCE *)(Current);
				F1159_7671(RTCW(tr1), loc3);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_3_1_0_0_);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_)) += ti4_1;
			} else {
				loc4 = *(EIF_REFERENCE *)(loc5);
				tb1 = F1159_7660(RTCW(arg1), loc4);
				if ((EIF_BOOLEAN) !tb1) {
					F1159_7671(RTCW(arg1), loc4);
					loc2++;
				}
			}
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_1_);
		loc6 = tr1;
		if (EIF_TEST(loc6)) {
			loc4 = *(EIF_REFERENCE *)(loc6);
			tb1 = F1159_7660(RTCW(arg1), loc4);
			if ((EIF_BOOLEAN) !tb1) {
				F1159_7671(RTCW(arg1), loc4);
				loc2++;
			}
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3) + _REFACS_2_);
		loc7 = tr1;
		if (EIF_TEST(loc7)) {
			tb1 = F1069_7061(RTCW(loc3));
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				F1159_7671(RTCW(tr1), loc7);
			} else {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				F1159_7671(RTCW(tr1), loc7);
			}
			tb1 = '\01';
			tr1 = *(EIF_REFERENCE *)(Current);
			tb2 = F1081_7250(RTCW(tr1));
			if (!tb2) {
				tr1 = *(EIF_REFERENCE *)(Current);
				tr1 = F1159_7655(RTCW(tr1));
				tb1 = (EIF_BOOLEAN)(tr1 != loc3);
			}
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current);
				F1159_7671(RTCW(tr1), loc3);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_3_1_0_0_);
				(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_)) += ti4_1;
			}
		}
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current);
	tr2 = RTOSCF(7087,F1070_7087, (Current));
	F1091_7280(RTCW(tr1), tr2);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = F1081_7250(RTCW(tr1));
	if ((EIF_BOOLEAN) !tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = RTOSCF(7088,F1070_7088, (Current));
		F1091_7280(RTCW(tr1), tr2);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F1159_7654(RTCW(tr1));
		F163_1725(RTCW(tr1), (EIF_BOOLEAN) 1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = RTOSCF(7088,F1070_7088, (Current));
	F1091_7280(RTCW(tr1), tr2);
	RTLE;
}

/* {LX_DFA_STATE}.minimum_symbol */
EIF_INTEGER_32 F1070_7077 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_3_);
	RTLE;
	return Result;
}

/* {LX_DFA_STATE}.maximum_symbol */
EIF_INTEGER_32 F1070_7078 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	Result = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_0_0_4_);
	RTLE;
	return Result;
}

/* {LX_DFA_STATE}.set_id */
void F1070_7080 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {LX_DFA_STATE}.is_accepting */
EIF_BOOLEAN F1070_7081 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	Result = F1081_7250(RTCW(tr1));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {LX_DFA_STATE}.is_accepting_head */
EIF_BOOLEAN F1070_7082 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	Result = F1081_7250(RTCW(tr1));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) !Result;
	RTLE;
	return Result;
}

/* {LX_DFA_STATE}.is_equal */
EIF_BOOLEAN F1070_7084 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	tr1 = RTOSCF(5994,F932_5994, (Current));
	tb2 = F16_120(RTCW(tr1), Current, arg1);
	if (tb2) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_1_);
		tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_1_) == ti4_1);
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1));
		Result = F1159_7663(RTCW(tr1), tr2);
	}
	RTLE;
	return Result;
}

/* {LX_DFA_STATE}.new_state */
EIF_REFERENCE F1070_7085 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc4);
	RTLR(3,loc3);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc4 = RTLNS(typres0.id, 1158, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	F1159_7647(RTCW(loc4), loc2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F1159_7653(RTCW(tr1), loc1);
		loc3 = *(EIF_REFERENCE *)(RTCW(tr1));
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			tb2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE, EIF_INTEGER_32)) R5560[Dtype(RTCW(loc3))-1077])(loc3, arg1);
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
			F1159_7666(RTCW(loc4), tr1);
		}
		loc1++;
	}
	Result = RTLNS(eif_new_type(1069, 0x01).id, 1069, _OBJSIZ_4_0_0_2_0_0_0_0_);
	ti4_1 = F1070_7077(Current);
	ti4_2 = F1070_7078(Current);
	F1070_7071(RTCW(Result), loc4, ti4_1, ti4_2);
	RTLE;
	return Result;
}

/* {LX_DFA_STATE}.partition */
void F1070_7086 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc3);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current);
		tr1 = F1159_7653(RTCW(tr1), loc1);
		loc3 = *(EIF_REFERENCE *)(RTCW(tr1));
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5561[Dtype(RTCW(loc3))-1077])(loc3, arg1);
		}
		loc1++;
	}
	RTLE;
}

/* {LX_DFA_STATE}.bubble_sorter */
static EIF_REFERENCE F1070_7087_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDD;
	RTLD;
	
	dftype = Dftype(Current);

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (7087);
#define Result RTOSR(7087)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,234,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 234, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,76,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 76, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F74_947(RTCW(tr1), loc1);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (7087);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1070_7087 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(7087,F1070_7087_body,(Current));
}

/* {LX_DFA_STATE}.rule_sorter */
static EIF_REFERENCE F1070_7088_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDD;
	RTLD;
	
	dftype = Dftype(Current);

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (7088);
#define Result RTOSR(7088)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,234,0xFF01,162,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 234, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,76,0xFF01,162,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 76, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F74_947(RTCW(tr1), loc1);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (7088);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1070_7088 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(7088,F1070_7088_body,(Current));
}

void EIF_Minit329 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
