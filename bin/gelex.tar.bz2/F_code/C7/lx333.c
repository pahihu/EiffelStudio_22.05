/*
 * Code for class LX_GENERATABLE_DFA
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "lx333.h"
#include "eif_helpers.h"
#include "eif_out.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {LX_GENERATABLE_DFA}.initialize */
void F1074_7139 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc7);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,tr2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLIU(7);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		RTAR(Current, loc7);
		*(EIF_REFERENCE *)(Current + O5504[dtype-1073]) = (EIF_REFERENCE) loc7;
	} else {
		tr1 = RTOSCF(7179,F1074_7179, (Current));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O5504[dtype-1073]) = (EIF_REFERENCE) tr1;
	}
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_9_21_);
	*(EIF_BOOLEAN *)(Current + O5505[dtype-1073]) = (EIF_BOOLEAN) tb1;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_9_22_0_0_);
	*(EIF_INTEGER_32 *)(Current + O5514[dtype-1073]) = (EIF_INTEGER_32) ti4_1;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_9_10_);
	*(EIF_BOOLEAN *)(Current + O5516[dtype-1073]) = (EIF_BOOLEAN) tb1;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_9_9_);
	*(EIF_BOOLEAN *)(Current + O5515[dtype-1073]) = (EIF_BOOLEAN) tb1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_7_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O5506[dtype-1073]) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_8_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O5507[dtype-1073]) = (EIF_REFERENCE) tr1;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_9_19_);
	*(EIF_BOOLEAN *)(Current + O5508[dtype-1073]) = (EIF_BOOLEAN) tb1;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_9_14_);
	*(EIF_BOOLEAN *)(Current + O5509[dtype-1073]) = (EIF_BOOLEAN) tb1;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_9_15_);
	*(EIF_BOOLEAN *)(Current + O5510[dtype-1073]) = (EIF_BOOLEAN) tb1;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_9_16_);
	*(EIF_BOOLEAN *)(Current + O5511[dtype-1073]) = (EIF_BOOLEAN) tb1;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_9_17_);
	*(EIF_BOOLEAN *)(Current + O5512[dtype-1073]) = (EIF_BOOLEAN) tb1;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_9_18_);
	*(EIF_BOOLEAN *)(Current + O5513[dtype-1073]) = (EIF_BOOLEAN) tb1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	tr1 = F1161_7731(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_4_);
	F1074_7162(Current, tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_5_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	ti4_1 = F702_3697(RTCW(tr2));
	F1074_7163(Current, tr1, ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
	loc1 = ((EIF_INTEGER_32) 0L);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_9_22_0_1_);
	*(EIF_INTEGER_32 *)(Current + O5363[dtype-1059]) = (EIF_INTEGER_32) loc2;
	loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_6_);
	tb1 = '\0';
	if ((EIF_BOOLEAN)(loc3 != NULL)) {
		tb2 = F96_1063(RTCW(loc3));
		tb1 = tb2;
	}
	if (tb1) {
		loc4 = F96_1068(RTCW(loc3), ((EIF_INTEGER_32) 0L), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)));
		loc5 = (EIF_INTEGER_32) loc1;
		loc6 = (EIF_INTEGER_32) loc2;
		loc2 = *(EIF_INTEGER_32 *)(RTCW(loc3) + O1061[Dtype(loc3)-95]);
		for (;;) {
			if ((EIF_BOOLEAN) (loc5 > loc6)) break;
			ti4_1 = F703_3690(RTCW(loc4), loc5);
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L))) {
				F703_3709(RTCW(loc4), (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L)), loc5);
			}
			loc5++;
		}
		ti4_1 = F703_3690(RTCW(loc4), ((EIF_INTEGER_32) 0L));
		*(EIF_INTEGER_32 *)(Current + O5362[dtype-1059]) = (EIF_INTEGER_32) ti4_1;
		F703_3709(RTCW(loc4), *(EIF_INTEGER_32 *)(Current + O5362[dtype-1059]), (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)));
		F703_3709(RTCW(loc4), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
		RTAR(Current, loc4);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc4;
	} else {
		*(EIF_INTEGER_32 *)(Current + O5362[dtype-1059]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
	*(EIF_INTEGER_32 *)(Current + O5360[dtype-1059]) = (EIF_INTEGER_32) ti4_1;
	*(EIF_INTEGER_32 *)(Current + O5361[dtype-1059]) = (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5360[dtype-1059]) + ((EIF_INTEGER_32) 1L));
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_9_12_);
	*(EIF_BOOLEAN *)(Current + O5364[dtype-1059]) = (EIF_BOOLEAN) tb1;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_9_13_);
	*(EIF_BOOLEAN *)(Current + O5365[dtype-1059]) = (EIF_BOOLEAN) tb1;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	F1073_7122(Current, tr1, loc1, loc2);
	RTLE;
}

/* {LX_GENERATABLE_DFA}.put_eob_state */
void F1074_7140 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,loc3);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,1068,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc2 = RTLNS(typres0.id, 1158, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	F1159_7647(RTCW(loc2), ((EIF_INTEGER_32) 0L));
	loc1 = RTLNS(eif_new_type(1069, 0x01).id, 1069, _OBJSIZ_4_0_0_2_0_0_0_0_);
	F1070_7071(RTCW(loc1), loc2, *(EIF_INTEGER_32 *)(Current + O5466[dtype-1072]), *(EIF_INTEGER_32 *)(Current + O5467[dtype-1072]));
	loc3 = RTLNS(eif_new_type(162, 0x01).id, 162, _OBJSIZ_2_2_0_6_0_0_0_0_);
	F163_1709(RTCW(loc3), *(EIF_INTEGER_32 *)(Current + O5361[dtype-1059]));
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
	F1159_7670(RTCW(tr1), loc3);
	tr1 = *(EIF_REFERENCE *)(Current + O5469[dtype-1072]);
	F1159_7666(RTCW(tr1), loc1);
	tr1 = *(EIF_REFERENCE *)(Current + O5469[dtype-1072]);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	F1070_7080(RTCW(loc1), ti4_1);
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_scanner */
void F1074_7142 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O5505[dtype-1073])) {
		F1074_7144(Current, arg1);
	}
	F1074_7145(Current, arg1);
	tr1 = RTMS_EX_H("\012feature -- Status report\012\012",27,2128155658);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	F1074_7146(Current, arg1);
	tr1 = RTMS_EX_H("\012feature {NONE} -- Implementation\012\012",35,94872586);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5487[dtype-1074])(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
	F1074_7148(Current, arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
	F1074_7154(Current, arg1);
	tr1 = RTMS_EX_H("\012feature {NONE} -- Table templates\012\012",36,1394488842);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5495[dtype-1074])(Current, arg1);
	tr1 = RTMS_EX_H("\012feature {NONE} -- Constants\012\012",30,1306754314);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5496[dtype-1074])(Current, arg1);
	tr1 = RTMS_EX_H("\012feature -- User-defined features\012\012",35,1428619018);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	F1074_7157(Current, arg1);
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_backing_up_report */
void F1074_7143 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc3);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O5465[dtype-1072]);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	tr1 = *(EIF_REFERENCE *)(Current + O5469[dtype-1072]);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + O5469[dtype-1072]);
		loc3 = F1159_7653(RTCW(tr1), loc1);
		tb1 = F1070_7081(RTCW(loc3));
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = RTMS_EX_H("State #",7,1007266339);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_4_0_0_0_);
			F924_5951(RTCW(arg1), ti4_1);
			tr1 = RTMS_EX_H(" is non-accepting -\012",20,883700746);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			F1074_7159(Current, loc3, arg1);
			F1074_7160(Current, loc3, arg1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
		}
		loc1++;
	}
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_bom */
void F1074_7144 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(6109,F938_6109, (Current));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_eiffel_header */
void F1074_7145 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O5507[dtype-1073]) != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + O5507[dtype-1073]);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_4_0_0_1_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = *(EIF_REFERENCE *)(Current + O5507[dtype-1073]);
			tr1 = F1159_7653(RTCW(tr1), loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			loc1++;
		}
	}
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_status_report_routines */
void F1074_7146 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTMS_EX_H("\011valid_start_condition (sc: INTEGER): BOOLEAN\012\011\011\011-- Is `sc\' a valid start condition\?\012\011\011do\012\011\011\011Result := ",103,1231650592);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	ti4_1 = F702_3697(RTCW(tr1));
	switch (ti4_1) {
		case 0L:
			tr1 = RTMS_EX_H("False",5,1635034981);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			break;
		case 1L:
			tr1 = RTMS_EX_H("(sc = ",6,1742583584);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_1_1_0_1_);
			tr1 = F702_3690(RTCW(tr1), ti4_1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) ')');
			break;
		default:
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '(');
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_1_1_0_1_);
			tr1 = F702_3690(RTCW(tr1), ti4_1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			tr1 = RTMS_EX_H(" <= sc and sc <= ",17,637432608);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr2)+ _LNGOFF_1_1_0_0_);
			tr1 = F702_3690(RTCW(tr1), ti4_1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) ')');
			break;
	}
	tr1 = RTMS_EX_H("\012\011\011end\012",7,310222602);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_actions */
void F1074_7148 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("\011yy_execute_action (yy_act: INTEGER)\012\011\011\011-- Execute semantic action.\012\011\011do\012",73,1327100938);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	if (*(EIF_BOOLEAN *)(Current + O5516[dtype-1073])) {
		F1074_7149(Current, arg1);
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_1_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		ti4_2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
		F1074_7150(Current, arg1, ti4_1, ti4_2);
	}
	if (*(EIF_BOOLEAN *)(Current + O5510[dtype-1073])) {
		tr1 = RTMS_EX_H("\011\011\011post_action\012",15,1861173514);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	}
	if (*(EIF_BOOLEAN *)(Current + O5508[dtype-1073])) {
		tr1 = RTMS_EX_H("\011\011\011yy_set_beginning_of_line\012",28,1262148362);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	}
	tr1 = RTMS_EX_H("\011\011end\012",6,1719497226);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	if (*(EIF_BOOLEAN *)(Current + O5515[dtype-1073])) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_1_);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr1 = F702_3690(RTCW(tr1), loc1);
			F1074_7152(Current, arg1, tr1);
			loc1++;
		}
	}
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_inspect_actions */
void F1074_7149 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc5 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	RTCDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc3);
	RTLR(4,loc4);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = RTMS_EX_H("\011\011\011inspect yy_act\012",18,1358496778);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc3 = F702_3690(RTCW(tr1), loc1);
		tr1 = RTMS_EX_H("when ",5,1752391712);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_2_2_0_0_);
		F924_5951(RTCW(arg1), ti4_1);
		tb1 = *(EIF_BOOLEAN *)(RTCW(loc3)+ _CHROFF_2_1_);
		if ((EIF_BOOLEAN) !tb1) {
			loc1++;
			loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			for (;;) {
				if ((EIF_BOOLEAN) (loc5 || (EIF_BOOLEAN) (loc1 > loc2))) break;
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc4 = F702_3690(RTCW(tr1), loc1);
				tb1 = '\0';
				tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
				tr2 = *(EIF_REFERENCE *)(RTCW(loc4));
				if ((EIF_BOOLEAN)(tr1 == tr2)) {
					tb2 = '\01';
					tb3 = '\01';
					tb4 = *(EIF_BOOLEAN *)(RTCW(loc4)+ _CHROFF_2_1_);
					if (!tb4) {
						tb3 = *(EIF_BOOLEAN *)(Current + O5364[dtype-1059]);
					}
					if (!tb3) {
						tb2 = *(EIF_BOOLEAN *)(Current + O5365[dtype-1059]);
					}
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) {
					tr1 = RTMS_EX_H(", ",2,11296);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
					ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_2_2_0_0_);
					F924_5951(RTCW(arg1), ti4_1);
					loc1++;
				} else {
					tb1 = '\01';
					tb2 = '\01';
					tb3 = *(EIF_BOOLEAN *)(RTCW(loc4)+ _CHROFF_2_1_);
					if (!tb3) {
						tb2 = *(EIF_BOOLEAN *)(Current + O5364[dtype-1059]);
					}
					if (!tb2) {
						tb1 = *(EIF_BOOLEAN *)(Current + O5365[dtype-1059]);
					}
					if (tb1) {
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					} else {
						loc5 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					}
				}
			}
		} else {
			loc1++;
			if ((EIF_BOOLEAN) (loc1 <= loc2)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				loc4 = F702_3690(RTCW(tr1), loc1);
				tr1 = *(EIF_REFERENCE *)(RTCW(loc4));
				tr2 = *(EIF_REFERENCE *)(RTCW(loc3));
				if ((EIF_BOOLEAN)(tr1 == tr2)) {
				}
			}
		}
		tr1 = RTMS_EX_H(" then\012",6,1815283210);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
		F1074_7151(Current, arg1, loc3);
	}
	tr1 = RTMS_EX_H("\011\011\011else\012",8,2074934538);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	if (*(EIF_BOOLEAN *)(Current + O5509[dtype-1073])) {
		tr1 = RTMS_EX_H("\011\011\011\011pre_action\012",15,1196381450);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	}
	tr1 = RTMS_EX_H("\011\011\011\011last_token := yyError_token\012\011\011\011\011fatal_error (\"fatal scanner internal error: no action found\")\012\011\011\011end\012",105,1612643338);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_binary_search_actions */
void F1074_7150 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg2 == arg3)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tr1 = F702_3690(RTCW(tr1), arg2);
		F1074_7151(Current, arg1, tr1);
	} else {
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L)) == arg3)) {
			tr1 = RTMS_EX_H("if yy_act = ",12,954784032);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			F924_5951(RTCW(arg1), arg2);
			tr1 = RTMS_EX_H(" then\012",6,1815283210);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr1 = F702_3690(RTCW(tr1), arg2);
			F1074_7151(Current, arg1, tr1);
			tr1 = RTMS_EX_H("else\012",5,1820277514);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr1 = F702_3690(RTCW(tr1), arg3);
			F1074_7151(Current, arg1, tr1);
			tr1 = RTMS_EX_H("end\012",4,1701733386);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
		} else {
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) / ((EIF_INTEGER_32) 2L)));
			tr1 = RTMS_EX_H("if yy_act <= ",13,1759435808);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			F924_5951(RTCW(arg1), loc1);
			tr1 = RTMS_EX_H(" then\012",6,1815283210);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			F1074_7150(Current, arg1, arg2, loc1);
			tr1 = RTMS_EX_H("else\012",5,1820277514);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			F1074_7150(Current, arg1, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), arg3);
			tr1 = RTMS_EX_H("end\012",4,1701733386);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
		}
	}
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_action_call */
void F1074_7151 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,arg2);
	RTLIU(4);
	
	RTGC;
	if (*(EIF_BOOLEAN *)(Current + O5515[dtype-1073])) {
		tr1 = RTMS_EX_H("\011\011--|#line ",11,1008859936);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
		if (*(EIF_BOOLEAN *)(Current + O5513[dtype-1073])) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_2_0_1_);
			F924_5951(RTCW(arg1), ti4_1);
		} else {
			tr1 = RTMS_EX_H("<not available>",15,705516862);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
		}
		tr1 = RTMS_EX_H(" \"",2,8226);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, *(EIF_REFERENCE *)(Current + O5504[dtype-1073]));
		tr1 = RTMS_EX_H("\"\012\011yy_execute_action_",21,674185055);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_2_0_0_);
		F924_5951(RTCW(arg1), ti4_1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
	} else {
		F1074_7153(Current, arg1, arg2);
	}
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_action_routine */
void F1074_7152 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = RTMS_EX_H("\011yy_execute_action_",19,499707487);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_2_0_0_);
	F924_5951(RTCW(arg1), ti4_1);
	tr1 = RTMS_EX_H("\012\011\011\011--|#line ",13,567674400);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	if (*(EIF_BOOLEAN *)(Current + O5513[dtype-1073])) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_2_0_1_);
		F924_5951(RTCW(arg1), ti4_1);
	} else {
		tr1 = RTMS_EX_H("<not available>",15,705516862);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	}
	tr1 = RTMS_EX_H(" \"",2,8226);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, *(EIF_REFERENCE *)(Current + O5504[dtype-1073]));
	tr1 = RTMS_EX_H("\"\012\011\011do\012",7,110228746);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	F1074_7153(Current, arg1, arg2);
	tr1 = RTMS_EX_H("\012\011\011end\012",7,310222602);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_action_body */
void F1074_7153 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg2)+ _CHROFF_2_1_);
	if (tb1) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_2_0_3_);
		if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 0L))) {
			tr1 = RTMS_EX_H("\011yy_end := yy_end - ",20,367518240);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_2_0_3_);
			F924_5951(RTCW(arg1), ti4_1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_2_0_2_);
			if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 0L))) {
				tr1 = RTMS_EX_H("\011yy_end := yy_start + yy_more_len + ",36,2121564448);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_2_0_2_);
				F924_5951(RTCW(arg1), ti4_1);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
			}
		}
	}
	if (*(EIF_BOOLEAN *)(Current + O5364[dtype-1059])) {
		loc1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_2_0_4_);
		loc2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_2_0_5_);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
			if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
				tr1 = RTMS_EX_H("\011yy_column := yy_column + ",26,1251453728);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
				F924_5951(RTCW(arg1), loc2);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
			} else {
				if ((EIF_BOOLEAN)(loc2 != ((EIF_INTEGER_32) 0L))) {
					tr1 = RTMS_EX_H("\011yy_column := yy_column + yy_end - yy_start - yy_more_len\012",58,2110195722);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
				}
			}
		} else {
			if ((EIF_BOOLEAN) (loc1 > ((EIF_INTEGER_32) 0L))) {
				if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
					tr1 = RTMS_EX_H("\011yy_line := yy_line + ",22,681639712);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
					F924_5951(RTCW(arg1), loc1);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
					tr1 = RTMS_EX_H("\011yy_column := 1\012",16,1853028362);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
				} else {
					if ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L))) {
						tr1 = RTMS_EX_H("\011yy_line := yy_line + ",22,681639712);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
						F924_5951(RTCW(arg1), loc1);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
						tr1 = RTMS_EX_H("\011yy_column := ",14,618981920);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
						F924_5951(RTCW(arg1), loc2);
						tr1 = RTMS_EX_H(" + 1\012",5,723775754);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
					} else {
						tr1 = RTMS_EX_H("yy_set_column (",15,244382760);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
						F924_5951(RTCW(arg1), loc1);
						tr1 = RTMS_EX_H(")\012",2,10506);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
					}
				}
			} else {
				if ((EIF_BOOLEAN) (loc2 >= ((EIF_INTEGER_32) 0L))) {
					tr1 = RTMS_EX_H("yy_set_line (",13,212798504);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
					F924_5951(RTCW(arg1), loc2);
					tr1 = RTMS_EX_H(")\012",2,10506);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
				} else {
					tr1 = RTMS_EX_H("yy_set_line_column\012",19,885416202);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
				}
			}
		}
	}
	if (*(EIF_BOOLEAN *)(Current + O5365[dtype-1059])) {
		loc3 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_2_0_2_);
		if ((EIF_BOOLEAN) (loc3 > ((EIF_INTEGER_32) 0L))) {
			tr1 = RTMS_EX_H("\011yy_position := yy_position + ",30,383188768);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			F924_5951(RTCW(arg1), loc3);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
		} else {
			if ((EIF_BOOLEAN)(loc3 != ((EIF_INTEGER_32) 0L))) {
				tr1 = RTMS_EX_H("\011yy_position := yy_position + yy_end - yy_start - yy_more_len\012",62,567004682);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			}
		}
	}
	if (*(EIF_BOOLEAN *)(Current + O5509[dtype-1073])) {
		tr1 = RTMS_EX_H("pre_action\012",11,768476682);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	}
	tr1 = RTMS_EX_H("--|#line ",9,342430240);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	if (*(EIF_BOOLEAN *)(Current + O5513[dtype-1073])) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_2_0_1_);
		F924_5951(RTCW(arg1), ti4_1);
	} else {
		tr1 = RTMS_EX_H("<not available>",15,705516862);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	}
	tr1 = RTMS_EX_H(" \"",2,8226);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, *(EIF_REFERENCE *)(Current + O5504[dtype-1073]));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\"');
	F927_5969(RTCW(arg1));
	tr1 = RTMS_EX_H("debug (\"GELEX\")",15,1455994153);
	F927_5968(RTCW(arg1), tr1);
	tr1 = RTMS_EX_H("\011std.error.put_line (\"Executing scanner user-code from file \'",61,1899330087);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, *(EIF_REFERENCE *)(Current + O5504[dtype-1073]));
	tr1 = RTMS_EX_H("\' at line ",10,320983584);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	if (*(EIF_BOOLEAN *)(Current + O5513[dtype-1073])) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_2_2_0_1_);
		F924_5951(RTCW(arg1), ti4_1);
	} else {
		tr1 = RTMS_EX_H("<not available>",15,705516862);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	}
	tr1 = RTMS_EX_H("\")",2,8745);
	F927_5968(RTCW(arg1), tr1);
	tr1 = RTMS_EX_H("end",3,6647396);
	F927_5968(RTCW(arg1), tr1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
	tr1 = F109_1160(RTCW(tr1));
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	F927_5969(RTCW(arg1));
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_eof_actions */
void F1074_7154 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc4);
	RTLR(4,loc3);
	RTLR(5,loc5);
	RTLR(6,loc9);
	RTLR(7,loc8);
	RTLR(8,loc10);
	RTLIU(9);
	
	RTGC;
	tr1 = RTMS_EX_H("\011yy_execute_eof_action (yy_sc: INTEGER)\012\011\011\011-- Execute EOF semantic action.\012\011\011do\012",80,1675121418);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	if (*(EIF_BOOLEAN *)(Current + O5511[dtype-1073])) {
		tr1 = RTMS_EX_H("\011\011\011pre_eof_action\012",18,711072522);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_1_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1158,0xFF01,152,0xFF01,107,0xFF01,1144,0xFF01,162,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc4 = RTLNS(typres0.id, 1158, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	ti4_1 = F702_3697(RTCW(tr1));
	F1159_7647(RTCW(loc4), ti4_1);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc3 = F702_3690(RTCW(tr1), loc1);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			loc5 = *(EIF_REFERENCE *)(RTCW(loc3));
			loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc7 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_4_0_0_1_);
			for (;;) {
				tb1 = '\01';
				if (!(EIF_BOOLEAN) (loc6 > loc7)) {
					tr1 = F1159_7653(RTCW(loc4), loc6);
					tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
					tb1 = (EIF_BOOLEAN)(tr1 == loc5);
				}
				if (tb1) break;
				loc6++;
			}
			if ((EIF_BOOLEAN) (loc6 <= loc7)) {
				tr1 = F1159_7653(RTCW(loc4), loc6);
				loc9 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			} else {
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,1144,0xFF01,162,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					loc9 = RTLNS(typres0.id, 1144, _OBJSIZ_4_0_0_1_0_0_0_0_);
				}
				F1145_7496(RTCW(loc9));
				{
					static EIF_TYPE_INDEX typarr0[] = {0xFF01,152,0xFF01,107,0xFF01,1144,0xFF01,162,0xFFFF};
					EIF_TYPE typres0;
					static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
					
					typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
					loc8 = RTLNS(typres0.id, 152, _OBJSIZ_2_0_0_0_0_0_0_0_);
				}
				F153_1683(RTCW(loc8), loc5, loc9);
				F1159_7666(RTCW(loc4), loc8);
			}
			F1145_7522(RTCW(loc9), loc3);
		}
		loc1++;
	}
	loc7 = *(EIF_INTEGER_32 *)(RTCW(loc4)+ _LNGOFF_4_0_0_1_);
	if ((EIF_BOOLEAN) (loc7 > ((EIF_INTEGER_32) 0L))) {
		tr1 = RTMS_EX_H("\011\011\011inspect yy_sc\012",17,946008586);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
		loc6 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc6 > loc7)) break;
			tr1 = F1159_7653(RTCW(loc4), loc6);
			loc9 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
			loc10 = F1145_7505(RTCW(loc9));
			F990_6721(RTCW(loc10));
			loc3 = F1040_6809(RTCW(loc10));
			tr1 = RTMS_EX_H("when ",5,1752391712);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_2_2_0_0_);
			F924_5951(RTCW(arg1), ti4_1);
			F990_6722(RTCW(loc10));
			for (;;) {
				tb2 = *(EIF_BOOLEAN *)(RTCW(loc10)+ _CHROFF_3_1_);
				if (tb2) break;
				tr1 = RTMS_EX_H(", ",2,11296);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
				tr1 = F1040_6809(RTCW(loc10));
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_2_0_0_);
				F924_5951(RTCW(arg1), ti4_1);
				F990_6722(RTCW(loc10));
			}
			tr1 = RTMS_EX_H(" then\012",6,1815283210);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			tr1 = RTMS_EX_H("--|#line ",9,342430240);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			if (*(EIF_BOOLEAN *)(Current + O5513[dtype-1073])) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_2_2_0_1_);
				F924_5951(RTCW(arg1), ti4_1);
			} else {
				tr1 = RTMS_EX_H("<not available>",15,705516862);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			}
			tr1 = RTMS_EX_H(" \"",2,8226);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, *(EIF_REFERENCE *)(Current + O5504[dtype-1073]));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\"');
			F927_5969(RTCW(arg1));
			tr1 = RTMS_EX_H("debug (\"GELEX\")",15,1455994153);
			F927_5968(RTCW(arg1), tr1);
			tr1 = RTMS_EX_H("\011std.error.put_line (\"Executing scanner user-code from file \'",61,1899330087);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, *(EIF_REFERENCE *)(Current + O5504[dtype-1073]));
			tr1 = RTMS_EX_H("\' at line ",10,320983584);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			if (*(EIF_BOOLEAN *)(Current + O5513[dtype-1073])) {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_2_2_0_1_);
				F924_5951(RTCW(arg1), ti4_1);
			} else {
				tr1 = RTMS_EX_H("<not available>",15,705516862);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			}
			tr1 = RTMS_EX_H("\")",2,8745);
			F927_5968(RTCW(arg1), tr1);
			tr1 = RTMS_EX_H("end",3,6647396);
			F927_5968(RTCW(arg1), tr1);
			tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
			tr1 = F109_1160(RTCW(tr1));
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
			F927_5969(RTCW(arg1));
			loc6++;
		}
		tr1 = RTMS_EX_H("\011\011\011else\012\011\011\011\011terminate\012\011\011\011end\012",29,955538954);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	} else {
		tr1 = RTMS_EX_H("\011\011\011terminate\012",13,1510107914);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	}
	if (*(EIF_BOOLEAN *)(Current + O5512[dtype-1073])) {
		tr1 = RTMS_EX_H("\011\011\011post_eof_action\012",19,1336311050);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	}
	tr1 = RTMS_EX_H("\011\011end\012",6,1719497226);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_constants */
void F1074_7156 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTMS_EX_H("\011yyNb_rules: INTEGER = ",23,1138243616);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	F924_5951(RTCW(arg1), *(EIF_INTEGER_32 *)(Current + O5360[dtype-1059]));
	tr1 = RTMS_EX_H("\012\011\011\011-- Number of rules\012\012\011yyEnd_of_buffer: INTEGER = ",52,1209235744);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	F924_5951(RTCW(arg1), *(EIF_INTEGER_32 *)(Current + O5361[dtype-1059]));
	tr1 = RTMS_EX_H("\012\011\011\011-- End of buffer rule code\012\012\011yyLine_used: BOOLEAN = ",56,4194848);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTOSCF(2134,F222_2134, (Current));
	F9_86(RTCW(tr1), arg1, *(EIF_BOOLEAN *)(Current + O5364[dtype-1059]));
	tr1 = RTMS_EX_H("\012\011\011\011-- Are line and column numbers used\?\012\012\011yyPosition_used: BOOLEAN = ",70,490866976);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = RTOSCF(2134,F222_2134, (Current));
	F9_86(RTCW(tr1), arg1, *(EIF_BOOLEAN *)(Current + O5365[dtype-1059]));
	tr1 = RTMS_EX_H("\012\011\011\011-- Is `position\' used\?\012\012",28,1498629130);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\011');
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr1 = F702_3690(RTCW(tr1), loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
		tr1 = RTMS_EX_H(": INTEGER = ",12,442146592);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
		F924_5951(RTCW(arg1), loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg1))-927])(arg1, (EIF_CHARACTER_8) '\012');
		loc1++;
	}
	tr1 = RTMS_EX_H("\011\011\011-- Start condition codes\012",28,551774730);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, tr1);
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_eiffel_code */
void F1074_7157 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O5506[Dtype(Current)-1073]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg1))-927])(arg1, loc1);
	}
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_eiffel_array */
void F1074_7158 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc9 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN tb4;
	EIF_BOOLEAN tb5;
	EIF_BOOLEAN tb6;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg2);
	RTLR(1,arg3);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	loc9 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 25L);
	loc4 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_1_);
	loc5 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_0_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg3))-927])(arg3, (EIF_CHARACTER_8) '\011');
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, arg1);
	tr1 = RTMS_EX_H(": SPECIAL [INTEGER]\012",20,1117505802);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
	tr1 = RTMS_EX_H("_template",9,516553061);
	tb1 = F913_5788(RTCW(arg1), tr1);
	if (tb1) {
		tr1 = RTMS_EX_H("\011\011\011-- Template for `",20,617605728);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4338[Dtype(RTCW(arg1))-910])(arg1, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 9L)));
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
		tr1 = RTMS_EX_H("\'\012",2,9994);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
	} else {
		tr1 = RTMS_EX_H("\011\011\011-- `",7,1010584672);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, arg1);
		tr1 = RTMS_EX_H("\'\012",2,9994);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O5514[dtype-1073]) == ((EIF_INTEGER_32) 0L))) {
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		loc3 = F703_3697(RTCW(arg2));
		ti4_1 = *(EIF_INTEGER_32 *)(Current + O5514[dtype-1073]);
		loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 / ti4_1);
		ti4_1 = F703_3697(RTCW(arg2));
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) (ti4_1 % *(EIF_INTEGER_32 *)(Current + O5514[dtype-1073])) != ((EIF_INTEGER_32) 0L))) {
			loc3++;
		}
	}
	if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) {
		tr1 = RTMS_EX_H("\011\011once\012\011\011\011Result := yy_fixed_array (<<yy_Dummy>>)\012\011\011end\012",56,1698322954);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
	} else {
		if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 1L))) {
			tr1 = RTMS_EX_H("\011\011once\012\011\011\011Result := yy_fixed_array (<<\012",39,1078641162);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
			tr1 = RTOSCF(2136,F222_2136, (Current));
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_1_);
			ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg2)+ _LNGOFF_1_1_0_0_);
			F8_77(RTCW(tr1), arg3, arg2, ti4_1, ti4_2);
			tr1 = RTMS_EX_H(", yy_Dummy>>)\012\011\011end\012",20,1104336394);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
		} else {
			tr1 = RTMS_EX_H("\011\011local\012\011\011\011an_array: ARRAY [INTEGER]\012\011\011once\012\011\011\011create an_array.make_filled (0, ",79,1953116704);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
			F924_5951(RTCW(arg3), loc4);
			tr1 = RTMS_EX_H(", ",2,11296);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
			F924_5951(RTCW(arg3), loc5);
			tr1 = RTMS_EX_H(")\012",2,10506);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc1 = (EIF_INTEGER_32) loc4;
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc5)) break;
				loc6 = (EIF_INTEGER_32) loc1;
				ti4_1 = *(EIF_INTEGER_32 *)(Current + O5514[dtype-1073]);
				loc7 = eif_min_int32 ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + ti4_1) - ((EIF_INTEGER_32) 1L)),loc5);
				for (;;) {
					tb1 = '\01';
					if (!(EIF_BOOLEAN) (loc6 > loc7)) {
						tb2 = '\0';
						if ((EIF_BOOLEAN) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 - loc6) + ((EIF_INTEGER_32) 1L)) >= loc9)) {
							tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
							ti4_1 = F703_3690(RTCW(arg2), loc6);
							tb3 = F678_3611(RTCW(tr1), ti4_1, (EIF_INTEGER_32) (loc6 - loc4), (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 - loc4) + loc9) - ((EIF_INTEGER_32) 1L)));
							tb2 = tb3;
						}
						tb1 = tb2;
					}
					if (tb1) break;
					loc6++;
				}
				if ((EIF_BOOLEAN)(loc6 == loc1)) {
					loc8 = F703_3690(RTCW(arg2), loc1);
					loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + loc9);
					for (;;) {
						tb2 = '\01';
						if (!(EIF_BOOLEAN) (loc7 > loc5)) {
							ti4_1 = F703_3690(RTCW(arg2), loc7);
							tb2 = (EIF_BOOLEAN)(ti4_1 != loc8);
						}
						if (tb2) break;
						loc7++;
					}
					loc7--;
					tr1 = RTOSCF(7177,F1074_7177, (Current));
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
					tr1 = RTMS_EX_H("an_array.area.fill_with (",25,1147611176);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
					F924_5951(RTCW(arg3), loc8);
					tr1 = RTMS_EX_H(", ",2,11296);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
					F924_5951(RTCW(arg3), (EIF_INTEGER_32) (loc1 - loc4));
					tr1 = RTMS_EX_H(", ",2,11296);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
					F924_5951(RTCW(arg3), (EIF_INTEGER_32) (loc7 - loc4));
					tr1 = RTMS_EX_H(")\012",2,10506);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
				} else {
					if ((EIF_BOOLEAN) (loc6 <= loc7)) {
						loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 - ((EIF_INTEGER_32) 1L));
					}
					if ((EIF_BOOLEAN)(loc7 == loc1)) {
						tr1 = RTOSCF(7177,F1074_7177, (Current));
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
						tr1 = RTMS_EX_H("an_array.put (",14,317218600);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
						ti4_1 = F703_3690(RTCW(arg2), loc1);
						F924_5951(RTCW(arg3), ti4_1);
						tr1 = RTMS_EX_H(", ",2,11296);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
						F924_5951(RTCW(arg3), loc1);
						tr1 = RTMS_EX_H(")\012",2,10506);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
					} else {
						tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
						ti4_1 = F703_3690(RTCW(arg2), loc1);
						tb3 = F678_3611(RTCW(tr1), ti4_1, (EIF_INTEGER_32) (loc1 - loc4), (EIF_INTEGER_32) (loc7 - loc4));
						if (tb3) {
							tr1 = RTOSCF(7177,F1074_7177, (Current));
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
							tr1 = RTMS_EX_H("an_array.area.fill_with (",25,1147611176);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
							ti4_1 = F703_3690(RTCW(arg2), loc1);
							F924_5951(RTCW(arg3), ti4_1);
							tr1 = RTMS_EX_H(", ",2,11296);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
							F924_5951(RTCW(arg3), (EIF_INTEGER_32) (loc1 - loc4));
							tr1 = RTMS_EX_H(", ",2,11296);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
							F924_5951(RTCW(arg3), (EIF_INTEGER_32) (loc7 - loc4));
							tr1 = RTMS_EX_H(")\012",2,10506);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
						} else {
							tr1 = RTOSCF(7177,F1074_7177, (Current));
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, arg1);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg3))-927])(arg3, (EIF_CHARACTER_8) '_');
							F924_5951(RTCW(arg3), loc2);
							tr1 = RTMS_EX_H(" (an_array)\012",12,344871434);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
							loc2++;
						}
					}
				}
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 1L));
			}
			tr1 = RTMS_EX_H("\011\011\011Result := yy_fixed_array (an_array)\012\011\011end\012",45,1806436874);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
			loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			loc1 = (EIF_INTEGER_32) loc4;
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc5)) break;
				loc6 = (EIF_INTEGER_32) loc1;
				ti4_1 = *(EIF_INTEGER_32 *)(Current + O5514[dtype-1073]);
				loc7 = eif_min_int32 ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + ti4_1) - ((EIF_INTEGER_32) 1L)),loc5);
				for (;;) {
					tb3 = '\01';
					if (!(EIF_BOOLEAN) (loc6 > loc7)) {
						tb4 = '\0';
						if ((EIF_BOOLEAN) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc5 - loc6) + ((EIF_INTEGER_32) 1L)) >= loc9)) {
							tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
							ti4_1 = F703_3690(RTCW(arg2), loc6);
							tb5 = F678_3611(RTCW(tr1), ti4_1, (EIF_INTEGER_32) (loc6 - loc4), (EIF_INTEGER_32) ((EIF_INTEGER_32) ((EIF_INTEGER_32) (loc6 - loc4) + loc9) - ((EIF_INTEGER_32) 1L)));
							tb4 = tb5;
						}
						tb3 = tb4;
					}
					if (tb3) break;
					loc6++;
				}
				if ((EIF_BOOLEAN)(loc6 == loc1)) {
					loc8 = F703_3690(RTCW(arg2), loc1);
					loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + loc9);
					for (;;) {
						tb4 = '\01';
						if (!(EIF_BOOLEAN) (loc7 > loc5)) {
							ti4_1 = F703_3690(RTCW(arg2), loc7);
							tb4 = (EIF_BOOLEAN)(ti4_1 != loc8);
						}
						if (tb4) break;
						loc7++;
					}
					loc7--;
				} else {
					if ((EIF_BOOLEAN) (loc6 <= loc7)) {
						loc7 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 - ((EIF_INTEGER_32) 1L));
					}
					tb5 = '\0';
					if ((EIF_BOOLEAN)(loc7 != loc1)) {
						tr1 = *(EIF_REFERENCE *)(RTCW(arg2));
						ti4_1 = F703_3690(RTCW(arg2), loc1);
						tb6 = F678_3611(RTCW(tr1), ti4_1, (EIF_INTEGER_32) (loc1 - loc4), (EIF_INTEGER_32) (loc7 - loc4));
						tb5 = (EIF_BOOLEAN) !tb6;
					}
					if (tb5) {
						tr1 = RTMS_EX_H("\012\011",2,2569);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, arg1);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg3))-927])(arg3, (EIF_CHARACTER_8) '_');
						F924_5951(RTCW(arg3), loc2);
						tr1 = RTMS_EX_H(" (an_array: ARRAY [INTEGER])\012",29,2050092042);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
						tr1 = RTMS_EX_H("\011\011\011-- Fill chunk #",18,1617121827);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
						F924_5951(RTCW(arg3), loc2);
						tr1 = RTMS_EX_H(" of ",4,544171552);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
						tr1 = RTMS_EX_H("_template",9,516553061);
						tb5 = F913_5788(RTCW(arg1), tr1);
						if (tb5) {
							tr1 = RTMS_EX_H("template for `",14,1558312032);
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
							ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
							tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32)) R4338[Dtype(RTCW(arg1))-910])(arg1, ((EIF_INTEGER_32) 1L), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 9L)));
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
						} else {
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg3))-927])(arg3, (EIF_CHARACTER_8) '`');
							(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, arg1);
						}
						tr1 = RTMS_EX_H("\'.\012",3,2567690);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
						tr1 = RTMS_EX_H("\011\011do\012\011\011\011yy_array_subcopy (an_array, <<\012",39,825229834);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
						tr1 = RTOSCF(2136,F222_2136, (Current));
						F8_77(RTCW(tr1), arg3, arg2, loc1, loc7);
						tr1 = RTMS_EX_H(", yy_Dummy>>,\012\011\011\011",17,266440457);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
						F924_5951(RTCW(arg3), ((EIF_INTEGER_32) 1L));
						tr1 = RTMS_EX_H(", ",2,11296);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
						F924_5951(RTCW(arg3), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc7 - loc1) + ((EIF_INTEGER_32) 1L)));
						tr1 = RTMS_EX_H(", ",2,11296);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
						F924_5951(RTCW(arg3), loc1);
						tr1 = RTMS_EX_H(")\012\011\011end\012",8,319669002);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg3))-927])(arg3, tr1);
						loc2++;
					}
				}
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc7 + ((EIF_INTEGER_32) 1L));
			}
		}
	}
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_rule_line_numbers */
void F1074_7159 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc6);
	RTLR(1,arg1);
	RTLR(2,loc7);
	RTLR(3,Current);
	RTLR(4,loc5);
	RTLR(5,tr1);
	RTLR(6,arg2);
	RTLIU(7);
	
	RTGC;
	loc6 = *(EIF_REFERENCE *)(RTCW(arg1));
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_4_0_0_1_);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1159,834,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		loc7 = RTLNS(typres0.id, 1159, _OBJSIZ_4_0_0_2_0_0_0_0_);
	}
	F1160_7647(RTCW(loc7), loc2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc5 = F1159_7653(RTCW(loc6), loc1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc3 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_1_);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		loc4 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_1_1_0_0_);
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN) (loc3 > loc4)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				tr1 = F702_3690(RTCW(tr1), loc3);
				tr1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
				tb2 = F1072_7098(RTCW(tr1), loc5);
				tb1 = tb2;
			}
			if (tb1) break;
			loc3++;
		}
		if ((EIF_BOOLEAN) (loc3 <= loc4)) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr1 = F702_3690(RTCW(tr1), loc3);
			loc8 = *(EIF_INTEGER_32 *)(RTCW(tr1)+ _LNGOFF_2_2_0_1_);
		}
		tb2 = F1160_7660(RTCW(loc7), loc8);
		if ((EIF_BOOLEAN) !tb2) {
			F1160_7666(RTCW(loc7), loc8);
		}
		loc1++;
	}
	tr1 = RTOSCF(7178,F1074_7178, (Current));
	F1092_7280(RTCW(loc7), tr1);
	tr1 = RTMS_EX_H(" associated rule line numbers:",30,323372090);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg2))-927])(arg2, tr1);
	loc2 = *(EIF_INTEGER_32 *)(RTCW(loc7)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		if ((EIF_BOOLEAN)((EIF_INTEGER_32) (loc1 % ((EIF_INTEGER_32) 8L)) == ((EIF_INTEGER_32) 1L))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg2))-927])(arg2, (EIF_CHARACTER_8) '\012');
		}
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg2))-927])(arg2, (EIF_CHARACTER_8) '\011');
		ti4_1 = F1160_7653(RTCW(loc7), loc1);
		F924_5951(RTCW(arg2), ti4_1);
		loc1++;
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg2))-927])(arg2, (EIF_CHARACTER_8) '\012');
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_transitions */
void F1074_7160 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc3);
	RTLR(1,arg1);
	RTLR(2,loc7);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc4);
	RTLR(6,arg2);
	RTLIU(7);
	
	RTGC;
	loc3 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		loc5 = *(EIF_INTEGER_32 *)(Current + O5466[dtype-1072]);
		loc6 = *(EIF_INTEGER_32 *)(loc7+ _LNGOFF_1_1_0_0_);
		loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 - ((EIF_INTEGER_32) 1L));
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,704,867,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc4 = RTLNS(typres0.id, 704, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		F705_3685(RTCW(loc4), (EIF_BOOLEAN) 0, loc5, loc6);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc6)) break;
			loc2 = F703_3690(loc7, loc1);
			if ((EIF_BOOLEAN)(loc2 == (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5467[dtype-1072]) + ((EIF_INTEGER_32) 1L)))) {
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			}
			tb1 = F1067_7038(RTCW(loc3), loc2);
			if (tb1) {
				tr1 = F1067_7040(RTCW(loc3), loc2);
				F705_3709(RTCW(loc4), (EIF_BOOLEAN)(tr1 != NULL), loc1);
			}
			loc1++;
		}
		if ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 0L))) {
			loc2 = F703_3690(loc7, (EIF_INTEGER_32) (loc6 + ((EIF_INTEGER_32) 1L)));
			if ((EIF_BOOLEAN)(loc2 == (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current + O5467[dtype-1072]) + ((EIF_INTEGER_32) 1L)))) {
				loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
			}
			tb1 = F1067_7038(RTCW(loc3), loc2);
			if (tb1) {
				tr1 = F1067_7040(RTCW(loc3), loc2);
				F705_3709(RTCW(loc4), (EIF_BOOLEAN)(tr1 != NULL), loc5);
			}
		}
	} else {
		loc5 = *(EIF_INTEGER_32 *)(Current + O5466[dtype-1072]);
		loc6 = *(EIF_INTEGER_32 *)(Current + O5467[dtype-1072]);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,704,867,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			loc4 = RTLNS(typres0.id, 704, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		F705_3685(RTCW(loc4), (EIF_BOOLEAN) 0, loc5, loc6);
		loc1 = (EIF_INTEGER_32) loc5;
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc6)) break;
			tb1 = F1067_7038(RTCW(loc3), loc1);
			if (tb1) {
				tr1 = F1067_7040(RTCW(loc3), loc1);
				F705_3709(RTCW(loc4), (EIF_BOOLEAN)(tr1 != NULL), loc1);
			}
			loc1++;
		}
	}
	tr1 = RTMS_EX_H(" out-transitions: [",19,1461046363);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg2))-927])(arg2, tr1);
	loc1 = (EIF_INTEGER_32) loc5;
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc6)) break;
		tb1 = F705_3690(RTCW(loc4), loc1);
		if (tb1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg2))-927])(arg2, (EIF_CHARACTER_8) ' ');
			F1074_7161(Current, loc1, arg2);
			loc2 = (EIF_INTEGER_32) loc1;
			loc1++;
			for (;;) {
				tb1 = '\01';
				if (!(EIF_BOOLEAN) (loc1 > loc6)) {
					tb2 = F705_3690(RTCW(loc4), loc1);
					tb1 = (EIF_BOOLEAN) !tb2;
				}
				if (tb1) break;
				loc1++;
			}
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)) > loc2)) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg2))-927])(arg2, (EIF_CHARACTER_8) '-');
				F1074_7161(Current, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)), arg2);
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg2))-927])(arg2, (EIF_CHARACTER_8) ' ');
		}
		loc1++;
	}
	tr1 = RTMS_EX_H("]\012 jam-transitions: EOF [",25,1336264539);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg2))-927])(arg2, tr1);
	loc1 = (EIF_INTEGER_32) loc5;
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc6)) break;
		tb2 = F705_3690(RTCW(loc4), loc1);
		if ((EIF_BOOLEAN) !tb2) {
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg2))-927])(arg2, (EIF_CHARACTER_8) ' ');
			F1074_7161(Current, loc1, arg2);
			loc2 = (EIF_INTEGER_32) loc1;
			loc1++;
			for (;;) {
				tb2 = '\01';
				if (!(EIF_BOOLEAN) (loc1 > loc6)) {
					tb3 = F705_3690(RTCW(loc4), loc1);
					tb2 = tb3;
				}
				if (tb2) break;
				loc1++;
			}
			if ((EIF_BOOLEAN) ((EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)) > loc2)) {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg2))-927])(arg2, (EIF_CHARACTER_8) '-');
				F1074_7161(Current, (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)), arg2);
			}
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg2))-927])(arg2, (EIF_CHARACTER_8) ' ');
		}
		loc1++;
	}
	tr1 = RTMS_EX_H("]\012",2,23818);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg2))-927])(arg2, tr1);
	RTLE;
}

/* {LX_GENERATABLE_DFA}.print_readable_character */
void F1074_7161 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 < ((EIF_INTEGER_32) 32L)) || (EIF_BOOLEAN) (arg1 >= ((EIF_INTEGER_32) 127L)))) {
		switch (arg1) {
			case 8L:
				tr1 = RTMS_EX_H("\\b",2,23650);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg2))-927])(arg2, tr1);
				break;
			case 12L:
				tr1 = RTMS_EX_H("\\f",2,23654);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg2))-927])(arg2, tr1);
				break;
			case 10L:
				tr1 = RTMS_EX_H("\\n",2,23662);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg2))-927])(arg2, tr1);
				break;
			case 13L:
				tr1 = RTMS_EX_H("\\r",2,23666);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg2))-927])(arg2, tr1);
				break;
			case 9L:
				tr1 = RTMS_EX_H("\\t",2,23668);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg2))-927])(arg2, tr1);
				break;
			default:
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg2))-927])(arg2, (EIF_CHARACTER_8) '\\');
				loc3 = (EIF_INTEGER_32) arg1;
				if ((EIF_BOOLEAN) (loc3 < ((EIF_INTEGER_32) 0L))) {
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg2))-927])(arg2, (EIF_CHARACTER_8) '-');
					loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) -loc3;
				}
				loc1 = RTMS_EX_H("",0,0);
				for (;;) {
					if ((EIF_BOOLEAN)(loc3 == ((EIF_INTEGER_32) 0L))) break;
					tr1 = RTOSCF(5917,F917_5917, (Current));
					tr2 = eif_out__i4_s1((EIF_INTEGER_32) (loc3 % ((EIF_INTEGER_32) 8L)));
					loc2 = F936_6060(RTCW(tr1), tr2);
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4522[Dtype(RTCW(loc2))-914])(loc2, loc1);
					loc1 = (EIF_REFERENCE) loc2;
					loc3 /= ((EIF_INTEGER_32) 8L);
				}
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_1_1_0_2_);
				switch (ti4_1) {
					case 0L:
						tr1 = RTMS_EX_H("000",3,3158064);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg2))-927])(arg2, tr1);
						break;
					case 1L:
						tr1 = RTMS_EX_H("00",2,12336);
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg2))-927])(arg2, tr1);
						break;
					case 2L:
						(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg2))-927])(arg2, (EIF_CHARACTER_8) '0');
						break;
				}
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg2))-927])(arg2, loc1);
				break;
		}
	} else {
		if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 32L))) {
			tr1 = RTMS_EX_H("\' \'",3,2564135);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R4567[Dtype(RTCW(arg2))-927])(arg2, tr1);
		} else {
			tr1 = RTOSCF(4093,F794_4093, (Current));
			tc1 = F937_6079(RTCW(tr1), arg1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R973[Dtype(RTCW(arg2))-927])(arg2, tc1);
		}
	}
	RTLE;
}

/* {LX_GENERATABLE_DFA}.build_rules */
void F1074_7162 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_1_);
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 0L))) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,938,0xFF01,162,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNS(typres0.id, 938, _OBJSIZ_0_0_0_0_0_0_0_0_);
		}
		tr1 = F939_6159(RTCW(tr1), ((EIF_INTEGER_32) 1L));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,701,0xFF01,162,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNSMART(typres0.id);
		}
		tr2 = F1159_7654(RTCW(arg1));
		F702_3685(RTCW(tr1), tr2, ((EIF_INTEGER_32) 1L), loc2);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			tr2 = F1159_7653(RTCW(arg1), loc1);
			F702_3709(RTCW(tr1), tr2, loc1);
			loc1++;
		}
	}
	RTLE;
}

/* {LX_GENERATABLE_DFA}.build_eof_rules */
void F1074_7163 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc3);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,701,162,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F702_3685(RTCW(tr1), NULL, arg2, arg3);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	loc2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_1_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = F1159_7653(RTCW(arg1), loc1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc3)+ _LNGOFF_2_2_0_0_);
		F702_3709(RTCW(tr1), loc3, ti4_1);
		loc1++;
	}
	RTLE;
}

/* {LX_GENERATABLE_DFA}.indentation */

EIF_REFERENCE F1074_7177 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (7177,RTMS_EX_H("\011\011\011",3,592137));
}

/* {LX_GENERATABLE_DFA}.integer_sorter */
static EIF_REFERENCE F1074_7178_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDD;
	RTLD;
	
	dftype = Dftype(Current);

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (7178);
#define Result RTOSR(7178)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,235,834,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		loc1 = RTLNS(typres0.id, 235, _OBJSIZ_0_0_0_0_0_0_0_0_);
	}
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,77,834,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNS(typres0.id, 77, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F75_947(RTCW(tr1), loc1);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (7178);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1074_7178 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(7178,F1074_7178_body,(Current));
}

/* {LX_GENERATABLE_DFA}.default_input_filename */

EIF_REFERENCE F1074_7179 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (7179,RTMS_EX_H("standard input",14,666902900));
}

void EIF_Minit333 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
