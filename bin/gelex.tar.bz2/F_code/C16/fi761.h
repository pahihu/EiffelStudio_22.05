
#ifndef _C16_fi761_
#define _C16_fi761_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F606_3219(EIF_REFERENCE);
extern void EIF_Minit761(void);
extern EIF_INTEGER_32 F707_3697(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
