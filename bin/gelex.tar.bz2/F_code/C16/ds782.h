
#ifndef _C16_ds782_
#define _C16_ds782_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1171_7888(EIF_REFERENCE);
extern EIF_INTEGER_32 F1171_7891(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit782(void);
extern void F1014_6747(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_TYPE_INDEX Y5580[];
extern EIF_TYPE_INDEX *Y5580_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
