/*
 * Code for class DS_SPARSE_SET [INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds785.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_SET}.make_equal */
void F1167_7828 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1164_7737(Current, arg1);
	tr1 = RTLNSMART(eif_final_id(Y5622,Y5622_gen_type,Dftype(Current),1100).id);
	F1_29(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_SPARSE_SET}.has */
EIF_BOOLEAN F1167_7833 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1164_7770(Current, arg1);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_) != ((EIF_INTEGER_32) -1L));
}

/* {DS_SPARSE_SET}.search */
void F1167_7837 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1164_7770(Current, arg1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_6_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_);
	RTLE;
}

/* {DS_SPARSE_SET}.is_equal */
EIF_BOOLEAN F1167_7838 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		tb2 = '\0';
		tr1 = RTOSCF(5994,F932_5994, (Current));
		tb3 = F16_120(RTCW(tr1), Current, arg1);
		if (tb3) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_7_0_0_8_);
			tb2 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) == ti4_1);
		}
		if (tb2) {
			tb1 = F1102_7298(Current, arg1);
		}
		if (tb1) {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !Result || (EIF_BOOLEAN) (loc2 < ((EIF_INTEGER_32) 0L)))) break;
				if ((EIF_BOOLEAN) (F1169_7864(Current, loc2) > ((EIF_INTEGER_32) -2L))) {
					loc1 = F1169_7863(Current, loc2);
					Result = F1167_7833(RTCW(arg1), loc1);
				}
				loc2--;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_SPARSE_SET}.force */
void F1167_7842 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1164_7756(Current);
	F1164_7770(Current, arg1);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_) != ((EIF_INTEGER_32) -1L))) {
		F1169_7867(Current, arg1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_));
	} else {
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_7_))) {
			ti4_1 = F1164_7826(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) + ((EIF_INTEGER_32) 1L)));
			F1164_7761(Current, ti4_1);
			loc2 = F1171_7891(Current, arg1);
		} else {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_4_);
		}
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_);
		if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_))++;
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
		} else {
			ti4_1 = F1169_7864(Current, loc1);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
		}
		ti4_1 = F1169_7880(Current, loc2);
		F1169_7874(Current, ti4_1, loc1);
		F1169_7881(Current, loc1, loc2);
		F1169_7867(Current, arg1, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_))++;
	}
	RTLE;
}

/* {DS_SPARSE_SET}.force_new */
void F1167_7843 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1164_7756(Current);
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_7_))) {
		ti4_1 = F1164_7826(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_) + ((EIF_INTEGER_32) 1L)));
		F1164_7761(Current, ti4_1);
	}
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_);
	if ((EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) -1L))) {
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_))++;
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
	} else {
		ti4_1 = F1169_7864(Current, loc1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) -3L) - ti4_1);
	}
	loc2 = F1171_7891(Current, arg1);
	ti4_1 = F1169_7880(Current, loc2);
	F1169_7874(Current, ti4_1, loc1);
	F1169_7881(Current, loc1, loc2);
	F1169_7867(Current, arg1, loc1);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_8_))++;
	RTLE;
}

/* {DS_SPARSE_SET}.key_storage_item */
EIF_INTEGER_32 F1167_7853 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F1169_7863(Current, arg1);
}

/* {DS_SPARSE_SET}.key_equality_tester */
EIF_REFERENCE F1167_7854 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current);
}

/* {DS_SPARSE_SET}.make_key_storage */
void F1167_7856 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
}

/* {DS_SPARSE_SET}.clone_key_storage */
void F1167_7858 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {DS_SPARSE_SET}.key_storage_resize */
void F1167_7859 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	RTGC;
}

/* {DS_SPARSE_SET}.key_storage_wipe_out */
void F1167_7860 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

void EIF_Minit785 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
