
#ifndef _C16_re767_
#define _C16_re767_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F631_3232(EIF_REFERENCE);
extern void EIF_Minit767(void);
extern EIF_INTEGER_32 F707_3698(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
