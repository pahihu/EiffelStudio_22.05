/*
 * Code for class DS_ARRAYED_SPARSE_SET [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds794.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_ARRAYED_SPARSE_SET}.item_storage_item */
EIF_REFERENCE F1168_7863 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(tr1))-676])(tr1, arg1);
	RTLE;
	return Result;
}

/* {DS_ARRAYED_SPARSE_SET}.clashes_item */
EIF_INTEGER_32 F1168_7864 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (arg1));
	/* END INLINED CODE */
	Result = ti4_2;
	RTLE;
	return Result;
}

/* {DS_ARRAYED_SPARSE_SET}.make_item_storage */
void F1168_7866 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(eif_final_id(Y5877,Y5877_gen_type,Dftype(Current),1167).id);
	F1_29(RTCW(tr1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_5_) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R271[Dtype(RTCW(tr1))-19])(tr1, arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_SET}.item_storage_put */
void F1168_7867 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,arg1);
	RTLR(4,tr3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr3 = RTCCL(arg1);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R276[Dtype(RTCW(tr1))-19])(tr1, tr2, tr3, arg2);
	RTLE;
}

/* {DS_ARRAYED_SPARSE_SET}.clone_item_storage */
void F1168_7868 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2639[Dtype(RTCW(tr2))-676])(tr2);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3108[Dtype(RTCW(tr1))-676])(tr1, ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_SET}.item_storage_resize */
void F1168_7869 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_5_);
	tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32)) R279[Dtype(RTCW(tr1))-19])(tr1, *(EIF_REFERENCE *)(Current + _REFACS_2_), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_SET}.item_storage_wipe_out */
void F1168_7870 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R3104[Dtype(RTCW(tr1))-676])(tr1, ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {DS_ARRAYED_SPARSE_SET}.make_clashes */
void F1168_7873 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,677,834,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSP2(typres0.id,0,arg1,sizeof(EIF_INTEGER_32), EIF_TRUE);
	}
	F678_3597(RTCW(tr1), ((EIF_INTEGER_32) -1L), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_SET}.clashes_put */
void F1168_7874 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_INTEGER_32 *)RTCW(tr1) + (arg2)) = arg1;
	/* END INLINED CODE */
	;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_SET}.clone_clashes */
void F1168_7875 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (tr2);
	tr1 = F678_3629(RTCW(tr1), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_SET}.clashes_resize */
void F1168_7876 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(2620,F268_2620, (Current));
	tr1 = F21_276(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_3_), ((EIF_INTEGER_32) -1L), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_SET}.clashes_wipe_out */
void F1168_7877 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + (loc1)) = ((EIF_INTEGER_32) -1L);
		/* END INLINED CODE */
		;
		loc1--;
	}
	RTLE;
}

/* {DS_ARRAYED_SPARSE_SET}.make_slots */
void F1168_7879 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,677,834,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNSP2(typres0.id,0,arg1,sizeof(EIF_INTEGER_32), EIF_TRUE);
	}
	F678_3597(RTCW(tr1), ((EIF_INTEGER_32) -1L), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_SET}.slots_item */
EIF_INTEGER_32 F1168_7880 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	/* INLINED CODE (SPECIAL.item) */
	ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr1) + (arg1));
	/* END INLINED CODE */
	Result = ti4_2;
	RTLE;
	return Result;
}

/* {DS_ARRAYED_SPARSE_SET}.slots_put */
void F1168_7881 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_INTEGER_32 *)RTCW(tr1) + (arg2)) = arg1;
	/* END INLINED CODE */
	;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_SET}.clone_slots */
void F1168_7882 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_capacity__i4 (tr2);
	tr1 = F678_3629(RTCW(tr1), ti4_1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_SET}.slots_resize */
void F1168_7883 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(2620,F268_2620, (Current));
	tr1 = F21_276(RTCW(tr1), *(EIF_REFERENCE *)(Current + _REFACS_4_), ((EIF_INTEGER_32) -1L), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_4_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {DS_ARRAYED_SPARSE_SET}.slots_wipe_out */
void F1168_7884 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_1_);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + (loc1)) = ((EIF_INTEGER_32) -1L);
		/* END INLINED CODE */
		;
		loc1--;
	}
	RTLE;
}

/* {DS_ARRAYED_SPARSE_SET}.correct_mismatch */
void F1168_7886 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(3863,F772_3863, (Current))) + _REFACS_7_);
	loc2 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc2))) {
		tb2 = F914_5820(loc2);
		tb1 = tb2;
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5878[dtype-1169])(Current);
	} else {
		tb1 = F907_5485(loc2);
		if (tb1) {
			loc1 = F907_5519(loc2);
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 20130823L))) {
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R5878[dtype-1169])(Current);
			} else {
				F772_3862(Current);
			}
		} else {
			F772_3862(Current);
		}
	}
	RTLE;
}

/* {DS_ARRAYED_SPARSE_SET}.correct_mismatch_20130823 */
void F1168_7887 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32)) R3101[Dtype(RTCW(tr1))-676])(tr1, ((EIF_INTEGER_32) 1L), ((EIF_INTEGER_32) 0L), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_));
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_INTEGER_32)) R3104[Dtype(RTCW(tr1))-676])(tr1, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_));
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		/* INLINED CODE (SPECIAL.item) */
		ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr2) + (loc1));
		/* END INLINED CODE */
		ti4_1 = ti4_2;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L)))) = (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L));
		/* END INLINED CODE */
		;
		loc1++;
	}
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	tr2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	ti4_1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr2);
	/* INLINED CODE (SPECIAL.put) */
	*((EIF_INTEGER_32 *)RTCW(tr1) + ((EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)))) = ((EIF_INTEGER_32) -1L);
	/* END INLINED CODE */
	;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
	loc1 = (EIF_INTEGER_32) eif_builtin_SPECIAL_count__i4 (tr1);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 0L))) break;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		tr2 = *(EIF_REFERENCE *)(Current + _REFACS_4_);
		/* INLINED CODE (SPECIAL.item) */
		ti4_2 = *((EIF_INTEGER_32 *)RTCW(tr2) + (loc1));
		/* END INLINED CODE */
		ti4_1 = ti4_2;
		/* INLINED CODE (SPECIAL.put) */
		*((EIF_INTEGER_32 *)RTCW(tr1) + (loc1)) = (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L));
		/* END INLINED CODE */
		;
		loc1--;
	}
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_5_))--;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_6_))--;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_2_))--;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_3_))--;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_0_))--;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R2639[Dtype(RTCW(tr1))-676])(tr1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_7_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

void EIF_Minit794 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
