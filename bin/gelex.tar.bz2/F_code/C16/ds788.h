
#ifndef _C16_ds788_
#define _C16_ds788_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1164_7737(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1164_7738(EIF_REFERENCE);
extern EIF_INTEGER_32 F1164_7739(EIF_REFERENCE);
extern EIF_INTEGER_32 F1164_7742(EIF_REFERENCE);
extern EIF_INTEGER_32 F1164_7743(EIF_REFERENCE);
extern EIF_BOOLEAN F1164_7746(EIF_REFERENCE);
extern void F1164_7756(EIF_REFERENCE);
extern void F1164_7757(EIF_REFERENCE, EIF_REFERENCE);
extern void F1164_7760(EIF_REFERENCE);
extern void F1164_7761(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1164_7770(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1164_7771(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1164_7807(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1164_7808(EIF_REFERENCE);
extern void F1164_7809(EIF_REFERENCE);
extern EIF_INTEGER_32 F1164_7813(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1164_7814(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1164_7815(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1164_7816(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1164_7817(EIF_REFERENCE, EIF_REFERENCE);
extern void F1164_7819(EIF_REFERENCE, EIF_REFERENCE);
extern void F1164_7821(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F1164_7823(EIF_REFERENCE, EIF_REFERENCE);
extern void F1164_7825(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1164_7826(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1164_7827(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit788(void);
extern EIF_BOOLEAN F1096_7285(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1082_7250(EIF_REFERENCE);
extern void F1014_6754(EIF_REFERENCE);
extern EIF_BOOLEAN F1108_7322(EIF_REFERENCE, EIF_REFERENCE);
extern void F1096_7293(EIF_REFERENCE, EIF_REFERENCE);
extern void F1014_6753(EIF_REFERENCE, EIF_INTEGER_32);
extern void F976_6710(EIF_REFERENCE, EIF_REFERENCE);
extern void F1096_7294(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1096_7290(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R5831[])();
extern char *(*R5833[])();
extern char *(*R5834[])();
extern char *(*R5835[])();
extern char *(*R5836[])();
extern char *(*R1979[])();
extern char *(*R5838[])();
extern char *(*R5603[])();
extern char *(*R5840[])();
extern char *(*R5841[])();
extern char *(*R5842[])();
extern char *(*R5844[])();
extern char *(*R5845[])();
extern char *(*R5846[])();
extern char *(*R5847[])();
extern char *(*R5848[])();
extern char *(*R5849[])();
extern char *(*R5850[])();
extern char *(*R5851[])();
extern char *(*R5852[])();
extern char *(*R5853[])();
extern char *(*R5854[])();
extern char *(*R5821[])();
extern char *(*R5823[])();
extern char *(*R5824[])();
extern char *(*R5829[])();
extern long O5860[];
extern long O5820[];
extern long O5870[];
extern long O5871[];
extern long O5855[];
extern long O5856[];
extern long O5857[];
extern long O5858[];
extern long O5859[];

#ifdef __cplusplus
}
#endif

#endif
