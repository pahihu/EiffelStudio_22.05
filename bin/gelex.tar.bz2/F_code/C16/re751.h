
#ifndef _C16_re751_
#define _C16_re751_

#ifdef __cplusplus
extern "C" {
#endif

extern void F394_3034(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F394_3036(EIF_REFERENCE);
extern EIF_INTEGER_32 F394_3037(EIF_REFERENCE);
extern EIF_INTEGER_32 F394_3038(EIF_REFERENCE);
extern EIF_INTEGER_32 F394_3039(EIF_REFERENCE);
extern EIF_BOOLEAN F394_3047(EIF_REFERENCE);
extern EIF_BOOLEAN F394_3048(EIF_REFERENCE);
extern void F394_3053(EIF_REFERENCE);
extern void EIF_Minit751(void);
extern char *(*R3078[])();
extern char *(*R3079[])();

#ifdef __cplusplus
}
#endif

#endif
