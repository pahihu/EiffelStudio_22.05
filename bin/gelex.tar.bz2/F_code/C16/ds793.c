/*
 * Code for class DS_HASH_SET [G#1]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds793.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_HASH_SET}.new_cursor */
EIF_REFERENCE F1170_7888 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1019,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y5580,Y5580_gen_type,Dftype(Current),1080);
			typarr0[2] = l_type.annotations | 0xFF00;
			typarr0[3] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 1019, _OBJSIZ_2_0_0_1_0_0_0_0_);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R5216[Dtype(RTCW(tr1))-1019])(tr1, Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {DS_HASH_SET}.hash_position */
EIF_INTEGER_32 F1170_7891 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,loc1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_6_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = RTCCL(arg1);
			Result = (RTNA((loc1, tr1)), ((EIF_INTEGER_32) 0));
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_1_);
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ti4_1);
		} else {
			Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R3362[Dtype(RTCW(arg1))-795])(arg1);
			ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_1_);
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result % ti4_1);
		}
	} else {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_7_0_0_1_);
		RTLE;
		return (EIF_INTEGER_32) Result;
	}
	RTLE;
	return Result;
}

void EIF_Minit793 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
