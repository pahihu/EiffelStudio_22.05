
#ifndef _C16_ds792_
#define _C16_ds792_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1021_6766(EIF_REFERENCE);
extern void EIF_Minit792(void);

#ifdef __cplusplus
}
#endif

#endif
