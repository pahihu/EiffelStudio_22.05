
#ifndef _C16_co760_
#define _C16_co760_

#ifdef __cplusplus
extern "C" {
#endif

extern void F463_3121(EIF_REFERENCE);
extern void EIF_Minit760(void);
extern long O2805[];

#ifdef __cplusplus
}
#endif

#endif
