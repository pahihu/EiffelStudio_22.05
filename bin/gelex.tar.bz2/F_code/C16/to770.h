
#ifndef _C16_to770_
#define _C16_to770_

#ifdef __cplusplus
extern "C" {
#endif

extern void F253_2420(EIF_REFERENCE, EIF_INTEGER_32);
extern void F253_2421(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern void F253_2427(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit770(void);
extern void F682_3597(EIF_REFERENCE, EIF_NATURAL_64, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2242[];
extern EIF_TYPE_INDEX *Y2242_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
