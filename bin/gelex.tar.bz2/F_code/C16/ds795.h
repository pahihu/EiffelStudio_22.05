
#ifndef _C16_ds795_
#define _C16_ds795_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1166_7828(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F1166_7833(EIF_REFERENCE, EIF_REFERENCE);
extern void F1166_7837(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1166_7838(EIF_REFERENCE, EIF_REFERENCE);
extern void F1166_7842(EIF_REFERENCE, EIF_REFERENCE);
extern void F1166_7843(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1166_7853(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1166_7854(EIF_REFERENCE);
extern void F1166_7856(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1166_7858(EIF_REFERENCE);
extern void F1166_7859(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1166_7860(EIF_REFERENCE);
extern void EIF_Minit795(void);
extern EIF_REFERENCE F932_5994(EIF_REFERENCE);
extern void F1_29(EIF_REFERENCE);
extern EIF_BOOLEAN F16_120(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,5994)
extern char *(*R5831[])();
extern char *(*R5778[])();
extern char *(*R5845[])();
extern char *(*R5616[])();
extern char *(*R5777[])();
extern char *(*R5619[])();
extern char *(*R5812[])();
extern char *(*R5850[])();
extern char *(*R5816[])();
extern char *(*R5851[])();
extern char *(*R5821[])();
extern char *(*R5822[])();
extern char *(*R5824[])();
extern char *(*R5827[])();
extern EIF_TYPE_INDEX Y5622[];
extern EIF_TYPE_INDEX *Y5622_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
