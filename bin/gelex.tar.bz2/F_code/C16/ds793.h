
#ifndef _C16_ds793_
#define _C16_ds793_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1170_7888(EIF_REFERENCE);
extern EIF_INTEGER_32 F1170_7891(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit793(void);
extern char *(*R5216[])();
extern char *(*R3362[])();
extern EIF_TYPE_INDEX Y5580[];
extern EIF_TYPE_INDEX *Y5580_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
