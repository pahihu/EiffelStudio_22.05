#include "epoly2.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2241[985])();
void R2241_init () {
	R2241[0] = (char *(*)()) F255_2421_2241_133;
	R2241[438] = (char *(*)()) F248_2421;
	R2241[439] = (char *(*)()) F249_2421_2241_133;
	R2241[440] = (char *(*)()) F250_2421_2241_133;
	R2241[441] = (char *(*)()) F251_2421_2241_133;
	R2241[442] = (char *(*)()) F252_2421_2241_133;
	R2241[443] = (char *(*)()) F253_2421_2241_133;
	R2241[444] = (char *(*)()) F254_2421_2241_133;
	R2241[445] = (char *(*)()) F255_2421_2241_133;
	R2241[446] = (char *(*)()) F256_2421_2241_133;
	R2241[447] = (char *(*)()) F257_2421_2241_133;
	R2241[448] = (char *(*)()) F258_2421_2241_133;
	R2241[449] = (char *(*)()) F259_2421_2241_133;
	R2241[450] = (char *(*)()) F248_2421;
	R2241[451] = (char *(*)()) F249_2421_2241_133;
	R2241[452] = (char *(*)()) F254_2421_2241_133;
	R2241[453] = (char *(*)()) F251_2421_2241_133;
	R2241[454] = (char *(*)()) F259_2421_2241_133;
	R2241[455] = (char *(*)()) F253_2421_2241_133;
	R2241[648] = (char *(*)()) F252_2421_2241_133;
	R2241[651] = (char *(*)()) F254_2421_2241_133;
	R2241[984] = (char *(*)()) F254_2421_2241_133;
}
static void F255_2421_2241_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F255_2421(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F249_2421_2241_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F249_2421(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F250_2421_2241_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F250_2421(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F251_2421_2241_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F251_2421(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F252_2421_2241_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F252_2421(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F253_2421_2241_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F253_2421(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F254_2421_2241_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F254_2421(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F256_2421_2241_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F256_2421(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F257_2421_2241_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F257_2421(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F258_2421_2241_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F258_2421(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F259_2421_2241_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F259_2421(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}

char *(*R2247[985])();
void R2247_init () {
	R2247[0] = (char *(*)()) F255_2427;
	R2247[438] = (char *(*)()) F248_2427;
	R2247[439] = (char *(*)()) F249_2427;
	R2247[440] = (char *(*)()) F250_2427;
	R2247[441] = (char *(*)()) F251_2427;
	R2247[442] = (char *(*)()) F252_2427;
	R2247[443] = (char *(*)()) F253_2427;
	R2247[444] = (char *(*)()) F254_2427;
	R2247[445] = (char *(*)()) F255_2427;
	R2247[446] = (char *(*)()) F256_2427;
	R2247[447] = (char *(*)()) F257_2427;
	R2247[448] = (char *(*)()) F258_2427;
	R2247[449] = (char *(*)()) F259_2427;
	R2247[450] = (char *(*)()) F248_2427;
	R2247[451] = (char *(*)()) F249_2427;
	R2247[452] = (char *(*)()) F254_2427;
	R2247[453] = (char *(*)()) F251_2427;
	R2247[454] = (char *(*)()) F259_2427;
	R2247[455] = (char *(*)()) F253_2427;
	R2247[648] = (char *(*)()) F252_2427;
	R2247[651] = (char *(*)()) F254_2427;
	R2247[984] = (char *(*)()) F254_2427;
}

char *(*R2514[103])();
void R2514_init () {
	R2514[0] = (char *(*)()) F954_6245;
	R2514[97] = (char *(*)()) F662_3280;
	R2514[102] = (char *(*)()) F662_3280;
}

char *(*R2527[103])();
void R2527_init () {
	R2527[0] = (char *(*)()) F954_6268;
	R2527[97] = (char *(*)()) F662_3354;
	R2527[102] = (char *(*)()) F662_3354;
}

char *(*R2529[103])();
void R2529_init () {
	R2529[0] = (char *(*)()) F954_6266;
	R2529[97] = (char *(*)()) F662_3357;
	R2529[102] = (char *(*)()) F662_3357;
}

char *(*R2557[103])();
void R2557_init () {
	R2557[0] = (char *(*)()) F954_6263;
	R2557[97] = (char *(*)()) F662_3387;
	R2557[102] = (char *(*)()) F662_3387;
}

char *(*R2570[103])();
void R2570_init () {
	R2570[0] = (char *(*)()) F954_6257;
	R2570[97] = (char *(*)()) F662_3394;
	R2570[102] = (char *(*)()) F662_3394;
}

char *(*R2638[12])();
void R2638_init () {
	R2638[0] = (char *(*)()) F677_3609;
	R2638[1] = (char *(*)()) F678_3609;
	R2638[2] = (char *(*)()) F679_3609;
	R2638[3] = (char *(*)()) F680_3609;
	R2638[4] = (char *(*)()) F681_3609;
	R2638[5] = (char *(*)()) F682_3609;
	R2638[6] = (char *(*)()) F683_3609;
	R2638[7] = (char *(*)()) F684_3609;
	R2638[8] = (char *(*)()) F685_3609;
	R2638[9] = (char *(*)()) F686_3609;
	R2638[10] = (char *(*)()) F687_3609;
	R2638[11] = (char *(*)()) F688_3609;
}

char *(*R2639[12])();
void R2639_init () {
	R2639[0] = (char *(*)()) F677_3610;
	R2639[1] = (char *(*)()) F678_3610;
	R2639[2] = (char *(*)()) F679_3610;
	R2639[3] = (char *(*)()) F680_3610;
	R2639[4] = (char *(*)()) F681_3610;
	R2639[5] = (char *(*)()) F682_3610;
	R2639[6] = (char *(*)()) F683_3610;
	R2639[7] = (char *(*)()) F684_3610;
	R2639[8] = (char *(*)()) F685_3610;
	R2639[9] = (char *(*)()) F686_3610;
	R2639[10] = (char *(*)()) F687_3610;
	R2639[11] = (char *(*)()) F688_3610;
}

char *(*R2688[643])();
void R2688_init () {
	R2688[0] = (char *(*)()) F402_3062;
	R2688[1] = (char *(*)()) F403_3062_2688_1;
	R2688[2] = (char *(*)()) F404_3062;
	R2688[3] = (char *(*)()) F405_3062_2688_1;
	R2688[4] = (char *(*)()) F406_3062_2688_1;
	R2688[618] = (char *(*)()) F975_6701;
	R2688[619] = (char *(*)()) F976_6701_2688_1;
	{long i; for (i = 628; i < 630; i++) R2688[i] = (char *(*)()) F975_6701;}
	R2688[630] = (char *(*)()) F976_6701_2688_1;
	R2688[631] = (char *(*)()) F979_6701_2688_1;
	R2688[636] = (char *(*)()) F975_6701;
	R2688[637] = (char *(*)()) F976_6701_2688_1;
	R2688[638] = (char *(*)()) F1040_6809;
	R2688[639] = (char *(*)()) F1041_6809_2688_1;
	R2688[640] = (char *(*)()) F1042_6809_2688_1;
	R2688[641] = (char *(*)()) F1043_6809_2688_1;
	R2688[642] = (char *(*)()) F1040_6809;
}
static EIF_REFERENCE F403_3062_2688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F403_3062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F405_3062_2688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F405_3062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F406_3062_2688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F406_3062(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F976_6701_2688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F976_6701(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F979_6701_2688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F979_6701(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(843, 0x00).id, 843, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1041_6809_2688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1041_6809(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1042_6809_2688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1042_6809(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(867, 0x00).id, 867, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1043_6809_2688_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1043_6809(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R2689[643])();
void R2689_init () {
	R2689[0] = (char *(*)()) F402_3065;
	R2689[1] = (char *(*)()) F403_3065;
	R2689[2] = (char *(*)()) F404_3065;
	R2689[3] = (char *(*)()) F405_3065;
	R2689[4] = (char *(*)()) F406_3065;
	R2689[197] = (char *(*)()) F598_3191;
	R2689[618] = (char *(*)()) F1012_6749;
	R2689[619] = (char *(*)()) F1014_6749;
	R2689[628] = (char *(*)()) F1012_6749;
	R2689[629] = (char *(*)()) F1013_6749;
	R2689[630] = (char *(*)()) F1014_6749;
	R2689[631] = (char *(*)()) F1015_6749;
	R2689[636] = (char *(*)()) F1038_6796;
	R2689[637] = (char *(*)()) F1039_6796;
	R2689[638] = (char *(*)()) F1040_6811;
	R2689[639] = (char *(*)()) F1041_6811;
	R2689[640] = (char *(*)()) F1042_6811;
	R2689[641] = (char *(*)()) F1043_6811;
	R2689[642] = (char *(*)()) F1040_6811;
}

char *(*R2690[643])();
void R2690_init () {
	R2690[0] = (char *(*)()) F402_3066;
	R2690[1] = (char *(*)()) F403_3066;
	R2690[2] = (char *(*)()) F404_3066;
	R2690[3] = (char *(*)()) F405_3066;
	R2690[4] = (char *(*)()) F406_3066;
	R2690[197] = (char *(*)()) F598_3197;
	R2690[618] = (char *(*)()) F990_6722;
	R2690[619] = (char *(*)()) F991_6722;
	{long i; for (i = 628; i < 630; i++) R2690[i] = (char *(*)()) F990_6722;}
	R2690[630] = (char *(*)()) F991_6722;
	R2690[631] = (char *(*)()) F994_6722;
	R2690[636] = (char *(*)()) F990_6722;
	R2690[637] = (char *(*)()) F991_6722;
	R2690[638] = (char *(*)()) F990_6722;
	R2690[639] = (char *(*)()) F992_6722;
	R2690[640] = (char *(*)()) F993_6722;
	R2690[641] = (char *(*)()) F991_6722;
	R2690[642] = (char *(*)()) F990_6722;
}

char *(*R2701[5])();
void R2701_init () {
	R2701[0] = (char *(*)()) F402_3063;
	R2701[1] = (char *(*)()) F403_3063;
	R2701[2] = (char *(*)()) F404_3063_2701_1;
	R2701[3] = (char *(*)()) F405_3063;
	R2701[4] = (char *(*)()) F406_3063_2701_1;
}
static EIF_REFERENCE F404_3063_2701_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F404_3063(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F406_3063_2701_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F406_3063(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R2703[398])();
void R2703_init () {
	R2703[0] = (char *(*)()) F786_3977;
	R2703[1] = (char *(*)()) F787_3977;
	R2703[2] = (char *(*)()) F788_3977;
	R2703[3] = (char *(*)()) F789_3977;
	R2703[4] = (char *(*)()) F790_3977;
	R2703[7] = (char *(*)()) F786_3977;
	R2703[359] = (char *(*)()) F1107_7305;
	R2703[360] = (char *(*)()) F1109_7305;
	R2703[361] = (char *(*)()) F1110_7305;
	R2703[362] = (char *(*)()) F1108_7305;
	{long i; for (i = 363; i < 365; i++) R2703[i] = (char *(*)()) F1107_7305;}
	R2703[366] = (char *(*)()) F1107_7305;
	R2703[373] = (char *(*)()) F1107_7305;
	R2703[374] = (char *(*)()) F1108_7305;
	R2703[375] = (char *(*)()) F1107_7305;
	R2703[384] = (char *(*)()) F1107_7305;
	R2703[385] = (char *(*)()) F1108_7305;
	{long i; for (i = 394; i < 396; i++) R2703[i] = (char *(*)()) F1107_7305;}
	R2703[396] = (char *(*)()) F1108_7305;
	R2703[397] = (char *(*)()) F1111_7305;
}

static EIF_TYPE_INDEX Y2704_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype12[] = {0xFF01,910,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype13[] = {861,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype14[] = {0xFF01,914,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype15[] = {0xFF01,914,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype68[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype69[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype71[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype80[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype88[] = {861,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype89[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype102[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype103[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype104[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype105[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype106[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype107[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype108[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype109[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype110[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype111[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype112[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype113[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype114[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype115[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype116[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype117[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype118[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype119[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype120[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype121[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype122[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype123[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype124[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype125[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype126[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype127[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype128[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype129[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype130[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype131[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype132[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype133[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype134[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype135[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype136[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype137[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype138[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype139[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype140[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype141[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype142[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype143[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype144[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype145[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype146[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype147[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype148[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype149[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype150[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype151[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype152[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype153[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype154[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype155[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype156[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype157[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype158[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype159[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype160[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype161[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype162[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype163[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype164[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype165[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype166[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype167[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype168[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype169[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype170[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype171[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype172[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype173[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype174[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype175[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype176[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype177[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype178[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype179[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype180[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype181[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype182[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype183[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype184[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype185[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype186[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype187[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype188[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype189[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype190[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype191[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype192[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype193[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype194[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype195[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype196[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype197[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype198[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype199[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype200[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype201[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype202[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype203[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype204[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype205[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype206[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype207[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype208[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype209[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype210[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype211[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype212[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype213[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype214[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype215[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype216[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype217[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype218[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype219[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype220[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype221[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype222[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype223[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype224[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype225[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype226[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype227[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype228[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype229[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype230[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype231[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype232[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype233[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype234[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype235[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype236[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype237[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype238[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype239[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype240[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype241[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype242[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype243[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype244[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype245[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype246[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype247[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype248[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype249[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype250[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype251[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype252[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype253[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype254[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype255[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype256[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype257[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype258[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype259[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype260[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype261[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype262[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype263[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype264[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype265[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype266[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype267[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype268[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype269[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype270[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype271[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype272[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype273[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype274[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype275[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype276[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype277[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype278[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype279[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype280[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype281[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype282[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype283[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype284[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype285[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype286[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype287[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype288[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype289[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype290[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype291[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype292[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype293[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype294[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype295[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype296[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype297[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype298[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype299[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype300[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype301[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype302[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype303[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype304[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype305[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype306[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype307[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype308[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype309[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype310[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype311[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype312[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype313[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype314[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype315[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype316[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype317[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype318[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype319[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype320[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype321[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype322[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype323[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype324[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype325[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype326[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype327[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype328[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype329[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype330[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype331[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype332[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype333[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype334[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype335[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype336[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype337[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype338[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype339[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype340[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype341[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype342[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype343[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype344[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype345[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype346[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype347[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype348[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype349[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype350[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype351[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype352[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype353[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype354[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype355[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype356[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype357[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype358[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype359[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype360[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype361[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype362[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype363[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype364[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype365[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype366[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype367[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype368[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype369[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype370[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype371[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype372[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype373[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype374[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype375[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype376[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype377[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype378[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype379[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype380[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype381[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype382[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype383[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype384[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype385[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype386[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype387[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype388[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype389[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype390[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype391[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype392[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype393[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype394[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype395[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype396[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype397[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype398[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype399[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype400[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype401[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype402[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype403[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype404[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype405[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype406[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype407[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype408[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype409[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype410[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype411[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype412[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype413[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype414[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype415[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype416[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype417[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype418[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype419[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype420[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype421[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype422[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype423[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype424[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype425[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype426[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype427[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype428[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype429[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype430[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype431[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype432[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype433[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype434[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype435[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype436[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype437[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype438[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype439[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype440[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype441[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype442[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype443[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype444[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype445[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype446[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype447[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype448[] = {0,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype449[] = {861,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype450[] = {861,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype451[] = {861,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype452[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype453[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype454[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype455[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype456[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype457[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype458[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype459[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype460[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype461[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype462[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype463[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype464[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype465[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype466[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype467[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype468[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype469[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype470[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype471[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype472[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype473[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype474[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype475[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype476[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype477[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype478[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype479[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype480[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype481[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype482[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype483[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype484[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype485[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype486[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype487[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype488[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype489[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype490[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype491[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype492[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype493[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype494[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype495[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype496[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype497[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype498[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype499[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype500[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype501[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype502[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype503[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype504[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype505[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype506[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype507[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype508[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype509[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype510[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype511[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype512[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype513[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype514[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype515[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype516[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype517[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype518[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype519[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype520[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype521[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype522[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype523[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype524[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype525[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype526[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype527[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype528[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype529[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype530[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype531[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype532[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype533[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype534[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype535[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype536[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype537[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype538[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype539[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype540[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype541[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype542[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype543[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype544[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype545[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype546[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype547[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype548[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype549[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype550[] = {0xFF01,1066,0xFF01,1069,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype551[] = {0xFF01,115,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype552[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype553[] = {0xFF01,47,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype554[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype555[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype556[] = {0xFF01,44,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype557[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype558[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype559[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype560[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype561[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype562[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype563[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype564[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype565[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype566[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype567[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype568[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype569[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype570[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype571[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype572[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype573[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype574[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype575[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype576[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype577[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype578[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype579[] = {864,0xFFFF};
static EIF_TYPE_INDEX Y2704_pgtype580[] = {864,0xFFFF};
EIF_TYPE_INDEX *Y2704_gen_type [907];
EIF_TYPE_INDEX Y2704 [907];
void Y2704_init (void)
{
	egc_routines_types [2704] = Y2704;
	egc_routines_gen_types [2704] = Y2704_gen_type;
	egc_routines_offset [2704] = 342;
	Y2704_gen_type [0] = Y2704_pgtype0;
	Y2704_gen_type [1] = Y2704_pgtype1;
	Y2704_gen_type [2] = Y2704_pgtype2;
	Y2704_gen_type [3] = Y2704_pgtype3;
	Y2704_gen_type [4] = Y2704_pgtype4;
	Y2704_gen_type [5] = Y2704_pgtype5;
	Y2704_gen_type [6] = Y2704_pgtype6;
	Y2704_gen_type [7] = Y2704_pgtype7;
	Y2704_gen_type [8] = Y2704_pgtype8;
	Y2704_gen_type [9] = Y2704_pgtype9;
	Y2704_gen_type [10] = Y2704_pgtype10;
	Y2704_gen_type [11] = Y2704_pgtype11;
	Y2704_gen_type [12] = Y2704_pgtype12;
	Y2704_gen_type [13] = Y2704_pgtype13;
	Y2704_gen_type [14] = Y2704_pgtype14;
	Y2704_gen_type [15] = Y2704_pgtype15;
	Y2704_gen_type [16] = Y2704_pgtype16;
	Y2704_gen_type [17] = Y2704_pgtype17;
	Y2704_gen_type [18] = Y2704_pgtype18;
	Y2704_gen_type [19] = Y2704_pgtype19;
	Y2704_gen_type [20] = Y2704_pgtype20;
	Y2704_gen_type [21] = Y2704_pgtype21;
	Y2704_gen_type [22] = Y2704_pgtype22;
	Y2704_gen_type [23] = Y2704_pgtype23;
	Y2704_gen_type [24] = Y2704_pgtype24;
	Y2704_gen_type [25] = Y2704_pgtype25;
	Y2704_gen_type [26] = Y2704_pgtype26;
	Y2704_gen_type [27] = Y2704_pgtype27;
	Y2704_gen_type [28] = Y2704_pgtype28;
	Y2704_gen_type [29] = Y2704_pgtype29;
	Y2704_gen_type [30] = Y2704_pgtype30;
	Y2704_gen_type [31] = Y2704_pgtype31;
	Y2704_gen_type [32] = Y2704_pgtype32;
	Y2704_gen_type [33] = Y2704_pgtype33;
	Y2704_gen_type [34] = Y2704_pgtype34;
	Y2704_gen_type [35] = Y2704_pgtype35;
	Y2704_gen_type [36] = Y2704_pgtype36;
	Y2704_gen_type [37] = Y2704_pgtype37;
	Y2704_gen_type [38] = Y2704_pgtype38;
	Y2704_gen_type [39] = Y2704_pgtype39;
	Y2704_gen_type [40] = Y2704_pgtype40;
	Y2704_gen_type [41] = Y2704_pgtype41;
	Y2704_gen_type [42] = Y2704_pgtype42;
	Y2704_gen_type [43] = Y2704_pgtype43;
	Y2704_gen_type [44] = Y2704_pgtype44;
	Y2704_gen_type [45] = Y2704_pgtype45;
	Y2704_gen_type [46] = Y2704_pgtype46;
	Y2704_gen_type [47] = Y2704_pgtype47;
	Y2704_gen_type [48] = Y2704_pgtype48;
	Y2704_gen_type [49] = Y2704_pgtype49;
	Y2704_gen_type [50] = Y2704_pgtype50;
	Y2704_gen_type [51] = Y2704_pgtype51;
	Y2704_gen_type [52] = Y2704_pgtype52;
	Y2704_gen_type [53] = Y2704_pgtype53;
	Y2704_gen_type [54] = Y2704_pgtype54;
	Y2704_gen_type [55] = Y2704_pgtype55;
	Y2704_gen_type [56] = Y2704_pgtype56;
	Y2704_gen_type [57] = Y2704_pgtype57;
	Y2704_gen_type [58] = Y2704_pgtype58;
	Y2704_gen_type [59] = Y2704_pgtype59;
	Y2704_gen_type [60] = Y2704_pgtype60;
	Y2704_gen_type [61] = Y2704_pgtype61;
	Y2704_gen_type [62] = Y2704_pgtype62;
	Y2704_gen_type [63] = Y2704_pgtype63;
	Y2704_gen_type [64] = Y2704_pgtype64;
	Y2704_gen_type [65] = Y2704_pgtype65;
	Y2704_gen_type [66] = Y2704_pgtype66;
	Y2704_gen_type [67] = Y2704_pgtype67;
	Y2704_gen_type [68] = Y2704_pgtype68;
	Y2704_gen_type [69] = Y2704_pgtype69;
	Y2704_gen_type [70] = Y2704_pgtype70;
	Y2704_gen_type [71] = Y2704_pgtype71;
	Y2704_gen_type [72] = Y2704_pgtype72;
	Y2704_gen_type [73] = Y2704_pgtype73;
	Y2704_gen_type [74] = Y2704_pgtype74;
	Y2704_gen_type [75] = Y2704_pgtype75;
	Y2704_gen_type [76] = Y2704_pgtype76;
	Y2704_gen_type [77] = Y2704_pgtype77;
	Y2704_gen_type [78] = Y2704_pgtype78;
	Y2704_gen_type [79] = Y2704_pgtype79;
	Y2704_gen_type [80] = Y2704_pgtype80;
	Y2704_gen_type [81] = Y2704_pgtype81;
	Y2704_gen_type [82] = Y2704_pgtype82;
	Y2704_gen_type [83] = Y2704_pgtype83;
	Y2704_gen_type [84] = Y2704_pgtype84;
	Y2704_gen_type [85] = Y2704_pgtype85;
	Y2704_gen_type [86] = Y2704_pgtype86;
	Y2704_gen_type [87] = Y2704_pgtype87;
	Y2704_gen_type [88] = Y2704_pgtype88;
	Y2704_gen_type [89] = Y2704_pgtype89;
	Y2704_gen_type [90] = Y2704_pgtype90;
	Y2704_gen_type [91] = Y2704_pgtype91;
	Y2704_gen_type [92] = Y2704_pgtype92;
	Y2704_gen_type [93] = Y2704_pgtype93;
	Y2704_gen_type [94] = Y2704_pgtype94;
	Y2704_gen_type [95] = Y2704_pgtype95;
	Y2704_gen_type [96] = Y2704_pgtype96;
	Y2704_gen_type [97] = Y2704_pgtype97;
	Y2704_gen_type [98] = Y2704_pgtype98;
	Y2704_gen_type [99] = Y2704_pgtype99;
	Y2704_gen_type [100] = Y2704_pgtype100;
	Y2704_gen_type [101] = Y2704_pgtype101;
	Y2704_gen_type [102] = Y2704_pgtype102;
	Y2704_gen_type [103] = Y2704_pgtype103;
	Y2704_gen_type [104] = Y2704_pgtype104;
	Y2704_gen_type [105] = Y2704_pgtype105;
	Y2704_gen_type [106] = Y2704_pgtype106;
	Y2704_gen_type [107] = Y2704_pgtype107;
	Y2704_gen_type [108] = Y2704_pgtype108;
	Y2704_gen_type [109] = Y2704_pgtype109;
	Y2704_gen_type [110] = Y2704_pgtype110;
	Y2704_gen_type [111] = Y2704_pgtype111;
	Y2704_gen_type [112] = Y2704_pgtype112;
	Y2704_gen_type [113] = Y2704_pgtype113;
	Y2704_gen_type [114] = Y2704_pgtype114;
	Y2704_gen_type [115] = Y2704_pgtype115;
	Y2704_gen_type [116] = Y2704_pgtype116;
	Y2704_gen_type [117] = Y2704_pgtype117;
	Y2704_gen_type [118] = Y2704_pgtype118;
	Y2704_gen_type [119] = Y2704_pgtype119;
	Y2704_gen_type [120] = Y2704_pgtype120;
	Y2704_gen_type [121] = Y2704_pgtype121;
	Y2704_gen_type [122] = Y2704_pgtype122;
	Y2704_gen_type [123] = Y2704_pgtype123;
	Y2704_gen_type [124] = Y2704_pgtype124;
	Y2704_gen_type [125] = Y2704_pgtype125;
	Y2704_gen_type [126] = Y2704_pgtype126;
	Y2704_gen_type [127] = Y2704_pgtype127;
	Y2704_gen_type [128] = Y2704_pgtype128;
	Y2704_gen_type [129] = Y2704_pgtype129;
	Y2704_gen_type [130] = Y2704_pgtype130;
	Y2704_gen_type [131] = Y2704_pgtype131;
	Y2704_gen_type [132] = Y2704_pgtype132;
	Y2704_gen_type [133] = Y2704_pgtype133;
	Y2704_gen_type [134] = Y2704_pgtype134;
	Y2704_gen_type [135] = Y2704_pgtype135;
	Y2704_gen_type [136] = Y2704_pgtype136;
	Y2704_gen_type [137] = Y2704_pgtype137;
	Y2704_gen_type [138] = Y2704_pgtype138;
	Y2704_gen_type [139] = Y2704_pgtype139;
	Y2704_gen_type [140] = Y2704_pgtype140;
	Y2704_gen_type [141] = Y2704_pgtype141;
	Y2704_gen_type [142] = Y2704_pgtype142;
	Y2704_gen_type [143] = Y2704_pgtype143;
	Y2704_gen_type [144] = Y2704_pgtype144;
	Y2704_gen_type [145] = Y2704_pgtype145;
	Y2704_gen_type [146] = Y2704_pgtype146;
	Y2704_gen_type [147] = Y2704_pgtype147;
	Y2704_gen_type [148] = Y2704_pgtype148;
	Y2704_gen_type [149] = Y2704_pgtype149;
	Y2704_gen_type [150] = Y2704_pgtype150;
	Y2704_gen_type [151] = Y2704_pgtype151;
	Y2704_gen_type [152] = Y2704_pgtype152;
	Y2704_gen_type [153] = Y2704_pgtype153;
	Y2704_gen_type [154] = Y2704_pgtype154;
	Y2704_gen_type [155] = Y2704_pgtype155;
	Y2704_gen_type [156] = Y2704_pgtype156;
	Y2704_gen_type [157] = Y2704_pgtype157;
	Y2704_gen_type [158] = Y2704_pgtype158;
	Y2704_gen_type [159] = Y2704_pgtype159;
	Y2704_gen_type [160] = Y2704_pgtype160;
	Y2704_gen_type [161] = Y2704_pgtype161;
	Y2704_gen_type [162] = Y2704_pgtype162;
	Y2704_gen_type [163] = Y2704_pgtype163;
	Y2704_gen_type [164] = Y2704_pgtype164;
	Y2704_gen_type [165] = Y2704_pgtype165;
	Y2704_gen_type [166] = Y2704_pgtype166;
	Y2704_gen_type [167] = Y2704_pgtype167;
	Y2704_gen_type [168] = Y2704_pgtype168;
	Y2704_gen_type [169] = Y2704_pgtype169;
	Y2704_gen_type [170] = Y2704_pgtype170;
	Y2704_gen_type [171] = Y2704_pgtype171;
	Y2704_gen_type [172] = Y2704_pgtype172;
	Y2704_gen_type [173] = Y2704_pgtype173;
	Y2704_gen_type [174] = Y2704_pgtype174;
	Y2704_gen_type [175] = Y2704_pgtype175;
	Y2704_gen_type [176] = Y2704_pgtype176;
	Y2704_gen_type [177] = Y2704_pgtype177;
	Y2704_gen_type [178] = Y2704_pgtype178;
	Y2704_gen_type [179] = Y2704_pgtype179;
	Y2704_gen_type [180] = Y2704_pgtype180;
	Y2704_gen_type [181] = Y2704_pgtype181;
	Y2704_gen_type [182] = Y2704_pgtype182;
	Y2704_gen_type [183] = Y2704_pgtype183;
	Y2704_gen_type [184] = Y2704_pgtype184;
	Y2704_gen_type [185] = Y2704_pgtype185;
	Y2704_gen_type [186] = Y2704_pgtype186;
	Y2704_gen_type [187] = Y2704_pgtype187;
	Y2704_gen_type [188] = Y2704_pgtype188;
	Y2704_gen_type [189] = Y2704_pgtype189;
	Y2704_gen_type [190] = Y2704_pgtype190;
	Y2704_gen_type [191] = Y2704_pgtype191;
	Y2704_gen_type [192] = Y2704_pgtype192;
	Y2704_gen_type [193] = Y2704_pgtype193;
	Y2704_gen_type [194] = Y2704_pgtype194;
	Y2704_gen_type [195] = Y2704_pgtype195;
	Y2704_gen_type [196] = Y2704_pgtype196;
	Y2704_gen_type [197] = Y2704_pgtype197;
	Y2704_gen_type [198] = Y2704_pgtype198;
	Y2704_gen_type [199] = Y2704_pgtype199;
	Y2704_gen_type [200] = Y2704_pgtype200;
	Y2704_gen_type [201] = Y2704_pgtype201;
	Y2704_gen_type [202] = Y2704_pgtype202;
	Y2704_gen_type [203] = Y2704_pgtype203;
	Y2704_gen_type [204] = Y2704_pgtype204;
	Y2704_gen_type [205] = Y2704_pgtype205;
	Y2704_gen_type [206] = Y2704_pgtype206;
	Y2704_gen_type [207] = Y2704_pgtype207;
	Y2704_gen_type [208] = Y2704_pgtype208;
	Y2704_gen_type [209] = Y2704_pgtype209;
	Y2704_gen_type [210] = Y2704_pgtype210;
	Y2704_gen_type [211] = Y2704_pgtype211;
	Y2704_gen_type [212] = Y2704_pgtype212;
	Y2704_gen_type [213] = Y2704_pgtype213;
	Y2704_gen_type [214] = Y2704_pgtype214;
	Y2704_gen_type [215] = Y2704_pgtype215;
	Y2704_gen_type [216] = Y2704_pgtype216;
	Y2704_gen_type [217] = Y2704_pgtype217;
	Y2704_gen_type [218] = Y2704_pgtype218;
	Y2704_gen_type [219] = Y2704_pgtype219;
	Y2704_gen_type [220] = Y2704_pgtype220;
	Y2704_gen_type [221] = Y2704_pgtype221;
	Y2704_gen_type [222] = Y2704_pgtype222;
	Y2704_gen_type [223] = Y2704_pgtype223;
	Y2704_gen_type [224] = Y2704_pgtype224;
	Y2704_gen_type [225] = Y2704_pgtype225;
	Y2704_gen_type [226] = Y2704_pgtype226;
	Y2704_gen_type [227] = Y2704_pgtype227;
	Y2704_gen_type [228] = Y2704_pgtype228;
	Y2704_gen_type [229] = Y2704_pgtype229;
	Y2704_gen_type [230] = Y2704_pgtype230;
	Y2704_gen_type [231] = Y2704_pgtype231;
	Y2704_gen_type [232] = Y2704_pgtype232;
	Y2704_gen_type [233] = Y2704_pgtype233;
	Y2704_gen_type [234] = Y2704_pgtype234;
	Y2704_gen_type [235] = Y2704_pgtype235;
	Y2704_gen_type [236] = Y2704_pgtype236;
	Y2704_gen_type [237] = Y2704_pgtype237;
	Y2704_gen_type [238] = Y2704_pgtype238;
	Y2704_gen_type [239] = Y2704_pgtype239;
	Y2704_gen_type [240] = Y2704_pgtype240;
	Y2704_gen_type [241] = Y2704_pgtype241;
	Y2704_gen_type [242] = Y2704_pgtype242;
	Y2704_gen_type [243] = Y2704_pgtype243;
	Y2704_gen_type [244] = Y2704_pgtype244;
	Y2704_gen_type [245] = Y2704_pgtype245;
	Y2704_gen_type [246] = Y2704_pgtype246;
	Y2704_gen_type [247] = Y2704_pgtype247;
	Y2704_gen_type [248] = Y2704_pgtype248;
	Y2704_gen_type [249] = Y2704_pgtype249;
	Y2704_gen_type [250] = Y2704_pgtype250;
	Y2704_gen_type [251] = Y2704_pgtype251;
	Y2704_gen_type [252] = Y2704_pgtype252;
	Y2704_gen_type [253] = Y2704_pgtype253;
	Y2704_gen_type [254] = Y2704_pgtype254;
	Y2704_gen_type [255] = Y2704_pgtype255;
	Y2704_gen_type [256] = Y2704_pgtype256;
	Y2704_gen_type [257] = Y2704_pgtype257;
	Y2704_gen_type [258] = Y2704_pgtype258;
	Y2704_gen_type [259] = Y2704_pgtype259;
	Y2704_gen_type [260] = Y2704_pgtype260;
	Y2704_gen_type [261] = Y2704_pgtype261;
	Y2704_gen_type [262] = Y2704_pgtype262;
	Y2704_gen_type [263] = Y2704_pgtype263;
	Y2704_gen_type [264] = Y2704_pgtype264;
	Y2704_gen_type [265] = Y2704_pgtype265;
	Y2704_gen_type [266] = Y2704_pgtype266;
	Y2704_gen_type [267] = Y2704_pgtype267;
	Y2704_gen_type [268] = Y2704_pgtype268;
	Y2704_gen_type [269] = Y2704_pgtype269;
	Y2704_gen_type [270] = Y2704_pgtype270;
	Y2704_gen_type [271] = Y2704_pgtype271;
	Y2704_gen_type [272] = Y2704_pgtype272;
	Y2704_gen_type [273] = Y2704_pgtype273;
	Y2704_gen_type [274] = Y2704_pgtype274;
	Y2704_gen_type [275] = Y2704_pgtype275;
	Y2704_gen_type [276] = Y2704_pgtype276;
	Y2704_gen_type [277] = Y2704_pgtype277;
	Y2704_gen_type [278] = Y2704_pgtype278;
	Y2704_gen_type [279] = Y2704_pgtype279;
	Y2704_gen_type [280] = Y2704_pgtype280;
	Y2704_gen_type [281] = Y2704_pgtype281;
	Y2704_gen_type [282] = Y2704_pgtype282;
	Y2704_gen_type [283] = Y2704_pgtype283;
	Y2704_gen_type [284] = Y2704_pgtype284;
	Y2704_gen_type [285] = Y2704_pgtype285;
	Y2704_gen_type [286] = Y2704_pgtype286;
	Y2704_gen_type [287] = Y2704_pgtype287;
	Y2704_gen_type [288] = Y2704_pgtype288;
	Y2704_gen_type [289] = Y2704_pgtype289;
	Y2704_gen_type [290] = Y2704_pgtype290;
	Y2704_gen_type [291] = Y2704_pgtype291;
	Y2704_gen_type [292] = Y2704_pgtype292;
	Y2704_gen_type [293] = Y2704_pgtype293;
	Y2704_gen_type [294] = Y2704_pgtype294;
	Y2704_gen_type [295] = Y2704_pgtype295;
	Y2704_gen_type [296] = Y2704_pgtype296;
	Y2704_gen_type [297] = Y2704_pgtype297;
	Y2704_gen_type [298] = Y2704_pgtype298;
	Y2704_gen_type [299] = Y2704_pgtype299;
	Y2704_gen_type [300] = Y2704_pgtype300;
	Y2704_gen_type [301] = Y2704_pgtype301;
	Y2704_gen_type [302] = Y2704_pgtype302;
	Y2704_gen_type [303] = Y2704_pgtype303;
	Y2704_gen_type [304] = Y2704_pgtype304;
	Y2704_gen_type [305] = Y2704_pgtype305;
	Y2704_gen_type [306] = Y2704_pgtype306;
	Y2704_gen_type [307] = Y2704_pgtype307;
	Y2704_gen_type [308] = Y2704_pgtype308;
	Y2704_gen_type [309] = Y2704_pgtype309;
	Y2704_gen_type [310] = Y2704_pgtype310;
	Y2704_gen_type [311] = Y2704_pgtype311;
	Y2704_gen_type [312] = Y2704_pgtype312;
	Y2704_gen_type [313] = Y2704_pgtype313;
	Y2704_gen_type [314] = Y2704_pgtype314;
	Y2704_gen_type [315] = Y2704_pgtype315;
	Y2704_gen_type [316] = Y2704_pgtype316;
	Y2704_gen_type [317] = Y2704_pgtype317;
	Y2704_gen_type [318] = Y2704_pgtype318;
	Y2704_gen_type [319] = Y2704_pgtype319;
	Y2704_gen_type [320] = Y2704_pgtype320;
	Y2704_gen_type [321] = Y2704_pgtype321;
	Y2704_gen_type [322] = Y2704_pgtype322;
	Y2704_gen_type [323] = Y2704_pgtype323;
	Y2704_gen_type [324] = Y2704_pgtype324;
	Y2704_gen_type [325] = Y2704_pgtype325;
	Y2704_gen_type [326] = Y2704_pgtype326;
	Y2704_gen_type [327] = Y2704_pgtype327;
	Y2704_gen_type [328] = Y2704_pgtype328;
	Y2704_gen_type [329] = Y2704_pgtype329;
	Y2704_gen_type [330] = Y2704_pgtype330;
	Y2704_gen_type [331] = Y2704_pgtype331;
	Y2704_gen_type [332] = Y2704_pgtype332;
	Y2704_gen_type [333] = Y2704_pgtype333;
	Y2704_gen_type [334] = Y2704_pgtype334;
	Y2704_gen_type [335] = Y2704_pgtype335;
	Y2704_gen_type [336] = Y2704_pgtype336;
	Y2704_gen_type [337] = Y2704_pgtype337;
	Y2704_gen_type [338] = Y2704_pgtype338;
	Y2704_gen_type [339] = Y2704_pgtype339;
	Y2704_gen_type [340] = Y2704_pgtype340;
	Y2704_gen_type [341] = Y2704_pgtype341;
	Y2704_gen_type [342] = Y2704_pgtype342;
	Y2704_gen_type [343] = Y2704_pgtype343;
	Y2704_gen_type [344] = Y2704_pgtype344;
	Y2704_gen_type [345] = Y2704_pgtype345;
	Y2704_gen_type [346] = Y2704_pgtype346;
	Y2704_gen_type [347] = Y2704_pgtype347;
	Y2704_gen_type [348] = Y2704_pgtype348;
	Y2704_gen_type [349] = Y2704_pgtype349;
	Y2704_gen_type [350] = Y2704_pgtype350;
	Y2704_gen_type [351] = Y2704_pgtype351;
	Y2704_gen_type [352] = Y2704_pgtype352;
	Y2704_gen_type [353] = Y2704_pgtype353;
	Y2704_gen_type [354] = Y2704_pgtype354;
	Y2704_gen_type [355] = Y2704_pgtype355;
	Y2704_gen_type [356] = Y2704_pgtype356;
	Y2704_gen_type [357] = Y2704_pgtype357;
	Y2704_gen_type [358] = Y2704_pgtype358;
	Y2704_gen_type [359] = Y2704_pgtype359;
	Y2704_gen_type [360] = Y2704_pgtype360;
	Y2704_gen_type [361] = Y2704_pgtype361;
	Y2704_gen_type [362] = Y2704_pgtype362;
	Y2704_gen_type [363] = Y2704_pgtype363;
	Y2704_gen_type [364] = Y2704_pgtype364;
	Y2704_gen_type [365] = Y2704_pgtype365;
	Y2704_gen_type [366] = Y2704_pgtype366;
	Y2704_gen_type [367] = Y2704_pgtype367;
	Y2704_gen_type [368] = Y2704_pgtype368;
	Y2704_gen_type [369] = Y2704_pgtype369;
	Y2704_gen_type [370] = Y2704_pgtype370;
	Y2704_gen_type [371] = Y2704_pgtype371;
	Y2704_gen_type [372] = Y2704_pgtype372;
	Y2704_gen_type [373] = Y2704_pgtype373;
	Y2704_gen_type [374] = Y2704_pgtype374;
	Y2704_gen_type [375] = Y2704_pgtype375;
	Y2704_gen_type [376] = Y2704_pgtype376;
	Y2704_gen_type [377] = Y2704_pgtype377;
	Y2704_gen_type [378] = Y2704_pgtype378;
	Y2704_gen_type [379] = Y2704_pgtype379;
	Y2704_gen_type [380] = Y2704_pgtype380;
	Y2704_gen_type [381] = Y2704_pgtype381;
	Y2704_gen_type [382] = Y2704_pgtype382;
	Y2704_gen_type [383] = Y2704_pgtype383;
	Y2704_gen_type [384] = Y2704_pgtype384;
	Y2704_gen_type [385] = Y2704_pgtype385;
	Y2704_gen_type [386] = Y2704_pgtype386;
	Y2704_gen_type [387] = Y2704_pgtype387;
	Y2704_gen_type [388] = Y2704_pgtype388;
	Y2704_gen_type [389] = Y2704_pgtype389;
	Y2704_gen_type [390] = Y2704_pgtype390;
	Y2704_gen_type [391] = Y2704_pgtype391;
	Y2704_gen_type [392] = Y2704_pgtype392;
	Y2704_gen_type [393] = Y2704_pgtype393;
	Y2704_gen_type [394] = Y2704_pgtype394;
	Y2704_gen_type [395] = Y2704_pgtype395;
	Y2704_gen_type [396] = Y2704_pgtype396;
	Y2704_gen_type [397] = Y2704_pgtype397;
	Y2704_gen_type [398] = Y2704_pgtype398;
	Y2704_gen_type [399] = Y2704_pgtype399;
	Y2704_gen_type [400] = Y2704_pgtype400;
	Y2704_gen_type [401] = Y2704_pgtype401;
	Y2704_gen_type [402] = Y2704_pgtype402;
	Y2704_gen_type [403] = Y2704_pgtype403;
	Y2704_gen_type [404] = Y2704_pgtype404;
	Y2704_gen_type [405] = Y2704_pgtype405;
	Y2704_gen_type [406] = Y2704_pgtype406;
	Y2704_gen_type [407] = Y2704_pgtype407;
	Y2704_gen_type [408] = Y2704_pgtype408;
	Y2704_gen_type [409] = Y2704_pgtype409;
	Y2704_gen_type [410] = Y2704_pgtype410;
	Y2704_gen_type [411] = Y2704_pgtype411;
	Y2704_gen_type [412] = Y2704_pgtype412;
	Y2704_gen_type [413] = Y2704_pgtype413;
	Y2704_gen_type [414] = Y2704_pgtype414;
	Y2704_gen_type [415] = Y2704_pgtype415;
	Y2704_gen_type [416] = Y2704_pgtype416;
	Y2704_gen_type [417] = Y2704_pgtype417;
	Y2704_gen_type [418] = Y2704_pgtype418;
	Y2704_gen_type [419] = Y2704_pgtype419;
	Y2704_gen_type [420] = Y2704_pgtype420;
	Y2704_gen_type [421] = Y2704_pgtype421;
	Y2704_gen_type [422] = Y2704_pgtype422;
	Y2704_gen_type [423] = Y2704_pgtype423;
	Y2704_gen_type [424] = Y2704_pgtype424;
	Y2704_gen_type [425] = Y2704_pgtype425;
	Y2704_gen_type [426] = Y2704_pgtype426;
	Y2704_gen_type [430] = Y2704_pgtype427;
	Y2704_gen_type [431] = Y2704_pgtype428;
	Y2704_gen_type [432] = Y2704_pgtype429;
	Y2704_gen_type [433] = Y2704_pgtype430;
	Y2704_gen_type [434] = Y2704_pgtype431;
	Y2704_gen_type [435] = Y2704_pgtype432;
	Y2704_gen_type [436] = Y2704_pgtype433;
	Y2704_gen_type [437] = Y2704_pgtype434;
	Y2704_gen_type [438] = Y2704_pgtype435;
	Y2704_gen_type [439] = Y2704_pgtype436;
	Y2704_gen_type [440] = Y2704_pgtype437;
	Y2704_gen_type [441] = Y2704_pgtype438;
	Y2704_gen_type [442] = Y2704_pgtype439;
	Y2704_gen_type [443] = Y2704_pgtype440;
	Y2704_gen_type [444] = Y2704_pgtype441;
	Y2704_gen_type [445] = Y2704_pgtype442;
	Y2704_gen_type [446] = Y2704_pgtype443;
	Y2704_gen_type [447] = Y2704_pgtype444;
	Y2704_gen_type [448] = Y2704_pgtype445;
	Y2704_gen_type [449] = Y2704_pgtype446;
	Y2704_gen_type [450] = Y2704_pgtype447;
	Y2704_gen_type [486] = Y2704_pgtype448;
	Y2704_gen_type [567] = Y2704_pgtype449;
	Y2704_gen_type [568] = Y2704_pgtype450;
	Y2704_gen_type [569] = Y2704_pgtype451;
	Y2704_gen_type [570] = Y2704_pgtype452;
	Y2704_gen_type [571] = Y2704_pgtype453;
	Y2704_gen_type [572] = Y2704_pgtype454;
	Y2704_gen_type [573] = Y2704_pgtype455;
	Y2704_gen_type [611] = Y2704_pgtype456;
	Y2704_gen_type [647] = Y2704_pgtype457;
	Y2704_gen_type [648] = Y2704_pgtype458;
	Y2704_gen_type [649] = Y2704_pgtype459;
	Y2704_gen_type [650] = Y2704_pgtype460;
	Y2704_gen_type [651] = Y2704_pgtype461;
	Y2704_gen_type [652] = Y2704_pgtype462;
	Y2704_gen_type [653] = Y2704_pgtype463;
	Y2704_gen_type [654] = Y2704_pgtype464;
	Y2704_gen_type [655] = Y2704_pgtype465;
	Y2704_gen_type [656] = Y2704_pgtype466;
	Y2704_gen_type [657] = Y2704_pgtype467;
	Y2704_gen_type [658] = Y2704_pgtype468;
	Y2704_gen_type [659] = Y2704_pgtype469;
	Y2704_gen_type [660] = Y2704_pgtype470;
	Y2704_gen_type [661] = Y2704_pgtype471;
	Y2704_gen_type [662] = Y2704_pgtype472;
	Y2704_gen_type [663] = Y2704_pgtype473;
	Y2704_gen_type [664] = Y2704_pgtype474;
	Y2704_gen_type [665] = Y2704_pgtype475;
	Y2704_gen_type [666] = Y2704_pgtype476;
	Y2704_gen_type [667] = Y2704_pgtype477;
	Y2704_gen_type [668] = Y2704_pgtype478;
	Y2704_gen_type [669] = Y2704_pgtype479;
	Y2704_gen_type [670] = Y2704_pgtype480;
	Y2704_gen_type [671] = Y2704_pgtype481;
	Y2704_gen_type [672] = Y2704_pgtype482;
	Y2704_gen_type [673] = Y2704_pgtype483;
	Y2704_gen_type [674] = Y2704_pgtype484;
	Y2704_gen_type [675] = Y2704_pgtype485;
	Y2704_gen_type [676] = Y2704_pgtype486;
	Y2704_gen_type [677] = Y2704_pgtype487;
	Y2704_gen_type [678] = Y2704_pgtype488;
	Y2704_gen_type [679] = Y2704_pgtype489;
	Y2704_gen_type [680] = Y2704_pgtype490;
	Y2704_gen_type [681] = Y2704_pgtype491;
	Y2704_gen_type [682] = Y2704_pgtype492;
	Y2704_gen_type [683] = Y2704_pgtype493;
	Y2704_gen_type [684] = Y2704_pgtype494;
	Y2704_gen_type [685] = Y2704_pgtype495;
	Y2704_gen_type [686] = Y2704_pgtype496;
	Y2704_gen_type [687] = Y2704_pgtype497;
	Y2704_gen_type [688] = Y2704_pgtype498;
	Y2704_gen_type [689] = Y2704_pgtype499;
	Y2704_gen_type [690] = Y2704_pgtype500;
	Y2704_gen_type [691] = Y2704_pgtype501;
	Y2704_gen_type [692] = Y2704_pgtype502;
	Y2704_gen_type [693] = Y2704_pgtype503;
	Y2704_gen_type [694] = Y2704_pgtype504;
	Y2704_gen_type [695] = Y2704_pgtype505;
	Y2704_gen_type [696] = Y2704_pgtype506;
	Y2704_gen_type [697] = Y2704_pgtype507;
	Y2704_gen_type [698] = Y2704_pgtype508;
	Y2704_gen_type [699] = Y2704_pgtype509;
	Y2704_gen_type [700] = Y2704_pgtype510;
	Y2704_gen_type [701] = Y2704_pgtype511;
	Y2704_gen_type [708] = Y2704_pgtype512;
	Y2704_gen_type [709] = Y2704_pgtype513;
	Y2704_gen_type [710] = Y2704_pgtype514;
	Y2704_gen_type [711] = Y2704_pgtype515;
	Y2704_gen_type [713] = Y2704_pgtype516;
	Y2704_gen_type [714] = Y2704_pgtype517;
	Y2704_gen_type [715] = Y2704_pgtype518;
	Y2704_gen_type [716] = Y2704_pgtype519;
	Y2704_gen_type [764] = Y2704_pgtype520;
	Y2704_gen_type [765] = Y2704_pgtype521;
	Y2704_gen_type [766] = Y2704_pgtype522;
	Y2704_gen_type [767] = Y2704_pgtype523;
	Y2704_gen_type [768] = Y2704_pgtype524;
	Y2704_gen_type [769] = Y2704_pgtype525;
	Y2704_gen_type [770] = Y2704_pgtype526;
	Y2704_gen_type [771] = Y2704_pgtype527;
	Y2704_gen_type [772] = Y2704_pgtype528;
	Y2704_gen_type [773] = Y2704_pgtype529;
	Y2704_gen_type [774] = Y2704_pgtype530;
	Y2704_gen_type [775] = Y2704_pgtype531;
	Y2704_gen_type [776] = Y2704_pgtype532;
	Y2704_gen_type [777] = Y2704_pgtype533;
	Y2704_gen_type [778] = Y2704_pgtype534;
	Y2704_gen_type [779] = Y2704_pgtype535;
	Y2704_gen_type [780] = Y2704_pgtype536;
	Y2704_gen_type [781] = Y2704_pgtype537;
	Y2704_gen_type [782] = Y2704_pgtype538;
	Y2704_gen_type [783] = Y2704_pgtype539;
	Y2704_gen_type [788] = Y2704_pgtype540;
	Y2704_gen_type [789] = Y2704_pgtype541;
	Y2704_gen_type [798] = Y2704_pgtype542;
	Y2704_gen_type [799] = Y2704_pgtype543;
	Y2704_gen_type [800] = Y2704_pgtype544;
	Y2704_gen_type [801] = Y2704_pgtype545;
	Y2704_gen_type [802] = Y2704_pgtype546;
	Y2704_gen_type [803] = Y2704_pgtype547;
	Y2704_gen_type [804] = Y2704_pgtype548;
	Y2704_gen_type [805] = Y2704_pgtype549;
	Y2704_gen_type [806] = Y2704_pgtype550;
	Y2704_gen_type [807] = Y2704_pgtype551;
	Y2704_gen_type [808] = Y2704_pgtype552;
	Y2704_gen_type [809] = Y2704_pgtype553;
	Y2704_gen_type [816] = Y2704_pgtype554;
	Y2704_gen_type [817] = Y2704_pgtype555;
	Y2704_gen_type [818] = Y2704_pgtype556;
	Y2704_gen_type [819] = Y2704_pgtype557;
	Y2704_gen_type [820] = Y2704_pgtype558;
	Y2704_gen_type [821] = Y2704_pgtype559;
	Y2704_gen_type [822] = Y2704_pgtype560;
	Y2704_gen_type [823] = Y2704_pgtype561;
	Y2704_gen_type [824] = Y2704_pgtype562;
	Y2704_gen_type [825] = Y2704_pgtype563;
	Y2704_gen_type [826] = Y2704_pgtype564;
	Y2704_gen_type [827] = Y2704_pgtype565;
	Y2704_gen_type [828] = Y2704_pgtype566;
	Y2704_gen_type [829] = Y2704_pgtype567;
	Y2704_gen_type [830] = Y2704_pgtype568;
	Y2704_gen_type [831] = Y2704_pgtype569;
	Y2704_gen_type [832] = Y2704_pgtype570;
	Y2704_gen_type [833] = Y2704_pgtype571;
	Y2704_gen_type [834] = Y2704_pgtype572;
	Y2704_gen_type [835] = Y2704_pgtype573;
	Y2704_gen_type [836] = Y2704_pgtype574;
	Y2704_gen_type [837] = Y2704_pgtype575;
	Y2704_gen_type [838] = Y2704_pgtype576;
	Y2704_gen_type [839] = Y2704_pgtype577;
	Y2704_gen_type [840] = Y2704_pgtype578;
	Y2704_gen_type [905] = Y2704_pgtype579;
	Y2704_gen_type [906] = Y2704_pgtype580;
	Y2704[12] = 910;
	Y2704[13] = 861;
	{long i; for (i = 14; i < 16; i++) Y2704[i] = 914;};
	Y2704[88] = 861;
	Y2704[89] = 864;
	Y2704[256] = 834;
	{long i; for (i = 319; i < 322; i++) Y2704[i] = 864;};
	Y2704[358] = 834;
	Y2704[450] = 0;
	Y2704[486] = 0;
	{long i; for (i = 567; i < 570; i++) Y2704[i] = 861;};
	{long i; for (i = 570; i < 574; i++) Y2704[i] = 864;};
	Y2704[611] = 864;
	{long i; for (i = 708; i < 712; i++) Y2704[i] = 864;};
	{long i; for (i = 713; i < 717; i++) Y2704[i] = 864;};
	Y2704[806] = 1066;
	Y2704[807] = 115;
	Y2704[809] = 47;
	Y2704[818] = 44;
	{long i; for (i = 905; i < 907; i++) Y2704[i] = 864;};
}

char *(*R2769[5])();
void R2769_init () {
	R2769[0] = (char *(*)()) F388_3048;
	R2769[1] = (char *(*)()) F391_3048;
	R2769[2] = (char *(*)()) F388_3048;
	{long i; for (i = 3; i < 5; i++) R2769[i] = (char *(*)()) F389_3048;}
}

char *(*R2772[5])();
void R2772_init () {
	R2772[0] = (char *(*)()) F388_3053;
	R2772[1] = (char *(*)()) F391_3053;
	R2772[2] = (char *(*)()) F388_3053;
	{long i; for (i = 3; i < 5; i++) R2772[i] = (char *(*)()) F389_3053;}
}

char *(*R2775[5])();
void R2775_init () {
	R2775[0] = (char *(*)()) F388_3034;
	R2775[1] = (char *(*)()) F391_3034;
	R2775[2] = (char *(*)()) F388_3034;
	{long i; for (i = 3; i < 5; i++) R2775[i] = (char *(*)()) F389_3034;}
}

char *(*R2802[650])();
void R2802_init () {
	R2802[0] = (char *(*)()) F599_3212_2802_2;
	R2802[316] = (char *(*)()) F913_5786_2802_2;
	R2802[649] = (char *(*)()) F1248_8963_2802_2;
}
static EIF_BOOLEAN F599_3212_2802_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F599_3212(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F913_5786_2802_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F913_5786(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1248_8963_2802_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1248_8963(Current, *(EIF_CHARACTER_8 *)arg1);
}

char *(*R2807[650])();
void R2807_init () {
	R2807[0] = (char *(*)()) F458_3121;
	R2807[103] = (char *(*)()) F457_3121;
	R2807[104] = (char *(*)()) F458_3121;
	R2807[105] = (char *(*)()) F460_3121;
	R2807[106] = (char *(*)()) F461_3121;
	R2807[107] = (char *(*)()) F462_3121;
	R2807[108] = (char *(*)()) F463_3121;
	R2807[109] = (char *(*)()) F459_3121;
	R2807[110] = (char *(*)()) F464_3121;
	R2807[111] = (char *(*)()) F465_3121;
	R2807[112] = (char *(*)()) F466_3121;
	R2807[113] = (char *(*)()) F467_3121;
	R2807[114] = (char *(*)()) F468_3121;
	R2807[115] = (char *(*)()) F457_3121;
	R2807[116] = (char *(*)()) F458_3121;
	R2807[117] = (char *(*)()) F459_3121;
	R2807[118] = (char *(*)()) F461_3121;
	R2807[119] = (char *(*)()) F468_3121;
	R2807[120] = (char *(*)()) F463_3121;
	R2807[187] = (char *(*)()) F457_3121;
	R2807[188] = (char *(*)()) F460_3121;
	R2807[189] = (char *(*)()) F457_3121;
	{long i; for (i = 190; i < 192; i++) R2807[i] = (char *(*)()) F458_3121;}
	R2807[194] = (char *(*)()) F457_3121;
	R2807[313] = (char *(*)()) F462_3121;
	R2807[316] = (char *(*)()) F459_3121;
	R2807[355] = (char *(*)()) F459_3121;
	R2807[452] = (char *(*)()) F459_3121;
	R2807[457] = (char *(*)()) F459_3121;
	R2807[649] = (char *(*)()) F459_3121;
}

char *(*R2840[547])();
void R2840_init () {
	R2840[0] = (char *(*)()) F702_3690_2840_5;
	R2840[1] = (char *(*)()) F703_3690_2840_5;
	R2840[2] = (char *(*)()) F704_3690_2840_5;
	R2840[3] = (char *(*)()) F705_3690_2840_5;
	R2840[4] = (char *(*)()) F706_3690_2840_5;
	R2840[5] = (char *(*)()) F707_3690_2840_5;
	R2840[6] = (char *(*)()) F708_3690_2840_5;
	R2840[7] = (char *(*)()) F709_3690_2840_5;
	R2840[8] = (char *(*)()) F710_3690_2840_5;
	R2840[9] = (char *(*)()) F711_3690_2840_5;
	R2840[10] = (char *(*)()) F712_3690_2840_5;
	R2840[11] = (char *(*)()) F713_3690_2840_5;
	R2840[12] = (char *(*)()) F702_3690_2840_5;
	R2840[13] = (char *(*)()) F703_3690_2840_5;
	R2840[14] = (char *(*)()) F708_3690_2840_5;
	R2840[15] = (char *(*)()) F705_3690_2840_5;
	R2840[16] = (char *(*)()) F713_3690_2840_5;
	R2840[17] = (char *(*)()) F707_3690_2840_5;
	R2840[210] = (char *(*)()) F912_5666_2840_5;
	R2840[213] = (char *(*)()) F915_5830_2840_5;
	R2840[546] = (char *(*)()) F1248_8942_2840_5;
}
static EIF_REFERENCE F702_3690_2840_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F702_3690(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F703_3690_2840_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F703_3690(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F704_3690_2840_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F704_3690(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F705_3690_2840_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F705_3690(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(867, 0x00).id, 867, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F706_3690_2840_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F706_3690(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(861, 0x00).id, 861, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F707_3690_2840_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F707_3690(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(843, 0x00).id, 843, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F708_3690_2840_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F708_3690(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F709_3690_2840_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F709_3690(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(852, 0x00).id, 852, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F710_3690_2840_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F710_3690(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(849, 0x00).id, 849, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F711_3690_2840_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F711_3690(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(855, 0x00).id, 855, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F712_3690_2840_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F712_3690(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(858, 0x00).id, 858, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F713_3690_2840_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F713_3690(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(846, 0x00).id, 846, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F912_5666_2840_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F912_5666(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(861, 0x00).id, 861, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F915_5830_2840_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F915_5830(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1248_8942_2840_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1248_8942(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R2843[547])();
void R2843_init () {
	R2843[0] = (char *(*)()) F702_3709_2843_14;
	R2843[1] = (char *(*)()) F703_3709_2843_14;
	R2843[2] = (char *(*)()) F704_3709_2843_14;
	R2843[3] = (char *(*)()) F705_3709_2843_14;
	R2843[4] = (char *(*)()) F706_3709_2843_14;
	R2843[5] = (char *(*)()) F707_3709_2843_14;
	R2843[6] = (char *(*)()) F708_3709_2843_14;
	R2843[7] = (char *(*)()) F709_3709_2843_14;
	R2843[8] = (char *(*)()) F710_3709_2843_14;
	R2843[9] = (char *(*)()) F711_3709_2843_14;
	R2843[10] = (char *(*)()) F712_3709_2843_14;
	R2843[11] = (char *(*)()) F713_3709_2843_14;
	R2843[12] = (char *(*)()) F702_3709_2843_14;
	R2843[13] = (char *(*)()) F703_3709_2843_14;
	R2843[14] = (char *(*)()) F708_3709_2843_14;
	R2843[15] = (char *(*)()) F705_3709_2843_14;
	R2843[16] = (char *(*)()) F713_3709_2843_14;
	R2843[17] = (char *(*)()) F707_3709_2843_14;
	R2843[84] = (char *(*)()) F786_4008;
	R2843[85] = (char *(*)()) F787_4008_2843_14;
	R2843[86] = (char *(*)()) F788_4008_2843_14;
	R2843[87] = (char *(*)()) F789_4008_2843_14;
	R2843[88] = (char *(*)()) F790_4008_2843_14;
	R2843[91] = (char *(*)()) F786_4008;
	R2843[210] = (char *(*)()) F912_5686_2843_14;
	R2843[213] = (char *(*)()) F915_5851_2843_14;
	R2843[546] = (char *(*)()) F1248_8977_2843_14;
}
static void F702_3709_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F702_3709(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F703_3709_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F703_3709(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F704_3709_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F704_3709(Current, *(EIF_POINTER *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F705_3709_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F705_3709(Current, *(EIF_BOOLEAN *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F706_3709_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F706_3709(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F707_3709_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F707_3709(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F708_3709_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F708_3709(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F709_3709_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F709_3709(Current, *(EIF_NATURAL_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F710_3709_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F710_3709(Current, *(EIF_NATURAL_16 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F711_3709_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F711_3709(Current, *(EIF_REAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F712_3709_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F712_3709(Current, *(EIF_REAL_64 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F713_3709_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F713_3709(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F787_4008_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F787_4008(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F788_4008_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F788_4008(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F789_4008_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F789_4008(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F790_4008_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F790_4008(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F912_5686_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F912_5686(Current, *(EIF_CHARACTER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F915_5851_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F915_5851(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1248_8977_2843_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1248_8977(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

static EIF_TYPE_INDEX Y2845_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype23[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype24[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype25[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype26[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype27[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype28[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype29[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype30[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype31[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype32[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype33[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype34[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype35[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype36[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype37[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype38[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype39[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype40[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype41[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype42[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype43[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype44[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype45[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype46[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype47[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype48[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype49[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype50[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype51[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype52[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype53[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype54[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype55[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype56[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype57[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype58[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype59[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype60[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype61[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype62[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype63[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype64[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype65[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype66[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype67[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype68[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype69[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype70[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype71[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype72[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype73[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype74[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype75[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype76[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype77[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype78[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype79[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype80[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype81[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype82[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype83[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype84[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype85[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype86[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype87[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype88[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype89[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype90[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype91[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype92[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype93[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype94[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype95[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype96[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype97[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype98[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype99[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype100[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype101[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype102[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype103[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype104[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype105[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype106[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype107[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype108[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype109[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype110[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype111[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype112[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype113[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype114[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype115[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype116[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype117[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype118[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype119[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype120[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype121[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype122[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype123[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype124[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype125[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype126[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype127[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype128[] = {0xFF01,906,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype129[] = {0xFF01,906,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype130[] = {0xFF01,914,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype131[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype132[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype133[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype134[] = {834,0xFFFF};
static EIF_TYPE_INDEX Y2845_pgtype135[] = {834,0xFFFF};
EIF_TYPE_INDEX *Y2845_gen_type [720];
EIF_TYPE_INDEX Y2845 [720];
void Y2845_init (void)
{
	egc_routines_types [2845] = Y2845;
	egc_routines_gen_types [2845] = Y2845_gen_type;
	egc_routines_offset [2845] = 529;
	Y2845_gen_type [0] = Y2845_pgtype0;
	Y2845_gen_type [1] = Y2845_pgtype1;
	Y2845_gen_type [2] = Y2845_pgtype2;
	Y2845_gen_type [3] = Y2845_pgtype3;
	Y2845_gen_type [4] = Y2845_pgtype4;
	Y2845_gen_type [5] = Y2845_pgtype5;
	Y2845_gen_type [6] = Y2845_pgtype6;
	Y2845_gen_type [7] = Y2845_pgtype7;
	Y2845_gen_type [8] = Y2845_pgtype8;
	Y2845_gen_type [9] = Y2845_pgtype9;
	Y2845_gen_type [10] = Y2845_pgtype10;
	Y2845_gen_type [11] = Y2845_pgtype11;
	Y2845_gen_type [12] = Y2845_pgtype12;
	Y2845_gen_type [13] = Y2845_pgtype13;
	Y2845_gen_type [14] = Y2845_pgtype14;
	Y2845_gen_type [15] = Y2845_pgtype15;
	Y2845_gen_type [16] = Y2845_pgtype16;
	Y2845_gen_type [17] = Y2845_pgtype17;
	Y2845_gen_type [18] = Y2845_pgtype18;
	Y2845_gen_type [19] = Y2845_pgtype19;
	Y2845_gen_type [20] = Y2845_pgtype20;
	Y2845_gen_type [21] = Y2845_pgtype21;
	Y2845_gen_type [22] = Y2845_pgtype22;
	Y2845_gen_type [23] = Y2845_pgtype23;
	Y2845_gen_type [24] = Y2845_pgtype24;
	Y2845_gen_type [25] = Y2845_pgtype25;
	Y2845_gen_type [26] = Y2845_pgtype26;
	Y2845_gen_type [27] = Y2845_pgtype27;
	Y2845_gen_type [28] = Y2845_pgtype28;
	Y2845_gen_type [29] = Y2845_pgtype29;
	Y2845_gen_type [159] = Y2845_pgtype30;
	Y2845_gen_type [160] = Y2845_pgtype31;
	Y2845_gen_type [161] = Y2845_pgtype32;
	Y2845_gen_type [162] = Y2845_pgtype33;
	Y2845_gen_type [163] = Y2845_pgtype34;
	Y2845_gen_type [164] = Y2845_pgtype35;
	Y2845_gen_type [165] = Y2845_pgtype36;
	Y2845_gen_type [166] = Y2845_pgtype37;
	Y2845_gen_type [167] = Y2845_pgtype38;
	Y2845_gen_type [168] = Y2845_pgtype39;
	Y2845_gen_type [169] = Y2845_pgtype40;
	Y2845_gen_type [170] = Y2845_pgtype41;
	Y2845_gen_type [171] = Y2845_pgtype42;
	Y2845_gen_type [172] = Y2845_pgtype43;
	Y2845_gen_type [173] = Y2845_pgtype44;
	Y2845_gen_type [174] = Y2845_pgtype45;
	Y2845_gen_type [175] = Y2845_pgtype46;
	Y2845_gen_type [176] = Y2845_pgtype47;
	Y2845_gen_type [177] = Y2845_pgtype48;
	Y2845_gen_type [178] = Y2845_pgtype49;
	Y2845_gen_type [179] = Y2845_pgtype50;
	Y2845_gen_type [180] = Y2845_pgtype51;
	Y2845_gen_type [181] = Y2845_pgtype52;
	Y2845_gen_type [182] = Y2845_pgtype53;
	Y2845_gen_type [183] = Y2845_pgtype54;
	Y2845_gen_type [184] = Y2845_pgtype55;
	Y2845_gen_type [185] = Y2845_pgtype56;
	Y2845_gen_type [186] = Y2845_pgtype57;
	Y2845_gen_type [187] = Y2845_pgtype58;
	Y2845_gen_type [188] = Y2845_pgtype59;
	Y2845_gen_type [189] = Y2845_pgtype60;
	Y2845_gen_type [190] = Y2845_pgtype61;
	Y2845_gen_type [191] = Y2845_pgtype62;
	Y2845_gen_type [192] = Y2845_pgtype63;
	Y2845_gen_type [193] = Y2845_pgtype64;
	Y2845_gen_type [194] = Y2845_pgtype65;
	Y2845_gen_type [195] = Y2845_pgtype66;
	Y2845_gen_type [196] = Y2845_pgtype67;
	Y2845_gen_type [197] = Y2845_pgtype68;
	Y2845_gen_type [198] = Y2845_pgtype69;
	Y2845_gen_type [199] = Y2845_pgtype70;
	Y2845_gen_type [200] = Y2845_pgtype71;
	Y2845_gen_type [201] = Y2845_pgtype72;
	Y2845_gen_type [202] = Y2845_pgtype73;
	Y2845_gen_type [203] = Y2845_pgtype74;
	Y2845_gen_type [204] = Y2845_pgtype75;
	Y2845_gen_type [205] = Y2845_pgtype76;
	Y2845_gen_type [206] = Y2845_pgtype77;
	Y2845_gen_type [207] = Y2845_pgtype78;
	Y2845_gen_type [208] = Y2845_pgtype79;
	Y2845_gen_type [209] = Y2845_pgtype80;
	Y2845_gen_type [210] = Y2845_pgtype81;
	Y2845_gen_type [211] = Y2845_pgtype82;
	Y2845_gen_type [212] = Y2845_pgtype83;
	Y2845_gen_type [213] = Y2845_pgtype84;
	Y2845_gen_type [214] = Y2845_pgtype85;
	Y2845_gen_type [215] = Y2845_pgtype86;
	Y2845_gen_type [216] = Y2845_pgtype87;
	Y2845_gen_type [217] = Y2845_pgtype88;
	Y2845_gen_type [218] = Y2845_pgtype89;
	Y2845_gen_type [219] = Y2845_pgtype90;
	Y2845_gen_type [220] = Y2845_pgtype91;
	Y2845_gen_type [221] = Y2845_pgtype92;
	Y2845_gen_type [222] = Y2845_pgtype93;
	Y2845_gen_type [223] = Y2845_pgtype94;
	Y2845_gen_type [224] = Y2845_pgtype95;
	Y2845_gen_type [225] = Y2845_pgtype96;
	Y2845_gen_type [226] = Y2845_pgtype97;
	Y2845_gen_type [227] = Y2845_pgtype98;
	Y2845_gen_type [228] = Y2845_pgtype99;
	Y2845_gen_type [229] = Y2845_pgtype100;
	Y2845_gen_type [230] = Y2845_pgtype101;
	Y2845_gen_type [231] = Y2845_pgtype102;
	Y2845_gen_type [232] = Y2845_pgtype103;
	Y2845_gen_type [233] = Y2845_pgtype104;
	Y2845_gen_type [234] = Y2845_pgtype105;
	Y2845_gen_type [235] = Y2845_pgtype106;
	Y2845_gen_type [236] = Y2845_pgtype107;
	Y2845_gen_type [237] = Y2845_pgtype108;
	Y2845_gen_type [238] = Y2845_pgtype109;
	Y2845_gen_type [239] = Y2845_pgtype110;
	Y2845_gen_type [244] = Y2845_pgtype111;
	Y2845_gen_type [245] = Y2845_pgtype112;
	Y2845_gen_type [246] = Y2845_pgtype113;
	Y2845_gen_type [247] = Y2845_pgtype114;
	Y2845_gen_type [248] = Y2845_pgtype115;
	Y2845_gen_type [249] = Y2845_pgtype116;
	Y2845_gen_type [250] = Y2845_pgtype117;
	Y2845_gen_type [251] = Y2845_pgtype118;
	Y2845_gen_type [252] = Y2845_pgtype119;
	Y2845_gen_type [253] = Y2845_pgtype120;
	Y2845_gen_type [254] = Y2845_pgtype121;
	Y2845_gen_type [255] = Y2845_pgtype122;
	Y2845_gen_type [256] = Y2845_pgtype123;
	Y2845_gen_type [257] = Y2845_pgtype124;
	Y2845_gen_type [258] = Y2845_pgtype125;
	Y2845_gen_type [259] = Y2845_pgtype126;
	Y2845_gen_type [260] = Y2845_pgtype127;
	Y2845_gen_type [261] = Y2845_pgtype128;
	Y2845_gen_type [262] = Y2845_pgtype129;
	Y2845_gen_type [263] = Y2845_pgtype130;
	Y2845_gen_type [382] = Y2845_pgtype131;
	Y2845_gen_type [385] = Y2845_pgtype132;
	Y2845_gen_type [386] = Y2845_pgtype133;
	Y2845_gen_type [718] = Y2845_pgtype134;
	Y2845_gen_type [719] = Y2845_pgtype135;
	{long i; for (i = 159; i < 240; i++) Y2845[i] = 834;};
	{long i; for (i = 244; i < 256; i++) Y2845[i] = 834;};
	{long i; for (i = 261; i < 263; i++) Y2845[i] = 906;};
	Y2845[263] = 914;
	Y2845[382] = 834;
	{long i; for (i = 385; i < 387; i++) Y2845[i] = 834;};
	{long i; for (i = 718; i < 720; i++) Y2845[i] = 834;};
}

char *(*R2867[547])();
void R2867_init () {
	R2867[0] = (char *(*)()) F702_3697;
	R2867[1] = (char *(*)()) F703_3697;
	R2867[2] = (char *(*)()) F704_3697;
	R2867[3] = (char *(*)()) F705_3697;
	R2867[4] = (char *(*)()) F706_3697;
	R2867[5] = (char *(*)()) F707_3697;
	R2867[6] = (char *(*)()) F708_3697;
	R2867[7] = (char *(*)()) F709_3697;
	R2867[8] = (char *(*)()) F710_3697;
	R2867[9] = (char *(*)()) F711_3697;
	R2867[10] = (char *(*)()) F712_3697;
	R2867[11] = (char *(*)()) F713_3697;
	R2867[12] = (char *(*)()) F702_3697;
	R2867[13] = (char *(*)()) F703_3697;
	R2867[14] = (char *(*)()) F708_3697;
	R2867[15] = (char *(*)()) F705_3697;
	R2867[16] = (char *(*)()) F713_3697;
	R2867[17] = (char *(*)()) F707_3697;
	R2867[84] = (char *(*)()) F786_3980;
	R2867[85] = (char *(*)()) F787_3980;
	R2867[86] = (char *(*)()) F788_3980;
	R2867[87] = (char *(*)()) F789_3980;
	R2867[88] = (char *(*)()) F790_3980;
	R2867[91] = (char *(*)()) F786_3980;
	R2867[210] = (char *(*)()) F910_5605;
	R2867[213] = (char *(*)()) F913_5773;
	R2867[252] = (char *(*)()) F954_6246;
	R2867[349] = (char *(*)()) F662_3275;
	R2867[354] = (char *(*)()) F662_3275;
	R2867[546] = (char *(*)()) F1248_8958;
}

char *(*R2870[547])();
void R2870_init () {
	R2870[0] = (char *(*)()) F702_3698;
	R2870[1] = (char *(*)()) F703_3698;
	R2870[2] = (char *(*)()) F704_3698;
	R2870[3] = (char *(*)()) F705_3698;
	R2870[4] = (char *(*)()) F706_3698;
	R2870[5] = (char *(*)()) F707_3698;
	R2870[6] = (char *(*)()) F708_3698;
	R2870[7] = (char *(*)()) F709_3698;
	R2870[8] = (char *(*)()) F710_3698;
	R2870[9] = (char *(*)()) F711_3698;
	R2870[10] = (char *(*)()) F712_3698;
	R2870[11] = (char *(*)()) F713_3698;
	R2870[12] = (char *(*)()) F702_3698;
	R2870[13] = (char *(*)()) F703_3698;
	R2870[14] = (char *(*)()) F708_3698;
	R2870[15] = (char *(*)()) F705_3698;
	R2870[16] = (char *(*)()) F713_3698;
	R2870[17] = (char *(*)()) F707_3698;
	R2870[210] = (char *(*)()) F910_5604;
	R2870[213] = (char *(*)()) F913_5772;
	R2870[546] = (char *(*)()) F1248_8960;
}

char *(*R2874[547])();
void R2874_init () {
	R2874[0] = (char *(*)()) F626_3232;
	R2874[1] = (char *(*)()) F627_3232;
	R2874[2] = (char *(*)()) F628_3232;
	R2874[3] = (char *(*)()) F629_3232;
	R2874[4] = (char *(*)()) F630_3232;
	R2874[5] = (char *(*)()) F631_3232;
	R2874[6] = (char *(*)()) F632_3232;
	R2874[7] = (char *(*)()) F633_3232;
	R2874[8] = (char *(*)()) F634_3232;
	R2874[9] = (char *(*)()) F635_3232;
	R2874[10] = (char *(*)()) F636_3232;
	R2874[11] = (char *(*)()) F637_3232;
	R2874[12] = (char *(*)()) F626_3232;
	R2874[13] = (char *(*)()) F627_3232;
	R2874[14] = (char *(*)()) F632_3232;
	R2874[15] = (char *(*)()) F629_3232;
	R2874[16] = (char *(*)()) F637_3232;
	R2874[17] = (char *(*)()) F631_3232;
	R2874[210] = (char *(*)()) F630_3232;
	R2874[213] = (char *(*)()) F632_3232;
	R2874[546] = (char *(*)()) F632_3232;
}


#ifdef __cplusplus
}
#endif
