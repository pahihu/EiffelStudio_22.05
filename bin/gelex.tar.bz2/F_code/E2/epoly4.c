#include "eif_eiffel.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

long O1061[2];
void O1061_init () {
	O1061[0] = + _LNGOFF_1_0_0_1_;
	O1061[1] = + _LNGOFF_2_0_0_1_;
}

long O1134[6];
void O1134_init () {
	O1134[0] = 0;
	O1134[1] = + _LNGOFF_0_0_0_0_;
	O1134[2] = + _I64OFF_0_0_0_0_0_0_0_;
	O1134[3] = + _LNGOFF_0_0_0_0_;
	O1134[4] = 0;
	O1134[5] = + _LNGOFF_1_0_0_0_;
}

long O1302[124];
void O1302_init () {
	{long i; for (i = 0; i < 2; i++) O1302[i] = + _LNGOFF_2_4_0_0_;}
	O1302[2] = + _LNGOFF_4_6_0_0_;
	O1302[3] = + _LNGOFF_3_7_0_0_;
	O1302[4] = + _LNGOFF_3_6_0_0_;
	O1302[5] = + _LNGOFF_4_6_0_0_;
	O1302[6] = + _LNGOFF_5_6_0_0_;
	O1302[109] = + _LNGOFF_2_4_0_0_;
	O1302[122] = + _LNGOFF_6_6_0_0_;
	O1302[123] = + _LNGOFF_4_7_0_0_;
}

long O1303[124];
void O1303_init () {
	{long i; for (i = 0; i < 2; i++) O1303[i] = + _CHROFF_2_0_;}
	O1303[2] = + _CHROFF_4_0_;
	{long i; for (i = 3; i < 5; i++) O1303[i] = + _CHROFF_3_0_;}
	O1303[5] = + _CHROFF_4_0_;
	O1303[6] = + _CHROFF_5_0_;
	O1303[109] = + _CHROFF_2_0_;
	O1303[122] = + _CHROFF_6_0_;
	O1303[123] = + _CHROFF_4_0_;
}

long O1305[124];
void O1305_init () {
	{long i; for (i = 0; i < 2; i++) O1305[i] = + _CHROFF_2_1_;}
	O1305[2] = + _CHROFF_4_1_;
	{long i; for (i = 3; i < 5; i++) O1305[i] = + _CHROFF_3_1_;}
	O1305[5] = + _CHROFF_4_1_;
	O1305[6] = + _CHROFF_5_1_;
	O1305[109] = + _CHROFF_2_1_;
	O1305[122] = + _CHROFF_6_1_;
	O1305[123] = + _CHROFF_4_1_;
}

long O1306[124];
void O1306_init () {
	{long i; for (i = 0; i < 2; i++) O1306[i] = + _CHROFF_2_2_;}
	O1306[2] = + _CHROFF_4_2_;
	{long i; for (i = 3; i < 5; i++) O1306[i] = + _CHROFF_3_2_;}
	O1306[5] = + _CHROFF_4_2_;
	O1306[6] = + _CHROFF_5_2_;
	O1306[109] = + _CHROFF_2_2_;
	O1306[122] = + _CHROFF_6_2_;
	O1306[123] = + _CHROFF_4_2_;
}

long O1307[124];
void O1307_init () {
	{long i; for (i = 0; i < 2; i++) O1307[i] = + _CHROFF_2_3_;}
	O1307[2] = + _CHROFF_4_3_;
	{long i; for (i = 3; i < 5; i++) O1307[i] = + _CHROFF_3_3_;}
	O1307[5] = + _CHROFF_4_3_;
	O1307[6] = + _CHROFF_5_3_;
	O1307[109] = + _CHROFF_2_3_;
	O1307[122] = + _CHROFF_6_3_;
	O1307[123] = + _CHROFF_4_3_;
}

long O1326[122];
void O1326_init () {
	O1326[0] =  + _REFACS_2_;
	O1326[1] = + _CHROFF_3_4_;
	O1326[2] = + _LNGOFF_3_6_0_1_;
	O1326[3] = + _LNGOFF_4_6_0_1_;
	O1326[4] =  + _REFACS_2_;
	O1326[120] =  + _REFACS_2_;
	O1326[121] = + _CHROFF_4_4_;
}

long O1327[122];
void O1327_init () {
	O1327[0] =  + _REFACS_3_;
	{long i; for (i = 1; i < 4; i++) O1327[i] =  + _REFACS_2_;}
	O1327[4] =  + _REFACS_3_;
	O1327[120] =  + _REFACS_3_;
	O1327[121] =  + _REFACS_2_;
}

long O1334[122];
void O1334_init () {
	O1334[0] = + _CHROFF_4_5_;
	O1334[1] = + _CHROFF_3_6_;
	O1334[2] = + _CHROFF_3_5_;
	O1334[3] = + _CHROFF_4_5_;
	O1334[4] = + _CHROFF_5_5_;
	O1334[120] = + _CHROFF_6_5_;
	O1334[121] = + _CHROFF_4_6_;
}

long O1447[4];
void O1447_init () {
	O1447[0] = + _CHROFF_2_0_;
	O1447[1] = + _CHROFF_2_1_;
	{long i; for (i = 2; i < 4; i++) O1447[i] = + _CHROFF_2_0_;}
}

long O1448[4];
void O1448_init () {
	O1448[0] = + _CHROFF_2_1_;
	O1448[1] = + _CHROFF_2_2_;
	{long i; for (i = 2; i < 4; i++) O1448[i] = + _CHROFF_2_1_;}
}

long O1617[11];
void O1617_init () {
	O1617[0] = 0;
	O1617[1] = + _CHROFF_0_0_;
	O1617[2] = + _LNGOFF_0_0_0_0_;
	O1617[3] = + _CHROFF_0_0_;
	{long i; for (i = 4; i < 6; i++) O1617[i] = 0;}
	O1617[6] = + _CHROFF_1_0_;
	O1617[7] = + _LNGOFF_1_0_0_0_;
	O1617[8] = + _CHROFF_1_0_;
	O1617[9] = 0;
	O1617[10] = + _LNGOFF_2_0_0_0_;
}

long O1626[6];
void O1626_init () {
	O1626[0] =  + _REFACS_1_;
	{long i; for (i = 1; i < 4; i++) O1626[i] = 0;}
	O1626[4] =  + _REFACS_1_;
	O1626[5] = 0;
}

long O1629[2];
void O1629_init () {
	O1629[0] =  + _REFACS_2_;
	O1629[1] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y1720_pgtype0[] = {0xFF01,92,0xFFFF};
static EIF_TYPE_INDEX Y1720_pgtype1[] = {0xFF01,92,0xFFFF};
static EIF_TYPE_INDEX Y1720_pgtype2[] = {0xFF01,269,0xFFFF};
static EIF_TYPE_INDEX Y1720_pgtype3[] = {0xFF01,92,0xFFFF};
static EIF_TYPE_INDEX Y1720_pgtype4[] = {0xFF01,92,0xFFFF};
static EIF_TYPE_INDEX Y1720_pgtype5[] = {0xFF01,269,0xFFFF};
EIF_TYPE_INDEX *Y1720_gen_type [6];
EIF_TYPE_INDEX Y1720 [6];
void Y1720_init (void)
{
	egc_routines_types [1720] = Y1720;
	egc_routines_gen_types [1720] = Y1720_gen_type;
	egc_routines_offset [1720] = 165;
	Y1720_gen_type [0] = Y1720_pgtype0;
	Y1720_gen_type [1] = Y1720_pgtype1;
	Y1720_gen_type [2] = Y1720_pgtype2;
	Y1720_gen_type [3] = Y1720_pgtype3;
	Y1720_gen_type [4] = Y1720_pgtype4;
	Y1720_gen_type [5] = Y1720_pgtype5;
	{long i; for (i = 0; i < 2; i++) Y1720[i] = 92;};
	Y1720[2] = 269;
	{long i; for (i = 3; i < 5; i++) Y1720[i] = 92;};
	Y1720[5] = 269;
}

long O1721[6];
void O1721_init () {
	{long i; for (i = 0; i < 3; i++) O1721[i] = + _LNGOFF_1_3_0_0_;}
	{long i; for (i = 3; i < 5; i++) O1721[i] = + _LNGOFF_2_4_0_0_;}
	O1721[5] = + _LNGOFF_2_5_0_0_;
}

long O1722[6];
void O1722_init () {
	{long i; for (i = 0; i < 3; i++) O1722[i] = + _LNGOFF_1_3_0_1_;}
	{long i; for (i = 3; i < 5; i++) O1722[i] = + _LNGOFF_2_4_0_1_;}
	O1722[5] = + _LNGOFF_2_5_0_1_;
}

long O1723[6];
void O1723_init () {
	{long i; for (i = 0; i < 3; i++) O1723[i] = + _LNGOFF_1_3_0_2_;}
	{long i; for (i = 3; i < 5; i++) O1723[i] = + _LNGOFF_2_4_0_2_;}
	O1723[5] = + _LNGOFF_2_5_0_2_;
}

long O1724[6];
void O1724_init () {
	{long i; for (i = 0; i < 3; i++) O1724[i] = + _LNGOFF_1_3_0_3_;}
	{long i; for (i = 3; i < 5; i++) O1724[i] = + _LNGOFF_2_4_0_3_;}
	O1724[5] = + _LNGOFF_2_5_0_3_;
}

long O1725[6];
void O1725_init () {
	{long i; for (i = 0; i < 3; i++) O1725[i] = + _LNGOFF_1_3_0_4_;}
	{long i; for (i = 3; i < 5; i++) O1725[i] = + _LNGOFF_2_4_0_4_;}
	O1725[5] = + _LNGOFF_2_5_0_4_;
}

long O1726[6];
void O1726_init () {
	{long i; for (i = 0; i < 3; i++) O1726[i] = + _LNGOFF_1_3_0_5_;}
	{long i; for (i = 3; i < 5; i++) O1726[i] = + _LNGOFF_2_4_0_5_;}
	O1726[5] = + _LNGOFF_2_5_0_5_;
}

long O1727[6];
void O1727_init () {
	{long i; for (i = 0; i < 3; i++) O1727[i] = + _CHROFF_1_0_;}
	{long i; for (i = 3; i < 6; i++) O1727[i] = + _CHROFF_2_0_;}
}

long O1732[6];
void O1732_init () {
	{long i; for (i = 0; i < 3; i++) O1732[i] = + _CHROFF_1_1_;}
	{long i; for (i = 3; i < 6; i++) O1732[i] = + _CHROFF_2_1_;}
}

static EIF_TYPE_INDEX Y2242_pgtype0[] = {0xFF01,676,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype1[] = {0xFF01,677,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype2[] = {0xFF01,678,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype3[] = {0xFF01,679,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype4[] = {0xFF01,680,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype5[] = {0xFF01,681,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype6[] = {0xFF01,682,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype7[] = {0xFF01,683,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype8[] = {0xFF01,684,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype9[] = {0xFF01,685,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype10[] = {0xFF01,686,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype11[] = {0xFF01,687,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype12[] = {0xFF01,683,852,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype13[] = {0xFF01,683,852,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype14[] = {0xFF01,676,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype15[] = {0xFF01,677,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype16[] = {0xFF01,678,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype17[] = {0xFF01,679,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype18[] = {0xFF01,680,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype19[] = {0xFF01,681,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype20[] = {0xFF01,682,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype21[] = {0xFF01,683,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype22[] = {0xFF01,684,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype23[] = {0xFF01,685,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype24[] = {0xFF01,686,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype25[] = {0xFF01,687,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype26[] = {0xFF01,676,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype27[] = {0xFF01,677,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype28[] = {0xFF01,682,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype29[] = {0xFF01,679,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype30[] = {0xFF01,687,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype31[] = {0xFF01,681,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype32[] = {0xFF01,676,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype33[] = {0xFF01,677,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype34[] = {0xFF01,678,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype35[] = {0xFF01,679,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype36[] = {0xFF01,680,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype37[] = {0xFF01,681,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype38[] = {0xFF01,682,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype39[] = {0xFF01,683,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype40[] = {0xFF01,684,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype41[] = {0xFF01,685,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype42[] = {0xFF01,686,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype43[] = {0xFF01,687,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype44[] = {0xFF01,680,861,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype45[] = {0xFF01,682,864,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype46[] = {0xFF01,682,864,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype47[] = {0xFF01,682,864,0xFFFF};
static EIF_TYPE_INDEX Y2242_pgtype48[] = {0xFF01,682,864,0xFFFF};
EIF_TYPE_INDEX *Y2242_gen_type [1002];
EIF_TYPE_INDEX Y2242 [1002];
void Y2242_init (void)
{
	egc_routines_types [2242] = Y2242;
	egc_routines_gen_types [2242] = Y2242_gen_type;
	egc_routines_offset [2242] = 247;
	Y2242_gen_type [0] = Y2242_pgtype0;
	Y2242_gen_type [1] = Y2242_pgtype1;
	Y2242_gen_type [2] = Y2242_pgtype2;
	Y2242_gen_type [3] = Y2242_pgtype3;
	Y2242_gen_type [4] = Y2242_pgtype4;
	Y2242_gen_type [5] = Y2242_pgtype5;
	Y2242_gen_type [6] = Y2242_pgtype6;
	Y2242_gen_type [7] = Y2242_pgtype7;
	Y2242_gen_type [8] = Y2242_pgtype8;
	Y2242_gen_type [9] = Y2242_pgtype9;
	Y2242_gen_type [10] = Y2242_pgtype10;
	Y2242_gen_type [11] = Y2242_pgtype11;
	Y2242_gen_type [16] = Y2242_pgtype12;
	Y2242_gen_type [17] = Y2242_pgtype13;
	Y2242_gen_type [454] = Y2242_pgtype14;
	Y2242_gen_type [455] = Y2242_pgtype15;
	Y2242_gen_type [456] = Y2242_pgtype16;
	Y2242_gen_type [457] = Y2242_pgtype17;
	Y2242_gen_type [458] = Y2242_pgtype18;
	Y2242_gen_type [459] = Y2242_pgtype19;
	Y2242_gen_type [460] = Y2242_pgtype20;
	Y2242_gen_type [461] = Y2242_pgtype21;
	Y2242_gen_type [462] = Y2242_pgtype22;
	Y2242_gen_type [463] = Y2242_pgtype23;
	Y2242_gen_type [464] = Y2242_pgtype24;
	Y2242_gen_type [465] = Y2242_pgtype25;
	Y2242_gen_type [466] = Y2242_pgtype26;
	Y2242_gen_type [467] = Y2242_pgtype27;
	Y2242_gen_type [468] = Y2242_pgtype28;
	Y2242_gen_type [469] = Y2242_pgtype29;
	Y2242_gen_type [470] = Y2242_pgtype30;
	Y2242_gen_type [471] = Y2242_pgtype31;
	Y2242_gen_type [526] = Y2242_pgtype32;
	Y2242_gen_type [527] = Y2242_pgtype33;
	Y2242_gen_type [528] = Y2242_pgtype34;
	Y2242_gen_type [529] = Y2242_pgtype35;
	Y2242_gen_type [530] = Y2242_pgtype36;
	Y2242_gen_type [531] = Y2242_pgtype37;
	Y2242_gen_type [532] = Y2242_pgtype38;
	Y2242_gen_type [533] = Y2242_pgtype39;
	Y2242_gen_type [534] = Y2242_pgtype40;
	Y2242_gen_type [535] = Y2242_pgtype41;
	Y2242_gen_type [536] = Y2242_pgtype42;
	Y2242_gen_type [537] = Y2242_pgtype43;
	Y2242_gen_type [664] = Y2242_pgtype44;
	Y2242_gen_type [667] = Y2242_pgtype45;
	Y2242_gen_type [668] = Y2242_pgtype46;
	Y2242_gen_type [1000] = Y2242_pgtype47;
	Y2242_gen_type [1001] = Y2242_pgtype48;
	Y2242[0] = 676;
	Y2242[1] = 677;
	Y2242[2] = 678;
	Y2242[3] = 679;
	Y2242[4] = 680;
	Y2242[5] = 681;
	Y2242[6] = 682;
	Y2242[7] = 683;
	Y2242[8] = 684;
	Y2242[9] = 685;
	Y2242[10] = 686;
	Y2242[11] = 687;
	{long i; for (i = 16; i < 18; i++) Y2242[i] = 683;};
	Y2242[454] = 676;
	Y2242[455] = 677;
	Y2242[456] = 678;
	Y2242[457] = 679;
	Y2242[458] = 680;
	Y2242[459] = 681;
	Y2242[460] = 682;
	Y2242[461] = 683;
	Y2242[462] = 684;
	Y2242[463] = 685;
	Y2242[464] = 686;
	Y2242[465] = 687;
	Y2242[466] = 676;
	Y2242[467] = 677;
	Y2242[468] = 682;
	Y2242[469] = 679;
	Y2242[470] = 687;
	Y2242[471] = 681;
	Y2242[526] = 676;
	Y2242[527] = 677;
	Y2242[528] = 678;
	Y2242[529] = 679;
	Y2242[530] = 680;
	Y2242[531] = 681;
	Y2242[532] = 682;
	Y2242[533] = 683;
	Y2242[534] = 684;
	Y2242[535] = 685;
	Y2242[536] = 686;
	Y2242[537] = 687;
	Y2242[664] = 680;
	{long i; for (i = 667; i < 669; i++) Y2242[i] = 682;};
	{long i; for (i = 1000; i < 1002; i++) Y2242[i] = 682;};
}

long O2497[787];
void O2497_init () {
	O2497[0] = + _CHROFF_1_0_;
	O2497[389] = + _CHROFF_3_0_;
	O2497[390] = + _CHROFF_4_0_;
	O2497[391] = + _CHROFF_5_0_;
	O2497[681] = + _CHROFF_5_0_;
	O2497[778] = + _CHROFF_6_0_;
	{long i; for (i = 779; i < 782; i++) O2497[i] = + _CHROFF_5_0_;}
	O2497[783] = + _CHROFF_7_1_;
	{long i; for (i = 784; i < 787; i++) O2497[i] = + _CHROFF_6_1_;}
}

long O2498[787];
void O2498_init () {
	O2498[0] = 0;
	{long i; for (i = 389; i < 392; i++) O2498[i] = 0;}
	O2498[681] = 0;
	{long i; for (i = 778; i < 782; i++) O2498[i] = 0;}
	O2498[783] =  + _REFACS_6_;
	{long i; for (i = 784; i < 787; i++) O2498[i] =  + _REFACS_5_;}
}

long O2805[793];
void O2805_init () {
	{long i; for (i = 0; i < 205; i++) O2805[i] = + _CHROFF_0_0_;}
	O2805[205] = + _CHROFF_3_2_;
	O2805[206] = + _CHROFF_4_2_;
	O2805[207] = + _CHROFF_5_2_;
	{long i; for (i = 232; i < 245; i++) O2805[i] = + _CHROFF_0_0_;}
	{long i; for (i = 245; i < 263; i++) O2805[i] = + _CHROFF_1_0_;}
	{long i; for (i = 263; i < 311; i++) O2805[i] = + _CHROFF_0_0_;}
	{long i; for (i = 311; i < 313; i++) O2805[i] = + _CHROFF_2_0_;}
	{long i; for (i = 316; i < 329; i++) O2805[i] = + _CHROFF_1_0_;}
	O2805[329] = + _CHROFF_7_0_;
	O2805[330] = + _CHROFF_5_0_;
	O2805[331] = + _CHROFF_6_0_;
	O2805[332] = + _CHROFF_5_0_;
	O2805[333] = + _CHROFF_4_0_;
	O2805[334] = + _CHROFF_7_0_;
	O2805[335] = + _CHROFF_5_0_;
	O2805[336] = + _CHROFF_9_0_;
	O2805[455] = + _CHROFF_1_0_;
	{long i; for (i = 458; i < 460; i++) O2805[i] = + _CHROFF_1_0_;}
	O2805[497] = + _CHROFF_5_2_;
	O2805[594] = + _CHROFF_6_2_;
	{long i; for (i = 595; i < 598; i++) O2805[i] = + _CHROFF_5_2_;}
	O2805[599] = + _CHROFF_7_2_;
	{long i; for (i = 600; i < 603; i++) O2805[i] = + _CHROFF_6_2_;}
	{long i; for (i = 791; i < 793; i++) O2805[i] = + _CHROFF_1_0_;}
}

long O2894[398];
void O2894_init () {
	O2894[0] = + _PTROFF_3_6_2_4_1_0_;
	O2894[1] = + _PTROFF_4_6_2_4_1_0_;
	O2894[2] = + _PTROFF_5_7_2_4_1_0_;
	O2894[292] = + _PTROFF_5_7_2_4_1_0_;
	O2894[389] = + _PTROFF_6_7_2_4_1_0_;
	{long i; for (i = 390; i < 393; i++) O2894[i] = + _PTROFF_5_6_2_4_1_0_;}
	O2894[394] = + _PTROFF_7_8_2_4_1_0_;
	{long i; for (i = 395; i < 398; i++) O2894[i] = + _PTROFF_6_7_2_4_1_0_;}
}

long O2977[398];
void O2977_init () {
	{long i; for (i = 0; i < 3; i++) O2977[i] =  + _REFACS_1_;}
	O2977[292] =  + _REFACS_1_;
	{long i; for (i = 389; i < 393; i++) O2977[i] =  + _REFACS_1_;}
	{long i; for (i = 394; i < 398; i++) O2977[i] = 0;}
}

long O2979[398];
void O2979_init () {
	{long i; for (i = 0; i < 3; i++) O2979[i] =  + _REFACS_2_;}
	O2979[292] =  + _REFACS_2_;
	{long i; for (i = 389; i < 393; i++) O2979[i] =  + _REFACS_2_;}
	{long i; for (i = 394; i < 398; i++) O2979[i] =  + _REFACS_1_;}
}

long O3033[398];
void O3033_init () {
	O3033[0] = + _LNGOFF_3_6_2_3_;
	O3033[1] = + _LNGOFF_4_6_2_3_;
	O3033[2] = + _LNGOFF_5_7_2_3_;
	O3033[292] = + _LNGOFF_5_7_2_3_;
	O3033[389] = + _LNGOFF_6_7_2_3_;
	{long i; for (i = 390; i < 393; i++) O3033[i] = + _LNGOFF_5_6_2_3_;}
	O3033[394] = + _LNGOFF_7_8_2_3_;
	{long i; for (i = 395; i < 398; i++) O3033[i] = + _LNGOFF_6_7_2_3_;}
}

long O3042[398];
void O3042_init () {
	O3042[0] = + _CHROFF_3_3_;
	O3042[1] = + _CHROFF_4_3_;
	O3042[2] = + _CHROFF_5_3_;
	O3042[292] = + _CHROFF_5_3_;
	O3042[389] = + _CHROFF_6_3_;
	{long i; for (i = 390; i < 393; i++) O3042[i] = + _CHROFF_5_3_;}
	O3042[394] = + _CHROFF_7_3_;
	{long i; for (i = 395; i < 398; i++) O3042[i] = + _CHROFF_6_3_;}
}

long O3056[393];
void O3056_init () {
	O3056[0] =  + _REFACS_3_;
	O3056[290] =  + _REFACS_3_;
	O3056[387] =  + _REFACS_3_;
	O3056[392] =  + _REFACS_2_;
}

EIF_TYPE_INDEX *Y3241_gen_type [1];
EIF_TYPE_INDEX Y3241 [1];
void Y3241_init (void)
{
	egc_routines_types [3241] = Y3241;
	egc_routines_gen_types [3241] = Y3241_gen_type;
	egc_routines_offset [3241] = 772;
	Y3241[0] = 834;
}

long O3261[8];
void O3261_init () {
	O3261[0] = 0;
	O3261[1] = + _PTROFF_5_3_0_7_0_0_;
	O3261[2] = 0;
	O3261[3] = + _LNGOFF_5_3_0_0_;
	O3261[4] = + _LNGOFF_4_3_0_0_;
	O3261[5] = 0;
	O3261[6] = + _LNGOFF_5_4_0_0_;
	O3261[7] = 0;
}

long O3270[8];
void O3270_init () {
	O3270[0] = + _LNGOFF_7_3_0_0_;
	O3270[1] = + _LNGOFF_5_3_0_0_;
	O3270[2] = + _LNGOFF_6_3_0_0_;
	O3270[3] = + _LNGOFF_5_3_0_1_;
	O3270[4] = + _LNGOFF_4_3_0_1_;
	O3270[5] = + _LNGOFF_7_4_0_0_;
	O3270[6] = + _LNGOFF_5_4_0_1_;
	O3270[7] = + _LNGOFF_9_3_0_0_;
}

long O3297[8];
void O3297_init () {
	O3297[0] =  + _REFACS_1_;
	O3297[1] = 0;
	O3297[2] =  + _REFACS_1_;
	{long i; for (i = 3; i < 5; i++) O3297[i] = 0;}
	O3297[5] =  + _REFACS_1_;
	O3297[6] = 0;
	O3297[7] =  + _REFACS_1_;
}

static EIF_TYPE_INDEX Y3297_pgtype0[] = {0xFF01,676,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3297_pgtype1[] = {0xFF01,678,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3297_pgtype2[] = {0xFF01,676,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3297_pgtype3[] = {0xFF01,677,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3297_pgtype4[] = {0xFF01,677,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3297_pgtype5[] = {0xFF01,676,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3297_pgtype6[] = {0xFF01,677,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y3297_pgtype7[] = {0xFF01,676,0,0xFFFF};
EIF_TYPE_INDEX *Y3297_gen_type [8];
EIF_TYPE_INDEX Y3297 [8];
void Y3297_init (void)
{
	egc_routines_types [3297] = Y3297;
	egc_routines_gen_types [3297] = Y3297_gen_type;
	egc_routines_offset [3297] = 785;
	Y3297_gen_type [0] = Y3297_pgtype0;
	Y3297_gen_type [1] = Y3297_pgtype1;
	Y3297_gen_type [2] = Y3297_pgtype2;
	Y3297_gen_type [3] = Y3297_pgtype3;
	Y3297_gen_type [4] = Y3297_pgtype4;
	Y3297_gen_type [5] = Y3297_pgtype5;
	Y3297_gen_type [6] = Y3297_pgtype6;
	Y3297_gen_type [7] = Y3297_pgtype7;
	Y3297[0] = 676;
	Y3297[1] = 678;
	Y3297[2] = 676;
	{long i; for (i = 3; i < 5; i++) Y3297[i] = 677;};
	Y3297[5] = 676;
	Y3297[6] = 677;
	Y3297[7] = 676;
}

long O3298[8];
void O3298_init () {
	O3298[0] =  + _REFACS_2_;
	O3298[1] =  + _REFACS_1_;
	O3298[2] =  + _REFACS_2_;
	{long i; for (i = 3; i < 5; i++) O3298[i] =  + _REFACS_1_;}
	O3298[5] =  + _REFACS_2_;
	O3298[6] =  + _REFACS_1_;
	O3298[7] =  + _REFACS_2_;
}

static EIF_TYPE_INDEX Y3298_pgtype0[] = {0xFF01,676,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3298_pgtype1[] = {0xFF01,676,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3298_pgtype2[] = {0xFF01,677,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3298_pgtype3[] = {0xFF01,676,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3298_pgtype4[] = {0xFF01,677,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y3298_pgtype5[] = {0xFF01,676,0xFF01,906,0xFFFF};
static EIF_TYPE_INDEX Y3298_pgtype6[] = {0xFF01,676,0xFF01,906,0xFFFF};
static EIF_TYPE_INDEX Y3298_pgtype7[] = {0xFF01,676,0xFF01,914,0xFFFF};
EIF_TYPE_INDEX *Y3298_gen_type [8];
EIF_TYPE_INDEX Y3298 [8];
void Y3298_init (void)
{
	egc_routines_types [3298] = Y3298;
	egc_routines_gen_types [3298] = Y3298_gen_type;
	egc_routines_offset [3298] = 785;
	Y3298_gen_type [0] = Y3298_pgtype0;
	Y3298_gen_type [1] = Y3298_pgtype1;
	Y3298_gen_type [2] = Y3298_pgtype2;
	Y3298_gen_type [3] = Y3298_pgtype3;
	Y3298_gen_type [4] = Y3298_pgtype4;
	Y3298_gen_type [5] = Y3298_pgtype5;
	Y3298_gen_type [6] = Y3298_pgtype6;
	Y3298_gen_type [7] = Y3298_pgtype7;
	{long i; for (i = 0; i < 2; i++) Y3298[i] = 676;};
	Y3298[2] = 677;
	Y3298[3] = 676;
	Y3298[4] = 677;
	{long i; for (i = 5; i < 8; i++) Y3298[i] = 676;};
}

long O3299[8];
void O3299_init () {
	O3299[0] =  + _REFACS_3_;
	O3299[1] =  + _REFACS_2_;
	O3299[2] =  + _REFACS_3_;
	{long i; for (i = 3; i < 5; i++) O3299[i] =  + _REFACS_2_;}
	O3299[5] =  + _REFACS_3_;
	O3299[6] =  + _REFACS_2_;
	O3299[7] =  + _REFACS_3_;
}

long O3300[8];
void O3300_init () {
	O3300[0] =  + _REFACS_4_;
	O3300[1] =  + _REFACS_3_;
	O3300[2] =  + _REFACS_4_;
	{long i; for (i = 3; i < 5; i++) O3300[i] =  + _REFACS_3_;}
	O3300[5] =  + _REFACS_4_;
	O3300[6] =  + _REFACS_3_;
	O3300[7] =  + _REFACS_4_;
}

long O3301[8];
void O3301_init () {
	O3301[0] = + _LNGOFF_7_3_0_1_;
	O3301[1] = + _LNGOFF_5_3_0_1_;
	O3301[2] = + _LNGOFF_6_3_0_1_;
	O3301[3] = + _LNGOFF_5_3_0_2_;
	O3301[4] = + _LNGOFF_4_3_0_2_;
	O3301[5] = + _LNGOFF_7_4_0_1_;
	O3301[6] = + _LNGOFF_5_4_0_2_;
	O3301[7] = + _LNGOFF_9_3_0_1_;
}

long O3302[8];
void O3302_init () {
	O3302[0] = + _CHROFF_7_2_;
	O3302[1] = + _CHROFF_5_2_;
	O3302[2] = + _CHROFF_6_2_;
	O3302[3] = + _CHROFF_5_2_;
	O3302[4] = + _CHROFF_4_2_;
	O3302[5] = + _CHROFF_7_2_;
	O3302[6] = + _CHROFF_5_2_;
	O3302[7] = + _CHROFF_9_2_;
}

long O3303[8];
void O3303_init () {
	O3303[0] = + _LNGOFF_7_3_0_2_;
	O3303[1] = + _LNGOFF_5_3_0_2_;
	O3303[2] = + _LNGOFF_6_3_0_2_;
	O3303[3] = + _LNGOFF_5_3_0_3_;
	O3303[4] = + _LNGOFF_4_3_0_3_;
	O3303[5] = + _LNGOFF_7_4_0_2_;
	O3303[6] = + _LNGOFF_5_4_0_3_;
	O3303[7] = + _LNGOFF_9_3_0_2_;
}

long O3306[8];
void O3306_init () {
	O3306[0] = + _LNGOFF_7_3_0_3_;
	O3306[1] = + _LNGOFF_5_3_0_3_;
	O3306[2] = + _LNGOFF_6_3_0_3_;
	O3306[3] = + _LNGOFF_5_3_0_4_;
	O3306[4] = + _LNGOFF_4_3_0_4_;
	O3306[5] = + _LNGOFF_7_4_0_3_;
	O3306[6] = + _LNGOFF_5_4_0_4_;
	O3306[7] = + _LNGOFF_9_3_0_3_;
}

long O3307[8];
void O3307_init () {
	O3307[0] = + _LNGOFF_7_3_0_4_;
	O3307[1] = + _LNGOFF_5_3_0_4_;
	O3307[2] = + _LNGOFF_6_3_0_4_;
	O3307[3] = + _LNGOFF_5_3_0_5_;
	O3307[4] = + _LNGOFF_4_3_0_5_;
	O3307[5] = + _LNGOFF_7_4_0_4_;
	O3307[6] = + _LNGOFF_5_4_0_5_;
	O3307[7] = + _LNGOFF_9_3_0_4_;
}

long O3311[8];
void O3311_init () {
	O3311[0] = + _LNGOFF_7_3_0_5_;
	O3311[1] = + _LNGOFF_5_3_0_5_;
	O3311[2] = + _LNGOFF_6_3_0_5_;
	O3311[3] = + _LNGOFF_5_3_0_6_;
	O3311[4] = + _LNGOFF_4_3_0_6_;
	O3311[5] = + _LNGOFF_7_4_0_5_;
	O3311[6] = + _LNGOFF_5_4_0_6_;
	O3311[7] = + _LNGOFF_9_3_0_5_;
}

long O3312[8];
void O3312_init () {
	O3312[0] =  + _REFACS_5_;
	O3312[1] = + _PTROFF_5_3_0_7_0_1_;
	O3312[2] =  + _REFACS_5_;
	O3312[3] = + _LNGOFF_5_3_0_7_;
	O3312[4] = + _LNGOFF_4_3_0_7_;
	O3312[5] =  + _REFACS_5_;
	O3312[6] = + _LNGOFF_5_4_0_7_;
	O3312[7] =  + _REFACS_5_;
}

long O3313[8];
void O3313_init () {
	O3313[0] =  + _REFACS_6_;
	O3313[1] =  + _REFACS_4_;
	O3313[2] = + _LNGOFF_6_3_0_6_;
	O3313[3] =  + _REFACS_4_;
	O3313[4] = + _LNGOFF_4_3_0_8_;
	O3313[5] =  + _REFACS_6_;
	O3313[6] =  + _REFACS_4_;
	O3313[7] =  + _REFACS_6_;
}

long O3347[8];
void O3347_init () {
	O3347[0] = + _LNGOFF_7_3_0_6_;
	O3347[1] = + _LNGOFF_5_3_0_6_;
	O3347[2] = + _LNGOFF_6_3_0_7_;
	O3347[3] = + _LNGOFF_5_3_0_8_;
	O3347[4] = + _LNGOFF_4_3_0_9_;
	O3347[5] = + _LNGOFF_7_4_0_6_;
	O3347[6] = + _LNGOFF_5_4_0_8_;
	O3347[7] = + _LNGOFF_9_3_0_6_;
}

long O4251[3];
void O4251_init () {
	O4251[0] =  + _REFACS_4_;
	{long i; for (i = 1; i < 3; i++) O4251[i] = + _CHROFF_4_2_;}
}

long O4350[343];
void O4350_init () {
	{long i; for (i = 0; i < 3; i++) O4350[i] = + _LNGOFF_0_0_0_0_;}
	{long i; for (i = 3; i < 5; i++) O4350[i] = + _LNGOFF_1_0_0_0_;}
	O4350[5] = + _LNGOFF_1_1_0_0_;
	{long i; for (i = 6; i < 8; i++) O4350[i] = + _LNGOFF_1_0_0_0_;}
	{long i; for (i = 8; i < 10; i++) O4350[i] = + _LNGOFF_1_1_0_0_;}
	{long i; for (i = 341; i < 343; i++) O4350[i] = + _LNGOFF_1_1_0_0_;}
}

long O4351[343];
void O4351_init () {
	{long i; for (i = 0; i < 3; i++) O4351[i] = + _LNGOFF_0_0_0_1_;}
	{long i; for (i = 3; i < 5; i++) O4351[i] = + _LNGOFF_1_0_0_1_;}
	O4351[5] = + _LNGOFF_1_1_0_1_;
	{long i; for (i = 6; i < 8; i++) O4351[i] = + _LNGOFF_1_0_0_1_;}
	{long i; for (i = 8; i < 10; i++) O4351[i] = + _LNGOFF_1_1_0_1_;}
	{long i; for (i = 341; i < 343; i++) O4351[i] = + _LNGOFF_1_1_0_1_;}
}

long O4416[3];
void O4416_init () {
	{long i; for (i = 0; i < 2; i++) O4416[i] = + _LNGOFF_1_0_0_2_;}
	O4416[2] = + _LNGOFF_1_1_0_2_;
}

long O4496[337];
void O4496_init () {
	{long i; for (i = 0; i < 2; i++) O4496[i] = + _LNGOFF_1_0_0_2_;}
	{long i; for (i = 2; i < 4; i++) O4496[i] = + _LNGOFF_1_1_0_2_;}
	{long i; for (i = 335; i < 337; i++) O4496[i] = + _LNGOFF_1_1_0_2_;}
}

long O5332[11];
void O5332_init () {
	{long i; for (i = 0; i < 2; i++) O5332[i] = 0;}
	O5332[2] =  + _REFACS_5_;
	{long i; for (i = 3; i < 6; i++) O5332[i] =  + _REFACS_4_;}
	O5332[6] = 0;
	O5332[7] =  + _REFACS_4_;
	{long i; for (i = 8; i < 11; i++) O5332[i] =  + _REFACS_3_;}
}

long O5360[17];
void O5360_init () {
	O5360[0] = + _LNGOFF_5_2_0_0_;
	O5360[1] = + _LNGOFF_10_4_0_15_;
	O5360[2] = + _LNGOFF_11_4_0_0_;
	O5360[3] = + _LNGOFF_25_8_0_21_;
	O5360[4] = + _LNGOFF_6_3_0_0_;
	O5360[5] = + _LNGOFF_14_5_0_15_;
	O5360[14] = + _LNGOFF_10_11_0_0_;
	O5360[15] = + _LNGOFF_20_14_0_0_;
	O5360[16] = + _LNGOFF_11_12_0_0_;
}

long O5361[17];
void O5361_init () {
	O5361[0] = + _LNGOFF_5_2_0_1_;
	O5361[1] = + _LNGOFF_10_4_0_16_;
	O5361[2] = + _LNGOFF_11_4_0_1_;
	O5361[3] = + _LNGOFF_25_8_0_22_;
	O5361[4] = + _LNGOFF_6_3_0_1_;
	O5361[5] = + _LNGOFF_14_5_0_16_;
	O5361[14] = + _LNGOFF_10_11_0_1_;
	O5361[15] = + _LNGOFF_20_14_0_1_;
	O5361[16] = + _LNGOFF_11_12_0_1_;
}

long O5362[17];
void O5362_init () {
	O5362[0] = + _LNGOFF_5_2_0_2_;
	O5362[1] = + _LNGOFF_10_4_0_17_;
	O5362[2] = + _LNGOFF_11_4_0_2_;
	O5362[3] = + _LNGOFF_25_8_0_23_;
	O5362[4] = + _LNGOFF_6_3_0_2_;
	O5362[5] = + _LNGOFF_14_5_0_17_;
	O5362[14] = + _LNGOFF_10_11_0_2_;
	O5362[15] = + _LNGOFF_20_14_0_2_;
	O5362[16] = + _LNGOFF_11_12_0_2_;
}

long O5363[17];
void O5363_init () {
	O5363[0] = + _LNGOFF_5_2_0_3_;
	O5363[1] = + _LNGOFF_10_4_0_18_;
	O5363[2] = + _LNGOFF_11_4_0_3_;
	O5363[3] = + _LNGOFF_25_8_0_24_;
	O5363[4] = + _LNGOFF_6_3_0_3_;
	O5363[5] = + _LNGOFF_14_5_0_18_;
	O5363[14] = + _LNGOFF_10_11_0_3_;
	O5363[15] = + _LNGOFF_20_14_0_3_;
	O5363[16] = + _LNGOFF_11_12_0_3_;
}

long O5364[17];
void O5364_init () {
	O5364[0] = + _CHROFF_5_0_;
	O5364[1] = + _CHROFF_10_2_;
	O5364[2] = + _CHROFF_11_0_;
	O5364[3] = + _CHROFF_25_3_;
	O5364[4] = + _CHROFF_6_0_;
	O5364[5] = + _CHROFF_14_2_;
	O5364[14] = + _CHROFF_10_0_;
	O5364[15] = + _CHROFF_20_0_;
	O5364[16] = + _CHROFF_11_0_;
}

long O5365[17];
void O5365_init () {
	O5365[0] = + _CHROFF_5_1_;
	O5365[1] = + _CHROFF_10_3_;
	O5365[2] = + _CHROFF_11_1_;
	O5365[3] = + _CHROFF_25_4_;
	O5365[4] = + _CHROFF_6_1_;
	O5365[5] = + _CHROFF_14_3_;
	O5365[14] = + _CHROFF_10_1_;
	O5365[15] = + _CHROFF_20_1_;
	O5365[16] = + _CHROFF_11_1_;
}

long O5465[4];
void O5465_init () {
	O5465[0] = + _LNGOFF_2_0_0_0_;
	O5465[1] = + _LNGOFF_10_11_0_4_;
	O5465[2] = + _LNGOFF_20_14_0_7_;
	O5465[3] = + _LNGOFF_11_12_0_5_;
}

long O5466[4];
void O5466_init () {
	O5466[0] = + _LNGOFF_2_0_0_1_;
	O5466[1] = + _LNGOFF_10_11_0_5_;
	O5466[2] = + _LNGOFF_20_14_0_8_;
	O5466[3] = + _LNGOFF_11_12_0_6_;
}

long O5467[4];
void O5467_init () {
	O5467[0] = + _LNGOFF_2_0_0_2_;
	O5467[1] = + _LNGOFF_10_11_0_6_;
	O5467[2] = + _LNGOFF_20_14_0_9_;
	O5467[3] = + _LNGOFF_11_12_0_7_;
}

long O5469[4];
void O5469_init () {
	O5469[0] = 0;
	O5469[1] =  + _REFACS_5_;
	O5469[2] =  + _REFACS_11_;
	O5469[3] =  + _REFACS_6_;
}

long O5471[4];
void O5471_init () {
	O5471[0] =  + _REFACS_1_;
	O5471[1] =  + _REFACS_6_;
	O5471[2] =  + _REFACS_12_;
	O5471[3] =  + _REFACS_7_;
}

long O5504[3];
void O5504_init () {
	O5504[0] =  + _REFACS_7_;
	O5504[1] =  + _REFACS_13_;
	O5504[2] =  + _REFACS_8_;
}

long O5505[3];
void O5505_init () {
	O5505[0] = + _CHROFF_10_2_;
	O5505[1] = + _CHROFF_20_4_;
	O5505[2] = + _CHROFF_11_3_;
}

long O5506[3];
void O5506_init () {
	O5506[0] =  + _REFACS_8_;
	O5506[1] =  + _REFACS_14_;
	O5506[2] =  + _REFACS_9_;
}

long O5507[3];
void O5507_init () {
	O5507[0] =  + _REFACS_9_;
	O5507[1] =  + _REFACS_15_;
	O5507[2] =  + _REFACS_10_;
}

long O5508[3];
void O5508_init () {
	O5508[0] = + _CHROFF_10_3_;
	O5508[1] = + _CHROFF_20_5_;
	O5508[2] = + _CHROFF_11_4_;
}

long O5509[3];
void O5509_init () {
	O5509[0] = + _CHROFF_10_4_;
	O5509[1] = + _CHROFF_20_6_;
	O5509[2] = + _CHROFF_11_5_;
}

long O5510[3];
void O5510_init () {
	O5510[0] = + _CHROFF_10_5_;
	O5510[1] = + _CHROFF_20_7_;
	O5510[2] = + _CHROFF_11_6_;
}

long O5511[3];
void O5511_init () {
	O5511[0] = + _CHROFF_10_6_;
	O5511[1] = + _CHROFF_20_8_;
	O5511[2] = + _CHROFF_11_7_;
}

long O5512[3];
void O5512_init () {
	O5512[0] = + _CHROFF_10_7_;
	O5512[1] = + _CHROFF_20_9_;
	O5512[2] = + _CHROFF_11_8_;
}

long O5513[3];
void O5513_init () {
	O5513[0] = + _CHROFF_10_8_;
	O5513[1] = + _CHROFF_20_10_;
	O5513[2] = + _CHROFF_11_9_;
}

long O5514[3];
void O5514_init () {
	O5514[0] = + _LNGOFF_10_11_0_8_;
	O5514[1] = + _LNGOFF_20_14_0_11_;
	O5514[2] = + _LNGOFF_11_12_0_9_;
}

long O5515[3];
void O5515_init () {
	O5515[0] = + _CHROFF_10_9_;
	O5515[1] = + _CHROFF_20_11_;
	O5515[2] = + _CHROFF_11_10_;
}

long O5516[3];
void O5516_init () {
	O5516[0] = + _CHROFF_10_10_;
	O5516[1] = + _CHROFF_20_12_;
	O5516[2] = + _CHROFF_11_11_;
}

static EIF_TYPE_INDEX Y5622_pgtype0[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype1[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype2[] = {227,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype3[] = {228,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype4[] = {229,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype5[] = {230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype6[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype7[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype8[] = {227,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype9[] = {228,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype10[] = {229,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype11[] = {230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype12[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype13[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype14[] = {227,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype15[] = {228,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype16[] = {229,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype17[] = {230,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype18[] = {225,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype19[] = {226,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype20[] = {226,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype21[] = {230,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype22[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype23[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype24[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype25[] = {229,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype26[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype27[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype28[] = {227,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype29[] = {228,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype30[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype31[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype32[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype33[] = {228,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype34[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype35[] = {228,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype36[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype37[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype38[] = {227,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype39[] = {228,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype40[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype41[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype42[] = {227,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype43[] = {228,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype44[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype45[] = {227,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype46[] = {228,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype47[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype48[] = {225,0xFF01,1066,0xFF01,1069,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype49[] = {225,0xFF01,115,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype50[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype51[] = {225,0xFF01,47,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype52[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype53[] = {228,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype54[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype55[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype56[] = {225,0xFF01,44,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype57[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype58[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype59[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype60[] = {229,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype61[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype62[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype63[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype64[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype65[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype66[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype67[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype68[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype69[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype70[] = {229,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype71[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype72[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype73[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype74[] = {229,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype75[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype76[] = {225,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype77[] = {226,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5622_pgtype78[] = {229,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5622_gen_type [83];
EIF_TYPE_INDEX Y5622 [83];
void Y5622_init (void)
{
	egc_routines_types [5622] = Y5622;
	egc_routines_gen_types [5622] = Y5622_gen_type;
	egc_routines_offset [5622] = 1100;
	Y5622_gen_type [0] = Y5622_pgtype0;
	Y5622_gen_type [1] = Y5622_pgtype1;
	Y5622_gen_type [2] = Y5622_pgtype2;
	Y5622_gen_type [3] = Y5622_pgtype3;
	Y5622_gen_type [4] = Y5622_pgtype4;
	Y5622_gen_type [5] = Y5622_pgtype5;
	Y5622_gen_type [6] = Y5622_pgtype6;
	Y5622_gen_type [7] = Y5622_pgtype7;
	Y5622_gen_type [8] = Y5622_pgtype8;
	Y5622_gen_type [9] = Y5622_pgtype9;
	Y5622_gen_type [10] = Y5622_pgtype10;
	Y5622_gen_type [11] = Y5622_pgtype11;
	Y5622_gen_type [12] = Y5622_pgtype12;
	Y5622_gen_type [13] = Y5622_pgtype13;
	Y5622_gen_type [14] = Y5622_pgtype14;
	Y5622_gen_type [15] = Y5622_pgtype15;
	Y5622_gen_type [16] = Y5622_pgtype16;
	Y5622_gen_type [17] = Y5622_pgtype17;
	Y5622_gen_type [18] = Y5622_pgtype18;
	Y5622_gen_type [19] = Y5622_pgtype19;
	Y5622_gen_type [20] = Y5622_pgtype20;
	Y5622_gen_type [21] = Y5622_pgtype21;
	Y5622_gen_type [22] = Y5622_pgtype22;
	Y5622_gen_type [23] = Y5622_pgtype23;
	Y5622_gen_type [24] = Y5622_pgtype24;
	Y5622_gen_type [25] = Y5622_pgtype25;
	Y5622_gen_type [26] = Y5622_pgtype26;
	Y5622_gen_type [27] = Y5622_pgtype27;
	Y5622_gen_type [28] = Y5622_pgtype28;
	Y5622_gen_type [29] = Y5622_pgtype29;
	Y5622_gen_type [30] = Y5622_pgtype30;
	Y5622_gen_type [31] = Y5622_pgtype31;
	Y5622_gen_type [32] = Y5622_pgtype32;
	Y5622_gen_type [33] = Y5622_pgtype33;
	Y5622_gen_type [34] = Y5622_pgtype34;
	Y5622_gen_type [35] = Y5622_pgtype35;
	Y5622_gen_type [36] = Y5622_pgtype36;
	Y5622_gen_type [37] = Y5622_pgtype37;
	Y5622_gen_type [38] = Y5622_pgtype38;
	Y5622_gen_type [39] = Y5622_pgtype39;
	Y5622_gen_type [40] = Y5622_pgtype40;
	Y5622_gen_type [41] = Y5622_pgtype41;
	Y5622_gen_type [42] = Y5622_pgtype42;
	Y5622_gen_type [43] = Y5622_pgtype43;
	Y5622_gen_type [44] = Y5622_pgtype44;
	Y5622_gen_type [45] = Y5622_pgtype45;
	Y5622_gen_type [46] = Y5622_pgtype46;
	Y5622_gen_type [47] = Y5622_pgtype47;
	Y5622_gen_type [48] = Y5622_pgtype48;
	Y5622_gen_type [49] = Y5622_pgtype49;
	Y5622_gen_type [50] = Y5622_pgtype50;
	Y5622_gen_type [51] = Y5622_pgtype51;
	Y5622_gen_type [56] = Y5622_pgtype52;
	Y5622_gen_type [57] = Y5622_pgtype53;
	Y5622_gen_type [58] = Y5622_pgtype54;
	Y5622_gen_type [59] = Y5622_pgtype55;
	Y5622_gen_type [60] = Y5622_pgtype56;
	Y5622_gen_type [61] = Y5622_pgtype57;
	Y5622_gen_type [62] = Y5622_pgtype58;
	Y5622_gen_type [63] = Y5622_pgtype59;
	Y5622_gen_type [64] = Y5622_pgtype60;
	Y5622_gen_type [65] = Y5622_pgtype61;
	Y5622_gen_type [66] = Y5622_pgtype62;
	Y5622_gen_type [67] = Y5622_pgtype63;
	Y5622_gen_type [68] = Y5622_pgtype64;
	Y5622_gen_type [69] = Y5622_pgtype65;
	Y5622_gen_type [70] = Y5622_pgtype66;
	Y5622_gen_type [71] = Y5622_pgtype67;
	Y5622_gen_type [72] = Y5622_pgtype68;
	Y5622_gen_type [73] = Y5622_pgtype69;
	Y5622_gen_type [74] = Y5622_pgtype70;
	Y5622_gen_type [75] = Y5622_pgtype71;
	Y5622_gen_type [76] = Y5622_pgtype72;
	Y5622_gen_type [77] = Y5622_pgtype73;
	Y5622_gen_type [78] = Y5622_pgtype74;
	Y5622_gen_type [79] = Y5622_pgtype75;
	Y5622_gen_type [80] = Y5622_pgtype76;
	Y5622_gen_type [81] = Y5622_pgtype77;
	Y5622_gen_type [82] = Y5622_pgtype78;
	Y5622[0] = 225;
	Y5622[1] = 226;
	Y5622[2] = 227;
	Y5622[3] = 228;
	Y5622[4] = 229;
	Y5622[5] = 230;
	Y5622[6] = 225;
	Y5622[7] = 226;
	Y5622[8] = 227;
	Y5622[9] = 228;
	Y5622[10] = 229;
	Y5622[11] = 230;
	Y5622[12] = 225;
	Y5622[13] = 226;
	Y5622[14] = 227;
	Y5622[15] = 228;
	Y5622[16] = 229;
	Y5622[17] = 230;
	Y5622[18] = 225;
	{long i; for (i = 19; i < 21; i++) Y5622[i] = 226;};
	Y5622[21] = 230;
	{long i; for (i = 22; i < 24; i++) Y5622[i] = 225;};
	Y5622[24] = 226;
	Y5622[25] = 229;
	Y5622[26] = 225;
	Y5622[27] = 226;
	Y5622[28] = 227;
	Y5622[29] = 228;
	Y5622[30] = 225;
	{long i; for (i = 31; i < 33; i++) Y5622[i] = 226;};
	Y5622[33] = 228;
	Y5622[34] = 226;
	Y5622[35] = 228;
	Y5622[36] = 225;
	Y5622[37] = 226;
	Y5622[38] = 227;
	Y5622[39] = 228;
	Y5622[40] = 225;
	Y5622[41] = 226;
	Y5622[42] = 227;
	Y5622[43] = 228;
	Y5622[44] = 225;
	Y5622[45] = 227;
	Y5622[46] = 228;
	Y5622[47] = 226;
	{long i; for (i = 48; i < 52; i++) Y5622[i] = 225;};
	Y5622[56] = 226;
	Y5622[57] = 228;
	Y5622[58] = 225;
	Y5622[59] = 226;
	{long i; for (i = 60; i < 63; i++) Y5622[i] = 225;};
	Y5622[63] = 226;
	Y5622[64] = 229;
	Y5622[65] = 225;
	Y5622[66] = 226;
	Y5622[67] = 225;
	Y5622[68] = 226;
	Y5622[69] = 225;
	Y5622[70] = 226;
	{long i; for (i = 71; i < 73; i++) Y5622[i] = 225;};
	Y5622[73] = 226;
	Y5622[74] = 229;
	{long i; for (i = 75; i < 77; i++) Y5622[i] = 225;};
	Y5622[77] = 226;
	Y5622[78] = 229;
	{long i; for (i = 79; i < 81; i++) Y5622[i] = 225;};
	Y5622[81] = 226;
	Y5622[82] = 229;
}

static EIF_TYPE_INDEX Y5655_pgtype0[] = {0xFF01,1171,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5655_pgtype1[] = {0xFF01,1172,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5655_pgtype2[] = {0xFF01,1173,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5655_pgtype3[] = {0xFF01,1174,0xFFF8,1,0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y5655_gen_type [4];
EIF_TYPE_INDEX Y5655 [4];
void Y5655_init (void)
{
	egc_routines_types [5655] = Y5655;
	egc_routines_gen_types [5655] = Y5655_gen_type;
	egc_routines_offset [5655] = 1118;
	Y5655_gen_type [0] = Y5655_pgtype0;
	Y5655_gen_type [1] = Y5655_pgtype1;
	Y5655_gen_type [2] = Y5655_pgtype2;
	Y5655_gen_type [3] = Y5655_pgtype3;
	Y5655[0] = 1171;
	Y5655[1] = 1172;
	Y5655[2] = 1173;
	Y5655[3] = 1174;
}

static EIF_TYPE_INDEX Y5753_pgtype0[] = {153,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5753_pgtype1[] = {154,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5753_pgtype2[] = {156,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5753_pgtype3[] = {155,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5753_pgtype4[] = {153,0xFF01,1066,0xFF01,1069,0xFFFF};
static EIF_TYPE_INDEX Y5753_pgtype5[] = {153,0xFF01,115,0xFFFF};
static EIF_TYPE_INDEX Y5753_pgtype6[] = {157,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5753_pgtype7[] = {157,0xFF01,47,0xFFFF};
EIF_TYPE_INDEX *Y5753_gen_type [8];
EIF_TYPE_INDEX Y5753 [8];
void Y5753_init (void)
{
	egc_routines_types [5753] = Y5753;
	egc_routines_gen_types [5753] = Y5753_gen_type;
	egc_routines_offset [5753] = 1144;
	Y5753_gen_type [0] = Y5753_pgtype0;
	Y5753_gen_type [1] = Y5753_pgtype1;
	Y5753_gen_type [2] = Y5753_pgtype2;
	Y5753_gen_type [3] = Y5753_pgtype3;
	Y5753_gen_type [4] = Y5753_pgtype4;
	Y5753_gen_type [5] = Y5753_pgtype5;
	Y5753_gen_type [6] = Y5753_pgtype6;
	Y5753_gen_type [7] = Y5753_pgtype7;
	Y5753[0] = 153;
	Y5753[1] = 154;
	Y5753[2] = 156;
	Y5753[3] = 155;
	{long i; for (i = 4; i < 6; i++) Y5753[i] = 153;};
	{long i; for (i = 6; i < 8; i++) Y5753[i] = 157;};
}

long O5761[8];
void O5761_init () {
	{long i; for (i = 0; i < 4; i++) O5761[i] = + _LNGOFF_4_0_0_0_;}
	O5761[4] = + _LNGOFF_5_0_0_0_;
	O5761[5] = + _LNGOFF_6_0_0_0_;
	{long i; for (i = 6; i < 8; i++) O5761[i] = + _LNGOFF_4_0_0_0_;}
}

static EIF_TYPE_INDEX Y5794_pgtype0[] = {0xFF01,19,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5794_pgtype1[] = {0xFF01,20,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5794_pgtype2[] = {0xFF01,19,0xFF01,44,0xFFFF};
EIF_TYPE_INDEX *Y5794_gen_type [3];
EIF_TYPE_INDEX Y5794 [3];
void Y5794_init (void)
{
	egc_routines_types [5794] = Y5794;
	egc_routines_gen_types [5794] = Y5794_gen_type;
	egc_routines_offset [5794] = 1158;
	Y5794_gen_type [0] = Y5794_pgtype0;
	Y5794_gen_type [1] = Y5794_pgtype1;
	Y5794_gen_type [2] = Y5794_pgtype2;
	Y5794[0] = 19;
	Y5794[1] = 20;
	Y5794[2] = 19;
}

long O5820[22];
void O5820_init () {
	{long i; for (i = 0; i < 6; i++) O5820[i] = + _LNGOFF_2_0_0_0_;}
	{long i; for (i = 6; i < 8; i++) O5820[i] = + _LNGOFF_6_0_0_0_;}
	{long i; for (i = 8; i < 10; i++) O5820[i] = + _LNGOFF_7_0_0_0_;}
	{long i; for (i = 10; i < 14; i++) O5820[i] = + _LNGOFF_4_0_0_0_;}
	{long i; for (i = 14; i < 18; i++) O5820[i] = + _LNGOFF_10_0_0_0_;}
	{long i; for (i = 18; i < 22; i++) O5820[i] = + _LNGOFF_11_0_0_0_;}
}

long O5855[22];
void O5855_init () {
	{long i; for (i = 0; i < 6; i++) O5855[i] = + _LNGOFF_2_0_0_1_;}
	{long i; for (i = 6; i < 8; i++) O5855[i] = + _LNGOFF_6_0_0_1_;}
	{long i; for (i = 8; i < 10; i++) O5855[i] = + _LNGOFF_7_0_0_1_;}
	{long i; for (i = 10; i < 14; i++) O5855[i] = + _LNGOFF_4_0_0_1_;}
	{long i; for (i = 14; i < 18; i++) O5855[i] = + _LNGOFF_10_0_0_1_;}
	{long i; for (i = 18; i < 22; i++) O5855[i] = + _LNGOFF_11_0_0_1_;}
}

long O5856[22];
void O5856_init () {
	{long i; for (i = 0; i < 6; i++) O5856[i] = + _LNGOFF_2_0_0_2_;}
	{long i; for (i = 6; i < 8; i++) O5856[i] = + _LNGOFF_6_0_0_2_;}
	{long i; for (i = 8; i < 10; i++) O5856[i] = + _LNGOFF_7_0_0_2_;}
	{long i; for (i = 10; i < 14; i++) O5856[i] = + _LNGOFF_4_0_0_2_;}
	{long i; for (i = 14; i < 18; i++) O5856[i] = + _LNGOFF_10_0_0_2_;}
	{long i; for (i = 18; i < 22; i++) O5856[i] = + _LNGOFF_11_0_0_2_;}
}

long O5857[22];
void O5857_init () {
	{long i; for (i = 0; i < 6; i++) O5857[i] = + _LNGOFF_2_0_0_3_;}
	{long i; for (i = 6; i < 8; i++) O5857[i] = + _LNGOFF_6_0_0_3_;}
	{long i; for (i = 8; i < 10; i++) O5857[i] = + _LNGOFF_7_0_0_3_;}
	{long i; for (i = 10; i < 14; i++) O5857[i] = + _LNGOFF_4_0_0_3_;}
	{long i; for (i = 14; i < 18; i++) O5857[i] = + _LNGOFF_10_0_0_3_;}
	{long i; for (i = 18; i < 22; i++) O5857[i] = + _LNGOFF_11_0_0_3_;}
}

long O5858[22];
void O5858_init () {
	{long i; for (i = 0; i < 6; i++) O5858[i] = + _LNGOFF_2_0_0_4_;}
	{long i; for (i = 6; i < 8; i++) O5858[i] = + _LNGOFF_6_0_0_4_;}
	{long i; for (i = 8; i < 10; i++) O5858[i] = + _LNGOFF_7_0_0_4_;}
	{long i; for (i = 10; i < 14; i++) O5858[i] = + _LNGOFF_4_0_0_4_;}
	{long i; for (i = 14; i < 18; i++) O5858[i] = + _LNGOFF_10_0_0_4_;}
	{long i; for (i = 18; i < 22; i++) O5858[i] = + _LNGOFF_11_0_0_4_;}
}

long O5859[22];
void O5859_init () {
	{long i; for (i = 0; i < 6; i++) O5859[i] = + _LNGOFF_2_0_0_5_;}
	{long i; for (i = 6; i < 8; i++) O5859[i] = + _LNGOFF_6_0_0_5_;}
	{long i; for (i = 8; i < 10; i++) O5859[i] = + _LNGOFF_7_0_0_5_;}
	{long i; for (i = 10; i < 14; i++) O5859[i] = + _LNGOFF_4_0_0_5_;}
	{long i; for (i = 14; i < 18; i++) O5859[i] = + _LNGOFF_10_0_0_5_;}
	{long i; for (i = 18; i < 22; i++) O5859[i] = + _LNGOFF_11_0_0_5_;}
}

long O5860[22];
void O5860_init () {
	{long i; for (i = 0; i < 6; i++) O5860[i] = + _LNGOFF_2_0_0_6_;}
	{long i; for (i = 6; i < 8; i++) O5860[i] = + _LNGOFF_6_0_0_6_;}
	{long i; for (i = 8; i < 10; i++) O5860[i] = + _LNGOFF_7_0_0_6_;}
	{long i; for (i = 10; i < 14; i++) O5860[i] = + _LNGOFF_4_0_0_6_;}
	{long i; for (i = 14; i < 18; i++) O5860[i] = + _LNGOFF_10_0_0_6_;}
	{long i; for (i = 18; i < 22; i++) O5860[i] = + _LNGOFF_11_0_0_6_;}
}

long O5870[22];
void O5870_init () {
	{long i; for (i = 0; i < 6; i++) O5870[i] = + _LNGOFF_2_0_0_7_;}
	{long i; for (i = 6; i < 8; i++) O5870[i] = + _LNGOFF_6_0_0_7_;}
	{long i; for (i = 8; i < 10; i++) O5870[i] = + _LNGOFF_7_0_0_7_;}
	{long i; for (i = 10; i < 14; i++) O5870[i] = + _LNGOFF_4_0_0_7_;}
	{long i; for (i = 14; i < 18; i++) O5870[i] = + _LNGOFF_10_0_0_7_;}
	{long i; for (i = 18; i < 22; i++) O5870[i] = + _LNGOFF_11_0_0_7_;}
}

long O5871[22];
void O5871_init () {
	{long i; for (i = 0; i < 6; i++) O5871[i] = + _LNGOFF_2_0_0_8_;}
	{long i; for (i = 6; i < 8; i++) O5871[i] = + _LNGOFF_6_0_0_8_;}
	{long i; for (i = 8; i < 10; i++) O5871[i] = + _LNGOFF_7_0_0_8_;}
	{long i; for (i = 10; i < 14; i++) O5871[i] = + _LNGOFF_4_0_0_8_;}
	{long i; for (i = 14; i < 18; i++) O5871[i] = + _LNGOFF_10_0_0_8_;}
	{long i; for (i = 18; i < 22; i++) O5871[i] = + _LNGOFF_11_0_0_8_;}
}

static EIF_TYPE_INDEX Y5877_pgtype0[] = {0xFF01,19,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype1[] = {0xFF01,20,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype2[] = {0xFF01,19,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5877_pgtype3[] = {0xFF01,20,0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5877_gen_type [4];
EIF_TYPE_INDEX Y5877 [4];
void Y5877_init (void)
{
	egc_routines_types [5877] = Y5877;
	egc_routines_gen_types [5877] = Y5877_gen_type;
	egc_routines_offset [5877] = 1167;
	Y5877_gen_type [0] = Y5877_pgtype0;
	Y5877_gen_type [1] = Y5877_pgtype1;
	Y5877_gen_type [2] = Y5877_pgtype2;
	Y5877_gen_type [3] = Y5877_pgtype3;
	Y5877[0] = 19;
	Y5877[1] = 20;
	Y5877[2] = 19;
	Y5877[3] = 20;
}

static EIF_TYPE_INDEX Y5901_pgtype0[] = {225,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5901_pgtype1[] = {226,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5901_pgtype2[] = {226,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5901_pgtype3[] = {230,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5901_pgtype4[] = {225,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5901_pgtype5[] = {226,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5901_pgtype6[] = {226,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5901_pgtype7[] = {230,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5901_pgtype8[] = {225,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5901_pgtype9[] = {226,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5901_pgtype10[] = {226,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5901_pgtype11[] = {230,0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y5901_gen_type [12];
EIF_TYPE_INDEX Y5901 [12];
void Y5901_init (void)
{
	egc_routines_types [5901] = Y5901;
	egc_routines_gen_types [5901] = Y5901_gen_type;
	egc_routines_offset [5901] = 1171;
	Y5901_gen_type [0] = Y5901_pgtype0;
	Y5901_gen_type [1] = Y5901_pgtype1;
	Y5901_gen_type [2] = Y5901_pgtype2;
	Y5901_gen_type [3] = Y5901_pgtype3;
	Y5901_gen_type [4] = Y5901_pgtype4;
	Y5901_gen_type [5] = Y5901_pgtype5;
	Y5901_gen_type [6] = Y5901_pgtype6;
	Y5901_gen_type [7] = Y5901_pgtype7;
	Y5901_gen_type [8] = Y5901_pgtype8;
	Y5901_gen_type [9] = Y5901_pgtype9;
	Y5901_gen_type [10] = Y5901_pgtype10;
	Y5901_gen_type [11] = Y5901_pgtype11;
	Y5901[0] = 225;
	{long i; for (i = 1; i < 3; i++) Y5901[i] = 226;};
	Y5901[3] = 230;
	Y5901[4] = 225;
	{long i; for (i = 5; i < 7; i++) Y5901[i] = 226;};
	Y5901[7] = 230;
	Y5901[8] = 225;
	{long i; for (i = 9; i < 11; i++) Y5901[i] = 226;};
	Y5901[11] = 230;
}

static EIF_TYPE_INDEX Y5907_pgtype0[] = {0xFF01,19,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5907_pgtype1[] = {0xFF01,20,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5907_pgtype2[] = {0xFF01,20,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5907_pgtype3[] = {0xFF01,22,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5907_pgtype4[] = {0xFF01,19,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5907_pgtype5[] = {0xFF01,20,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5907_pgtype6[] = {0xFF01,20,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5907_pgtype7[] = {0xFF01,22,0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y5907_gen_type [8];
EIF_TYPE_INDEX Y5907 [8];
void Y5907_init (void)
{
	egc_routines_types [5907] = Y5907;
	egc_routines_gen_types [5907] = Y5907_gen_type;
	egc_routines_offset [5907] = 1175;
	Y5907_gen_type [0] = Y5907_pgtype0;
	Y5907_gen_type [1] = Y5907_pgtype1;
	Y5907_gen_type [2] = Y5907_pgtype2;
	Y5907_gen_type [3] = Y5907_pgtype3;
	Y5907_gen_type [4] = Y5907_pgtype4;
	Y5907_gen_type [5] = Y5907_pgtype5;
	Y5907_gen_type [6] = Y5907_pgtype6;
	Y5907_gen_type [7] = Y5907_pgtype7;
	Y5907[0] = 19;
	{long i; for (i = 1; i < 3; i++) Y5907[i] = 20;};
	Y5907[3] = 22;
	Y5907[4] = 19;
	{long i; for (i = 5; i < 7; i++) Y5907[i] = 20;};
	Y5907[7] = 22;
}


#ifdef __cplusplus
}
#endif
