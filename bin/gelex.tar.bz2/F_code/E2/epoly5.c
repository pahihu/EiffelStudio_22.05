#include "epoly5.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R4414[2])();
void R4414_init () {
	R4414[0] = (char *(*)()) F911_5658;
	R4414[1] = (char *(*)()) F910_5635;
}

char *(*R4472[334])();
void R4472_init () {
	R4472[0] = (char *(*)()) F915_5834;
	R4472[333] = (char *(*)()) F1248_8941;
}

char *(*R4474[335])();
void R4474_init () {
	{long i; for (i = 0; i < 2; i++) R4474[i] = (char *(*)()) F913_5764;}
	R4474[334] = (char *(*)()) F1248_8952;
}

char *(*R4476[335])();
void R4476_init () {
	{long i; for (i = 0; i < 2; i++) R4476[i] = (char *(*)()) F913_5767;}
	R4476[334] = (char *(*)()) F1248_8947;
}

char *(*R4481[335])();
void R4481_init () {
	{long i; for (i = 0; i < 2; i++) R4481[i] = (char *(*)()) F913_5779;}
	R4481[334] = (char *(*)()) F1248_8970;
}

char *(*R4486[334])();
void R4486_init () {
	R4486[0] = (char *(*)()) F915_5883;
	R4486[333] = (char *(*)()) F1248_8948;
}

char *(*R4494[335])();
void R4494_init () {
	R4494[0] = (char *(*)()) F914_5824;
	R4494[1] = (char *(*)()) F913_5803;
	R4494[334] = (char *(*)()) F913_5803;
}

char *(*R4520[334])();
void R4520_init () {
	R4520[0] = (char *(*)()) F915_5864;
	R4520[333] = (char *(*)()) F1248_8986;
}

char *(*R4522[334])();
void R4522_init () {
	R4522[0] = (char *(*)()) F915_5866;
	R4522[333] = (char *(*)()) F1248_8984;
}

char *(*R4524[334])();
void R4524_init () {
	R4524[0] = (char *(*)()) F915_5877;
	R4524[333] = (char *(*)()) F1248_8983;
}

char *(*R4536[334])();
void R4536_init () {
	R4536[0] = (char *(*)()) F915_5905;
	R4536[333] = (char *(*)()) F1248_9017;
}

char *(*R4567[321])();
void R4567_init () {
	R4567[0] = (char *(*)()) F928_5976;
	R4567[1] = (char *(*)()) F929_5984;
	R4567[123] = (char *(*)()) F1050_6936;
	R4567[320] = (char *(*)()) F1248_8985;
}

char *(*R4587[321])();
void R4587_init () {
	R4587[0] = (char *(*)()) F928_5973;
	R4587[1] = (char *(*)()) F929_5981;
	R4587[123] = (char *(*)()) F1051_6950;
	R4587[320] = (char *(*)()) F1248_9026;
}

char *(*R4769[110])();
void R4769_init () {
	R4769[0] = (char *(*)()) F947_6186;
	R4769[1] = (char *(*)()) F945_6168;
	R4769[109] = (char *(*)()) F1055_6965;
}

char *(*R5186[25])();
void R5186_init () {
	R5186[0] = (char *(*)()) F1020_6766;
	R5186[1] = (char *(*)()) F1021_6766;
	R5186[10] = (char *(*)()) F1030_6774;
	R5186[11] = (char *(*)()) F1031_6774;
	R5186[12] = (char *(*)()) F1032_6774;
	R5186[13] = (char *(*)()) F1033_6774;
	R5186[18] = (char *(*)()) F1038_6795;
	R5186[19] = (char *(*)()) F1039_6795;
	R5186[20] = (char *(*)()) F1040_6810;
	R5186[21] = (char *(*)()) F1041_6810;
	R5186[22] = (char *(*)()) F1042_6810;
	R5186[23] = (char *(*)()) F1043_6810;
	R5186[24] = (char *(*)()) F1044_6822;
}

char *(*R5187[25])();
void R5187_init () {
	R5187[0] = (char *(*)()) F1012_6751;
	R5187[1] = (char *(*)()) F1014_6751;
	R5187[10] = (char *(*)()) F1012_6751;
	R5187[11] = (char *(*)()) F1013_6751;
	R5187[12] = (char *(*)()) F1014_6751;
	R5187[13] = (char *(*)()) F1015_6751;
	R5187[18] = (char *(*)()) F998_6731;
	R5187[19] = (char *(*)()) F999_6731;
	R5187[20] = (char *(*)()) F1040_6813;
	R5187[21] = (char *(*)()) F1041_6813;
	R5187[22] = (char *(*)()) F1042_6813;
	R5187[23] = (char *(*)()) F1043_6813;
	R5187[24] = (char *(*)()) F1040_6813;
}

char *(*R5188[25])();
void R5188_init () {
	R5188[0] = (char *(*)()) F975_6704;
	R5188[1] = (char *(*)()) F976_6704;
	{long i; for (i = 10; i < 12; i++) R5188[i] = (char *(*)()) F975_6704;}
	R5188[12] = (char *(*)()) F976_6704;
	R5188[13] = (char *(*)()) F979_6704;
	R5188[18] = (char *(*)()) F975_6704;
	R5188[19] = (char *(*)()) F976_6704;
	R5188[20] = (char *(*)()) F1040_6814;
	R5188[21] = (char *(*)()) F1041_6814;
	R5188[22] = (char *(*)()) F1042_6814;
	R5188[23] = (char *(*)()) F1043_6814;
	R5188[24] = (char *(*)()) F1040_6814;
}

char *(*R5192[25])();
void R5192_init () {
	R5192[0] = (char *(*)()) F975_6710;
	R5192[1] = (char *(*)()) F976_6710;
	{long i; for (i = 10; i < 12; i++) R5192[i] = (char *(*)()) F975_6710;}
	R5192[12] = (char *(*)()) F976_6710;
	R5192[13] = (char *(*)()) F979_6710;
	R5192[18] = (char *(*)()) F975_6710;
	R5192[19] = (char *(*)()) F976_6710;
	R5192[20] = (char *(*)()) F975_6710;
	R5192[21] = (char *(*)()) F977_6710;
	R5192[22] = (char *(*)()) F978_6710;
	R5192[23] = (char *(*)()) F976_6710;
	R5192[24] = (char *(*)()) F975_6710;
}

char *(*R5194[7])();
void R5194_init () {
	R5194[0] = (char *(*)()) F1034_6776;
	R5194[1] = (char *(*)()) F1035_6776;
	R5194[2] = (char *(*)()) F1034_6776;
	R5194[3] = (char *(*)()) F1036_6776;
	R5194[4] = (char *(*)()) F1037_6776;
	R5194[5] = (char *(*)()) F1035_6776;
	R5194[6] = (char *(*)()) F1034_6776;
}

char *(*R5199[25])();
void R5199_init () {
	R5199[0] = (char *(*)()) F990_6718;
	R5199[1] = (char *(*)()) F991_6718;
	{long i; for (i = 10; i < 12; i++) R5199[i] = (char *(*)()) F990_6718;}
	R5199[12] = (char *(*)()) F991_6718;
	R5199[13] = (char *(*)()) F994_6718;
	R5199[18] = (char *(*)()) F990_6718;
	R5199[19] = (char *(*)()) F991_6718;
	R5199[20] = (char *(*)()) F990_6718;
	R5199[21] = (char *(*)()) F992_6718;
	R5199[22] = (char *(*)()) F993_6718;
	R5199[23] = (char *(*)()) F991_6718;
	R5199[24] = (char *(*)()) F990_6718;
}

char *(*R5200[25])();
void R5200_init () {
	R5200[0] = (char *(*)()) F990_6721;
	R5200[1] = (char *(*)()) F991_6721;
	{long i; for (i = 10; i < 12; i++) R5200[i] = (char *(*)()) F990_6721;}
	R5200[12] = (char *(*)()) F991_6721;
	R5200[13] = (char *(*)()) F994_6721;
	R5200[18] = (char *(*)()) F990_6721;
	R5200[19] = (char *(*)()) F991_6721;
	R5200[20] = (char *(*)()) F990_6721;
	R5200[21] = (char *(*)()) F992_6721;
	R5200[22] = (char *(*)()) F993_6721;
	R5200[23] = (char *(*)()) F991_6721;
	R5200[24] = (char *(*)()) F990_6721;
}

char *(*R5203[25])();
void R5203_init () {
	R5203[0] = (char *(*)()) F998_6729;
	R5203[1] = (char *(*)()) F999_6729;
	{long i; for (i = 10; i < 12; i++) R5203[i] = (char *(*)()) F998_6729;}
	R5203[12] = (char *(*)()) F999_6729;
	R5203[13] = (char *(*)()) F1002_6729;
	R5203[18] = (char *(*)()) F998_6729;
	R5203[19] = (char *(*)()) F999_6729;
	R5203[20] = (char *(*)()) F998_6729;
	R5203[21] = (char *(*)()) F1000_6729;
	R5203[22] = (char *(*)()) F1001_6729;
	R5203[23] = (char *(*)()) F999_6729;
	R5203[24] = (char *(*)()) F998_6729;
}

char *(*R5204[25])();
void R5204_init () {
	R5204[0] = (char *(*)()) F1012_6750;
	R5204[1] = (char *(*)()) F1014_6750;
	R5204[10] = (char *(*)()) F1012_6750;
	R5204[11] = (char *(*)()) F1013_6750;
	R5204[12] = (char *(*)()) F1014_6750;
	R5204[13] = (char *(*)()) F1015_6750;
	R5204[18] = (char *(*)()) F1038_6797;
	R5204[19] = (char *(*)()) F1039_6797;
	R5204[20] = (char *(*)()) F1040_6812;
	R5204[21] = (char *(*)()) F1041_6812;
	R5204[22] = (char *(*)()) F1042_6812;
	R5204[23] = (char *(*)()) F1043_6812;
	R5204[24] = (char *(*)()) F1040_6812;
}

char *(*R5214[4])();
void R5214_init () {
	R5214[0] = (char *(*)()) F1022_6768;
	R5214[1] = (char *(*)()) F1023_6768_5214_1;
	R5214[2] = (char *(*)()) F1024_6768_5214_1;
	R5214[3] = (char *(*)()) F1025_6768_5214_1;
}
static EIF_REFERENCE F1023_6768_5214_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1023_6768(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1024_6768_5214_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1024_6768(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1025_6768_5214_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1025_6768(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(846, 0x00).id, 846, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R5216[14])();
void R5216_init () {
	R5216[0] = (char *(*)()) F1012_6747;
	R5216[1] = (char *(*)()) F1014_6747;
	R5216[10] = (char *(*)()) F1012_6747;
	R5216[11] = (char *(*)()) F1013_6747;
	R5216[12] = (char *(*)()) F1014_6747;
	R5216[13] = (char *(*)()) F1015_6747;
}

char *(*R5218[14])();
void R5218_init () {
	R5218[0] = (char *(*)()) F1012_6753;
	R5218[1] = (char *(*)()) F1014_6753;
	R5218[10] = (char *(*)()) F1012_6753;
	R5218[11] = (char *(*)()) F1013_6753;
	R5218[12] = (char *(*)()) F1014_6753;
	R5218[13] = (char *(*)()) F1015_6753;
}

char *(*R5219[14])();
void R5219_init () {
	R5219[0] = (char *(*)()) F1012_6754;
	R5219[1] = (char *(*)()) F1014_6754;
	R5219[10] = (char *(*)()) F1012_6754;
	R5219[11] = (char *(*)()) F1013_6754;
	R5219[12] = (char *(*)()) F1014_6754;
	R5219[13] = (char *(*)()) F1015_6754;
}

char *(*R5224[14])();
void R5224_init () {
	R5224[0] = (char *(*)()) F1012_6761;
	R5224[1] = (char *(*)()) F1014_6761;
	R5224[10] = (char *(*)()) F1012_6761;
	R5224[11] = (char *(*)()) F1013_6761;
	R5224[12] = (char *(*)()) F1014_6761;
	R5224[13] = (char *(*)()) F1015_6761;
}

char *(*R5240[2])();
void R5240_init () {
	R5240[0] = (char *(*)()) F1038_6794;
	R5240[1] = (char *(*)()) F1039_6794;
}

char *(*R5242[2])();
void R5242_init () {
	R5242[0] = (char *(*)()) F1038_6800;
	R5242[1] = (char *(*)()) F1039_6800;
}

char *(*R5243[2])();
void R5243_init () {
	R5243[0] = (char *(*)()) F1038_6801;
	R5243[1] = (char *(*)()) F1039_6801;
}

char *(*R5247[2])();
void R5247_init () {
	R5247[0] = (char *(*)()) F1038_6807;
	R5247[1] = (char *(*)()) F1039_6807;
}

char *(*R5249[5])();
void R5249_init () {
	R5249[0] = (char *(*)()) F1040_6808;
	R5249[1] = (char *(*)()) F1041_6808;
	R5249[2] = (char *(*)()) F1042_6808;
	R5249[3] = (char *(*)()) F1043_6808;
	R5249[4] = (char *(*)()) F1040_6808;
}

char *(*R5251[5])();
void R5251_init () {
	R5251[0] = (char *(*)()) F1040_6817;
	R5251[1] = (char *(*)()) F1041_6817;
	R5251[2] = (char *(*)()) F1042_6817;
	R5251[3] = (char *(*)()) F1043_6817;
	R5251[4] = (char *(*)()) F1040_6817;
}

char *(*R5252[5])();
void R5252_init () {
	R5252[0] = (char *(*)()) F1040_6818;
	R5252[1] = (char *(*)()) F1041_6818;
	R5252[2] = (char *(*)()) F1042_6818;
	R5252[3] = (char *(*)()) F1043_6818;
	R5252[4] = (char *(*)()) F1040_6818;
}

char *(*R5254[5])();
void R5254_init () {
	R5254[0] = (char *(*)()) F1040_6820;
	R5254[1] = (char *(*)()) F1041_6820;
	R5254[2] = (char *(*)()) F1042_6820;
	R5254[3] = (char *(*)()) F1043_6820;
	R5254[4] = (char *(*)()) F1040_6820;
}

static EIF_TYPE_INDEX Y5434_pgtype0[] = {0xFF01,1067,0xFFFF};
static EIF_TYPE_INDEX Y5434_pgtype1[] = {0xFF01,1068,0xFFFF};
static EIF_TYPE_INDEX Y5434_pgtype2[] = {0xFF01,1069,0xFFFF};
static EIF_TYPE_INDEX Y5434_pgtype3[] = {0xFF01,1069,0xFFFF};
static EIF_TYPE_INDEX Y5434_pgtype4[] = {0xFF01,1069,0xFFFF};
static EIF_TYPE_INDEX Y5434_pgtype5[] = {0xFF01,1069,0xFFFF};
EIF_TYPE_INDEX *Y5434_gen_type [6];
EIF_TYPE_INDEX Y5434 [6];
void Y5434_init (void)
{
	egc_routines_types [5434] = Y5434;
	egc_routines_gen_types [5434] = Y5434_gen_type;
	egc_routines_offset [5434] = 1070;
	Y5434_gen_type [0] = Y5434_pgtype0;
	Y5434_gen_type [1] = Y5434_pgtype1;
	Y5434_gen_type [2] = Y5434_pgtype2;
	Y5434_gen_type [3] = Y5434_pgtype3;
	Y5434_gen_type [4] = Y5434_pgtype4;
	Y5434_gen_type [5] = Y5434_pgtype5;
	Y5434[0] = 1067;
	Y5434[1] = 1068;
	{long i; for (i = 2; i < 6; i++) Y5434[i] = 1069;};
}

char *(*R5476[2])();
void R5476_init () {
	R5476[0] = (char *(*)()) F1075_7191;
	R5476[1] = (char *(*)()) F1073_7136;
}

char *(*R5483[2])();
void R5483_init () {
	R5483[0] = (char *(*)()) F1075_7182;
	R5483[1] = (char *(*)()) F1076_7221;
}

char *(*R5487[2])();
void R5487_init () {
	R5487[0] = (char *(*)()) F1075_7184;
	R5487[1] = (char *(*)()) F1076_7222;
}

char *(*R5495[2])();
void R5495_init () {
	R5495[0] = (char *(*)()) F1075_7185;
	R5495[1] = (char *(*)()) F1076_7223;
}

char *(*R5496[2])();
void R5496_init () {
	R5496[0] = (char *(*)()) F1075_7186;
	R5496[1] = (char *(*)()) F1076_7224;
}

char *(*R5560[3])();
void R5560_init () {
	R5560[0] = (char *(*)()) F1078_7239;
	R5560[1] = (char *(*)()) F1079_7245;
	R5560[2] = (char *(*)()) F1077_7233;
}

char *(*R5561[3])();
void R5561_init () {
	R5561[0] = (char *(*)()) F1078_7240;
	R5561[1] = (char *(*)()) F1079_7246;
	R5561[2] = (char *(*)()) F1077_7234;
}

char *(*R5571[39])();
void R5571_init () {
	R5571[0] = (char *(*)()) F1145_7506;
	R5571[1] = (char *(*)()) F1146_7506;
	R5571[2] = (char *(*)()) F1147_7506;
	R5571[3] = (char *(*)()) F1148_7506;
	{long i; for (i = 4; i < 6; i++) R5571[i] = (char *(*)()) F1145_7506;}
	R5571[7] = (char *(*)()) F1145_7506;
	R5571[12] = (char *(*)()) F1157_7622;
	R5571[13] = (char *(*)()) F1158_7622;
	R5571[14] = (char *(*)()) F1159_7657;
	R5571[15] = (char *(*)()) F1160_7657;
	R5571[16] = (char *(*)()) F1159_7657;
	R5571[25] = (char *(*)()) F1162_7742;
	R5571[26] = (char *(*)()) F1164_7742;
	R5571[35] = (char *(*)()) F1162_7742;
	R5571[36] = (char *(*)()) F1163_7742;
	R5571[37] = (char *(*)()) F1164_7742;
	R5571[38] = (char *(*)()) F1165_7742;
}

char *(*R5572[39])();
void R5572_init () {
	R5572[0] = (char *(*)()) F1081_7250;
	R5572[1] = (char *(*)()) F1083_7250;
	R5572[2] = (char *(*)()) F1084_7250;
	R5572[3] = (char *(*)()) F1082_7250;
	{long i; for (i = 4; i < 6; i++) R5572[i] = (char *(*)()) F1081_7250;}
	R5572[7] = (char *(*)()) F1081_7250;
	R5572[12] = (char *(*)()) F1082_7250;
	R5572[13] = (char *(*)()) F1084_7250;
	R5572[14] = (char *(*)()) F1081_7250;
	R5572[15] = (char *(*)()) F1082_7250;
	R5572[16] = (char *(*)()) F1081_7250;
	R5572[25] = (char *(*)()) F1081_7250;
	R5572[26] = (char *(*)()) F1082_7250;
	{long i; for (i = 35; i < 37; i++) R5572[i] = (char *(*)()) F1081_7250;}
	R5572[37] = (char *(*)()) F1082_7250;
	R5572[38] = (char *(*)()) F1085_7250;
}

char *(*R5573[39])();
void R5573_init () {
	R5573[0] = (char *(*)()) F1145_7556;
	R5573[1] = (char *(*)()) F1146_7556;
	R5573[2] = (char *(*)()) F1147_7556;
	R5573[3] = (char *(*)()) F1148_7556;
	{long i; for (i = 4; i < 6; i++) R5573[i] = (char *(*)()) F1145_7556;}
	R5573[7] = (char *(*)()) F1145_7556;
	R5573[14] = (char *(*)()) F1159_7699;
	R5573[15] = (char *(*)()) F1160_7699;
	R5573[16] = (char *(*)()) F1159_7699;
	R5573[25] = (char *(*)()) F1162_7760;
	R5573[26] = (char *(*)()) F1164_7760;
	R5573[35] = (char *(*)()) F1162_7760;
	R5573[36] = (char *(*)()) F1163_7760;
	R5573[37] = (char *(*)()) F1164_7760;
	R5573[38] = (char *(*)()) F1165_7760;
}

static EIF_TYPE_INDEX Y5580_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype12[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype13[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype14[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype15[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype30[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype31[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype33[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype36[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype38[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype39[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype40[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype41[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype58[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype59[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype60[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype61[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype62[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype63[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype64[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype65[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype66[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype67[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype68[] = {0xFF01,1066,0xFF01,1069,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype69[] = {0xFF01,115,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype70[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype71[] = {0xFF01,47,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype72[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype73[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype74[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype75[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype76[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype77[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype78[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype79[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype80[] = {0xFF01,44,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype81[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype82[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype83[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype84[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype85[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype86[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype87[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype88[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype89[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype90[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype91[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype92[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype93[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype94[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype95[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype96[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype97[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype98[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype99[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype100[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype101[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5580_pgtype102[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5580_gen_type [103];
EIF_TYPE_INDEX Y5580 [103];
void Y5580_init (void)
{
	egc_routines_types [5580] = Y5580;
	egc_routines_gen_types [5580] = Y5580_gen_type;
	egc_routines_offset [5580] = 1080;
	Y5580_gen_type [0] = Y5580_pgtype0;
	Y5580_gen_type [1] = Y5580_pgtype1;
	Y5580_gen_type [2] = Y5580_pgtype2;
	Y5580_gen_type [3] = Y5580_pgtype3;
	Y5580_gen_type [4] = Y5580_pgtype4;
	Y5580_gen_type [5] = Y5580_pgtype5;
	Y5580_gen_type [6] = Y5580_pgtype6;
	Y5580_gen_type [7] = Y5580_pgtype7;
	Y5580_gen_type [8] = Y5580_pgtype8;
	Y5580_gen_type [9] = Y5580_pgtype9;
	Y5580_gen_type [10] = Y5580_pgtype10;
	Y5580_gen_type [11] = Y5580_pgtype11;
	Y5580_gen_type [12] = Y5580_pgtype12;
	Y5580_gen_type [13] = Y5580_pgtype13;
	Y5580_gen_type [14] = Y5580_pgtype14;
	Y5580_gen_type [15] = Y5580_pgtype15;
	Y5580_gen_type [16] = Y5580_pgtype16;
	Y5580_gen_type [17] = Y5580_pgtype17;
	Y5580_gen_type [18] = Y5580_pgtype18;
	Y5580_gen_type [19] = Y5580_pgtype19;
	Y5580_gen_type [20] = Y5580_pgtype20;
	Y5580_gen_type [21] = Y5580_pgtype21;
	Y5580_gen_type [22] = Y5580_pgtype22;
	Y5580_gen_type [23] = Y5580_pgtype23;
	Y5580_gen_type [24] = Y5580_pgtype24;
	Y5580_gen_type [25] = Y5580_pgtype25;
	Y5580_gen_type [26] = Y5580_pgtype26;
	Y5580_gen_type [27] = Y5580_pgtype27;
	Y5580_gen_type [28] = Y5580_pgtype28;
	Y5580_gen_type [29] = Y5580_pgtype29;
	Y5580_gen_type [30] = Y5580_pgtype30;
	Y5580_gen_type [31] = Y5580_pgtype31;
	Y5580_gen_type [32] = Y5580_pgtype32;
	Y5580_gen_type [33] = Y5580_pgtype33;
	Y5580_gen_type [34] = Y5580_pgtype34;
	Y5580_gen_type [35] = Y5580_pgtype35;
	Y5580_gen_type [36] = Y5580_pgtype36;
	Y5580_gen_type [37] = Y5580_pgtype37;
	Y5580_gen_type [38] = Y5580_pgtype38;
	Y5580_gen_type [39] = Y5580_pgtype39;
	Y5580_gen_type [40] = Y5580_pgtype40;
	Y5580_gen_type [41] = Y5580_pgtype41;
	Y5580_gen_type [42] = Y5580_pgtype42;
	Y5580_gen_type [43] = Y5580_pgtype43;
	Y5580_gen_type [44] = Y5580_pgtype44;
	Y5580_gen_type [45] = Y5580_pgtype45;
	Y5580_gen_type [46] = Y5580_pgtype46;
	Y5580_gen_type [47] = Y5580_pgtype47;
	Y5580_gen_type [48] = Y5580_pgtype48;
	Y5580_gen_type [49] = Y5580_pgtype49;
	Y5580_gen_type [50] = Y5580_pgtype50;
	Y5580_gen_type [51] = Y5580_pgtype51;
	Y5580_gen_type [52] = Y5580_pgtype52;
	Y5580_gen_type [53] = Y5580_pgtype53;
	Y5580_gen_type [54] = Y5580_pgtype54;
	Y5580_gen_type [55] = Y5580_pgtype55;
	Y5580_gen_type [56] = Y5580_pgtype56;
	Y5580_gen_type [57] = Y5580_pgtype57;
	Y5580_gen_type [58] = Y5580_pgtype58;
	Y5580_gen_type [59] = Y5580_pgtype59;
	Y5580_gen_type [60] = Y5580_pgtype60;
	Y5580_gen_type [61] = Y5580_pgtype61;
	Y5580_gen_type [62] = Y5580_pgtype62;
	Y5580_gen_type [63] = Y5580_pgtype63;
	Y5580_gen_type [64] = Y5580_pgtype64;
	Y5580_gen_type [65] = Y5580_pgtype65;
	Y5580_gen_type [66] = Y5580_pgtype66;
	Y5580_gen_type [67] = Y5580_pgtype67;
	Y5580_gen_type [68] = Y5580_pgtype68;
	Y5580_gen_type [69] = Y5580_pgtype69;
	Y5580_gen_type [70] = Y5580_pgtype70;
	Y5580_gen_type [71] = Y5580_pgtype71;
	Y5580_gen_type [72] = Y5580_pgtype72;
	Y5580_gen_type [73] = Y5580_pgtype73;
	Y5580_gen_type [74] = Y5580_pgtype74;
	Y5580_gen_type [75] = Y5580_pgtype75;
	Y5580_gen_type [76] = Y5580_pgtype76;
	Y5580_gen_type [77] = Y5580_pgtype77;
	Y5580_gen_type [78] = Y5580_pgtype78;
	Y5580_gen_type [79] = Y5580_pgtype79;
	Y5580_gen_type [80] = Y5580_pgtype80;
	Y5580_gen_type [81] = Y5580_pgtype81;
	Y5580_gen_type [82] = Y5580_pgtype82;
	Y5580_gen_type [83] = Y5580_pgtype83;
	Y5580_gen_type [84] = Y5580_pgtype84;
	Y5580_gen_type [85] = Y5580_pgtype85;
	Y5580_gen_type [86] = Y5580_pgtype86;
	Y5580_gen_type [87] = Y5580_pgtype87;
	Y5580_gen_type [88] = Y5580_pgtype88;
	Y5580_gen_type [89] = Y5580_pgtype89;
	Y5580_gen_type [90] = Y5580_pgtype90;
	Y5580_gen_type [91] = Y5580_pgtype91;
	Y5580_gen_type [92] = Y5580_pgtype92;
	Y5580_gen_type [93] = Y5580_pgtype93;
	Y5580_gen_type [94] = Y5580_pgtype94;
	Y5580_gen_type [95] = Y5580_pgtype95;
	Y5580_gen_type [96] = Y5580_pgtype96;
	Y5580_gen_type [97] = Y5580_pgtype97;
	Y5580_gen_type [98] = Y5580_pgtype98;
	Y5580_gen_type [99] = Y5580_pgtype99;
	Y5580_gen_type [100] = Y5580_pgtype100;
	Y5580_gen_type [101] = Y5580_pgtype101;
	Y5580_gen_type [102] = Y5580_pgtype102;
	Y5580[68] = 1066;
	Y5580[69] = 115;
	Y5580[71] = 47;
	Y5580[80] = 44;
}

char *(*R5582[4])();
void R5582_init () {
	R5582[0] = (char *(*)()) F1172_7900;
	R5582[1] = (char *(*)()) F1173_7900_5582_5;
	R5582[2] = (char *(*)()) F1174_7900_5582_5;
	R5582[3] = (char *(*)()) F1175_7900_5582_5;
}
static EIF_REFERENCE F1173_7900_5582_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1173_7900(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F1174_7900_5582_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1174_7900(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1175_7900_5582_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1175_7900(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(843, 0x00).id, 843, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5585[4])();
void R5585_init () {
	R5585[0] = (char *(*)()) F1172_7908;
	R5585[1] = (char *(*)()) F1173_7908_5585_2;
	R5585[2] = (char *(*)()) F1174_7908_5585_2;
	R5585[3] = (char *(*)()) F1175_7908_5585_2;
}
static EIF_BOOLEAN F1173_7908_5585_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1173_7908(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1174_7908_5585_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1174_7908(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1175_7908_5585_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1175_7908(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R5589[4])();
void R5589_init () {
	R5589[0] = (char *(*)()) F1172_7921;
	R5589[1] = (char *(*)()) F1173_7921_5589_14;
	R5589[2] = (char *(*)()) F1174_7921_5589_14;
	R5589[3] = (char *(*)()) F1175_7921_5589_14;
}
static void F1173_7921_5589_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1173_7921(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1174_7921_5589_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1174_7921(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1175_7921_5589_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1175_7921(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_NATURAL_32 *)arg2);
}

char *(*R5603[39])();
void R5603_init () {
	R5603[0] = (char *(*)()) F1145_7505;
	R5603[1] = (char *(*)()) F1146_7505;
	R5603[2] = (char *(*)()) F1147_7505;
	R5603[3] = (char *(*)()) F1148_7505;
	{long i; for (i = 4; i < 6; i++) R5603[i] = (char *(*)()) F1145_7505;}
	R5603[7] = (char *(*)()) F1151_7590;
	R5603[14] = (char *(*)()) F1159_7656;
	R5603[15] = (char *(*)()) F1160_7656;
	R5603[16] = (char *(*)()) F1159_7656;
	R5603[25] = (char *(*)()) F1170_7888;
	R5603[26] = (char *(*)()) F1171_7888;
	R5603[35] = (char *(*)()) F1180_7972;
	R5603[36] = (char *(*)()) F1181_7972;
	R5603[37] = (char *(*)()) F1182_7972;
	R5603[38] = (char *(*)()) F1183_7972;
}

static EIF_TYPE_INDEX Y5603_pgtype0[] = {0xFF01,974,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype1[] = {0xFF01,975,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype2[] = {0xFF01,976,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype3[] = {0xFF01,977,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype4[] = {0xFF01,978,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype5[] = {0xFF01,979,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype6[] = {0xFF01,989,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype7[] = {0xFF01,990,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype8[] = {0xFF01,991,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype9[] = {0xFF01,992,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype10[] = {0xFF01,993,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype11[] = {0xFF01,994,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype12[] = {0xFF01,997,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype13[] = {0xFF01,998,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype14[] = {0xFF01,999,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype15[] = {0xFF01,1000,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype16[] = {0xFF01,1001,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype17[] = {0xFF01,1002,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype18[] = {0xFF01,1003,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype19[] = {0xFF01,1004,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype20[] = {0xFF01,1005,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype21[] = {0xFF01,1006,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype22[] = {0xFF01,1007,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype23[] = {0xFF01,1008,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype24[] = {0xFF01,1009,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype25[] = {0xFF01,1010,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype26[] = {0xFF01,995,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype27[] = {0xFF01,996,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype28[] = {0xFF01,1033,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype29[] = {0xFF01,1034,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype30[] = {0xFF01,1035,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype31[] = {0xFF01,1036,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype32[] = {0xFF01,1039,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype33[] = {0xFF01,1040,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype34[] = {0xFF01,1041,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype35[] = {0xFF01,1042,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype36[] = {0xFF01,1039,0xFF01,1066,0xFF01,1069,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype37[] = {0xFF01,1039,0xFF01,115,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype38[] = {0xFF01,1043,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype39[] = {0xFF01,1043,0xFF01,47,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype40[] = {0xFF01,1037,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype41[] = {0xFF01,1038,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype42[] = {0xFF01,1037,0xFF01,44,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype43[] = {0xFF01,1011,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype44[] = {0xFF01,1012,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype45[] = {0xFF01,1013,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype46[] = {0xFF01,1014,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype47[] = {0xFF01,1015,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype48[] = {0xFF01,1016,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype49[] = {0xFF01,1017,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype50[] = {0xFF01,1018,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype51[] = {0xFF01,1019,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype52[] = {0xFF01,1020,0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype53[] = {0xFF01,1021,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype54[] = {0xFF01,1022,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype55[] = {0xFF01,1023,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype56[] = {0xFF01,1024,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype57[] = {0xFF01,1025,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype58[] = {0xFF01,1026,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype59[] = {0xFF01,1027,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype60[] = {0xFF01,1028,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype61[] = {0xFF01,1029,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype62[] = {0xFF01,1030,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype63[] = {0xFF01,1031,0xFFF8,1,0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5603_pgtype64[] = {0xFF01,1032,0xFFF8,1,0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y5603_gen_type [89];
EIF_TYPE_INDEX Y5603 [89];
void Y5603_init (void)
{
	egc_routines_types [5603] = Y5603;
	egc_routines_gen_types [5603] = Y5603_gen_type;
	egc_routines_offset [5603] = 1094;
	Y5603_gen_type [0] = Y5603_pgtype0;
	Y5603_gen_type [1] = Y5603_pgtype1;
	Y5603_gen_type [2] = Y5603_pgtype2;
	Y5603_gen_type [3] = Y5603_pgtype3;
	Y5603_gen_type [4] = Y5603_pgtype4;
	Y5603_gen_type [5] = Y5603_pgtype5;
	Y5603_gen_type [12] = Y5603_pgtype6;
	Y5603_gen_type [13] = Y5603_pgtype7;
	Y5603_gen_type [14] = Y5603_pgtype8;
	Y5603_gen_type [15] = Y5603_pgtype9;
	Y5603_gen_type [16] = Y5603_pgtype10;
	Y5603_gen_type [17] = Y5603_pgtype11;
	Y5603_gen_type [18] = Y5603_pgtype12;
	Y5603_gen_type [19] = Y5603_pgtype13;
	Y5603_gen_type [20] = Y5603_pgtype14;
	Y5603_gen_type [21] = Y5603_pgtype15;
	Y5603_gen_type [22] = Y5603_pgtype16;
	Y5603_gen_type [23] = Y5603_pgtype17;
	Y5603_gen_type [24] = Y5603_pgtype18;
	Y5603_gen_type [25] = Y5603_pgtype19;
	Y5603_gen_type [26] = Y5603_pgtype20;
	Y5603_gen_type [27] = Y5603_pgtype21;
	Y5603_gen_type [28] = Y5603_pgtype22;
	Y5603_gen_type [29] = Y5603_pgtype23;
	Y5603_gen_type [30] = Y5603_pgtype24;
	Y5603_gen_type [31] = Y5603_pgtype25;
	Y5603_gen_type [36] = Y5603_pgtype26;
	Y5603_gen_type [37] = Y5603_pgtype27;
	Y5603_gen_type [46] = Y5603_pgtype28;
	Y5603_gen_type [47] = Y5603_pgtype29;
	Y5603_gen_type [48] = Y5603_pgtype30;
	Y5603_gen_type [49] = Y5603_pgtype31;
	Y5603_gen_type [50] = Y5603_pgtype32;
	Y5603_gen_type [51] = Y5603_pgtype33;
	Y5603_gen_type [52] = Y5603_pgtype34;
	Y5603_gen_type [53] = Y5603_pgtype35;
	Y5603_gen_type [54] = Y5603_pgtype36;
	Y5603_gen_type [55] = Y5603_pgtype37;
	Y5603_gen_type [56] = Y5603_pgtype38;
	Y5603_gen_type [57] = Y5603_pgtype39;
	Y5603_gen_type [64] = Y5603_pgtype40;
	Y5603_gen_type [65] = Y5603_pgtype41;
	Y5603_gen_type [66] = Y5603_pgtype42;
	Y5603_gen_type [67] = Y5603_pgtype43;
	Y5603_gen_type [68] = Y5603_pgtype44;
	Y5603_gen_type [69] = Y5603_pgtype45;
	Y5603_gen_type [70] = Y5603_pgtype46;
	Y5603_gen_type [71] = Y5603_pgtype47;
	Y5603_gen_type [72] = Y5603_pgtype48;
	Y5603_gen_type [73] = Y5603_pgtype49;
	Y5603_gen_type [74] = Y5603_pgtype50;
	Y5603_gen_type [75] = Y5603_pgtype51;
	Y5603_gen_type [76] = Y5603_pgtype52;
	Y5603_gen_type [77] = Y5603_pgtype53;
	Y5603_gen_type [78] = Y5603_pgtype54;
	Y5603_gen_type [79] = Y5603_pgtype55;
	Y5603_gen_type [80] = Y5603_pgtype56;
	Y5603_gen_type [81] = Y5603_pgtype57;
	Y5603_gen_type [82] = Y5603_pgtype58;
	Y5603_gen_type [83] = Y5603_pgtype59;
	Y5603_gen_type [84] = Y5603_pgtype60;
	Y5603_gen_type [85] = Y5603_pgtype61;
	Y5603_gen_type [86] = Y5603_pgtype62;
	Y5603_gen_type [87] = Y5603_pgtype63;
	Y5603_gen_type [88] = Y5603_pgtype64;
	Y5603[0] = 974;
	Y5603[1] = 975;
	Y5603[2] = 976;
	Y5603[3] = 977;
	Y5603[4] = 978;
	Y5603[5] = 979;
	Y5603[12] = 989;
	Y5603[13] = 990;
	Y5603[14] = 991;
	Y5603[15] = 992;
	Y5603[16] = 993;
	Y5603[17] = 994;
	Y5603[18] = 997;
	Y5603[19] = 998;
	Y5603[20] = 999;
	Y5603[21] = 1000;
	Y5603[22] = 1001;
	Y5603[23] = 1002;
	Y5603[24] = 1003;
	Y5603[25] = 1004;
	Y5603[26] = 1005;
	Y5603[27] = 1006;
	Y5603[28] = 1007;
	Y5603[29] = 1008;
	Y5603[30] = 1009;
	Y5603[31] = 1010;
	Y5603[36] = 995;
	Y5603[37] = 996;
	Y5603[46] = 1033;
	Y5603[47] = 1034;
	Y5603[48] = 1035;
	Y5603[49] = 1036;
	Y5603[50] = 1039;
	Y5603[51] = 1040;
	Y5603[52] = 1041;
	Y5603[53] = 1042;
	{long i; for (i = 54; i < 56; i++) Y5603[i] = 1039;};
	{long i; for (i = 56; i < 58; i++) Y5603[i] = 1043;};
	Y5603[64] = 1037;
	Y5603[65] = 1038;
	Y5603[66] = 1037;
	Y5603[67] = 1011;
	Y5603[68] = 1012;
	Y5603[69] = 1013;
	Y5603[70] = 1014;
	Y5603[71] = 1015;
	Y5603[72] = 1016;
	Y5603[73] = 1017;
	Y5603[74] = 1018;
	Y5603[75] = 1019;
	Y5603[76] = 1020;
	Y5603[77] = 1021;
	Y5603[78] = 1022;
	Y5603[79] = 1023;
	Y5603[80] = 1024;
	Y5603[81] = 1025;
	Y5603[82] = 1026;
	Y5603[83] = 1027;
	Y5603[84] = 1028;
	Y5603[85] = 1029;
	Y5603[86] = 1030;
	Y5603[87] = 1031;
	Y5603[88] = 1032;
}

char *(*R5606[39])();
void R5606_init () {
	R5606[0] = (char *(*)()) F1095_7285;
	R5606[1] = (char *(*)()) F1097_7285;
	R5606[2] = (char *(*)()) F1098_7285;
	R5606[3] = (char *(*)()) F1096_7285;
	{long i; for (i = 4; i < 6; i++) R5606[i] = (char *(*)()) F1095_7285;}
	R5606[7] = (char *(*)()) F1095_7285;
	R5606[14] = (char *(*)()) F1095_7285;
	R5606[15] = (char *(*)()) F1096_7285;
	R5606[16] = (char *(*)()) F1095_7285;
	R5606[25] = (char *(*)()) F1095_7285;
	R5606[26] = (char *(*)()) F1096_7285;
	{long i; for (i = 35; i < 37; i++) R5606[i] = (char *(*)()) F1095_7285;}
	R5606[37] = (char *(*)()) F1096_7285;
	R5606[38] = (char *(*)()) F1099_7285;
}

char *(*R5608[39])();
void R5608_init () {
	R5608[0] = (char *(*)()) F1145_7561;
	R5608[1] = (char *(*)()) F1146_7561;
	R5608[2] = (char *(*)()) F1147_7561;
	R5608[3] = (char *(*)()) F1148_7561;
	{long i; for (i = 4; i < 6; i++) R5608[i] = (char *(*)()) F1145_7561;}
	R5608[7] = (char *(*)()) F1145_7561;
	R5608[14] = (char *(*)()) F1159_7705;
	R5608[15] = (char *(*)()) F1160_7705;
	R5608[16] = (char *(*)()) F1159_7705;
	R5608[25] = (char *(*)()) F1162_7807;
	R5608[26] = (char *(*)()) F1164_7807;
	R5608[35] = (char *(*)()) F1162_7807;
	R5608[36] = (char *(*)()) F1163_7807;
	R5608[37] = (char *(*)()) F1164_7807;
	R5608[38] = (char *(*)()) F1165_7807;
}

char *(*R5609[39])();
void R5609_init () {
	R5609[0] = (char *(*)()) F1145_7562;
	R5609[1] = (char *(*)()) F1146_7562;
	R5609[2] = (char *(*)()) F1147_7562;
	R5609[3] = (char *(*)()) F1148_7562;
	{long i; for (i = 4; i < 6; i++) R5609[i] = (char *(*)()) F1145_7562;}
	R5609[7] = (char *(*)()) F1145_7562;
	R5609[14] = (char *(*)()) F1159_7706;
	R5609[15] = (char *(*)()) F1160_7706;
	R5609[16] = (char *(*)()) F1159_7706;
	R5609[25] = (char *(*)()) F1162_7808;
	R5609[26] = (char *(*)()) F1164_7808;
	R5609[35] = (char *(*)()) F1162_7808;
	R5609[36] = (char *(*)()) F1163_7808;
	R5609[37] = (char *(*)()) F1164_7808;
	R5609[38] = (char *(*)()) F1165_7808;
}

char *(*R5610[39])();
void R5610_init () {
	R5610[0] = (char *(*)()) F1145_7566;
	R5610[1] = (char *(*)()) F1146_7566_5610_5;
	R5610[2] = (char *(*)()) F1147_7566_5610_5;
	R5610[3] = (char *(*)()) F1148_7566_5610_5;
	{long i; for (i = 4; i < 6; i++) R5610[i] = (char *(*)()) F1145_7566;}
	R5610[7] = (char *(*)()) F1145_7566;
	R5610[14] = (char *(*)()) F1159_7711;
	R5610[15] = (char *(*)()) F1160_7711_5610_5;
	R5610[16] = (char *(*)()) F1159_7711;
	R5610[25] = (char *(*)()) F1162_7813;
	R5610[26] = (char *(*)()) F1164_7813_5610_5;
	R5610[35] = (char *(*)()) F1162_7813;
	R5610[36] = (char *(*)()) F1163_7813;
	R5610[37] = (char *(*)()) F1164_7813_5610_5;
	R5610[38] = (char *(*)()) F1165_7813_5610_5;
}
static EIF_REFERENCE F1146_7566_5610_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1146_7566(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1147_7566_5610_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1147_7566(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(867, 0x00).id, 867, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1148_7566_5610_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1148_7566(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1160_7711_5610_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1160_7711(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1164_7813_5610_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1164_7813(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1165_7813_5610_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1165_7813(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(843, 0x00).id, 843, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5611[39])();
void R5611_init () {
	R5611[0] = (char *(*)()) F1095_7290;
	R5611[1] = (char *(*)()) F1097_7290;
	R5611[2] = (char *(*)()) F1098_7290;
	R5611[3] = (char *(*)()) F1096_7290;
	{long i; for (i = 4; i < 6; i++) R5611[i] = (char *(*)()) F1095_7290;}
	R5611[7] = (char *(*)()) F1095_7290;
	R5611[14] = (char *(*)()) F1095_7290;
	R5611[15] = (char *(*)()) F1096_7290;
	R5611[16] = (char *(*)()) F1095_7290;
	R5611[25] = (char *(*)()) F1095_7290;
	R5611[26] = (char *(*)()) F1096_7290;
	{long i; for (i = 35; i < 37; i++) R5611[i] = (char *(*)()) F1095_7290;}
	R5611[37] = (char *(*)()) F1096_7290;
	R5611[38] = (char *(*)()) F1099_7290;
}

char *(*R5612[39])();
void R5612_init () {
	R5612[0] = (char *(*)()) F1145_7570;
	R5612[1] = (char *(*)()) F1146_7570;
	R5612[2] = (char *(*)()) F1147_7570;
	R5612[3] = (char *(*)()) F1148_7570;
	{long i; for (i = 4; i < 6; i++) R5612[i] = (char *(*)()) F1145_7570;}
	R5612[7] = (char *(*)()) F1145_7570;
	R5612[14] = (char *(*)()) F1159_7715;
	R5612[15] = (char *(*)()) F1160_7715;
	R5612[16] = (char *(*)()) F1159_7715;
	R5612[25] = (char *(*)()) F1162_7816;
	R5612[26] = (char *(*)()) F1164_7816;
	R5612[35] = (char *(*)()) F1162_7816;
	R5612[36] = (char *(*)()) F1163_7816;
	R5612[37] = (char *(*)()) F1164_7816;
	R5612[38] = (char *(*)()) F1165_7816;
}

char *(*R5613[39])();
void R5613_init () {
	R5613[0] = (char *(*)()) F1145_7579;
	R5613[1] = (char *(*)()) F1146_7579;
	R5613[2] = (char *(*)()) F1147_7579;
	R5613[3] = (char *(*)()) F1148_7579;
	{long i; for (i = 4; i < 6; i++) R5613[i] = (char *(*)()) F1145_7579;}
	R5613[7] = (char *(*)()) F1145_7579;
	R5613[14] = (char *(*)()) F1159_7724;
	R5613[15] = (char *(*)()) F1160_7724;
	R5613[16] = (char *(*)()) F1159_7724;
	R5613[25] = (char *(*)()) F1162_7825;
	R5613[26] = (char *(*)()) F1164_7825;
	R5613[35] = (char *(*)()) F1162_7825;
	R5613[36] = (char *(*)()) F1163_7825;
	R5613[37] = (char *(*)()) F1164_7825;
	R5613[38] = (char *(*)()) F1165_7825;
}

char *(*R5614[39])();
void R5614_init () {
	R5614[0] = (char *(*)()) F1095_7293;
	R5614[1] = (char *(*)()) F1097_7293;
	R5614[2] = (char *(*)()) F1098_7293;
	R5614[3] = (char *(*)()) F1096_7293;
	{long i; for (i = 4; i < 6; i++) R5614[i] = (char *(*)()) F1095_7293;}
	R5614[7] = (char *(*)()) F1095_7293;
	R5614[14] = (char *(*)()) F1095_7293;
	R5614[15] = (char *(*)()) F1096_7293;
	R5614[16] = (char *(*)()) F1095_7293;
	R5614[25] = (char *(*)()) F1095_7293;
	R5614[26] = (char *(*)()) F1096_7293;
	{long i; for (i = 35; i < 37; i++) R5614[i] = (char *(*)()) F1095_7293;}
	R5614[37] = (char *(*)()) F1096_7293;
	R5614[38] = (char *(*)()) F1099_7293;
}

char *(*R5615[39])();
void R5615_init () {
	R5615[0] = (char *(*)()) F1095_7294;
	R5615[1] = (char *(*)()) F1097_7294;
	R5615[2] = (char *(*)()) F1098_7294;
	R5615[3] = (char *(*)()) F1096_7294;
	{long i; for (i = 4; i < 6; i++) R5615[i] = (char *(*)()) F1095_7294;}
	R5615[7] = (char *(*)()) F1095_7294;
	R5615[14] = (char *(*)()) F1095_7294;
	R5615[15] = (char *(*)()) F1096_7294;
	R5615[16] = (char *(*)()) F1095_7294;
	R5615[25] = (char *(*)()) F1095_7294;
	R5615[26] = (char *(*)()) F1096_7294;
	{long i; for (i = 35; i < 37; i++) R5615[i] = (char *(*)()) F1095_7294;}
	R5615[37] = (char *(*)()) F1096_7294;
	R5615[38] = (char *(*)()) F1099_7294;
}

char *(*R5616[27])();
void R5616_init () {
	R5616[0] = (char *(*)()) F1145_7508;
	R5616[1] = (char *(*)()) F1146_7508_5616_2;
	R5616[2] = (char *(*)()) F1147_7508_5616_2;
	R5616[3] = (char *(*)()) F1148_7508_5616_2;
	{long i; for (i = 4; i < 6; i++) R5616[i] = (char *(*)()) F1145_7508;}
	R5616[7] = (char *(*)()) F1145_7508;
	R5616[14] = (char *(*)()) F1159_7660;
	R5616[15] = (char *(*)()) F1160_7660_5616_2;
	R5616[16] = (char *(*)()) F1159_7660;
	R5616[25] = (char *(*)()) F1166_7833;
	R5616[26] = (char *(*)()) F1167_7833_5616_2;
}
static EIF_BOOLEAN F1146_7508_5616_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1146_7508(Current, *(EIF_CHARACTER_8 *)arg1);
}
static EIF_BOOLEAN F1147_7508_5616_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1147_7508(Current, *(EIF_BOOLEAN *)arg1);
}
static EIF_BOOLEAN F1148_7508_5616_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1148_7508(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1160_7660_5616_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1160_7660(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F1167_7833_5616_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1167_7833(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5619[39])();
void R5619_init () {
	R5619[0] = (char *(*)()) F1101_7298;
	R5619[1] = (char *(*)()) F1103_7298;
	R5619[2] = (char *(*)()) F1104_7298;
	R5619[3] = (char *(*)()) F1102_7298;
	{long i; for (i = 4; i < 6; i++) R5619[i] = (char *(*)()) F1101_7298;}
	R5619[7] = (char *(*)()) F1101_7298;
	R5619[12] = (char *(*)()) F1102_7298;
	R5619[13] = (char *(*)()) F1104_7298;
	R5619[14] = (char *(*)()) F1101_7298;
	R5619[15] = (char *(*)()) F1102_7298;
	R5619[16] = (char *(*)()) F1101_7298;
	R5619[25] = (char *(*)()) F1101_7298;
	R5619[26] = (char *(*)()) F1102_7298;
	{long i; for (i = 35; i < 37; i++) R5619[i] = (char *(*)()) F1101_7298;}
	R5619[37] = (char *(*)()) F1102_7298;
	R5619[38] = (char *(*)()) F1105_7298;
}

char *(*R5624[39])();
void R5624_init () {
	R5624[0] = (char *(*)()) F1145_7503;
	R5624[1] = (char *(*)()) F1146_7503_5624_1;
	R5624[2] = (char *(*)()) F1147_7503_5624_1;
	R5624[3] = (char *(*)()) F1148_7503_5624_1;
	{long i; for (i = 4; i < 6; i++) R5624[i] = (char *(*)()) F1145_7503;}
	R5624[7] = (char *(*)()) F1145_7503;
	R5624[14] = (char *(*)()) F1159_7654;
	R5624[15] = (char *(*)()) F1160_7654_5624_1;
	R5624[16] = (char *(*)()) F1159_7654;
	R5624[25] = (char *(*)()) F1162_7739;
	R5624[26] = (char *(*)()) F1164_7739_5624_1;
	R5624[35] = (char *(*)()) F1162_7739;
	R5624[36] = (char *(*)()) F1163_7739;
	R5624[37] = (char *(*)()) F1164_7739_5624_1;
	R5624[38] = (char *(*)()) F1165_7739_5624_1;
}
static EIF_REFERENCE F1146_7503_5624_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1146_7503(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1147_7503_5624_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1147_7503(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(867, 0x00).id, 867, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1148_7503_5624_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1148_7503(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1160_7654_5624_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1160_7654(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1164_7739_5624_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1164_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1165_7739_5624_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1165_7739(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(843, 0x00).id, 843, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y5624_pgtype0[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype1[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype2[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype3[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype4[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype5[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype6[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype7[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype8[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype9[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype10[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype11[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype16[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype17[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype18[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype19[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype20[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype21[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype22[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype23[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype24[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype25[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype26[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype27[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype28[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype29[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype30[] = {0xFF01,1066,0xFF01,1069,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype31[] = {0xFF01,115,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype32[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype33[] = {0xFF01,47,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype34[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype35[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype36[] = {0xFF01,44,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype37[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype38[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype39[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype40[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype41[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype42[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype43[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype44[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype45[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype46[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype47[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype48[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype49[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype50[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype51[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype52[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype53[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype54[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype55[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype56[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype57[] = {0xFFF8,1,0xFFFF};
static EIF_TYPE_INDEX Y5624_pgtype58[] = {0xFFF8,1,0xFFFF};
EIF_TYPE_INDEX *Y5624_gen_type [77];
EIF_TYPE_INDEX Y5624 [77];
void Y5624_init (void)
{
	egc_routines_types [5624] = Y5624;
	egc_routines_gen_types [5624] = Y5624_gen_type;
	egc_routines_offset [5624] = 1106;
	Y5624_gen_type [0] = Y5624_pgtype0;
	Y5624_gen_type [1] = Y5624_pgtype1;
	Y5624_gen_type [2] = Y5624_pgtype2;
	Y5624_gen_type [3] = Y5624_pgtype3;
	Y5624_gen_type [4] = Y5624_pgtype4;
	Y5624_gen_type [5] = Y5624_pgtype5;
	Y5624_gen_type [6] = Y5624_pgtype6;
	Y5624_gen_type [7] = Y5624_pgtype7;
	Y5624_gen_type [8] = Y5624_pgtype8;
	Y5624_gen_type [9] = Y5624_pgtype9;
	Y5624_gen_type [10] = Y5624_pgtype10;
	Y5624_gen_type [11] = Y5624_pgtype11;
	Y5624_gen_type [12] = Y5624_pgtype12;
	Y5624_gen_type [13] = Y5624_pgtype13;
	Y5624_gen_type [14] = Y5624_pgtype14;
	Y5624_gen_type [15] = Y5624_pgtype15;
	Y5624_gen_type [16] = Y5624_pgtype16;
	Y5624_gen_type [17] = Y5624_pgtype17;
	Y5624_gen_type [18] = Y5624_pgtype18;
	Y5624_gen_type [19] = Y5624_pgtype19;
	Y5624_gen_type [24] = Y5624_pgtype20;
	Y5624_gen_type [25] = Y5624_pgtype21;
	Y5624_gen_type [34] = Y5624_pgtype22;
	Y5624_gen_type [35] = Y5624_pgtype23;
	Y5624_gen_type [36] = Y5624_pgtype24;
	Y5624_gen_type [37] = Y5624_pgtype25;
	Y5624_gen_type [38] = Y5624_pgtype26;
	Y5624_gen_type [39] = Y5624_pgtype27;
	Y5624_gen_type [40] = Y5624_pgtype28;
	Y5624_gen_type [41] = Y5624_pgtype29;
	Y5624_gen_type [42] = Y5624_pgtype30;
	Y5624_gen_type [43] = Y5624_pgtype31;
	Y5624_gen_type [44] = Y5624_pgtype32;
	Y5624_gen_type [45] = Y5624_pgtype33;
	Y5624_gen_type [52] = Y5624_pgtype34;
	Y5624_gen_type [53] = Y5624_pgtype35;
	Y5624_gen_type [54] = Y5624_pgtype36;
	Y5624_gen_type [55] = Y5624_pgtype37;
	Y5624_gen_type [56] = Y5624_pgtype38;
	Y5624_gen_type [57] = Y5624_pgtype39;
	Y5624_gen_type [58] = Y5624_pgtype40;
	Y5624_gen_type [59] = Y5624_pgtype41;
	Y5624_gen_type [60] = Y5624_pgtype42;
	Y5624_gen_type [61] = Y5624_pgtype43;
	Y5624_gen_type [62] = Y5624_pgtype44;
	Y5624_gen_type [63] = Y5624_pgtype45;
	Y5624_gen_type [64] = Y5624_pgtype46;
	Y5624_gen_type [65] = Y5624_pgtype47;
	Y5624_gen_type [66] = Y5624_pgtype48;
	Y5624_gen_type [67] = Y5624_pgtype49;
	Y5624_gen_type [68] = Y5624_pgtype50;
	Y5624_gen_type [69] = Y5624_pgtype51;
	Y5624_gen_type [70] = Y5624_pgtype52;
	Y5624_gen_type [71] = Y5624_pgtype53;
	Y5624_gen_type [72] = Y5624_pgtype54;
	Y5624_gen_type [73] = Y5624_pgtype55;
	Y5624_gen_type [74] = Y5624_pgtype56;
	Y5624_gen_type [75] = Y5624_pgtype57;
	Y5624_gen_type [76] = Y5624_pgtype58;
	Y5624[42] = 1066;
	Y5624[43] = 115;
	Y5624[45] = 47;
	Y5624[54] = 44;
}

char *(*R5634[39])();
void R5634_init () {
	R5634[0] = (char *(*)()) F1145_7568;
	R5634[1] = (char *(*)()) F1146_7568;
	R5634[2] = (char *(*)()) F1147_7568;
	R5634[3] = (char *(*)()) F1148_7568;
	{long i; for (i = 4; i < 6; i++) R5634[i] = (char *(*)()) F1145_7568;}
	R5634[7] = (char *(*)()) F1145_7568;
	R5634[14] = (char *(*)()) F1159_7713;
	R5634[15] = (char *(*)()) F1160_7713;
	R5634[16] = (char *(*)()) F1159_7713;
	R5634[25] = (char *(*)()) F1162_7814;
	R5634[26] = (char *(*)()) F1164_7814;
	R5634[35] = (char *(*)()) F1162_7814;
	R5634[36] = (char *(*)()) F1163_7814;
	R5634[37] = (char *(*)()) F1164_7814;
	R5634[38] = (char *(*)()) F1165_7814;
}

char *(*R5635[39])();
void R5635_init () {
	R5635[0] = (char *(*)()) F1107_7322;
	R5635[1] = (char *(*)()) F1109_7322;
	R5635[2] = (char *(*)()) F1110_7322;
	R5635[3] = (char *(*)()) F1108_7322;
	{long i; for (i = 4; i < 6; i++) R5635[i] = (char *(*)()) F1107_7322;}
	R5635[7] = (char *(*)()) F1107_7322;
	R5635[14] = (char *(*)()) F1107_7322;
	R5635[15] = (char *(*)()) F1108_7322;
	R5635[16] = (char *(*)()) F1107_7322;
	R5635[25] = (char *(*)()) F1107_7322;
	R5635[26] = (char *(*)()) F1108_7322;
	{long i; for (i = 35; i < 37; i++) R5635[i] = (char *(*)()) F1107_7322;}
	R5635[37] = (char *(*)()) F1108_7322;
	R5635[38] = (char *(*)()) F1111_7322;
}

char *(*R5636[39])();
void R5636_init () {
	R5636[0] = (char *(*)()) F1145_7571;
	R5636[1] = (char *(*)()) F1146_7571;
	R5636[2] = (char *(*)()) F1147_7571;
	R5636[3] = (char *(*)()) F1148_7571;
	{long i; for (i = 4; i < 6; i++) R5636[i] = (char *(*)()) F1145_7571;}
	R5636[7] = (char *(*)()) F1145_7571;
	R5636[14] = (char *(*)()) F1159_7716;
	R5636[15] = (char *(*)()) F1160_7716;
	R5636[16] = (char *(*)()) F1159_7716;
	R5636[25] = (char *(*)()) F1162_7817;
	R5636[26] = (char *(*)()) F1164_7817;
	R5636[35] = (char *(*)()) F1162_7817;
	R5636[36] = (char *(*)()) F1163_7817;
	R5636[37] = (char *(*)()) F1164_7817;
	R5636[38] = (char *(*)()) F1165_7817;
}

char *(*R5637[39])();
void R5637_init () {
	R5637[0] = (char *(*)()) F1145_7573;
	R5637[1] = (char *(*)()) F1146_7573;
	R5637[2] = (char *(*)()) F1147_7573;
	R5637[3] = (char *(*)()) F1148_7573;
	{long i; for (i = 4; i < 6; i++) R5637[i] = (char *(*)()) F1145_7573;}
	R5637[7] = (char *(*)()) F1145_7573;
	R5637[14] = (char *(*)()) F1159_7718;
	R5637[15] = (char *(*)()) F1160_7718;
	R5637[16] = (char *(*)()) F1159_7718;
	R5637[25] = (char *(*)()) F1162_7819;
	R5637[26] = (char *(*)()) F1164_7819;
	R5637[35] = (char *(*)()) F1162_7819;
	R5637[36] = (char *(*)()) F1163_7819;
	R5637[37] = (char *(*)()) F1164_7819;
	R5637[38] = (char *(*)()) F1165_7819;
}

char *(*R5638[39])();
void R5638_init () {
	R5638[0] = (char *(*)()) F1145_7575;
	R5638[1] = (char *(*)()) F1146_7575_5638_14;
	R5638[2] = (char *(*)()) F1147_7575_5638_14;
	R5638[3] = (char *(*)()) F1148_7575_5638_14;
	{long i; for (i = 4; i < 6; i++) R5638[i] = (char *(*)()) F1145_7575;}
	R5638[7] = (char *(*)()) F1145_7575;
	R5638[14] = (char *(*)()) F1159_7720;
	R5638[15] = (char *(*)()) F1160_7720_5638_14;
	R5638[16] = (char *(*)()) F1159_7720;
	R5638[25] = (char *(*)()) F1162_7821;
	R5638[26] = (char *(*)()) F1164_7821_5638_14;
	R5638[35] = (char *(*)()) F1162_7821;
	R5638[36] = (char *(*)()) F1163_7821;
	R5638[37] = (char *(*)()) F1164_7821_5638_14;
	R5638[38] = (char *(*)()) F1165_7821_5638_14;
}
static void F1146_7575_5638_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1146_7575(Current, arg1, *(EIF_CHARACTER_8 *)arg2);
}
static void F1147_7575_5638_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1147_7575(Current, arg1, *(EIF_BOOLEAN *)arg2);
}
static void F1148_7575_5638_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1148_7575(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1160_7720_5638_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1160_7720(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1164_7821_5638_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1164_7821(Current, arg1, *(EIF_INTEGER_32 *)arg2);
}
static void F1165_7821_5638_14 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	F1165_7821(Current, arg1, *(EIF_NATURAL_64 *)arg2);
}

char *(*R5639[39])();
void R5639_init () {
	R5639[0] = (char *(*)()) F1145_7577;
	R5639[1] = (char *(*)()) F1146_7577;
	R5639[2] = (char *(*)()) F1147_7577;
	R5639[3] = (char *(*)()) F1148_7577;
	{long i; for (i = 4; i < 6; i++) R5639[i] = (char *(*)()) F1145_7577;}
	R5639[7] = (char *(*)()) F1145_7577;
	R5639[14] = (char *(*)()) F1159_7722;
	R5639[15] = (char *(*)()) F1160_7722;
	R5639[16] = (char *(*)()) F1159_7722;
	R5639[25] = (char *(*)()) F1162_7823;
	R5639[26] = (char *(*)()) F1164_7823;
	R5639[35] = (char *(*)()) F1162_7823;
	R5639[36] = (char *(*)()) F1163_7823;
	R5639[37] = (char *(*)()) F1164_7823;
	R5639[38] = (char *(*)()) F1165_7823;
}

char *(*R5640[17])();
void R5640_init () {
	R5640[0] = (char *(*)()) F1145_7504;
	R5640[1] = (char *(*)()) F1146_7504_5640_1;
	R5640[2] = (char *(*)()) F1147_7504_5640_1;
	R5640[3] = (char *(*)()) F1148_7504_5640_1;
	{long i; for (i = 4; i < 6; i++) R5640[i] = (char *(*)()) F1145_7504;}
	R5640[7] = (char *(*)()) F1145_7504;
	R5640[14] = (char *(*)()) F1159_7655;
	R5640[15] = (char *(*)()) F1160_7655_5640_1;
	R5640[16] = (char *(*)()) F1159_7655;
}
static EIF_REFERENCE F1146_7504_5640_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1146_7504(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1147_7504_5640_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1147_7504(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(867, 0x00).id, 867, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1148_7504_5640_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1148_7504(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1160_7655_5640_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1160_7655(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5647[39])();
void R5647_init () {
	R5647[0] = (char *(*)()) F1145_7569;
	R5647[1] = (char *(*)()) F1146_7569;
	R5647[2] = (char *(*)()) F1147_7569;
	R5647[3] = (char *(*)()) F1148_7569;
	{long i; for (i = 4; i < 6; i++) R5647[i] = (char *(*)()) F1145_7569;}
	R5647[7] = (char *(*)()) F1145_7569;
	R5647[14] = (char *(*)()) F1159_7714;
	R5647[15] = (char *(*)()) F1160_7714;
	R5647[16] = (char *(*)()) F1159_7714;
	R5647[25] = (char *(*)()) F1162_7815;
	R5647[26] = (char *(*)()) F1164_7815;
	R5647[35] = (char *(*)()) F1162_7815;
	R5647[36] = (char *(*)()) F1163_7815;
	R5647[37] = (char *(*)()) F1164_7815;
	R5647[38] = (char *(*)()) F1165_7815;
}

char *(*R5660[4])();
void R5660_init () {
	R5660[0] = (char *(*)()) F1172_7936;
	R5660[1] = (char *(*)()) F1173_7936_5660_5;
	R5660[2] = (char *(*)()) F1174_7936_5660_5;
	R5660[3] = (char *(*)()) F1175_7936_5660_5;
}
static EIF_REFERENCE F1173_7936_5660_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1173_7936(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1174_7936_5660_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1174_7936(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1175_7936_5660_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1175_7936(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(846, 0x00).id, 846, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R5661[5])();
void R5661_init () {
	R5661[0] = (char *(*)()) F1157_7619;
	R5661[1] = (char *(*)()) F1158_7619;
	R5661[2] = (char *(*)()) F1159_7661;
	R5661[3] = (char *(*)()) F1160_7661;
	R5661[4] = (char *(*)()) F1159_7661;
}

char *(*R5662[17])();
void R5662_init () {
	R5662[0] = (char *(*)()) F1145_7522;
	R5662[1] = (char *(*)()) F1146_7522_5662_4;
	R5662[2] = (char *(*)()) F1147_7522_5662_4;
	R5662[3] = (char *(*)()) F1148_7522_5662_4;
	{long i; for (i = 4; i < 6; i++) R5662[i] = (char *(*)()) F1145_7522;}
	R5662[7] = (char *(*)()) F1145_7522;
	R5662[14] = (char *(*)()) F1159_7666;
	R5662[15] = (char *(*)()) F1160_7666_5662_4;
	R5662[16] = (char *(*)()) F1159_7666;
}
static void F1146_7522_5662_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1146_7522(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1147_7522_5662_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1147_7522(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1148_7522_5662_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1148_7522(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1160_7666_5662_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1160_7666(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5663[17])();
void R5663_init () {
	R5663[0] = (char *(*)()) F1145_7523;
	R5663[1] = (char *(*)()) F1146_7523_5663_4;
	R5663[2] = (char *(*)()) F1147_7523_5663_4;
	R5663[3] = (char *(*)()) F1148_7523_5663_4;
	{long i; for (i = 4; i < 6; i++) R5663[i] = (char *(*)()) F1145_7523;}
	R5663[7] = (char *(*)()) F1145_7523;
	R5663[12] = (char *(*)()) F1157_7628_5663_4;
	R5663[13] = (char *(*)()) F1158_7628_5663_4;
	R5663[14] = (char *(*)()) F1159_7671;
	R5663[15] = (char *(*)()) F1160_7671_5663_4;
	R5663[16] = (char *(*)()) F1159_7671;
}
static void F1146_7523_5663_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1146_7523(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F1147_7523_5663_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1147_7523(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1148_7523_5663_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1148_7523(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1157_7628_5663_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1157_7628(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1158_7628_5663_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1158_7628(Current, *(EIF_BOOLEAN *)arg1);
}
static void F1160_7671_5663_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1160_7671(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R5664[3])();
void R5664_init () {
	R5664[0] = (char *(*)()) F1159_7676;
	R5664[1] = (char *(*)()) F1160_7676;
	R5664[2] = (char *(*)()) F1159_7676;
}

char *(*R5692[17])();
void R5692_init () {
	R5692[0] = (char *(*)()) F1145_7502;
	R5692[1] = (char *(*)()) F1146_7502_5692_28;
	R5692[2] = (char *(*)()) F1147_7502_5692_28;
	R5692[3] = (char *(*)()) F1148_7502_5692_28;
	{long i; for (i = 4; i < 6; i++) R5692[i] = (char *(*)()) F1145_7502;}
	R5692[7] = (char *(*)()) F1145_7502;
	R5692[14] = (char *(*)()) F1159_7653;
	R5692[15] = (char *(*)()) F1160_7653_5692_28;
	R5692[16] = (char *(*)()) F1159_7653;
}
static EIF_REFERENCE F1146_7502_5692_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1146_7502(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1147_7502_5692_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F1147_7502(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(867, 0x00).id, 867, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1148_7502_5692_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1148_7502(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1160_7653_5692_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1160_7653(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R5696[3])();
void R5696_init () {
	R5696[0] = (char *(*)()) F1159_7667;
	R5696[1] = (char *(*)()) F1160_7667_5696_133;
	R5696[2] = (char *(*)()) F1159_7667;
}
static void F1160_7667_5696_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1160_7667(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R5699[17])();
void R5699_init () {
	R5699[0] = (char *(*)()) F1145_7524;
	R5699[1] = (char *(*)()) F1146_7524_5699_133;
	R5699[2] = (char *(*)()) F1147_7524_5699_133;
	R5699[3] = (char *(*)()) F1148_7524_5699_133;
	{long i; for (i = 4; i < 6; i++) R5699[i] = (char *(*)()) F1145_7524;}
	R5699[7] = (char *(*)()) F1145_7524;
	R5699[14] = (char *(*)()) F1159_7664;
	R5699[15] = (char *(*)()) F1160_7664_5699_133;
	R5699[16] = (char *(*)()) F1159_7664;
}
static void F1146_7524_5699_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1146_7524(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F1147_7524_5699_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1147_7524(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F1148_7524_5699_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1148_7524(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1160_7664_5699_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1160_7664(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}

char *(*R5700[17])();
void R5700_init () {
	R5700[0] = (char *(*)()) F1145_7531;
	R5700[1] = (char *(*)()) F1146_7531;
	R5700[2] = (char *(*)()) F1147_7531;
	R5700[3] = (char *(*)()) F1148_7531;
	{long i; for (i = 4; i < 6; i++) R5700[i] = (char *(*)()) F1145_7531;}
	R5700[7] = (char *(*)()) F1145_7531;
	R5700[14] = (char *(*)()) F1137_7438;
	R5700[15] = (char *(*)()) F1138_7438;
	R5700[16] = (char *(*)()) F1137_7438;
}

char *(*R5705[8])();
void R5705_init () {
	R5705[0] = (char *(*)()) F1145_7542;
	R5705[1] = (char *(*)()) F1146_7542;
	R5705[2] = (char *(*)()) F1147_7542;
	R5705[3] = (char *(*)()) F1148_7542;
	{long i; for (i = 4; i < 6; i++) R5705[i] = (char *(*)()) F1145_7542;}
	R5705[7] = (char *(*)()) F1145_7542;
}

char *(*R5706[17])();
void R5706_init () {
	R5706[0] = (char *(*)()) F1145_7543;
	R5706[1] = (char *(*)()) F1146_7543;
	R5706[2] = (char *(*)()) F1147_7543;
	R5706[3] = (char *(*)()) F1148_7543;
	{long i; for (i = 4; i < 6; i++) R5706[i] = (char *(*)()) F1145_7543;}
	R5706[7] = (char *(*)()) F1151_7595;
	R5706[14] = (char *(*)()) F1159_7686;
	R5706[15] = (char *(*)()) F1160_7686;
	R5706[16] = (char *(*)()) F1159_7686;
}

char *(*R5707[3])();
void R5707_init () {
	R5707[0] = (char *(*)()) F1159_7687;
	R5707[1] = (char *(*)()) F1160_7687;
	R5707[2] = (char *(*)()) F1159_7687;
}

char *(*R5737[17])();
void R5737_init () {
	R5737[0] = (char *(*)()) F1145_7545;
	R5737[1] = (char *(*)()) F1146_7545;
	R5737[2] = (char *(*)()) F1147_7545;
	R5737[3] = (char *(*)()) F1148_7545;
	{long i; for (i = 4; i < 6; i++) R5737[i] = (char *(*)()) F1145_7545;}
	R5737[7] = (char *(*)()) F1151_7596;
	R5737[14] = (char *(*)()) F1159_7688;
	R5737[15] = (char *(*)()) F1160_7688;
	R5737[16] = (char *(*)()) F1159_7688;
}

char *(*R5747[17])();
void R5747_init () {
	R5747[0] = (char *(*)()) F1145_7567;
	R5747[1] = (char *(*)()) F1146_7567;
	R5747[2] = (char *(*)()) F1147_7567;
	R5747[3] = (char *(*)()) F1148_7567;
	{long i; for (i = 4; i < 6; i++) R5747[i] = (char *(*)()) F1145_7567;}
	R5747[7] = (char *(*)()) F1145_7567;
	R5747[14] = (char *(*)()) F1159_7712;
	R5747[15] = (char *(*)()) F1160_7712;
	R5747[16] = (char *(*)()) F1159_7712;
}

char *(*R5755[8])();
void R5755_init () {
	R5755[0] = (char *(*)()) F1145_7559;
	R5755[1] = (char *(*)()) F1146_7559;
	R5755[2] = (char *(*)()) F1147_7559;
	R5755[3] = (char *(*)()) F1148_7559;
	{long i; for (i = 4; i < 6; i++) R5755[i] = (char *(*)()) F1145_7559;}
	R5755[7] = (char *(*)()) F1151_7602;
}

char *(*R5756[8])();
void R5756_init () {
	R5756[0] = (char *(*)()) F1145_7560;
	R5756[1] = (char *(*)()) F1146_7560;
	R5756[2] = (char *(*)()) F1147_7560;
	R5756[3] = (char *(*)()) F1148_7560;
	{long i; for (i = 4; i < 6; i++) R5756[i] = (char *(*)()) F1145_7560;}
	R5756[7] = (char *(*)()) F1145_7560;
}

char *(*R5757[8])();
void R5757_init () {
	R5757[0] = (char *(*)()) F1145_7563;
	R5757[1] = (char *(*)()) F1146_7563;
	R5757[2] = (char *(*)()) F1147_7563;
	R5757[3] = (char *(*)()) F1148_7563;
	{long i; for (i = 4; i < 6; i++) R5757[i] = (char *(*)()) F1145_7563;}
	R5757[7] = (char *(*)()) F1145_7563;
}

char *(*R5758[8])();
void R5758_init () {
	R5758[0] = (char *(*)()) F1145_7564;
	R5758[1] = (char *(*)()) F1146_7564;
	R5758[2] = (char *(*)()) F1147_7564;
	R5758[3] = (char *(*)()) F1148_7564;
	{long i; for (i = 4; i < 6; i++) R5758[i] = (char *(*)()) F1145_7564;}
	R5758[7] = (char *(*)()) F1145_7564;
}

char *(*R5759[8])();
void R5759_init () {
	R5759[0] = (char *(*)()) F1145_7565;
	R5759[1] = (char *(*)()) F1146_7565;
	R5759[2] = (char *(*)()) F1147_7565;
	R5759[3] = (char *(*)()) F1148_7565;
	{long i; for (i = 4; i < 6; i++) R5759[i] = (char *(*)()) F1145_7565;}
	R5759[7] = (char *(*)()) F1145_7565;
}

char *(*R5774[27])();
void R5774_init () {
	R5774[0] = (char *(*)()) F1157_7623;
	R5774[1] = (char *(*)()) F1158_7623;
	R5774[2] = (char *(*)()) F1159_7658;
	R5774[3] = (char *(*)()) F1160_7658;
	R5774[4] = (char *(*)()) F1159_7658;
	R5774[13] = (char *(*)()) F1162_7743;
	R5774[14] = (char *(*)()) F1164_7743;
	R5774[23] = (char *(*)()) F1162_7743;
	R5774[24] = (char *(*)()) F1163_7743;
	R5774[25] = (char *(*)()) F1164_7743;
	R5774[26] = (char *(*)()) F1165_7743;
}

char *(*R5777[27])();
void R5777_init () {
	R5777[0] = (char *(*)()) F1157_7636;
	R5777[1] = (char *(*)()) F1158_7636;
	R5777[2] = (char *(*)()) F1159_7700;
	R5777[3] = (char *(*)()) F1160_7700;
	R5777[4] = (char *(*)()) F1159_7700;
	R5777[13] = (char *(*)()) F1162_7761;
	R5777[14] = (char *(*)()) F1164_7761;
	R5777[23] = (char *(*)()) F1162_7761;
	R5777[24] = (char *(*)()) F1163_7761;
	R5777[25] = (char *(*)()) F1164_7761;
	R5777[26] = (char *(*)()) F1165_7761;
}

char *(*R5778[27])();
void R5778_init () {
	R5778[0] = (char *(*)()) F1154_7614;
	R5778[1] = (char *(*)()) F1155_7614;
	R5778[2] = (char *(*)()) F1153_7614;
	R5778[3] = (char *(*)()) F1154_7614;
	R5778[4] = (char *(*)()) F1153_7614;
	R5778[13] = (char *(*)()) F1162_7826;
	R5778[14] = (char *(*)()) F1164_7826;
	R5778[23] = (char *(*)()) F1162_7826;
	R5778[24] = (char *(*)()) F1163_7826;
	R5778[25] = (char *(*)()) F1164_7826;
	R5778[26] = (char *(*)()) F1165_7826;
}

char *(*R5792[3])();
void R5792_init () {
	R5792[0] = (char *(*)()) F1159_7702;
	R5792[1] = (char *(*)()) F1160_7702;
	R5792[2] = (char *(*)()) F1159_7702;
}

char *(*R5793[3])();
void R5793_init () {
	R5793[0] = (char *(*)()) F1159_7703;
	R5793[1] = (char *(*)()) F1160_7703;
	R5793[2] = (char *(*)()) F1159_7703;
}

char *(*R5795[3])();
void R5795_init () {
	R5795[0] = (char *(*)()) F1159_7707;
	R5795[1] = (char *(*)()) F1160_7707;
	R5795[2] = (char *(*)()) F1159_7707;
}

char *(*R5796[3])();
void R5796_init () {
	R5796[0] = (char *(*)()) F1159_7708;
	R5796[1] = (char *(*)()) F1160_7708;
	R5796[2] = (char *(*)()) F1159_7708;
}

char *(*R5797[3])();
void R5797_init () {
	R5797[0] = (char *(*)()) F1159_7709;
	R5797[1] = (char *(*)()) F1160_7709;
	R5797[2] = (char *(*)()) F1159_7709;
}

char *(*R5798[3])();
void R5798_init () {
	R5798[0] = (char *(*)()) F1159_7710;
	R5798[1] = (char *(*)()) F1160_7710;
	R5798[2] = (char *(*)()) F1159_7710;
}

char *(*R5799[3])();
void R5799_init () {
	R5799[0] = (char *(*)()) F1159_7727;
	R5799[1] = (char *(*)()) F1160_7727;
	R5799[2] = (char *(*)()) F1159_7727;
}

char *(*R5812[14])();
void R5812_init () {
	R5812[0] = (char *(*)()) F1162_7737;
	R5812[1] = (char *(*)()) F1164_7737;
	R5812[10] = (char *(*)()) F1162_7737;
	R5812[11] = (char *(*)()) F1163_7737;
	R5812[12] = (char *(*)()) F1164_7737;
	R5812[13] = (char *(*)()) F1165_7737;
}

char *(*R5814[14])();
void R5814_init () {
	R5814[0] = (char *(*)()) F1162_7746;
	R5814[1] = (char *(*)()) F1164_7746;
	R5814[10] = (char *(*)()) F1162_7746;
	R5814[11] = (char *(*)()) F1163_7746;
	R5814[12] = (char *(*)()) F1164_7746;
	R5814[13] = (char *(*)()) F1165_7746;
}

char *(*R5815[14])();
void R5815_init () {
	R5815[0] = (char *(*)()) F1166_7837;
	R5815[1] = (char *(*)()) F1167_7837_5815_4;
	R5815[10] = (char *(*)()) F1172_7911;
	R5815[11] = (char *(*)()) F1173_7911_5815_4;
	R5815[12] = (char *(*)()) F1174_7911_5815_4;
	R5815[13] = (char *(*)()) F1175_7911_5815_4;
}
static void F1167_7837_5815_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1167_7837(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1173_7911_5815_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1173_7911(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1174_7911_5815_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1174_7911(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1175_7911_5815_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1175_7911(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R5816[14])();
void R5816_init () {
	R5816[0] = (char *(*)()) F1162_7756;
	R5816[1] = (char *(*)()) F1164_7756;
	R5816[10] = (char *(*)()) F1162_7756;
	R5816[11] = (char *(*)()) F1163_7756;
	R5816[12] = (char *(*)()) F1164_7756;
	R5816[13] = (char *(*)()) F1165_7756;
}

char *(*R5821[14])();
void R5821_init () {
	R5821[0] = (char *(*)()) F1168_7863;
	R5821[1] = (char *(*)()) F1169_7863_5821_28;
	R5821[10] = (char *(*)()) F1176_7938;
	R5821[11] = (char *(*)()) F1177_7938;
	R5821[12] = (char *(*)()) F1178_7938_5821_28;
	R5821[13] = (char *(*)()) F1179_7938_5821_28;
}
static EIF_REFERENCE F1169_7863_5821_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1169_7863(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1178_7938_5821_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1178_7938(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1179_7938_5821_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1179_7938(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(843, 0x00).id, 843, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}

char *(*R5822[14])();
void R5822_init () {
	R5822[0] = (char *(*)()) F1168_7867;
	R5822[1] = (char *(*)()) F1169_7867_5822_133;
	R5822[10] = (char *(*)()) F1176_7939;
	R5822[11] = (char *(*)()) F1177_7939;
	R5822[12] = (char *(*)()) F1178_7939_5822_133;
	R5822[13] = (char *(*)()) F1179_7939_5822_133;
}
static void F1169_7867_5822_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1169_7867(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1178_7939_5822_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1178_7939(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1179_7939_5822_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1179_7939(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}

char *(*R5823[14])();
void R5823_init () {
	R5823[0] = (char *(*)()) F1166_7853;
	R5823[1] = (char *(*)()) F1167_7853_5823_28;
	R5823[10] = (char *(*)()) F1176_7940;
	R5823[11] = (char *(*)()) F1177_7940_5823_28;
	R5823[12] = (char *(*)()) F1178_7940_5823_28;
	R5823[13] = (char *(*)()) F1179_7940_5823_28;
}
static EIF_REFERENCE F1167_7853_5823_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1167_7853(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1177_7940_5823_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1177_7940(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1178_7940_5823_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1178_7940(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1179_7940_5823_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F1179_7940(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(846, 0x00).id, 846, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}

char *(*R5824[14])();
void R5824_init () {
	R5824[0] = (char *(*)()) F1168_7864;
	R5824[1] = (char *(*)()) F1169_7864;
	R5824[10] = (char *(*)()) F1176_7941;
	R5824[11] = (char *(*)()) F1177_7941;
	R5824[12] = (char *(*)()) F1178_7941;
	R5824[13] = (char *(*)()) F1179_7941;
}

char *(*R5827[14])();
void R5827_init () {
	R5827[0] = (char *(*)()) F1162_7770;
	R5827[1] = (char *(*)()) F1164_7770_5827_4;
	R5827[10] = (char *(*)()) F1162_7770;
	R5827[11] = (char *(*)()) F1163_7770_5827_4;
	R5827[12] = (char *(*)()) F1164_7770_5827_4;
	R5827[13] = (char *(*)()) F1165_7770_5827_4;
}
static void F1164_7770_5827_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1164_7770(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1163_7770_5827_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1163_7770(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1165_7770_5827_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1165_7770(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R5828[14])();
void R5828_init () {
	R5828[0] = (char *(*)()) F1162_7771;
	R5828[1] = (char *(*)()) F1164_7771_5828_21;
	R5828[10] = (char *(*)()) F1162_7771;
	R5828[11] = (char *(*)()) F1163_7771_5828_21;
	R5828[12] = (char *(*)()) F1164_7771_5828_21;
	R5828[13] = (char *(*)()) F1165_7771_5828_21;
}
static EIF_INTEGER_32 F1164_7771_5828_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1164_7771(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F1163_7771_5828_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1163_7771(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F1165_7771_5828_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1165_7771(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R5829[14])();
void R5829_init () {
	R5829[0] = (char *(*)()) F1166_7854;
	R5829[1] = (char *(*)()) F1167_7854;
	R5829[10] = (char *(*)()) F1172_7906;
	R5829[11] = (char *(*)()) F1173_7906;
	R5829[12] = (char *(*)()) F1174_7906;
	R5829[13] = (char *(*)()) F1175_7906;
}

char *(*R5831[14])();
void R5831_init () {
	R5831[0] = (char *(*)()) F1170_7891;
	R5831[1] = (char *(*)()) F1171_7891_5831_21;
	R5831[10] = (char *(*)()) F1180_7975;
	R5831[11] = (char *(*)()) F1181_7975_5831_21;
	R5831[12] = (char *(*)()) F1182_7975_5831_21;
	R5831[13] = (char *(*)()) F1183_7975_5831_21;
}
static EIF_INTEGER_32 F1171_7891_5831_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1171_7891(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F1181_7975_5831_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1181_7975(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F1182_7975_5831_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1182_7975(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F1183_7975_5831_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1183_7975(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R5833[14])();
void R5833_init () {
	R5833[0] = (char *(*)()) F1168_7866;
	R5833[1] = (char *(*)()) F1169_7866;
	R5833[10] = (char *(*)()) F1176_7943;
	R5833[11] = (char *(*)()) F1177_7943;
	R5833[12] = (char *(*)()) F1178_7943;
	R5833[13] = (char *(*)()) F1179_7943;
}

char *(*R5834[14])();
void R5834_init () {
	R5834[0] = (char *(*)()) F1168_7868;
	R5834[1] = (char *(*)()) F1169_7868;
	R5834[10] = (char *(*)()) F1176_7944;
	R5834[11] = (char *(*)()) F1177_7944;
	R5834[12] = (char *(*)()) F1178_7944;
	R5834[13] = (char *(*)()) F1179_7944;
}

char *(*R5835[14])();
void R5835_init () {
	R5835[0] = (char *(*)()) F1168_7869;
	R5835[1] = (char *(*)()) F1169_7869;
	R5835[10] = (char *(*)()) F1176_7945;
	R5835[11] = (char *(*)()) F1177_7945;
	R5835[12] = (char *(*)()) F1178_7945;
	R5835[13] = (char *(*)()) F1179_7945;
}

char *(*R5836[14])();
void R5836_init () {
	R5836[0] = (char *(*)()) F1168_7870;
	R5836[1] = (char *(*)()) F1169_7870;
	R5836[10] = (char *(*)()) F1176_7946;
	R5836[11] = (char *(*)()) F1177_7946;
	R5836[12] = (char *(*)()) F1178_7946;
	R5836[13] = (char *(*)()) F1179_7946;
}

char *(*R5838[14])();
void R5838_init () {
	R5838[0] = (char *(*)()) F1166_7856;
	R5838[1] = (char *(*)()) F1167_7856;
	R5838[10] = (char *(*)()) F1176_7949;
	R5838[11] = (char *(*)()) F1177_7949;
	R5838[12] = (char *(*)()) F1178_7949;
	R5838[13] = (char *(*)()) F1179_7949;
}

char *(*R5839[4])();
void R5839_init () {
	R5839[0] = (char *(*)()) F1176_7950;
	R5839[1] = (char *(*)()) F1177_7950_5839_133;
	R5839[2] = (char *(*)()) F1178_7950_5839_133;
	R5839[3] = (char *(*)()) F1179_7950_5839_133;
}
static void F1177_7950_5839_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1177_7950(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1178_7950_5839_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1178_7950(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F1179_7950_5839_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F1179_7950(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}

char *(*R5840[14])();
void R5840_init () {
	R5840[0] = (char *(*)()) F1166_7858;
	R5840[1] = (char *(*)()) F1167_7858;
	R5840[10] = (char *(*)()) F1176_7951;
	R5840[11] = (char *(*)()) F1177_7951;
	R5840[12] = (char *(*)()) F1178_7951;
	R5840[13] = (char *(*)()) F1179_7951;
}

char *(*R5841[14])();
void R5841_init () {
	R5841[0] = (char *(*)()) F1166_7859;
	R5841[1] = (char *(*)()) F1167_7859;
	R5841[10] = (char *(*)()) F1176_7952;
	R5841[11] = (char *(*)()) F1177_7952;
	R5841[12] = (char *(*)()) F1178_7952;
	R5841[13] = (char *(*)()) F1179_7952;
}

char *(*R5842[14])();
void R5842_init () {
	R5842[0] = (char *(*)()) F1166_7860;
	R5842[1] = (char *(*)()) F1167_7860;
	R5842[10] = (char *(*)()) F1176_7953;
	R5842[11] = (char *(*)()) F1177_7953;
	R5842[12] = (char *(*)()) F1178_7953;
	R5842[13] = (char *(*)()) F1179_7953;
}

char *(*R5844[14])();
void R5844_init () {
	R5844[0] = (char *(*)()) F1168_7873;
	R5844[1] = (char *(*)()) F1169_7873;
	R5844[10] = (char *(*)()) F1176_7956;
	R5844[11] = (char *(*)()) F1177_7956;
	R5844[12] = (char *(*)()) F1178_7956;
	R5844[13] = (char *(*)()) F1179_7956;
}

char *(*R5845[14])();
void R5845_init () {
	R5845[0] = (char *(*)()) F1168_7874;
	R5845[1] = (char *(*)()) F1169_7874;
	R5845[10] = (char *(*)()) F1176_7957;
	R5845[11] = (char *(*)()) F1177_7957;
	R5845[12] = (char *(*)()) F1178_7957;
	R5845[13] = (char *(*)()) F1179_7957;
}

char *(*R5846[14])();
void R5846_init () {
	R5846[0] = (char *(*)()) F1168_7875;
	R5846[1] = (char *(*)()) F1169_7875;
	R5846[10] = (char *(*)()) F1176_7958;
	R5846[11] = (char *(*)()) F1177_7958;
	R5846[12] = (char *(*)()) F1178_7958;
	R5846[13] = (char *(*)()) F1179_7958;
}

char *(*R5847[14])();
void R5847_init () {
	R5847[0] = (char *(*)()) F1168_7876;
	R5847[1] = (char *(*)()) F1169_7876;
	R5847[10] = (char *(*)()) F1176_7959;
	R5847[11] = (char *(*)()) F1177_7959;
	R5847[12] = (char *(*)()) F1178_7959;
	R5847[13] = (char *(*)()) F1179_7959;
}

char *(*R5848[14])();
void R5848_init () {
	R5848[0] = (char *(*)()) F1168_7877;
	R5848[1] = (char *(*)()) F1169_7877;
	R5848[10] = (char *(*)()) F1176_7960;
	R5848[11] = (char *(*)()) F1177_7960;
	R5848[12] = (char *(*)()) F1178_7960;
	R5848[13] = (char *(*)()) F1179_7960;
}

char *(*R5849[14])();
void R5849_init () {
	R5849[0] = (char *(*)()) F1168_7879;
	R5849[1] = (char *(*)()) F1169_7879;
	R5849[10] = (char *(*)()) F1176_7962;
	R5849[11] = (char *(*)()) F1177_7962;
	R5849[12] = (char *(*)()) F1178_7962;
	R5849[13] = (char *(*)()) F1179_7962;
}

char *(*R5850[14])();
void R5850_init () {
	R5850[0] = (char *(*)()) F1168_7880;
	R5850[1] = (char *(*)()) F1169_7880;
	R5850[10] = (char *(*)()) F1176_7963;
	R5850[11] = (char *(*)()) F1177_7963;
	R5850[12] = (char *(*)()) F1178_7963;
	R5850[13] = (char *(*)()) F1179_7963;
}

char *(*R5851[14])();
void R5851_init () {
	R5851[0] = (char *(*)()) F1168_7881;
	R5851[1] = (char *(*)()) F1169_7881;
	R5851[10] = (char *(*)()) F1176_7964;
	R5851[11] = (char *(*)()) F1177_7964;
	R5851[12] = (char *(*)()) F1178_7964;
	R5851[13] = (char *(*)()) F1179_7964;
}

char *(*R5852[14])();
void R5852_init () {
	R5852[0] = (char *(*)()) F1168_7882;
	R5852[1] = (char *(*)()) F1169_7882;
	R5852[10] = (char *(*)()) F1176_7965;
	R5852[11] = (char *(*)()) F1177_7965;
	R5852[12] = (char *(*)()) F1178_7965;
	R5852[13] = (char *(*)()) F1179_7965;
}

char *(*R5853[14])();
void R5853_init () {
	R5853[0] = (char *(*)()) F1168_7883;
	R5853[1] = (char *(*)()) F1169_7883;
	R5853[10] = (char *(*)()) F1176_7966;
	R5853[11] = (char *(*)()) F1177_7966;
	R5853[12] = (char *(*)()) F1178_7966;
	R5853[13] = (char *(*)()) F1179_7966;
}

char *(*R5854[14])();
void R5854_init () {
	R5854[0] = (char *(*)()) F1168_7884;
	R5854[1] = (char *(*)()) F1169_7884;
	R5854[10] = (char *(*)()) F1176_7967;
	R5854[11] = (char *(*)()) F1177_7967;
	R5854[12] = (char *(*)()) F1178_7967;
	R5854[13] = (char *(*)()) F1179_7967;
}

char *(*R5864[14])();
void R5864_init () {
	R5864[0] = (char *(*)()) F1162_7809;
	R5864[1] = (char *(*)()) F1164_7809;
	R5864[10] = (char *(*)()) F1162_7809;
	R5864[11] = (char *(*)()) F1163_7809;
	R5864[12] = (char *(*)()) F1164_7809;
	R5864[13] = (char *(*)()) F1165_7809;
}

char *(*R5868[14])();
void R5868_init () {
	R5868[0] = (char *(*)()) F1162_7827;
	R5868[1] = (char *(*)()) F1164_7827;
	R5868[10] = (char *(*)()) F1162_7827;
	R5868[11] = (char *(*)()) F1163_7827;
	R5868[12] = (char *(*)()) F1164_7827;
	R5868[13] = (char *(*)()) F1165_7827;
}

char *(*R5878[2])();
void R5878_init () {
	R5878[0] = (char *(*)()) F1168_7887;
	R5878[1] = (char *(*)()) F1169_7887;
}

char *(*R5883[4])();
void R5883_init () {
	R5883[0] = (char *(*)()) F1172_7895;
	R5883[1] = (char *(*)()) F1173_7895;
	R5883[2] = (char *(*)()) F1174_7895;
	R5883[3] = (char *(*)()) F1175_7895;
}

char *(*R5886[4])();
void R5886_init () {
	R5886[0] = (char *(*)()) F1172_7898;
	R5886[1] = (char *(*)()) F1173_7898;
	R5886[2] = (char *(*)()) F1174_7898;
	R5886[3] = (char *(*)()) F1175_7898;
}

char *(*R5892[4])();
void R5892_init () {
	R5892[0] = (char *(*)()) F1172_7915;
	R5892[1] = (char *(*)()) F1173_7915;
	R5892[2] = (char *(*)()) F1174_7915_5892_4;
	R5892[3] = (char *(*)()) F1175_7915_5892_4;
}
static void F1174_7915_5892_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1174_7915(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F1175_7915_5892_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F1175_7915(Current, *(EIF_NATURAL_64 *)arg1);
}

char *(*R5908[4])();
void R5908_init () {
	R5908[0] = (char *(*)()) F1176_7971;
	R5908[1] = (char *(*)()) F1177_7971;
	R5908[2] = (char *(*)()) F1178_7971;
	R5908[3] = (char *(*)()) F1179_7971;
}

char *(*R6011[2])();
void R6011_init () {
	R6011[0] = (char *(*)()) F1189_8132;
	R6011[1] = (char *(*)()) F1190_8160;
}

char *(*R6043[2])();
void R6043_init () {
	R6043[0] = (char *(*)()) F1192_8186;
	R6043[1] = (char *(*)()) F1193_8205;
}

char *(*R6423[38])();
void R6423_init () {
	R6423[0] = (char *(*)()) F1205_8626;
	R6423[1] = (char *(*)()) F1206_8629;
	R6423[2] = (char *(*)()) F1207_8632;
	R6423[3] = (char *(*)()) F1208_8635;
	R6423[4] = (char *(*)()) F1209_8638;
	R6423[5] = (char *(*)()) F1210_8641;
	R6423[6] = (char *(*)()) F1211_8644;
	R6423[7] = (char *(*)()) F1212_8647;
	R6423[8] = (char *(*)()) F1213_8650;
	R6423[9] = (char *(*)()) F1214_8653;
	R6423[10] = (char *(*)()) F1215_8656;
	R6423[11] = (char *(*)()) F1216_8659;
	R6423[12] = (char *(*)()) F1217_8662;
	R6423[13] = (char *(*)()) F1218_8665;
	R6423[14] = (char *(*)()) F1219_8668;
	R6423[15] = (char *(*)()) F1220_8671;
	R6423[16] = (char *(*)()) F1221_8674;
	R6423[17] = (char *(*)()) F1222_8677;
	R6423[18] = (char *(*)()) F1223_8680;
	R6423[19] = (char *(*)()) F1224_8683;
	R6423[20] = (char *(*)()) F1225_8686;
	R6423[21] = (char *(*)()) F1226_8689;
	R6423[22] = (char *(*)()) F1227_8692;
	R6423[23] = (char *(*)()) F1228_8695;
	R6423[24] = (char *(*)()) F1229_8698;
	R6423[25] = (char *(*)()) F1230_8701;
	R6423[26] = (char *(*)()) F1231_8704;
	R6423[27] = (char *(*)()) F1232_8707;
	R6423[28] = (char *(*)()) F1233_8710;
	R6423[29] = (char *(*)()) F1234_8713;
	R6423[30] = (char *(*)()) F1235_8716;
	R6423[31] = (char *(*)()) F1236_8724;
	R6423[32] = (char *(*)()) F1237_8739;
	R6423[33] = (char *(*)()) F1238_8742;
	R6423[34] = (char *(*)()) F1239_8745;
	R6423[35] = (char *(*)()) F1240_8748;
	R6423[36] = (char *(*)()) F1241_8751;
	R6423[37] = (char *(*)()) F1242_8754;
}
char *(*R2[1249])();
void R2_init () {}
char *(*R6[1249])();
void R6_init () {}

char *(*R3[1249])();
void R3_init () {
	R3[220] = (char *(*)()) F221_2128;
	R3[953] = (char *(*)()) F954_6247;
	R3[1050] = (char *(*)()) F273_2741;
	R3[1055] = (char *(*)()) F273_2741;
}

char *(*R4[1249])();
void R4_init () {
	R4[2] = (char *(*)()) F1_15;
	R4[4] = (char *(*)()) F1_15;
	{long i; for (i = 6; i < 9; i++) R4[i] = (char *(*)()) F1_15;}
	R4[15] = (char *(*)()) F1_15;
	{long i; for (i = 17; i < 25; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 27; i < 30; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 42; i < 48; i++) R4[i] = (char *(*)()) F1_15;}
	R4[66] = (char *(*)()) F1_15;
	{long i; for (i = 75; i < 78; i++) R4[i] = (char *(*)()) F1_15;}
	R4[86] = (char *(*)()) F1_15;
	{long i; for (i = 95; i < 97; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 98; i < 104; i++) R4[i] = (char *(*)()) F1_15;}
	R4[108] = (char *(*)()) F1_15;
	R4[116] = (char *(*)()) F1_15;
	{long i; for (i = 120; i < 122; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 140; i < 142; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 143; i < 145; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 152; i < 159; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 162; i < 166; i++) R4[i] = (char *(*)()) F1_15;}
	R4[170] = (char *(*)()) F1_15;
	{long i; for (i = 177; i < 181; i++) R4[i] = (char *(*)()) F1_15;}
	R4[184] = (char *(*)()) F1_15;
	{long i; for (i = 186; i < 189; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 190; i < 193; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 194; i < 196; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 198; i < 200; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 201; i < 204; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 205; i < 209; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 210; i < 212; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 213; i < 219; i++) R4[i] = (char *(*)()) F1_15;}
	R4[220] = (char *(*)()) F221_2047;
	{long i; for (i = 224; i < 232; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 234; i < 236; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 237; i < 239; i++) R4[i] = (char *(*)()) F1_15;}
	R4[242] = (char *(*)()) F1_15;
	{long i; for (i = 260; i < 262; i++) R4[i] = (char *(*)()) F1_15;}
	R4[263] = (char *(*)()) F264_2590;
	R4[266] = (char *(*)()) F1_15;
	{long i; for (i = 269; i < 272; i++) R4[i] = (char *(*)()) F1_15;}
	R4[354] = (char *(*)()) F1_15;
	R4[357] = (char *(*)()) F1_15;
	{long i; for (i = 401; i < 406; i++) R4[i] = (char *(*)()) F1_15;}
	R4[598] = (char *(*)()) F1_15;
	{long i; for (i = 676; i < 688; i++) R4[i] = (char *(*)()) F1_15;}
	R4[701] = (char *(*)()) F702_3738;
	R4[702] = (char *(*)()) F703_3738;
	R4[703] = (char *(*)()) F704_3738;
	R4[704] = (char *(*)()) F705_3738;
	R4[705] = (char *(*)()) F706_3738;
	R4[706] = (char *(*)()) F707_3738;
	R4[707] = (char *(*)()) F708_3738;
	R4[708] = (char *(*)()) F709_3738;
	R4[709] = (char *(*)()) F710_3738;
	R4[710] = (char *(*)()) F711_3738;
	R4[711] = (char *(*)()) F712_3738;
	R4[712] = (char *(*)()) F713_3738;
	R4[713] = (char *(*)()) F702_3738;
	R4[714] = (char *(*)()) F703_3738;
	R4[715] = (char *(*)()) F708_3738;
	R4[716] = (char *(*)()) F705_3738;
	R4[717] = (char *(*)()) F713_3738;
	R4[718] = (char *(*)()) F707_3738;
	R4[785] = (char *(*)()) F786_4019;
	R4[786] = (char *(*)()) F787_4019;
	R4[787] = (char *(*)()) F788_4019;
	R4[788] = (char *(*)()) F789_4019;
	R4[789] = (char *(*)()) F790_4019;
	R4[792] = (char *(*)()) F786_4019;
	R4[795] = (char *(*)()) F796_4134;
	R4[796] = (char *(*)()) F797_4176;
	{long i; for (i = 797; i < 829; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 830; i < 832; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 833; i < 835; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 836; i < 838; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 839; i < 841; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 842; i < 844; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 845; i < 847; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 848; i < 850; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 851; i < 853; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 854; i < 856; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 857; i < 859; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 860; i < 862; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 863; i < 865; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 866; i < 868; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 869; i < 901; i++) R4[i] = (char *(*)()) F1_15;}
	R4[905] = (char *(*)()) F905_5448;
	R4[910] = (char *(*)()) F911_5642;
	R4[911] = (char *(*)()) F910_5623;
	R4[913] = (char *(*)()) F914_5807;
	R4[914] = (char *(*)()) F913_5791;
	{long i; for (i = 918; i < 921; i++) R4[i] = (char *(*)()) F1_15;}
	R4[922] = (char *(*)()) F1_15;
	{long i; for (i = 927; i < 929; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 935; i < 944; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 946; i < 948; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 953; i < 960; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1019] = (char *(*)()) F975_6707;
	R4[1020] = (char *(*)()) F976_6707;
	{long i; for (i = 1029; i < 1031; i++) R4[i] = (char *(*)()) F975_6707;}
	R4[1031] = (char *(*)()) F976_6707;
	R4[1032] = (char *(*)()) F979_6707;
	R4[1037] = (char *(*)()) F975_6707;
	R4[1038] = (char *(*)()) F976_6707;
	R4[1039] = (char *(*)()) F975_6707;
	R4[1040] = (char *(*)()) F977_6707;
	R4[1041] = (char *(*)()) F978_6707;
	R4[1042] = (char *(*)()) F976_6707;
	R4[1043] = (char *(*)()) F975_6707;
	R4[1047] = (char *(*)()) F1_15;
	R4[1050] = (char *(*)()) F1_15;
	R4[1055] = (char *(*)()) F1_15;
	R4[1066] = (char *(*)()) F1067_7051;
	{long i; for (i = 1068; i < 1070; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1071] = (char *(*)()) F1072_7100;
	{long i; for (i = 1074; i < 1076; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1077; i < 1080; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1144] = (char *(*)()) F1145_7518;
	R4[1145] = (char *(*)()) F1146_7518;
	R4[1146] = (char *(*)()) F1147_7518;
	R4[1147] = (char *(*)()) F1148_7518;
	{long i; for (i = 1148; i < 1150; i++) R4[i] = (char *(*)()) F1145_7518;}
	R4[1151] = (char *(*)()) F1145_7518;
	R4[1156] = (char *(*)()) F1157_7625;
	R4[1157] = (char *(*)()) F1158_7625;
	R4[1158] = (char *(*)()) F1159_7662;
	R4[1159] = (char *(*)()) F1160_7662;
	R4[1160] = (char *(*)()) F1159_7662;
	R4[1169] = (char *(*)()) F1162_7757;
	R4[1170] = (char *(*)()) F1164_7757;
	R4[1179] = (char *(*)()) F1172_7924;
	R4[1180] = (char *(*)()) F1173_7924;
	R4[1181] = (char *(*)()) F1174_7924;
	R4[1182] = (char *(*)()) F1175_7924;
	{long i; for (i = 1188; i < 1190; i++) R4[i] = (char *(*)()) F1_15;}
	{long i; for (i = 1191; i < 1193; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1195] = (char *(*)()) F1_15;
	R4[1201] = (char *(*)()) F1_15;
	{long i; for (i = 1204; i < 1242; i++) R4[i] = (char *(*)()) F1_15;}
	R4[1247] = (char *(*)()) F1248_9011;
}

char *(*R5[1249])();
void R5_init () {
	R5[2] = (char *(*)()) F1_8;
	R5[4] = (char *(*)()) F1_8;
	{long i; for (i = 6; i < 9; i++) R5[i] = (char *(*)()) F1_8;}
	R5[15] = (char *(*)()) F1_8;
	{long i; for (i = 17; i < 25; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 27; i < 30; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 42; i < 48; i++) R5[i] = (char *(*)()) F1_8;}
	R5[66] = (char *(*)()) F1_8;
	{long i; for (i = 75; i < 78; i++) R5[i] = (char *(*)()) F1_8;}
	R5[86] = (char *(*)()) F1_8;
	{long i; for (i = 95; i < 97; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 98; i < 104; i++) R5[i] = (char *(*)()) F1_8;}
	R5[108] = (char *(*)()) F1_8;
	R5[116] = (char *(*)()) F1_8;
	{long i; for (i = 120; i < 122; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 140; i < 142; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 143; i < 145; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 152; i < 159; i++) R5[i] = (char *(*)()) F1_8;}
	R5[162] = (char *(*)()) F161_1704;
	{long i; for (i = 163; i < 166; i++) R5[i] = (char *(*)()) F1_8;}
	R5[170] = (char *(*)()) F1_8;
	{long i; for (i = 177; i < 181; i++) R5[i] = (char *(*)()) F1_8;}
	R5[184] = (char *(*)()) F1_8;
	{long i; for (i = 186; i < 189; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 190; i < 193; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 194; i < 196; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 198; i < 200; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 201; i < 204; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 205; i < 209; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 210; i < 212; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 213; i < 219; i++) R5[i] = (char *(*)()) F1_8;}
	R5[220] = (char *(*)()) F221_2046;
	{long i; for (i = 224; i < 232; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 234; i < 236; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 237; i < 239; i++) R5[i] = (char *(*)()) F1_8;}
	R5[242] = (char *(*)()) F1_8;
	R5[260] = (char *(*)()) F1_8;
	R5[261] = (char *(*)()) F262_2481;
	R5[263] = (char *(*)()) F264_2589;
	R5[266] = (char *(*)()) F1_8;
	{long i; for (i = 269; i < 272; i++) R5[i] = (char *(*)()) F1_8;}
	R5[354] = (char *(*)()) F1_8;
	R5[357] = (char *(*)()) F1_8;
	{long i; for (i = 401; i < 406; i++) R5[i] = (char *(*)()) F1_8;}
	R5[598] = (char *(*)()) F1_8;
	{long i; for (i = 676; i < 688; i++) R5[i] = (char *(*)()) F1_8;}
	R5[701] = (char *(*)()) F702_3700;
	R5[702] = (char *(*)()) F703_3700;
	R5[703] = (char *(*)()) F704_3700;
	R5[704] = (char *(*)()) F705_3700;
	R5[705] = (char *(*)()) F706_3700;
	R5[706] = (char *(*)()) F707_3700;
	R5[707] = (char *(*)()) F708_3700;
	R5[708] = (char *(*)()) F709_3700;
	R5[709] = (char *(*)()) F710_3700;
	R5[710] = (char *(*)()) F711_3700;
	R5[711] = (char *(*)()) F712_3700;
	R5[712] = (char *(*)()) F713_3700;
	R5[713] = (char *(*)()) F702_3700;
	R5[714] = (char *(*)()) F703_3700;
	R5[715] = (char *(*)()) F708_3700;
	R5[716] = (char *(*)()) F705_3700;
	R5[717] = (char *(*)()) F713_3700;
	R5[718] = (char *(*)()) F707_3700;
	R5[785] = (char *(*)()) F786_3985;
	R5[786] = (char *(*)()) F787_3985;
	R5[787] = (char *(*)()) F788_3985;
	R5[788] = (char *(*)()) F789_3985;
	R5[789] = (char *(*)()) F790_3985;
	R5[792] = (char *(*)()) F786_3985;
	R5[795] = (char *(*)()) F796_4131;
	R5[796] = (char *(*)()) F797_4168;
	R5[797] = (char *(*)()) F798_4201;
	R5[798] = (char *(*)()) F799_4201;
	R5[799] = (char *(*)()) F800_4201;
	R5[800] = (char *(*)()) F801_4201;
	R5[801] = (char *(*)()) F802_4201;
	R5[802] = (char *(*)()) F803_4201;
	R5[803] = (char *(*)()) F804_4201;
	R5[804] = (char *(*)()) F805_4201;
	R5[805] = (char *(*)()) F806_4201;
	R5[806] = (char *(*)()) F807_4201;
	R5[807] = (char *(*)()) F808_4201;
	R5[808] = (char *(*)()) F809_4201;
	R5[809] = (char *(*)()) F810_4201;
	R5[810] = (char *(*)()) F811_4201;
	R5[811] = (char *(*)()) F812_4201;
	R5[812] = (char *(*)()) F813_4201;
	R5[813] = (char *(*)()) F814_4201;
	R5[814] = (char *(*)()) F815_4201;
	R5[815] = (char *(*)()) F816_4201;
	R5[816] = (char *(*)()) F817_4201;
	R5[817] = (char *(*)()) F818_4201;
	R5[818] = (char *(*)()) F819_4201;
	R5[819] = (char *(*)()) F820_4201;
	R5[820] = (char *(*)()) F821_4201;
	R5[821] = (char *(*)()) F822_4201;
	R5[822] = (char *(*)()) F823_4201;
	R5[823] = (char *(*)()) F824_4201;
	R5[824] = (char *(*)()) F825_4201;
	R5[825] = (char *(*)()) F826_4201;
	R5[826] = (char *(*)()) F827_4201;
	R5[827] = (char *(*)()) F828_4201;
	R5[828] = (char *(*)()) F829_4244;
	{long i; for (i = 830; i < 832; i++) R5[i] = (char *(*)()) F830_4362;}
	{long i; for (i = 833; i < 835; i++) R5[i] = (char *(*)()) F833_4460;}
	{long i; for (i = 836; i < 838; i++) R5[i] = (char *(*)()) F836_4559;}
	{long i; for (i = 839; i < 841; i++) R5[i] = (char *(*)()) F839_4658;}
	{long i; for (i = 842; i < 844; i++) R5[i] = (char *(*)()) F842_4757;}
	{long i; for (i = 845; i < 847; i++) R5[i] = (char *(*)()) F845_4851;}
	{long i; for (i = 848; i < 850; i++) R5[i] = (char *(*)()) F848_4945;}
	{long i; for (i = 851; i < 853; i++) R5[i] = (char *(*)()) F851_5040;}
	{long i; for (i = 854; i < 856; i++) R5[i] = (char *(*)()) F854_5139;}
	{long i; for (i = 857; i < 859; i++) R5[i] = (char *(*)()) F857_5205;}
	{long i; for (i = 860; i < 862; i++) R5[i] = (char *(*)()) F860_5266;}
	{long i; for (i = 863; i < 865; i++) R5[i] = (char *(*)()) F863_5306;}
	{long i; for (i = 866; i < 868; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 869; i < 901; i++) R5[i] = (char *(*)()) F869_5372;}
	R5[905] = (char *(*)()) F905_5447;
	{long i; for (i = 910; i < 912; i++) R5[i] = (char *(*)()) F910_5608;}
	{long i; for (i = 913; i < 915; i++) R5[i] = (char *(*)()) F913_5776;}
	{long i; for (i = 918; i < 921; i++) R5[i] = (char *(*)()) F1_8;}
	R5[922] = (char *(*)()) F1_8;
	{long i; for (i = 927; i < 929; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 935; i < 944; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 946; i < 948; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 953; i < 960; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1019] = (char *(*)()) F975_6708;
	R5[1020] = (char *(*)()) F976_6708;
	{long i; for (i = 1029; i < 1031; i++) R5[i] = (char *(*)()) F975_6708;}
	R5[1031] = (char *(*)()) F976_6708;
	R5[1032] = (char *(*)()) F979_6708;
	R5[1037] = (char *(*)()) F975_6708;
	R5[1038] = (char *(*)()) F976_6708;
	R5[1039] = (char *(*)()) F975_6708;
	R5[1040] = (char *(*)()) F977_6708;
	R5[1041] = (char *(*)()) F978_6708;
	R5[1042] = (char *(*)()) F976_6708;
	R5[1043] = (char *(*)()) F975_6708;
	R5[1047] = (char *(*)()) F1_8;
	R5[1050] = (char *(*)()) F1_8;
	R5[1055] = (char *(*)()) F1_8;
	R5[1066] = (char *(*)()) F1067_7052;
	R5[1068] = (char *(*)()) F1069_7064;
	R5[1069] = (char *(*)()) F1070_7084;
	R5[1071] = (char *(*)()) F1072_7101;
	{long i; for (i = 1074; i < 1076; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1077; i < 1080; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1144] = (char *(*)()) F1145_7519;
	R5[1145] = (char *(*)()) F1146_7519;
	R5[1146] = (char *(*)()) F1147_7519;
	R5[1147] = (char *(*)()) F1148_7519;
	{long i; for (i = 1148; i < 1150; i++) R5[i] = (char *(*)()) F1145_7519;}
	R5[1151] = (char *(*)()) F1145_7519;
	R5[1156] = (char *(*)()) F1157_7626;
	R5[1157] = (char *(*)()) F1158_7626;
	R5[1158] = (char *(*)()) F1159_7663;
	R5[1159] = (char *(*)()) F1160_7663;
	R5[1160] = (char *(*)()) F1159_7663;
	R5[1169] = (char *(*)()) F1166_7838;
	R5[1170] = (char *(*)()) F1167_7838;
	R5[1179] = (char *(*)()) F1172_7912;
	R5[1180] = (char *(*)()) F1173_7912;
	R5[1181] = (char *(*)()) F1174_7912;
	R5[1182] = (char *(*)()) F1175_7912;
	{long i; for (i = 1188; i < 1190; i++) R5[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1191; i < 1193; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1195] = (char *(*)()) F1_8;
	R5[1201] = (char *(*)()) F1_8;
	{long i; for (i = 1204; i < 1242; i++) R5[i] = (char *(*)()) F1_8;}
	R5[1247] = (char *(*)()) F1248_8968;
}


#ifdef __cplusplus
}
#endif
