#include "epoly1.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R11[1246])();
void R11_init () {
	R11[0] = (char *(*)()) F1_8;
	R11[2] = (char *(*)()) F1_8;
	{long i; for (i = 4; i < 7; i++) R11[i] = (char *(*)()) F1_8;}
	R11[13] = (char *(*)()) F1_8;
	{long i; for (i = 15; i < 23; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 25; i < 28; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 40; i < 46; i++) R11[i] = (char *(*)()) F1_8;}
	R11[64] = (char *(*)()) F1_8;
	{long i; for (i = 73; i < 76; i++) R11[i] = (char *(*)()) F1_8;}
	R11[84] = (char *(*)()) F1_8;
	{long i; for (i = 93; i < 95; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 96; i < 102; i++) R11[i] = (char *(*)()) F1_8;}
	R11[106] = (char *(*)()) F1_8;
	R11[114] = (char *(*)()) F1_8;
	{long i; for (i = 118; i < 120; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 138; i < 140; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 141; i < 143; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 150; i < 157; i++) R11[i] = (char *(*)()) F1_8;}
	R11[160] = (char *(*)()) F161_1704;
	{long i; for (i = 161; i < 164; i++) R11[i] = (char *(*)()) F1_8;}
	R11[168] = (char *(*)()) F1_8;
	{long i; for (i = 175; i < 179; i++) R11[i] = (char *(*)()) F1_8;}
	R11[182] = (char *(*)()) F1_8;
	{long i; for (i = 184; i < 187; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 188; i < 191; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 192; i < 194; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 196; i < 198; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 199; i < 202; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 203; i < 207; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 208; i < 210; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 211; i < 217; i++) R11[i] = (char *(*)()) F1_8;}
	R11[218] = (char *(*)()) F221_2046;
	{long i; for (i = 222; i < 230; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 232; i < 234; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 235; i < 237; i++) R11[i] = (char *(*)()) F1_8;}
	R11[240] = (char *(*)()) F1_8;
	R11[258] = (char *(*)()) F1_8;
	R11[259] = (char *(*)()) F262_2481;
	R11[261] = (char *(*)()) F264_2589;
	R11[264] = (char *(*)()) F1_8;
	{long i; for (i = 267; i < 270; i++) R11[i] = (char *(*)()) F1_8;}
	R11[352] = (char *(*)()) F1_8;
	R11[355] = (char *(*)()) F1_8;
	{long i; for (i = 399; i < 404; i++) R11[i] = (char *(*)()) F1_8;}
	R11[596] = (char *(*)()) F1_8;
	{long i; for (i = 674; i < 686; i++) R11[i] = (char *(*)()) F1_8;}
	R11[699] = (char *(*)()) F702_3700;
	R11[700] = (char *(*)()) F703_3700;
	R11[701] = (char *(*)()) F704_3700;
	R11[702] = (char *(*)()) F705_3700;
	R11[703] = (char *(*)()) F706_3700;
	R11[704] = (char *(*)()) F707_3700;
	R11[705] = (char *(*)()) F708_3700;
	R11[706] = (char *(*)()) F709_3700;
	R11[707] = (char *(*)()) F710_3700;
	R11[708] = (char *(*)()) F711_3700;
	R11[709] = (char *(*)()) F712_3700;
	R11[710] = (char *(*)()) F713_3700;
	R11[711] = (char *(*)()) F702_3700;
	R11[712] = (char *(*)()) F703_3700;
	R11[713] = (char *(*)()) F708_3700;
	R11[714] = (char *(*)()) F705_3700;
	R11[715] = (char *(*)()) F713_3700;
	R11[716] = (char *(*)()) F707_3700;
	R11[783] = (char *(*)()) F786_3985;
	R11[784] = (char *(*)()) F787_3985;
	R11[785] = (char *(*)()) F788_3985;
	R11[786] = (char *(*)()) F789_3985;
	R11[787] = (char *(*)()) F790_3985;
	R11[790] = (char *(*)()) F786_3985;
	R11[793] = (char *(*)()) F796_4131;
	R11[794] = (char *(*)()) F797_4168;
	R11[795] = (char *(*)()) F798_4201;
	R11[796] = (char *(*)()) F799_4201;
	R11[797] = (char *(*)()) F800_4201;
	R11[798] = (char *(*)()) F801_4201;
	R11[799] = (char *(*)()) F802_4201;
	R11[800] = (char *(*)()) F803_4201;
	R11[801] = (char *(*)()) F804_4201;
	R11[802] = (char *(*)()) F805_4201;
	R11[803] = (char *(*)()) F806_4201;
	R11[804] = (char *(*)()) F807_4201;
	R11[805] = (char *(*)()) F808_4201;
	R11[806] = (char *(*)()) F809_4201;
	R11[807] = (char *(*)()) F810_4201;
	R11[808] = (char *(*)()) F811_4201;
	R11[809] = (char *(*)()) F812_4201;
	R11[810] = (char *(*)()) F813_4201;
	R11[811] = (char *(*)()) F814_4201;
	R11[812] = (char *(*)()) F815_4201;
	R11[813] = (char *(*)()) F816_4201;
	R11[814] = (char *(*)()) F817_4201;
	R11[815] = (char *(*)()) F818_4201;
	R11[816] = (char *(*)()) F819_4201;
	R11[817] = (char *(*)()) F820_4201;
	R11[818] = (char *(*)()) F821_4201;
	R11[819] = (char *(*)()) F822_4201;
	R11[820] = (char *(*)()) F823_4201;
	R11[821] = (char *(*)()) F824_4201;
	R11[822] = (char *(*)()) F825_4201;
	R11[823] = (char *(*)()) F826_4201;
	R11[824] = (char *(*)()) F827_4201;
	R11[825] = (char *(*)()) F828_4201;
	R11[826] = (char *(*)()) F829_4244;
	{long i; for (i = 828; i < 830; i++) R11[i] = (char *(*)()) F830_4362;}
	{long i; for (i = 831; i < 833; i++) R11[i] = (char *(*)()) F833_4460;}
	{long i; for (i = 834; i < 836; i++) R11[i] = (char *(*)()) F836_4559;}
	{long i; for (i = 837; i < 839; i++) R11[i] = (char *(*)()) F839_4658;}
	{long i; for (i = 840; i < 842; i++) R11[i] = (char *(*)()) F842_4757;}
	{long i; for (i = 843; i < 845; i++) R11[i] = (char *(*)()) F845_4851;}
	{long i; for (i = 846; i < 848; i++) R11[i] = (char *(*)()) F848_4945;}
	{long i; for (i = 849; i < 851; i++) R11[i] = (char *(*)()) F851_5040;}
	{long i; for (i = 852; i < 854; i++) R11[i] = (char *(*)()) F854_5139;}
	{long i; for (i = 855; i < 857; i++) R11[i] = (char *(*)()) F857_5205;}
	{long i; for (i = 858; i < 860; i++) R11[i] = (char *(*)()) F860_5266;}
	{long i; for (i = 861; i < 863; i++) R11[i] = (char *(*)()) F863_5306;}
	{long i; for (i = 864; i < 866; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 867; i < 899; i++) R11[i] = (char *(*)()) F869_5372;}
	R11[903] = (char *(*)()) F905_5447;
	{long i; for (i = 908; i < 910; i++) R11[i] = (char *(*)()) F910_5608;}
	{long i; for (i = 911; i < 913; i++) R11[i] = (char *(*)()) F913_5776;}
	{long i; for (i = 916; i < 919; i++) R11[i] = (char *(*)()) F1_8;}
	R11[920] = (char *(*)()) F1_8;
	{long i; for (i = 925; i < 927; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 933; i < 942; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 944; i < 946; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 951; i < 958; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1017] = (char *(*)()) F975_6708;
	R11[1018] = (char *(*)()) F976_6708;
	{long i; for (i = 1027; i < 1029; i++) R11[i] = (char *(*)()) F975_6708;}
	R11[1029] = (char *(*)()) F976_6708;
	R11[1030] = (char *(*)()) F979_6708;
	R11[1035] = (char *(*)()) F975_6708;
	R11[1036] = (char *(*)()) F976_6708;
	R11[1037] = (char *(*)()) F975_6708;
	R11[1038] = (char *(*)()) F977_6708;
	R11[1039] = (char *(*)()) F978_6708;
	R11[1040] = (char *(*)()) F976_6708;
	R11[1041] = (char *(*)()) F975_6708;
	R11[1045] = (char *(*)()) F1_8;
	R11[1048] = (char *(*)()) F1_8;
	R11[1053] = (char *(*)()) F1_8;
	R11[1064] = (char *(*)()) F1067_7052;
	R11[1066] = (char *(*)()) F1069_7064;
	R11[1067] = (char *(*)()) F1070_7084;
	R11[1069] = (char *(*)()) F1072_7101;
	{long i; for (i = 1072; i < 1074; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1075; i < 1078; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1142] = (char *(*)()) F1145_7519;
	R11[1143] = (char *(*)()) F1146_7519;
	R11[1144] = (char *(*)()) F1147_7519;
	R11[1145] = (char *(*)()) F1148_7519;
	{long i; for (i = 1146; i < 1148; i++) R11[i] = (char *(*)()) F1145_7519;}
	R11[1149] = (char *(*)()) F1145_7519;
	R11[1154] = (char *(*)()) F1157_7626;
	R11[1155] = (char *(*)()) F1158_7626;
	R11[1156] = (char *(*)()) F1159_7663;
	R11[1157] = (char *(*)()) F1160_7663;
	R11[1158] = (char *(*)()) F1159_7663;
	R11[1167] = (char *(*)()) F1166_7838;
	R11[1168] = (char *(*)()) F1167_7838;
	R11[1177] = (char *(*)()) F1172_7912;
	R11[1178] = (char *(*)()) F1173_7912;
	R11[1179] = (char *(*)()) F1174_7912;
	R11[1180] = (char *(*)()) F1175_7912;
	{long i; for (i = 1186; i < 1188; i++) R11[i] = (char *(*)()) F1_8;}
	{long i; for (i = 1189; i < 1191; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1193] = (char *(*)()) F1_8;
	R11[1199] = (char *(*)()) F1_8;
	{long i; for (i = 1202; i < 1240; i++) R11[i] = (char *(*)()) F1_8;}
	R11[1245] = (char *(*)()) F1248_8968;
}

char *(*R271[6])();
void R271_init () {
	R271[0] = (char *(*)()) F20_267;
	R271[1] = (char *(*)()) F21_267;
	R271[2] = (char *(*)()) F22_267;
	R271[3] = (char *(*)()) F23_267;
	R271[4] = (char *(*)()) F24_267;
	R271[5] = (char *(*)()) F25_267;
}

char *(*R276[6])();
void R276_init () {
	R276[0] = (char *(*)()) F20_272;
	R276[1] = (char *(*)()) F21_272_276_41;
	R276[2] = (char *(*)()) F22_272_276_41;
	R276[3] = (char *(*)()) F23_272_276_41;
	R276[4] = (char *(*)()) F24_272_276_41;
	R276[5] = (char *(*)()) F25_272_276_41;
}
static void F21_272_276_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F21_272(Current, arg1, *(EIF_INTEGER_32 *)arg2, arg3);
}
static void F22_272_276_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F22_272(Current, arg1, *(EIF_BOOLEAN *)arg2, arg3);
}
static void F23_272_276_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F23_272(Current, arg1, *(EIF_NATURAL_32 *)arg2, arg3);
}
static void F24_272_276_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F24_272(Current, arg1, *(EIF_NATURAL_64 *)arg2, arg3);
}
static void F25_272_276_41 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	F25_272(Current, arg1, *(EIF_CHARACTER_8 *)arg2, arg3);
}

char *(*R279[6])();
void R279_init () {
	R279[0] = (char *(*)()) F20_275;
	R279[1] = (char *(*)()) F21_275;
	R279[2] = (char *(*)()) F22_275;
	R279[3] = (char *(*)()) F23_275;
	R279[4] = (char *(*)()) F24_275;
	R279[5] = (char *(*)()) F25_275;
}

char *(*R803[4])();
void R803_init () {
	R803[0] = (char *(*)()) F1172_7901;
	R803[1] = (char *(*)()) F1173_7901_803_5;
	R803[2] = (char *(*)()) F1174_7901_803_5;
	R803[3] = (char *(*)()) F1175_7901_803_5;
}
static EIF_REFERENCE F1173_7901_803_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F1173_7901(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_REFERENCE F1174_7901_803_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F1174_7901(Current, *(EIF_INTEGER_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1175_7901_803_5 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F1175_7901(Current, *(EIF_NATURAL_32 *)arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(843, 0x00).id, 843, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}

static EIF_TYPE_INDEX Y805_pgtype0[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype1[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype2[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype3[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype4[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype5[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype6[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype7[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype8[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype9[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype10[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype11[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype12[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype13[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype14[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype15[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype16[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype17[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype18[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype19[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype20[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype21[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype22[] = {0xFFF8,2,0xFFFF};
static EIF_TYPE_INDEX Y805_pgtype23[] = {0xFFF8,2,0xFFFF};
EIF_TYPE_INDEX *Y805_gen_type [1130];
EIF_TYPE_INDEX Y805 [1130];
void Y805_init (void)
{
	egc_routines_types [805] = Y805;
	egc_routines_gen_types [805] = Y805_gen_type;
	egc_routines_offset [805] = 53;
	Y805_gen_type [0] = Y805_pgtype0;
	Y805_gen_type [1] = Y805_pgtype1;
	Y805_gen_type [2] = Y805_pgtype2;
	Y805_gen_type [3] = Y805_pgtype3;
	Y805_gen_type [1033] = Y805_pgtype4;
	Y805_gen_type [1034] = Y805_pgtype5;
	Y805_gen_type [1035] = Y805_pgtype6;
	Y805_gen_type [1036] = Y805_pgtype7;
	Y805_gen_type [1069] = Y805_pgtype8;
	Y805_gen_type [1070] = Y805_pgtype9;
	Y805_gen_type [1071] = Y805_pgtype10;
	Y805_gen_type [1072] = Y805_pgtype11;
	Y805_gen_type [1118] = Y805_pgtype12;
	Y805_gen_type [1119] = Y805_pgtype13;
	Y805_gen_type [1120] = Y805_pgtype14;
	Y805_gen_type [1121] = Y805_pgtype15;
	Y805_gen_type [1122] = Y805_pgtype16;
	Y805_gen_type [1123] = Y805_pgtype17;
	Y805_gen_type [1124] = Y805_pgtype18;
	Y805_gen_type [1125] = Y805_pgtype19;
	Y805_gen_type [1126] = Y805_pgtype20;
	Y805_gen_type [1127] = Y805_pgtype21;
	Y805_gen_type [1128] = Y805_pgtype22;
	Y805_gen_type [1129] = Y805_pgtype23;
}

char *(*R951[3])();
void R951_init () {
	{long i; for (i = 0; i < 2; i++) R951[i] = (char *(*)()) F74_955;}
	R951[2] = (char *(*)()) F75_955;
}

char *(*R953[3])();
void R953_init () {
	{long i; for (i = 0; i < 2; i++) R953[i] = (char *(*)()) F74_957;}
	R953[2] = (char *(*)()) F75_957;
}

char *(*R962[3])();
void R962_init () {
	R962[0] = (char *(*)()) F76_961;
	R962[1] = (char *(*)()) F77_962;
	R962[2] = (char *(*)()) F78_962;
}

char *(*R973[321])();
void R973_init () {
	R973[0] = (char *(*)()) F928_5975;
	R973[1] = (char *(*)()) F929_5983;
	R973[123] = (char *(*)()) F1050_6935;
	R973[320] = (char *(*)()) F1248_8983;
}

char *(*R1012[2])();
void R1012_init () {
	R1012[0] = (char *(*)()) F270_2626_1012_28;
	R1012[1] = (char *(*)()) F271_2655_1012_28;
}
static EIF_REFERENCE F270_2626_1012_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F270_2626(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F271_2655_1012_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F271_2655(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R1013[2])();
void R1013_init () {
	R1013[0] = (char *(*)()) F270_2634;
	R1013[1] = (char *(*)()) F271_2659;
}

char *(*R1014[2])();
void R1014_init () {
	R1014[0] = (char *(*)()) F270_2638_1014_133;
	R1014[1] = (char *(*)()) F271_2661_1014_133;
}
static void F270_2638_1014_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F270_2638(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F271_2661_1014_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F271_2661(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}

char *(*R1017[2])();
void R1017_init () {
	R1017[0] = (char *(*)()) F270_2650;
	R1017[1] = (char *(*)()) F271_2668;
}

char *(*R1018[2])();
void R1018_init () {
	R1018[0] = (char *(*)()) F270_2651;
	R1018[1] = (char *(*)()) F271_2669;
}

char *(*R1022[2])();
void R1022_init () {
	R1022[0] = (char *(*)()) F270_2627;
	R1022[1] = (char *(*)()) F93_1019;
}

char *(*R1023[2])();
void R1023_init () {
	R1023[0] = (char *(*)()) F270_2628;
	R1023[1] = (char *(*)()) F93_1020;
}

char *(*R1024[2])();
void R1024_init () {
	R1024[0] = (char *(*)()) F270_2629;
	R1024[1] = (char *(*)()) F271_2656;
}

char *(*R1025[2])();
void R1025_init () {
	R1025[0] = (char *(*)()) F270_2630;
	R1025[1] = (char *(*)()) F271_2657;
}

char *(*R1026[2])();
void R1026_init () {
	R1026[0] = (char *(*)()) F270_2631;
	R1026[1] = (char *(*)()) F271_2658;
}

char *(*R1029[2])();
void R1029_init () {
	R1029[0] = (char *(*)()) F93_1026;
	R1029[1] = (char *(*)()) F271_2660;
}

char *(*R1030[2])();
void R1030_init () {
	R1030[0] = (char *(*)()) F270_2635;
	R1030[1] = (char *(*)()) F93_1027;
}

char *(*R1035[2])();
void R1035_init () {
	R1035[0] = (char *(*)()) F270_2645;
	R1035[1] = (char *(*)()) F271_2665;
}

char *(*R1053[2])();
void R1053_init () {
	R1053[0] = (char *(*)()) F96_1051;
	R1053[1] = (char *(*)()) F97_1071;
}

char *(*R1067[2])();
void R1067_init () {
	R1067[0] = (char *(*)()) F96_1065;
	R1067[1] = (char *(*)()) F97_1074;
}

char *(*R1068[2])();
void R1068_init () {
	R1068[0] = (char *(*)()) F96_1066;
	R1068[1] = (char *(*)()) F97_1075;
}

char *(*R1134[4])();
void R1134_init () {
	R1134[0] = (char *(*)()) F101_1147;
	R1134[1] = (char *(*)()) F102_1147_1134_1;
	R1134[2] = (char *(*)()) F103_1147_1134_1;
	R1134[3] = (char *(*)()) F104_1147_1134_1;
}
static EIF_REFERENCE F102_1147_1134_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F102_1147(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(861, 0x00).id, 861, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F103_1147_1134_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F103_1147(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(843, 0x00).id, 843, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F104_1147_1134_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F104_1147(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R1292[123])();
void R1292_init () {
	R1292[0] = (char *(*)()) F116_1309;
	R1292[4] = (char *(*)()) F121_1362;
	R1292[5] = (char *(*)()) F118_1347;
	R1292[108] = (char *(*)()) F116_1309;
	R1292[121] = (char *(*)()) F238_2155;
	R1292[122] = (char *(*)()) F239_2161;
}

char *(*R1297[123])();
void R1297_init () {
	R1297[0] = (char *(*)()) F116_1314;
	R1297[4] = (char *(*)()) F120_1349;
	R1297[5] = (char *(*)()) F118_1349;
	R1297[108] = (char *(*)()) F116_1314;
	R1297[121] = (char *(*)()) F118_1349;
	R1297[122] = (char *(*)()) F119_1349;
}

char *(*R1300[123])();
void R1300_init () {
	R1300[0] = (char *(*)()) F116_1317;
	R1300[4] = (char *(*)()) F120_1350;
	R1300[5] = (char *(*)()) F118_1350;
	R1300[108] = (char *(*)()) F116_1317;
	R1300[121] = (char *(*)()) F118_1350;
	R1300[122] = (char *(*)()) F119_1350;
}

char *(*R1301[123])();
void R1301_init () {
	R1301[0] = (char *(*)()) F117_1342;
	R1301[4] = (char *(*)()) F120_1354;
	R1301[5] = (char *(*)()) F118_1354;
	R1301[108] = (char *(*)()) F117_1342;
	R1301[121] = (char *(*)()) F118_1354;
	R1301[122] = (char *(*)()) F119_1354;
}

char *(*R1308[123])();
void R1308_init () {
	R1308[0] = (char *(*)()) F117_1343;
	R1308[4] = (char *(*)()) F120_1355;
	R1308[5] = (char *(*)()) F118_1355;
	R1308[108] = (char *(*)()) F117_1343;
	R1308[121] = (char *(*)()) F118_1355;
	R1308[122] = (char *(*)()) F119_1355;
}

char *(*R1309[123])();
void R1309_init () {
	R1309[0] = (char *(*)()) F117_1344;
	R1309[4] = (char *(*)()) F120_1356;
	R1309[5] = (char *(*)()) F118_1356;
	R1309[108] = (char *(*)()) F117_1344;
	R1309[121] = (char *(*)()) F118_1356;
	R1309[122] = (char *(*)()) F119_1356;
}

char *(*R1323[123])();
void R1323_init () {
	R1323[0] = (char *(*)()) F117_1345;
	R1323[4] = (char *(*)()) F121_1366;
	R1323[5] = (char *(*)()) F122_1370;
	R1323[108] = (char *(*)()) F225_2139;
	R1323[121] = (char *(*)()) F238_2160;
	R1323[122] = (char *(*)()) F239_2169;
}

char *(*R1324[123])();
void R1324_init () {
	R1324[0] = (char *(*)()) F117_1346;
	R1324[4] = (char *(*)()) F121_1365;
	R1324[5] = (char *(*)()) F122_1369;
	R1324[108] = (char *(*)()) F117_1346;
	R1324[121] = (char *(*)()) F122_1369;
	R1324[122] = (char *(*)()) F239_2168;
}

char *(*R1326[119])();
void R1326_init () {
	R1326[0] = (char *(*)()) F120_1348_1326_1;
	R1326[1] = (char *(*)()) F118_1348;
	R1326[117] = (char *(*)()) F118_1348;
	R1326[118] = (char *(*)()) F119_1348_1326_1;
}
static EIF_REFERENCE F120_1348_1326_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F120_1348(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F119_1348_1326_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F119_1348(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(867, 0x00).id, 867, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R1329[119])();
void R1329_init () {
	R1329[0] = (char *(*)()) F121_1363;
	R1329[1] = (char *(*)()) F122_1367;
	R1329[117] = (char *(*)()) F122_1367;
	R1329[118] = (char *(*)()) F239_2166;
}

char *(*R1343[110])();
void R1343_init () {
	R1343[0] = (char *(*)()) F947_6181;
	R1343[1] = (char *(*)()) F948_6199;
	R1343[109] = (char *(*)()) F1055_6962;
}

char *(*R1349[110])();
void R1349_init () {
	R1349[0] = (char *(*)()) F947_6180;
	R1349[1] = (char *(*)()) F948_6193;
	R1349[109] = (char *(*)()) F949_6207;
}

char *(*R1351[110])();
void R1351_init () {
	R1351[0] = (char *(*)()) F947_6175;
	R1351[1] = (char *(*)()) F948_6195;
	R1351[109] = (char *(*)()) F1049_6905;
}

char *(*R1352[110])();
void R1352_init () {
	R1352[0] = (char *(*)()) F947_6176_1352_1;
	R1352[1] = (char *(*)()) F948_6196_1352_1;
	R1352[109] = (char *(*)()) F1056_6979_1352_1;
}
static EIF_REFERENCE F947_6176_1352_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F947_6176(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F948_6196_1352_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F948_6196(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1056_6979_1352_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1056_6979(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R1356[687])();
void R1356_init () {
	R1356[0] = (char *(*)()) F128_1386;
	R1356[1] = (char *(*)()) F129_1386_1356_3;
	R1356[686] = (char *(*)()) F921_5931;
}
static EIF_BOOLEAN F129_1386_1356_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F129_1386(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R1357[687])();
void R1357_init () {
	R1357[0] = (char *(*)()) F128_1387;
	R1357[1] = (char *(*)()) F129_1387_1357_3;
	R1357[686] = (char *(*)()) F128_1387;
}
static EIF_BOOLEAN F129_1387_1357_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F129_1387(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R1358[687])();
void R1358_init () {
	R1358[0] = (char *(*)()) F235_2151;
	R1358[1] = (char *(*)()) F236_2151_1358_3;
	R1358[686] = (char *(*)()) F921_5932;
}
static EIF_BOOLEAN F236_2151_1358_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F236_2151(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R1617[7])();
void R1617_init () {
	{long i; for (i = 0; i < 2; i++) R1617[i] = (char *(*)()) F149_1679;}
	R1617[2] = (char *(*)()) F150_1679_1617_1;
	R1617[3] = (char *(*)()) F151_1679_1617_1;
	R1617[4] = (char *(*)()) F152_1679_1617_1;
	R1617[5] = (char *(*)()) F149_1679;
	R1617[6] = (char *(*)()) F151_1679_1617_1;
}
static EIF_REFERENCE F150_1679_1617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F150_1679(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F151_1679_1617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F151_1679(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F152_1679_1617_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F152_1679(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(867, 0x00).id, 867, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R1619[7])();
void R1619_init () {
	{long i; for (i = 0; i < 2; i++) R1619[i] = (char *(*)()) F149_1681;}
	R1619[2] = (char *(*)()) F150_1681_1619_4;
	R1619[3] = (char *(*)()) F151_1681_1619_4;
	R1619[4] = (char *(*)()) F152_1681_1619_4;
	R1619[5] = (char *(*)()) F149_1681;
	R1619[6] = (char *(*)()) F151_1681_1619_4;
}
static void F150_1681_1619_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F150_1681(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F151_1681_1619_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F151_1681(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F152_1681_1619_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F152_1681(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R1620[7])();
void R1620_init () {
	{long i; for (i = 0; i < 2; i++) R1620[i] = (char *(*)()) F149_1682;}
	R1620[2] = (char *(*)()) F150_1682_1620_4;
	R1620[3] = (char *(*)()) F151_1682_1620_4;
	R1620[4] = (char *(*)()) F152_1682_1620_4;
	R1620[5] = (char *(*)()) F149_1682;
	R1620[6] = (char *(*)()) F151_1682_1620_4;
}
static void F150_1682_1620_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F150_1682(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F151_1682_1620_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F151_1682(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F152_1682_1620_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F152_1682(Current, *(EIF_BOOLEAN *)arg1);
}

char *(*R1627[6])();
void R1627_init () {
	R1627[0] = (char *(*)()) F154_1688;
	R1627[1] = (char *(*)()) F155_1688;
	R1627[2] = (char *(*)()) F156_1688;
	R1627[3] = (char *(*)()) F157_1688;
	R1627[4] = (char *(*)()) F158_1691;
	R1627[5] = (char *(*)()) F159_1691;
}

char *(*R1628[6])();
void R1628_init () {
	R1628[0] = (char *(*)()) F154_1689;
	R1628[1] = (char *(*)()) F155_1689;
	R1628[2] = (char *(*)()) F156_1689;
	R1628[3] = (char *(*)()) F157_1689;
	R1628[4] = (char *(*)()) F154_1689;
	R1628[5] = (char *(*)()) F156_1689;
}

char *(*R1631[2])();
void R1631_init () {
	R1631[0] = (char *(*)()) F158_1693;
	R1631[1] = (char *(*)()) F159_1693;
}

char *(*R1632[2])();
void R1632_init () {
	R1632[0] = (char *(*)()) F158_1694;
	R1632[1] = (char *(*)()) F159_1694;
}

char *(*R1633[2])();
void R1633_init () {
	R1633[0] = (char *(*)()) F158_1695;
	R1633[1] = (char *(*)()) F159_1695;
}

char *(*R1634[1086])();
void R1634_init () {
	R1634[0] = (char *(*)()) F163_1731;
	R1634[633] = (char *(*)()) F796_4130;
	R1634[668] = (char *(*)()) F831_4423_1634_2;
	R1634[669] = (char *(*)()) F832_4423_1634_2;
	R1634[671] = (char *(*)()) F834_4522_1634_2;
	R1634[672] = (char *(*)()) F835_4522_1634_2;
	R1634[674] = (char *(*)()) F837_4621_1634_2;
	R1634[675] = (char *(*)()) F838_4621_1634_2;
	R1634[677] = (char *(*)()) F840_4720_1634_2;
	R1634[678] = (char *(*)()) F841_4720_1634_2;
	R1634[680] = (char *(*)()) F843_4815_1634_2;
	R1634[681] = (char *(*)()) F844_4815_1634_2;
	R1634[683] = (char *(*)()) F846_4909_1634_2;
	R1634[684] = (char *(*)()) F847_4909_1634_2;
	R1634[686] = (char *(*)()) F849_5004_1634_2;
	R1634[687] = (char *(*)()) F850_5004_1634_2;
	R1634[689] = (char *(*)()) F852_5099_1634_2;
	R1634[690] = (char *(*)()) F853_5099_1634_2;
	R1634[692] = (char *(*)()) F855_5168_1634_2;
	R1634[693] = (char *(*)()) F856_5168_1634_2;
	R1634[695] = (char *(*)()) F858_5234_1634_2;
	R1634[696] = (char *(*)()) F859_5234_1634_2;
	{long i; for (i = 698; i < 700; i++) R1634[i] = (char *(*)()) F860_5265;}
	{long i; for (i = 701; i < 703; i++) R1634[i] = (char *(*)()) F863_5305;}
	{long i; for (i = 748; i < 750; i++) R1634[i] = (char *(*)()) F910_5613;}
	{long i; for (i = 751; i < 753; i++) R1634[i] = (char *(*)()) F913_5781;}
	R1634[906] = (char *(*)()) F1069_7065;
	R1634[1085] = (char *(*)()) F1248_8969;
}
static EIF_BOOLEAN F831_4423_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F831_4423(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F832_4423_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F832_4423(Current, *(EIF_INTEGER_64 *)arg1);
}
static EIF_BOOLEAN F834_4522_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F834_4522(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F835_4522_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F835_4522(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_BOOLEAN F837_4621_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F837_4621(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F838_4621_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F838_4621(Current, *(EIF_INTEGER_16 *)arg1);
}
static EIF_BOOLEAN F840_4720_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F840_4720(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F841_4720_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F841_4720(Current, *(EIF_INTEGER_8 *)arg1);
}
static EIF_BOOLEAN F843_4815_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F843_4815(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F844_4815_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F844_4815(Current, *(EIF_NATURAL_64 *)arg1);
}
static EIF_BOOLEAN F846_4909_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F846_4909(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F847_4909_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F847_4909(Current, *(EIF_NATURAL_32 *)arg1);
}
static EIF_BOOLEAN F849_5004_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F849_5004(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F850_5004_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F850_5004(Current, *(EIF_NATURAL_16 *)arg1);
}
static EIF_BOOLEAN F852_5099_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F852_5099(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F853_5099_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F853_5099(Current, *(EIF_NATURAL_8 *)arg1);
}
static EIF_BOOLEAN F855_5168_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F855_5168(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F856_5168_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F856_5168(Current, *(EIF_REAL_32 *)arg1);
}
static EIF_BOOLEAN F858_5234_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F858_5234(Current, *(EIF_REAL_64 *)arg1);
}
static EIF_BOOLEAN F859_5234_1634_2 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F859_5234(Current, *(EIF_REAL_64 *)arg1);
}

char *(*R1735[6])();
void R1735_init () {
	R1735[0] = (char *(*)()) F166_1821;
	R1735[5] = (char *(*)()) F171_1875;
}

char *(*R1740[6])();
void R1740_init () {
	R1740[0] = (char *(*)()) F166_1826;
	R1740[5] = (char *(*)()) F168_1838;
}

char *(*R1815[40])();
void R1815_init () {
	R1815[0] = (char *(*)()) F180_1921;
	R1815[1] = (char *(*)()) F181_1945;
	R1815[5] = (char *(*)()) F185_1948;
	R1815[7] = (char *(*)()) F187_1950;
	R1815[8] = (char *(*)()) F188_1956;
	R1815[9] = (char *(*)()) F189_1973;
	R1815[11] = (char *(*)()) F191_1977;
	R1815[12] = (char *(*)()) F192_1979;
	R1815[13] = (char *(*)()) F193_1981;
	R1815[15] = (char *(*)()) F195_1983;
	R1815[16] = (char *(*)()) F196_1987;
	R1815[19] = (char *(*)()) F199_1989;
	R1815[20] = (char *(*)()) F200_1991;
	R1815[22] = (char *(*)()) F202_1995;
	R1815[23] = (char *(*)()) F203_2001;
	R1815[24] = (char *(*)()) F204_2003;
	R1815[26] = (char *(*)()) F206_2005;
	R1815[27] = (char *(*)()) F207_2007;
	R1815[28] = (char *(*)()) F208_2011;
	R1815[29] = (char *(*)()) F209_2015;
	R1815[31] = (char *(*)()) F211_2017;
	R1815[32] = (char *(*)()) F212_2019;
	R1815[34] = (char *(*)()) F214_2021;
	R1815[35] = (char *(*)()) F215_2023;
	R1815[36] = (char *(*)()) F216_2025;
	R1815[37] = (char *(*)()) F217_2027;
	R1815[38] = (char *(*)()) F218_2031;
	R1815[39] = (char *(*)()) F219_2033;
}

char *(*R1979[696])();
void R1979_init () {
	R1979[0] = (char *(*)()) F226_2144;
	R1979[1] = (char *(*)()) F227_2144_1979_3;
	R1979[2] = (char *(*)()) F228_2144_1979_3;
	R1979[3] = (char *(*)()) F229_2144_1979_3;
	R1979[4] = (char *(*)()) F230_2144_1979_3;
	R1979[5] = (char *(*)()) F231_2144_1979_3;
	R1979[6] = (char *(*)()) F232_2145;
	R1979[9] = (char *(*)()) F233_2149;
	R1979[10] = (char *(*)()) F234_2149_1979_3;
	R1979[693] = (char *(*)()) F919_5919;
	R1979[695] = (char *(*)()) F233_2149;
}
static EIF_BOOLEAN F227_2144_1979_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F227_2144(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F228_2144_1979_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F228_2144(Current, *(EIF_CHARACTER_8 *)arg1, *(EIF_CHARACTER_8 *)arg2);
}
static EIF_BOOLEAN F229_2144_1979_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F229_2144(Current, *(EIF_BOOLEAN *)arg1, *(EIF_BOOLEAN *)arg2);
}
static EIF_BOOLEAN F230_2144_1979_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F230_2144(Current, *(EIF_NATURAL_64 *)arg1, *(EIF_NATURAL_64 *)arg2);
}
static EIF_BOOLEAN F231_2144_1979_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F231_2144(Current, *(EIF_NATURAL_32 *)arg1, *(EIF_NATURAL_32 *)arg2);
}
static EIF_BOOLEAN F234_2149_1979_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F234_2149(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R1981[687])();
void R1981_init () {
	R1981[0] = (char *(*)()) F233_2146;
	R1981[1] = (char *(*)()) F234_2146_1981_3;
	R1981[686] = (char *(*)()) F233_2146;
}
static EIF_BOOLEAN F234_2146_1981_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F234_2146(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R2240[985])();
void R2240_init () {
	R2240[0] = (char *(*)()) F255_2420;
	R2240[438] = (char *(*)()) F248_2420;
	R2240[439] = (char *(*)()) F249_2420;
	R2240[440] = (char *(*)()) F250_2420;
	R2240[441] = (char *(*)()) F251_2420;
	R2240[442] = (char *(*)()) F252_2420;
	R2240[443] = (char *(*)()) F253_2420;
	R2240[444] = (char *(*)()) F254_2420;
	R2240[445] = (char *(*)()) F255_2420;
	R2240[446] = (char *(*)()) F256_2420;
	R2240[447] = (char *(*)()) F257_2420;
	R2240[448] = (char *(*)()) F258_2420;
	R2240[449] = (char *(*)()) F259_2420;
	R2240[450] = (char *(*)()) F248_2420;
	R2240[451] = (char *(*)()) F249_2420;
	R2240[452] = (char *(*)()) F254_2420;
	R2240[453] = (char *(*)()) F251_2420;
	R2240[454] = (char *(*)()) F259_2420;
	R2240[455] = (char *(*)()) F253_2420;
	R2240[648] = (char *(*)()) F252_2420;
	R2240[651] = (char *(*)()) F254_2420;
	R2240[984] = (char *(*)()) F254_2420;
}


#ifdef __cplusplus
}
#endif
