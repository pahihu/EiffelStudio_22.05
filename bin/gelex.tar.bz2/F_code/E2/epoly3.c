#include "epoly3.h"
#include "../E1/eoffsets.h"


#ifdef __cplusplus
extern "C" {
#endif

char *(*R2906[103])();
void R2906_init () {
	R2906[0] = (char *(*)()) F954_6244;
	R2906[97] = (char *(*)()) F662_3279;
	R2906[102] = (char *(*)()) F662_3279;
}

char *(*R2976[103])();
void R2976_init () {
	R2976[0] = (char *(*)()) F954_6300;
	R2976[97] = (char *(*)()) F662_3404;
	R2976[102] = (char *(*)()) F662_3404;
}

char *(*R3077[572])();
void R3077_init () {
	R3077[0] = (char *(*)()) F677_3599;
	R3077[1] = (char *(*)()) F678_3599_3077_28;
	R3077[2] = (char *(*)()) F679_3599_3077_28;
	R3077[3] = (char *(*)()) F680_3599_3077_28;
	R3077[4] = (char *(*)()) F681_3599_3077_28;
	R3077[5] = (char *(*)()) F682_3599_3077_28;
	R3077[6] = (char *(*)()) F683_3599_3077_28;
	R3077[7] = (char *(*)()) F684_3599_3077_28;
	R3077[8] = (char *(*)()) F685_3599_3077_28;
	R3077[9] = (char *(*)()) F686_3599_3077_28;
	R3077[10] = (char *(*)()) F687_3599_3077_28;
	R3077[11] = (char *(*)()) F688_3599_3077_28;
	R3077[25] = (char *(*)()) F702_3690;
	R3077[26] = (char *(*)()) F703_3690_3077_28;
	R3077[27] = (char *(*)()) F704_3690_3077_28;
	R3077[28] = (char *(*)()) F705_3690_3077_28;
	R3077[29] = (char *(*)()) F706_3690_3077_28;
	R3077[30] = (char *(*)()) F707_3690_3077_28;
	R3077[31] = (char *(*)()) F708_3690_3077_28;
	R3077[32] = (char *(*)()) F709_3690_3077_28;
	R3077[33] = (char *(*)()) F710_3690_3077_28;
	R3077[34] = (char *(*)()) F711_3690_3077_28;
	R3077[35] = (char *(*)()) F712_3690_3077_28;
	R3077[36] = (char *(*)()) F713_3690_3077_28;
	R3077[37] = (char *(*)()) F702_3690;
	R3077[38] = (char *(*)()) F703_3690_3077_28;
	R3077[39] = (char *(*)()) F708_3690_3077_28;
	R3077[40] = (char *(*)()) F705_3690_3077_28;
	R3077[41] = (char *(*)()) F713_3690_3077_28;
	R3077[42] = (char *(*)()) F707_3690_3077_28;
	R3077[152] = (char *(*)()) F829_4221;
	R3077[234] = (char *(*)()) F911_5643_3077_28;
	R3077[235] = (char *(*)()) F912_5666_3077_28;
	R3077[237] = (char *(*)()) F914_5808_3077_28;
	R3077[238] = (char *(*)()) F915_5830_3077_28;
	R3077[571] = (char *(*)()) F1248_8942_3077_28;
}
static EIF_REFERENCE F678_3599_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F678_3599(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F679_3599_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F679_3599(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F680_3599_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F680_3599(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(867, 0x00).id, 867, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F681_3599_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F681_3599(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(861, 0x00).id, 861, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F682_3599_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F682_3599(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(843, 0x00).id, 843, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F683_3599_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F683_3599(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F684_3599_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F684_3599(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(852, 0x00).id, 852, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F685_3599_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F685_3599(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(849, 0x00).id, 849, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F686_3599_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F686_3599(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(855, 0x00).id, 855, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F687_3599_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F687_3599(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(858, 0x00).id, 858, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F688_3599_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F688_3599(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(846, 0x00).id, 846, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F703_3690_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F703_3690(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F704_3690_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F704_3690(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F705_3690_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F705_3690(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(867, 0x00).id, 867, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F706_3690_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F706_3690(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(861, 0x00).id, 861, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F707_3690_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F707_3690(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(843, 0x00).id, 843, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F708_3690_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F708_3690(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F709_3690_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F709_3690(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(852, 0x00).id, 852, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F710_3690_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F710_3690(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(849, 0x00).id, 849, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F711_3690_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F711_3690(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(855, 0x00).id, 855, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F712_3690_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F712_3690(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(858, 0x00).id, 858, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F713_3690_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F713_3690(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(846, 0x00).id, 846, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F911_5643_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F911_5643(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(861, 0x00).id, 861, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F912_5666_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F912_5666(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(861, 0x00).id, 861, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F914_5808_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F914_5808(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F915_5830_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F915_5830(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F1248_8942_3077_28 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F1248_8942(Current, arg1);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}

char *(*R3078[572])();
void R3078_init () {
	R3078[0] = (char *(*)()) F677_3607;
	R3078[1] = (char *(*)()) F678_3607;
	R3078[2] = (char *(*)()) F679_3607;
	R3078[3] = (char *(*)()) F680_3607;
	R3078[4] = (char *(*)()) F681_3607;
	R3078[5] = (char *(*)()) F682_3607;
	R3078[6] = (char *(*)()) F683_3607;
	R3078[7] = (char *(*)()) F684_3607;
	R3078[8] = (char *(*)()) F685_3607;
	R3078[9] = (char *(*)()) F686_3607;
	R3078[10] = (char *(*)()) F687_3607;
	R3078[11] = (char *(*)()) F688_3607;
	R3078[25] = (char *(*)()) F702_3695;
	R3078[26] = (char *(*)()) F703_3695;
	R3078[27] = (char *(*)()) F704_3695;
	R3078[28] = (char *(*)()) F705_3695;
	R3078[29] = (char *(*)()) F706_3695;
	R3078[30] = (char *(*)()) F707_3695;
	R3078[31] = (char *(*)()) F708_3695;
	R3078[32] = (char *(*)()) F709_3695;
	R3078[33] = (char *(*)()) F710_3695;
	R3078[34] = (char *(*)()) F711_3695;
	R3078[35] = (char *(*)()) F712_3695;
	R3078[36] = (char *(*)()) F713_3695;
	R3078[37] = (char *(*)()) F702_3695;
	R3078[38] = (char *(*)()) F703_3695;
	R3078[39] = (char *(*)()) F708_3695;
	R3078[40] = (char *(*)()) F705_3695;
	R3078[41] = (char *(*)()) F713_3695;
	R3078[42] = (char *(*)()) F707_3695;
	R3078[109] = (char *(*)()) F786_3983;
	R3078[110] = (char *(*)()) F787_3983;
	R3078[111] = (char *(*)()) F788_3983;
	R3078[112] = (char *(*)()) F789_3983;
	R3078[113] = (char *(*)()) F790_3983;
	R3078[116] = (char *(*)()) F786_3983;
	R3078[152] = (char *(*)()) F829_4251;
	{long i; for (i = 234; i < 236; i++) R3078[i] = (char *(*)()) F910_5607;}
	{long i; for (i = 237; i < 239; i++) R3078[i] = (char *(*)()) F913_5775;}
	R3078[571] = (char *(*)()) F913_5775;
}

EIF_TYPE_INDEX *Y3078_gen_type [585];
EIF_TYPE_INDEX Y3078 [585];
void Y3078_init (void)
{
	egc_routines_types [3078] = Y3078;
	egc_routines_gen_types [3078] = Y3078_gen_type;
	egc_routines_offset [3078] = 664;
	{long i; for (i = 0; i < 105; i++) Y3078[i] = 834;};
	{long i; for (i = 109; i < 129; i++) Y3078[i] = 834;};
	Y3078[164] = 834;
	{long i; for (i = 245; i < 252; i++) Y3078[i] = 834;};
	{long i; for (i = 583; i < 585; i++) Y3078[i] = 834;};
}

char *(*R3079[572])();
void R3079_init () {
	R3079[0] = (char *(*)()) F677_3608;
	R3079[1] = (char *(*)()) F678_3608;
	R3079[2] = (char *(*)()) F679_3608;
	R3079[3] = (char *(*)()) F680_3608;
	R3079[4] = (char *(*)()) F681_3608;
	R3079[5] = (char *(*)()) F682_3608;
	R3079[6] = (char *(*)()) F683_3608;
	R3079[7] = (char *(*)()) F684_3608;
	R3079[8] = (char *(*)()) F685_3608;
	R3079[9] = (char *(*)()) F686_3608;
	R3079[10] = (char *(*)()) F687_3608;
	R3079[11] = (char *(*)()) F688_3608;
	R3079[25] = (char *(*)()) F702_3696;
	R3079[26] = (char *(*)()) F703_3696;
	R3079[27] = (char *(*)()) F704_3696;
	R3079[28] = (char *(*)()) F705_3696;
	R3079[29] = (char *(*)()) F706_3696;
	R3079[30] = (char *(*)()) F707_3696;
	R3079[31] = (char *(*)()) F708_3696;
	R3079[32] = (char *(*)()) F709_3696;
	R3079[33] = (char *(*)()) F710_3696;
	R3079[34] = (char *(*)()) F711_3696;
	R3079[35] = (char *(*)()) F712_3696;
	R3079[36] = (char *(*)()) F713_3696;
	R3079[37] = (char *(*)()) F702_3696;
	R3079[38] = (char *(*)()) F703_3696;
	R3079[39] = (char *(*)()) F708_3696;
	R3079[40] = (char *(*)()) F705_3696;
	R3079[41] = (char *(*)()) F713_3696;
	R3079[42] = (char *(*)()) F707_3696;
	R3079[109] = (char *(*)()) F786_3984;
	R3079[110] = (char *(*)()) F787_3984;
	R3079[111] = (char *(*)()) F788_3984;
	R3079[112] = (char *(*)()) F789_3984;
	R3079[113] = (char *(*)()) F790_3984;
	R3079[116] = (char *(*)()) F786_3984;
	R3079[152] = (char *(*)()) F829_4250;
	{long i; for (i = 234; i < 236; i++) R3079[i] = (char *(*)()) F910_5605;}
	{long i; for (i = 237; i < 239; i++) R3079[i] = (char *(*)()) F913_5773;}
	R3079[571] = (char *(*)()) F1248_8958;
}

char *(*R3082[12])();
void R3082_init () {
	R3082[0] = (char *(*)()) F677_3596;
	R3082[1] = (char *(*)()) F678_3596;
	R3082[2] = (char *(*)()) F679_3596;
	R3082[3] = (char *(*)()) F680_3596;
	R3082[4] = (char *(*)()) F681_3596;
	R3082[5] = (char *(*)()) F682_3596;
	R3082[6] = (char *(*)()) F683_3596;
	R3082[7] = (char *(*)()) F684_3596;
	R3082[8] = (char *(*)()) F685_3596;
	R3082[9] = (char *(*)()) F686_3596;
	R3082[10] = (char *(*)()) F687_3596;
	R3082[11] = (char *(*)()) F688_3596;
}

char *(*R3083[12])();
void R3083_init () {
	R3083[0] = (char *(*)()) F677_3597;
	R3083[1] = (char *(*)()) F678_3597_3083_133;
	R3083[2] = (char *(*)()) F679_3597_3083_133;
	R3083[3] = (char *(*)()) F680_3597_3083_133;
	R3083[4] = (char *(*)()) F681_3597_3083_133;
	R3083[5] = (char *(*)()) F682_3597_3083_133;
	R3083[6] = (char *(*)()) F683_3597_3083_133;
	R3083[7] = (char *(*)()) F684_3597_3083_133;
	R3083[8] = (char *(*)()) F685_3597_3083_133;
	R3083[9] = (char *(*)()) F686_3597_3083_133;
	R3083[10] = (char *(*)()) F687_3597_3083_133;
	R3083[11] = (char *(*)()) F688_3597_3083_133;
}
static void F678_3597_3083_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F678_3597(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F679_3597_3083_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F679_3597(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F680_3597_3083_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F680_3597(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F681_3597_3083_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F681_3597(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F682_3597_3083_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F682_3597(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F683_3597_3083_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F683_3597(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F684_3597_3083_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F684_3597(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F685_3597_3083_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F685_3597(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F686_3597_3083_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F686_3597(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F687_3597_3083_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F687_3597(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F688_3597_3083_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F688_3597(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}

char *(*R3092[12])();
void R3092_init () {
	R3092[0] = (char *(*)()) F677_3612;
	R3092[1] = (char *(*)()) F678_3612;
	R3092[2] = (char *(*)()) F679_3612;
	R3092[3] = (char *(*)()) F680_3612;
	R3092[4] = (char *(*)()) F681_3612;
	R3092[5] = (char *(*)()) F682_3612;
	R3092[6] = (char *(*)()) F683_3612;
	R3092[7] = (char *(*)()) F684_3612;
	R3092[8] = (char *(*)()) F685_3612;
	R3092[9] = (char *(*)()) F686_3612;
	R3092[10] = (char *(*)()) F687_3612;
	R3092[11] = (char *(*)()) F688_3612;
}

char *(*R3093[12])();
void R3093_init () {
	R3093[0] = (char *(*)()) F677_3614;
	R3093[1] = (char *(*)()) F678_3614_3093_133;
	R3093[2] = (char *(*)()) F679_3614_3093_133;
	R3093[3] = (char *(*)()) F680_3614_3093_133;
	R3093[4] = (char *(*)()) F681_3614_3093_133;
	R3093[5] = (char *(*)()) F682_3614_3093_133;
	R3093[6] = (char *(*)()) F683_3614_3093_133;
	R3093[7] = (char *(*)()) F684_3614_3093_133;
	R3093[8] = (char *(*)()) F685_3614_3093_133;
	R3093[9] = (char *(*)()) F686_3614_3093_133;
	R3093[10] = (char *(*)()) F687_3614_3093_133;
	R3093[11] = (char *(*)()) F688_3614_3093_133;
}
static void F678_3614_3093_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F678_3614(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F679_3614_3093_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F679_3614(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F680_3614_3093_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F680_3614(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F681_3614_3093_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F681_3614(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F682_3614_3093_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F682_3614(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F683_3614_3093_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F683_3614(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F684_3614_3093_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F684_3614(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F685_3614_3093_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F685_3614(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F686_3614_3093_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F686_3614(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F687_3614_3093_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F687_3614(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F688_3614_3093_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F688_3614(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}

char *(*R3094[12])();
void R3094_init () {
	R3094[0] = (char *(*)()) F677_3615;
	R3094[1] = (char *(*)()) F678_3615_3094_133;
	R3094[2] = (char *(*)()) F679_3615_3094_133;
	R3094[3] = (char *(*)()) F680_3615_3094_133;
	R3094[4] = (char *(*)()) F681_3615_3094_133;
	R3094[5] = (char *(*)()) F682_3615_3094_133;
	R3094[6] = (char *(*)()) F683_3615_3094_133;
	R3094[7] = (char *(*)()) F684_3615_3094_133;
	R3094[8] = (char *(*)()) F685_3615_3094_133;
	R3094[9] = (char *(*)()) F686_3615_3094_133;
	R3094[10] = (char *(*)()) F687_3615_3094_133;
	R3094[11] = (char *(*)()) F688_3615_3094_133;
}
static void F678_3615_3094_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F678_3615(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static void F679_3615_3094_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F679_3615(Current, *(EIF_POINTER *)arg1, arg2);
}
static void F680_3615_3094_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F680_3615(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static void F681_3615_3094_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F681_3615(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static void F682_3615_3094_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F682_3615(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static void F683_3615_3094_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F683_3615(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static void F684_3615_3094_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F684_3615(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static void F685_3615_3094_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F685_3615(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static void F686_3615_3094_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F686_3615(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static void F687_3615_3094_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F687_3615(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static void F688_3615_3094_133 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	F688_3615(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}

char *(*R3095[12])();
void R3095_init () {
	R3095[0] = (char *(*)()) F677_3616;
	R3095[1] = (char *(*)()) F678_3616_3095_4;
	R3095[2] = (char *(*)()) F679_3616_3095_4;
	R3095[3] = (char *(*)()) F680_3616_3095_4;
	R3095[4] = (char *(*)()) F681_3616_3095_4;
	R3095[5] = (char *(*)()) F682_3616_3095_4;
	R3095[6] = (char *(*)()) F683_3616_3095_4;
	R3095[7] = (char *(*)()) F684_3616_3095_4;
	R3095[8] = (char *(*)()) F685_3616_3095_4;
	R3095[9] = (char *(*)()) F686_3616_3095_4;
	R3095[10] = (char *(*)()) F687_3616_3095_4;
	R3095[11] = (char *(*)()) F688_3616_3095_4;
}
static void F678_3616_3095_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F678_3616(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F679_3616_3095_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F679_3616(Current, *(EIF_POINTER *)arg1);
}
static void F680_3616_3095_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F680_3616(Current, *(EIF_BOOLEAN *)arg1);
}
static void F681_3616_3095_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F681_3616(Current, *(EIF_CHARACTER_32 *)arg1);
}
static void F682_3616_3095_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F682_3616(Current, *(EIF_NATURAL_64 *)arg1);
}
static void F683_3616_3095_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F683_3616(Current, *(EIF_CHARACTER_8 *)arg1);
}
static void F684_3616_3095_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F684_3616(Current, *(EIF_NATURAL_8 *)arg1);
}
static void F685_3616_3095_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F685_3616(Current, *(EIF_NATURAL_16 *)arg1);
}
static void F686_3616_3095_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F686_3616(Current, *(EIF_REAL_32 *)arg1);
}
static void F687_3616_3095_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F687_3616(Current, *(EIF_REAL_64 *)arg1);
}
static void F688_3616_3095_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F688_3616(Current, *(EIF_NATURAL_32 *)arg1);
}

char *(*R3097[12])();
void R3097_init () {
	R3097[0] = (char *(*)()) F677_3618;
	R3097[1] = (char *(*)()) F678_3618_3097_40;
	R3097[2] = (char *(*)()) F679_3618_3097_40;
	R3097[3] = (char *(*)()) F680_3618_3097_40;
	R3097[4] = (char *(*)()) F681_3618_3097_40;
	R3097[5] = (char *(*)()) F682_3618_3097_40;
	R3097[6] = (char *(*)()) F683_3618_3097_40;
	R3097[7] = (char *(*)()) F684_3618_3097_40;
	R3097[8] = (char *(*)()) F685_3618_3097_40;
	R3097[9] = (char *(*)()) F686_3618_3097_40;
	R3097[10] = (char *(*)()) F687_3618_3097_40;
	R3097[11] = (char *(*)()) F688_3618_3097_40;
}
static void F678_3618_3097_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F678_3618(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F679_3618_3097_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F679_3618(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F680_3618_3097_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F680_3618(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F681_3618_3097_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F681_3618(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F682_3618_3097_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F682_3618(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F683_3618_3097_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F683_3618(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F684_3618_3097_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F684_3618(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F685_3618_3097_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F685_3618(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F686_3618_3097_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F686_3618(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F687_3618_3097_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F687_3618(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}
static void F688_3618_3097_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F688_3618(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}

char *(*R3100[12])();
void R3100_init () {
	R3100[0] = (char *(*)()) F677_3621;
	R3100[1] = (char *(*)()) F678_3621;
	R3100[2] = (char *(*)()) F679_3621;
	R3100[3] = (char *(*)()) F680_3621;
	R3100[4] = (char *(*)()) F681_3621;
	R3100[5] = (char *(*)()) F682_3621;
	R3100[6] = (char *(*)()) F683_3621;
	R3100[7] = (char *(*)()) F684_3621;
	R3100[8] = (char *(*)()) F685_3621;
	R3100[9] = (char *(*)()) F686_3621;
	R3100[10] = (char *(*)()) F687_3621;
	R3100[11] = (char *(*)()) F688_3621;
}

char *(*R3101[12])();
void R3101_init () {
	R3101[0] = (char *(*)()) F677_3622;
	R3101[1] = (char *(*)()) F678_3622;
	R3101[2] = (char *(*)()) F679_3622;
	R3101[3] = (char *(*)()) F680_3622;
	R3101[4] = (char *(*)()) F681_3622;
	R3101[5] = (char *(*)()) F682_3622;
	R3101[6] = (char *(*)()) F683_3622;
	R3101[7] = (char *(*)()) F684_3622;
	R3101[8] = (char *(*)()) F685_3622;
	R3101[9] = (char *(*)()) F686_3622;
	R3101[10] = (char *(*)()) F687_3622;
	R3101[11] = (char *(*)()) F688_3622;
}

char *(*R3102[12])();
void R3102_init () {
	R3102[0] = (char *(*)()) F677_3623;
	R3102[1] = (char *(*)()) F678_3623;
	R3102[2] = (char *(*)()) F679_3623;
	R3102[3] = (char *(*)()) F680_3623;
	R3102[4] = (char *(*)()) F681_3623;
	R3102[5] = (char *(*)()) F682_3623;
	R3102[6] = (char *(*)()) F683_3623;
	R3102[7] = (char *(*)()) F684_3623;
	R3102[8] = (char *(*)()) F685_3623;
	R3102[9] = (char *(*)()) F686_3623;
	R3102[10] = (char *(*)()) F687_3623;
	R3102[11] = (char *(*)()) F688_3623;
}

char *(*R3103[12])();
void R3103_init () {
	R3103[0] = (char *(*)()) F677_3624;
	R3103[1] = (char *(*)()) F678_3624;
	R3103[2] = (char *(*)()) F679_3624;
	R3103[3] = (char *(*)()) F680_3624;
	R3103[4] = (char *(*)()) F681_3624;
	R3103[5] = (char *(*)()) F682_3624;
	R3103[6] = (char *(*)()) F683_3624;
	R3103[7] = (char *(*)()) F684_3624;
	R3103[8] = (char *(*)()) F685_3624;
	R3103[9] = (char *(*)()) F686_3624;
	R3103[10] = (char *(*)()) F687_3624;
	R3103[11] = (char *(*)()) F688_3624;
}

char *(*R3104[12])();
void R3104_init () {
	R3104[0] = (char *(*)()) F677_3625;
	R3104[1] = (char *(*)()) F678_3625;
	R3104[2] = (char *(*)()) F679_3625;
	R3104[3] = (char *(*)()) F680_3625;
	R3104[4] = (char *(*)()) F681_3625;
	R3104[5] = (char *(*)()) F682_3625;
	R3104[6] = (char *(*)()) F683_3625;
	R3104[7] = (char *(*)()) F684_3625;
	R3104[8] = (char *(*)()) F685_3625;
	R3104[9] = (char *(*)()) F686_3625;
	R3104[10] = (char *(*)()) F687_3625;
	R3104[11] = (char *(*)()) F688_3625;
}

char *(*R3108[12])();
void R3108_init () {
	R3108[0] = (char *(*)()) F677_3629;
	R3108[1] = (char *(*)()) F678_3629;
	R3108[2] = (char *(*)()) F679_3629;
	R3108[3] = (char *(*)()) F680_3629;
	R3108[4] = (char *(*)()) F681_3629;
	R3108[5] = (char *(*)()) F682_3629;
	R3108[6] = (char *(*)()) F683_3629;
	R3108[7] = (char *(*)()) F684_3629;
	R3108[8] = (char *(*)()) F685_3629;
	R3108[9] = (char *(*)()) F686_3629;
	R3108[10] = (char *(*)()) F687_3629;
	R3108[11] = (char *(*)()) F688_3629;
}

char *(*R3110[12])();
void R3110_init () {
	R3110[0] = (char *(*)()) F677_3631;
	R3110[1] = (char *(*)()) F678_3631;
	R3110[2] = (char *(*)()) F679_3631;
	R3110[3] = (char *(*)()) F680_3631;
	R3110[4] = (char *(*)()) F681_3631;
	R3110[5] = (char *(*)()) F682_3631;
	R3110[6] = (char *(*)()) F683_3631;
	R3110[7] = (char *(*)()) F684_3631;
	R3110[8] = (char *(*)()) F685_3631;
	R3110[9] = (char *(*)()) F686_3631;
	R3110[10] = (char *(*)()) F687_3631;
	R3110[11] = (char *(*)()) F688_3631;
}

char *(*R3111[12])();
void R3111_init () {
	R3111[0] = (char *(*)()) F677_3632;
	R3111[1] = (char *(*)()) F678_3632_3111_30;
	R3111[2] = (char *(*)()) F679_3632_3111_30;
	R3111[3] = (char *(*)()) F680_3632_3111_30;
	R3111[4] = (char *(*)()) F681_3632_3111_30;
	R3111[5] = (char *(*)()) F682_3632_3111_30;
	R3111[6] = (char *(*)()) F683_3632_3111_30;
	R3111[7] = (char *(*)()) F684_3632_3111_30;
	R3111[8] = (char *(*)()) F685_3632_3111_30;
	R3111[9] = (char *(*)()) F686_3632_3111_30;
	R3111[10] = (char *(*)()) F687_3632_3111_30;
	R3111[11] = (char *(*)()) F688_3632_3111_30;
}
static EIF_REFERENCE F678_3632_3111_30 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F678_3632(Current, *(EIF_INTEGER_32 *)arg1, arg2);
}
static EIF_REFERENCE F679_3632_3111_30 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F679_3632(Current, *(EIF_POINTER *)arg1, arg2);
}
static EIF_REFERENCE F680_3632_3111_30 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F680_3632(Current, *(EIF_BOOLEAN *)arg1, arg2);
}
static EIF_REFERENCE F681_3632_3111_30 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F681_3632(Current, *(EIF_CHARACTER_32 *)arg1, arg2);
}
static EIF_REFERENCE F682_3632_3111_30 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F682_3632(Current, *(EIF_NATURAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F683_3632_3111_30 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F683_3632(Current, *(EIF_CHARACTER_8 *)arg1, arg2);
}
static EIF_REFERENCE F684_3632_3111_30 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F684_3632(Current, *(EIF_NATURAL_8 *)arg1, arg2);
}
static EIF_REFERENCE F685_3632_3111_30 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F685_3632(Current, *(EIF_NATURAL_16 *)arg1, arg2);
}
static EIF_REFERENCE F686_3632_3111_30 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F686_3632(Current, *(EIF_REAL_32 *)arg1, arg2);
}
static EIF_REFERENCE F687_3632_3111_30 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F687_3632(Current, *(EIF_REAL_64 *)arg1, arg2);
}
static EIF_REFERENCE F688_3632_3111_30 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	return F688_3632(Current, *(EIF_NATURAL_32 *)arg1, arg2);
}

char *(*R3113[12])();
void R3113_init () {
	R3113[0] = (char *(*)()) F677_3634;
	R3113[1] = (char *(*)()) F678_3634;
	R3113[2] = (char *(*)()) F679_3634;
	R3113[3] = (char *(*)()) F680_3634;
	R3113[4] = (char *(*)()) F681_3634;
	R3113[5] = (char *(*)()) F682_3634;
	R3113[6] = (char *(*)()) F683_3634;
	R3113[7] = (char *(*)()) F684_3634;
	R3113[8] = (char *(*)()) F685_3634;
	R3113[9] = (char *(*)()) F686_3634;
	R3113[10] = (char *(*)()) F687_3634;
	R3113[11] = (char *(*)()) F688_3634;
}

char *(*R3122[12])();
void R3122_init () {
	R3122[0] = (char *(*)()) F677_3644;
	R3122[1] = (char *(*)()) F678_3644;
	R3122[2] = (char *(*)()) F679_3644;
	R3122[3] = (char *(*)()) F680_3644;
	R3122[4] = (char *(*)()) F681_3644;
	R3122[5] = (char *(*)()) F682_3644;
	R3122[6] = (char *(*)()) F683_3644;
	R3122[7] = (char *(*)()) F684_3644;
	R3122[8] = (char *(*)()) F685_3644;
	R3122[9] = (char *(*)()) F686_3644;
	R3122[10] = (char *(*)()) F687_3644;
	R3122[11] = (char *(*)()) F688_3644;
}

char *(*R3142[18])();
void R3142_init () {
	R3142[0] = (char *(*)()) F702_3684;
	R3142[1] = (char *(*)()) F703_3684;
	R3142[2] = (char *(*)()) F704_3684;
	R3142[3] = (char *(*)()) F705_3684;
	R3142[4] = (char *(*)()) F706_3684;
	R3142[5] = (char *(*)()) F707_3684;
	R3142[6] = (char *(*)()) F708_3684;
	R3142[7] = (char *(*)()) F709_3684;
	R3142[8] = (char *(*)()) F710_3684;
	R3142[9] = (char *(*)()) F711_3684;
	R3142[10] = (char *(*)()) F712_3684;
	R3142[11] = (char *(*)()) F713_3684;
	R3142[12] = (char *(*)()) F702_3684;
	R3142[13] = (char *(*)()) F703_3684;
	R3142[14] = (char *(*)()) F708_3684;
	R3142[15] = (char *(*)()) F705_3684;
	R3142[16] = (char *(*)()) F713_3684;
	R3142[17] = (char *(*)()) F707_3684;
}

char *(*R3145[18])();
void R3145_init () {
	R3145[0] = (char *(*)()) F702_3687;
	R3145[1] = (char *(*)()) F703_3687;
	R3145[2] = (char *(*)()) F704_3687;
	R3145[3] = (char *(*)()) F705_3687;
	R3145[4] = (char *(*)()) F706_3687;
	R3145[5] = (char *(*)()) F707_3687;
	R3145[6] = (char *(*)()) F708_3687;
	R3145[7] = (char *(*)()) F709_3687;
	R3145[8] = (char *(*)()) F710_3687;
	R3145[9] = (char *(*)()) F711_3687;
	R3145[10] = (char *(*)()) F712_3687;
	R3145[11] = (char *(*)()) F713_3687;
	R3145[12] = (char *(*)()) F702_3687;
	R3145[13] = (char *(*)()) F703_3687;
	R3145[14] = (char *(*)()) F708_3687;
	R3145[15] = (char *(*)()) F705_3687;
	R3145[16] = (char *(*)()) F713_3687;
	R3145[17] = (char *(*)()) F707_3687;
}

char *(*R3146[18])();
void R3146_init () {
	R3146[0] = (char *(*)()) F702_3688;
	R3146[1] = (char *(*)()) F703_3688;
	R3146[2] = (char *(*)()) F704_3688;
	R3146[3] = (char *(*)()) F705_3688;
	R3146[4] = (char *(*)()) F706_3688;
	R3146[5] = (char *(*)()) F707_3688;
	R3146[6] = (char *(*)()) F708_3688;
	R3146[7] = (char *(*)()) F709_3688;
	R3146[8] = (char *(*)()) F710_3688;
	R3146[9] = (char *(*)()) F711_3688;
	R3146[10] = (char *(*)()) F712_3688;
	R3146[11] = (char *(*)()) F713_3688;
	R3146[12] = (char *(*)()) F702_3688;
	R3146[13] = (char *(*)()) F703_3688;
	R3146[14] = (char *(*)()) F708_3688;
	R3146[15] = (char *(*)()) F705_3688;
	R3146[16] = (char *(*)()) F713_3688;
	R3146[17] = (char *(*)()) F707_3688;
}

char *(*R3156[18])();
void R3156_init () {
	R3156[0] = (char *(*)()) F702_3714;
	R3156[1] = (char *(*)()) F703_3714;
	R3156[2] = (char *(*)()) F704_3714;
	R3156[3] = (char *(*)()) F705_3714;
	R3156[4] = (char *(*)()) F706_3714;
	R3156[5] = (char *(*)()) F707_3714;
	R3156[6] = (char *(*)()) F708_3714;
	R3156[7] = (char *(*)()) F709_3714;
	R3156[8] = (char *(*)()) F710_3714;
	R3156[9] = (char *(*)()) F711_3714;
	R3156[10] = (char *(*)()) F712_3714;
	R3156[11] = (char *(*)()) F713_3714;
	R3156[12] = (char *(*)()) F702_3714;
	R3156[13] = (char *(*)()) F703_3714;
	R3156[14] = (char *(*)()) F708_3714;
	R3156[15] = (char *(*)()) F705_3714;
	R3156[16] = (char *(*)()) F713_3714;
	R3156[17] = (char *(*)()) F707_3714;
}

char *(*R3170[18])();
void R3170_init () {
	R3170[0] = (char *(*)()) F702_3730;
	R3170[1] = (char *(*)()) F703_3730_3170_40;
	R3170[2] = (char *(*)()) F704_3730_3170_40;
	R3170[3] = (char *(*)()) F705_3730_3170_40;
	R3170[4] = (char *(*)()) F706_3730_3170_40;
	R3170[5] = (char *(*)()) F707_3730_3170_40;
	R3170[6] = (char *(*)()) F708_3730_3170_40;
	R3170[7] = (char *(*)()) F709_3730_3170_40;
	R3170[8] = (char *(*)()) F710_3730_3170_40;
	R3170[9] = (char *(*)()) F711_3730_3170_40;
	R3170[10] = (char *(*)()) F712_3730_3170_40;
	R3170[11] = (char *(*)()) F713_3730_3170_40;
	R3170[12] = (char *(*)()) F702_3730;
	R3170[13] = (char *(*)()) F703_3730_3170_40;
	R3170[14] = (char *(*)()) F708_3730_3170_40;
	R3170[15] = (char *(*)()) F705_3730_3170_40;
	R3170[16] = (char *(*)()) F713_3730_3170_40;
	R3170[17] = (char *(*)()) F707_3730_3170_40;
}
static void F703_3730_3170_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F703_3730(Current, *(EIF_INTEGER_32 *)arg1, arg2, arg3);
}
static void F704_3730_3170_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F704_3730(Current, *(EIF_POINTER *)arg1, arg2, arg3);
}
static void F705_3730_3170_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F705_3730(Current, *(EIF_BOOLEAN *)arg1, arg2, arg3);
}
static void F706_3730_3170_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F706_3730(Current, *(EIF_CHARACTER_32 *)arg1, arg2, arg3);
}
static void F707_3730_3170_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F707_3730(Current, *(EIF_NATURAL_64 *)arg1, arg2, arg3);
}
static void F708_3730_3170_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F708_3730(Current, *(EIF_CHARACTER_8 *)arg1, arg2, arg3);
}
static void F709_3730_3170_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F709_3730(Current, *(EIF_NATURAL_8 *)arg1, arg2, arg3);
}
static void F710_3730_3170_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F710_3730(Current, *(EIF_NATURAL_16 *)arg1, arg2, arg3);
}
static void F711_3730_3170_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F711_3730(Current, *(EIF_REAL_32 *)arg1, arg2, arg3);
}
static void F712_3730_3170_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F712_3730(Current, *(EIF_REAL_64 *)arg1, arg2, arg3);
}
static void F713_3730_3170_40 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	F713_3730(Current, *(EIF_NATURAL_32 *)arg1, arg2, arg3);
}

char *(*R3177[18])();
void R3177_init () {
	R3177[0] = (char *(*)()) F702_3742;
	R3177[1] = (char *(*)()) F703_3742;
	R3177[2] = (char *(*)()) F704_3742;
	R3177[3] = (char *(*)()) F705_3742;
	R3177[4] = (char *(*)()) F706_3742;
	R3177[5] = (char *(*)()) F707_3742;
	R3177[6] = (char *(*)()) F708_3742;
	R3177[7] = (char *(*)()) F709_3742;
	R3177[8] = (char *(*)()) F710_3742;
	R3177[9] = (char *(*)()) F711_3742;
	R3177[10] = (char *(*)()) F712_3742;
	R3177[11] = (char *(*)()) F713_3742;
	R3177[12] = (char *(*)()) F702_3742;
	R3177[13] = (char *(*)()) F703_3742;
	R3177[14] = (char *(*)()) F708_3742;
	R3177[15] = (char *(*)()) F705_3742;
	R3177[16] = (char *(*)()) F713_3742;
	R3177[17] = (char *(*)()) F707_3742;
}

char *(*R3180[6])();
void R3180_init () {
	R3180[0] = (char *(*)()) F714_3743;
	R3180[1] = (char *(*)()) F715_3743;
	R3180[2] = (char *(*)()) F716_3743;
	R3180[3] = (char *(*)()) F717_3743;
	R3180[4] = (char *(*)()) F718_3743;
	R3180[5] = (char *(*)()) F719_3743;
}

char *(*R3230[463])();
void R3230_init () {
	R3230[0] = (char *(*)()) F786_4021;
	R3230[1] = (char *(*)()) F787_4021;
	R3230[2] = (char *(*)()) F788_4021;
	R3230[3] = (char *(*)()) F789_4021;
	R3230[4] = (char *(*)()) F790_4021;
	R3230[7] = (char *(*)()) F786_4021;
	R3230[43] = (char *(*)()) F829_4329;
	R3230[120] = (char *(*)()) F902_5420;
	R3230[125] = (char *(*)()) F911_5659;
	R3230[126] = (char *(*)()) F912_5750;
	R3230[129] = (char *(*)()) F915_5914;
	R3230[234] = (char *(*)()) F1012_6760;
	R3230[235] = (char *(*)()) F1014_6760;
	R3230[244] = (char *(*)()) F1012_6760;
	R3230[245] = (char *(*)()) F1013_6760;
	R3230[246] = (char *(*)()) F1014_6760;
	R3230[247] = (char *(*)()) F1015_6760;
	R3230[252] = (char *(*)()) F1038_6806;
	R3230[253] = (char *(*)()) F1039_6806;
	R3230[371] = (char *(*)()) F1157_7645;
	R3230[372] = (char *(*)()) F1158_7645;
	R3230[373] = (char *(*)()) F1159_7726;
	R3230[374] = (char *(*)()) F1160_7726;
	R3230[375] = (char *(*)()) F1159_7726;
	R3230[384] = (char *(*)()) F1168_7886;
	R3230[385] = (char *(*)()) F1169_7886;
	R3230[394] = (char *(*)()) F1176_7970;
	R3230[395] = (char *(*)()) F1177_7970;
	R3230[396] = (char *(*)()) F1178_7970;
	R3230[397] = (char *(*)()) F1179_7970;
	R3230[462] = (char *(*)()) F915_5914;
}

char *(*R3257[8])();
void R3257_init () {
	R3257[0] = (char *(*)()) F786_3962;
	R3257[1] = (char *(*)()) F787_3962;
	R3257[2] = (char *(*)()) F788_3962;
	R3257[3] = (char *(*)()) F789_3962;
	R3257[4] = (char *(*)()) F790_3962;
	R3257[7] = (char *(*)()) F786_3962;
}

char *(*R3260[8])();
void R3260_init () {
	R3260[0] = (char *(*)()) F786_3965;
	R3260[1] = (char *(*)()) F787_3965;
	R3260[2] = (char *(*)()) F788_3965;
	R3260[3] = (char *(*)()) F789_3965;
	R3260[4] = (char *(*)()) F790_3965;
	R3260[7] = (char *(*)()) F786_3965;
}

char *(*R3261[8])();
void R3261_init () {
	R3261[0] = (char *(*)()) F786_3966;
	R3261[1] = (char *(*)()) F787_3966_3261_1;
	R3261[2] = (char *(*)()) F788_3966;
	R3261[3] = (char *(*)()) F789_3966_3261_1;
	R3261[4] = (char *(*)()) F790_3966_3261_1;
	R3261[7] = (char *(*)()) F786_3966;
}
static EIF_REFERENCE F787_3966_3261_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F787_3966(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F789_3966_3261_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F789_3966(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F790_3966_3261_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F790_3966(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R3269[8])();
void R3269_init () {
	R3269[0] = (char *(*)()) F786_3979;
	R3269[1] = (char *(*)()) F787_3979;
	R3269[2] = (char *(*)()) F788_3979_3269_21;
	R3269[3] = (char *(*)()) F789_3979;
	R3269[4] = (char *(*)()) F790_3979_3269_21;
	R3269[7] = (char *(*)()) F786_3979;
}
static EIF_INTEGER_32 F788_3979_3269_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F788_3979(Current, *(EIF_INTEGER_32 *)arg1);
}
static EIF_INTEGER_32 F790_3979_3269_21 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	return F790_3979(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3271[8])();
void R3271_init () {
	R3271[0] = (char *(*)()) F786_3986;
	R3271[1] = (char *(*)()) F787_3986;
	R3271[2] = (char *(*)()) F788_3986_3271_3;
	R3271[3] = (char *(*)()) F789_3986;
	R3271[4] = (char *(*)()) F790_3986_3271_3;
	R3271[7] = (char *(*)()) F786_3986;
}
static EIF_BOOLEAN F788_3986_3271_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F788_3986(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}
static EIF_BOOLEAN F790_3986_3271_3 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	return F790_3986(Current, *(EIF_INTEGER_32 *)arg1, *(EIF_INTEGER_32 *)arg2);
}

char *(*R3277[8])();
void R3277_init () {
	R3277[0] = (char *(*)()) F786_3994;
	R3277[1] = (char *(*)()) F787_3994;
	R3277[2] = (char *(*)()) F788_3994;
	R3277[3] = (char *(*)()) F789_3994;
	R3277[4] = (char *(*)()) F790_3994;
	R3277[7] = (char *(*)()) F786_3994;
}

char *(*R3278[8])();
void R3278_init () {
	R3278[0] = (char *(*)()) F786_3995;
	R3278[1] = (char *(*)()) F787_3995;
	R3278[2] = (char *(*)()) F788_3995;
	R3278[3] = (char *(*)()) F789_3995;
	R3278[4] = (char *(*)()) F790_3995;
	R3278[7] = (char *(*)()) F786_3995;
}

char *(*R3286[8])();
void R3286_init () {
	R3286[0] = (char *(*)()) F786_4004;
	R3286[1] = (char *(*)()) F787_4004;
	R3286[2] = (char *(*)()) F788_4004_3286_4;
	R3286[3] = (char *(*)()) F789_4004;
	R3286[4] = (char *(*)()) F790_4004_3286_4;
	R3286[7] = (char *(*)()) F786_4004;
}
static void F788_4004_3286_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F788_4004(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F790_4004_3286_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F790_4004(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3288[8])();
void R3288_init () {
	R3288[0] = (char *(*)()) F786_4006;
	R3288[1] = (char *(*)()) F787_4006;
	R3288[2] = (char *(*)()) F788_4006;
	R3288[3] = (char *(*)()) F789_4006;
	R3288[4] = (char *(*)()) F790_4006;
	R3288[7] = (char *(*)()) F786_4006;
}

char *(*R3289[8])();
void R3289_init () {
	R3289[0] = (char *(*)()) F786_4007;
	R3289[1] = (char *(*)()) F787_4007;
	R3289[2] = (char *(*)()) F788_4007;
	R3289[3] = (char *(*)()) F789_4007;
	R3289[4] = (char *(*)()) F790_4007;
	R3289[7] = (char *(*)()) F786_4007;
}

char *(*R3295[8])();
void R3295_init () {
	R3295[0] = (char *(*)()) F786_4020;
	R3295[1] = (char *(*)()) F787_4020;
	R3295[2] = (char *(*)()) F788_4020;
	R3295[3] = (char *(*)()) F789_4020;
	R3295[4] = (char *(*)()) F790_4020;
	R3295[7] = (char *(*)()) F786_4020;
}

char *(*R3304[8])();
void R3304_init () {
	R3304[0] = (char *(*)()) F786_4030;
	R3304[1] = (char *(*)()) F787_4030;
	R3304[2] = (char *(*)()) F788_4030;
	R3304[3] = (char *(*)()) F789_4030;
	R3304[4] = (char *(*)()) F790_4030;
	R3304[7] = (char *(*)()) F786_4030;
}

char *(*R3305[8])();
void R3305_init () {
	R3305[0] = (char *(*)()) F786_4031;
	R3305[1] = (char *(*)()) F787_4031;
	R3305[2] = (char *(*)()) F788_4031;
	R3305[3] = (char *(*)()) F789_4031;
	R3305[4] = (char *(*)()) F790_4031;
	R3305[7] = (char *(*)()) F786_4031;
}

char *(*R3312[8])();
void R3312_init () {
	R3312[0] = (char *(*)()) F786_4038;
	R3312[1] = (char *(*)()) F787_4038_3312_1;
	R3312[2] = (char *(*)()) F788_4038;
	R3312[3] = (char *(*)()) F789_4038_3312_1;
	R3312[4] = (char *(*)()) F790_4038_3312_1;
	R3312[7] = (char *(*)()) F786_4038;
}
static EIF_REFERENCE F787_4038_3312_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F787_4038(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F789_4038_3312_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F789_4038(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F790_4038_3312_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F790_4038(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R3313[8])();
void R3313_init () {
	R3313[0] = (char *(*)()) F786_4039;
	R3313[1] = (char *(*)()) F787_4039;
	R3313[2] = (char *(*)()) F788_4039_3313_1;
	R3313[3] = (char *(*)()) F789_4039;
	R3313[4] = (char *(*)()) F790_4039_3313_1;
	R3313[7] = (char *(*)()) F786_4039;
}
static EIF_REFERENCE F788_4039_3313_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F788_4039(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F790_4039_3313_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F790_4039(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}

char *(*R3314[8])();
void R3314_init () {
	R3314[0] = (char *(*)()) F786_4040;
	R3314[1] = (char *(*)()) F787_4040;
	R3314[2] = (char *(*)()) F788_4040;
	R3314[3] = (char *(*)()) F789_4040;
	R3314[4] = (char *(*)()) F790_4040;
	R3314[7] = (char *(*)()) F786_4040;
}

char *(*R3315[8])();
void R3315_init () {
	R3315[0] = (char *(*)()) F786_4041;
	R3315[1] = (char *(*)()) F787_4041;
	R3315[2] = (char *(*)()) F788_4041;
	R3315[3] = (char *(*)()) F789_4041;
	R3315[4] = (char *(*)()) F790_4041;
	R3315[7] = (char *(*)()) F786_4041;
}

char *(*R3318[8])();
void R3318_init () {
	R3318[0] = (char *(*)()) F786_4044;
	R3318[1] = (char *(*)()) F787_4044;
	R3318[2] = (char *(*)()) F788_4044;
	R3318[3] = (char *(*)()) F789_4044;
	R3318[4] = (char *(*)()) F790_4044;
	R3318[7] = (char *(*)()) F786_4044;
}

char *(*R3320[8])();
void R3320_init () {
	R3320[0] = (char *(*)()) F786_4046;
	R3320[1] = (char *(*)()) F787_4046;
	R3320[2] = (char *(*)()) F788_4046;
	R3320[3] = (char *(*)()) F789_4046;
	R3320[4] = (char *(*)()) F790_4046;
	R3320[7] = (char *(*)()) F786_4046;
}

char *(*R3321[8])();
void R3321_init () {
	R3321[0] = (char *(*)()) F786_4047;
	R3321[1] = (char *(*)()) F787_4047;
	R3321[2] = (char *(*)()) F788_4047;
	R3321[3] = (char *(*)()) F789_4047;
	R3321[4] = (char *(*)()) F790_4047;
	R3321[7] = (char *(*)()) F786_4047;
}

char *(*R3322[8])();
void R3322_init () {
	R3322[0] = (char *(*)()) F786_4048;
	R3322[1] = (char *(*)()) F787_4048;
	R3322[2] = (char *(*)()) F788_4048;
	R3322[3] = (char *(*)()) F789_4048;
	R3322[4] = (char *(*)()) F790_4048;
	R3322[7] = (char *(*)()) F786_4048;
}

char *(*R3326[8])();
void R3326_init () {
	R3326[0] = (char *(*)()) F786_4052;
	R3326[1] = (char *(*)()) F787_4052;
	R3326[2] = (char *(*)()) F788_4052_3326_4;
	R3326[3] = (char *(*)()) F789_4052;
	R3326[4] = (char *(*)()) F790_4052_3326_4;
	R3326[7] = (char *(*)()) F786_4052;
}
static void F788_4052_3326_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F788_4052(Current, *(EIF_INTEGER_32 *)arg1);
}
static void F790_4052_3326_4 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	F790_4052(Current, *(EIF_INTEGER_32 *)arg1);
}

char *(*R3332[8])();
void R3332_init () {
	R3332[0] = (char *(*)()) F786_4058;
	R3332[1] = (char *(*)()) F787_4058;
	R3332[2] = (char *(*)()) F788_4058;
	R3332[3] = (char *(*)()) F789_4058;
	R3332[4] = (char *(*)()) F790_4058;
	R3332[7] = (char *(*)()) F786_4058;
}

char *(*R3345[8])();
void R3345_init () {
	R3345[0] = (char *(*)()) F786_4071;
	R3345[1] = (char *(*)()) F787_4071;
	R3345[2] = (char *(*)()) F788_4071;
	R3345[3] = (char *(*)()) F789_4071;
	R3345[4] = (char *(*)()) F790_4071;
	R3345[7] = (char *(*)()) F786_4071;
}

char *(*R3362[453])();
void R3362_init () {
	R3362[0] = (char *(*)()) F796_4120;
	R3362[1] = (char *(*)()) F797_4161;
	R3362[2] = (char *(*)()) F798_4195;
	R3362[3] = (char *(*)()) F799_4195;
	R3362[4] = (char *(*)()) F800_4195;
	R3362[5] = (char *(*)()) F801_4195;
	R3362[6] = (char *(*)()) F802_4195;
	R3362[7] = (char *(*)()) F803_4195;
	R3362[8] = (char *(*)()) F804_4195;
	R3362[9] = (char *(*)()) F805_4195;
	R3362[10] = (char *(*)()) F806_4195;
	R3362[11] = (char *(*)()) F807_4195;
	R3362[12] = (char *(*)()) F808_4195;
	R3362[13] = (char *(*)()) F809_4195;
	R3362[14] = (char *(*)()) F810_4195;
	R3362[15] = (char *(*)()) F811_4195;
	R3362[16] = (char *(*)()) F812_4195;
	R3362[17] = (char *(*)()) F813_4195;
	R3362[18] = (char *(*)()) F814_4195;
	R3362[19] = (char *(*)()) F815_4195;
	R3362[20] = (char *(*)()) F816_4195;
	R3362[21] = (char *(*)()) F817_4195;
	R3362[22] = (char *(*)()) F818_4195;
	R3362[23] = (char *(*)()) F819_4195;
	R3362[24] = (char *(*)()) F820_4195;
	R3362[25] = (char *(*)()) F821_4195;
	R3362[26] = (char *(*)()) F822_4195;
	R3362[27] = (char *(*)()) F823_4195;
	R3362[28] = (char *(*)()) F824_4195;
	R3362[29] = (char *(*)()) F825_4195;
	R3362[30] = (char *(*)()) F826_4195;
	R3362[31] = (char *(*)()) F827_4195;
	R3362[32] = (char *(*)()) F828_4195;
	R3362[33] = (char *(*)()) F829_4247;
	{long i; for (i = 35; i < 37; i++) R3362[i] = (char *(*)()) F830_4354;}
	{long i; for (i = 38; i < 40; i++) R3362[i] = (char *(*)()) F833_4452;}
	{long i; for (i = 41; i < 43; i++) R3362[i] = (char *(*)()) F836_4551;}
	{long i; for (i = 44; i < 46; i++) R3362[i] = (char *(*)()) F839_4650;}
	{long i; for (i = 47; i < 49; i++) R3362[i] = (char *(*)()) F842_4749;}
	{long i; for (i = 50; i < 52; i++) R3362[i] = (char *(*)()) F845_4843;}
	{long i; for (i = 53; i < 55; i++) R3362[i] = (char *(*)()) F848_4937;}
	{long i; for (i = 56; i < 58; i++) R3362[i] = (char *(*)()) F851_5032;}
	{long i; for (i = 59; i < 61; i++) R3362[i] = (char *(*)()) F854_5127;}
	{long i; for (i = 62; i < 64; i++) R3362[i] = (char *(*)()) F857_5193;}
	{long i; for (i = 65; i < 67; i++) R3362[i] = (char *(*)()) F860_5260;}
	{long i; for (i = 68; i < 70; i++) R3362[i] = (char *(*)()) F863_5301;}
	{long i; for (i = 71; i < 73; i++) R3362[i] = (char *(*)()) F866_5349;}
	{long i; for (i = 74; i < 104; i++) R3362[i] = (char *(*)()) F869_5370;}
	R3362[104] = (char *(*)()) F900_5396;
	R3362[105] = (char *(*)()) F901_5396;
	R3362[110] = (char *(*)()) F902_5404;
	{long i; for (i = 115; i < 117; i++) R3362[i] = (char *(*)()) F907_5463;}
	{long i; for (i = 118; i < 120; i++) R3362[i] = (char *(*)()) F907_5463;}
	R3362[452] = (char *(*)()) F1248_8953;
}

char *(*R3450[31])();
void R3450_init () {
	R3450[0] = (char *(*)()) F798_4191;
	R3450[1] = (char *(*)()) F799_4191;
	R3450[2] = (char *(*)()) F800_4191;
	R3450[3] = (char *(*)()) F801_4191;
	R3450[4] = (char *(*)()) F802_4191;
	R3450[5] = (char *(*)()) F803_4191;
	R3450[6] = (char *(*)()) F804_4191;
	R3450[7] = (char *(*)()) F805_4191;
	R3450[8] = (char *(*)()) F806_4191;
	R3450[9] = (char *(*)()) F807_4191;
	R3450[10] = (char *(*)()) F808_4191;
	R3450[11] = (char *(*)()) F809_4191;
	R3450[12] = (char *(*)()) F810_4191;
	R3450[13] = (char *(*)()) F811_4191;
	R3450[14] = (char *(*)()) F812_4191;
	R3450[15] = (char *(*)()) F813_4191;
	R3450[16] = (char *(*)()) F814_4191;
	R3450[17] = (char *(*)()) F815_4191;
	R3450[18] = (char *(*)()) F816_4191;
	R3450[19] = (char *(*)()) F817_4191;
	R3450[20] = (char *(*)()) F818_4191;
	R3450[21] = (char *(*)()) F819_4191;
	R3450[22] = (char *(*)()) F820_4191;
	R3450[23] = (char *(*)()) F821_4191;
	R3450[24] = (char *(*)()) F822_4191;
	R3450[25] = (char *(*)()) F823_4191;
	R3450[26] = (char *(*)()) F824_4191;
	R3450[27] = (char *(*)()) F825_4191;
	R3450[28] = (char *(*)()) F826_4191;
	R3450[29] = (char *(*)()) F827_4191;
	R3450[30] = (char *(*)()) F828_4191;
}

char *(*R3453[31])();
void R3453_init () {
	R3453[0] = (char *(*)()) F798_4194;
	R3453[1] = (char *(*)()) F799_4194;
	R3453[2] = (char *(*)()) F800_4194;
	R3453[3] = (char *(*)()) F801_4194;
	R3453[4] = (char *(*)()) F802_4194;
	R3453[5] = (char *(*)()) F803_4194;
	R3453[6] = (char *(*)()) F804_4194;
	R3453[7] = (char *(*)()) F805_4194;
	R3453[8] = (char *(*)()) F806_4194;
	R3453[9] = (char *(*)()) F807_4194;
	R3453[10] = (char *(*)()) F808_4194;
	R3453[11] = (char *(*)()) F809_4194;
	R3453[12] = (char *(*)()) F810_4194;
	R3453[13] = (char *(*)()) F811_4194;
	R3453[14] = (char *(*)()) F812_4194;
	R3453[15] = (char *(*)()) F813_4194;
	R3453[16] = (char *(*)()) F814_4194;
	R3453[17] = (char *(*)()) F815_4194;
	R3453[18] = (char *(*)()) F816_4194;
	R3453[19] = (char *(*)()) F817_4194;
	R3453[20] = (char *(*)()) F818_4194;
	R3453[21] = (char *(*)()) F819_4194;
	R3453[22] = (char *(*)()) F820_4194;
	R3453[23] = (char *(*)()) F821_4194;
	R3453[24] = (char *(*)()) F822_4194;
	R3453[25] = (char *(*)()) F823_4194;
	R3453[26] = (char *(*)()) F824_4194;
	R3453[27] = (char *(*)()) F825_4194;
	R3453[28] = (char *(*)()) F826_4194;
	R3453[29] = (char *(*)()) F827_4194;
	R3453[30] = (char *(*)()) F828_4194;
}

char *(*R3458[31])();
void R3458_init () {
	R3458[0] = (char *(*)()) F798_4200;
	R3458[1] = (char *(*)()) F799_4200;
	R3458[2] = (char *(*)()) F800_4200;
	R3458[3] = (char *(*)()) F801_4200;
	R3458[4] = (char *(*)()) F802_4200;
	R3458[5] = (char *(*)()) F803_4200;
	R3458[6] = (char *(*)()) F804_4200;
	R3458[7] = (char *(*)()) F805_4200;
	R3458[8] = (char *(*)()) F806_4200;
	R3458[9] = (char *(*)()) F807_4200;
	R3458[10] = (char *(*)()) F808_4200;
	R3458[11] = (char *(*)()) F809_4200;
	R3458[12] = (char *(*)()) F810_4200;
	R3458[13] = (char *(*)()) F811_4200;
	R3458[14] = (char *(*)()) F812_4200;
	R3458[15] = (char *(*)()) F813_4200;
	R3458[16] = (char *(*)()) F814_4200;
	R3458[17] = (char *(*)()) F815_4200;
	R3458[18] = (char *(*)()) F816_4200;
	R3458[19] = (char *(*)()) F817_4200;
	R3458[20] = (char *(*)()) F818_4200;
	R3458[21] = (char *(*)()) F819_4200;
	R3458[22] = (char *(*)()) F820_4200;
	R3458[23] = (char *(*)()) F821_4200;
	R3458[24] = (char *(*)()) F822_4200;
	R3458[25] = (char *(*)()) F823_4200;
	R3458[26] = (char *(*)()) F824_4200;
	R3458[27] = (char *(*)()) F825_4200;
	R3458[28] = (char *(*)()) F826_4200;
	R3458[29] = (char *(*)()) F827_4200;
	R3458[30] = (char *(*)()) F828_4200;
}

char *(*R3463[31])();
void R3463_init () {
	R3463[0] = (char *(*)()) F798_4208;
	R3463[1] = (char *(*)()) F799_4208_3463_1;
	R3463[2] = (char *(*)()) F800_4208_3463_1;
	R3463[3] = (char *(*)()) F801_4208_3463_1;
	R3463[4] = (char *(*)()) F802_4208_3463_1;
	R3463[5] = (char *(*)()) F803_4208_3463_1;
	R3463[6] = (char *(*)()) F804_4208_3463_1;
	R3463[7] = (char *(*)()) F805_4208_3463_1;
	R3463[8] = (char *(*)()) F806_4208_3463_1;
	R3463[9] = (char *(*)()) F807_4208_3463_1;
	R3463[10] = (char *(*)()) F808_4208_3463_1;
	R3463[11] = (char *(*)()) F809_4208_3463_1;
	R3463[12] = (char *(*)()) F810_4208_3463_1;
	R3463[13] = (char *(*)()) F811_4208_3463_1;
	R3463[14] = (char *(*)()) F812_4208_3463_1;
	R3463[15] = (char *(*)()) F813_4208_3463_1;
	R3463[16] = (char *(*)()) F814_4208_3463_1;
	R3463[17] = (char *(*)()) F815_4208_3463_1;
	R3463[18] = (char *(*)()) F816_4208_3463_1;
	R3463[19] = (char *(*)()) F817_4208_3463_1;
	R3463[20] = (char *(*)()) F818_4208_3463_1;
	R3463[21] = (char *(*)()) F819_4208_3463_1;
	R3463[22] = (char *(*)()) F820_4208_3463_1;
	R3463[23] = (char *(*)()) F821_4208_3463_1;
	R3463[24] = (char *(*)()) F822_4208;
	R3463[25] = (char *(*)()) F823_4208_3463_1;
	R3463[26] = (char *(*)()) F824_4208_3463_1;
	R3463[27] = (char *(*)()) F825_4208_3463_1;
	R3463[28] = (char *(*)()) F826_4208_3463_1;
	R3463[29] = (char *(*)()) F827_4208_3463_1;
	R3463[30] = (char *(*)()) F828_4208_3463_1;
}
static EIF_REFERENCE F799_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REFERENCE* r = F799_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {870,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 870, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REFERENCE* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F800_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER r = F800_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		Result = RTLNS(eif_new_type(900, 0x00).id, 900, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F801_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32 r = F801_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i4;
	} else {
		Result = RTLNS(eif_new_type(834, 0x00).id, 834, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_INTEGER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F802_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64 r = F802_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r8;
	} else {
		Result = RTLNS(eif_new_type(858, 0x00).id, 858, _OBJSIZ_0_0_0_0_0_0_0_1_);
		*(EIF_REAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F803_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32 r = F803_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_r4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_r4;
	} else {
		Result = RTLNS(eif_new_type(855, 0x00).id, 855, _OBJSIZ_0_0_0_0_1_0_0_0_);
		*(EIF_REAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F804_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8 r = F804_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n1;
	} else {
		Result = RTLNS(eif_new_type(852, 0x00).id, 852, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_NATURAL_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F805_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16 r = F805_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n2;
	} else {
		Result = RTLNS(eif_new_type(849, 0x00).id, 849, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_NATURAL_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F806_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32 r = F806_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n4;
	} else {
		Result = RTLNS(eif_new_type(846, 0x00).id, 846, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_NATURAL_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F807_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64 r = F807_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_n8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_n8;
	} else {
		Result = RTLNS(eif_new_type(843, 0x00).id, 843, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_NATURAL_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F808_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8 r = F808_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i1;
	} else {
		Result = RTLNS(eif_new_type(840, 0x00).id, 840, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_INTEGER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F809_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16 r = F809_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i2 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i2;
	} else {
		Result = RTLNS(eif_new_type(837, 0x00).id, 837, _OBJSIZ_0_0_1_0_0_0_0_0_);
		*(EIF_INTEGER_16 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F810_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64 r = F810_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_i8 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_i8;
	} else {
		Result = RTLNS(eif_new_type(831, 0x00).id, 831, _OBJSIZ_0_0_0_0_0_0_1_0_);
		*(EIF_INTEGER_64 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F811_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8 r = F811_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c1 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c1;
	} else {
		Result = RTLNS(eif_new_type(864, 0x00).id, 864, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_CHARACTER_8 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F812_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F812_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(867, 0x00).id, 867, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F813_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32 r = F813_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_c4 = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_c4;
	} else {
		Result = RTLNS(eif_new_type(861, 0x00).id, 861, _OBJSIZ_0_0_0_1_0_0_0_0_);
		*(EIF_CHARACTER_32 *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F814_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_64* r = F814_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {872,831,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 872, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F815_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_16* r = F815_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {874,837,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 874, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F816_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_64* r = F816_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {876,843,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 876, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F817_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_32* r = F817_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {878,846,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 878, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F818_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_16* r = F818_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {880,849,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 880, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_16* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F819_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_NATURAL_8* r = F819_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {882,852,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 882, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_NATURAL_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F820_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_32* r = F820_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {884,855,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 884, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F821_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_REAL_64* r = F821_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {886,858,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 886, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_REAL_64* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F823_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_POINTER* r = F823_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {888,900,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 888, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_POINTER* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F824_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_8* r = F824_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {890,840,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 890, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F825_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_INTEGER_32* r = F825_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {892,834,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 892, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_INTEGER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F826_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_8* r = F826_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {894,864,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 894, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_8* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F827_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_CHARACTER_32* r = F827_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {896,861,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 896, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_CHARACTER_32* *)Result = r;
		return Result;
	}
}
static EIF_REFERENCE F828_4208_3463_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN* r = F828_4208(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_p = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_p;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {898,867,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			Result = RTLNS(typres0.id, 898, _OBJSIZ_0_0_0_0_0_1_0_0_);
		}
		*(EIF_BOOLEAN* *)Result = r;
		return Result;
	}
}

char *(*R3473[31])();
void R3473_init () {
	R3473[0] = (char *(*)()) F798_4220;
	R3473[1] = (char *(*)()) F799_4220;
	R3473[2] = (char *(*)()) F800_4220;
	R3473[3] = (char *(*)()) F801_4220;
	R3473[4] = (char *(*)()) F802_4220;
	R3473[5] = (char *(*)()) F803_4220;
	R3473[6] = (char *(*)()) F804_4220;
	R3473[7] = (char *(*)()) F805_4220;
	R3473[8] = (char *(*)()) F806_4220;
	R3473[9] = (char *(*)()) F807_4220;
	R3473[10] = (char *(*)()) F808_4220;
	R3473[11] = (char *(*)()) F809_4220;
	R3473[12] = (char *(*)()) F810_4220;
	R3473[13] = (char *(*)()) F811_4220;
	R3473[14] = (char *(*)()) F812_4220;
	R3473[15] = (char *(*)()) F813_4220;
	R3473[16] = (char *(*)()) F814_4220;
	R3473[17] = (char *(*)()) F815_4220;
	R3473[18] = (char *(*)()) F816_4220;
	R3473[19] = (char *(*)()) F817_4220;
	R3473[20] = (char *(*)()) F818_4220;
	R3473[21] = (char *(*)()) F819_4220;
	R3473[22] = (char *(*)()) F820_4220;
	R3473[23] = (char *(*)()) F821_4220;
	R3473[24] = (char *(*)()) F822_4220;
	R3473[25] = (char *(*)()) F823_4220;
	R3473[26] = (char *(*)()) F824_4220;
	R3473[27] = (char *(*)()) F825_4220;
	R3473[28] = (char *(*)()) F826_4220;
	R3473[29] = (char *(*)()) F827_4220;
	R3473[30] = (char *(*)()) F828_4220;
}

char *(*R3619[2])();
void R3619_init () {
	R3619[0] = (char *(*)()) F831_4436;
	R3619[1] = (char *(*)()) F832_4436;
}

char *(*R3622[2])();
void R3622_init () {
	R3622[0] = (char *(*)()) F831_4439;
	R3622[1] = (char *(*)()) F832_4439;
}

char *(*R3674[2])();
void R3674_init () {
	R3674[0] = (char *(*)()) F834_4534;
	R3674[1] = (char *(*)()) F835_4534;
}

char *(*R3675[2])();
void R3675_init () {
	R3675[0] = (char *(*)()) F834_4535;
	R3675[1] = (char *(*)()) F835_4535;
}

char *(*R3679[2])();
void R3679_init () {
	R3679[0] = (char *(*)()) F834_4539;
	R3679[1] = (char *(*)()) F835_4539;
}

char *(*R3731[2])();
void R3731_init () {
	R3731[0] = (char *(*)()) F837_4634;
	R3731[1] = (char *(*)()) F838_4634;
}

char *(*R3734[2])();
void R3734_init () {
	R3734[0] = (char *(*)()) F837_4637;
	R3734[1] = (char *(*)()) F838_4637;
}

char *(*R3784[2])();
void R3784_init () {
	R3784[0] = (char *(*)()) F840_4730;
	R3784[1] = (char *(*)()) F841_4730;
}

char *(*R3787[2])();
void R3787_init () {
	R3787[0] = (char *(*)()) F840_4733;
	R3787[1] = (char *(*)()) F841_4733;
}

char *(*R3790[2])();
void R3790_init () {
	R3790[0] = (char *(*)()) F840_4736;
	R3790[1] = (char *(*)()) F841_4736;
}

char *(*R3844[2])();
void R3844_init () {
	R3844[0] = (char *(*)()) F843_4830;
	R3844[1] = (char *(*)()) F844_4830;
}

char *(*R3890[2])();
void R3890_init () {
	R3890[0] = (char *(*)()) F846_4918;
	R3890[1] = (char *(*)()) F847_4918;
}

char *(*R3891[2])();
void R3891_init () {
	R3891[0] = (char *(*)()) F846_4919;
	R3891[1] = (char *(*)()) F847_4919;
}

char *(*R3893[2])();
void R3893_init () {
	R3893[0] = (char *(*)()) F846_4921;
	R3893[1] = (char *(*)()) F847_4921;
}

char *(*R3896[2])();
void R3896_init () {
	R3896[0] = (char *(*)()) F846_4924;
	R3896[1] = (char *(*)()) F847_4924;
}

char *(*R3897[2])();
void R3897_init () {
	R3897[0] = (char *(*)()) F846_4925;
	R3897[1] = (char *(*)()) F847_4925;
}

char *(*R3945[2])();
void R3945_init () {
	R3945[0] = (char *(*)()) F849_5015;
	R3945[1] = (char *(*)()) F850_5015;
}

char *(*R3946[2])();
void R3946_init () {
	R3946[0] = (char *(*)()) F849_5016;
	R3946[1] = (char *(*)()) F850_5016;
}

char *(*R3949[2])();
void R3949_init () {
	R3949[0] = (char *(*)()) F849_5019;
	R3949[1] = (char *(*)()) F850_5019;
}

char *(*R3997[2])();
void R3997_init () {
	R3997[0] = (char *(*)()) F852_5109;
	R3997[1] = (char *(*)()) F853_5109;
}

char *(*R3998[2])();
void R3998_init () {
	R3998[0] = (char *(*)()) F852_5110;
	R3998[1] = (char *(*)()) F853_5110;
}

char *(*R3999[2])();
void R3999_init () {
	R3999[0] = (char *(*)()) F852_5111;
	R3999[1] = (char *(*)()) F853_5111;
}

char *(*R4000[2])();
void R4000_init () {
	R4000[0] = (char *(*)()) F852_5112;
	R4000[1] = (char *(*)()) F853_5112;
}

char *(*R4002[2])();
void R4002_init () {
	R4002[0] = (char *(*)()) F852_5114;
	R4002[1] = (char *(*)()) F853_5114;
}

char *(*R4048[2])();
void R4048_init () {
	R4048[0] = (char *(*)()) F855_5172;
	R4048[1] = (char *(*)()) F856_5172;
}

char *(*R4082[2])();
void R4082_init () {
	R4082[0] = (char *(*)()) F858_5238;
	R4082[1] = (char *(*)()) F859_5238;
}

char *(*R4103[2])();
void R4103_init () {
	R4103[0] = (char *(*)()) F861_5296;
	R4103[1] = (char *(*)()) F862_5296;
}

char *(*R4251[1])();
void R4251_init () {
	R4251[0] = (char *(*)()) F905_5443_4251_1;
}
static EIF_REFERENCE F905_5443_4251_1 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result;
	int l_eif_optimize_return = eif_optimize_return;
	EIF_BOOLEAN r = F905_5443(Current);
	if (l_eif_optimize_return) {
		eif_optimize_return = 0;
		eif_optimized_return_value.it_b = r;
		return (EIF_REFERENCE) &eif_optimized_return_value.it_b;
	} else {
		Result = RTLNS(eif_new_type(867, 0x00).id, 867, _OBJSIZ_0_1_0_0_0_0_0_0_);
		*(EIF_BOOLEAN *)Result = r;
		return Result;
	}
}

char *(*R4258[338])();
void R4258_init () {
	{long i; for (i = 0; i < 2; i++) R4258[i] = (char *(*)()) F910_5584;}
	{long i; for (i = 3; i < 5; i++) R4258[i] = (char *(*)()) F913_5751;}
	R4258[337] = (char *(*)()) F1248_8927;
}

char *(*R4260[338])();
void R4260_init () {
	R4260[0] = (char *(*)()) F911_5645;
	R4260[1] = (char *(*)()) F912_5668;
	R4260[3] = (char *(*)()) F914_5811;
	R4260[4] = (char *(*)()) F915_5833;
	R4260[337] = (char *(*)()) F1248_9055;
}

char *(*R4261[338])();
void R4261_init () {
	R4261[0] = (char *(*)()) F911_5643;
	R4261[1] = (char *(*)()) F912_5666;
	R4261[3] = (char *(*)()) F914_5810;
	R4261[4] = (char *(*)()) F915_5832;
	R4261[337] = (char *(*)()) F915_5832;
}

char *(*R4275[338])();
void R4275_init () {
	R4275[0] = (char *(*)()) F911_5655;
	R4275[1] = (char *(*)()) F605_3219;
	R4275[3] = (char *(*)()) F914_5820;
	R4275[4] = (char *(*)()) F602_3219;
	R4275[337] = (char *(*)()) F602_3219;
}

char *(*R4297[338])();
void R4297_init () {
	{long i; for (i = 0; i < 2; i++) R4297[i] = (char *(*)()) F910_5605;}
	{long i; for (i = 3; i < 5; i++) R4297[i] = (char *(*)()) F913_5773;}
	R4297[337] = (char *(*)()) F1248_8958;
}

char *(*R4298[338])();
void R4298_init () {
	{long i; for (i = 0; i < 2; i++) R4298[i] = (char *(*)()) F910_5604;}
	{long i; for (i = 3; i < 5; i++) R4298[i] = (char *(*)()) F913_5772;}
	R4298[337] = (char *(*)()) F1248_8960;
}

char *(*R4303[338])();
void R4303_init () {
	{long i; for (i = 0; i < 2; i++) R4303[i] = (char *(*)()) F907_5499;}
	{long i; for (i = 3; i < 5; i++) R4303[i] = (char *(*)()) F907_5499;}
	R4303[337] = (char *(*)()) F1248_8971;
}

char *(*R4319[338])();
void R4319_init () {
	R4319[0] = (char *(*)()) F911_5650;
	R4319[4] = (char *(*)()) F915_5899;
	R4319[337] = (char *(*)()) F1248_9015;
}

char *(*R4338[338])();
void R4338_init () {
	R4338[0] = (char *(*)()) F911_5652;
	R4338[1] = (char *(*)()) F912_5746;
	R4338[3] = (char *(*)()) F914_5818;
	R4338[4] = (char *(*)()) F915_5911;
	R4338[337] = (char *(*)()) F1248_8944;
}

char *(*R4353[337])();
void R4353_init () {
	R4353[0] = (char *(*)()) F912_5748;
	R4353[3] = (char *(*)()) F915_5913;
	R4353[336] = (char *(*)()) F915_5913;
}

char *(*R4356[337])();
void R4356_init () {
	R4356[0] = (char *(*)()) F912_5687;
	R4356[3] = (char *(*)()) F915_5852;
	R4356[336] = (char *(*)()) F1248_9057;
}

char *(*R4357[337])();
void R4357_init () {
	R4357[0] = (char *(*)()) F909_5554;
	R4357[3] = (char *(*)()) F909_5554;
	R4357[336] = (char *(*)()) F1248_9058;
}

char *(*R4376[334])();
void R4376_init () {
	R4376[0] = (char *(*)()) F915_5846;
	R4376[333] = (char *(*)()) F1248_9004;
}

char *(*R4377[334])();
void R4377_init () {
	R4377[0] = (char *(*)()) F915_5847;
	R4377[333] = (char *(*)()) F1248_9005;
}

char *(*R4382[334])();
void R4382_init () {
	R4382[0] = (char *(*)()) F915_5886;
	R4382[333] = (char *(*)()) F1248_9006;
}

char *(*R4384[334])();
void R4384_init () {
	R4384[0] = (char *(*)()) F915_5888;
	R4384[333] = (char *(*)()) F1248_9007;
}

char *(*R4385[334])();
void R4385_init () {
	R4385[0] = (char *(*)()) F915_5893;
	R4385[333] = (char *(*)()) F1248_9051;
}

char *(*R4386[337])();
void R4386_init () {
	R4386[0] = (char *(*)()) F912_5731;
	R4386[3] = (char *(*)()) F915_5896;
	R4386[336] = (char *(*)()) F915_5896;
}


#ifdef __cplusplus
}
#endif
