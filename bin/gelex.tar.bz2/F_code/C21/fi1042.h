
#ifndef _C21_fi1042_
#define _C21_fi1042_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F609_3219(EIF_REFERENCE);
extern void EIF_Minit1042(void);
extern EIF_INTEGER_32 F711_3697(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
