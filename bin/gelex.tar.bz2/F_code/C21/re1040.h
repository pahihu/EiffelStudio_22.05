
#ifndef _C21_re1040_
#define _C21_re1040_

#ifdef __cplusplus
extern "C" {
#endif

extern void F397_3034(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F397_3036(EIF_REFERENCE);
extern EIF_INTEGER_32 F397_3037(EIF_REFERENCE);
extern EIF_INTEGER_32 F397_3038(EIF_REFERENCE);
extern EIF_INTEGER_32 F397_3039(EIF_REFERENCE);
extern EIF_BOOLEAN F397_3047(EIF_REFERENCE);
extern EIF_BOOLEAN F397_3048(EIF_REFERENCE);
extern void F397_3053(EIF_REFERENCE);
extern void EIF_Minit1040(void);
extern char *(*R3078[])();
extern char *(*R3079[])();

#ifdef __cplusplus
}
#endif

#endif
