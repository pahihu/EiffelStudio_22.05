
#ifndef _C21_ds1014_
#define _C21_ds1014_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1023_6768(EIF_REFERENCE);
extern void EIF_Minit1014(void);
extern char *(*R5660[])();

#ifdef __cplusplus
}
#endif

#endif
