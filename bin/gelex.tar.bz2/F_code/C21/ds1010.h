
#ifndef _C21_ds1010_
#define _C21_ds1010_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1181_7972(EIF_REFERENCE);
extern EIF_INTEGER_32 F1181_7975(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1010(void);
extern char *(*R5216[])();
extern EIF_TYPE_INDEX Y5580[];
extern EIF_TYPE_INDEX *Y5580_gen_type [];
extern EIF_TYPE_INDEX Y805[];
extern EIF_TYPE_INDEX *Y805_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
