
#ifndef _C21_ds1016_
#define _C21_ds1016_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1163_7737(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1163_7738(EIF_REFERENCE);
extern EIF_REFERENCE F1163_7739(EIF_REFERENCE);
extern EIF_INTEGER_32 F1163_7742(EIF_REFERENCE);
extern EIF_INTEGER_32 F1163_7743(EIF_REFERENCE);
extern EIF_BOOLEAN F1163_7746(EIF_REFERENCE);
extern void F1163_7756(EIF_REFERENCE);
extern void F1163_7757(EIF_REFERENCE, EIF_REFERENCE);
extern void F1163_7760(EIF_REFERENCE);
extern void F1163_7761(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1163_7770(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1163_7771(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1163_7807(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1163_7808(EIF_REFERENCE);
extern void F1163_7809(EIF_REFERENCE);
extern EIF_REFERENCE F1163_7813(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1163_7814(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1163_7815(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1163_7816(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1163_7817(EIF_REFERENCE, EIF_REFERENCE);
extern void F1163_7819(EIF_REFERENCE, EIF_REFERENCE);
extern void F1163_7821(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F1163_7823(EIF_REFERENCE, EIF_REFERENCE);
extern void F1163_7825(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1163_7826(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1163_7827(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit1016(void);
extern char *(*R5831[])();
extern char *(*R5833[])();
extern char *(*R5834[])();
extern char *(*R5835[])();
extern char *(*R5836[])();
extern char *(*R1979[])();
extern char *(*R5838[])();
extern char *(*R5603[])();
extern char *(*R5864[])();
extern char *(*R5218[])();
extern char *(*R5606[])();
extern char *(*R5608[])();
extern char *(*R5841[])();
extern char *(*R5842[])();
extern char *(*R5192[])();
extern char *(*R5844[])();
extern char *(*R5845[])();
extern char *(*R5846[])();
extern char *(*R5847[])();
extern char *(*R5848[])();
extern char *(*R5849[])();
extern char *(*R5610[])();
extern char *(*R5611[])();
extern char *(*R5572[])();
extern char *(*R5614[])();
extern char *(*R5615[])();
extern char *(*R5850[])();
extern char *(*R5851[])();
extern char *(*R5852[])();
extern char *(*R5853[])();
extern char *(*R5854[])();
extern char *(*R5816[])();
extern char *(*R5821[])();
extern char *(*R5823[])();
extern char *(*R5824[])();
extern char *(*R5868[])();
extern char *(*R5840[])();
extern char *(*R5829[])();
extern char *(*R5219[])();
extern char *(*R5635[])();
extern char *(*R5637[])();
extern long O5860[];
extern long O5820[];
extern long O5870[];
extern long O5871[];
extern long O5855[];
extern long O5856[];
extern long O5857[];
extern long O5858[];
extern long O5859[];

#ifdef __cplusplus
}
#endif

#endif
