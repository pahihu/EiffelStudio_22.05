
#ifndef _C21_ds1023_
#define _C21_ds1023_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1031_6774(EIF_REFERENCE);
extern void EIF_Minit1023(void);

#ifdef __cplusplus
}
#endif

#endif
