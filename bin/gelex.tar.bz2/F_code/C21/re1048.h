
#ifndef _C21_re1048_
#define _C21_re1048_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F635_3232(EIF_REFERENCE);
extern void EIF_Minit1048(void);
extern EIF_INTEGER_32 F711_3698(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
