
#ifndef _C21_co1037_
#define _C21_co1037_

#ifdef __cplusplus
extern "C" {
#endif

extern void F466_3121(EIF_REFERENCE);
extern void EIF_Minit1037(void);
extern long O2805[];

#ifdef __cplusplus
}
#endif

#endif
