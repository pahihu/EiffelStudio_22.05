/*
 * Code for class DS_SPARSE_CONTAINER_CURSOR [G#1, INTEGER_32]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds1015.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_SPARSE_CONTAINER_CURSOR}.make */
void F1013_6747 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -2L);
	RTLE;
}

/* {DS_SPARSE_CONTAINER_CURSOR}.after */
EIF_BOOLEAN F1013_6749 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) == ((EIF_INTEGER_32) -3L));
}

/* {DS_SPARSE_CONTAINER_CURSOR}.before */
EIF_BOOLEAN F1013_6750 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) == ((EIF_INTEGER_32) -2L));
}

/* {DS_SPARSE_CONTAINER_CURSOR}.off */
EIF_BOOLEAN F1013_6751 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) < ((EIF_INTEGER_32) 0L));
}

/* {DS_SPARSE_CONTAINER_CURSOR}.set_position */
void F1013_6753 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) = (EIF_INTEGER_32) arg1;
}

/* {DS_SPARSE_CONTAINER_CURSOR}.set_after */
void F1013_6754 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -3L);
}

/* {DS_SPARSE_CONTAINER_CURSOR}.correct_mismatch */
void F1013_6760 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\01';
	tr1 = *(EIF_REFERENCE *)(RTCV(RTOSCF(3863,F772_3863, (Current))) + _REFACS_7_);
	loc2 = tr1;
	if (!((EIF_BOOLEAN) !EIF_TEST(loc2))) {
		tb2 = F914_5820(loc2);
		tb1 = tb2;
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R5224[dtype-1019])(Current);
	} else {
		tb1 = F907_5485(loc2);
		if (tb1) {
			loc1 = F907_5519(loc2);
			if ((EIF_BOOLEAN) (loc1 < ((EIF_INTEGER_32) 20130823L))) {
				(FUNCTION_CAST(void, (EIF_REFERENCE)) R5224[dtype-1019])(Current);
			} else {
				F772_3862(Current);
			}
		} else {
			F772_3862(Current);
		}
	}
	RTLE;
}

/* {DS_SPARSE_CONTAINER_CURSOR}.correct_mismatch_20130823 */
void F1013_6761 (EIF_REFERENCE Current)
{
	GTCX
	
	
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_2_0_0_0_))--;
}

void EIF_Minit1015 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
