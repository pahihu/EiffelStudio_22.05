
#ifndef _C21_ds1012_
#define _C21_ds1012_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1173_7892(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1173_7895(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1173_7898(EIF_REFERENCE, EIF_INTEGER_32, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1173_7900(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1173_7901(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F1173_7906(EIF_REFERENCE);
extern EIF_BOOLEAN F1173_7908(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1173_7911(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_BOOLEAN F1173_7912(EIF_REFERENCE, EIF_REFERENCE);
extern void F1173_7913(EIF_REFERENCE, EIF_REFERENCE);
extern void F1173_7915(EIF_REFERENCE, EIF_REFERENCE);
extern void F1173_7920(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F1173_7921(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F1173_7924(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1173_7936(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit1012(void);
extern void F1163_7757(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F932_5994(EIF_REFERENCE);
extern void F1_29(EIF_REFERENCE);
extern EIF_BOOLEAN F16_120(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
RTOSHF(EIF_REFERENCE,5994)
extern char *(*R5831[])();
extern char *(*R5839[])();
extern char *(*R5886[])();
extern char *(*R5845[])();
extern char *(*R5777[])();
extern char *(*R5778[])();
extern char *(*R5582[])();
extern char *(*R5812[])();
extern char *(*R5585[])();
extern char *(*R5850[])();
extern char *(*R5816[])();
extern char *(*R5851[])();
extern char *(*R5821[])();
extern char *(*R5822[])();
extern char *(*R5823[])();
extern char *(*R5824[])();
extern char *(*R5827[])();
extern char *(*R5828[])();
extern EIF_TYPE_INDEX Y5901[];
extern EIF_TYPE_INDEX *Y5901_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
