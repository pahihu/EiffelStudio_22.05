
#ifndef _C9_ar438_
#define _C9_ar438_

#ifdef __cplusplus
extern "C" {
#endif

extern void F702_3684(EIF_REFERENCE);
extern void F702_3685(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F702_3686(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F702_3687(EIF_REFERENCE, EIF_REFERENCE);
extern void F702_3688(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F702_3690(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F702_3695(EIF_REFERENCE);
extern EIF_INTEGER_32 F702_3696(EIF_REFERENCE);
extern EIF_INTEGER_32 F702_3697(EIF_REFERENCE);
extern EIF_INTEGER_32 F702_3698(EIF_REFERENCE);
extern EIF_BOOLEAN F702_3700(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F702_3705(EIF_REFERENCE, EIF_INTEGER_32);
extern void F702_3709(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F702_3711(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F702_3714(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F702_3730(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F702_3738(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F702_3742(EIF_REFERENCE);
extern void EIF_Minit438(void);
extern EIF_REFERENCE F1_14(EIF_REFERENCE);
extern char *(*R3092[])();
extern char *(*R3093[])();
extern char *(*R3095[])();
extern char *(*R3097[])();
extern char *(*R2867[])();
extern char *(*R2240[])();
extern char *(*R2241[])();
extern char *(*R3177[])();
extern char *(*R2247[])();
extern char *(*R2638[])();
extern char *(*R2639[])();
extern char *(*R2874[])();
extern char *(*R2870[])();
extern char *(*R3100[])();
extern char *(*R3101[])();
extern char *(*R2840[])();
extern char *(*R3463[])();
extern char *(*R3077[])();
extern char *(*R3110[])();
extern char *(*R3111[])();
extern EIF_TYPE_INDEX Y2704[];
extern EIF_TYPE_INDEX *Y2704_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
