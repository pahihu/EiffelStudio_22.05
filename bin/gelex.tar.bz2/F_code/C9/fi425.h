
#ifndef _C9_fi425_
#define _C9_fi425_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F600_3219(EIF_REFERENCE);
extern void EIF_Minit425(void);
extern char *(*R2867[])();

#ifdef __cplusplus
}
#endif

#endif
