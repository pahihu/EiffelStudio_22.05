
#ifndef _C9_re431_
#define _C9_re431_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F626_3232(EIF_REFERENCE);
extern void EIF_Minit431(void);
extern char *(*R2870[])();

#ifdef __cplusplus
}
#endif

#endif
