/*
 * Code for class UC_STRING
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "uc404.h"
#include "eif_copy.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {UC_STRING}.make */
void F1248_8927 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1248_9037(Current);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 0L))) {
		F913_5751(Current, ((EIF_INTEGER_32) 1L));
	} else {
		F913_5751(Current, arg1);
	}
	ti4_1 = F1248_8960(Current);
	F1248_9045(Current, ti4_1);
	ti4_1 = F1248_8960(Current);
	F915_5913(Current, ti4_1);
	F1248_9045(Current, ((EIF_INTEGER_32) 0L));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {UC_STRING}.make_from_string */
void F1248_8928 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1248_8930(Current, arg1);
}

/* {UC_STRING}.make_empty */
void F1248_8929 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1248_8927(Current, ((EIF_INTEGER_32) 0L));
}

/* {UC_STRING}.make_from_string_general */
void F1248_8930 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,loc1);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc2 = arg1;
	loc2 = RTRV(eif_new_type(1247, 0x01),loc2);
	if (EIF_TEST(loc2)) {
		loc1 = (EIF_REFERENCE) loc2;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		if ((EIF_BOOLEAN)(arg1 != Current)) {
			loc1 = (EIF_REFERENCE) NULL;
		}
	}
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4297[Dtype(RTCW(arg1))-910])(arg1);
		F1248_8932(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
	}
	RTLE;
}

/* {UC_STRING}.make_from_substring */
void F1248_8931 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	
	
	F1248_8932(Current, arg1, arg2, arg3);
}

/* {UC_STRING}.make_from_substring_general */
void F1248_8932 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc4);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	loc4 = arg1;
	loc4 = RTRV(eif_new_type(1247, 0x01),loc4);
	if (EIF_TEST(loc4)) {
		loc3 = (EIF_REFERENCE) loc4;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		if ((EIF_BOOLEAN)(arg1 != Current)) {
			loc3 = (EIF_REFERENCE) NULL;
		}
	}
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc3 != NULL) && (EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 1L))) && (EIF_BOOLEAN)(arg3 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_)))) {
		tr1 = *(EIF_REFERENCE *)(RTCW(loc3));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	} else {
		if ((EIF_BOOLEAN) (arg3 < arg2)) {
			F1248_8927(Current, ((EIF_INTEGER_32) 0L));
		} else {
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				loc2 = F1248_9012(RTCW(loc3));
			} else {
				loc2 = (EIF_REFERENCE) arg1;
			}
			tr1 = RTOSCF(940,F68_940, (Current));
			loc1 = F938_6119(RTCW(tr1), loc2, arg2, arg3);
			F1248_8927(Current, loc1);
			F1248_9045(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L)));
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) loc1;
			F1248_9048(Current, loc2, arg2, arg3, loc1, ((EIF_INTEGER_32) 1L));
		}
	}
	RTLE;
}

/* {UC_STRING}.make_filled */
void F1248_8935 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(940,F68_940, (Current));
	loc2 = F938_6120(RTCW(tr1), arg1);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 * arg2);
	F1248_8927(Current, loc3);
	F1248_9045(Current, arg2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) loc3;
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 1L))) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			F1248_9040(Current, arg1, loc1);
			loc1++;
		}
	} else {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			F1248_9047(Current, arg1, loc2, loc1);
			loc1 += loc2;
		}
	}
	RTLE;
}

/* {UC_STRING}.item_code */
EIF_INTEGER_32 F1248_8941 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		tc1 = F1248_9039(Current, arg1);
		Result = (EIF_INTEGER_32) (tc1);
	} else {
		loc1 = F1248_9033(Current, arg1);
		Result = F1248_9029(Current, loc1);
		RTLE;
		return (EIF_INTEGER_32) Result;
	}
	RTLE;
	return Result;
}

/* {UC_STRING}.item */
EIF_CHARACTER_8 F1248_8942 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		RTLE;
		return (EIF_CHARACTER_8) F1248_9039(Current, arg1);
	} else {
		loc1 = F1248_9033(Current, arg1);
		RTLE;
		return (EIF_CHARACTER_8) F1248_9030(Current, loc1);
	}/* NOTREACHED */
	
}

/* {UC_STRING}.substring */
EIF_REFERENCE F1248_8944 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg2 < arg1)) {
		tr1 = RTLNSMART(dftype);
		F1248_8927(RTCW(tr1), ((EIF_INTEGER_32) 0L));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTLNSMART(dftype);
		F1248_8931(RTCW(tr1), Current, arg1, arg2);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {UC_STRING}.unicode_substring_index */
EIF_INTEGER_32 F1248_8945 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_NATURAL_32 tu4_1;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc11);
	RTLR(3,loc12);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		if ((EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 1L))) {
			RTLE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
	} else {
		loc10 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4297[Dtype(RTCW(arg1))-910])(arg1);
		if ((EIF_BOOLEAN)(loc10 == ((EIF_INTEGER_32) 0L))) {
			RTLE;
			return (EIF_INTEGER_32) arg2;
		} else {
			loc8 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
			loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc8 - loc10) + ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN) (arg2 <= loc8)) {
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
					loc11 = arg1;
					loc11 = RTRV(eif_new_type(1247, 0x01),loc11);
					if (EIF_TEST(loc11)) {
						loc3 = *(EIF_INTEGER_32 *)(loc11+ _LNGOFF_1_1_0_3_);
						loc6 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc6 > loc8)) break;
							loc2 = (EIF_INTEGER_32) loc6;
							loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							for (;;) {
								if ((EIF_BOOLEAN) (loc1 > loc3)) break;
								loc4 = F1248_9029(loc11, loc1);
								tc1 = F1248_9039(Current, loc2);
								ti4_1 = (EIF_INTEGER_32) (tc1);
								if ((EIF_BOOLEAN)(ti4_1 != loc4)) {
									loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
								} else {
									loc2++;
									ti4_1 = F1248_9031(loc11, loc1);
									loc1 = (EIF_INTEGER_32) ti4_1;
								}
							}
							if (loc9) {
								Result = (EIF_INTEGER_32) loc6;
								loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
							} else {
								loc6++;
							}
						}
					} else {
						loc3 = (EIF_INTEGER_32) loc10;
						loc6 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc6 > loc8)) break;
							loc2 = (EIF_INTEGER_32) loc6;
							loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							for (;;) {
								if ((EIF_BOOLEAN) (loc1 > loc3)) break;
								tc1 = F1248_9039(Current, loc2);
								ti4_1 = (EIF_INTEGER_32) (tc1);
								tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4260[Dtype(RTCW(arg1))-910])(arg1, loc1);
								ti4_2 = (EIF_INTEGER_32) tu4_1;
								if ((EIF_BOOLEAN)(ti4_1 != ti4_2)) {
									loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
								} else {
									loc2++;
									loc1++;
								}
							}
							if (loc9) {
								Result = (EIF_INTEGER_32) loc6;
								loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
							} else {
								loc6++;
							}
						}
					}
				} else {
					loc7 = F1248_9033(Current, arg2);
					loc12 = arg1;
					loc12 = RTRV(eif_new_type(1247, 0x01),loc12);
					if (EIF_TEST(loc12)) {
						loc3 = *(EIF_INTEGER_32 *)(loc12+ _LNGOFF_1_1_0_3_);
						loc6 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc6 > loc8)) break;
							loc2 = (EIF_INTEGER_32) loc7;
							loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							for (;;) {
								if ((EIF_BOOLEAN) (loc1 > loc3)) break;
								loc4 = F1248_9029(Current, loc2);
								loc5 = F1248_9029(loc12, loc1);
								if ((EIF_BOOLEAN)(loc4 != loc5)) {
									loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
								} else {
									ti4_1 = F1248_9031(Current, loc2);
									loc2 = (EIF_INTEGER_32) ti4_1;
									ti4_1 = F1248_9031(loc12, loc1);
									loc1 = (EIF_INTEGER_32) ti4_1;
								}
							}
							if (loc9) {
								Result = (EIF_INTEGER_32) loc6;
								loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
							} else {
								ti4_1 = F1248_9031(Current, loc7);
								loc7 = (EIF_INTEGER_32) ti4_1;
								loc6++;
							}
						}
					} else {
						loc3 = (EIF_INTEGER_32) loc10;
						loc6 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc6 > loc8)) break;
							loc2 = (EIF_INTEGER_32) loc7;
							loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							for (;;) {
								if ((EIF_BOOLEAN) (loc1 > loc3)) break;
								loc4 = F1248_9029(Current, loc2);
								tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4260[Dtype(RTCW(arg1))-910])(arg1, loc1);
								ti4_1 = (EIF_INTEGER_32) tu4_1;
								if ((EIF_BOOLEAN)(loc4 != ti4_1)) {
									loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
								} else {
									ti4_1 = F1248_9031(Current, loc2);
									loc2 = (EIF_INTEGER_32) ti4_1;
									loc1++;
								}
							}
							if (loc9) {
								Result = (EIF_INTEGER_32) loc6;
								loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
							} else {
								ti4_1 = F1248_9031(Current, loc7);
								loc7 = (EIF_INTEGER_32) ti4_1;
								loc6++;
							}
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {UC_STRING}.substring_index */
EIF_INTEGER_32 F1248_8946 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc11);
	RTLR(3,loc12);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		if ((EIF_BOOLEAN)(arg2 == ((EIF_INTEGER_32) 1L))) {
			RTLE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		}
	} else {
		loc10 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O4496[Dtype(arg1)-912]);
		if ((EIF_BOOLEAN)(loc10 == ((EIF_INTEGER_32) 0L))) {
			RTLE;
			return (EIF_INTEGER_32) arg2;
		} else {
			loc8 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
			loc8 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc8 - loc10) + ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN) (arg2 <= loc8)) {
				if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
					loc11 = arg1;
					loc11 = RTRV(eif_new_type(1247, 0x01),loc11);
					if (EIF_TEST(loc11)) {
						loc3 = *(EIF_INTEGER_32 *)(loc11+ _LNGOFF_1_1_0_3_);
						loc6 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc6 > loc8)) break;
							loc2 = (EIF_INTEGER_32) loc6;
							loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							for (;;) {
								if ((EIF_BOOLEAN) (loc1 > loc3)) break;
								loc4 = F1248_9029(loc11, loc1);
								ti4_1 = RTOSCF(1798,F165_1798, (RTCV(RTOSCF(871,F65_871, (Current)))));
								if ((EIF_BOOLEAN) (loc4 > ti4_1)) {
									loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								}
								tc1 = F1248_9039(Current, loc2);
								ti4_1 = (EIF_INTEGER_32) (tc1);
								if ((EIF_BOOLEAN)(ti4_1 != loc4)) {
									loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
								} else {
									loc2++;
									ti4_1 = F1248_9031(loc11, loc1);
									loc1 = (EIF_INTEGER_32) ti4_1;
								}
							}
							if (loc9) {
								Result = (EIF_INTEGER_32) loc6;
								loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
							} else {
								loc6++;
							}
						}
					} else {
						loc3 = (EIF_INTEGER_32) loc10;
						loc6 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc6 > loc8)) break;
							loc2 = (EIF_INTEGER_32) loc6;
							loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							for (;;) {
								if ((EIF_BOOLEAN) (loc1 > loc3)) break;
								tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, loc1));
								if ((EIF_BOOLEAN)(F1248_9039(Current, loc2) != tc1)) {
									loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
								} else {
									loc2++;
									loc1++;
								}
							}
							if (loc9) {
								Result = (EIF_INTEGER_32) loc6;
								loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
							} else {
								loc6++;
							}
						}
					}
				} else {
					loc7 = F1248_9033(Current, arg2);
					loc12 = arg1;
					loc12 = RTRV(eif_new_type(1247, 0x01),loc12);
					if (EIF_TEST(loc12)) {
						loc3 = *(EIF_INTEGER_32 *)(loc12+ _LNGOFF_1_1_0_3_);
						loc6 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc6 > loc8)) break;
							loc2 = (EIF_INTEGER_32) loc7;
							loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							for (;;) {
								if ((EIF_BOOLEAN) (loc1 > loc3)) break;
								loc4 = F1248_9029(Current, loc2);
								ti4_1 = RTOSCF(1798,F165_1798, (RTCV(RTOSCF(871,F65_871, (Current)))));
								if ((EIF_BOOLEAN) (loc4 > ti4_1)) {
									loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								}
								loc5 = F1248_9029(loc12, loc1);
								ti4_1 = RTOSCF(1798,F165_1798, (RTCV(RTOSCF(871,F65_871, (Current)))));
								if ((EIF_BOOLEAN) (loc5 > ti4_1)) {
									loc5 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								}
								if ((EIF_BOOLEAN)(loc4 != loc5)) {
									loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
								} else {
									ti4_1 = F1248_9031(Current, loc2);
									loc2 = (EIF_INTEGER_32) ti4_1;
									ti4_1 = F1248_9031(loc12, loc1);
									loc1 = (EIF_INTEGER_32) ti4_1;
								}
							}
							if (loc9) {
								Result = (EIF_INTEGER_32) loc6;
								loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
							} else {
								ti4_1 = F1248_9031(Current, loc7);
								loc7 = (EIF_INTEGER_32) ti4_1;
								loc6++;
							}
						}
					} else {
						loc3 = (EIF_INTEGER_32) loc10;
						loc6 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc6 > loc8)) break;
							loc2 = (EIF_INTEGER_32) loc7;
							loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
							loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
							for (;;) {
								if ((EIF_BOOLEAN) (loc1 > loc3)) break;
								loc4 = F1248_9029(Current, loc2);
								ti4_1 = RTOSCF(1798,F165_1798, (RTCV(RTOSCF(871,F65_871, (Current)))));
								if ((EIF_BOOLEAN) (loc4 > ti4_1)) {
									loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
								}
								tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(RTCW(arg1))-676])(arg1, loc1));
								ti4_1 = (EIF_INTEGER_32) (tc1);
								if ((EIF_BOOLEAN)(loc4 != ti4_1)) {
									loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
									loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
								} else {
									ti4_1 = F1248_9031(Current, loc2);
									loc2 = (EIF_INTEGER_32) ti4_1;
									loc1++;
								}
							}
							if (loc9) {
								Result = (EIF_INTEGER_32) loc6;
								loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc8 + ((EIF_INTEGER_32) 1L));
							} else {
								ti4_1 = F1248_9031(Current, loc7);
								loc7 = (EIF_INTEGER_32) ti4_1;
								loc6++;
							}
						}
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {UC_STRING}.string */
EIF_REFERENCE F1248_8947 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	Result = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F913_5751(RTCW(Result), loc2);
	if ((EIF_BOOLEAN)(loc2 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			tc1 = F1248_9039(Current, loc1);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, tc1);
			loc1++;
		}
	} else {
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc3 = F1248_9029(Current, loc1);
			ti4_1 = RTOSCF(1798,F165_1798, (RTCV(RTOSCF(871,F65_871, (Current)))));
			if ((EIF_BOOLEAN) (loc3 <= ti4_1)) {
				tr1 = RTOSCF(4093,F794_4093, (Current));
				tc1 = F937_6079(RTCW(tr1), loc3);
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, tc1);
			} else {
				(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, (EIF_CHARACTER_8) '\000');
			}
			ti4_1 = F1248_9031(Current, loc1);
			loc1 = (EIF_INTEGER_32) ti4_1;
		}
	}
	RTLE;
	return Result;
}

/* {UC_STRING}.plus */
EIF_REFERENCE F1248_8948 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNSMART(Dftype(Current));
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	tr1 = RTOSCF(940,F68_940, (Current));
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O4496[Dtype(arg1)-912]);
	ti4_2 = F938_6119(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L), ti4_2);
	F1248_8927(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ti4_2));
	F1248_8984(RTCW(Result), Current);
	F1248_8984(RTCW(Result), arg1);
	RTLE;
	return Result;
}

/* {UC_STRING}.prefixed_string */
EIF_REFERENCE F1248_8949 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	Result = RTLNSMART(Dftype(Current));
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	tr1 = RTOSCF(940,F68_940, (Current));
	ti4_2 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
	ti4_2 = F938_6119(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L), ti4_2);
	F1248_8927(RTCW(Result), (EIF_INTEGER_32) (ti4_1 + ti4_2));
	F1248_8984(RTCW(Result), arg1);
	F1248_8984(RTCW(Result), Current);
	RTLE;
	return Result;
}

/* {UC_STRING}.index_of_item_code */
EIF_INTEGER_32 F1248_8951 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN)(loc3 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		if ((EIF_BOOLEAN) (arg1 > ((EIF_INTEGER_32) 127L))) {
			RTLE;
			return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		} else {
			loc1 = (EIF_INTEGER_32) arg2;
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc3)) break;
				tc1 = F1248_9039(Current, loc1);
				ti4_1 = (EIF_INTEGER_32) (tc1);
				if ((EIF_BOOLEAN)(ti4_1 == arg1)) {
					Result = (EIF_INTEGER_32) loc1;
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
				} else {
					loc1++;
				}
			}
		}
	} else {
		if ((EIF_BOOLEAN) (arg2 <= loc3)) {
			loc2 = F1248_9033(Current, arg2);
			loc1 = (EIF_INTEGER_32) arg2;
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc3)) break;
				if ((EIF_BOOLEAN)(F1248_9029(Current, loc2) == arg1)) {
					Result = (EIF_INTEGER_32) loc1;
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
				} else {
					ti4_1 = F1248_9031(Current, loc2);
					loc2 = (EIF_INTEGER_32) ti4_1;
					loc1++;
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {UC_STRING}.index_of */
EIF_INTEGER_32 F1248_8952 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN)(loc3 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		loc1 = (EIF_INTEGER_32) arg2;
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc3)) break;
			if ((EIF_BOOLEAN)(F1248_9039(Current, loc1) == arg1)) {
				Result = (EIF_INTEGER_32) loc1;
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
			} else {
				loc1++;
			}
		}
	} else {
		if ((EIF_BOOLEAN)(arg1 == (EIF_CHARACTER_8) '\000')) {
			if ((EIF_BOOLEAN) (arg2 <= loc3)) {
				loc4 = RTOSCF(1798,F165_1798, (RTCV(RTOSCF(871,F65_871, (Current)))));
				loc2 = F1248_9033(Current, arg2);
				loc1 = (EIF_INTEGER_32) arg2;
				for (;;) {
					if ((EIF_BOOLEAN) (loc1 > loc3)) break;
					loc5 = F1248_9029(Current, loc2);
					if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc5 == ((EIF_INTEGER_32) 0L)) || (EIF_BOOLEAN) (loc5 > loc4))) {
						Result = (EIF_INTEGER_32) loc1;
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 1L));
					} else {
						ti4_1 = F1248_9031(Current, loc2);
						loc2 = (EIF_INTEGER_32) ti4_1;
						loc1++;
					}
				}
			}
		} else {
			ti4_1 = (EIF_INTEGER_32) (arg1);
			Result = F1248_8951(Current, ti4_1, arg2);
		}
	}
	RTLE;
	return Result;
}

/* {UC_STRING}.hash_code */
EIF_INTEGER_32 F1248_8953 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc4 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	if ((EIF_BOOLEAN)(loc2 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		Result = F907_5463(Current);
	} else {
		loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc3 = F1248_9029(Current, loc1);
			Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 5L) * Result) + loc3);
			ti4_1 = RTOSCF(1798,F165_1798, (RTCV(RTOSCF(871,F65_871, (Current)))));
			if ((EIF_BOOLEAN) (loc3 > ti4_1)) {
				loc4 = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
			}
			ti4_1 = F1248_9031(Current, loc1);
			loc1 = (EIF_INTEGER_32) ti4_1;
		}
		if (loc4) {
			tr1 = F1248_8947(Current);
			Result = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R3362[Dtype(RTCW(tr1))-795])(tr1);
		}
	}
	if ((EIF_BOOLEAN) (Result < ((EIF_INTEGER_32) 0L))) {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) -(EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) 1L));
	}
	RTLE;
	return Result;
}

/* {UC_STRING}.new_empty_string */
EIF_REFERENCE F1248_8954 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNSMART(Dftype(Current));
	F1248_8927(RTCW(tr1), arg1);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {UC_STRING}.count */
EIF_INTEGER_32 F1248_8958 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
}


/* {UC_STRING}.byte_capacity */
EIF_INTEGER_32 F1248_8960 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) F913_5772(Current);
}

/* {UC_STRING}.has */
EIF_BOOLEAN F1248_8963 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F1248_8952(Current, arg1, ((EIF_INTEGER_32) 1L));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {UC_STRING}.is_equal */
EIF_BOOLEAN F1248_8968 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		tr1 = RTOSCF(5994,F932_5994, (Current));
		tb2 = F16_120(RTCW(tr1), Current, arg1);
		if (tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_3_);
			tb1 = (EIF_BOOLEAN)(ti4_1 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
		}
		if (tb1) {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				tc1 = F1248_9039(RTCW(arg1), loc1);
				if ((EIF_BOOLEAN)(F1248_9039(Current, loc1) != tc1)) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				} else {
					loc1++;
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {UC_STRING}.is_less */
EIF_BOOLEAN F1248_8969 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	ti4_1 = F1248_8973(Current, arg1);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) -1L));
	RTLE;
	return Result;
}

/* {UC_STRING}.same_string */
EIF_BOOLEAN F1248_8970 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O4496[Dtype(arg1)-912]);
		if ((EIF_BOOLEAN)(ti4_1 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))) {
			ti4_1 = F1248_8946(Current, arg1, ((EIF_INTEGER_32) 1L));
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L));
		}
	}
	RTLE;
	return Result;
}

/* {UC_STRING}.same_string_general */
EIF_BOOLEAN F1248_8971 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_NATURAL_32 loc3 = (EIF_NATURAL_32) 0;
	EIF_NATURAL_32 loc4 = (EIF_NATURAL_32) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4297[Dtype(RTCW(arg1))-910])(arg1);
		if ((EIF_BOOLEAN)(ti4_1 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))) {
			loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				loc3 = F1248_9055(Current, loc1);
				ti4_1 = RTOSCF(1798,F165_1798, (RTCV(RTOSCF(871,F65_871, (Current)))));
				tu4_1 = (EIF_NATURAL_32) ti4_1;
				if ((EIF_BOOLEAN) (loc3 > tu4_1)) {
					loc3 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
				}
				loc4 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4260[Dtype(RTCW(arg1))-910])(arg1, loc1);
				ti4_1 = RTOSCF(1798,F165_1798, (RTCV(RTOSCF(871,F65_871, (Current)))));
				tu4_1 = (EIF_NATURAL_32) ti4_1;
				if ((EIF_BOOLEAN) (loc4 > tu4_1)) {
					loc4 = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L);
				}
				if ((EIF_BOOLEAN)(loc3 != loc4)) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc1 = (EIF_INTEGER_32) loc2;
				}
				loc1++;
			}
		}
	}
	RTLE;
	return Result;
}

/* {UC_STRING}.same_unicode_string */
EIF_BOOLEAN F1248_8972 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R4297[Dtype(RTCW(arg1))-910])(arg1);
		if ((EIF_BOOLEAN)(ti4_1 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))) {
			ti4_1 = F1248_8945(Current, arg1, ((EIF_INTEGER_32) 1L));
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 1L));
		}
	}
	RTLE;
	return Result;
}

/* {UC_STRING}.three_way_comparison */
EIF_INTEGER_32 F1248_8973 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc5 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc6 = (EIF_CHARACTER_8) 0;
	EIF_BOOLEAN loc7 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tb1 = '\0';
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		tr1 = RTOSCF(5994,F932_5994, (Current));
		tb2 = F16_120(RTCW(tr1), Current, arg1);
		tb1 = tb2;
	}
	if (tb1) {
		loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
		loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_3_);
		if ((EIF_BOOLEAN) (loc3 < loc4)) {
			loc2 = (EIF_INTEGER_32) loc3;
		} else {
			loc2 = (EIF_INTEGER_32) loc4;
		}
		loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN) (loc1 > loc2)) break;
			loc5 = F1248_9039(Current, loc1);
			loc6 = F1248_9039(RTCW(arg1), loc1);
			if ((EIF_BOOLEAN)(loc5 == loc6)) {
				loc1++;
			} else {
				if ((EIF_BOOLEAN) (loc5 < loc6)) {
					loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				} else {
					loc7 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
				}
			}
		}
		if ((EIF_BOOLEAN) !loc7) {
			if ((EIF_BOOLEAN) (loc3 < loc4)) {
				RTLE;
				return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
			} else {
				if ((EIF_BOOLEAN)(loc3 != loc4)) {
					RTLE;
					return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {UC_STRING}.three_way_unicode_comparison */
EIF_INTEGER_32 F1248_8974 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc5 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 loc6 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc8 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc9 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc10);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == Current)) {
		RTLE;
		return (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	} else {
		tb1 = '\0';
		tr1 = RTOSCF(5994,F932_5994, (Current));
		tb2 = F16_120(RTCW(tr1), Current, arg1);
		if (tb2) {
			loc10 = arg1;
			loc10 = RTRV(eif_new_type(1247, 0x01),loc10);
			tb1 = EIF_TEST(loc10);
		}
		if (tb1) {
			loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
			loc4 = *(EIF_INTEGER_32 *)(loc10+ _LNGOFF_1_1_0_3_);
			if ((EIF_BOOLEAN) (loc3 < loc4)) {
				loc2 = (EIF_INTEGER_32) loc3;
			} else {
				loc2 = (EIF_INTEGER_32) loc4;
			}
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				loc5 = F1248_9039(Current, loc1);
				loc6 = F1248_9039(loc10, loc1);
				if ((EIF_BOOLEAN)(loc5 == loc6)) {
					loc1++;
				} else {
					if ((EIF_BOOLEAN) (loc5 < loc6)) {
						loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					} else {
						loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					}
				}
			}
			if ((EIF_BOOLEAN) !loc9) {
				if ((EIF_BOOLEAN) (loc3 < loc4)) {
					RTLE;
					return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				} else {
					if ((EIF_BOOLEAN)(loc3 != loc4)) {
						RTLE;
						return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					}
				}
			}
		} else {
			loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
			loc4 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
			if ((EIF_BOOLEAN) (loc3 < loc4)) {
				loc2 = (EIF_INTEGER_32) loc3;
			} else {
				loc2 = (EIF_INTEGER_32) loc4;
			}
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN) (loc1 > loc2)) break;
				loc7 = F1248_8941(Current, loc1);
				loc8 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4472[Dtype(RTCW(arg1))-914])(arg1, loc1);
				if ((EIF_BOOLEAN)(loc7 == loc8)) {
					loc1++;
				} else {
					if ((EIF_BOOLEAN) (loc7 < loc8)) {
						loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					} else {
						loc9 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
						Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
						loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
					}
				}
			}
			if ((EIF_BOOLEAN) !loc9) {
				if ((EIF_BOOLEAN) (loc3 < loc4)) {
					RTLE;
					return (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
				} else {
					if ((EIF_BOOLEAN)(loc3 != loc4)) {
						RTLE;
						return (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
					}
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {UC_STRING}.put_item_code */
void F1248_8976 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc6 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		loc1 = (EIF_INTEGER_32) arg2;
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		loc1 = F1248_9033(Current, arg2);
		loc6 = F1248_9039(Current, loc1);
		tr1 = RTOSCF(940,F68_940, (Current));
		loc3 = F938_6117(RTCW(tr1), loc6);
	}
	tr1 = RTOSCF(940,F68_940, (Current));
	loc4 = F938_6123(RTCW(tr1), arg1);
	if ((EIF_BOOLEAN)(loc4 == loc3)) {
	} else {
		if ((EIF_BOOLEAN) (loc4 < loc3)) {
			F1248_9043(Current, (EIF_INTEGER_32) (loc1 + loc3), (EIF_INTEGER_32) (loc3 - loc4));
		} else {
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - loc3);
			loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + loc2);
			if ((EIF_BOOLEAN) (loc5 > F1248_8960(Current))) {
				F1248_9041(Current, loc5);
			}
			F1248_9042(Current, (EIF_INTEGER_32) (loc1 + loc3), loc2);
		}
	}
	F1248_9046(Current, arg1, loc4, loc1);
	RTLE;
}

/* {UC_STRING}.put */
void F1248_8977 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
		loc1 = (EIF_INTEGER_32) arg2;
		loc4 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		loc1 = F1248_9033(Current, arg2);
		loc3 = F1248_9039(Current, loc1);
		tr1 = RTOSCF(940,F68_940, (Current));
		loc4 = F938_6117(RTCW(tr1), loc3);
	}
	tr1 = RTOSCF(940,F68_940, (Current));
	loc5 = F938_6120(RTCW(tr1), arg1);
	if ((EIF_BOOLEAN)(loc5 == loc4)) {
	} else {
		if ((EIF_BOOLEAN) (loc5 < loc4)) {
			F1248_9043(Current, (EIF_INTEGER_32) (loc1 + loc4), (EIF_INTEGER_32) (loc4 - loc5));
		} else {
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 - loc4);
			loc6 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
			loc6 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc6 + loc2);
			if ((EIF_BOOLEAN) (loc6 > F1248_8960(Current))) {
				F1248_9041(Current, loc6);
			}
			F1248_9042(Current, (EIF_INTEGER_32) (loc1 + loc4), loc2);
		}
	}
	F1248_9047(Current, arg1, loc5, loc1);
	RTLE;
}

/* {UC_STRING}.append_item_code */
void F1248_8982 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(940,F68_940, (Current));
	loc2 = F938_6123(RTCW(tr1), arg1);
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + loc2);
	if ((EIF_BOOLEAN) (loc3 > F1248_8960(Current))) {
		F1248_9041(Current, loc3);
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) loc3;
	F1248_9045(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) + ((EIF_INTEGER_32) 1L)));
	F1248_9046(Current, arg1, loc2, loc1);
	RTLE;
}

/* {UC_STRING}.append_character */
void F1248_8983 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= (EIF_CHARACTER_8) '')) {
		loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		tr1 = RTOSCF(940,F68_940, (Current));
		loc2 = F938_6120(RTCW(tr1), arg1);
	}
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L));
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	loc3 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc3 + loc2);
	if ((EIF_BOOLEAN) (loc3 > F1248_8960(Current))) {
		F1248_9041(Current, loc3);
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) loc3;
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 1L))) {
		loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
		loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + ((EIF_INTEGER_32) 1L));
		F1248_9045(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
		F915_5851(Current, arg1, loc1);
		F1248_9045(Current, loc4);
	} else {
		F1248_9045(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) + ((EIF_INTEGER_32) 1L)));
		F1248_9047(Current, arg1, loc2, loc1);
	}
	RTLE;
}

/* {UC_STRING}.append_string */
void F1248_8984 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		F1248_8986(Current, arg1);
	}
	RTLE;
}

/* {UC_STRING}.put_string */
void F1248_8985 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1248_8986(Current, arg1);
}

/* {UC_STRING}.append */
void F1248_8986 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_BOOLEAN loc6 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLR(4,loc7);
	RTLR(5,loc8);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(5994,F932_5994, (Current));
	tr2 = RTOSCF(9049,F1248_9049, (Current));
	tb1 = F16_120(RTCW(tr1), arg1, tr2);
	if (tb1) {
		tr1 = RTOSCF(940,F68_940, (Current));
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O4496[Dtype(arg1)-912]);
		loc1 = F938_6119(RTCW(tr1), arg1, ((EIF_INTEGER_32) 1L), ti4_1);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O4496[Dtype(arg1)-912]);
		if ((EIF_BOOLEAN)(loc1 == ti4_1)) {
			loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
			loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + loc1);
			loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
			loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + loc1);
			F1248_9045(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
			F915_5913(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
			loc6 = (EIF_BOOLEAN) EIF_TEST(c_check_assert((EIF_BOOLEAN) 0));
			F915_5864(Current, arg1);
			tb1 = (EIF_BOOLEAN) EIF_TEST(c_check_assert(loc6));
			loc6 = (EIF_BOOLEAN) tb1;
			ti4_1 = F1248_8960(Current);
			F1248_9045(Current, ti4_1);
			ti4_1 = F1248_8960(Current);
			F915_5913(Current, ti4_1);
			F1248_9045(Current, loc5);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) loc4;
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O4496[Dtype(arg1)-912]);
			F1248_8987(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	} else {
		loc7 = arg1;
		loc7 = RTRV(eif_new_type(1247, 0x01),loc7);
		if (EIF_TEST(loc7)) {
			tb1 = '\01';
			loc8 = arg1;
			loc8 = RTRV(eif_new_type(1248, 0x01),loc8);
			if (!(EIF_TEST(loc8))) {
				tr1 = RTOSCF(5994,F932_5994, (Current));
				tr2 = RTOSCF(9050,F1248_9050, (Current));
				tb2 = F16_120(RTCW(tr1), loc7, tr2);
				tb1 = tb2;
			}
			if (tb1) {
				if ((EIF_BOOLEAN)(loc7 == Current)) {
					loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
					loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * loc4);
					loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
					loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (((EIF_INTEGER_32) 2L) * loc5);
					F1248_9045(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
					F915_5913(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
					loc6 = (EIF_BOOLEAN) EIF_TEST(c_check_assert((EIF_BOOLEAN) 0));
					F915_5864(Current, arg1);
					tb1 = (EIF_BOOLEAN) EIF_TEST(c_check_assert(loc6));
					loc6 = (EIF_BOOLEAN) tb1;
					ti4_1 = F1248_8960(Current);
					F1248_9045(Current, ti4_1);
					ti4_1 = F1248_8960(Current);
					F915_5913(Current, ti4_1);
					F1248_9045(Current, loc5);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) loc4;
				} else {
					loc3 = *(EIF_INTEGER_32 *)(loc7+ _LNGOFF_1_1_0_2_);
					loc2 = *(EIF_INTEGER_32 *)(loc7+ _LNGOFF_1_1_0_3_);
					loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
					loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + loc2);
					loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
					loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + loc3);
					F1248_9045(loc7, loc2);
					F1248_9045(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
					F915_5913(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
					loc6 = (EIF_BOOLEAN) EIF_TEST(c_check_assert((EIF_BOOLEAN) 0));
					F915_5864(Current, arg1);
					tb1 = (EIF_BOOLEAN) EIF_TEST(c_check_assert(loc6));
					loc6 = (EIF_BOOLEAN) tb1;
					ti4_1 = F1248_8960(Current);
					F1248_9045(Current, ti4_1);
					ti4_1 = F1248_8960(Current);
					F915_5913(Current, ti4_1);
					F1248_9045(Current, loc5);
					F1248_9045(loc7, loc3);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) loc4;
				}
			} else {
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O4496[Dtype(arg1)-912]);
				F1248_8987(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
			}
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O4496[Dtype(arg1)-912]);
			F1248_8987(Current, arg1, ((EIF_INTEGER_32) 1L), ti4_1);
		}
	}
	RTLE;
}

/* {UC_STRING}.gobo_append_substring */
void F1248_8987 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc5);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L));
	if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
		if ((EIF_BOOLEAN)(arg1 == Current)) {
			loc5 = F1248_9012(Current);
		} else {
			loc5 = (EIF_REFERENCE) arg1;
		}
		tr1 = RTOSCF(940,F68_940, (Current));
		loc3 = F938_6119(RTCW(tr1), loc5, arg2, arg3);
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
		loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc2 + ((EIF_INTEGER_32) 1L));
		loc4 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
		loc4 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 + loc3);
		if ((EIF_BOOLEAN) (loc4 > F1248_8960(Current))) {
			F1248_9041(Current, loc4);
		}
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) loc4;
		F1248_9045(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) + loc1));
		F1248_9048(Current, loc5, arg2, arg3, loc3, loc2);
	}
	RTLE;
}

/* {UC_STRING}.keep_head */
void F1248_9004 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 0L))) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		F1248_9045(Current, ((EIF_INTEGER_32) 0L));
	} else {
		if ((EIF_BOOLEAN) (arg1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))) {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) arg1;
			} else {
				ti4_1 = F1248_9033(Current, (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)));
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L));
			}
			F1248_9045(Current, arg1);
		}
	}
	RTLE;
}

/* {UC_STRING}.keep_tail */
void F1248_9005 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 0L))) {
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
		F1248_9045(Current, ((EIF_INTEGER_32) 0L));
	} else {
		if ((EIF_BOOLEAN) (arg1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))) {
			if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
				loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - arg1);
			} else {
				loc1 = F1248_9033(Current, (EIF_INTEGER_32) ((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) - arg1) + ((EIF_INTEGER_32) 1L)));
				loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc1 - ((EIF_INTEGER_32) 1L));
			}
			F1248_9043(Current, (EIF_INTEGER_32) (loc1 + ((EIF_INTEGER_32) 1L)), loc1);
			F1248_9045(Current, arg1);
		}
	}
	RTLE;
}

/* {UC_STRING}.remove_head */
void F1248_9006 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))) {
		F1248_9010(Current);
	} else {
		if ((EIF_BOOLEAN)(arg1 != ((EIF_INTEGER_32) 0L))) {
			F1248_9005(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) - arg1));
		}
	}
	RTLE;
}

/* {UC_STRING}.remove_tail */
void F1248_9007 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))) {
		F1248_9010(Current);
	} else {
		if ((EIF_BOOLEAN)(arg1 != ((EIF_INTEGER_32) 0L))) {
			F1248_9004(Current, (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) - arg1));
		}
	}
	RTLE;
}

/* {UC_STRING}.wipe_out */
void F1248_9010 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	F1248_9045(Current, ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {UC_STRING}.copy */
void F1248_9011 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		loc1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_2_);
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_1_1_0_3_);
		F1248_9045(RTCW(arg1), ti4_1);
		F913_5791(Current, arg1);
		F1248_9045(Current, loc1);
		F1248_9045(RTCW(arg1), loc1);
	}
	RTLE;
}

/* {UC_STRING}.cloned_string */
EIF_REFERENCE F1248_9012 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1_14(Current);
}

/* {UC_STRING}.as_lower */
EIF_REFERENCE F1248_9015 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F1248_9012(Current);
	F1248_9017(RTCW(Result));
	RTLE;
	return Result;
}

/* {UC_STRING}.to_lower */
void F1248_9017 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc7 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc6 = F1248_9029(Current, loc1);
		tr1 = RTOSCF(2170,F240_2170, (Current));
		loc7 = F965_6391(RTCW(tr1), loc6);
		if ((EIF_BOOLEAN)(loc7 != loc6)) {
			tr1 = RTOSCF(940,F68_940, (Current));
			loc3 = F938_6123(RTCW(tr1), loc6);
			tr1 = RTOSCF(940,F68_940, (Current));
			loc4 = F938_6123(RTCW(tr1), loc7);
			if ((EIF_BOOLEAN)(loc4 == loc3)) {
			} else {
				if ((EIF_BOOLEAN) (loc4 < loc3)) {
					F1248_9043(Current, (EIF_INTEGER_32) (loc1 + loc3), (EIF_INTEGER_32) (loc3 - loc4));
				} else {
					loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc4 - loc3);
					loc5 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
					loc5 = (EIF_INTEGER_32) (EIF_INTEGER_32) (loc5 + loc2);
					if ((EIF_BOOLEAN) (loc5 > F1248_8960(Current))) {
						F1248_9041(Current, loc5);
					}
					F1248_9042(Current, (EIF_INTEGER_32) (loc1 + loc3), loc2);
				}
			}
			F1248_9046(Current, loc7, loc4, loc1);
		}
		ti4_1 = F1248_9031(Current, loc1);
		loc1 = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
}

/* {UC_STRING}.to_utf8 */
EIF_REFERENCE F1248_9019 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	Result = RTLNS(eif_new_type(914, 0x01).id, 914, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F913_5751(RTCW(Result), loc2);
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tc1 = F1248_9039(Current, loc1);
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_CHARACTER_8)) R4524[Dtype(RTCW(Result))-914])(Result, tc1);
		loc1++;
	}
	RTLE;
	return Result;
}

/* {UC_STRING}.as_string */
EIF_REFERENCE F1248_9024 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F1248_9019(Current);
}

/* {UC_STRING}.eol */

EIF_REFERENCE F1248_9026 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (9026,RTMS_EX_H("\012",1,10));
}

/* {UC_STRING}.item_code_at_byte_index */
EIF_INTEGER_32 F1248_9029 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc3 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) arg1;
	loc3 = F1248_9039(Current, loc1);
	tr1 = RTOSCF(940,F68_940, (Current));
	Result = F938_6111(RTCW(tr1), loc3);
	tr1 = RTOSCF(940,F68_940, (Current));
	loc2 = F938_6117(RTCW(tr1), loc3);
	loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + loc2) - ((EIF_INTEGER_32) 1L));
	loc1++;
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		loc3 = F1248_9039(Current, loc1);
		tr1 = RTOSCF(940,F68_940, (Current));
		ti4_1 = F938_6112(RTCW(tr1), loc3);
		Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result * ((EIF_INTEGER_32) 64L)) + ti4_1);
		loc1++;
	}
	RTLE;
	return Result;
}

/* {UC_STRING}.character_item_at_byte_index */
EIF_CHARACTER_8 F1248_9030 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc1 = F1248_9039(Current, arg1);
	tr1 = RTOSCF(940,F68_940, (Current));
	ti4_1 = F938_6117(RTCW(tr1), loc1);
	switch (ti4_1) {
		case 1L:
			Result = (EIF_CHARACTER_8) loc1;
			break;
		case 2L:
			tr1 = RTOSCF(940,F68_940, (Current));
			loc2 = F938_6111(RTCW(tr1), loc1);
			loc1 = F1248_9039(Current, (EIF_INTEGER_32) (arg1 + ((EIF_INTEGER_32) 1L)));
			tr1 = RTOSCF(940,F68_940, (Current));
			ti4_1 = F938_6112(RTCW(tr1), loc1);
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 * ((EIF_INTEGER_32) 64L)) + ti4_1);
			ti4_1 = RTOSCF(1798,F165_1798, (RTCV(RTOSCF(871,F65_871, (Current)))));
			if ((EIF_BOOLEAN) (loc2 <= ti4_1)) {
				tr1 = RTOSCF(4093,F794_4093, (Current));
				Result = F937_6079(RTCW(tr1), loc2);
			} else {
				Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
			}
			break;
		default:
			loc2 = F1248_9029(Current, arg1);
			ti4_1 = RTOSCF(1798,F165_1798, (RTCV(RTOSCF(871,F65_871, (Current)))));
			if ((EIF_BOOLEAN) (loc2 <= ti4_1)) {
				tr1 = RTOSCF(4093,F794_4093, (Current));
				Result = F937_6079(RTCW(tr1), loc2);
			} else {
				Result = (EIF_CHARACTER_8) (EIF_CHARACTER_8) '\000';
			}
			break;
	}
	RTLE;
	return Result;
}

/* {UC_STRING}.next_byte_index */
EIF_INTEGER_32 F1248_9031 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(940,F68_940, (Current));
	tc1 = F1248_9039(Current, arg1);
	Result = F938_6117(RTCW(tr1), tc1);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg1 + Result);
	RTLE;
	return Result;
}

/* {UC_STRING}.shifted_byte_index */
EIF_INTEGER_32 F1248_9032 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_CHARACTER_8 tc1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	Result = (EIF_INTEGER_32) arg1;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > arg2)) break;
		tr1 = RTOSCF(940,F68_940, (Current));
		tc1 = F1248_9039(Current, Result);
		ti4_1 = F938_6117(RTCW(tr1), tc1);
		Result += ti4_1;
		if ((EIF_BOOLEAN) (Result > *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_))) {
			loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) (arg2 + ((EIF_INTEGER_32) 1L));
		} else {
			loc1++;
		}
	}
	RTLE;
	return Result;
}

/* {UC_STRING}.byte_index */
EIF_INTEGER_32 F1248_9033 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_) == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_))) {
		Result = (EIF_INTEGER_32) arg1;
	} else {
		if ((EIF_BOOLEAN) (arg1 < *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_4_))) {
			loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		} else {
			loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_4_);
			Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_5_);
		}
		for (;;) {
			if ((EIF_BOOLEAN)(loc1 == arg1)) break;
			loc2 = F1248_9039(Current, Result);
			tr1 = RTOSCF(940,F68_940, (Current));
			ti4_1 = F938_6117(RTCW(tr1), loc2);
			Result += ti4_1;
			loc1++;
		}
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_4_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_5_) = (EIF_INTEGER_32) Result;
	RTLE;
	return Result;
}

/* {UC_STRING}.reset_byte_index_cache */
void F1248_9037 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_4_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_5_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {UC_STRING}.byte_item */
EIF_CHARACTER_8 F1248_9039 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	F1248_9045(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
	Result = F915_5830(Current, arg1);
	F1248_9045(Current, loc1);
	RTLE;
	return Result;
}

/* {UC_STRING}.put_byte */
void F1248_9040 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	F1248_9045(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
	F915_5851(Current, arg1, arg2);
	F1248_9045(Current, loc1);
	RTLE;
}

/* {UC_STRING}.resize_byte_storage */
void F1248_9041 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 > F1248_8960(Current))) {
		F915_5896(Current, arg1);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
		F1248_9045(Current, arg1);
		F915_5913(Current, arg1);
		F1248_9045(Current, loc1);
	}
	RTLE;
}

/* {UC_STRING}.move_bytes_right */
void F1248_9042 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_5_) > arg1)) {
		F1248_9037(Current);
	}
	loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	loc2 = (EIF_INTEGER_32) arg1;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_)) += arg2;
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	F1248_9045(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 < loc2)) break;
		tc1 = F915_5830(Current, loc1);
		F915_5851(Current, tc1, (EIF_INTEGER_32) (loc1 + arg2));
		loc1--;
	}
	F1248_9045(Current, loc3);
	RTLE;
}

/* {UC_STRING}.move_bytes_left */
void F1248_9043 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_5_) > (EIF_INTEGER_32) (arg1 - arg2))) {
		F1248_9037(Current);
	}
	loc1 = (EIF_INTEGER_32) arg1;
	loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_);
	loc3 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_);
	F1248_9045(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		tc1 = F915_5830(Current, loc1);
		F915_5851(Current, tc1, (EIF_INTEGER_32) (loc1 - arg2));
		loc1++;
	}
	F1248_9045(Current, loc3);
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_3_)) -= arg2;
	RTLE;
}

/* {UC_STRING}.set_count */
void F1248_9045 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_4_) > arg1)) {
		F1248_9037(Current);
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) arg1;
	RTLE;
}

/* {UC_STRING}.put_code_at_byte_index */
void F1248_9046 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc2 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	loc3 = (EIF_INTEGER_32) arg1;
	loc1 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 + arg2) - ((EIF_INTEGER_32) 1L));
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == arg3)) break;
		tr1 = RTOSCF(4093,F794_4093, (Current));
		loc2 = F937_6079(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc3 % ((EIF_INTEGER_32) 64L)) + ((EIF_INTEGER_32) 128L)));
		F1248_9040(Current, loc2, loc1);
		loc3 /= ((EIF_INTEGER_32) 64L);
		loc1--;
	}
	switch (arg2) {
		case 1L:
			tr1 = RTOSCF(4093,F794_4093, (Current));
			loc2 = F937_6079(RTCW(tr1), loc3);
			break;
		case 2L:
			tr1 = RTOSCF(4093,F794_4093, (Current));
			loc2 = F937_6079(RTCW(tr1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 192L)));
			break;
		case 3L:
			tr1 = RTOSCF(4093,F794_4093, (Current));
			loc2 = F937_6079(RTCW(tr1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 224L)));
			break;
		case 4L:
			tr1 = RTOSCF(4093,F794_4093, (Current));
			loc2 = F937_6079(RTCW(tr1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 240L)));
			break;
		case 5L:
			tr1 = RTOSCF(4093,F794_4093, (Current));
			loc2 = F937_6079(RTCW(tr1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 248L)));
			break;
		case 6L:
			tr1 = RTOSCF(4093,F794_4093, (Current));
			loc2 = F937_6079(RTCW(tr1), (EIF_INTEGER_32) (loc3 + ((EIF_INTEGER_32) 252L)));
			break;
		default:
			RTEC(EN_WHEN);
	}
	F1248_9040(Current, loc2, arg3);
	RTLE;
}

/* {UC_STRING}.put_character_at_byte_index */
void F1248_9047 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	switch (arg2) {
		case 1L:
			F1248_9040(Current, arg1, arg3);
			break;
		case 2L:
			loc2 = (EIF_INTEGER_32) (arg1);
			tr1 = RTOSCF(4093,F794_4093, (Current));
			loc1 = F937_6079(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 / ((EIF_INTEGER_32) 64L)) + ((EIF_INTEGER_32) 192L)));
			F1248_9040(Current, loc1, arg3);
			tr1 = RTOSCF(4093,F794_4093, (Current));
			loc1 = F937_6079(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc2 % ((EIF_INTEGER_32) 64L)) + ((EIF_INTEGER_32) 128L)));
			F1248_9040(Current, loc1, (EIF_INTEGER_32) (arg3 + ((EIF_INTEGER_32) 1L)));
			break;
		default:
			ti4_1 = (EIF_INTEGER_32) (arg1);
			F1248_9046(Current, ti4_1, arg2, arg3);
			break;
	}
	RTLE;
}

/* {UC_STRING}.put_substring_at_byte_index */
void F1248_9048 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_CHARACTER_8 loc5 = (EIF_CHARACTER_8) 0;
	EIF_INTEGER_32 loc6 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(8);
	RTLR(0,loc7);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,loc8);
	RTLR(6,loc9);
	RTLR(7,loc10);
	RTLIU(8);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg4 > ((EIF_INTEGER_32) 0L))) {
		tb1 = '\0';
		loc7 = arg1;
		loc7 = RTRV(eif_new_type(914, 0x01),loc7);
		if (EIF_TEST(loc7)) {
			tr1 = RTOSCF(5994,F932_5994, (Current));
			tr2 = RTOSCF(9049,F1248_9049, (Current));
			tb2 = F16_120(RTCW(tr1), arg1, tr2);
			tb1 = tb2;
		}
		if (tb1) {
			loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (arg3 - arg2) + ((EIF_INTEGER_32) 1L));
			if ((EIF_BOOLEAN)(loc2 == arg4)) {
				loc3 = (EIF_INTEGER_32) arg5;
				loc1 = (EIF_INTEGER_32) arg2;
				for (;;) {
					if ((EIF_BOOLEAN) (loc1 > arg3)) break;
					tc1 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(loc7)-676])(loc7, loc1));
					F1248_9040(Current, tc1, loc3);
					loc3++;
					loc1++;
				}
			} else {
				loc3 = (EIF_INTEGER_32) arg5;
				loc1 = (EIF_INTEGER_32) arg2;
				for (;;) {
					if ((EIF_BOOLEAN) (loc1 > arg3)) break;
					loc5 = (eif_optimize_return = 1, *(EIF_CHARACTER_8 *)(FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE, EIF_INTEGER_32)) R3077[Dtype(loc7)-676])(loc7, loc1));
					tr1 = RTOSCF(940,F68_940, (Current));
					loc4 = F938_6120(RTCW(tr1), loc5);
					F1248_9047(Current, loc5, loc4, loc3);
					loc3 += loc4;
					loc1++;
				}
			}
		} else {
			tb1 = '\0';
			tr1 = RTOSCF(5994,F932_5994, (Current));
			tb2 = F16_120(RTCW(tr1), arg1, Current);
			if (tb2) {
				loc8 = arg1;
				loc8 = RTRV(eif_new_type(1247, 0x01),loc8);
				tb1 = EIF_TEST(loc8);
			}
			if (tb1) {
				loc3 = (EIF_INTEGER_32) arg5;
				loc1 = F1248_9033(loc8, arg2);
				loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + arg4) - ((EIF_INTEGER_32) 1L));
				for (;;) {
					if ((EIF_BOOLEAN) (loc1 > loc2)) break;
					tc1 = F1248_9039(loc8, loc1);
					F1248_9040(Current, tc1, loc3);
					loc3++;
					loc1++;
				}
			} else {
				loc9 = arg1;
				loc9 = RTRV(eif_new_type(1248, 0x01),loc9);
				if (EIF_TEST(loc9)) {
					loc3 = (EIF_INTEGER_32) arg5;
					loc1 = (RTNA((loc9, arg2)), ((EIF_INTEGER_32) 0));
					loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + arg4) - ((EIF_INTEGER_32) 1L));
					for (;;) {
						if ((EIF_BOOLEAN) (loc1 > loc2)) break;
						tc1 = (RTNA((loc9, loc1)), ((EIF_CHARACTER_8) 0));
						F1248_9040(Current, tc1, loc3);
						loc3++;
						loc1++;
					}
				} else {
					loc10 = arg1;
					loc10 = RTRV(eif_new_type(1247, 0x01),loc10);
					if (EIF_TEST(loc10)) {
						loc3 = (EIF_INTEGER_32) arg5;
						loc1 = F1248_9033(loc10, arg2);
						loc2 = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (loc1 + arg4) - ((EIF_INTEGER_32) 1L));
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 > loc2)) break;
							loc6 = F1248_9029(loc10, loc1);
							tr1 = RTOSCF(940,F68_940, (Current));
							loc4 = F938_6123(RTCW(tr1), loc6);
							F1248_9046(Current, loc6, loc4, loc3);
							loc3 += loc4;
							ti4_1 = F1248_9031(loc10, loc1);
							loc1 = (EIF_INTEGER_32) ti4_1;
						}
					} else {
						loc3 = (EIF_INTEGER_32) arg5;
						loc1 = (EIF_INTEGER_32) arg2;
						for (;;) {
							if ((EIF_BOOLEAN) (loc1 > arg3)) break;
							tu4_1 = (FUNCTION_CAST(EIF_NATURAL_32, (EIF_REFERENCE, EIF_INTEGER_32)) R4260[Dtype(RTCW(arg1))-910])(arg1, loc1);
							loc6 = (EIF_INTEGER_32) tu4_1;
							tr1 = RTOSCF(940,F68_940, (Current));
							loc4 = F938_6123(RTCW(tr1), loc6);
							F1248_9046(Current, loc6, loc4, loc3);
							loc3 += loc4;
							loc1++;
						}
					}
				}
			}
		}
	}
	RTLE;
}

/* {UC_STRING}.dummy_string */

EIF_REFERENCE F1248_9049 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (9049,RTMS_EX_H("",0,0));
}

/* {UC_STRING}.dummy_uc_string */
static EIF_REFERENCE F1248_9050_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (9050);
#define Result RTOSR(9050)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1247, 0x01).id, 1247, _OBJSIZ_1_1_0_6_0_0_0_0_);
	F1248_8929(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9050);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1248_9050 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9050,F1248_9050_body,(Current));
}

/* {UC_STRING}.old_wipe_out */
void F1248_9051 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	F915_5893(Current);
	F1248_9010(Current);
	RTLE;
}

/* {UC_STRING}.code */
EIF_NATURAL_32 F1248_9055 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = F1248_8941(Current, arg1);
	Result = (EIF_NATURAL_32) ti4_1;
	RTLE;
	return Result;
}

/* {UC_STRING}.put_code */
void F1248_9057 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) arg1;
	F1248_8976(Current, ti4_1, arg2);
	RTLE;
}

/* {UC_STRING}.append_code */
void F1248_9058 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = (EIF_INTEGER_32) arg1;
	F1248_8982(Current, ti4_1);
	RTLE;
}

void EIF_Minit404 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
