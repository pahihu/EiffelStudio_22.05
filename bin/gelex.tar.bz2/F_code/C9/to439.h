
#ifndef _C9_to439_
#define _C9_to439_

#ifdef __cplusplus
extern "C" {
#endif

extern void F248_2420(EIF_REFERENCE, EIF_INTEGER_32);
extern void F248_2421(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32);
extern void F248_2427(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit439(void);
extern char *(*R3083[])();
extern EIF_TYPE_INDEX Y2242[];
extern EIF_TYPE_INDEX *Y2242_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
