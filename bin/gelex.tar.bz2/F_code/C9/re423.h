
#ifndef _C9_re423_
#define _C9_re423_

#ifdef __cplusplus
extern "C" {
#endif

extern void F388_3034(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F388_3036(EIF_REFERENCE);
extern EIF_INTEGER_32 F388_3037(EIF_REFERENCE);
extern EIF_INTEGER_32 F388_3038(EIF_REFERENCE);
extern EIF_INTEGER_32 F388_3039(EIF_REFERENCE);
extern EIF_BOOLEAN F388_3047(EIF_REFERENCE);
extern EIF_BOOLEAN F388_3048(EIF_REFERENCE);
extern void F388_3053(EIF_REFERENCE);
extern void EIF_Minit423(void);
extern char *(*R3078[])();
extern char *(*R3079[])();

#ifdef __cplusplus
}
#endif

#endif
