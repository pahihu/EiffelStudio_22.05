
#ifndef _C9_fu417_
#define _C9_fu417_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F905_5443(EIF_REFERENCE);
extern EIF_BOOLEAN F905_5447(EIF_REFERENCE, EIF_REFERENCE);
extern void F905_5448(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit417(void);
extern void F902_5416(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F902_5409(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
