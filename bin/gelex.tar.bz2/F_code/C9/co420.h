
#ifndef _C9_co420_
#define _C9_co420_

#ifdef __cplusplus
extern "C" {
#endif

extern void F457_3121(EIF_REFERENCE);
extern void EIF_Minit420(void);
extern long O2805[];

#ifdef __cplusplus
}
#endif

#endif
