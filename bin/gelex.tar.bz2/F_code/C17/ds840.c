/*
 * Code for class DS_INDEXABLE [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds840.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_INDEXABLE}.swap */
void F1139_7438 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_CHARACTER_8 loc1 = (EIF_CHARACTER_8) 0;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	loc1 = F1146_7502(Current, arg1);
	tc1 = F1146_7502(Current, arg2);
	F1146_7524(Current, tc1, arg1);
	F1146_7524(Current, loc1, arg2);
	RTLE;
}

void EIF_Minit840 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
