
#ifndef _C17_kl810_
#define _C17_kl810_

#ifdef __cplusplus
extern "C" {
#endif

extern void F716_3743(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit810(void);

#ifdef __cplusplus
}
#endif

#endif
