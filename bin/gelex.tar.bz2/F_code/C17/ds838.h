
#ifndef _C17_ds838_
#define _C17_ds838_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1000_6729(EIF_REFERENCE);
extern EIF_BOOLEAN F1000_6731(EIF_REFERENCE);
extern void EIF_Minit838(void);
extern EIF_BOOLEAN F1146_7569(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
