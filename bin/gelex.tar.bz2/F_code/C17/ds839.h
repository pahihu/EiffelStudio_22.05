
#ifndef _C17_ds839_
#define _C17_ds839_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1115_7329(EIF_REFERENCE);
extern void EIF_Minit839(void);
extern EIF_BOOLEAN F1146_7569(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
