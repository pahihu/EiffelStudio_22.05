
#ifndef _C17_ds802_
#define _C17_ds802_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1103_7298(EIF_REFERENCE, EIF_REFERENCE);
extern void F1103_7302(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit802(void);

#ifdef __cplusplus
}
#endif

#endif
