/*
 * Code for class DS_LINKED_LIST [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds801.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_LINKED_LIST}.make */
void F1146_7496 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = F1146_7505(Current);
	F1146_7561(Current, tr1);
	RTLE;
}

/* {DS_LINKED_LIST}.item */
EIF_CHARACTER_8 F1146_7502 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc2 == arg1)) break;
		RTCT0("valid_index", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		loc1 = (EIF_REFERENCE) tr1;
		loc2++;
	}
	RTCT0("valid_index", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = *(EIF_CHARACTER_8 *)(RTCW(loc1)+ _CHROFF_1_0_);
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.first */
EIF_CHARACTER_8 F1146_7503 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTCT0("not_empty", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = *(EIF_CHARACTER_8 *)(loc1+ _CHROFF_1_0_);
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.last */
EIF_CHARACTER_8 F1146_7504 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	RTCT0("not_empty", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = *(EIF_CHARACTER_8 *)(loc1+ _CHROFF_1_0_);
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.new_cursor */
EIF_REFERENCE F1146_7505 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1040,0,0,0xFFFF};
		EIF_TYPE typres0;
		{
			EIF_TYPE l_type;
			l_type = eif_final_id(Y5580,Y5580_gen_type,Dftype(Current),1080);
			typarr0[2] = l_type.annotations | 0xFF00;
			typarr0[3] = l_type.id;
		}
		
		typres0 = eif_compound_id(Dftype(Current), typarr0);
		tr1 = RTLNS(typres0.id, 1040, _OBJSIZ_3_2_0_0_0_0_0_0_);
	}
	F1041_6808(RTCW(tr1), Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {DS_LINKED_LIST}.count */
EIF_INTEGER_32 F1146_7506 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_);
}


/* {DS_LINKED_LIST}.has */
EIF_BOOLEAN F1146_7508 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		for (;;) {
			if ((EIF_BOOLEAN)(loc1 == NULL)) break;
			tc1 = *(EIF_CHARACTER_8 *)(RTCW(loc1)+ _CHROFF_1_0_);
			tb1 = F228_2144(loc2, tc1, arg1);
			if (tb1) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_REFERENCE) NULL;
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
				loc1 = (EIF_REFERENCE) tr1;
			}
		}
	} else {
		for (;;) {
			if ((EIF_BOOLEAN)(loc1 == NULL)) break;
			tc1 = *(EIF_CHARACTER_8 *)(RTCW(loc1)+ _CHROFF_1_0_);
			if ((EIF_BOOLEAN)(tc1 == arg1)) {
				Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
				loc1 = (EIF_REFERENCE) NULL;
			} else {
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
				loc1 = (EIF_REFERENCE) tr1;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.copy */
void F1146_7518 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTCFDT;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc1);
	RTLR(5,loc3);
	RTLR(6,loc2);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		loc4 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F1146_7565(Current);
		eif_builtin_ANY_standard_copy__o_ (Current, arg1);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			tb1 = F1097_7285(Current, loc4);
		}
		if (tb1) {
			F1146_7561(Current, loc4);
		} else {
			tr1 = F1146_7505(Current);
			F1146_7561(Current, tr1);
		}
		loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			loc3 = RTLNSMART(eif_final_id(Y5753,Y5753_gen_type,dftype,1144).id);
			tc1 = *(EIF_CHARACTER_8 *)(RTCW(loc1)+ _CHROFF_1_0_);
			F150_1682(RTCW(loc3), tc1);
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc3;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			loc1 = (EIF_REFERENCE) tr1;
			for (;;) {
				if ((EIF_BOOLEAN)(loc1 == NULL)) break;
				loc2 = RTLNSMART(eif_final_id(Y5753,Y5753_gen_type,dftype,1144).id);
				tc1 = *(EIF_CHARACTER_8 *)(RTCW(loc1)+ _CHROFF_1_0_);
				F150_1682(RTCW(loc2), tc1);
				F155_1688(RTCW(loc3), loc2);
				loc3 = (EIF_REFERENCE) loc2;
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
				loc1 = (EIF_REFERENCE) tr1;
			}
			RTAR(Current, loc3);
			*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc3;
		}
	}
	RTLE;
}

/* {DS_LINKED_LIST}.is_equal */
EIF_BOOLEAN F1146_7519 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	EIF_CHARACTER_8 tc2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(Current == arg1)) {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	} else {
		tb1 = '\0';
		tr1 = RTOSCF(5994,F932_5994, (Current));
		tb2 = F16_120(RTCW(tr1), Current, arg1);
		if (tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1)+ _LNGOFF_4_0_0_0_);
			tb1 = (EIF_BOOLEAN)(ti4_1 == *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_));
		}
		if (tb1) {
			loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
			for (;;) {
				if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == NULL) || (EIF_BOOLEAN)(loc2 == NULL))) break;
				tc1 = *(EIF_CHARACTER_8 *)(RTCW(loc1)+ _CHROFF_1_0_);
				tc2 = *(EIF_CHARACTER_8 *)(RTCW(loc2)+ _CHROFF_1_0_);
				if ((EIF_BOOLEAN)(tc1 != tc2)) {
					Result = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
					loc1 = (EIF_REFERENCE) NULL;
				} else {
					tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
					loc1 = (EIF_REFERENCE) tr1;
					tr1 = *(EIF_REFERENCE *)(RTCW(loc2));
					loc2 = (EIF_REFERENCE) tr1;
				}
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.put_first */
void F1146_7520 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = RTLNSMART(eif_final_id(Y5753,Y5753_gen_type,dftype,1144).id);
		F150_1682(RTCW(loc1), arg1);
		F155_1688(RTCW(loc1), loc2);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) loc1;
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_))++;
	} else {
		tr1 = RTLNSMART(eif_final_id(Y5753,Y5753_gen_type,dftype,1144).id);
		F150_1682(RTCW(tr1), arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.put_last */
void F1146_7522 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = RTLNSMART(eif_final_id(Y5753,Y5753_gen_type,dftype,1144).id);
		F150_1682(RTCW(loc1), arg1);
		F155_1688(loc2, loc1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_))++;
	} else {
		tr1 = RTLNSMART(eif_final_id(Y5753,Y5753_gen_type,dftype,1144).id);
		F150_1682(RTCW(tr1), arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.force_last */
void F1146_7523 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = RTLNSMART(eif_final_id(Y5753,Y5753_gen_type,dftype,1144).id);
		F150_1682(RTCW(loc1), arg1);
		F155_1688(loc2, loc1);
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) loc1;
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_))++;
	} else {
		tr1 = RTLNSMART(eif_final_id(Y5753,Y5753_gen_type,dftype,1144).id);
		F150_1682(RTCW(tr1), arg1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.replace */
void F1146_7524 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	for (;;) {
		if ((EIF_BOOLEAN)(loc2 == arg2)) break;
		RTCT0("valid_index", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		loc1 = (EIF_REFERENCE) tr1;
		loc2++;
	}
	RTCT0("valid_index", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	F150_1681(RTCW(loc1), arg1);
	RTLE;
}

/* {DS_LINKED_LIST}.swap */
void F1146_7531 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc3 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_CHARACTER_8 loc6 = (EIF_CHARACTER_8) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 tc1;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc5);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != arg2)) {
		if ((EIF_BOOLEAN) (arg1 < arg2)) {
			loc1 = (EIF_INTEGER_32) arg1;
			loc2 = (EIF_INTEGER_32) arg2;
		} else {
			loc1 = (EIF_INTEGER_32) arg2;
			loc2 = (EIF_INTEGER_32) arg1;
		}
		loc4 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc3 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		for (;;) {
			if ((EIF_BOOLEAN)(loc3 == loc1)) break;
			RTCT0("valid_i", EX_CHECK);
			if ((EIF_BOOLEAN)(loc4 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc4));
			loc4 = (EIF_REFERENCE) tr1;
			loc3++;
		}
		loc5 = (EIF_REFERENCE) loc4;
		for (;;) {
			if ((EIF_BOOLEAN)(loc3 == loc2)) break;
			RTCT0("valid_j", EX_CHECK);
			if ((EIF_BOOLEAN)(loc5 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc5));
			loc5 = (EIF_REFERENCE) tr1;
			loc3++;
		}
		RTCT0("valid_i_and_j", EX_CHECK);
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc4 != NULL) && (EIF_BOOLEAN)(loc5 != NULL))) {
			RTCK0;
		} else {
			RTCF0;
		}
		loc6 = *(EIF_CHARACTER_8 *)(RTCW(loc4)+ _CHROFF_1_0_);
		tc1 = *(EIF_CHARACTER_8 *)(RTCW(loc5)+ _CHROFF_1_0_);
		F150_1681(RTCW(loc4), tc1);
		F150_1681(RTCW(loc5), loc6);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.remove_first */
void F1146_7542 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,loc2);
	RTLIU(4);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) == ((EIF_INTEGER_32) 1L))) {
		F1146_7556(Current);
	} else {
		RTCT0("two_or_more_items", EX_CHECK);
		tb1 = '\0';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc1 = tr1;
		if (EIF_TEST(loc1)) {
			tr1 = *(EIF_REFERENCE *)(loc1);
			loc2 = tr1;
			tb1 = EIF_TEST(loc2);
		}
		if (tb1) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1146_7564(Current, loc1, loc2);
		F1146_7559(Current, loc2);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_))--;
	}
	RTLE;
}

/* {DS_LINKED_LIST}.remove_last */
void F1146_7543 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) == ((EIF_INTEGER_32) 1L))) {
		F1146_7556(Current);
	} else {
		F1146_7563(Current);
		loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		loc2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_);
		for (;;) {
			if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) 2L))) break;
			RTCT0("two_or_more_items", EX_CHECK);
			if ((EIF_BOOLEAN)(loc1 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			loc1 = (EIF_REFERENCE) tr1;
			loc2--;
		}
		RTCT0("two_or_more_items", EX_CHECK);
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		F1146_7560(Current, loc1);
		(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_))--;
	}
	RTLE;
}

/* {DS_LINKED_LIST}.remove_at_cursor */
void F1146_7545 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_CHARACTER_8 tc1;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,tr1);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	tb1 = F992_6718(RTCW(arg1));
	if (tb1) {
		F1146_7542(Current);
	} else {
		tb1 = F1000_6729(RTCW(arg1));
		if (tb1) {
			F1146_7543(Current);
		} else {
			RTCT0("not_off_and_not_last", EX_CHECK);
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			loc1 = tr1;
			if (EIF_TEST(loc1)) {
				tr1 = *(EIF_REFERENCE *)(loc1);
				loc2 = tr1;
				tb1 = EIF_TEST(loc2);
			}
			if (tb1) {
				RTCK0;
			} else {
				RTCF0;
			}
			if ((EIF_BOOLEAN)(loc2 == *(EIF_REFERENCE *)(Current + _REFACS_2_))) {
				F1146_7560(Current, loc1);
			} else {
				RTCT0("before_second_to_last", EX_CHECK);
				tr1 = *(EIF_REFERENCE *)(loc2);
				loc3 = tr1;
				if (EIF_TEST(loc3)) {
					RTCK0;
				} else {
					RTCF0;
				}
				F155_1688(loc1, loc3);
			}
			tc1 = *(EIF_CHARACTER_8 *)(loc2+ _CHROFF_1_0_);
			F150_1681(loc1, tc1);
			(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_))--;
			F1146_7564(Current, loc2, loc1);
		}
	}
	RTLE;
}

/* {DS_LINKED_LIST}.wipe_out */
void F1146_7556 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1146_7565(Current);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) NULL;
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) NULL;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {DS_LINKED_LIST}.set_first_cell */
void F1146_7559 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg1;
}

/* {DS_LINKED_LIST}.set_last_cell */
void F1146_7560 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	F155_1689(RTCW(arg1));
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTLE;
}

/* {DS_LINKED_LIST}.set_internal_cursor */
void F1146_7561 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) arg1;
}

/* {DS_LINKED_LIST}.internal_cursor */
EIF_REFERENCE F1146_7562 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {DS_LINKED_LIST}.move_last_cursors_after */
void F1146_7563 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc4);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLR(5,loc2);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
	if ((EIF_BOOLEAN)(tr1 == loc4)) {
		F1041_6818(RTCW(loc1));
	}
	loc3 = (EIF_REFERENCE) loc1;
	tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
	loc1 = (EIF_REFERENCE) tr1;
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		if ((EIF_BOOLEAN)(tr1 == loc4)) {
			F1041_6818(RTCW(loc1));
			loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
			F977_6710(RTCW(loc3), loc2);
			F977_6710(RTCW(loc1), NULL);
			loc1 = (EIF_REFERENCE) loc2;
		} else {
			loc3 = (EIF_REFERENCE) loc1;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			loc1 = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
}

/* {DS_LINKED_LIST}.move_all_cursors */
void F1146_7564 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_1_);
		if ((EIF_BOOLEAN)(tr1 == arg1)) {
			F1041_6817(RTCW(loc1), arg2);
		}
		tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
		loc1 = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {DS_LINKED_LIST}.move_all_cursors_after */
void F1146_7565 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == NULL)) break;
		F1041_6818(RTCW(loc1));
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1));
		F977_6710(RTCW(loc1), NULL);
		loc1 = (EIF_REFERENCE) loc2;
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_item */
EIF_CHARACTER_8 F1146_7566 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	RTCT0("not_off", EX_CHECK);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = *(EIF_CHARACTER_8 *)(loc1+ _CHROFF_1_0_);
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.cursor_index */
EIF_INTEGER_32 F1146_7567 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_1_);
	if (tb1) {
		RTLE;
		return (EIF_INTEGER_32) (EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) + ((EIF_INTEGER_32) 1L));
	} else {
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_0_);
		if ((EIF_BOOLEAN) !tb1) {
			loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			loc1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
			for (;;) {
				if ((EIF_BOOLEAN)(loc1 == loc2)) break;
				RTCT0("valid_cursor", EX_CHECK);
				if ((EIF_BOOLEAN)(loc1 != NULL)) {
					RTCK0;
				} else {
					RTCF0;
				}
				tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
				loc1 = (EIF_REFERENCE) tr1;
				Result++;
			}
		}
	}
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.cursor_is_first */
EIF_BOOLEAN F1146_7568 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && (EIF_BOOLEAN)(loc1 == *(EIF_REFERENCE *)(Current + _REFACS_1_)));
}

/* {DS_LINKED_LIST}.cursor_is_last */
EIF_BOOLEAN F1146_7569 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	RTLE;
	return (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 != NULL) && (EIF_BOOLEAN)(loc1 == *(EIF_REFERENCE *)(Current + _REFACS_2_)));
}

/* {DS_LINKED_LIST}.cursor_same_position */
EIF_BOOLEAN F1146_7570 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN tb3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	tr2 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
	if ((EIF_BOOLEAN)(tr1 == tr2)) {
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_0_);
		tb3 = *(EIF_BOOLEAN *)(RTCW(arg2)+ _CHROFF_3_0_);
		tb1 = (EIF_BOOLEAN)(tb2 == tb3);
	}
	if (tb1) {
		tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_1_);
		tb2 = *(EIF_BOOLEAN *)(RTCW(arg2)+ _CHROFF_3_1_);
		Result = (EIF_BOOLEAN)(tb1 == tb2);
	}
	RTLE;
	return Result;
}

/* {DS_LINKED_LIST}.cursor_start */
void F1146_7571 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	loc1 = F1097_7290(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == NULL);
	F1041_6820(RTCW(arg1), *(EIF_REFERENCE *)(Current + _REFACS_1_), (EIF_BOOLEAN) 0, loc2);
	if ((EIF_BOOLEAN) ((EIF_BOOLEAN) !loc2 && loc1)) {
		F1097_7293(Current, arg1);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_forth */
void F1146_7573 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc4);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,loc3);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		loc3 = *(EIF_REFERENCE *)(loc4);
	} else {
		loc1 = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
		loc3 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	}
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc3 == NULL);
	F1041_6820(RTCW(arg1), loc3, (EIF_BOOLEAN) 0, loc2);
	if (loc2) {
		if ((EIF_BOOLEAN) !loc1) {
			F1097_7294(Current, arg1);
		}
	} else {
		if (loc1) {
			F1097_7293(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_search_forth */
void F1146_7575 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_CHARACTER_8 arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_BOOLEAN loc3 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_CHARACTER_8 tc1;
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc2 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc1 == NULL);
	tr1 = *(EIF_REFERENCE *)(Current);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		for (;;) {
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(loc1 == NULL)) {
				tc1 = *(EIF_CHARACTER_8 *)(RTCW(loc1)+ _CHROFF_1_0_);
				tb2 = F228_2144(loc4, tc1, arg2);
				tb1 = tb2;
			}
			if (tb1) break;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			loc1 = (EIF_REFERENCE) tr1;
		}
	} else {
		for (;;) {
			tb2 = '\01';
			if (!(EIF_BOOLEAN)(loc1 == NULL)) {
				tc1 = *(EIF_CHARACTER_8 *)(RTCW(loc1)+ _CHROFF_1_0_);
				tb2 = (EIF_BOOLEAN)(tc1 == arg2);
			}
			if (tb2) break;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			loc1 = (EIF_REFERENCE) tr1;
		}
	}
	loc3 = (EIF_BOOLEAN) (EIF_BOOLEAN)(loc1 == NULL);
	F1041_6820(RTCW(arg1), loc1, (EIF_BOOLEAN) 0, loc3);
	if (loc3) {
		if ((EIF_BOOLEAN) !loc2) {
			F1097_7294(Current, arg1);
		}
	} else {
		if (loc2) {
			F1097_7293(Current, arg1);
		}
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_go_after */
void F1146_7577 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F1097_7290(Current, arg1);
	F1041_6818(RTCW(arg1));
	if ((EIF_BOOLEAN) !loc1) {
		F1097_7294(Current, arg1);
	}
	RTLE;
}

/* {DS_LINKED_LIST}.cursor_go_to */
void F1146_7579 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	loc1 = F1097_7290(Current, arg1);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg2)+ _CHROFF_3_0_);
	tb2 = *(EIF_BOOLEAN *)(RTCW(arg2)+ _CHROFF_3_1_);
	F1041_6820(RTCW(arg1), tr1, tb1, tb2);
	tb1 = F1041_6813(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		if (loc1) {
			F1097_7293(Current, arg1);
		}
	} else {
		if ((EIF_BOOLEAN) !loc1) {
			F1097_7294(Current, arg1);
		}
	}
	RTLE;
}

void EIF_Minit801 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
