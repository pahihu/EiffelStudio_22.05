/*
 * Code for class DS_CONTAINER [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds803.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_CONTAINER}.is_empty */
EIF_BOOLEAN F1083_7250 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_0_0_0_) == ((EIF_INTEGER_32) 0L));
}

void EIF_Minit803 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
