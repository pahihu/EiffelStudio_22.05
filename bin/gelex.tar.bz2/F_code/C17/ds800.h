
#ifndef _C17_ds800_
#define _C17_ds800_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1020_6766(EIF_REFERENCE);
extern void EIF_Minit800(void);

#ifdef __cplusplus
}
#endif

#endif
