/*
 * Code for class DS_TRAVERSABLE [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds832.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_TRAVERSABLE}.item_for_iteration */
EIF_CHARACTER_8 F1097_7281 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_CHARACTER_8) F1146_7566(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_));
}

/* {DS_TRAVERSABLE}.off */
EIF_BOOLEAN F1097_7283 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F1097_7290(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_));
}

/* {DS_TRAVERSABLE}.valid_cursor */
EIF_BOOLEAN F1097_7285 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_2_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tr1 == Current);
	RTLE;
	return Result;
}

/* {DS_TRAVERSABLE}.cursor_off */
EIF_BOOLEAN F1097_7290 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	
	
	tb1 = F1041_6813(RTCW(arg1));
	return (EIF_BOOLEAN) tb1;
}

/* {DS_TRAVERSABLE}.add_traversing_cursor */
void F1097_7293 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != *(EIF_REFERENCE *)(Current + _REFACS_3_))) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		tr1 = *(EIF_REFERENCE *)(RTCW(tr1));
		F977_6710(RTCW(arg1), tr1);
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		F977_6710(RTCW(tr1), arg1);
	}
	RTLE;
}

/* {DS_TRAVERSABLE}.remove_traversing_cursor */
void F1097_7294 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,loc2);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != *(EIF_REFERENCE *)(Current + _REFACS_3_))) {
		loc2 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
		loc1 = *(EIF_REFERENCE *)(RTCW(loc2));
		for (;;) {
			if ((EIF_BOOLEAN) ((EIF_BOOLEAN)(loc1 == arg1) || (EIF_BOOLEAN)(loc1 == NULL))) break;
			loc2 = (EIF_REFERENCE) loc1;
			tr1 = *(EIF_REFERENCE *)(RTCW(loc1));
			loc1 = (EIF_REFERENCE) tr1;
		}
		if ((EIF_BOOLEAN)(loc1 == arg1)) {
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1));
			F977_6710(RTCW(loc2), tr1);
			F977_6710(RTCW(arg1), NULL);
		}
	}
	RTLE;
}

void EIF_Minit832 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
