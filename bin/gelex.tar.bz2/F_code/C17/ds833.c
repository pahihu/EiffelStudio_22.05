/*
 * Code for class DS_LINEAR [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds833.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_LINEAR}.new_iterator */
EIF_REFERENCE F1109_7305 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F1146_7505(Current);
	F992_6721(RTCW(Result));
	RTLE;
	return Result;
}

/* {DS_LINEAR}.after */
EIF_BOOLEAN F1109_7307 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) F1109_7322(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_));
}

/* {DS_LINEAR}.start */
void F1109_7310 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1146_7571(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_));
}

/* {DS_LINEAR}.forth */
void F1109_7311 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1146_7573(Current, *(EIF_REFERENCE *)(Current + _REFACS_3_));
}

/* {DS_LINEAR}.cursor_after */
EIF_BOOLEAN F1109_7322 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	
	
	tb1 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_3_1_);
	return (EIF_BOOLEAN) tb1;
}

void EIF_Minit833 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
