
#ifndef _C17_to822_
#define _C17_to822_

#ifdef __cplusplus
extern "C" {
#endif

extern void F254_2420(EIF_REFERENCE, EIF_INTEGER_32);
extern void F254_2421(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern void F254_2427(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit822(void);
extern void F683_3597(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);
extern EIF_TYPE_INDEX Y2242[];
extern EIF_TYPE_INDEX *Y2242_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
