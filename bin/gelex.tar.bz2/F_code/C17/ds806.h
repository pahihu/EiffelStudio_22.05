
#ifndef _C17_ds806_
#define _C17_ds806_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1093_7280(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit806(void);

#ifdef __cplusplus
}
#endif

#endif
