
#ifndef _C17_ds803_
#define _C17_ds803_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F1083_7250(EIF_REFERENCE);
extern void EIF_Minit803(void);

#ifdef __cplusplus
}
#endif

#endif
