
#ifndef _C17_re819_
#define _C17_re819_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F632_3232(EIF_REFERENCE);
extern void EIF_Minit819(void);
extern char *(*R2870[])();

#ifdef __cplusplus
}
#endif

#endif
