
#ifndef _C17_ds845_
#define _C17_ds845_

#ifdef __cplusplus
extern "C" {
#endif

extern void F153_1683(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F153_1684(EIF_REFERENCE);
extern void EIF_Minit845(void);

#ifdef __cplusplus
}
#endif

#endif
