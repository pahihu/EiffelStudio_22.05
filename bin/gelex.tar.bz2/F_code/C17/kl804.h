
#ifndef _C17_kl804_
#define _C17_kl804_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F228_2144(EIF_REFERENCE, EIF_CHARACTER_8, EIF_CHARACTER_8);
extern void EIF_Minit804(void);

#ifdef __cplusplus
}
#endif

#endif
