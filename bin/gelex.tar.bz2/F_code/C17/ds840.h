
#ifndef _C17_ds840_
#define _C17_ds840_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1139_7438(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit840(void);
extern EIF_CHARACTER_8 F1146_7502(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1146_7524(EIF_REFERENCE, EIF_CHARACTER_8, EIF_INTEGER_32);

#ifdef __cplusplus
}
#endif

#endif
