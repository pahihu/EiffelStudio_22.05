/*
 * Code for class KL_ARRAY_ROUTINES [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "kl808.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {KL_ARRAY_ROUTINES}.make_empty_with_lower */
EIF_REFERENCE F941_6159 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 == ((EIF_INTEGER_32) 1L))) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,707,0xFFF8,1,0xFFFF};
			EIF_TYPE typres0;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr1 = RTLNS(typres0.id, 707, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		F708_3684(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,715,0xFFF8,1,0xFFFF};
			EIF_TYPE typres0;
			
			typres0 = eif_compound_id(dftype, typarr0);
			loc1 = RTLNS(typres0.id, 715, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		F708_3684(RTCW(loc1));
		F716_3743(RTCW(loc1), arg1);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,707,0xFFF8,1,0xFFFF};
			EIF_TYPE typres0;
			
			typres0 = eif_compound_id(dftype, typarr0);
			tr1 = RTLNS(typres0.id, 707, _OBJSIZ_1_1_0_2_0_0_0_0_);
		}
		F708_3687(RTCW(tr1), loc1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}/* NOTREACHED */
	
}

/* {KL_ARRAY_ROUTINES}.subcopy */
void F941_6164 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,arg2);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg3 <= arg4)) {
		F708_3714(RTCW(arg1), arg2, arg3, arg4, arg5);
	}
	RTLE;
}

/* {KL_ARRAY_ROUTINES}.resize_with_default */
void F941_6166 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_CHARACTER_8 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg3 <= arg4)) {
		F708_3730(RTCW(arg1), arg2, arg3, arg4);
	}
	RTLE;
}

void EIF_Minit808 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
