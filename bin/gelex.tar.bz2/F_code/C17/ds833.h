
#ifndef _C17_ds833_
#define _C17_ds833_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1109_7305(EIF_REFERENCE);
extern EIF_BOOLEAN F1109_7307(EIF_REFERENCE);
extern void F1109_7310(EIF_REFERENCE);
extern void F1109_7311(EIF_REFERENCE);
extern EIF_BOOLEAN F1109_7322(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit833(void);
extern void F1146_7573(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1146_7505(EIF_REFERENCE);
extern void F1146_7571(EIF_REFERENCE, EIF_REFERENCE);
extern void F992_6721(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
