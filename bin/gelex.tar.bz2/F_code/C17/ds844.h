
#ifndef _C17_ds844_
#define _C17_ds844_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_8 F150_1679(EIF_REFERENCE);
extern void F150_1681(EIF_REFERENCE, EIF_CHARACTER_8);
extern void F150_1682(EIF_REFERENCE, EIF_CHARACTER_8);
extern void EIF_Minit844(void);
extern long O1617[];

#ifdef __cplusplus
}
#endif

#endif
