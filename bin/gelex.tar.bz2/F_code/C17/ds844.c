/*
 * Code for class DS_CELL [CHARACTER_8]
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ds844.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DS_CELL}.item */
EIF_CHARACTER_8 F150_1679 (EIF_REFERENCE Current)
{
	return *(EIF_CHARACTER_8 *)(Current + O1617[Dtype(Current)-148]);
}


/* {DS_CELL}.put */
void F150_1681 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current + O1617[Dtype(Current)-148]) = (EIF_CHARACTER_8) arg1;
}

/* {DS_CELL}.make */
void F150_1682 (EIF_REFERENCE Current, EIF_CHARACTER_8 arg1)
{
	GTCX
	
	
	*(EIF_CHARACTER_8 *)(Current + O1617[Dtype(Current)-148]) = (EIF_CHARACTER_8) arg1;
}

void EIF_Minit844 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
