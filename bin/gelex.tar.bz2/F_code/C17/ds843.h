
#ifndef _C17_ds843_
#define _C17_ds843_

#ifdef __cplusplus
extern "C" {
#endif

extern void F155_1688(EIF_REFERENCE, EIF_REFERENCE);
extern void F155_1689(EIF_REFERENCE);
extern void EIF_Minit843(void);

#ifdef __cplusplus
}
#endif

#endif
