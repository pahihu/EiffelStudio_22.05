
#ifndef _C17_kl807_
#define _C17_kl807_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F130_1386(EIF_REFERENCE, EIF_CHARACTER_8, EIF_CHARACTER_8);
extern EIF_BOOLEAN F130_1387(EIF_REFERENCE, EIF_CHARACTER_8, EIF_CHARACTER_8);
extern void EIF_Minit807(void);

#ifdef __cplusplus
}
#endif

#endif
