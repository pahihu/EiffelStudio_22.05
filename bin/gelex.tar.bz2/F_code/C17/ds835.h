
#ifndef _C17_ds835_
#define _C17_ds835_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1036_6776(EIF_REFERENCE);
extern void F1036_6788(EIF_REFERENCE);
extern void EIF_Minit835(void);
extern void F1146_7545(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1146_7567(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
