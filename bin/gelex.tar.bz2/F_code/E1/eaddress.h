#include "eif_eiffel.h"
#include "eif_rout_obj.h"

#ifdef __cplusplus
extern "C" {
#endif

extern void F793_4089(EIF_REFERENCE, EIF_REFERENCE, EIF_POINTER);
extern EIF_BOOLEAN F1082_7250(EIF_REFERENCE);
extern void F786_4016(EIF_REFERENCE);
extern void F793_4090(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);
extern EIF_BOOLEAN F602_3219(EIF_REFERENCE);
extern char *(*R5572[])();

#ifdef __cplusplus
}
#endif
