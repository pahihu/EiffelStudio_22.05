#include "eif_eiffel.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ANY */
static EIF_TYPE_INDEX ptf0[] = {0xFFFF};
static struct eif_par_types par0 = {0, ptf0, (uint16) 0, (uint16) 0, (char) 0};

/* RX_CHARACTER_SET */
static EIF_TYPE_INDEX ptf1[] = {0,0xFFFF};
static struct eif_par_types par1 = {1, ptf1, (uint16) 1, (uint16) 0, (char) 0};

/* KL_OPERATING_SYSTEM */
static EIF_TYPE_INDEX ptf2[] = {0,0xFFFF};
static struct eif_par_types par2 = {2, ptf2, (uint16) 1, (uint16) 0, (char) 0};

/* DESCRIPTOR_CACHE */
static EIF_TYPE_INDEX ptf3[] = {0,0xFFFF};
static struct eif_par_types par3 = {3, ptf3, (uint16) 1, (uint16) 0, (char) 0};

/* RX_PCRE_ROUTINES */
static EIF_TYPE_INDEX ptf4[] = {0,0xFFFF};
static struct eif_par_types par4 = {4, ptf4, (uint16) 1, (uint16) 0, (char) 0};

/* VERSIONABLE */
static EIF_TYPE_INDEX ptf5[] = {0,0xFFFF};
static struct eif_par_types par5 = {5, ptf5, (uint16) 1, (uint16) 0, (char) 0};

/* LX_ACTION_FACTORY */
static EIF_TYPE_INDEX ptf6[] = {0,0xFFFF};
static struct eif_par_types par6 = {6, ptf6, (uint16) 1, (uint16) 0, (char) 0};

/* UT_ARRAY_FORMATTER */
static EIF_TYPE_INDEX ptf7[] = {0,0xFFFF};
static struct eif_par_types par7 = {7, ptf7, (uint16) 1, (uint16) 0, (char) 0};

/* UT_BOOLEAN_FORMATTER */
static EIF_TYPE_INDEX ptf8[] = {0,0xFFFF};
static struct eif_par_types par8 = {8, ptf8, (uint16) 1, (uint16) 0, (char) 0};

/* CODE_PAGE_CONSTANTS */
static EIF_TYPE_INDEX ptf9[] = {0,0xFFFF};
static struct eif_par_types par9 = {9, ptf9, (uint16) 1, (uint16) 0, (char) 0};

/* ENCODING */
static EIF_TYPE_INDEX ptf10[] = {0,0xFFFF};
static struct eif_par_types par10 = {10, ptf10, (uint16) 1, (uint16) 0, (char) 0};

/* SYSTEM_ENCODINGS */
static EIF_TYPE_INDEX ptf11[] = {0,0xFFFF};
static struct eif_par_types par11 = {11, ptf11, (uint16) 1, (uint16) 0, (char) 0};

/* KL_HASH_FUNCTION [G#1] */
static EIF_TYPE_INDEX ptf12[] = {0,0xFFFF};
static struct eif_par_types par12 = {12, ptf12, (uint16) 1, (uint16) 1, (char) 0};

/* KL_HASH_FUNCTION [INTEGER_32] */
static EIF_TYPE_INDEX ptf13[] = {0,0xFFFF};
static struct eif_par_types par13 = {13, ptf13, (uint16) 1, (uint16) 1, (char) 0};

/* KL_HASH_FUNCTION [NATURAL_32] */
static EIF_TYPE_INDEX ptf14[] = {0,0xFFFF};
static struct eif_par_types par14 = {14, ptf14, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ANY_ROUTINES */
static EIF_TYPE_INDEX ptf15[] = {0,0xFFFF};
static struct eif_par_types par15 = {15, ptf15, (uint16) 1, (uint16) 0, (char) 0};

/* SYSTEM_STRING_FACTORY */
static EIF_TYPE_INDEX ptf16[] = {0,0xFFFF};
static struct eif_par_types par16 = {16, ptf16, (uint16) 1, (uint16) 0, (char) 0};

/* CHARACTER_PROPERTY */
static EIF_TYPE_INDEX ptf17[] = {0,0xFFFF};
static struct eif_par_types par17 = {17, ptf17, (uint16) 1, (uint16) 0, (char) 0};

/* KL_STANDARD_FILES */
static EIF_TYPE_INDEX ptf18[] = {0,0xFFFF};
static struct eif_par_types par18 = {18, ptf18, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SPECIAL_ROUTINES [G#1] */
static EIF_TYPE_INDEX ptf19[] = {0,0xFFFF};
static struct eif_par_types par19 = {19, ptf19, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SPECIAL_ROUTINES [INTEGER_32] */
static EIF_TYPE_INDEX ptf20[] = {0,0xFFFF};
static struct eif_par_types par20 = {20, ptf20, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SPECIAL_ROUTINES [BOOLEAN] */
static EIF_TYPE_INDEX ptf21[] = {0,0xFFFF};
static struct eif_par_types par21 = {21, ptf21, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SPECIAL_ROUTINES [NATURAL_32] */
static EIF_TYPE_INDEX ptf22[] = {0,0xFFFF};
static struct eif_par_types par22 = {22, ptf22, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SPECIAL_ROUTINES [NATURAL_64] */
static EIF_TYPE_INDEX ptf23[] = {0,0xFFFF};
static struct eif_par_types par23 = {23, ptf23, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SPECIAL_ROUTINES [CHARACTER_8] */
static EIF_TYPE_INDEX ptf24[] = {0,0xFFFF};
static struct eif_par_types par24 = {24, ptf24, (uint16) 1, (uint16) 1, (char) 0};

/* SYSTEM_STRING */
static EIF_TYPE_INDEX ptf25[] = {0,0xFFFF};
static struct eif_par_types par25 = {25, ptf25, (uint16) 1, (uint16) 0, (char) 0};

/* RT_DBG_EXECUTION_PARAMETERS */
static EIF_TYPE_INDEX ptf26[] = {0,0xFFFF};
static struct eif_par_types par26 = {26, ptf26, (uint16) 1, (uint16) 0, (char) 0};

/* reference UTF_CONVERTER */
static EIF_TYPE_INDEX ptf27[] = {0,0xFFFF};
static struct eif_par_types par27 = {27, ptf27, (uint16) 1, (uint16) 0, (char) 1};

/* UTF_CONVERTER */
static EIF_TYPE_INDEX ptf28[] = {27,0xFFFF};
static struct eif_par_types par28 = {28, ptf28, (uint16) 1, (uint16) 0, (char) 1};

/* ISE_RUNTIME */
static EIF_TYPE_INDEX ptf29[] = {0,0xFFFF};
static struct eif_par_types par29 = {29, ptf29, (uint16) 1, (uint16) 0, (char) 0};

/* NATIVE_ARRAY [G#1] */
static EIF_TYPE_INDEX ptf30[] = {0,0xFFFF};
static struct eif_par_types par30 = {30, ptf30, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [INTEGER_32] */
static EIF_TYPE_INDEX ptf31[] = {0,0xFFFF};
static struct eif_par_types par31 = {31, ptf31, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [POINTER] */
static EIF_TYPE_INDEX ptf32[] = {0,0xFFFF};
static struct eif_par_types par32 = {32, ptf32, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [BOOLEAN] */
static EIF_TYPE_INDEX ptf33[] = {0,0xFFFF};
static struct eif_par_types par33 = {33, ptf33, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [CHARACTER_32] */
static EIF_TYPE_INDEX ptf34[] = {0,0xFFFF};
static struct eif_par_types par34 = {34, ptf34, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [NATURAL_64] */
static EIF_TYPE_INDEX ptf35[] = {0,0xFFFF};
static struct eif_par_types par35 = {35, ptf35, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [CHARACTER_8] */
static EIF_TYPE_INDEX ptf36[] = {0,0xFFFF};
static struct eif_par_types par36 = {36, ptf36, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [NATURAL_8] */
static EIF_TYPE_INDEX ptf37[] = {0,0xFFFF};
static struct eif_par_types par37 = {37, ptf37, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [NATURAL_16] */
static EIF_TYPE_INDEX ptf38[] = {0,0xFFFF};
static struct eif_par_types par38 = {38, ptf38, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [REAL_32] */
static EIF_TYPE_INDEX ptf39[] = {0,0xFFFF};
static struct eif_par_types par39 = {39, ptf39, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [REAL_64] */
static EIF_TYPE_INDEX ptf40[] = {0,0xFFFF};
static struct eif_par_types par40 = {40, ptf40, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_ARRAY [NATURAL_32] */
static EIF_TYPE_INDEX ptf41[] = {0,0xFFFF};
static struct eif_par_types par41 = {41, ptf41, (uint16) 1, (uint16) 1, (char) 0};

/* STD_FILES */
static EIF_TYPE_INDEX ptf42[] = {0,0xFFFF};
static struct eif_par_types par42 = {42, ptf42, (uint16) 1, (uint16) 0, (char) 0};

/* OPERATING_ENVIRONMENT */
static EIF_TYPE_INDEX ptf43[] = {0,0xFFFF};
static struct eif_par_types par43 = {43, ptf43, (uint16) 1, (uint16) 0, (char) 0};

/* LX_START_CONDITION */
static EIF_TYPE_INDEX ptf44[] = {0,0xFFFF};
static struct eif_par_types par44 = {44, ptf44, (uint16) 1, (uint16) 0, (char) 0};

/* LX_DESCRIPTION */
static EIF_TYPE_INDEX ptf45[] = {0,0xFFFF};
static struct eif_par_types par45 = {45, ptf45, (uint16) 1, (uint16) 0, (char) 0};

/* LX_SINGLETON */
static EIF_TYPE_INDEX ptf46[] = {0,0xFFFF};
static struct eif_par_types par46 = {46, ptf46, (uint16) 1, (uint16) 0, (char) 0};

/* LX_PROTO */
static EIF_TYPE_INDEX ptf47[] = {0,0xFFFF};
static struct eif_par_types par47 = {47, ptf47, (uint16) 1, (uint16) 0, (char) 0};

/* RX_PCRE_SHARED_CHARACTER_SETS */
static EIF_TYPE_INDEX ptf48[] = {0,0xFFFF};
static struct eif_par_types par48 = {48, ptf48, (uint16) 1, (uint16) 0, (char) 0};

/* RX_PCRE_OPTION_ROUTINES */
static EIF_TYPE_INDEX ptf49[] = {0,0xFFFF};
static struct eif_par_types par49 = {49, ptf49, (uint16) 1, (uint16) 0, (char) 0};

/* RX_PCRE_ERROR_CONSTANTS */
static EIF_TYPE_INDEX ptf50[] = {0,0xFFFF};
static struct eif_par_types par50 = {50, ptf50, (uint16) 1, (uint16) 0, (char) 0};

/* RX_PCRE_BYTE_CODE_CONSTANTS */
static EIF_TYPE_INDEX ptf51[] = {0,0xFFFF};
static struct eif_par_types par51 = {51, ptf51, (uint16) 1, (uint16) 0, (char) 0};

/* UC_SHARED_STRING_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf52[] = {0,0xFFFF};
static struct eif_par_types par52 = {52, ptf52, (uint16) 1, (uint16) 0, (char) 0};

/* KL_VALUES [G#1, G#2] */
static EIF_TYPE_INDEX ptf53[] = {0,0xFFFF};
static struct eif_par_types par53 = {53, ptf53, (uint16) 1, (uint16) 2, (char) 0};

/* KL_VALUES [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf54[] = {0,0xFFFF};
static struct eif_par_types par54 = {54, ptf54, (uint16) 1, (uint16) 2, (char) 0};

/* KL_VALUES [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf55[] = {0,0xFFFF};
static struct eif_par_types par55 = {55, ptf55, (uint16) 1, (uint16) 2, (char) 0};

/* KL_VALUES [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf56[] = {0,0xFFFF};
static struct eif_par_types par56 = {56, ptf56, (uint16) 1, (uint16) 2, (char) 0};

/* KI_PLATFORM */
static EIF_TYPE_INDEX ptf57[] = {0,0xFFFF};
static struct eif_par_types par57 = {57, ptf57, (uint16) 1, (uint16) 0, (char) 0};

/* CODE_SETS */
static EIF_TYPE_INDEX ptf58[] = {0,0xFFFF};
static struct eif_par_types par58 = {58, ptf58, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_OPERATING_SYSTEM */
static EIF_TYPE_INDEX ptf59[] = {0,0xFFFF};
static struct eif_par_types par59 = {59, ptf59, (uint16) 1, (uint16) 0, (char) 0};

/* OBJECT_GRAPH_TRAVERSABLE */
static EIF_TYPE_INDEX ptf60[] = {0,0xFFFF};
static struct eif_par_types par60 = {60, ptf60, (uint16) 1, (uint16) 0, (char) 0};

/* OBJECT_GRAPH_BREADTH_FIRST_TRAVERSABLE */
static EIF_TYPE_INDEX ptf61[] = {60,0xFFFF};
static struct eif_par_types par61 = {61, ptf61, (uint16) 1, (uint16) 0, (char) 0};

/* YY_PARSER */
static EIF_TYPE_INDEX ptf62[] = {0,0xFFFF};
static struct eif_par_types par62 = {62, ptf62, (uint16) 1, (uint16) 0, (char) 0};

/* KL_ANY */
static EIF_TYPE_INDEX ptf63[] = {0,0xFFFF};
static struct eif_par_types par63 = {63, ptf63, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_PLATFORM */
static EIF_TYPE_INDEX ptf64[] = {63,0xFFFF};
static struct eif_par_types par64 = {64, ptf64, (uint16) 1, (uint16) 0, (char) 0};

/* KL_CHARACTER_ROUTINES */
static EIF_TYPE_INDEX ptf65[] = {64,0xFFFF};
static struct eif_par_types par65 = {65, ptf65, (uint16) 1, (uint16) 0, (char) 0};

/* UC_UNICODE_CONSTANTS */
static EIF_TYPE_INDEX ptf66[] = {64,0xFFFF};
static struct eif_par_types par66 = {66, ptf66, (uint16) 1, (uint16) 0, (char) 0};

/* UC_IMPORTED_UTF8_ROUTINES */
static EIF_TYPE_INDEX ptf67[] = {0,0xFFFF};
static struct eif_par_types par67 = {67, ptf67, (uint16) 1, (uint16) 0, (char) 0};

/* UC_STRING_HANDLER */
static EIF_TYPE_INDEX ptf68[] = {0,0xFFFF};
static struct eif_par_types par68 = {68, ptf68, (uint16) 1, (uint16) 0, (char) 0};

/* DS_SORTER [G#1] */
static EIF_TYPE_INDEX ptf69[] = {0,0xFFFF};
static struct eif_par_types par69 = {69, ptf69, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SORTER [INTEGER_32] */
static EIF_TYPE_INDEX ptf70[] = {0,0xFFFF};
static struct eif_par_types par70 = {70, ptf70, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SORTER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf71[] = {0,0xFFFF};
static struct eif_par_types par71 = {71, ptf71, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SORTER [BOOLEAN] */
static EIF_TYPE_INDEX ptf72[] = {0,0xFFFF};
static struct eif_par_types par72 = {72, ptf72, (uint16) 1, (uint16) 1, (char) 0};

/* DS_INDEXABLE_SORTER [G#1] */
static EIF_TYPE_INDEX ptf73[] = {69,0xFFF8,1,0xFFFF};
static struct eif_par_types par73 = {73, ptf73, (uint16) 1, (uint16) 1, (char) 0};

/* DS_INDEXABLE_SORTER [INTEGER_32] */
static EIF_TYPE_INDEX ptf74[] = {70,834,0xFFFF};
static struct eif_par_types par74 = {74, ptf74, (uint16) 1, (uint16) 1, (char) 0};

/* DS_QUICK_SORTER [G#1] */
static EIF_TYPE_INDEX ptf75[] = {73,0xFFF8,1,0xFFFF};
static struct eif_par_types par75 = {75, ptf75, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BUBBLE_SORTER [G#1] */
static EIF_TYPE_INDEX ptf76[] = {73,0xFFF8,1,0xFFFF};
static struct eif_par_types par76 = {76, ptf76, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BUBBLE_SORTER [INTEGER_32] */
static EIF_TYPE_INDEX ptf77[] = {74,834,0xFFFF};
static struct eif_par_types par77 = {77, ptf77, (uint16) 1, (uint16) 1, (char) 0};

/* SYSTEM_ENCODINGS_I */
static EIF_TYPE_INDEX ptf78[] = {0,0xFFFF};
static struct eif_par_types par78 = {78, ptf78, (uint16) 1, (uint16) 0, (char) 0};

/* KL_CELL [G#1] */
static EIF_TYPE_INDEX ptf79[] = {0,0xFFFF};
static struct eif_par_types par79 = {79, ptf79, (uint16) 1, (uint16) 1, (char) 0};

/* KL_CELL [CHARACTER_8] */
static EIF_TYPE_INDEX ptf80[] = {0,0xFFFF};
static struct eif_par_types par80 = {80, ptf80, (uint16) 1, (uint16) 1, (char) 0};

/* KL_LINKABLE [G#1] */
static EIF_TYPE_INDEX ptf81[] = {79,0xFFF8,1,0xFFFF};
static struct eif_par_types par81 = {81, ptf81, (uint16) 1, (uint16) 1, (char) 0};

/* KL_LINKABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf82[] = {80,864,0xFFFF};
static struct eif_par_types par82 = {82, ptf82, (uint16) 1, (uint16) 1, (char) 0};

/* KI_OUTPUT_STREAM [CHARACTER_8] */
static EIF_TYPE_INDEX ptf83[] = {0,0xFFFF};
static struct eif_par_types par83 = {83, ptf83, (uint16) 1, (uint16) 1, (char) 0};

/* OBJECT_GRAPH_MARKER */
static EIF_TYPE_INDEX ptf84[] = {0,0xFFFF};
static struct eif_par_types par84 = {84, ptf84, (uint16) 1, (uint16) 0, (char) 0};

/* MATH_CONST */
static EIF_TYPE_INDEX ptf85[] = {0,0xFFFF};
static struct eif_par_types par85 = {85, ptf85, (uint16) 1, (uint16) 0, (char) 0};

/* DOUBLE_MATH */
static EIF_TYPE_INDEX ptf86[] = {85,0xFFFF};
static struct eif_par_types par86 = {86, ptf86, (uint16) 1, (uint16) 0, (char) 0};

/* KI_EXCEPTIONS */
static EIF_TYPE_INDEX ptf87[] = {0,0xFFFF};
static struct eif_par_types par87 = {87, ptf87, (uint16) 1, (uint16) 0, (char) 0};

/* KL_GOBO_VERSION */
static EIF_TYPE_INDEX ptf88[] = {0,0xFFFF};
static struct eif_par_types par88 = {88, ptf88, (uint16) 1, (uint16) 0, (char) 0};

/* GELEX_VERSION */
static EIF_TYPE_INDEX ptf89[] = {88,0xFFFF};
static struct eif_par_types par89 = {89, ptf89, (uint16) 1, (uint16) 0, (char) 0};

/* KI_BUFFER [G#1] */
static EIF_TYPE_INDEX ptf90[] = {0,0xFFFF};
static struct eif_par_types par90 = {90, ptf90, (uint16) 1, (uint16) 1, (char) 0};

/* KI_BUFFER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf91[] = {0,0xFFFF};
static struct eif_par_types par91 = {91, ptf91, (uint16) 1, (uint16) 1, (char) 0};

/* KI_CHARACTER_BUFFER */
static EIF_TYPE_INDEX ptf92[] = {91,864,0xFFFF};
static struct eif_par_types par92 = {92, ptf92, (uint16) 1, (uint16) 0, (char) 0};

/* REFLECTOR_HELPER */
static EIF_TYPE_INDEX ptf93[] = {0,0xFFFF};
static struct eif_par_types par93 = {93, ptf93, (uint16) 1, (uint16) 0, (char) 0};

/* REFACTORING_HELPER */
static EIF_TYPE_INDEX ptf94[] = {0,0xFFFF};
static struct eif_par_types par94 = {94, ptf94, (uint16) 1, (uint16) 0, (char) 0};

/* LX_EQUIVALENCE_CLASSES */
static EIF_TYPE_INDEX ptf95[] = {0,0xFFFF};
static struct eif_par_types par95 = {95, ptf95, (uint16) 1, (uint16) 0, (char) 0};

/* LX_SYMBOL_PARTITIONS */
static EIF_TYPE_INDEX ptf96[] = {95,0xFFFF};
static struct eif_par_types par96 = {96, ptf96, (uint16) 1, (uint16) 0, (char) 0};

/* EXCEPTION_MANAGER */
static EIF_TYPE_INDEX ptf97[] = {0,0xFFFF};
static struct eif_par_types par97 = {97, ptf97, (uint16) 1, (uint16) 0, (char) 0};

/* ISE_EXCEPTION_MANAGER */
static EIF_TYPE_INDEX ptf98[] = {97,0xFFFF};
static struct eif_par_types par98 = {98, ptf98, (uint16) 1, (uint16) 0, (char) 0};

/* EXCEP_CONST */
static EIF_TYPE_INDEX ptf99[] = {0,0xFFFF};
static struct eif_par_types par99 = {99, ptf99, (uint16) 1, (uint16) 0, (char) 0};

/* CELL [G#1] */
static EIF_TYPE_INDEX ptf100[] = {0,0xFFFF};
static struct eif_par_types par100 = {100, ptf100, (uint16) 1, (uint16) 1, (char) 0};

/* CELL [CHARACTER_32] */
static EIF_TYPE_INDEX ptf101[] = {0,0xFFFF};
static struct eif_par_types par101 = {101, ptf101, (uint16) 1, (uint16) 1, (char) 0};

/* CELL [NATURAL_64] */
static EIF_TYPE_INDEX ptf102[] = {0,0xFFFF};
static struct eif_par_types par102 = {102, ptf102, (uint16) 1, (uint16) 1, (char) 0};

/* CELL [INTEGER_32] */
static EIF_TYPE_INDEX ptf103[] = {0,0xFFFF};
static struct eif_par_types par103 = {103, ptf103, (uint16) 1, (uint16) 1, (char) 0};

/* LINKABLE [G#1] */
static EIF_TYPE_INDEX ptf104[] = {100,0xFFF8,1,0xFFFF};
static struct eif_par_types par104 = {104, ptf104, (uint16) 1, (uint16) 1, (char) 0};

/* LINKABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf105[] = {103,834,0xFFFF};
static struct eif_par_types par105 = {105, ptf105, (uint16) 1, (uint16) 1, (char) 0};

/* LX_DESCRIPTION_OVERRIDER */
static EIF_TYPE_INDEX ptf106[] = {0,0xFFFF};
static struct eif_par_types par106 = {106, ptf106, (uint16) 1, (uint16) 0, (char) 0};

/* DP_COMMAND */
static EIF_TYPE_INDEX ptf107[] = {0,0xFFFF};
static struct eif_par_types par107 = {107, ptf107, (uint16) 1, (uint16) 0, (char) 0};

/* LX_ACTION */
static EIF_TYPE_INDEX ptf108[] = {107,0xFFFF};
static struct eif_par_types par108 = {108, ptf108, (uint16) 1, (uint16) 0, (char) 0};

/* UT_CHARACTER_32_CODES */
static EIF_TYPE_INDEX ptf109[] = {0,0xFFFF};
static struct eif_par_types par109 = {109, ptf109, (uint16) 1, (uint16) 0, (char) 0};

/* ENCODING_HELPER */
static EIF_TYPE_INDEX ptf110[] = {0,0xFFFF};
static struct eif_par_types par110 = {110, ptf110, (uint16) 1, (uint16) 0, (char) 0};

/* SYSTEM_ENCODINGS_IMP */
static EIF_TYPE_INDEX ptf111[] = {78,0xFFFF};
static struct eif_par_types par111 = {111, ptf111, (uint16) 1, (uint16) 0, (char) 0};

/* KI_FILE_SYSTEM_ENTRY */
static EIF_TYPE_INDEX ptf112[] = {0,0xFFFF};
static struct eif_par_types par112 = {112, ptf112, (uint16) 1, (uint16) 0, (char) 0};

/* KI_FILE */
static EIF_TYPE_INDEX ptf113[] = {112,0xFFFF};
static struct eif_par_types par113 = {113, ptf113, (uint16) 1, (uint16) 0, (char) 0};

/* AP_CONSTANTS */
static EIF_TYPE_INDEX ptf114[] = {0,0xFFFF};
static struct eif_par_types par114 = {114, ptf114, (uint16) 1, (uint16) 0, (char) 0};

/* AP_OPTION */
static EIF_TYPE_INDEX ptf115[] = {114,0xFFFF};
static struct eif_par_types par115 = {115, ptf115, (uint16) 1, (uint16) 0, (char) 0};

/* AP_FLAG */
static EIF_TYPE_INDEX ptf116[] = {115,0xFFFF};
static struct eif_par_types par116 = {116, ptf116, (uint16) 1, (uint16) 0, (char) 0};

/* AP_OPTION_WITH_PARAMETER [G#1] */
static EIF_TYPE_INDEX ptf117[] = {115,0xFFFF};
static struct eif_par_types par117 = {117, ptf117, (uint16) 1, (uint16) 1, (char) 0};

/* AP_OPTION_WITH_PARAMETER [BOOLEAN] */
static EIF_TYPE_INDEX ptf118[] = {115,0xFFFF};
static struct eif_par_types par118 = {118, ptf118, (uint16) 1, (uint16) 1, (char) 0};

/* AP_OPTION_WITH_PARAMETER [INTEGER_32] */
static EIF_TYPE_INDEX ptf119[] = {115,0xFFFF};
static struct eif_par_types par119 = {119, ptf119, (uint16) 1, (uint16) 1, (char) 0};

/* AP_INTEGER_OPTION */
static EIF_TYPE_INDEX ptf120[] = {119,834,0xFFFF};
static struct eif_par_types par120 = {120, ptf120, (uint16) 1, (uint16) 0, (char) 0};

/* AP_STRING_OPTION */
static EIF_TYPE_INDEX ptf121[] = {117,0xFF01,914,0xFFFF};
static struct eif_par_types par121 = {121, ptf121, (uint16) 1, (uint16) 0, (char) 0};

/* KL_IMPORTED_CHARACTER_ROUTINES */
static EIF_TYPE_INDEX ptf122[] = {0,0xFFFF};
static struct eif_par_types par122 = {122, ptf122, (uint16) 1, (uint16) 0, (char) 0};

/* UC_IMPORTED_UTF32_ROUTINES */
static EIF_TYPE_INDEX ptf123[] = {0,0xFFFF};
static struct eif_par_types par123 = {123, ptf123, (uint16) 1, (uint16) 0, (char) 0};

/* UC_IMPORTED_UTF16_ROUTINES */
static EIF_TYPE_INDEX ptf124[] = {0,0xFFFF};
static struct eif_par_types par124 = {124, ptf124, (uint16) 1, (uint16) 0, (char) 0};

/* KI_INPUT_STREAM [G#1] */
static EIF_TYPE_INDEX ptf125[] = {0,0xFFFF};
static struct eif_par_types par125 = {125, ptf125, (uint16) 1, (uint16) 1, (char) 0};

/* KI_INPUT_STREAM [CHARACTER_8] */
static EIF_TYPE_INDEX ptf126[] = {0,0xFFFF};
static struct eif_par_types par126 = {126, ptf126, (uint16) 1, (uint16) 1, (char) 0};

/* KL_PART_COMPARATOR [G#1] */
static EIF_TYPE_INDEX ptf127[] = {0,0xFFFF};
static struct eif_par_types par127 = {127, ptf127, (uint16) 1, (uint16) 1, (char) 0};

/* KL_PART_COMPARATOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf128[] = {0,0xFFFF};
static struct eif_par_types par128 = {128, ptf128, (uint16) 1, (uint16) 1, (char) 0};

/* KL_PART_COMPARATOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf129[] = {0,0xFFFF};
static struct eif_par_types par129 = {129, ptf129, (uint16) 1, (uint16) 1, (char) 0};

/* KL_PART_COMPARATOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf130[] = {0,0xFFFF};
static struct eif_par_types par130 = {130, ptf130, (uint16) 1, (uint16) 1, (char) 0};

/* KL_REVERSE_PART_COMPARATOR [G#1] */
static EIF_TYPE_INDEX ptf131[] = {127,0xFFF8,1,0xFFFF};
static struct eif_par_types par131 = {131, ptf131, (uint16) 1, (uint16) 1, (char) 0};

/* KL_REVERSE_PART_COMPARATOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf132[] = {128,834,0xFFFF};
static struct eif_par_types par132 = {132, ptf132, (uint16) 1, (uint16) 1, (char) 0};

/* RT_EXTENSION_COMMON */
static EIF_TYPE_INDEX ptf133[] = {0,0xFFFF};
static struct eif_par_types par133 = {133, ptf133, (uint16) 1, (uint16) 0, (char) 0};

/* RT_EXTENSION_GENERAL */
static EIF_TYPE_INDEX ptf134[] = {133,0xFFFF};
static struct eif_par_types par134 = {134, ptf134, (uint16) 1, (uint16) 0, (char) 0};

/* RT_EXTENSION */
static EIF_TYPE_INDEX ptf135[] = {134,0xFFFF};
static struct eif_par_types par135 = {135, ptf135, (uint16) 1, (uint16) 0, (char) 0};

/* RT_DBG_COMMON */
static EIF_TYPE_INDEX ptf136[] = {133,0xFFFF};
static struct eif_par_types par136 = {136, ptf136, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_SEARCHER */
static EIF_TYPE_INDEX ptf137[] = {0,0xFFFF};
static struct eif_par_types par137 = {137, ptf137, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_32_SEARCHER */
static EIF_TYPE_INDEX ptf138[] = {137,0xFFFF};
static struct eif_par_types par138 = {138, ptf138, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_8_SEARCHER */
static EIF_TYPE_INDEX ptf139[] = {137,0xFFFF};
static struct eif_par_types par139 = {139, ptf139, (uint16) 1, (uint16) 0, (char) 0};

/* NUMERIC_INFORMATION */
static EIF_TYPE_INDEX ptf140[] = {0,0xFFFF};
static struct eif_par_types par140 = {140, ptf140, (uint16) 1, (uint16) 0, (char) 0};

/* INTEGER_OVERFLOW_CHECKER */
static EIF_TYPE_INDEX ptf141[] = {140,0xFFFF};
static struct eif_par_types par141 = {141, ptf141, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_TO_NUMERIC_CONVERTOR */
static EIF_TYPE_INDEX ptf142[] = {140,0xFFFF};
static struct eif_par_types par142 = {142, ptf142, (uint16) 1, (uint16) 0, (char) 0};

/* HEXADECIMAL_STRING_TO_INTEGER_CONVERTER */
static EIF_TYPE_INDEX ptf143[] = {142,0xFFFF};
static struct eif_par_types par143 = {143, ptf143, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_TO_INTEGER_CONVERTOR */
static EIF_TYPE_INDEX ptf144[] = {142,0xFFFF};
static struct eif_par_types par144 = {144, ptf144, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_TO_REAL_CONVERTOR */
static EIF_TYPE_INDEX ptf145[] = {142,0xFFFF};
static struct eif_par_types par145 = {145, ptf145, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_STREAMS */
static EIF_TYPE_INDEX ptf146[] = {0,0xFFFF};
static struct eif_par_types par146 = {146, ptf146, (uint16) 1, (uint16) 0, (char) 0};

/* UT_CHARACTER_CODES */
static EIF_TYPE_INDEX ptf147[] = {0,0xFFFF};
static struct eif_par_types par147 = {147, ptf147, (uint16) 1, (uint16) 0, (char) 0};

/* DS_CELL [G#1] */
static EIF_TYPE_INDEX ptf148[] = {0,0xFFFF};
static struct eif_par_types par148 = {148, ptf148, (uint16) 1, (uint16) 1, (char) 0};

/* DS_CELL [CHARACTER_8] */
static EIF_TYPE_INDEX ptf149[] = {0,0xFFFF};
static struct eif_par_types par149 = {149, ptf149, (uint16) 1, (uint16) 1, (char) 0};

/* DS_CELL [INTEGER_32] */
static EIF_TYPE_INDEX ptf150[] = {0,0xFFFF};
static struct eif_par_types par150 = {150, ptf150, (uint16) 1, (uint16) 1, (char) 0};

/* DS_CELL [BOOLEAN] */
static EIF_TYPE_INDEX ptf151[] = {0,0xFFFF};
static struct eif_par_types par151 = {151, ptf151, (uint16) 1, (uint16) 1, (char) 0};

/* DS_PAIR [G#1, G#2] */
static EIF_TYPE_INDEX ptf152[] = {148,0xFFF8,1,0xFFFF};
static struct eif_par_types par152 = {152, ptf152, (uint16) 1, (uint16) 2, (char) 0};

/* DS_LINKABLE [G#1] */
static EIF_TYPE_INDEX ptf153[] = {148,0xFFF8,1,0xFFFF};
static struct eif_par_types par153 = {153, ptf153, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf154[] = {149,864,0xFFFF};
static struct eif_par_types par154 = {154, ptf154, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf155[] = {150,834,0xFFFF};
static struct eif_par_types par155 = {155, ptf155, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf156[] = {151,867,0xFFFF};
static struct eif_par_types par156 = {156, ptf156, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINKABLE [G#1] */
static EIF_TYPE_INDEX ptf157[] = {153,0xFFF8,1,0xFFFF};
static struct eif_par_types par157 = {157, ptf157, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINKABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf158[] = {155,834,0xFFFF};
static struct eif_par_types par158 = {158, ptf158, (uint16) 1, (uint16) 1, (char) 0};

/* PART_COMPARABLE */
static EIF_TYPE_INDEX ptf159[] = {0,0xFFFF};
static struct eif_par_types par159 = {159, ptf159, (uint16) 1, (uint16) 0, (char) 0};

/* COMPARABLE */
static EIF_TYPE_INDEX ptf160[] = {159,0xFFFF};
static struct eif_par_types par160 = {160, ptf160, (uint16) 1, (uint16) 0, (char) 0};

/* KL_COMPARABLE */
static EIF_TYPE_INDEX ptf161[] = {160,0xFFFF};
static struct eif_par_types par161 = {161, ptf161, (uint16) 1, (uint16) 0, (char) 0};

/* LX_RULE */
static EIF_TYPE_INDEX ptf162[] = {161,0xFFFF};
static struct eif_par_types par162 = {162, ptf162, (uint16) 1, (uint16) 0, (char) 0};

/* PLATFORM */
static EIF_TYPE_INDEX ptf163[] = {0,0xFFFF};
static struct eif_par_types par163 = {163, ptf163, (uint16) 1, (uint16) 0, (char) 0};

/* KL_PLATFORM */
static EIF_TYPE_INDEX ptf164[] = {57,0xFFF7,163,0xFFFF};
static struct eif_par_types par164 = {164, ptf164, (uint16) 2, (uint16) 0, (char) 0};

/* YY_BUFFER */
static EIF_TYPE_INDEX ptf165[] = {0,0xFFFF};
static struct eif_par_types par165 = {165, ptf165, (uint16) 1, (uint16) 0, (char) 0};

/* YY_UTF8_BUFFER */
static EIF_TYPE_INDEX ptf166[] = {165,0xFFFF};
static struct eif_par_types par166 = {166, ptf166, (uint16) 1, (uint16) 0, (char) 0};

/* YY_UNICODE_BUFFER */
static EIF_TYPE_INDEX ptf167[] = {165,0xFFFF};
static struct eif_par_types par167 = {167, ptf167, (uint16) 1, (uint16) 0, (char) 0};

/* YY_FILE_BUFFER */
static EIF_TYPE_INDEX ptf168[] = {165,0xFFF7,146,0xFFFF};
static struct eif_par_types par168 = {168, ptf168, (uint16) 2, (uint16) 0, (char) 0};

/* YY_UTF8_FILE_BUFFER */
static EIF_TYPE_INDEX ptf169[] = {168,0xFFF7,166,0xFFFF};
static struct eif_par_types par169 = {169, ptf169, (uint16) 2, (uint16) 0, (char) 0};

/* YY_UNICODE_FILE_BUFFER */
static EIF_TYPE_INDEX ptf170[] = {167,0xFFF7,168,0xFFFF};
static struct eif_par_types par170 = {170, ptf170, (uint16) 2, (uint16) 0, (char) 0};

/* CURSOR */
static EIF_TYPE_INDEX ptf171[] = {0,0xFFFF};
static struct eif_par_types par171 = {171, ptf171, (uint16) 1, (uint16) 0, (char) 0};

/* LINKED_LIST_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf172[] = {171,0xFFFF};
static struct eif_par_types par172 = {172, ptf172, (uint16) 1, (uint16) 1, (char) 0};

/* LINKED_LIST_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf173[] = {171,0xFFFF};
static struct eif_par_types par173 = {173, ptf173, (uint16) 1, (uint16) 1, (char) 0};

/* HASH_TABLE_CURSOR */
static EIF_TYPE_INDEX ptf174[] = {171,0xFFFF};
static struct eif_par_types par174 = {174, ptf174, (uint16) 1, (uint16) 0, (char) 0};

/* ARRAYED_LIST_CURSOR */
static EIF_TYPE_INDEX ptf175[] = {171,0xFFFF};
static struct eif_par_types par175 = {175, ptf175, (uint16) 1, (uint16) 0, (char) 0};

/* EXCEPTION_MANAGER_FACTORY */
static EIF_TYPE_INDEX ptf176[] = {0,0xFFFF};
static struct eif_par_types par176 = {176, ptf176, (uint16) 1, (uint16) 0, (char) 0};

/* EXCEPTIONS */
static EIF_TYPE_INDEX ptf177[] = {99,0xFFF7,176,0xFFFF};
static struct eif_par_types par177 = {177, ptf177, (uint16) 2, (uint16) 0, (char) 0};

/* KL_EXCEPTIONS */
static EIF_TYPE_INDEX ptf178[] = {87,0xFFF7,177,0xFFFF};
static struct eif_par_types par178 = {178, ptf178, (uint16) 2, (uint16) 0, (char) 0};

/* EXCEPTION */
static EIF_TYPE_INDEX ptf179[] = {176,0xFFFF};
static struct eif_par_types par179 = {179, ptf179, (uint16) 1, (uint16) 0, (char) 0};

/* DEVELOPER_EXCEPTION */
static EIF_TYPE_INDEX ptf180[] = {179,0xFFFF};
static struct eif_par_types par180 = {180, ptf180, (uint16) 1, (uint16) 0, (char) 0};

/* CONVERSION_FAILURE */
static EIF_TYPE_INDEX ptf181[] = {180,0xFFFF};
static struct eif_par_types par181 = {181, ptf181, (uint16) 1, (uint16) 0, (char) 0};

/* MACHINE_EXCEPTION */
static EIF_TYPE_INDEX ptf182[] = {179,0xFFFF};
static struct eif_par_types par182 = {182, ptf182, (uint16) 1, (uint16) 0, (char) 0};

/* HARDWARE_EXCEPTION */
static EIF_TYPE_INDEX ptf183[] = {182,0xFFFF};
static struct eif_par_types par183 = {183, ptf183, (uint16) 1, (uint16) 0, (char) 0};

/* FLOATING_POINT_FAILURE */
static EIF_TYPE_INDEX ptf184[] = {183,0xFFFF};
static struct eif_par_types par184 = {184, ptf184, (uint16) 1, (uint16) 0, (char) 0};

/* OPERATING_SYSTEM_EXCEPTION */
static EIF_TYPE_INDEX ptf185[] = {182,0xFFFF};
static struct eif_par_types par185 = {185, ptf185, (uint16) 1, (uint16) 0, (char) 0};

/* OPERATING_SYSTEM_SIGNAL_FAILURE */
static EIF_TYPE_INDEX ptf186[] = {185,0xFFFF};
static struct eif_par_types par186 = {186, ptf186, (uint16) 1, (uint16) 0, (char) 0};

/* COM_FAILURE */
static EIF_TYPE_INDEX ptf187[] = {185,0xFFFF};
static struct eif_par_types par187 = {187, ptf187, (uint16) 1, (uint16) 0, (char) 0};

/* OPERATING_SYSTEM_FAILURE */
static EIF_TYPE_INDEX ptf188[] = {185,0xFFFF};
static struct eif_par_types par188 = {188, ptf188, (uint16) 1, (uint16) 0, (char) 0};

/* OBSOLETE_EXCEPTION */
static EIF_TYPE_INDEX ptf189[] = {179,0xFFFF};
static struct eif_par_types par189 = {189, ptf189, (uint16) 1, (uint16) 0, (char) 0};

/* EXCEPTION_IN_SIGNAL_HANDLER_FAILURE */
static EIF_TYPE_INDEX ptf190[] = {189,0xFFFF};
static struct eif_par_types par190 = {190, ptf190, (uint16) 1, (uint16) 0, (char) 0};

/* RESUMPTION_FAILURE */
static EIF_TYPE_INDEX ptf191[] = {189,0xFFFF};
static struct eif_par_types par191 = {191, ptf191, (uint16) 1, (uint16) 0, (char) 0};

/* RESCUE_FAILURE */
static EIF_TYPE_INDEX ptf192[] = {189,0xFFFF};
static struct eif_par_types par192 = {192, ptf192, (uint16) 1, (uint16) 0, (char) 0};

/* SYS_EXCEPTION */
static EIF_TYPE_INDEX ptf193[] = {179,0xFFFF};
static struct eif_par_types par193 = {193, ptf193, (uint16) 1, (uint16) 0, (char) 0};

/* EIFFEL_RUNTIME_PANIC */
static EIF_TYPE_INDEX ptf194[] = {193,0xFFFF};
static struct eif_par_types par194 = {194, ptf194, (uint16) 1, (uint16) 0, (char) 0};

/* OLD_VIOLATION */
static EIF_TYPE_INDEX ptf195[] = {193,0xFFFF};
static struct eif_par_types par195 = {195, ptf195, (uint16) 1, (uint16) 0, (char) 0};

/* EIF_EXCEPTION */
static EIF_TYPE_INDEX ptf196[] = {193,0xFFFF};
static struct eif_par_types par196 = {196, ptf196, (uint16) 1, (uint16) 0, (char) 0};

/* EIFFEL_RUNTIME_EXCEPTION */
static EIF_TYPE_INDEX ptf197[] = {196,0xFFFF};
static struct eif_par_types par197 = {197, ptf197, (uint16) 1, (uint16) 0, (char) 0};

/* EXTERNAL_FAILURE */
static EIF_TYPE_INDEX ptf198[] = {197,0xFFFF};
static struct eif_par_types par198 = {198, ptf198, (uint16) 1, (uint16) 0, (char) 0};

/* NO_MORE_MEMORY */
static EIF_TYPE_INDEX ptf199[] = {197,0xFFFF};
static struct eif_par_types par199 = {199, ptf199, (uint16) 1, (uint16) 0, (char) 0};

/* DATA_EXCEPTION */
static EIF_TYPE_INDEX ptf200[] = {197,0xFFFF};
static struct eif_par_types par200 = {200, ptf200, (uint16) 1, (uint16) 0, (char) 0};

/* IO_FAILURE */
static EIF_TYPE_INDEX ptf201[] = {200,0xFFFF};
static struct eif_par_types par201 = {201, ptf201, (uint16) 1, (uint16) 0, (char) 0};

/* SERIALIZATION_FAILURE */
static EIF_TYPE_INDEX ptf202[] = {200,0xFFFF};
static struct eif_par_types par202 = {202, ptf202, (uint16) 1, (uint16) 0, (char) 0};

/* MISMATCH_FAILURE */
static EIF_TYPE_INDEX ptf203[] = {200,0xFFFF};
static struct eif_par_types par203 = {203, ptf203, (uint16) 1, (uint16) 0, (char) 0};

/* LANGUAGE_EXCEPTION */
static EIF_TYPE_INDEX ptf204[] = {196,0xFFFF};
static struct eif_par_types par204 = {204, ptf204, (uint16) 1, (uint16) 0, (char) 0};

/* VOID_ASSIGNED_TO_EXPANDED */
static EIF_TYPE_INDEX ptf205[] = {204,0xFFFF};
static struct eif_par_types par205 = {205, ptf205, (uint16) 1, (uint16) 0, (char) 0};

/* BAD_INSPECT_VALUE */
static EIF_TYPE_INDEX ptf206[] = {204,0xFFFF};
static struct eif_par_types par206 = {206, ptf206, (uint16) 1, (uint16) 0, (char) 0};

/* ROUTINE_FAILURE */
static EIF_TYPE_INDEX ptf207[] = {204,0xFFFF};
static struct eif_par_types par207 = {207, ptf207, (uint16) 1, (uint16) 0, (char) 0};

/* VOID_TARGET */
static EIF_TYPE_INDEX ptf208[] = {204,0xFFFF};
static struct eif_par_types par208 = {208, ptf208, (uint16) 1, (uint16) 0, (char) 0};

/* EIFFELSTUDIO_SPECIFIC_LANGUAGE_EXCEPTION */
static EIF_TYPE_INDEX ptf209[] = {204,0xFFFF};
static struct eif_par_types par209 = {209, ptf209, (uint16) 1, (uint16) 0, (char) 0};

/* CREATE_ON_DEFERRED */
static EIF_TYPE_INDEX ptf210[] = {209,0xFFFF};
static struct eif_par_types par210 = {210, ptf210, (uint16) 1, (uint16) 0, (char) 0};

/* ADDRESS_APPLIED_TO_MELTED_FEATURE */
static EIF_TYPE_INDEX ptf211[] = {209,0xFFFF};
static struct eif_par_types par211 = {211, ptf211, (uint16) 1, (uint16) 0, (char) 0};

/* ASSERTION_VIOLATION */
static EIF_TYPE_INDEX ptf212[] = {179,0xFFFF};
static struct eif_par_types par212 = {212, ptf212, (uint16) 1, (uint16) 0, (char) 0};

/* LOOP_INVARIANT_VIOLATION */
static EIF_TYPE_INDEX ptf213[] = {212,0xFFFF};
static struct eif_par_types par213 = {213, ptf213, (uint16) 1, (uint16) 0, (char) 0};

/* VARIANT_VIOLATION */
static EIF_TYPE_INDEX ptf214[] = {212,0xFFFF};
static struct eif_par_types par214 = {214, ptf214, (uint16) 1, (uint16) 0, (char) 0};

/* CHECK_VIOLATION */
static EIF_TYPE_INDEX ptf215[] = {212,0xFFFF};
static struct eif_par_types par215 = {215, ptf215, (uint16) 1, (uint16) 0, (char) 0};

/* INVARIANT_VIOLATION */
static EIF_TYPE_INDEX ptf216[] = {212,0xFFFF};
static struct eif_par_types par216 = {216, ptf216, (uint16) 1, (uint16) 0, (char) 0};

/* POSTCONDITION_VIOLATION */
static EIF_TYPE_INDEX ptf217[] = {212,0xFFFF};
static struct eif_par_types par217 = {217, ptf217, (uint16) 1, (uint16) 0, (char) 0};

/* PRECONDITION_VIOLATION */
static EIF_TYPE_INDEX ptf218[] = {212,0xFFFF};
static struct eif_par_types par218 = {218, ptf218, (uint16) 1, (uint16) 0, (char) 0};

/* DISPOSABLE */
static EIF_TYPE_INDEX ptf219[] = {0,0xFFFF};
static struct eif_par_types par219 = {219, ptf219, (uint16) 1, (uint16) 0, (char) 0};

/* MANAGED_POINTER */
static EIF_TYPE_INDEX ptf220[] = {219,0xFFF7,163,0xFFFF};
static struct eif_par_types par220 = {220, ptf220, (uint16) 2, (uint16) 0, (char) 0};

/* UT_IMPORTED_FORMATTERS */
static EIF_TYPE_INDEX ptf221[] = {0,0xFFFF};
static struct eif_par_types par221 = {221, ptf221, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_ARGUMENTS */
static EIF_TYPE_INDEX ptf222[] = {0,0xFFFF};
static struct eif_par_types par222 = {222, ptf222, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_EXCEPTIONS */
static EIF_TYPE_INDEX ptf223[] = {0,0xFFFF};
static struct eif_par_types par223 = {223, ptf223, (uint16) 1, (uint16) 0, (char) 0};

/* AP_DISPLAY_HELP_FLAG */
static EIF_TYPE_INDEX ptf224[] = {116,0xFFF7,223,0xFFFF};
static struct eif_par_types par224 = {224, ptf224, (uint16) 2, (uint16) 0, (char) 0};

/* KL_EQUALITY_TESTER [G#1] */
static EIF_TYPE_INDEX ptf225[] = {0,0xFFFF};
static struct eif_par_types par225 = {225, ptf225, (uint16) 1, (uint16) 1, (char) 0};

/* KL_EQUALITY_TESTER [INTEGER_32] */
static EIF_TYPE_INDEX ptf226[] = {0,0xFFFF};
static struct eif_par_types par226 = {226, ptf226, (uint16) 1, (uint16) 1, (char) 0};

/* KL_EQUALITY_TESTER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf227[] = {0,0xFFFF};
static struct eif_par_types par227 = {227, ptf227, (uint16) 1, (uint16) 1, (char) 0};

/* KL_EQUALITY_TESTER [BOOLEAN] */
static EIF_TYPE_INDEX ptf228[] = {0,0xFFFF};
static struct eif_par_types par228 = {228, ptf228, (uint16) 1, (uint16) 1, (char) 0};

/* KL_EQUALITY_TESTER [NATURAL_64] */
static EIF_TYPE_INDEX ptf229[] = {0,0xFFFF};
static struct eif_par_types par229 = {229, ptf229, (uint16) 1, (uint16) 1, (char) 0};

/* KL_EQUALITY_TESTER [NATURAL_32] */
static EIF_TYPE_INDEX ptf230[] = {0,0xFFFF};
static struct eif_par_types par230 = {230, ptf230, (uint16) 1, (uint16) 1, (char) 0};

/* KL_STRING_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf231[] = {225,0xFF01,914,0xFFFF};
static struct eif_par_types par231 = {231, ptf231, (uint16) 1, (uint16) 0, (char) 0};

/* KL_COMPARATOR [G#1] */
static EIF_TYPE_INDEX ptf232[] = {127,0xFFF8,1,0xFFF7,225,0xFFF8,1,0xFFFF};
static struct eif_par_types par232 = {232, ptf232, (uint16) 2, (uint16) 1, (char) 0};

/* KL_COMPARATOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf233[] = {128,834,0xFFF7,226,834,0xFFFF};
static struct eif_par_types par233 = {233, ptf233, (uint16) 2, (uint16) 1, (char) 0};

/* KL_COMPARABLE_COMPARATOR [G#1] */
static EIF_TYPE_INDEX ptf234[] = {232,0xFFF8,1,0xFFFF};
static struct eif_par_types par234 = {234, ptf234, (uint16) 1, (uint16) 1, (char) 0};

/* KL_COMPARABLE_COMPARATOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf235[] = {233,834,0xFFFF};
static struct eif_par_types par235 = {235, ptf235, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SHARED_STRING_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf236[] = {0,0xFFFF};
static struct eif_par_types par236 = {236, ptf236, (uint16) 1, (uint16) 0, (char) 0};

/* AP_ENUMERATION_OPTION */
static EIF_TYPE_INDEX ptf237[] = {121,0xFFF7,236,0xFFFF};
static struct eif_par_types par237 = {237, ptf237, (uint16) 2, (uint16) 0, (char) 0};

/* AP_BOOLEAN_OPTION */
static EIF_TYPE_INDEX ptf238[] = {118,867,0xFFF7,236,0xFFFF};
static struct eif_par_types par238 = {238, ptf238, (uint16) 2, (uint16) 0, (char) 0};

/* UC_IMPORTED_UNICODE_ROUTINES */
static EIF_TYPE_INDEX ptf239[] = {0,0xFFFF};
static struct eif_par_types par239 = {239, ptf239, (uint16) 1, (uint16) 0, (char) 0};

/* REFLECTOR_CONSTANTS */
static EIF_TYPE_INDEX ptf240[] = {0,0xFFFF};
static struct eif_par_types par240 = {240, ptf240, (uint16) 1, (uint16) 0, (char) 0};

/* REFLECTED_OBJECT */
static EIF_TYPE_INDEX ptf241[] = {240,0xFFFF};
static struct eif_par_types par241 = {241, ptf241, (uint16) 1, (uint16) 0, (char) 0};

/* REFLECTOR */
static EIF_TYPE_INDEX ptf242[] = {93,0xFFF7,240,0xFFFF};
static struct eif_par_types par242 = {242, ptf242, (uint16) 2, (uint16) 0, (char) 0};

/* INTERNAL */
static EIF_TYPE_INDEX ptf243[] = {242,0xFFF7,84,0xFFFF};
static struct eif_par_types par243 = {243, ptf243, (uint16) 2, (uint16) 0, (char) 0};

/* RT_DBG_INTERNAL */
static EIF_TYPE_INDEX ptf244[] = {240,0xFFFF};
static struct eif_par_types par244 = {244, ptf244, (uint16) 1, (uint16) 0, (char) 0};

/* REFLECTED_COPY_SEMANTICS_OBJECT */
static EIF_TYPE_INDEX ptf245[] = {241,0xFFF7,240,0xFFFF};
static struct eif_par_types par245 = {245, ptf245, (uint16) 2, (uint16) 0, (char) 0};

/* REFLECTED_REFERENCE_OBJECT */
static EIF_TYPE_INDEX ptf246[] = {241,0xFFF7,240,0xFFFF};
static struct eif_par_types par246 = {246, ptf246, (uint16) 2, (uint16) 0, (char) 0};

/* TO_SPECIAL [G#1] */
static EIF_TYPE_INDEX ptf247[] = {0,0xFFFF};
static struct eif_par_types par247 = {247, ptf247, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [INTEGER_32] */
static EIF_TYPE_INDEX ptf248[] = {0,0xFFFF};
static struct eif_par_types par248 = {248, ptf248, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [POINTER] */
static EIF_TYPE_INDEX ptf249[] = {0,0xFFFF};
static struct eif_par_types par249 = {249, ptf249, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [BOOLEAN] */
static EIF_TYPE_INDEX ptf250[] = {0,0xFFFF};
static struct eif_par_types par250 = {250, ptf250, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [CHARACTER_32] */
static EIF_TYPE_INDEX ptf251[] = {0,0xFFFF};
static struct eif_par_types par251 = {251, ptf251, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [NATURAL_64] */
static EIF_TYPE_INDEX ptf252[] = {0,0xFFFF};
static struct eif_par_types par252 = {252, ptf252, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [CHARACTER_8] */
static EIF_TYPE_INDEX ptf253[] = {0,0xFFFF};
static struct eif_par_types par253 = {253, ptf253, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [NATURAL_8] */
static EIF_TYPE_INDEX ptf254[] = {0,0xFFFF};
static struct eif_par_types par254 = {254, ptf254, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [NATURAL_16] */
static EIF_TYPE_INDEX ptf255[] = {0,0xFFFF};
static struct eif_par_types par255 = {255, ptf255, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [REAL_32] */
static EIF_TYPE_INDEX ptf256[] = {0,0xFFFF};
static struct eif_par_types par256 = {256, ptf256, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [REAL_64] */
static EIF_TYPE_INDEX ptf257[] = {0,0xFFFF};
static struct eif_par_types par257 = {257, ptf257, (uint16) 1, (uint16) 1, (char) 0};

/* TO_SPECIAL [NATURAL_32] */
static EIF_TYPE_INDEX ptf258[] = {0,0xFFFF};
static struct eif_par_types par258 = {258, ptf258, (uint16) 1, (uint16) 1, (char) 0};

/* NATIVE_STRING_HANDLER */
static EIF_TYPE_INDEX ptf259[] = {0,0xFFFF};
static struct eif_par_types par259 = {259, ptf259, (uint16) 1, (uint16) 0, (char) 0};

/* EXECUTION_ENVIRONMENT */
static EIF_TYPE_INDEX ptf260[] = {259,0xFFFF};
static struct eif_par_types par260 = {260, ptf260, (uint16) 1, (uint16) 0, (char) 0};

/* NATIVE_STRING */
static EIF_TYPE_INDEX ptf261[] = {259,0xFFFF};
static struct eif_par_types par261 = {261, ptf261, (uint16) 1, (uint16) 0, (char) 0};

/* DIRECTORY */
static EIF_TYPE_INDEX ptf262[] = {219,0xFFF7,259,0xFFFF};
static struct eif_par_types par262 = {262, ptf262, (uint16) 2, (uint16) 0, (char) 0};

/* FILE_INFO */
static EIF_TYPE_INDEX ptf263[] = {254,852,0xFFF7,259,0xFFFF};
static struct eif_par_types par263 = {263, ptf263, (uint16) 2, (uint16) 0, (char) 0};

/* UNIX_FILE_INFO */
static EIF_TYPE_INDEX ptf264[] = {263,0xFFFF};
static struct eif_par_types par264 = {264, ptf264, (uint16) 1, (uint16) 0, (char) 0};

/* KL_SHARED_STANDARD_FILES */
static EIF_TYPE_INDEX ptf265[] = {0,0xFFFF};
static struct eif_par_types par265 = {265, ptf265, (uint16) 1, (uint16) 0, (char) 0};

/* GELEX */
static EIF_TYPE_INDEX ptf266[] = {106,0xFFF7,265,0xFFF7,223,0xFFF7,222,0xFFFF};
static struct eif_par_types par266 = {266, ptf266, (uint16) 4, (uint16) 0, (char) 0};

/* KL_IMPORTED_SPECIAL_ROUTINES */
static EIF_TYPE_INDEX ptf267[] = {0,0xFFFF};
static struct eif_par_types par267 = {267, ptf267, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_HANDLER */
static EIF_TYPE_INDEX ptf268[] = {0,0xFFFF};
static struct eif_par_types par268 = {268, ptf268, (uint16) 1, (uint16) 0, (char) 0};

/* KL_UNICODE_CHARACTER_BUFFER */
static EIF_TYPE_INDEX ptf269[] = {92,0xFFF7,268,0xFFFF};
static struct eif_par_types par269 = {269, ptf269, (uint16) 2, (uint16) 0, (char) 0};

/* KL_CHARACTER_BUFFER */
static EIF_TYPE_INDEX ptf270[] = {92,0xFFF7,268,0xFFFF};
static struct eif_par_types par270 = {270, ptf270, (uint16) 2, (uint16) 0, (char) 0};

/* C_STRING */
static EIF_TYPE_INDEX ptf271[] = {268,0xFFFF};
static struct eif_par_types par271 = {271, ptf271, (uint16) 1, (uint16) 0, (char) 0};

/* IO_MEDIUM */
static EIF_TYPE_INDEX ptf272[] = {219,0xFFF7,268,0xFFFF};
static struct eif_par_types par272 = {272, ptf272, (uint16) 2, (uint16) 0, (char) 0};

/* DEBUG_OUTPUT */
static EIF_TYPE_INDEX ptf273[] = {0,0xFFFF};
static struct eif_par_types par273 = {273, ptf273, (uint16) 1, (uint16) 0, (char) 0};

/* RT_DBG_CALL_RECORD */
static EIF_TYPE_INDEX ptf274[] = {273,0xFFFF};
static struct eif_par_types par274 = {274, ptf274, (uint16) 1, (uint16) 0, (char) 0};

/* ABSTRACT_SPECIAL */
static EIF_TYPE_INDEX ptf275[] = {273,0xFFFF};
static struct eif_par_types par275 = {275, ptf275, (uint16) 1, (uint16) 0, (char) 0};

/* RT_DBG_VALUE_RECORD */
static EIF_TYPE_INDEX ptf276[] = {273,0xFFF7,136,0xFFF7,244,0xFFFF};
static struct eif_par_types par276 = {276, ptf276, (uint16) 3, (uint16) 0, (char) 0};

/* RT_DBG_LOCAL_RECORD [G#1] */
static EIF_TYPE_INDEX ptf277[] = {276,0xFFFF};
static struct eif_par_types par277 = {277, ptf277, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [POINTER] */
static EIF_TYPE_INDEX ptf278[] = {276,0xFFFF};
static struct eif_par_types par278 = {278, ptf278, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [REAL_64] */
static EIF_TYPE_INDEX ptf279[] = {276,0xFFFF};
static struct eif_par_types par279 = {279, ptf279, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [NATURAL_8] */
static EIF_TYPE_INDEX ptf280[] = {276,0xFFFF};
static struct eif_par_types par280 = {280, ptf280, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [NATURAL_16] */
static EIF_TYPE_INDEX ptf281[] = {276,0xFFFF};
static struct eif_par_types par281 = {281, ptf281, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [NATURAL_32] */
static EIF_TYPE_INDEX ptf282[] = {276,0xFFFF};
static struct eif_par_types par282 = {282, ptf282, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [INTEGER_8] */
static EIF_TYPE_INDEX ptf283[] = {276,0xFFFF};
static struct eif_par_types par283 = {283, ptf283, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [INTEGER_32] */
static EIF_TYPE_INDEX ptf284[] = {276,0xFFFF};
static struct eif_par_types par284 = {284, ptf284, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [CHARACTER_8] */
static EIF_TYPE_INDEX ptf285[] = {276,0xFFFF};
static struct eif_par_types par285 = {285, ptf285, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [CHARACTER_32] */
static EIF_TYPE_INDEX ptf286[] = {276,0xFFFF};
static struct eif_par_types par286 = {286, ptf286, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [NATURAL_64] */
static EIF_TYPE_INDEX ptf287[] = {276,0xFFFF};
static struct eif_par_types par287 = {287, ptf287, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [INTEGER_64] */
static EIF_TYPE_INDEX ptf288[] = {276,0xFFFF};
static struct eif_par_types par288 = {288, ptf288, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [REAL_32] */
static EIF_TYPE_INDEX ptf289[] = {276,0xFFFF};
static struct eif_par_types par289 = {289, ptf289, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [INTEGER_16] */
static EIF_TYPE_INDEX ptf290[] = {276,0xFFFF};
static struct eif_par_types par290 = {290, ptf290, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_LOCAL_RECORD [BOOLEAN] */
static EIF_TYPE_INDEX ptf291[] = {276,0xFFFF};
static struct eif_par_types par291 = {291, ptf291, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [G#1] */
static EIF_TYPE_INDEX ptf292[] = {276,0xFFFF};
static struct eif_par_types par292 = {292, ptf292, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [INTEGER_64] */
static EIF_TYPE_INDEX ptf293[] = {276,0xFFFF};
static struct eif_par_types par293 = {293, ptf293, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [INTEGER_16] */
static EIF_TYPE_INDEX ptf294[] = {276,0xFFFF};
static struct eif_par_types par294 = {294, ptf294, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [NATURAL_64] */
static EIF_TYPE_INDEX ptf295[] = {276,0xFFFF};
static struct eif_par_types par295 = {295, ptf295, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [NATURAL_32] */
static EIF_TYPE_INDEX ptf296[] = {276,0xFFFF};
static struct eif_par_types par296 = {296, ptf296, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [NATURAL_16] */
static EIF_TYPE_INDEX ptf297[] = {276,0xFFFF};
static struct eif_par_types par297 = {297, ptf297, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [NATURAL_8] */
static EIF_TYPE_INDEX ptf298[] = {276,0xFFFF};
static struct eif_par_types par298 = {298, ptf298, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [REAL_32] */
static EIF_TYPE_INDEX ptf299[] = {276,0xFFFF};
static struct eif_par_types par299 = {299, ptf299, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [REAL_64] */
static EIF_TYPE_INDEX ptf300[] = {276,0xFFFF};
static struct eif_par_types par300 = {300, ptf300, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [POINTER] */
static EIF_TYPE_INDEX ptf301[] = {276,0xFFFF};
static struct eif_par_types par301 = {301, ptf301, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [BOOLEAN] */
static EIF_TYPE_INDEX ptf302[] = {276,0xFFFF};
static struct eif_par_types par302 = {302, ptf302, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [CHARACTER_32] */
static EIF_TYPE_INDEX ptf303[] = {276,0xFFFF};
static struct eif_par_types par303 = {303, ptf303, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [CHARACTER_8] */
static EIF_TYPE_INDEX ptf304[] = {276,0xFFFF};
static struct eif_par_types par304 = {304, ptf304, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [INTEGER_32] */
static EIF_TYPE_INDEX ptf305[] = {276,0xFFFF};
static struct eif_par_types par305 = {305, ptf305, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_ATTRIBUTE_RECORD [INTEGER_8] */
static EIF_TYPE_INDEX ptf306[] = {276,0xFFFF};
static struct eif_par_types par306 = {306, ptf306, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [G#1] */
static EIF_TYPE_INDEX ptf307[] = {276,0xFFFF};
static struct eif_par_types par307 = {307, ptf307, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [CHARACTER_32] */
static EIF_TYPE_INDEX ptf308[] = {276,0xFFFF};
static struct eif_par_types par308 = {308, ptf308, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [INTEGER_32] */
static EIF_TYPE_INDEX ptf309[] = {276,0xFFFF};
static struct eif_par_types par309 = {309, ptf309, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [NATURAL_8] */
static EIF_TYPE_INDEX ptf310[] = {276,0xFFFF};
static struct eif_par_types par310 = {310, ptf310, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [REAL_64] */
static EIF_TYPE_INDEX ptf311[] = {276,0xFFFF};
static struct eif_par_types par311 = {311, ptf311, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [REAL_32] */
static EIF_TYPE_INDEX ptf312[] = {276,0xFFFF};
static struct eif_par_types par312 = {312, ptf312, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [POINTER] */
static EIF_TYPE_INDEX ptf313[] = {276,0xFFFF};
static struct eif_par_types par313 = {313, ptf313, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [BOOLEAN] */
static EIF_TYPE_INDEX ptf314[] = {276,0xFFFF};
static struct eif_par_types par314 = {314, ptf314, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [CHARACTER_8] */
static EIF_TYPE_INDEX ptf315[] = {276,0xFFFF};
static struct eif_par_types par315 = {315, ptf315, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [INTEGER_64] */
static EIF_TYPE_INDEX ptf316[] = {276,0xFFFF};
static struct eif_par_types par316 = {316, ptf316, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [INTEGER_8] */
static EIF_TYPE_INDEX ptf317[] = {276,0xFFFF};
static struct eif_par_types par317 = {317, ptf317, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [INTEGER_16] */
static EIF_TYPE_INDEX ptf318[] = {276,0xFFFF};
static struct eif_par_types par318 = {318, ptf318, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [NATURAL_32] */
static EIF_TYPE_INDEX ptf319[] = {276,0xFFFF};
static struct eif_par_types par319 = {319, ptf319, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [NATURAL_64] */
static EIF_TYPE_INDEX ptf320[] = {276,0xFFFF};
static struct eif_par_types par320 = {320, ptf320, (uint16) 1, (uint16) 1, (char) 0};

/* RT_DBG_FIELD_RECORD [NATURAL_16] */
static EIF_TYPE_INDEX ptf321[] = {276,0xFFFF};
static struct eif_par_types par321 = {321, ptf321, (uint16) 1, (uint16) 1, (char) 0};

/* NUMERIC */
static EIF_TYPE_INDEX ptf322[] = {273,0xFFFF};
static struct eif_par_types par322 = {322, ptf322, (uint16) 1, (uint16) 0, (char) 0};

/* ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf323[] = {0,0xFFFF};
static struct eif_par_types par323 = {323, ptf323, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf324[] = {0,0xFFFF};
static struct eif_par_types par324 = {324, ptf324, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf325[] = {0,0xFFFF};
static struct eif_par_types par325 = {325, ptf325, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf326[] = {0,0xFFFF};
static struct eif_par_types par326 = {326, ptf326, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf327[] = {0,0xFFFF};
static struct eif_par_types par327 = {327, ptf327, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf328[] = {0,0xFFFF};
static struct eif_par_types par328 = {328, ptf328, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf329[] = {0,0xFFFF};
static struct eif_par_types par329 = {329, ptf329, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf330[] = {0,0xFFFF};
static struct eif_par_types par330 = {330, ptf330, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf331[] = {0,0xFFFF};
static struct eif_par_types par331 = {331, ptf331, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf332[] = {0,0xFFFF};
static struct eif_par_types par332 = {332, ptf332, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf333[] = {0,0xFFFF};
static struct eif_par_types par333 = {333, ptf333, (uint16) 1, (uint16) 1, (char) 0};

/* ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf334[] = {0,0xFFFF};
static struct eif_par_types par334 = {334, ptf334, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_QUEUE_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf335[] = {323,0xFFF8,1,0xFFFF};
static struct eif_par_types par335 = {335, ptf335, (uint16) 1, (uint16) 1, (char) 0};

/* FILE_ITERATION_CURSOR */
static EIF_TYPE_INDEX ptf336[] = {219,0xFFF7,325,864,0xFFFF};
static struct eif_par_types par336 = {336, ptf336, (uint16) 2, (uint16) 0, (char) 0};

/* TABLE_ITERATION_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf337[] = {323,0xFFF8,1,0xFFFF};
static struct eif_par_types par337 = {337, ptf337, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERATION_CURSOR [POINTER, G#2] */
static EIF_TYPE_INDEX ptf338[] = {326,900,0xFFFF};
static struct eif_par_types par338 = {338, ptf338, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERATION_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf339[] = {323,0xFFF8,1,0xFFFF};
static struct eif_par_types par339 = {339, ptf339, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERATION_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf340[] = {324,834,0xFFFF};
static struct eif_par_types par340 = {340, ptf340, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERATION_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf341[] = {324,834,0xFFFF};
static struct eif_par_types par341 = {341, ptf341, (uint16) 1, (uint16) 2, (char) 0};

/* ITERABLE [G#1] */
static EIF_TYPE_INDEX ptf342[] = {0,0xFFFF};
static struct eif_par_types par342 = {342, ptf342, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf343[] = {0,0xFFFF};
static struct eif_par_types par343 = {343, ptf343, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf344[] = {0,0xFFFF};
static struct eif_par_types par344 = {344, ptf344, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [POINTER] */
static EIF_TYPE_INDEX ptf345[] = {0,0xFFFF};
static struct eif_par_types par345 = {345, ptf345, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf346[] = {0,0xFFFF};
static struct eif_par_types par346 = {346, ptf346, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf347[] = {0,0xFFFF};
static struct eif_par_types par347 = {347, ptf347, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf348[] = {0,0xFFFF};
static struct eif_par_types par348 = {348, ptf348, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [NATURAL_8] */
static EIF_TYPE_INDEX ptf349[] = {0,0xFFFF};
static struct eif_par_types par349 = {349, ptf349, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [NATURAL_16] */
static EIF_TYPE_INDEX ptf350[] = {0,0xFFFF};
static struct eif_par_types par350 = {350, ptf350, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [REAL_32] */
static EIF_TYPE_INDEX ptf351[] = {0,0xFFFF};
static struct eif_par_types par351 = {351, ptf351, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [REAL_64] */
static EIF_TYPE_INDEX ptf352[] = {0,0xFFFF};
static struct eif_par_types par352 = {352, ptf352, (uint16) 1, (uint16) 1, (char) 0};

/* ITERABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf353[] = {0,0xFFFF};
static struct eif_par_types par353 = {353, ptf353, (uint16) 1, (uint16) 1, (char) 0};

/* ARGUMENTS_32 */
static EIF_TYPE_INDEX ptf354[] = {342,0xFF01,910,0xFFFF};
static struct eif_par_types par354 = {354, ptf354, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_ITERATION_CURSOR */
static EIF_TYPE_INDEX ptf355[] = {328,861,0xFFF7,347,861,0xFFFF};
static struct eif_par_types par355 = {355, ptf355, (uint16) 2, (uint16) 0, (char) 0};

/* ARGUMENTS */
static EIF_TYPE_INDEX ptf356[] = {342,0xFF01,914,0xFFFF};
static struct eif_par_types par356 = {356, ptf356, (uint16) 1, (uint16) 0, (char) 0};

/* KL_ARGUMENTS */
static EIF_TYPE_INDEX ptf357[] = {356,0xFFFF};
static struct eif_par_types par357 = {357, ptf357, (uint16) 1, (uint16) 0, (char) 0};

/* TABLE_ITERABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf358[] = {342,0xFFF8,1,0xFFFF};
static struct eif_par_types par358 = {358, ptf358, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERABLE [POINTER, G#2] */
static EIF_TYPE_INDEX ptf359[] = {345,900,0xFFFF};
static struct eif_par_types par359 = {359, ptf359, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf360[] = {342,0xFFF8,1,0xFFFF};
static struct eif_par_types par360 = {360, ptf360, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf361[] = {343,834,0xFFFF};
static struct eif_par_types par361 = {361, ptf361, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE_ITERABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf362[] = {343,834,0xFFFF};
static struct eif_par_types par362 = {362, ptf362, (uint16) 1, (uint16) 2, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf363[] = {323,0xFFF8,1,0xFFF7,342,0xFFF8,1,0xFFFF};
static struct eif_par_types par363 = {363, ptf363, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf364[] = {324,834,0xFFF7,343,834,0xFFFF};
static struct eif_par_types par364 = {364, ptf364, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf365[] = {325,864,0xFFF7,344,864,0xFFFF};
static struct eif_par_types par365 = {365, ptf365, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf366[] = {326,900,0xFFF7,345,900,0xFFFF};
static struct eif_par_types par366 = {366, ptf366, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf367[] = {327,867,0xFFF7,346,867,0xFFFF};
static struct eif_par_types par367 = {367, ptf367, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf368[] = {328,861,0xFFF7,347,861,0xFFFF};
static struct eif_par_types par368 = {368, ptf368, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf369[] = {329,843,0xFFF7,348,843,0xFFFF};
static struct eif_par_types par369 = {369, ptf369, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf370[] = {330,852,0xFFF7,349,852,0xFFFF};
static struct eif_par_types par370 = {370, ptf370, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf371[] = {331,849,0xFFF7,350,849,0xFFFF};
static struct eif_par_types par371 = {371, ptf371, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf372[] = {332,855,0xFFF7,351,855,0xFFFF};
static struct eif_par_types par372 = {372, ptf372, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf373[] = {333,858,0xFFF7,352,858,0xFFFF};
static struct eif_par_types par373 = {373, ptf373, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE_ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf374[] = {334,846,0xFFF7,353,846,0xFFFF};
static struct eif_par_types par374 = {374, ptf374, (uint16) 2, (uint16) 1, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf375[] = {363,0xFFF8,1,0xFFFF};
static struct eif_par_types par375 = {375, ptf375, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf376[] = {364,834,0xFFFF};
static struct eif_par_types par376 = {376, ptf376, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [CHARACTER_8, G#2] */
static EIF_TYPE_INDEX ptf377[] = {365,864,0xFFFF};
static struct eif_par_types par377 = {377, ptf377, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [POINTER, G#2] */
static EIF_TYPE_INDEX ptf378[] = {366,900,0xFFFF};
static struct eif_par_types par378 = {378, ptf378, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf379[] = {367,867,0xFFFF};
static struct eif_par_types par379 = {379, ptf379, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [CHARACTER_32, G#2] */
static EIF_TYPE_INDEX ptf380[] = {368,861,0xFFFF};
static struct eif_par_types par380 = {380, ptf380, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [NATURAL_64, G#2] */
static EIF_TYPE_INDEX ptf381[] = {369,843,0xFFFF};
static struct eif_par_types par381 = {381, ptf381, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf382[] = {370,852,0xFFFF};
static struct eif_par_types par382 = {382, ptf382, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [NATURAL_16, G#2] */
static EIF_TYPE_INDEX ptf383[] = {371,849,0xFFFF};
static struct eif_par_types par383 = {383, ptf383, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [REAL_32, G#2] */
static EIF_TYPE_INDEX ptf384[] = {372,855,0xFFFF};
static struct eif_par_types par384 = {384, ptf384, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [REAL_64, G#2] */
static EIF_TYPE_INDEX ptf385[] = {373,858,0xFFFF};
static struct eif_par_types par385 = {385, ptf385, (uint16) 1, (uint16) 2, (char) 0};

/* TYPED_INDEXABLE_ITERATION_CURSOR [NATURAL_32, G#2] */
static EIF_TYPE_INDEX ptf386[] = {374,846,0xFFFF};
static struct eif_par_types par386 = {386, ptf386, (uint16) 1, (uint16) 2, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf387[] = {375,0xFFF8,1,0xFF01,664,0xFFF8,1,0xFFFF};
static struct eif_par_types par387 = {387, ptf387, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf388[] = {376,834,0xFF01,665,834,0xFFFF};
static struct eif_par_types par388 = {388, ptf388, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf389[] = {377,864,0xFF01,666,864,0xFFFF};
static struct eif_par_types par389 = {389, ptf389, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf390[] = {378,900,0xFF01,667,900,0xFFFF};
static struct eif_par_types par390 = {390, ptf390, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf391[] = {379,867,0xFF01,668,867,0xFFFF};
static struct eif_par_types par391 = {391, ptf391, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf392[] = {380,861,0xFF01,669,861,0xFFFF};
static struct eif_par_types par392 = {392, ptf392, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf393[] = {381,843,0xFF01,670,843,0xFFFF};
static struct eif_par_types par393 = {393, ptf393, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf394[] = {382,852,0xFF01,671,852,0xFFFF};
static struct eif_par_types par394 = {394, ptf394, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf395[] = {383,849,0xFF01,672,849,0xFFFF};
static struct eif_par_types par395 = {395, ptf395, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf396[] = {384,855,0xFF01,673,855,0xFFFF};
static struct eif_par_types par396 = {396, ptf396, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf397[] = {385,858,0xFF01,674,858,0xFFFF};
static struct eif_par_types par397 = {397, ptf397, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE_ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf398[] = {386,846,0xFF01,675,846,0xFFFF};
static struct eif_par_types par398 = {398, ptf398, (uint16) 1, (uint16) 1, (char) 0};

/* LINKED_LIST_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf399[] = {387,0xFFF8,1,0xFFFF};
static struct eif_par_types par399 = {399, ptf399, (uint16) 1, (uint16) 1, (char) 0};

/* LINKED_LIST_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf400[] = {388,834,0xFFFF};
static struct eif_par_types par400 = {400, ptf400, (uint16) 1, (uint16) 1, (char) 0};

/* HASH_TABLE_ITERATION_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf401[] = {387,0xFFF8,1,0xFFF7,337,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par401 = {401, ptf401, (uint16) 2, (uint16) 2, (char) 0};

/* HASH_TABLE_ITERATION_CURSOR [POINTER, G#2] */
static EIF_TYPE_INDEX ptf402[] = {390,900,0xFFF7,338,900,0xFFF8,2,0xFFFF};
static struct eif_par_types par402 = {402, ptf402, (uint16) 2, (uint16) 2, (char) 0};

/* HASH_TABLE_ITERATION_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf403[] = {387,0xFFF8,1,0xFFF7,339,0xFFF8,1,834,0xFFFF};
static struct eif_par_types par403 = {403, ptf403, (uint16) 2, (uint16) 2, (char) 0};

/* HASH_TABLE_ITERATION_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf404[] = {388,834,0xFFF7,340,834,0xFFF8,2,0xFFFF};
static struct eif_par_types par404 = {404, ptf404, (uint16) 2, (uint16) 2, (char) 0};

/* HASH_TABLE_ITERATION_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf405[] = {388,834,0xFFF7,341,834,834,0xFFFF};
static struct eif_par_types par405 = {405, ptf405, (uint16) 2, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf406[] = {375,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par406 = {406, ptf406, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf407[] = {376,834,0xFFF8,2,0xFFFF};
static struct eif_par_types par407 = {407, ptf407, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [POINTER, G#2] */
static EIF_TYPE_INDEX ptf408[] = {378,900,0xFFF8,2,0xFFFF};
static struct eif_par_types par408 = {408, ptf408, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [BOOLEAN, G#2] */
static EIF_TYPE_INDEX ptf409[] = {379,867,0xFFF8,2,0xFFFF};
static struct eif_par_types par409 = {409, ptf409, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [CHARACTER_32, G#2] */
static EIF_TYPE_INDEX ptf410[] = {380,861,0xFFF8,2,0xFFFF};
static struct eif_par_types par410 = {410, ptf410, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [NATURAL_64, G#2] */
static EIF_TYPE_INDEX ptf411[] = {381,843,0xFFF8,2,0xFFFF};
static struct eif_par_types par411 = {411, ptf411, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [CHARACTER_8, G#2] */
static EIF_TYPE_INDEX ptf412[] = {377,864,0xFFF8,2,0xFFFF};
static struct eif_par_types par412 = {412, ptf412, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [NATURAL_8, G#2] */
static EIF_TYPE_INDEX ptf413[] = {382,852,0xFFF8,2,0xFFFF};
static struct eif_par_types par413 = {413, ptf413, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [NATURAL_16, G#2] */
static EIF_TYPE_INDEX ptf414[] = {383,849,0xFFF8,2,0xFFFF};
static struct eif_par_types par414 = {414, ptf414, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [REAL_32, G#2] */
static EIF_TYPE_INDEX ptf415[] = {384,855,0xFFF8,2,0xFFFF};
static struct eif_par_types par415 = {415, ptf415, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [REAL_64, G#2] */
static EIF_TYPE_INDEX ptf416[] = {385,858,0xFFF8,2,0xFFFF};
static struct eif_par_types par416 = {416, ptf416, (uint16) 1, (uint16) 2, (char) 0};

/* GENERAL_SPECIAL_ITERATION_CURSOR [NATURAL_32, G#2] */
static EIF_TYPE_INDEX ptf417[] = {386,846,0xFFF8,2,0xFFFF};
static struct eif_par_types par417 = {417, ptf417, (uint16) 1, (uint16) 2, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf418[] = {406,0xFFF8,1,0xFF01,773,0xFFF8,1,0xFFFF};
static struct eif_par_types par418 = {418, ptf418, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf419[] = {407,834,0xFF01,774,834,0xFFFF};
static struct eif_par_types par419 = {419, ptf419, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf420[] = {408,900,0xFF01,775,900,0xFFFF};
static struct eif_par_types par420 = {420, ptf420, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf421[] = {409,867,0xFF01,776,867,0xFFFF};
static struct eif_par_types par421 = {421, ptf421, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf422[] = {410,861,0xFF01,777,861,0xFFFF};
static struct eif_par_types par422 = {422, ptf422, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf423[] = {411,843,0xFF01,778,843,0xFFFF};
static struct eif_par_types par423 = {423, ptf423, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf424[] = {412,864,0xFF01,779,864,0xFFFF};
static struct eif_par_types par424 = {424, ptf424, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf425[] = {413,852,0xFF01,780,852,0xFFFF};
static struct eif_par_types par425 = {425, ptf425, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf426[] = {414,849,0xFF01,781,849,0xFFFF};
static struct eif_par_types par426 = {426, ptf426, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf427[] = {415,855,0xFF01,782,855,0xFFFF};
static struct eif_par_types par427 = {427, ptf427, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf428[] = {416,858,0xFF01,783,858,0xFFFF};
static struct eif_par_types par428 = {428, ptf428, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAYED_LIST_ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf429[] = {417,846,0xFF01,784,846,0xFFFF};
static struct eif_par_types par429 = {429, ptf429, (uint16) 1, (uint16) 1, (char) 0};

/* STRING_32_ITERATION_CURSOR */
static EIF_TYPE_INDEX ptf430[] = {410,861,0xFF01,909,0xFFFF};
static struct eif_par_types par430 = {430, ptf430, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_8_ITERATION_CURSOR */
static EIF_TYPE_INDEX ptf431[] = {412,864,0xFF01,912,0xFFFF};
static struct eif_par_types par431 = {431, ptf431, (uint16) 1, (uint16) 0, (char) 0};

/* ARRAY_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf432[] = {406,0xFFF8,1,0xFF01,701,0xFFF8,1,0xFFFF};
static struct eif_par_types par432 = {432, ptf432, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf433[] = {407,834,0xFF01,702,834,0xFFFF};
static struct eif_par_types par433 = {433, ptf433, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf434[] = {408,900,0xFF01,703,900,0xFFFF};
static struct eif_par_types par434 = {434, ptf434, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf435[] = {409,867,0xFF01,704,867,0xFFFF};
static struct eif_par_types par435 = {435, ptf435, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf436[] = {410,861,0xFF01,705,861,0xFFFF};
static struct eif_par_types par436 = {436, ptf436, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf437[] = {411,843,0xFF01,706,843,0xFFFF};
static struct eif_par_types par437 = {437, ptf437, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf438[] = {412,864,0xFF01,707,864,0xFFFF};
static struct eif_par_types par438 = {438, ptf438, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf439[] = {413,852,0xFF01,708,852,0xFFFF};
static struct eif_par_types par439 = {439, ptf439, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf440[] = {414,849,0xFF01,709,849,0xFFFF};
static struct eif_par_types par440 = {440, ptf440, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf441[] = {415,855,0xFF01,710,855,0xFFFF};
static struct eif_par_types par441 = {441, ptf441, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf442[] = {416,858,0xFF01,711,858,0xFFFF};
static struct eif_par_types par442 = {442, ptf442, (uint16) 1, (uint16) 1, (char) 0};

/* ARRAY_ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf443[] = {417,846,0xFF01,712,846,0xFFFF};
static struct eif_par_types par443 = {443, ptf443, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf444[] = {406,0xFFF8,1,0xFF01,676,0xFFF8,1,0xFFFF};
static struct eif_par_types par444 = {444, ptf444, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf445[] = {407,834,0xFF01,677,834,0xFFFF};
static struct eif_par_types par445 = {445, ptf445, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [POINTER] */
static EIF_TYPE_INDEX ptf446[] = {408,900,0xFF01,678,900,0xFFFF};
static struct eif_par_types par446 = {446, ptf446, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf447[] = {409,867,0xFF01,679,867,0xFFFF};
static struct eif_par_types par447 = {447, ptf447, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf448[] = {410,861,0xFF01,680,861,0xFFFF};
static struct eif_par_types par448 = {448, ptf448, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf449[] = {411,843,0xFF01,681,843,0xFFFF};
static struct eif_par_types par449 = {449, ptf449, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf450[] = {412,864,0xFF01,682,864,0xFFFF};
static struct eif_par_types par450 = {450, ptf450, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [NATURAL_8] */
static EIF_TYPE_INDEX ptf451[] = {413,852,0xFF01,683,852,0xFFFF};
static struct eif_par_types par451 = {451, ptf451, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [NATURAL_16] */
static EIF_TYPE_INDEX ptf452[] = {414,849,0xFF01,684,849,0xFFFF};
static struct eif_par_types par452 = {452, ptf452, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [REAL_32] */
static EIF_TYPE_INDEX ptf453[] = {415,855,0xFF01,685,855,0xFFFF};
static struct eif_par_types par453 = {453, ptf453, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [REAL_64] */
static EIF_TYPE_INDEX ptf454[] = {416,858,0xFF01,686,858,0xFFFF};
static struct eif_par_types par454 = {454, ptf454, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL_ITERATION_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf455[] = {417,846,0xFF01,687,846,0xFFFF};
static struct eif_par_types par455 = {455, ptf455, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [G#1] */
static EIF_TYPE_INDEX ptf456[] = {342,0xFFF8,1,0xFFFF};
static struct eif_par_types par456 = {456, ptf456, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [INTEGER_32] */
static EIF_TYPE_INDEX ptf457[] = {343,834,0xFFFF};
static struct eif_par_types par457 = {457, ptf457, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf458[] = {344,864,0xFFFF};
static struct eif_par_types par458 = {458, ptf458, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [POINTER] */
static EIF_TYPE_INDEX ptf459[] = {345,900,0xFFFF};
static struct eif_par_types par459 = {459, ptf459, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [BOOLEAN] */
static EIF_TYPE_INDEX ptf460[] = {346,867,0xFFFF};
static struct eif_par_types par460 = {460, ptf460, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [CHARACTER_32] */
static EIF_TYPE_INDEX ptf461[] = {347,861,0xFFFF};
static struct eif_par_types par461 = {461, ptf461, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [NATURAL_64] */
static EIF_TYPE_INDEX ptf462[] = {348,843,0xFFFF};
static struct eif_par_types par462 = {462, ptf462, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [NATURAL_8] */
static EIF_TYPE_INDEX ptf463[] = {349,852,0xFFFF};
static struct eif_par_types par463 = {463, ptf463, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [NATURAL_16] */
static EIF_TYPE_INDEX ptf464[] = {350,849,0xFFFF};
static struct eif_par_types par464 = {464, ptf464, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [REAL_32] */
static EIF_TYPE_INDEX ptf465[] = {351,855,0xFFFF};
static struct eif_par_types par465 = {465, ptf465, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [REAL_64] */
static EIF_TYPE_INDEX ptf466[] = {352,858,0xFFFF};
static struct eif_par_types par466 = {466, ptf466, (uint16) 1, (uint16) 1, (char) 0};

/* CONTAINER [NATURAL_32] */
static EIF_TYPE_INDEX ptf467[] = {353,846,0xFFFF};
static struct eif_par_types par467 = {467, ptf467, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [G#1] */
static EIF_TYPE_INDEX ptf468[] = {456,0xFFF8,1,0xFFFF};
static struct eif_par_types par468 = {468, ptf468, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf469[] = {457,834,0xFFFF};
static struct eif_par_types par469 = {469, ptf469, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf470[] = {458,864,0xFFFF};
static struct eif_par_types par470 = {470, ptf470, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [POINTER] */
static EIF_TYPE_INDEX ptf471[] = {459,900,0xFFFF};
static struct eif_par_types par471 = {471, ptf471, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf472[] = {460,867,0xFFFF};
static struct eif_par_types par472 = {472, ptf472, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf473[] = {461,861,0xFFFF};
static struct eif_par_types par473 = {473, ptf473, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf474[] = {462,843,0xFFFF};
static struct eif_par_types par474 = {474, ptf474, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [NATURAL_8] */
static EIF_TYPE_INDEX ptf475[] = {463,852,0xFFFF};
static struct eif_par_types par475 = {475, ptf475, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [NATURAL_16] */
static EIF_TYPE_INDEX ptf476[] = {464,849,0xFFFF};
static struct eif_par_types par476 = {476, ptf476, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [REAL_32] */
static EIF_TYPE_INDEX ptf477[] = {465,855,0xFFFF};
static struct eif_par_types par477 = {477, ptf477, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [REAL_64] */
static EIF_TYPE_INDEX ptf478[] = {466,858,0xFFFF};
static struct eif_par_types par478 = {478, ptf478, (uint16) 1, (uint16) 1, (char) 0};

/* TRAVERSABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf479[] = {467,846,0xFFFF};
static struct eif_par_types par479 = {479, ptf479, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [G#1] */
static EIF_TYPE_INDEX ptf480[] = {468,0xFFF8,1,0xFFFF};
static struct eif_par_types par480 = {480, ptf480, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [INTEGER_32] */
static EIF_TYPE_INDEX ptf481[] = {469,834,0xFFFF};
static struct eif_par_types par481 = {481, ptf481, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf482[] = {470,864,0xFFFF};
static struct eif_par_types par482 = {482, ptf482, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [POINTER] */
static EIF_TYPE_INDEX ptf483[] = {471,900,0xFFFF};
static struct eif_par_types par483 = {483, ptf483, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [BOOLEAN] */
static EIF_TYPE_INDEX ptf484[] = {472,867,0xFFFF};
static struct eif_par_types par484 = {484, ptf484, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf485[] = {473,861,0xFFFF};
static struct eif_par_types par485 = {485, ptf485, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [NATURAL_64] */
static EIF_TYPE_INDEX ptf486[] = {474,843,0xFFFF};
static struct eif_par_types par486 = {486, ptf486, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [NATURAL_8] */
static EIF_TYPE_INDEX ptf487[] = {475,852,0xFFFF};
static struct eif_par_types par487 = {487, ptf487, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [NATURAL_16] */
static EIF_TYPE_INDEX ptf488[] = {476,849,0xFFFF};
static struct eif_par_types par488 = {488, ptf488, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [REAL_32] */
static EIF_TYPE_INDEX ptf489[] = {477,855,0xFFFF};
static struct eif_par_types par489 = {489, ptf489, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [REAL_64] */
static EIF_TYPE_INDEX ptf490[] = {478,858,0xFFFF};
static struct eif_par_types par490 = {490, ptf490, (uint16) 1, (uint16) 1, (char) 0};

/* LINEAR [NATURAL_32] */
static EIF_TYPE_INDEX ptf491[] = {479,846,0xFFFF};
static struct eif_par_types par491 = {491, ptf491, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [G#1] */
static EIF_TYPE_INDEX ptf492[] = {480,0xFFF8,1,0xFFFF};
static struct eif_par_types par492 = {492, ptf492, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [INTEGER_32] */
static EIF_TYPE_INDEX ptf493[] = {481,834,0xFFFF};
static struct eif_par_types par493 = {493, ptf493, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [POINTER] */
static EIF_TYPE_INDEX ptf494[] = {483,900,0xFFFF};
static struct eif_par_types par494 = {494, ptf494, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [BOOLEAN] */
static EIF_TYPE_INDEX ptf495[] = {484,867,0xFFFF};
static struct eif_par_types par495 = {495, ptf495, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [CHARACTER_32] */
static EIF_TYPE_INDEX ptf496[] = {485,861,0xFFFF};
static struct eif_par_types par496 = {496, ptf496, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [NATURAL_64] */
static EIF_TYPE_INDEX ptf497[] = {486,843,0xFFFF};
static struct eif_par_types par497 = {497, ptf497, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf498[] = {482,864,0xFFFF};
static struct eif_par_types par498 = {498, ptf498, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [NATURAL_8] */
static EIF_TYPE_INDEX ptf499[] = {487,852,0xFFFF};
static struct eif_par_types par499 = {499, ptf499, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [NATURAL_16] */
static EIF_TYPE_INDEX ptf500[] = {488,849,0xFFFF};
static struct eif_par_types par500 = {500, ptf500, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [REAL_32] */
static EIF_TYPE_INDEX ptf501[] = {489,855,0xFFFF};
static struct eif_par_types par501 = {501, ptf501, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [REAL_64] */
static EIF_TYPE_INDEX ptf502[] = {490,858,0xFFFF};
static struct eif_par_types par502 = {502, ptf502, (uint16) 1, (uint16) 1, (char) 0};

/* BILINEAR [NATURAL_32] */
static EIF_TYPE_INDEX ptf503[] = {491,846,0xFFFF};
static struct eif_par_types par503 = {503, ptf503, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [G#1] */
static EIF_TYPE_INDEX ptf504[] = {456,0xFFF8,1,0xFFFF};
static struct eif_par_types par504 = {504, ptf504, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [INTEGER_32] */
static EIF_TYPE_INDEX ptf505[] = {457,834,0xFFFF};
static struct eif_par_types par505 = {505, ptf505, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [CHARACTER_8] */
static EIF_TYPE_INDEX ptf506[] = {458,864,0xFFFF};
static struct eif_par_types par506 = {506, ptf506, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [POINTER] */
static EIF_TYPE_INDEX ptf507[] = {459,900,0xFFFF};
static struct eif_par_types par507 = {507, ptf507, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [BOOLEAN] */
static EIF_TYPE_INDEX ptf508[] = {460,867,0xFFFF};
static struct eif_par_types par508 = {508, ptf508, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [CHARACTER_32] */
static EIF_TYPE_INDEX ptf509[] = {461,861,0xFFFF};
static struct eif_par_types par509 = {509, ptf509, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [NATURAL_64] */
static EIF_TYPE_INDEX ptf510[] = {462,843,0xFFFF};
static struct eif_par_types par510 = {510, ptf510, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [NATURAL_8] */
static EIF_TYPE_INDEX ptf511[] = {463,852,0xFFFF};
static struct eif_par_types par511 = {511, ptf511, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [NATURAL_16] */
static EIF_TYPE_INDEX ptf512[] = {464,849,0xFFFF};
static struct eif_par_types par512 = {512, ptf512, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [REAL_32] */
static EIF_TYPE_INDEX ptf513[] = {465,855,0xFFFF};
static struct eif_par_types par513 = {513, ptf513, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [REAL_64] */
static EIF_TYPE_INDEX ptf514[] = {466,858,0xFFFF};
static struct eif_par_types par514 = {514, ptf514, (uint16) 1, (uint16) 1, (char) 0};

/* COLLECTION [NATURAL_32] */
static EIF_TYPE_INDEX ptf515[] = {467,846,0xFFFF};
static struct eif_par_types par515 = {515, ptf515, (uint16) 1, (uint16) 1, (char) 0};

/* SET [INTEGER_32] */
static EIF_TYPE_INDEX ptf516[] = {505,834,0xFFFF};
static struct eif_par_types par516 = {516, ptf516, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [G#1] */
static EIF_TYPE_INDEX ptf517[] = {504,0xFFF8,1,0xFFFF};
static struct eif_par_types par517 = {517, ptf517, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [INTEGER_32] */
static EIF_TYPE_INDEX ptf518[] = {505,834,0xFFFF};
static struct eif_par_types par518 = {518, ptf518, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [CHARACTER_8] */
static EIF_TYPE_INDEX ptf519[] = {506,864,0xFFFF};
static struct eif_par_types par519 = {519, ptf519, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [POINTER] */
static EIF_TYPE_INDEX ptf520[] = {507,900,0xFFFF};
static struct eif_par_types par520 = {520, ptf520, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [BOOLEAN] */
static EIF_TYPE_INDEX ptf521[] = {508,867,0xFFFF};
static struct eif_par_types par521 = {521, ptf521, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [CHARACTER_32] */
static EIF_TYPE_INDEX ptf522[] = {509,861,0xFFFF};
static struct eif_par_types par522 = {522, ptf522, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [NATURAL_64] */
static EIF_TYPE_INDEX ptf523[] = {510,843,0xFFFF};
static struct eif_par_types par523 = {523, ptf523, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [NATURAL_8] */
static EIF_TYPE_INDEX ptf524[] = {511,852,0xFFFF};
static struct eif_par_types par524 = {524, ptf524, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [NATURAL_16] */
static EIF_TYPE_INDEX ptf525[] = {512,849,0xFFFF};
static struct eif_par_types par525 = {525, ptf525, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [REAL_32] */
static EIF_TYPE_INDEX ptf526[] = {513,855,0xFFFF};
static struct eif_par_types par526 = {526, ptf526, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [REAL_64] */
static EIF_TYPE_INDEX ptf527[] = {514,858,0xFFFF};
static struct eif_par_types par527 = {527, ptf527, (uint16) 1, (uint16) 1, (char) 0};

/* BAG [NATURAL_32] */
static EIF_TYPE_INDEX ptf528[] = {515,846,0xFFFF};
static struct eif_par_types par528 = {528, ptf528, (uint16) 1, (uint16) 1, (char) 0};

/* TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf529[] = {517,0xFFF8,1,0xFFFF};
static struct eif_par_types par529 = {529, ptf529, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf530[] = {517,0xFFF8,1,0xFFFF};
static struct eif_par_types par530 = {530, ptf530, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf531[] = {518,834,0xFFFF};
static struct eif_par_types par531 = {531, ptf531, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf532[] = {518,834,0xFFFF};
static struct eif_par_types par532 = {532, ptf532, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [CHARACTER_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf533[] = {519,864,0xFFFF};
static struct eif_par_types par533 = {533, ptf533, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [POINTER, G#2] */
static EIF_TYPE_INDEX ptf534[] = {520,900,0xFFFF};
static struct eif_par_types par534 = {534, ptf534, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [POINTER, INTEGER_32] */
static EIF_TYPE_INDEX ptf535[] = {520,900,0xFFFF};
static struct eif_par_types par535 = {535, ptf535, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [BOOLEAN, INTEGER_32] */
static EIF_TYPE_INDEX ptf536[] = {521,867,0xFFFF};
static struct eif_par_types par536 = {536, ptf536, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [CHARACTER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf537[] = {522,861,0xFFFF};
static struct eif_par_types par537 = {537, ptf537, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [NATURAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf538[] = {523,843,0xFFFF};
static struct eif_par_types par538 = {538, ptf538, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [NATURAL_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf539[] = {524,852,0xFFFF};
static struct eif_par_types par539 = {539, ptf539, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [NATURAL_16, INTEGER_32] */
static EIF_TYPE_INDEX ptf540[] = {525,849,0xFFFF};
static struct eif_par_types par540 = {540, ptf540, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [REAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf541[] = {526,855,0xFFFF};
static struct eif_par_types par541 = {541, ptf541, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [REAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf542[] = {527,858,0xFFFF};
static struct eif_par_types par542 = {542, ptf542, (uint16) 1, (uint16) 2, (char) 0};

/* TABLE [NATURAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf543[] = {528,846,0xFFFF};
static struct eif_par_types par543 = {543, ptf543, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf544[] = {529,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par544 = {544, ptf544, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf545[] = {530,0xFFF8,1,834,0xFFFF};
static struct eif_par_types par545 = {545, ptf545, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf546[] = {531,834,0xFFF8,2,0xFFFF};
static struct eif_par_types par546 = {546, ptf546, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf547[] = {532,834,834,0xFFFF};
static struct eif_par_types par547 = {547, ptf547, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [CHARACTER_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf548[] = {533,864,834,0xFFFF};
static struct eif_par_types par548 = {548, ptf548, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [POINTER, G#2] */
static EIF_TYPE_INDEX ptf549[] = {534,900,0xFFF8,2,0xFFFF};
static struct eif_par_types par549 = {549, ptf549, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [POINTER, INTEGER_32] */
static EIF_TYPE_INDEX ptf550[] = {535,900,834,0xFFFF};
static struct eif_par_types par550 = {550, ptf550, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [BOOLEAN, INTEGER_32] */
static EIF_TYPE_INDEX ptf551[] = {536,867,834,0xFFFF};
static struct eif_par_types par551 = {551, ptf551, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [CHARACTER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf552[] = {537,861,834,0xFFFF};
static struct eif_par_types par552 = {552, ptf552, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [NATURAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf553[] = {538,843,834,0xFFFF};
static struct eif_par_types par553 = {553, ptf553, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [NATURAL_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf554[] = {539,852,834,0xFFFF};
static struct eif_par_types par554 = {554, ptf554, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [NATURAL_16, INTEGER_32] */
static EIF_TYPE_INDEX ptf555[] = {540,849,834,0xFFFF};
static struct eif_par_types par555 = {555, ptf555, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [REAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf556[] = {541,855,834,0xFFFF};
static struct eif_par_types par556 = {556, ptf556, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [REAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf557[] = {542,858,834,0xFFFF};
static struct eif_par_types par557 = {557, ptf557, (uint16) 1, (uint16) 2, (char) 0};

/* DYNAMIC_TABLE [NATURAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf558[] = {543,846,834,0xFFFF};
static struct eif_par_types par558 = {558, ptf558, (uint16) 1, (uint16) 2, (char) 0};

/* ACTIVE [G#1] */
static EIF_TYPE_INDEX ptf559[] = {517,0xFFF8,1,0xFFFF};
static struct eif_par_types par559 = {559, ptf559, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [INTEGER_32] */
static EIF_TYPE_INDEX ptf560[] = {518,834,0xFFFF};
static struct eif_par_types par560 = {560, ptf560, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf561[] = {519,864,0xFFFF};
static struct eif_par_types par561 = {561, ptf561, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [POINTER] */
static EIF_TYPE_INDEX ptf562[] = {520,900,0xFFFF};
static struct eif_par_types par562 = {562, ptf562, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [BOOLEAN] */
static EIF_TYPE_INDEX ptf563[] = {521,867,0xFFFF};
static struct eif_par_types par563 = {563, ptf563, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf564[] = {522,861,0xFFFF};
static struct eif_par_types par564 = {564, ptf564, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [NATURAL_64] */
static EIF_TYPE_INDEX ptf565[] = {523,843,0xFFFF};
static struct eif_par_types par565 = {565, ptf565, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [NATURAL_8] */
static EIF_TYPE_INDEX ptf566[] = {524,852,0xFFFF};
static struct eif_par_types par566 = {566, ptf566, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [NATURAL_16] */
static EIF_TYPE_INDEX ptf567[] = {525,849,0xFFFF};
static struct eif_par_types par567 = {567, ptf567, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [REAL_32] */
static EIF_TYPE_INDEX ptf568[] = {526,855,0xFFFF};
static struct eif_par_types par568 = {568, ptf568, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [REAL_64] */
static EIF_TYPE_INDEX ptf569[] = {527,858,0xFFFF};
static struct eif_par_types par569 = {569, ptf569, (uint16) 1, (uint16) 1, (char) 0};

/* ACTIVE [NATURAL_32] */
static EIF_TYPE_INDEX ptf570[] = {528,846,0xFFFF};
static struct eif_par_types par570 = {570, ptf570, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [G#1] */
static EIF_TYPE_INDEX ptf571[] = {559,0xFFF8,1,0xFFFF};
static struct eif_par_types par571 = {571, ptf571, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [INTEGER_32] */
static EIF_TYPE_INDEX ptf572[] = {560,834,0xFFFF};
static struct eif_par_types par572 = {572, ptf572, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf573[] = {561,864,0xFFFF};
static struct eif_par_types par573 = {573, ptf573, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [POINTER] */
static EIF_TYPE_INDEX ptf574[] = {562,900,0xFFFF};
static struct eif_par_types par574 = {574, ptf574, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [BOOLEAN] */
static EIF_TYPE_INDEX ptf575[] = {563,867,0xFFFF};
static struct eif_par_types par575 = {575, ptf575, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf576[] = {564,861,0xFFFF};
static struct eif_par_types par576 = {576, ptf576, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [NATURAL_64] */
static EIF_TYPE_INDEX ptf577[] = {565,843,0xFFFF};
static struct eif_par_types par577 = {577, ptf577, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [NATURAL_8] */
static EIF_TYPE_INDEX ptf578[] = {566,852,0xFFFF};
static struct eif_par_types par578 = {578, ptf578, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [NATURAL_16] */
static EIF_TYPE_INDEX ptf579[] = {567,849,0xFFFF};
static struct eif_par_types par579 = {579, ptf579, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [REAL_32] */
static EIF_TYPE_INDEX ptf580[] = {568,855,0xFFFF};
static struct eif_par_types par580 = {580, ptf580, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [REAL_64] */
static EIF_TYPE_INDEX ptf581[] = {569,858,0xFFFF};
static struct eif_par_types par581 = {581, ptf581, (uint16) 1, (uint16) 1, (char) 0};

/* CURSOR_STRUCTURE [NATURAL_32] */
static EIF_TYPE_INDEX ptf582[] = {570,846,0xFFFF};
static struct eif_par_types par582 = {582, ptf582, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [G#1] */
static EIF_TYPE_INDEX ptf583[] = {456,0xFFF8,1,0xFFFF};
static struct eif_par_types par583 = {583, ptf583, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [INTEGER_32] */
static EIF_TYPE_INDEX ptf584[] = {457,834,0xFFFF};
static struct eif_par_types par584 = {584, ptf584, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [CHARACTER_8] */
static EIF_TYPE_INDEX ptf585[] = {458,864,0xFFFF};
static struct eif_par_types par585 = {585, ptf585, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [POINTER] */
static EIF_TYPE_INDEX ptf586[] = {459,900,0xFFFF};
static struct eif_par_types par586 = {586, ptf586, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [BOOLEAN] */
static EIF_TYPE_INDEX ptf587[] = {460,867,0xFFFF};
static struct eif_par_types par587 = {587, ptf587, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [CHARACTER_32] */
static EIF_TYPE_INDEX ptf588[] = {461,861,0xFFFF};
static struct eif_par_types par588 = {588, ptf588, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [NATURAL_64] */
static EIF_TYPE_INDEX ptf589[] = {462,843,0xFFFF};
static struct eif_par_types par589 = {589, ptf589, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [NATURAL_8] */
static EIF_TYPE_INDEX ptf590[] = {463,852,0xFFFF};
static struct eif_par_types par590 = {590, ptf590, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [NATURAL_16] */
static EIF_TYPE_INDEX ptf591[] = {464,849,0xFFFF};
static struct eif_par_types par591 = {591, ptf591, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [REAL_32] */
static EIF_TYPE_INDEX ptf592[] = {465,855,0xFFFF};
static struct eif_par_types par592 = {592, ptf592, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [REAL_64] */
static EIF_TYPE_INDEX ptf593[] = {466,858,0xFFFF};
static struct eif_par_types par593 = {593, ptf593, (uint16) 1, (uint16) 1, (char) 0};

/* BOX [NATURAL_32] */
static EIF_TYPE_INDEX ptf594[] = {467,846,0xFFFF};
static struct eif_par_types par594 = {594, ptf594, (uint16) 1, (uint16) 1, (char) 0};

/* INFINITE [INTEGER_32] */
static EIF_TYPE_INDEX ptf595[] = {584,834,0xFFFF};
static struct eif_par_types par595 = {595, ptf595, (uint16) 1, (uint16) 1, (char) 0};

/* COUNTABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf596[] = {595,834,0xFFFF};
static struct eif_par_types par596 = {596, ptf596, (uint16) 1, (uint16) 1, (char) 0};

/* COUNTABLE_SEQUENCE [INTEGER_32] */
static EIF_TYPE_INDEX ptf597[] = {596,834,0xFFF7,481,834,0xFFFF};
static struct eif_par_types par597 = {597, ptf597, (uint16) 2, (uint16) 1, (char) 0};

/* PRIMES */
static EIF_TYPE_INDEX ptf598[] = {597,834,0xFFF7,324,834,0xFFFF};
static struct eif_par_types par598 = {598, ptf598, (uint16) 2, (uint16) 0, (char) 0};

/* FINITE [G#1] */
static EIF_TYPE_INDEX ptf599[] = {583,0xFFF8,1,0xFFFF};
static struct eif_par_types par599 = {599, ptf599, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [INTEGER_32] */
static EIF_TYPE_INDEX ptf600[] = {584,834,0xFFFF};
static struct eif_par_types par600 = {600, ptf600, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf601[] = {585,864,0xFFFF};
static struct eif_par_types par601 = {601, ptf601, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [POINTER] */
static EIF_TYPE_INDEX ptf602[] = {586,900,0xFFFF};
static struct eif_par_types par602 = {602, ptf602, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [BOOLEAN] */
static EIF_TYPE_INDEX ptf603[] = {587,867,0xFFFF};
static struct eif_par_types par603 = {603, ptf603, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf604[] = {588,861,0xFFFF};
static struct eif_par_types par604 = {604, ptf604, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [NATURAL_64] */
static EIF_TYPE_INDEX ptf605[] = {589,843,0xFFFF};
static struct eif_par_types par605 = {605, ptf605, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [NATURAL_8] */
static EIF_TYPE_INDEX ptf606[] = {590,852,0xFFFF};
static struct eif_par_types par606 = {606, ptf606, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [NATURAL_16] */
static EIF_TYPE_INDEX ptf607[] = {591,849,0xFFFF};
static struct eif_par_types par607 = {607, ptf607, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [REAL_32] */
static EIF_TYPE_INDEX ptf608[] = {592,855,0xFFFF};
static struct eif_par_types par608 = {608, ptf608, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [REAL_64] */
static EIF_TYPE_INDEX ptf609[] = {593,858,0xFFFF};
static struct eif_par_types par609 = {609, ptf609, (uint16) 1, (uint16) 1, (char) 0};

/* FINITE [NATURAL_32] */
static EIF_TYPE_INDEX ptf610[] = {594,846,0xFFFF};
static struct eif_par_types par610 = {610, ptf610, (uint16) 1, (uint16) 1, (char) 0};

/* DISPENSER [G#1] */
static EIF_TYPE_INDEX ptf611[] = {559,0xFFF8,1,0xFFF7,599,0xFFF8,1,0xFFFF};
static struct eif_par_types par611 = {611, ptf611, (uint16) 2, (uint16) 1, (char) 0};

/* QUEUE [G#1] */
static EIF_TYPE_INDEX ptf612[] = {611,0xFFF8,1,0xFFFF};
static struct eif_par_types par612 = {612, ptf612, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [G#1] */
static EIF_TYPE_INDEX ptf613[] = {599,0xFFF8,1,0xFFFF};
static struct eif_par_types par613 = {613, ptf613, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [INTEGER_32] */
static EIF_TYPE_INDEX ptf614[] = {600,834,0xFFFF};
static struct eif_par_types par614 = {614, ptf614, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [POINTER] */
static EIF_TYPE_INDEX ptf615[] = {602,900,0xFFFF};
static struct eif_par_types par615 = {615, ptf615, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [BOOLEAN] */
static EIF_TYPE_INDEX ptf616[] = {603,867,0xFFFF};
static struct eif_par_types par616 = {616, ptf616, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [CHARACTER_32] */
static EIF_TYPE_INDEX ptf617[] = {604,861,0xFFFF};
static struct eif_par_types par617 = {617, ptf617, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [NATURAL_64] */
static EIF_TYPE_INDEX ptf618[] = {605,843,0xFFFF};
static struct eif_par_types par618 = {618, ptf618, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [CHARACTER_8] */
static EIF_TYPE_INDEX ptf619[] = {601,864,0xFFFF};
static struct eif_par_types par619 = {619, ptf619, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [NATURAL_8] */
static EIF_TYPE_INDEX ptf620[] = {606,852,0xFFFF};
static struct eif_par_types par620 = {620, ptf620, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [NATURAL_16] */
static EIF_TYPE_INDEX ptf621[] = {607,849,0xFFFF};
static struct eif_par_types par621 = {621, ptf621, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [REAL_32] */
static EIF_TYPE_INDEX ptf622[] = {608,855,0xFFFF};
static struct eif_par_types par622 = {622, ptf622, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [REAL_64] */
static EIF_TYPE_INDEX ptf623[] = {609,858,0xFFFF};
static struct eif_par_types par623 = {623, ptf623, (uint16) 1, (uint16) 1, (char) 0};

/* BOUNDED [NATURAL_32] */
static EIF_TYPE_INDEX ptf624[] = {610,846,0xFFFF};
static struct eif_par_types par624 = {624, ptf624, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [G#1] */
static EIF_TYPE_INDEX ptf625[] = {613,0xFFF8,1,0xFFFF};
static struct eif_par_types par625 = {625, ptf625, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf626[] = {614,834,0xFFFF};
static struct eif_par_types par626 = {626, ptf626, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [POINTER] */
static EIF_TYPE_INDEX ptf627[] = {615,900,0xFFFF};
static struct eif_par_types par627 = {627, ptf627, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf628[] = {616,867,0xFFFF};
static struct eif_par_types par628 = {628, ptf628, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf629[] = {617,861,0xFFFF};
static struct eif_par_types par629 = {629, ptf629, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf630[] = {618,843,0xFFFF};
static struct eif_par_types par630 = {630, ptf630, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf631[] = {619,864,0xFFFF};
static struct eif_par_types par631 = {631, ptf631, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [NATURAL_8] */
static EIF_TYPE_INDEX ptf632[] = {620,852,0xFFFF};
static struct eif_par_types par632 = {632, ptf632, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [NATURAL_16] */
static EIF_TYPE_INDEX ptf633[] = {621,849,0xFFFF};
static struct eif_par_types par633 = {633, ptf633, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [REAL_32] */
static EIF_TYPE_INDEX ptf634[] = {622,855,0xFFFF};
static struct eif_par_types par634 = {634, ptf634, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [REAL_64] */
static EIF_TYPE_INDEX ptf635[] = {623,858,0xFFFF};
static struct eif_par_types par635 = {635, ptf635, (uint16) 1, (uint16) 1, (char) 0};

/* RESIZABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf636[] = {624,846,0xFFFF};
static struct eif_par_types par636 = {636, ptf636, (uint16) 1, (uint16) 1, (char) 0};

/* SEQUENCE [G#1] */
static EIF_TYPE_INDEX ptf637[] = {559,0xFFF8,1,0xFFF7,492,0xFFF8,1,0xFFF7,599,0xFFF8,1,0xFFFF};
static struct eif_par_types par637 = {637, ptf637, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [INTEGER_32] */
static EIF_TYPE_INDEX ptf638[] = {560,834,0xFFF7,493,834,0xFFF7,600,834,0xFFFF};
static struct eif_par_types par638 = {638, ptf638, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [POINTER] */
static EIF_TYPE_INDEX ptf639[] = {562,900,0xFFF7,494,900,0xFFF7,602,900,0xFFFF};
static struct eif_par_types par639 = {639, ptf639, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [BOOLEAN] */
static EIF_TYPE_INDEX ptf640[] = {563,867,0xFFF7,495,867,0xFFF7,603,867,0xFFFF};
static struct eif_par_types par640 = {640, ptf640, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf641[] = {564,861,0xFFF7,496,861,0xFFF7,604,861,0xFFFF};
static struct eif_par_types par641 = {641, ptf641, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [NATURAL_64] */
static EIF_TYPE_INDEX ptf642[] = {565,843,0xFFF7,497,843,0xFFF7,605,843,0xFFFF};
static struct eif_par_types par642 = {642, ptf642, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf643[] = {561,864,0xFFF7,498,864,0xFFF7,601,864,0xFFFF};
static struct eif_par_types par643 = {643, ptf643, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [NATURAL_8] */
static EIF_TYPE_INDEX ptf644[] = {566,852,0xFFF7,499,852,0xFFF7,606,852,0xFFFF};
static struct eif_par_types par644 = {644, ptf644, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [NATURAL_16] */
static EIF_TYPE_INDEX ptf645[] = {567,849,0xFFF7,500,849,0xFFF7,607,849,0xFFFF};
static struct eif_par_types par645 = {645, ptf645, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [REAL_32] */
static EIF_TYPE_INDEX ptf646[] = {568,855,0xFFF7,501,855,0xFFF7,608,855,0xFFFF};
static struct eif_par_types par646 = {646, ptf646, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [REAL_64] */
static EIF_TYPE_INDEX ptf647[] = {569,858,0xFFF7,502,858,0xFFF7,609,858,0xFFFF};
static struct eif_par_types par647 = {647, ptf647, (uint16) 3, (uint16) 1, (char) 0};

/* SEQUENCE [NATURAL_32] */
static EIF_TYPE_INDEX ptf648[] = {570,846,0xFFF7,503,846,0xFFF7,610,846,0xFFFF};
static struct eif_par_types par648 = {648, ptf648, (uint16) 3, (uint16) 1, (char) 0};

/* UNBOUNDED [G#1] */
static EIF_TYPE_INDEX ptf649[] = {599,0xFFF8,1,0xFFFF};
static struct eif_par_types par649 = {649, ptf649, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [INTEGER_32] */
static EIF_TYPE_INDEX ptf650[] = {600,834,0xFFFF};
static struct eif_par_types par650 = {650, ptf650, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [POINTER] */
static EIF_TYPE_INDEX ptf651[] = {602,900,0xFFFF};
static struct eif_par_types par651 = {651, ptf651, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [BOOLEAN] */
static EIF_TYPE_INDEX ptf652[] = {603,867,0xFFFF};
static struct eif_par_types par652 = {652, ptf652, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [CHARACTER_32] */
static EIF_TYPE_INDEX ptf653[] = {604,861,0xFFFF};
static struct eif_par_types par653 = {653, ptf653, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [NATURAL_64] */
static EIF_TYPE_INDEX ptf654[] = {605,843,0xFFFF};
static struct eif_par_types par654 = {654, ptf654, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [CHARACTER_8] */
static EIF_TYPE_INDEX ptf655[] = {601,864,0xFFFF};
static struct eif_par_types par655 = {655, ptf655, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [NATURAL_8] */
static EIF_TYPE_INDEX ptf656[] = {606,852,0xFFFF};
static struct eif_par_types par656 = {656, ptf656, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [NATURAL_16] */
static EIF_TYPE_INDEX ptf657[] = {607,849,0xFFFF};
static struct eif_par_types par657 = {657, ptf657, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [REAL_32] */
static EIF_TYPE_INDEX ptf658[] = {608,855,0xFFFF};
static struct eif_par_types par658 = {658, ptf658, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [REAL_64] */
static EIF_TYPE_INDEX ptf659[] = {609,858,0xFFFF};
static struct eif_par_types par659 = {659, ptf659, (uint16) 1, (uint16) 1, (char) 0};

/* UNBOUNDED [NATURAL_32] */
static EIF_TYPE_INDEX ptf660[] = {610,846,0xFFFF};
static struct eif_par_types par660 = {660, ptf660, (uint16) 1, (uint16) 1, (char) 0};

/* FILE */
static EIF_TYPE_INDEX ptf661[] = {655,864,0xFFF7,643,864,0xFFF7,272,0xFFF7,259,0xFFFF};
static struct eif_par_types par661 = {661, ptf661, (uint16) 4, (uint16) 0, (char) 0};

/* RAW_FILE */
static EIF_TYPE_INDEX ptf662[] = {661,0xFFFF};
static struct eif_par_types par662 = {662, ptf662, (uint16) 1, (uint16) 0, (char) 0};

/* PLAIN_TEXT_FILE */
static EIF_TYPE_INDEX ptf663[] = {661,0xFFFF};
static struct eif_par_types par663 = {663, ptf663, (uint16) 1, (uint16) 0, (char) 0};

/* READABLE_INDEXABLE [G#1] */
static EIF_TYPE_INDEX ptf664[] = {342,0xFFF8,1,0xFFFF};
static struct eif_par_types par664 = {664, ptf664, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf665[] = {343,834,0xFFFF};
static struct eif_par_types par665 = {665, ptf665, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf666[] = {344,864,0xFFFF};
static struct eif_par_types par666 = {666, ptf666, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [POINTER] */
static EIF_TYPE_INDEX ptf667[] = {345,900,0xFFFF};
static struct eif_par_types par667 = {667, ptf667, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf668[] = {346,867,0xFFFF};
static struct eif_par_types par668 = {668, ptf668, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf669[] = {347,861,0xFFFF};
static struct eif_par_types par669 = {669, ptf669, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf670[] = {348,843,0xFFFF};
static struct eif_par_types par670 = {670, ptf670, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [NATURAL_8] */
static EIF_TYPE_INDEX ptf671[] = {349,852,0xFFFF};
static struct eif_par_types par671 = {671, ptf671, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [NATURAL_16] */
static EIF_TYPE_INDEX ptf672[] = {350,849,0xFFFF};
static struct eif_par_types par672 = {672, ptf672, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [REAL_32] */
static EIF_TYPE_INDEX ptf673[] = {351,855,0xFFFF};
static struct eif_par_types par673 = {673, ptf673, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [REAL_64] */
static EIF_TYPE_INDEX ptf674[] = {352,858,0xFFFF};
static struct eif_par_types par674 = {674, ptf674, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_INDEXABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf675[] = {353,846,0xFFFF};
static struct eif_par_types par675 = {675, ptf675, (uint16) 1, (uint16) 1, (char) 0};

/* SPECIAL [G#1] */
static EIF_TYPE_INDEX ptf676[] = {275,0xFFF7,664,0xFFF8,1,0xFFFF};
static struct eif_par_types par676 = {676, ptf676, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [INTEGER_32] */
static EIF_TYPE_INDEX ptf677[] = {275,0xFFF7,665,834,0xFFFF};
static struct eif_par_types par677 = {677, ptf677, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [POINTER] */
static EIF_TYPE_INDEX ptf678[] = {275,0xFFF7,667,900,0xFFFF};
static struct eif_par_types par678 = {678, ptf678, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [BOOLEAN] */
static EIF_TYPE_INDEX ptf679[] = {275,0xFFF7,668,867,0xFFFF};
static struct eif_par_types par679 = {679, ptf679, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [CHARACTER_32] */
static EIF_TYPE_INDEX ptf680[] = {275,0xFFF7,669,861,0xFFFF};
static struct eif_par_types par680 = {680, ptf680, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [NATURAL_64] */
static EIF_TYPE_INDEX ptf681[] = {275,0xFFF7,670,843,0xFFFF};
static struct eif_par_types par681 = {681, ptf681, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [CHARACTER_8] */
static EIF_TYPE_INDEX ptf682[] = {275,0xFFF7,666,864,0xFFFF};
static struct eif_par_types par682 = {682, ptf682, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [NATURAL_8] */
static EIF_TYPE_INDEX ptf683[] = {275,0xFFF7,671,852,0xFFFF};
static struct eif_par_types par683 = {683, ptf683, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [NATURAL_16] */
static EIF_TYPE_INDEX ptf684[] = {275,0xFFF7,672,849,0xFFFF};
static struct eif_par_types par684 = {684, ptf684, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [REAL_32] */
static EIF_TYPE_INDEX ptf685[] = {275,0xFFF7,673,855,0xFFFF};
static struct eif_par_types par685 = {685, ptf685, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [REAL_64] */
static EIF_TYPE_INDEX ptf686[] = {275,0xFFF7,674,858,0xFFFF};
static struct eif_par_types par686 = {686, ptf686, (uint16) 2, (uint16) 1, (char) 0};

/* SPECIAL [NATURAL_32] */
static EIF_TYPE_INDEX ptf687[] = {275,0xFFF7,675,846,0xFFFF};
static struct eif_par_types par687 = {687, ptf687, (uint16) 2, (uint16) 1, (char) 0};

/* INDEXABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf688[] = {530,0xFFF8,1,834,0xFFF7,664,0xFFF8,1,0xFFFF};
static struct eif_par_types par688 = {688, ptf688, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf689[] = {532,834,834,0xFFF7,665,834,0xFFFF};
static struct eif_par_types par689 = {689, ptf689, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [POINTER, INTEGER_32] */
static EIF_TYPE_INDEX ptf690[] = {535,900,834,0xFFF7,667,900,0xFFFF};
static struct eif_par_types par690 = {690, ptf690, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [BOOLEAN, INTEGER_32] */
static EIF_TYPE_INDEX ptf691[] = {536,867,834,0xFFF7,668,867,0xFFFF};
static struct eif_par_types par691 = {691, ptf691, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [CHARACTER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf692[] = {537,861,834,0xFFF7,669,861,0xFFFF};
static struct eif_par_types par692 = {692, ptf692, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [NATURAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf693[] = {538,843,834,0xFFF7,670,843,0xFFFF};
static struct eif_par_types par693 = {693, ptf693, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [CHARACTER_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf694[] = {533,864,834,0xFFF7,666,864,0xFFFF};
static struct eif_par_types par694 = {694, ptf694, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [NATURAL_8, INTEGER_32] */
static EIF_TYPE_INDEX ptf695[] = {539,852,834,0xFFF7,671,852,0xFFFF};
static struct eif_par_types par695 = {695, ptf695, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [NATURAL_16, INTEGER_32] */
static EIF_TYPE_INDEX ptf696[] = {540,849,834,0xFFF7,672,849,0xFFFF};
static struct eif_par_types par696 = {696, ptf696, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [REAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf697[] = {541,855,834,0xFFF7,673,855,0xFFFF};
static struct eif_par_types par697 = {697, ptf697, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [REAL_64, INTEGER_32] */
static EIF_TYPE_INDEX ptf698[] = {542,858,834,0xFFF7,674,858,0xFFFF};
static struct eif_par_types par698 = {698, ptf698, (uint16) 2, (uint16) 2, (char) 0};

/* INDEXABLE [NATURAL_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf699[] = {543,846,834,0xFFF7,675,846,0xFFFF};
static struct eif_par_types par699 = {699, ptf699, (uint16) 2, (uint16) 2, (char) 0};

/* INTEGER_INTERVAL */
static EIF_TYPE_INDEX ptf700[] = {626,834,0xFFF7,689,834,834,0xFFF7,516,834,0xFFFF};
static struct eif_par_types par700 = {700, ptf700, (uint16) 3, (uint16) 0, (char) 0};

/* ARRAY [G#1] */
static EIF_TYPE_INDEX ptf701[] = {625,0xFFF8,1,0xFFF7,688,0xFFF8,1,834,0xFFF7,247,0xFFF8,1,0xFFFF};
static struct eif_par_types par701 = {701, ptf701, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [INTEGER_32] */
static EIF_TYPE_INDEX ptf702[] = {626,834,0xFFF7,689,834,834,0xFFF7,248,834,0xFFFF};
static struct eif_par_types par702 = {702, ptf702, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [POINTER] */
static EIF_TYPE_INDEX ptf703[] = {627,900,0xFFF7,690,900,834,0xFFF7,249,900,0xFFFF};
static struct eif_par_types par703 = {703, ptf703, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [BOOLEAN] */
static EIF_TYPE_INDEX ptf704[] = {628,867,0xFFF7,691,867,834,0xFFF7,250,867,0xFFFF};
static struct eif_par_types par704 = {704, ptf704, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [CHARACTER_32] */
static EIF_TYPE_INDEX ptf705[] = {629,861,0xFFF7,692,861,834,0xFFF7,251,861,0xFFFF};
static struct eif_par_types par705 = {705, ptf705, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [NATURAL_64] */
static EIF_TYPE_INDEX ptf706[] = {630,843,0xFFF7,693,843,834,0xFFF7,252,843,0xFFFF};
static struct eif_par_types par706 = {706, ptf706, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [CHARACTER_8] */
static EIF_TYPE_INDEX ptf707[] = {631,864,0xFFF7,694,864,834,0xFFF7,253,864,0xFFFF};
static struct eif_par_types par707 = {707, ptf707, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [NATURAL_8] */
static EIF_TYPE_INDEX ptf708[] = {632,852,0xFFF7,695,852,834,0xFFF7,254,852,0xFFFF};
static struct eif_par_types par708 = {708, ptf708, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [NATURAL_16] */
static EIF_TYPE_INDEX ptf709[] = {633,849,0xFFF7,696,849,834,0xFFF7,255,849,0xFFFF};
static struct eif_par_types par709 = {709, ptf709, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [REAL_32] */
static EIF_TYPE_INDEX ptf710[] = {634,855,0xFFF7,697,855,834,0xFFF7,256,855,0xFFFF};
static struct eif_par_types par710 = {710, ptf710, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [REAL_64] */
static EIF_TYPE_INDEX ptf711[] = {635,858,0xFFF7,698,858,834,0xFFF7,257,858,0xFFFF};
static struct eif_par_types par711 = {711, ptf711, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAY [NATURAL_32] */
static EIF_TYPE_INDEX ptf712[] = {636,846,0xFFF7,699,846,834,0xFFF7,258,846,0xFFFF};
static struct eif_par_types par712 = {712, ptf712, (uint16) 3, (uint16) 1, (char) 0};

/* KL_ARRAY [G#1] */
static EIF_TYPE_INDEX ptf713[] = {701,0xFFF8,1,0xFFFF};
static struct eif_par_types par713 = {713, ptf713, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY [INTEGER_32] */
static EIF_TYPE_INDEX ptf714[] = {702,834,0xFFFF};
static struct eif_par_types par714 = {714, ptf714, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY [CHARACTER_8] */
static EIF_TYPE_INDEX ptf715[] = {707,864,0xFFFF};
static struct eif_par_types par715 = {715, ptf715, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY [BOOLEAN] */
static EIF_TYPE_INDEX ptf716[] = {704,867,0xFFFF};
static struct eif_par_types par716 = {716, ptf716, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY [NATURAL_32] */
static EIF_TYPE_INDEX ptf717[] = {712,846,0xFFFF};
static struct eif_par_types par717 = {717, ptf717, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY [NATURAL_64] */
static EIF_TYPE_INDEX ptf718[] = {706,843,0xFFFF};
static struct eif_par_types par718 = {718, ptf718, (uint16) 1, (uint16) 1, (char) 0};

/* CHAIN [G#1] */
static EIF_TYPE_INDEX ptf719[] = {571,0xFFF8,1,0xFFF7,688,0xFFF8,1,834,0xFFF7,637,0xFFF8,1,0xFFFF};
static struct eif_par_types par719 = {719, ptf719, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [INTEGER_32] */
static EIF_TYPE_INDEX ptf720[] = {572,834,0xFFF7,689,834,834,0xFFF7,638,834,0xFFFF};
static struct eif_par_types par720 = {720, ptf720, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [POINTER] */
static EIF_TYPE_INDEX ptf721[] = {574,900,0xFFF7,690,900,834,0xFFF7,639,900,0xFFFF};
static struct eif_par_types par721 = {721, ptf721, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [BOOLEAN] */
static EIF_TYPE_INDEX ptf722[] = {575,867,0xFFF7,691,867,834,0xFFF7,640,867,0xFFFF};
static struct eif_par_types par722 = {722, ptf722, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [CHARACTER_32] */
static EIF_TYPE_INDEX ptf723[] = {576,861,0xFFF7,692,861,834,0xFFF7,641,861,0xFFFF};
static struct eif_par_types par723 = {723, ptf723, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [NATURAL_64] */
static EIF_TYPE_INDEX ptf724[] = {577,843,0xFFF7,693,843,834,0xFFF7,642,843,0xFFFF};
static struct eif_par_types par724 = {724, ptf724, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [CHARACTER_8] */
static EIF_TYPE_INDEX ptf725[] = {573,864,0xFFF7,694,864,834,0xFFF7,643,864,0xFFFF};
static struct eif_par_types par725 = {725, ptf725, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [NATURAL_8] */
static EIF_TYPE_INDEX ptf726[] = {578,852,0xFFF7,695,852,834,0xFFF7,644,852,0xFFFF};
static struct eif_par_types par726 = {726, ptf726, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [NATURAL_16] */
static EIF_TYPE_INDEX ptf727[] = {579,849,0xFFF7,696,849,834,0xFFF7,645,849,0xFFFF};
static struct eif_par_types par727 = {727, ptf727, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [REAL_32] */
static EIF_TYPE_INDEX ptf728[] = {580,855,0xFFF7,697,855,834,0xFFF7,646,855,0xFFFF};
static struct eif_par_types par728 = {728, ptf728, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [REAL_64] */
static EIF_TYPE_INDEX ptf729[] = {581,858,0xFFF7,698,858,834,0xFFF7,647,858,0xFFFF};
static struct eif_par_types par729 = {729, ptf729, (uint16) 3, (uint16) 1, (char) 0};

/* CHAIN [NATURAL_32] */
static EIF_TYPE_INDEX ptf730[] = {582,846,0xFFF7,699,846,834,0xFFF7,648,846,0xFFFF};
static struct eif_par_types par730 = {730, ptf730, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [G#1] */
static EIF_TYPE_INDEX ptf731[] = {719,0xFFF8,1,0xFFF7,649,0xFFF8,1,0xFFF7,545,0xFFF8,1,834,0xFFFF};
static struct eif_par_types par731 = {731, ptf731, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [INTEGER_32] */
static EIF_TYPE_INDEX ptf732[] = {720,834,0xFFF7,650,834,0xFFF7,547,834,834,0xFFFF};
static struct eif_par_types par732 = {732, ptf732, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [POINTER] */
static EIF_TYPE_INDEX ptf733[] = {721,900,0xFFF7,651,900,0xFFF7,550,900,834,0xFFFF};
static struct eif_par_types par733 = {733, ptf733, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [BOOLEAN] */
static EIF_TYPE_INDEX ptf734[] = {722,867,0xFFF7,652,867,0xFFF7,551,867,834,0xFFFF};
static struct eif_par_types par734 = {734, ptf734, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [CHARACTER_32] */
static EIF_TYPE_INDEX ptf735[] = {723,861,0xFFF7,653,861,0xFFF7,552,861,834,0xFFFF};
static struct eif_par_types par735 = {735, ptf735, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [NATURAL_64] */
static EIF_TYPE_INDEX ptf736[] = {724,843,0xFFF7,654,843,0xFFF7,553,843,834,0xFFFF};
static struct eif_par_types par736 = {736, ptf736, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [CHARACTER_8] */
static EIF_TYPE_INDEX ptf737[] = {725,864,0xFFF7,655,864,0xFFF7,548,864,834,0xFFFF};
static struct eif_par_types par737 = {737, ptf737, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [NATURAL_8] */
static EIF_TYPE_INDEX ptf738[] = {726,852,0xFFF7,656,852,0xFFF7,554,852,834,0xFFFF};
static struct eif_par_types par738 = {738, ptf738, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [NATURAL_16] */
static EIF_TYPE_INDEX ptf739[] = {727,849,0xFFF7,657,849,0xFFF7,555,849,834,0xFFFF};
static struct eif_par_types par739 = {739, ptf739, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [REAL_32] */
static EIF_TYPE_INDEX ptf740[] = {728,855,0xFFF7,658,855,0xFFF7,556,855,834,0xFFFF};
static struct eif_par_types par740 = {740, ptf740, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [REAL_64] */
static EIF_TYPE_INDEX ptf741[] = {729,858,0xFFF7,659,858,0xFFF7,557,858,834,0xFFFF};
static struct eif_par_types par741 = {741, ptf741, (uint16) 3, (uint16) 1, (char) 0};

/* DYNAMIC_CHAIN [NATURAL_32] */
static EIF_TYPE_INDEX ptf742[] = {730,846,0xFFF7,660,846,0xFFF7,558,846,834,0xFFFF};
static struct eif_par_types par742 = {742, ptf742, (uint16) 3, (uint16) 1, (char) 0};

/* LIST [G#1] */
static EIF_TYPE_INDEX ptf743[] = {719,0xFFF8,1,0xFFFF};
static struct eif_par_types par743 = {743, ptf743, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf744[] = {720,834,0xFFFF};
static struct eif_par_types par744 = {744, ptf744, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [POINTER] */
static EIF_TYPE_INDEX ptf745[] = {721,900,0xFFFF};
static struct eif_par_types par745 = {745, ptf745, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [BOOLEAN] */
static EIF_TYPE_INDEX ptf746[] = {722,867,0xFFFF};
static struct eif_par_types par746 = {746, ptf746, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [CHARACTER_32] */
static EIF_TYPE_INDEX ptf747[] = {723,861,0xFFFF};
static struct eif_par_types par747 = {747, ptf747, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [NATURAL_64] */
static EIF_TYPE_INDEX ptf748[] = {724,843,0xFFFF};
static struct eif_par_types par748 = {748, ptf748, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [CHARACTER_8] */
static EIF_TYPE_INDEX ptf749[] = {725,864,0xFFFF};
static struct eif_par_types par749 = {749, ptf749, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [NATURAL_8] */
static EIF_TYPE_INDEX ptf750[] = {726,852,0xFFFF};
static struct eif_par_types par750 = {750, ptf750, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [NATURAL_16] */
static EIF_TYPE_INDEX ptf751[] = {727,849,0xFFFF};
static struct eif_par_types par751 = {751, ptf751, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [REAL_32] */
static EIF_TYPE_INDEX ptf752[] = {728,855,0xFFFF};
static struct eif_par_types par752 = {752, ptf752, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [REAL_64] */
static EIF_TYPE_INDEX ptf753[] = {729,858,0xFFFF};
static struct eif_par_types par753 = {753, ptf753, (uint16) 1, (uint16) 1, (char) 0};

/* LIST [NATURAL_32] */
static EIF_TYPE_INDEX ptf754[] = {730,846,0xFFFF};
static struct eif_par_types par754 = {754, ptf754, (uint16) 1, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [G#1] */
static EIF_TYPE_INDEX ptf755[] = {743,0xFFF8,1,0xFFF7,731,0xFFF8,1,0xFFFF};
static struct eif_par_types par755 = {755, ptf755, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf756[] = {744,834,0xFFF7,732,834,0xFFFF};
static struct eif_par_types par756 = {756, ptf756, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [POINTER] */
static EIF_TYPE_INDEX ptf757[] = {745,900,0xFFF7,733,900,0xFFFF};
static struct eif_par_types par757 = {757, ptf757, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [BOOLEAN] */
static EIF_TYPE_INDEX ptf758[] = {746,867,0xFFF7,734,867,0xFFFF};
static struct eif_par_types par758 = {758, ptf758, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [CHARACTER_32] */
static EIF_TYPE_INDEX ptf759[] = {747,861,0xFFF7,735,861,0xFFFF};
static struct eif_par_types par759 = {759, ptf759, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [NATURAL_64] */
static EIF_TYPE_INDEX ptf760[] = {748,843,0xFFF7,736,843,0xFFFF};
static struct eif_par_types par760 = {760, ptf760, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [CHARACTER_8] */
static EIF_TYPE_INDEX ptf761[] = {749,864,0xFFF7,737,864,0xFFFF};
static struct eif_par_types par761 = {761, ptf761, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [NATURAL_8] */
static EIF_TYPE_INDEX ptf762[] = {750,852,0xFFF7,738,852,0xFFFF};
static struct eif_par_types par762 = {762, ptf762, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [NATURAL_16] */
static EIF_TYPE_INDEX ptf763[] = {751,849,0xFFF7,739,849,0xFFFF};
static struct eif_par_types par763 = {763, ptf763, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [REAL_32] */
static EIF_TYPE_INDEX ptf764[] = {752,855,0xFFF7,740,855,0xFFFF};
static struct eif_par_types par764 = {764, ptf764, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [REAL_64] */
static EIF_TYPE_INDEX ptf765[] = {753,858,0xFFF7,741,858,0xFFFF};
static struct eif_par_types par765 = {765, ptf765, (uint16) 2, (uint16) 1, (char) 0};

/* DYNAMIC_LIST [NATURAL_32] */
static EIF_TYPE_INDEX ptf766[] = {754,846,0xFFF7,742,846,0xFFFF};
static struct eif_par_types par766 = {766, ptf766, (uint16) 2, (uint16) 1, (char) 0};

/* LINKED_LIST [G#1] */
static EIF_TYPE_INDEX ptf767[] = {755,0xFFF8,1,0xFFFF};
static struct eif_par_types par767 = {767, ptf767, (uint16) 1, (uint16) 1, (char) 0};

/* LINKED_LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf768[] = {756,834,0xFFFF};
static struct eif_par_types par768 = {768, ptf768, (uint16) 1, (uint16) 1, (char) 0};

/* KL_IMPORTED_ARRAY_ROUTINES */
static EIF_TYPE_INDEX ptf769[] = {0,0xFFFF};
static struct eif_par_types par769 = {769, ptf769, (uint16) 1, (uint16) 0, (char) 0};

/* KI_DIRECTORY */
static EIF_TYPE_INDEX ptf770[] = {112,0xFFF7,125,0xFF01,914,0xFFF7,769,0xFFFF};
static struct eif_par_types par770 = {770, ptf770, (uint16) 3, (uint16) 0, (char) 0};

/* MISMATCH_CORRECTOR */
static EIF_TYPE_INDEX ptf771[] = {0,0xFFFF};
static struct eif_par_types par771 = {771, ptf771, (uint16) 1, (uint16) 0, (char) 0};

/* ARRAYED_QUEUE [G#1] */
static EIF_TYPE_INDEX ptf772[] = {612,0xFFF8,1,0xFFF7,625,0xFFF8,1,0xFFF7,771,0xFFFF};
static struct eif_par_types par772 = {772, ptf772, (uint16) 3, (uint16) 1, (char) 0};

/* ARRAYED_LIST [G#1] */
static EIF_TYPE_INDEX ptf773[] = {247,0xFFF8,1,0xFFF7,625,0xFFF8,1,0xFFF7,755,0xFFF8,1,0xFFF7,771,0xFFFF};
static struct eif_par_types par773 = {773, ptf773, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf774[] = {248,834,0xFFF7,626,834,0xFFF7,756,834,0xFFF7,771,0xFFFF};
static struct eif_par_types par774 = {774, ptf774, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [POINTER] */
static EIF_TYPE_INDEX ptf775[] = {249,900,0xFFF7,627,900,0xFFF7,757,900,0xFFF7,771,0xFFFF};
static struct eif_par_types par775 = {775, ptf775, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [BOOLEAN] */
static EIF_TYPE_INDEX ptf776[] = {250,867,0xFFF7,628,867,0xFFF7,758,867,0xFFF7,771,0xFFFF};
static struct eif_par_types par776 = {776, ptf776, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [CHARACTER_32] */
static EIF_TYPE_INDEX ptf777[] = {251,861,0xFFF7,629,861,0xFFF7,759,861,0xFFF7,771,0xFFFF};
static struct eif_par_types par777 = {777, ptf777, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [NATURAL_64] */
static EIF_TYPE_INDEX ptf778[] = {252,843,0xFFF7,630,843,0xFFF7,760,843,0xFFF7,771,0xFFFF};
static struct eif_par_types par778 = {778, ptf778, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [CHARACTER_8] */
static EIF_TYPE_INDEX ptf779[] = {253,864,0xFFF7,631,864,0xFFF7,761,864,0xFFF7,771,0xFFFF};
static struct eif_par_types par779 = {779, ptf779, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [NATURAL_8] */
static EIF_TYPE_INDEX ptf780[] = {254,852,0xFFF7,632,852,0xFFF7,762,852,0xFFF7,771,0xFFFF};
static struct eif_par_types par780 = {780, ptf780, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [NATURAL_16] */
static EIF_TYPE_INDEX ptf781[] = {255,849,0xFFF7,633,849,0xFFF7,763,849,0xFFF7,771,0xFFFF};
static struct eif_par_types par781 = {781, ptf781, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [REAL_32] */
static EIF_TYPE_INDEX ptf782[] = {256,855,0xFFF7,634,855,0xFFF7,764,855,0xFFF7,771,0xFFFF};
static struct eif_par_types par782 = {782, ptf782, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [REAL_64] */
static EIF_TYPE_INDEX ptf783[] = {257,858,0xFFF7,635,858,0xFFF7,765,858,0xFFF7,771,0xFFFF};
static struct eif_par_types par783 = {783, ptf783, (uint16) 4, (uint16) 1, (char) 0};

/* ARRAYED_LIST [NATURAL_32] */
static EIF_TYPE_INDEX ptf784[] = {258,846,0xFFF7,636,846,0xFFF7,766,846,0xFFF7,771,0xFFFF};
static struct eif_par_types par784 = {784, ptf784, (uint16) 4, (uint16) 1, (char) 0};

/* HASH_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf785[] = {649,0xFFF8,1,0xFFF7,544,0xFFF8,1,0xFFF8,2,0xFFF7,358,0xFFF8,1,0xFFF8,2,0xFFF7,664,0xFFF8,1,0xFFF7,771,0xFFFF};
static struct eif_par_types par785 = {785, ptf785, (uint16) 5, (uint16) 2, (char) 0};

/* HASH_TABLE [POINTER, G#2] */
static EIF_TYPE_INDEX ptf786[] = {651,900,0xFFF7,549,900,0xFFF8,2,0xFFF7,359,900,0xFFF8,2,0xFFF7,667,900,0xFFF7,771,0xFFFF};
static struct eif_par_types par786 = {786, ptf786, (uint16) 5, (uint16) 2, (char) 0};

/* HASH_TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf787[] = {649,0xFFF8,1,0xFFF7,545,0xFFF8,1,834,0xFFF7,360,0xFFF8,1,834,0xFFF7,664,0xFFF8,1,0xFFF7,771,0xFFFF};
static struct eif_par_types par787 = {787, ptf787, (uint16) 5, (uint16) 2, (char) 0};

/* HASH_TABLE [INTEGER_32, G#2] */
static EIF_TYPE_INDEX ptf788[] = {650,834,0xFFF7,546,834,0xFFF8,2,0xFFF7,361,834,0xFFF8,2,0xFFF7,665,834,0xFFF7,771,0xFFFF};
static struct eif_par_types par788 = {788, ptf788, (uint16) 5, (uint16) 2, (char) 0};

/* HASH_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf789[] = {650,834,0xFFF7,547,834,834,0xFFF7,362,834,834,0xFFF7,665,834,0xFFF7,771,0xFFFF};
static struct eif_par_types par789 = {789, ptf789, (uint16) 5, (uint16) 2, (char) 0};

/* STRING_TABLE [G#1] */
static EIF_TYPE_INDEX ptf790[] = {785,0xFFF8,1,0xFF01,906,0xFFFF};
static struct eif_par_types par790 = {790, ptf790, (uint16) 1, (uint16) 1, (char) 0};

/* STRING_TABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf791[] = {788,834,0xFF01,906,0xFFFF};
static struct eif_par_types par791 = {791, ptf791, (uint16) 1, (uint16) 1, (char) 0};

/* MISMATCH_INFORMATION */
static EIF_TYPE_INDEX ptf792[] = {785,0,0xFF01,914,0xFFFF};
static struct eif_par_types par792 = {792, ptf792, (uint16) 1, (uint16) 0, (char) 0};

/* KL_IMPORTED_INTEGER_ROUTINES */
static EIF_TYPE_INDEX ptf793[] = {0,0xFFFF};
static struct eif_par_types par793 = {793, ptf793, (uint16) 1, (uint16) 0, (char) 0};

/* HASHABLE */
static EIF_TYPE_INDEX ptf794[] = {0,0xFFFF};
static struct eif_par_types par794 = {794, ptf794, (uint16) 1, (uint16) 0, (char) 0};

/* PATH */
static EIF_TYPE_INDEX ptf795[] = {794,0xFFF7,160,0xFFF7,259,0xFFF7,273,0xFFFF};
static struct eif_par_types par795 = {795, ptf795, (uint16) 4, (uint16) 0, (char) 0};

/* LX_SYMBOL_CLASS */
static EIF_TYPE_INDEX ptf796[] = {794,0xFFFF};
static struct eif_par_types par796 = {796, ptf796, (uint16) 1, (uint16) 0, (char) 0};

/* TYPE [G#1] */
static EIF_TYPE_INDEX ptf797[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par797 = {797, ptf797, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [ANY]] */
static EIF_TYPE_INDEX ptf798[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par798 = {798, ptf798, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [POINTER] */
static EIF_TYPE_INDEX ptf799[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par799 = {799, ptf799, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [INTEGER_32] */
static EIF_TYPE_INDEX ptf800[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par800 = {800, ptf800, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [REAL_64] */
static EIF_TYPE_INDEX ptf801[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par801 = {801, ptf801, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [REAL_32] */
static EIF_TYPE_INDEX ptf802[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par802 = {802, ptf802, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [NATURAL_8] */
static EIF_TYPE_INDEX ptf803[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par803 = {803, ptf803, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [NATURAL_16] */
static EIF_TYPE_INDEX ptf804[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par804 = {804, ptf804, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [NATURAL_32] */
static EIF_TYPE_INDEX ptf805[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par805 = {805, ptf805, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [NATURAL_64] */
static EIF_TYPE_INDEX ptf806[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par806 = {806, ptf806, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [INTEGER_8] */
static EIF_TYPE_INDEX ptf807[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par807 = {807, ptf807, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [INTEGER_16] */
static EIF_TYPE_INDEX ptf808[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par808 = {808, ptf808, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [INTEGER_64] */
static EIF_TYPE_INDEX ptf809[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par809 = {809, ptf809, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf810[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par810 = {810, ptf810, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [BOOLEAN] */
static EIF_TYPE_INDEX ptf811[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par811 = {811, ptf811, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [CHARACTER_32] */
static EIF_TYPE_INDEX ptf812[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par812 = {812, ptf812, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [INTEGER_64]] */
static EIF_TYPE_INDEX ptf813[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par813 = {813, ptf813, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [INTEGER_16]] */
static EIF_TYPE_INDEX ptf814[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par814 = {814, ptf814, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [NATURAL_64]] */
static EIF_TYPE_INDEX ptf815[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par815 = {815, ptf815, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [NATURAL_32]] */
static EIF_TYPE_INDEX ptf816[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par816 = {816, ptf816, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [NATURAL_16]] */
static EIF_TYPE_INDEX ptf817[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par817 = {817, ptf817, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [NATURAL_8]] */
static EIF_TYPE_INDEX ptf818[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par818 = {818, ptf818, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [REAL_32]] */
static EIF_TYPE_INDEX ptf819[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par819 = {819, ptf819, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [REAL_64]] */
static EIF_TYPE_INDEX ptf820[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par820 = {820, ptf820, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [UTF_CONVERTER] */
static EIF_TYPE_INDEX ptf821[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par821 = {821, ptf821, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [POINTER]] */
static EIF_TYPE_INDEX ptf822[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par822 = {822, ptf822, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [INTEGER_8]] */
static EIF_TYPE_INDEX ptf823[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par823 = {823, ptf823, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [INTEGER_32]] */
static EIF_TYPE_INDEX ptf824[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par824 = {824, ptf824, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [CHARACTER_8]] */
static EIF_TYPE_INDEX ptf825[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par825 = {825, ptf825, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [CHARACTER_32]] */
static EIF_TYPE_INDEX ptf826[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par826 = {826, ptf826, (uint16) 3, (uint16) 1, (char) 0};

/* TYPE [TYPED_POINTER [BOOLEAN]] */
static EIF_TYPE_INDEX ptf827[] = {794,0xFFF7,159,0xFFF7,273,0xFFFF};
static struct eif_par_types par827 = {827, ptf827, (uint16) 3, (uint16) 1, (char) 0};

/* TUPLE */
static EIF_TYPE_INDEX ptf828[] = {794,0xFFF7,771,0xFFF7,664,0,0xFFFF};
static struct eif_par_types par828 = {828, ptf828, (uint16) 3, (uint16) 0, (char) 0};

/* INTEGER_64_REF */
static EIF_TYPE_INDEX ptf829[] = {322,0xFFF7,160,0xFFF7,794,0xFFFF};
static struct eif_par_types par829 = {829, ptf829, (uint16) 3, (uint16) 0, (char) 0};

/* reference INTEGER_64 */
static EIF_TYPE_INDEX ptf830[] = {829,0xFFFF};
static struct eif_par_types par830 = {830, ptf830, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_64 */
static EIF_TYPE_INDEX ptf831[] = {830,0xFFFF};
static struct eif_par_types par831 = {831, ptf831, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_32_REF */
static EIF_TYPE_INDEX ptf832[] = {322,0xFFF7,160,0xFFF7,794,0xFFFF};
static struct eif_par_types par832 = {832, ptf832, (uint16) 3, (uint16) 0, (char) 0};

/* reference INTEGER_32 */
static EIF_TYPE_INDEX ptf833[] = {832,0xFFFF};
static struct eif_par_types par833 = {833, ptf833, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_32 */
static EIF_TYPE_INDEX ptf834[] = {833,0xFFFF};
static struct eif_par_types par834 = {834, ptf834, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_16_REF */
static EIF_TYPE_INDEX ptf835[] = {322,0xFFF7,160,0xFFF7,794,0xFFFF};
static struct eif_par_types par835 = {835, ptf835, (uint16) 3, (uint16) 0, (char) 0};

/* reference INTEGER_16 */
static EIF_TYPE_INDEX ptf836[] = {835,0xFFFF};
static struct eif_par_types par836 = {836, ptf836, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_16 */
static EIF_TYPE_INDEX ptf837[] = {836,0xFFFF};
static struct eif_par_types par837 = {837, ptf837, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_8_REF */
static EIF_TYPE_INDEX ptf838[] = {322,0xFFF7,160,0xFFF7,794,0xFFFF};
static struct eif_par_types par838 = {838, ptf838, (uint16) 3, (uint16) 0, (char) 0};

/* reference INTEGER_8 */
static EIF_TYPE_INDEX ptf839[] = {838,0xFFFF};
static struct eif_par_types par839 = {839, ptf839, (uint16) 1, (uint16) 0, (char) 1};

/* INTEGER_8 */
static EIF_TYPE_INDEX ptf840[] = {839,0xFFFF};
static struct eif_par_types par840 = {840, ptf840, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_64_REF */
static EIF_TYPE_INDEX ptf841[] = {322,0xFFF7,160,0xFFF7,794,0xFFFF};
static struct eif_par_types par841 = {841, ptf841, (uint16) 3, (uint16) 0, (char) 0};

/* reference NATURAL_64 */
static EIF_TYPE_INDEX ptf842[] = {841,0xFFFF};
static struct eif_par_types par842 = {842, ptf842, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_64 */
static EIF_TYPE_INDEX ptf843[] = {842,0xFFFF};
static struct eif_par_types par843 = {843, ptf843, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_32_REF */
static EIF_TYPE_INDEX ptf844[] = {322,0xFFF7,160,0xFFF7,794,0xFFFF};
static struct eif_par_types par844 = {844, ptf844, (uint16) 3, (uint16) 0, (char) 0};

/* reference NATURAL_32 */
static EIF_TYPE_INDEX ptf845[] = {844,0xFFFF};
static struct eif_par_types par845 = {845, ptf845, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_32 */
static EIF_TYPE_INDEX ptf846[] = {845,0xFFFF};
static struct eif_par_types par846 = {846, ptf846, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_16_REF */
static EIF_TYPE_INDEX ptf847[] = {322,0xFFF7,160,0xFFF7,794,0xFFFF};
static struct eif_par_types par847 = {847, ptf847, (uint16) 3, (uint16) 0, (char) 0};

/* reference NATURAL_16 */
static EIF_TYPE_INDEX ptf848[] = {847,0xFFFF};
static struct eif_par_types par848 = {848, ptf848, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_16 */
static EIF_TYPE_INDEX ptf849[] = {848,0xFFFF};
static struct eif_par_types par849 = {849, ptf849, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_8_REF */
static EIF_TYPE_INDEX ptf850[] = {322,0xFFF7,160,0xFFF7,794,0xFFFF};
static struct eif_par_types par850 = {850, ptf850, (uint16) 3, (uint16) 0, (char) 0};

/* reference NATURAL_8 */
static EIF_TYPE_INDEX ptf851[] = {850,0xFFFF};
static struct eif_par_types par851 = {851, ptf851, (uint16) 1, (uint16) 0, (char) 1};

/* NATURAL_8 */
static EIF_TYPE_INDEX ptf852[] = {851,0xFFFF};
static struct eif_par_types par852 = {852, ptf852, (uint16) 1, (uint16) 0, (char) 1};

/* REAL_32_REF */
static EIF_TYPE_INDEX ptf853[] = {322,0xFFF7,160,0xFFF7,794,0xFFFF};
static struct eif_par_types par853 = {853, ptf853, (uint16) 3, (uint16) 0, (char) 0};

/* reference REAL_32 */
static EIF_TYPE_INDEX ptf854[] = {853,0xFFFF};
static struct eif_par_types par854 = {854, ptf854, (uint16) 1, (uint16) 0, (char) 1};

/* REAL_32 */
static EIF_TYPE_INDEX ptf855[] = {854,0xFFFF};
static struct eif_par_types par855 = {855, ptf855, (uint16) 1, (uint16) 0, (char) 1};

/* REAL_64_REF */
static EIF_TYPE_INDEX ptf856[] = {322,0xFFF7,160,0xFFF7,794,0xFFFF};
static struct eif_par_types par856 = {856, ptf856, (uint16) 3, (uint16) 0, (char) 0};

/* reference REAL_64 */
static EIF_TYPE_INDEX ptf857[] = {856,0xFFFF};
static struct eif_par_types par857 = {857, ptf857, (uint16) 1, (uint16) 0, (char) 1};

/* REAL_64 */
static EIF_TYPE_INDEX ptf858[] = {857,0xFFFF};
static struct eif_par_types par858 = {858, ptf858, (uint16) 1, (uint16) 0, (char) 1};

/* CHARACTER_32_REF */
static EIF_TYPE_INDEX ptf859[] = {160,0xFFF7,794,0xFFFF};
static struct eif_par_types par859 = {859, ptf859, (uint16) 2, (uint16) 0, (char) 0};

/* reference CHARACTER_32 */
static EIF_TYPE_INDEX ptf860[] = {859,0xFFFF};
static struct eif_par_types par860 = {860, ptf860, (uint16) 1, (uint16) 0, (char) 1};

/* CHARACTER_32 */
static EIF_TYPE_INDEX ptf861[] = {860,0xFFFF};
static struct eif_par_types par861 = {861, ptf861, (uint16) 1, (uint16) 0, (char) 1};

/* CHARACTER_8_REF */
static EIF_TYPE_INDEX ptf862[] = {160,0xFFF7,794,0xFFFF};
static struct eif_par_types par862 = {862, ptf862, (uint16) 2, (uint16) 0, (char) 0};

/* reference CHARACTER_8 */
static EIF_TYPE_INDEX ptf863[] = {862,0xFFFF};
static struct eif_par_types par863 = {863, ptf863, (uint16) 1, (uint16) 0, (char) 1};

/* CHARACTER_8 */
static EIF_TYPE_INDEX ptf864[] = {863,0xFFFF};
static struct eif_par_types par864 = {864, ptf864, (uint16) 1, (uint16) 0, (char) 1};

/* BOOLEAN_REF */
static EIF_TYPE_INDEX ptf865[] = {794,0xFFFF};
static struct eif_par_types par865 = {865, ptf865, (uint16) 1, (uint16) 0, (char) 0};

/* reference BOOLEAN */
static EIF_TYPE_INDEX ptf866[] = {865,0xFFFF};
static struct eif_par_types par866 = {866, ptf866, (uint16) 1, (uint16) 0, (char) 1};

/* BOOLEAN */
static EIF_TYPE_INDEX ptf867[] = {866,0xFFFF};
static struct eif_par_types par867 = {867, ptf867, (uint16) 1, (uint16) 0, (char) 1};

/* POINTER_REF */
static EIF_TYPE_INDEX ptf868[] = {794,0xFFF7,94,0xFFFF};
static struct eif_par_types par868 = {868, ptf868, (uint16) 2, (uint16) 0, (char) 0};

/* reference TYPED_POINTER [G#1] */
static EIF_TYPE_INDEX ptf869[] = {868,0xFFFF};
static struct eif_par_types par869 = {869, ptf869, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [G#1] */
static EIF_TYPE_INDEX ptf870[] = {869,0xFFF8,1,0xFFFF};
static struct eif_par_types par870 = {870, ptf870, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [INTEGER_64] */
static EIF_TYPE_INDEX ptf871[] = {868,0xFFFF};
static struct eif_par_types par871 = {871, ptf871, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [INTEGER_64] */
static EIF_TYPE_INDEX ptf872[] = {871,831,0xFFFF};
static struct eif_par_types par872 = {872, ptf872, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [INTEGER_16] */
static EIF_TYPE_INDEX ptf873[] = {868,0xFFFF};
static struct eif_par_types par873 = {873, ptf873, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [INTEGER_16] */
static EIF_TYPE_INDEX ptf874[] = {873,837,0xFFFF};
static struct eif_par_types par874 = {874, ptf874, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [NATURAL_64] */
static EIF_TYPE_INDEX ptf875[] = {868,0xFFFF};
static struct eif_par_types par875 = {875, ptf875, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [NATURAL_64] */
static EIF_TYPE_INDEX ptf876[] = {875,843,0xFFFF};
static struct eif_par_types par876 = {876, ptf876, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [NATURAL_32] */
static EIF_TYPE_INDEX ptf877[] = {868,0xFFFF};
static struct eif_par_types par877 = {877, ptf877, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [NATURAL_32] */
static EIF_TYPE_INDEX ptf878[] = {877,846,0xFFFF};
static struct eif_par_types par878 = {878, ptf878, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [NATURAL_16] */
static EIF_TYPE_INDEX ptf879[] = {868,0xFFFF};
static struct eif_par_types par879 = {879, ptf879, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [NATURAL_16] */
static EIF_TYPE_INDEX ptf880[] = {879,849,0xFFFF};
static struct eif_par_types par880 = {880, ptf880, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [NATURAL_8] */
static EIF_TYPE_INDEX ptf881[] = {868,0xFFFF};
static struct eif_par_types par881 = {881, ptf881, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [NATURAL_8] */
static EIF_TYPE_INDEX ptf882[] = {881,852,0xFFFF};
static struct eif_par_types par882 = {882, ptf882, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [REAL_32] */
static EIF_TYPE_INDEX ptf883[] = {868,0xFFFF};
static struct eif_par_types par883 = {883, ptf883, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [REAL_32] */
static EIF_TYPE_INDEX ptf884[] = {883,855,0xFFFF};
static struct eif_par_types par884 = {884, ptf884, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [REAL_64] */
static EIF_TYPE_INDEX ptf885[] = {868,0xFFFF};
static struct eif_par_types par885 = {885, ptf885, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [REAL_64] */
static EIF_TYPE_INDEX ptf886[] = {885,858,0xFFFF};
static struct eif_par_types par886 = {886, ptf886, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [POINTER] */
static EIF_TYPE_INDEX ptf887[] = {868,0xFFFF};
static struct eif_par_types par887 = {887, ptf887, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [POINTER] */
static EIF_TYPE_INDEX ptf888[] = {887,900,0xFFFF};
static struct eif_par_types par888 = {888, ptf888, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [INTEGER_8] */
static EIF_TYPE_INDEX ptf889[] = {868,0xFFFF};
static struct eif_par_types par889 = {889, ptf889, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [INTEGER_8] */
static EIF_TYPE_INDEX ptf890[] = {889,840,0xFFFF};
static struct eif_par_types par890 = {890, ptf890, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [INTEGER_32] */
static EIF_TYPE_INDEX ptf891[] = {868,0xFFFF};
static struct eif_par_types par891 = {891, ptf891, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [INTEGER_32] */
static EIF_TYPE_INDEX ptf892[] = {891,834,0xFFFF};
static struct eif_par_types par892 = {892, ptf892, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf893[] = {868,0xFFFF};
static struct eif_par_types par893 = {893, ptf893, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf894[] = {893,864,0xFFFF};
static struct eif_par_types par894 = {894, ptf894, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [CHARACTER_32] */
static EIF_TYPE_INDEX ptf895[] = {868,0xFFFF};
static struct eif_par_types par895 = {895, ptf895, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [CHARACTER_32] */
static EIF_TYPE_INDEX ptf896[] = {895,861,0xFFFF};
static struct eif_par_types par896 = {896, ptf896, (uint16) 1, (uint16) 1, (char) 1};

/* reference TYPED_POINTER [BOOLEAN] */
static EIF_TYPE_INDEX ptf897[] = {868,0xFFFF};
static struct eif_par_types par897 = {897, ptf897, (uint16) 1, (uint16) 1, (char) 1};

/* TYPED_POINTER [BOOLEAN] */
static EIF_TYPE_INDEX ptf898[] = {897,867,0xFFFF};
static struct eif_par_types par898 = {898, ptf898, (uint16) 1, (uint16) 1, (char) 1};

/* reference POINTER */
static EIF_TYPE_INDEX ptf899[] = {868,0xFFFF};
static struct eif_par_types par899 = {899, ptf899, (uint16) 1, (uint16) 0, (char) 1};

/* POINTER */
static EIF_TYPE_INDEX ptf900[] = {899,0xFFFF};
static struct eif_par_types par900 = {900, ptf900, (uint16) 1, (uint16) 0, (char) 1};

/* ROUTINE [G#1] */
static EIF_TYPE_INDEX ptf901[] = {794,0xFFF7,771,0xFFFF};
static struct eif_par_types par901 = {901, ptf901, (uint16) 2, (uint16) 1, (char) 0};

/* PROCEDURE [G#1] */
static EIF_TYPE_INDEX ptf902[] = {901,0xFFF8,1,0xFFFF};
static struct eif_par_types par902 = {902, ptf902, (uint16) 1, (uint16) 1, (char) 0};

/* FUNCTION [G#1, G#2] */
static EIF_TYPE_INDEX ptf903[] = {901,0xFFF8,1,0xFFFF};
static struct eif_par_types par903 = {903, ptf903, (uint16) 1, (uint16) 2, (char) 0};

/* FUNCTION [G#1, BOOLEAN] */
static EIF_TYPE_INDEX ptf904[] = {901,0xFFF8,1,0xFFFF};
static struct eif_par_types par904 = {904, ptf904, (uint16) 1, (uint16) 2, (char) 0};

/* PREDICATE [G#1] */
static EIF_TYPE_INDEX ptf905[] = {904,0xFFF8,1,867,0xFFFF};
static struct eif_par_types par905 = {905, ptf905, (uint16) 1, (uint16) 1, (char) 0};

/* READABLE_STRING_GENERAL */
static EIF_TYPE_INDEX ptf906[] = {160,0xFFF7,794,0xFFF7,268,0xFFFF};
static struct eif_par_types par906 = {906, ptf906, (uint16) 3, (uint16) 0, (char) 0};

/* IMMUTABLE_STRING_GENERAL */
static EIF_TYPE_INDEX ptf907[] = {906,0xFFFF};
static struct eif_par_types par907 = {907, ptf907, (uint16) 1, (uint16) 0, (char) 0};

/* STRING_GENERAL */
static EIF_TYPE_INDEX ptf908[] = {906,0xFFFF};
static struct eif_par_types par908 = {908, ptf908, (uint16) 1, (uint16) 0, (char) 0};

/* READABLE_STRING_32 */
static EIF_TYPE_INDEX ptf909[] = {906,0xFFF7,669,861,0xFFFF};
static struct eif_par_types par909 = {909, ptf909, (uint16) 2, (uint16) 0, (char) 0};

/* IMMUTABLE_STRING_32 */
static EIF_TYPE_INDEX ptf910[] = {909,0xFFF7,907,0xFFF7,771,0xFFFF};
static struct eif_par_types par910 = {910, ptf910, (uint16) 3, (uint16) 0, (char) 0};

/* STRING_32 */
static EIF_TYPE_INDEX ptf911[] = {909,0xFFF7,908,0xFFF7,552,861,834,0xFFF7,692,861,834,0xFFF7,629,861,0xFFF7,251,861,0xFFF7,771,0xFFFF};
static struct eif_par_types par911 = {911, ptf911, (uint16) 7, (uint16) 0, (char) 0};

/* READABLE_STRING_8 */
static EIF_TYPE_INDEX ptf912[] = {906,0xFFF7,666,864,0xFFFF};
static struct eif_par_types par912 = {912, ptf912, (uint16) 2, (uint16) 0, (char) 0};

/* IMMUTABLE_STRING_8 */
static EIF_TYPE_INDEX ptf913[] = {912,0xFFF7,907,0xFFFF};
static struct eif_par_types par913 = {913, ptf913, (uint16) 2, (uint16) 0, (char) 0};

/* STRING_8 */
static EIF_TYPE_INDEX ptf914[] = {912,0xFFF7,908,0xFFF7,548,864,834,0xFFF7,694,864,834,0xFFF7,631,864,0xFFF7,253,864,0xFFF7,771,0xFFFF};
static struct eif_par_types par914 = {914, ptf914, (uint16) 7, (uint16) 0, (char) 0};

/* KL_STRING */
static EIF_TYPE_INDEX ptf915[] = {914,0xFFFF};
static struct eif_par_types par915 = {915, ptf915, (uint16) 1, (uint16) 0, (char) 0};

/* KL_IMPORTED_STRING_ROUTINES */
static EIF_TYPE_INDEX ptf916[] = {0,0xFFFF};
static struct eif_par_types par916 = {916, ptf916, (uint16) 1, (uint16) 0, (char) 0};

/* UC_STRING_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf917[] = {225,0xFF01,914,0xFFF7,916,0xFFFF};
static struct eif_par_types par917 = {917, ptf917, (uint16) 2, (uint16) 0, (char) 0};

/* KL_CASE_INSENSITIVE_STRING_EQUALITY_TESTER */
static EIF_TYPE_INDEX ptf918[] = {225,0xFF01,914,0xFFF7,916,0xFFFF};
static struct eif_par_types par918 = {918, ptf918, (uint16) 2, (uint16) 0, (char) 0};

/* ST_WORD_WRAPPER */
static EIF_TYPE_INDEX ptf919[] = {916,0xFFFF};
static struct eif_par_types par919 = {919, ptf919, (uint16) 1, (uint16) 0, (char) 0};

/* AP_OPTION_COMPARATOR */
static EIF_TYPE_INDEX ptf920[] = {232,0xFF01,115,0xFFF7,916,0xFFFF};
static struct eif_par_types par920 = {920, ptf920, (uint16) 2, (uint16) 0, (char) 0};

/* UC_CHARACTER */
static EIF_TYPE_INDEX ptf921[] = {161,0xFFF7,794,0xFFF7,64,0xFFF7,239,0xFFF7,793,0xFFF7,916,0xFFFF};
static struct eif_par_types par921 = {921, ptf921, (uint16) 6, (uint16) 0, (char) 0};

/* GELEX_COMMAND_LINE */
static EIF_TYPE_INDEX ptf922[] = {89,0xFFF7,916,0xFFF7,223,0xFFF7,222,0xFFFF};
static struct eif_par_types par922 = {922, ptf922, (uint16) 4, (uint16) 0, (char) 0};

/* KI_CHARACTER_OUTPUT_STREAM */
static EIF_TYPE_INDEX ptf923[] = {83,864,0xFFF7,916,0xFFFF};
static struct eif_par_types par923 = {923, ptf923, (uint16) 2, (uint16) 0, (char) 0};

/* KI_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf924[] = {113,0xFFF7,923,0xFFFF};
static struct eif_par_types par924 = {924, ptf924, (uint16) 2, (uint16) 0, (char) 0};

/* KI_BINARY_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf925[] = {924,0xFFFF};
static struct eif_par_types par925 = {925, ptf925, (uint16) 1, (uint16) 0, (char) 0};

/* KI_TEXT_OUTPUT_STREAM */
static EIF_TYPE_INDEX ptf926[] = {923,0xFFFF};
static struct eif_par_types par926 = {926, ptf926, (uint16) 1, (uint16) 0, (char) 0};

/* KL_STDERR_FILE */
static EIF_TYPE_INDEX ptf927[] = {926,0xFFFF};
static struct eif_par_types par927 = {927, ptf927, (uint16) 1, (uint16) 0, (char) 0};

/* KL_STDOUT_FILE */
static EIF_TYPE_INDEX ptf928[] = {926,0xFFFF};
static struct eif_par_types par928 = {928, ptf928, (uint16) 1, (uint16) 0, (char) 0};

/* KL_NULL_TEXT_OUTPUT_STREAM */
static EIF_TYPE_INDEX ptf929[] = {926,0xFFFF};
static struct eif_par_types par929 = {929, ptf929, (uint16) 1, (uint16) 0, (char) 0};

/* KI_TEXT_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf930[] = {924,0xFFF7,926,0xFFFF};
static struct eif_par_types par930 = {930, ptf930, (uint16) 2, (uint16) 0, (char) 0};

/* KL_IMPORTED_ANY_ROUTINES */
static EIF_TYPE_INDEX ptf931[] = {0,0xFFFF};
static struct eif_par_types par931 = {931, ptf931, (uint16) 1, (uint16) 0, (char) 0};

/* KL_NATURAL_32_ROUTINES */
static EIF_TYPE_INDEX ptf932[] = {931,0xFFFF};
static struct eif_par_types par932 = {932, ptf932, (uint16) 1, (uint16) 0, (char) 0};

/* UC_UTF32_ROUTINES */
static EIF_TYPE_INDEX ptf933[] = {66,0xFFF7,239,0xFFF7,931,0xFFF7,793,0xFFFF};
static struct eif_par_types par933 = {933, ptf933, (uint16) 4, (uint16) 0, (char) 0};

/* UC_UTF16_ROUTINES */
static EIF_TYPE_INDEX ptf934[] = {66,0xFFF7,931,0xFFF7,793,0xFFFF};
static struct eif_par_types par934 = {934, ptf934, (uint16) 3, (uint16) 0, (char) 0};

/* KL_STRING_ROUTINES */
static EIF_TYPE_INDEX ptf935[] = {64,0xFFF7,122,0xFFF7,793,0xFFF7,931,0xFFF7,239,0xFFF7,124,0xFFF7,123,0xFFFF};
static struct eif_par_types par935 = {935, ptf935, (uint16) 7, (uint16) 0, (char) 0};

/* KL_INTEGER_ROUTINES */
static EIF_TYPE_INDEX ptf936[] = {64,0xFFF7,916,0xFFF7,931,0xFFFF};
static struct eif_par_types par936 = {936, ptf936, (uint16) 3, (uint16) 0, (char) 0};

/* UC_UTF8_ROUTINES */
static EIF_TYPE_INDEX ptf937[] = {239,0xFFF7,931,0xFFFF};
static struct eif_par_types par937 = {937, ptf937, (uint16) 2, (uint16) 0, (char) 0};

/* KL_ARRAY_ROUTINES [G#1] */
static EIF_TYPE_INDEX ptf938[] = {931,0xFFFF};
static struct eif_par_types par938 = {938, ptf938, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY_ROUTINES [INTEGER_32] */
static EIF_TYPE_INDEX ptf939[] = {931,0xFFFF};
static struct eif_par_types par939 = {939, ptf939, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY_ROUTINES [CHARACTER_8] */
static EIF_TYPE_INDEX ptf940[] = {931,0xFFFF};
static struct eif_par_types par940 = {940, ptf940, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY_ROUTINES [BOOLEAN] */
static EIF_TYPE_INDEX ptf941[] = {931,0xFFFF};
static struct eif_par_types par941 = {941, ptf941, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY_ROUTINES [NATURAL_32] */
static EIF_TYPE_INDEX ptf942[] = {931,0xFFFF};
static struct eif_par_types par942 = {942, ptf942, (uint16) 1, (uint16) 1, (char) 0};

/* KL_ARRAY_ROUTINES [NATURAL_64] */
static EIF_TYPE_INDEX ptf943[] = {931,0xFFFF};
static struct eif_par_types par943 = {943, ptf943, (uint16) 1, (uint16) 1, (char) 0};

/* KI_CHARACTER_INPUT_STREAM */
static EIF_TYPE_INDEX ptf944[] = {126,864,0xFFF7,931,0xFFFF};
static struct eif_par_types par944 = {944, ptf944, (uint16) 2, (uint16) 0, (char) 0};

/* KI_TEXT_INPUT_STREAM */
static EIF_TYPE_INDEX ptf945[] = {944,0xFFFF};
static struct eif_par_types par945 = {945, ptf945, (uint16) 1, (uint16) 0, (char) 0};

/* KL_STDIN_FILE */
static EIF_TYPE_INDEX ptf946[] = {945,0xFFF7,916,0xFFF7,268,0xFFFF};
static struct eif_par_types par946 = {946, ptf946, (uint16) 3, (uint16) 0, (char) 0};

/* KL_STRING_INPUT_STREAM */
static EIF_TYPE_INDEX ptf947[] = {945,0xFFF7,916,0xFFFF};
static struct eif_par_types par947 = {947, ptf947, (uint16) 2, (uint16) 0, (char) 0};

/* KI_INPUT_FILE */
static EIF_TYPE_INDEX ptf948[] = {113,0xFFF7,944,0xFFF7,64,0xFFFF};
static struct eif_par_types par948 = {948, ptf948, (uint16) 3, (uint16) 0, (char) 0};

/* KI_BINARY_INPUT_FILE */
static EIF_TYPE_INDEX ptf949[] = {948,0xFFFF};
static struct eif_par_types par949 = {949, ptf949, (uint16) 1, (uint16) 0, (char) 0};

/* KI_TEXT_INPUT_FILE */
static EIF_TYPE_INDEX ptf950[] = {948,0xFFF7,945,0xFFFF};
static struct eif_par_types par950 = {950, ptf950, (uint16) 2, (uint16) 0, (char) 0};

/* RX_BYTE_CODE */
static EIF_TYPE_INDEX ptf951[] = {0,0xFFF7,267,0xFFFF};
static struct eif_par_types par951 = {951, ptf951, (uint16) 2, (uint16) 0, (char) 0};

/* UT_INTEGER_FORMATTER */
static EIF_TYPE_INDEX ptf952[] = {0,0xFFF7,793,0xFFFF};
static struct eif_par_types par952 = {952, ptf952, (uint16) 2, (uint16) 0, (char) 0};

/* CONSOLE */
static EIF_TYPE_INDEX ptf953[] = {663,0xFFF7,0,0xFFFF};
static struct eif_par_types par953 = {953, ptf953, (uint16) 2, (uint16) 0, (char) 0};

/* KL_TYPE [G#1] */
static EIF_TYPE_INDEX ptf954[] = {0,0xFFF7,931,0xFFFF};
static struct eif_par_types par954 = {954, ptf954, (uint16) 2, (uint16) 1, (char) 0};

/* KL_TYPE [INTEGER_32] */
static EIF_TYPE_INDEX ptf955[] = {0,0xFFF7,931,0xFFFF};
static struct eif_par_types par955 = {955, ptf955, (uint16) 2, (uint16) 1, (char) 0};

/* KL_TYPE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf956[] = {0,0xFFF7,931,0xFFFF};
static struct eif_par_types par956 = {956, ptf956, (uint16) 2, (uint16) 1, (char) 0};

/* KL_TYPE [BOOLEAN] */
static EIF_TYPE_INDEX ptf957[] = {0,0xFFF7,931,0xFFFF};
static struct eif_par_types par957 = {957, ptf957, (uint16) 2, (uint16) 1, (char) 0};

/* KL_TYPE [NATURAL_32] */
static EIF_TYPE_INDEX ptf958[] = {0,0xFFF7,931,0xFFFF};
static struct eif_par_types par958 = {958, ptf958, (uint16) 2, (uint16) 1, (char) 0};

/* KL_TYPE [NATURAL_64] */
static EIF_TYPE_INDEX ptf959[] = {0,0xFFF7,931,0xFFFF};
static struct eif_par_types par959 = {959, ptf959, (uint16) 2, (uint16) 1, (char) 0};

/* RX_PCRE_ESCAPE_CONSTANTS */
static EIF_TYPE_INDEX ptf960[] = {0,0xFFF7,109,0xFFFF};
static struct eif_par_types par960 = {960, ptf960, (uint16) 2, (uint16) 0, (char) 0};

/* UC_V510_CTYPE_TITLECASE */
static EIF_TYPE_INDEX ptf961[] = {0,0xFFF7,793,0xFFFF};
static struct eif_par_types par961 = {961, ptf961, (uint16) 2, (uint16) 0, (char) 0};

/* UC_V510_CTYPE_UPPERCASE */
static EIF_TYPE_INDEX ptf962[] = {0,0xFFF7,793,0xFFFF};
static struct eif_par_types par962 = {962, ptf962, (uint16) 2, (uint16) 0, (char) 0};

/* UC_V510_CTYPE_LOWERCASE */
static EIF_TYPE_INDEX ptf963[] = {0,0xFFF7,793,0xFFFF};
static struct eif_par_types par963 = {963, ptf963, (uint16) 2, (uint16) 0, (char) 0};

/* UC_V510_CTYPE */
static EIF_TYPE_INDEX ptf964[] = {963,0xFFF7,962,0xFFF7,961,0xFFF7,66,0xFFFF};
static struct eif_par_types par964 = {964, ptf964, (uint16) 4, (uint16) 0, (char) 0};

/* UC_CTYPE */
static EIF_TYPE_INDEX ptf965[] = {964,0xFFFF};
static struct eif_par_types par965 = {965, ptf965, (uint16) 1, (uint16) 0, (char) 0};

/* YY_SCANNER */
static EIF_TYPE_INDEX ptf966[] = {0,0xFFF7,265,0xFFFF};
static struct eif_par_types par966 = {966, ptf966, (uint16) 2, (uint16) 0, (char) 0};

/* YY_SCANNER_SKELETON */
static EIF_TYPE_INDEX ptf967[] = {966,0xFFF7,267,0xFFF7,916,0xFFF7,769,0xFFFF};
static struct eif_par_types par967 = {967, ptf967, (uint16) 4, (uint16) 0, (char) 0};

/* YY_FULL_SCANNER_SKELETON */
static EIF_TYPE_INDEX ptf968[] = {967,0xFFFF};
static struct eif_par_types par968 = {968, ptf968, (uint16) 1, (uint16) 0, (char) 0};

/* YY_COMPRESSED_SCANNER_SKELETON */
static EIF_TYPE_INDEX ptf969[] = {967,0xFFFF};
static struct eif_par_types par969 = {969, ptf969, (uint16) 1, (uint16) 0, (char) 0};

/* LX_LEX_SCANNER_SKELETON */
static EIF_TYPE_INDEX ptf970[] = {969,0xFFF7,147,0xFFF7,916,0xFFF7,236,0xFFFF};
static struct eif_par_types par970 = {970, ptf970, (uint16) 4, (uint16) 0, (char) 0};

/* ENCODING_I */
static EIF_TYPE_INDEX ptf971[] = {0,0xFFFF};
static struct eif_par_types par971 = {971, ptf971, (uint16) 1, (uint16) 0, (char) 0};

/* ENCODING_IMP */
static EIF_TYPE_INDEX ptf972[] = {971,0xFFFF};
static struct eif_par_types par972 = {972, ptf972, (uint16) 1, (uint16) 0, (char) 0};

/* UNICODE_CONVERSION */
static EIF_TYPE_INDEX ptf973[] = {971,0xFFFF};
static struct eif_par_types par973 = {973, ptf973, (uint16) 1, (uint16) 0, (char) 0};

/* DS_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf974[] = {0,0xFFF7,931,0xFFFF};
static struct eif_par_types par974 = {974, ptf974, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf975[] = {0,0xFFF7,931,0xFFFF};
static struct eif_par_types par975 = {975, ptf975, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf976[] = {0,0xFFF7,931,0xFFFF};
static struct eif_par_types par976 = {976, ptf976, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf977[] = {0,0xFFF7,931,0xFFFF};
static struct eif_par_types par977 = {977, ptf977, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf978[] = {0,0xFFF7,931,0xFFFF};
static struct eif_par_types par978 = {978, ptf978, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf979[] = {0,0xFFF7,931,0xFFFF};
static struct eif_par_types par979 = {979, ptf979, (uint16) 2, (uint16) 1, (char) 0};

/* DS_INDEXED_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf980[] = {974,0xFFF8,1,0xFFFF};
static struct eif_par_types par980 = {980, ptf980, (uint16) 1, (uint16) 1, (char) 0};

/* DS_INDEXED_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf981[] = {975,834,0xFFFF};
static struct eif_par_types par981 = {981, ptf981, (uint16) 1, (uint16) 1, (char) 0};

/* DS_INDEXED_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf982[] = {976,864,0xFFFF};
static struct eif_par_types par982 = {982, ptf982, (uint16) 1, (uint16) 1, (char) 0};

/* DS_INDEXED_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf983[] = {977,867,0xFFFF};
static struct eif_par_types par983 = {983, ptf983, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DYNAMIC_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf984[] = {974,0xFFF8,1,0xFFFF};
static struct eif_par_types par984 = {984, ptf984, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DYNAMIC_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf985[] = {975,834,0xFFFF};
static struct eif_par_types par985 = {985, ptf985, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DYNAMIC_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf986[] = {976,864,0xFFFF};
static struct eif_par_types par986 = {986, ptf986, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DYNAMIC_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf987[] = {977,867,0xFFFF};
static struct eif_par_types par987 = {987, ptf987, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DYNAMIC_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf988[] = {978,843,0xFFFF};
static struct eif_par_types par988 = {988, ptf988, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf989[] = {974,0xFFF8,1,0xFFF7,323,0xFFF8,1,0xFFF7,342,0xFFF8,1,0xFFFF};
static struct eif_par_types par989 = {989, ptf989, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf990[] = {975,834,0xFFF7,324,834,0xFFF7,343,834,0xFFFF};
static struct eif_par_types par990 = {990, ptf990, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf991[] = {976,864,0xFFF7,325,864,0xFFF7,344,864,0xFFFF};
static struct eif_par_types par991 = {991, ptf991, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf992[] = {977,867,0xFFF7,327,867,0xFFF7,346,867,0xFFFF};
static struct eif_par_types par992 = {992, ptf992, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf993[] = {978,843,0xFFF7,329,843,0xFFF7,348,843,0xFFFF};
static struct eif_par_types par993 = {993, ptf993, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf994[] = {979,846,0xFFF7,334,846,0xFFF7,353,846,0xFFFF};
static struct eif_par_types par994 = {994, ptf994, (uint16) 3, (uint16) 1, (char) 0};

/* DS_SET_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf995[] = {989,0xFFF8,1,0xFFFF};
static struct eif_par_types par995 = {995, ptf995, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SET_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf996[] = {990,834,0xFFFF};
static struct eif_par_types par996 = {996, ptf996, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf997[] = {989,0xFFF8,1,0xFFFF};
static struct eif_par_types par997 = {997, ptf997, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf998[] = {990,834,0xFFFF};
static struct eif_par_types par998 = {998, ptf998, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf999[] = {991,864,0xFFFF};
static struct eif_par_types par999 = {999, ptf999, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf1000[] = {992,867,0xFFFF};
static struct eif_par_types par1000 = {1000, ptf1000, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [NATURAL_64] */
static EIF_TYPE_INDEX ptf1001[] = {993,843,0xFFFF};
static struct eif_par_types par1001 = {1001, ptf1001, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR_CURSOR [NATURAL_32] */
static EIF_TYPE_INDEX ptf1002[] = {994,846,0xFFFF};
static struct eif_par_types par1002 = {1002, ptf1002, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SPARSE_TABLE_KEYS_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1003[] = {997,0xFFF8,2,0xFFFF};
static struct eif_par_types par1003 = {1003, ptf1003, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1004[] = {998,834,0xFFFF};
static struct eif_par_types par1004 = {1004, ptf1004, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1005[] = {998,834,0xFFFF};
static struct eif_par_types par1005 = {1005, ptf1005, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1006[] = {1002,846,0xFFFF};
static struct eif_par_types par1006 = {1006, ptf1006, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1007[] = {997,0xFFF8,1,0xFFFF};
static struct eif_par_types par1007 = {1007, ptf1007, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1008[] = {997,0xFFF8,1,0xFFFF};
static struct eif_par_types par1008 = {1008, ptf1008, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1009[] = {998,834,0xFFFF};
static struct eif_par_types par1009 = {1009, ptf1009, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1010[] = {1001,843,0xFFFF};
static struct eif_par_types par1010 = {1010, ptf1010, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1011[] = {997,0xFFF8,1,0xFFF7,771,0xFFFF};
static struct eif_par_types par1011 = {1011, ptf1011, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1012[] = {997,0xFFF8,1,0xFFF7,771,0xFFFF};
static struct eif_par_types par1012 = {1012, ptf1012, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1013[] = {998,834,0xFFF7,771,0xFFFF};
static struct eif_par_types par1013 = {1013, ptf1013, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1014[] = {1001,843,0xFFF7,771,0xFFFF};
static struct eif_par_types par1014 = {1014, ptf1014, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_SET_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1015[] = {1011,0xFFF8,1,0xFFF8,1,0xFFF7,995,0xFFF8,1,0xFFFF};
static struct eif_par_types par1015 = {1015, ptf1015, (uint16) 2, (uint16) 1, (char) 0};

/* DS_SPARSE_SET_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1016[] = {1013,834,834,0xFFF7,996,834,0xFFFF};
static struct eif_par_types par1016 = {1016, ptf1016, (uint16) 2, (uint16) 1, (char) 0};

/* DS_ARRAYED_SPARSE_SET_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1017[] = {1015,0xFFF8,1,0xFFFF};
static struct eif_par_types par1017 = {1017, ptf1017, (uint16) 1, (uint16) 1, (char) 0};

/* DS_ARRAYED_SPARSE_SET_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1018[] = {1016,834,0xFFFF};
static struct eif_par_types par1018 = {1018, ptf1018, (uint16) 1, (uint16) 1, (char) 0};

/* DS_HASH_SET_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1019[] = {1017,0xFFF8,1,0xFFFF};
static struct eif_par_types par1019 = {1019, ptf1019, (uint16) 1, (uint16) 1, (char) 0};

/* DS_HASH_SET_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1020[] = {1018,834,0xFFFF};
static struct eif_par_types par1020 = {1020, ptf1020, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SPARSE_TABLE_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1021[] = {1011,0xFFF8,1,0xFFF8,2,0xFFF7,1007,0xFFF8,1,0xFFF8,2,0xFFF7,984,0xFFF8,1,0xFFFF};
static struct eif_par_types par1021 = {1021, ptf1021, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1022[] = {1012,0xFFF8,1,834,0xFFF7,1008,0xFFF8,1,834,0xFFF7,984,0xFFF8,1,0xFFFF};
static struct eif_par_types par1022 = {1022, ptf1022, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1023[] = {1013,834,834,0xFFF7,1009,834,834,0xFFF7,985,834,0xFFFF};
static struct eif_par_types par1023 = {1023, ptf1023, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1024[] = {1014,843,846,0xFFF7,1010,843,846,0xFFF7,988,843,0xFFFF};
static struct eif_par_types par1024 = {1024, ptf1024, (uint16) 3, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1025[] = {1021,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par1025 = {1025, ptf1025, (uint16) 1, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1026[] = {1022,0xFFF8,1,834,0xFFFF};
static struct eif_par_types par1026 = {1026, ptf1026, (uint16) 1, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1027[] = {1023,834,834,0xFFFF};
static struct eif_par_types par1027 = {1027, ptf1027, (uint16) 1, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1028[] = {1024,843,846,0xFFFF};
static struct eif_par_types par1028 = {1028, ptf1028, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE_CURSOR [G#1, G#2] */
static EIF_TYPE_INDEX ptf1029[] = {1025,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par1029 = {1029, ptf1029, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE_CURSOR [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1030[] = {1026,0xFFF8,1,834,0xFFFF};
static struct eif_par_types par1030 = {1030, ptf1030, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE_CURSOR [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1031[] = {1027,834,834,0xFFFF};
static struct eif_par_types par1031 = {1031, ptf1031, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE_CURSOR [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1032[] = {1028,843,846,0xFFFF};
static struct eif_par_types par1032 = {1032, ptf1032, (uint16) 1, (uint16) 2, (char) 0};

/* DS_LIST_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1033[] = {997,0xFFF8,1,0xFFF7,984,0xFFF8,1,0xFFF7,980,0xFFF8,1,0xFFFF};
static struct eif_par_types par1033 = {1033, ptf1033, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LIST_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1034[] = {998,834,0xFFF7,985,834,0xFFF7,981,834,0xFFFF};
static struct eif_par_types par1034 = {1034, ptf1034, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LIST_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1035[] = {999,864,0xFFF7,986,864,0xFFF7,982,864,0xFFFF};
static struct eif_par_types par1035 = {1035, ptf1035, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LIST_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf1036[] = {1000,867,0xFFF7,987,867,0xFFF7,983,867,0xFFFF};
static struct eif_par_types par1036 = {1036, ptf1036, (uint16) 3, (uint16) 1, (char) 0};

/* DS_ARRAYED_LIST_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1037[] = {1033,0xFFF8,1,0xFFF7,771,0xFFFF};
static struct eif_par_types par1037 = {1037, ptf1037, (uint16) 2, (uint16) 1, (char) 0};

/* DS_ARRAYED_LIST_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1038[] = {1034,834,0xFFF7,771,0xFFFF};
static struct eif_par_types par1038 = {1038, ptf1038, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LINKED_LIST_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1039[] = {1033,0xFFF8,1,0xFFFF};
static struct eif_par_types par1039 = {1039, ptf1039, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKED_LIST_CURSOR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1040[] = {1035,864,0xFFFF};
static struct eif_par_types par1040 = {1040, ptf1040, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKED_LIST_CURSOR [BOOLEAN] */
static EIF_TYPE_INDEX ptf1041[] = {1036,867,0xFFFF};
static struct eif_par_types par1041 = {1041, ptf1041, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINKED_LIST_CURSOR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1042[] = {1034,834,0xFFFF};
static struct eif_par_types par1042 = {1042, ptf1042, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINKED_LIST_CURSOR [G#1] */
static EIF_TYPE_INDEX ptf1043[] = {1039,0xFFF8,1,0xFFFF};
static struct eif_par_types par1043 = {1043, ptf1043, (uint16) 1, (uint16) 1, (char) 0};

/* KL_SHARED_FILE_SYSTEM */
static EIF_TYPE_INDEX ptf1044[] = {0,0xFFF7,59,0xFFFF};
static struct eif_par_types par1044 = {1044, ptf1044, (uint16) 2, (uint16) 0, (char) 0};

/* KL_DIRECTORY */
static EIF_TYPE_INDEX ptf1045[] = {770,0xFFF7,1044,0xFFF7,916,0xFFF7,931,0xFFF7,769,0xFFF7,262,0xFFFF};
static struct eif_par_types par1045 = {1045, ptf1045, (uint16) 6, (uint16) 0, (char) 0};

/* AP_BASIC_PARSER */
static EIF_TYPE_INDEX ptf1046[] = {222,0xFFF7,265,0xFFF7,223,0xFFF7,236,0xFFF7,1044,0xFFF7,769,0xFFF7,916,0xFFF7,114,0xFFFF};
static struct eif_par_types par1046 = {1046, ptf1046, (uint16) 8, (uint16) 0, (char) 0};

/* AP_PARSER */
static EIF_TYPE_INDEX ptf1047[] = {1046,0xFFFF};
static struct eif_par_types par1047 = {1047, ptf1047, (uint16) 1, (uint16) 0, (char) 0};

/* KL_FILE */
static EIF_TYPE_INDEX ptf1048[] = {113,0xFFF7,1044,0xFFF7,916,0xFFF7,931,0xFFFF};
static struct eif_par_types par1048 = {1048, ptf1048, (uint16) 4, (uint16) 0, (char) 0};

/* KL_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1049[] = {924,0xFFF7,1048,0xFFFF};
static struct eif_par_types par1049 = {1049, ptf1049, (uint16) 2, (uint16) 0, (char) 0};

/* KL_TEXT_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1050[] = {930,0xFFF7,1049,0xFFF7,663,0xFFFF};
static struct eif_par_types par1050 = {1050, ptf1050, (uint16) 3, (uint16) 0, (char) 0};

/* KL_BINARY_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1051[] = {925,0xFFF7,1049,0xFFF7,662,0xFFFF};
static struct eif_par_types par1051 = {1051, ptf1051, (uint16) 3, (uint16) 0, (char) 0};

/* KL_UNIX_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1052[] = {930,0xFFF7,1051,0xFFFF};
static struct eif_par_types par1052 = {1052, ptf1052, (uint16) 2, (uint16) 0, (char) 0};

/* KL_WINDOWS_OUTPUT_FILE */
static EIF_TYPE_INDEX ptf1053[] = {930,0xFFF7,1051,0xFFFF};
static struct eif_par_types par1053 = {1053, ptf1053, (uint16) 2, (uint16) 0, (char) 0};

/* KL_INPUT_FILE */
static EIF_TYPE_INDEX ptf1054[] = {948,0xFFF7,1048,0xFFF7,268,0xFFFF};
static struct eif_par_types par1054 = {1054, ptf1054, (uint16) 3, (uint16) 0, (char) 0};

/* KL_TEXT_INPUT_FILE */
static EIF_TYPE_INDEX ptf1055[] = {950,0xFFF7,1054,0xFFF7,663,0xFFFF};
static struct eif_par_types par1055 = {1055, ptf1055, (uint16) 3, (uint16) 0, (char) 0};

/* KL_BINARY_INPUT_FILE */
static EIF_TYPE_INDEX ptf1056[] = {949,0xFFF7,1054,0xFFF7,662,0xFFFF};
static struct eif_par_types par1056 = {1056, ptf1056, (uint16) 3, (uint16) 0, (char) 0};

/* KL_UNIX_INPUT_FILE */
static EIF_TYPE_INDEX ptf1057[] = {950,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1057 = {1057, ptf1057, (uint16) 2, (uint16) 0, (char) 0};

/* KL_WINDOWS_INPUT_FILE */
static EIF_TYPE_INDEX ptf1058[] = {950,0xFFF7,1056,0xFFFF};
static struct eif_par_types par1058 = {1058, ptf1058, (uint16) 2, (uint16) 0, (char) 0};

/* LX_TABLES */
static EIF_TYPE_INDEX ptf1059[] = {0,0xFFF7,769,0xFFFF};
static struct eif_par_types par1059 = {1059, ptf1059, (uint16) 2, (uint16) 0, (char) 0};

/* LX_SCANNER */
static EIF_TYPE_INDEX ptf1060[] = {967,0xFFF7,1059,0xFFFF};
static struct eif_par_types par1060 = {1060, ptf1060, (uint16) 2, (uint16) 0, (char) 0};

/* LX_COMPRESSED_TABLES */
static EIF_TYPE_INDEX ptf1061[] = {1059,0xFFFF};
static struct eif_par_types par1061 = {1061, ptf1061, (uint16) 1, (uint16) 0, (char) 0};

/* LX_COMPRESSED_SCANNER */
static EIF_TYPE_INDEX ptf1062[] = {1060,0xFFF7,969,0xFFF7,1061,0xFFFF};
static struct eif_par_types par1062 = {1062, ptf1062, (uint16) 3, (uint16) 0, (char) 0};

/* LX_FULL_TABLES */
static EIF_TYPE_INDEX ptf1063[] = {1059,0xFFFF};
static struct eif_par_types par1063 = {1063, ptf1063, (uint16) 1, (uint16) 0, (char) 0};

/* LX_FULL_SCANNER */
static EIF_TYPE_INDEX ptf1064[] = {1060,0xFFF7,968,0xFFF7,1063,0xFFFF};
static struct eif_par_types par1064 = {1064, ptf1064, (uint16) 3, (uint16) 0, (char) 0};

/* KL_CLONABLE */
static EIF_TYPE_INDEX ptf1065[] = {0,0xFFF7,931,0xFFFF};
static struct eif_par_types par1065 = {1065, ptf1065, (uint16) 2, (uint16) 0, (char) 0};

/* LX_TRANSITION_TABLE [G#1] */
static EIF_TYPE_INDEX ptf1066[] = {0,0xFFF7,1065,0xFFFF};
static struct eif_par_types par1066 = {1066, ptf1066, (uint16) 2, (uint16) 1, (char) 0};

/* LX_STATE */
static EIF_TYPE_INDEX ptf1067[] = {1065,0xFFFF};
static struct eif_par_types par1067 = {1067, ptf1067, (uint16) 1, (uint16) 0, (char) 0};

/* LX_NFA_STATE */
static EIF_TYPE_INDEX ptf1068[] = {1067,0xFFF7,161,0xFFFF};
static struct eif_par_types par1068 = {1068, ptf1068, (uint16) 2, (uint16) 0, (char) 0};

/* LX_DFA_STATE */
static EIF_TYPE_INDEX ptf1069[] = {1067,0xFFF7,931,0xFFFF};
static struct eif_par_types par1069 = {1069, ptf1069, (uint16) 2, (uint16) 0, (char) 0};

/* LX_AUTOMATON */
static EIF_TYPE_INDEX ptf1070[] = {1065,0xFFFF};
static struct eif_par_types par1070 = {1070, ptf1070, (uint16) 1, (uint16) 0, (char) 0};

/* LX_NFA */
static EIF_TYPE_INDEX ptf1071[] = {1070,0xFFF7,931,0xFFFF};
static struct eif_par_types par1071 = {1071, ptf1071, (uint16) 2, (uint16) 0, (char) 0};

/* LX_DFA */
static EIF_TYPE_INDEX ptf1072[] = {1070,0xFFFF};
static struct eif_par_types par1072 = {1072, ptf1072, (uint16) 1, (uint16) 0, (char) 0};

/* LX_GENERATABLE_DFA */
static EIF_TYPE_INDEX ptf1073[] = {1072,0xFFF7,1059,0xFFF7,147,0xFFF7,793,0xFFF7,916,0xFFF7,221,0xFFFF};
static struct eif_par_types par1073 = {1073, ptf1073, (uint16) 6, (uint16) 0, (char) 0};

/* LX_COMPRESSED_DFA */
static EIF_TYPE_INDEX ptf1074[] = {1073,0xFFF7,1061,0xFFFF};
static struct eif_par_types par1074 = {1074, ptf1074, (uint16) 2, (uint16) 0, (char) 0};

/* LX_FULL_DFA */
static EIF_TYPE_INDEX ptf1075[] = {1073,0xFFF7,1063,0xFFFF};
static struct eif_par_types par1075 = {1075, ptf1075, (uint16) 2, (uint16) 0, (char) 0};

/* LX_TRANSITION [G#1] */
static EIF_TYPE_INDEX ptf1076[] = {1065,0xFFFF};
static struct eif_par_types par1076 = {1076, ptf1076, (uint16) 1, (uint16) 1, (char) 0};

/* LX_SYMBOL_TRANSITION [G#1] */
static EIF_TYPE_INDEX ptf1077[] = {1076,0xFFF8,1,0xFFFF};
static struct eif_par_types par1077 = {1077, ptf1077, (uint16) 1, (uint16) 1, (char) 0};

/* LX_SYMBOL_CLASS_TRANSITION [G#1] */
static EIF_TYPE_INDEX ptf1078[] = {1076,0xFFF8,1,0xFFFF};
static struct eif_par_types par1078 = {1078, ptf1078, (uint16) 1, (uint16) 1, (char) 0};

/* LX_EPSILON_TRANSITION [G#1] */
static EIF_TYPE_INDEX ptf1079[] = {1076,0xFFF8,1,0xFFFF};
static struct eif_par_types par1079 = {1079, ptf1079, (uint16) 1, (uint16) 1, (char) 0};

/* DS_CONTAINER [G#1] */
static EIF_TYPE_INDEX ptf1080[] = {0,0xFFF7,1065,0xFFFF};
static struct eif_par_types par1080 = {1080, ptf1080, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CONTAINER [INTEGER_32] */
static EIF_TYPE_INDEX ptf1081[] = {0,0xFFF7,1065,0xFFFF};
static struct eif_par_types par1081 = {1081, ptf1081, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CONTAINER [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1082[] = {0,0xFFF7,1065,0xFFFF};
static struct eif_par_types par1082 = {1082, ptf1082, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CONTAINER [BOOLEAN] */
static EIF_TYPE_INDEX ptf1083[] = {0,0xFFF7,1065,0xFFFF};
static struct eif_par_types par1083 = {1083, ptf1083, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CONTAINER [NATURAL_64] */
static EIF_TYPE_INDEX ptf1084[] = {0,0xFFF7,1065,0xFFFF};
static struct eif_par_types par1084 = {1084, ptf1084, (uint16) 2, (uint16) 1, (char) 0};

/* DS_CONTAINER [NATURAL_32] */
static EIF_TYPE_INDEX ptf1085[] = {0,0xFFF7,1065,0xFFFF};
static struct eif_par_types par1085 = {1085, ptf1085, (uint16) 2, (uint16) 1, (char) 0};

/* DS_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf1086[] = {1080,0xFFF8,1,0xFFF7,53,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par1086 = {1086, ptf1086, (uint16) 2, (uint16) 2, (char) 0};

/* DS_TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1087[] = {1080,0xFFF8,1,0xFFF7,54,0xFFF8,1,834,0xFFFF};
static struct eif_par_types par1087 = {1087, ptf1087, (uint16) 2, (uint16) 2, (char) 0};

/* DS_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1088[] = {1081,834,0xFFF7,55,834,834,0xFFFF};
static struct eif_par_types par1088 = {1088, ptf1088, (uint16) 2, (uint16) 2, (char) 0};

/* DS_TABLE [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1089[] = {1084,843,0xFFF7,56,843,846,0xFFFF};
static struct eif_par_types par1089 = {1089, ptf1089, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SORTABLE [G#1] */
static EIF_TYPE_INDEX ptf1090[] = {1080,0xFFF8,1,0xFFFF};
static struct eif_par_types par1090 = {1090, ptf1090, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SORTABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1091[] = {1081,834,0xFFFF};
static struct eif_par_types par1091 = {1091, ptf1091, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SORTABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1092[] = {1082,864,0xFFFF};
static struct eif_par_types par1092 = {1092, ptf1092, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SORTABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf1093[] = {1083,867,0xFFFF};
static struct eif_par_types par1093 = {1093, ptf1093, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [G#1] */
static EIF_TYPE_INDEX ptf1094[] = {1080,0xFFF8,1,0xFFFF};
static struct eif_par_types par1094 = {1094, ptf1094, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1095[] = {1081,834,0xFFFF};
static struct eif_par_types par1095 = {1095, ptf1095, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1096[] = {1082,864,0xFFFF};
static struct eif_par_types par1096 = {1096, ptf1096, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf1097[] = {1083,867,0xFFFF};
static struct eif_par_types par1097 = {1097, ptf1097, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf1098[] = {1084,843,0xFFFF};
static struct eif_par_types par1098 = {1098, ptf1098, (uint16) 1, (uint16) 1, (char) 0};

/* DS_TRAVERSABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf1099[] = {1085,846,0xFFFF};
static struct eif_par_types par1099 = {1099, ptf1099, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [G#1] */
static EIF_TYPE_INDEX ptf1100[] = {1080,0xFFF8,1,0xFFFF};
static struct eif_par_types par1100 = {1100, ptf1100, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1101[] = {1081,834,0xFFFF};
static struct eif_par_types par1101 = {1101, ptf1101, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1102[] = {1082,864,0xFFFF};
static struct eif_par_types par1102 = {1102, ptf1102, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf1103[] = {1083,867,0xFFFF};
static struct eif_par_types par1103 = {1103, ptf1103, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf1104[] = {1084,843,0xFFFF};
static struct eif_par_types par1104 = {1104, ptf1104, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SEARCHABLE [NATURAL_32] */
static EIF_TYPE_INDEX ptf1105[] = {1085,846,0xFFFF};
static struct eif_par_types par1105 = {1105, ptf1105, (uint16) 1, (uint16) 1, (char) 0};

/* DS_LINEAR [G#1] */
static EIF_TYPE_INDEX ptf1106[] = {1094,0xFFF8,1,0xFFF7,1100,0xFFF8,1,0xFFF7,342,0xFFF8,1,0xFFFF};
static struct eif_par_types par1106 = {1106, ptf1106, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1107[] = {1095,834,0xFFF7,1101,834,0xFFF7,343,834,0xFFFF};
static struct eif_par_types par1107 = {1107, ptf1107, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1108[] = {1096,864,0xFFF7,1102,864,0xFFF7,344,864,0xFFFF};
static struct eif_par_types par1108 = {1108, ptf1108, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR [BOOLEAN] */
static EIF_TYPE_INDEX ptf1109[] = {1097,867,0xFFF7,1103,867,0xFFF7,346,867,0xFFFF};
static struct eif_par_types par1109 = {1109, ptf1109, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR [NATURAL_64] */
static EIF_TYPE_INDEX ptf1110[] = {1098,843,0xFFF7,1104,843,0xFFF7,348,843,0xFFFF};
static struct eif_par_types par1110 = {1110, ptf1110, (uint16) 3, (uint16) 1, (char) 0};

/* DS_LINEAR [NATURAL_32] */
static EIF_TYPE_INDEX ptf1111[] = {1099,846,0xFFF7,1105,846,0xFFF7,353,846,0xFFFF};
static struct eif_par_types par1111 = {1111, ptf1111, (uint16) 3, (uint16) 1, (char) 0};

/* DS_BILINEAR [G#1] */
static EIF_TYPE_INDEX ptf1112[] = {1106,0xFFF8,1,0xFFFF};
static struct eif_par_types par1112 = {1112, ptf1112, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR [INTEGER_32] */
static EIF_TYPE_INDEX ptf1113[] = {1107,834,0xFFFF};
static struct eif_par_types par1113 = {1113, ptf1113, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1114[] = {1108,864,0xFFFF};
static struct eif_par_types par1114 = {1114, ptf1114, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR [BOOLEAN] */
static EIF_TYPE_INDEX ptf1115[] = {1109,867,0xFFFF};
static struct eif_par_types par1115 = {1115, ptf1115, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR [NATURAL_64] */
static EIF_TYPE_INDEX ptf1116[] = {1110,843,0xFFFF};
static struct eif_par_types par1116 = {1116, ptf1116, (uint16) 1, (uint16) 1, (char) 0};

/* DS_BILINEAR [NATURAL_32] */
static EIF_TYPE_INDEX ptf1117[] = {1111,846,0xFFFF};
static struct eif_par_types par1117 = {1117, ptf1117, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SPARSE_TABLE_KEYS [G#1, G#2] */
static EIF_TYPE_INDEX ptf1118[] = {1112,0xFFF8,2,0xFFFF};
static struct eif_par_types par1118 = {1118, ptf1118, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1119[] = {1113,834,0xFFFF};
static struct eif_par_types par1119 = {1119, ptf1119, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1120[] = {1113,834,0xFFFF};
static struct eif_par_types par1120 = {1120, ptf1120, (uint16) 1, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE_KEYS [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1121[] = {1117,846,0xFFFF};
static struct eif_par_types par1121 = {1121, ptf1121, (uint16) 1, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf1122[] = {1086,0xFFF8,1,0xFFF8,2,0xFFF7,1112,0xFFF8,1,0xFFFF};
static struct eif_par_types par1122 = {1122, ptf1122, (uint16) 2, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1123[] = {1087,0xFFF8,1,834,0xFFF7,1112,0xFFF8,1,0xFFFF};
static struct eif_par_types par1123 = {1123, ptf1123, (uint16) 2, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1124[] = {1088,834,834,0xFFF7,1113,834,0xFFFF};
static struct eif_par_types par1124 = {1124, ptf1124, (uint16) 2, (uint16) 2, (char) 0};

/* DS_BILINEAR_TABLE [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1125[] = {1089,843,846,0xFFF7,1116,843,0xFFFF};
static struct eif_par_types par1125 = {1125, ptf1125, (uint16) 2, (uint16) 2, (char) 0};

/* DS_EXTENDIBLE [G#1] */
static EIF_TYPE_INDEX ptf1126[] = {1100,0xFFF8,1,0xFFFF};
static struct eif_par_types par1126 = {1126, ptf1126, (uint16) 1, (uint16) 1, (char) 0};

/* DS_EXTENDIBLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1127[] = {1101,834,0xFFFF};
static struct eif_par_types par1127 = {1127, ptf1127, (uint16) 1, (uint16) 1, (char) 0};

/* DS_EXTENDIBLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1128[] = {1102,864,0xFFFF};
static struct eif_par_types par1128 = {1128, ptf1128, (uint16) 1, (uint16) 1, (char) 0};

/* DS_EXTENDIBLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf1129[] = {1103,867,0xFFFF};
static struct eif_par_types par1129 = {1129, ptf1129, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SET [G#1] */
static EIF_TYPE_INDEX ptf1130[] = {1106,0xFFF8,1,0xFFF7,1126,0xFFF8,1,0xFFFF};
static struct eif_par_types par1130 = {1130, ptf1130, (uint16) 2, (uint16) 1, (char) 0};

/* DS_SET [INTEGER_32] */
static EIF_TYPE_INDEX ptf1131[] = {1107,834,0xFFF7,1127,834,0xFFFF};
static struct eif_par_types par1131 = {1131, ptf1131, (uint16) 2, (uint16) 1, (char) 0};

/* DS_DISPENSER [INTEGER_32] */
static EIF_TYPE_INDEX ptf1132[] = {1127,834,0xFFFF};
static struct eif_par_types par1132 = {1132, ptf1132, (uint16) 1, (uint16) 1, (char) 0};

/* DS_DISPENSER [BOOLEAN] */
static EIF_TYPE_INDEX ptf1133[] = {1129,867,0xFFFF};
static struct eif_par_types par1133 = {1133, ptf1133, (uint16) 1, (uint16) 1, (char) 0};

/* DS_STACK [INTEGER_32] */
static EIF_TYPE_INDEX ptf1134[] = {1132,834,0xFFFF};
static struct eif_par_types par1134 = {1134, ptf1134, (uint16) 1, (uint16) 1, (char) 0};

/* DS_STACK [BOOLEAN] */
static EIF_TYPE_INDEX ptf1135[] = {1133,867,0xFFFF};
static struct eif_par_types par1135 = {1135, ptf1135, (uint16) 1, (uint16) 1, (char) 0};

/* DS_INDEXABLE [G#1] */
static EIF_TYPE_INDEX ptf1136[] = {1090,0xFFF8,1,0xFFF7,1126,0xFFF8,1,0xFFFF};
static struct eif_par_types par1136 = {1136, ptf1136, (uint16) 2, (uint16) 1, (char) 0};

/* DS_INDEXABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1137[] = {1091,834,0xFFF7,1127,834,0xFFFF};
static struct eif_par_types par1137 = {1137, ptf1137, (uint16) 2, (uint16) 1, (char) 0};

/* DS_INDEXABLE [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1138[] = {1092,864,0xFFF7,1128,864,0xFFFF};
static struct eif_par_types par1138 = {1138, ptf1138, (uint16) 2, (uint16) 1, (char) 0};

/* DS_INDEXABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf1139[] = {1093,867,0xFFF7,1129,867,0xFFFF};
static struct eif_par_types par1139 = {1139, ptf1139, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LIST [G#1] */
static EIF_TYPE_INDEX ptf1140[] = {1112,0xFFF8,1,0xFFF7,1136,0xFFF8,1,0xFFFF};
static struct eif_par_types par1140 = {1140, ptf1140, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf1141[] = {1113,834,0xFFF7,1137,834,0xFFFF};
static struct eif_par_types par1141 = {1141, ptf1141, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LIST [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1142[] = {1114,864,0xFFF7,1138,864,0xFFFF};
static struct eif_par_types par1142 = {1142, ptf1142, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LIST [BOOLEAN] */
static EIF_TYPE_INDEX ptf1143[] = {1115,867,0xFFF7,1139,867,0xFFFF};
static struct eif_par_types par1143 = {1143, ptf1143, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LINKED_LIST [G#1] */
static EIF_TYPE_INDEX ptf1144[] = {1140,0xFFF8,1,0xFFF7,931,0xFFFF};
static struct eif_par_types par1144 = {1144, ptf1144, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LINKED_LIST [CHARACTER_8] */
static EIF_TYPE_INDEX ptf1145[] = {1142,864,0xFFF7,931,0xFFFF};
static struct eif_par_types par1145 = {1145, ptf1145, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LINKED_LIST [BOOLEAN] */
static EIF_TYPE_INDEX ptf1146[] = {1143,867,0xFFF7,931,0xFFFF};
static struct eif_par_types par1146 = {1146, ptf1146, (uint16) 2, (uint16) 1, (char) 0};

/* DS_LINKED_LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf1147[] = {1141,834,0xFFF7,931,0xFFFF};
static struct eif_par_types par1147 = {1147, ptf1147, (uint16) 2, (uint16) 1, (char) 0};

/* LX_TEMPLATE_LIST */
static EIF_TYPE_INDEX ptf1148[] = {1144,0xFF01,1066,0xFF01,1069,0xFFFF};
static struct eif_par_types par1148 = {1148, ptf1148, (uint16) 1, (uint16) 0, (char) 0};

/* AP_ALTERNATIVE_OPTIONS_LIST */
static EIF_TYPE_INDEX ptf1149[] = {1144,0xFF01,115,0xFFFF};
static struct eif_par_types par1149 = {1149, ptf1149, (uint16) 1, (uint16) 0, (char) 0};

/* DS_BILINKED_LIST [G#1] */
static EIF_TYPE_INDEX ptf1150[] = {1144,0xFFF8,1,0xFFFF};
static struct eif_par_types par1150 = {1150, ptf1150, (uint16) 1, (uint16) 1, (char) 0};

/* LX_PROTO_QUEUE */
static EIF_TYPE_INDEX ptf1151[] = {1150,0xFF01,47,0xFFFF};
static struct eif_par_types par1151 = {1151, ptf1151, (uint16) 1, (uint16) 0, (char) 0};

/* DS_RESIZABLE [G#1] */
static EIF_TYPE_INDEX ptf1152[] = {1080,0xFFF8,1,0xFFFF};
static struct eif_par_types par1152 = {1152, ptf1152, (uint16) 1, (uint16) 1, (char) 0};

/* DS_RESIZABLE [INTEGER_32] */
static EIF_TYPE_INDEX ptf1153[] = {1081,834,0xFFFF};
static struct eif_par_types par1153 = {1153, ptf1153, (uint16) 1, (uint16) 1, (char) 0};

/* DS_RESIZABLE [BOOLEAN] */
static EIF_TYPE_INDEX ptf1154[] = {1083,867,0xFFFF};
static struct eif_par_types par1154 = {1154, ptf1154, (uint16) 1, (uint16) 1, (char) 0};

/* DS_RESIZABLE [NATURAL_64] */
static EIF_TYPE_INDEX ptf1155[] = {1084,843,0xFFFF};
static struct eif_par_types par1155 = {1155, ptf1155, (uint16) 1, (uint16) 1, (char) 0};

/* DS_ARRAYED_STACK [INTEGER_32] */
static EIF_TYPE_INDEX ptf1156[] = {1134,834,0xFFF7,1153,834,0xFFF7,931,0xFFF7,771,0xFFFF};
static struct eif_par_types par1156 = {1156, ptf1156, (uint16) 4, (uint16) 1, (char) 0};

/* DS_ARRAYED_STACK [BOOLEAN] */
static EIF_TYPE_INDEX ptf1157[] = {1135,867,0xFFF7,1154,867,0xFFF7,931,0xFFF7,771,0xFFFF};
static struct eif_par_types par1157 = {1157, ptf1157, (uint16) 4, (uint16) 1, (char) 0};

/* DS_ARRAYED_LIST [G#1] */
static EIF_TYPE_INDEX ptf1158[] = {1140,0xFFF8,1,0xFFF7,1152,0xFFF8,1,0xFFF7,931,0xFFF7,771,0xFFFF};
static struct eif_par_types par1158 = {1158, ptf1158, (uint16) 4, (uint16) 1, (char) 0};

/* DS_ARRAYED_LIST [INTEGER_32] */
static EIF_TYPE_INDEX ptf1159[] = {1141,834,0xFFF7,1153,834,0xFFF7,931,0xFFF7,771,0xFFFF};
static struct eif_par_types par1159 = {1159, ptf1159, (uint16) 4, (uint16) 1, (char) 0};

/* LX_START_CONDITIONS */
static EIF_TYPE_INDEX ptf1160[] = {1158,0xFF01,44,0xFFF7,916,0xFFF7,769,0xFFFF};
static struct eif_par_types par1160 = {1160, ptf1160, (uint16) 3, (uint16) 0, (char) 0};

/* DS_SPARSE_CONTAINER [G#1, G#2] */
static EIF_TYPE_INDEX ptf1161[] = {1080,0xFFF8,1,0xFFF7,1112,0xFFF8,1,0xFFF7,1152,0xFFF8,1,0xFFFF};
static struct eif_par_types par1161 = {1161, ptf1161, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1162[] = {1080,0xFFF8,1,0xFFF7,1112,0xFFF8,1,0xFFF7,1152,0xFFF8,1,0xFFFF};
static struct eif_par_types par1162 = {1162, ptf1162, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1163[] = {1081,834,0xFFF7,1113,834,0xFFF7,1153,834,0xFFFF};
static struct eif_par_types par1163 = {1163, ptf1163, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_CONTAINER [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1164[] = {1084,843,0xFFF7,1116,843,0xFFF7,1155,843,0xFFFF};
static struct eif_par_types par1164 = {1164, ptf1164, (uint16) 3, (uint16) 2, (char) 0};

/* DS_SPARSE_SET [G#1] */
static EIF_TYPE_INDEX ptf1165[] = {1130,0xFFF8,1,0xFFF7,1161,0xFFF8,1,0xFFF8,1,0xFFF7,931,0xFFFF};
static struct eif_par_types par1165 = {1165, ptf1165, (uint16) 3, (uint16) 1, (char) 0};

/* DS_SPARSE_SET [INTEGER_32] */
static EIF_TYPE_INDEX ptf1166[] = {1131,834,0xFFF7,1163,834,834,0xFFF7,931,0xFFFF};
static struct eif_par_types par1166 = {1166, ptf1166, (uint16) 3, (uint16) 1, (char) 0};

/* DS_ARRAYED_SPARSE_SET [G#1] */
static EIF_TYPE_INDEX ptf1167[] = {1165,0xFFF8,1,0xFFF7,267,0xFFF7,771,0xFFFF};
static struct eif_par_types par1167 = {1167, ptf1167, (uint16) 3, (uint16) 1, (char) 0};

/* DS_ARRAYED_SPARSE_SET [INTEGER_32] */
static EIF_TYPE_INDEX ptf1168[] = {1166,834,0xFFF7,267,0xFFF7,771,0xFFFF};
static struct eif_par_types par1168 = {1168, ptf1168, (uint16) 3, (uint16) 1, (char) 0};

/* DS_HASH_SET [G#1] */
static EIF_TYPE_INDEX ptf1169[] = {1167,0xFFF8,1,0xFFFF};
static struct eif_par_types par1169 = {1169, ptf1169, (uint16) 1, (uint16) 1, (char) 0};

/* DS_HASH_SET [INTEGER_32] */
static EIF_TYPE_INDEX ptf1170[] = {1168,834,0xFFFF};
static struct eif_par_types par1170 = {1170, ptf1170, (uint16) 1, (uint16) 1, (char) 0};

/* DS_SPARSE_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf1171[] = {1122,0xFFF8,1,0xFFF8,2,0xFFF7,1161,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par1171 = {1171, ptf1171, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1172[] = {1123,0xFFF8,1,834,0xFFF7,1162,0xFFF8,1,834,0xFFFF};
static struct eif_par_types par1172 = {1172, ptf1172, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1173[] = {1124,834,834,0xFFF7,1163,834,834,0xFFFF};
static struct eif_par_types par1173 = {1173, ptf1173, (uint16) 2, (uint16) 2, (char) 0};

/* DS_SPARSE_TABLE [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1174[] = {1125,843,846,0xFFF7,1164,843,846,0xFFFF};
static struct eif_par_types par1174 = {1174, ptf1174, (uint16) 2, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf1175[] = {1171,0xFFF8,1,0xFFF8,2,0xFFF7,267,0xFFF7,771,0xFFFF};
static struct eif_par_types par1175 = {1175, ptf1175, (uint16) 3, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1176[] = {1172,0xFFF8,1,834,0xFFF7,267,0xFFF7,771,0xFFFF};
static struct eif_par_types par1176 = {1176, ptf1176, (uint16) 3, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1177[] = {1173,834,834,0xFFF7,267,0xFFF7,771,0xFFFF};
static struct eif_par_types par1177 = {1177, ptf1177, (uint16) 3, (uint16) 2, (char) 0};

/* DS_ARRAYED_SPARSE_TABLE [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1178[] = {1174,843,846,0xFFF7,267,0xFFF7,771,0xFFFF};
static struct eif_par_types par1178 = {1178, ptf1178, (uint16) 3, (uint16) 2, (char) 0};

/* DS_HASH_TABLE [G#1, G#2] */
static EIF_TYPE_INDEX ptf1179[] = {1175,0xFFF8,1,0xFFF8,2,0xFFFF};
static struct eif_par_types par1179 = {1179, ptf1179, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE [G#1, INTEGER_32] */
static EIF_TYPE_INDEX ptf1180[] = {1176,0xFFF8,1,834,0xFFFF};
static struct eif_par_types par1180 = {1180, ptf1180, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE [INTEGER_32, INTEGER_32] */
static EIF_TYPE_INDEX ptf1181[] = {1177,834,834,0xFFFF};
static struct eif_par_types par1181 = {1181, ptf1181, (uint16) 1, (uint16) 2, (char) 0};

/* DS_HASH_TABLE [NATURAL_64, NATURAL_32] */
static EIF_TYPE_INDEX ptf1182[] = {1178,843,846,0xFFFF};
static struct eif_par_types par1182 = {1182, ptf1182, (uint16) 1, (uint16) 2, (char) 0};

/* RX_CASE_MAPPING */
static EIF_TYPE_INDEX ptf1183[] = {0,0xFFF7,267,0xFFF7,793,0xFFFF};
static struct eif_par_types par1183 = {1183, ptf1183, (uint16) 3, (uint16) 0, (char) 0};

/* UT_CHARACTER_FORMATTER */
static EIF_TYPE_INDEX ptf1184[] = {0,0xFFF7,221,0xFFF7,793,0xFFFF};
static struct eif_par_types par1184 = {1184, ptf1184, (uint16) 3, (uint16) 0, (char) 0};

/* RT_DBG_EXECUTION_RECORDER */
static EIF_TYPE_INDEX ptf1185[] = {0,0xFFFF};
static struct eif_par_types par1185 = {1185, ptf1185, (uint16) 1, (uint16) 0, (char) 0};

/* KI_FILE_SYSTEM */
static EIF_TYPE_INDEX ptf1186[] = {0,0xFFF7,931,0xFFF7,769,0xFFFF};
static struct eif_par_types par1186 = {1186, ptf1186, (uint16) 3, (uint16) 0, (char) 0};

/* KL_FILE_SYSTEM */
static EIF_TYPE_INDEX ptf1187[] = {1186,0xFFF7,916,0xFFF7,931,0xFFF7,1044,0xFFFF};
static struct eif_par_types par1187 = {1187, ptf1187, (uint16) 4, (uint16) 0, (char) 0};

/* KL_UNIX_FILE_SYSTEM */
static EIF_TYPE_INDEX ptf1188[] = {1187,0xFFFF};
static struct eif_par_types par1188 = {1188, ptf1188, (uint16) 1, (uint16) 0, (char) 0};

/* KL_WINDOWS_FILE_SYSTEM */
static EIF_TYPE_INDEX ptf1189[] = {1187,0xFFFF};
static struct eif_par_types par1189 = {1189, ptf1189, (uint16) 1, (uint16) 0, (char) 0};

/* KL_WINDOWS_FILE_SYSTEM_BACKSLASH_ONLY */
static EIF_TYPE_INDEX ptf1190[] = {1189,0xFFFF};
static struct eif_par_types par1190 = {1190, ptf1190, (uint16) 1, (uint16) 0, (char) 0};

/* UT_ERROR_HANDLER */
static EIF_TYPE_INDEX ptf1191[] = {0,0xFFF7,265,0xFFF7,146,0xFFFF};
static struct eif_par_types par1191 = {1191, ptf1191, (uint16) 3, (uint16) 0, (char) 0};

/* AP_ERROR_HANDLER */
static EIF_TYPE_INDEX ptf1192[] = {1191,0xFFFF};
static struct eif_par_types par1192 = {1192, ptf1192, (uint16) 1, (uint16) 0, (char) 0};

/* RX_PATTERN_MATCHER */
static EIF_TYPE_INDEX ptf1193[] = {0,0xFFF7,916,0xFFF7,931,0xFFFF};
static struct eif_par_types par1193 = {1193, ptf1193, (uint16) 3, (uint16) 0, (char) 0};

/* RX_REGULAR_EXPRESSION */
static EIF_TYPE_INDEX ptf1194[] = {1193,0xFFF7,109,0xFFF7,769,0xFFFF};
static struct eif_par_types par1194 = {1194, ptf1194, (uint16) 3, (uint16) 0, (char) 0};

/* UC_UNICODE_ROUTINES */
static EIF_TYPE_INDEX ptf1195[] = {0,0xFFF7,965,0xFFF7,793,0xFFF7,64,0xFFFF};
static struct eif_par_types par1195 = {1195, ptf1195, (uint16) 4, (uint16) 0, (char) 0};

/* YY_PARSER_TOKENS */
static EIF_TYPE_INDEX ptf1196[] = {0,0xFFF7,64,0xFFF7,793,0xFFF7,916,0xFFFF};
static struct eif_par_types par1196 = {1196, ptf1196, (uint16) 4, (uint16) 0, (char) 0};

/* LX_LEX_TOKENS */
static EIF_TYPE_INDEX ptf1197[] = {1196,0xFFFF};
static struct eif_par_types par1197 = {1197, ptf1197, (uint16) 1, (uint16) 0, (char) 0};

/* LX_LEX_SCANNER */
static EIF_TYPE_INDEX ptf1198[] = {970,0xFFF7,1197,0xFFFF};
static struct eif_par_types par1198 = {1198, ptf1198, (uint16) 2, (uint16) 0, (char) 0};

/* YY_PARSER_SKELETON */
static EIF_TYPE_INDEX ptf1199[] = {62,0xFFF7,1196,0xFFF7,265,0xFFF7,267,0xFFF7,769,0xFFFF};
static struct eif_par_types par1199 = {1199, ptf1199, (uint16) 5, (uint16) 0, (char) 0};

/* LX_LEX_PARSER_SKELETON */
static EIF_TYPE_INDEX ptf1200[] = {1199,0xFFF7,970,0xFFFF};
static struct eif_par_types par1200 = {1200, ptf1200, (uint16) 2, (uint16) 0, (char) 0};

/* LX_LEX_PARSER */
static EIF_TYPE_INDEX ptf1201[] = {1200,0xFFF7,1198,0xFFFF};
static struct eif_par_types par1201 = {1201, ptf1201, (uint16) 2, (uint16) 0, (char) 0};

/* UT_STRING_FORMATTER */
static EIF_TYPE_INDEX ptf1202[] = {0,0xFFF7,916,0xFFF7,793,0xFFF7,931,0xFFF7,221,0xFFFF};
static struct eif_par_types par1202 = {1202, ptf1202, (uint16) 5, (uint16) 0, (char) 0};

/* UT_ERROR */
static EIF_TYPE_INDEX ptf1203[] = {0,0xFFF7,222,0xFFF7,916,0xFFF7,769,0xFFF7,931,0xFFFF};
static struct eif_par_types par1203 = {1203, ptf1203, (uint16) 5, (uint16) 0, (char) 0};

/* LX_MISSING_BRACKET_ERROR */
static EIF_TYPE_INDEX ptf1204[] = {1203,0xFFFF};
static struct eif_par_types par1204 = {1204, ptf1204, (uint16) 1, (uint16) 0, (char) 0};

/* LX_UNRECOGNIZED_OPTION_ERROR */
static EIF_TYPE_INDEX ptf1205[] = {1203,0xFFFF};
static struct eif_par_types par1205 = {1205, ptf1205, (uint16) 1, (uint16) 0, (char) 0};

/* LX_UNRECOGNIZED_DIRECTIVE_ERROR */
static EIF_TYPE_INDEX ptf1206[] = {1203,0xFFFF};
static struct eif_par_types par1206 = {1206, ptf1206, (uint16) 1, (uint16) 0, (char) 0};

/* LX_UNDEFINED_DEFINITION_ERROR */
static EIF_TYPE_INDEX ptf1207[] = {1203,0xFFFF};
static struct eif_par_types par1207 = {1207, ptf1207, (uint16) 1, (uint16) 0, (char) 0};

/* LX_START_CONDITION_EXPECTED_ERROR */
static EIF_TYPE_INDEX ptf1208[] = {1203,0xFFFF};
static struct eif_par_types par1208 = {1208, ptf1208, (uint16) 1, (uint16) 0, (char) 0};

/* LX_START_CONDITION_DECLARED_TWICE_ERROR */
static EIF_TYPE_INDEX ptf1209[] = {1203,0xFFFF};
static struct eif_par_types par1209 = {1209, ptf1209, (uint16) 1, (uint16) 0, (char) 0};

/* LX_NAME_DEFINED_TWICE_ERROR */
static EIF_TYPE_INDEX ptf1210[] = {1203,0xFFFF};
static struct eif_par_types par1210 = {1210, ptf1210, (uint16) 1, (uint16) 0, (char) 0};

/* LX_MISSING_QUOTE_ERROR */
static EIF_TYPE_INDEX ptf1211[] = {1203,0xFFFF};
static struct eif_par_types par1211 = {1211, ptf1211, (uint16) 1, (uint16) 0, (char) 0};

/* LX_INCOMPLETE_NAME_DEFINITION_ERROR */
static EIF_TYPE_INDEX ptf1212[] = {1203,0xFFFF};
static struct eif_par_types par1212 = {1212, ptf1212, (uint16) 1, (uint16) 0, (char) 0};

/* LX_DIRECTIVE_EXPECTED_ERROR */
static EIF_TYPE_INDEX ptf1213[] = {1203,0xFFFF};
static struct eif_par_types par1213 = {1213, ptf1213, (uint16) 1, (uint16) 0, (char) 0};

/* LX_INTEGER_TOO_LARGE_ERROR */
static EIF_TYPE_INDEX ptf1214[] = {1203,0xFFFF};
static struct eif_par_types par1214 = {1214, ptf1214, (uint16) 1, (uint16) 0, (char) 0};

/* LX_INVALID_UNICODE_CHARACTER_ERROR */
static EIF_TYPE_INDEX ptf1215[] = {1203,0xFFFF};
static struct eif_par_types par1215 = {1215, ptf1215, (uint16) 1, (uint16) 0, (char) 0};

/* LX_CHARACTER_OUT_OF_RANGE_ERROR */
static EIF_TYPE_INDEX ptf1216[] = {1203,0xFFFF};
static struct eif_par_types par1216 = {1216, ptf1216, (uint16) 1, (uint16) 0, (char) 0};

/* LX_BAD_START_CONDITION_ERROR */
static EIF_TYPE_INDEX ptf1217[] = {1203,0xFFFF};
static struct eif_par_types par1217 = {1217, ptf1217, (uint16) 1, (uint16) 0, (char) 0};

/* LX_BAD_CHARACTER_IN_BRACKETS_ERROR */
static EIF_TYPE_INDEX ptf1218[] = {1203,0xFFFF};
static struct eif_par_types par1218 = {1218, ptf1218, (uint16) 1, (uint16) 0, (char) 0};

/* LX_BAD_CHARACTER_CLASS_ERROR */
static EIF_TYPE_INDEX ptf1219[] = {1203,0xFFFF};
static struct eif_par_types par1219 = {1219, ptf1219, (uint16) 1, (uint16) 0, (char) 0};

/* LX_BAD_CHARACTER_ERROR */
static EIF_TYPE_INDEX ptf1220[] = {1203,0xFFFF};
static struct eif_par_types par1220 = {1220, ptf1220, (uint16) 1, (uint16) 0, (char) 0};

/* UT_SYNTAX_ERROR */
static EIF_TYPE_INDEX ptf1221[] = {1203,0xFFFF};
static struct eif_par_types par1221 = {1221, ptf1221, (uint16) 1, (uint16) 0, (char) 0};

/* LX_FULL_AND_REJECT_ERROR */
static EIF_TYPE_INDEX ptf1222[] = {1203,0xFFFF};
static struct eif_par_types par1222 = {1222, ptf1222, (uint16) 1, (uint16) 0, (char) 0};

/* LX_FULL_AND_META_ERROR */
static EIF_TYPE_INDEX ptf1223[] = {1203,0xFFFF};
static struct eif_par_types par1223 = {1223, ptf1223, (uint16) 1, (uint16) 0, (char) 0};

/* LX_UNDECLARED_START_CONDITION_ERROR */
static EIF_TYPE_INDEX ptf1224[] = {1203,0xFFFF};
static struct eif_par_types par1224 = {1224, ptf1224, (uint16) 1, (uint16) 0, (char) 0};

/* LX_TRAILING_CONTEXT_USED_TWICE_ERROR */
static EIF_TYPE_INDEX ptf1225[] = {1203,0xFFFF};
static struct eif_par_types par1225 = {1225, ptf1225, (uint16) 1, (uint16) 0, (char) 0};

/* LX_START_CONDITION_SPECIFIED_TWICE_ERROR */
static EIF_TYPE_INDEX ptf1226[] = {1203,0xFFFF};
static struct eif_par_types par1226 = {1226, ptf1226, (uint16) 1, (uint16) 0, (char) 0};

/* LX_NEGATIVE_RANGE_IN_CHARACTER_CLASS_ERROR */
static EIF_TYPE_INDEX ptf1227[] = {1203,0xFFFF};
static struct eif_par_types par1227 = {1227, ptf1227, (uint16) 1, (uint16) 0, (char) 0};

/* LX_MULTIPLE_EOF_RULES_ERROR */
static EIF_TYPE_INDEX ptf1228[] = {1203,0xFFFF};
static struct eif_par_types par1228 = {1228, ptf1228, (uint16) 1, (uint16) 0, (char) 0};

/* LX_ITERATION_NOT_POSITIVE_ERROR */
static EIF_TYPE_INDEX ptf1229[] = {1203,0xFFFF};
static struct eif_par_types par1229 = {1229, ptf1229, (uint16) 1, (uint16) 0, (char) 0};

/* LX_BAD_ITERATION_VALUES_ERROR */
static EIF_TYPE_INDEX ptf1230[] = {1203,0xFFFF};
static struct eif_par_types par1230 = {1230, ptf1230, (uint16) 1, (uint16) 0, (char) 0};

/* LX_BAD_START_CONDITION_LIST_ERROR */
static EIF_TYPE_INDEX ptf1231[] = {1203,0xFFFF};
static struct eif_par_types par1231 = {1231, ptf1231, (uint16) 1, (uint16) 0, (char) 0};

/* LX_ALL_START_CONDITIONS_EOF_ERROR */
static EIF_TYPE_INDEX ptf1232[] = {1203,0xFFFF};
static struct eif_par_types par1232 = {1232, ptf1232, (uint16) 1, (uint16) 0, (char) 0};

/* LX_FULL_AND_VARIABLE_TRAILING_CONTEXT_ERROR */
static EIF_TYPE_INDEX ptf1233[] = {1203,0xFFFF};
static struct eif_par_types par1233 = {1233, ptf1233, (uint16) 1, (uint16) 0, (char) 0};

/* LX_UNRECOGNIZED_RULE_ERROR */
static EIF_TYPE_INDEX ptf1234[] = {1203,0xFFFF};
static struct eif_par_types par1234 = {1234, ptf1234, (uint16) 1, (uint16) 0, (char) 0};

/* AP_ERROR */
static EIF_TYPE_INDEX ptf1235[] = {1203,0xFFFF};
static struct eif_par_types par1235 = {1235, ptf1235, (uint16) 1, (uint16) 0, (char) 0};

/* UT_VERSION_NUMBER */
static EIF_TYPE_INDEX ptf1236[] = {1203,0xFFFF};
static struct eif_par_types par1236 = {1236, ptf1236, (uint16) 1, (uint16) 0, (char) 0};

/* LX_DEFAULT_RULE_CAN_BE_MATCHED_ERROR */
static EIF_TYPE_INDEX ptf1237[] = {1203,0xFFFF};
static struct eif_par_types par1237 = {1237, ptf1237, (uint16) 1, (uint16) 0, (char) 0};

/* LX_RULE_CANNOT_BE_MATCHED_ERROR */
static EIF_TYPE_INDEX ptf1238[] = {1203,0xFFFF};
static struct eif_par_types par1238 = {1238, ptf1238, (uint16) 1, (uint16) 0, (char) 0};

/* LX_DANGEROUS_TRAILING_CONTEXT_ERROR */
static EIF_TYPE_INDEX ptf1239[] = {1203,0xFFFF};
static struct eif_par_types par1239 = {1239, ptf1239, (uint16) 1, (uint16) 0, (char) 0};

/* UT_CANNOT_WRITE_TO_FILE_ERROR */
static EIF_TYPE_INDEX ptf1240[] = {1203,0xFFFF};
static struct eif_par_types par1240 = {1240, ptf1240, (uint16) 1, (uint16) 0, (char) 0};

/* UT_CANNOT_READ_FILE_ERROR */
static EIF_TYPE_INDEX ptf1241[] = {1203,0xFFFF};
static struct eif_par_types par1241 = {1241, ptf1241, (uint16) 1, (uint16) 0, (char) 0};

/* KI_PATHNAME */
static EIF_TYPE_INDEX ptf1242[] = {0,0xFFF7,1065,0xFFF7,916,0xFFF7,931,0xFFF7,769,0xFFF7,236,0xFFF7,52,0xFFFF};
static struct eif_par_types par1242 = {1242, ptf1242, (uint16) 7, (uint16) 0, (char) 0};

/* KL_PATHNAME */
static EIF_TYPE_INDEX ptf1243[] = {1242,0xFFF7,769,0xFFFF};
static struct eif_par_types par1243 = {1243, ptf1243, (uint16) 2, (uint16) 0, (char) 0};

/* RX_PCRE_COMPILER */
static EIF_TYPE_INDEX ptf1244[] = {0,0xFFF7,51,0xFFF7,50,0xFFF7,960,0xFFF7,49,0xFFF7,48,0xFFF7,916,0xFFF7,122,0xFFF7,793,0xFFF7,221,0xFFF7,265,0xFFF7,64,0xFFFF};
static struct eif_par_types par1244 = {1244, ptf1244, (uint16) 12, (uint16) 0, (char) 0};

/* RX_PCRE_MATCHER */
static EIF_TYPE_INDEX ptf1245[] = {1193,0xFFF7,1244,0xFFF7,267,0xFFFF};
static struct eif_par_types par1245 = {1245, ptf1245, (uint16) 3, (uint16) 0, (char) 0};

/* RX_PCRE_REGULAR_EXPRESSION */
static EIF_TYPE_INDEX ptf1246[] = {1194,0xFFF7,1245,0xFFFF};
static struct eif_par_types par1246 = {1246, ptf1246, (uint16) 2, (uint16) 0, (char) 0};

/* UC_STRING */
static EIF_TYPE_INDEX ptf1247[] = {0,0xFFF7,915,0xFFF7,161,0xFFF7,926,0xFFF7,68,0xFFF7,239,0xFFF7,67,0xFFF7,124,0xFFF7,123,0xFFF7,793,0xFFF7,931,0xFFF7,64,0xFFF7,273,0xFFFF};
static struct eif_par_types par1247 = {1247, ptf1247, (uint16) 13, (uint16) 0, (char) 0};

/* UC_UTF8_STRING */
static EIF_TYPE_INDEX ptf1248[] = {1247,0xFFFF};
static struct eif_par_types par1248 = {1248, ptf1248, (uint16) 1, (uint16) 0, (char) 0};

int egc_partab_size_init = 1248				;
				struct eif_par_types *egc_partab_init[] = {
&par0,
&par1,
&par2,
&par3,
&par4,
&par5,
&par6,
&par7,
&par8,
&par9,
&par10,
&par11,
&par12,
&par13,
&par14,
&par15,
&par16,
&par17,
&par18,
&par19,
&par20,
&par21,
&par22,
&par23,
&par24,
&par25,
&par26,
&par27,
&par28,
&par29,
&par30,
&par31,
&par32,
&par33,
&par34,
&par35,
&par36,
&par37,
&par38,
&par39,
&par40,
&par41,
&par42,
&par43,
&par44,
&par45,
&par46,
&par47,
&par48,
&par49,
&par50,
&par51,
&par52,
&par53,
&par54,
&par55,
&par56,
&par57,
&par58,
&par59,
&par60,
&par61,
&par62,
&par63,
&par64,
&par65,
&par66,
&par67,
&par68,
&par69,
&par70,
&par71,
&par72,
&par73,
&par74,
&par75,
&par76,
&par77,
&par78,
&par79,
&par80,
&par81,
&par82,
&par83,
&par84,
&par85,
&par86,
&par87,
&par88,
&par89,
&par90,
&par91,
&par92,
&par93,
&par94,
&par95,
&par96,
&par97,
&par98,
&par99,
&par100,
&par101,
&par102,
&par103,
&par104,
&par105,
&par106,
&par107,
&par108,
&par109,
&par110,
&par111,
&par112,
&par113,
&par114,
&par115,
&par116,
&par117,
&par118,
&par119,
&par120,
&par121,
&par122,
&par123,
&par124,
&par125,
&par126,
&par127,
&par128,
&par129,
&par130,
&par131,
&par132,
&par133,
&par134,
&par135,
&par136,
&par137,
&par138,
&par139,
&par140,
&par141,
&par142,
&par143,
&par144,
&par145,
&par146,
&par147,
&par148,
&par149,
&par150,
&par151,
&par152,
&par153,
&par154,
&par155,
&par156,
&par157,
&par158,
&par159,
&par160,
&par161,
&par162,
&par163,
&par164,
&par165,
&par166,
&par167,
&par168,
&par169,
&par170,
&par171,
&par172,
&par173,
&par174,
&par175,
&par176,
&par177,
&par178,
&par179,
&par180,
&par181,
&par182,
&par183,
&par184,
&par185,
&par186,
&par187,
&par188,
&par189,
&par190,
&par191,
&par192,
&par193,
&par194,
&par195,
&par196,
&par197,
&par198,
&par199,
&par200,
&par201,
&par202,
&par203,
&par204,
&par205,
&par206,
&par207,
&par208,
&par209,
&par210,
&par211,
&par212,
&par213,
&par214,
&par215,
&par216,
&par217,
&par218,
&par219,
&par220,
&par221,
&par222,
&par223,
&par224,
&par225,
&par226,
&par227,
&par228,
&par229,
&par230,
&par231,
&par232,
&par233,
&par234,
&par235,
&par236,
&par237,
&par238,
&par239,
&par240,
&par241,
&par242,
&par243,
&par244,
&par245,
&par246,
&par247,
&par248,
&par249,
&par250,
&par251,
&par252,
&par253,
&par254,
&par255,
&par256,
&par257,
&par258,
&par259,
&par260,
&par261,
&par262,
&par263,
&par264,
&par265,
&par266,
&par267,
&par268,
&par269,
&par270,
&par271,
&par272,
&par273,
&par274,
&par275,
&par276,
&par277,
&par278,
&par279,
&par280,
&par281,
&par282,
&par283,
&par284,
&par285,
&par286,
&par287,
&par288,
&par289,
&par290,
&par291,
&par292,
&par293,
&par294,
&par295,
&par296,
&par297,
&par298,
&par299,
&par300,
&par301,
&par302,
&par303,
&par304,
&par305,
&par306,
&par307,
&par308,
&par309,
&par310,
&par311,
&par312,
&par313,
&par314,
&par315,
&par316,
&par317,
&par318,
&par319,
&par320,
&par321,
&par322,
&par323,
&par324,
&par325,
&par326,
&par327,
&par328,
&par329,
&par330,
&par331,
&par332,
&par333,
&par334,
&par335,
&par336,
&par337,
&par338,
&par339,
&par340,
&par341,
&par342,
&par343,
&par344,
&par345,
&par346,
&par347,
&par348,
&par349,
&par350,
&par351,
&par352,
&par353,
&par354,
&par355,
&par356,
&par357,
&par358,
&par359,
&par360,
&par361,
&par362,
&par363,
&par364,
&par365,
&par366,
&par367,
&par368,
&par369,
&par370,
&par371,
&par372,
&par373,
&par374,
&par375,
&par376,
&par377,
&par378,
&par379,
&par380,
&par381,
&par382,
&par383,
&par384,
&par385,
&par386,
&par387,
&par388,
&par389,
&par390,
&par391,
&par392,
&par393,
&par394,
&par395,
&par396,
&par397,
&par398,
&par399,
&par400,
&par401,
&par402,
&par403,
&par404,
&par405,
&par406,
&par407,
&par408,
&par409,
&par410,
&par411,
&par412,
&par413,
&par414,
&par415,
&par416,
&par417,
&par418,
&par419,
&par420,
&par421,
&par422,
&par423,
&par424,
&par425,
&par426,
&par427,
&par428,
&par429,
&par430,
&par431,
&par432,
&par433,
&par434,
&par435,
&par436,
&par437,
&par438,
&par439,
&par440,
&par441,
&par442,
&par443,
&par444,
&par445,
&par446,
&par447,
&par448,
&par449,
&par450,
&par451,
&par452,
&par453,
&par454,
&par455,
&par456,
&par457,
&par458,
&par459,
&par460,
&par461,
&par462,
&par463,
&par464,
&par465,
&par466,
&par467,
&par468,
&par469,
&par470,
&par471,
&par472,
&par473,
&par474,
&par475,
&par476,
&par477,
&par478,
&par479,
&par480,
&par481,
&par482,
&par483,
&par484,
&par485,
&par486,
&par487,
&par488,
&par489,
&par490,
&par491,
&par492,
&par493,
&par494,
&par495,
&par496,
&par497,
&par498,
&par499,
&par500,
&par501,
&par502,
&par503,
&par504,
&par505,
&par506,
&par507,
&par508,
&par509,
&par510,
&par511,
&par512,
&par513,
&par514,
&par515,
&par516,
&par517,
&par518,
&par519,
&par520,
&par521,
&par522,
&par523,
&par524,
&par525,
&par526,
&par527,
&par528,
&par529,
&par530,
&par531,
&par532,
&par533,
&par534,
&par535,
&par536,
&par537,
&par538,
&par539,
&par540,
&par541,
&par542,
&par543,
&par544,
&par545,
&par546,
&par547,
&par548,
&par549,
&par550,
&par551,
&par552,
&par553,
&par554,
&par555,
&par556,
&par557,
&par558,
&par559,
&par560,
&par561,
&par562,
&par563,
&par564,
&par565,
&par566,
&par567,
&par568,
&par569,
&par570,
&par571,
&par572,
&par573,
&par574,
&par575,
&par576,
&par577,
&par578,
&par579,
&par580,
&par581,
&par582,
&par583,
&par584,
&par585,
&par586,
&par587,
&par588,
&par589,
&par590,
&par591,
&par592,
&par593,
&par594,
&par595,
&par596,
&par597,
&par598,
&par599,
&par600,
&par601,
&par602,
&par603,
&par604,
&par605,
&par606,
&par607,
&par608,
&par609,
&par610,
&par611,
&par612,
&par613,
&par614,
&par615,
&par616,
&par617,
&par618,
&par619,
&par620,
&par621,
&par622,
&par623,
&par624,
&par625,
&par626,
&par627,
&par628,
&par629,
&par630,
&par631,
&par632,
&par633,
&par634,
&par635,
&par636,
&par637,
&par638,
&par639,
&par640,
&par641,
&par642,
&par643,
&par644,
&par645,
&par646,
&par647,
&par648,
&par649,
&par650,
&par651,
&par652,
&par653,
&par654,
&par655,
&par656,
&par657,
&par658,
&par659,
&par660,
&par661,
&par662,
&par663,
&par664,
&par665,
&par666,
&par667,
&par668,
&par669,
&par670,
&par671,
&par672,
&par673,
&par674,
&par675,
&par676,
&par677,
&par678,
&par679,
&par680,
&par681,
&par682,
&par683,
&par684,
&par685,
&par686,
&par687,
&par688,
&par689,
&par690,
&par691,
&par692,
&par693,
&par694,
&par695,
&par696,
&par697,
&par698,
&par699,
&par700,
&par701,
&par702,
&par703,
&par704,
&par705,
&par706,
&par707,
&par708,
&par709,
&par710,
&par711,
&par712,
&par713,
&par714,
&par715,
&par716,
&par717,
&par718,
&par719,
&par720,
&par721,
&par722,
&par723,
&par724,
&par725,
&par726,
&par727,
&par728,
&par729,
&par730,
&par731,
&par732,
&par733,
&par734,
&par735,
&par736,
&par737,
&par738,
&par739,
&par740,
&par741,
&par742,
&par743,
&par744,
&par745,
&par746,
&par747,
&par748,
&par749,
&par750,
&par751,
&par752,
&par753,
&par754,
&par755,
&par756,
&par757,
&par758,
&par759,
&par760,
&par761,
&par762,
&par763,
&par764,
&par765,
&par766,
&par767,
&par768,
&par769,
&par770,
&par771,
&par772,
&par773,
&par774,
&par775,
&par776,
&par777,
&par778,
&par779,
&par780,
&par781,
&par782,
&par783,
&par784,
&par785,
&par786,
&par787,
&par788,
&par789,
&par790,
&par791,
&par792,
&par793,
&par794,
&par795,
&par796,
&par797,
&par798,
&par799,
&par800,
&par801,
&par802,
&par803,
&par804,
&par805,
&par806,
&par807,
&par808,
&par809,
&par810,
&par811,
&par812,
&par813,
&par814,
&par815,
&par816,
&par817,
&par818,
&par819,
&par820,
&par821,
&par822,
&par823,
&par824,
&par825,
&par826,
&par827,
&par828,
&par829,
&par830,
&par831,
&par832,
&par833,
&par834,
&par835,
&par836,
&par837,
&par838,
&par839,
&par840,
&par841,
&par842,
&par843,
&par844,
&par845,
&par846,
&par847,
&par848,
&par849,
&par850,
&par851,
&par852,
&par853,
&par854,
&par855,
&par856,
&par857,
&par858,
&par859,
&par860,
&par861,
&par862,
&par863,
&par864,
&par865,
&par866,
&par867,
&par868,
&par869,
&par870,
&par871,
&par872,
&par873,
&par874,
&par875,
&par876,
&par877,
&par878,
&par879,
&par880,
&par881,
&par882,
&par883,
&par884,
&par885,
&par886,
&par887,
&par888,
&par889,
&par890,
&par891,
&par892,
&par893,
&par894,
&par895,
&par896,
&par897,
&par898,
&par899,
&par900,
&par901,
&par902,
&par903,
&par904,
&par905,
&par906,
&par907,
&par908,
&par909,
&par910,
&par911,
&par912,
&par913,
&par914,
&par915,
&par916,
&par917,
&par918,
&par919,
&par920,
&par921,
&par922,
&par923,
&par924,
&par925,
&par926,
&par927,
&par928,
&par929,
&par930,
&par931,
&par932,
&par933,
&par934,
&par935,
&par936,
&par937,
&par938,
&par939,
&par940,
&par941,
&par942,
&par943,
&par944,
&par945,
&par946,
&par947,
&par948,
&par949,
&par950,
&par951,
&par952,
&par953,
&par954,
&par955,
&par956,
&par957,
&par958,
&par959,
&par960,
&par961,
&par962,
&par963,
&par964,
&par965,
&par966,
&par967,
&par968,
&par969,
&par970,
&par971,
&par972,
&par973,
&par974,
&par975,
&par976,
&par977,
&par978,
&par979,
&par980,
&par981,
&par982,
&par983,
&par984,
&par985,
&par986,
&par987,
&par988,
&par989,
&par990,
&par991,
&par992,
&par993,
&par994,
&par995,
&par996,
&par997,
&par998,
&par999,
&par1000,
&par1001,
&par1002,
&par1003,
&par1004,
&par1005,
&par1006,
&par1007,
&par1008,
&par1009,
&par1010,
&par1011,
&par1012,
&par1013,
&par1014,
&par1015,
&par1016,
&par1017,
&par1018,
&par1019,
&par1020,
&par1021,
&par1022,
&par1023,
&par1024,
&par1025,
&par1026,
&par1027,
&par1028,
&par1029,
&par1030,
&par1031,
&par1032,
&par1033,
&par1034,
&par1035,
&par1036,
&par1037,
&par1038,
&par1039,
&par1040,
&par1041,
&par1042,
&par1043,
&par1044,
&par1045,
&par1046,
&par1047,
&par1048,
&par1049,
&par1050,
&par1051,
&par1052,
&par1053,
&par1054,
&par1055,
&par1056,
&par1057,
&par1058,
&par1059,
&par1060,
&par1061,
&par1062,
&par1063,
&par1064,
&par1065,
&par1066,
&par1067,
&par1068,
&par1069,
&par1070,
&par1071,
&par1072,
&par1073,
&par1074,
&par1075,
&par1076,
&par1077,
&par1078,
&par1079,
&par1080,
&par1081,
&par1082,
&par1083,
&par1084,
&par1085,
&par1086,
&par1087,
&par1088,
&par1089,
&par1090,
&par1091,
&par1092,
&par1093,
&par1094,
&par1095,
&par1096,
&par1097,
&par1098,
&par1099,
&par1100,
&par1101,
&par1102,
&par1103,
&par1104,
&par1105,
&par1106,
&par1107,
&par1108,
&par1109,
&par1110,
&par1111,
&par1112,
&par1113,
&par1114,
&par1115,
&par1116,
&par1117,
&par1118,
&par1119,
&par1120,
&par1121,
&par1122,
&par1123,
&par1124,
&par1125,
&par1126,
&par1127,
&par1128,
&par1129,
&par1130,
&par1131,
&par1132,
&par1133,
&par1134,
&par1135,
&par1136,
&par1137,
&par1138,
&par1139,
&par1140,
&par1141,
&par1142,
&par1143,
&par1144,
&par1145,
&par1146,
&par1147,
&par1148,
&par1149,
&par1150,
&par1151,
&par1152,
&par1153,
&par1154,
&par1155,
&par1156,
&par1157,
&par1158,
&par1159,
&par1160,
&par1161,
&par1162,
&par1163,
&par1164,
&par1165,
&par1166,
&par1167,
&par1168,
&par1169,
&par1170,
&par1171,
&par1172,
&par1173,
&par1174,
&par1175,
&par1176,
&par1177,
&par1178,
&par1179,
&par1180,
&par1181,
&par1182,
&par1183,
&par1184,
&par1185,
&par1186,
&par1187,
&par1188,
&par1189,
&par1190,
&par1191,
&par1192,
&par1193,
&par1194,
&par1195,
&par1196,
&par1197,
&par1198,
&par1199,
&par1200,
&par1201,
&par1202,
&par1203,
&par1204,
&par1205,
&par1206,
&par1207,
&par1208,
&par1209,
&par1210,
&par1211,
&par1212,
&par1213,
&par1214,
&par1215,
&par1216,
&par1217,
&par1218,
&par1219,
&par1220,
&par1221,
&par1222,
&par1223,
&par1224,
&par1225,
&par1226,
&par1227,
&par1228,
&par1229,
&par1230,
&par1231,
&par1232,
&par1233,
&par1234,
&par1235,
&par1236,
&par1237,
&par1238,
&par1239,
&par1240,
&par1241,
&par1242,
&par1243,
&par1244,
&par1245,
&par1246,
&par1247,
&par1248,
NULL};

#ifdef __cplusplus
}
#endif
